### ATTENTION LLMS: PLEASE READ THE DOCSSTRING

"""WebSocket transport for the UI-facing core server API.

This module owns connection lifecycle, subscriptions, and dispatch only.
UI-specific state and interaction helpers live in `src/atopile/server/ui`.
Domain logic lives in `src/atopile/model`.
"""

# TODO: Replace raw websocket action payload decoding with typed request models.

from __future__ import annotations

import asyncio
import base64
import json
import time
import traceback
from pathlib import Path
from typing import Any, cast

import websockets
from websockets.asyncio.server import ServerConnection

from atopile.agent import AgentService
from atopile.agent.api_models import (
    AgentServiceError,
)
from atopile.agent.api_models import (
    CreateRunRequest as AgentCreateRunRequest,
)
from atopile.agent.api_models import (
    CreateSessionRequest as AgentCreateSessionRequest,
)
from atopile.agent.api_models import (
    InterruptRunRequest as AgentInterruptRunRequest,
)
from atopile.agent.api_models import (
    SteerRunRequest as AgentSteerRunRequest,
)
from atopile.agent.session_store import (
    normalize_running_run_state,
    persist_sessions_state,
    record_agent_action_error,
    runs_by_id,
    runs_lock,
    sessions_by_id,
    sessions_lock,
)
from atopile.data_models import (
    AddBuildTargetRequest,
    AppContext,
    BuildRequest,
    CreateProjectRequest,
    DeleteBuildTargetRequest,
    Project,
    ResolvedBuildTarget,
    UiAgentData,
    UiAgentMutation,
    UiAgentSessionData,
    UiBuildLogRequest,
    UiLayoutData,
    UiLogEntry,
    UiLogsErrorMessage,
    UiLogsStreamMessage,
    UiPackageSyncProgress,
    UiPinoutData,
    UiProjectState,
    UiSidebarDetails,
    UpdateBuildTargetRequest,
)
from atopile.logging import get_logger
from atopile.model import (
    artifacts,
    builds,
    file_ops,
    migrations,
    packages,
    parts,
    parts_search,
    projects,
    stdlib,
)
from atopile.model.build_queue import BuildQueue, _build_queue
from atopile.model.file_watcher import FileWatcher
from atopile.model.sqlite import Logs
from atopile.pathutils import same_path
from atopile.server.domains.layout import layout_service
from atopile.server.domains.layout_models import WsMessage
from atopile.server.domains.layout_pcb_manager import PcbManager
from atopile.server.domains.layout_rpc import LayoutRpcSession
from atopile.server.domains.vscode_bridge import VscodeBridge
from atopile.server.ui import remote_assets, sidebar
from atopile.server.ui.store import Store

log = get_logger(__name__)

STREAM_POLL_INTERVAL = 0.25  # seconds
EXTENSION_SESSION_ID = "extension"


def _render_model_from_pcb_text(text: str):
    manager = PcbManager()
    manager.load_text(text)
    return manager.get_render_model()


async def _get_package_layout_render_model(url: str):
    data = await remote_assets.fetch_remote_asset_bytes(url)
    return await asyncio.to_thread(
        _render_model_from_pcb_text, data.decode("utf-8-sig")
    )


async def _get_part_footprint_render_model(lcsc_id: str):
    data = await asyncio.to_thread(parts_search.handle_get_part_footprint, lcsc_id)
    if not data:
        raise ValueError(f"Footprint not found: {lcsc_id}")
    return await asyncio.to_thread(
        _render_model_from_pcb_text, data.decode("utf-8-sig")
    )

class CoreSocket:
    """Manages WebSocket connections and dispatches actions."""

    def __init__(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._clients: set[ServerConnection] = set()
        self._subscriptions: dict[ServerConnection, dict[str, set[str]]] = {}
        self._layout_sessions: dict[ServerConnection, dict[str, LayoutRpcSession]] = {}
        self._log_tasks: dict[ServerConnection, dict[str, asyncio.Task]] = {}
        self._discovery_paths: list[Path] = []
        self._vscode_bridge = VscodeBridge()
        self._store = Store()
        self._store.on_change = self._on_store_change
        layout_service.add_listener(self._handle_layout_message)
        self._agent_last_mutation: UiAgentMutation | None = None
        self._agent = AgentService(
            self._build_agent_context,
            emit_progress=self._emit_agent_progress,
        )
        self._project_files = FileWatcher(
            "project-files",
            paths=[],
            on_change=lambda result: self._store.set(
                "project_files",
                result.model_copy(update={"loading": False}),
            ),
            glob="**/*",
            debounce_s=0.1,
            mode="tree",
        )
        self._project_selection_lock = asyncio.Lock()
        self._store.set(
            "current_builds",
            [build.model_dump() for build in builds.get_active_builds()],
        )
        self._store.set(
            "previous_builds",
            [build.model_dump() for build in builds.get_finished_builds()],
        )
        self._store.set(
            "queue_builds",
            [build.model_dump() for build in builds.get_queue_builds()],
        )
        self._push_agent_state()
        self.bind_build_queue(_build_queue)

    # -- Client lifecycle --------------------------------------------------

    async def handle_client(self, ws: ServerConnection) -> None:
        path = getattr(getattr(ws, "request", None), "path", None)
        if path not in {None, "/atopile-ui"}:
            await ws.close(code=4000, reason="unknown path")
            return

        self._clients.add(ws)
        self._subscriptions[ws] = {}
        self._layout_sessions[ws] = {}
        self._log_tasks[ws] = {}
        self._vscode_bridge.add_client(ws)

        try:
            async for raw in ws:
                msg = json.loads(raw)
                keys = msg.get("keys")
                self._log_websocket_event(
                    "recv",
                    session_id=self._session_id(msg),
                    type=msg.get("type"),
                    action=msg.get("action"),
                    request_id=msg.get("requestId"),
                    ok=msg.get("ok"),
                    key_count=len(keys) if isinstance(keys, list) else None,
                )
                match msg.get("type"):
                    case "subscribe":
                        await self._handle_subscribe(ws, msg)
                    case "unsubscribe":
                        self._handle_unsubscribe(ws, msg)
                    case "action":
                        try:
                            await self._dispatch(ws, msg)
                        except Exception:
                            log.exception(
                                "dispatch failed for action %s",
                                msg.get("action"),
                            )
                    case "extension_response":
                        response = self._vscode_bridge.handle_response(
                            ws, self._session_id(msg), msg
                        )
                        if response is not None:
                            await self._send_message(ws, response)

        except websockets.ConnectionClosed:
            pass
        finally:
            await self._release_client(ws)

    async def _handle_subscribe(
        self, ws: ServerConnection, msg: dict[str, Any]
    ) -> None:
        session_id = self._session_id(msg)
        keys = {str(key) for key in msg.get("keys", [])}
        subscriptions = self._subscriptions.setdefault(ws, {})
        session_keys = subscriptions.setdefault(session_id, set())
        session_keys.update(keys)
        for key in keys:
            field_name = self._store.require_field_name(key)
            await self._send_state(
                ws, session_id, field_name, self._store.dump(field_name)
            )

    def _handle_unsubscribe(self, ws: ServerConnection, msg: dict[str, Any]) -> None:
        session_id = self._session_id(msg)
        keys = {str(key) for key in msg.get("keys", [])}
        session_keys = self._subscriptions.setdefault(ws, {}).get(session_id)
        if session_keys is None:
            return
        session_keys.difference_update(keys)
        if not session_keys:
            self._subscriptions[ws].pop(session_id, None)

    def _build_agent_context(self) -> AppContext:
        return AppContext(workspace_paths=list(self._discovery_paths))

    @staticmethod
    def _request_key(msg: dict[str, Any]) -> str:
        payload = {
            key: value
            for key, value in msg.items()
            if key not in {"type", "action", "requestId", "sessionId"}
        }
        return json.dumps(payload, separators=(",", ":"))

    def _log_websocket_event(self, event: str, **fields: Any) -> None:
        details = " ".join(
            f"{key}={value}" for key, value in fields.items() if value is not None
        )
        if details:
            log.debug("WebSocket %s %s", event, details)
            return
        log.debug("WebSocket %s", event)

    def _build_agent_state(self) -> UiAgentData:
        with sessions_lock:
            sessions = list(sessions_by_id.values())
        with runs_lock:
            runs = dict(runs_by_id)

        session_items: list[UiAgentSessionData] = []
        for session in sessions:
            active_run = runs.get(session.active_run_id or "")
            if active_run is not None:
                active_run = normalize_running_run_state(active_run)
                if active_run.status != "running":
                    active_run = None

            session_items.append(
                UiAgentSessionData(
                    session_id=session.session_id,
                    project_root=session.project_root,
                    messages=list(session.messages),
                    history=list(session.history),
                    recent_selected_targets=list(session.recent_selected_targets),
                    active_run_id=active_run.run_id if active_run else None,
                    active_run_status=active_run.status if active_run else None,
                    active_run_stop_requested=bool(
                        active_run and active_run.stop_requested
                    ),
                    active_run_error=active_run.error if active_run else None,
                    activity_label=session.activity_label,
                    error=session.error,
                    run_started_at=session.run_started_at,
                    created_at=float(session.created_at),
                    updated_at=float(session.updated_at),
                )
            )

        session_items.sort(key=lambda session: session.updated_at, reverse=True)
        return UiAgentData(
            loaded=True,
            sessions=session_items,
            last_mutation=self._agent_last_mutation,
        )

    def _push_agent_state(
        self,
        *,
        action: str | None = None,
        session_id: str | None = None,
        run_id: str | None = None,
        error: str | None = None,
    ) -> None:
        if action is not None:
            self._agent_last_mutation = UiAgentMutation(
                action=action,
                session_id=session_id,
                run_id=run_id,
                error=error,
                updated_at=time.time(),
            )
        self._store.set("agent_data", self._build_agent_state())

    async def _emit_agent_progress(self, payload: dict[str, object]) -> None:
        await self._broadcast_agent_message(payload)
        self._push_agent_state()

    async def _apply_project_selection(
        self,
        *,
        selected_project_root: str | None,
        selected_target: ResolvedBuildTarget | None,
        project_list: list[Project] | None = None,
        project_state: UiProjectState | None = None,
    ) -> None:
        current_project_state = (
            cast(UiProjectState, self._store.get("project_state"))
            if project_state is None
            else project_state
        )
        await sidebar.apply_project_selection(
            store=self._store,
            project_files=self._project_files,
            sync_selected_layout=self._sync_selected_layout,
            sync_selected_pinout=self._sync_selected_pinout,
            set_layout_data=self._set_layout_data,
            selection_lock=self._project_selection_lock,
            project_list=project_list,
            project_state=current_project_state.model_copy(
                update={
                    "selected_project_root": selected_project_root,
                    "selected_target": selected_target,
                    "log_view_build_id": None,
                    "log_view_stage": None,
                }
            ),
        )

    # -- Action dispatch ---------------------------------------------------

    async def _dispatch(self, ws: ServerConnection, msg: dict) -> None:
        session_id = self._session_id(msg)
        action = str(msg.get("action", ""))
        if action == "closeSession":
            request_id = str(msg.get("requestId") or "")
            await self._close_session(ws, session_id)
            if request_id:
                await self._send_action_result(
                    ws,
                    session_id,
                    action,
                    request_id,
                    ok=True,
                )
            return
        if action.startswith("agent."):
            await self._handle_agent_action(session_id, msg)
            return
        if self._vscode_bridge.handles(action):
            await self._send_message(
                ws, self._vscode_bridge.forward_request(ws, session_id, msg)
            )
            return
        layout_session = self._layout_session(ws, session_id)
        if LayoutRpcSession.handles(action):
            try:
                await layout_session.dispatch(msg)
            except Exception as exc:
                log.exception("Layout RPC action failed for session %s", session_id)
                await layout_session.send_error(
                    action,
                    str(msg.get("requestId") or ""),
                    str(exc),
                )
            return

        match action:
            case (
                "generateThreeDModel"
                | "getPackageLayoutRenderModel"
                | "getPartFootprintRenderModel"
            ):
                request_id = str(msg.get("requestId") or "")
                if not request_id:
                    raise ValueError(f"{action} requires requestId")
                try:
                    target = projects.parse_target(msg.get("target"))
                    if action == "generateThreeDModel" and target is None:
                        raise ValueError("target is required")
                    result = (
                        await asyncio.to_thread(
                            artifacts.generate_3d_model,
                            target,
                        )
                        if action == "generateThreeDModel"
                        else (
                            await _get_package_layout_render_model(
                                str(msg.get("url") or "")
                            )
                            if action == "getPackageLayoutRenderModel"
                            else await _get_part_footprint_render_model(
                                str(msg.get("lcsc") or "")
                            )
                        )
                    )
                except Exception as exc:
                    await self._send_action_result(
                        ws,
                        session_id,
                        action,
                        request_id,
                        ok=False,
                        error=str(exc),
                    )
                    return
                await self._send_action_result(
                    ws,
                    session_id,
                    action,
                    request_id,
                    ok=True,
                    result=(
                        result
                        if action == "generateThreeDModel"
                        else result.model_dump(mode="json")
                    ),
                )
                return

            case "getRemoteAsset":
                request_key = self._request_key(msg)
                asset = await remote_assets.proxy_remote_asset(
                    str(msg.get("url", "")),
                    str(msg.get("filename")) if msg.get("filename") else None,
                )
                self._store.set(
                    "blob_asset",
                    {
                        "action": action,
                        "requestKey": request_key,
                        **asset,
                    },
                )
                return

            case "getPartModelData":
                lcsc_id = str(msg.get("lcsc", ""))
                request_key = self._request_key(msg)
                model = await asyncio.to_thread(
                    parts_search.handle_get_part_model,
                    lcsc_id,
                )
                if not model:
                    raise ValueError(f"3D model not found: {lcsc_id}")
                data, name = model
                self._store.set(
                    "blob_asset",
                    {
                        "action": action,
                        "requestKey": request_key,
                        "contentType": "model/step",
                        "filename": name,
                        "data": base64.b64encode(data).decode("ascii"),
                    },
                )
                return

            case "selectProject":
                selected_project, selected_target = projects.resolve_project_selection(
                    cast(list[Project], self._store.get("projects")),
                    str(msg.get("projectRoot") or "") or None,
                )
                await self._apply_project_selection(
                    selected_project_root=(
                        selected_project.root if selected_project else None
                    ),
                    selected_target=selected_target,
                )
                return

            case "selectTarget":
                selected_project, resolved_target = projects.resolve_target_selection(
                    cast(list[Project], self._store.get("projects")),
                    cast(
                        UiProjectState, self._store.get("project_state")
                    ).selected_project_root,
                    projects.parse_target(msg.get("target")),
                )
                await self._apply_project_selection(
                    selected_project_root=(
                        selected_project.root if selected_project else None
                    ),
                    selected_target=resolved_target,
                )
                return

            case "setLogViewCurrentId":
                self._store.merge(
                    "project_state",
                    {
                        "logViewBuildId": str(msg.get("buildId") or "") or None,
                        "logViewStage": str(msg.get("stage") or "") or None,
                    },
                )
                return

            case "resolverInfo":
                self._store.merge(
                    "core_status",
                    {
                        "uvPath": msg.get("uvPath", ""),
                        "atoBinary": msg.get("atoBinary", ""),
                        "mode": msg.get("mode", "production"),
                        "version": msg.get("version", ""),
                        "coreServerPort": msg.get("coreServerPort", 0),
                    },
                )
                return

            case "extensionSettings":
                self._store.merge(
                    "extension_settings",
                    {
                        "enableChat": msg.get("enableChat", True),
                    },
                )
                return

            case "updateExtensionSetting":
                key = msg.get("key")
                if isinstance(key, str):
                    self._store.merge("extension_settings", {key: msg.get("value")})
                return

            case "setActiveFile":
                self._store.merge(
                    "project_state",
                    {
                        "activeFilePath": msg.get("filePath"),
                    },
                )
                return

            case "discoverProjects":
                self._discovery_paths = [Path(p) for p in msg.get("paths", []) if p]
                project_list = projects.handle_get_projects(
                    self._discovery_paths
                ).projects
                await sidebar.apply_project_selection(
                    store=self._store,
                    project_files=self._project_files,
                    sync_selected_layout=self._sync_selected_layout,
                    sync_selected_pinout=self._sync_selected_pinout,
                    set_layout_data=self._set_layout_data,
                    selection_lock=self._project_selection_lock,
                    project_list=project_list,
                )
                return

            case "createProject":
                request_id = str(msg.get("requestId") or "")
                try:
                    request = CreateProjectRequest(
                        parent_directory=str(msg.get("parentDirectory") or ""),
                        name=(
                            str(msg.get("name"))
                            if isinstance(msg.get("name"), str) and msg.get("name")
                            else None
                        ),
                    )
                    create_result = await asyncio.to_thread(
                        projects.handle_create_project, request
                    )
                    # Ensure new project is discoverable even if it's
                    # outside the current workspace folders.
                    new_project_path = Path(create_result.project_root)
                    if not any(
                        new_project_path.is_relative_to(dp)
                        for dp in self._discovery_paths
                    ):
                        self._discovery_paths.append(new_project_path)

                    project_list = (
                        await asyncio.to_thread(
                            projects.handle_get_projects, self._discovery_paths
                        )
                    ).projects
                    selected_project, selected_target = (
                        projects.resolve_project_selection(
                            project_list,
                            create_result.project_root,
                        )
                    )
                    await self._apply_project_selection(
                        project_list=project_list,
                        selected_project_root=(
                            selected_project.root if selected_project else None
                        ),
                        selected_target=selected_target,
                    )
                except Exception as exc:
                    log.exception("createProject failed")
                    if request_id:
                        await self._send_action_result(
                            ws, session_id, action, request_id,
                            ok=False, error=str(exc),
                        )
                    return
                if request_id:
                    await self._send_action_result(
                        ws, session_id, action, request_id,
                        ok=True, result=create_result.project_root,
                    )
                return

            case "addBuildTarget":
                request = AddBuildTargetRequest(
                    project_root=str(msg.get("projectRoot") or ""),
                    name=str(msg.get("name") or ""),
                    entry=str(msg.get("entry") or ""),
                )
                add_result = await asyncio.to_thread(
                    projects.handle_add_build_target, request
                )
                project_list, project = await asyncio.to_thread(
                    projects.refresh_project,
                    cast(list[Project], self._store.get("projects")),
                    request.project_root,
                )
                selected_target = projects.find_target(
                    project,
                    add_result.target,
                    request.project_root,
                )
                await self._apply_project_selection(
                    project_list=project_list if project is not None else None,
                    selected_project_root=request.project_root,
                    selected_target=selected_target,
                )
                return

            case "updateBuildTarget":
                request = UpdateBuildTargetRequest(
                    project_root=str(msg.get("projectRoot") or ""),
                    old_name=str(msg.get("oldName") or ""),
                    new_name=(
                        str(msg.get("newName"))
                        if isinstance(msg.get("newName"), str) and msg.get("newName")
                        else None
                    ),
                    new_entry=(
                        str(msg.get("newEntry"))
                        if isinstance(msg.get("newEntry"), str)
                        else None
                    ),
                )
                update_result = await asyncio.to_thread(
                    projects.handle_update_build_target, request
                )
                current_project_state = cast(
                    UiProjectState, self._store.get("project_state")
                )
                was_selected = projects.is_selected_target(
                    current_project_state,
                    request.project_root,
                    request.old_name,
                )
                project_list, project = await asyncio.to_thread(
                    projects.refresh_project,
                    cast(list[Project], self._store.get("projects")),
                    request.project_root,
                )
                replacement = None
                if was_selected:
                    replacement = projects.find_target(
                        project,
                        update_result.target or request.old_name,
                        request.project_root,
                    )
                if was_selected:
                    await self._apply_project_selection(
                        project_list=project_list if project is not None else None,
                        project_state=current_project_state,
                        selected_project_root=current_project_state.selected_project_root,
                        selected_target=replacement,
                    )
                elif project is not None:
                    await sidebar.apply_project_selection(
                        store=self._store,
                        project_files=self._project_files,
                        sync_selected_layout=self._sync_selected_layout,
                        sync_selected_pinout=self._sync_selected_pinout,
                        set_layout_data=self._set_layout_data,
                        selection_lock=self._project_selection_lock,
                        project_list=project_list,
                    )
                return

            case "deleteBuildTarget":
                request = DeleteBuildTargetRequest(
                    project_root=str(msg.get("projectRoot") or ""),
                    name=str(msg.get("name") or ""),
                )
                await asyncio.to_thread(projects.handle_delete_build_target, request)
                project_list, project = await asyncio.to_thread(
                    projects.refresh_project,
                    cast(list[Project], self._store.get("projects")),
                    request.project_root,
                )
                current_project_state = cast(
                    UiProjectState, self._store.get("project_state")
                )
                if projects.is_selected_target(
                    current_project_state,
                    request.project_root,
                    request.name,
                ):
                    replacement = (
                        project.targets[0] if project and project.targets else None
                    )
                    await self._apply_project_selection(
                        project_list=project_list if project is not None else None,
                        project_state=current_project_state,
                        selected_project_root=current_project_state.selected_project_root,
                        selected_target=replacement,
                    )
                elif project is not None:
                    await sidebar.apply_project_selection(
                        store=self._store,
                        project_files=self._project_files,
                        sync_selected_layout=self._sync_selected_layout,
                        sync_selected_pinout=self._sync_selected_pinout,
                        set_layout_data=self._set_layout_data,
                        selection_lock=self._project_selection_lock,
                        project_list=project_list,
                    )
                return

            case "checkEntry":
                project_root = str(msg.get("projectRoot") or "")
                entry = str(msg.get("entry") or "").strip()
                project = projects.find_project(
                    cast(list[Project], self._store.get("projects")),
                    project_root,
                )
                result = await asyncio.to_thread(
                    projects.handle_check_entry,
                    project_root,
                    entry,
                    project.targets if project else None,
                )
                self._store.set(
                    "entry_check",
                    {
                        "projectRoot": project_root or None,
                        "entry": entry,
                        **result,
                    },
                )
                return

            case "createFile":
                project_root = str(msg.get("projectRoot") or "")
                parent_relative_path = str(msg.get("parentRelativePath") or "")
                name = str(msg.get("name") or "")
                created_path = await asyncio.to_thread(
                    file_ops.create_project_file,
                    project_root,
                    parent_relative_path,
                    name,
                )
                self._store.set(
                    "file_action",
                    {
                        "action": "create_file",
                        "path": created_path,
                        "isFolder": False,
                    },
                )
                return

            case "createFolder":
                project_root = str(msg.get("projectRoot") or "")
                parent_relative_path = str(msg.get("parentRelativePath") or "")
                name = str(msg.get("name") or "")
                created_path = await asyncio.to_thread(
                    file_ops.create_project_folder,
                    project_root,
                    parent_relative_path,
                    name,
                )
                self._store.set(
                    "file_action",
                    {
                        "action": "create_folder",
                        "path": created_path,
                        "isFolder": True,
                    },
                )
                return

            case "renamePath":
                project_root = str(msg.get("projectRoot") or "")
                relative_path = str(msg.get("relativePath") or "")
                new_name = str(msg.get("newName") or "")
                renamed_path = await asyncio.to_thread(
                    file_ops.rename_project_path,
                    project_root,
                    relative_path,
                    new_name,
                )
                self._store.set(
                    "file_action",
                    {
                        "action": "rename",
                        "path": renamed_path,
                        "isFolder": Path(renamed_path).is_dir(),
                    },
                )
                return

            case "deletePath":
                project_root = str(msg.get("projectRoot") or "")
                relative_path = str(msg.get("relativePath") or "")
                deleted_path = await asyncio.to_thread(
                    file_ops.delete_project_path,
                    project_root,
                    relative_path,
                )
                self._store.set(
                    "file_action",
                    {
                        "action": "delete",
                        "path": deleted_path,
                        "isFolder": False,
                    },
                )
                return

            case "duplicatePath":
                project_root = str(msg.get("projectRoot") or "")
                relative_path = str(msg.get("relativePath") or "")
                duplicated_path = await asyncio.to_thread(
                    file_ops.duplicate_project_path,
                    project_root,
                    relative_path,
                )
                self._store.set(
                    "file_action",
                    {
                        "action": "duplicate",
                        "path": duplicated_path,
                        "isFolder": Path(duplicated_path).is_dir(),
                    },
                )
                return

            case "startBuild":
                request = BuildRequest(
                    project_root=msg.get("projectRoot", ""),
                    targets=msg.get("targets", []),
                    frozen=msg.get("frozen", False),
                    include_targets=msg.get("includeTargets", []),
                    exclude_targets=msg.get("excludeTargets", []),
                )
                enqueued_builds = builds.handle_start_build(request)
                if enqueued_builds:
                    self._store.merge(
                        "project_state",
                        {
                            "logViewBuildId": None,
                            "logViewStage": None,
                        },
                    )
                await self._push_builds()
                return

            case "cancelBuild":
                build_id = str(msg.get("buildId") or "")
                await asyncio.to_thread(_build_queue.cancel_build, build_id)
                return

            case "getManufacturingArtifacts":
                request_id = str(msg.get("requestId") or "")
                if not request_id:
                    raise ValueError("getManufacturingArtifacts requires requestId")
                try:
                    project_root = str(msg.get("projectRoot", ""))
                    target_data = msg.get("target", {})
                    target_name = str(target_data.get("name", ""))
                    build_dir = Path(project_root) / "manufacturing" / target_name
                    mfg_files: list[dict[str, object]] = []
                    if build_dir.is_dir():
                        for entry in sorted(build_dir.iterdir()):
                            if entry.is_file():
                                mfg_files.append(
                                    {
                                        "name": entry.name,
                                        "path": str(entry),
                                        "sizeBytes": entry.stat().st_size,
                                    }
                                )
                    await self._send_action_result(
                        ws,
                        session_id,
                        action,
                        request_id,
                        ok=True,
                        result={"artifacts": mfg_files},
                    )
                except Exception as exc:
                    await self._send_action_result(
                        ws,
                        session_id,
                        action,
                        request_id,
                        ok=False,
                        error=str(exc),
                    )
                return

            case "getPackagesSummary":
                project_root = msg.get("projectRoot", "")
                root = Path(project_root) if project_root else None
                packages_result = await asyncio.to_thread(
                    packages.handle_packages_summary, root
                )
                self._store.set("packages_summary", packages_result)
                return

            case "showPackageDetails":
                await sidebar.show_package_details(
                    self._store,
                    msg.get("projectRoot") or None,
                    str(msg.get("packageId", "")),
                )
                return

            case "closeSidebarDetails":
                self._store.set("sidebar_details", sidebar.clear())
                return

            case "installPackage":
                project_root = Path(msg.get("projectRoot", ""))
                pkg_id = msg.get("packageId", "")
                version = msg.get("version")

                # Set initial progress state synchronously before the thread starts
                _install_current = cast(
                    UiSidebarDetails, self._store.get("sidebar_details")
                )
                if _install_current.view == "package":
                    self._store.set(
                        "sidebar_details",
                        _install_current.model_copy(
                            update={
                                "package": _install_current.package.model_copy(
                                    update={
                                        "sync_progress": UiPackageSyncProgress(
                                            stage="starting",
                                            message=f"Installing {pkg_id}...",
                                            completed=0,
                                            total=1,
                                        )
                                    }
                                )
                            }
                        ),
                    )

                loop = asyncio.get_running_loop()

                def _install_progress(
                    stage: str, message: str, completed: int, total: int
                ) -> None:
                    current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                    if current.view == "package":
                        asyncio.run_coroutine_threadsafe(
                            self._set_sync_progress(
                                pkg_id, stage, message, completed, total
                            ),
                            loop,
                        )

                try:
                    await asyncio.to_thread(
                        packages.install_package_to_project,
                        project_root,
                        pkg_id,
                        version,
                        on_progress=_install_progress,
                    )
                except Exception as exc:
                    await sidebar.show_package_details(
                        self._store,
                        str(project_root),
                        str(pkg_id),
                        action_error=str(exc),
                    )
                    return
                packages_result = await asyncio.to_thread(
                    packages.handle_packages_summary, project_root
                )
                self._store.set("packages_summary", packages_result)
                current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                package_state = current.package
                if (
                    current.view == "package"
                    and package_state.package_id == pkg_id
                    and same_path(package_state.project_root, str(project_root))
                ):
                    await sidebar.show_package_details(
                        self._store,
                        str(project_root),
                        str(pkg_id),
                    )
                return

            case "removePackage":
                project_root = Path(msg.get("projectRoot", ""))
                pkg_id = msg.get("packageId", "")

                # Set initial progress state synchronously before the thread starts
                _remove_current = cast(
                    UiSidebarDetails, self._store.get("sidebar_details")
                )
                if _remove_current.view == "package":
                    self._store.set(
                        "sidebar_details",
                        _remove_current.model_copy(
                            update={
                                "package": _remove_current.package.model_copy(
                                    update={
                                        "sync_progress": UiPackageSyncProgress(
                                            stage="starting",
                                            message=f"Removing {pkg_id}...",
                                            completed=0,
                                            total=1,
                                        )
                                    }
                                )
                            }
                        ),
                    )

                loop = asyncio.get_running_loop()

                def _remove_progress(
                    stage: str, message: str, completed: int, total: int
                ) -> None:
                    current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                    if current.view == "package":
                        asyncio.run_coroutine_threadsafe(
                            self._set_sync_progress(
                                pkg_id, stage, message, completed, total
                            ),
                            loop,
                        )

                try:
                    await asyncio.to_thread(
                        packages.remove_package_from_project,
                        project_root,
                        pkg_id,
                        on_progress=_remove_progress,
                    )
                except Exception as exc:
                    await sidebar.show_package_details(
                        self._store,
                        str(project_root),
                        str(pkg_id),
                        action_error=str(exc),
                    )
                    return
                packages_result = await asyncio.to_thread(
                    packages.handle_packages_summary, project_root
                )
                self._store.set("packages_summary", packages_result)
                current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                package_state = current.package
                if (
                    current.view == "package"
                    and package_state.package_id == pkg_id
                    and same_path(package_state.project_root, str(project_root))
                ):
                    await sidebar.show_package_details(
                        self._store,
                        str(project_root),
                        str(pkg_id),
                    )
                return

            case "getStdlib":
                type_filter = msg.get("typeFilter")
                search = msg.get("search")
                stdlib_result = await asyncio.to_thread(
                    stdlib.handle_get_stdlib, type_filter, search
                )
                self._store.set("stdlib_data", stdlib_result)
                return

            case "getStructure":
                project_root = str(msg.get("projectRoot") or "") or None
                await asyncio.to_thread(
                    sidebar.refresh_project_structure_data,
                    self._store,
                    project_root,
                )
                return

            case "searchParts":
                query = msg.get("query", "")
                limit = msg.get("limit", 50)
                parts_result, search_error = await asyncio.to_thread(
                    parts_search.handle_search_parts,
                    query,
                    limit=limit,
                )
                self._store.set(
                    "parts_search", {"parts": parts_result, "error": search_error}
                )
                return

            case "getInstalledParts":
                project_root = msg.get("projectRoot", "")
                installed_parts = await asyncio.to_thread(
                    parts_search.handle_list_installed_parts,
                    project_root,
                )
                self._store.set("installed_parts", {"parts": installed_parts})
                return

            case "showPartDetails":
                await sidebar.show_part_details(
                    self._store,
                    project_root=msg.get("projectRoot") or None,
                    identifier=msg.get("identifier"),
                    lcsc=msg.get("lcsc"),
                    installed=bool(msg.get("installed")),
                )
                return

            case "installPart":
                project_root = msg.get("projectRoot", "")
                lcsc = msg.get("lcsc", "")
                create_package = bool(msg.get("createPackage"))
                result = await asyncio.to_thread(
                    parts_search.handle_install_part_as_package
                    if create_package
                    else parts_search.handle_install_part,
                    lcsc,
                    project_root,
                )
                if create_package:
                    project_list, project = await asyncio.to_thread(
                        projects.refresh_project,
                        cast(list[Project], self._store.get("projects")),
                        project_root,
                    )
                    if project is not None:
                        self._store.set("projects", project_list)
                installed_parts = await asyncio.to_thread(
                    parts_search.handle_list_installed_parts,
                    project_root,
                )
                self._store.set("installed_parts", {"parts": installed_parts})
                current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                part_state = current.part
                if (
                    current.view == "part"
                    and part_state.lcsc == lcsc
                    and same_path(part_state.project_root, project_root)
                ):
                    part = part_state.part
                    seed = (
                        part.model_copy(
                            update={
                                "installed": False if create_package else True,
                                "import_statement": result.get("import_statement")
                                if create_package
                                else part.import_statement,
                            }
                        )
                        if part
                        else None
                    )
                    await sidebar.show_part_details(
                        self._store,
                        project_root=project_root,
                        identifier=part.identifier if part else None,
                        lcsc=lcsc,
                        installed=False if create_package else True,
                        seed=seed,
                    )
                return

            case "uninstallPart":
                project_root = msg.get("projectRoot", "")
                lcsc = msg.get("lcsc", "")
                await asyncio.to_thread(
                    parts_search.handle_uninstall_part,
                    lcsc,
                    project_root,
                )
                installed_parts = await asyncio.to_thread(
                    parts_search.handle_list_installed_parts,
                    project_root,
                )
                self._store.set("installed_parts", {"parts": installed_parts})
                current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
                part_state = current.part
                if (
                    current.view == "part"
                    and part_state.lcsc == lcsc
                    and same_path(part_state.project_root, project_root)
                ):
                    part = part_state.part
                    await sidebar.show_part_details(
                        self._store,
                        project_root=project_root,
                        identifier=part.identifier if part else None,
                        lcsc=lcsc,
                        installed=False,
                        seed=part.model_copy(update={"installed": False})
                        if part
                        else None,
                    )
                return

            case "showMigrationDetails":
                project_root = str(msg.get("projectRoot", ""))
                if project_root:
                    await sidebar.show_migration_details(self._store, project_root)
                return

            case "runMigration" | "migrateProjectSteps":
                project_root = str(msg.get("projectRoot", ""))
                selected_steps = [str(step) for step in msg.get("steps", []) if step]
                if not project_root:
                    return
                self._store.set(
                    "sidebar_details",
                    sidebar.start_migration_run(
                        self._store.get("sidebar_details"),
                        selected_steps,
                    ),
                )
                for step_id in selected_steps:
                    try:
                        await migrations.get_step(step_id).run(Path(project_root))
                        error = None
                    except Exception as exc:
                        log.exception("Migration step %s failed", step_id)
                        error = str(exc)
                    self._store.set(
                        "sidebar_details",
                        sidebar.finish_migration_step(
                            self._store.get("sidebar_details"),
                            step_id,
                            error=error,
                        ),
                    )
                final_state, success = sidebar.complete_migration_run(
                    self._store.get("sidebar_details")
                )
                self._store.set("sidebar_details", final_state)
                project_list, project = await asyncio.to_thread(
                    projects.refresh_project,
                    cast(list[Project], self._store.get("projects")),
                    project_root,
                )
                if project is not None:
                    self._store.set("projects", project_list)
                self._store.set(
                    "sidebar_details",
                    sidebar.update_migration_project_state(
                        self._store.get("sidebar_details"),
                        cast(list[Project], self._store.get("projects")),
                        project_root,
                    ),
                )
                return

            case "getVariables":
                project_root = msg.get("projectRoot", "")
                try:
                    target = projects.parse_target(msg.get("target"))
                    variables = await asyncio.to_thread(
                        artifacts.read_target_json_artifact,
                        project_root,
                        ".variables.json",
                        label="variables",
                        target=target,
                    )
                    project_state = cast(
                        UiProjectState, self._store.get("project_state")
                    )
                    if not projects.same_selection(
                        project_root or None,
                        target,
                        project_state.selected_project_root,
                        project_state.selected_target,
                    ):
                        return
                    self._store.set(
                        "variables_data", variables or {"nodes": []}
                    )
                except Exception:
                    log.exception("getVariables failed")
                    self._store.set(
                        "variables_data",
                        {"nodes": [], "error": "Failed to load variables"},
                    )
                return

            case "getBom":
                project_root = msg.get("projectRoot", "")
                try:
                    target = projects.parse_target(msg.get("target"))
                    bom = await asyncio.to_thread(
                        artifacts.read_target_json_artifact,
                        project_root,
                        ".bom.json",
                        label="BOM",
                        target=target,
                    )
                    project_state = cast(
                        UiProjectState, self._store.get("project_state")
                    )
                    if not projects.same_selection(
                        project_root or None,
                        target,
                        project_state.selected_project_root,
                        project_state.selected_target,
                    ):
                        return
                    self._store.set(
                        "bom_data",
                        {
                            "projectRoot": project_root or None,
                            "target": target.model_dump() if target else None,
                            **(
                                bom
                                or {
                                    "components": [],
                                    "totalQuantity": 0,
                                    "uniqueParts": 0,
                                    "estimatedCost": None,
                                    "outOfStock": 0,
                                }
                            ),
                        },
                    )
                except Exception:
                    log.exception("getBom failed")
                    self._store.set(
                        "bom_data",
                        {
                            "projectRoot": project_root or None,
                            "target": None,
                            "components": [],
                            "totalQuantity": 0,
                            "uniqueParts": 0,
                            "estimatedCost": None,
                            "outOfStock": 0,
                            "error": "Failed to load BOM",
                            "errorTraceback": traceback.format_exc(),
                        },
                    )
                return

            case "getBuildsByProject":
                project_root = msg.get("projectRoot") or None
                target = projects.parse_target(msg.get("target"))
                limit = int(msg.get("limit", 50))
                result = await asyncio.to_thread(
                    builds.get_builds_by_project,
                    project_root,
                    target,
                    limit,
                )
                project_state = cast(UiProjectState, self._store.get("project_state"))
                if not projects.same_selection(
                    project_root,
                    target,
                    project_state.selected_project_root,
                    project_state.selected_target,
                ):
                    return
                self._store.set(
                    "builds_by_project_data",
                    {
                        "projectRoot": project_root,
                        "target": target.model_dump() if target else None,
                        "limit": limit,
                        "builds": [build.model_dump() for build in result],
                    },
                )
                return

            case "fetchLcscParts":
                lcsc_ids = [str(value) for value in msg.get("lcscIds", []) if value]
                project_root = msg.get("projectRoot") or None
                try:
                    target = projects.parse_target(msg.get("target"))
                    current_lcsc_parts = cast(
                        dict[str, Any], self._store.dump("lcsc_parts_data")
                    )
                    current_parts = current_lcsc_parts.get("parts", {})
                    current_target = projects.parse_target(
                        current_lcsc_parts.get("target")
                    )
                    if not projects.same_selection(
                        current_lcsc_parts.get("projectRoot"),
                        current_target,
                        project_root,
                        target,
                    ):
                        current_parts = {}
                    result = await asyncio.to_thread(
                        parts.handle_get_lcsc_parts,
                        lcsc_ids,
                    )
                    project_state = cast(
                        UiProjectState, self._store.get("project_state")
                    )
                    if not projects.same_selection(
                        project_root,
                        target,
                        project_state.selected_project_root,
                        project_state.selected_target,
                    ):
                        return
                    self._store.set(
                        "lcsc_parts_data",
                        {
                            "projectRoot": project_root,
                            "target": target.model_dump() if target else None,
                            "parts": {**current_parts, **result.get("parts", {})},
                            "loadingIds": [],
                        },
                    )
                except Exception:
                    log.exception("fetchLcscParts failed")
                    self._store.set(
                        "lcsc_parts_data",
                        {
                            "projectRoot": project_root,
                            "target": None,
                            "parts": {},
                            "loadingIds": [],
                            "error": "Failed to fetch LCSC parts",
                        },
                    )
                return

            case "subscribeLogs":
                request = UiBuildLogRequest.model_validate(msg)
                build_id = request.build_id.strip()
                if not build_id:
                    payload = UiLogsErrorMessage(
                        error="buildId is required"
                    ).model_dump(mode="json")
                    payload["sessionId"] = session_id
                    await self._send_message(ws, payload)
                    return
                old_task = self._log_tasks.setdefault(ws, {}).pop(session_id, None)
                if old_task:
                    old_task.cancel()
                query = {
                    "session_id": session_id,
                    "build_id": build_id,
                    "stage": request.stage,
                    "log_levels": request.log_levels,
                    "audience": request.audience,
                    "count": request.count or 1000,
                }
                task = asyncio.create_task(self._log_stream_loop(ws, query))
                self._log_tasks.setdefault(ws, {})[session_id] = task
                return

            case "unsubscribeLogs":
                old_task = self._log_tasks.setdefault(ws, {}).pop(session_id, None)
                if old_task:
                    old_task.cancel()
                return

            case _:
                raise ValueError(f"Unknown action: {action}")
        return

    # -- Log streaming -----------------------------------------------------

    async def _log_stream_loop(self, ws: ServerConnection, query: dict) -> None:
        """Poll SQLite for new logs and push to the client until cancelled."""
        last_id = 0
        try:
            # Send initial batch immediately
            last_id = await self._push_log_stream(ws, query, last_id)
            while True:
                await asyncio.sleep(STREAM_POLL_INTERVAL)
                last_id = await self._push_log_stream(ws, query, last_id)
        except asyncio.CancelledError:
            pass
        except websockets.ConnectionClosed:
            pass

    async def _push_log_stream(
        self, ws: ServerConnection, query: dict, after_id: int
    ) -> int:
        """Fetch new logs from SQLite and push to the client. Returns new cursor."""
        session_id = query.get("session_id", EXTENSION_SESSION_ID)
        build_id = query.get("build_id", "")
        stage = query.get("stage") or None
        log_levels = query.get("log_levels") or None
        audience = query.get("audience") or None
        count = query.get("count", 1000)

        logs, new_last_id = await asyncio.to_thread(
            Logs.fetch_chunk,
            build_id,
            stage=stage,
            levels=log_levels,
            audience=audience,
            after_id=after_id,
            count=count,
        )

        if logs:
            payload = UiLogsStreamMessage(
                build_id=build_id,
                stage=stage,
                logs=[UiLogEntry.model_validate(log) for log in logs],
                last_id=new_last_id,
            ).model_dump(mode="json")
            payload["sessionId"] = session_id
            await self._send_message(ws, payload)
            return new_last_id

        return after_id

    # -- Build queue integration -------------------------------------------

    def bind_build_queue(self, build_queue: BuildQueue) -> None:
        """Register as the listener for build queue changes."""
        loop = asyncio.get_running_loop()

        def _on_change(build_id: str, event_type: str) -> None:
            asyncio.run_coroutine_threadsafe(self._push_builds(), loop)

        def _on_completed(build: Any) -> None:
            payload = {
                "project_root": build.project_root or "",
                "build_id": build.build_id or "",
                "target": (
                    build.target.name
                    if getattr(build, "target", None) is not None
                    and getattr(build.target, "name", None)
                    else str(getattr(build, "target", "") or "default")
                ),
                "status": (
                    build.status.value
                    if hasattr(build.status, "value")
                    else str(build.status)
                ),
                "warnings": build.warnings or 0,
                "errors": build.errors or 0,
                "error": build.error,
                "elapsed_seconds": build.elapsed_seconds or 0.0,
            }
            self._agent.handle_build_completed(payload)

        build_queue.on_change = _on_change
        build_queue.on_completed = _on_completed
        build_queue.start()

    async def _push_builds(self) -> None:
        self._store.set(
            "current_builds",
            [build.model_dump() for build in builds.get_active_builds()],
        )
        self._store.set(
            "previous_builds",
            [build.model_dump() for build in builds.get_finished_builds()],
        )
        self._store.set(
            "queue_builds",
            [build.model_dump() for build in builds.get_queue_builds()],
        )
        _, selected_target = projects.resolve_selection(
            cast(list[Project], self._store.get("projects")),
            cast(UiProjectState, self._store.get("project_state")),
        )
        self._set_selected_build(selected_target)
        await asyncio.gather(
            self._sync_selected_layout(),
            self._sync_selected_pinout(),
        )

    async def _set_sync_progress(
        self,
        pkg_id: str,
        stage: str,
        message: str,
        completed: int,
        total: int,
    ) -> None:
        """Update sidebar_details sync_progress from the main event loop."""
        current = cast(UiSidebarDetails, self._store.get("sidebar_details"))
        if current.view == "package":
            self._store.set(
                "sidebar_details",
                current.model_copy(
                    update={
                        "package": current.package.model_copy(
                            update={
                                "sync_progress": UiPackageSyncProgress(
                                    stage=stage,
                                    message=message,
                                    completed=completed,
                                    total=total,
                                )
                            }
                        )
                    }
                ),
            )

    # -- Broadcasting ------------------------------------------------------

    def _on_store_change(self, field_name: str, value: Any, prev: Any) -> None:
        asyncio.run_coroutine_threadsafe(
            self._broadcast_state(field_name, value), self._loop
        )

    def _set_selected_build(self, target: ResolvedBuildTarget | None) -> None:
        selected_build = builds.get_selected_build(target)
        self._store.set("selected_build", selected_build)
        self._store.set(
            "selected_build_in_progress",
            builds.is_build_in_progress(selected_build),
        )

    async def _send_state(
        self,
        ws: ServerConnection,
        session_id: str,
        field_name: str,
        data: Any,
    ) -> None:
        await self._send_message(
            ws,
            {
                "type": "state",
                "sessionId": session_id,
                "key": self._store.wire_key(field_name),
                "data": data,
            },
        )

    async def _send_message(
        self,
        ws: ServerConnection,
        payload: dict[str, Any],
    ) -> None:
        self._log_websocket_event(
            "send",
            session_id=payload.get("sessionId"),
            type=payload.get("type"),
            action=payload.get("action"),
            request_id=payload.get("requestId"),
            ok=payload.get("ok"),
            key=payload.get("key"),
            step=payload.get("step"),
            success=payload.get("success"),
            last_id=payload.get("last_id"),
            log_count=(
                len(payload["logs"]) if isinstance(payload.get("logs"), list) else None
            ),
        )
        await ws.send(json.dumps(payload))

    async def _send_action_result(
        self,
        ws: ServerConnection,
        session_id: str,
        action: str,
        request_id: str,
        *,
        ok: bool,
        result: Any = None,
        error: str | None = None,
    ) -> None:
        await self._send_message(
            ws,
            {
                "type": "action_result",
                "sessionId": session_id,
                "requestId": request_id,
                "action": action,
                "ok": ok,
                "result": result,
                "error": error,
            },
        )

    async def _release_client(self, ws: ServerConnection) -> None:
        self._clients.discard(ws)
        self._subscriptions.pop(ws, None)
        for layout_session in self._layout_sessions.pop(ws, {}).values():
            await layout_session.close()
        self._vscode_bridge.remove_client(ws)
        for task in self._log_tasks.pop(ws, {}).values():
            task.cancel()

    async def _close_session(
        self,
        ws: ServerConnection,
        session_id: str,
    ) -> None:
        self._subscriptions.setdefault(ws, {}).pop(session_id, None)
        if layout_session := self._layout_sessions.setdefault(ws, {}).pop(
            session_id, None
        ):
            await layout_session.close()
        if log_task := self._log_tasks.setdefault(ws, {}).pop(session_id, None):
            log_task.cancel()
        self._vscode_bridge.remove_session(ws, session_id)

    def _layout_session(
        self,
        ws: ServerConnection,
        session_id: str,
    ) -> LayoutRpcSession:
        sessions = self._layout_sessions.setdefault(ws, {})
        session = sessions.get(session_id)
        if session is not None:
            return session

        async def send(payload: dict[str, Any]) -> None:
            await self._send_message(ws, {"sessionId": session_id, **payload})

        session = LayoutRpcSession(layout_service, send)
        sessions[session_id] = session
        return session

    def _set_layout_data(
        self,
        project_root: str | None,
        target: ResolvedBuildTarget | None,
        *,
        path: str | None = None,
        loading: bool = False,
        error: str | None = None,
        bump_revision: bool = False,
    ) -> None:
        current = cast(UiLayoutData, self._store.get("layout_data"))
        same_context = projects.same_selection(
            current.project_root,
            current.target,
            project_root,
            target,
        ) and same_path(current.path, path)

        if path is None:
            revision = 0
        elif bump_revision:
            revision = current.revision + 1 if same_context else 1
        else:
            revision = current.revision if same_context else 1

        self._store.set(
            "layout_data",
            UiLayoutData(
                project_root=project_root,
                target=target,
                path=path,
                revision=revision,
                loading=loading,
                error=error,
            ),
        )

    async def _handle_layout_message(self, _message: WsMessage) -> None:
        project_state = cast(UiProjectState, self._store.get("project_state"))
        selected_project_root = project_state.selected_project_root
        selected_target = project_state.selected_target
        current_path = layout_service.current_path
        if (
            selected_project_root is None
            or selected_target is None
            or current_path is None
            or not same_path(str(current_path), selected_target.pcb_path)
        ):
            return
        self._set_layout_data(
            selected_project_root,
            selected_target,
            path=str(current_path),
            error=None,
            bump_revision=True,
        )

    def _selected_project_context(
        self,
    ) -> tuple[str | None, ResolvedBuildTarget | None]:
        project_list = cast(list[Project], self._store.get("projects"))
        project_state = cast(UiProjectState, self._store.get("project_state"))
        selected_project, selected_target = projects.resolve_selection(
            project_list,
            project_state,
        )
        return selected_project.root if selected_project else None, selected_target

    async def _sync_selected_layout(self) -> None:
        selected_project_root, selected_target = self._selected_project_context()

        if selected_project_root is None or selected_target is None:
            await layout_service.clear()
            self._set_layout_data(selected_project_root, selected_target)
            return

        layout_path = Path(selected_target.pcb_path).resolve()
        current_layout = cast(UiLayoutData, self._store.get("layout_data"))
        if not layout_path.exists():
            await layout_service.clear()
            self._set_layout_data(selected_project_root, selected_target)
            return

        if (
            current_layout.error is None
            and projects.same_selection(
                current_layout.project_root,
                current_layout.target,
                selected_project_root,
                selected_target,
            )
            and same_path(current_layout.path, str(layout_path))
            and same_path(
                str(layout_service.current_path)
                if layout_service.current_path
                else None,
                str(layout_path),
            )
        ):
            return

        try:
            model = await layout_service.open(layout_path)
        except FileNotFoundError:
            await layout_service.clear()
            self._set_layout_data(selected_project_root, selected_target)
            return
        except Exception as exc:
            await layout_service.clear()
            self._set_layout_data(
                selected_project_root,
                selected_target,
                error=str(exc),
            )
            log.exception(
                "Failed to load selected layout for %s",
                selected_project_root,
            )
            return

        await layout_service.broadcast(WsMessage(type="layout_updated", model=model))

    async def _sync_selected_pinout(self) -> None:
        selected_project_root, selected_target = self._selected_project_context()

        if selected_project_root is None or selected_target is None:
            self._store.set(
                "pinout_data",
                UiPinoutData(
                    project_root=selected_project_root,
                    target=selected_target,
                ),
            )
            return

        pinout = await asyncio.to_thread(
            artifacts.get_pinout,
            selected_project_root,
            selected_target,
        )
        self._store.set(
            "pinout_data",
            UiPinoutData(
                project_root=selected_project_root,
                target=selected_target,
                components=pinout or [],
            ),
        )

    async def _broadcast_state(self, field_name: str, data: Any) -> None:
        wire_key = self._store.wire_key(field_name)
        dead: list[ServerConnection] = []
        for ws, sessions in list(self._subscriptions.items()):
            for session_id, keys in sessions.items():
                try:
                    if wire_key in keys:
                        await self._send_state(ws, session_id, field_name, data)
                except websockets.ConnectionClosed:
                    dead.append(ws)
                    break
        for ws in dead:
            await self._release_client(ws)

    async def broadcast_state(self, field_name: str, data: Any) -> None:
        self._store.set(field_name, data)

    def _session_id(self, msg: dict[str, Any]) -> str:
        session_id = msg.get("sessionId")
        if isinstance(session_id, str) and session_id:
            return session_id
        return EXTENSION_SESSION_ID

    async def _broadcast_agent_message(self, payload: dict[str, object]) -> None:
        dead: list[ServerConnection] = []
        for ws, sessions in list(self._subscriptions.items()):
            for session_id in sessions:
                if session_id == EXTENSION_SESSION_ID:
                    continue
                try:
                    await self._send_message(
                        ws,
                        {
                            **payload,
                            "sessionId": session_id,
                        },
                    )
                except websockets.ConnectionClosed:
                    dead.append(ws)
                    break
        for ws in dead:
            await self._release_client(ws)

    async def _handle_agent_action(
        self,
        session_id: str,
        msg: dict[str, Any],
    ) -> None:
        action = str(msg.get("action", ""))
        agent_session_id = str(
            msg.get("agentSessionId") or msg.get("sessionIdValue") or ""
        )
        mutation_session_id = agent_session_id or None
        mutation_run_id = str(msg.get("runId") or "") or None
        try:
            match action:
                case "agent.createSession":
                    result = await self._agent.create_session(
                        AgentCreateSessionRequest.model_validate(msg)
                    )
                    mutation_session_id = result.session_id
                case "agent.createRun":
                    result = await self._agent.create_run(
                        agent_session_id,
                        AgentCreateRunRequest.model_validate(msg),
                    )
                    mutation_run_id = result.run_id
                case "agent.cancelRun":
                    await self._agent.cancel_run(
                        agent_session_id,
                        str(msg.get("runId") or ""),
                    )
                case "agent.steerRun":
                    await self._agent.steer_run(
                        agent_session_id,
                        str(msg.get("runId") or ""),
                        AgentSteerRunRequest.model_validate(msg),
                    )
                case "agent.interruptRun":
                    await self._agent.interrupt_run(
                        agent_session_id,
                        str(msg.get("runId") or ""),
                        AgentInterruptRunRequest.model_validate(msg),
                    )
                case _:
                    raise AgentServiceError(400, f"Unknown agent action: {action}")
            self._push_agent_state(
                action=action,
                session_id=mutation_session_id,
                run_id=mutation_run_id,
            )
        except AgentServiceError as exc:
            if mutation_session_id:
                with sessions_lock:
                    session = sessions_by_id.get(mutation_session_id)
                    if session is not None:
                        record_agent_action_error(
                            session,
                            action=action,
                            error=exc.message,
                            run_id=mutation_run_id,
                            request_message=(
                                str(msg.get("message"))
                                if isinstance(msg.get("message"), str)
                                else None
                            ),
                        )
                persist_sessions_state()
            self._push_agent_state(
                action=action,
                session_id=mutation_session_id,
                run_id=mutation_run_id,
                error=exc.message,
            )
            log.warning(
                "Agent action failed action=%s session_id=%s run_id=%s error=%s",
                action,
                mutation_session_id,
                mutation_run_id,
                exc.message,
            )
