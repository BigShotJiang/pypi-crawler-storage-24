"""Artifact domain logic for build outputs consumed by the UI."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from atopile import config
from atopile.data_models import PinoutComponent, ResolvedBuildTarget
from atopile.model.builds import resolve_build_target_config
from faebryk.exporters.pcb.kicad.artifacts import (
    KicadCliExportError,
    export_glb,
    githash_layout,
)


def _read_json_artifact(path: Path, *, label: str) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {label}: {exc}") from exc


def _target_build_config(
    project_root: str,
    target: ResolvedBuildTarget | None = None,
) -> config.BuildTargetConfig:
    return resolve_build_target_config(
        target.root if target else project_root,
        target.name if target else "default",
    )


def _target_build_dir(
    project_root: str,
    target: ResolvedBuildTarget | None = None,
) -> Path:
    return _target_build_config(project_root, target).paths.output_base.parent


def _target_artifact_path(
    project_root: str,
    suffix: str,
    target: ResolvedBuildTarget | None = None,
) -> Path:
    return _target_build_config(project_root, target).paths.output_base.with_suffix(
        suffix
    )


def _project_builds(project_root: str) -> dict[str, config.BuildTargetConfig]:
    project_path = Path(project_root)
    if not project_path.exists():
        raise ValueError(f"Project path does not exist: {project_root}")

    project_cfg = config.ProjectConfig.from_path(project_path)
    if project_cfg is None:
        raise ValueError(f"No ato.yaml found in: {project_root}")

    return project_cfg.builds


def read_target_json_artifact(
    project_root: str,
    suffix: str,
    *,
    label: str,
    target: ResolvedBuildTarget | None = None,
) -> dict | None:
    """Read a JSON artifact for a build target from its resolved output base."""
    return _read_json_artifact(
        _target_artifact_path(project_root, suffix, target),
        label=label,
    )


def list_target_artifact_names(project_root: str, *, suffix: str) -> list[str]:
    """Return build target names whose configured artifact path exists."""
    return sorted(
        name
        for name, build_cfg in _project_builds(project_root).items()
        if build_cfg.paths.output_base.with_suffix(suffix).exists()
    )


def get_pinout(
    project_root: str,
    target: ResolvedBuildTarget | None = None,
) -> list[PinoutComponent] | None:
    """Read per-component pinout JSON artifacts for a build target."""
    pinout_dir = _target_build_dir(project_root, target) / "pinout"
    if not pinout_dir.exists():
        return None

    return [
        PinoutComponent.model_validate(
            {**(_read_json_artifact(path, label=f"pinout {path.name}") or {}),
             "id": path.stem}
        )
        for path in sorted(pinout_dir.glob("*.json"))
    ]


def generate_3d_model(target: ResolvedBuildTarget) -> dict[str, str]:
    """Generate a GLB preview directly from the target's existing layout."""
    project_path = Path(target.root)
    if not project_path.exists():
        raise ValueError(f"Project path does not exist: {project_path}")

    build_cfg = _target_build_config(target.root, target)
    layout_path = build_cfg.paths.layout
    if not layout_path.exists():
        raise FileNotFoundError(
            f"Layout file not found: {layout_path}\n\n"
            "Run a full build first to generate the layout."
        )

    glb_path = build_cfg.paths.output_base.with_suffix(".pcba.glb")
    glb_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="atopile-glb-") as temp_dir:
        temp_layout = Path(temp_dir) / layout_path.name
        githash_layout(layout_path, temp_layout)
        try:
            export_glb(
                temp_layout,
                glb_file=glb_path,
                project_dir=layout_path.parent,
            )
        except KicadCliExportError as exc:
            raise ValueError(f"Failed to generate 3D model: {exc}") from exc

    return {"modelPath": str(glb_path)}


__all__ = [
    "generate_3d_model",
    "get_pinout",
    "list_target_artifact_names",
    "read_target_json_artifact",
]
