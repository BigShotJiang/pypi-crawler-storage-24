"""Create a fast development worktree with cloned .venv and Zig artifacts.

Python rewrite of scripts/worktree_fast.sh.
"""

import os
import re
import shutil
import subprocess
from pathlib import Path

from faebryk.libs.util import app_root, git_root

DEFAULT_BRANCH_PREFIX = "feature/"


def _log(msg: str) -> None:
    print(f"[worktree] {msg}")


def _resolve_main_worktree(repo_path: Path) -> Path:
    """Return the path of the main (first) git worktree."""
    result = subprocess.run(
        ["git", "-C", str(repo_path), "worktree", "list", "--porcelain"],
        capture_output=True,
        text=True,
        check=True,
    )
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            return Path(line[len("worktree ") :])
    raise RuntimeError("failed to detect main worktree path")


def _clone_dir(src: Path, dst: Path, *, force: bool = False) -> None:
    """Clone a directory tree."""
    if not src.is_dir():
        raise FileNotFoundError(f"source directory does not exist: {src}")

    if dst.exists() or dst.is_symlink():
        if force:
            shutil.rmtree(dst)
        else:
            raise FileExistsError(f"{dst} already exists (use --force)")

    shutil.copytree(src, dst, symlinks=True)
    _log(f"cloned: {dst}")


def _set_venv_prompt(venv: Path, prompt: str) -> None:
    """Set the shell prompt name in pyvenv.cfg."""
    pyvenv_cfg = venv / "pyvenv.cfg"
    if not pyvenv_cfg.is_file():
        return
    text = pyvenv_cfg.read_text()
    new_line = f"prompt = {prompt}"
    text, n = re.subn(r"^prompt\s*=.*$", new_line, text, count=1, flags=re.MULTILINE)
    if not n:
        text = text.rstrip("\n") + "\n" + new_line + "\n"
    pyvenv_cfg.write_text(text)
    _log(f"set venv prompt to '{prompt}'")


def _rewrite_venv_paths(source_root: Path, worktree_path: Path) -> None:
    """Rewrite absolute paths in the cloned venv from source_root to worktree_path."""
    venv = worktree_path / ".venv"
    source_str = str(source_root)
    dest_str = str(worktree_path)

    # 1. Rewrite .pth files (editable install source paths)
    site_packages = None
    for sp in (venv / "lib").glob("python*/site-packages"):
        site_packages = sp
        break

    if site_packages:
        for pth in site_packages.glob("_atopile*.pth"):
            text = pth.read_text()
            if source_str in text:
                pth.write_text(text.replace(source_str, dest_str))
                _log(f"rewrote: {pth}")

        # 2. Rewrite direct_url.json (PEP 660 editable metadata)
        for durl in site_packages.glob("atopile*.dist-info/direct_url.json"):
            text = durl.read_text()
            if source_str in text:
                durl.write_text(text.replace(source_str, dest_str))
                _log(f"rewrote: {durl}")

    # 3. Rewrite shebangs in all venv bin scripts
    count = 0
    bin_dir = venv / "bin"
    if bin_dir.is_dir():
        for script in bin_dir.iterdir():
            if not script.is_file():
                continue
            try:
                data = script.read_bytes()
                # Skip binary files (check for null bytes in first 512 bytes)
                if b"\x00" in data[:512]:
                    continue
                text = data.decode("utf-8", errors="strict")
            except UnicodeDecodeError, OSError:
                continue
            if source_str in text:
                script.write_text(text.replace(source_str, dest_str))
                count += 1
    _log(f"rewrote shebangs/paths in {count} scripts under .venv/bin/")

    # 4. Rewrite pyvenv.cfg if it references the source root
    pyvenv_cfg = venv / "pyvenv.cfg"
    if pyvenv_cfg.is_file():
        text = pyvenv_cfg.read_text()
        if source_str in text:
            pyvenv_cfg.write_text(text.replace(source_str, dest_str))
            _log(f"rewrote: {pyvenv_cfg}")


def _remote_branch_exists(
    source_root: Path,
    branch_name: str,
    *,
    timeout_seconds: int = 5,
) -> bool:
    """
    Check whether origin has the exact branch name.

    We probe refs/heads/<branch> explicitly (not a tail-match pattern), and bound
    the network call with a timeout so worktree creation does not hang indefinitely
    on unreachable remotes.
    """
    env = {
        **os.environ,
        # Never block the CLI on an interactive credential prompt while probing
        # whether an origin branch exists.
        "GIT_TERMINAL_PROMPT": "0",
        "GCM_INTERACTIVE": "Never",
    }
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(source_root),
                "ls-remote",
                "--exit-code",
                "--heads",
                "origin",
                f"refs/heads/{branch_name}",
            ],
            capture_output=True,
            env=env,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        _log("timed out checking origin branch; treating as non-existent")
        return False

    return result.returncode == 0


def create_worktree(
    name_suffix: str,
    *,
    branch_name: str | None = None,
    path: Path | None = None,
    start_point: str = "HEAD",
    base_dir: Path | None = None,
    source_root: Path | None = None,
    force: bool = False,
    skip_editable_install: bool = False,
) -> Path:
    """Create a fast development worktree with cloned .venv and Zig artifacts."""
    current_git_root = git_root()
    source_app_root = app_root().resolve()
    app_rel = source_app_root.relative_to(current_git_root)

    # Resolve source roots (main worktree + app root inside it)
    if source_root is None:
        source_git_root = _resolve_main_worktree(current_git_root)
        source_app_root = source_git_root / app_rel
    else:
        source_root = source_root.resolve()
        if (source_root / "pyproject.toml").is_file():
            source_app_root = source_root
            source_git_root = git_root(source_root)
        else:
            source_git_root = source_root
            source_app_root = source_git_root / app_rel

    if not (source_git_root / ".git").exists():
        raise RuntimeError(f"source root is not a git worktree: {source_git_root}")
    if not (source_app_root / ".venv").is_dir():
        raise RuntimeError(
            f"source app root does not have .venv: {source_app_root / '.venv'}"
        )

    # Determine worktree paths
    if path is None:
        if base_dir is None:
            base_dir = source_git_root.parent
        git_worktree_path = base_dir / f"{source_git_root.name}_{name_suffix}"
    else:
        git_worktree_path = path

    worktree_path = git_worktree_path / app_rel

    if git_worktree_path.exists():
        raise RuntimeError(f"target worktree path already exists: {git_worktree_path}")

    _log(f"main worktree: {source_git_root}")
    _log(f"app root:      {source_app_root}")
    _log(f"new worktree:  {worktree_path}")
    resolved_branch_name = branch_name or f"{DEFAULT_BRANCH_PREFIX}{name_suffix}"
    _log(f"branch:        {resolved_branch_name}")
    _log(f"start point:   {start_point}")

    # Create git worktree
    branch_exists_local = (
        subprocess.run(
            [
                "git",
                "-C",
                str(source_git_root),
                "show-ref",
                "--verify",
                "--quiet",
                f"refs/heads/{resolved_branch_name}",
            ],
            capture_output=True,
        ).returncode
        == 0
    )

    branch_exists_remote = False

    if branch_exists_local:
        _log(
            f"branch '{resolved_branch_name}' already exists locally; "
            "creating worktree on existing branch"
        )
        subprocess.run(
            [
                "git",
                "-C",
                str(source_git_root),
                "worktree",
                "add",
                str(git_worktree_path),
                resolved_branch_name,
            ],
            check=True,
        )
    else:
        branch_exists_remote = _remote_branch_exists(
            source_git_root, resolved_branch_name
        )

    if not branch_exists_local and branch_exists_remote:
        _log(
            f"branch '{resolved_branch_name}' exists on origin; "
            "creating local tracking branch"
        )
        subprocess.run(
            [
                "git",
                "-C",
                str(source_git_root),
                "worktree",
                "add",
                "--track",
                "-b",
                resolved_branch_name,
                str(git_worktree_path),
                f"origin/{resolved_branch_name}",
            ],
            check=True,
        )
    elif not branch_exists_local:
        _log(f"creating branch '{resolved_branch_name}' from '{start_point}'")
        subprocess.run(
            [
                "git",
                "-C",
                str(source_git_root),
                "worktree",
                "add",
                "-b",
                resolved_branch_name,
                str(git_worktree_path),
                start_point,
            ],
            check=True,
        )

    # Clone .venv
    _log("cloning venv")
    _clone_dir(source_app_root / ".venv", worktree_path / ".venv", force=force)

    # Clone zig-out if it exists
    zig_out_src = source_app_root / "src" / "faebryk" / "core" / "zig" / "zig-out"
    if zig_out_src.is_dir():
        zig_out_dst = worktree_path / "src" / "faebryk" / "core" / "zig" / "zig-out"
        _clone_dir(zig_out_src, zig_out_dst, force=force)

        # Write source hash so build-on-import skips the expensive zig build
        _log("computing zig source hash")
        zig_dir = worktree_path / "src" / "faebryk" / "core" / "zig"

        # Import directly — compute_hash is stdlib-only, no faebryk deps
        from faebryk.core.zig.compute_hash import compute_source_hash

        source_hash = compute_source_hash(zig_dir=zig_dir)

        hash_file = zig_out_dst / "lib" / ".zig-source-hash"
        hash_file.parent.mkdir(parents=True, exist_ok=True)
        hash_file.write_text(source_hash)
        _log(f"wrote zig source hash: {source_hash}")
    else:
        _log("zig-out not found in source tree; skipping zig-out clone")

    # Rewrite venv paths
    if not skip_editable_install:
        _log(f"rewriting venv paths: {source_app_root} -> {worktree_path}")
        _rewrite_venv_paths(source_app_root, worktree_path)
    else:
        _log("skipping venv path rewrite (--skip-editable-install)")

    _set_venv_prompt(worktree_path / ".venv", name_suffix)

    print(f"""
Done.
Use this worktree with:
  cd {worktree_path}
  source .venv/bin/activate
  ato --help

Notes:
  - This creates an isolated venv clone for the worktree.
  - Venv paths are rewritten in-place (no recompile needed).""")

    return worktree_path
