# This file is part of the faebryk project
# SPDX-License-Identifier: MIT

import faebryk.core.node as fabll
import faebryk.library._F as F


class Resistor(fabll.Node):
    # ----------------------------------------
    #     modules, interfaces, parameters
    # ----------------------------------------
    unnamed = [F.Electrical.MakeChild() for _ in range(2)]

    resistance = F.Parameters.NumericParameter.MakeChild(unit=F.Units.Ohm)
    max_power = F.Parameters.NumericParameter.MakeChild(unit=F.Units.Watt)
    max_voltage = F.Parameters.NumericParameter.MakeChild(unit=F.Units.Volt)

    # ----------------------------------------
    #                 traits
    # ----------------------------------------
    _is_module = fabll.Traits.MakeEdge(fabll.is_module.MakeChild())
    _is_sink = fabll.Traits.MakeEdge(F.is_sink.MakeChild())

    _can_attatch_to_footprint = fabll.Traits.MakeEdge(
        F.Footprints.can_attach_to_footprint.MakeChild()
    )

    for e in unnamed:
        lead = fabll.Traits.MakeEdge(F.Lead.is_lead.MakeChild(), [e])
        lead.add_dependant(
            fabll.Traits.MakeEdge(F.Lead.can_attach_to_any_pad.MakeChild(), [lead])
        )
        e.add_dependant(lead)

    can_bridge = fabll.Traits.MakeEdge(
        F.can_bridge.MakeChild(["unnamed[0]"], ["unnamed[1]"])
    )

    _is_pickable = fabll.Traits.MakeEdge(
        F.Pickable.is_pickable_by_type.MakeChild(
            endpoint=F.Pickable.is_pickable_by_type.Endpoint.RESISTORS,
            params={
                "resistance": resistance,
                "max_power": max_power,
                "max_voltage": max_voltage,
            },
            package_prefix="R",
        ),
    )

    S = F.has_simple_value_representation.Spec
    _simple_repr = fabll.Traits.MakeEdge(
        F.has_simple_value_representation.MakeChild(
            S(resistance, tolerance=True),
            S(max_power),
            S(max_voltage),
        )
    )

    designator_prefix = fabll.Traits.MakeEdge(
        F.has_designator_prefix.MakeChild(F.has_designator_prefix.Prefix.R)
    )

    usage_example = fabll.Traits.MakeEdge(
        F.has_usage_example.MakeChild(
            example="""
                import Resistor
                resistor = new Resistor
                resistor.resistance = 10kohm +/- 5%
            """,
            language=F.has_usage_example.Language.ato,
        ).put_on_type()
    )
