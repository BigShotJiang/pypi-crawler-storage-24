"""指令注册表 — 服务端下发，客户端纯缓存（含标签页分组）"""

from __future__ import annotations
from collections import OrderedDict

from .game_handler import CommandInfo


# ── 服务端下发的当前位置指令集 ──

_current_commands: list[CommandInfo] = []
_current_tabs: list[tuple[str, list[CommandInfo]]] = []  # [(tab_name, [cmds])]


def set_commands(commands: list[dict]) -> None:
    """接收服务端下发的指令列表，替换当前缓存并按 tab 分组"""
    global _current_commands, _current_tabs
    _current_commands = [
        CommandInfo(
            command=c.get('name', ''),
            label=c.get('label', ''),
            description=c.get('desc', ''),
            tab=c.get('tab', '其他'),
        )
        for c in commands
    ]
    # 按 tab 字段分组（保持服务端顺序）
    tabs: OrderedDict[str, list[CommandInfo]] = OrderedDict()
    for cmd in _current_commands:
        tabs.setdefault(cmd.tab, []).append(cmd)
    _current_tabs = list(tabs.items())


def get_available_commands() -> list[CommandInfo]:
    """获取当前可用指令（平铺）"""
    return list(_current_commands)


def get_command_tabs() -> list[tuple[str, list[CommandInfo]]]:
    """获取按标签页分组的指令列表"""
    return list(_current_tabs)


def filter_commands(prefix: str) -> list[CommandInfo]:
    """根据输入前缀过滤可用指令"""
    if not prefix:
        return list(_current_commands)
    return [c for c in _current_commands if c.command.startswith(prefix)]


def format_completion_bar(commands: list[CommandInfo], max_show: int = 6) -> str:
    """格式化指令列表为补全提示文本"""
    if not commands:
        return ""
    parts = [f"{c.command}({c.label})" for c in commands[:max_show]]
    text = "  ".join(parts)
    if len(commands) > max_show:
        text += f"  …(+{len(commands) - max_show})"
    return text
