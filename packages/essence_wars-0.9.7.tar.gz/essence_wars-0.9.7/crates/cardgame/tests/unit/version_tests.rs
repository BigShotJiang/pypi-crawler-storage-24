//! Tests migrated from inline #[cfg(test)] module in src/version.rs

use cardgame::version::{version_string, VersionInfo, VERSION};

#[test]
fn test_version_available() {
    assert!(!VERSION.is_empty());
    // Validate semver format (MAJOR.MINOR.PATCH)
    let parts: Vec<&str> = VERSION.split('.').collect();
    assert_eq!(parts.len(), 3, "VERSION should be semver: {}", VERSION);
    for part in &parts {
        assert!(part.parse::<u32>().is_ok(), "Non-numeric version part: {}", part);
    }
}

#[test]
fn test_version_string() {
    let vs = version_string();
    assert!(vs.contains("cardgame"));
    assert!(vs.contains(VERSION), "version_string() should contain VERSION constant");
}

#[test]
fn test_version_info_serializable() {
    let info = VersionInfo::current();
    let json = serde_json::to_string(&info).unwrap();
    assert!(json.contains(VERSION), "Serialized VersionInfo should contain VERSION");
}
