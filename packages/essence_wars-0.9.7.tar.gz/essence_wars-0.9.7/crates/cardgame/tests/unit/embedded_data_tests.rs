//! Tests migrated from inline #[cfg(test)] module in src/embedded_data.rs

use cardgame::cards::Faction;
use cardgame::embedded_data::{
    get_embedded_deck_ids, get_mvp_deck_ids, load_embedded_cards,
    load_embedded_cards_with_commanders, load_embedded_decks, load_embedded_game_data,
};

#[test]
fn test_load_embedded_cards() {
    let card_db = load_embedded_cards().expect("Failed to load embedded cards");
    assert!(
        card_db.len() >= 300,
        "Expected at least 300 cards, got {}",
        card_db.len()
    );
}

#[test]
fn test_load_embedded_decks() {
    let registry = load_embedded_decks().expect("Failed to load embedded decks");
    assert_eq!(registry.len(), 12, "Expected 12 decks");
}

#[test]
fn test_load_embedded_game_data() {
    let (cards, decks) = load_embedded_game_data().expect("Failed to load game data");
    assert!(cards.len() >= 300);
    assert_eq!(decks.len(), 12);
}

#[test]
fn test_mvp_decks_exist() {
    let registry = load_embedded_decks().expect("Failed to load decks");
    for deck_id in get_mvp_deck_ids() {
        assert!(
            registry.get(deck_id).is_some(),
            "MVP deck {} not found",
            deck_id
        );
    }
}

#[test]
fn test_all_deck_ids_valid() {
    let registry = load_embedded_decks().expect("Failed to load decks");
    for deck_id in get_embedded_deck_ids() {
        assert!(
            registry.get(deck_id).is_some(),
            "Deck {} not found",
            deck_id
        );
    }
}

#[test]
fn test_load_embedded_cards_with_commanders() {
    let card_db =
        load_embedded_cards_with_commanders().expect("Failed to load embedded cards with commanders");

    assert!(
        card_db.len() >= 300,
        "Expected at least 300 cards, got {}",
        card_db.len()
    );

    let commander_count = card_db.commander_count();
    assert_eq!(
        commander_count, 12,
        "Expected 12 commanders, got {}",
        commander_count
    );

    let argentum_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Argentum)
        .count();
    let symbiote_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Symbiote)
        .count();
    let obsidion_count = card_db
        .iter_commanders()
        .filter(|c| c.faction == Faction::Obsidion)
        .count();

    assert_eq!(argentum_count, 4, "Expected 4 Argentum commanders");
    assert_eq!(symbiote_count, 4, "Expected 4 Symbiote commanders");
    assert_eq!(obsidion_count, 4, "Expected 4 Obsidion commanders");
}

#[test]
fn test_embedded_commanders_have_abilities() {
    let card_db =
        load_embedded_cards_with_commanders().expect("Failed to load cards with commanders");

    for commander in card_db.iter_commanders() {
        let has_passive = commander.has_passive();
        let has_triggered = commander.has_triggered();
        assert!(
            has_passive || has_triggered,
            "Commander {} has no abilities",
            commander.name
        );
    }
}
