//! Tests migrated from inline #[cfg(test)] modules in src/tuning/*.rs

use std::path::PathBuf;

// ── checkpoint.rs ────────────────────────────────────────────────────────────

#[test]
fn test_cov_flatten_unflatten() {
    use cardgame::tuning::CmaEsCheckpoint;

    let cov = vec![
        vec![1.0, 0.1, 0.2],
        vec![0.1, 2.0, 0.3],
        vec![0.2, 0.3, 3.0],
    ];

    let flat = CmaEsCheckpoint::flatten_cov(&cov);
    assert_eq!(flat.len(), 9);

    let restored = CmaEsCheckpoint::unflatten_cov(&flat, 3).unwrap();
    assert_eq!(restored, cov);
}

#[test]
fn test_unflatten_cov_wrong_size() {
    use cardgame::tuning::CmaEsCheckpoint;

    let flat = vec![1.0, 2.0, 3.0];
    let result = CmaEsCheckpoint::unflatten_cov(&flat, 2);
    assert!(result.is_err());
}

#[test]
fn test_checkpoint_version() {
    use cardgame::tuning::checkpoint::CHECKPOINT_VERSION;
    use cardgame::tuning::TuningCheckpoint;
    assert_eq!(TuningCheckpoint::VERSION, CHECKPOINT_VERSION);
}

// ── experiment.rs ────────────────────────────────────────────────────────────

#[test]
fn test_experiment_config_new() {
    use cardgame::tuning::ExperimentConfig;

    let config = ExperimentConfig::new("experiments", "mcts", "test_run");
    assert_eq!(config.base_dir, PathBuf::from("experiments"));
    assert_eq!(config.category, "mcts");
    assert_eq!(config.tag, "test_run");
}

#[test]
fn test_experiment_dir_create() {
    use cardgame::tuning::{ExperimentConfig, ExperimentDir};

    let temp_dir = std::env::temp_dir().join("cardgame_test_exp");
    let _ = std::fs::remove_dir_all(&temp_dir);

    let config = ExperimentConfig::new(&temp_dir, "mcts", "unit_test");
    let exp_dir = ExperimentDir::create(&config).unwrap();

    assert!(exp_dir.root.exists());
    assert!(exp_dir.plots_dir.exists());
    assert!(exp_dir.id.contains("unit_test"));

    let _ = std::fs::remove_dir_all(&temp_dir);
}

#[test]
fn test_experiment_dir_save_version() {
    use cardgame::tuning::{ExperimentConfig, ExperimentDir};

    let temp_dir = std::env::temp_dir().join("cardgame_test_version");
    let _ = std::fs::remove_dir_all(&temp_dir);

    let config = ExperimentConfig::new(&temp_dir, "mcts", "version_test");
    let exp_dir = ExperimentDir::create(&config).unwrap();

    exp_dir.save_version().unwrap();

    let version_path = exp_dir.root.join("version.toml");
    assert!(version_path.exists());

    let _ = std::fs::remove_dir_all(&temp_dir);
}
