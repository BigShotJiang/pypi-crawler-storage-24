"""Unified evaluation for Essence Wars agents.

Example:
    from essence_wars.eval import UnifiedEvaluator
    evaluator = UnifiedEvaluator()
    results = evaluator.evaluate(["greedy", "mcts-100"])
"""

from .unified import UnifiedEvaluator, parse_agent_spec

__all__ = [
    "UnifiedEvaluator",
    "parse_agent_spec",
]
