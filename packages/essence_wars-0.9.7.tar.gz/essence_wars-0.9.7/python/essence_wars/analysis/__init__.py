"""
Analysis tools for Essence Wars experiments.

Modules:
    - aggregator: Collect and aggregate MCTS training runs
"""

from .aggregator import ExperimentAggregator, ExperimentMetadata, ExperimentRun

__all__ = [
    "ExperimentAggregator",
    "ExperimentMetadata",
    "ExperimentRun",
]
