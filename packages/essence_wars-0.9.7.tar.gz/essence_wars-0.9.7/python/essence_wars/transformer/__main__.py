"""Entry point for running the data generator as a module.

Usage:
    uv run python -m essence_wars.transformer --games 1000 --output data/transcripts/games.jsonl.gz
"""

from essence_wars.transformer.data_generator import main

main()
