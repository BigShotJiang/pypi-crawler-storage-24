"""Game Transformer — A language model approach to strategic card game play.

This module implements Phase 6 of the ML Research Plan: training a decoder-only
transformer on structured game transcripts to learn strategic play through
sequence modeling rather than RL.

See docs/GAME-TRANSFORMER.md for the full research design.
"""
