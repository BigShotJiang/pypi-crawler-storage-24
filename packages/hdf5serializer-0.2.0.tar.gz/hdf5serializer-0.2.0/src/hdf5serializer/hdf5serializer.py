import h5py
import numpy as np
from abc import ABC


class HDF5Serializable(ABC):

    def save_hdf5(self, filename, groupname=None):
        """Save object to an HDF5 file."""
        with h5py.File(filename, "w") as f:
            grp = f if groupname is None else f.create_group(groupname)
            self._save_to_group(grp)

    @classmethod
    def load_hdf5(cls, filename, groupname=None):
        """Load object from an HDF5 file."""
        with h5py.File(filename, "r") as f:
            grp = f if groupname is None else f[groupname]
            return cls._load_from_group(grp)

    def _save_to_group(self, group):
        """Internal recursive save."""

        group.attrs["_class"] = self.__class__.__name__

        for key, value in self.__dict__.items():

            if isinstance(value, np.ndarray):
                group.create_dataset(key, data=value)

            elif isinstance(value, (int, float, str, bool)):
                group.attrs[key] = value

            elif isinstance(value, HDF5Serializable):
                subgrp = group.create_group(key)
                value._save_to_group(subgrp)

            elif isinstance(value, list):
                subgrp = group.create_group(key)
                subgrp.attrs["_type"] = "list"

                for i, item in enumerate(value):
                    itemgrp = subgrp.create_group(str(i))
                    item._save_to_group(itemgrp)

            else:
                raise TypeError(f"Unsupported attribute type: {type(value)}")

    @classmethod
    def _load_from_group(cls, group):
        """Internal recursive load."""

        obj = cls.__new__(cls)

        # Load attributes
        for key, value in group.attrs.items():
            if key != "_class":
                setattr(obj, key, value)

        # Load datasets / groups
        for key, item in group.items():

            if isinstance(item, h5py.Dataset):
                setattr(obj, key, item[()])

            elif isinstance(item, h5py.Group):

                if item.attrs.get("_type") == "list":
                    values = []
                    for idx in sorted(item.keys(), key=int):
                        values.append(cls._load_dynamic(item[idx]))
                    setattr(obj, key, values)

                else:
                    setattr(obj, key, cls._load_dynamic(item))

        return obj

    @staticmethod
    def _load_dynamic(group):
        """Load object when only class name is known."""

        classname = group.attrs["_class"]

        for subclass in HDF5Serializable.__subclasses__():
            if subclass.__name__ == classname:
                return subclass._load_from_group(group)

        raise ValueError(f"Unknown class {classname}")
