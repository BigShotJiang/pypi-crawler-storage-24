"""CertiSigma Census — Cryptographic file inventory and exfiltration detection."""

__version__ = "1.9.2"
