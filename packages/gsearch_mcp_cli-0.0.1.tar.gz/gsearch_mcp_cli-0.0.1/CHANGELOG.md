# Changelog

All notable changes to gsearch-mcp-cli will be documented in this file.

Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
versioning follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.1] - 2026-03-22

### Added

- **Google Search** (`gsearch search` / `gsearch "query"`) — regular Google search with AI Overview, organic results, People Also Ask, and related searches
- **Google AI Mode** (`gsearch ai`) — synthesized AI response with structured sections and cited sources, equivalent to g.ai
- **Page Fetching** (`gsearch fetch`) — fetch any URL and convert to clean Markdown using trafilatura + html-to-markdown. SSRF-safe with IPv4/IPv6 validation
- **MCP Server** (`gsearch-mcp`) — 3 tools: `gsearch_search`, `gsearch_ai`, `gsearch_fetch` for AI agent integration via Model Context Protocol
- **Time/Date Filtering** — `--time` flag (hour, 1h, 12h, day, 24h, week, 7d, month, year) and `--after`/`--before` for custom date ranges. Supports arbitrary `Nh` patterns (e.g., 6h = last 6 hours)
- **Browser Automation** — headless Chrome via CDP (Chrome DevTools Protocol) with persistent warmed profile. No authentication needed
- **Multi-Browser Support** — auto-detects Chrome, Brave, Edge, Chromium, Vivaldi, Opera, Opera GX on macOS, Linux, and Windows
- **MCP Setup** (`gsearch setup add`) — configure MCP server for Claude Code, Gemini CLI, Cursor, Windsurf, Cline, Antigravity, Codex, and OpenCode
- **Skill Installer** (`gsearch skill install`) — install SKILL.md for Claude Code, Cursor, Codex, Gemini CLI, OpenCode, Antigravity, Cline, OpenClaw, CC-Claw, and generic agents
- **Profile Warmup** (`gsearch setup`) — one-time ~8s warmup establishes BotGuard trust cookies for anonymous Google access
- **Configuration** (`gsearch config`) — persistent config for browser preference, language, region, rate limits, timeouts
- **Diagnostics** (`gsearch doctor`) — check browser, profile, config, and connectivity
- **Rate Limiting** — built-in token bucket (default 1 search/2s, burst of 3) to prevent Google blocking
- **Crash Recovery** — auto-relaunch Chrome on CDP connection failure
- **Tab Context Manager** — guaranteed tab cleanup on error, max 5 concurrent tabs
- **Error Sanitization** — MCP responses strip file paths, PIDs, and port numbers
- **JSON Output** — `--json` flag on all search/fetch commands for programmatic use
- **AI Documentation** — `gsearch --docs` prints LLM-optimized reference for AI agents

### Security

- SSRF prevention in `gsearch fetch`: scheme whitelist (http/https only), private IP blocklist, DNS pre-resolution, IPv6 validation
- CDP restricted to `--remote-allow-origins=http://localhost`
- TOCTOU-safe port allocation via `--remote-debugging-port=0` + stderr parsing
- Error sanitization prevents information leakage to MCP clients

### Technical

- Python 3.10+, async throughout (websockets library for CDP)
- Pydantic BaseModel for all data models with automatic JSON serialization
- Single shared backend (`shared.py`) serves both CLI and MCP
- Click + rich-click for CLI, FastMCP for MCP server
- 86 unit tests, 1 integration test
