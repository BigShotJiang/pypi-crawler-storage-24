class GSearchError(Exception):
    """Base exception for gsearch-mcp-cli."""


class BrowserNotFoundError(GSearchError):
    """No supported Chromium browser found."""


class CDPConnectionError(GSearchError):
    """Failed to connect to Chrome via CDP."""


class SearchBlockedError(GSearchError):
    """Google blocked the search (unusual traffic)."""


class ProfileWarmupError(GSearchError):
    """Profile warmup failed."""


class FetchError(GSearchError):
    """Failed to fetch URL."""


class SSRFBlockedError(FetchError):
    """URL blocked for security (SSRF prevention)."""


class GSearchTimeoutError(GSearchError):
    """Operation timed out."""


class RateLimitError(GSearchError):
    """Rate limit exceeded."""


class PortExhaustedError(GSearchError):
    """All CDP ports in range are occupied."""


class ExtractionError(GSearchError):
    """Failed to extract results from DOM (selectors may be outdated)."""


class ConfigError(GSearchError):
    """Invalid configuration."""
