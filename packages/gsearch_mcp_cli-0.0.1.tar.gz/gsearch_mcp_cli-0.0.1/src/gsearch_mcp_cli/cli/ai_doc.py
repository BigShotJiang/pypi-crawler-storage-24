AI_DOC = """gsearch-mcp-cli v{version} — Google Search CLI and MCP for AI Agents

SETUP
  gsearch setup              # One-time profile warmup (~8s)
  gsearch setup --check      # Verify profile works
  gsearch setup --reset      # Delete and recreate profile
  gsearch setup add cursor   # Configure MCP for Cursor
  gsearch setup add claude-code  # Configure MCP for Claude Code
  gsearch setup list         # Show all MCP setup targets
  gsearch doctor             # Diagnose browser, profile, connectivity

SEARCH (default command)
  gsearch "query"                        # Regular Google search (default)
  gsearch search "query" --json          # JSON output
  gsearch search "query" --no-ai         # Skip AI Overview
  gsearch search "query" -n 5            # Max 5 results
  gsearch search "query" --lang fr       # French results
  gsearch search "query" --region CA     # Canadian results

TIME-FILTERED SEARCH (use for news, recent events, time-sensitive queries)
  gsearch "AI news" --time hour          # Last hour
  gsearch "AI news" --time 1h            # Last hour (alias)
  gsearch "news" --time 12h              # Last 12 hours
  gsearch "news" --time day              # Last 24 hours
  gsearch "news" --time 24h             # Last 24 hours (alias)
  gsearch "updates" --time week          # Last 7 days
  gsearch "updates" --time 7d            # Last 7 days (alias)
  gsearch "developments" --time month    # Last month
  gsearch "report" --time year           # Last year
  gsearch "events" --time 6h             # Last 6 hours (arbitrary)
  gsearch "earnings" --after 2026-01-01 --before 2026-03-31  # Custom date range

  Time filter values: hour, 1h, 12h, day, 24h, week, 7d, month, 1m, year, 1y
  Arbitrary hours: any "Nh" pattern (e.g., 3h, 6h, 18h)
  Custom range: --after YYYY-MM-DD and/or --before YYYY-MM-DD

AI MODE (Google AI Mode / g.ai)
  gsearch ai "query"                     # AI Mode synthesized response
  gsearch ai "query" --json              # JSON output
  gsearch ai "query" --time day          # With time filter
  gsearch ai "query" --after 2026-01-01  # With date range

FETCH (URL to Markdown)
  gsearch fetch "url"                    # Fetch and convert to Markdown
  gsearch fetch "url" --raw              # Plain text output
  gsearch fetch "url" --json             # JSON with metadata
  gsearch fetch "url" --browser always   # Force browser rendering

CONFIG
  gsearch config show                    # Show all settings
  gsearch config set browser brave       # Set preferred browser
  gsearch config set rate_limit 1.0      # Search throttle (seconds)

SKILL INSTALL
  gsearch skill install cursor           # Install for Cursor
  gsearch skill install claude-code      # Install for Claude Code
  gsearch skill install cc-claw          # Install for CC-Claw
  gsearch skill list                     # Show all targets

MCP TOOLS (for AI agents via MCP protocol)
  gsearch_search(query, max_results=10, include_ai=True, language="en",
                 time_filter=None, date_from=None, date_to=None, timeout_seconds=30)
  gsearch_ai(query, language="en",
             time_filter=None, date_from=None, date_to=None, timeout_seconds=30)
  gsearch_fetch(url, format="md", use_browser="auto", timeout_seconds=30)

  time_filter: "hour", "12h", "day", "week", "month", "year", or any "Nh" (e.g., "6h")
  date_from / date_to: "YYYY-MM-DD" for custom date range

WHEN TO USE TIME FILTERS
  "latest news about X"       -> time_filter="day" or "12h"
  "what happened today"       -> time_filter="day"
  "breaking news"             -> time_filter="hour"
  "recent developments"       -> time_filter="week"
  "this month's updates"      -> time_filter="month"
  "between Jan and March"     -> date_from="2026-01-01", date_to="2026-03-31"

NOTES
  - First run: gsearch setup runs automatically on first search
  - No Google account needed: anonymous, pseudonymous sessions
  - Rate limited: 1 search/2s default (configurable)
  - Headless: no visible browser window
  - SSRF protection: fetch validates URLs against private IP ranges
"""


def get_ai_doc(version: str) -> str:
    return AI_DOC.format(version=version)
