from unittest.mock import AsyncMock

import pytest


@pytest.fixture
def tmp_config_dir(tmp_path):
    """Temporary config directory for tests."""
    config_dir = tmp_path / ".gsearch-mcp-cli"
    config_dir.mkdir()
    return config_dir


@pytest.fixture
def mock_cdp_connection():
    """Mock CDPConnection that returns canned CDP responses."""
    conn = AsyncMock()
    conn.send = AsyncMock(return_value={"result": {}})
    conn.close = AsyncMock()
    return conn


@pytest.fixture
def mock_tab():
    """Mock Tab with canned evaluate() results."""
    tab = AsyncMock()
    tab.navigate = AsyncMock()
    tab.evaluate = AsyncMock(return_value={})
    tab.wait_for_load = AsyncMock()
    tab.override_ua = AsyncMock()
    tab.get_cookies = AsyncMock(return_value=[])

    async def _aenter(self):
        return tab
    async def _aexit(self, *exc):
        pass
    tab.__aenter__ = _aenter.__get__(tab)
    tab.__aexit__ = _aexit.__get__(tab)
    return tab


@pytest.fixture
def mock_browser_cdp(mock_tab):
    """Mock BrowserCDP that returns mock tabs."""
    browser = AsyncMock()
    browser.create_tab = AsyncMock(return_value=mock_tab)
    browser.close = AsyncMock()
    return browser


@pytest.fixture
def sample_search_html():
    """Sample Google search results for testing extractors."""
    return {
        "results": [
            {"position": 1, "title": "Test Result", "url": "https://example.com",
             "snippet": "A test snippet", "source": "example.com"}
        ],
        "ai_overview": None,
        "people_also_ask": ["What is test?"],
        "related_searches": ["test related"],
    }


@pytest.fixture
def sample_ai_html():
    """Sample Google AI Mode results for testing extractors."""
    return {
        "synthesis": "AI-generated synthesis text for testing.",
        "sections": [{"heading": "Overview", "content": "Content text", "items": ["item1", "item2"]}],
        "sources": [{"title": "Source", "url": "https://example.com", "domain": "example.com", "snippet": ""}],
    }
