from click.testing import CliRunner

from gsearch_mcp_cli.cli.main import cli


def test_config_show():
    runner = CliRunner()
    result = runner.invoke(cli, ["config", "show"])
    assert result.exit_code == 0
    assert "browser" in result.output


def test_config_set_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["config", "set", "--help"])
    assert result.exit_code == 0


def test_doctor_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--help"])
    assert result.exit_code == 0


def test_setup_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "--help"])
    assert result.exit_code == 0
    assert "--reset" in result.output
    assert "--check" in result.output


def test_skill_list():
    runner = CliRunner()
    result = runner.invoke(cli, ["skill", "list"])
    assert result.exit_code == 0
    assert "claude-code" in result.output
    assert "cursor" in result.output
    assert "cc-claw" in result.output
    assert "openclaw" in result.output
    assert "opencode" in result.output
    assert "antigravity" in result.output
    assert "cline" in result.output
    assert "agents" in result.output


def test_skill_install_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["skill", "install", "--help"])
    assert result.exit_code == 0
    assert "cc-claw" in result.output
    assert "openclaw" in result.output


def test_skill_install_creates_files(tmp_path):
    from gsearch_mcp_cli.cli.skill_cmd import _install_to
    target = tmp_path / "test-skill"
    _install_to(target)
    assert (target / "SKILL.md").is_file()
    assert (target / "references").is_dir()


# -- Setup MCP tests --

def test_setup_add_list():
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "list"])
    assert result.exit_code == 0
    assert "claude-code" in result.output
    assert "cursor" in result.output
    assert "gemini-cli" in result.output
    assert "windsurf" in result.output
    assert "cline" in result.output
    assert "antigravity" in result.output
    assert "codex" in result.output
    assert "opencode" in result.output


def test_setup_add_json():
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "add", "json"])
    assert result.exit_code == 0
    assert "gsearch-mcp" in result.output
    assert "mcpServers" in result.output
    assert "uvx" in result.output


def test_setup_add_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "add", "--help"])
    assert result.exit_code == 0
    assert "claude-code" in result.output


def test_setup_remove_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "remove", "--help"])
    assert result.exit_code == 0
