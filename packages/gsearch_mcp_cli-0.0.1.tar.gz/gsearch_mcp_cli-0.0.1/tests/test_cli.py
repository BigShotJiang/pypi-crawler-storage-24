from click.testing import CliRunner

from gsearch_mcp_cli.cli.main import cli


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "0.0.1" in result.output


def test_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "gsearch" in result.output.lower() or "search" in result.output.lower()


def test_ai_flag():
    runner = CliRunner()
    result = runner.invoke(cli, ["--ai"])
    assert result.exit_code == 0
    assert "gsearch" in result.output.lower()
    assert len(result.output) > 200


def test_search_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["search", "--help"])
    assert result.exit_code == 0
    assert "--json" in result.output
    assert "--max-results" in result.output
    assert "--lang" in result.output
