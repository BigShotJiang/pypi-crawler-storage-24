# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListSparkJobsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        '_from': 'int',
        'total': 'int',
        'sessions': 'list[SparkJob]',
        'create_time': 'int'
    }

    attribute_map = {
        '_from': 'from',
        'total': 'total',
        'sessions': 'sessions',
        'create_time': 'create_time'
    }

    def __init__(self, _from=None, total=None, sessions=None, create_time=None):
        r"""ListSparkJobsResponse

        The model defined in huaweicloud sdk

        :param _from: 参数解释:   起始批处理作业的索引号 示例: 0 约束限制:  无 取值范围: 无 默认取值: 无
        :type _from: int
        :param total: 参数解释:   返回批处理作业的总数 示例: 1 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无
        :type total: int
        :param sessions: 批处理作业信息。
        :type sessions: list[:class:`huaweicloudsdkdli.v1.SparkJob`]
        :param create_time: 参数解释:   批处理作业的创建时间 示例: 1747169165821 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无
        :type create_time: int
        """
        
        super().__init__()

        self.__from = None
        self._total = None
        self._sessions = None
        self._create_time = None
        self.discriminator = None

        if _from is not None:
            self._from = _from
        if total is not None:
            self.total = total
        if sessions is not None:
            self.sessions = sessions
        if create_time is not None:
            self.create_time = create_time

    @property
    def _from(self):
        r"""Gets the _from of this ListSparkJobsResponse.

        参数解释:   起始批处理作业的索引号 示例: 0 约束限制:  无 取值范围: 无 默认取值: 无

        :return: The _from of this ListSparkJobsResponse.
        :rtype: int
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        r"""Sets the _from of this ListSparkJobsResponse.

        参数解释:   起始批处理作业的索引号 示例: 0 约束限制:  无 取值范围: 无 默认取值: 无

        :param _from: The _from of this ListSparkJobsResponse.
        :type _from: int
        """
        self.__from = _from

    @property
    def total(self):
        r"""Gets the total of this ListSparkJobsResponse.

        参数解释:   返回批处理作业的总数 示例: 1 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无

        :return: The total of this ListSparkJobsResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListSparkJobsResponse.

        参数解释:   返回批处理作业的总数 示例: 1 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无

        :param total: The total of this ListSparkJobsResponse.
        :type total: int
        """
        self._total = total

    @property
    def sessions(self):
        r"""Gets the sessions of this ListSparkJobsResponse.

        批处理作业信息。

        :return: The sessions of this ListSparkJobsResponse.
        :rtype: list[:class:`huaweicloudsdkdli.v1.SparkJob`]
        """
        return self._sessions

    @sessions.setter
    def sessions(self, sessions):
        r"""Sets the sessions of this ListSparkJobsResponse.

        批处理作业信息。

        :param sessions: The sessions of this ListSparkJobsResponse.
        :type sessions: list[:class:`huaweicloudsdkdli.v1.SparkJob`]
        """
        self._sessions = sessions

    @property
    def create_time(self):
        r"""Gets the create_time of this ListSparkJobsResponse.

        参数解释:   批处理作业的创建时间 示例: 1747169165821 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无

        :return: The create_time of this ListSparkJobsResponse.
        :rtype: int
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this ListSparkJobsResponse.

        参数解释:   批处理作业的创建时间 示例: 1747169165821 约束限制:  无 取值范围: 大于等于0的整数 默认取值: 无

        :param create_time: The create_time of this ListSparkJobsResponse.
        :type create_time: int
        """
        self._create_time = create_time

    def to_dict(self):
        import warnings
        warnings.warn("ListSparkJobsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListSparkJobsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
