# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListTableUsersRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'database_name': 'str',
        'table_name': 'str'
    }

    attribute_map = {
        'database_name': 'database_name',
        'table_name': 'table_name'
    }

    def __init__(self, database_name=None, table_name=None):
        r"""ListTableUsersRequest

        The model defined in huaweicloud sdk

        :param database_name: 被查询的数据库名称。
        :type database_name: str
        :param table_name: 被查询的表名称。
        :type table_name: str
        """
        
        

        self._database_name = None
        self._table_name = None
        self.discriminator = None

        self.database_name = database_name
        self.table_name = table_name

    @property
    def database_name(self):
        r"""Gets the database_name of this ListTableUsersRequest.

        被查询的数据库名称。

        :return: The database_name of this ListTableUsersRequest.
        :rtype: str
        """
        return self._database_name

    @database_name.setter
    def database_name(self, database_name):
        r"""Sets the database_name of this ListTableUsersRequest.

        被查询的数据库名称。

        :param database_name: The database_name of this ListTableUsersRequest.
        :type database_name: str
        """
        self._database_name = database_name

    @property
    def table_name(self):
        r"""Gets the table_name of this ListTableUsersRequest.

        被查询的表名称。

        :return: The table_name of this ListTableUsersRequest.
        :rtype: str
        """
        return self._table_name

    @table_name.setter
    def table_name(self, table_name):
        r"""Sets the table_name of this ListTableUsersRequest.

        被查询的表名称。

        :param table_name: The table_name of this ListTableUsersRequest.
        :type table_name: str
        """
        self._table_name = table_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListTableUsersRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
