# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ExecuteFlinkJobSavepointRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'action': 'str',
        'savepoint_path': 'str'
    }

    attribute_map = {
        'action': 'action',
        'savepoint_path': 'savepoint_path'
    }

    def __init__(self, action=None, savepoint_path=None):
        r"""ExecuteFlinkJobSavepointRequestBody

        The model defined in huaweicloud sdk

        :param action: 操作类型
        :type action: str
        :param savepoint_path: obs桶路径.例 \&quot;bucket_name/file_name/\&quot;
        :type savepoint_path: str
        """
        
        

        self._action = None
        self._savepoint_path = None
        self.discriminator = None

        self.action = action
        self.savepoint_path = savepoint_path

    @property
    def action(self):
        r"""Gets the action of this ExecuteFlinkJobSavepointRequestBody.

        操作类型

        :return: The action of this ExecuteFlinkJobSavepointRequestBody.
        :rtype: str
        """
        return self._action

    @action.setter
    def action(self, action):
        r"""Sets the action of this ExecuteFlinkJobSavepointRequestBody.

        操作类型

        :param action: The action of this ExecuteFlinkJobSavepointRequestBody.
        :type action: str
        """
        self._action = action

    @property
    def savepoint_path(self):
        r"""Gets the savepoint_path of this ExecuteFlinkJobSavepointRequestBody.

        obs桶路径.例 \"bucket_name/file_name/\"

        :return: The savepoint_path of this ExecuteFlinkJobSavepointRequestBody.
        :rtype: str
        """
        return self._savepoint_path

    @savepoint_path.setter
    def savepoint_path(self, savepoint_path):
        r"""Sets the savepoint_path of this ExecuteFlinkJobSavepointRequestBody.

        obs桶路径.例 \"bucket_name/file_name/\"

        :param savepoint_path: The savepoint_path of this ExecuteFlinkJobSavepointRequestBody.
        :type savepoint_path: str
        """
        self._savepoint_path = savepoint_path

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ExecuteFlinkJobSavepointRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
