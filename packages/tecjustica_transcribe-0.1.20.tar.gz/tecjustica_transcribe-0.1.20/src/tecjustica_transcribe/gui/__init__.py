"""GUI desktop com NiceGUI."""
