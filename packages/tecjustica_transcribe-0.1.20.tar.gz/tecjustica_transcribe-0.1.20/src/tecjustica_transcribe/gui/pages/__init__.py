"""Páginas da GUI."""
