from setuptools import setup, find_packages

setup(
    name='ella_sc_common_interface',
    version='3.1.6',
    description='SC贴文销售公用的接口',
    long_description='SC贴文销售公用的接口，提供直播、贴文等通用接口封装。',
    long_description_content_type='text/plain',
    author='river',
    packages=find_packages(),
    install_requires=[
    "requests>=2.0.0",
    "jsonpath>=0.82",
    "websocket-client>=1.6.1",
    "websockets>=15.0.1"
             ]
)

