"""
gxb - A utility package for common pandas code snippets.
"""

from .core import message

__version__ = "0.1.0"
__all__ = ["message"]
