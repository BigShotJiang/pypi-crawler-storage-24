def message():
    """
    Returns a dictionary of common pandas code snippets.

    Returns:
        dict: A dictionary where keys are operation names and values are
              pandas code snippet strings.

    Example:
        >>> from gxb import message
        >>> snippets = message()
        >>> print(snippets["to_datetime"])
        DataFrame["colum_name"] = pd.to_datetime(DataFrame["colum_name"], errors = "coerce")
    """
    obj = {
        "to_datetime": 'DataFrame["colum_name"] = pd.to_datetime(DataFrame["colum_name"], errors = "coerce")',
        "string": 'DataFrame["column_name"] = DataFrame["column_name"].astype(str)',
    }
    return obj
