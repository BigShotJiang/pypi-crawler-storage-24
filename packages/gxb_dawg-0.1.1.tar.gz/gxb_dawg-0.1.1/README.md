# gxb

A lightweight Python utility package that provides ready-to-use **pandas code snippets** for common DataFrame operations.

## Installation

```bash
pip install gxb
```

## Usage

```python
from gxb import message

snippets = message()

# Get all available snippets
print(snippets)

# Get a specific snippet
print(snippets["to_datetime"])
# Output: DataFrame["colum_name"] = pd.to_datetime(DataFrame["colum_name"], errors = "coerce")

print(snippets["string"])
# Output: DataFrame["column_name"] = DataFrame["column_name"].astype(str)
```

## Available Snippets

| Key           | Description                              |
|---------------|------------------------------------------|
| `to_datetime` | Convert a column to datetime using pandas |
| `string`      | Convert a column to string type           |

## License

MIT License
