"""
WebForge test suite.
Run with: pytest tests/
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from WebForge.core import WebForgeApp, Request, Response
from WebForge.security import SecurityManager
from WebForge.env import EnvManager


# ------------------------------------------------------------------ #
#  Core tests                                                          #
# ------------------------------------------------------------------ #

def make_request(path="/", method="GET"):
    return Request(method=method, path=path, headers={}, body=b"", query={})


def test_basic_route():
    app = WebForgeApp()
    app._base_dir = "/tmp"
    app._template_dir = "/tmp"
    app._public_dir = "/tmp/public"

    @app.app("/hello")
    def hello():
        return Response("Hello, World!")

    req = make_request("/hello")
    resp = app._dispatch(req)
    assert resp.status == 200
    assert resp.body == "Hello, World!"


def test_404():
    app = WebForgeApp()
    app._base_dir = "/tmp"
    app._template_dir = "/tmp"
    app._public_dir = "/tmp/public"

    req = make_request("/nonexistent")
    resp = app._dispatch(req)
    assert resp.status == 404


def test_json_response():
    r = Response.json({"key": "value"})
    assert r.status == 200
    assert "application/json" in r.content_type
    assert '"key"' in r.body


def test_redirect():
    r = Response.redirect("/login")
    assert r.status == 302
    assert r.headers.get("Location") == "/login"


def test_security_passwordlock():
    app = WebForgeApp()
    app._base_dir = "/tmp"
    app._template_dir = "/tmp"
    app._public_dir = "/tmp/public"

    @app.app("/secret")
    def secret():
        return Response("SECRET!")

    app._security_rules["/secret"] = [{"type": "passwordlock", "password": "1234"}]

    # Without password – should get 401
    req = make_request("/secret")
    resp = app._dispatch(req)
    assert resp.status == 401

    # With correct password in query
    req2 = Request("GET", "/secret", {}, b"", {"password": ["1234"]})
    resp2 = app._dispatch(req2)
    assert resp2.status == 200


def test_method_not_allowed():
    app = WebForgeApp()
    app._base_dir = "/tmp"
    app._template_dir = "/tmp"
    app._public_dir = "/tmp/public"

    @app.app("/only-get", methods=["GET"])
    def only_get():
        return Response("ok")

    req = Request("POST", "/only-get", {}, b"", {})
    resp = app._dispatch(req)
    assert resp.status == 405


# ------------------------------------------------------------------ #
#  Security tests                                                      #
# ------------------------------------------------------------------ #

def test_hash_verify():
    sm = SecurityManager()
    h = sm.hash_password("secret", "salt")
    assert sm.verify_password("secret", h, "salt")
    assert not sm.verify_password("wrong", h, "salt")


def test_rate_limit():
    sm = SecurityManager()
    for _ in range(5):
        assert sm.check_rate_limit("127.0.0.1", max_requests=5, window=60)
    assert not sm.check_rate_limit("127.0.0.1", max_requests=5, window=60)


def test_generate_token():
    sm = SecurityManager()
    t = sm.generate_token(16)
    assert len(t) == 32  # hex = 2 chars per byte


# ------------------------------------------------------------------ #
#  EnvManager tests                                                    #
# ------------------------------------------------------------------ #

def test_env_read():
    os.environ["TEST_VAR"] = "hello"
    em = EnvManager()
    assert em.env("TEST_VAR") == "hello"
    assert em.env("MISSING_VAR", "default") == "default"


def test_env_required_missing():
    em = EnvManager()
    try:
        em.env_required("__DEFINITELY_NOT_SET__")
        assert False, "Should have raised"
    except EnvironmentError:
        pass
