"""
WebForge CLI – scaffold and run WebForge projects.

Commands:
  webforge new <name>   Create a new WebForge project
  webforge run          Run the current project
  webforge version      Print the version
"""

import sys
import os
import subprocess
from pathlib import Path


FORGE_PY_TEMPLATE = '''\
from WebForge import env as web

# Load environment variables
# password = web.env("PASSWORD")

@web.app("/")
def index():
    web.route("style", "/public/service/style.css")
    web.route("script", "/public/script/app.js")
    return web.render("index.html")

@web.app("/about")
def about():
    return web.render("about.html", {"title": "About"})

# @web.security("/")
# def protect_index():
#     web.passwordlock(web.env("PASSWORD"))

if __name__ == "__main__":
    web.runapp(debug=True, port=5000, host="0.0.0.0")
'''

INDEX_HTML_TEMPLATE = '''\
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebForge App</title>
</head>
<body>
    <h1>Hello from WebForge! 🔥</h1>
    <p>Edit <code>public/pages/index.html</code> to get started.</p>
</body>
</html>
'''

ABOUT_HTML_TEMPLATE = '''\
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ title }}</title>
</head>
<body>
    <h1>{{ title }}</h1>
    <p>A WebForge-powered page.</p>
    <a href="/">← Home</a>
</body>
</html>
'''

STYLE_CSS_TEMPLATE = '''\
/* WebForge default styles */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: system-ui, sans-serif;
    background: #0f0f0f;
    color: #f0f0f0;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
}

h1 { font-size: 2.5rem; margin-bottom: 1rem; }
p  { color: #aaa; }
code { background: #222; padding: 2px 6px; border-radius: 4px; }
a { color: #4af; }
'''

APP_JS_TEMPLATE = '''\
// WebForge app script
console.log("WebForge 🔥 loaded");
'''

REQUIREMENTS_TEMPLATE = '''\
WebForge
'''

GITIGNORE_TEMPLATE = '''\
__pycache__/
*.pyc
*.pyo
.env
.env.*
venv/
.venv/
*.egg-info/
dist/
build/
'''


def cmd_new(name: str):
    root = Path(name)
    if root.exists():
        print(f"  ✗  Directory '{name}' already exists.")
        sys.exit(1)

    dirs = [
        root / "backend" / "server",
        root / "public" / "pages",
        root / "public" / "script",
        root / "public" / "service",
    ]
    for d in dirs:
        d.mkdir(parents=True)

    (root / "backend" / "server" / "forge.py").write_text(FORGE_PY_TEMPLATE)
    (root / "backend" / "requirements.txt").write_text(REQUIREMENTS_TEMPLATE)
    (root / "public" / "pages" / "index.html").write_text(INDEX_HTML_TEMPLATE)
    (root / "public" / "pages" / "about.html").write_text(ABOUT_HTML_TEMPLATE)
    (root / "public" / "script" / "app.js").write_text(APP_JS_TEMPLATE)
    (root / "public" / "service" / "style.css").write_text(STYLE_CSS_TEMPLATE)
    (root / ".gitignore").write_text(GITIGNORE_TEMPLATE)

    print(f"\n  🔥 WebForge project '{name}' created!\n")
    print(f"  cd {name}")
    print(f"  pip install -r backend/requirements.txt")
    print(f"  python backend/server/forge.py\n")


def cmd_run():
    forge = Path("backend") / "server" / "forge.py"
    if not forge.exists():
        print("  ✗  No forge.py found. Are you in a WebForge project root?")
        sys.exit(1)
    subprocess.run([sys.executable, str(forge)])


def cmd_version():
    from WebForge import __version__
    print(f"  WebForge v{__version__}")


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help", "help"):
        print(__doc__)
        return

    command = args[0]

    if command == "new":
        if len(args) < 2:
            print("  Usage: webforge new <project-name>")
            sys.exit(1)
        cmd_new(args[1])

    elif command == "run":
        cmd_run()

    elif command in ("version", "--version", "-v"):
        cmd_version()

    else:
        print(f"  Unknown command: {command}")
        print("  Run 'webforge --help' for usage.")
        sys.exit(1)


if __name__ == "__main__":
    main()
