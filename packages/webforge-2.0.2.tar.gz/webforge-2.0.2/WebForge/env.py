"""
WebForge Env Module
-------------------
This module exposes a single `env` instance that acts as the
all-in-one namespace for WebForge's API:

    from WebForge import env as web

    @web.app("/")
    def index():
        web.route("style", "/public/service/style.css")
        return web.render("index.html")

    web.runapp(debug=True, port=5000)

The `EnvManager` class delegates routing, rendering, security and
server management to a lazily-created `WebForgeApp` instance, and
adds environment-variable helpers.
"""

import os
from typing import Any, Optional
from .core import WebForgeApp
from .security import SecurityManager


class EnvManager:
    """
    Acts as `web` in user code – a unified facade over WebForgeApp + env vars.
    """

    def __init__(self):
        self._app: Optional[WebForgeApp] = None
        self._security_manager = SecurityManager()

    # ------------------------------------------------------------------ #
    #  Lazy app creation                                                   #
    # ------------------------------------------------------------------ #

    @property
    def _get_app(self) -> WebForgeApp:
        if self._app is None:
            self._app = WebForgeApp()
        return self._app

    # ------------------------------------------------------------------ #
    #  Environment variables                                               #
    # ------------------------------------------------------------------ #

    def env(self, key: str, default: Any = None) -> Any:
        """
        Read an environment variable (like os.getenv).

            password = web.env("PASSWORD")
        """
        return os.environ.get(key, default)

    def env_required(self, key: str) -> str:
        """Read an environment variable, raising if missing."""
        value = os.environ.get(key)
        if value is None:
            raise EnvironmentError(
                f"WebForge: required environment variable '{key}' is not set."
            )
        return value

    def set_env(self, key: str, value: str):
        """Set an environment variable at runtime."""
        os.environ[key] = value

    # ------------------------------------------------------------------ #
    #  Routing – delegates to WebForgeApp                                  #
    # ------------------------------------------------------------------ #

    def app(self, path: str, methods: list = None):
        """Route decorator. See WebForgeApp.app()."""
        return self._get_app.app(path, methods=methods)

    def route(self, name: str, filepath: str):
        """Register a static asset for the current handler. See WebForgeApp.route()."""
        return self._get_app.route(name, filepath)

    def render(self, template: str, context: dict = None):
        """Render a template. See WebForgeApp.render()."""
        return self._get_app.render(template, context)

    # ------------------------------------------------------------------ #
    #  Security – delegates to WebForgeApp                                 #
    # ------------------------------------------------------------------ #

    def security(self, path: str):
        """Security decorator. See WebForgeApp.security()."""
        return self._get_app.security(path)

    def passwordlock(self, password: str):
        """Declare a password-lock rule inside a @web.security block."""
        return self._get_app.passwordlock(password)

    # ------------------------------------------------------------------ #
    #  Response helpers                                                    #
    # ------------------------------------------------------------------ #

    def json(self, data: Any, status: int = 200):
        """Return a JSON response."""
        from .core import Response
        return Response.json(data, status)

    def redirect(self, location: str, status: int = 302):
        """Return a redirect response."""
        from .core import Response
        return Response.redirect(location, status)

    def response(self, body: str = "", status: int = 200, content_type: str = "text/html; charset=utf-8"):
        """Return a raw Response object."""
        from .core import Response
        return Response(body, status, content_type)

    # ------------------------------------------------------------------ #
    #  Hooks                                                               #
    # ------------------------------------------------------------------ #

    def before_request(self, func):
        return self._get_app.before_request(func)

    def after_request(self, func):
        return self._get_app.after_request(func)

    def errorhandler(self, code: int):
        return self._get_app.errorhandler(code)

    # ------------------------------------------------------------------ #
    #  Security utilities (delegated to SecurityManager)                   #
    # ------------------------------------------------------------------ #

    @property
    def security_manager(self) -> SecurityManager:
        return self._security_manager

    def hash_password(self, password: str, salt: str = "") -> str:
        return self._security_manager.hash_password(password, salt)

    def verify_password(self, password: str, hashed: str, salt: str = "") -> bool:
        return self._security_manager.verify_password(password, hashed, salt)

    def generate_token(self, length: int = 32) -> str:
        return self._security_manager.generate_token(length)

    # ------------------------------------------------------------------ #
    #  Server                                                              #
    # ------------------------------------------------------------------ #

    def runapp(self, host: str = "0.0.0.0", port: int = 5000, debug: bool = False):
        """
        Start the WebForge server.

            web.runapp(debug=True, port=5000, host="0.0.0.0")
        """
        import inspect
        frame = inspect.stack()[1]
        # Pass caller file so the app can detect the project layout
        self._get_app._detect_layout(frame.filename)
        self._get_app.runapp(host=host, port=port, debug=debug)


# -----------------------------------------------------------------------
# Singleton instance – imported as `env` by user code
# -----------------------------------------------------------------------
env = EnvManager()
