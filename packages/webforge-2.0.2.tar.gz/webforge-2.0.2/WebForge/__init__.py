"""
WebForge - A simple and elegant web framework for Python
"""

from .core import WebForgeApp
from .security import SecurityManager
from .env import EnvManager

__version__ = "0.1.0"
__author__ = "WebForge"
__all__ = ["WebForgeApp", "SecurityManager", "EnvManager", "webforge"]

# Convenience: expose a default app instance as `webforge`
webforge = WebForgeApp
