"""
WebForge Core - The heart of the WebForge framework.
Manages routing, rendering, static files, and the WSGI server.
"""

import os
import mimetypes
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
from typing import Callable, Optional, Dict, Any
import json


class Request:
    """Represents an incoming HTTP request."""

    def __init__(self, method: str, path: str, headers: dict, body: bytes, query: dict):
        self.method = method
        self.path = path
        self.headers = headers
        self.body = body
        self.query = query
        self._json = None

    def json(self) -> Any:
        """Parse body as JSON."""
        if self._json is None:
            try:
                self._json = json.loads(self.body.decode("utf-8"))
            except Exception:
                self._json = {}
        return self._json

    def form(self) -> dict:
        """Parse body as form data."""
        try:
            from urllib.parse import parse_qs
            data = parse_qs(self.body.decode("utf-8"))
            return {k: v[0] if len(v) == 1 else v for k, v in data.items()}
        except Exception:
            return {}


class Response:
    """Represents an HTTP response."""

    def __init__(self, body: str = "", status: int = 200, content_type: str = "text/html; charset=utf-8"):
        self.body = body
        self.status = status
        self.content_type = content_type
        self.headers: Dict[str, str] = {}

    def set_header(self, key: str, value: str):
        self.headers[key] = value
        return self

    @staticmethod
    def json(data: Any, status: int = 200) -> "Response":
        return Response(
            body=json.dumps(data, ensure_ascii=False),
            status=status,
            content_type="application/json; charset=utf-8"
        )

    @staticmethod
    def redirect(location: str, status: int = 302) -> "Response":
        r = Response(body="", status=status)
        r.set_header("Location", location)
        return r


# Thread-local storage for current request/response context
_local = threading.local()


def _get_current_app():
    return getattr(_local, "app", None)


class WebForgeApp:
    """
    The main WebForge application class.

    Usage:
        from WebForge import env as web

        @web.app("/")
        def index():
            return web.render("index.html")

        web.runapp(debug=True, port=5000)
    """

    def __init__(self):
        self._routes: Dict[str, Dict[str, Callable]] = {}  # path -> {method -> handler}
        self._static_routes: Dict[str, str] = {}           # url_prefix -> filesystem_path
        self._security_rules: Dict[str, list] = {}         # path -> [rules]
        self._base_dir: Optional[str] = None
        self._template_dir: Optional[str] = None
        self._public_dir: Optional[str] = None
        self._current_route_statics: Dict[str, str] = {}   # registered within a request handler
        self._before_request_hooks: list = []
        self._after_request_hooks: list = []
        self._error_handlers: Dict[int, Callable] = {}

    # ------------------------------------------------------------------ #
    #  Project layout detection                                            #
    # ------------------------------------------------------------------ #

    def _detect_layout(self, caller_file: Optional[str] = None):
        """
        Auto-detect the WebForge project layout based on the caller's file
        location (forge.py lives in backend/server/).
        Expected layout:
            project_root/
              backend/server/forge.py
              public/pages/       ← HTML templates
              public/service/     ← static assets
              public/script/      ← JS files
        """
        if caller_file:
            # backend/server/ -> backend/ -> project_root/
            server_dir = Path(caller_file).resolve().parent
            backend_dir = server_dir.parent
            project_root = backend_dir.parent
        else:
            project_root = Path.cwd()

        self._base_dir = str(project_root)
        self._template_dir = str(project_root / "public" / "pages")
        self._public_dir = str(project_root / "public")

    # ------------------------------------------------------------------ #
    #  Routing decorator                                                   #
    # ------------------------------------------------------------------ #

    def app(self, path: str, methods: list = None):
        """
        Decorator to register a route handler.

        @web.app("/")
        def index():
            web.route("style", "/public/service/style.css")
            return web.render("index.html")
        """
        if methods is None:
            methods = ["GET", "POST", "PUT", "DELETE", "PATCH"]

        def decorator(func: Callable):
            if path not in self._routes:
                self._routes[path] = {}
            for method in methods:
                self._routes[path][method.upper()] = func
            return func

        return decorator

    # ------------------------------------------------------------------ #
    #  Static file routing (called INSIDE a route handler)                #
    # ------------------------------------------------------------------ #

    def route(self, name: str, filepath: str):
        """
        Register a static file to be served for the current request context.
        The file path is relative to the project root.

        web.route("style", "/public/service/style.css")
        """
        self._current_route_statics[name] = filepath

    # ------------------------------------------------------------------ #
    #  Rendering                                                           #
    # ------------------------------------------------------------------ #

    def render(self, template: str, context: dict = None) -> Response:
        """
        Render an HTML template from public/pages/.
        Supports simple {{ variable }} substitution.

        return web.render("index.html", {"title": "Home"})
        """
        if self._template_dir is None:
            self._detect_layout()

        template_path = Path(self._template_dir) / template
        if not template_path.exists():
            return Response(f"<h1>404 – Template not found: {template}</h1>", status=404)

        html = template_path.read_text(encoding="utf-8")

        # Inject static route <link> / <script> tags automatically
        injections = []
        for name, filepath in self._current_route_statics.items():
            abs_path = Path(self._base_dir or "") / filepath.lstrip("/")
            if abs_path.suffix == ".css":
                injections.append(f'<link rel="stylesheet" href="{filepath}">')
            elif abs_path.suffix == ".js":
                injections.append(f'<script src="{filepath}" defer></script>')

        if injections:
            inject_str = "\n    ".join(injections)
            if "</head>" in html:
                html = html.replace("</head>", f"    {inject_str}\n</head>")
            else:
                html = inject_str + "\n" + html

        # Simple context substitution {{ key }}
        if context:
            for key, value in context.items():
                html = html.replace("{{{{ {key} }}}}".format(key=key), str(value))
                html = html.replace(f"{{{{ {key} }}}}", str(value))
                html = html.replace(f"{{{{{key}}}}}", str(value))

        return Response(html)

    # ------------------------------------------------------------------ #
    #  Security                                                            #
    # ------------------------------------------------------------------ #

    def security(self, path: str):
        """
        Decorator to attach security rules to a route.

        @web.security("/")
        def protect():
            web.passwordlock(password)
        """
        def decorator(func: Callable):
            self._security_rules.setdefault(path, [])
            # Execute the function to collect rules
            try:
                func()
            except _SecurityRuleCollected as e:
                self._security_rules[path].append(e.rule)
            return func
        return decorator

    def passwordlock(self, password: str):
        """Declare a password-lock rule (used inside a @web.security block)."""
        raise _SecurityRuleCollected({"type": "passwordlock", "password": password})

    # ------------------------------------------------------------------ #
    #  Hooks                                                               #
    # ------------------------------------------------------------------ #

    def before_request(self, func: Callable):
        self._before_request_hooks.append(func)
        return func

    def after_request(self, func: Callable):
        self._after_request_hooks.append(func)
        return func

    def errorhandler(self, code: int):
        def decorator(func: Callable):
            self._error_handlers[code] = func
            return func
        return decorator

    # ------------------------------------------------------------------ #
    #  Run                                                                 #
    # ------------------------------------------------------------------ #

    def runapp(self, host: str = "0.0.0.0", port: int = 5000, debug: bool = False):
        """
        Start the WebForge development server.

        web.runapp(debug=True, port=5000, host="0.0.0.0")
        """
        import inspect
        frame = inspect.stack()[1]
        caller_file = frame.filename
        self._detect_layout(caller_file)

        app = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                if debug:
                    super().log_message(format, *args)

            def _handle(self):
                parsed = urlparse(self.path)
                path = parsed.path
                query = parse_qs(parsed.query)

                # Read body
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length) if content_length else b""

                headers = dict(self.headers)
                request = Request(
                    method=self.command,
                    path=path,
                    headers=headers,
                    body=body,
                    query=query,
                )

                response = app._dispatch(request)
                self._send_response(response)

            def _send_response(self, response: Response):
                self.send_response(response.status)
                self.send_header("Content-Type", response.content_type)
                for k, v in response.headers.items():
                    self.send_header(k, v)
                body_bytes = response.body.encode("utf-8") if isinstance(response.body, str) else response.body
                self.send_header("Content-Length", str(len(body_bytes)))
                self.end_headers()
                self.wfile.write(body_bytes)

            def do_GET(self):    self._handle()
            def do_POST(self):   self._handle()
            def do_PUT(self):    self._handle()
            def do_DELETE(self): self._handle()
            def do_PATCH(self):  self._handle()

        server = HTTPServer((host, port), Handler)
        print(f"\n  🔥 WebForge running on http://{host}:{port}")
        print(f"  📁 Project root: {self._base_dir}")
        if debug:
            print("  🐛 Debug mode: ON\n")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\n  ⛔ Server stopped.")
            server.server_close()

    # ------------------------------------------------------------------ #
    #  Internal dispatch                                                   #
    # ------------------------------------------------------------------ #

    def _dispatch(self, request: Request) -> Response:
        """Route a request to the appropriate handler."""
        self._current_route_statics = {}

        # 1. Try to serve a static file from public/
        static_response = self._try_static(request.path)
        if static_response:
            return static_response

        # 2. Before-request hooks
        for hook in self._before_request_hooks:
            result = hook(request)
            if isinstance(result, Response):
                return result

        # 3. Security check
        sec_response = self._check_security(request)
        if sec_response:
            return sec_response

        # 4. Route matching
        handler_map = self._routes.get(request.path)
        if not handler_map:
            return self._handle_error(404, request)

        handler = handler_map.get(request.method)
        if not handler:
            return Response("Method Not Allowed", status=405)

        # 5. Execute handler
        try:
            result = handler()
        except Exception as e:
            if 500 in self._error_handlers:
                return self._error_handlers[500](e)
            return Response(f"<h1>500 Internal Server Error</h1><pre>{e}</pre>", status=500)

        if isinstance(result, Response):
            response = result
        elif isinstance(result, str):
            response = Response(result)
        elif isinstance(result, dict):
            response = Response.json(result)
        else:
            response = Response(str(result))

        # 6. After-request hooks
        for hook in self._after_request_hooks:
            hook(request, response)

        return response

    def _try_static(self, path: str) -> Optional[Response]:
        """Attempt to serve a static file from the public/ directory."""
        if self._public_dir is None:
            return None

        # Map URL paths under /public/ to filesystem
        if path.startswith("/public/"):
            rel = path.lstrip("/")
            full_path = Path(self._base_dir or "") / rel
            if full_path.exists() and full_path.is_file():
                mime, _ = mimetypes.guess_type(str(full_path))
                content = full_path.read_bytes()
                r = Response.__new__(Response)
                r.body = content
                r.status = 200
                r.content_type = mime or "application/octet-stream"
                r.headers = {}
                return r
        return None

    def _check_security(self, request: Request) -> Optional[Response]:
        rules = self._security_rules.get(request.path, [])
        for rule in rules:
            if rule["type"] == "passwordlock":
                # Check Authorization header or query param
                auth = request.headers.get("Authorization", "")
                pwd_param = request.query.get("password", [None])[0]
                expected = rule["password"]
                if auth != f"Bearer {expected}" and pwd_param != expected:
                    return Response(
                        '<h1>401 – Unauthorized</h1><p>Password required.</p>',
                        status=401
                    )
        return None

    def _handle_error(self, code: int, request: Request) -> Response:
        if code in self._error_handlers:
            return self._error_handlers[code](request)
        messages = {
            404: "<h1>404 – Page Not Found</h1>",
            403: "<h1>403 – Forbidden</h1>",
        }
        return Response(messages.get(code, f"<h1>{code} Error</h1>"), status=code)


class _SecurityRuleCollected(Exception):
    def __init__(self, rule: dict):
        self.rule = rule
