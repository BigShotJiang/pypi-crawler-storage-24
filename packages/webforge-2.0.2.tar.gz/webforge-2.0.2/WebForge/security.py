"""
WebForge Security Module
Provides security utilities: password protection, CORS, rate limiting, etc.
"""

import hashlib
import time
from typing import Dict, Tuple, Optional
from functools import wraps


class SecurityManager:
    """
    Standalone security manager (can be used independently of the main app).
    """

    def __init__(self):
        self._rate_limits: Dict[str, list] = {}  # ip -> [timestamps]

    # ------------------------------------------------------------------ #
    #  Password hashing                                                    #
    # ------------------------------------------------------------------ #

    @staticmethod
    def hash_password(password: str, salt: str = "") -> str:
        """Return a SHA-256 hex digest of password+salt."""
        raw = (password + salt).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    @staticmethod
    def verify_password(password: str, hashed: str, salt: str = "") -> bool:
        return SecurityManager.hash_password(password, salt) == hashed

    # ------------------------------------------------------------------ #
    #  Rate limiting                                                       #
    # ------------------------------------------------------------------ #

    def check_rate_limit(self, key: str, max_requests: int = 60, window: int = 60) -> bool:
        """
        Returns True if the key is within the rate limit, False if exceeded.
        key    : usually the client IP
        max_requests: allowed requests per window
        window : time window in seconds
        """
        now = time.time()
        history = self._rate_limits.get(key, [])
        # Keep only timestamps within the window
        history = [t for t in history if now - t < window]
        if len(history) >= max_requests:
            self._rate_limits[key] = history
            return False
        history.append(now)
        self._rate_limits[key] = history
        return True

    # ------------------------------------------------------------------ #
    #  CORS headers helper                                                 #
    # ------------------------------------------------------------------ #

    @staticmethod
    def cors_headers(
        origin: str = "*",
        methods: str = "GET, POST, PUT, DELETE, OPTIONS",
        headers: str = "Content-Type, Authorization",
    ) -> Dict[str, str]:
        return {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": methods,
            "Access-Control-Allow-Headers": headers,
        }

    # ------------------------------------------------------------------ #
    #  Token helper                                                        #
    # ------------------------------------------------------------------ #

    @staticmethod
    def generate_token(length: int = 32) -> str:
        import secrets
        return secrets.token_hex(length)
