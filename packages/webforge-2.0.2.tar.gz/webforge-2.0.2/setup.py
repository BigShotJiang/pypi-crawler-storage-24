from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="WebForge",
    version="2.0.2",
    author="WebForge Contributors",
    description="A simple and elegant Python web framework – forge your site in minutes.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=["WebForge"],
    package_dir={"WebForge": "WebForge"},
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "dev": ["pytest", "requests"],
    },
    entry_points={
        "console_scripts": [
            "webforge=WebForge.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
    ],
    keywords="web framework server http routing template",
)