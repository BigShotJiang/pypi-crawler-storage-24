# dpop-broker-auth

Agent-side ES256 key enrollment and DPoP proof-of-possession (RFC 9449) for MCP broker authentication.

Endpoints are discovered automatically from the broker's discovery document — no hardcoded paths.

## Install

```bash
pip install dpop-broker-auth
```

## Usage

```python
from broker_auth import BrokerAuthClient

client = BrokerAuthClient(
    "https://your-broker.example.com",
    "<gateway-token>",
    keystore_path="broker_keypair.json",
)

# One-time enrollment (discovers endpoints, generates keypair, registers with broker)
if not client.is_enrolled:
    client.enroll()

# All requests include DPoP proof automatically
response = client.make_request(
    "POST",
    "https://your-broker.example.com/your/endpoint",
    json={...},
)
```

## How it works

1. On first run, `enroll()` discovers registration endpoints from the broker
2. Generates an ES256 keypair and registers the public key
3. Confirms ownership via challenge-response
4. Saves the keypair to disk so the agent only enrolls once
5. `make_request()` attaches a signed DPoP proof JWT to every request and handles nonce retry
