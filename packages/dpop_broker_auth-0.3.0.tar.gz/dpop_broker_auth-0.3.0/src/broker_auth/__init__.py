"""
DPoP Broker Auth — agent-side authentication package.

Provides ES256 key management, broker registration, and DPoP proof creation.
"""

from broker_auth.client import BrokerAuthClient, StepUpRequiredError

__version__ = "0.3.0"
__all__ = ["BrokerAuthClient", "StepUpRequiredError", "__version__"]
