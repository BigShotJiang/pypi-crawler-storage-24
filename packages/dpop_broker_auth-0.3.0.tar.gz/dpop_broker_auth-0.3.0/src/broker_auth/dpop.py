"""
DPoP proof JWT creation for agent-side authentication.
"""

from __future__ import annotations

import base64
import hashlib
import time
import uuid

import jwt as pyjwt


def create_dpop_proof(private_key, kid, method, url, nonce=None, access_token=None):
    """
    Create a DPoP proof JWT (ES256).

    Args:
        private_key: EC private key for signing
        kid: Key identifier from registration
        method: HTTP method (GET, POST, etc.)
        url: Request URL
        nonce: Optional server-issued nonce
        access_token: Optional access token for ath claim (RFC 9449 §4.2)

    Returns:
        Signed DPoP proof JWT string
    """
    headers = {
        "typ": "dpop+jwt",
        "alg": "ES256",
        "jwk": {"kid": kid},
    }
    payload = {
        "htm": method,
        "htu": url,
        "iat": int(time.time()),
        "jti": str(uuid.uuid4()),
    }
    if nonce:
        payload["nonce"] = nonce
    if access_token:
        payload["ath"] = base64.urlsafe_b64encode(hashlib.sha256(access_token.encode()).digest()).rstrip(b"=").decode()

    return pyjwt.encode(payload, private_key, algorithm="ES256", headers=headers)
