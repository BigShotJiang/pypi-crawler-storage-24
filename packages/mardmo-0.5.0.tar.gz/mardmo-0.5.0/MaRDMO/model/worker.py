'''Worker Module for Model Preview and Export'''

import logging
import time

from .constants import (
    data_properties_check,
    data_properties_label,
    preview_relations,
    preview_map_general,
    preview_map_quantity,
    get_relations,
)
from .utils import get_data_properties, map_entity_quantity

from ..getters import get_items, get_mathmoddb, get_properties, get_url
from ..helpers import entity_relations, map_entity, unique_items
from ..payload import GeneratePayload
from ..queries import query_sparql

from ..publication.worker import PublicationExport

class PrepareModel(PublicationExport):
    '''Class preparing Model Answers for Preview and Export'''
    def __init__(self):
        self.mathmoddb = get_mathmoddb()
        self.items = get_items()
        self.properties = get_properties()

    def preview(self, answers):
        '''Function to establish relations between Model Documentation Data'''

        # Prepare General Mappings
        for mapping in preview_map_general:
            map_entity(
                data = answers,
                idx = {
                    'from': mapping[0],
                    'to': mapping[1]
                },
                entity = {
                    'old_name': mapping[2],
                    'new_name': mapping[3],
                    'encryption': mapping[4]
                }
            )

        # Prepare Relations for Preview
        for relation in preview_relations:
            entity_relations(
                data = answers,
                idx = {
                    'from': relation['from_idx'],
                    'to': relation['to_idx']
                },
                entity = {
                    'relation': relation['relation'],
                    'old_name': relation['old_name'],
                    'new_name': relation['new_name'],
                    'encryption': relation['encryption']
                },
                order = {
                    'formulation': relation['formulation'],
                    'task': relation['task']
                },
                assumption = relation['assumption'],
                mapping = self.mathmoddb
            )

        # Quantity Type as Label
        for quantity in answers.get("quantity", {}).values():
            if quantity.get("QorQK"):
                quantity['QorQK'] = self.mathmoddb.get(url=quantity["QorQK"])['label']

        # Prepare Quantity Mapping
        for mapping in preview_map_quantity:
            map_entity_quantity(
                data = answers,
                entity_type = mapping
            )

        # Check Data Properties for Preview
        for mathmoddb_class in answers.values():
            for class_item in mathmoddb_class.values():
                properties = class_item.get('Properties')
                if not properties:
                    continue

                present = set(properties.values())
                wrong = set()

                for pair in data_properties_check:
                    opt_a, opt_b = self.mathmoddb.get(key=pair[0])["url"], self.mathmoddb.get(key=pair[1])["url"]
                    if {opt_a, opt_b}.issubset(present):
                        wrong.update([pair[0], pair[1]])
                        present.discard(opt_a)
                        present.discard(opt_b)

                correct = {key for key in data_properties_label if self.mathmoddb.get(key=key)["url"] in present}

                class_item['Properties_Check'] = [
                    {'label': data_properties_label[k], 'error': k in wrong}
                    for k in correct | wrong
                ]

        return answers

    def export(self, data, url):
        """Function to create Payload for Model Export."""

        items, dependency = unique_items(data)

        payload = GeneratePayload(
            dependency = dependency,
            user_items = items,
            url = url,
            wikibase = {
                'data_properties': get_data_properties,
                'items': get_items(),
                'properties': get_properties(),
                'relations': get_relations()
            }
        )

        # Add / Retrieve Components of Model Item
        payload.process_items()

        # Delegate to helper functions
        self._export_fields(
            payload = payload,
            fields = data.get("field", {}),
        )
        self._export_problems(
            payload = payload,
            problems = data.get("problem", {})
        )
        self._export_models(
            payload = payload,
            models = data.get("model", {})
        )
        self._export_tasks(
            payload = payload,
            tasks = data.get("task", {})
        )
        self._export_formulations(
            payload = payload,
            formulations = data.get("formulation", {})
        )
        self._export_quantities(
            payload = payload,
            quantities = data.get("quantity", {})
        )
        self._export_authors(
            payload = payload,
            publications = data.get("publication", {})
        )
        self._export_journals(
            payload = payload,
            publications = data.get("publication", {})
        )
        self._export_publications(
            payload = payload,
            publications = data.get("publication", {}),
            relations = [('P2E', 'EntityRelatant')]
        )

        # Construct Item Payloads
        payload.add_item_payload()

        # If Relations are added, check if they exist
        if any(
            key.startswith("RELATION")
            for key in payload.get_dictionary()
        ):
            query = payload.build_relation_check_query()

            check = None
            for attempt in range(2):  # try twice
                try:
                    check = query_sparql(
                        query = query,
                        sparql_endpoint = get_url('mardi', 'sparql')
                    )
                    break
                except Exception as e:
                    logging.warning("SPARQL query attempt %s failed: %s", attempt + 1, e)
                    if attempt == 0:
                        time.sleep(1)  # short wait before retry
            if not check:
                # both attempts failed → pretend no results
                check = [{}]

            payload.add_check_results(
                check = check
            )
        return payload.get_dictionary(), payload.dependency

    # ---------------------------
    # Shared helper
    # ---------------------------
    def _add_common_metadata(self, payload, qclass, profile_type):
        """Add metadata common to most entities (except publication)."""
        payload.add_answer(
            verb = self.properties["instance of"],
            object_and_type = [qclass, "wikibase-item"],
        )

        payload.add_answer(
            verb = self.properties["community"],
            object_and_type = [self.items["MathModDB"], "wikibase-item"],
        )

        payload.add_answer(
            verb = self.properties["MaRDI profile type"],
            object_and_type = [self.items[profile_type], "wikibase-item"],
        )

        payload.add_answers(
            mardmo_property = "descriptionLong",
            wikibase_property = "description",
        )

    # ---------------------------
    # Entity export helpers
    # ---------------------------
    def _export_fields(self, payload, fields: dict):
        for entry in fields.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            self._add_common_metadata(
                payload = payload,
                qclass = self.items["academic discipline"],
                profile_type = "MaRDI research field profile",
            )

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "IntraClassRelation",
                    'relatant': "IntraClassElement"
                }
            )

    def _export_problems(self, payload, problems: dict):
        for entry in problems.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            self._add_common_metadata(
                payload = payload,
                qclass = self.items["research problem"],
                profile_type = "MaRDI research problem profile",
            )

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_single_relation(
                statement = {
                    'relation': self.properties["contains"],
                    'relatant': "RFRelatant"
                },
                reverse = True
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "IntraClassRelation",
                    'relatant': "IntraClassElement"
                }
            )

    def _export_models(self, payload, models: dict):
        for entry in models.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            self._add_common_metadata(
                payload = payload,
                qclass = self.items["mathematical model"],
                profile_type = "MaRDI model profile",
            )

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_data_properties(
                item_class = "model"
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "MM2MF",
                    'relatant': "MFRelatant"
                },
                optional_qualifier = ['series ordinal']
            )

            payload.add_single_relation(
                statement = {
                    'relation': self.properties["modelled by"],
                    'relatant': "RPRelatant"
                },
                reverse = True
            )

            payload.add_single_relation(
                statement = {
                    'relation': self.properties["used by"],
                    'relatant': "TRelatant"
                }
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "IntraClassRelation",
                    'relatant': "IntraClassElement"
                },
                optional_qualifier = ['assumes']
            )

    def _export_tasks(self, payload, tasks: dict):
        for entry in tasks.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            self._add_common_metadata(
                payload = payload,
                qclass = self.items["computational task"],
                profile_type = "MaRDI task profile",
            )

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_data_properties(
                item_class = "task"
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "T2MF",
                    'relatant': "MFRelatant"
                }
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "T2Q",
                    'relatant': "QRelatant"
                }
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "IntraClassRelation",
                    'relatant': "IntraClassElement"
                },
                optional_qualifier = ['assumes', 'series ordinal']
            )

    def _export_formulations(self, payload, formulations: dict):
        for entry in formulations.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            self._add_common_metadata(
                payload = payload,
                qclass = self.items["mathematical expression"],
                profile_type = "MaRDI formula profile",
            )

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_data_properties(
                item_class = "equation"
            )

            if entry.get('reference'):
                payload.add_answer(
                    verb = self.properties["comment"],
                    object_and_type = [entry.get('reference'), "string"],
                )

            payload.add_answers(
                mardmo_property = "Formula",
                wikibase_property = "defining formula",
                datatype = "math",
            )

            payload.add_in_defining_formula()

            payload.add_multiple_relation(
                statement = {
                    'relation': "MF2MF",
                    'relatant': "MFRelatant"
                }
            )

            payload.add_multiple_relation(
                statement = {
                    'relation': "IntraClassRelation",
                    'relatant': "IntraClassElement"
                },
                optional_qualifier = ['assumes']
            )

    def _export_quantities(self, payload, quantities: dict):
        for entry in quantities.values():
            if not entry.get("ID"):
                continue

            payload.get_item_key(
                value = entry
            )

            if entry.get("QorQK") == self.mathmoddb.get(label='Quantity')['url']:
                self._add_common_metadata(
                    payload = payload,
                    qclass = self.items["quantity"],
                    profile_type = "MaRDI quantity profile",
                )
                qtype = "quantity"

            elif entry.get("QorQK") == self.mathmoddb.get(label='Quantity Kind')['url']:
                self._add_common_metadata(
                    payload = payload,
                    qclass = self.items["kind of quantity"],
                    profile_type = "MaRDI quantity profile",
                )
                qtype = "quantity kind"

            else:
                continue

            payload.add_aliases(
                aliases_dict = entry.get('Alias')
            )

            payload.add_data_properties(
                item_class = qtype
            )

            if (
                entry.get("reference")
                and qtype == "quantity kind"
            ):
                payload.add_answer(
                    verb = self.properties["QUDT quantity kind ID"],
                    object_and_type = [entry["reference"][0][1], "external-id"],
                )

            if (
                entry.get("reference")
                and qtype == "quantity"
            ):
                payload.add_answer(
                    verb = self.properties["QUDT constant ID"],
                    object_and_type = [entry["reference"][1][1], "external-id"],
                )

            payload.add_answers(
                mardmo_property = "Formula",
                wikibase_property = "defining formula",
                datatype = "math",
            )

            payload.add_in_defining_formula()

            if qtype == "quantity":
                payload.add_multiple_relation(
                    statement = {
                        'relation': "Q2Q",
                        'relatant': "QRelatant-Q"
                    }
                )

                payload.add_multiple_relation(
                    statement = {
                        'relation': "Q2QK",
                        'relatant': "QKRelatant-Q"
                    }
                )

            else:
                payload.add_multiple_relation(
                    statement = {
                        'relation': "QK2QK",
                        'relatant': "QKRelatant-QK"
                    }
                )

                payload.add_multiple_relation(
                    statement = {
                        'relation': "QK2Q",
                        'relatant': "QRelatant-QK"
                    }
                )
