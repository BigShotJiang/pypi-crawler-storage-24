[{"locale":"fr"}]
