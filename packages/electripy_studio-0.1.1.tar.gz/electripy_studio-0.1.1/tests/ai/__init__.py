"""AI component tests."""
