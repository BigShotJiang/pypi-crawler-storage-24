"""Hallucination guard tests."""
