"""Hook runner — invoked by the pre-commit hook to validate staged files.

Exit code 0 = all clear.
Exit code 1 = CRITICAL or HIGH violations found, block commit.
"""

from __future__ import annotations

import sys
from pathlib import Path

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import get_logger

_log = get_logger("hook_runner")


def main() -> int:
    files = sys.argv[1:]
    if not files:
        return 0

    # Find repo root
    cwd = Path.cwd()
    repo_root = cwd
    while repo_root != repo_root.parent:
        if (repo_root / CODEBRAIN_DIR / DB_FILENAME).exists():
            break
        repo_root = repo_root.parent
    else:
        # No index found, skip validation
        return 0

    db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME
    if not db_path.exists():
        return 0

    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator, Severity

    with GraphStore(db_path) as store:
        validator = ChangeValidator(store)

        all_violations = []
        for file_str in files:
            file_path = repo_root / file_str
            if not file_path.exists():
                report = validator.validate_deletion(file_str)
            else:
                report = validator.validate_file(file_path, repo_root)

            critical_or_high = [
                v for v in report.violations
                if v.severity in (Severity.CRITICAL, Severity.HIGH)
            ]
            if critical_or_high:
                all_violations.extend(critical_or_high)
                _log.warning("[CodeBrain] %s — risk: %.0f%%", file_str, report.risk_score * 100)
                for v in critical_or_high:
                    _log.warning("  [%8s] %s", v.severity, v.message)

    if all_violations:
        _log.warning("[CodeBrain] %d violation(s) found. Commit blocked.", len(all_violations))
        _log.warning("  Use `git commit --no-verify` to bypass (not recommended).")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
