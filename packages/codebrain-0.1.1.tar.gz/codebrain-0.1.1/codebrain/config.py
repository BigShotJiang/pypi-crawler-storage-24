"""Project-wide constants and configuration."""

from pathlib import Path

# Directory name for CodeBrain data at repo root
CODEBRAIN_DIR = ".codebrain"

# SQLite database filename inside CODEBRAIN_DIR
DB_FILENAME = "graph.db"

# Schema version for future migrations
SCHEMA_VERSION = 2

# Directories/patterns to always skip during indexing
SKIP_DIRS = frozenset({
    "__pycache__",
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    ".env",
    "node_modules",
    ".tox",
    ".nox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
    "*.egg-info",
    "coverage",
    ".coverage",
    ".nyc_output",
    ".next",
    ".nuxt",
    "_reference",
    CODEBRAIN_DIR,
})

# File extensions to index
INDEXABLE_EXTENSIONS = frozenset({".py", ".ts", ".tsx", ".js", ".jsx"})

# Watcher debounce interval in seconds
WATCHER_DEBOUNCE_SECONDS = 0.3
