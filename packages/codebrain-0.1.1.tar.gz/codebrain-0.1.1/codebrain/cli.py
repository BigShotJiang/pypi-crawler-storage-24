"""Click CLI — the ``brain`` command."""

from __future__ import annotations

import functools
import json
import sys
import threading
import time
import traceback
from pathlib import Path

import click

from codebrain import __version__
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import configure_logging, get_logger

_log = get_logger("cli")


def _db_path(repo_root: Path) -> Path:
    return repo_root / CODEBRAIN_DIR / DB_FILENAME


def _require_index(repo_root: Path) -> Path:
    """Return db_path or exit with an error if not initialized."""
    db = _db_path(repo_root)
    if not db.exists():
        click.echo(click.style("Error: CodeBrain not initialized.", fg="red"), err=True)
        click.echo("  Run: brain init", err=True)
        sys.exit(1)
    # Quick integrity check
    try:
        import sqlite3
        conn = sqlite3.connect(str(db))
        try:
            conn.execute("SELECT count(*) FROM nodes")
            # Check for incomplete index
            row = conn.execute(
                "SELECT value FROM meta WHERE key = 'index_status'"
            ).fetchone()
            if row and row[0] == "in_progress":
                total_row = conn.execute(
                    "SELECT value FROM meta WHERE key = 'index_files_total'"
                ).fetchone()
                file_count = conn.execute("SELECT count(*) FROM files").fetchone()[0]
                total = int(total_row[0]) if total_row else "?"
                click.echo(click.style(
                    f"Warning: Index is incomplete ({file_count} of {total} files).",
                    fg="yellow",
                ), err=True)
                click.echo("  Run: brain reindex", err=True)
        finally:
            conn.close()
    except Exception:
        click.echo(click.style("Warning: Database may be corrupted. Rebuilding...", fg="yellow"), err=True)
        import gc
        gc.collect()  # Release any lingering connections
        try:
            db.unlink(missing_ok=True)
            for wal in db.parent.glob(f"{db.name}-*"):
                wal.unlink(missing_ok=True)
            from codebrain.indexer import full_index
            full_index(repo_root, db)
            click.echo(click.style("Database rebuilt successfully.", fg="green"), err=True)
        except Exception as rebuild_err:
            click.echo(click.style(f"Rebuild failed: {rebuild_err}", fg="red"), err=True)
            sys.exit(1)
    return db


def _output(data: object, *, as_json: bool) -> None:
    """Print *data* as JSON or human-readable text."""
    if as_json:
        click.echo(json.dumps(data, indent=2))
    elif isinstance(data, dict):
        for key, value in data.items():
            click.echo(f"  {key}: {value}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                parts = [f"{k}={v}" for k, v in item.items()]
                click.echo("  " + "  ".join(parts))
            else:
                click.echo(f"  {item}")


def _get_timeout(ctx: click.Context) -> int:
    """Get CLI timeout from context (--timeout flag or settings default)."""
    if ctx and ctx.obj:
        explicit = ctx.obj.get("timeout")
        if explicit is not None:
            return explicit
    from codebrain.settings import load_settings
    repo = ctx.obj["repo_root"] if ctx and ctx.obj else None
    return load_settings(repo).cli_timeout


def _run_with_timeout(fn, timeout: int, label: str = "Computing"):
    """Run *fn* in a thread with a timeout. Shows spinner on stderr.

    Returns the result or exits with a timeout message.
    """
    result_box = [None]
    error_box = [None]

    def _target():
        try:
            result_box[0] = fn()
        except Exception as exc:
            error_box[0] = exc

    thread = threading.Thread(target=_target, daemon=True)
    thread.start()

    # Show spinner while waiting, tracking total elapsed time
    spinner_chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    idx = 0
    deadline = time.perf_counter() + timeout
    thread.join(timeout=0.1)
    while thread.is_alive() and time.perf_counter() < deadline:
        char = spinner_chars[idx % len(spinner_chars)]
        click.echo(f"\r  {char} {label}...", nl=False, err=True)
        idx += 1
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            break
        thread.join(timeout=min(0.2, remaining))

    if thread.is_alive():
        # Timeout — thread is still running (daemon, will be cleaned up)
        click.echo(f"\r  ", nl=False, err=True)  # Clear spinner
        click.echo(err=True)
        click.echo(click.style(
            f"Operation timed out after {timeout}s.", fg="yellow"
        ), err=True)
        click.echo(f"  Use --timeout N to increase (e.g. --timeout 300).", err=True)
        sys.exit(1)

    # Clear spinner line
    click.echo(f"\r  ", nl=False, err=True)

    if error_box[0] is not None:
        raise error_box[0]
    return result_box[0]


def _safe_command(fn):  # noqa: ANN001, ANN201
    """Decorator that catches exceptions and shows user-friendly messages."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        try:
            return fn(*args, **kwargs)
        except SystemExit:
            raise
        except PermissionError as exc:
            click.echo(click.style(f"Permission denied: {exc}", fg="red"), err=True)
            click.echo("  Another process may be using the database. Close other brain/MCP instances and retry.", err=True)
            sys.exit(1)
        except Exception as exc:
            import sqlite3
            ctx = click.get_current_context(silent=True)
            verbose = ctx.obj.get("verbose", False) if ctx and ctx.obj else False
            if isinstance(exc, sqlite3.DatabaseError):
                click.echo(click.style(f"Database error: {exc}", fg="red"), err=True)
                click.echo("  Run: brain reindex", err=True)
            elif isinstance(exc, ModuleNotFoundError) and "tree_sitter" in str(exc):
                click.echo(click.style(f"Missing dependency: {exc}", fg="red"), err=True)
                click.echo("  Install with: pip install codebrain[ts]", err=True)
            elif verbose:
                click.echo(traceback.format_exc(), err=True)
            else:
                click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
                click.echo("  (use --verbose for full traceback)", err=True)
            sys.exit(1)
    return wrapper


@click.group()
@click.version_option(version=__version__, prog_name="CodeBrain")
@click.option("--repo", default=".", help="Repository root (default: current directory).")
@click.option("--project", default=None, help="Project directory path (overrides --repo).")
@click.option("--verbose", is_flag=True, help="Enable debug logging and full tracebacks.")
@click.option("--timeout", type=int, default=None, help="Timeout in seconds for analysis commands (default: 120).")
@click.pass_context
def cli(ctx: click.Context, repo: str, project: str | None, verbose: bool, timeout: int | None) -> None:
    """CodeBrain — structural knowledge graph for your codebase."""
    ctx.ensure_object(dict)
    if timeout is not None:
        ctx.obj["timeout"] = timeout
    if project is not None:
        project_path = Path(project).resolve()
        if not project_path.is_dir():
            click.echo(click.style(f"Error: Project path does not exist: {project_path}", fg="red"), err=True)
            sys.exit(1)
        ctx.obj["repo_root"] = project_path
    else:
        ctx.obj["repo_root"] = Path(repo).resolve()
    ctx.obj["verbose"] = verbose
    configure_logging(verbose)


# ------------------------------------------------------------------ init
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def init(ctx: click.Context, as_json: bool) -> None:
    """Index the current repository and create the CodeBrain database."""
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    files = discover_files(repo_root)

    if not files:
        click.echo(click.style("No parseable files found.", fg="yellow"), err=True)
        click.echo(f"  CodeBrain supports: .py, .ts, .tsx, .js, .jsx, .env, docker-compose.yml", err=True)
        click.echo(f"  Check that you're in the right directory: {repo_root}", err=True)
        return

    if as_json:
        result = full_index(repo_root)
        click.echo(json.dumps(result, indent=2))
        return

    click.echo(f"Indexing {repo_root} ({len(files)} files) ...")

    with click.progressbar(length=len(files), label="Parsing") as bar:
        def _progress(current: int, total: int) -> None:
            bar.update(1)
        result = full_index(repo_root, progress_callback=_progress)

    click.echo(f"Done in {result['elapsed_seconds']}s")
    click.echo(f"  Files parsed: {result['files_parsed']}")
    click.echo(f"  Nodes: {result['total_nodes']}")
    click.echo(f"  Edges: {result['total_edges']}")
    if result["errors"]:
        click.echo(f"  Errors: {len(result['errors'])}")
        for err in result["errors"][:5]:
            click.echo(f"    {err}")

    # Warn if TypeScript files were indexed
    ts_exts = (".ts", ".tsx", ".js", ".jsx")
    if any(str(f).endswith(ts_exts) for f in files):
        click.echo()
        click.echo(click.style("Note:", fg="yellow") + " TypeScript parsing is experimental (regex-based). Results may be incomplete.")

    # D3: Post-init onboarding
    click.echo()
    click.echo(click.style("Quick start:", bold=True))
    click.echo("  brain status        Show index statistics")
    click.echo("  brain search <q>    Search for symbols")
    click.echo("  brain trace <fn>    Show call chain from a function")
    click.echo("  brain impact <fn>   What breaks if a function changes")
    click.echo("  brain health        Codebase health score")
    click.echo("  brain serve         Start REST API at http://localhost:8484")
    click.echo("  brain setup         Set up Claude Code integration (CLAUDE.md + MCP)")


# ------------------------------------------------------------------ setup
@cli.command()
@click.option("--force", is_flag=True, help="Overwrite existing CLAUDE.md.")
@click.pass_context
@_safe_command
def setup(ctx: click.Context, force: bool) -> None:
    """Set up Claude Code integration: index + CLAUDE.md + MCP config.

    Creates a CLAUDE.md with instructions for Claude Code to use CodeBrain
    tools, and ensures the MCP server is configured globally.
    """
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    project_name = repo_root.name

    # 1. Index if needed
    db_path = _get_db(repo_root)
    if not db_path.exists():
        files = discover_files(repo_root)
        click.echo(f"Indexing {repo_root} ({len(files)} files) ...")
        with click.progressbar(length=len(files), label="Parsing") as bar:
            result = full_index(repo_root, progress_callback=lambda c, t: bar.update(1))
        click.echo(f"  {result['files_parsed']} files, {result['total_nodes']} nodes, {result['total_edges']} edges")
    else:
        click.echo(f"Index exists at {db_path}")

    # 2. Create CLAUDE.md
    claude_md = repo_root / "CLAUDE.md"
    if claude_md.exists() and not force:
        click.echo(f"CLAUDE.md already exists (use --force to overwrite)")
    else:
        template_path = Path(__file__).parent.parent / "templates" / "CLAUDE.md.template"
        if template_path.exists():
            content = template_path.read_text().replace("{{PROJECT_NAME}}", project_name)
        else:
            content = _generate_claude_md(project_name)
        claude_md.write_text(content)
        click.echo(f"Created {claude_md}")

    # 3. Configure MCP globally
    settings_path = Path.home() / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    if settings_path.exists():
        settings = json.loads(settings_path.read_text())
    else:
        settings = {}
    if "mcpServers" not in settings:
        settings["mcpServers"] = {}
    if "codebrain" not in settings["mcpServers"]:
        # Find the codebrain package location
        import codebrain
        cb_root = str(Path(codebrain.__file__).parent.parent)
        settings["mcpServers"]["codebrain"] = {
            "command": "python",
            "args": ["-m", "codebrain.mcp_server"],
            "cwd": cb_root,
        }
        settings_path.write_text(json.dumps(settings, indent=2))
        click.echo(f"Added CodeBrain MCP server to {settings_path}")
    else:
        click.echo("MCP server already configured")

    click.echo()
    click.echo(click.style("Done! Restart Claude Code to activate.", bold=True))
    click.echo("Claude Code will now use CodeBrain tools to understand your codebase.")


def _generate_claude_md(project_name: str) -> str:
    """Generate a CLAUDE.md without the template file."""
    return f"""# {project_name} — Claude Code Instructions

## CodeBrain Integration

This project is indexed by CodeBrain. You have MCP tools that give you structural understanding of the entire codebase. **USE THEM.**

### Workflow

1. **Starting a task** -> `codebase_overview()` and `query_modules("", 3)`
2. **Before modifying code** -> `impact_analysis("function_name")` and `query_dependencies("module/path")`
3. **After modifying code** -> `validate_change("file/path.py")` on every changed file
4. **Need to understand code** -> `get_symbol_context("name")` or `explain_code("file/path")`
5. **Have a question** -> `ask_codebase("how does X work?")`

### Key Rule
**Never modify a function with >5 dependents without running `impact_analysis` first.**
"""


# ------------------------------------------------------------------ status
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def status(ctx: click.Context, as_json: bool) -> None:
    """Show index statistics."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files

    repo_root: Path = ctx.obj["repo_root"]
    db = _require_index(repo_root)
    with GraphStore(db) as store:
        stats = store.get_stats()

    # M20: Index completeness — compare indexed files vs actual files on disk
    actual_files = len(discover_files(repo_root))
    indexed_files = stats.get("files", 0)
    stats["index_completeness"] = {
        "indexed": indexed_files,
        "total": actual_files,
        "complete": indexed_files >= actual_files * 0.95,
    }

    _output(stats, as_json=as_json)


# ------------------------------------------------------------------ trace
@cli.command()
@click.argument("name")
@click.option("--depth", default=10, help="Max traversal depth.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def trace(ctx: click.Context, name: str, depth: int, as_json: bool) -> None:
    """Show the forward call chain from a function."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No node found matching '{name}'.", err=True)
            sys.exit(1)

        results: list[dict] = []
        for node in nodes:
            chain = engine.get_call_chain(node["id"], max_depth=depth)
            results.append({"root": node["id"], "chain": chain})

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            click.echo(f"Call chain from {r['root']}:")
            if not r["chain"]:
                click.echo("  (no outgoing calls)")
            for entry in r["chain"]:
                indent = "  " * entry["depth"]
                click.echo(f"  {indent}{entry['node_id']}  (via {entry['from']})")


# ------------------------------------------------------------------ impact
@cli.command()
@click.argument("name")
@click.option("--depth", default=10, help="Max traversal depth.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def impact(ctx: click.Context, name: str, depth: int, as_json: bool) -> None:
    """Show what could break if a function/class changes."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(click.style(f"No symbol matching '{name}' found.", fg="red"), err=True)
            click.echo(f"  Try: brain search {name}", err=True)
            sys.exit(1)

        def _compute():
            engine.preload_reverse_index()
            results = []
            for node in nodes:
                impacted = engine.impact_of_change(node["id"], max_depth=depth)
                results.append({"target": node["id"], "impacted": impacted})
            return results

        results = _run_with_timeout(_compute, timeout, f"Analyzing impact of '{name}'")

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            click.echo(f"Impact of changing {r['target']}:")
            if not r["impacted"]:
                click.echo("  (no dependents found)")
            for entry in r["impacted"]:
                click.echo(f"  [{entry['depth']}] {entry['node_id']}  ({entry['edge_type']} via {entry['via']})")


# ------------------------------------------------------------------ deps
@cli.command()
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def deps(ctx: click.Context, name: str, as_json: bool) -> None:
    """Show dependencies of a symbol (what it calls/imports)."""
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        # Try resolving as a file first
        file_nodes = store.get_nodes_by_file(name)
        if file_nodes:
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            file_deps = engine.get_file_dependencies(name)
            if as_json:
                click.echo(json.dumps({"file": name, "imports": file_deps}, indent=2))
            else:
                click.echo(f"Dependencies of {name}:")
                for dep in file_deps:
                    click.echo(f"  {dep}")
            return

        # Resolve as a symbol
        from codebrain.graph.query import QueryEngine
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No node found matching '{name}'.", err=True)
            sys.exit(1)

        results: list[dict] = []
        for node in nodes:
            edges = store.get_edges_from(node["id"])
            results.append({
                "node": node["id"],
                "dependencies": [
                    {"target": e["target"], "type": e["type"], "line": e["line"]}
                    for e in edges
                ],
            })

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            click.echo(f"Dependencies of {r['node']}:")
            for dep in r["dependencies"]:
                click.echo(f"  {dep['type']} → {dep['target']}  (line {dep['line']})")


# ------------------------------------------------------------------ deadcode
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def deadcode(ctx: click.Context, as_json: bool) -> None:
    """List potentially unused functions and classes."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        dead = _run_with_timeout(
            engine.find_dead_code, timeout, "Scanning for dead code"
        )

    if as_json:
        click.echo(json.dumps(dead, indent=2))
    else:
        if not dead:
            click.echo("No dead code detected.")
        else:
            click.echo(click.style(f"Potentially unused symbols ({len(dead)}):", bold=True))
            for item in dead:
                click.echo(f"  {item['type']:10s} {item['name']:30s} {item['file_path']}:{item['line_start']}")


# ------------------------------------------------------------------ cycles
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def cycles(ctx: click.Context, as_json: bool) -> None:
    """Detect import cycles."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        found_cycles = _run_with_timeout(
            engine.detect_cycles, timeout, "Detecting cycles"
        )

    if as_json:
        click.echo(json.dumps(found_cycles, indent=2))
    else:
        if not found_cycles:
            click.echo("No import cycles detected.")
        else:
            click.echo(click.style(f"Import cycles ({len(found_cycles)}):", bold=True))
            for cycle in found_cycles:
                click.echo(f"  {' → '.join(cycle)}")


# ------------------------------------------------------------------ search
@cli.command()
@click.argument("query")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def search(ctx: click.Context, query: str, as_json: bool) -> None:
    """Search for nodes by name."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        results = engine.search_nodes(query)

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        if not results:
            click.echo(f"No results for '{query}'.")
        else:
            click.echo(f"Results for '{query}' ({len(results)}):")
            for node in results:
                sig = f"  {node['signature']}" if node["signature"] else ""
                click.echo(f"  {node['type']:10s} {node['qualified_name']}{sig}  ({node['file_path']}:{node['line_start']})")


# ------------------------------------------------------------------ validate
@cli.command()
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def validate(ctx: click.Context, file: str, as_json: bool) -> None:
    """Validate a changed file against the graph — detect what breaks."""
    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        validator = ChangeValidator(store)

        target = Path(file)
        if not target.is_absolute():
            target = repo_root / target

        if not target.exists():
            rel = target.relative_to(repo_root).as_posix()
            report = validator.validate_deletion(rel)
        else:
            report = validator.validate_file(target, repo_root)

    if as_json:
        click.echo(json.dumps(report.to_dict(), indent=2))
    else:
        risk_bar = "#" * int(report.risk_score * 20)
        risk_color = "red" if report.risk_score > 0.7 else ("yellow" if report.risk_score > 0.3 else "green")
        valid_str = click.style("YES", fg="green") if report.is_valid else click.style("NO", fg="red")
        click.echo(click.style(f"Validation: {report.file_path}", bold=True))
        click.echo(f"  Valid:      {valid_str}")
        click.echo(f"  Risk:       [{click.style(risk_bar, fg=risk_color):<20s}] {report.risk_score:.1%}")
        click.echo(f"  Summary:    {report.summary}")
        if report.violations:
            click.echo(f"  Violations ({len(report.violations)}):")
            for v in report.violations:
                sev_color = {"critical": "red", "high": "yellow", "medium": "cyan"}.get(v.severity, None)
                sev_str = click.style(f"[{v.severity:8s}]", fg=sev_color) if sev_color else f"[{v.severity:8s}]"
                click.echo(f"    {sev_str} {v.message}")
        if report.affected_files:
            click.echo(f"  Affected files ({len(report.affected_files)}):")
            for f in report.affected_files:
                click.echo(f"    {f}")


# ------------------------------------------------------------------ overview
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def overview(ctx: click.Context, as_json: bool) -> None:
    """System-level overview of the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            comp.system_overview, timeout, "Building overview"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        stats = result["stats"]
        click.echo(f"Codebase: {stats['files']} files, {stats['nodes']} symbols, {stats['edges']} edges")
        click.echo()
        click.echo("Packages:")
        for name, info in result["packages"].items():
            doc = f" — {info['docstring']}" if info["docstring"] else ""
            deps = f"  depends on: {', '.join(info['depends_on'])}" if info["depends_on"] else ""
            click.echo(f"  {name}: {info['file_count']} files, {info['node_count']} symbols{doc}")
            if deps:
                click.echo(f"    {deps}")
        if result["entry_points"]:
            click.echo()
            click.echo("Entry points:")
            for ep in result["entry_points"]:
                click.echo(f"  {ep['file_path']}:{ep['line']}")


# ------------------------------------------------------------------ anatomy
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def anatomy(ctx: click.Context, as_json: bool) -> None:
    """Codebase anatomy — subsystem map for new developers."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = comp.codebase_anatomy()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(click.style(result["purpose"], bold=True))
        click.echo()
        click.echo("Subsystems:")
        for sub in sorted(result["subsystems"], key=lambda s: -s["importance"]):
            imp = sub["importance"]
            if imp >= 0.75:
                stars = "***"
            elif imp >= 0.50:
                stars = "** "
            elif imp >= 0.25:
                stars = "*  "
            else:
                stars = "   "
            click.echo(
                f"  {stars} {sub['name']:<20} "
                f"{sub['file_count']} files, {sub['symbol_count']} symbols"
            )
            click.echo(f"        {sub['description']}")
            if sub["depends_on"]:
                click.echo(f"        depends on: {', '.join(sub['depends_on'])}")
        if result["connections"]:
            click.echo()
            click.echo("Connections:")
            for conn in result["connections"][:10]:
                click.echo(f"  {conn['from']} → {conn['to']}  ({conn['label']})")


# ------------------------------------------------------------------ module
@cli.command()
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def module(ctx: click.Context, file: str, as_json: bool) -> None:
    """Module-level view of a file."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = comp.module_view(file)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if "error" in result:
            click.echo(result["error"], err=True)
            sys.exit(1)
        click.echo(f"Module: {result['file_path']}  ({result['role']})")
        if result["docstring"]:
            click.echo(f"  {result['docstring']}")
        click.echo(f"  Lines: {result['line_count']}  Coupling: in={result['coupling']['incoming']} out={result['coupling']['outgoing']}")
        click.echo()
        if result["symbols"]:
            click.echo("  Symbols:")
            for s in result["symbols"]:
                exp = "*" if s["is_exported"] else " "
                sig = f"  {s['signature']}" if s["signature"] else ""
                click.echo(f"    {exp} {s['type']:10s} {s['name']}{sig}")
        if result["imports"]:
            click.echo(f"  Imports: {', '.join(result['imports'])}")
        if result["imported_by"]:
            click.echo(f"  Imported by: {', '.join(result['imported_by'])}")


# ------------------------------------------------------------------ context
@cli.command()
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def context(ctx: click.Context, name: str, as_json: bool) -> None:
    """Generate structured LLM context for a symbol."""
    from codebrain.context import ContextGenerator
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        gen = ContextGenerator(store)
        results = gen.for_symbol(name)

    if not results:
        click.echo(f"No node found matching '{name}'.", err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for ctx_data in results:
            click.echo(f"{ctx_data['symbol_type']} {ctx_data['qualified_name']}  {ctx_data['signature']}")
            click.echo(f"  File: {ctx_data['file_path']}:{ctx_data['line_start']}-{ctx_data['line_end']}")
            if ctx_data["docstring"]:
                click.echo(f"  Doc: {ctx_data['docstring']}")
            if ctx_data["parent"]:
                click.echo(f"  Parent: {ctx_data['parent']['name']} ({ctx_data['parent']['type']})")
            if ctx_data["calls"]:
                click.echo(f"  Calls: {', '.join(c['target'] for c in ctx_data['calls'])}")
            if ctx_data["called_by"]:
                click.echo(f"  Called by: {', '.join(c['source'] for c in ctx_data['called_by'])}")
            if ctx_data.get("methods"):
                click.echo(f"  Methods: {', '.join(m['name'] for m in ctx_data['methods'])}")
            if ctx_data.get("bases"):
                click.echo(f"  Extends: {', '.join(ctx_data['bases'])}")
            click.echo()


# ------------------------------------------------------------------ hotspots
@cli.command()
@click.option("--top", default=20, help="Number of hotspots to show.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def hotspots(ctx: click.Context, top: int, as_json: bool) -> None:
    """Show the riskiest symbols in the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        results = _run_with_timeout(
            lambda: comp.risk_hotspots(top_n=top), timeout, "Finding hotspots"
        )

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        if not results:
            click.echo("No risk hotspots found.")
        else:
            click.echo(click.style(f"Risk hotspots (top {len(results)}):", bold=True))
            click.echo(f"  {'Score':>6s}  {'Type':10s} {'Name':30s} {'Deps':>5s} {'Files':>5s} Location")
            for h in results:
                score = h["risk_score"]
                score_color = "red" if score > 20 else ("yellow" if score > 5 else "green")
                click.echo(
                    f"  {click.style(f'{score:6.1f}', fg=score_color)}  {h['type']:10s} {h['name']:30s} "
                    f"{h['direct_dependents']:5d} {h['affected_files']:5d} "
                    f"{h['file_path']}:{h['line_start']}"
                )


# ------------------------------------------------------------------ health
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def health(ctx: click.Context, as_json: bool) -> None:
    """Show codebase health score (0-100)."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            comp.health_score, timeout, "Computing health score"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        score = result["score"]
        grade = result["grade"]
        details = result["details"]

        if score >= 80:
            color = "green"
        elif score >= 60:
            color = "yellow"
        else:
            color = "red"

        bar_len = score // 5
        bar = "#" * bar_len + "-" * (20 - bar_len)

        click.echo(click.style("Codebase Health", bold=True))
        click.echo(f"  Score: [{click.style(bar, fg=color)}] {click.style(str(score), fg=color, bold=True)}/100  (Grade: {click.style(grade, fg=color, bold=True)})")
        click.echo()
        dims = result.get("dimensions", {})
        click.echo(click.style("Dimensions:", bold=True))
        dc = dims.get("dead_code", {})
        cy = dims.get("import_cycles", {})
        cp = dims.get("coupling", {})
        click.echo(f"  Dead code:     {dc.get('count', details.get('dead_code_count', 0))} symbols ({dc.get('ratio', details.get('dead_code_ratio', 0)):.1%})  score {dc.get('score', '?')}/100")
        click.echo(f"  Import cycles: {cy.get('count', details.get('import_cycles', 0))}  score {cy.get('score', '?')}/100")
        click.echo(f"  Coupling:      {cp.get('high_risk_hotspots', details.get('high_risk_hotspots', 0))} hotspot(s)  score {cp.get('score', '?')}/100")


# ------------------------------------------------------------------ coupling
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def coupling(ctx: click.Context, as_json: bool) -> None:
    """Analyze module coupling across the codebase."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.coupling_analysis, timeout, "Analyzing coupling"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result["pairs"]:
            click.echo(click.style("Most coupled file pairs:", bold=True))
            for pair in result["pairs"][:15]:
                click.echo(f"  {pair['coupling_score']:3d}  {pair['file_a']}  <->  {pair['file_b']}")
        click.echo()
        if result["file_ranking"]:
            click.echo(click.style("Most coupled files (aggregate):", bold=True))
            for f in result["file_ranking"][:15]:
                click.echo(f"  {f['total_coupling']:3d}  {f['file']}")


# ------------------------------------------------------------------ contracts
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def contracts(ctx: click.Context, as_json: bool) -> None:
    """Detect implicit contracts in the codebase."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.detect_contracts, timeout, "Detecting contracts"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if not result:
            click.echo("No implicit contracts detected.")
        else:
            click.echo(f"Implicit contracts ({len(result)}):")
            for c in result:
                conf = f"{c['confidence']:.0%}"
                click.echo(f"  [{c['type']:16s}] ({conf}) {c['message']}")


# ------------------------------------------------------------------ layers
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def layers(ctx: click.Context, as_json: bool) -> None:
    """Show architectural layers inferred from dependencies."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.detect_layers, timeout, "Computing layers"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        for layer in result["layers"]:
            click.echo(f"{layer['label']}  ({layer['description']})")
            for f in layer["files"]:
                click.echo(f"    {f}")
            click.echo()


# ------------------------------------------------------------------ watch
@cli.command()
@click.pass_context
@_safe_command
def watch(ctx: click.Context) -> None:
    """Start file watcher daemon for incremental updates."""
    from codebrain.watcher.file_watcher import start_watching

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    click.echo(f"Watching {repo_root} for changes... (Ctrl+C to stop)")
    start_watching(repo_root, _db_path(repo_root))


# ------------------------------------------------------------------ zoom
@cli.command()
@click.argument("target", required=False, default=None)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def zoom(ctx: click.Context, target: str | None, as_json: bool) -> None:
    """Multi-resolution zoom — navigate system, module, or symbol level.

    No target: system overview. File path: module view. Symbol name: symbol context.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)
    _require_index(repo_root)

    timeout = _get_timeout(ctx)

    with GraphStore(db) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            lambda: comp.zoom(target), timeout, "Zooming"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2, default=str))
    else:
        level = result.get("level", "unknown")
        if level == "system":
            narr = result.get("narrative", {})
            click.echo(f"System: {narr.get('summary', '')}")
            click.echo(f"Health: {narr.get('health', '')}")
            click.echo()
            if result.get("drill_down"):
                click.echo("Top modules (drill down):")
                for d in result["drill_down"][:8]:
                    click.echo(f"  {d['target']:<50} ({d['symbols']} symbols)")
        elif level == "module":
            narr = result.get("narrative", {})
            click.echo(f"Module: {result.get('file', '')}")
            click.echo(f"  {narr.get('summary', '')}")
            click.echo(f"  {narr.get('importance', '')}")
            click.echo()
            if result.get("symbols"):
                click.echo("Symbols:")
                for s in result["symbols"][:15]:
                    click.echo(f"  {s['type']:<10} {s['name']:<30} line {s['line']}")
        elif level == "symbol":
            narr = result.get("narrative", {})
            click.echo(f"Symbol: {result.get('name', '')} ({result.get('type', '')})")
            click.echo(f"  File: {result.get('file', '')}:{result.get('line', '')}")
            click.echo(f"  {narr.get('summary', '')}")
            if result.get("callers"):
                click.echo(f"\n  Callers ({len(result['callers'])}):")
                for c in result["callers"][:5]:
                    click.echo(f"    {c['name']}")
        elif "error" in result:
            click.echo(click.style(result["error"], fg="red"), err=True)


# ------------------------------------------------------------------ ci
@cli.command()
@click.option("--base", default="main", help="Base branch to diff against.")
@click.option("--fail-on", type=click.Choice(["unsafe", "caution"]), default="unsafe",
              help="Exit non-zero on this verdict level or worse.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def ci(ctx: click.Context, base: str, fail_on: str, as_json: bool) -> None:
    """Run structural validation on changed files (for CI pipelines).

    Compares HEAD against base branch and validates all changed files.
    Exits non-zero if structural breakage is detected.
    """
    import subprocess
    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    # Auto-init if needed
    if not db.exists():
        from codebrain.indexer import full_index
        if not as_json:
            click.echo("Index not found, running brain init...")
        full_index(repo_root, db)

    # Get changed files — try three-dot diff first (PR changes only),
    # then two-dot diff, then direct comparison
    import os
    git_env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    diff_output = ""
    for diff_spec in [f"{base}...HEAD", f"{base}..HEAD", base]:
        try:
            diff_output = subprocess.check_output(
                ["git", "diff", "--name-only", diff_spec],
                cwd=str(repo_root), text=True, stderr=subprocess.DEVNULL,
                env=git_env,
            ).strip()
            if diff_output:
                break
        except subprocess.CalledProcessError:
            continue

    if not diff_output:
        if as_json:
            click.echo(json.dumps({"verdict": "SAFE", "changed_files": 0, "message": "No changes"}))
        else:
            click.echo("No changes detected. Verdict: SAFE")
        return

    # Filter to supported extensions
    from codebrain.config import INDEXABLE_EXTENSIONS
    changed = [f for f in diff_output.splitlines()
               if Path(f).suffix in INDEXABLE_EXTENSIONS]

    if not changed:
        if as_json:
            click.echo(json.dumps({"verdict": "SAFE", "changed_files": 0, "message": "No structural changes"}))
        else:
            click.echo("No structural changes. Verdict: SAFE")
        return

    # Validate each file
    results = []
    with GraphStore(db) as store:
        validator = ChangeValidator(store)
        for rel_path in changed:
            abs_path = repo_root / rel_path
            if abs_path.exists():
                report = validator.validate_file(abs_path, repo_root)
            else:
                report = validator.validate_deletion(rel_path)
            results.append({"file": rel_path, "report": report})

    # Determine overall verdict
    has_critical = any(
        any(v.severity == "critical" for v in r["report"].violations)
        for r in results
    )
    has_high = any(
        any(v.severity == "high" for v in r["report"].violations)
        for r in results
    )
    has_medium = any(
        any(v.severity == "medium" for v in r["report"].violations)
        for r in results
    )

    if has_critical or has_high:
        verdict = "UNSAFE"
    elif has_medium:
        verdict = "CAUTION"
    else:
        verdict = "SAFE"

    # Determine exit code
    if fail_on == "unsafe" and verdict == "UNSAFE":
        exit_code = 1
    elif fail_on == "caution" and verdict in ("UNSAFE", "CAUTION"):
        exit_code = 1
    else:
        exit_code = 0

    if as_json:
        output = {
            "verdict": verdict,
            "changed_files": len(changed),
            "exit_code": exit_code,
            "files": [
                {"file": r["file"], **r["report"].to_dict()}
                for r in results
            ],
        }
        click.echo(json.dumps(output, indent=2))
    else:
        click.echo("CodeBrain Structural Validation")
        click.echo("=" * 32)
        click.echo(f"Changed files: {len(changed)}")
        for r in results:
            file_verdict = "UNSAFE" if not r["report"].is_valid else (
                "CAUTION" if any(v.severity == "medium" for v in r["report"].violations) else "SAFE"
            )
            violations_count = len(r["report"].violations)
            if violations_count:
                label = "warning" if file_verdict == "CAUTION" else "violation"
                label = label + "s" if violations_count > 1 else label
                suffix = f"  ({violations_count} {label})"
            else:
                suffix = ""
            color = {"SAFE": "green", "CAUTION": "yellow", "UNSAFE": "red"}[file_verdict]
            click.echo(f"  {r['file']:<50} {click.style(file_verdict, fg=color)}{suffix}")

        # Print violations
        all_violations = []
        for r in results:
            for v in r["report"].violations:
                if v.severity in ("critical", "high"):
                    all_violations.append(v)
        if all_violations:
            click.echo()
            click.echo("Violations:")
            for v in all_violations:
                click.echo(f"  [{v.severity.upper()}] {v.file_path}:{v.line} — {v.message}")

        click.echo()
        color = {"SAFE": "green", "CAUTION": "yellow", "UNSAFE": "red"}[verdict]
        click.echo(f"Verdict: {click.style(verdict, fg=color, bold=True)}")
        if exit_code:
            click.echo(f"Exit code: {exit_code}")

    sys.exit(exit_code)


# ------------------------------------------------------------------ reindex
@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def reindex(ctx: click.Context, yes: bool, as_json: bool) -> None:
    """Force a full rebuild of the index."""
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    if not yes and not as_json:
        if not click.confirm("This will delete and rebuild the entire index. Continue?"):
            click.echo("Aborted.")
            return

    if db.exists():
        db.unlink()

    files = discover_files(repo_root)

    if as_json:
        result = full_index(repo_root, db)
        click.echo(json.dumps(result, indent=2))
        return

    click.echo(f"Reindexing {repo_root} ({len(files)} files) ...")

    with click.progressbar(length=len(files), label="Parsing") as bar:
        def _progress(current: int, total: int) -> None:
            bar.update(1)
        result = full_index(repo_root, db, progress_callback=_progress)

    click.echo(f"Done in {result['elapsed_seconds']}s")
    click.echo(f"  Files parsed: {result['files_parsed']}")
    click.echo(f"  Nodes: {result['total_nodes']}")
    click.echo(f"  Edges: {result['total_edges']}")
    if result["errors"]:
        click.echo(f"  Errors ({len(result['errors'])})")


# ------------------------------------------------------------------ doctor
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def doctor(ctx: click.Context, as_json: bool) -> None:
    """Run diagnostic checks on the CodeBrain index."""
    from codebrain.graph.schema import get_schema_version
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files
    from codebrain.utils import file_hash, normalize_path
    from codebrain.config import SCHEMA_VERSION

    repo_root: Path = ctx.obj["repo_root"]
    checks: list[dict] = []

    # Check 1: DB exists and is readable
    db = _db_path(repo_root)
    if not db.exists():
        checks.append({"check": "database", "status": "FAIL", "message": "Database not found. Run `brain init`."})
        if as_json:
            click.echo(json.dumps({"checks": checks}, indent=2))
        else:
            for c in checks:
                _print_check(c)
        return

    checks.append({"check": "database", "status": "OK", "message": f"Database found at {db}"})

    with GraphStore(db) as store:
        # Check 2: Schema version
        version = get_schema_version(store.conn)
        if version == SCHEMA_VERSION:
            checks.append({"check": "schema_version", "status": "OK", "message": f"Schema version {version} (current)"})
        else:
            checks.append({"check": "schema_version", "status": "WARN", "message": f"Schema version {version}, expected {SCHEMA_VERSION}"})

        # Check 3: Stats
        stats = store.get_stats()
        checks.append({"check": "stats", "status": "OK", "message": f"{stats['files']} files, {stats['nodes']} nodes, {stats['edges']} edges"})

        # Check 4: Sample hash check (stale detection)
        disk_files = discover_files(repo_root)
        sample = disk_files[:5]
        stale = 0
        for fp in sample:
            rel = normalize_path(fp, repo_root)
            stored = store.get_file_hash(rel)
            if stored is None:
                stale += 1
            elif stored != file_hash(fp):
                stale += 1

        if stale == 0:
            checks.append({"check": "freshness", "status": "OK", "message": f"Sample of {len(sample)} files matches stored hashes"})
        else:
            checks.append({"check": "freshness", "status": "WARN", "message": f"{stale}/{len(sample)} sampled files are stale — consider `brain reindex`"})

        # Check 5: Edge resolution rate
        all_edges_count = stats["edges"]
        if all_edges_count > 0:
            resolved = store.conn.execute(
                "SELECT COUNT(*) FROM edges WHERE target IN (SELECT id FROM nodes)"
            ).fetchone()[0]
            rate = resolved / all_edges_count if all_edges_count else 0
            status = "OK" if rate > 0.5 else "WARN"
            checks.append({"check": "edge_resolution", "status": status, "message": f"{resolved}/{all_edges_count} edges resolve to known nodes ({rate:.0%})"})

        # Check 6: Orphaned nodes (nodes with no edges)
        orphaned = store.conn.execute(
            "SELECT COUNT(*) FROM nodes WHERE type != 'file' AND id NOT IN (SELECT source FROM edges) AND id NOT IN (SELECT target FROM edges)"
        ).fetchone()[0]
        total_non_file = store.conn.execute("SELECT COUNT(*) FROM nodes WHERE type != 'file'").fetchone()[0]
        if total_non_file > 0:
            orphan_rate = orphaned / total_non_file
            status = "OK" if orphan_rate < 0.3 else "WARN"
            checks.append({"check": "orphaned_nodes", "status": status, "message": f"{orphaned}/{total_non_file} symbols have no edges ({orphan_rate:.0%})"})

    if as_json:
        click.echo(json.dumps({"checks": checks}, indent=2))
    else:
        for c in checks:
            _print_check(c)

        ok = sum(1 for c in checks if c["status"] == "OK")
        total = len(checks)
        click.echo(f"\n{ok}/{total} checks passed.")


def _print_check(check: dict) -> None:
    status = check["status"]
    if status == "OK":
        label = click.style("[OK]  ", fg="green")
    elif status == "WARN":
        label = click.style("[WARN]", fg="yellow")
    else:
        label = click.style("[FAIL]", fg="red")
    click.echo(f"  {label} {check['check']}: {check['message']}")


# ------------------------------------------------------------------ repair
@cli.command()
@click.pass_context
@_safe_command
def repair(ctx: click.Context) -> None:
    """Check database integrity and rebuild if corrupted."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import full_index

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    if not db.exists():
        click.echo("No database found. Run 'brain init' first.")
        return

    needs_rebuild = False
    try:
        import sqlite3 as _sqlite3
        conn = _sqlite3.connect(str(db))
        try:
            result = conn.execute("PRAGMA integrity_check").fetchone()
            if result[0] != "ok":
                needs_rebuild = True
        except _sqlite3.DatabaseError:
            needs_rebuild = True
        finally:
            conn.close()
    except Exception:
        needs_rebuild = True

    if not needs_rebuild:
        click.echo("Database integrity: OK")
        return

    click.echo("Database corrupted. Rebuilding...")
    import gc, time as _time
    gc.collect()
    for _attempt in range(5):
        try:
            db.unlink(missing_ok=True)
            break
        except PermissionError:
            _time.sleep(0.2)
    # Also clean up WAL/SHM files
    for suffix in ("-wal", "-shm"):
        wal = db.parent / (db.name + suffix)
        wal.unlink(missing_ok=True)
    full_index(repo_root, db)
    click.echo("Rebuilt successfully.")


# ------------------------------------------------------------------ mcp
@cli.command(name="mcp")
@click.pass_context
@_safe_command
def mcp_cmd(ctx: click.Context) -> None:
    """Start the MCP server (for LLM agent integration)."""
    from codebrain.mcp_server import run_server

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    import os
    os.chdir(repo_root)
    run_server()


# ------------------------------------------------------------------ hook
@cli.group()
def hook() -> None:
    """Manage git pre-commit hooks."""
    pass


@hook.command()
@click.pass_context
def install(ctx: click.Context) -> None:
    """Install the CodeBrain pre-commit validation hook."""
    from codebrain.hooks import install_hook

    repo_root: Path = ctx.obj["repo_root"]
    result = install_hook(repo_root)
    click.echo(result)


@hook.command()
@click.pass_context
def uninstall(ctx: click.Context) -> None:
    """Remove the CodeBrain pre-commit hook."""
    from codebrain.hooks import uninstall_hook

    repo_root: Path = ctx.obj["repo_root"]
    result = uninstall_hook(repo_root)
    click.echo(result)


# ------------------------------------------------------------------ agent
@cli.command()
@click.pass_context
@_safe_command
def agent(ctx: click.Context) -> None:
    """Generate agent integration files (CLAUDE.md, context.json, MCP config)."""
    from codebrain.agent_bridge import write_agent_files

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    written = write_agent_files(repo_root)
    click.echo(f"Generated {len(written)} agent integration files:")
    for f in written:
        click.echo(f"  {f}")


# ------------------------------------------------------------------ resolve
@cli.command()
@click.argument("target")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def resolve(ctx: click.Context, target: str, as_json: bool) -> None:
    """Resolve an import string to graph node IDs."""
    from codebrain.graph.store import GraphStore
    from codebrain.resolver import ModuleResolver

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        resolver = ModuleResolver(store)
        results = resolver.resolve(target)

    if as_json:
        click.echo(json.dumps({"target": target, "resolved": results}, indent=2))
    else:
        if not results:
            click.echo(f"Could not resolve '{target}'.")
        else:
            click.echo(f"Resolved '{target}':")
            for r in results:
                click.echo(f"  {r}")


# ------------------------------------------------------------------ diff
@cli.command(name="diff")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def diff_cmd(ctx: click.Context, as_json: bool) -> None:
    """Show files changed since last index (added/modified/deleted)."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files
    from codebrain.utils import file_hash, normalize_path

    repo_root: Path = ctx.obj["repo_root"]
    disk_files = discover_files(repo_root)
    disk_map: dict[str, str] = {}
    for fp in disk_files:
        rel = normalize_path(fp, repo_root)
        disk_map[rel] = file_hash(fp)

    with GraphStore(_require_index(repo_root)) as store:
        rows = store.conn.execute("SELECT path, content_hash FROM files").fetchall()
        all_stored = {row["path"]: row["content_hash"] for row in rows}

    added = [f for f in disk_map if f not in all_stored]
    deleted = [f for f in all_stored if f not in disk_map]
    modified = [
        f for f in disk_map
        if f in all_stored and disk_map[f] != all_stored[f]
    ]

    result = {"added": sorted(added), "modified": sorted(modified), "deleted": sorted(deleted)}

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        total = len(added) + len(modified) + len(deleted)
        if total == 0:
            click.echo("Index is up to date.")
        else:
            click.echo(f"Changes since last index ({total} files):")
            for f in sorted(added):
                click.echo(f"  + {f}")
            for f in sorted(modified):
                click.echo(f"  ~ {f}")
            for f in sorted(deleted):
                click.echo(f"  - {f}")


# ------------------------------------------------------------------ ask
@cli.command()
@click.argument("question")
@click.option("--no-llm", is_flag=True, help="Skip LLM, use only structural data.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def ask(ctx: click.Context, question: str, no_llm: bool, as_json: bool) -> None:
    """Ask a natural language question about the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    with GraphStore(db) as store:
        comp = ComprehensionEngine(store)
        result = comp.answer_question(question)

    # Try LLM enhancement
    if not no_llm:
        try:
            from codebrain.llm import LLMNarrator, load_llm_settings

            settings = load_llm_settings(repo_root)
            if settings.enabled and settings.api_keys:
                with GraphStore(db) as store:
                    narrator = LLMNarrator(
                        store, settings,
                        cache_dir=repo_root / CODEBRAIN_DIR,
                    )
                    result = narrator.ask(question)
        except ImportError:
            pass

    if as_json:
        click.echo(json.dumps(result, indent=2, default=str))
        return

    click.echo(click.style(f"\nQuestion: {question}\n", fg="cyan"))

    # Show LLM answer if available
    if result.get("llm_answer"):
        click.echo(click.style("[AI Answer]", fg="green", bold=True))
        click.echo(result["llm_answer"])
        click.echo()

    # Show structural answer
    click.echo(click.style("[Structural Answer]", fg="yellow", bold=True))
    click.echo(result["answer"])
    click.echo()

    # Suggestions
    if result.get("suggestions"):
        click.echo(click.style("Suggested follow-ups:", fg="blue"))
        for s in result["suggestions"]:
            click.echo(f"  - {s}")
    click.echo()




# ------------------------------------------------------------------ serve
@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to.")
@click.option("--port", default=8484, help="Port to listen on.")
@click.option(
    "--projects", "project_dirs", multiple=True,
    type=click.Path(exists=True, file_okay=False),
    help="Additional project directories to serve (repeatable).",
)
@click.option("--watch", is_flag=True, help="Also start file watcher for incremental validation.")
@click.option("--discover", is_flag=True, help="Auto-discover sibling projects with .codebrain databases.")
@click.pass_context
@_safe_command
def serve(ctx: click.Context, host: str, port: int, project_dirs: tuple[str, ...], watch: bool, discover: bool) -> None:
    """Start the REST API server (requires fastapi + uvicorn)."""
    try:
        import uvicorn
    except ImportError:
        click.echo("Error: 'uvicorn' not installed. Install with: pip install codebrain[api]", err=True)
        sys.exit(1)

    from codebrain.api import app, configure, configure_multi

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    configure(repo_root)

    # Auto-discover sibling project directories
    if discover:
        parent = repo_root.parent
        discovered = []
        for d in sorted(parent.iterdir()):
            if d.is_dir() and d != repo_root and (d / CODEBRAIN_DIR / DB_FILENAME).exists():
                discovered.append(str(d))
                click.echo(f"  ~ discovered: {d.name} ({d})")
        project_dirs = tuple(project_dirs) + tuple(discovered)

    if project_dirs:
        extra = []
        for d in project_dirs:
            p = Path(d).resolve()
            db = _db_path(p)
            if db.exists():
                extra.append(p)
                click.echo(f"  + project: {p.name} ({p})")
            else:
                click.echo(f"  ! skipping {p.name} (not indexed)", err=True)
        if extra:
            configure_multi(extra)

    if watch:
        from codebrain.watcher.file_watcher import start_watching_background
        db = _db_path(repo_root)
        observer, handler = start_watching_background(repo_root, db)
        app.state.watcher_handler = handler
        click.echo("File watcher started (validates on save).")

    click.echo(f"Starting CodeBrain API on http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


# ------------------------------------------------------------------ export
@cli.group()
def export() -> None:
    """Export the knowledge graph in various formats."""
    pass


# ------------------------------------------------------------------ explain
@cli.group()
def explain() -> None:
    """AI-powered explanations using Grok LLM."""
    pass


@explain.command(name="system")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_system(ctx: click.Context, as_json: bool) -> None:
    """AI-generated explanation of the codebase architecture."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_system()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  {result['health_summary']}")
        if result.get("recommendations"):
            click.echo(click.style("Recommendations:", bold=True))
            for rec in result["recommendations"]:
                click.echo(f"  - {rec}")


@explain.command(name="module")
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_module(ctx: click.Context, file: str, as_json: bool) -> None:
    """AI-generated explanation of a module."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_module(file)

    if "error" in result:
        click.echo(click.style(f"Error: {result['error']}", fg="red"), err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  Importance: {result['importance']}")
        click.echo(f"  {result['dependencies']}")


@explain.command(name="symbol")
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_symbol(ctx: click.Context, name: str, as_json: bool) -> None:
    """AI-generated explanation of a symbol."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No symbol found matching '{name}'.", err=True)
            sys.exit(1)

        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_symbol(nodes[0]["id"])

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  Importance: {result['importance']}")
        click.echo(f"  {result['usage']}")


@explain.command(name="health")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_health(ctx: click.Context, as_json: bool) -> None:
    """AI-generated health analysis with recommendations."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_health()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Health Score", bold=True))
        click.echo(f"  Score: {result['score']}/100 (Grade: {result['grade']})")
        details = result.get("details", {})
        click.echo(f"  Dead code: {details.get('dead_code_count', 0)} symbols")
        click.echo(f"  Import cycles: {details.get('import_cycles', 0)}")
        click.echo(f"  High-risk hotspots: {details.get('high_risk_hotspots', 0)}")


@export.command(name="dot")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_dot(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as Graphviz DOT format."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = exporter.to_dot(nodes, edges)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="mermaid")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_mermaid(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as Mermaid flowchart format."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = exporter.to_mermaid(nodes, edges)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="json")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_json(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as JSON (nodes + edges)."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = json.dumps({"nodes": nodes, "edges": edges}, indent=2)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="html")
@click.option("-o", "--output", default="codebrain_report.html", help="Output file path.")
@click.pass_context
@_safe_command
def export_html(ctx: click.Context, output: str) -> None:
    """Export a self-contained HTML report."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        content = exporter.to_html_report()

    Path(output).write_text(content)
    click.echo(f"Report written to {output}")
