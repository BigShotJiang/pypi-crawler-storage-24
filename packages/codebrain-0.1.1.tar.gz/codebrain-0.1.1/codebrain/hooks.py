"""Git hook integration for pre-commit validation.

Installs a pre-commit hook that validates changed files against the
knowledge graph before allowing a commit. Blocks on CRITICAL violations,
warns on HIGH.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

_HOOK_SCRIPT = """\
#!/usr/bin/env python3
\"\"\"CodeBrain pre-commit hook — validates changes against the knowledge graph.\"\"\"
import subprocess
import sys

def main():
    # Get staged files
    result = subprocess.run(
        ["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return 0

    files = [f.strip() for f in result.stdout.strip().splitlines() if f.strip()]
    py_files = [f for f in files if f.endswith((".py", ".ts", ".tsx", ".js", ".jsx"))]

    if not py_files:
        return 0

    # Run brain validate on each file
    cmd = [sys.executable, "-m", "codebrain.hook_runner"] + py_files
    proc = subprocess.run(cmd)
    return proc.returncode

if __name__ == "__main__":
    sys.exit(main())
"""


def install_hook(repo_root: Path) -> str:
    """Install the pre-commit hook in the repo's .git/hooks/."""
    git_dir = repo_root / ".git"
    if not git_dir.is_dir():
        return "Error: not a git repository."

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_path = hooks_dir / "pre-commit"

    # Don't overwrite existing hooks — chain instead
    if hook_path.exists():
        existing = hook_path.read_text()
        if "codebrain" in existing.lower():
            return "CodeBrain pre-commit hook already installed."
        # Rename existing hook and chain
        backup = hooks_dir / "pre-commit.backup"
        hook_path.rename(backup)
        chained = _HOOK_SCRIPT.rstrip() + f"""

# Chain to previous pre-commit hook
import os
backup = os.path.join(os.path.dirname(__file__), "pre-commit.backup")
if os.path.exists(backup):
    exit_code = os.system(f'python "{{backup}}"')
    if exit_code != 0:
        sys.exit(exit_code)
"""
        hook_path.write_text(chained)
    else:
        hook_path.write_text(_HOOK_SCRIPT)

    # Make executable on Unix
    hook_path.chmod(0o755)
    return f"Installed pre-commit hook at {hook_path}"


def uninstall_hook(repo_root: Path) -> str:
    """Remove the CodeBrain pre-commit hook."""
    git_dir = repo_root / ".git"
    if not git_dir.is_dir():
        return "Error: not a git repository."

    hook_path = git_dir / "hooks" / "pre-commit"
    backup = git_dir / "hooks" / "pre-commit.backup"

    if not hook_path.exists():
        return "No pre-commit hook found."

    content = hook_path.read_text()
    if "codebrain" not in content.lower():
        return "Pre-commit hook exists but is not a CodeBrain hook."

    hook_path.unlink()

    # Restore backup if exists
    if backup.exists():
        backup.rename(hook_path)
        return "Removed CodeBrain hook and restored previous hook."

    return "Removed CodeBrain pre-commit hook."
