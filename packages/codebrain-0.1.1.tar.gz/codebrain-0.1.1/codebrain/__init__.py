"""CodeBrain — persistent structural knowledge graph for codebases."""

__version__ = "0.1.0"
