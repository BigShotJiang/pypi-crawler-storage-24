"""Watchdog-based file monitor with debounced incremental updates."""

from __future__ import annotations

import threading
import time
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from codebrain.config import INDEXABLE_EXTENSIONS, WATCHER_DEBOUNCE_SECONDS
from codebrain.graph.store import GraphStore
from codebrain.indexer import incremental_update
from codebrain.logging import get_logger
from codebrain.settings import load_settings

_log = get_logger("watcher")


class _DebouncedHandler(FileSystemEventHandler):
    """Collects file-change events and flushes them after a debounce window."""

    def __init__(
        self,
        repo_root: Path,
        store: GraphStore,
        *,
        debounce: float = WATCHER_DEBOUNCE_SECONDS,
        extensions: frozenset[str] = INDEXABLE_EXTENSIONS,
    ) -> None:
        super().__init__()
        self.repo_root = repo_root
        self.store = store
        self._debounce = debounce
        self._extensions = extensions
        self._changed: set[Path] = set()
        self._deleted: set[Path] = set()
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._last_validation: dict[str, object] = {}  # rel_path -> ValidationReport

    def _schedule_flush(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
        self._timer = threading.Timer(self._debounce, self._flush)
        self._timer.daemon = True
        self._timer.start()

    def _flush(self) -> None:
        with self._lock:
            changed = list(self._changed)
            deleted = list(self._deleted)
            self._changed.clear()
            self._deleted.clear()

        if not changed and not deleted:
            return

        # Validate changed files BEFORE re-indexing (graph still has old state)
        if changed:
            self._validate_changed(changed)

        result = incremental_update(self.repo_root, changed, deleted, self.store)
        total = result["files_updated"] + result["files_removed"]
        if total:
            _log.info(
                "Updated %d, removed %d (%.3fs)",
                result["files_updated"],
                result["files_removed"],
                result["elapsed_seconds"],
            )

    def _validate_changed(self, changed: list[Path]) -> None:
        """Run structural validation on recently changed files."""
        from codebrain.validator import ChangeValidator

        validator = ChangeValidator(self.store)
        for abs_path in changed:
            rel_path = abs_path.relative_to(self.repo_root).as_posix()
            try:
                report = validator.validate_file(abs_path, self.repo_root)
                if not report.is_valid:
                    _log.warning(
                        "STRUCTURAL BREAKAGE in %s: %d violation(s)",
                        rel_path,
                        len(report.violations),
                    )
                    for v in report.violations:
                        if v.severity in ("critical", "high"):
                            _log.warning("  [%s] %s", v.severity.upper(), v.message)
                self._last_validation[rel_path] = report
            except Exception as e:
                _log.debug("Validation failed for %s: %s", rel_path, e)

    def get_recent_validations(self) -> dict[str, dict]:
        """Return validation results from the most recent flush."""
        return {
            path: report.to_dict()
            for path, report in self._last_validation.items()
        }

    def _is_relevant(self, path: str) -> bool:
        return Path(path).suffix in self._extensions

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory or not self._is_relevant(event.src_path):
            return
        with self._lock:
            self._changed.add(Path(event.src_path))
        self._schedule_flush()

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory or not self._is_relevant(event.src_path):
            return
        with self._lock:
            self._changed.add(Path(event.src_path))
        self._schedule_flush()

    def on_deleted(self, event: FileSystemEvent) -> None:
        if event.is_directory or not self._is_relevant(event.src_path):
            return
        with self._lock:
            self._deleted.add(Path(event.src_path))
            self._changed.discard(Path(event.src_path))
        self._schedule_flush()

    def on_moved(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        if self._is_relevant(event.src_path):
            with self._lock:
                self._deleted.add(Path(event.src_path))
        if self._is_relevant(event.dest_path):
            with self._lock:
                self._changed.add(Path(event.dest_path))
        self._schedule_flush()


def start_watching_background(
    repo_root: Path, db_path: Path,
) -> tuple[Observer, GraphStore, _DebouncedHandler]:
    """Start a non-blocking file watcher on a daemon thread.

    Returns (observer, store, handler) so the caller can stop it later
    and poll validation results via handler.get_recent_validations().
    """
    settings = load_settings(repo_root)
    store = GraphStore(db_path)
    handler = _DebouncedHandler(
        repo_root,
        store,
        debounce=settings.watcher_debounce,
        extensions=settings.indexable_extensions,
    )
    observer = Observer()
    observer.daemon = True
    observer.schedule(handler, str(repo_root), recursive=True)
    observer.start()
    _log.info("Background watcher started for %s", repo_root)
    return observer, store, handler


def start_watching(repo_root: Path, db_path: Path) -> None:
    """Block forever, watching *repo_root* for file changes."""
    observer, store, _handler = start_watching_background(repo_root, db_path)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    store.close()
