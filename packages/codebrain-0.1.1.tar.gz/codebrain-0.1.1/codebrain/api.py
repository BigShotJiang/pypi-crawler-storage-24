"""REST API server — FastAPI wrapper around CodeBrain's analysis engines.

Provides a JSON API for querying the knowledge graph and running analyses.

Usage:
    brain serve [--host 127.0.0.1] [--port 8484]
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from codebrain.api_models import (
    AskRequest,
    AskResponse,
    ErrorResponse,
    StatsResponse,
)
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

_log = logging.getLogger(__name__)

app = FastAPI(
    title="CodeBrain API",
    description="Structural knowledge graph for codebases",
    version="0.1.0",
    redoc_url=None,  # M18: Keep /docs (Swagger), drop ReDoc
)

# B4: Configurable CORS
_cors_origins = os.environ.get(
    "CODEBRAIN_CORS_ORIGINS",
    "http://localhost:8484,http://127.0.0.1:8484",
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _cors_origins],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Multi-project registry
# ---------------------------------------------------------------------------
_projects: dict[str, Path] = {}       # slug -> repo_root
_default_project: str | None = None


def _make_slug(repo_root: Path) -> str:
    """URL-safe slug from repo path. Uses directory name, disambiguating with parent if needed."""
    import re
    name = repo_root.name.lower()
    slug = re.sub(r"[^a-z0-9]+", "-", name).strip("-") or "project"
    if slug not in _projects:
        return slug
    # Disambiguate with parent directory
    parent = repo_root.parent.name.lower()
    slug2 = re.sub(r"[^a-z0-9]+", "-", parent).strip("-") + "-" + slug
    if slug2 not in _projects:
        return slug2
    # Fallback: append counter
    i = 2
    while f"{slug}-{i}" in _projects:
        i += 1
    return f"{slug}-{i}"


def configure(repo_root: Path) -> None:
    """Set the repository root and database path (single-project, backward-compatible)."""
    global _default_project
    slug = _make_slug(repo_root)
    _projects[slug] = repo_root
    _default_project = slug


def configure_multi(project_roots: list[Path]) -> None:
    """Register additional projects."""
    for root in project_roots:
        slug = _make_slug(root)
        _projects[slug] = root


def _resolve_project(project: str | None = None) -> str:
    """Resolve slug, default if None, 404 if unknown."""
    if project is None:
        if _default_project is None:
            raise HTTPException(status_code=503, detail="No projects configured.")
        return _default_project
    if project not in _projects:
        available = list(_projects.keys())
        raise HTTPException(
            status_code=404,
            detail=f"Unknown project: {project}. Available: {available}",
        )
    return project


def _get_db(project: str | None = None) -> Path:
    slug = _resolve_project(project)
    db_path = _projects[slug] / CODEBRAIN_DIR / DB_FILENAME
    if not db_path.exists():
        raise HTTPException(status_code=503, detail=f"CodeBrain not initialized for '{slug}'. Run `brain init` first.")
    return db_path


def _get_root(project: str | None = None) -> Path:
    slug = _resolve_project(project)
    return _projects[slug]


def _make_store(project: str | None = None):
    from codebrain.graph.store import GraphStore
    return GraphStore(_get_db(project))


# ---------------------------------------------------------------------------
# Simple TTL cache for expensive endpoints
# ---------------------------------------------------------------------------
_api_cache: dict[str, tuple[float, Any]] = {}
_API_CACHE_TTL = 120  # seconds — data only changes on reindex


def _cached(key: str, fn: Any, ttl: int = _API_CACHE_TTL, project: str | None = None) -> Any:
    """Return cached result if fresh, otherwise compute and cache."""
    slug = _resolve_project(project)
    full_key = f"{slug}:{key}"
    now = time.monotonic()
    if full_key in _api_cache:
        ts, val = _api_cache[full_key]
        if now - ts < ttl:
            return val
    val = fn()
    _api_cache[full_key] = (now, val)
    return val


# B3: Path traversal protection
def _validate_path(file_path: str) -> None:
    """Reject path traversal attempts."""
    if "\x00" in file_path:
        raise HTTPException(status_code=400, detail="Invalid path: null bytes not allowed.")
    if ".." in file_path.split("/"):
        raise HTTPException(status_code=400, detail="Invalid path: directory traversal not allowed.")
    if file_path.startswith("/") or (len(file_path) >= 2 and file_path[1] == ":"):
        raise HTTPException(status_code=400, detail="Invalid path: absolute paths not allowed.")


# B5: Global exception handler
@app.exception_handler(Exception)
async def _global_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


def _try_explain(fn, fallback=None):
    """Try LLM explanation, return None on failure."""
    try:
        return fn()
    except (ImportError, Exception):
        return fallback


# ---------------------------------------------------------------------------
# Endpoints (~20 routes, rationalized from 39)
# ---------------------------------------------------------------------------

@app.get("/api/projects")
def api_projects():
    """List registered projects with basic stats."""
    from codebrain.graph.store import GraphStore
    result = []
    for slug, root in _projects.items():
        db = root / CODEBRAIN_DIR / DB_FILENAME
        info: dict[str, Any] = {
            "slug": slug,
            "name": root.name,
            "path": str(root),
            "initialized": db.exists(),
        }
        if db.exists():
            try:
                with GraphStore(db) as store:
                    info["stats"] = store.get_stats()
            except Exception:
                info["stats"] = None
        result.append(info)
    return {"projects": result, "default": _default_project}


@app.get("/api/status", response_model=StatsResponse)
def api_status(project: str | None = Query(None)):
    """Index statistics with health score and LLM status."""
    from codebrain.comprehension import ComprehensionEngine
    with _make_store(project) as store:
        stats = store.get_stats()
        # M18: Merge health into status
        comp = ComprehensionEngine(store)
        hotspots = _cached("hotspots:100", lambda: comp.risk_hotspots(top_n=100), project=project)
        health = comp.health_score(hotspots=hotspots)
        stats["health"] = health
    # M18: Merge LLM status
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings
        repo_root = _get_root(project)
        settings = load_llm_settings(repo_root)
        stats["llm"] = {"enabled": settings.enabled, "provider": getattr(settings, "provider", "groq")}
    except (ImportError, Exception):
        stats["llm"] = {"enabled": False}
    # M20: Index completeness — compare indexed files vs actual files on disk
    try:
        from codebrain.indexer import discover_files
        repo_root = _get_root(project)
        actual_files = len(discover_files(repo_root))
        indexed_files = stats.get("files", 0)
        stats["index_completeness"] = {
            "indexed": indexed_files,
            "total": actual_files,
            "complete": indexed_files >= actual_files * 0.95,
        }
    except Exception:
        stats["index_completeness"] = {"indexed": stats.get("files", 0), "total": 0, "complete": False}
    return stats


@app.get("/api/search")
def api_search(
    q: str = Query(..., min_length=1),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    project: str | None = Query(None),
):
    """Search for symbols by name."""
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        engine = QueryEngine(store)
        results = engine.search_nodes(q, limit=limit + offset)
        return results[offset:offset + limit]


@app.get("/api/impact/{name:path}")
def api_impact(name: str, max_depth: int = Query(5, ge=1, le=20), project: str | None = Query(None)):
    """Impact analysis — what breaks if this symbol changes."""
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            raise HTTPException(status_code=404, detail=f"No symbol found: {name}")
        results = []
        for node in nodes:
            impacted = engine.impact_of_change(node["id"], max_depth=max_depth)
            results.append({"target": node["id"], "impacted": impacted})
        return results


@app.get("/api/callchain/{name:path}")
def api_callchain(name: str, max_depth: int = Query(10, ge=1, le=20), project: str | None = Query(None)):
    """Forward call chain from a symbol."""
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            raise HTTPException(status_code=404, detail=f"No symbol found: {name}")
        results = []
        for node in nodes:
            chain = engine.get_call_chain(node["id"], max_depth=max_depth)
            results.append({"root": node["id"], "chain": chain})
        return results


# Keep /api/trace as alias for backward compatibility
@app.get("/api/trace/{name:path}")
def api_trace(name: str, max_depth: int = Query(10, ge=1, le=20), project: str | None = Query(None)):
    """Forward call chain from a symbol (alias for /api/callchain)."""
    return api_callchain(name, max_depth, project)


@app.get("/api/deadcode")
def api_deadcode(
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    project: str | None = Query(None),
):
    """Find potentially unused symbols."""
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        engine = QueryEngine(store)
        results = engine.find_dead_code()
        return results[offset:offset + limit]


@app.get("/api/cycles")
def api_cycles(
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    project: str | None = Query(None),
):
    """Detect import cycles."""
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        engine = QueryEngine(store)
        results = engine.detect_cycles()
        return results[offset:offset + limit]


@app.get("/api/overview")
def api_overview(explain: bool = Query(False), project: str | None = Query(None)):
    """System-level codebase overview with narrative inline."""
    from codebrain.comprehension import ComprehensionEngine
    with _make_store(project) as store:
        comp = ComprehensionEngine(store)
        result = comp.system_overview()
        # M18: Inline narrative
        result["narrative"] = _cached(
            "narrative:system",
            lambda: comp.system_narrative(),
            project=project,
        )
        if explain:
            try:
                from codebrain.llm import LLMNarrator, load_llm_settings
                repo_root = _get_root(project)
                settings = load_llm_settings(repo_root)
                cache_dir = repo_root / CODEBRAIN_DIR
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result["explanation"] = narrator.explain_system()
            except (ImportError, Exception):
                pass
        return result


@app.get("/api/module/{file_path:path}")
def api_module(file_path: str, explain: bool = Query(False), project: str | None = Query(None)):
    """Module-level view of a file with narrative inline."""
    _validate_path(file_path)
    from codebrain.comprehension import ComprehensionEngine
    with _make_store(project) as store:
        comp = ComprehensionEngine(store)
        result = comp.module_view(file_path)
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        # M18: Inline narrative
        result["narrative"] = comp.module_narrative(file_path)
        if explain:
            try:
                from codebrain.llm import LLMNarrator, load_llm_settings
                repo_root = _get_root(project)
                settings = load_llm_settings(repo_root)
                cache_dir = repo_root / CODEBRAIN_DIR
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result["explanation"] = narrator.explain_module(file_path)
            except (ImportError, Exception):
                pass
        return result


def _compute_hotspots(limit: int = 100, project: str | None = None) -> list:
    """Compute risk hotspots (cached)."""
    from codebrain.comprehension import ComprehensionEngine
    with _make_store(project) as store:
        comp = ComprehensionEngine(store)
        return comp.risk_hotspots(top_n=limit)


@app.get("/api/hotspots")
def api_hotspots(
    top: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    project: str | None = Query(None),
):
    """Risk hotspots — most dangerous symbols to change."""
    results = _cached("hotspots:100", lambda: _compute_hotspots(100, project), project=project)
    return results[offset:offset + top]


@app.get("/api/coupling")
def api_coupling(
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    project: str | None = Query(None),
):
    """Module coupling analysis."""
    def _compute():
        from codebrain.analyzer import StructuralAnalyzer
        with _make_store(project) as store:
            analyzer = StructuralAnalyzer(store)
            return analyzer.coupling_analysis()
    result = _cached("coupling", _compute, project=project)
    return {"pairs": result["pairs"][offset:offset + limit], "file_ranking": result["file_ranking"]}


@app.get("/api/layers")
def api_layers(project: str | None = Query(None)):
    """Architectural layer detection."""
    def _compute():
        from codebrain.analyzer import StructuralAnalyzer
        with _make_store(project) as store:
            analyzer = StructuralAnalyzer(store)
            return analyzer.detect_layers()
    return _cached("layers", _compute, project=project)


@app.get("/api/validate/{file_path:path}")
def api_validate(file_path: str, project: str | None = Query(None)):
    """Validate a file against the graph."""
    _validate_path(file_path)
    from codebrain.validator import ChangeValidator
    with _make_store(project) as store:
        repo_root = _get_root(project)
        validator = ChangeValidator(store)
        target = repo_root / file_path
        if not target.exists():
            report = validator.validate_deletion(file_path)
        else:
            report = validator.validate_file(target, repo_root)
        return report.to_dict()


@app.get("/api/context/{name:path}")
def api_context(name: str, explain: bool = Query(False), project: str | None = Query(None)):
    """Generate structured LLM context for a symbol with narrative inline."""
    from codebrain.context import ContextGenerator
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine
    with _make_store(project) as store:
        gen = ContextGenerator(store)
        context_list = gen.for_symbol(name)
        if not context_list:
            raise HTTPException(status_code=404, detail=f"No symbol found: {name}")
        result = {"contexts": context_list}
        # M18: Inline symbol narrative
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if nodes:
            comp = ComprehensionEngine(store)
            result["narrative"] = comp.symbol_narrative(nodes[0]["id"])
        if explain:
            try:
                from codebrain.llm import LLMNarrator, load_llm_settings
                repo_root = _get_root(project)
                settings = load_llm_settings(repo_root)
                cache_dir = repo_root / CODEBRAIN_DIR
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result["explanation"] = narrator.explain_symbol(nodes[0]["id"])
            except (ImportError, Exception):
                pass
        return result


@app.post("/api/ask", response_model=AskResponse)
def api_ask_post(body: AskRequest, project: str | None = Query(None)):
    """Ask a natural language question about the codebase (POST)."""
    from codebrain.comprehension import ComprehensionEngine

    with _make_store(project) as store:
        comp = ComprehensionEngine(store)
        result = comp.answer_question(body.question)

    if body.use_llm:
        try:
            from codebrain.llm import LLMNarrator, load_llm_settings

            repo_root = _get_root(project)
            settings = load_llm_settings(repo_root)
            if settings.enabled and settings.api_keys:
                cache_dir = repo_root / CODEBRAIN_DIR
                with _make_store(project) as store:
                    narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                    result = narrator.ask(body.question)
        except ImportError:
            pass

    return result


@app.get("/api/anatomy")
def api_anatomy(explain: bool = Query(False), project: str | None = Query(None)):
    """Codebase anatomy — subsystem map for new developers."""
    def _compute():
        from codebrain.comprehension import ComprehensionEngine
        with _make_store(project) as store:
            return ComprehensionEngine(store).codebase_anatomy()
    result = _cached("anatomy", _compute, project=project)
    if explain:
        try:
            from codebrain.llm import LLMNarrator, load_llm_settings
            repo_root = _get_root(project)
            settings = load_llm_settings(repo_root)
            cache_dir = repo_root / CODEBRAIN_DIR
            with _make_store(project) as store:
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result = {"anatomy": result, "explanation": narrator.explain_anatomy()}
        except (ImportError, Exception):
            pass
    return result


@app.get("/api/patterns")
def api_patterns(project: str | None = Query(None)):
    """Cross-module structural pattern detection."""
    from codebrain.analyzer import StructuralAnalyzer
    with _make_store(project) as store:
        analyzer = StructuralAnalyzer(store)
        return analyzer.detect_structural_patterns()


@app.get("/api/export/json")
def api_export_json(project: str | None = Query(None)):
    """Export the full graph as a streaming JSON download."""
    import json as _json

    try:
        with _make_store(project) as store:
            nodes = store.get_all_nodes()
            edges = store.get_all_edges()

        def _stream():
            yield '{"meta":' + _json.dumps({
                "repo": str(_get_root(project)),
                "total_nodes": len(nodes),
                "total_edges": len(edges),
            }, default=str)
            yield ',"nodes":['
            for i, n in enumerate(nodes):
                if i:
                    yield ","
                yield _json.dumps(dict(n), default=str)
            yield '],"edges":['
            for i, e in enumerate(edges):
                if i:
                    yield ","
                yield _json.dumps(dict(e), default=str)
            yield "]}"

        from starlette.responses import StreamingResponse

        return StreamingResponse(
            _stream(),
            media_type="application/json",
            headers={
                "Content-Disposition": "attachment; filename=codebrain-export.json",
            },
        )
    except Exception as exc:
        _log.exception("Export failed: %s", exc)
        return JSONResponse(
            status_code=500,
            content={"detail": "Export failed. Check server logs for details."},
        )


@app.get("/api/watch/validations")
def api_watch_validations(project: str = ""):
    """Return recent validation results from the file watcher."""
    handler = getattr(app.state, "watcher_handler", None)
    if handler is None:
        return {"error": "File watcher not running. Start with 'brain serve --watch'."}
    return handler.get_recent_validations()


@app.get("/api/zoom")
def api_zoom(target: str = "", project: str | None = Query(None)):
    """Multi-resolution zoom — system, module, or symbol level."""
    from codebrain.comprehension import ComprehensionEngine
    with _make_store(project) as store:
        comp = ComprehensionEngine(store)
        return comp.zoom(target if target else None)
