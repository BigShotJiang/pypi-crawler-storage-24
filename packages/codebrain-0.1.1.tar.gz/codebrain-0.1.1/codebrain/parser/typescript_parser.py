"""TypeScript/JavaScript structural parser.

Enhanced regex-based extraction for .ts, .tsx, .js, and .jsx files.
Captures: functions, classes, interfaces, types, enums, imports, exports,
re-exports, decorators, namespaces, React components, hooks, API calls,
navigation, and module-level variables.
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Imports
_IMPORT_DEFAULT = re.compile(
    r"""import\s+(\w+)\s+from\s+['"]([^'"]+)['"]""",
)
_IMPORT_NAMED = re.compile(
    r"""import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]""",
)
_IMPORT_STAR = re.compile(
    r"""import\s+\*\s+as\s+(\w+)\s+from\s+['"]([^'"]+)['"]""",
)
_REQUIRE = re.compile(
    r"""(?:const|let|var)\s+(?:(\w+)|\{([^}]+)\})\s*=\s*require\s*\(\s*['"]([^'"]+)['"]\s*\)""",
)

# Type imports: import type { X } from "y"
_IMPORT_TYPE = re.compile(
    r"""import\s+type\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]""",
)

# Re-exports: export { X, Y } from "./module", export * from "./module"
_REEXPORT_NAMED = re.compile(
    r"""^export\s+(?:type\s+)?\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]""",
    re.MULTILINE,
)
_REEXPORT_STAR = re.compile(
    r"""^export\s+\*\s+(?:as\s+(\w+)\s+)?from\s+['"]([^'"]+)['"]""",
    re.MULTILINE,
)

# Decorators: @DecoratorName or @decorator(args)
_DECORATOR = re.compile(
    r"""^(\s*)@(\w[\w.]*)\s*(?:\([^)]*\))?""",
    re.MULTILINE,
)

# Functions — generics use a permissive match that allows nested <> via [^(]* up to the opening paren
_FUNCTION_DECL = re.compile(
    r"""^(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s+(\w+)\s*(<[^(]*>)?\s*\(([^)]*)\)(?:\s*:\s*([^\n{]+))?\s*\{""",
    re.MULTILINE,
)
_ARROW_CONST = re.compile(
    r"""^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::\s*[^=]+?)?\s*=\s*(?:async\s+)?(?:<[^>]*>\s*)?(?:\((?:[^)(]*|\([^)]*\))*\)|(\w+))\s*(?::\s*[^=]+?)?\s*=>""",
    re.MULTILINE,
)

# Classes
_CLASS_DECL = re.compile(
    r"""^(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+(\w+)(?:\s+extends\s+(\w[\w.]*))?(?:\s+implements\s+([\w.,\s]+))?\s*\{""",
    re.MULTILINE,
)

# Methods inside classes
_METHOD_DECL = re.compile(
    r"""^\s+(?:(?:public|private|protected|static|readonly|abstract|async|override|get|set)\s+)*(\w+)\s*(<[^>]*>)?\s*\(([^)]*)\)(?:\s*:\s*([^\n{;]+))?\s*[{;]""",
    re.MULTILINE,
)

# Interfaces
_INTERFACE_DECL = re.compile(
    r"""^(?:export\s+)?interface\s+(\w+)(?:\s+extends\s+([\w.,\s]+))?\s*\{""",
    re.MULTILINE,
)

# Type aliases
_TYPE_ALIAS = re.compile(
    r"""^(?:export\s+)?type\s+(\w+)(?:<[^>]*>)?\s*=""",
    re.MULTILINE,
)

# Enum
_ENUM_DECL = re.compile(
    r"""^(?:export\s+)?(?:const\s+)?enum\s+(\w+)\s*\{""",
    re.MULTILINE,
)

# Namespace / module declarations
_NAMESPACE_DECL = re.compile(
    r"""^(?:export\s+)?(?:declare\s+)?(?:namespace|module)\s+(\w+)\s*\{""",
    re.MULTILINE,
)

# Exports
_EXPORT_DEFAULT = re.compile(
    r"""^export\s+default\s+(?:class|function|abstract\s+class)\s+(\w+)""",
    re.MULTILINE,
)
_EXPORT_NAMED = re.compile(
    r"""^export\s+(?:const|let|var|function|class|interface|type|enum|abstract\s+class|async\s+function)""",
    re.MULTILINE,
)

# Object property methods: { methodName() { ... } } or { methodName: function() { ... } }
_OBJ_METHOD = re.compile(
    r"""^\s+(\w+)\s*\(([^)]*)\)\s*\{""",
    re.MULTILINE,
)
_OBJ_METHOD_ARROW = re.compile(
    r"""^\s+(\w+)\s*:\s*(?:async\s+)?(?:\([^)]*\)|(\w+))\s*=>""",
    re.MULTILINE,
)

# Nested functions inside function bodies
_NESTED_FUNCTION = re.compile(
    r"""(?:^|\n)\s+(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)\s*\{""",
)
_NESTED_ARROW = re.compile(
    r"""\s+(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|(\w+))\s*=>""",
)

# Function calls (simple heuristic)
_CALL_EXPR = re.compile(
    r"""(?<!\w)(\w[\w.]*)\s*\(""",
)

# Module-level const/let/var
_VARIABLE_DECL = re.compile(
    r"""^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::\s*([^=\n]+))?\s*=""",
    re.MULTILINE,
)

# React component wrappers: React.memo, memo, forwardRef, React.forwardRef, connect, styled
_REACT_WRAPPER = re.compile(
    r"""^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::\s*[^=]+?)?\s*=\s*(?:React\.)?(?:memo|forwardRef|lazy)\s*\(""",
    re.MULTILINE,
)
_REACT_HOC = re.compile(
    r"""^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:connect|withRouter|withNavigation|withTheme|styled|observer)\s*\(""",
    re.MULTILINE,
)

# React hooks: useState, useEffect, useCallback, useMemo, useRef, custom hooks
_HOOK_CALL = re.compile(
    r"""(?<!\w)(use[A-Z]\w*)\s*\(""",
)

# JSX component references: <ComponentName or <Component.Sub
_JSX_COMPONENT = re.compile(
    r"""<([A-Z]\w*(?:\.\w+)?)\s""",
)

# API calls: fetch, axios, api.get/post/put/delete
_API_CALL = re.compile(
    r"""(?<!\w)(?:fetch|axios(?:\.(?:get|post|put|delete|patch))?|api\.(?:get|post|put|delete|patch))\s*\(\s*[`'"]([^`'"]+)[`'"]""",
)

# Navigation: createStackNavigator, createBottomTabNavigator, Screen name=
_NAV_SCREEN = re.compile(
    r"""<\w+\.Screen\s+[^>]*name\s*=\s*['"]\s*(\w+)\s*['"]""",
)
_NAV_NAVIGATOR = re.compile(
    r"""(?:const|let|var)\s+(\w+)\s*=\s*create\w*Navigator\s*\(""",
)

# Keywords to skip in call extraction
_CALL_SKIP = frozenset({
    "if", "for", "while", "switch", "catch", "return", "new", "typeof",
    "instanceof", "import", "require", "from", "throw", "delete", "void",
    "yield", "await", "case", "else", "try", "finally", "class", "function",
    "const", "let", "var", "export", "default", "extends", "implements",
    "true", "false", "null", "undefined", "this", "super",
    # Common JS built-ins that add noise
    "console", "console.log", "console.warn", "console.error",
    "JSON.stringify", "JSON.parse", "Object.keys", "Object.values",
    "Object.assign", "Object.entries", "Array.isArray", "Array.from",
    "Math.floor", "Math.ceil", "Math.round", "Math.max", "Math.min",
    "parseInt", "parseFloat", "String", "Number", "Boolean",
    "setTimeout", "setInterval", "clearTimeout", "clearInterval",
    "Promise.resolve", "Promise.reject", "Promise.all",
})


def _find_line(source: str, pos: int) -> int:
    """Return 1-based line number for position pos in source."""
    return source.count("\n", 0, pos) + 1


def _find_block_end(source: str, start: int) -> int:
    """Find the matching closing brace for an opening brace at/near start."""
    depth = 0
    i = source.find("{", start)
    if i == -1:
        return start + 1
    while i < len(source):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                return _find_line(source, i)
        i += 1
    return _find_line(source, len(source) - 1)


def _find_block_end_pos(source: str, start: int) -> int | None:
    """Find the position of the matching closing brace."""
    depth = 0
    i = source.find("{", start)
    if i == -1:
        return None
    while i < len(source):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None


def _match_angle_brackets(source: str, start: int) -> int:
    """Match nested angle brackets starting from ``<`` at *start*.

    Returns the position **after** the closing ``>``, or *start* if the
    character at *start* is not ``<``.  Handles nesting like
    ``<T extends Array<U>>``.
    """
    if start >= len(source) or source[start] != "<":
        return start
    depth = 0
    i = start
    while i < len(source):
        ch = source[i]
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth -= 1
            if depth == 0:
                return i + 1
        # Bail on clearly non-generic content
        elif ch in ("{", "}", ";"):
            return start
        i += 1
    return start


def _find_arrow_expr_end(source: str, arrow_pos: int) -> int:
    """Find the end of a single-expression arrow function body.

    Starts scanning right after ``=>``.  Handles parenthesized expressions,
    template literals, string literals, and nested function calls.  Returns
    the position of the last character of the expression.
    """
    i = arrow_pos + 2  # skip =>
    # skip whitespace
    while i < len(source) and source[i] in (" ", "\t", "\n", "\r"):
        i += 1

    if i >= len(source):
        return len(source) - 1

    # If it's a block body, delegate to _find_block_end_pos
    if source[i] == "{":
        end = _find_block_end_pos(source, i)
        return end if end is not None else len(source) - 1

    # Otherwise, scan for the expression end
    paren_depth = 0
    bracket_depth = 0
    in_string = None  # None, '"', "'", '`'
    expr_start = i
    while i < len(source):
        ch = source[i]

        # Handle string/template literals
        if in_string:
            if ch == "\\" and i + 1 < len(source):
                i += 2  # skip escaped char
                continue
            if ch == in_string:
                in_string = None
            i += 1
            continue

        if ch in ('"', "'", "`"):
            in_string = ch
            i += 1
            continue

        if ch == "(":
            paren_depth += 1
        elif ch == ")":
            if paren_depth > 0:
                paren_depth -= 1
            else:
                # unbalanced paren — we're past the expression
                return i - 1
        elif ch == "[":
            bracket_depth += 1
        elif ch == "]":
            if bracket_depth > 0:
                bracket_depth -= 1
            else:
                return i - 1

        # End conditions: semicolon, newline at depth 0, comma at depth 0
        if paren_depth == 0 and bracket_depth == 0:
            if ch == ";":
                return i
            if ch == "\n":
                # Check if next non-whitespace line starts a new statement
                j = i + 1
                while j < len(source) and source[j] in (" ", "\t"):
                    j += 1
                if j >= len(source) or source[j] == "\n":
                    return i
                # Continuation heuristics: operator, dot, ?, :, etc.
                next_ch = source[j] if j < len(source) else ""
                if next_ch not in (".", "?", ":", "+", "-", "*", "/", "%",
                                   "&", "|", "^", "!", "=", "<", ">",
                                   ",", "(", "[", "`"):
                    return i

        i += 1

    return len(source) - 1


def _collect_decorators(source: str, decl_pos: int) -> list[str]:
    """Collect decorator names from lines preceding a declaration at *decl_pos*."""
    decorators: list[str] = []
    # Walk backwards from decl_pos to find decorator lines
    line_start = source.rfind("\n", 0, decl_pos)
    if line_start == -1:
        return decorators
    # Scan backwards through preceding lines
    pos = line_start
    while pos > 0:
        prev_line_start = source.rfind("\n", 0, pos)
        if prev_line_start == -1:
            prev_line_start = 0
        line = source[prev_line_start:pos].strip()
        if not line:
            pos = prev_line_start
            continue
        dm = re.match(r"@(\w[\w.]*)", line)
        if dm:
            decorators.append(dm.group(1))
            pos = prev_line_start
        else:
            break
    decorators.reverse()
    return decorators


# Significant comment patterns (JS/TS uses // and /* */ comments)
_SIGNIFICANT_COMMENT_JS = re.compile(
    r"""(?://|/?\*)\s*(TODO|FIXME|HACK|NOTE|WARNING|BUG|XXX|IMPORTANT|REFACTOR)\b[:\s]*(.+)""",
    re.IGNORECASE,
)


def _extract_significant_comments_js(source: str, max_comments: int = 20) -> list[str]:
    """Extract TODO, FIXME, HACK, NOTE comments from JS/TS source."""
    comments: list[str] = []
    for m in _SIGNIFICANT_COMMENT_JS.finditer(source):
        tag = m.group(1).upper()
        text = m.group(2).strip().rstrip("*/").strip()[:100]
        line = source.count("\n", 0, m.start()) + 1
        comments.append(f"L{line} {tag}: {text}")
        if len(comments) >= max_comments:
            break
    return comments


def _is_in_export(source: str, pos: int) -> bool:
    """Check if the statement at *pos* is an export."""
    line_start = source.rfind("\n", 0, pos) + 1
    line_end = source.find("\n", pos)
    if line_end == -1:
        line_end = len(source)
    line = source[line_start:line_end]
    return line.lstrip().startswith("export")


def _extract_calls(source_block: str, caller_id: str, file_path: str, base_line: int) -> list[ParsedEdge]:
    """Extract CALLS edges from a code block."""
    edges: list[ParsedEdge] = []
    seen: set[str] = set()
    for call in _CALL_EXPR.finditer(source_block):
        call_name = call.group(1)
        if call_name in _CALL_SKIP:
            continue
        if call_name in seen:
            continue
        seen.add(call_name)
        edges.append(ParsedEdge(
            source=caller_id, target=call_name,
            type="CALLS", file_path=file_path,
            line=base_line + _find_line(source_block, call.start()) - 1,
        ))
    return edges


def _extract_hooks(source_block: str, caller_id: str, file_path: str, base_line: int) -> list[ParsedEdge]:
    """Extract hook usage edges from a code block."""
    edges: list[ParsedEdge] = []
    seen: set[str] = set()
    for m in _HOOK_CALL.finditer(source_block):
        hook_name = m.group(1)
        if hook_name in seen:
            continue
        seen.add(hook_name)
        edges.append(ParsedEdge(
            source=caller_id, target=hook_name,
            type="CALLS", file_path=file_path,
            line=base_line + _find_line(source_block, m.start()) - 1,
        ))
    return edges


def _extract_jsx_refs(source_block: str, caller_id: str, file_path: str, base_line: int) -> list[ParsedEdge]:
    """Extract JSX component references as CALLS edges."""
    edges: list[ParsedEdge] = []
    seen: set[str] = set()
    for m in _JSX_COMPONENT.finditer(source_block):
        comp_name = m.group(1)
        if comp_name in seen:
            continue
        # Skip HTML-like elements (all lowercase like View, Text are RN components — keep capitalized)
        seen.add(comp_name)
        edges.append(ParsedEdge(
            source=caller_id, target=comp_name,
            type="CALLS", file_path=file_path,
            line=base_line + _find_line(source_block, m.start()) - 1,
        ))
    return edges


def _extract_api_calls(source_block: str, caller_id: str, file_path: str, base_line: int) -> list[ParsedEdge]:
    """Extract API endpoint references as DATAFLOW edges."""
    edges: list[ParsedEdge] = []
    for m in _API_CALL.finditer(source_block):
        endpoint = m.group(1)
        edges.append(ParsedEdge(
            source=caller_id, target=f"API:{endpoint}",
            type="DATAFLOW", file_path=file_path,
            line=base_line + _find_line(source_block, m.start()) - 1,
        ))
    return edges


def parse_typescript_file(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a TypeScript/JavaScript file and return a ParsedFile."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").removesuffix(".ts").removesuffix(".tsx").removesuffix(".js").removesuffix(".jsx")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []
    exported_names: set[str] = set()
    seen_node_ids: set[str] = set()

    # File-level node — use __module__ suffix to avoid collision with
    # same-named component exports (e.g. ProfileScreen.tsx exports ProfileScreen)
    file_node_id = f"{rel_path}::__module__"
    # Extract significant comments for LLM context
    significant_comments = _extract_significant_comments_js(source)
    file_docstring = ""
    if significant_comments:
        file_docstring = f"[Comments: {' | '.join(significant_comments)}]"

    file_node = ParsedNode(
        id=file_node_id,
        name=module_name.rsplit(".", 1)[-1],
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        docstring=file_docstring,
    )
    nodes.append(file_node)
    seen_node_ids.add(file_node_id)

    # --- Imports ---
    for m in _IMPORT_DEFAULT.finditer(source):
        name, module = m.group(1), m.group(2)
        edges.append(ParsedEdge(
            source=file_node_id, target=module,
            type="IMPORTS", file_path=rel_path, line=_find_line(source, m.start()),
        ))

    for m in _IMPORT_NAMED.finditer(source):
        names_str, module = m.group(1), m.group(2)
        line = _find_line(source, m.start())
        for name in names_str.split(","):
            name = name.strip().split(" as ")[0].strip()
            if name:
                edges.append(ParsedEdge(
                    source=file_node_id, target=f"{module}.{name}",
                    type="IMPORTS", file_path=rel_path, line=line,
                ))

    for m in _IMPORT_STAR.finditer(source):
        alias, module = m.group(1), m.group(2)
        edges.append(ParsedEdge(
            source=file_node_id, target=module,
            type="IMPORTS", file_path=rel_path, line=_find_line(source, m.start()),
        ))

    for m in _REQUIRE.finditer(source):
        module = m.group(3)
        edges.append(ParsedEdge(
            source=file_node_id, target=module,
            type="IMPORTS", file_path=rel_path, line=_find_line(source, m.start()),
        ))

    # --- Type imports ---
    for m in _IMPORT_TYPE.finditer(source):
        names_str, module = m.group(1), m.group(2)
        line = _find_line(source, m.start())
        for name in names_str.split(","):
            name = name.strip().split(" as ")[0].strip()
            if name:
                edges.append(ParsedEdge(
                    source=file_node_id, target=f"{module}.{name}",
                    type="IMPORTS", file_path=rel_path, line=line,
                ))

    # --- Re-exports ---
    for m in _REEXPORT_NAMED.finditer(source):
        names_str, module = m.group(1), m.group(2)
        line = _find_line(source, m.start())
        edges.append(ParsedEdge(
            source=file_node_id, target=module,
            type="IMPORTS", file_path=rel_path, line=line,
        ))
        for name in names_str.split(","):
            raw = name.strip()
            # Handle "default as NewName" or "X as Y"
            if " as " in raw:
                parts = raw.split(" as ")
                original = parts[0].strip()
                alias = parts[1].strip()
                exported_names.add(alias)
                edges.append(ParsedEdge(
                    source=file_node_id, target=f"{module}.{original}",
                    type="IMPORTS", file_path=rel_path, line=line,
                ))
                # Create a re-exported node
                node_id = f"{rel_path}::{alias}"
                if node_id not in seen_node_ids:
                    seen_node_ids.add(node_id)
                    nodes.append(ParsedNode(
                        id=node_id, name=alias, qualified_name=alias,
                        type="variable", file_path=rel_path,
                        line_start=line, line_end=line,
                        is_exported=True, decorators=["re-export"],
                    ))
            else:
                clean = raw.strip()
                if clean:
                    exported_names.add(clean)
                    edges.append(ParsedEdge(
                        source=file_node_id, target=f"{module}.{clean}",
                        type="IMPORTS", file_path=rel_path, line=line,
                    ))
                    # Create a re-exported node
                    node_id = f"{rel_path}::{clean}"
                    if node_id not in seen_node_ids:
                        seen_node_ids.add(node_id)
                        nodes.append(ParsedNode(
                            id=node_id, name=clean, qualified_name=clean,
                            type="variable", file_path=rel_path,
                            line_start=line, line_end=line,
                            is_exported=True, decorators=["re-export"],
                        ))

    for m in _REEXPORT_STAR.finditer(source):
        alias = m.group(1)  # may be None
        module = m.group(2)
        line = _find_line(source, m.start())
        edges.append(ParsedEdge(
            source=file_node_id, target=module,
            type="IMPORTS", file_path=rel_path, line=line,
        ))
        if alias:
            exported_names.add(alias)
            node_id = f"{rel_path}::{alias}"
            if node_id not in seen_node_ids:
                seen_node_ids.add(node_id)
                nodes.append(ParsedNode(
                    id=node_id, name=alias, qualified_name=alias,
                    type="variable", file_path=rel_path,
                    line_start=line, line_end=line,
                    is_exported=True, decorators=["re-export"],
                ))

    # --- Functions (function keyword) ---
    for m in _FUNCTION_DECL.finditer(source):
        name = m.group(1)
        params = m.group(3).strip()
        return_type = m.group(4).strip() if m.group(4) else ""
        line = _find_line(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        sig = f"({params})"
        if return_type:
            sig += f" => {return_type}"
        end_line = _find_block_end(source, m.start())
        node_id = f"{rel_path}::{name}"
        # Collect decorators from preceding lines
        func_decorators = _collect_decorators(source, m.start())
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="function",
                file_path=rel_path, line_start=line, line_end=end_line,
                signature=sig, is_exported=is_exp,
                decorators=func_decorators,
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))
        # Extract calls within this function
        block_end = _find_block_end_pos(source, m.start())
        func_body = source[m.start():block_end + 1] if block_end is not None else ""
        edges.extend(_extract_calls(func_body, node_id, rel_path, line))
        edges.extend(_extract_hooks(func_body, node_id, rel_path, line))
        edges.extend(_extract_jsx_refs(func_body, node_id, rel_path, line))
        edges.extend(_extract_api_calls(func_body, node_id, rel_path, line))

        # Extract nested functions
        if func_body:
            for nm in _NESTED_FUNCTION.finditer(func_body):
                nname = nm.group(1)
                nline = line + _find_line(func_body, nm.start()) - 1
                nid = f"{rel_path}::{name}.{nname}"
                if nid not in seen_node_ids:
                    seen_node_ids.add(nid)
                    nend = line + _find_line(func_body[nm.start():], func_body[nm.start():].find("}") if "}" in func_body[nm.start():] else 0)
                    nb_end = _find_block_end_pos(func_body, nm.start())
                    if nb_end is not None:
                        nend = line + _find_line(func_body, nb_end) - 1
                    nodes.append(ParsedNode(
                        id=nid, name=nname,
                        qualified_name=f"{name}.{nname}", type="function",
                        file_path=rel_path, line_start=nline, line_end=nend,
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=nid,
                        type="CONTAINS", file_path=rel_path, line=nline,
                    ))
            for nm in _NESTED_ARROW.finditer(func_body):
                nname = nm.group(1)
                nline = line + _find_line(func_body, nm.start()) - 1
                nid = f"{rel_path}::{name}.{nname}"
                if nid not in seen_node_ids:
                    seen_node_ids.add(nid)
                    nodes.append(ParsedNode(
                        id=nid, name=nname,
                        qualified_name=f"{name}.{nname}", type="function",
                        file_path=rel_path, line_start=nline, line_end=nline,
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=nid,
                        type="CONTAINS", file_path=rel_path, line=nline,
                    ))

    # --- Arrow functions (const foo = (...) => ...) ---
    for m in _ARROW_CONST.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        arrow_decorators = _collect_decorators(source, m.start())
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="function",
                file_path=rel_path, line_start=line, line_end=line,
                is_exported=is_exp, decorators=arrow_decorators,
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))
        # Find the arrow `=>` position, then look for `{` AFTER it
        arrow_pos = source.find("=>", m.end() - 2)
        if arrow_pos == -1:
            arrow_pos = m.end()
        block_end = _find_block_end_pos(source, arrow_pos)
        if block_end is not None:
            arrow_body = source[arrow_pos:block_end + 1]
            # Update end_line for arrow functions with block bodies
            for n in nodes:
                if n.id == node_id:
                    n.line_end = _find_line(source, block_end)
                    break
        else:
            # Single-expression arrow: use smart expression-end detection
            expr_end = _find_arrow_expr_end(source, arrow_pos)
            arrow_body = source[arrow_pos:expr_end + 1]
            for n in nodes:
                if n.id == node_id:
                    n.line_end = _find_line(source, expr_end)
                    break
        edges.extend(_extract_calls(arrow_body, node_id, rel_path, line))
        edges.extend(_extract_hooks(arrow_body, node_id, rel_path, line))
        edges.extend(_extract_jsx_refs(arrow_body, node_id, rel_path, line))
        edges.extend(_extract_api_calls(arrow_body, node_id, rel_path, line))

    # --- React wrapped components (memo, forwardRef, lazy) ---
    for m in _REACT_WRAPPER.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            end_line = _find_block_end(source, m.start())
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="function",
                file_path=rel_path, line_start=line, line_end=end_line,
                is_exported=is_exp, decorators=["react_component"],
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))
        # Extract calls from wrapped component body
        block_end = _find_block_end_pos(source, m.start())
        if block_end is not None:
            comp_body = source[m.start():block_end + 1]
            edges.extend(_extract_calls(comp_body, node_id, rel_path, line))
            edges.extend(_extract_hooks(comp_body, node_id, rel_path, line))
            edges.extend(_extract_jsx_refs(comp_body, node_id, rel_path, line))
            edges.extend(_extract_api_calls(comp_body, node_id, rel_path, line))

    # --- HOC-wrapped components (connect, withRouter, styled, observer) ---
    for m in _REACT_HOC.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="function",
                file_path=rel_path, line_start=line, line_end=line,
                is_exported=is_exp, decorators=["hoc_wrapped"],
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))

    # --- Classes ---
    for m in _CLASS_DECL.finditer(source):
        name = m.group(1)
        extends = m.group(2)
        implements = m.group(3)
        line = _find_line(source, m.start())
        end_line = _find_block_end(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        class_decorators = _collect_decorators(source, m.start())
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="class",
                file_path=rel_path, line_start=line, line_end=end_line,
                is_exported=is_exp, decorators=class_decorators,
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))
        if extends:
            edges.append(ParsedEdge(
                source=node_id, target=extends.strip(),
                type="EXTENDS", file_path=rel_path, line=line,
            ))
        if implements:
            for iface in implements.split(","):
                iface = iface.strip()
                if iface:
                    edges.append(ParsedEdge(
                        source=node_id, target=iface,
                        type="IMPLEMENTS", file_path=rel_path, line=line,
                    ))

        # Extract methods within the class body
        block_end_pos = _find_block_end_pos(source, m.start())
        class_body = source[m.start():block_end_pos + 1] if block_end_pos is not None else source[m.start():]
        for method_m in _METHOD_DECL.finditer(class_body):
            method_name = method_m.group(1)
            if method_name in ("if", "for", "while", "switch", "catch", "return", "new"):
                continue
            method_params = method_m.group(3).strip() if method_m.group(3) else ""
            method_return = method_m.group(4).strip() if method_m.group(4) else ""
            method_line = line + _find_line(class_body, method_m.start()) - 1
            method_sig = f"({method_params})"
            if method_return:
                method_sig += f" => {method_return}"
            method_id = f"{rel_path}::{name}.{method_name}"
            if method_id not in seen_node_ids:
                seen_node_ids.add(method_id)
                # Find method body for call extraction
                method_block_end = _find_block_end_pos(class_body, method_m.start())
                method_end_line = method_line
                if method_block_end is not None:
                    method_body = class_body[method_m.start():method_block_end + 1]
                    method_end_line = line + _find_line(class_body, method_block_end) - 1
                    edges.extend(_extract_calls(method_body, method_id, rel_path, method_line))
                    edges.extend(_extract_hooks(method_body, method_id, rel_path, method_line))
                    edges.extend(_extract_jsx_refs(method_body, method_id, rel_path, method_line))
                    edges.extend(_extract_api_calls(method_body, method_id, rel_path, method_line))
                nodes.append(ParsedNode(
                    id=method_id, name=method_name,
                    qualified_name=f"{name}.{method_name}", type="method",
                    file_path=rel_path, line_start=method_line, line_end=method_end_line,
                    signature=method_sig,
                ))
                edges.append(ParsedEdge(
                    source=node_id, target=method_id,
                    type="CONTAINS", file_path=rel_path, line=method_line,
                ))

    # --- Interfaces ---
    for m in _INTERFACE_DECL.finditer(source):
        name = m.group(1)
        extends = m.group(2)
        line = _find_line(source, m.start())
        end_line = _find_block_end(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="class",
                file_path=rel_path, line_start=line, line_end=end_line,
                is_exported=is_exp, decorators=["interface"],
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))
        if extends:
            for base in extends.split(","):
                base = base.strip()
                if base:
                    edges.append(ParsedEdge(
                        source=node_id, target=base,
                        type="EXTENDS", file_path=rel_path, line=line,
                    ))

    # --- Type aliases ---
    for m in _TYPE_ALIAS.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="variable",
                file_path=rel_path, line_start=line, line_end=line,
                is_exported=is_exp, decorators=["type_alias"],
            ))

    # --- Enums ---
    for m in _ENUM_DECL.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        end_line = _find_block_end(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="class",
                file_path=rel_path, line_start=line, line_end=end_line,
                is_exported=is_exp, decorators=["enum"],
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))

    # --- Namespaces / modules ---
    for m in _NAMESPACE_DECL.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        end_line = _find_block_end(source, m.start())
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="class",
                file_path=rel_path, line_start=line, line_end=end_line,
                is_exported=is_exp, decorators=["namespace"],
            ))
            edges.append(ParsedEdge(
                source=file_node_id, target=node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))

        # Extract nested declarations inside the namespace
        # Use patterns without ^ anchor since namespace body is indented
        _NS_FUNC = re.compile(
            r"""(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*(?:<[^(]*>)?\s*\([^)]*\)(?:\s*:\s*[^\n{]+)?\s*\{""",
        )
        _NS_IFACE = re.compile(
            r"""(?:export\s+)?interface\s+(\w+)(?:\s+extends\s+[\w.,\s]+)?\s*\{""",
        )
        _NS_CLASS = re.compile(
            r"""(?:export\s+)?(?:abstract\s+)?class\s+(\w+)[^{]*\{""",
        )
        _NS_ENUM = re.compile(
            r"""(?:export\s+)?(?:const\s+)?enum\s+(\w+)\s*\{""",
        )
        _NS_TYPE = re.compile(
            r"""(?:export\s+)?type\s+(\w+)(?:<[^>]*>)?\s*=""",
        )
        block_end_pos = _find_block_end_pos(source, m.start())
        if block_end_pos is not None:
            # Skip the namespace header line to avoid re-matching the namespace itself
            first_brace = source.find("{", m.start())
            ns_body = source[first_brace + 1:block_end_pos]
            ns_body_offset = first_brace + 1
            for fn_m in _NS_FUNC.finditer(ns_body):
                fn_name = fn_m.group(1)
                fn_line = _find_line(source, ns_body_offset + fn_m.start())
                fn_id = f"{rel_path}::{name}.{fn_name}"
                if fn_id not in seen_node_ids:
                    seen_node_ids.add(fn_id)
                    fn_end = fn_line
                    nb_end = _find_block_end_pos(ns_body, fn_m.start())
                    if nb_end is not None:
                        fn_end = _find_line(source, ns_body_offset + nb_end)
                    nodes.append(ParsedNode(
                        id=fn_id, name=fn_name,
                        qualified_name=f"{name}.{fn_name}", type="function",
                        file_path=rel_path, line_start=fn_line, line_end=fn_end,
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=fn_id,
                        type="CONTAINS", file_path=rel_path, line=fn_line,
                    ))
            for iface_m in _NS_IFACE.finditer(ns_body):
                iname = iface_m.group(1)
                iline = _find_line(source, ns_body_offset + iface_m.start())
                iid = f"{rel_path}::{name}.{iname}"
                if iid not in seen_node_ids:
                    seen_node_ids.add(iid)
                    iend = iline
                    ib_end = _find_block_end_pos(ns_body, iface_m.start())
                    if ib_end is not None:
                        iend = _find_line(source, ns_body_offset + ib_end)
                    nodes.append(ParsedNode(
                        id=iid, name=iname,
                        qualified_name=f"{name}.{iname}", type="class",
                        file_path=rel_path, line_start=iline, line_end=iend,
                        decorators=["interface"],
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=iid,
                        type="CONTAINS", file_path=rel_path, line=iline,
                    ))
            for cls_m in _NS_CLASS.finditer(ns_body):
                cname = cls_m.group(1)
                cline = _find_line(source, ns_body_offset + cls_m.start())
                cid = f"{rel_path}::{name}.{cname}"
                if cid not in seen_node_ids:
                    seen_node_ids.add(cid)
                    cend = cline
                    cb_end = _find_block_end_pos(ns_body, cls_m.start())
                    if cb_end is not None:
                        cend = _find_line(source, ns_body_offset + cb_end)
                    nodes.append(ParsedNode(
                        id=cid, name=cname,
                        qualified_name=f"{name}.{cname}", type="class",
                        file_path=rel_path, line_start=cline, line_end=cend,
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=cid,
                        type="CONTAINS", file_path=rel_path, line=cline,
                    ))
            for enum_m in _NS_ENUM.finditer(ns_body):
                ename = enum_m.group(1)
                eline = _find_line(source, ns_body_offset + enum_m.start())
                eid = f"{rel_path}::{name}.{ename}"
                if eid not in seen_node_ids:
                    seen_node_ids.add(eid)
                    eend = eline
                    eb_end = _find_block_end_pos(ns_body, enum_m.start())
                    if eb_end is not None:
                        eend = _find_line(source, ns_body_offset + eb_end)
                    nodes.append(ParsedNode(
                        id=eid, name=ename,
                        qualified_name=f"{name}.{ename}", type="class",
                        file_path=rel_path, line_start=eline, line_end=eend,
                        decorators=["enum"],
                    ))
                    edges.append(ParsedEdge(
                        source=node_id, target=eid,
                        type="CONTAINS", file_path=rel_path, line=eline,
                    ))
            for type_m in _NS_TYPE.finditer(ns_body):
                tname = type_m.group(1)
                tline = _find_line(source, ns_body_offset + type_m.start())
                tid = f"{rel_path}::{name}.{tname}"
                if tid not in seen_node_ids:
                    seen_node_ids.add(tid)
                    nodes.append(ParsedNode(
                        id=tid, name=tname,
                        qualified_name=f"{name}.{tname}", type="variable",
                        file_path=rel_path, line_start=tline, line_end=tline,
                        decorators=["type_alias"],
                    ))

    # --- Module-level variables (not already captured as functions/classes) ---
    for m in _VARIABLE_DECL.finditer(source):
        name = m.group(1)
        type_ann = m.group(2).strip() if m.group(2) else ""
        line = _find_line(source, m.start())
        node_id = f"{rel_path}::{name}"
        if node_id in seen_node_ids:
            continue
        # Skip if this is inside a class/function body (indented)
        line_start_pos = source.rfind("\n", 0, m.start()) + 1
        indent = m.start() - line_start_pos
        if indent > 2:
            continue
        is_exp = _is_in_export(source, m.start())
        if is_exp:
            exported_names.add(name)
        seen_node_ids.add(node_id)
        decorators = []
        if type_ann:
            decorators.append(f"type:{type_ann[:50]}")
        nodes.append(ParsedNode(
            id=node_id, name=name, qualified_name=name, type="variable",
            file_path=rel_path, line_start=line, line_end=line,
            is_exported=is_exp, decorators=decorators,
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    # --- Object property methods (const obj = { method() {} }) ---
    # Look for variable assignments whose RHS starts with `{`
    _OBJ_LITERAL = re.compile(
        r"""^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::\s*[^=]+?)?\s*=\s*\{""",
        re.MULTILINE,
    )
    for m in _OBJ_LITERAL.finditer(source):
        obj_name = m.group(1)
        obj_node_id = f"{rel_path}::{obj_name}"
        # Only process if this is a top-level variable (not already a known function)
        line_start_pos = source.rfind("\n", 0, m.start()) + 1
        indent = m.start() - line_start_pos
        if indent > 2:
            continue
        block_end_pos = _find_block_end_pos(source, m.start())
        if block_end_pos is None:
            continue
        obj_body = source[m.start():block_end_pos + 1]
        obj_line = _find_line(source, m.start())
        # Find methods: name(...) { or name: (...) =>
        for om in _OBJ_METHOD.finditer(obj_body):
            mname = om.group(1)
            if mname in ("if", "for", "while", "switch", "catch", "return", "new", "get", "set"):
                continue
            mline = obj_line + _find_line(obj_body, om.start()) - 1
            mid = f"{rel_path}::{obj_name}.{mname}"
            if mid not in seen_node_ids:
                seen_node_ids.add(mid)
                mend = mline
                mb_end = _find_block_end_pos(obj_body, om.start())
                if mb_end is not None:
                    mend = obj_line + _find_line(obj_body, mb_end) - 1
                nodes.append(ParsedNode(
                    id=mid, name=mname,
                    qualified_name=f"{obj_name}.{mname}", type="method",
                    file_path=rel_path, line_start=mline, line_end=mend,
                ))
                edges.append(ParsedEdge(
                    source=obj_node_id, target=mid,
                    type="CONTAINS", file_path=rel_path, line=mline,
                ))
        for om in _OBJ_METHOD_ARROW.finditer(obj_body):
            mname = om.group(1)
            mline = obj_line + _find_line(obj_body, om.start()) - 1
            mid = f"{rel_path}::{obj_name}.{mname}"
            if mid not in seen_node_ids:
                seen_node_ids.add(mid)
                nodes.append(ParsedNode(
                    id=mid, name=mname,
                    qualified_name=f"{obj_name}.{mname}", type="method",
                    file_path=rel_path, line_start=mline, line_end=mline,
                ))
                edges.append(ParsedEdge(
                    source=obj_node_id, target=mid,
                    type="CONTAINS", file_path=rel_path, line=mline,
                ))

    # --- Navigation screens ---
    for m in _NAV_NAVIGATOR.finditer(source):
        name = m.group(1)
        line = _find_line(source, m.start())
        node_id = f"{rel_path}::{name}"
        if node_id not in seen_node_ids:
            seen_node_ids.add(node_id)
            nodes.append(ParsedNode(
                id=node_id, name=name, qualified_name=name, type="variable",
                file_path=rel_path, line_start=line, line_end=line,
                decorators=["navigator"],
            ))

    for m in _NAV_SCREEN.finditer(source):
        screen_name = m.group(1)
        line = _find_line(source, m.start())
        edges.append(ParsedEdge(
            source=file_node_id, target=screen_name,
            type="CALLS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


class TypeScriptParser(BaseParser):
    """BaseParser wrapper around the TypeScript/JavaScript regex parser."""

    _TS_EXTENSIONS = frozenset({".ts", ".tsx", ".js", ".jsx"})

    def extensions(self) -> frozenset[str]:
        return self._TS_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        return parse_typescript_file(path, repo_root)
