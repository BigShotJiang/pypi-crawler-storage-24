"""Parser registry — dispatches file parsing to the correct language parser."""

from __future__ import annotations

from pathlib import Path

from codebrain.logging import get_logger
from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedFile

_log = get_logger("parser.registry")

# Module-level singleton
_registry: "ParserRegistry | None" = None


class ParserRegistry:
    """Manages registered language parsers and dispatches parse requests."""

    def __init__(self) -> None:
        self._parsers: list[BaseParser] = []
        self._ext_map: dict[str, BaseParser] = {}
        self._name_map: dict[str, BaseParser] = {}

    def register(self, parser: BaseParser) -> None:
        """Register a parser instance."""
        self._parsers.append(parser)
        for ext in parser.extensions():
            if ext in self._ext_map:
                _log.debug(
                    "Extension %s already registered by %s, overriding with %s",
                    ext,
                    type(self._ext_map[ext]).__name__,
                    type(parser).__name__,
                )
            self._ext_map[ext] = parser

    def register_name(self, name: str, parser: BaseParser) -> None:
        """Register a parser for a specific filename (e.g. 'docker-compose.yml')."""
        self._name_map[name] = parser

    def can_parse(self, path: Path) -> bool:
        """Return True if any registered parser handles this file."""
        return path.suffix in self._ext_map or path.name in self._name_map

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        """Parse a file using the appropriate registered parser.

        Raises ValueError if no parser handles this file.
        """
        # Name-based match takes priority
        parser = self._name_map.get(path.name)
        if parser is None:
            parser = self._ext_map.get(path.suffix)
        if parser is None:
            raise ValueError(f"No parser registered for '{path.name}' (ext '{path.suffix}')")
        return parser.parse(path, repo_root)

    @property
    def supported_extensions(self) -> frozenset[str]:
        """Return all extensions supported by registered parsers."""
        return frozenset(self._ext_map.keys())

    @property
    def supported_names(self) -> frozenset[str]:
        """Return all filenames with name-based parser matching."""
        return frozenset(self._name_map.keys())

    @property
    def parsers(self) -> list[BaseParser]:
        """Return list of registered parsers."""
        return list(self._parsers)

    def load_entrypoints(self) -> None:
        """Discover and load parsers from the ``codebrain.parsers`` entry-points group."""
        try:
            from importlib.metadata import entry_points
        except ImportError:
            return

        eps = entry_points()
        # Python 3.12+ returns a SelectableGroups, older returns dict
        if hasattr(eps, "select"):
            group = eps.select(group="codebrain.parsers")
        elif isinstance(eps, dict):
            group = eps.get("codebrain.parsers", [])
        else:
            group = [ep for ep in eps if ep.group == "codebrain.parsers"]

        for ep in group:
            try:
                parser_cls = ep.load()
                # Skip entry-point parsers whose extensions are all already
                # covered by built-in parsers (avoids regex overriding tree-sitter).
                parser = parser_cls()
                new_exts = parser.extensions() - frozenset(self._ext_map.keys())
                if not new_exts:
                    _log.debug(
                        "Skipping plugin %s (%s) — all extensions already registered",
                        ep.name, type(parser).__name__,
                    )
                    continue
                self.register(parser)
                _log.debug("Loaded plugin parser: %s (%s)", ep.name, type(parser).__name__)
            except Exception as exc:
                _log.warning("Failed to load parser plugin %s: %s", ep.name, exc)


def get_registry() -> ParserRegistry:
    """Return the global parser registry, initializing it on first call."""
    global _registry
    if _registry is None:
        _registry = ParserRegistry()
        _init_builtin_parsers(_registry)
        _registry.load_entrypoints()
    return _registry


def _init_builtin_parsers(registry: ParserRegistry) -> None:
    """Register the built-in Python, TypeScript, and config parsers."""
    from codebrain.parser.python_parser import PythonParser
    from codebrain.parser.config_parser import ConfigParser

    registry.register(PythonParser())

    # Prefer tree-sitter AST parser for TypeScript/JavaScript when available
    try:
        from codebrain.parser.typescript_treesitter import TypeScriptTreeSitterParser, _TS_AVAILABLE
        if _TS_AVAILABLE:
            registry.register(TypeScriptTreeSitterParser())
            _log.debug("Using tree-sitter AST parser for TypeScript/JavaScript")
        else:
            from codebrain.parser.typescript_parser import TypeScriptParser
            registry.register(TypeScriptParser())
            _log.debug("tree-sitter not available, using regex parser for TypeScript/JavaScript")
    except ImportError:
        from codebrain.parser.typescript_parser import TypeScriptParser
        registry.register(TypeScriptParser())

    # Config parser: .env by extension, docker-compose by name
    config = ConfigParser()
    registry.register(config)
    for name in config._COMPOSE_NAMES:
        registry.register_name(name, config)
