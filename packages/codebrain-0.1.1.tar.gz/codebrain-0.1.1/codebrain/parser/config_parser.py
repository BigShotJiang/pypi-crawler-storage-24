"""Config file parsers for .env and docker-compose.yml.

Extracts configuration keys, service definitions, ports, and environment
variables into the knowledge graph so infrastructure is visible.
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash


# ---------------------------------------------------------------------------
# .env parser
# ---------------------------------------------------------------------------

_ENV_LINE = re.compile(r"""^([A-Z_][A-Z0-9_]*)\s*=\s*(.*)$""", re.MULTILINE)


def _parse_env_file(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a .env file — extract key=value pairs as variable nodes."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").replace(".env", "env")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["config"],
    ))

    for m in _ENV_LINE.finditer(source):
        key = m.group(1)
        value = m.group(2).strip().strip("'\"")
        line = source.count("\n", 0, m.start()) + 1

        # Mask secrets
        is_secret = any(s in key.lower() for s in ("secret", "password", "key", "token", "api_key"))
        display_value = "***" if is_secret else (value[:50] if value else "")

        node_id = f"{rel_path}::{key}"
        nodes.append(ParsedNode(
            id=node_id,
            name=key,
            qualified_name=key,
            type="variable",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=display_value,
            is_exported=True,
            decorators=["env_var"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# docker-compose.yml parser (simple regex, no PyYAML dependency)
# ---------------------------------------------------------------------------

_SERVICE_DECL = re.compile(r"""^  (\w[\w-]+):\s*$""", re.MULTILINE)
_PORT_MAPPING = re.compile(r"""['"]?(\d+):(\d+)['"]?""")
_IMAGE_LINE = re.compile(r"""^\s+image:\s*['"]?(\S+?)['"]?\s*$""", re.MULTILINE)
_DEPENDS_ON = re.compile(r"""^\s+-\s*(\w[\w-]+)\s*$""", re.MULTILINE)
_ENV_VAR_LINE = re.compile(r"""^\s+-?\s*([A-Z_][A-Z0-9_]*)\s*[:=]""", re.MULTILINE)


def _parse_docker_compose(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a docker-compose.yml — extract services, ports, dependencies."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").replace(".yml", "").replace(".yaml", "")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["docker_compose"],
    ))

    # Find services section
    services_match = re.search(r"^services:\s*$", source, re.MULTILINE)
    if not services_match:
        return ParsedFile(path=rel_path, content_hash=hash_val, nodes=nodes,
                          edges=edges, line_count=line_count)

    services_section = source[services_match.end():]

    # Find each service
    service_positions = list(_SERVICE_DECL.finditer(services_section))
    for i, sm in enumerate(service_positions):
        svc_name = sm.group(1)
        svc_line = source.count("\n", 0, services_match.end() + sm.start()) + 1

        # Get service body (until next service or end)
        start = sm.end()
        end = service_positions[i + 1].start() if i + 1 < len(service_positions) else len(services_section)
        svc_body = services_section[start:end]

        # Extract ports
        ports = []
        for pm in _PORT_MAPPING.finditer(svc_body):
            ports.append(f"{pm.group(1)}:{pm.group(2)}")

        # Extract image
        image = ""
        im = _IMAGE_LINE.search(svc_body)
        if im:
            image = im.group(1)

        sig = ""
        if image:
            sig += f"image={image}"
        if ports:
            sig += f" ports={','.join(ports)}"

        node_id = f"{rel_path}::service:{svc_name}"
        nodes.append(ParsedNode(
            id=node_id,
            name=svc_name,
            qualified_name=f"service:{svc_name}",
            type="class",
            file_path=rel_path,
            line_start=svc_line,
            line_end=svc_line,
            signature=sig.strip(),
            is_exported=True,
            decorators=["docker_service"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=node_id,
            type="CONTAINS", file_path=rel_path, line=svc_line,
        ))

        # Extract depends_on
        depends_section = re.search(r"depends_on:", svc_body)
        if depends_section:
            deps_text = svc_body[depends_section.end():depends_section.end() + 200]
            for dm in _DEPENDS_ON.finditer(deps_text):
                dep_name = dm.group(1)
                edges.append(ParsedEdge(
                    source=node_id,
                    target=f"{rel_path}::service:{dep_name}",
                    type="DEPENDS",
                    file_path=rel_path,
                    line=svc_line,
                ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Combined config parser
# ---------------------------------------------------------------------------

class ConfigParser(BaseParser):
    """Parser for configuration files (.env, docker-compose.yml)."""

    _EXTENSIONS = frozenset({".env"})
    _COMPOSE_NAMES = {"docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml"}

    def extensions(self) -> frozenset[str]:
        return self._EXTENSIONS

    def can_parse(self, path: Path) -> bool:
        """Check if this parser handles the file (extension or name match)."""
        return path.suffix in self._EXTENSIONS or path.name in self._COMPOSE_NAMES

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if path.name in self._COMPOSE_NAMES:
            return _parse_docker_compose(path, repo_root)
        return _parse_env_file(path, repo_root)
