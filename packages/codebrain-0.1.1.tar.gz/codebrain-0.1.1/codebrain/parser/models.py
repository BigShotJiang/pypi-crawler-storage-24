"""Data classes produced by the parser and consumed by the graph store."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ParsedNode:
    """A code symbol extracted from a Python source file."""

    id: str  # file_path::qualified_name
    name: str  # simple name, e.g. "process"
    qualified_name: str  # e.g. "module.Class.process"
    type: str  # file | function | class | method | variable
    file_path: str  # relative path from repo root
    line_start: int
    line_end: int
    signature: str = ""
    decorators: list[str] = field(default_factory=list)
    docstring: str = ""
    is_exported: bool = False


@dataclass(slots=True)
class ParsedEdge:
    """A relationship between two code symbols."""

    source: str  # source node ID
    target: str  # target node ID (may be unresolved name)
    type: str  # CALLS | IMPORTS | EXTENDS | IMPLEMENTS | CONTAINS
    file_path: str
    line: int


@dataclass(slots=True)
class ParsedFile:
    """Complete parse result for a single Python file."""

    path: str  # relative path from repo root
    content_hash: str
    nodes: list[ParsedNode] = field(default_factory=list)
    edges: list[ParsedEdge] = field(default_factory=list)
    line_count: int = 0
