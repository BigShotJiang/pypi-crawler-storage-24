"""Structural analyzer — coupling, cohesion, contracts, layers.

Goes beyond querying the graph to detect emergent architectural
properties: which modules are dangerously coupled, where implicit
contracts exist, and how the codebase naturally layers.
"""

from __future__ import annotations

from collections import Counter, defaultdict

from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore


class StructuralAnalyzer:
    """Analyzes emergent architectural properties of the knowledge graph."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.engine = QueryEngine(store)

    # ------------------------------------------------------------------
    # Module coupling
    # ------------------------------------------------------------------
    def coupling_analysis(self) -> dict:
        """Compute coupling scores between every pair of files.

        Coupling(A, B) = number of edges from A to B + B to A.
        Returns sorted pairs from most coupled to least.
        Uses bulk queries to avoid N+1 patterns.
        """
        # Fetch all edges and nodes once
        all_edges = self.store.get_all_edges()
        all_nodes = self.store.get_all_nodes()
        node_by_id: dict[str, dict] = {n["id"]: n for n in all_nodes}

        # Build indices for multi-strategy resolution
        nodes_by_name: dict[str, list[dict]] = defaultdict(list)
        nodes_by_qname: dict[str, list[dict]] = defaultdict(list)
        for n in all_nodes:
            nodes_by_name[n["name"]].append(n)
            if n["qualified_name"] != n["name"]:
                nodes_by_qname[n["qualified_name"]].append(n)
        file_paths = {n["file_path"] for n in all_nodes if n["type"] == "file"}

        # Pre-build suffix indexes for O(1) lookups (replaces O(N) scans)
        file_suffix_index = self._build_file_suffix_index(file_paths)
        qname_suffix_index = self._build_qname_suffix_index(node_by_id)

        pair_counts: Counter[tuple[str, str]] = Counter()

        for e in all_edges:
            if e["type"] in ("CALLS", "IMPORTS"):
                src_file = e["file_path"]
                tgt_file = self._resolve_target_to_file(
                    e["target"], node_by_id, nodes_by_qname,
                    nodes_by_name, file_paths,
                    file_suffix_index=file_suffix_index,
                    qname_suffix_index=qname_suffix_index,
                )
                if tgt_file and src_file != tgt_file:
                    key = tuple(sorted([src_file, tgt_file]))
                    pair_counts[key] += 1

        pairs = [
            {
                "file_a": k[0],
                "file_b": k[1],
                "coupling_score": v,
            }
            for k, v in pair_counts.most_common()
        ]

        # Per-file aggregate coupling
        file_scores: Counter[str] = Counter()
        for k, v in pair_counts.items():
            file_scores[k[0]] += v
            file_scores[k[1]] += v

        file_ranking = [
            {"file": f, "total_coupling": s}
            for f, s in file_scores.most_common()
        ]

        return {
            "pairs": pairs,
            "file_ranking": file_ranking,
        }

    # ------------------------------------------------------------------
    # Cohesion analysis
    # ------------------------------------------------------------------
    def cohesion_analysis(self) -> list[dict]:
        """Analyze internal cohesion of each file.

        Cohesion = ratio of internal edges to total symbols.
        Low cohesion = file contains unrelated things.
        Uses bulk queries to avoid N+1 patterns.
        """
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Group nodes by file
        file_symbols: dict[str, list[dict]] = defaultdict(list)
        for n in all_nodes:
            if n["type"] != "file":
                file_symbols[n["file_path"]].append(n)

        # Group outgoing edges by source
        edges_by_source: dict[str, list[dict]] = defaultdict(list)
        for e in all_edges:
            edges_by_source[e["source"]].append(e)

        results: list[dict] = []
        for file_path, symbols in file_symbols.items():
            if len(symbols) < 2:
                continue

            node_ids = {n["id"] for n in symbols}
            # Build name→ids and qname→ids maps for this file's symbols
            file_node_names: set[str] = set()
            file_node_qnames: set[str] = set()
            for n in symbols:
                file_node_names.add(n["name"])
                if n["qualified_name"] != n["name"]:
                    file_node_qnames.add(n["qualified_name"])

            internal_edges = 0
            total_edges = 0

            for n in symbols:
                for e in edges_by_source.get(n["id"], []):
                    if e["type"] in ("CALLS", "CONTAINS"):
                        total_edges += 1
                        target = e["target"]
                        if (target in node_ids
                                or target in file_node_names
                                or target in file_node_qnames):
                            internal_edges += 1

            cohesion = internal_edges / max(total_edges, 1)
            results.append({
                "file_path": file_path,
                "symbol_count": len(symbols),
                "internal_edges": internal_edges,
                "total_edges": total_edges,
                "cohesion_score": round(cohesion, 3),
            })

        results.sort(key=lambda r: r["cohesion_score"])
        return results

    # ------------------------------------------------------------------
    # Implicit contract detection
    # ------------------------------------------------------------------
    def detect_contracts(self, min_confidence: float = 0.5) -> list[dict]:
        """Detect implicit contracts in the codebase.

        An implicit contract is a pattern where:
        - Multiple callers use the same set of functions together
        - A function is always called after another (temporal coupling)
        - Multiple modules import the same combination of symbols

        These are fragile: changing one part may break the pattern.
        Uses bulk queries to avoid N+1 patterns.
        """
        contracts: list[dict] = []

        # Standard library names to filter from co-call patterns
        _STDLIB_NAMES = frozenset({
            "print", "len", "range", "str", "int", "float", "list", "dict",
            "set", "tuple", "bool", "type", "super", "isinstance", "issubclass",
            "getattr", "setattr", "hasattr", "open", "sorted", "enumerate",
            "zip", "map", "filter", "any", "all", "min", "max", "sum", "abs",
            "round", "repr", "id", "hash", "iter", "next", "reversed",
            "os", "sys", "json", "re", "math", "pathlib", "logging",
            "os.path", "os.path.join", "os.path.exists",
        })

        # Fetch all data once
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Build lookup structures
        node_by_id: dict[str, dict] = {n["id"]: n for n in all_nodes}
        edges_by_source: dict[str, list[dict]] = defaultdict(list)
        for e in all_edges:
            edges_by_source[e["source"]].append(e)

        file_nodes = [n for n in all_nodes if n["type"] == "file"]
        _abc_subclasses: dict[str, list[str]] = {}

        # Pattern 1: Co-imported symbols
        import_groups: dict[str, list[str]] = defaultdict(list)

        for fn in file_nodes:
            edges = edges_by_source.get(fn["id"], [])
            imports = [e["target"] for e in edges if e["type"] == "IMPORTS"]
            for imp in imports:
                import_groups[imp].append(fn["file_path"])

        co_import_pairs: Counter[tuple[str, str]] = Counter()
        for fn in file_nodes:
            edges = edges_by_source.get(fn["id"], [])
            imports = sorted({e["target"] for e in edges if e["type"] == "IMPORTS"})
            for i, a in enumerate(imports):
                for b in imports[i + 1:]:
                    co_import_pairs[(a, b)] += 1

        for (a, b), count in co_import_pairs.most_common(20):
            total_a = len(import_groups.get(a, []))
            total_b = len(import_groups.get(b, []))
            min_total = min(total_a, total_b)
            if min_total >= 3 and count >= min_total * 0.8:
                confidence = round(count / min_total, 2)
                if confidence >= min_confidence:
                    contracts.append({
                        "type": "co_import",
                        "symbols": [a, b],
                        "co_occurrence": count,
                        "total_uses": {"a": total_a, "b": total_b},
                        "confidence": confidence,
                        "message": f"'{a}' and '{b}' are imported together in {count}/{min_total} files — likely an implicit contract.",
                    })

        # Pattern 2: Co-called functions (filter stdlib names)
        all_functions = [n for n in all_nodes if n["type"] in ("function", "method")]

        call_patterns: dict[str, set[str]] = {}
        for func in all_functions:
            edges = edges_by_source.get(func["id"], [])
            callees = {e["target"] for e in edges if e["type"] == "CALLS"}
            callees = {c for c in callees if c not in _STDLIB_NAMES}
            if len(callees) >= 2:
                call_patterns[func["id"]] = callees

        call_pair_counts: Counter[tuple[str, str]] = Counter()
        for func_id, callees in call_patterns.items():
            callees_list = sorted(callees)
            for i, a in enumerate(callees_list):
                for b in callees_list[i + 1:]:
                    call_pair_counts[(a, b)] += 1

        for (a, b), count in call_pair_counts.most_common(20):
            if count >= 3:
                confidence = min(1.0, count / 5.0)
                if confidence >= min_confidence:
                    contracts.append({
                        "type": "co_call",
                        "symbols": [a, b],
                        "co_occurrence": count,
                        "confidence": confidence,
                        "message": f"'{a}' and '{b}' are called together by {count} functions — possible implicit contract.",
                    })

        # Pattern 3: Interface contracts (classes with same method names)
        all_classes = [n for n in all_nodes if n["type"] == "class"]
        class_methods: dict[str, set[str]] = {}
        for cls in all_classes:
            edges = edges_by_source.get(cls["id"], [])
            methods = set()
            for e in edges:
                if e["type"] == "CONTAINS":
                    target = node_by_id.get(e["target"])
                    if target and target["type"] == "method":
                        methods.add(target["name"])
            if methods:
                class_methods[cls["id"]] = methods

        class_ids = list(class_methods.keys())
        for i, cls_a in enumerate(class_ids):
            for cls_b in class_ids[i + 1:]:
                shared = class_methods[cls_a] & class_methods[cls_b]
                shared = {m for m in shared if not (m.startswith("__") and m.endswith("__"))}
                total = max(len(class_methods[cls_a]), len(class_methods[cls_b]))
                if len(shared) >= 3 or (len(shared) >= 2 and len(shared) / total >= 0.5):
                    confidence = round(len(shared) / total, 2)
                    if confidence >= min_confidence:
                        contracts.append({
                            "type": "shared_interface",
                            "symbols": [cls_a, cls_b],
                            "shared_methods": sorted(shared),
                            "confidence": confidence,
                            "message": f"Classes share methods {sorted(shared)} — possible implicit interface (duck typing).",
                        })

        # Pattern 4: ABC subclass contracts (explicit interface via inheritance)
        for cls in all_classes:
            edges = edges_by_source.get(cls["id"], [])
            for e in edges:
                if e["type"] in ("INHERITS", "EXTENDS"):
                    base = e["target"]
                    # Find base class node by name/qname/id
                    base_node = node_by_id.get(base)
                    if not base_node:
                        # Try matching by name
                        for n in all_classes:
                            if n["name"] == base or n["qualified_name"] == base:
                                base_node = n
                                break
                    if base_node:
                        base_id = base_node["id"]
                        if base_id not in _abc_subclasses:
                            _abc_subclasses[base_id] = []
                        _abc_subclasses[base_id].append(cls["id"])

        for base_id, subclass_ids in _abc_subclasses.items():
            if len(subclass_ids) >= 2:
                base_node = node_by_id.get(base_id, {})
                impl_names = [node_by_id.get(s, {}).get("name", s) for s in subclass_ids]
                contracts.append({
                    "type": "interface",
                    "base_class": base_node.get("name", base_id),
                    "base_class_id": base_id,
                    "implementors": impl_names,
                    "implementor_ids": subclass_ids,
                    "confidence": 1.0,
                    "message": (
                        f"{base_node.get('name', base_id)} is implemented by "
                        f"{len(subclass_ids)} classes ({', '.join(impl_names)}). "
                        f"All must maintain the same interface."
                    ),
                })

        contracts.sort(key=lambda c: c.get("confidence", 0), reverse=True)
        return contracts

    def check_contract_violations(self, contracts: list[dict] | None = None) -> list[dict]:
        """Check if any detected contracts are currently violated."""
        if contracts is None:
            contracts = self.detect_contracts()

        violations = []
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Build contains map for method lookup
        node_by_id = {n["id"]: n for n in all_nodes}
        contains_targets: dict[str, list[str]] = defaultdict(list)
        for e in all_edges:
            if e["type"] == "CONTAINS":
                contains_targets[e["source"]].append(e["target"])

        for contract in contracts:
            if contract["type"] == "interface":
                base_id = contract.get("base_class_id")
                if not base_id:
                    continue
                # Get base class methods (non-dunder)
                base_methods = set()
                for target_id in contains_targets.get(base_id, []):
                    target = node_by_id.get(target_id)
                    if target and target["type"] == "method":
                        name = target["name"]
                        if not (name.startswith("__") and name.endswith("__")):
                            base_methods.add(name)

                for impl_id in contract.get("implementor_ids", []):
                    impl_methods = set()
                    for target_id in contains_targets.get(impl_id, []):
                        target = node_by_id.get(target_id)
                        if target and target["type"] == "method":
                            name = target["name"]
                            if not (name.startswith("__") and name.endswith("__")):
                                impl_methods.add(name)

                    missing = base_methods - impl_methods
                    if missing:
                        impl_name = node_by_id.get(impl_id, {}).get("name", impl_id)
                        violations.append({
                            "contract": contract["message"],
                            "violator": impl_name,
                            "missing_methods": sorted(missing),
                            "message": f"{impl_name} is missing methods: {', '.join(sorted(missing))}",
                        })

        return violations

    # ------------------------------------------------------------------
    # Architectural layers
    # ------------------------------------------------------------------
    @staticmethod
    def _resolve_target_to_file(
        target: str,
        node_by_id: dict[str, dict],
        nodes_by_qname: dict[str, list[dict]],
        nodes_by_name: dict[str, list[dict]],
        file_paths: set[str],
        *,
        file_suffix_index: dict[str, list[str]] | None = None,
        qname_suffix_index: dict[str, list[str]] | None = None,
    ) -> str | None:
        """Resolve an edge target to a file path using multiple strategies.

        Strategy 1: Exact node ID lookup
        Strategy 2: Qualified name lookup
        Strategy 3: Simple name lookup
        Strategy 4: Dotted import path → file path conversion
        Strategy 5: Indexed suffix match on dotted paths
        Strategy 6: Indexed suffix match on node qualified names
        """
        # Strategy 1: Exact node ID
        node = node_by_id.get(target)
        if node and node["file_path"] in file_paths:
            return node["file_path"]

        # Strategy 2: Qualified name
        matches = nodes_by_qname.get(target)
        if matches:
            for m in matches:
                if m["file_path"] in file_paths:
                    return m["file_path"]

        # Strategy 3: Simple name
        matches = nodes_by_name.get(target)
        if matches:
            for m in matches:
                if m["file_path"] in file_paths:
                    return m["file_path"]

        # Strategy 4: Dotted import path → file path
        if "." in target:
            parts = target.split(".")
            for i in range(len(parts), 0, -1):
                candidate = "/".join(parts[:i]) + ".py"
                if candidate in file_paths:
                    return candidate
                candidate_pkg = "/".join(parts[:i]) + "/__init__.py"
                if candidate_pkg in file_paths:
                    return candidate_pkg

        # Strategy 5: Indexed suffix match — O(1) lookup instead of O(N) scan
        if "." in target and file_suffix_index is not None:
            suffix = target.split(".")[0] + ".py"
            candidates = file_suffix_index.get(suffix, [])
            if len(candidates) == 1:
                return candidates[0]

        # Strategy 6: Indexed qualified name suffix match — O(1) lookup
        if "::" not in target and qname_suffix_index is not None:
            candidates = qname_suffix_index.get(target, [])
            if len(candidates) == 1:
                node = node_by_id.get(candidates[0])
                if node and node["file_path"] in file_paths:
                    return node["file_path"]

        return None

    def detect_layers(self) -> dict:
        """Infer natural architectural layers from dependency direction.

        Uses Kahn's algorithm for topological sort. Strongly connected
        components (cycles) are collapsed and assigned their own layer.
        Uses bulk queries to avoid N+1 patterns.
        """
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()
        node_by_id: dict[str, dict] = {n["id"]: n for n in all_nodes}

        # Build name and qualified name indices for multi-strategy resolution
        nodes_by_name: dict[str, list[dict]] = defaultdict(list)
        nodes_by_qname: dict[str, list[dict]] = defaultdict(list)
        for n in all_nodes:
            nodes_by_name[n["name"]].append(n)
            if n["qualified_name"] != n["name"]:
                nodes_by_qname[n["qualified_name"]].append(n)

        file_nodes = [n for n in all_nodes if n["type"] == "file"]
        file_paths = {fn["file_path"] for fn in file_nodes}

        # Group nodes by file
        nodes_by_file: dict[str, list[dict]] = defaultdict(list)
        for n in all_nodes:
            nodes_by_file[n["file_path"]].append(n)

        # Group edges by source
        edges_by_source: dict[str, list[dict]] = defaultdict(list)
        for e in all_edges:
            edges_by_source[e["source"]].append(e)

        # Build set of top-level package prefixes from indexed files
        # so we can distinguish internal vs third-party import targets.
        _repo_prefixes: set[str] = set()
        for fp in file_paths:
            top = fp.split("/")[0] if "/" in fp else fp.rsplit(".", 1)[0]
            _repo_prefixes.add(top)

        def _is_third_party(target: str) -> bool:
            """Return True if *target* looks like a third-party/stdlib import."""
            # Targets that are node IDs (contain ::) are always internal
            if "::" in target:
                return False
            # Bare names like "os", "sys", "json" — check if they match a repo prefix
            first = target.split(".")[0]
            return first not in _repo_prefixes

        # Pre-build suffix indexes for O(1) lookups
        file_suffix_index = self._build_file_suffix_index(file_paths)
        qname_suffix_index = self._build_qname_suffix_index(node_by_id)

        # Build file-level dependency graph using IMPORTS and CALLS edges
        deps: dict[str, set[str]] = {fp: set() for fp in file_paths}
        resolved_count = 0
        unresolved_count = 0
        third_party_count = 0
        unresolved_targets: list[str] = []
        for fn in file_nodes:
            for node in nodes_by_file.get(fn["file_path"], []):
                for e in edges_by_source.get(node["id"], []):
                    if e["type"] in ("IMPORTS", "CALLS"):
                        # Skip third-party/stdlib imports — they can never resolve
                        # to a repo file and shouldn't count as "unresolved"
                        if e["type"] == "IMPORTS" and _is_third_party(e["target"]):
                            third_party_count += 1
                            continue

                        target_file = self._resolve_target_to_file(
                            e["target"], node_by_id, nodes_by_qname,
                            nodes_by_name, file_paths,
                            file_suffix_index=file_suffix_index,
                            qname_suffix_index=qname_suffix_index,
                        )
                        if target_file and target_file != fn["file_path"]:
                            deps[fn["file_path"]].add(target_file)
                            resolved_count += 1
                        elif not target_file:
                            unresolved_count += 1
                            if len(unresolved_targets) < 20:
                                unresolved_targets.append(e["target"])

        # Detect strongly connected components (Tarjan's)
        sccs = self._tarjan_scc(file_paths, deps)

        # Map each file to its SCC representative
        file_to_scc: dict[str, int] = {}
        for i, scc in enumerate(sccs):
            for fp in scc:
                file_to_scc[fp] = i

        # Build condensed DAG (SCC-level deps)
        scc_deps: dict[int, set[int]] = {i: set() for i in range(len(sccs))}
        for fp, fp_deps in deps.items():
            src_scc = file_to_scc[fp]
            for dep in fp_deps:
                dst_scc = file_to_scc[dep]
                if src_scc != dst_scc:
                    scc_deps[src_scc].add(dst_scc)

        # Kahn's algorithm on condensed DAG
        # scc_deps[i] = set of SCCs that i depends on (i → dep)
        # dep_count[i] = number of unresolved dependencies of i
        # reverse_deps[i] = set of SCCs that depend on i
        from collections import deque

        dep_count: dict[int, int] = {i: len(scc_deps[i]) for i in range(len(sccs))}
        reverse_deps: dict[int, set[int]] = {i: set() for i in range(len(sccs))}
        for src, targets in scc_deps.items():
            for t in targets:
                reverse_deps[t].add(src)

        # Start with leaf nodes (no dependencies)
        queue: deque[int] = deque(i for i, d in dep_count.items() if d == 0)
        scc_layers: dict[int, int] = {}
        while queue:
            node = queue.popleft()
            dep_layers = [scc_layers[d] for d in scc_deps[node] if d in scc_layers]
            scc_layers[node] = (max(dep_layers) + 1) if dep_layers else 0
            # Notify nodes that depend on this one
            for dependent in reverse_deps[node]:
                dep_count[dependent] -= 1
                if dep_count[dependent] == 0:
                    queue.append(dependent)

        # Assign file-level layers
        layers: dict[str, int] = {}
        for fp in file_paths:
            scc_idx = file_to_scc[fp]
            base_layer = scc_layers.get(scc_idx, 0)
            is_cycle = len(sccs[scc_idx]) > 1
            layers[fp] = -1 if is_cycle else base_layer

        # Group by layer
        layer_groups: dict[int, list[str]] = defaultdict(list)
        for fp, layer in layers.items():
            layer_groups[layer].append(fp)

        MAX_LAYER_FILES = 30  # Truncate for API/web UI performance

        result_layers = []
        for layer_num in sorted(layer_groups.keys()):
            files = sorted(layer_groups[layer_num])
            total_files = len(files)
            truncated = total_files > MAX_LAYER_FILES
            display_files = files[:MAX_LAYER_FILES] if truncated else files
            label = self._layer_label(layer_num, files)

            # Build summary: "N files across M packages"
            pkgs_in_layer = {f.split("/")[0] for f in files if "/" in f}
            summary = f"{total_files} files"
            if pkgs_in_layer:
                summary += f" across {len(pkgs_in_layer)} packages"

            result_layers.append({
                "layer": layer_num,
                "label": label,
                "files": display_files,
                "total_files": total_files,
                "files_truncated": truncated,
                "description": self._layer_description(layer_num, files),
                "summary": summary,
            })

        total_internal = resolved_count + unresolved_count
        resolution_pct = (resolved_count / total_internal * 100) if total_internal else 100.0

        # Confidence: how much we trust the layer detection result
        if resolution_pct >= 80:
            confidence = "high"
        elif resolution_pct >= 50:
            confidence = "medium"
        else:
            confidence = "low"

        return {
            "layers": result_layers,
            "confidence": confidence,
            "edge_resolution": {
                "total_internal": total_internal,
                "resolved": resolved_count,
                "unresolved": unresolved_count,
                "third_party_skipped": third_party_count,
                "resolution_rate": f"{resolution_pct:.1f}%",
                "sample_unresolved": unresolved_targets,
            },
        }

    @staticmethod
    def _build_file_suffix_index(file_paths: set[str]) -> dict[str, list[str]]:
        """Build filename → [full_paths] index for O(1) suffix matching."""
        idx: dict[str, list[str]] = defaultdict(list)
        for fp in file_paths:
            name = fp.rsplit("/", 1)[-1]
            idx[name].append(fp)
        return dict(idx)

    @staticmethod
    def _build_qname_suffix_index(node_by_id: dict[str, dict]) -> dict[str, list[str]]:
        """Build qualified_name_suffix → [node_ids] index for O(1) :: matching."""
        idx: dict[str, list[str]] = defaultdict(list)
        for nid in node_by_id:
            if "::" in nid:
                suffix = nid.split("::", 1)[1]
                idx[suffix].append(nid)
        return dict(idx)

    @staticmethod
    def _tarjan_scc(nodes: set[str], deps: dict[str, set[str]]) -> list[list[str]]:
        """Return strongly connected components via iterative Tarjan's.

        Uses an explicit call stack instead of recursion to avoid
        RecursionError on large graphs.
        """
        index_counter = 0
        stack: list[str] = []
        on_stack: set[str] = set()
        index_map: dict[str, int] = {}
        lowlink: dict[str, int] = {}
        result: list[list[str]] = []

        for root in sorted(nodes):
            if root in index_map:
                continue

            # Explicit call stack: (node, iterator_over_neighbors, phase)
            # We store the neighbor iterator so we can resume after returning
            # from a "recursive" call.
            call_stack: list[tuple[str, list[str], int]] = []

            # "Enter" root
            index_map[root] = lowlink[root] = index_counter
            index_counter += 1
            stack.append(root)
            on_stack.add(root)

            neighbors = [w for w in deps.get(root, set()) if w in nodes]
            call_stack.append((root, neighbors, 0))

            while call_stack:
                v, v_neighbors, idx = call_stack[-1]

                if idx < len(v_neighbors):
                    w = v_neighbors[idx]
                    # Advance the index for next time we resume this frame
                    call_stack[-1] = (v, v_neighbors, idx + 1)

                    if w not in index_map:
                        # "Recurse" into w
                        index_map[w] = lowlink[w] = index_counter
                        index_counter += 1
                        stack.append(w)
                        on_stack.add(w)
                        w_neighbors = [u for u in deps.get(w, set()) if u in nodes]
                        call_stack.append((w, w_neighbors, 0))
                    elif w in on_stack:
                        lowlink[v] = min(lowlink[v], index_map[w])
                else:
                    # All neighbors processed — "return" from this frame
                    call_stack.pop()
                    if call_stack:
                        parent = call_stack[-1][0]
                        lowlink[parent] = min(lowlink[parent], lowlink[v])

                    # Check if v is an SCC root
                    if lowlink[v] == index_map[v]:
                        component: list[str] = []
                        while True:
                            w = stack.pop()
                            on_stack.discard(w)
                            component.append(w)
                            if w == v:
                                break
                        result.append(component)

        return result

    # ------------------------------------------------------------------
    # Cross-module pattern detection
    # ------------------------------------------------------------------
    @staticmethod
    def _is_test_file(file_path: str) -> bool:
        """Check if a file path looks like a test file."""
        name = file_path.split("/")[-1]
        return (name.startswith("test_")
                or name.endswith("_test.py")
                or "/tests/" in file_path
                or "/test/" in file_path
                or file_path.startswith("tests/")
                or file_path.startswith("test/"))

    def detect_structural_patterns(self) -> list[dict]:
        """Detect groups of files that share similar structural signatures.

        For each file, compute a signature of (type, name_stem) tuples.
        Compare via Jaccard similarity. Group files with >60% overlap.
        Flag deviations where a file in a group is missing expected symbols.
        """
        all_nodes = self.store.get_all_nodes()

        # Build per-file structural signatures
        file_signatures: dict[str, set[tuple[str, str]]] = defaultdict(set)
        for node in all_nodes:
            if node["type"] == "file":
                continue
            name = node["name"]
            # Normalize: strip leading underscore, lowercase
            stem = name.lower()
            if stem.startswith("_") and not stem.startswith("__"):
                stem = stem[1:]
            file_signatures[node["file_path"]].add((node["type"], stem))

        # Filter: exclude test files and files with too few symbols
        candidates = {
            fp: sig for fp, sig in file_signatures.items()
            if len(sig) >= 2 and not self._is_test_file(fp)
        }
        file_paths = sorted(candidates.keys())

        # Compute pairwise Jaccard similarity using inverted index
        # to avoid O(N²) full scan — only compare files sharing signatures
        sig_to_files: dict[tuple[str, str], list[str]] = defaultdict(list)
        for fp, sig in candidates.items():
            for s in sig:
                sig_to_files[s].append(fp)

        # Only compare file pairs that share at least one signature element
        pair_shared: Counter[tuple[str, str]] = Counter()
        for sig_key, fps in sig_to_files.items():
            if len(fps) > 100:
                continue  # Skip overly common signatures (noise)
            for i, a in enumerate(fps):
                for b in fps[i + 1:]:
                    key = (a, b) if a < b else (b, a)
                    pair_shared[key] += 1

        similar_pairs: list[tuple[str, str, float, set[tuple[str, str]]]] = []
        for (fp_a, fp_b), shared_count in pair_shared.items():
            sig_a = candidates[fp_a]
            sig_b = candidates[fp_b]
            # Quick check: shared_count / max(len) gives upper bound on Jaccard
            if shared_count / max(len(sig_a), len(sig_b)) < 0.6:
                continue
            intersection = sig_a & sig_b
            union = sig_a | sig_b
            if not union:
                continue
            jaccard = len(intersection) / len(union)
            if jaccard >= 0.6:
                similar_pairs.append((fp_a, fp_b, jaccard, intersection))

        # Group files by connected components of similarity
        # Build adjacency for union-find
        parent: dict[str, str] = {}

        def find(x: str) -> str:
            while parent.get(x, x) != x:
                parent[x] = parent.get(parent[x], parent[x])
                x = parent[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        for fp_a, fp_b, _, _ in similar_pairs:
            union(fp_a, fp_b)

        # Collect groups
        groups: dict[str, list[str]] = defaultdict(list)
        for fp in file_paths:
            if any(fp == a or fp == b for a, b, _, _ in similar_pairs):
                groups[find(fp)].append(fp)

        # Build result patterns
        patterns: list[dict] = []
        for root, files in groups.items():
            if len(files) < 2:
                continue

            # Find shared signature across all files in group
            shared = candidates[files[0]].copy()
            for fp in files[1:]:
                shared &= candidates[fp]

            if len(shared) < 3:
                continue

            # Compute average similarity
            sims = []
            for fp_a, fp_b, sim, _ in similar_pairs:
                if fp_a in files and fp_b in files:
                    sims.append(sim)
            avg_sim = sum(sims) / len(sims) if sims else 0.0

            # Find deviations
            # Full union of all signatures in the group
            full_union: set[tuple[str, str]] = set()
            for fp in files:
                full_union |= candidates[fp]

            deviations: list[dict] = []
            for fp in files:
                missing = full_union - candidates[fp]
                # Only flag missing symbols that appear in majority of group members
                threshold = len(files) * 0.6
                for sym_type, sym_name in missing:
                    count = sum(1 for f in files if (sym_type, sym_name) in candidates[f])
                    if count >= threshold:
                        deviations.append({
                            "file": fp,
                            "missing": f"{sym_type}: {sym_name}",
                        })

            shared_pattern = sorted(f"{t}: {n}" for t, n in shared)
            patterns.append({
                "type": "structural_group",
                "files": sorted(files),
                "shared_pattern": shared_pattern,
                "similarity": round(avg_sim, 2),
                "deviations": deviations,
            })

        patterns.sort(key=lambda p: p["similarity"], reverse=True)
        return patterns[:20]

    def _layer_label(self, layer: int, files: list[str]) -> str:
        if layer == -1:
            return "cycle"

        # Analyze package distribution
        pkg_counts: Counter[str] = Counter()
        for f in files:
            parts = f.split("/")
            pkg = parts[0] if len(parts) > 1 else "(root)"
            pkg_counts[pkg] += 1

        # Check for known roles via filenames
        names = {f.split("/")[-1].removesuffix(".py") for f in files}
        utility_names = {"utils", "helpers", "util", "common", "config", "constants", "settings"}
        model_names = {"models", "schemas", "types", "entities"}
        entry_names = {"cli", "main", "__main__", "app", "server", "api"}

        if names & entry_names:
            return "entry_points"
        if names & model_names and not (names & entry_names):
            return "data_layer"
        if names & utility_names and not (names & entry_names) and layer == 0:
            return "foundation"

        # Use dominant package name
        if pkg_counts:
            top_pkg, top_count = pkg_counts.most_common(1)[0]
            if top_count > len(files) * 0.5 and top_pkg != "(root)":
                return top_pkg.replace("/", ".")

        if layer == 0:
            return "foundation"
        return f"layer_{layer}"

    def _layer_description(self, layer: int, files: list[str] | None = None) -> str:
        if layer == -1:
            return "Circular dependencies — these files form a cycle and cannot be cleanly layered."

        files = files or []

        # Gather package breakdown
        pkg_counts: Counter[str] = Counter()
        for f in files:
            parts = f.split("/")
            pkg = "/".join(parts[:-1]) if len(parts) > 1 else "(root)"
            pkg_counts[pkg] += 1
        pkg_summary = ", ".join(f"{pkg} ({ct})" for pkg, ct in pkg_counts.most_common(3))

        # Notable files (entry points, configs)
        notable_stems = {"cli", "main", "app", "server", "api", "__init__", "config", "settings"}
        notable = [
            f.split("/")[-1]
            for f in files
            if f.split("/")[-1].removesuffix(".py") in notable_stems
        ]

        base = {
            0: "Foundation — leaf modules with no internal dependencies. Safest to modify.",
            1: "Core — depends only on foundation. Changes here may affect upper layers.",
        }.get(layer, f"Level {layer} — depends on {layer} lower layer(s). Higher risk of cascading impact.")

        parts = [base]
        if pkg_summary:
            parts.append(f"Packages: {pkg_summary}.")
        if notable:
            parts.append(f"Key files: {', '.join(notable[:5])}.")
        return " ".join(parts)
