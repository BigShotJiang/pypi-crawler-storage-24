"""Hashing, path normalization, and timing helpers."""

from __future__ import annotations

import hashlib
import time
from contextlib import contextmanager
from pathlib import Path

from codebrain.logging import get_logger

_log = get_logger("utils")


def content_hash(data: bytes) -> str:
    """Return the SHA-256 hex digest of *data*."""
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path) -> str:
    """Return the SHA-256 hex digest of the file at *path*."""
    return content_hash(path.read_bytes())


def normalize_path(path: Path, repo_root: Path) -> str:
    """Return *path* relative to *repo_root* using forward slashes."""
    return path.relative_to(repo_root).as_posix()


def is_test_file(file_path: str) -> bool:
    """Return True if *file_path* looks like a test file.

    Checks for: test_ prefix, Test prefix (e.g. TestFoo.py), _test.py suffix,
    conftest.py, /tests/ or /test/ anywhere in the path, and tests/ or test/
    at the start.
    """
    name = file_path.rsplit("/", 1)[-1]
    if name.startswith("test_") or name.startswith("Test") or name == "conftest.py":
        return True
    if name.endswith("_test.py"):
        return True
    if "/tests/" in file_path or "/test/" in file_path:
        return True
    if file_path.startswith("tests/") or file_path.startswith("test/"):
        return True
    return False


@contextmanager
def timed(label: str | None = None):
    """Context manager that yields a dict and fills in ``elapsed`` on exit."""
    result: dict = {}
    start = time.perf_counter()
    try:
        yield result
    finally:
        result["elapsed"] = time.perf_counter() - start
        if label:
            _log.debug("%s: %.3fs", label, result["elapsed"])
