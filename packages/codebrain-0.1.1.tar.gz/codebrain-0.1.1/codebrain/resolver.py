"""Python module resolver.

Resolves import strings (e.g. "mypackage.utils.helper") to actual
node IDs in the graph (e.g. "mypackage/utils.py::helper").

This replaces heuristic name matching with deterministic resolution
based on the actual file structure of the indexed repository.
"""

from __future__ import annotations

from pathlib import PurePosixPath

from codebrain.graph.store import GraphStore


class ModuleResolver:
    """Resolves import target strings to graph node IDs."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self._file_index: dict[str, str] | None = None  # module_path → file_path
        self._node_index: dict[str, list[str]] | None = None  # name → [node_ids]

    def _build_indexes(self) -> None:
        """Build lookup indexes from the graph (lazy, cached)."""
        if self._file_index is not None:
            return

        self._file_index = {}
        self._node_index = {}

        all_nodes = self.store.get_all_nodes()
        for node in all_nodes:
            # File index: map dotted module paths to file paths
            if node["type"] == "file":
                fp = node["file_path"]
                # mypackage/utils.py → mypackage.utils
                mod = fp.replace("/", ".").removesuffix(".py")
                if mod.endswith(".__init__"):
                    mod = mod.removesuffix(".__init__")
                self._file_index[mod] = fp
            else:
                # Node index: map names to node IDs
                name = node["name"]
                if name not in self._node_index:
                    self._node_index[name] = []
                self._node_index[name].append(node["id"])

                # Also index by qualified name
                qname = node["qualified_name"]
                if qname != name:
                    if qname not in self._node_index:
                        self._node_index[qname] = []
                    self._node_index[qname].append(node["id"])

    def resolve(self, import_target: str, source_file: str | None = None) -> list[str]:
        """Resolve an import target string to matching node IDs.

        Args:
            import_target: The import string, e.g. "os.path.join",
                "mypackage.utils.helper", "helper"
            source_file: The file where the import occurs (for relative imports)

        Returns:
            List of matching node IDs, best match first.
        """
        self._build_indexes()
        assert self._file_index is not None
        assert self._node_index is not None

        results: list[str] = []

        # Strategy 1: Direct node ID match
        node = self.store.get_node(import_target)
        if node:
            return [import_target]

        # Strategy 2: The target is "module.symbol" — resolve module to file, find symbol
        parts = import_target.rsplit(".", 1)
        if len(parts) == 2:
            module_path, symbol_name = parts
            file_path = self._file_index.get(module_path)
            if file_path:
                # Look for a node named symbol_name in that file
                file_nodes = self.store.get_nodes_by_file(file_path)
                for n in file_nodes:
                    if n["name"] == symbol_name:
                        results.append(n["id"])
                if results:
                    return results

        # Strategy 3: Full dotted path is a module itself (e.g. "mypackage.utils")
        file_path = self._file_index.get(import_target)
        if file_path:
            file_nodes = self.store.get_nodes_by_file(file_path)
            for n in file_nodes:
                if n["type"] == "file":
                    results.append(n["id"])
            if results:
                return results

        # Strategy 4: Try progressively shorter prefixes
        # e.g. "a.b.c.d" → try "a.b.c" + "d", "a.b" + "c.d", "a" + "b.c.d"
        dotted = import_target
        for i in range(dotted.count("."), 0, -1):
            idx = _nth_dot(dotted, i)
            module_part = dotted[:idx]
            symbol_part = dotted[idx + 1:]
            file_path = self._file_index.get(module_part)
            if file_path:
                file_nodes = self.store.get_nodes_by_file(file_path)
                # Try matching the symbol part
                for n in file_nodes:
                    if n["name"] == symbol_part or n["qualified_name"] == symbol_part:
                        results.append(n["id"])
                if results:
                    return results

        # Strategy 5: Bare name lookup across entire codebase
        if import_target in self._node_index:
            return self._node_index[import_target]

        # Strategy 6: Last component of dotted name
        bare_name = import_target.rsplit(".", 1)[-1]
        if bare_name in self._node_index:
            return self._node_index[bare_name]

        return []

    def resolve_all_edges(self) -> dict:
        """Resolve all edge targets in the graph and return stats.

        This is a batch operation that attempts to resolve every edge
        target to a concrete node ID. Returns resolution statistics.
        """
        self._build_indexes()
        assert self._file_index is not None

        all_nodes = self.store.get_all_nodes()
        total = 0
        resolved = 0
        unresolved_targets: list[str] = []

        for node in all_nodes:
            edges = self.store.get_edges_from(node["id"])
            for edge in edges:
                if edge["type"] in ("CALLS", "IMPORTS", "EXTENDS"):
                    total += 1
                    node_ids = self.resolve(edge["target"], edge["file_path"])
                    if node_ids:
                        resolved += 1
                    else:
                        if edge["target"] not in unresolved_targets:
                            unresolved_targets.append(edge["target"])

        return {
            "total_edges": total,
            "resolved": resolved,
            "unresolved": total - resolved,
            "resolution_rate": round(resolved / max(total, 1), 3),
            "unresolved_targets": sorted(set(unresolved_targets))[:50],
        }


def _nth_dot(s: str, n: int) -> int:
    """Find the index of the nth dot in string s."""
    idx = -1
    for _ in range(n):
        idx = s.index(".", idx + 1)
    return idx
