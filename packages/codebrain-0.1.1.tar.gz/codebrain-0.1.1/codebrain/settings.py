"""Runtime configuration loaded from .codebrain.toml and environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from codebrain.config import (
    CODEBRAIN_DIR,
    DB_FILENAME,
    INDEXABLE_EXTENSIONS,
    SKIP_DIRS,
    WATCHER_DEBOUNCE_SECONDS,
)


@dataclass(slots=True)
class Settings:
    """Resolved configuration for a CodeBrain session."""

    codebrain_dir: str = CODEBRAIN_DIR
    db_filename: str = DB_FILENAME
    skip_dirs: frozenset[str] = SKIP_DIRS
    indexable_extensions: frozenset[str] = INDEXABLE_EXTENSIONS
    watcher_debounce: float = WATCHER_DEBOUNCE_SECONDS
    parallel_threshold: int = 50
    max_workers: int | None = None
    max_file_size_kb: int = 1024  # Skip files larger than this (KB)
    cli_timeout: int = 120  # Seconds before CLI commands time out

    @property
    def db_path(self) -> str:
        return f"{self.codebrain_dir}/{self.db_filename}"


def load_settings(repo_root: Path | None = None) -> Settings:
    """Load settings from .codebrain.toml (if present), overlaid with env vars.

    Precedence: env vars > .codebrain.toml > defaults.
    """
    file_overrides: dict = {}

    if repo_root is not None:
        toml_path = repo_root / ".codebrain.toml"
        if toml_path.is_file():
            try:
                import tomllib
            except ModuleNotFoundError:  # Python < 3.11 fallback guard
                pass
            else:
                with open(toml_path, "rb") as f:
                    data = tomllib.load(f)
                file_overrides = data.get("codebrain", data)

    kwargs: dict = {}

    # From file
    if "skip_dirs" in file_overrides:
        kwargs["skip_dirs"] = frozenset(file_overrides["skip_dirs"])
    if "extensions" in file_overrides:
        kwargs["indexable_extensions"] = frozenset(file_overrides["extensions"])
    if "watcher_debounce" in file_overrides:
        kwargs["watcher_debounce"] = float(file_overrides["watcher_debounce"])
    if "parallel_threshold" in file_overrides:
        kwargs["parallel_threshold"] = int(file_overrides["parallel_threshold"])
    if "max_workers" in file_overrides:
        kwargs["max_workers"] = int(file_overrides["max_workers"])
    if "max_file_size_kb" in file_overrides:
        kwargs["max_file_size_kb"] = int(file_overrides["max_file_size_kb"])
    if "cli_timeout" in file_overrides:
        kwargs["cli_timeout"] = int(file_overrides["cli_timeout"])

    # Environment overrides (highest precedence)
    if val := os.environ.get("CODEBRAIN_SKIP_DIRS"):
        kwargs["skip_dirs"] = frozenset(val.split(","))
    if val := os.environ.get("CODEBRAIN_EXTENSIONS"):
        kwargs["indexable_extensions"] = frozenset(val.split(","))
    if val := os.environ.get("CODEBRAIN_DEBOUNCE"):
        kwargs["watcher_debounce"] = float(val)
    if val := os.environ.get("CODEBRAIN_PARALLEL_THRESHOLD"):
        kwargs["parallel_threshold"] = int(val)
    if val := os.environ.get("CODEBRAIN_MAX_WORKERS"):
        kwargs["max_workers"] = int(val)
    if val := os.environ.get("CODEBRAIN_CLI_TIMEOUT"):
        kwargs["cli_timeout"] = int(val)

    return Settings(**kwargs)
