"""Grok LLM explanation layer for CodeBrain.

Provides AI-generated natural language explanations of structural data
using xAI's Grok API, with key rotation, caching, and graceful degradation.

When the LLM is unavailable (no keys, rate-limited, httpx not installed),
all methods fall back to deterministic narratives from ComprehensionEngine.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from codebrain.config import CODEBRAIN_DIR

_log = logging.getLogger("codebrain.llm")

# ---------------------------------------------------------------------------
# Optional httpx import — graceful degradation when not installed
# ---------------------------------------------------------------------------
try:
    import httpx

    _HTTPX_AVAILABLE = True
except ImportError:
    _HTTPX_AVAILABLE = False


# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = (
    "You are CodeBrain, a structural intelligence engine. Your job is to give "
    "developers architectural insights they can't see by reading code file-by-file. "
    "Rules: (1) Use exact numbers and names from the data — never round or generalize. "
    "(2) Focus on coupling risks, hidden dependencies, and change impact — not obvious things. "
    "(3) Identify what a developer would NOT expect. "
    "(4) Never say 'careful maintenance is needed' or similar filler. "
    "(5) Be direct and specific — every sentence must contain a concrete fact or actionable insight."
)

SYSTEM_EXPLAIN_TEMPLATE = """\
Analyze this codebase's architecture. Focus on:
1. What are the real architectural boundaries? Are they clean or leaking?
2. Which components are over-coupled and would cause cascade failures if changed?
3. What is the single biggest structural risk a developer should know about?

Structural data:
- Summary: {summary}
- Architecture: {architecture}
- Health: {health_summary}
- Key components: {key_components}
- Package dependencies: {pkg_dependencies}
- Recommendations: {recommendations}
"""

MODULE_EXPLAIN_TEMPLATE = """\
Analyze this module's structural role. Answer these questions:
1. Is this a load-bearing module (many dependents) or a leaf module (safe to change)?
2. What would break if this module's API changed?
3. Are there any surprising or indirect dependencies?

Module data:
- Summary: {summary}
- Importance: {importance}
- Dependencies: {dependencies}
- Exports: {exports_summary}
- Top callers: {top_callers}
- Risks: {risks}
"""

SYMBOL_EXPLAIN_TEMPLATE = """\
Analyze this symbol's structural significance. Answer:
1. How central is it — is it a widely-used utility or isolated logic?
2. What is the blast radius if it changes (who calls it, directly and transitively)?
3. Are any of its callers surprising or in unexpected modules?

Symbol data:
- Summary: {summary}
- Importance: {importance}
- Usage: {usage}
- Callers: {callers_summary}
- Caller files: {caller_files}
- Dependencies: {dependencies}
"""

IMPACT_EXPLAIN_TEMPLATE = """\
A developer is about to modify this file. Give a clear risk assessment:
1. State the blast radius: exactly how many files and symbols are affected.
2. Name the most critical affected files and explain why they matter.
3. Give a verdict: "Safe to change", "Change with caution", or "High risk — review carefully".

Impact data:
- File: {file_path}
- Affected files: {affected_file_count}
- Affected file list: {affected_files}
- Impacted nodes: {impacted_node_count}
"""

ANATOMY_EXPLAIN_TEMPLATE = """\
You are explaining this codebase to a brand new developer who has never seen it before.
Think of the codebase like a machine with named parts.

For each subsystem below, write a one-sentence description that a non-expert can understand.
Rules:
1. Start each description with a verb: "Handles...", "Stores...", "Provides..."
2. Mention what would break if this part were removed
3. Do NOT use jargon like "middleware", "abstraction layer", or "facade"
4. Use exact names from the data — never generalize

Codebase purpose: {purpose}

Subsystems:
{subsystems}

Return a JSON array of objects with "slug" and "description" fields. Return ONLY the JSON array.
"""

ASK_TEMPLATE = """\
A developer is asking about the codebase. Answer using the structural data below.
Rules:
1. Be specific — use actual module names, file counts, and symbol names
2. Start with a direct answer to the question (1-2 sentences)
3. Then give supporting evidence from the data
4. Suggest what the developer should look at next
5. Never speculate beyond what the data shows

QUESTION: {question}

STRUCTURAL DATA:
{data}
"""

HEALTH_EXPLAIN_TEMPLATE = """\
Triage this codebase's health. Prioritize what to fix first:
1. What is the #1 structural problem to fix right now?
2. Which hotspots would give the most benefit if refactored?
3. Are the import cycles dangerous or benign?

Health data:
- Score: {score}/100 (Grade: {grade})
- Dead code: {dead_code_count} symbols ({dead_code_ratio})
- Import cycles: {import_cycles}
- High-risk hotspots: {high_risk_hotspots}

Top risk hotspots:
{hotspots}
"""


# ---------------------------------------------------------------------------
# LLMSettings
# ---------------------------------------------------------------------------


@dataclass
class LLMSettings:
    """Configuration for the Grok LLM integration."""

    enabled: bool = False
    api_keys: list[str] = field(default_factory=list)
    model: str = "grok-3-mini-fast"
    base_url: str = "https://api.x.ai/v1"
    max_tokens: int = 1024
    temperature: float = 0.3
    timeout: float = 30.0
    cache_ttl: int = 3600  # seconds


def load_llm_settings(repo_root: Path | None = None) -> LLMSettings:
    """Load LLM settings from .codebrain.toml and environment variables.

    Precedence: env vars > .codebrain.toml > defaults.
    Auto-enables if keys are provided but ``enabled`` is not explicitly set.
    """
    file_overrides: dict[str, Any] = {}
    explicitly_enabled: bool | None = None

    if repo_root is not None:
        toml_path = repo_root / ".codebrain.toml"
        if toml_path.is_file():
            try:
                import tomllib
            except ModuleNotFoundError:
                pass
            else:
                with open(toml_path, "rb") as f:
                    data = tomllib.load(f)
                file_overrides = data.get("llm", {})
                if "enabled" in file_overrides:
                    explicitly_enabled = bool(file_overrides["enabled"])

    kwargs: dict[str, Any] = {}

    # From file
    if "api_keys" in file_overrides:
        kwargs["api_keys"] = list(file_overrides["api_keys"])
    if "model" in file_overrides:
        kwargs["model"] = str(file_overrides["model"])
    if "base_url" in file_overrides:
        kwargs["base_url"] = str(file_overrides["base_url"])
    if "max_tokens" in file_overrides:
        kwargs["max_tokens"] = int(file_overrides["max_tokens"])
    if "temperature" in file_overrides:
        kwargs["temperature"] = float(file_overrides["temperature"])
    if "timeout" in file_overrides:
        kwargs["timeout"] = float(file_overrides["timeout"])
    if "cache_ttl" in file_overrides:
        kwargs["cache_ttl"] = int(file_overrides["cache_ttl"])

    # Environment overrides (highest precedence)
    if val := os.environ.get("CODEBRAIN_LLM_API_KEYS"):
        kwargs["api_keys"] = [k.strip() for k in val.split(",") if k.strip()]
    if val := os.environ.get("CODEBRAIN_LLM_MODEL"):
        kwargs["model"] = val
    if val := os.environ.get("CODEBRAIN_LLM_BASE_URL"):
        kwargs["base_url"] = val
    if val := os.environ.get("CODEBRAIN_LLM_MAX_TOKENS"):
        kwargs["max_tokens"] = int(val)
    if val := os.environ.get("CODEBRAIN_LLM_TEMPERATURE"):
        kwargs["temperature"] = float(val)
    if val := os.environ.get("CODEBRAIN_LLM_TIMEOUT"):
        kwargs["timeout"] = float(val)
    if val := os.environ.get("CODEBRAIN_LLM_CACHE_TTL"):
        kwargs["cache_ttl"] = int(val)
    if val := os.environ.get("CODEBRAIN_LLM_ENABLED"):
        explicitly_enabled = val.lower() in ("1", "true", "yes")

    # Auto-enable: if keys are present but enabled was never set explicitly
    keys = kwargs.get("api_keys", [])
    if explicitly_enabled is not None:
        kwargs["enabled"] = explicitly_enabled
    elif keys:
        kwargs["enabled"] = True

    return LLMSettings(**kwargs)


# ---------------------------------------------------------------------------
# KeyRotator
# ---------------------------------------------------------------------------


class KeyRotator:
    """Round-robin API key rotation with per-key cooldown on rate limits."""

    def __init__(self, keys: list[str], cooldown: float = 60.0) -> None:
        self._keys = list(keys)
        self._cooldown = cooldown
        self._index = 0
        self._cooldowns: dict[str, float] = {}  # key -> cooldown_until timestamp

    @property
    def total(self) -> int:
        return len(self._keys)

    @property
    def available_count(self) -> int:
        now = time.monotonic()
        return sum(1 for k in self._keys if self._cooldowns.get(k, 0) <= now)

    def get_key(self) -> str | None:
        """Return the next available key, or ``None`` if all are on cooldown."""
        if not self._keys:
            return None

        now = time.monotonic()
        for _ in range(len(self._keys)):
            key = self._keys[self._index % len(self._keys)]
            self._index += 1
            if self._cooldowns.get(key, 0) <= now:
                return key

        return None  # All keys on cooldown

    def report_rate_limit(self, key: str) -> None:
        """Put *key* on cooldown for ``self._cooldown`` seconds."""
        self._cooldowns[key] = time.monotonic() + self._cooldown

    def report_success(self, key: str) -> None:
        """Clear any cooldown on *key*."""
        self._cooldowns.pop(key, None)


# ---------------------------------------------------------------------------
# ResponseCache (SQLite-backed)
# ---------------------------------------------------------------------------


class ResponseCache:
    """SQLite-backed LLM response cache with TTL expiry.

    Stored in ``.codebrain/llm_cache.db``, separate from the graph DB.
    """

    def __init__(self, cache_dir: Path | str, ttl: int = 3600) -> None:
        self._ttl = ttl
        cache_path = Path(cache_dir) / "llm_cache.db"
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(cache_path))
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS cache ("
            "  key TEXT PRIMARY KEY,"
            "  response TEXT NOT NULL,"
            "  created_at REAL NOT NULL"
            ")"
        )
        self._conn.commit()

    @staticmethod
    def make_key(prompt_type: str, structural_data: str) -> str:
        """Generate a cache key from prompt type and structural data hash."""
        raw = f"{prompt_type}:{structural_data}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, key: str) -> str | None:
        """Return cached response if it exists and hasn't expired."""
        row = self._conn.execute(
            "SELECT response, created_at FROM cache WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        response, created_at = row
        if time.time() - created_at > self._ttl:
            self._conn.execute("DELETE FROM cache WHERE key = ?", (key,))
            self._conn.commit()
            return None
        return response

    def put(self, key: str, response: str) -> None:
        """Store a response in the cache."""
        self._conn.execute(
            "INSERT OR REPLACE INTO cache (key, response, created_at) VALUES (?, ?, ?)",
            (key, response, time.time()),
        )
        self._conn.commit()

    def clear(self) -> None:
        """Remove all cached entries."""
        self._conn.execute("DELETE FROM cache")
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()


# ---------------------------------------------------------------------------
# Grok API caller
# ---------------------------------------------------------------------------


async def _call_grok(
    prompt: str,
    settings: LLMSettings,
    rotator: KeyRotator,
    system_prompt: str | None = None,
) -> str | None:
    """Call the Grok API asynchronously. Returns the response text or None on failure."""
    if not _HTTPX_AVAILABLE:
        _log.warning("httpx not installed — LLM calls disabled")
        return None

    key = rotator.get_key()
    if key is None:
        _log.warning("All API keys on cooldown")
        return None

    payload = {
        "model": settings.model,
        "messages": [
            {"role": "system", "content": system_prompt or _SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": settings.max_tokens,
        "temperature": settings.temperature,
    }

    for attempt in range(2):  # retry once on 429
        try:
            async with httpx.AsyncClient(timeout=settings.timeout) as client:
                resp = await client.post(
                    f"{settings.base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )

            if resp.status_code == 429:
                rotator.report_rate_limit(key)
                _log.info("Rate limited on key ...%s, rotating", key[-4:] if len(key) > 4 else "****")
                key = rotator.get_key()
                if key is None:
                    _log.warning("All API keys on cooldown after retry")
                    return None
                continue

            if resp.status_code != 200:
                _log.warning("Grok API returned %d: %s", resp.status_code, resp.text[:200])
                return None

            data = resp.json()
            text = data["choices"][0]["message"]["content"]
            rotator.report_success(key)
            return text

        except Exception as exc:
            _log.warning("Grok API call failed: %s", exc)
            return None

    return None


def _call_grok_sync(
    prompt: str,
    settings: LLMSettings,
    rotator: KeyRotator,
    system_prompt: str | None = None,
) -> str | None:
    """Synchronous wrapper around _call_grok.

    Handles both CLI (no running loop) and FastAPI (running loop) contexts.
    """
    import asyncio

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        # Running inside an event loop (e.g., FastAPI) — use thread pool
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, _call_grok(prompt, settings, rotator, system_prompt))
            return future.result(timeout=settings.timeout + 5)
    else:
        return asyncio.run(_call_grok(prompt, settings, rotator, system_prompt))


# ---------------------------------------------------------------------------
# LLMNarrator
# ---------------------------------------------------------------------------


class LLMNarrator:
    """Wraps ComprehensionEngine, adds LLM-generated explanations to narratives."""

    def __init__(
        self,
        store: Any,
        settings: LLMSettings,
        cache_dir: Path | str | None = None,
    ) -> None:
        from codebrain.comprehension import ComprehensionEngine

        self._store = store
        self._comp = ComprehensionEngine(store)
        self._settings = settings
        self._rotator = KeyRotator(settings.api_keys)
        self._cache: ResponseCache | None = None
        if cache_dir is not None and settings.cache_ttl > 0:
            self._cache = ResponseCache(cache_dir, ttl=settings.cache_ttl)

    def _graph_stats_hash(self) -> str:
        """Return a short hash of the current graph stats (node/edge counts).

        This ensures that cached LLM responses are invalidated when the
        codebase is re-indexed (node or edge counts change).
        """
        stats = self._store.get_stats()
        raw = json.dumps(stats, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()[:8]

    def _get_explanation(self, prompt_type: str, prompt: str, structural_hash: str) -> str | None:
        """Check cache, call Grok if miss, cache result."""
        if not self._settings.enabled:
            return None

        # Include graph stats in the cache key so re-indexing invalidates
        stats_hash = self._graph_stats_hash()
        composite_hash = f"{stats_hash}:{structural_hash}"

        # Check cache
        if self._cache is not None:
            cache_key = ResponseCache.make_key(prompt_type, composite_hash)
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        # Call Grok
        result = _call_grok_sync(prompt, self._settings, self._rotator)

        # Cache result
        if result is not None and self._cache is not None:
            cache_key = ResponseCache.make_key(prompt_type, composite_hash)
            self._cache.put(cache_key, result)

        return result

    def explain_system(self) -> dict:
        """System-level narrative + LLM explanation."""
        narrative = self._comp.system_narrative()
        # Gather package dependency info from system overview
        overview = self._comp.system_overview()
        pkg_deps = {
            name: info.get("depends_on", [])
            for name, info in overview.get("packages", {}).items()
            if info.get("depends_on")
        }
        prompt = SYSTEM_EXPLAIN_TEMPLATE.format(
            summary=narrative["summary"],
            architecture=narrative["architecture"],
            health_summary=narrative["health_summary"],
            key_components=json.dumps(narrative["key_components"]),
            pkg_dependencies=json.dumps(pkg_deps) if pkg_deps else "None",
            recommendations=", ".join(narrative["recommendations"]),
        )
        structural_hash = hashlib.sha256(json.dumps(narrative, sort_keys=True).encode()).hexdigest()
        explanation = self._get_explanation("system", prompt, structural_hash)
        return {**narrative, "llm_explanation": explanation}

    def explain_module(self, file_path: str) -> dict:
        """Module-level narrative + LLM explanation."""
        narrative = self._comp.module_narrative(file_path)
        if "error" in narrative:
            return narrative
        prompt = MODULE_EXPLAIN_TEMPLATE.format(
            summary=narrative["summary"],
            importance=narrative["importance"],
            dependencies=narrative["dependencies"],
            exports_summary=narrative["exports_summary"],
            top_callers=narrative.get("top_callers", "None"),
            risks=", ".join(narrative["risks"]),
        )
        structural_hash = hashlib.sha256(json.dumps(narrative, sort_keys=True).encode()).hexdigest()
        explanation = self._get_explanation("module", prompt, structural_hash)
        return {**narrative, "llm_explanation": explanation}

    def explain_symbol(self, node_id: str) -> dict:
        """Symbol-level narrative + LLM explanation."""
        narrative = self._comp.symbol_narrative(node_id)
        if "error" in narrative:
            return narrative
        prompt = SYMBOL_EXPLAIN_TEMPLATE.format(
            summary=narrative["summary"],
            importance=narrative["importance"],
            usage=narrative["usage"],
            callers_summary=narrative["callers_summary"],
            caller_files=json.dumps(narrative.get("caller_files", [])),
            dependencies=narrative["dependencies"],
        )
        structural_hash = hashlib.sha256(json.dumps(narrative, sort_keys=True).encode()).hexdigest()
        explanation = self._get_explanation("symbol", prompt, structural_hash)
        return {**narrative, "llm_explanation": explanation}

    def explain_impact(self, file_path: str) -> dict:
        """Change impact summary + LLM explanation."""
        summary = self._comp.change_summary(file_path)
        prompt = IMPACT_EXPLAIN_TEMPLATE.format(
            file_path=summary["file_path"],
            affected_file_count=summary["affected_file_count"],
            affected_files=", ".join(summary["affected_files"][:20]),
            impacted_node_count=len(summary["impacted_nodes"]),
        )
        structural_hash = hashlib.sha256(json.dumps(summary, sort_keys=True).encode()).hexdigest()
        explanation = self._get_explanation("impact", prompt, structural_hash)
        return {**summary, "llm_explanation": explanation}

    def explain_anatomy(self) -> dict:
        """Codebase anatomy + LLM-enhanced subsystem descriptions."""
        anatomy = self._comp.codebase_anatomy()

        # Format subsystems for the prompt
        sub_lines = []
        for sub in anatomy.get("subsystems", []):
            sub_lines.append(
                f"- {sub['name']} (slug={sub['slug']}, role={sub['role']}, "
                f"files={sub['file_count']}, symbols={sub['symbol_count']}, "
                f"importance={sub['importance_label']}, "
                f"top_symbols={', '.join(sub['top_symbols'][:3])})"
            )
        prompt = ANATOMY_EXPLAIN_TEMPLATE.format(
            purpose=anatomy.get("purpose", ""),
            subsystems="\n".join(sub_lines) if sub_lines else "(none)",
        )
        structural_hash = hashlib.sha256(
            json.dumps(anatomy, sort_keys=True, default=str).encode()
        ).hexdigest()
        explanation = self._get_explanation("anatomy", prompt, structural_hash)

        # Try to overlay LLM descriptions onto subsystems
        if explanation:
            try:
                # Extract JSON from response (handle markdown code fences)
                text = explanation.strip()
                if text.startswith("```"):
                    text = text.split("\n", 1)[1] if "\n" in text else text[3:]
                    text = text.rsplit("```", 1)[0]
                descriptions = json.loads(text)
                slug_desc = {d["slug"]: d["description"] for d in descriptions}
                for sub in anatomy.get("subsystems", []):
                    if sub["slug"] in slug_desc:
                        sub["llm_description"] = slug_desc[sub["slug"]]
            except (json.JSONDecodeError, KeyError, TypeError):
                pass  # Keep deterministic descriptions

        return {**anatomy, "llm_explanation": explanation}

    def explain_health(self) -> dict:
        """Health score + LLM explanation with prioritized recommendations."""
        health = self._comp.health_score()
        hotspots = self._comp.risk_hotspots(top_n=10)
        hotspot_lines = []
        for h in hotspots[:5]:
            hotspot_lines.append(
                f"  - {h['name']} ({h['type']}): risk={h['risk_score']}, "
                f"{h['direct_dependents']} dependents, {h['affected_files']} affected files"
            )
        details = health["details"]
        prompt = HEALTH_EXPLAIN_TEMPLATE.format(
            score=health["score"],
            grade=health["grade"],
            dead_code_count=details["dead_code_count"],
            dead_code_ratio=f"{details['dead_code_ratio']:.1%}",
            import_cycles=details["import_cycles"],
            high_risk_hotspots=details["high_risk_hotspots"],
            hotspots="\n".join(hotspot_lines) if hotspot_lines else "  (none)",
        )
        structural_hash = hashlib.sha256(
            json.dumps({"health": health, "hotspots": hotspots}, sort_keys=True).encode()
        ).hexdigest()
        explanation = self._get_explanation("health", prompt, structural_hash)
        return {**health, "hotspots": hotspots, "llm_explanation": explanation}

    def ask(self, question: str) -> dict:
        """Answer a natural language question with LLM enhancement.

        Calls ``ComprehensionEngine.answer_question()`` for structural data,
        then enhances the answer with an LLM-generated explanation.
        Falls back to the deterministic answer if LLM is unavailable.
        """
        result = self._comp.answer_question(question)

        # Format structural data for the LLM prompt
        data_str = json.dumps(
            {"intent": result["intent"], "answer": result["answer"],
             "data": result["data"], "sources": result["sources"]},
            indent=2, default=str,
        )
        prompt = ASK_TEMPLATE.format(question=question, data=data_str)
        structural_hash = hashlib.sha256(data_str.encode()).hexdigest()
        llm_answer = self._get_explanation("ask", prompt, structural_hash)
        result["llm_answer"] = llm_answer
        return result

    def status(self) -> dict:
        """Return LLM configuration status."""
        return {
            "enabled": self._settings.enabled,
            "model": self._settings.model,
            "keys_configured": len(self._settings.api_keys),
            "keys_available": self._rotator.available_count,
            "httpx_installed": _HTTPX_AVAILABLE,
        }
