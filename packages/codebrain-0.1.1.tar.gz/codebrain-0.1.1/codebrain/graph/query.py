"""QueryEngine — high-level queries over the knowledge graph."""

from __future__ import annotations

from collections import deque

from codebrain.graph.store import GraphStore
from codebrain.utils import is_test_file


class QueryEngine:
    """Provides structured queries on top of GraphStore."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self._edge_cache: dict[str, list[dict]] = {}
        self._reverse_index_loaded = False

    def get_all_edges_from_nodes(self, node_ids: set[str]) -> list[dict]:
        """Delegate bulk edge fetch to store."""
        return self.store.get_all_edges_from_nodes(node_ids)

    def preload_reverse_index(self) -> None:
        """Preload all edges into the reverse cache for bulk operations.

        After calling this, _get_incoming_edges() will return results from
        the pre-built index without any additional DB queries.
        """
        if self._reverse_index_loaded:
            return
        all_edges = self.store.get_all_edges()
        all_nodes = self.store.get_all_nodes()
        # Build lookup: node_id -> (name, qualified_name)
        node_names: dict[str, tuple[str, str]] = {}
        for n in all_nodes:
            node_names[n["id"]] = (n["name"], n["qualified_name"])
        # Build reverse index: key -> list of edges where key is in (target)
        reverse: dict[str, list[dict]] = {}
        for e in all_edges:
            reverse.setdefault(e["target"], []).append(e)
        # Now populate _edge_cache: for each node_id, collect edges targeting
        # the node by its id, name, or qualified_name
        # Also build a type lookup so we can handle self.X backward compat
        node_types: dict[str, str] = {}
        for n in all_nodes:
            node_types[n["id"]] = n["type"]
        for node_id, (name, qname) in node_names.items():
            edges = list(reverse.get(node_id, []))
            if name != node_id:
                edges.extend(reverse.get(name, []))
            if qname != name and qname != node_id:
                edges.extend(reverse.get(qname, []))
            self._edge_cache[node_id] = edges
        # Backward compat: map legacy "self.X" edge targets to method nodes.
        # Must match by class context to avoid cross-class false positives:
        # e.g. ClassA.run() calling self.helper should NOT map to ClassB.helper().
        method_ids_by_name: dict[str, list[str]] = {}
        for nid, (name, _qname) in node_names.items():
            if node_types.get(nid) == "method":
                method_ids_by_name.setdefault(name, []).append(nid)
        for e in all_edges:
            if e["target"].startswith("self."):
                method_name = e["target"][5:]
                # Extract class name from the source node's qualified name
                source_info = node_names.get(e["source"])
                source_class = None
                if source_info:
                    parts = source_info[1].rsplit(".", 1)  # qualified_name
                    if len(parts) == 2:
                        source_class = parts[0]
                for nid in method_ids_by_name.get(method_name, []):
                    # Only match if method belongs to the same class as the caller
                    if source_class:
                        nid_qname = node_names.get(nid, ("", ""))[1]
                        nid_class = nid_qname.rsplit(".", 1)[0] if "." in nid_qname else None
                        if nid_class and nid_class != source_class:
                            continue
                    self._edge_cache.setdefault(nid, []).append(e)
        self._reverse_index_loaded = True

    # ------------------------------------------------------------------
    # Node resolution helpers
    # ------------------------------------------------------------------
    def _expand_to_node_ids(self, node_id: str) -> list[str]:
        """If *node_id* is a file path, return IDs of all symbols in that file.
        Otherwise return [node_id] as-is."""
        if "::" not in node_id and ("/" in node_id or "\\" in node_id or node_id.endswith(".py")):
            nodes = self.store.get_nodes_by_file(node_id)
            if nodes:
                return [n["id"] for n in nodes]
        return [node_id]

    def _get_incoming_edges(self, node_id: str) -> list[dict]:
        """Get all incoming edges to a node, matching by ID and name (cached).

        For method nodes, also matches legacy ``self.X`` edge targets from
        indexes built before self-resolution was added to the parser.
        """
        if node_id in self._edge_cache:
            return self._edge_cache[node_id]
        node = self.store.get_node(node_id)
        if node:
            result = self.store.get_edges_to_symbol(node_id, node["name"], node["qualified_name"])
            # Backward compat: old indexes may store target="self.X"
            if node["type"] == "method":
                self_target = f"self.{node['name']}"
                self_edges = self.store.get_edges_to(self_target)
                # Deduplicate: get_edges_to_symbol may have already found some
                seen_ids = {e["id"] for e in result}
                for e in self_edges:
                    if e["id"] not in seen_ids:
                        seen_ids.add(e["id"])
                        result.append(e)
                result = list(result)
        else:
            result = self.store.get_edges_to(node_id)
        self._edge_cache[node_id] = result
        return result

    def resolve_node(self, name: str) -> list[dict]:
        """Find nodes matching *name* — exact ID, exact name, or substring."""
        # Try exact ID first
        node = self.store.get_node(name)
        if node:
            return [node]

        # Exact name match
        nodes = self.store.get_nodes_by_name(name)
        if nodes:
            return nodes

        # Substring / qualified name search
        return self.search_nodes(name)

    # ------------------------------------------------------------------
    # Call chain (forward)
    # ------------------------------------------------------------------
    def _resolve_call_target(self, source_id: str, target: str) -> str:
        """Resolve an edge target that may be unqualified (e.g. ``self.X`` or ``ClassName.X``).

        For ``self.X`` targets, infers the class from the source node's qualified name
        and looks up the corresponding method node.
        """
        if target.startswith("self."):
            method_name = target[5:]
            # Infer class from source: "file.py::ClassName.method" → ClassName
            if "::" in source_id:
                qname = source_id.split("::", 1)[1]
                parts = qname.rsplit(".", 1)
                if len(parts) == 2:
                    class_name = parts[0]
                    file_prefix = source_id.split("::", 1)[0]
                    candidate = f"{file_prefix}::{class_name}.{method_name}"
                    if self.store.get_node(candidate):
                        return candidate
        # Try resolving by qualified_name or name if target has no `::`
        if "::" not in target:
            # Try qualified_name match first (e.g. "ClassName.method")
            rows = self.store.conn.execute(
                "SELECT id FROM nodes WHERE qualified_name = ?", (target,)
            ).fetchall()
            if len(rows) == 1:
                return rows[0]["id"]

            # For attribute chains like "obj.attr.method", try the last
            # two segments as "Class.method" qualified name
            if "." in target:
                parts = target.split(".")
                # Try last two parts: "Class.method"
                if len(parts) >= 2:
                    suffix = f"{parts[-2]}.{parts[-1]}"
                    rows = self.store.conn.execute(
                        "SELECT id FROM nodes WHERE qualified_name = ?", (suffix,)
                    ).fetchall()
                    if len(rows) == 1:
                        return rows[0]["id"]
                # Try just the last part as a bare name
                last = parts[-1]
                nodes = self.store.get_nodes_by_name(last)
                if len(nodes) == 1:
                    return nodes[0]["id"]
            else:
                # Fallback to name match
                nodes = self.store.get_nodes_by_name(target)
                if len(nodes) == 1:
                    return nodes[0]["id"]
        return target

    def get_call_chain(self, node_id: str, max_depth: int = 10) -> list[dict]:
        """BFS forward through CALLS edges from *node_id*.

        Returns a list of dicts: {node_id, depth, edge_type}.
        """
        visited: set[str] = {node_id}
        queue: deque[tuple[str, int]] = deque([(node_id, 0)])
        result: list[dict] = []

        while queue:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            edges = self.store.get_edges_from(current)
            for edge in edges:
                if edge["type"] == "CALLS":
                    resolved = self._resolve_call_target(current, edge["target"])
                    # Skip unresolved targets (no :: means not a real node ID)
                    if "::" not in resolved:
                        continue
                    if resolved not in visited:
                        visited.add(resolved)
                        result.append({
                            "node_id": resolved,
                            "depth": depth + 1,
                            "from": current,
                            "edge_type": edge["type"],
                        })
                        queue.append((resolved, depth + 1))

        return result

    # ------------------------------------------------------------------
    # Reverse dependencies
    # ------------------------------------------------------------------
    def get_reverse_dependencies(self, node_id: str) -> list[dict]:
        """All nodes that CALL or IMPORT *node_id*.

        If *node_id* looks like a file path (contains '/' or '\\' and no '::'),
        expands to all symbols in that file and collects reverse deps for each.
        """
        target_ids = self._expand_to_node_ids(node_id)
        seen: set[tuple[str, str, int]] = set()
        results: list[dict] = []
        for tid in target_ids:
            for edge in self._get_incoming_edges(tid):
                if edge["type"] in ("CALLS", "IMPORTS"):
                    key = (edge["source"], edge["type"], edge["line"])
                    if key not in seen:
                        seen.add(key)
                        results.append({
                            "node_id": edge["source"],
                            "edge_type": edge["type"],
                            "line": edge["line"],
                            "file_path": edge["file_path"],
                        })
        return results

    # ------------------------------------------------------------------
    # Impact analysis
    # ------------------------------------------------------------------
    def impact_of_change(self, node_id: str, max_depth: int = 10) -> list[dict]:
        """Transitive reverse dependencies — what could break if *node_id* changes.

        If *node_id* is a file path, seeds the BFS from all symbols in the file.
        """
        seed_ids = self._expand_to_node_ids(node_id)
        visited: set[str] = set(seed_ids)
        queue: deque[tuple[str, int]] = deque([(sid, 0) for sid in seed_ids])
        result: list[dict] = []

        while queue:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            # Look at all incoming CALLS and IMPORTS edges
            edges = self._get_incoming_edges(current)
            for edge in edges:
                if edge["type"] in ("CALLS", "IMPORTS") and edge["source"] not in visited:
                    visited.add(edge["source"])
                    result.append({
                        "node_id": edge["source"],
                        "depth": depth + 1,
                        "edge_type": edge["type"],
                        "via": current,
                    })
                    queue.append((edge["source"], depth + 1))

        return result

    # ------------------------------------------------------------------
    # Dead code detection
    # ------------------------------------------------------------------

    # Decorators that mark framework entry points (not dead code)
    _FRAMEWORK_DECORATORS = frozenset({
        "pytest.fixture", "fixture",
        "click.command", "click.group", "command", "group",
        "app.get", "app.post", "app.put", "app.delete", "app.route",
        "app.exception_handler",
        "app.on_event", "on_event", "app.before_request", "app.after_request",
        "app.errorhandler", "app.teardown_appcontext",
        "router.get", "router.post", "router.put", "router.delete", "router.patch",
        "celery.task", "shared_task", "task",
        "middleware", "app.middleware",
        "signal", "receiver",
        "admin.register", "register",
        "login_required", "permission_required", "requires_auth",
        "lru_cache", "cache", "cached_property",
        "contextmanager", "asynccontextmanager",
        "overload", "typing.overload",
        "validator", "field_validator", "model_validator",
        "computed_field", "field_serializer",
        "callback", "on_message", "on_connect", "on_disconnect",
        "subscriber", "listener", "hook",
        "blueprint.route", "bp.route",
        "mcp.tool",
        "property", "staticmethod", "classmethod", "abstractmethod",
        "dataclass",
        "_safe_command", "_safe_tool",
    })

    @staticmethod
    def _decorator_matches(dec: str, pattern: str) -> bool:
        """Check if decorator *dec* matches *pattern* on word boundaries.

        Matches when the pattern is the full decorator, or appears at the start
        followed by ``(``, or appears after a ``.`` followed by ``(`` or end-of-string.
        Does NOT match when the pattern is merely a substring of a longer identifier
        (e.g. ``"property"`` must not match ``"my_property_setter"``).
        """
        # Strip the decorator down to the callable part (before any '(')
        dec_base = dec.split("(", 1)[0]

        # Exact match: @property == property, @app.get == app.get
        if dec_base == pattern:
            return True

        # Pattern at the tail after a dot: @something.app.get matches "app.get"
        if dec_base.endswith("." + pattern):
            return True

        return False

    def _is_framework_entry(self, node: dict, contains_targets: set[str]) -> bool:
        """Return True if *node* is a framework entry point (should not be flagged as dead).

        Checks for: test files/functions, CLI decorators, API routes,
        fixture decorators, class methods (used via their class), etc.
        """
        import json as _json

        name = node["name"]
        file_path = node["file_path"]
        raw_decorators = node.get("decorators") or []
        # Decorators may be stored as JSON string in SQLite
        if isinstance(raw_decorators, str):
            try:
                raw_decorators = _json.loads(raw_decorators)
            except (ValueError, TypeError):
                raw_decorators = []
        decorators = raw_decorators

        # Test files and test functions/classes
        if is_test_file(file_path):
            return True
        if name.startswith("test_") or name.startswith("Test"):
            return True

        # Framework decorators
        for dec in decorators:
            # Route endpoint decorators extracted by the parser
            if dec.startswith("endpoint:"):
                return True
            for pattern in self._FRAMEWORK_DECORATORS:
                if self._decorator_matches(dec, pattern):
                    return True

        # Methods whose class has incoming edges (used via their class)
        if node["type"] == "method" and node["id"] in contains_targets:
            return True

        return False

    def find_dead_code(self, repo_root: str = "") -> list[dict]:
        """Find nodes with no incoming CALLS or IMPORTS edges.

        Excludes: file nodes, exported symbols, __init__/__main__ entry points,
        framework entry points (tests, fixtures, CLI commands, API routes).
        Uses bulk edge fetch to avoid N+1 queries.

        Each result includes a 'confidence' field:
        - "high": no dynamic patterns, not private, not dunder
        - "medium": file contains dynamic dispatch patterns (getattr, etc.)
        - "low": private function (_name) or plugin/registry file
        """
        all_nodes = self.store.get_all_nodes()
        # Fetch all edges once and build an incoming-edges index
        all_edges = self.store.get_all_edges()
        # Build set of targets that have CALLS or IMPORTS incoming
        has_incoming: set[str] = set()
        # Build set of nodes that are CONTAINS targets (methods owned by classes)
        contains_targets: set[str] = set()
        for e in all_edges:
            if e["type"] in ("CALLS", "IMPORTS"):
                has_incoming.add(e["target"])
            elif e["type"] == "CONTAINS":
                contains_targets.add(e["target"])

        # Also build name->targets and qname->targets maps for unresolved edges
        node_names: dict[str, list[str]] = {}
        node_qnames: dict[str, list[str]] = {}
        for node in all_nodes:
            node_names.setdefault(node["name"], []).append(node["id"])
            node_qnames.setdefault(node["qualified_name"], []).append(node["id"])

        # Build set of exported classes (for public method exemption)
        exported_classes: set[str] = set()
        for node in all_nodes:
            if node["type"] == "class" and node["is_exported"]:
                exported_classes.add(node["id"])

        # Pre-build parent class lookup: method_id -> parent_class_id
        method_parent: dict[str, str] = {}
        for e in all_edges:
            if e["type"] == "CONTAINS" and e["source"] in exported_classes:
                method_parent[e["target"]] = e["source"]

        # Build __all__ names per file for checking unexported but __all__-listed symbols
        all_names_by_file: dict[str, set[str]] = {}
        for node in all_nodes:
            if node["type"] == "variable" and node["name"] == "__all__":
                # The parser marks symbols as exported if in __all__, but for
                # symbols that aren't top-level (nested), we track __all__ files
                all_names_by_file.setdefault(node["file_path"], set())
        # Also check: any node in a file with __all__ that is exported is in __all__
        for node in all_nodes:
            if node["is_exported"] and node["file_path"] in all_names_by_file:
                all_names_by_file[node["file_path"]].add(node["name"])

        # Build set of symbol names/qnames re-exported by __init__.py files.
        # If an __init__.py IMPORTS a symbol, that symbol is part of the
        # package's public API and should not be considered dead.
        init_reexported: set[str] = set()
        for e in all_edges:
            if e["type"] == "IMPORTS":
                src_file = e.get("file_path", "")
                if src_file.replace("\\", "/").endswith("__init__.py"):
                    init_reexported.add(e["target"])

        # Detect __main__.py entry points: if a file is __main__.py, its
        # symbols named 'main' are entry points.  Also, if a __main__.py
        # imports a symbol from another file, that target is an entry point.
        main_entry_targets: set[str] = set()
        for e in all_edges:
            if e["type"] == "IMPORTS":
                src_file = e.get("file_path", "")
                if src_file.replace("\\", "/").endswith("__main__.py"):
                    main_entry_targets.add(e["target"])

        dead: list[dict] = []
        for node in all_nodes:
            # Skip file-level nodes and entry points
            if node["type"] == "file":
                continue
            if node["is_exported"]:
                continue
            if node["name"] in ("__init__", "__main__", "main"):
                continue
            if node["name"].startswith("__") and node["name"].endswith("__"):
                continue

            # Skip variables that are likely config/constants, not dead code:
            # - ALL_CAPS (convention for constants)
            # - Single underscore prefix (private by convention but used internally)
            # - Names starting with lowercase that contain only lowercase+underscore (likely config)
            if node["type"] == "variable":
                name_val = node["name"]
                # Always skip constants (ALL_CAPS)
                if name_val.isupper() or (name_val.isupper() and "_" in name_val):
                    continue
                # Skip leading-underscore private vars (convention, not truly dead)
                if name_val.startswith("_"):
                    continue
                # Skip common config patterns: module-level dicts/lists used at runtime
                if name_val in ("logger", "log", "app", "router", "blueprint", "bp",
                                "celery", "db", "engine", "session", "registry", "config",
                                "settings", "metadata", "Base"):
                    continue

            # Skip symbols listed in __all__ (even if parser didn't mark as exported)
            file_all = all_names_by_file.get(node["file_path"])
            if file_all and node["name"] in file_all:
                continue

            # Skip symbols re-exported by __init__.py
            if (node["id"] in init_reexported
                    or node["name"] in init_reexported
                    or node["qualified_name"] in init_reexported):
                continue

            # Skip symbols referenced by __main__.py (entry points)
            if (node["id"] in main_entry_targets
                    or node["name"] in main_entry_targets
                    or node["qualified_name"] in main_entry_targets):
                continue

            # Skip 'main' in __main__.py files (entry point by convention)
            if node["name"] == "main" and node["file_path"].replace("\\", "/").endswith("__main__.py"):
                continue

            # Skip framework entry points
            if self._is_framework_entry(node, contains_targets):
                continue

            # Check if any incoming edge targets this node by ID, name, or qualified name
            if (node["id"] in has_incoming
                    or node["name"] in has_incoming
                    or node["qualified_name"] in has_incoming):
                continue

            # Backward compat: check for legacy self.{name} edges targeting this method
            if node["type"] == "method" and f"self.{node['name']}" in has_incoming:
                continue

            # Skip public methods on exported classes (part of the class's public API)
            if (node["type"] == "method"
                    and not node["name"].startswith("_")
                    and node["id"] in contains_targets
                    and node["id"] in method_parent):
                continue

            dead.append({
                "node_id": node["id"],
                "name": node["name"],
                "type": node["type"],
                "file_path": node["file_path"],
                "line_start": node["line_start"],
            })

        # Classify confidence levels
        file_dynamic_cache: dict[str, bool] = {}
        for entry in dead:
            fp = entry["file_path"]
            name = entry["name"]

            if name.startswith("_") and not name.startswith("__"):
                entry["confidence"] = "low"
            elif repo_root:
                if fp not in file_dynamic_cache:
                    file_dynamic_cache[fp] = self._file_has_dynamic_patterns(fp, repo_root)
                if file_dynamic_cache[fp]:
                    entry["confidence"] = "medium"
                else:
                    entry["confidence"] = "high"
            else:
                entry["confidence"] = "high"

        return dead

    @staticmethod
    def _file_has_dynamic_patterns(file_path: str, repo_root: str) -> bool:
        """Check if a file uses dynamic dispatch patterns."""
        from pathlib import Path
        try:
            full = Path(repo_root) / file_path
            content = full.read_text(encoding="utf-8", errors="ignore")
        except (OSError, ValueError):
            return True  # Conservative: assume dynamic if unreadable
        patterns = ["getattr(", "setattr(", "globals()[", "locals()[", "importlib", "__import__("]
        return any(p in content for p in patterns)

    # ------------------------------------------------------------------
    # Import cycle detection
    # ------------------------------------------------------------------
    def detect_cycles(self) -> list[list[str]]:
        """Find cycles in the IMPORTS graph using DFS.

        Returns a list of cycles, each cycle being a list of node IDs.
        """
        # Build adjacency list for IMPORTS edges using bulk fetch (avoids N+1)
        adj: dict[str, list[str]] = {}
        all_nodes = self.store.get_all_nodes(type_filter="file")
        node_ids = {n["id"] for n in all_nodes}

        all_edges = self.store.get_all_edges()
        for e in all_edges:
            if e["type"] == "IMPORTS" and e["source"] in node_ids:
                adj.setdefault(e["source"], []).append(e["target"])

        cycles: list[list[str]] = []
        visited: set[str] = set()
        rec_stack: set[str] = set()
        path: list[str] = []

        def dfs(node: str) -> None:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in adj.get(node, []):
                if neighbor not in visited and neighbor in node_ids:
                    dfs(neighbor)
                elif neighbor in rec_stack:
                    # Found a cycle
                    idx = path.index(neighbor)
                    cycles.append(path[idx:] + [neighbor])

            path.pop()
            rec_stack.discard(node)

        for node_id in node_ids:
            if node_id not in visited:
                dfs(node_id)

        return cycles

    # ------------------------------------------------------------------
    # File dependencies
    # ------------------------------------------------------------------
    def get_file_dependencies(self, file_path: str) -> list[str]:
        """Return list of module/file names that *file_path* imports."""
        nodes = self.store.get_nodes_by_file(file_path)
        node_ids = {n["id"] for n in nodes}
        edges = self.store.get_all_edges_from_nodes(node_ids)
        imports: set[str] = set()
        for e in edges:
            if e["type"] == "IMPORTS":
                imports.add(e["target"])
        return sorted(imports)

    # ------------------------------------------------------------------
    # Module structure
    # ------------------------------------------------------------------
    def get_module_structure(self, file_path: str) -> list[dict]:
        """Return a tree of classes/functions in a file."""
        nodes = self.store.get_nodes_by_file(file_path)
        return [
            {
                "id": n["id"],
                "name": n["name"],
                "type": n["type"],
                "line_start": n["line_start"],
                "line_end": n["line_end"],
                "signature": n["signature"],
            }
            for n in nodes
            if n["type"] != "file"
        ]

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    def search_nodes(self, query: str, limit: int = 50) -> list[dict]:
        """Case-insensitive substring search across node names and qualified names."""
        rows = self.store.conn.execute(
            """SELECT * FROM nodes
               WHERE name LIKE ? OR qualified_name LIKE ?
               ORDER BY
                 CASE WHEN name = ? THEN 0
                      WHEN name LIKE ? THEN 1
                      ELSE 2
                 END,
                 file_path, line_start
               LIMIT ?""",
            (f"%{query}%", f"%{query}%", query, f"{query}%", limit),
        ).fetchall()
        return [dict(r) for r in rows]
