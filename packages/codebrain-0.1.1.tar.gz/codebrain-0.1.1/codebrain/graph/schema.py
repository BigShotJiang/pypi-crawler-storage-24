"""SQLite schema creation and migration management."""

from __future__ import annotations

import sqlite3

from codebrain.config import SCHEMA_VERSION

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS files (
    path         TEXT PRIMARY KEY,
    content_hash TEXT NOT NULL,
    last_indexed REAL NOT NULL,
    line_count   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS nodes (
    id             TEXT PRIMARY KEY,
    name           TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    type           TEXT NOT NULL,
    file_path      TEXT NOT NULL REFERENCES files(path),
    line_start     INTEGER NOT NULL,
    line_end       INTEGER NOT NULL,
    signature      TEXT NOT NULL DEFAULT '',
    decorators     TEXT NOT NULL DEFAULT '[]',
    docstring      TEXT NOT NULL DEFAULT '',
    is_exported    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS edges (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    source    TEXT NOT NULL,
    target    TEXT NOT NULL,
    type      TEXT NOT NULL,
    file_path TEXT NOT NULL,
    line      INTEGER NOT NULL DEFAULT 0
);

-- Indexes for fast lookups
CREATE INDEX IF NOT EXISTS idx_nodes_file_path ON nodes(file_path);
CREATE INDEX IF NOT EXISTS idx_nodes_type      ON nodes(type);
CREATE INDEX IF NOT EXISTS idx_nodes_name      ON nodes(name);
CREATE INDEX IF NOT EXISTS idx_edges_source    ON edges(source);
CREATE INDEX IF NOT EXISTS idx_edges_target    ON edges(target);
CREATE INDEX IF NOT EXISTS idx_edges_type      ON edges(type);
CREATE INDEX IF NOT EXISTS idx_edges_file_path ON edges(file_path);
CREATE UNIQUE INDEX IF NOT EXISTS idx_edges_unique ON edges(source, target, type, file_path);
CREATE INDEX IF NOT EXISTS idx_edges_target_type ON edges(target, type);
"""

# Migrations keyed by *target* version — each value is a list of SQL statements
# that upgrade from (version - 1) to version.
_MIGRATIONS: dict[int, list[str]] = {
    2: [
        # Deduplicate existing edges before adding unique constraint
        """DELETE FROM edges WHERE id NOT IN (
            SELECT MIN(id) FROM edges GROUP BY source, target, type, file_path
        )""",
        # Prevent duplicate edges from accumulating on re-index
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_edges_unique ON edges(source, target, type, file_path)",
        # Compound index for faster reverse lookups (target + type in one scan)
        "CREATE INDEX IF NOT EXISTS idx_edges_target_type ON edges(target, type)",
    ],
}


def init_db(conn: sqlite3.Connection) -> None:
    """Create tables and indexes if they don't exist.  Set schema version."""
    conn.executescript(_SCHEMA_SQL)
    conn.execute(
        "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
        ("schema_version", str(SCHEMA_VERSION)),
    )
    conn.commit()


def get_schema_version(conn: sqlite3.Connection) -> int | None:
    """Return the current schema version, or None if uninitialized."""
    try:
        row = conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        return int(row[0]) if row else None
    except sqlite3.OperationalError:
        return None


def migrate_db(conn: sqlite3.Connection) -> None:
    """Apply pending migrations to bring the schema up to SCHEMA_VERSION.

    If the database is fresh (no meta table), ``init_db`` is called instead.
    """
    current = get_schema_version(conn)
    if current is None:
        init_db(conn)
        return

    if current >= SCHEMA_VERSION:
        return

    for target_ver in range(current + 1, SCHEMA_VERSION + 1):
        stmts = _MIGRATIONS.get(target_ver, [])
        for stmt in stmts:
            conn.execute(stmt)
        conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("schema_version", str(target_ver)),
        )
    conn.commit()
