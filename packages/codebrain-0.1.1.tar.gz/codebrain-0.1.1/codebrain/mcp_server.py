"""MCP (Model Context Protocol) server for CodeBrain.

Exposes the knowledge graph as tools that LLM agents can call directly,
eliminating the need to grep/glob the codebase.

Usage:
    brain mcp                         # start server on stdio
    python -m codebrain.mcp_server    # direct invocation
"""

from __future__ import annotations

import functools
import json
import os
import traceback
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import get_logger

_log = get_logger("mcp_server")

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP("CodeBrain")


def _find_db() -> Path:
    """Walk up from CWD to find the nearest .codebrain/graph.db."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        db = parent / CODEBRAIN_DIR / DB_FILENAME
        if db.exists():
            return db
    raise FileNotFoundError(
        "No CodeBrain index found. Run `brain init` in the repo root first."
    )


def _get_repo_root() -> Path:
    """Return the repo root (parent of .codebrain/)."""
    db = _find_db()
    return db.parent.parent


def _make_store():
    from codebrain.graph.store import GraphStore
    return GraphStore(_find_db())


def _safe_tool(fn):  # noqa: ANN001, ANN201
    """Wrap an MCP tool so exceptions become JSON error responses."""
    import sqlite3 as _sqlite3

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        try:
            _log.debug("Tool invoked: %s", fn.__name__)
            return fn(*args, **kwargs)
        except FileNotFoundError:
            return json.dumps({
                "error": "No CodeBrain index found. Run `brain init` first.",
                "tool": fn.__name__,
            })
        except _sqlite3.OperationalError as exc:
            msg = str(exc).lower()
            _log.exception("Tool %s database error", fn.__name__)
            if "locked" in msg or "busy" in msg:
                return json.dumps({
                    "error": "Database is locked by another process.",
                    "tool": fn.__name__,
                    "hint": "Another CodeBrain process (CLI, API, or MCP) is using the database. Wait a few seconds and retry.",
                })
            return json.dumps({
                "error": str(exc),
                "tool": fn.__name__,
                "hint": "Database error. Try `reindex_codebase` to rebuild the index.",
            })
        except Exception as exc:
            _log.exception("Tool %s failed", fn.__name__)
            return json.dumps({
                "error": str(exc),
                "tool": fn.__name__,
                "hint": "Try running `reindex_codebase` if the index seems stale.",
            })
    return wrapper


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
@_safe_tool
def search_symbol(query: str) -> str:
    """Search for functions, classes, methods, or variables by name.

    Use this as the starting point when you need to find code symbols.
    Returns matching nodes with file paths, line numbers, signatures, and docstrings.
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)
        results = engine.search_nodes(query, limit=30)
    return json.dumps(results)


@mcp.tool()
@_safe_tool
def get_symbol_context(name: str) -> str:
    """Get complete structural context for a symbol — everything needed to reason about it.

    Returns: signature, docstring, callers, callees, parent class/module,
    sibling functions, methods (if class), base classes, decorators,
    plus a plain-English summary explaining importance and risk.

    Tip: For file-level context, use get_file_context() instead.
    If you pass a file path here, it will automatically redirect.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        comp = ComprehensionEngine(store)

        # Auto-detect file paths and redirect to get_file_context
        if "/" in name or name.endswith((".py", ".ts", ".js", ".tsx", ".jsx")):
            file_result = gen.for_file(name)
            if "error" not in file_result:
                file_result["_note"] = (
                    f"'{name}' is a file, not a symbol. "
                    "Showing file context instead. Use get_file_context() for files."
                )
                return json.dumps(file_result)

        results = gen.for_symbol(name)
        if not results:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Enrich each result with a narrative
        for ctx in results:
            node_id = ctx.get("id", "")
            if node_id:
                try:
                    narrative = comp.symbol_narrative(node_id)
                    if "error" not in narrative:
                        ctx["narrative"] = narrative
                except Exception:
                    pass

            # Add parser note for TypeScript/JavaScript files
            fp = ctx.get("file_path", "")
            if fp.endswith((".ts", ".tsx", ".js", ".jsx")):
                ctx["parser_note"] = "Parsed with experimental regex-based TypeScript parser. Some symbols and relationships may be missing."

    return json.dumps(results)


@mcp.tool()
@_safe_tool
def get_file_context(file_path: str, top_n: int = 30) -> str:
    """Get structural context for an entire file — symbols, imports, dependents.

    Returns structural data plus a plain-English narrative explaining
    what this file does, how important it is, and what risks to watch for.
    Use this instead of reading the full file when you need to understand
    what a module does and how it relates to the rest of the codebase.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        comp = ComprehensionEngine(store)
        result = gen.for_file(file_path)

        # Enrich with narrative
        if "error" not in result:
            try:
                narrative = comp.module_narrative(file_path)
                if "error" not in narrative:
                    result["narrative"] = narrative
            except Exception:
                pass

    # Add parser note for TypeScript/JavaScript files
    if file_path.endswith((".ts", ".tsx", ".js", ".jsx")):
        result["parser_note"] = "Parsed with experimental regex-based TypeScript parser. Some symbols and relationships may be missing."

    # Truncate large lists to keep MCP responses manageable
    if "symbols" in result:
        total_symbols = len(result["symbols"])
        if total_symbols > top_n:
            result["symbols"] = result["symbols"][:top_n]
            result["total_symbols"] = total_symbols
    if "external_dependents" in result:
        total_deps = len(result["external_dependents"])
        if total_deps > top_n:
            result["external_dependents"] = result["external_dependents"][:top_n]
            result["total_external_dependents"] = total_deps

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def get_task_context(task_description: str, relevant_symbols: list[str]) -> str:
    """Get focused context for a task — combines multiple symbols with guidance.

    Provide a task description and the names of symbols you think are relevant.
    Returns structural context for all symbols, affected files, and actionable guidance.
    """
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        result = gen.for_task(task_description, relevant_symbols)
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_change(file_path: str) -> str:
    """Validate a modified file against the knowledge graph BEFORE committing.

    Detects: removed symbols that have callers, signature changes that break
    call sites, and the full blast radius of the change. Returns a risk score (0-1)
    and specific violations with severity levels.

    Call this after modifying a file to check if the change is safe.
    """
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)

        target = repo_root / file_path
        if not target.exists():
            report = validator.validate_deletion(file_path)
        else:
            report = validator.validate_file(target, repo_root)

        result = report.to_dict()

        # Active validation: automatically include impact, contracts, patterns, narrative
        try:
            engine = QueryEngine(store)
            comp = ComprehensionEngine(store)
            analyzer = StructuralAnalyzer(store)

            # Impact analysis on all symbols in the file
            nodes = store.get_nodes_by_file(file_path)
            all_nodes_list = store.get_all_nodes()
            node_by_id = {n["id"]: n for n in all_nodes_list}
            affected_files: set[str] = set()
            for node in nodes:
                if node["type"] == "file":
                    continue
                impacted = engine.impact_of_change(node["id"], max_depth=3)
                for entry in impacted:
                    t = node_by_id.get(entry["node_id"])
                    if t and t["file_path"] != file_path:
                        affected_files.add(t["file_path"])

            result["impact"] = {
                "affected_files": sorted(affected_files),
                "total_impacted": len(affected_files),
            }

            # Contract violations — filter to affected symbols
            contracts = analyzer.detect_contracts(min_confidence=0.5)
            node_names = {n["name"] for n in nodes}
            node_ids = {n["id"] for n in nodes}
            warnings = []
            for c in contracts:
                symbols = c.get("symbols", [])
                if any(s in node_names or s in node_ids for s in symbols):
                    warnings.append(c["message"])
            result["warnings"] = warnings[:10]

            # Narrative
            narrative = comp.module_narrative(file_path)
            if "error" not in narrative:
                result["narrative"] = (
                    f"{narrative['summary']} {narrative['importance']}"
                )
        except Exception as exc:
            _log.warning("Enrichment failed for %s: %s", file_path, exc)
            result["enrichment_partial"] = True
            result["enrichment_error"] = str(exc)

        # Add remediation guidance for violations
        if result.get("violations"):
            guidance = []
            for v in result["violations"]:
                if v["category"] == "removed_symbol":
                    guidance.append(f"Update callers of '{v['node_id']}' before removing it")
                elif v["category"] == "signature_change":
                    guidance.append(f"Check callers of '{v['node_id']}' for parameter compatibility")
                elif v["category"] == "broken_caller":
                    guidance.append(f"Fix '{v['node_id']}' in {v['file_path']}:{v['line']}")
            result["remediation"] = guidance[:10]

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_changes(file_paths: list[str]) -> str:
    """Validate multiple modified files at once — the batch safety gate.

    Call this after modifying multiple files to get a single pass/fail verdict
    with aggregated impact analysis. Returns a clear verdict: SAFE, CAUTION, or UNSAFE.

    Args:
        file_paths: List of file paths that were modified.
    """
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        engine = QueryEngine(store)
        comp = ComprehensionEngine(store)

        all_violations = []
        all_affected: set[str] = set()
        file_results = []

        all_nodes_list = store.get_all_nodes()
        node_by_id = {n["id"]: n for n in all_nodes_list}

        for fp in file_paths:
            target = repo_root / fp
            if not target.exists():
                report = validator.validate_deletion(fp)
            else:
                report = validator.validate_file(target, repo_root)

            file_report = report.to_dict()

            # Impact analysis
            nodes = store.get_nodes_by_file(fp)
            for node in nodes:
                if node["type"] == "file":
                    continue
                impacted = engine.impact_of_change(node["id"], max_depth=3)
                for entry in impacted:
                    t = node_by_id.get(entry["node_id"])
                    if t and t["file_path"] != fp and t["file_path"] not in file_paths:
                        all_affected.add(t["file_path"])

            all_violations.extend(file_report.get("violations", []))
            file_results.append({
                "file": fp,
                "risk_score": file_report.get("risk_score", 0),
                "violations": len(file_report.get("violations", [])),
            })

        # Determine verdict
        max_risk = max((fr["risk_score"] for fr in file_results), default=0)
        total_violations = len(all_violations)
        if total_violations == 0 and len(all_affected) < 5:
            verdict = "SAFE"
        elif total_violations <= 2 and max_risk < 0.5:
            verdict = "CAUTION"
        else:
            verdict = "UNSAFE"

        # Build narrative
        if verdict == "SAFE":
            narrative = f"Changes to {len(file_paths)} file(s) look safe. No structural violations detected."
        elif verdict == "CAUTION":
            narrative = (
                f"Changes to {len(file_paths)} file(s) have minor risks: "
                f"{total_violations} violation(s), {len(all_affected)} external file(s) affected. Review recommended."
            )
        else:
            narrative = (
                f"Changes to {len(file_paths)} file(s) are UNSAFE: "
                f"{total_violations} violation(s), {len(all_affected)} external file(s) affected. "
                f"Fix violations before committing."
            )

        result = {
            "verdict": verdict,
            "narrative": narrative,
            "files": file_results,
            "total_violations": total_violations,
            "affected_external_files": sorted(all_affected),
            "violations": all_violations[:20],
        }

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_after_write(file_paths: list[str]) -> str:
    """Re-validate files AFTER writing them to disk.

    Call this after writing modified files to verify nothing broke.
    Reads the files from disk and validates against the current knowledge graph.

    Args:
        file_paths: List of relative file paths that were just written.
    """
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        results = []

        for fp in file_paths:
            abs_path = repo_root / fp
            if not abs_path.exists():
                results.append({"file": fp, "status": "MISSING"})
                continue
            try:
                report = validator.validate_file(abs_path, repo_root)
                if report.is_valid:
                    results.append({"file": fp, "status": "OK"})
                else:
                    results.append({
                        "file": fp,
                        "status": "BROKEN",
                        "violations": [
                            {"severity": v.severity, "message": v.message}
                            for v in report.violations
                            if v.severity in ("critical", "high")
                        ][:5],
                    })
            except Exception as e:
                results.append({"file": fp, "status": "ERROR", "error": str(e)})

        all_ok = all(r["status"] == "OK" for r in results)
        return json.dumps({
            "verdict": "PASS" if all_ok else "FAIL",
            "files": results,
        })


@mcp.tool()
@_safe_tool
def get_validation_status() -> str:
    """Check if recent file changes caused structural breakage.

    Call this after writing files to verify nothing broke.
    Returns validation results from the file watcher if running,
    or validates recently modified files against the knowledge graph.
    """
    import os
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        # Find files modified in the last 60 seconds
        import time
        threshold = time.time() - 60
        results = []
        for root_dir, _dirs, files in os.walk(str(repo_root)):
            for fname in files:
                if not fname.endswith(('.py', '.ts', '.tsx', '.js', '.jsx')):
                    continue
                fpath = Path(root_dir) / fname
                try:
                    if fpath.stat().st_mtime > threshold:
                        rel = str(fpath.relative_to(repo_root)).replace("\\", "/")
                        report = validator.validate_file(fpath, repo_root)
                        status = "OK" if report.is_valid else "BROKEN"
                        entry: dict = {"file": rel, "status": status}
                        if not report.is_valid:
                            entry["violations"] = [
                                {"severity": v.severity, "message": v.message}
                                for v in report.violations
                                if v.severity in ("critical", "high")
                            ][:5]
                        results.append(entry)
                except Exception:
                    continue

        if not results:
            return json.dumps({"verdict": "PASS", "message": "No recently modified files.", "files": []})

        all_ok = all(r["status"] == "OK" for r in results)
        return json.dumps({
            "verdict": "PASS" if all_ok else "FAIL",
            "files": results,
        })


@mcp.tool()
@_safe_tool
def propose_change(file_path: str, new_content: str) -> str:
    """Check if proposed code is safe BEFORE writing it to disk.

    This is the structural safety gate. Pass the file path and the full
    new content you plan to write. Returns a verdict (SAFE/CAUTION/UNSAFE)
    with specific violations, affected files, and remediation steps.

    Use this before writing any file that modifies existing functions/classes.
    For new files, validation is less critical but still catches syntax errors.

    Args:
        file_path: Relative path within the repo (e.g. 'codebrain/api.py').
        new_content: The complete new file content to validate.
    """
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        report = validator.validate_content(file_path, new_content, repo_root)
        result = report.to_dict()

        # Determine verdict
        critical = sum(1 for v in result.get("violations", []) if v["severity"] == "critical")
        high = sum(1 for v in result.get("violations", []) if v["severity"] == "high")

        if critical > 0:
            verdict = "UNSAFE"
        elif high > 0:
            verdict = "CAUTION"
        else:
            verdict = "SAFE"

        # Build plain-English verdict
        if verdict == "SAFE":
            narrative = f"Proposed change to {file_path} is safe. {result.get('summary', '')}"
        elif verdict == "CAUTION":
            affected = result.get("affected_files", [])
            narrative = (
                f"Proposed change to {file_path} has risks: {result.get('summary', '')} "
                f"Affected files: {', '.join(affected[:5]) if affected else 'none'}."
            )
        else:
            narrative = (
                f"UNSAFE: Proposed change to {file_path} will break things. "
                f"{result.get('summary', '')} Fix violations before writing."
            )

        # Build response — verdict first, short for SAFE, detailed for UNSAFE
        response: dict = {"verdict": verdict, "narrative": narrative}

        if verdict == "SAFE":
            # Keep it short — don't waste agent context window
            response["changes"] = {
                "added": len(result.get("nodes_added", [])),
                "removed": len(result.get("nodes_removed", [])),
                "modified": len(result.get("nodes_modified", [])),
            }
        else:
            # Detailed response for CAUTION/UNSAFE
            response["violations"] = [
                v for v in result.get("violations", [])
                if v["severity"] in ("critical", "high")
            ]
            response["affected_files"] = result.get("affected_files", [])

            # files_to_update: extract caller file paths from violations
            files_to_update: dict[str, dict] = {}
            for v in result.get("violations", []):
                for caller in v.get("callers", []):
                    fp = caller.get("file", "")
                    if fp and fp != file_path:
                        if fp not in files_to_update:
                            files_to_update[fp] = {"file": fp, "reasons": []}
                        files_to_update[fp]["reasons"].append(
                            f"{v['category']}: {v['message'][:100]}"
                        )
            response["files_to_update"] = list(files_to_update.values())

            # Remediation guidance
            guidance = []
            for v in result.get("violations", []):
                if v["category"] == "removed_symbol":
                    guidance.append(f"Update callers of '{v['node_id']}' before removing it")
                elif v["category"] == "signature_change":
                    guidance.append(f"Check callers of '{v['node_id']}' for parameter compatibility")
                elif v["category"] == "broken_caller":
                    guidance.append(f"Fix '{v['node_id']}' in {v['file_path']}:{v['line']}")
                elif v["category"] == "syntax_error":
                    guidance.append(f"Fix syntax error at line {v['line']}: {v['message']}")
            response["remediation"] = guidance[:10]

    return json.dumps(response)


@mcp.tool()
@_safe_tool
def impact_analysis(name: str, max_depth: int = 5) -> str:
    """Show what could break if a function/class changes.

    Traces transitive reverse dependencies — every symbol that directly
    or indirectly depends on this one. Essential before modifying
    high-traffic code.

    Args:
        name: Symbol name, qualified name, or file path (e.g. 'auth.py' or 'backend/auth.py').
              File paths are expanded to all symbols in the file.
        max_depth: How many levels of transitive dependents to trace (default 5).
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        # Fallback: try as file path if resolve_node found nothing
        if not nodes:
            file_nodes = store.get_nodes_by_file(name)
            if file_nodes:
                nodes = file_nodes

        if not nodes:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Expand file-level nodes to their contained symbols
        expanded: list[dict] = []
        for node in nodes:
            if node["type"] == "file":
                file_symbols = store.get_nodes_by_file(node["file_path"])
                expanded.extend(s for s in file_symbols if s["type"] != "file")
            else:
                expanded.append(node)

        if not expanded:
            return json.dumps({"error": f"No symbols found in '{name}'"})

        _MAX_IMPACT_RESULTS = 200
        results = []
        seen_ids: set[str] = set()
        truncated = False
        for node in expanded:
            if len(seen_ids) >= _MAX_IMPACT_RESULTS:
                truncated = True
                break
            impacted = engine.impact_of_change(node["id"], max_depth=max_depth)
            # Deduplicate across symbols from the same file
            new_impacted = []
            for entry in impacted:
                if entry["node_id"] not in seen_ids:
                    seen_ids.add(entry["node_id"])
                    new_impacted.append(entry)
                    if len(seen_ids) >= _MAX_IMPACT_RESULTS:
                        truncated = True
                        break
            if new_impacted:
                results.append({"target": node["id"], "impacted": new_impacted})

        # Add narrative summary
        total_impacted = len(seen_ids)
        affected_files = {nid.split("::")[0] for nid in seen_ids if "::" in nid}
        if total_impacted == 0:
            narrative = f"No downstream dependents found for '{name}'. Safe to modify."
        elif total_impacted <= 5:
            narrative = f"Low blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s) depend on '{name}'."
        elif total_impacted <= 20:
            narrative = f"Medium blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s). Test thoroughly after changes."
        else:
            narrative = f"HIGH blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s). This is load-bearing code — changes are risky."

        resp = {"narrative": narrative, "total_impacted": total_impacted, "affected_files": len(affected_files), "details": results}
        if truncated:
            resp["truncated"] = True
            resp["note"] = f"Results capped at {_MAX_IMPACT_RESULTS}. Actual impact may be larger."

    return json.dumps(resp)


@mcp.tool()
@_safe_tool
def call_chain(name: str, max_depth: int = 5) -> str:
    """Trace forward call chain from a function — what does it call, transitively.

    Useful for understanding execution flow and identifying all code paths
    triggered by calling a function.

    Args:
        name: Symbol name, qualified name, or file path (e.g. 'auth.py' or 'backend/auth.py').
              File paths are expanded to all symbols in the file.
        max_depth: How many levels deep to trace (default 5).
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        # Fallback: try as file path if resolve_node found nothing
        if not nodes:
            file_nodes = store.get_nodes_by_file(name)
            if file_nodes:
                nodes = file_nodes

        if not nodes:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Expand file-level nodes to their contained symbols
        expanded: list[dict] = []
        for node in nodes:
            if node["type"] == "file":
                file_symbols = store.get_nodes_by_file(node["file_path"])
                expanded.extend(s for s in file_symbols if s["type"] != "file")
            else:
                expanded.append(node)

        if not expanded:
            return json.dumps({"error": f"No symbols found in '{name}'"})

        _MAX_CHAIN_RESULTS = 200
        results = []
        seen_ids: set[str] = set()
        truncated = False
        for node in expanded:
            if len(seen_ids) >= _MAX_CHAIN_RESULTS:
                truncated = True
                break
            chain = engine.get_call_chain(node["id"], max_depth=max_depth)
            # Deduplicate across symbols from the same file
            new_chain = []
            for entry in chain:
                if entry["node_id"] not in seen_ids:
                    seen_ids.add(entry["node_id"])
                    new_chain.append(entry)
                    if len(seen_ids) >= _MAX_CHAIN_RESULTS:
                        truncated = True
                        break
            if new_chain:
                results.append({"root": node["id"], "chain": new_chain})

        # Build narrative
        total_calls = len(seen_ids)
        call_files = {nid.split("::")[0] for nid in seen_ids if "::" in nid}
        if total_calls == 0:
            narrative = f"'{name}' makes no outgoing calls to other indexed symbols."
        elif total_calls <= 5:
            narrative = f"'{name}' has a shallow call tree: {total_calls} function(s) across {len(call_files)} file(s)."
        else:
            narrative = f"'{name}' triggers {total_calls} function(s) across {len(call_files)} file(s). Deep call tree — changes to callees may affect this function's behavior."

        resp = {"narrative": narrative, "total_calls": total_calls, "call_files": len(call_files), "details": results}
        if truncated:
            resp["truncated"] = True
            resp["note"] = f"Results capped at {_MAX_CHAIN_RESULTS}."

    return json.dumps(resp)


@mcp.tool()
@_safe_tool
def codebase_overview() -> str:
    """Get a high-level overview of the entire codebase.

    Returns: package structure, symbol counts, entry points,
    inter-package dependencies, plus a human-readable narrative.
    Use this first to orient yourself in an unfamiliar codebase.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.system_overview()
        narrative = comp.system_narrative()
        result["narrative"] = {
            "summary": narrative["summary"],
            "architecture": narrative["architecture"],
            "health": narrative["health_summary"],
            "recommendations": narrative["recommendations"],
        }
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def codebase_anatomy() -> str:
    """Get a subsystem map of the codebase — the 'truck parts' view.

    Groups files into named subsystems with descriptions, importance
    rankings, and inter-subsystem connections. Ideal for onboarding
    new developers or understanding how the codebase is organized.

    Tries LLM-enhanced descriptions first, falls back to deterministic.
    """
    repo_root = _get_repo_root()
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings
        settings = load_llm_settings(repo_root)
        if settings.enabled:
            from codebrain.config import CODEBRAIN_DIR
            cache_dir = repo_root / CODEBRAIN_DIR
            with _make_store() as store:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_anatomy()
            return json.dumps(result)
    except ImportError:
        pass

    from codebrain.comprehension import ComprehensionEngine
    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.codebase_anatomy()
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def module_overview(file_path: str) -> str:
    """Get overview of a package (directory) or module (file).

    Pass a package name like 'codebrain/graph' for package view,
    or a file path like 'codebrain/graph/store.py' for file view.
    Auto-detects based on whether input ends with a source file extension.

    Returns: role, symbols, exports, imports, imported_by, coupling score,
    plus a human-readable narrative explaining importance and risks.
    """
    from codebrain.comprehension import ComprehensionEngine

    _source_exts = ('.py', '.ts', '.tsx', '.js', '.jsx')
    with _make_store() as store:
        comp = ComprehensionEngine(store)
        if file_path.endswith(_source_exts):
            # File/module level
            result = comp.module_view(file_path)
            if "error" not in result:
                narrative = comp.module_narrative(file_path)
                result["narrative"] = {
                    "summary": narrative["summary"],
                    "importance": narrative["importance"],
                    "risks": narrative["risks"],
                    "top_callers": narrative["top_callers"],
                }
            result["zoom_out"] = "Use codebase_overview() for system view."
            result["drill_down"] = "Use get_symbol_context('<name>') for symbol details."
        else:
            # Package level
            result = comp.package_view(file_path)
            result["zoom_out"] = "Use codebase_overview() for system view."
            result["drill_down"] = "Use module_overview('<file_path>') for file details."
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def risk_hotspots(top_n: int = 15) -> str:
    """Find the riskiest symbols in the codebase.

    Ranked by: number of dependents, cross-file impact, transitive reach.
    These are the symbols where changes are most likely to cause breakage.
    Returns data plus a human-readable narrative per hotspot.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        stats = store.get_stats()
        total_files = stats.get("files", 1)
        results = comp.risk_hotspots(top_n=top_n)
        for item in results:
            risk_level = "HIGH" if item["risk_score"] > 20 else ("MEDIUM" if item["risk_score"] > 5 else "LOW")
            pct = item["affected_files"] / max(total_files, 1) * 100
            item["narrative"] = (
                f"{item['name']} ({item['type']}) — {risk_level} risk. "
                f"{item['direct_dependents']} direct dependents, "
                f"affects {item['affected_files']} files ({pct:.0f}% of codebase)."
            )
            # Per-hotspot why field with specific file names
            caller_files = []
            if "callers" in item:
                caller_files = list({c.get("file", "").rsplit("/", 1)[-1]
                                     for c in item.get("callers", []) if c.get("file")})[:4]
            item["why"] = (
                f"Called by {item['direct_dependents']} symbols across {item['affected_files']} files. "
                f"A signature change would cascade through "
                f"{', '.join(caller_files) if caller_files else 'dependent modules'}."
            )
    return json.dumps(results)


@mcp.tool()
@_safe_tool
def find_dead_code(top_n: int = 50) -> str:
    """Find potentially unused functions and classes.

    Returns symbols with no incoming calls or imports, excluding
    entry points and exported APIs.

    Args:
        top_n: Maximum number of dead code entries to return (default 50).
    """
    from codebrain.graph.query import QueryEngine

    repo_root = str(_get_repo_root())

    with _make_store() as store:
        engine = QueryEngine(store)
        dead = engine.find_dead_code(repo_root=repo_root)

    total = len(dead)

    # Group by confidence
    high = [d for d in dead if d.get("confidence") == "high"]
    medium = [d for d in dead if d.get("confidence") == "medium"]
    low = [d for d in dead if d.get("confidence") == "low"]

    if total == 0:
        narrative = "No dead code detected. All symbols have incoming references."
    else:
        parts = []
        if high:
            parts.append(f"{len(high)} high-confidence (likely truly dead)")
        if medium:
            parts.append(f"{len(medium)} medium (in files with dynamic dispatch)")
        if low:
            parts.append(f"{len(low)} low (private helpers)")
        narrative = f"Found {total} potentially unused symbols. {', '.join(parts)}."

    summary = {
        "total_dead_code_found": total,
        "narrative": narrative,
        "high_confidence": high[:top_n],
        "medium_confidence": medium[:top_n],
        "low_confidence": low[:top_n],
        "note": (
            "Excludes: test files, framework entry points, exported symbols, "
            "dunder methods, variables/constants, __all__ listed symbols. "
            "High-confidence items are most likely truly unused."
        ),
    }
    return json.dumps(summary)


@mcp.tool()
@_safe_tool
def detect_import_cycles() -> str:
    """Find circular import dependencies in the codebase.

    Returns cycles with a narrative explaining severity and fix suggestions.
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)
        cycles = engine.detect_cycles()

    if not cycles:
        narrative = "No import cycles detected. Clean dependency structure."
    elif len(cycles) == 1:
        narrative = f"Found 1 import cycle involving {len(cycles[0])} module(s). Consider extracting shared code into a separate module."
    else:
        total_files = len({f for c in cycles for f in c})
        narrative = f"Found {len(cycles)} import cycles involving {total_files} module(s). These create tight coupling and make layering impossible. Break cycles by extracting shared interfaces."

    return json.dumps({"narrative": narrative, "total_cycles": len(cycles), "cycles": cycles})


@mcp.tool()
@_safe_tool
def architectural_layers(top_n: int = 30) -> str:
    """Show how the codebase layers from foundation to top-level orchestrators.

    Layer 0 = leaf modules with no internal dependencies (safest to modify).
    Higher layers depend on lower ones. Cycles are flagged.

    Args:
        top_n: Maximum modules per layer to show (default 30).
    """
    from codebrain.analyzer import StructuralAnalyzer

    with _make_store() as store:
        analyzer = StructuralAnalyzer(store)
        result = analyzer.detect_layers()

    # Truncate each layer's files list to top_n entries
    if "layers" in result:
        for layer in result["layers"]:
            files = layer.get("files", [])
            total = len(files)
            if total > top_n:
                truncated = files[:top_n]
                layer["files"] = truncated
                layer["total_files"] = total
                layer["files_truncated"] = True
            else:
                layer["total_files"] = total
                layer["files_truncated"] = False
            # Add per-layer summary string
            shown = layer["files"]
            short_names = [f.rsplit("/", 1)[-1] for f in shown[:3]]
            remaining = total - len(short_names)
            if remaining > 0:
                layer["summary"] = f"{total} files ({', '.join(short_names)}, +{remaining} more)"
            else:
                layer["summary"] = f"{total} files ({', '.join(short_names)})"

    # Add overall narrative
    layers = result.get("layers", [])
    cycle_layers = [l for l in layers if l["layer"] == -1]
    normal_layers = [l for l in layers if l["layer"] >= 0]
    edge_res = result.get("edge_resolution", {})

    parts = [f"Architecture has {len(normal_layers)} layer(s)."]
    if cycle_layers:
        cycle_files = sum(l["total_files"] for l in cycle_layers)
        parts.append(f"{cycle_files} file(s) are in dependency cycles (layer -1) — consider breaking these.")
    if edge_res.get("unresolved", 0) > 0:
        parts.append(
            f"Edge resolution: {edge_res['resolution_rate']} of dependencies resolved. "
            f"{edge_res['unresolved']} unresolved edges (mostly third-party imports)."
        )
    result["narrative"] = " ".join(parts)

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def implicit_contracts(top_n: int = 30) -> str:
    """Detect implicit contracts — patterns that are fragile but not enforced.

    Finds: co-imported symbol pairs, co-called function groups,
    and duck-typing interfaces (classes sharing method sets).
    Breaking these patterns causes subtle bugs.

    Args:
        top_n: Maximum entries per contract type to return (default 30).
    """
    from codebrain.analyzer import StructuralAnalyzer

    with _make_store() as store:
        analyzer = StructuralAnalyzer(store)
        contracts = analyzer.detect_contracts()
        violations = analyzer.check_contract_violations(contracts)

    total = len(contracts)
    contracts = contracts[:top_n]

    # Narrative
    if total == 0:
        narrative = "No implicit contracts detected. The codebase has few tightly co-used symbol pairs."
    else:
        co_imports = sum(1 for c in contracts if c["type"] == "co_import")
        co_calls = sum(1 for c in contracts if c["type"] == "co_call")
        interfaces = sum(1 for c in contracts if c["type"] in ("shared_interface", "interface"))
        parts = []
        if co_imports:
            parts.append(f"{co_imports} co-import contracts")
        if co_calls:
            parts.append(f"{co_calls} co-call contracts")
        if interfaces:
            parts.append(f"{interfaces} interface contracts")
        violation_note = f" {len(violations)} violation(s) found." if violations else " No violations."
        narrative = f"Found {total} implicit contracts: {'; '.join(parts)}.{violation_note}"

    summary = {
        "narrative": narrative,
        "total_contracts_found": total,
        "showing": len(contracts),
        "items": contracts,
        "violations": violations,
    }
    return json.dumps(summary)


@mcp.tool()
@_safe_tool
def reindex_codebase() -> str:
    """Force a full reindex of the codebase.

    Call this after major refactoring or if the index seems stale.
    """
    from codebrain.indexer import full_index

    repo_root = _get_repo_root()
    db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME
    # Clear tables in-place instead of deleting the file.
    # This avoids file lock conflicts when the MCP server holds the DB open.
    if db_path.exists():
        with _make_store() as store:
            store.clear_all()
    result = full_index(repo_root, db_path)
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def export_dot(name: str = "") -> str:
    """Export graph as Graphviz DOT format.

    Optionally limit to a subgraph around a symbol name.
    Returns a DOT string that can be rendered with Graphviz.
    """
    from codebrain.export import GraphExporter

    with _make_store() as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=name or None)
        return exporter.to_dot(nodes, edges)


@mcp.tool()
@_safe_tool
def export_mermaid(name: str = "") -> str:
    """Export graph as Mermaid flowchart format.

    Optionally limit to a subgraph around a symbol name.
    Returns a Mermaid string for use in Markdown.
    """
    from codebrain.export import GraphExporter

    with _make_store() as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=name or None)
        return exporter.to_mermaid(nodes, edges)


@mcp.tool()
@_safe_tool
def query_modules(package: str = "", depth: int = 3) -> str:
    """Show the high-level module/subsystem structure of the codebase.

    Groups files by directory structure and shows inter-module dependencies.
    Use this to understand how the codebase is organized before diving into details.

    Args:
        package: Filter to a specific package (e.g. 'backend'). Empty = all.
        depth: Directory depth for grouping (2-4). Higher = more granular.
    """
    from collections import defaultdict

    with _make_store() as store:
        file_nodes = store.get_all_nodes(type_filter="file")
        all_edges = store.get_all_edges()
        all_nodes = store.get_all_nodes()

    def _mod_key(fp: str) -> str:
        parts = fp.split("/")
        dp = parts[:-1] if len(parts) > 1 else parts
        return "/".join(dp[:depth]) if len(dp) >= depth else "/".join(dp)

    if package:
        file_nodes = [n for n in file_nodes if n["file_path"].startswith(package + "/")]

    mod_files: dict[str, int] = defaultdict(int)
    mod_symbols: dict[str, int] = defaultdict(int)
    for n in file_nodes:
        mod_files[_mod_key(n["file_path"])] += 1
    for n in all_nodes:
        if n["type"] != "file" and n.get("file_path"):
            k = _mod_key(n["file_path"])
            if k in mod_files:
                mod_symbols[k] += 1

    node_mod: dict[str, str] = {}
    for n in all_nodes:
        fp = n.get("file_path", "")
        if fp:
            node_mod[n["id"]] = _mod_key(fp)
            node_mod[n["name"]] = _mod_key(fp)

    edge_w: dict[tuple[str, str], int] = defaultdict(int)
    for e in all_edges:
        if e["type"] not in ("CALLS", "IMPORTS"):
            continue
        sm = node_mod.get(e["source"])
        tm = node_mod.get(e["target"])
        if sm and tm and sm != tm and sm in mod_files and tm in mod_files:
            edge_w[(sm, tm)] += 1

    modules = []
    for mod, fc in sorted(mod_files.items(), key=lambda x: -mod_symbols.get(x[0], 0)):
        modules.append({"module": mod, "files": fc, "symbols": mod_symbols.get(mod, 0)})

    connections = []
    for (s, t), w in sorted(edge_w.items(), key=lambda x: -x[1])[:50]:
        connections.append({"from": s, "to": t, "references": w})

    # Narrative
    if not modules:
        narrative = "No modules found."
    else:
        top3 = sorted(modules, key=lambda m: -m["symbols"])[:3]
        top_str = ", ".join(f"{m['module']} ({m['symbols']} symbols)" for m in top3)
        narrative = f"{len(modules)} modules found. Largest: {top_str}."
        if connections:
            heaviest = connections[0]
            narrative += f" Strongest dependency: {heaviest['from']} -> {heaviest['to']} ({heaviest['references']} references)."

    return json.dumps({"narrative": narrative, "modules": modules, "connections": connections})


@mcp.tool()
@_safe_tool
def query_dependencies(module_path: str, direction: str = "both") -> str:
    """Show what a module/directory depends on and what depends on it.

    Args:
        module_path: Directory path (e.g. 'backend/palmistry' or 'backend/vedic-profiles/engines').
        direction: 'incoming' (who calls this), 'outgoing' (what this calls), or 'both'.
    """
    from collections import defaultdict

    with _make_store() as store:
        all_nodes = store.get_all_nodes()
        all_edges = store.get_all_edges()

    # Map each node to its module
    node_mod: dict[str, str] = {}
    mod_nodes: set[str] = set()
    for n in all_nodes:
        fp = n.get("file_path", "")
        if fp:
            node_mod[n["id"]] = fp
            node_mod[n["name"]] = fp
            if fp.startswith(module_path + "/") or fp == module_path:
                mod_nodes.add(n["id"])

    # Detect language of the target module to filter cross-language false positives
    _PY_EXTS = (".py",)
    _JS_EXTS = (".ts", ".tsx", ".js", ".jsx")

    def _lang(path: str) -> str:
        ext = os.path.splitext(path)[1].lower() if path else ""
        if ext in _PY_EXTS:
            return "python"
        if ext in _JS_EXTS:
            return "js"
        return "other"

    # Determine language of the module from its files
    mod_langs = {_lang(node_mod.get(nid, "")) for nid in mod_nodes}
    mod_langs.discard("other")

    incoming: dict[str, int] = defaultdict(int)
    outgoing: dict[str, int] = defaultdict(int)
    for e in all_edges:
        if e["type"] not in ("CALLS", "IMPORTS"):
            continue
        src_in = e["source"] in mod_nodes
        tgt_fp = node_mod.get(e["target"], "")
        tgt_in = tgt_fp.startswith(module_path + "/") or tgt_fp == module_path

        if src_in and not tgt_in and tgt_fp:
            # Skip cross-language edges (Python <-> JS/TS)
            if mod_langs and _lang(tgt_fp) not in mod_langs and _lang(tgt_fp) != "other":
                continue
            outgoing[tgt_fp.rsplit("/", 1)[0] if "/" in tgt_fp else tgt_fp] += 1
        if tgt_in and not src_in:
            src_fp = node_mod.get(e["source"], "")
            if src_fp:
                # Skip cross-language edges
                if mod_langs and _lang(src_fp) not in mod_langs and _lang(src_fp) != "other":
                    continue
                incoming[src_fp.rsplit("/", 1)[0] if "/" in src_fp else src_fp] += 1

    result = {"module": module_path}
    if direction in ("both", "incoming"):
        result["used_by"] = [{"module": k, "references": v} for k, v in sorted(incoming.items(), key=lambda x: -x[1])[:20]]
    if direction in ("both", "outgoing"):
        result["depends_on"] = [{"module": k, "references": v} for k, v in sorted(outgoing.items(), key=lambda x: -x[1])[:20]]

    # Narrative
    in_count = len(incoming)
    out_count = len(outgoing)
    if in_count == 0 and out_count == 0:
        narrative = f"'{module_path}' has no detected dependencies in either direction."
    elif in_count > out_count * 2:
        narrative = f"'{module_path}' is a provider: {in_count} modules depend on it, it depends on {out_count}. Changes here have wide blast radius."
    elif out_count > in_count * 2:
        narrative = f"'{module_path}' is a consumer: depends on {out_count} modules, only {in_count} depend on it. Lower risk to modify."
    else:
        narrative = f"'{module_path}' has balanced dependencies: {in_count} incoming, {out_count} outgoing."
    result["narrative"] = narrative

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def explain_code(target: str) -> str:
    """Get an AI-generated explanation of a module, file, or the whole system.

    Uses the LLM layer (xAI Grok) to produce a natural language explanation
    of the structural data. Falls back to deterministic narrative if LLM unavailable.

    Args:
        target: 'system' for codebase overview, or a file path for module explanation.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine

    repo_root = _get_repo_root()
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings
        settings = load_llm_settings(repo_root)
        cache_dir = repo_root / CODEBRAIN_DIR
    except ImportError:
        settings = None

    with _make_store() as store:
        engine = QueryEngine(store)
        comp = ComprehensionEngine(store)

        if target == "system":
            narrative = comp.system_narrative()
            if settings and settings.enabled:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_system()
                return json.dumps(result)
            return json.dumps(narrative)
        else:
            narrative = comp.module_narrative(target)
            if narrative.get("error"):
                return json.dumps(narrative)
            if settings and settings.enabled:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_module(target)
                return json.dumps(result)
            return json.dumps(narrative)


@mcp.tool()
@_safe_tool
def ask_codebase(question: str) -> str:
    """Ask a natural language question about the codebase structure.

    Analyzes the question, queries the knowledge graph, and uses LLM to
    generate a clear answer. Works best for structural questions like:
    - "How do the astrology modules interact?"
    - "What are the main subsystems?"
    - "What would break if I change the auth middleware?"
    - "What are the riskiest files?"

    Args:
        question: Your question about the codebase.
    """
    from codebrain.comprehension import ComprehensionEngine

    repo_root = _get_repo_root()

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.answer_question(question)

    # Try LLM enhancement
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings

        settings = load_llm_settings(repo_root)
        if settings.enabled and settings.api_keys:
            cache_dir = repo_root / CODEBRAIN_DIR
            with _make_store() as store:
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result = narrator.ask(question)
    except ImportError:
        pass

    return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Memory tools
# ---------------------------------------------------------------------------


def _make_memory_store(scope: str = "project"):
    """Create a MemoryStore for the given scope."""
    from codebrain.memory.store import MemoryStore

    if scope == "global":
        db = Path.home() / ".codebrain" / "memory.db"
    else:
        db = _get_repo_root() / CODEBRAIN_DIR / "memory.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    return MemoryStore(db)


@mcp.tool()
@_safe_tool
def save_memory(
    content: str,
    category: str,
    tags: list[str] | None = None,
    scope: str = "project",
    expires_in_days: float | None = None,
    source: str = "",
) -> str:
    """Save a memory to CodeBrain's persistent memory store.

    Use this to remember session context, codebase patterns, architectural
    decisions, user preferences, or risk notes across conversations.

    Args:
        content: The memory content — be specific and self-contained.
        category: One of 'session', 'pattern', 'decision', 'preference', 'risk'.
        tags: Optional list of tags for filtering (e.g. ['auth', 'api']).
        scope: 'project' (default) or 'global' (cross-project).
        expires_in_days: Auto-expire after N days. None = never.
        source: Where this memory came from (e.g. 'conversation', 'code-review').
    """
    import time

    expires_at = None
    if expires_in_days is not None:
        expires_at = time.time() + (expires_in_days * 86400)

    with _make_memory_store(scope) as store:
        memory_id = store.save(
            content=content,
            category=category,
            tags=tags or [],
            expires_at=expires_at,
            source=source,
        )
        result = store.get(memory_id)

    return json.dumps({"saved": result})


@mcp.tool()
@_safe_tool
def recall_memories(
    query: str,
    category: str | None = None,
    scope: str = "both",
    limit: int = 20,
) -> str:
    """Search memories using full-text search.

    Finds memories matching the query across content, category, and tags.
    Use this to recall context from previous sessions, known patterns,
    or past decisions.

    Args:
        query: Search terms (e.g. 'auth middleware', 'database migration').
        category: Filter to a specific category. None = all.
        scope: 'project', 'global', or 'both' (default — merges results).
        limit: Max results to return (default 20).
    """
    results = []
    seen_ids: set[str] = set()

    scopes = ["project", "global"] if scope == "both" else [scope]
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                store.cleanup_expired()
                hits = store.search(query, category=category, limit=limit)
                for hit in hits:
                    if hit["id"] not in seen_ids:
                        hit["scope"] = s
                        seen_ids.add(hit["id"])
                        results.append(hit)
        except FileNotFoundError:
            continue

    results = results[:limit]
    return json.dumps({"count": len(results), "memories": results})


@mcp.tool()
@_safe_tool
def list_memories(
    category: str | None = None,
    scope: str = "project",
    limit: int = 20,
) -> str:
    """List recent memories sorted by last updated.

    Args:
        category: Filter to a specific category. None = all.
        scope: 'project' (default), 'global', or 'both'.
        limit: Max results to return (default 20).
    """
    results = []
    seen_ids: set[str] = set()

    scopes = ["project", "global"] if scope == "both" else [scope]
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                store.cleanup_expired()
                hits = store.list_recent(category=category, limit=limit)
                for hit in hits:
                    if hit["id"] not in seen_ids:
                        hit["scope"] = s
                        seen_ids.add(hit["id"])
                        results.append(hit)
        except FileNotFoundError:
            continue

    # Sort merged results by updated_at DESC
    results.sort(key=lambda m: m["updated_at"], reverse=True)
    results = results[:limit]

    stats = {}
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                stats[s] = store.stats()
        except FileNotFoundError:
            continue

    return json.dumps({"count": len(results), "memories": results, "stats": stats})


@mcp.tool()
@_safe_tool
def update_memory(
    memory_id: str,
    content: str | None = None,
    confidence: float | None = None,
    tags: list[str] | None = None,
    scope: str = "project",
) -> str:
    """Update an existing memory.

    Args:
        memory_id: The ID of the memory to update.
        content: New content (optional).
        confidence: New confidence score 0.0-1.0 (optional).
        tags: New tags list (optional).
        scope: 'project' (default) or 'global'.
    """
    with _make_memory_store(scope) as store:
        updated = store.update(
            memory_id, content=content, confidence=confidence, tags=tags,
        )
        if not updated:
            return json.dumps({"error": f"Memory '{memory_id}' not found in {scope} store"})
        result = store.get(memory_id)

    return json.dumps({"updated": result})


@mcp.tool()
@_safe_tool
def delete_memory(memory_id: str, scope: str = "project") -> str:
    """Delete a memory by ID.

    Args:
        memory_id: The ID of the memory to delete.
        scope: 'project' (default) or 'global'.
    """
    with _make_memory_store(scope) as store:
        deleted = store.delete(memory_id)

    if not deleted:
        return json.dumps({"error": f"Memory '{memory_id}' not found in {scope} store"})
    return json.dumps({"deleted": memory_id, "scope": scope})


@mcp.tool()
@_safe_tool
def zoom(target: str = "") -> str:
    """Multi-resolution zoom — like Google Maps for your codebase.

    Navigate between three zoom levels with drill-down/zoom-out hints:
    - No target (empty string): system level — what is this codebase?
    - File path: module level — what does this file do?
    - Symbol name: symbol level — full context for one function/class

    Each response includes navigation hints to zoom in or out.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.zoom(target if target else None)
    return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

@mcp.resource("codebrain://status")
def get_status() -> str:
    """Current index status — file count, node count, edge count."""
    with _make_store() as store:
        stats = store.get_stats()
    return json.dumps(stats)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_server() -> None:
    """Start the MCP server on stdio with automatic background file watching."""
    _log.info("Starting CodeBrain MCP server on stdio")

    observer = None
    watcher_store = None
    try:
        db_path = _find_db()
        repo_root = db_path.parent.parent
        from codebrain.watcher.file_watcher import start_watching_background
        observer, watcher_store, _watcher_handler = start_watching_background(repo_root, db_path)
        _log.info("Auto-indexing enabled for %s", repo_root)
    except FileNotFoundError:
        _log.info("No index found — auto-indexing disabled (run `brain init` first)")
    except Exception as exc:
        _log.warning("Could not start file watcher: %s", exc)

    try:
        mcp.run(transport="stdio")
    finally:
        if observer is not None:
            observer.stop()
            observer.join()
        if watcher_store is not None:
            watcher_store.close()


if __name__ == "__main__":
    run_server()
