"""Pydantic response models for the CodeBrain REST API."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class NodeResponse(BaseModel):
    id: str
    name: str
    qualified_name: str
    type: str
    file_path: str
    line_start: int
    line_end: int
    signature: str = ""
    docstring: str = ""
    is_exported: bool = False
    decorators: list[str] = Field(default_factory=list)


class EdgeResponse(BaseModel):
    source: str
    target: str
    type: str
    file_path: str
    line: int


class StatsResponse(BaseModel):
    model_config = ConfigDict(extra="allow")
    files: int
    nodes: int
    edges: int
    node_types: dict[str, int] = Field(default_factory=dict)
    edge_types: dict[str, int] = Field(default_factory=dict)
    health: dict | None = None
    llm: dict | None = None


class GraphResponse(BaseModel):
    nodes: list[dict]
    edges: list[dict]


class ImpactEntry(BaseModel):
    node_id: str
    depth: int
    edge_type: str
    via: str


class ImpactResult(BaseModel):
    target: str
    impacted: list[ImpactEntry]


class TraceEntry(BaseModel):
    model_config = ConfigDict(extra="allow")
    node_id: str
    depth: int


class TraceResult(BaseModel):
    root: str
    chain: list[dict]


class ErrorResponse(BaseModel):
    detail: str


class ValidationReport(BaseModel):
    file_path: str
    is_valid: bool
    risk_score: float
    summary: str
    violations: list[dict] = Field(default_factory=list)
    affected_files: list[str] = Field(default_factory=list)


class HealthResult(BaseModel):
    score: int
    grade: str
    details: dict


class AskRequest(BaseModel):
    question: str
    use_llm: bool = True


class AskResponse(BaseModel):
    question: str
    intent: str
    answer: str
    llm_answer: str | None = None
    data: Any = None
    sources: list[str] = Field(default_factory=list)
    suggestions: list[str] = Field(default_factory=list)
