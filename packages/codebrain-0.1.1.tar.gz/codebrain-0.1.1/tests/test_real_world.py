"""M1: Self-validation on real codebases.

Tests CodeBrain on its own repo — every QueryEngine, ComprehensionEngine,
StructuralAnalyzer, and ChangeValidator method must return correct results.

Run with: pytest tests/test_real_world.py -v
"""

from __future__ import annotations

import ast
import shutil
import time
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.graph.query import QueryEngine
from codebrain.comprehension import ComprehensionEngine
from codebrain.analyzer import StructuralAnalyzer
from codebrain.validator import ChangeValidator
from codebrain.indexer import full_index

# CodeBrain repo root (one level up from tests/)
REPO_ROOT = Path(__file__).parent.parent


@pytest.fixture(scope="module")
def indexed_db(tmp_path_factory):
    """Index CodeBrain's own codebrain/ source once, reuse for all tests."""
    db_path = tmp_path_factory.mktemp("m1") / "codebrain.db"
    start = time.time()
    full_index(REPO_ROOT, db_path)
    elapsed = time.time() - start
    return {"db_path": db_path, "index_time": elapsed}


# =========================================================================
# QueryEngine tests
# =========================================================================

class TestQueryEngine:

    def test_search_finds_graphstore(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            results = qe.search_nodes("GraphStore")
            assert len(results) > 0
            names = [r["name"] for r in results]
            assert "GraphStore" in names

    def test_file_dependencies(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            deps = qe.get_file_dependencies("codebrain/graph/store.py")
            assert len(deps) > 0

    def test_reverse_dependencies_by_file(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            rdeps = qe.get_reverse_dependencies("codebrain/graph/store.py")
            files = set(r["file_path"] for r in rdeps)
            assert len(files) >= 3, f"Expected >=3 files depending on store.py, got {len(files)}"
            # query.py, comprehension.py, and mcp_server.py should depend on store.py
            expected = {"codebrain/graph/query.py", "codebrain/comprehension.py"}
            assert expected.issubset(files), f"Missing expected dependents: {expected - files}"

    def test_reverse_dependencies_by_symbol(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            rdeps = qe.get_reverse_dependencies("codebrain/graph/store.py::GraphStore")
            assert len(rdeps) > 0

    def test_impact_of_change(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            impact = qe.impact_of_change("codebrain/graph/store.py")
            assert len(impact) > 0
            files = set()
            for entry in impact:
                node = store.get_node(entry["node_id"])
                if node:
                    files.add(node["file_path"])
            assert len(files) >= 3

    def test_call_chain(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            chain = qe.get_call_chain("codebrain/comprehension.py::ComprehensionEngine.system_overview")
            assert len(chain) > 0
            # system_overview calls store.get_all_nodes, get_all_edges, etc.
            resolved_names = [c["node_id"].split("::")[-1] if "::" in c["node_id"] else c["node_id"] for c in chain]
            assert any("get_all_nodes" in n or "get_stats" in n for n in resolved_names)

    def test_find_dead_code_no_core_false_positives(self, indexed_db):
        """Core classes must NOT be flagged as dead code."""
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            dead = qe.find_dead_code()
            dead_names = {d["name"] for d in dead}
            core_symbols = {"GraphStore", "QueryEngine", "ComprehensionEngine",
                            "ChangeValidator", "StructuralAnalyzer"}
            falsely_flagged = core_symbols & dead_names
            assert not falsely_flagged, f"Core symbols falsely flagged as dead: {falsely_flagged}"

    def test_detect_cycles(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            cycles = qe.detect_cycles()
            assert isinstance(cycles, list)


# =========================================================================
# ComprehensionEngine tests
# =========================================================================

class TestComprehensionEngine:

    def test_system_overview(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            ov = comp.system_overview()
            assert ov["stats"]["nodes"] > 200
            assert ov["stats"]["files"] > 20
            assert len(ov["packages"]) > 0

    def test_module_view(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            mv = comp.module_view("codebrain/graph/store.py")
            assert "error" not in mv
            assert len(mv["symbols"]) > 10
            assert mv["coupling"]["incoming"] > 0

    def test_system_narrative(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            sn = comp.system_narrative()
            assert isinstance(sn, (str, dict))
            assert len(str(sn)) > 50

    def test_module_narrative(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            mn = comp.module_narrative("codebrain/graph/store.py")
            assert isinstance(mn, (str, dict))
            assert len(str(mn)) > 50
            assert "error" not in str(mn).lower() or "store" in str(mn).lower()

    def test_symbol_narrative_by_name(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            symn = comp.symbol_narrative("GraphStore")
            assert "error" not in symn, f"symbol_narrative failed: {symn}"
            assert "summary" in symn

    def test_symbol_narrative_by_id(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            symn = comp.symbol_narrative("codebrain/graph/store.py::GraphStore")
            assert "error" not in symn

    def test_health_score(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            hs = comp.health_score()
            assert "score" in hs
            assert 0 <= hs["score"] <= 100
            assert "grade" in hs

    def test_risk_hotspots(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            hot = comp.risk_hotspots()
            assert len(hot) > 0
            assert hot[0]["risk_score"] > 0
            # GraphStore should be a hotspot
            hotspot_names = [h["name"] for h in hot]
            assert "GraphStore" in hotspot_names or any("Store" in n for n in hotspot_names)

    def test_codebase_anatomy(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            anat = comp.codebase_anatomy()
            assert isinstance(anat, dict)
            assert len(anat) > 0


# =========================================================================
# StructuralAnalyzer tests
# =========================================================================

class TestStructuralAnalyzer:

    def test_coupling_analysis(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            analyzer = StructuralAnalyzer(store)
            coupling = analyzer.coupling_analysis()
            assert len(coupling.get("pairs", [])) > 0

    def test_detect_layers_multiple(self, indexed_db):
        """Must produce >1 layer on CodeBrain's repo."""
        with GraphStore(indexed_db["db_path"]) as store:
            analyzer = StructuralAnalyzer(store)
            layers = analyzer.detect_layers()
            layer_list = layers.get("layers", [])
            assert len(layer_list) > 1, f"Expected >1 layer, got {len(layer_list)}"

    def test_detect_contracts(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            analyzer = StructuralAnalyzer(store)
            contracts = analyzer.detect_contracts()
            assert isinstance(contracts, list)
            # Should find at least some co-import contracts
            assert len(contracts) > 0

    def test_cohesion_analysis(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            analyzer = StructuralAnalyzer(store)
            cohesion = analyzer.cohesion_analysis()
            assert len(cohesion) > 0


# =========================================================================
# ChangeValidator tests
# =========================================================================

class TestValidator:

    def test_unchanged_file_is_safe(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            validator = ChangeValidator(store)
            content = (REPO_ROOT / "codebrain/graph/store.py").read_text(encoding="utf-8")
            report = validator.validate_content("codebrain/graph/store.py", content, str(REPO_ROOT))
            assert report.is_valid
            assert len(report.violations) == 0

    def test_removing_get_node_is_unsafe(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            validator = ChangeValidator(store)
            content = (REPO_ROOT / "codebrain/graph/store.py").read_text(encoding="utf-8")

            # Remove get_node method via AST
            tree = ast.parse(content)
            for node in tree.body:
                if isinstance(node, ast.ClassDef) and node.name == "GraphStore":
                    node.body = [
                        item for item in node.body
                        if not (isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                                and item.name == "get_node")
                    ]
            modified = ast.unparse(tree)

            report = validator.validate_content("codebrain/graph/store.py", modified, str(REPO_ROOT))
            assert not report.is_valid, "Removing get_node should be UNSAFE"
            assert len(report.violations) > 0
            removed_violations = [v for v in report.violations if v.category == "removed_symbol"]
            assert len(removed_violations) > 0

    def test_adding_function_is_safe(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            validator = ChangeValidator(store)
            content = (REPO_ROOT / "codebrain/graph/store.py").read_text(encoding="utf-8")
            modified = content + "\n\ndef _new_helper():\n    pass\n"
            report = validator.validate_content("codebrain/graph/store.py", modified, str(REPO_ROOT))
            assert report.is_valid


# =========================================================================
# Indexing performance
# =========================================================================

class TestPerformance:

    def test_indexing_under_30s(self, indexed_db):
        assert indexed_db["index_time"] < 30, f"Indexing took {indexed_db['index_time']:.1f}s"

    def test_search_under_1s(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            start = time.time()
            qe.search_nodes("GraphStore")
            assert time.time() - start < 1.0

    def test_impact_under_5s(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            qe = QueryEngine(store)
            start = time.time()
            qe.impact_of_change("codebrain/graph/store.py")
            assert time.time() - start < 5.0

    def test_hotspots_under_10s(self, indexed_db):
        with GraphStore(indexed_db["db_path"]) as store:
            comp = ComprehensionEngine(store)
            start = time.time()
            comp.risk_hotspots()
            assert time.time() - start < 10.0
