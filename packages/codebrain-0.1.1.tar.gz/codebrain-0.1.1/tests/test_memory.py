"""Tests for the CodeBrain memory layer."""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from codebrain.memory.store import MemoryStore, VALID_CATEGORIES

try:
    from codebrain.mcp_server import _find_db, _get_repo_root
    _MCP_AVAILABLE = True
except (TypeError, ImportError):
    _MCP_AVAILABLE = False


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def mem_store(tmp_path: Path):
    """Create a fresh MemoryStore in a temp directory."""
    db = tmp_path / "memory.db"
    store = MemoryStore(db)
    yield store
    store.close()


@pytest.fixture
def populated_store(mem_store: MemoryStore):
    """MemoryStore pre-loaded with several memories."""
    mem_store.save("authentication middleware uses JWT tokens", "pattern",
                   tags=["auth", "middleware"], source="code-review")
    mem_store.save("decided to use SQLite for persistence", "decision",
                   tags=["database", "architecture"])
    mem_store.save("user prefers dark mode and vim keybindings", "preference",
                   tags=["editor", "ui"])
    mem_store.save("session context: working on API refactor", "session",
                   tags=["api", "refactor"], confidence=0.8)
    mem_store.save("risk: changing auth module affects 30 files", "risk",
                   tags=["auth", "high-impact"])
    return mem_store


# ------------------------------------------------------------------
# TestMemoryStore — CRUD
# ------------------------------------------------------------------

class TestMemoryStore:
    def test_save_returns_id(self, mem_store):
        mid = mem_store.save("test content", "pattern")
        assert isinstance(mid, str)
        assert len(mid) == 12

    def test_get_by_id(self, mem_store):
        mid = mem_store.save("test content", "pattern", tags=["tag1"])
        result = mem_store.get(mid)
        assert result is not None
        assert result["id"] == mid
        assert result["content"] == "test content"
        assert result["category"] == "pattern"
        assert result["tags"] == ["tag1"]
        assert result["confidence"] == 1.0
        assert result["source"] == ""

    def test_get_nonexistent(self, mem_store):
        assert mem_store.get("nonexistent") is None

    def test_save_all_categories(self, mem_store):
        for cat in VALID_CATEGORIES:
            mid = mem_store.save(f"content for {cat}", cat)
            result = mem_store.get(mid)
            assert result["category"] == cat

    def test_save_invalid_category(self, mem_store):
        with pytest.raises(ValueError, match="Invalid category"):
            mem_store.save("test", "invalid_category")

    def test_update_content(self, mem_store):
        mid = mem_store.save("original", "pattern")
        assert mem_store.update(mid, content="updated")
        result = mem_store.get(mid)
        assert result["content"] == "updated"

    def test_update_confidence(self, mem_store):
        mid = mem_store.save("test", "pattern")
        mem_store.update(mid, confidence=0.5)
        result = mem_store.get(mid)
        assert result["confidence"] == 0.5

    def test_update_tags(self, mem_store):
        mid = mem_store.save("test", "pattern", tags=["old"])
        mem_store.update(mid, tags=["new1", "new2"])
        result = mem_store.get(mid)
        assert result["tags"] == ["new1", "new2"]

    def test_update_nonexistent(self, mem_store):
        assert mem_store.update("nonexistent", content="x") is False

    def test_update_changes_updated_at(self, mem_store):
        mid = mem_store.save("test", "pattern")
        r1 = mem_store.get(mid)
        time.sleep(0.05)
        mem_store.update(mid, content="changed")
        r2 = mem_store.get(mid)
        assert r2["updated_at"] > r1["updated_at"]

    def test_delete(self, mem_store):
        mid = mem_store.save("to delete", "session")
        assert mem_store.delete(mid) is True
        assert mem_store.get(mid) is None

    def test_delete_nonexistent(self, mem_store):
        assert mem_store.delete("nonexistent") is False

    def test_save_with_source(self, mem_store):
        mid = mem_store.save("test", "pattern", source="conversation")
        result = mem_store.get(mid)
        assert result["source"] == "conversation"

    def test_save_with_expires_at(self, mem_store):
        future = time.time() + 86400
        mid = mem_store.save("temporary", "session", expires_at=future)
        result = mem_store.get(mid)
        assert result["expires_at"] is not None

    def test_timestamps_are_iso(self, mem_store):
        mid = mem_store.save("test", "pattern")
        result = mem_store.get(mid)
        # ISO 8601 format check
        assert "T" in result["created_at"]
        assert "+" in result["created_at"] or "Z" in result["created_at"]

    def test_list_recent(self, populated_store):
        results = populated_store.list_recent()
        assert len(results) == 5
        # Should be sorted by updated_at DESC
        timestamps = [r["updated_at"] for r in results]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_list_recent_with_category(self, populated_store):
        results = populated_store.list_recent(category="pattern")
        assert len(results) == 1
        assert results[0]["category"] == "pattern"

    def test_list_recent_with_limit(self, populated_store):
        results = populated_store.list_recent(limit=2)
        assert len(results) == 2

    def test_cleanup_expired(self, mem_store):
        # Save one expired and one current
        mem_store.save("expired", "session", expires_at=time.time() - 100)
        mem_store.save("current", "session")
        deleted = mem_store.cleanup_expired()
        assert deleted == 1
        remaining = mem_store.list_recent()
        assert len(remaining) == 1
        assert remaining[0]["content"] == "current"

    def test_cleanup_no_expired(self, mem_store):
        mem_store.save("current", "session")
        assert mem_store.cleanup_expired() == 0

    def test_stats(self, populated_store):
        stats = populated_store.stats()
        assert stats["total"] == 5
        assert stats["by_category"]["pattern"] == 1
        assert stats["by_category"]["decision"] == 1
        assert stats["by_category"]["preference"] == 1
        assert stats["by_category"]["session"] == 1
        assert stats["by_category"]["risk"] == 1
        assert stats["oldest"] is not None
        assert stats["newest"] is not None

    def test_stats_empty(self, mem_store):
        stats = mem_store.stats()
        assert stats["total"] == 0
        assert stats["by_category"] == {}

    def test_context_manager(self, tmp_path):
        db = tmp_path / "ctx.db"
        with MemoryStore(db) as store:
            store.save("test", "pattern")
        # Should not raise — DB closed cleanly
        with MemoryStore(db) as store:
            assert len(store.list_recent()) == 1


# ------------------------------------------------------------------
# TestMemoryFTS — full-text search
# ------------------------------------------------------------------

class TestMemoryFTS:
    def test_search_basic(self, populated_store):
        results = populated_store.search("authentication")
        assert len(results) >= 1
        assert any("authentication" in r["content"] for r in results)

    def test_search_partial_term(self, populated_store):
        results = populated_store.search("JWT")
        assert len(results) >= 1

    def test_search_multiple_terms(self, populated_store):
        results = populated_store.search("auth middleware")
        assert len(results) >= 1

    def test_search_with_category_filter(self, populated_store):
        results = populated_store.search("auth", category="risk")
        assert len(results) == 1
        assert results[0]["category"] == "risk"

    def test_search_no_results(self, populated_store):
        results = populated_store.search("xyznonexistent")
        assert len(results) == 0

    def test_search_empty_query(self, populated_store):
        results = populated_store.search("")
        assert len(results) == 0

    def test_search_respects_limit(self, populated_store):
        results = populated_store.search("auth", limit=1)
        assert len(results) <= 1

    def test_search_finds_in_tags(self, mem_store):
        mem_store.save("some content", "pattern", tags=["uniquetag123"])
        results = mem_store.search("uniquetag123")
        assert len(results) >= 1

    def test_search_after_update(self, mem_store):
        mid = mem_store.save("old content", "pattern")
        mem_store.update(mid, content="new searchable content")
        results = mem_store.search("searchable")
        assert len(results) >= 1
        assert results[0]["content"] == "new searchable content"

    def test_search_after_delete(self, mem_store):
        mid = mem_store.save("deleteme content", "pattern")
        mem_store.delete(mid)
        results = mem_store.search("deleteme")
        assert len(results) == 0

    def test_search_cross_category(self, populated_store):
        # "auth" appears in both pattern and risk memories
        results = populated_store.search("auth")
        categories = {r["category"] for r in results}
        assert len(categories) >= 2


# ------------------------------------------------------------------
# TestMemoryMCPTools — lifecycle via MCP tool functions
# ------------------------------------------------------------------

@pytest.mark.skipif(not _MCP_AVAILABLE, reason="MCP server failed to import")
class TestMemoryMCPTools:
    @pytest.fixture
    def mem_project(self, tmp_path):
        """Set up paths for memory MCP tools."""
        repo_root = tmp_path / "repo"
        repo_root.mkdir()
        codebrain_dir = repo_root / ".codebrain"
        codebrain_dir.mkdir()

        # Create a dummy graph.db so _find_db works
        db_path = codebrain_dir / "graph.db"
        db_path.touch()

        with patch("codebrain.mcp_server._find_db", return_value=db_path), \
             patch("codebrain.mcp_server._get_repo_root", return_value=repo_root):
            yield repo_root

    def test_save_and_recall(self, mem_project):
        from codebrain.mcp_server import save_memory, recall_memories

        result = json.loads(save_memory("test pattern for auth", "pattern",
                                        tags=["auth"]))
        assert "saved" in result
        assert result["saved"]["content"] == "test pattern for auth"
        mid = result["saved"]["id"]

        # Recall by search
        result = json.loads(recall_memories("auth", scope="project"))
        assert result["count"] >= 1
        assert any(m["id"] == mid for m in result["memories"])

    def test_save_and_update(self, mem_project):
        from codebrain.mcp_server import save_memory, update_memory

        saved = json.loads(save_memory("original", "decision"))
        mid = saved["saved"]["id"]

        updated = json.loads(update_memory(mid, content="revised decision"))
        assert "updated" in updated
        assert updated["updated"]["content"] == "revised decision"

    def test_save_and_delete(self, mem_project):
        from codebrain.mcp_server import save_memory, delete_memory, recall_memories

        saved = json.loads(save_memory("to delete", "session"))
        mid = saved["saved"]["id"]

        deleted = json.loads(delete_memory(mid))
        assert deleted["deleted"] == mid

        # Should not be found
        results = json.loads(recall_memories("delete", scope="project"))
        assert all(m["id"] != mid for m in results["memories"])

    def test_list_memories(self, mem_project):
        from codebrain.mcp_server import save_memory, list_memories

        save_memory("first", "pattern")
        save_memory("second", "decision")

        result = json.loads(list_memories(scope="project"))
        assert result["count"] == 2
        assert "stats" in result

    def test_list_memories_with_category(self, mem_project):
        from codebrain.mcp_server import save_memory, list_memories

        save_memory("pattern item", "pattern")
        save_memory("decision item", "decision")

        result = json.loads(list_memories(category="pattern", scope="project"))
        assert result["count"] == 1
        assert result["memories"][0]["category"] == "pattern"

    def test_update_nonexistent(self, mem_project):
        from codebrain.mcp_server import update_memory

        result = json.loads(update_memory("nonexistent", content="x"))
        assert "error" in result

    def test_delete_nonexistent(self, mem_project):
        from codebrain.mcp_server import delete_memory

        result = json.loads(delete_memory("nonexistent"))
        assert "error" in result

    def test_save_with_expires(self, mem_project):
        from codebrain.mcp_server import save_memory

        result = json.loads(save_memory("temp", "session", expires_in_days=7))
        assert result["saved"]["expires_at"] is not None

    def test_full_lifecycle(self, mem_project):
        """save → recall → update → list → delete."""
        from codebrain.mcp_server import (
            save_memory, recall_memories, update_memory,
            list_memories, delete_memory,
        )

        # Save
        saved = json.loads(save_memory(
            "authentication uses bcrypt hashing", "pattern",
            tags=["auth", "security"],
        ))
        mid = saved["saved"]["id"]

        # Recall
        recalled = json.loads(recall_memories("bcrypt", scope="project"))
        assert recalled["count"] >= 1

        # Update
        updated = json.loads(update_memory(mid, content="auth uses argon2 now",
                                           tags=["auth", "security", "migration"]))
        assert updated["updated"]["content"] == "auth uses argon2 now"

        # List
        listed = json.loads(list_memories(scope="project"))
        assert listed["count"] >= 1

        # Delete
        deleted = json.loads(delete_memory(mid))
        assert deleted["deleted"] == mid

        # Verify gone
        listed2 = json.loads(list_memories(scope="project"))
        assert all(m["id"] != mid for m in listed2["memories"])


# ------------------------------------------------------------------
# TestMemoryScopes — project vs global vs both
# ------------------------------------------------------------------

@pytest.mark.skipif(not _MCP_AVAILABLE, reason="MCP server failed to import")
class TestMemoryScopes:
    @pytest.fixture
    def scoped_project(self, tmp_path):
        """Set up separate project and global memory paths."""
        repo_root = tmp_path / "repo"
        repo_root.mkdir()
        codebrain_dir = repo_root / ".codebrain"
        codebrain_dir.mkdir()
        db_path = codebrain_dir / "graph.db"
        db_path.touch()

        global_dir = tmp_path / "home" / ".codebrain"
        global_dir.mkdir(parents=True)

        with patch("codebrain.mcp_server._find_db", return_value=db_path), \
             patch("codebrain.mcp_server._get_repo_root", return_value=repo_root), \
             patch("pathlib.Path.home", return_value=tmp_path / "home"):
            yield repo_root, global_dir

    def test_project_scope_creates_db(self, scoped_project):
        from codebrain.mcp_server import save_memory

        repo_root, _ = scoped_project
        save_memory("project memory", "pattern", scope="project")
        assert (repo_root / ".codebrain" / "memory.db").exists()

    def test_global_scope_creates_db(self, scoped_project):
        from codebrain.mcp_server import save_memory

        _, global_dir = scoped_project
        save_memory("global memory", "preference", scope="global")
        assert (global_dir / "memory.db").exists()

    def test_scopes_are_isolated(self, scoped_project):
        from codebrain.mcp_server import save_memory, recall_memories

        save_memory("flamingo migration strategy", "pattern", scope="project")
        save_memory("zeppelin keyboard shortcuts", "preference", scope="global")

        proj = json.loads(recall_memories("flamingo", scope="project"))
        glob = json.loads(recall_memories("zeppelin", scope="global"))

        assert proj["count"] >= 1
        assert glob["count"] >= 1

        # Project search shouldn't find global memory
        proj_glob = json.loads(recall_memories("zeppelin", scope="project"))
        assert proj_glob["count"] == 0

    def test_both_scope_merges(self, scoped_project):
        from codebrain.mcp_server import save_memory, recall_memories

        save_memory("project auth pattern", "pattern", scope="project")
        save_memory("global auth preference", "preference", scope="global")

        both = json.loads(recall_memories("auth", scope="both"))
        assert both["count"] >= 2
        scopes = {m["scope"] for m in both["memories"]}
        assert "project" in scopes
        assert "global" in scopes

    def test_list_both_scopes(self, scoped_project):
        from codebrain.mcp_server import save_memory, list_memories

        save_memory("project item", "pattern", scope="project")
        save_memory("global item", "preference", scope="global")

        result = json.loads(list_memories(scope="both"))
        assert result["count"] == 2
        assert "project" in result["stats"]
        assert "global" in result["stats"]
