"""Integration tests — full pipeline from indexing through querying.

Tests multi-package projects, incremental updates, mixed languages,
and error recovery.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import discover_files, full_index, incremental_update
from codebrain.utils import normalize_path
from codebrain.validator import ChangeValidator


@pytest.fixture
def multi_package(tmp_path: Path) -> Path:
    """Create a multi-package project with cross-package imports."""
    # Package A: core library
    pkg_a = tmp_path / "pkg_a"
    pkg_a.mkdir()
    (pkg_a / "__init__.py").write_text('"""Package A — core library."""\n')
    (pkg_a / "models.py").write_text(
        '''\
"""Core data models."""

class User:
    """Represents a user."""
    def __init__(self, name: str, email: str):
        self.name = name
        self.email = email

    def display_name(self):
        return self.name.title()


class Order:
    """Represents an order."""
    def __init__(self, user: "User", total: float):
        self.user = user
        self.total = total

    def summary(self):
        return f"{self.user.display_name()}: ${self.total}"
'''
    )
    (pkg_a / "utils.py").write_text(
        '''\
"""Shared utilities."""

def format_currency(amount: float) -> str:
    return f"${amount:.2f}"

def validate_email(email: str) -> bool:
    return "@" in email
'''
    )

    # Package B: depends on A
    pkg_b = tmp_path / "pkg_b"
    pkg_b.mkdir()
    (pkg_b / "__init__.py").write_text('"""Package B — services."""\n')
    (pkg_b / "service.py").write_text(
        '''\
"""Business logic service."""

from pkg_a.models import User, Order
from pkg_a.utils import format_currency, validate_email


def create_user(name: str, email: str) -> User:
    if not validate_email(email):
        raise ValueError("Invalid email")
    return User(name, email)


def place_order(user: User, amount: float) -> str:
    order = Order(user, amount)
    formatted = format_currency(amount)
    return f"Order placed: {formatted}"
'''
    )

    # Package C: TypeScript module
    pkg_c = tmp_path / "frontend"
    pkg_c.mkdir()
    (pkg_c / "api.ts").write_text(
        '''\
// API client for the backend

export interface ApiResponse {
  status: number;
  data: any;
}

export function fetchUser(id: string): Promise<ApiResponse> {
  return fetch(`/api/users/${id}`).then(r => r.json());
}

export function fetchOrders(userId: string): Promise<ApiResponse> {
  return fetch(`/api/orders?user=${userId}`).then(r => r.json());
}

function formatError(error: Error): string {
  return `Error: ${error.message}`;
}
'''
    )

    return tmp_path


class TestFullPipeline:
    """End-to-end: index -> query -> validate -> incremental update."""

    def test_index_multi_package(self, multi_package: Path) -> None:
        result = full_index(multi_package)
        assert result["errors"] == []
        assert result["files_parsed"] >= 5  # 3 py + 1 ts + 2 __init__
        assert result["total_nodes"] > 0
        assert result["total_edges"] > 0

    def test_query_after_index(self, multi_package: Path) -> None:
        full_index(multi_package)
        db = multi_package / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)

            # Search should find cross-package symbols
            users = engine.resolve_node("User")
            assert len(users) > 0

            # Impact analysis should cross package boundaries
            user_node = users[0]
            impacted = engine.impact_of_change(user_node["id"], max_depth=5)
            # create_user depends on User
            assert len(impacted) >= 0  # at minimum, something depends

            # Dead code detection
            dead = engine.find_dead_code()
            dead_names = [d["name"] for d in dead]
            # formatError is not exported properly in TS — may be dead
            # validate_email might appear if no callers are resolved

    def test_validate_after_index(self, multi_package: Path) -> None:
        full_index(multi_package)
        db = multi_package / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_file(
                multi_package / "pkg_a" / "models.py",
                multi_package,
            )
            assert report.file_path == "pkg_a/models.py"
            assert isinstance(report.risk_score, float)
            assert isinstance(report.is_valid, bool)

    def test_incremental_update(self, multi_package: Path) -> None:
        full_index(multi_package)
        db = multi_package / CODEBRAIN_DIR / DB_FILENAME

        # Modify a file
        (multi_package / "pkg_a" / "utils.py").write_text(
            '''\
"""Shared utilities — updated."""

def format_currency(amount: float) -> str:
    return f"${amount:,.2f}"

def validate_email(email: str) -> bool:
    return "@" in email and "." in email.split("@")[1]

def new_helper():
    """Newly added function."""
    return 42
'''
        )

        with GraphStore(db) as store:
            result = incremental_update(
                multi_package,
                [multi_package / "pkg_a" / "utils.py"],
                [],
                store,
            )
            assert result["files_updated"] == 1
            assert result["errors"] == []

            # Verify the new function was indexed
            engine = QueryEngine(store)
            found = engine.resolve_node("new_helper")
            assert len(found) > 0

    def test_file_deletion_incremental(self, multi_package: Path) -> None:
        full_index(multi_package)
        db = multi_package / CODEBRAIN_DIR / DB_FILENAME

        with GraphStore(db) as store:
            # Verify file exists in index
            nodes_before = store.get_nodes_by_file("pkg_a/utils.py")
            assert len(nodes_before) > 0

            result = incremental_update(
                multi_package,
                [],
                [multi_package / "pkg_a" / "utils.py"],
                store,
            )
            assert result["files_removed"] == 1

            nodes_after = store.get_nodes_by_file("pkg_a/utils.py")
            assert len(nodes_after) == 0


class TestMixedLanguages:
    """Projects with both Python and TypeScript files."""

    def test_ts_files_indexed(self, multi_package: Path) -> None:
        result = full_index(multi_package)
        assert result["errors"] == []

        db = multi_package / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            ts_nodes = store.get_nodes_by_file("frontend/api.ts")
            assert len(ts_nodes) > 0
            node_names = [n["name"] for n in ts_nodes]
            assert "fetchUser" in node_names or "api.ts" in node_names


class TestErrorRecovery:
    """Indexer should handle broken files gracefully."""

    def test_syntax_error_doesnt_crash(self, tmp_path: Path) -> None:
        pkg = tmp_path / "broken"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "bad.py").write_text("def foo(:\n  pass\n")  # syntax error
        (pkg / "good.py").write_text("def bar():\n    return 1\n")

        result = full_index(tmp_path)
        # Should still index the good file; errors may or may not be reported
        # depending on parser resilience, but the indexer must not crash
        assert result["files_parsed"] >= 1

    def test_empty_file(self, tmp_path: Path) -> None:
        pkg = tmp_path / "empty"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "empty.py").write_text("")

        result = full_index(tmp_path)
        assert result["errors"] == []

    def test_binary_gitignored(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("*.pyc\n__pycache__/\n")
        pkg = tmp_path / "src"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "main.py").write_text("print('hello')\n")

        files = discover_files(tmp_path)
        paths_str = [str(f) for f in files]
        assert not any("__pycache__" in p for p in paths_str)


class TestGraphStoreContextManager:
    """GraphStore works as a context manager."""

    def test_context_manager(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.db"
        with GraphStore(db_path) as store:
            stats = store.get_stats()
            assert stats["files"] == 0

    def test_nested_context_managers(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.db"
        with GraphStore(db_path) as store:
            store.get_stats()
        # Re-open should work fine
        with GraphStore(db_path) as store:
            stats = store.get_stats()
            assert stats["files"] == 0
