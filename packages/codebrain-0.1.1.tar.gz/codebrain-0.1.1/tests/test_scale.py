"""Stress tests -- verify CodeBrain works on medium-to-large codebases.

Tests index speed, query speed, and memory behavior on synthetic projects
of 200+ files with realistic dependency patterns.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from codebrain.analyzer import StructuralAnalyzer
from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index


def _create_synthetic_project(root: Path, num_packages: int = 5, files_per_pkg: int = 40) -> int:
    """Create a synthetic Python project with realistic structure.

    Returns total file count.
    """
    total = 0

    for pkg_idx in range(num_packages):
        pkg_name = f"pkg_{pkg_idx}"
        pkg_dir = root / pkg_name
        pkg_dir.mkdir(parents=True, exist_ok=True)
        (pkg_dir / "__init__.py").write_text(
            f'"""Package {pkg_name}."""\n'
            f"from .models import BaseModel_{pkg_idx}\n"
        )
        total += 1

        (pkg_dir / "models.py").write_text(
            f"class BaseModel_{pkg_idx}:\n"
            f"    def validate(self): pass\n"
            f"    def serialize(self): pass\n\n"
            f"class Config_{pkg_idx}:\n"
            f"    DEBUG = False\n"
            f"    VERSION = '1.0'\n"
        )
        total += 1

        (pkg_dir / "utils.py").write_text(
            f"from .models import BaseModel_{pkg_idx}\n\n"
            f"def helper_{pkg_idx}(model: BaseModel_{pkg_idx}):\n"
            f"    return model.validate()\n\n"
            f"def format_output(data):\n"
            f"    return str(data)\n"
        )
        total += 1

        for file_idx in range(files_per_pkg - 3):
            fname = f"module_{file_idx}.py"
            cross_import = ""
            if file_idx % 5 == 0 and pkg_idx > 0:
                other_pkg = f"pkg_{pkg_idx - 1}"
                cross_import = f"from {other_pkg}.utils import helper_{pkg_idx - 1}\n"

            content = (
                f"from .models import BaseModel_{pkg_idx}\n"
                f"from .utils import helper_{pkg_idx}\n"
                f"{cross_import}\n"
                f"class Service_{pkg_idx}_{file_idx}(BaseModel_{pkg_idx}):\n"
                f"    def process(self):\n"
                f"        return helper_{pkg_idx}(self)\n\n"
                f"    def transform(self, data):\n"
                f"        return self.validate()\n\n"
                f"def standalone_func_{file_idx}():\n"
                f"    svc = Service_{pkg_idx}_{file_idx}()\n"
                f"    return svc.process()\n"
            )
            (pkg_dir / fname).write_text(content)
            total += 1

    imports = "\n".join(f"from pkg_{i}.utils import helper_{i}" for i in range(num_packages))
    (root / "main.py").write_text(
        f"{imports}\n\n"
        f"def main():\n"
        f"    results = []\n"
        + "".join(f"    results.append(helper_{i}(None))\n" for i in range(num_packages))
        + f"    return results\n"
    )
    total += 1

    return total


@pytest.fixture
def large_project(tmp_path):
    """Create a 200+ file synthetic project and index it."""
    root = tmp_path / "project"
    root.mkdir()
    _create_synthetic_project(root, num_packages=5, files_per_pkg=40)
    db = tmp_path / "test.db"
    full_index(root, db)
    return str(db)


class TestIndexingScale:
    def test_index_200_files_under_30s(self, tmp_path):
        root = tmp_path / "project"
        root.mkdir()
        _create_synthetic_project(root, num_packages=5, files_per_pkg=40)
        db = tmp_path / "test.db"

        start = time.perf_counter()
        full_index(root, db)
        elapsed = time.perf_counter() - start

        assert elapsed < 30, f"Indexing took {elapsed:.1f}s (expected <30s)"

        with GraphStore(str(db)) as store:
            nodes = store.get_all_nodes()
            edges = store.get_all_edges()

        assert len(nodes) > 200, f"Expected 200+ nodes, got {len(nodes)}"
        assert len(edges) > 200, f"Expected 200+ edges, got {len(edges)}"


class TestQueryScale:
    def test_coupling_analysis_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            analyzer = StructuralAnalyzer(store)
            start = time.perf_counter()
            result = analyzer.coupling_analysis()
            elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Coupling analysis took {elapsed:.1f}s"
        assert len(result["pairs"]) > 0

    def test_layer_detection_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            analyzer = StructuralAnalyzer(store)
            start = time.perf_counter()
            result = analyzer.detect_layers()
            elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Layer detection took {elapsed:.1f}s"
        assert len(result["layers"]) > 0

    def test_cohesion_analysis_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            analyzer = StructuralAnalyzer(store)
            start = time.perf_counter()
            result = analyzer.cohesion_analysis()
            elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Cohesion analysis took {elapsed:.1f}s"
        assert len(result) > 0

    def test_contracts_detection_under_10s(self, large_project):
        with GraphStore(large_project) as store:
            analyzer = StructuralAnalyzer(store)
            start = time.perf_counter()
            result = analyzer.detect_contracts()
            elapsed = time.perf_counter() - start

        assert elapsed < 10, f"Contract detection took {elapsed:.1f}s"

    def test_structural_patterns_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            analyzer = StructuralAnalyzer(store)
            start = time.perf_counter()
            result = analyzer.detect_structural_patterns()
            elapsed = time.perf_counter() - start

        assert elapsed < 5, f"Pattern detection took {elapsed:.1f}s"

    def test_health_score_under_10s(self, large_project):
        with GraphStore(large_project) as store:
            engine = ComprehensionEngine(store)
            start = time.perf_counter()
            result = engine.health_score()
            elapsed = time.perf_counter() - start

        assert elapsed < 10, f"Health score took {elapsed:.1f}s"
        assert "score" in result

    def test_impact_analysis_under_2s(self, large_project):
        with GraphStore(large_project) as store:
            engine = QueryEngine(store)
            nodes = store.get_all_nodes()
            target = next(n for n in nodes if n["type"] == "class")

            start = time.perf_counter()
            result = engine.impact_of_change(target["id"])
            elapsed = time.perf_counter() - start

        assert elapsed < 2, f"Impact analysis took {elapsed:.1f}s"


    def test_zoom_all_levels_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()

            sys_result = comp.zoom()
            assert sys_result["level"] == "system"

            # Module level
            nodes = store.get_all_nodes()
            file_paths = {n["file_path"] for n in nodes}
            if file_paths:
                comp.zoom(next(iter(file_paths)))

            # Symbol level
            functions = [n for n in nodes if n["type"] == "function"]
            if functions:
                comp.zoom(functions[0]["name"])

            elapsed = time.perf_counter() - start
            assert elapsed < 5, f"3 zoom levels took {elapsed:.1f}s (should be <5s)"

    def test_system_narrative_under_5s(self, large_project):
        with GraphStore(large_project) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()
            narrative = comp.system_narrative()
            elapsed = time.perf_counter() - start

        assert elapsed < 5, f"system_narrative took {elapsed:.1f}s (should be <5s)"
        assert "summary" in narrative


class TestErrorRecovery:
    def test_empty_db_doesnt_crash(self, tmp_path):
        db = str(tmp_path / "empty.db")
        with GraphStore(db) as store:
            analyzer = StructuralAnalyzer(store)
            assert analyzer.coupling_analysis() == {"pairs": [], "file_ranking": []}
            assert analyzer.cohesion_analysis() == []
            assert analyzer.detect_layers()["layers"] == []
            assert analyzer.detect_contracts() == []
            assert analyzer.detect_structural_patterns() == []

    def test_concurrent_read_access(self, large_project):
        with GraphStore(large_project) as store1, GraphStore(large_project) as store2:
            nodes1 = store1.get_all_nodes()
            nodes2 = store2.get_all_nodes()
            assert len(nodes1) == len(nodes2)
