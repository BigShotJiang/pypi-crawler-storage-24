"""Tests for the QueryEngine."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode


def _populate_store(store: GraphStore) -> None:
    """Insert a multi-file graph for query testing."""
    # File A: has function `entry` which calls `process`
    store.upsert_file(ParsedFile(
        path="a.py",
        content_hash="aaa",
        line_count=20,
        nodes=[
            ParsedNode(id="a.py::a", name="a", qualified_name="a", type="file",
                       file_path="a.py", line_start=1, line_end=20, is_exported=True),
            ParsedNode(id="a.py::entry", name="entry", qualified_name="entry", type="function",
                       file_path="a.py", line_start=3, line_end=8, is_exported=True),
        ],
        edges=[
            ParsedEdge(source="a.py::a", target="a.py::entry", type="CONTAINS", file_path="a.py", line=3),
            ParsedEdge(source="a.py::entry", target="b.py::process", type="CALLS", file_path="a.py", line=5),
            ParsedEdge(source="a.py::a", target="b.process", type="IMPORTS", file_path="a.py", line=1),
        ],
    ))

    # File B: has `process` which calls `helper`, and `unused_func`
    store.upsert_file(ParsedFile(
        path="b.py",
        content_hash="bbb",
        line_count=30,
        nodes=[
            ParsedNode(id="b.py::b", name="b", qualified_name="b", type="file",
                       file_path="b.py", line_start=1, line_end=30, is_exported=True),
            ParsedNode(id="b.py::process", name="process", qualified_name="process", type="function",
                       file_path="b.py", line_start=3, line_end=10, is_exported=True),
            ParsedNode(id="b.py::helper", name="helper", qualified_name="helper", type="function",
                       file_path="b.py", line_start=12, line_end=18, is_exported=True),
            ParsedNode(id="b.py::_unused_func", name="_unused_func", qualified_name="_unused_func",
                       type="function", file_path="b.py", line_start=20, line_end=25),
        ],
        edges=[
            ParsedEdge(source="b.py::b", target="b.py::process", type="CONTAINS", file_path="b.py", line=3),
            ParsedEdge(source="b.py::b", target="b.py::helper", type="CONTAINS", file_path="b.py", line=12),
            ParsedEdge(source="b.py::b", target="b.py::_unused_func", type="CONTAINS", file_path="b.py", line=20),
            ParsedEdge(source="b.py::process", target="b.py::helper", type="CALLS", file_path="b.py", line=7),
        ],
    ))


class TestResolveNode:
    def test_resolve_by_id(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        results = engine.resolve_node("b.py::process")
        assert len(results) == 1
        assert results[0]["id"] == "b.py::process"

    def test_resolve_by_name(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        results = engine.resolve_node("process")
        assert any(r["name"] == "process" for r in results)

    def test_resolve_no_match(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        results = engine.resolve_node("nonexistent_xyz")
        assert results == []


class TestCallChain:
    def test_forward_chain(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        chain = engine.get_call_chain("a.py::entry")
        targets = [c["node_id"] for c in chain]
        assert "b.py::process" in targets

    def test_chain_transitive(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        chain = engine.get_call_chain("a.py::entry", max_depth=5)
        targets = [c["node_id"] for c in chain]
        assert "b.py::helper" in targets

    def test_chain_max_depth(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        chain = engine.get_call_chain("a.py::entry", max_depth=1)
        assert all(c["depth"] <= 1 for c in chain)


class TestReverseDependencies:
    def test_reverse_deps(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        deps = engine.get_reverse_dependencies("b.py::process")
        sources = [d["node_id"] for d in deps]
        assert "a.py::entry" in sources


class TestImpactAnalysis:
    def test_impact_of_helper(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        impacted = engine.impact_of_change("b.py::helper")
        ids = [i["node_id"] for i in impacted]
        # helper is called by process, which is called by entry
        assert "b.py::process" in ids

    def test_impact_transitive(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        impacted = engine.impact_of_change("b.py::helper", max_depth=5)
        ids = [i["node_id"] for i in impacted]
        assert "a.py::entry" in ids


class TestDeadCode:
    def test_finds_dead_code(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "_unused_func" in dead_names

    def test_used_code_not_dead(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "helper" not in dead_names


class TestDeadCodeFrameworkExclusions:
    """Tests that framework entry points are excluded from dead code detection."""

    def test_excludes_test_functions(self, store: GraphStore) -> None:
        """Test functions in test files should not be flagged as dead code."""
        store.upsert_file(ParsedFile(
            path="tests/test_something.py",
            content_hash="ttt",
            line_count=10,
            nodes=[
                ParsedNode(id="tests/test_something.py::f", name="test_something", qualified_name="test_something",
                           type="file", file_path="tests/test_something.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="tests/test_something.py::test_foo", name="test_foo", qualified_name="test_foo",
                           type="function", file_path="tests/test_something.py", line_start=3, line_end=8),
            ],
            edges=[
                ParsedEdge(source="tests/test_something.py::f", target="tests/test_something.py::test_foo",
                           type="CONTAINS", file_path="tests/test_something.py", line=3),
            ],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "test_foo" not in dead_names

    def test_excludes_test_classes(self, store: GraphStore) -> None:
        """Test classes should not be flagged as dead code."""
        store.upsert_file(ParsedFile(
            path="tests/test_cls.py",
            content_hash="tc",
            line_count=10,
            nodes=[
                ParsedNode(id="tests/test_cls.py::f", name="test_cls", qualified_name="test_cls",
                           type="file", file_path="tests/test_cls.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="tests/test_cls.py::TestMyClass", name="TestMyClass", qualified_name="TestMyClass",
                           type="class", file_path="tests/test_cls.py", line_start=3, line_end=8),
            ],
            edges=[],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "TestMyClass" not in dead_names

    def test_excludes_fixture_decorated(self, store: GraphStore) -> None:
        """Functions with fixture decorator should not be flagged as dead."""
        store.upsert_file(ParsedFile(
            path="conftest.py",
            content_hash="cf",
            line_count=10,
            nodes=[
                ParsedNode(id="conftest.py::f", name="conftest", qualified_name="conftest",
                           type="file", file_path="conftest.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="conftest.py::my_fixture", name="my_fixture", qualified_name="my_fixture",
                           type="function", file_path="conftest.py", line_start=3, line_end=8,
                           decorators=["pytest.fixture"]),
            ],
            edges=[],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "my_fixture" not in dead_names

    def test_excludes_cli_commands(self, store: GraphStore) -> None:
        """Functions with click.command decorator should not be flagged as dead."""
        store.upsert_file(ParsedFile(
            path="cli.py",
            content_hash="cl",
            line_count=10,
            nodes=[
                ParsedNode(id="cli.py::f", name="cli", qualified_name="cli",
                           type="file", file_path="cli.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="cli.py::init_cmd", name="init_cmd", qualified_name="init_cmd",
                           type="function", file_path="cli.py", line_start=3, line_end=8,
                           decorators=["click.command"]),
            ],
            edges=[],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "init_cmd" not in dead_names

    def test_excludes_class_methods(self, store: GraphStore) -> None:
        """Methods in classes with incoming edges should not be flagged as dead."""
        store.upsert_file(ParsedFile(
            path="mymod.py",
            content_hash="mm",
            line_count=20,
            nodes=[
                ParsedNode(id="mymod.py::f", name="mymod", qualified_name="mymod",
                           type="file", file_path="mymod.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="mymod.py::MyClass", name="MyClass", qualified_name="MyClass",
                           type="class", file_path="mymod.py", line_start=3, line_end=15, is_exported=True),
                ParsedNode(id="mymod.py::MyClass.do_stuff", name="do_stuff", qualified_name="MyClass.do_stuff",
                           type="method", file_path="mymod.py", line_start=5, line_end=10),
            ],
            edges=[
                ParsedEdge(source="mymod.py::MyClass", target="mymod.py::MyClass.do_stuff",
                           type="CONTAINS", file_path="mymod.py", line=5),
            ],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "do_stuff" not in dead_names

    def test_still_finds_truly_dead_code(self, store: GraphStore) -> None:
        """Genuinely unused code should still be flagged."""
        _populate_store(store)
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "_unused_func" in dead_names


class TestFileDependencies:
    def test_file_deps(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        deps = engine.get_file_dependencies("a.py")
        assert "b.process" in deps


class TestModuleStructure:
    def test_module_structure(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        structure = engine.get_module_structure("b.py")
        names = [s["name"] for s in structure]
        assert "process" in names
        assert "helper" in names


class TestSearch:
    def test_search_by_name(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        results = engine.search_nodes("proc")
        assert any(r["name"] == "process" for r in results)

    def test_search_no_results(self, store: GraphStore) -> None:
        _populate_store(store)
        engine = QueryEngine(store)
        results = engine.search_nodes("zzzzz_no_match")
        assert results == []


def _populate_class_store(store: GraphStore) -> None:
    """Insert a graph with class methods and self.X calls (resolved + legacy)."""
    store.upsert_file(ParsedFile(
        path="svc.py",
        content_hash="svc1",
        line_count=30,
        nodes=[
            ParsedNode(id="svc.py::svc", name="svc", qualified_name="svc", type="file",
                       file_path="svc.py", line_start=1, line_end=30, is_exported=True),
            ParsedNode(id="svc.py::Service", name="Service", qualified_name="Service", type="class",
                       file_path="svc.py", line_start=3, line_end=25, is_exported=True),
            ParsedNode(id="svc.py::Service.handle", name="handle", qualified_name="Service.handle", type="method",
                       file_path="svc.py", line_start=5, line_end=10),
            ParsedNode(id="svc.py::Service.process", name="process", qualified_name="Service.process", type="method",
                       file_path="svc.py", line_start=12, line_end=20),
        ],
        edges=[
            ParsedEdge(source="svc.py::Service", target="svc.py::Service.handle", type="CONTAINS", file_path="svc.py", line=5),
            ParsedEdge(source="svc.py::Service", target="svc.py::Service.process", type="CONTAINS", file_path="svc.py", line=12),
            # Resolved edge: handle calls Service.process (new parser behavior)
            ParsedEdge(source="svc.py::Service.handle", target="Service.process", type="CALLS", file_path="svc.py", line=7),
        ],
    ))
    # Caller file
    store.upsert_file(ParsedFile(
        path="app.py",
        content_hash="app1",
        line_count=10,
        nodes=[
            ParsedNode(id="app.py::app", name="app", qualified_name="app", type="file",
                       file_path="app.py", line_start=1, line_end=10, is_exported=True),
            ParsedNode(id="app.py::main", name="main", qualified_name="main", type="function",
                       file_path="app.py", line_start=3, line_end=8, is_exported=True),
        ],
        edges=[
            ParsedEdge(source="app.py::main", target="Service.handle", type="CALLS", file_path="app.py", line=5),
        ],
    ))


class TestInstanceMethodImpact:
    """Verify impact analysis works for instance methods via qualified_name matching."""

    def test_impact_finds_caller_via_qname(self, store: GraphStore) -> None:
        _populate_class_store(store)
        engine = QueryEngine(store)
        impacted = engine.impact_of_change("svc.py::Service.handle")
        ids = [i["node_id"] for i in impacted]
        assert "app.py::main" in ids

    def test_impact_transitive_through_method(self, store: GraphStore) -> None:
        _populate_class_store(store)
        engine = QueryEngine(store)
        impacted = engine.impact_of_change("svc.py::Service.process", max_depth=5)
        ids = [i["node_id"] for i in impacted]
        # process is called by handle, which is called by main
        assert "svc.py::Service.handle" in ids


class TestCallChainWithMethods:
    """Verify call chain traverses through resolved method targets."""

    def test_call_chain_follows_method(self, store: GraphStore) -> None:
        _populate_class_store(store)
        engine = QueryEngine(store)
        chain = engine.get_call_chain("svc.py::Service.handle")
        targets = [c["node_id"] for c in chain]
        assert "svc.py::Service.process" in targets


class TestBackwardCompatSelfEdges:
    """Verify that old-style self.X edges are still found via backward compat."""

    def test_impact_with_legacy_self_edges(self, store: GraphStore) -> None:
        """Insert legacy self.X edges and verify impact still works."""
        store.upsert_file(ParsedFile(
            path="old.py",
            content_hash="old1",
            line_count=20,
            nodes=[
                ParsedNode(id="old.py::old", name="old", qualified_name="old", type="file",
                           file_path="old.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="old.py::OldClass", name="OldClass", qualified_name="OldClass", type="class",
                           file_path="old.py", line_start=3, line_end=18, is_exported=True),
                ParsedNode(id="old.py::OldClass.caller", name="caller", qualified_name="OldClass.caller", type="method",
                           file_path="old.py", line_start=5, line_end=10),
                ParsedNode(id="old.py::OldClass.target", name="target", qualified_name="OldClass.target", type="method",
                           file_path="old.py", line_start=12, line_end=16),
            ],
            edges=[
                ParsedEdge(source="old.py::OldClass", target="old.py::OldClass.caller", type="CONTAINS", file_path="old.py", line=5),
                ParsedEdge(source="old.py::OldClass", target="old.py::OldClass.target", type="CONTAINS", file_path="old.py", line=12),
                # Legacy self.X edge (from old parser)
                ParsedEdge(source="old.py::OldClass.caller", target="self.target", type="CALLS", file_path="old.py", line=7),
            ],
        ))
        engine = QueryEngine(store)
        impacted = engine.impact_of_change("old.py::OldClass.target")
        ids = [i["node_id"] for i in impacted]
        assert "old.py::OldClass.caller" in ids

    def test_dead_code_with_legacy_self_edges(self, store: GraphStore) -> None:
        """Methods called via legacy self.X edges should not be flagged as dead."""
        store.upsert_file(ParsedFile(
            path="legacy.py",
            content_hash="leg1",
            line_count=20,
            nodes=[
                ParsedNode(id="legacy.py::legacy", name="legacy", qualified_name="legacy", type="file",
                           file_path="legacy.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="legacy.py::Cls", name="Cls", qualified_name="Cls", type="class",
                           file_path="legacy.py", line_start=3, line_end=18, is_exported=True),
                ParsedNode(id="legacy.py::Cls.called_method", name="called_method", qualified_name="Cls.called_method",
                           type="method", file_path="legacy.py", line_start=5, line_end=10),
                ParsedNode(id="legacy.py::Cls.caller_method", name="caller_method", qualified_name="Cls.caller_method",
                           type="method", file_path="legacy.py", line_start=12, line_end=16),
            ],
            edges=[
                ParsedEdge(source="legacy.py::Cls", target="legacy.py::Cls.called_method", type="CONTAINS", file_path="legacy.py", line=5),
                ParsedEdge(source="legacy.py::Cls", target="legacy.py::Cls.caller_method", type="CONTAINS", file_path="legacy.py", line=12),
                # Legacy self.X edge
                ParsedEdge(source="legacy.py::Cls.caller_method", target="self.called_method", type="CALLS", file_path="legacy.py", line=14),
            ],
        ))
        engine = QueryEngine(store)
        dead = engine.find_dead_code()
        dead_names = [d["name"] for d in dead]
        assert "called_method" not in dead_names

    def test_preload_reverse_index_maps_self_edges(self, store: GraphStore) -> None:
        """preload_reverse_index should map self.X edges to method nodes."""
        store.upsert_file(ParsedFile(
            path="preload.py",
            content_hash="pre1",
            line_count=20,
            nodes=[
                ParsedNode(id="preload.py::preload", name="preload", qualified_name="preload", type="file",
                           file_path="preload.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="preload.py::Svc", name="Svc", qualified_name="Svc", type="class",
                           file_path="preload.py", line_start=3, line_end=18, is_exported=True),
                ParsedNode(id="preload.py::Svc.do_work", name="do_work", qualified_name="Svc.do_work", type="method",
                           file_path="preload.py", line_start=5, line_end=10),
                ParsedNode(id="preload.py::Svc.caller", name="caller", qualified_name="Svc.caller", type="method",
                           file_path="preload.py", line_start=12, line_end=16),
            ],
            edges=[
                ParsedEdge(source="preload.py::Svc", target="preload.py::Svc.do_work", type="CONTAINS", file_path="preload.py", line=5),
                ParsedEdge(source="preload.py::Svc", target="preload.py::Svc.caller", type="CONTAINS", file_path="preload.py", line=12),
                ParsedEdge(source="preload.py::Svc.caller", target="self.do_work", type="CALLS", file_path="preload.py", line=14),
            ],
        ))
        engine = QueryEngine(store)
        engine.preload_reverse_index()
        edges = engine._get_incoming_edges("preload.py::Svc.do_work")
        call_sources = [e["source"] for e in edges if e["type"] == "CALLS"]
        assert "preload.py::Svc.caller" in call_sources
