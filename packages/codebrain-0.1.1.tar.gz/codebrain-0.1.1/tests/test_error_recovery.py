"""M20: Error recovery — corrupted DB rebuild, permission errors, graceful degradation."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from codebrain.cli import cli
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.indexer import full_index


@pytest.fixture
def indexed_project(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text("def greet():\n    pass\n", encoding="utf-8")

    db = root / CODEBRAIN_DIR / DB_FILENAME
    db.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db)
    return root


class TestErrorRecovery:

    def test_corrupted_db_auto_rebuilds(self, indexed_project):
        root = indexed_project
        db = root / CODEBRAIN_DIR / DB_FILENAME

        # Corrupt the database
        db.write_bytes(b"this is not a valid sqlite database")

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "status"])
        # Should auto-rebuild and succeed
        assert result.exit_code == 0, f"Should recover: {result.output}"

    def test_missing_db_gives_helpful_error(self, tmp_path):
        root = tmp_path / "repo"
        root.mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "status"])
        assert result.exit_code != 0
        assert "brain init" in result.output.lower() or "not initialized" in result.output.lower()

    def test_safe_command_catches_exceptions(self, indexed_project):
        runner = CliRunner()
        # Search for something that won't crash but tests the safe wrapper
        result = runner.invoke(cli, ["--repo", str(indexed_project), "search", "nonexistent_xyz"])
        assert result.exit_code == 0  # Should not crash

    def test_verbose_shows_traceback(self, tmp_path):
        root = tmp_path / "empty"
        root.mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "--verbose", "status"])
        # Should fail but with more info
        assert result.exit_code != 0


class TestRepairCommand:

    def test_repair_ok_database(self, indexed_project):
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(indexed_project), "repair"])
        assert result.exit_code == 0
        assert "OK" in result.output

    def test_repair_corrupted_database(self, indexed_project):
        root = indexed_project
        db = root / CODEBRAIN_DIR / DB_FILENAME
        db.write_bytes(b"corrupted data here")

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "repair"])
        assert result.exit_code == 0
        assert "Rebuilt" in result.output

    def test_repair_no_database(self, tmp_path):
        root = tmp_path / "repo"
        root.mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "repair"])
        assert result.exit_code == 0
        assert "brain init" in result.output.lower() or "not found" in result.output.lower()


class TestCheckIntegrity:

    def test_integrity_check_on_good_db(self, indexed_project):
        from codebrain.graph.store import GraphStore
        db = indexed_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            assert store.check_integrity() is True

    def test_execute_with_retry(self, indexed_project):
        from codebrain.graph.store import GraphStore
        db = indexed_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            result = store._execute_with_retry("SELECT 1")
            assert result.fetchone()[0] == 1


class TestFileSizeLimit:

    def test_large_file_skipped(self, tmp_path):
        from codebrain.indexer import discover_files
        from codebrain.settings import Settings

        root = tmp_path / "project"
        root.mkdir()
        # Create a small file (should be included)
        (root / "small.py").write_text("x = 1\n")
        # Create a large file (should be skipped)
        (root / "large.py").write_text("x = 1\n" * 200_000)  # ~1.2MB

        settings = Settings(max_file_size_kb=100)  # 100KB limit
        files = discover_files(root, settings=settings)
        names = [f.name for f in files]
        assert "small.py" in names
        assert "large.py" not in names


class TestIndexCompleteness:

    def test_status_includes_index_completeness(self, indexed_project):
        """M20: `brain status --json` must include index_completeness field."""
        import json as _json

        root = indexed_project
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "status", "--json"])
        assert result.exit_code == 0, f"status failed: {result.output}"

        data = _json.loads(result.output)
        assert "index_completeness" in data
        ic = data["index_completeness"]
        assert "indexed" in ic
        assert "total" in ic
        assert "complete" in ic
        # After full_index, indexed should equal total
        assert ic["indexed"] == ic["total"]
        assert ic["complete"] is True

    def test_partial_index_detected(self, tmp_path):
        """M20: Partial index should show indexed < total."""
        import json as _json
        from codebrain.graph.store import GraphStore

        root = tmp_path / "repo"
        root.mkdir()
        pkg = root / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("", encoding="utf-8")
        (pkg / "a.py").write_text("def aa():\n    pass\n", encoding="utf-8")
        (pkg / "b.py").write_text("def bb():\n    pass\n", encoding="utf-8")

        # Index only, then add another file AFTER indexing
        db = root / CODEBRAIN_DIR / DB_FILENAME
        db.parent.mkdir(parents=True, exist_ok=True)
        full_index(root, db)

        # Add a new file that wasn't indexed
        (pkg / "c.py").write_text("def cc():\n    pass\n", encoding="utf-8")

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "status", "--json"])
        assert result.exit_code == 0
        data = _json.loads(result.output)
        ic = data["index_completeness"]
        # indexed should be less than total now
        assert ic["indexed"] < ic["total"]


class TestConcurrentAccess:

    def test_concurrent_read_access(self, indexed_project):
        from codebrain.graph.store import GraphStore
        db = indexed_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store1, GraphStore(db) as store2:
            nodes1 = store1.get_all_nodes()
            nodes2 = store2.get_all_nodes()
            assert len(nodes1) == len(nodes2)
