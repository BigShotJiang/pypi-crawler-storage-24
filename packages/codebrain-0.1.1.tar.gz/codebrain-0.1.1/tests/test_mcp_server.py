"""Tests for the MCP server tools."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from codebrain.graph.store import GraphStore

try:
    from codebrain.mcp_server import _find_db, _get_repo_root
    _MCP_AVAILABLE = True
except (TypeError, ImportError):
    _MCP_AVAILABLE = False

pytestmark = pytest.mark.skipif(not _MCP_AVAILABLE, reason="MCP server failed to import (API mismatch)")


@pytest.fixture
def mcp_project(indexed_project):
    """Patch _find_db and _get_repo_root for MCP server tests."""
    repo_root, store = indexed_project
    db_path = store.db_path
    store.close()

    with patch("codebrain.mcp_server._find_db", return_value=db_path), \
         patch("codebrain.mcp_server._get_repo_root", return_value=repo_root):
        yield repo_root, db_path


class TestSearchSymbol:
    def test_search_returns_json(self, mcp_project):
        from codebrain.mcp_server import search_symbol
        result = search_symbol("process")
        data = json.loads(result)
        assert isinstance(data, list)
        assert len(data) > 0

    def test_search_no_results(self, mcp_project):
        from codebrain.mcp_server import search_symbol
        result = search_symbol("nonexistent_xyz_abc")
        data = json.loads(result)
        assert isinstance(data, list)
        assert len(data) == 0


class TestGetSymbolContext:
    def test_symbol_context(self, mcp_project):
        from codebrain.mcp_server import get_symbol_context
        result = get_symbol_context("process")
        data = json.loads(result)
        assert isinstance(data, list)
        assert data[0]["name"] == "process"

    def test_symbol_not_found(self, mcp_project):
        from codebrain.mcp_server import get_symbol_context
        result = get_symbol_context("nonexistent_xyz")
        data = json.loads(result)
        assert "error" in data


class TestGetFileContext:
    def test_file_context(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("mypackage/core.py")
        data = json.loads(result)
        assert data["file_path"] == "mypackage/core.py"

    def test_file_not_found(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("nonexistent.py")
        data = json.loads(result)
        assert "error" in data


class TestValidateChange:
    def test_validate_existing_file(self, mcp_project):
        from codebrain.mcp_server import validate_change
        result = validate_change("mypackage/core.py")
        data = json.loads(result)
        assert "is_valid" in data

    def test_validate_deleted_file(self, mcp_project):
        from codebrain.mcp_server import validate_change
        result = validate_change("mypackage/nonexistent.py")
        data = json.loads(result)
        assert "is_valid" in data


class TestImpactAnalysis:
    def test_impact(self, mcp_project):
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("helper")
        data = json.loads(result)
        assert "narrative" in data
        assert "details" in data
        assert isinstance(data["details"], list)

    def test_impact_not_found(self, mcp_project):
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("nonexistent_xyz")
        data = json.loads(result)
        assert "error" in data


class TestCallChain:
    def test_call_chain(self, mcp_project):
        from codebrain.mcp_server import call_chain
        result = call_chain("process")
        data = json.loads(result)
        assert "narrative" in data
        assert "details" in data
        assert isinstance(data["details"], list)


class TestCodebaseOverview:
    def test_overview(self, mcp_project):
        from codebrain.mcp_server import codebase_overview
        result = codebase_overview()
        data = json.loads(result)
        assert "stats" in data
        assert "packages" in data


class TestModuleOverview:
    def test_module(self, mcp_project):
        from codebrain.mcp_server import module_overview
        result = module_overview("mypackage/core.py")
        data = json.loads(result)
        assert "file_path" in data


class TestRiskHotspots:
    def test_hotspots(self, mcp_project):
        from codebrain.mcp_server import risk_hotspots
        result = risk_hotspots()
        data = json.loads(result)
        assert isinstance(data, list)


class TestFindDeadCode:
    def test_dead_code(self, mcp_project):
        from codebrain.mcp_server import find_dead_code
        result = find_dead_code()
        data = json.loads(result)
        assert "high_confidence" in data
        assert "medium_confidence" in data
        assert "low_confidence" in data
        assert "total_dead_code_found" in data
        assert isinstance(data["high_confidence"], list)


class TestDetectCycles:
    def test_cycles(self, mcp_project):
        from codebrain.mcp_server import detect_import_cycles
        result = detect_import_cycles()
        data = json.loads(result)
        assert "narrative" in data
        assert "cycles" in data
        assert isinstance(data["cycles"], list)


class TestArchitecturalLayers:
    def test_layers(self, mcp_project):
        from codebrain.mcp_server import architectural_layers
        result = architectural_layers()
        data = json.loads(result)
        assert "layers" in data


class TestImplicitContracts:
    def test_contracts(self, mcp_project):
        from codebrain.mcp_server import implicit_contracts
        result = implicit_contracts()
        data = json.loads(result)
        assert "items" in data
        assert "total_contracts_found" in data
        assert isinstance(data["items"], list)


class TestGetTaskContext:
    def test_task_context(self, mcp_project):
        from codebrain.mcp_server import get_task_context
        result = get_task_context("Fix the process function", ["process"])
        data = json.loads(result)
        assert "symbols" in data


class TestImpactAnalysisFileLevel:
    """A1: impact_analysis should expand file-level nodes to symbols."""

    def test_file_path_returns_results(self, mcp_project):
        """Querying a file path should expand to its symbols and return impact."""
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("mypackage/core.py")
        data = json.loads(result)
        assert "narrative" in data
        assert "details" in data
        assert isinstance(data["details"], list)

    def test_file_node_expansion_has_symbol_targets(self, mcp_project):
        """File-level query should produce targets that are symbols, not files."""
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("mypackage/utils.py")
        data = json.loads(result)
        assert isinstance(data["details"], list)
        # utils.py contains helper() which is called by core.py
        # So we should get at least one result with a symbol target
        if data["details"]:
            # All targets should be symbol IDs (contain ::), not file paths
            for entry in data["details"]:
                assert "::" in entry["target"]


class TestCallChainFileLevel:
    """A1: call_chain should expand file-level nodes to symbols."""

    def test_file_path_returns_chains(self, mcp_project):
        """Querying a file path should expand to its symbols and return call chains."""
        from codebrain.mcp_server import call_chain
        result = call_chain("mypackage/core.py")
        data = json.loads(result)
        assert "narrative" in data
        assert "details" in data
        assert isinstance(data["details"], list)
        # core.py has process() which calls helper() and transform()
        if data["details"]:
            for entry in data["details"]:
                assert "::" in entry["root"]


class TestArchitecturalLayersTruncation:
    """A3: architectural_layers should truncate files list and add metadata."""

    def test_layers_have_summary(self, mcp_project):
        """Each layer should have a summary string."""
        from codebrain.mcp_server import architectural_layers
        result = architectural_layers()
        data = json.loads(result)
        assert "layers" in data
        for layer in data["layers"]:
            assert "summary" in layer
            assert "total_files" in layer
            assert "files_truncated" in layer
            assert isinstance(layer["summary"], str)
            assert "files" in layer["summary"]

    def test_truncation_with_small_top_n(self, mcp_project):
        """With top_n=1, layers with >1 file should be truncated."""
        from codebrain.mcp_server import architectural_layers
        result = architectural_layers(top_n=1)
        data = json.loads(result)
        for layer in data["layers"]:
            assert len(layer["files"]) <= 1
            if layer["total_files"] > 1:
                assert layer["files_truncated"] is True


class TestFileContextTruncation:
    def test_truncation_with_small_top_n(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("mypackage/core.py", top_n=2)
        data = json.loads(result)
        # core.py has >2 symbols (process, transform, DataProcessor, etc.)
        if "total_symbols" in data:
            assert len(data["symbols"]) == 2
            assert data["total_symbols"] > 2
        else:
            # If there are <=2 symbols, truncation shouldn't kick in
            assert len(data["symbols"]) <= 2


class TestGetSymbolContextFileRedirect:
    """get_symbol_context should auto-redirect file paths to file context."""

    def test_file_path_redirects(self, mcp_project):
        """Passing a file path should return file context with _note."""
        from codebrain.mcp_server import get_symbol_context
        result = get_symbol_context("mypackage/core.py")
        data = json.loads(result)
        assert "_note" in data
        assert "file" in data["_note"].lower()
        assert data.get("type") == "file_context"
        assert data.get("file_path") == "mypackage/core.py"

    def test_symbol_name_still_works(self, mcp_project):
        """Passing a plain symbol name should still return symbol context."""
        from codebrain.mcp_server import get_symbol_context
        result = get_symbol_context("process")
        data = json.loads(result)
        assert isinstance(data, list)
        assert data[0]["name"] == "process"
        assert "_note" not in data[0]


class TestValidateChangeActionable:
    """validate_change should include caller details and remediation."""

    def test_violations_have_callers(self, mcp_project):
        """Violations for removed symbols should include callers list."""
        repo_root, db_path = mcp_project
        # Remove a called symbol to trigger a violation
        core_path = repo_root / "mypackage" / "core.py"
        original = core_path.read_text()
        # Remove the `process` function — it's called from __init__.py
        new_content = original.replace(
            'def process(data):\n    """Process incoming data."""\n    result = helper(data)\n    return transform(result)\n',
            ""
        )
        core_path.write_text(new_content)

        from codebrain.mcp_server import validate_change
        result = validate_change("mypackage/core.py")
        data = json.loads(result)

        # Find removed_symbol violations
        removed = [v for v in data.get("violations", []) if v["category"] == "removed_symbol"]
        if removed:
            # At least one should have callers populated
            assert any(len(v.get("callers", [])) > 0 for v in removed)

        # Restore original
        core_path.write_text(original)

    def test_has_remediation(self, mcp_project):
        """When violations exist, result should include remediation guidance."""
        repo_root, db_path = mcp_project
        core_path = repo_root / "mypackage" / "core.py"
        original = core_path.read_text()
        # Remove `process` to trigger violations
        new_content = original.replace(
            'def process(data):\n    """Process incoming data."""\n    result = helper(data)\n    return transform(result)\n',
            ""
        )
        core_path.write_text(new_content)

        from codebrain.mcp_server import validate_change
        result = validate_change("mypackage/core.py")
        data = json.loads(result)

        if data.get("violations"):
            assert "remediation" in data
            assert isinstance(data["remediation"], list)
            assert len(data["remediation"]) > 0

        # Restore original
        core_path.write_text(original)


class TestFindDeadCodeFiltering:
    """find_dead_code should exclude variables and include a note."""

    def test_no_variables_in_dead_code(self, mcp_project):
        """Variables should not appear in dead code results."""
        from codebrain.mcp_server import find_dead_code
        result = find_dead_code()
        data = json.loads(result)
        all_items = data.get("high_confidence", []) + data.get("medium_confidence", []) + data.get("low_confidence", [])
        for item in all_items:
            assert item["type"] != "variable", f"Variable '{item['name']}' should not be in dead code"

    def test_has_note(self, mcp_project):
        """Dead code response should include an explanatory note."""
        from codebrain.mcp_server import find_dead_code
        result = find_dead_code()
        data = json.loads(result)
        assert "note" in data
        assert "variables" in data["note"].lower() or "constants" in data["note"].lower()


class TestAskCodebaseContext:
    """ask_codebase should return structured answer with intent detection."""

    def test_ask_codebase_returns_structured_answer(self, mcp_project):
        from codebrain.mcp_server import ask_codebase
        result = ask_codebase("What are the riskiest modules?")
        data = json.loads(result)
        assert "question" in data
        assert "intent" in data
        assert "answer" in data
        assert "data" in data
        assert "sources" in data
        assert "suggestions" in data
        assert data["intent"] == "risk"
        assert isinstance(data["data"], list)
        assert len(data["answer"]) > 0


class TestProposeChange:
    """propose_change should validate content before writing."""

    def test_safe_change_returns_safe(self, mcp_project):
        repo_root, db_path = mcp_project
        # Read existing file and propose it unchanged — should be SAFE
        core_path = repo_root / "mypackage" / "core.py"
        content = core_path.read_text()

        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", content)
        data = json.loads(result)
        assert data["verdict"] == "SAFE"
        assert "narrative" in data

    def test_breaking_change_returns_unsafe(self, mcp_project):
        repo_root, db_path = mcp_project
        # Remove an exported function — should be CAUTION or UNSAFE
        core_path = repo_root / "mypackage" / "core.py"
        original = core_path.read_text()
        broken = original.replace(
            'def process(data):\n    """Process incoming data."""\n    result = helper(data)\n    return transform(result)\n',
            ""
        )

        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", broken)
        data = json.loads(result)
        assert data["verdict"] in ("CAUTION", "UNSAFE")
        assert len(data.get("violations", [])) > 0

    def test_syntax_error_returns_unsafe(self, mcp_project):
        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", "def broken(:\n")
        data = json.loads(result)
        assert data["verdict"] == "UNSAFE"
        assert any(v["category"] == "syntax_error" for v in data.get("violations", []))


class TestNarrativesPresent:
    """MCP tools should include narrative summaries."""

    def test_file_context_has_narrative(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("mypackage/core.py")
        data = json.loads(result)
        assert "narrative" in data
        assert "summary" in data["narrative"]

    def test_symbol_context_has_narrative(self, mcp_project):
        from codebrain.mcp_server import get_symbol_context
        result = get_symbol_context("process")
        data = json.loads(result)
        assert isinstance(data, list)
        # At least one result should have narrative
        assert any("narrative" in ctx for ctx in data)

    def test_impact_has_narrative(self, mcp_project):
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("helper")
        data = json.loads(result)
        assert "narrative" in data

    def test_call_chain_has_narrative(self, mcp_project):
        from codebrain.mcp_server import call_chain
        result = call_chain("process")
        data = json.loads(result)
        assert "narrative" in data

    def test_modules_has_narrative(self, mcp_project):
        from codebrain.mcp_server import query_modules
        result = query_modules()
        data = json.loads(result)
        assert "narrative" in data


class TestProposeChangeGate:
    """M2: propose_change returns structured verdict with files_to_update."""

    def test_safe_response_is_short(self, mcp_project):
        repo_root, db_path = mcp_project
        core_path = repo_root / "mypackage" / "core.py"
        content = core_path.read_text()

        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", content)
        data = json.loads(result)
        assert data["verdict"] == "SAFE"
        # SAFE response should have changes summary, NOT full violations
        assert "changes" in data
        assert "violations" not in data

    def test_unsafe_has_files_to_update(self, mcp_project):
        repo_root, db_path = mcp_project
        core_path = repo_root / "mypackage" / "core.py"
        original = core_path.read_text()
        broken = original.replace(
            'def process(data):\n    """Process incoming data."""\n    result = helper(data)\n    return transform(result)\n',
            ""
        )

        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", broken)
        data = json.loads(result)
        assert data["verdict"] in ("CAUTION", "UNSAFE")
        assert "files_to_update" in data
        assert "violations" in data
        assert "remediation" in data

    def test_verdict_is_first_key(self, mcp_project):
        repo_root, db_path = mcp_project
        core_path = repo_root / "mypackage" / "core.py"
        content = core_path.read_text()

        from codebrain.mcp_server import propose_change
        result = propose_change("mypackage/core.py", content)
        data = json.loads(result)
        first_key = list(data.keys())[0]
        assert first_key == "verdict"


class TestValidateAfterWrite:
    """M2: validate_after_write checks files post-write."""

    def test_valid_file_returns_pass(self, mcp_project):
        from codebrain.mcp_server import validate_after_write
        result = validate_after_write(["mypackage/core.py"])
        data = json.loads(result)
        assert data["verdict"] == "PASS"
        assert data["files"][0]["status"] == "OK"

    def test_missing_file_returns_fail(self, mcp_project):
        from codebrain.mcp_server import validate_after_write
        result = validate_after_write(["nonexistent/file.py"])
        data = json.loads(result)
        assert data["verdict"] == "FAIL"
        assert data["files"][0]["status"] == "MISSING"


class TestAgentBridgeGate:
    """M2: generated CLAUDE.md contains structural safety gate."""

    def test_claude_md_has_gate_instruction(self, mcp_project):
        repo_root, db_path = mcp_project
        from codebrain.agent_bridge import generate_claude_md
        content = generate_claude_md(repo_root)
        assert "propose_change" in content
        assert "UNSAFE" in content
        assert "Structural Safety Gate" in content

    def test_gate_appears_before_packages(self, mcp_project):
        repo_root, db_path = mcp_project
        from codebrain.agent_bridge import generate_claude_md
        content = generate_claude_md(repo_root)
        gate_pos = content.index("Structural Safety Gate")
        packages_pos = content.index("Packages")
        assert gate_pos < packages_pos, "Gate instruction must appear before codebase context"


class TestMCPBadInput:
    """M20: MCP tools must return valid JSON on bad input, never tracebacks."""

    def test_search_symbol_empty_string(self, mcp_project):
        from codebrain.mcp_server import search_symbol
        result = search_symbol("")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, (list, dict))

    def test_search_symbol_long_wildcard(self, mcp_project):
        from codebrain.mcp_server import search_symbol
        result = search_symbol("*" * 1000)
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, (list, dict))

    def test_get_file_context_empty_string(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, dict)

    def test_get_file_context_nonexistent(self, mcp_project):
        from codebrain.mcp_server import get_file_context
        result = get_file_context("totally/nonexistent/file.py")
        data = json.loads(result)
        assert "Traceback" not in result
        assert "error" in data

    def test_impact_analysis_empty_string(self, mcp_project):
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, dict)

    def test_impact_analysis_nonexistent_symbol(self, mcp_project):
        from codebrain.mcp_server import impact_analysis
        result = impact_analysis("completely_nonexistent_symbol_xyz")
        data = json.loads(result)
        assert "Traceback" not in result
        assert "error" in data

    def test_call_chain_empty_string(self, mcp_project):
        from codebrain.mcp_server import call_chain
        result = call_chain("")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, dict)

    def test_propose_change_empty_path(self, mcp_project):
        from codebrain.mcp_server import propose_change
        result = propose_change("", "")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, dict)

    def test_module_overview_nonexistent(self, mcp_project):
        from codebrain.mcp_server import module_overview
        result = module_overview("nonexistent/path.py")
        data = json.loads(result)
        assert "Traceback" not in result
        assert isinstance(data, dict)
