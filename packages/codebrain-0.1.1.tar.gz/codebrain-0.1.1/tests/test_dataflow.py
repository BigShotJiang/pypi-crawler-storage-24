"""M15: Dataflow accuracy — test all DATAFLOW edge patterns."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.parser.python_parser import parse_file


@pytest.fixture
def parse(tmp_path):
    """Helper to parse a Python snippet and return edges."""
    def _parse(code: str) -> list[dict]:
        f = tmp_path / "test_mod.py"
        f.write_text(code, encoding="utf-8")
        result = parse_file(f, tmp_path)
        return [{"source": e.source, "target": e.target, "type": e.type} for e in result.edges]
    return _parse


class TestDataflowEdges:

    def test_var_assignment_from_call(self, parse):
        edges = parse("def foo():\n    x = bar()\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("bar" in e["target"] for e in df)

    def test_return_call(self, parse):
        edges = parse("def foo():\n    return bar()\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("bar" in e["target"] for e in df)

    def test_nested_call(self, parse):
        edges = parse("def foo():\n    outer(inner())\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("inner" in e["source"] or "inner" in e["target"] for e in df)

    def test_yield_call(self, parse):
        edges = parse("def gen():\n    yield fetch()\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("fetch" in e["target"] for e in df)

    def test_await_call(self, parse):
        edges = parse("async def foo():\n    await fetch()\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("fetch" in e["target"] for e in df)

    def test_keyword_arg_call(self, parse):
        edges = parse("def foo():\n    outer(key=inner())\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert any("inner" in e["source"] or "inner" in e["target"] for e in df)

    def test_no_spurious_dataflow(self, parse):
        """Simple variable assignment should NOT create DATAFLOW."""
        edges = parse("def foo():\n    x = 42\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        assert len(df) == 0

    def test_chained_calls_produce_dataflow(self, parse):
        edges = parse("def foo():\n    result = process(load())\n")
        df = [e for e in edges if e["type"] == "DATAFLOW"]
        # load() feeds into process()
        assert any("load" in e["source"] for e in df)


# ---------------------------------------------------------------------------
# Integration tests: index a small project and verify DATAFLOW edge integrity
# ---------------------------------------------------------------------------


@pytest.fixture
def indexed_project(tmp_path: Path):
    """Create and index a small multi-file project with known dataflow patterns."""
    # module_a.py: defines helper() and producer()
    (tmp_path / "module_a.py").write_text(
        '''\
def producer():
    """Returns a value."""
    return 42

def helper():
    """Calls producer and returns its result."""
    return producer()
''',
        encoding="utf-8",
    )

    # module_b.py: calls helper(), has assignment from call
    (tmp_path / "module_b.py").write_text(
        '''\
from module_a import helper, producer

def consumer():
    """Consumes helper's output via assignment."""
    result = helper()
    return result

def transformer():
    """Nested call pattern — producer feeds into process."""
    return process(producer())

def process(value):
    return value * 2
''',
        encoding="utf-8",
    )

    # module_c.py: independent module with its own dataflow
    (tmp_path / "module_c.py").write_text(
        '''\
def fetch():
    return "data"

def render():
    data = fetch()
    return data
''',
        encoding="utf-8",
    )

    db_path = tmp_path / ".codebrain" / "codebrain.db"
    full_index(tmp_path, db_path)
    return tmp_path, db_path


class TestDataflowEdgeValidity:
    """Every DATAFLOW edge should reference valid source and target nodes."""

    def test_all_dataflow_edges_reference_valid_nodes(self, indexed_project):
        """Verify that every DATAFLOW edge has source and target that exist as
        node IDs or can be resolved to known symbol names in the graph."""
        project_root, db_path = indexed_project

        with GraphStore(db_path) as store:
            nodes = store.get_all_nodes()
            node_ids = {n["id"] for n in nodes}
            node_names = {n["name"] for n in nodes}
            node_qnames = {n["qualified_name"] for n in nodes}
            # Also collect suffix patterns (e.g. "Class.method") for resolution
            all_identifiers = node_ids | node_names | node_qnames

            edges = store.get_all_edges(type_filter="DATAFLOW")
            assert len(edges) > 0, "Expected at least one DATAFLOW edge"

            for edge in edges:
                source_ok = edge["source"] in all_identifiers
                target_ok = edge["target"] in all_identifiers
                # If source/target is a short name like "helper", it should
                # match a node name even if not a full node ID.
                assert source_ok, (
                    f"DATAFLOW source '{edge['source']}' not found in any node "
                    f"(file: {edge['file_path']}, line: {edge['line']})"
                )
                assert target_ok, (
                    f"DATAFLOW target '{edge['target']}' not found in any node "
                    f"(file: {edge['file_path']}, line: {edge['line']})"
                )

    def test_no_orphaned_dataflow_edges(self, indexed_project):
        """DATAFLOW edges should not point to completely unknown symbols —
        their targets should be resolvable to at least a node name."""
        project_root, db_path = indexed_project

        with GraphStore(db_path) as store:
            nodes = store.get_all_nodes()
            node_names = {n["name"] for n in nodes}
            node_qnames = {n["qualified_name"] for n in nodes}
            known = node_names | node_qnames

            edges = store.get_all_edges(type_filter="DATAFLOW")
            orphaned = []
            for edge in edges:
                # Extract the bare function name from the target
                target_bare = edge["target"].split(".")[-1] if "." in edge["target"] else edge["target"]
                source_bare = edge["source"].split("::")[-1].split(".")[-1] if "::" in edge["source"] else edge["source"].split(".")[-1]
                if target_bare not in known and edge["target"] not in known:
                    orphaned.append(f"target '{edge['target']}' in {edge['file_path']}:{edge['line']}")
            assert len(orphaned) == 0, f"Orphaned DATAFLOW edges found: {orphaned}"

    def test_dataflow_proportion_is_reasonable(self, indexed_project):
        """DATAFLOW edges should not dominate the edge set (< 50% of all edges)."""
        _, db_path = indexed_project

        with GraphStore(db_path) as store:
            all_edges = store.get_all_edges()
            dataflow_edges = store.get_all_edges(type_filter="DATAFLOW")
            assert len(dataflow_edges) < len(all_edges) * 0.5, (
                f"DATAFLOW edges are {len(dataflow_edges)}/{len(all_edges)} "
                f"({100 * len(dataflow_edges) / len(all_edges):.0f}%) — too many"
            )


class TestDataflowImpactAnalysis:
    """DATAFLOW edges should NOT inflate impact_of_change results."""

    def test_impact_uses_calls_not_dataflow(self, indexed_project):
        """impact_of_change traverses CALLS and IMPORTS, not DATAFLOW.
        Changing producer() should impact helper() (via CALLS) and consumer()
        (via CALLS to helper), but module_c should NOT appear."""
        project_root, db_path = indexed_project

        with GraphStore(db_path) as store:
            engine = QueryEngine(store)

            # Find the producer node
            results = engine.search_nodes("producer")
            producer_nodes = [n for n in results if n["name"] == "producer" and n["type"] == "function"]
            assert len(producer_nodes) > 0, "producer node not found"
            producer_id = producer_nodes[0]["id"]

            impact = engine.impact_of_change(producer_id)
            impacted_ids = {item["node_id"] for item in impact}

            # helper() CALLS producer(), so it should be impacted
            helper_nodes = [n for n in engine.search_nodes("helper") if n["name"] == "helper"]
            assert len(helper_nodes) > 0
            # The helper's container (module_a) or helper itself should appear
            # (depends on how CALLS edges resolve)

            # module_c symbols should NOT be impacted — they are independent
            module_c_nodes = engine.search_nodes("fetch") + engine.search_nodes("render")
            module_c_ids = {n["id"] for n in module_c_nodes}
            false_positives = impacted_ids & module_c_ids
            assert len(false_positives) == 0, (
                f"impact_of_change falsely includes module_c symbols: {false_positives}"
            )

    def test_dataflow_does_not_add_extra_impact(self, indexed_project):
        """Even with DATAFLOW edges present, impact_of_change should return
        the same set as if only CALLS/IMPORTS were considered, since the
        current implementation only traverses those edge types."""
        _, db_path = indexed_project

        with GraphStore(db_path) as store:
            engine = QueryEngine(store)

            # Pick any node and verify impact count is reasonable
            results = engine.search_nodes("process")
            process_nodes = [n for n in results if n["name"] == "process" and n["type"] == "function"]
            if not process_nodes:
                pytest.skip("process node not found")
            process_id = process_nodes[0]["id"]

            impact = engine.impact_of_change(process_id)
            # DATAFLOW edges from nested call (producer -> process) should NOT
            # cause producer to appear in impact results, because impact only
            # follows CALLS and IMPORTS edges *incoming* to the changed node.
            impacted_names = set()
            for item in impact:
                node = store.get_node(item["node_id"])
                if node:
                    impacted_names.add(node["name"])

            # process() is called by transformer(), so transformer should be impacted
            # But producer() should NOT be — it feeds INTO process via DATAFLOW,
            # not via an incoming CALLS edge to process.
            assert "producer" not in impacted_names, (
                "producer should not be in impact of process — DATAFLOW edge "
                "goes from producer to process, not the other way"
            )
