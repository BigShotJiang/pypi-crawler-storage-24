"""Tests for the REST API."""

from __future__ import annotations

import pytest

try:
    from fastapi.testclient import TestClient
    from codebrain.api import app, configure, configure_multi, _projects, _default_project
    _API_AVAILABLE = True
except ImportError:
    _API_AVAILABLE = False

pytestmark = pytest.mark.skipif(not _API_AVAILABLE, reason="fastapi not installed")


@pytest.fixture
def client(indexed_project):
    """Create a FastAPI test client pointed at the indexed project."""
    import codebrain.api as api_mod

    repo_root, store = indexed_project
    store.close()
    # Clear state so each test starts fresh
    api_mod._projects.clear()
    api_mod._default_project = None
    configure(repo_root)
    with TestClient(app) as c:
        yield c
    api_mod._projects.clear()
    api_mod._default_project = None


class TestStatus:
    def test_status(self, client):
        r = client.get("/api/status")
        assert r.status_code == 200
        data = r.json()
        assert "files" in data
        assert "nodes" in data
        assert "edges" in data

    def test_status_includes_health(self, client):
        """M18: Health merged into status."""
        r = client.get("/api/status")
        data = r.json()
        assert "health" in data
        assert "score" in data["health"]
        assert 0 <= data["health"]["score"] <= 100

    def test_status_includes_llm(self, client):
        """M18: LLM status merged into status."""
        r = client.get("/api/status")
        data = r.json()
        assert "llm" in data
        assert "enabled" in data["llm"]


class TestSearch:
    def test_search(self, client):
        r = client.get("/api/search?q=process")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) > 0

    def test_search_with_limit(self, client):
        r = client.get("/api/search?q=process&limit=1")
        assert r.status_code == 200
        data = r.json()
        assert len(data) <= 1

    def test_search_requires_query(self, client):
        r = client.get("/api/search")
        assert r.status_code == 422


class TestImpact:
    def test_impact(self, client):
        r = client.get("/api/impact/helper")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_impact_not_found(self, client):
        r = client.get("/api/impact/nonexistent_xyz")
        assert r.status_code == 404


class TestCallchain:
    def test_callchain(self, client):
        r = client.get("/api/callchain/process")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_trace_alias(self, client):
        """M18: /api/trace still works as alias."""
        r = client.get("/api/trace/process")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)


class TestDeadcode:
    def test_deadcode(self, client):
        r = client.get("/api/deadcode")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


class TestCycles:
    def test_cycles(self, client):
        r = client.get("/api/cycles")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


class TestOverview:
    def test_overview(self, client):
        r = client.get("/api/overview")
        assert r.status_code == 200
        data = r.json()
        assert "stats" in data
        assert "packages" in data

    def test_overview_includes_narrative(self, client):
        """M18: Narrative merged inline."""
        r = client.get("/api/overview")
        data = r.json()
        assert "narrative" in data


class TestModule:
    def test_module(self, client):
        r = client.get("/api/module/mypackage/core.py")
        assert r.status_code == 200
        data = r.json()
        assert data["file_path"] == "mypackage/core.py"

    def test_module_includes_narrative(self, client):
        """M18: Narrative merged inline."""
        r = client.get("/api/module/mypackage/core.py")
        data = r.json()
        assert "narrative" in data

    def test_module_not_found(self, client):
        r = client.get("/api/module/nonexistent.py")
        assert r.status_code == 404


class TestHotspots:
    def test_hotspots(self, client):
        r = client.get("/api/hotspots")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_hotspots_top(self, client):
        r = client.get("/api/hotspots?top=5")
        assert r.status_code == 200
        assert len(r.json()) <= 5


class TestCoupling:
    def test_coupling(self, client):
        r = client.get("/api/coupling")
        assert r.status_code == 200
        data = r.json()
        assert "pairs" in data


class TestLayers:
    def test_layers(self, client):
        r = client.get("/api/layers")
        assert r.status_code == 200
        data = r.json()
        assert "layers" in data


class TestValidate:
    def test_validate(self, client):
        r = client.get("/api/validate/mypackage/core.py")
        assert r.status_code == 200
        data = r.json()
        assert "is_valid" in data


class TestContext:
    def test_context(self, client):
        r = client.get("/api/context/process")
        assert r.status_code == 200
        data = r.json()
        assert "contexts" in data
        assert isinstance(data["contexts"], list)

    def test_context_not_found(self, client):
        r = client.get("/api/context/nonexistent_xyz")
        assert r.status_code == 404


class TestAnatomy:
    def test_anatomy_endpoint(self, client):
        r = client.get("/api/anatomy")
        assert r.status_code == 200
        data = r.json()
        assert "subsystems" in data
        assert "purpose" in data
        assert isinstance(data["subsystems"], list)


class TestPatterns:
    def test_patterns(self, client):
        r = client.get("/api/patterns")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


class TestExportJson:
    def test_export_json(self, client):
        r = client.get("/api/export/json")
        assert r.status_code == 200


class TestAsk:
    def test_ask_post(self, client):
        r = client.post("/api/ask", json={"question": "What are the riskiest files?", "use_llm": False})
        assert r.status_code == 200
        data = r.json()
        assert "answer" in data
        assert data["intent"] == "risk"

    def test_ask_returns_suggestions(self, client):
        r = client.post("/api/ask", json={"question": "health score", "use_llm": False})
        assert r.status_code == 200
        data = r.json()
        assert "suggestions" in data
        assert isinstance(data["suggestions"], list)


class TestPathTraversal:
    def test_validate_path_rejects_traversal(self):
        """Test the path validation function directly (httpx normalizes .. out of URLs)."""
        from codebrain.api import _validate_path
        import pytest as _pt
        from fastapi import HTTPException

        with _pt.raises(HTTPException) as exc_info:
            _validate_path("../../../etc/passwd")
        assert exc_info.value.status_code == 400
        assert "traversal" in exc_info.value.detail.lower()

    def test_validate_path_rejects_absolute(self):
        from codebrain.api import _validate_path
        import pytest as _pt
        from fastapi import HTTPException

        with _pt.raises(HTTPException) as exc_info:
            _validate_path("/etc/passwd")
        assert exc_info.value.status_code == 400

    def test_validate_path_rejects_null_bytes(self):
        from codebrain.api import _validate_path
        import pytest as _pt
        from fastapi import HTTPException

        with _pt.raises(HTTPException) as exc_info:
            _validate_path("test\x00.py")
        assert exc_info.value.status_code == 400
        assert "null" in exc_info.value.detail.lower()

    def test_validate_path_allows_normal(self):
        from codebrain.api import _validate_path
        # Should not raise
        _validate_path("mypackage/core.py")
        _validate_path("src/utils/helper.ts")


class TestPagination:
    def test_deadcode_with_offset(self, client):
        r1 = client.get("/api/deadcode?limit=200&offset=0")
        assert r1.status_code == 200
        all_items = r1.json()
        if len(all_items) >= 2:
            r2 = client.get("/api/deadcode?limit=200&offset=1")
            assert r2.status_code == 200
            assert len(r2.json()) == len(all_items) - 1

    def test_search_with_offset(self, client):
        r = client.get("/api/search?q=process&limit=50&offset=0")
        assert r.status_code == 200


class TestResponseModels:
    def test_status_has_typed_fields(self, client):
        r = client.get("/api/status")
        assert r.status_code == 200
        data = r.json()
        assert "files" in data
        assert "nodes" in data
        assert "edges" in data
        assert "node_types" in data
        assert "edge_types" in data


class TestZoom:
    def test_zoom(self, client):
        r = client.get("/api/zoom")
        assert r.status_code == 200
        data = r.json()
        assert "level" in data


@pytest.fixture
def second_project(tmp_path):
    """Create a second indexed project for multi-project tests."""
    from codebrain.indexer import full_index
    from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

    root = tmp_path / "second-project"
    root.mkdir()
    pkg = root / "otherpkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text('"""Other package."""\n')
    (pkg / "main.py").write_text(
        'def entrypoint():\n    """Entry."""\n    return 42\n'
    )

    result = full_index(root)
    assert result["errors"] == []
    return root


@pytest.fixture
def multi_client(indexed_project, second_project):
    """Create a test client with two projects registered."""
    import codebrain.api as api_mod

    repo_root, store = indexed_project
    store.close()

    # Clear any leftover state from other tests
    api_mod._projects.clear()
    api_mod._default_project = None

    configure(repo_root)
    configure_multi([second_project])

    with TestClient(app) as c:
        yield c

    # Clean up for other tests
    api_mod._projects.clear()
    api_mod._default_project = None


class TestProjects:
    def test_projects_endpoint(self, multi_client):
        r = multi_client.get("/api/projects")
        assert r.status_code == 200
        data = r.json()
        assert "projects" in data
        assert "default" in data
        assert len(data["projects"]) == 2
        slugs = [p["slug"] for p in data["projects"]]
        assert data["default"] in slugs
        for p in data["projects"]:
            assert p["initialized"] is True
            assert "name" in p
            assert "path" in p

    def test_query_with_project_param(self, multi_client):
        r = multi_client.get("/api/projects")
        slugs = [p["slug"] for p in r.json()["projects"]]
        # Query each project's status — both should work
        for slug in slugs:
            r = multi_client.get(f"/api/status?project={slug}")
            assert r.status_code == 200
            data = r.json()
            assert "nodes" in data

    def test_unknown_project_returns_404(self, multi_client):
        r = multi_client.get("/api/status?project=nonexistent")
        assert r.status_code == 404

    def test_no_project_param_uses_default(self, multi_client):
        r = multi_client.get("/api/status")
        assert r.status_code == 200
        data = r.json()
        assert "nodes" in data

    def test_single_project_backward_compat(self, client):
        """Existing single-project fixture still works."""
        r = client.get("/api/status")
        assert r.status_code == 200

    def test_projects_have_unique_slugs(self, multi_client):
        r = multi_client.get("/api/projects")
        slugs = [p["slug"] for p in r.json()["projects"]]
        assert len(slugs) == len(set(slugs))

    def test_search_with_project(self, multi_client):
        r = multi_client.get("/api/projects")
        second_slug = None
        for p in r.json()["projects"]:
            if "second" in p["name"].lower() or "second" in p["slug"]:
                second_slug = p["slug"]
                break
        if second_slug:
            r = multi_client.get(f"/api/search?q=entrypoint&project={second_slug}")
            assert r.status_code == 200
            data = r.json()
            assert any("entrypoint" in n.get("name", "") for n in data)
