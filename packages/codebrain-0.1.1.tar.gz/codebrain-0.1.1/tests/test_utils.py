"""Tests for codebrain.utils."""

from __future__ import annotations

from codebrain.utils import is_test_file


class TestIsTestFile:
    def test_tests_dir_at_start(self) -> None:
        assert is_test_file("tests/foo.py") is True

    def test_tests_dir_nested(self) -> None:
        assert is_test_file("src/tests/bar.py") is True

    def test_test_prefix(self) -> None:
        assert is_test_file("test_foo.py") is True

    def test_test_suffix(self) -> None:
        assert is_test_file("core_test.py") is True

    def test_conftest(self) -> None:
        assert is_test_file("conftest.py") is True

    def test_test_dir_at_start(self) -> None:
        assert is_test_file("test/helpers.py") is True

    def test_nested_test_dir(self) -> None:
        assert is_test_file("project/test/helpers.py") is True

    def test_test_uppercase_prefix(self) -> None:
        assert is_test_file("pkg/TestFoo.py") is True

    def test_production_file(self) -> None:
        assert is_test_file("src/core.py") is False

    def test_production_deep(self) -> None:
        assert is_test_file("codebrain/graph/store.py") is False
