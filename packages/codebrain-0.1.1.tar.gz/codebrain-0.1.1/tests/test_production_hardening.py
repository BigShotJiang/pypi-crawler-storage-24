"""M22: Production hardening tests.

Tests for CLI timeout, encoding resilience, symlink handling,
interrupted index recovery, progress indicators, and error messages.
"""

from __future__ import annotations

import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from codebrain.graph.store import GraphStore
from codebrain.indexer import discover_files, full_index
from codebrain.parser.models import ParsedFile
from codebrain.settings import Settings, load_settings


# ── H1: CLI Timeout ─────────────────────────────────────────────────────────


class TestCLITimeout:

    def test_timeout_in_settings_default(self):
        """Settings has cli_timeout with default 120s."""
        s = Settings()
        assert s.cli_timeout == 120

    def test_timeout_from_env(self, monkeypatch):
        """CODEBRAIN_CLI_TIMEOUT env var overrides default."""
        monkeypatch.setenv("CODEBRAIN_CLI_TIMEOUT", "60")
        s = load_settings()
        assert s.cli_timeout == 60

    def test_timeout_option_on_cli(self):
        """--timeout flag is accepted by the CLI."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--timeout", "10", "--help"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0

    def test_run_with_timeout_completes(self):
        """_run_with_timeout returns result for fast operations."""
        from codebrain.cli import _run_with_timeout
        result = _run_with_timeout(lambda: 42, timeout=5, label="Test")
        assert result == 42

    def test_run_with_timeout_exits_on_slow(self):
        """_run_with_timeout exits when operation exceeds timeout."""
        from codebrain.cli import _run_with_timeout

        def _slow():
            time.sleep(30)
            return "never"

        with pytest.raises(SystemExit):
            _run_with_timeout(_slow, timeout=1, label="Slow test")

    def test_run_with_timeout_propagates_errors(self):
        """_run_with_timeout re-raises exceptions from the function."""
        from codebrain.cli import _run_with_timeout

        def _fail():
            raise ValueError("test error")

        with pytest.raises(ValueError, match="test error"):
            _run_with_timeout(_fail, timeout=5, label="Fail test")


# ── H2: Encoding Resilience ─────────────────────────────────────────────────


class TestEncodingResilience:

    def test_parse_latin1_python_file(self, tmp_path):
        """Parser handles Latin-1 encoded Python file without crashing."""
        from codebrain.parser.python_parser import parse_file

        py_file = tmp_path / "latin1.py"
        # Write Latin-1 content (contains non-UTF-8 byte 0xe9 = é)
        py_file.write_bytes(b"# Comment with accent: caf\xe9\ndef hello():\n    pass\n")

        pf = parse_file(py_file, tmp_path)
        assert isinstance(pf, ParsedFile)
        assert pf.path == "latin1.py"

    def test_parse_binary_py_extension(self, tmp_path):
        """Parser handles binary file with .py extension gracefully."""
        from codebrain.parser.python_parser import parse_file

        py_file = tmp_path / "binary.py"
        py_file.write_bytes(b"\x00\x01\x02\x03\xff\xfe\xfd")

        pf = parse_file(py_file, tmp_path)
        assert isinstance(pf, ParsedFile)
        # May have no nodes (unparseable) but shouldn't crash

    def test_parse_utf8_bom(self, tmp_path):
        """Parser handles UTF-8 BOM-prefixed files correctly."""
        from codebrain.parser.python_parser import parse_file

        py_file = tmp_path / "bom.py"
        py_file.write_bytes(b"\xef\xbb\xbfdef hello():\n    pass\n")

        pf = parse_file(py_file, tmp_path)
        assert isinstance(pf, ParsedFile)
        # Should find the function
        names = [n.name for n in pf.nodes]
        assert "hello" in names

    def test_indexer_survives_bad_encoding(self, tmp_path):
        """full_index completes even with badly encoded files."""
        # Create a mix of good and bad files
        (tmp_path / "good.py").write_text("def good(): pass\n")
        (tmp_path / "bad.py").write_bytes(b"# \xff\xfe\n\x00def bad():\n    pass\n")
        (tmp_path / "also_good.py").write_text("x = 1\n")

        result = full_index(tmp_path)
        # Should not crash; should parse at least some files
        assert result["files_parsed"] >= 2

    def test_ts_parser_handles_latin1(self, tmp_path):
        """TypeScript regex parser handles non-UTF-8 files."""
        from codebrain.parser.typescript_parser import parse_typescript_file

        ts_file = tmp_path / "latin1.ts"
        ts_file.write_bytes(b"// Comment: caf\xe9\nexport function hello() {}\n")

        pf = parse_typescript_file(ts_file, tmp_path)
        assert isinstance(pf, ParsedFile)


# ── H3: Symlink and Filesystem Edge Cases ────────────────────────────────────


class TestFilesystemEdgeCases:

    @pytest.mark.skipif(sys.platform == "win32" and not os.environ.get("CI"),
                        reason="Symlinks require admin on Windows")
    def test_discover_skips_broken_symlinks(self, tmp_path):
        """Broken symlinks don't crash discover_files."""
        (tmp_path / "real.py").write_text("x = 1\n")
        broken = tmp_path / "broken.py"
        try:
            broken.symlink_to(tmp_path / "nonexistent.py")
        except OSError:
            pytest.skip("Cannot create symlinks")

        files = discover_files(tmp_path)
        names = [f.name for f in files]
        assert "real.py" in names
        assert "broken.py" not in names

    def test_discover_handles_deleted_during_walk(self, tmp_path):
        """discover_files doesn't crash if files disappear during walk."""
        (tmp_path / "exists.py").write_text("x = 1\n")
        # This test is more about verifying the stat() call doesn't crash
        files = discover_files(tmp_path)
        assert len(files) >= 1

    def test_index_survives_deleted_file(self, tmp_path):
        """If a file is deleted between discover and parse, indexer continues."""
        (tmp_path / "a.py").write_text("def a(): pass\n")
        (tmp_path / "b.py").write_text("def b(): pass\n")

        # Index with both files
        result = full_index(tmp_path)
        assert result["files_parsed"] >= 2

        # Delete one file and reindex
        (tmp_path / "b.py").unlink()
        result2 = full_index(tmp_path)
        # Should complete without error
        assert result2["files_parsed"] >= 1


# ── H4: Interrupted Indexing Recovery ────────────────────────────────────────


class TestInterruptedIndexRecovery:

    def test_complete_index_has_status(self, tmp_path):
        """Completed index writes status='complete' to meta table."""
        (tmp_path / "a.py").write_text("x = 1\n")
        db_path = tmp_path / ".codebrain" / "graph.db"
        full_index(tmp_path, db_path)

        conn = sqlite3.connect(str(db_path))
        row = conn.execute(
            "SELECT value FROM meta WHERE key = 'index_status'"
        ).fetchone()
        conn.close()
        assert row is not None
        assert row[0] == "complete"

    def test_incomplete_index_detected(self, tmp_path):
        """In-progress status is detectable in the database."""
        (tmp_path / "a.py").write_text("x = 1\n")
        db_path = tmp_path / ".codebrain" / "graph.db"
        full_index(tmp_path, db_path)

        # Simulate interrupted index by setting status back
        conn = sqlite3.connect(str(db_path))
        conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("index_status", "in_progress"),
        )
        conn.commit()

        row = conn.execute(
            "SELECT value FROM meta WHERE key = 'index_status'"
        ).fetchone()
        conn.close()
        assert row[0] == "in_progress"

    def test_index_records_file_count(self, tmp_path):
        """Index records total files and parsed count in meta."""
        (tmp_path / "a.py").write_text("x = 1\n")
        (tmp_path / "b.py").write_text("y = 2\n")
        db_path = tmp_path / ".codebrain" / "graph.db"
        full_index(tmp_path, db_path)

        conn = sqlite3.connect(str(db_path))
        total = conn.execute(
            "SELECT value FROM meta WHERE key = 'index_files_total'"
        ).fetchone()
        parsed = conn.execute(
            "SELECT value FROM meta WHERE key = 'index_files_parsed'"
        ).fetchone()
        conn.close()

        assert total is not None
        assert int(total[0]) >= 2
        assert parsed is not None
        assert int(parsed[0]) >= 2


# ── H5: Progress Indicators ─────────────────────────────────────────────────


class TestProgressIndicators:

    def test_init_shows_progress_bar(self, tmp_path):
        """brain init shows progress output."""
        (tmp_path / "a.py").write_text("def a(): pass\n")
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=60,
        )
        assert result.returncode == 0
        # Progress bar or file count should appear
        assert "Parsing" in result.stderr or "files" in result.stdout


# ── H6: Helpful Error Messages ──────────────────────────────────────────────


class TestErrorMessages:

    def test_error_not_initialized(self, tmp_path):
        """Commands on uninitialized repo show helpful message."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "status"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode != 0
        assert "brain init" in result.stderr

    def test_error_empty_repo(self, tmp_path):
        """brain init on empty dir shows supported extensions."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=30,
        )
        # Should mention supported formats
        combined = result.stdout + result.stderr
        assert ".py" in combined

    def test_error_impact_no_match(self, tmp_path):
        """brain impact with no matching symbol shows suggestion."""
        (tmp_path / "a.py").write_text("def a(): pass\n")
        subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=60,
        )
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path),
             "impact", "nonexistent_symbol_xyz"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode != 0
        assert "brain search" in result.stderr

    def test_help_all_commands(self):
        """Every subcommand has --help."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--help"],
            capture_output=True, text=True, timeout=15,
        )
        assert result.returncode == 0
        # Check key commands are listed
        for cmd in ["init", "status", "search", "impact", "health"]:
            assert cmd in result.stdout


# ── H7: Cross-Platform Install Verification ─────────────────────────────────


class TestInstallVerification:

    def test_brain_version(self):
        """brain --version exits 0 and prints version."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--version"],
            capture_output=True, text=True, timeout=15,
        )
        assert result.returncode == 0
        assert "CodeBrain" in result.stdout or "codebrain" in result.stdout

    def test_brain_init_and_status(self, tmp_path):
        """Full lifecycle: init -> status on temp repo."""
        (tmp_path / "hello.py").write_text("def hello(): return 'world'\n")

        # Init
        r1 = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=60,
        )
        assert r1.returncode == 0

        # Status
        r2 = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "status"],
            capture_output=True, text=True, timeout=30,
        )
        assert r2.returncode == 0
        assert "1" in r2.stdout  # At least 1 file

    def test_brain_search_after_init(self, tmp_path):
        """Search works on freshly indexed repo."""
        (tmp_path / "calc.py").write_text("def calculate(x): return x * 2\n")

        subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=60,
        )

        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path),
             "search", "calculate"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "calculate" in result.stdout

    def test_brain_health_after_init(self, tmp_path):
        """Health command works on freshly indexed repo."""
        (tmp_path / "app.py").write_text("def main(): pass\n")

        subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "init"],
            capture_output=True, text=True, timeout=60,
        )

        result = subprocess.run(
            [sys.executable, "-m", "codebrain", "--repo", str(tmp_path), "health"],
            capture_output=True, text=True, timeout=60,
        )
        assert result.returncode == 0
        assert "Health" in result.stdout or "score" in result.stdout.lower()
