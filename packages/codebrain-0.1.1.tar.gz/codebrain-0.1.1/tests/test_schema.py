"""Tests for schema creation and migration."""

from __future__ import annotations

import sqlite3

import pytest

from codebrain.graph.schema import get_schema_version, init_db, migrate_db
from codebrain.config import SCHEMA_VERSION


class TestInitDb:
    def test_init_creates_tables(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        init_db(conn)
        # Verify tables exist
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert "meta" in tables
        assert "files" in tables
        assert "nodes" in tables
        assert "edges" in tables
        conn.close()

    def test_init_sets_version(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        init_db(conn)
        version = get_schema_version(conn)
        assert version == SCHEMA_VERSION
        conn.close()


class TestGetSchemaVersion:
    def test_version_on_fresh_db(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        # No tables yet
        version = get_schema_version(conn)
        assert version is None
        conn.close()

    def test_version_after_init(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        init_db(conn)
        version = get_schema_version(conn)
        assert version == SCHEMA_VERSION
        conn.close()


class TestMigrateDb:
    def test_migrate_fresh_db(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        migrate_db(conn)
        version = get_schema_version(conn)
        assert version == SCHEMA_VERSION
        conn.close()

    def test_migrate_already_current(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        init_db(conn)
        # Calling migrate again should be a no-op
        migrate_db(conn)
        version = get_schema_version(conn)
        assert version == SCHEMA_VERSION
        conn.close()

    def test_migrate_idempotent(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        migrate_db(conn)
        migrate_db(conn)
        migrate_db(conn)
        version = get_schema_version(conn)
        assert version == SCHEMA_VERSION
        conn.close()

    def test_indexes_created(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        migrate_db(conn)
        indexes = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index'"
            ).fetchall()
        }
        assert "idx_nodes_file_path" in indexes
        assert "idx_edges_source" in indexes
        assert "idx_edges_target" in indexes
        conn.close()
