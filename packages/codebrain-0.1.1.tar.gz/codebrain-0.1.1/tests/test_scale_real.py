"""M21: Performance at scale — test against real open-source Python projects.

These tests clone real repos and verify CodeBrain meets performance budgets.
Marked with @pytest.mark.scale — skipped by default, run with:
    pytest -m scale tests/test_scale_real.py
"""

from __future__ import annotations

import shutil
import subprocess
import time
from pathlib import Path

import pytest

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index

pytestmark = pytest.mark.scale


def _clone_repo(url: str, dest: Path, sparse_dir: str | None = None) -> Path:
    """Clone a git repo. If sparse_dir given, do a sparse checkout of just that directory."""
    if dest.exists():
        shutil.rmtree(dest)
    if sparse_dir:
        subprocess.run(
            ["git", "clone", "--depth", "1", "--filter=blob:none", "--sparse", url, str(dest)],
            check=True, capture_output=True, timeout=120,
        )
        subprocess.run(
            ["git", "sparse-checkout", "set", sparse_dir],
            cwd=str(dest), check=True, capture_output=True, timeout=30,
        )
    else:
        subprocess.run(
            ["git", "clone", "--depth", "1", url, str(dest)],
            check=True, capture_output=True, timeout=120,
        )
    return dest


@pytest.fixture(scope="module")
def fastapi_project(tmp_path_factory):
    """Clone and index FastAPI (~200 files)."""
    base = tmp_path_factory.mktemp("fastapi")
    repo = _clone_repo("https://github.com/tiangolo/fastapi.git", base / "repo")
    db = base / "test.db"

    start = time.perf_counter()
    full_index(repo, db)
    index_time = time.perf_counter() - start

    return {"db": str(db), "repo": repo, "index_time": index_time}


@pytest.fixture(scope="module")
def flask_project(tmp_path_factory):
    """Clone and index Flask (~300 files)."""
    base = tmp_path_factory.mktemp("flask")
    repo = _clone_repo("https://github.com/pallets/flask.git", base / "repo")
    db = base / "test.db"

    start = time.perf_counter()
    full_index(repo, db)
    index_time = time.perf_counter() - start

    return {"db": str(db), "repo": repo, "index_time": index_time}


@pytest.fixture(scope="module")
def django_project(tmp_path_factory):
    """Clone and index Django core (~2000 files)."""
    base = tmp_path_factory.mktemp("django")
    repo = _clone_repo(
        "https://github.com/django/django.git",
        base / "repo",
        sparse_dir="django",
    )
    db = base / "test.db"

    start = time.perf_counter()
    full_index(repo, db)
    index_time = time.perf_counter() - start

    return {"db": str(db), "repo": repo, "index_time": index_time}


class TestFastAPIScale:
    """FastAPI: ~200 files, medium-large, heavy decorators."""

    def test_index_under_60s(self, fastapi_project):
        assert fastapi_project["index_time"] < 60, (
            f"Indexing took {fastapi_project['index_time']:.1f}s (budget: 60s)"
        )

    def test_nodes_found(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            nodes = store.get_all_nodes()
            assert len(nodes) > 50

    def test_search_under_1s(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            engine = QueryEngine(store)
            start = time.perf_counter()
            results = engine.search_nodes("FastAPI")
            elapsed = time.perf_counter() - start
            assert elapsed < 1.0, f"Search took {elapsed:.2f}s"

    def test_impact_under_5s(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            engine = QueryEngine(store)
            nodes = store.get_all_nodes()
            target = next((n for n in nodes if n["type"] == "class"), None)
            if target:
                start = time.perf_counter()
                engine.impact_of_change(target["id"])
                elapsed = time.perf_counter() - start
                assert elapsed < 5.0, f"Impact took {elapsed:.2f}s"

    def test_hotspots_under_10s(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()
            hotspots = comp.risk_hotspots()
            elapsed = time.perf_counter() - start
            assert elapsed < 10.0, f"Hotspots took {elapsed:.2f}s"
            assert len(hotspots) > 0

    def test_overview_works(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            comp = ComprehensionEngine(store)
            overview = comp.system_overview()
            assert overview["stats"]["files"] > 0

    def test_health_score_valid(self, fastapi_project):
        with GraphStore(fastapi_project["db"]) as store:
            comp = ComprehensionEngine(store)
            health = comp.health_score()
            assert 0 <= health["score"] <= 100


class TestFlaskScale:
    """Flask: ~300 files, large, complex."""

    def test_index_under_60s(self, flask_project):
        assert flask_project["index_time"] < 60

    def test_search_under_1s(self, flask_project):
        with GraphStore(flask_project["db"]) as store:
            engine = QueryEngine(store)
            start = time.perf_counter()
            results = engine.search_nodes("Flask")
            elapsed = time.perf_counter() - start
            assert elapsed < 1.0

    def test_hotspots_under_10s(self, flask_project):
        with GraphStore(flask_project["db"]) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()
            comp.risk_hotspots()
            elapsed = time.perf_counter() - start
            assert elapsed < 10.0


class TestDjangoScale:
    """Django core: ~2000 files — scale stress test."""

    def test_index_under_5min(self, django_project):
        assert django_project["index_time"] < 300, (
            f"Indexing took {django_project['index_time']:.1f}s (budget: 300s)"
        )

    def test_search_under_2s(self, django_project):
        with GraphStore(django_project["db"]) as store:
            engine = QueryEngine(store)
            start = time.perf_counter()
            results = engine.search_nodes("Model")
            elapsed = time.perf_counter() - start
            assert elapsed < 2.0, f"Search took {elapsed:.2f}s"
            assert len(results) > 0

    def test_hotspots_under_30s(self, django_project):
        with GraphStore(django_project["db"]) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()
            hotspots = comp.risk_hotspots()
            elapsed = time.perf_counter() - start
            assert elapsed < 30.0, f"Hotspots took {elapsed:.2f}s"
            assert len(hotspots) > 0

    def test_dead_code_under_30s(self, django_project):
        with GraphStore(django_project["db"]) as store:
            engine = QueryEngine(store)
            start = time.perf_counter()
            dead = engine.find_dead_code()
            elapsed = time.perf_counter() - start
            assert elapsed < 30.0, f"Dead code took {elapsed:.2f}s"

    def test_health_under_60s(self, django_project):
        with GraphStore(django_project["db"]) as store:
            comp = ComprehensionEngine(store)
            start = time.perf_counter()
            health = comp.health_score()
            elapsed = time.perf_counter() - start
            assert elapsed < 60.0, f"Health took {elapsed:.2f}s"
            assert 0 <= health["score"] <= 100

    def test_memory_under_1gb(self, django_project):
        try:
            import psutil
        except ImportError:
            pytest.skip("psutil not installed")
        import os
        process = psutil.Process(os.getpid())
        mem_mb = process.memory_info().rss / 1024 / 1024
        assert mem_mb < 1024, f"Memory usage {mem_mb:.0f}MB exceeds 1GB"
