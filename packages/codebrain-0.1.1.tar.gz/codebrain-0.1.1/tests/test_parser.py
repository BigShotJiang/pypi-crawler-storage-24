"""Tests for the Python parser."""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.python_parser import parse_file


def _write_and_parse(tmp_repo: Path, code: str, filename: str = "test.py") -> "ParsedFile":
    """Helper: write code to a file in tmp_repo and parse it."""
    p = tmp_repo / filename
    p.write_text(code)
    return parse_file(p, tmp_repo)


class TestParseBasicFunctions:
    def test_extracts_function(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "def foo():\n    pass\n")
        names = [n.name for n in pf.nodes]
        assert "foo" in names

    def test_function_has_correct_type(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "def foo():\n    pass\n")
        func = [n for n in pf.nodes if n.name == "foo"][0]
        assert func.type == "function"

    def test_function_line_numbers(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "x = 1\n\ndef foo():\n    return x\n")
        func = [n for n in pf.nodes if n.name == "foo"][0]
        assert func.line_start == 3

    def test_async_function(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "async def bar():\n    pass\n")
        func = [n for n in pf.nodes if n.name == "bar"][0]
        assert func.type == "function"

    def test_function_signature(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "def add(a: int, b: int = 0) -> int:\n    return a + b\n")
        func = [n for n in pf.nodes if n.name == "add"][0]
        assert "a: int" in func.signature
        assert "b: int = 0" in func.signature
        assert "-> int" in func.signature


class TestParseClasses:
    def test_extracts_class(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "class Foo:\n    pass\n")
        cls = [n for n in pf.nodes if n.name == "Foo"][0]
        assert cls.type == "class"

    def test_class_methods_are_methods(self, tmp_repo: Path) -> None:
        code = "class Foo:\n    def bar(self):\n        pass\n"
        pf = _write_and_parse(tmp_repo, code)
        method = [n for n in pf.nodes if n.name == "bar"][0]
        assert method.type == "method"

    def test_extends_edge(self, tmp_repo: Path) -> None:
        code = "class Base:\n    pass\n\nclass Child(Base):\n    pass\n"
        pf = _write_and_parse(tmp_repo, code)
        extends = [e for e in pf.edges if e.type == "EXTENDS"]
        assert len(extends) == 1
        assert extends[0].target == "Base"

    def test_contains_edge_for_method(self, tmp_repo: Path) -> None:
        code = "class Foo:\n    def bar(self):\n        pass\n"
        pf = _write_and_parse(tmp_repo, code)
        contains = [e for e in pf.edges if e.type == "CONTAINS" and "bar" in e.target]
        assert len(contains) >= 1

    def test_decorators(self, tmp_repo: Path) -> None:
        code = "class Foo:\n    @staticmethod\n    def bar():\n        pass\n"
        pf = _write_and_parse(tmp_repo, code)
        method = [n for n in pf.nodes if n.name == "bar"][0]
        assert "staticmethod" in method.decorators


class TestParseImports:
    def test_import(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "import os\n")
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "os" in targets

    def test_from_import(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "from os.path import join\n")
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "os.path.join" in targets


class TestParseCalls:
    def test_call_edge(self, tmp_repo: Path) -> None:
        code = "def foo():\n    bar()\n\ndef bar():\n    pass\n"
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "bar" in call_targets

    def test_method_call(self, tmp_repo: Path) -> None:
        code = "def foo():\n    obj.method()\n"
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "obj.method" in call_targets


class TestParseVariables:
    def test_module_level_variable(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "MAX_SIZE = 100\n")
        var = [n for n in pf.nodes if n.name == "MAX_SIZE"][0]
        assert var.type == "variable"

    def test_annotated_variable(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "count: int = 0\n")
        var = [n for n in pf.nodes if n.name == "count"][0]
        assert var.type == "variable"


class TestParseExports:
    def test_all_controls_exported(self, tmp_repo: Path) -> None:
        code = '__all__ = ["public_func"]\n\ndef public_func():\n    pass\n\ndef _private():\n    pass\n'
        pf = _write_and_parse(tmp_repo, code)
        pub = [n for n in pf.nodes if n.name == "public_func"][0]
        priv = [n for n in pf.nodes if n.name == "_private"][0]
        assert pub.is_exported is True
        assert priv.is_exported is False


class TestParseDocstrings:
    def test_function_docstring(self, tmp_repo: Path) -> None:
        code = 'def foo():\n    """This does stuff."""\n    pass\n'
        pf = _write_and_parse(tmp_repo, code)
        func = [n for n in pf.nodes if n.name == "foo"][0]
        assert func.docstring == "This does stuff."

    def test_class_docstring(self, tmp_repo: Path) -> None:
        code = 'class Bar:\n    """A bar class."""\n    pass\n'
        pf = _write_and_parse(tmp_repo, code)
        cls = [n for n in pf.nodes if n.name == "Bar"][0]
        assert cls.docstring == "A bar class."


class TestParseSyntaxError:
    def test_syntax_error_returns_empty(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "def broken(\n")
        assert pf.nodes == []
        assert pf.edges == []
        assert pf.content_hash != ""


class TestDataflowEdgeDirection:
    """Verify DATAFLOW edges point from consumer (source) to producer (target)."""

    def test_assignment_dataflow_direction(self, tmp_repo: Path) -> None:
        code = "def consumer():\n    result = producer()\n\ndef producer():\n    return 42\n"
        pf = _write_and_parse(tmp_repo, code)
        df = [e for e in pf.edges if e.type == "DATAFLOW"]
        assert len(df) >= 1
        # source should be the consumer, target should be the producer
        assert any(e.target == "producer" and "consumer" in e.source for e in df)

    def test_return_dataflow_direction(self, tmp_repo: Path) -> None:
        code = "def wrapper():\n    return inner()\n\ndef inner():\n    return 1\n"
        pf = _write_and_parse(tmp_repo, code)
        df = [e for e in pf.edges if e.type == "DATAFLOW"]
        assert len(df) >= 1
        # source should be wrapper (the consumer), target should be inner (the producer)
        assert any(e.target == "inner" and "wrapper" in e.source for e in df)


class TestFileNode:
    def test_file_node_exists(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "x = 1\n")
        file_nodes = [n for n in pf.nodes if n.type == "file"]
        assert len(file_nodes) == 1

    def test_file_node_line_count(self, tmp_repo: Path) -> None:
        pf = _write_and_parse(tmp_repo, "a = 1\nb = 2\nc = 3\n")
        assert pf.line_count == 4  # 3 lines + trailing newline


class TestSelfMethodResolution:
    """Verify that self.X() calls inside class methods are resolved to ClassName.X."""

    def test_self_call_resolved_to_class(self, tmp_repo: Path) -> None:
        code = (
            "class MyClass:\n"
            "    def foo(self):\n"
            "        self.bar()\n"
            "    def bar(self):\n"
            "        pass\n"
        )
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "MyClass.bar" in call_targets
        # Must NOT contain the unresolved "self.bar"
        assert "self.bar" not in call_targets

    def test_nested_class_self_resolution(self, tmp_repo: Path) -> None:
        code = (
            "class Outer:\n"
            "    class Inner:\n"
            "        def foo(self):\n"
            "            self.bar()\n"
            "        def bar(self):\n"
            "            pass\n"
        )
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "Outer.Inner.bar" in call_targets

    def test_non_self_attribute_unchanged(self, tmp_repo: Path) -> None:
        code = (
            "class MyClass:\n"
            "    def foo(self):\n"
            "        other.bar()\n"
        )
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "other.bar" in call_targets

    def test_self_dataflow_resolved(self, tmp_repo: Path) -> None:
        code = (
            "class MyClass:\n"
            "    def foo(self):\n"
            "        result = self.compute()\n"
            "    def compute(self):\n"
            "        return 42\n"
        )
        pf = _write_and_parse(tmp_repo, code)
        df = [e for e in pf.edges if e.type == "DATAFLOW"]
        df_targets = [e.target for e in df]
        assert "MyClass.compute" in df_targets

    def test_top_level_self_not_resolved(self, tmp_repo: Path) -> None:
        """self.X outside a class context should remain as-is."""
        code = (
            "def standalone():\n"
            "    self.bar()\n"
        )
        pf = _write_and_parse(tmp_repo, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        # No class context, so self.bar stays unresolved
        assert "self.bar" in call_targets
