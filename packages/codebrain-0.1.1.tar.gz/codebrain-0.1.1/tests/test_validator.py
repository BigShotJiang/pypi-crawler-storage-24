"""Tests for the pre-change impact validator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.validator import ChangeValidator, Severity


@pytest.fixture
def validated_project(simple_project: Path) -> tuple[Path, GraphStore]:
    """Index the simple_project for validator tests."""
    full_index(simple_project)
    db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    return simple_project, store


class TestValidateFile:
    def test_unchanged_file_is_valid(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)
        report = validator.validate_file(repo / "mypackage" / "utils.py", repo)
        assert report.is_valid is True
        store.close()

    def test_removing_used_function_is_invalid(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)

        # Rewrite core.py to remove `process` (which is imported by __init__.py)
        core = repo / "mypackage" / "core.py"
        core.write_text("def something_else():\n    pass\n")

        report = validator.validate_file(core, repo)
        # `process` was exported and imported — removing it should be flagged
        removed_names = [v.node_id for v in report.violations if v.category == "removed_symbol"]
        assert any("process" in n for n in removed_names) or any("DataProcessor" in n for n in removed_names)
        store.close()

    def test_adding_function_is_safe(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)

        utils = repo / "mypackage" / "utils.py"
        old_content = utils.read_text()
        utils.write_text(old_content + "\ndef brand_new():\n    return 99\n")

        report = validator.validate_file(utils, repo)
        assert report.is_valid is True
        assert len(report.nodes_added) >= 1
        store.close()

    def test_signature_change_detected(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)

        utils = repo / "mypackage" / "utils.py"
        # Change helper's signature (helper is called by core.process)
        utils.write_text(
            'def helper(x, y, z):\n    return x + y + z\n\ndef unused_function():\n    return 42\n'
        )

        report = validator.validate_file(utils, repo)
        sig_changes = [v for v in report.violations if v.category == "signature_change"]
        assert len(sig_changes) >= 1
        store.close()


class TestValidateDeletion:
    def test_deleting_file_with_dependents(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)

        report = validator.validate_deletion("mypackage/core.py")
        assert report.is_valid is False
        assert len(report.nodes_removed) > 0
        store.close()

    def test_deleting_leaf_file(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)

        report = validator.validate_deletion("mypackage/models.py")
        # models.py has no external callers in the simple project
        assert report.risk_score < 0.5
        store.close()


class TestRiskScore:
    def test_safe_change_low_risk(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)
        report = validator.validate_file(repo / "mypackage" / "models.py", repo)
        assert report.risk_score == 0.0
        store.close()

    def test_report_has_summary(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)
        report = validator.validate_file(repo / "mypackage" / "utils.py", repo)
        assert isinstance(report.summary, str)
        assert len(report.summary) > 0
        store.close()

    def test_report_to_dict(self, validated_project: tuple[Path, GraphStore]) -> None:
        repo, store = validated_project
        validator = ChangeValidator(store)
        report = validator.validate_file(repo / "mypackage" / "utils.py", repo)
        d = report.to_dict()
        assert "file_path" in d
        assert "is_valid" in d
        assert "risk_score" in d
        assert "violations" in d
        store.close()
