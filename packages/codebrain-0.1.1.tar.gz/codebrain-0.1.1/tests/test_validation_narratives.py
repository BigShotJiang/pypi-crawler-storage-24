"""M14: Validation narratives — human-readable explanations of validation results."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.validator import ChangeValidator


@pytest.fixture
def project(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def greet(name):\n    return f'hello {name}'\n\n"
        "def farewell(name):\n    return f'goodbye {name}'\n",
        encoding="utf-8",
    )
    (pkg / "cli.py").write_text(
        "from mypkg.core import greet\n\ndef main():\n    print(greet('world'))\n",
        encoding="utf-8",
    )
    (pkg / "utils.py").write_text(
        "def helper():\n    pass\n",
        encoding="utf-8",
    )

    db = root / CODEBRAIN_DIR / DB_FILENAME
    db.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db)

    return root, db


class TestValidationNarratives:

    def test_safe_addition_narrative(self, project):
        root, db = project
        core = root / "mypkg" / "core.py"
        core.write_text(
            core.read_text(encoding="utf-8") + "\ndef new_func():\n    pass\n",
            encoding="utf-8",
        )

        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_file(core, root)

        assert "safe" in report.narrative.lower() or "no" in report.narrative.lower()
        assert report.is_valid

    def test_breaking_removal_narrative(self, project):
        root, db = project
        core = root / "mypkg" / "core.py"
        core.write_text("def farewell(name):\n    return f'goodbye {name}'\n", encoding="utf-8")

        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_file(core, root)

        assert "UNSAFE" in report.narrative or "breaking" in report.narrative.lower()
        assert "greet" in report.narrative

    def test_narrative_in_to_dict(self, project):
        root, db = project
        core = root / "mypkg" / "core.py"

        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_file(core, root)

        d = report.to_dict()
        assert "narrative" in d
        assert isinstance(d["narrative"], str)
        assert len(d["narrative"]) > 0

    def test_deletion_narrative(self, project):
        root, db = project

        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_deletion("mypkg/core.py")

        assert len(report.narrative) > 0
        assert "greet" in report.narrative or "removing" in report.narrative.lower()

    def test_no_change_narrative(self, project):
        root, db = project
        core = root / "mypkg" / "core.py"

        with GraphStore(db) as store:
            validator = ChangeValidator(store)
            report = validator.validate_file(core, root)

        assert "safe" in report.narrative.lower() or "no" in report.narrative.lower()
