"""Tests for the LLM context generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.context import ContextGenerator
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME


@pytest.fixture
def ctx_project(simple_project: Path) -> tuple[Path, GraphStore, ContextGenerator]:
    full_index(simple_project)
    db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    gen = ContextGenerator(store)
    return simple_project, store, gen


class TestSymbolContext:
    def test_context_for_function(self, ctx_project) -> None:
        _, store, gen = ctx_project
        results = gen.for_symbol("process")
        assert len(results) >= 1
        ctx = results[0]
        assert ctx["type"] == "symbol_context"
        assert ctx["name"] == "process"
        assert ctx["file_path"] == "mypackage/core.py"
        store.close()

    def test_context_includes_callers(self, ctx_project) -> None:
        _, store, gen = ctx_project
        results = gen.for_symbol("helper")
        assert len(results) >= 1
        ctx = results[0]
        # helper is called by process
        assert "called_by" in ctx
        store.close()

    def test_context_includes_calls(self, ctx_project) -> None:
        _, store, gen = ctx_project
        results = gen.for_symbol("process")
        ctx = results[0]
        assert "calls" in ctx
        call_targets = [c["target"] for c in ctx["calls"]]
        assert any("helper" in t for t in call_targets)
        store.close()

    def test_context_for_class(self, ctx_project) -> None:
        _, store, gen = ctx_project
        results = gen.for_symbol("DataProcessor")
        assert len(results) >= 1
        ctx = results[0]
        assert ctx["symbol_type"] == "class"
        assert ctx.get("methods") is not None
        method_names = [m["name"] for m in ctx["methods"]]
        assert "run" in method_names
        store.close()

    def test_context_not_found(self, ctx_project) -> None:
        _, store, gen = ctx_project
        results = gen.for_symbol("nonexistent_zzz")
        assert results == []
        store.close()


class TestFileContext:
    def test_file_context(self, ctx_project) -> None:
        _, store, gen = ctx_project
        result = gen.for_file("mypackage/core.py")
        assert result["type"] == "file_context"
        assert len(result["symbols"]) > 0
        assert len(result["imports"]) > 0
        store.close()

    def test_file_context_missing(self, ctx_project) -> None:
        _, store, gen = ctx_project
        result = gen.for_file("nonexistent.py")
        assert "error" in result
        store.close()


class TestTaskContext:
    def test_task_context(self, ctx_project) -> None:
        _, store, gen = ctx_project
        result = gen.for_task(
            description="Fix a bug in the process function",
            relevant_names=["process", "helper"],
        )
        assert result["type"] == "task_context"
        assert len(result["symbols"]) >= 2
        assert len(result["directly_involved_files"]) >= 1
        store.close()

    def test_task_context_has_guidance(self, ctx_project) -> None:
        _, store, gen = ctx_project
        result = gen.for_task(
            description="Refactor helper",
            relevant_names=["helper"],
        )
        assert "guidance" in result
        assert isinstance(result["guidance"], list)
        store.close()
