# Pull Request: Deprecate internal NLP harvesters in favor of Sovereign JSON-LD / TNO FLINT architecture

**Title:** `refactor: Deprecate internal NLP harvesters in favor of Sovereign JSON-LD / TNO FLINT architecture`

## Description

> "In alignment with European Data Space architectures (NEN 381 525), ODGS is deprecating internal legal-text harvesters. ODGS is strictly an Execution Engine (The Physical Plane). Moving forward, ODGS natively delegates legal ontology and semantic parsing to authoritative upstream sources (e.g., TNO FLINT / Choppr) via standard JSON-LD ingestion. This eliminates vendor-specific legal interpretations and allows Sovereign States to act as their own Certificate Authorities for legal definitions."

## Technical Changes in v5.0.0
- **Removed** `src/odgs/harvester/` module (GDPR, AI Act, Basel III internal NLP blueprints).
- **Removed** `scripts/run_all_harvesters.py`.
- **Added** `/examples/standard_ontologies/` to provide developers with immediate testing payloads (Cold Start resolution).
- **Updated** `odgs` CLI: Replaced `odgs harvest` with `odgs ingest --payload` and `odgs compile --source`.
- **Security Upgrade**: Ingestion and compilation now generate a deterministic `SHA-256` hash at the physical boundary, stamping it cryptographically onto the generated `EnforcementRule`. This ensures if the upstream authoritative source changes its JSON-LD definition, the downstream cryptographic execution seal is instantly invalidated.

## Strategic Impact
This PR structurally positions ODGS as the missing **Execution Plane** for Civic Tech and Regels als Code initiatives. We are no longer trying to solve the problem of "Reading the Law." We are exclusively solving the problem of "Cryptographically Enforcing the Law."
