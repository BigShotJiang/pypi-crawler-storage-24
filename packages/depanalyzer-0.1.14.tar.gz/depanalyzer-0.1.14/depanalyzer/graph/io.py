"""Shared graph utilities for export-time graph cleanup."""

from __future__ import annotations

import hashlib
import logging
from typing import Any, Dict, List, Set, Tuple

import networkx as nx

from .models.schema import NodeType

logger = logging.getLogger("depanalyzer.graph.io")


def _generate_cluster_id(members: List[Any], prefix: str = "scc") -> str:
    """Generate a deterministic ID for a cluster of nodes."""
    sorted_members = sorted(str(member) for member in members)
    digest = hashlib.sha256(",".join(sorted_members).encode("utf-8")).hexdigest()
    return f"{prefix}:{digest[:16]}"


def _determine_cluster_type(graph: nx.MultiDiGraph, members: List[Any]) -> str:
    """Infer a cluster node type from its members."""
    if not members:
        return NodeType.SCC_CLUSTER.value

    first_member = sorted(members, key=lambda member: str(member))[0]
    node_data: Dict = graph.nodes[first_member] if graph.has_node(first_member) else {}
    node_type = node_data.get("type")

    code_like_types = {
        NodeType.CODE.value,
        NodeType.SYSTEM_HEADER.value,
        NodeType.PROJECT_HEADER.value,
    }
    if node_type in code_like_types or str(first_member).startswith("//"):
        return NodeType.CODE_SCC_CLUSTER.value

    return NodeType.SCC_CLUSTER.value


def _has_self_loop(graph: nx.MultiDiGraph, node: Any) -> bool:
    """Return True when the node has at least one self-loop."""
    return graph.has_edge(node, node)


def _build_member_snapshot(
    graph: nx.MultiDiGraph,
    members: List[Any],
) -> List[Dict[str, Any]]:
    """Create traceable member records for a virtual SCC node."""
    snapshots: List[Dict[str, Any]] = []
    for node_obj in sorted(members, key=lambda member: str(member)):
        attrs = graph.nodes.get(node_obj, {})
        node_id = str(node_obj)
        snapshots.append(
            {
                "id": node_id,
                "label": attrs.get("label"),
                "parser_name": attrs.get("parser_name"),
                "type": attrs.get("type"),
                "graph_id": attrs.get("graph_id"),
                "orig_id": attrs.get("orig_id"),
            }
        )
    return snapshots


def break_cycles(
    graph: nx.MultiDiGraph,
    *,
    max_removals: int = 50000,  # Kept for backward compatibility with callers.
) -> Tuple[nx.MultiDiGraph, int]:
    """
    Collapse SCC components with cycles into virtual nodes and rebuild graph.

    A component is collapsed when:
    - it has more than one node, or
    - it is a single node with a self-loop.

    The rebuilt graph keeps non-cyclic nodes as-is, rewires all external
    edges through virtual SCC nodes, and drops all edges fully internal to the
    same collapsed component.

    Args:
        graph: Input graph (MultiDiGraph).
        max_removals: Retained for API compatibility. No hard cutoff is applied
            because partial rewrites would violate the DAG guarantee.

    Returns:
        Tuple[nx.MultiDiGraph, int]: (Acyclic graph, number of removed edges).
    """
    try:
        sccs: List[Set[Any]] = list(nx.strongly_connected_components(graph))
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.warning("Failed to compute SCCs: %s. Returning original graph.", exc)
        return graph.copy(), 0

    collapsed_nodes: Dict[Any, str] = {}
    cluster_attrs: Dict[str, Dict[str, Any]] = {}

    try:
        for scc in sccs:
            members = list(scc)
            should_collapse = len(members) > 1 or _has_self_loop(graph, members[0])
            if not should_collapse:
                continue

            cluster_id = _generate_cluster_id(members)
            cluster_type = _determine_cluster_type(graph, members)
            cluster_attrs[cluster_id] = {
                "type": cluster_type,
                "members": sorted(str(member) for member in members),
                "member_count": len(members),
                "member_nodes": _build_member_snapshot(graph, members),
                "label": "Cycle Cluster",
                "parser_name": "scc_condensation",
                "provisional": True,
            }
            for member in members:
                collapsed_nodes[member] = cluster_id

    except Exception as exc:  # pragma: no cover - defensive logging
        logger.warning("Cycle removal failed: %s", exc)
        return graph.copy(), 0

    dag = nx.MultiDiGraph()
    removed_edges = 0

    # Add non-collapsed nodes unchanged.
    for node_id, attrs in graph.nodes(data=True):
        if node_id in collapsed_nodes:
            continue
        dag.add_node(node_id, **dict(attrs or {}))

    # Add collapsed SCC virtual nodes.
    for cluster_id, attrs in cluster_attrs.items():
        dag.add_node(cluster_id, **attrs)

    # Rebuild all edges based on source/target remapping.
    for source, target, _key, attrs in graph.edges(data=True, keys=True):
        mapped_source = collapsed_nodes.get(source, source)
        mapped_target = collapsed_nodes.get(target, target)

        # Internal edges are absorbed by virtual SCC nodes.
        if mapped_source == mapped_target:
            removed_edges += 1
            continue

        dag.add_edge(mapped_source, mapped_target, **dict(attrs or {}))

    if removed_edges > max_removals:
        logger.warning(
            "Cycle condensation removed %d internal edge(s), exceeding "
            "max_removals=%d (parameter retained only for compatibility).",
            removed_edges,
            max_removals,
        )

    return dag, removed_edges
