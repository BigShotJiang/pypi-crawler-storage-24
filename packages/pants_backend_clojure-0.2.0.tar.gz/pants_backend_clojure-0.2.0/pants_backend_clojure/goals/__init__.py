"""Goals for Clojure backend."""
