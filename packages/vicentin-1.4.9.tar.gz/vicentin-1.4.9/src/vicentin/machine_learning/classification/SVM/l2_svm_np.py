from typing import Optional
from itertools import combinations

import numpy as np

from vicentin.kernels import Kernel, LinearKernel
from vicentin.optimization.problems import QP
from vicentin.machine_learning.classification.SVM import SMO


def _train_binary(X, y, kernel, lambda_, C, smo_threshold, **kwargs):
    n = int(X.shape[0])
    if C is None:
        C = 1 / (lambda_ * n)

    if n > smo_threshold:
        return SMO(X, y, kernel, C, is_l2=True, **kwargs)

    P = kernel[:, :].copy() if isinstance(kernel, np.ndarray) else kernel(X, X)
    P += np.eye(n) / (2 * C)
    q = -y

    G = -np.diag(y)
    h = np.zeros(n)

    A = np.ones((1, n))
    b_eq = np.zeros(1)

    alpha, duals = QP(P, q, G, h, A, b_eq, return_dual=True, **kwargs)
    b = float(duals[1][0])

    return alpha, b


def L2_SVM(
    X: np.ndarray | Kernel,
    y: np.ndarray,
    lambda_: float = 1,
    C: Optional[float] = None,
    strategy: str = "ovo",
    smo_threshold: int = 10_000,
    **kwargs,
):
    if isinstance(X, Kernel):
        kernel = X
        X_data = kernel.X
    else:
        kernel = LinearKernel(X)
        X_data = X

    y = y.flatten()
    classes = np.unique(y)

    if len(classes) == 2:
        mask = np.ones_like(y, dtype=bool)
        y_bin = np.where(y == classes[0], -1, 1)

        alpha, b = _train_binary(
            X_data, y_bin, kernel, lambda_, C, smo_threshold, **kwargs
        )

        return {
            "classes": classes,
            "models": [(alpha, b, mask)],
            "strategy": "binary",
        }

    models = []
    if strategy == "ovo":
        for c1, c2 in combinations(classes, 2):
            mask = (y == c1) | (y == c2)
            y_bin = np.where(y[mask] == c1, -1, 1)

            alpha, b = _train_binary(
                X_data[mask], y_bin, kernel, lambda_, C, smo_threshold, **kwargs
            )

            models.append((alpha, b, mask))

    elif strategy == "ovr":
        for c in classes:
            mask = np.ones_like(y, dtype=bool)
            y_bin = np.where(y == c, 1.0, -1.0)

            alpha, b = _train_binary(
                X_data, y_bin, kernel, lambda_, C, smo_threshold, **kwargs
            )

            models.append((alpha, b, mask))

    return {"classes": classes, "models": models, "strategy": strategy}
