use numpy::{IntoPyArray, PyArray1, PyReadonlyArray1};
use pyo3::prelude::*;

use super::common::*;

#[pyfunction]
pub fn cdlmorningdojistar<'py>(
    py: Python<'py>,
    open: PyReadonlyArray1<'py, f64>,
    high: PyReadonlyArray1<'py, f64>,
    low: PyReadonlyArray1<'py, f64>,
    close: PyReadonlyArray1<'py, f64>,
) -> PyResult<Bound<'py, PyArray1<i32>>> {
    let opens = open.as_slice()?;
    let highs = high.as_slice()?;
    let lows = low.as_slice()?;
    let closes = close.as_slice()?;
    let n = opens.len();
    super::common::validate_ohlc_length(n, highs.len(), lows.len(), closes.len())?;
    let mut result = vec![0i32; n];
    for i in 2..n {
        let (o1, h1, l1, c1) = (opens[i - 2], highs[i - 2], lows[i - 2], closes[i - 2]);
        let (o2, _h2, _l2, c2) = (opens[i - 1], highs[i - 1], lows[i - 1], closes[i - 1]);
        let (o3, h3, l3, c3) = (opens[i], highs[i], lows[i], closes[i]);

        let body1 = body_size(o1, c1);
        let body2 = body_size(o2, c2);
        let body3 = body_size(o3, c3);
        let range1 = candle_range(h1, l1);
        let range2 = candle_range(o2.min(c2) - DOJI_BODY_EPSILON, o2.max(c2)); // avoid div-by-zero
        let range3 = candle_range(h3, l3);

        let large_body1 = range1 > 0.0 && body1 >= range1 * 0.6;
        // Middle candle must be a doji
        let is_doji2 = range2 > 0.0 && body2 / range2 <= 0.1;
        let large_body3 = range3 > 0.0 && body3 >= range3 * 0.6;

        if is_bearish(o1, c1)
            && large_body1
            && is_doji2
            && is_bullish(o3, c3)
            && large_body3
            && c3 > (o1 + c1) / 2.0
        {
            result[i] = 100;
        }
    }
    Ok(result.into_pyarray(py))
}
