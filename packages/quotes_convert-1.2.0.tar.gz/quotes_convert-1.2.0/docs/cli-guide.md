---
title: CLI Guide
description: "Complete guide to using quotes-convert from the command line. Installation, usage patterns, batch processing, shell integration, and troubleshooting."
keywords:
  - quotes-convert CLI
  - command-line interface
  - CLI guide
  - terminal
  - file conversion
  - batch processing
  - shell integration
  - quote conversion
---

--8<-- "CLI.md"
