# python generate.py generate
python generate.py generate-tools

