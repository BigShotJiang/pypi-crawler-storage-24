# Second iteration of issues with the seed data

In this iteration we will not create new seed (except for 2 cases, more on that below), but just document some of the observed minor issues for the README and the user guide.

Important: Document in the README that if multiple seed data types are used in conjunction, the recommendation is to use the `brief` version of each of them, as it is more likely to be compatible with the others. For example, if you use `personas` and `jobs` together, use the `brief` version of both.

Below is the list of seed data types and things that should be mentioned or noted in the README.

## Personas

The brief one is good an should be used as the "default" most of the time, ie., mention in the README to use the brief mostly.

## Jobs

Same as with personas -> use brief as the default.

## Coding Tasks

Don't use the brief version since it is not specific enough as a coding specification. But use the followup and other fields for multi-turn

## Math Categories

Be aware there is a wide gap between the brief and the detailed version.

## Writing Styles

Good as is, no issues.

## Scenarios

Brief version is already very detailed, so default

## Domains

Be aware of the wide gap between the brief and detailed version.

## Science Topics

Be aware of the wide gap between the brief and detailed version.

## Languages

only the brief version is good. Avoid the detailed one.

## Reasoning Patterns

This data is actually really bad and we don't just need to update the README but also change the seed data itself:
Instead of using an LLM to generate and upload a parquet file, let's just create a hardcoded python list of reasoning patterns, eg. counterfactual, abductive, analogical, etc. and then use that list to generate the parquet file. This way we can ensure that the reasoning patterns are actually correct and meaningful, instead of relying on an LLM to generate them which can lead to a lot of noise and irrelevant patterns.
The list should contain, around 200-300 items.
Mention in the README that this is a very small list and should used in conjunction with other seed data types or randomization source, and that it is not meant to be used on its own.

## Emotional States

Brief is very good. Detailed is very specific but the example in there is valuable.

## Instruction Complexity

This data is actually really bad and we don't just need to update the README but also change the seed data itself:
Instead of using an LLM to generate and upload a parquet file, let's just create a hardcoded python list of instruction complexities, eg. "explain like I am 5", first principles, step by step, etc. and then use that list to generate the parquet file. This way we can ensure that the instruction complexities are actually correct and meaningful, instead of relying on an LLM to generate them which can lead to a lot of noise and irrelevant complexities.
The list should contain, around 200-300 items.
Mention in the README that this is a very small list and should used in conjunction with other seed

## Tool Groups

The issues of interface drift has been fixed.
Also the group size is typically around 3-6, thus if more tools are needed, eg. for samples with >10 tools, sample multiple tool groups and combine them together. This should be mentioned in the README.
Remove the issues with the interface drift.
Also mention in the README that the tool variations are compatible within the same variation but not across variations.
eg. Tool A with variation 1 is compatible with Tool B with variation 1, but Tool A with variation 1 is not compatible with Tool B with variation 2. This should be mentioned in the README to avoid confusion.
