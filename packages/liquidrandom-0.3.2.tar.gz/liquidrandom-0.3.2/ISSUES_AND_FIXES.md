# liquidrandom issues and fixes list

In this document we are documenting all the issues that we observed 
in the seed data that was generated.
This covers mostly the scripts and modules inside the `seed_generation` folder.
The issue arise from implicit biases and things not considered before that only surface when we look at the generated data.

We will list all the issues for each of the seed data types:

# Optionality to go high-level vs detailed

A pattern that we observed across most of the seed data types is that they are very detailed and specific, which is good for certain use-cases but not for others. Other use-cases require only high-level data.

Therefore, we want to add this "high-level" vs "detailed" optionality inside the package itself instead of having to check for each of the seed data type how and which fields to use.

Think about how we could implement this and make accessible throughout all seed data types. There might be some seed data types such as the tool_groups that don't need this, here we may point both "paths" towards the same data since they are already high-level and not detailed. Just an idea to consider.

Note: We don't need backwards compatibility for this since we are still in the early stages of development and we can just add this as a new feature and update the existing seed data with the new fields.

Second note: A lot of seed data types have an "example" field, which may be even too much for the "detailed" path, or maybe not, I am not sure. Think of if this should be included in the "detailed" path or it a separate optional field.

Categories
## Coding Tasks	31,648	coding_task.parquet

Some of the tasks are too ambiguous and imcomplete. Make sure the description is detailed enough to understand and execute.
The constraints and exepcted_behavior is also good, but again, should be detailed to fully understand the task and what is expected from the solution.

Additionally, for each seed data sample we want the following fields:
- follow_up_task: Feature or extension that can be added to the task later on as a follow-up. Again, make this is detailed enough. Note: The feature or extension should be related to the original task and not be about change request or edge cases, since those we will be separate fields.
- change_request: A change request that can be made to the task. This is useful for testing the model's ability to understand and implement changes to a task. Again, make this is detailed enough.
- edge_cases: Certain edge cases that can be added to the task to make it more challenging. If the original task does not allow edge cases, then other types of inputs to be supported should be added. Again, make this is detailed enough.


## Domains	31,300	domain.parquet

Aagain, add 2-3 attribute that stay very high-level. Even the name is already too detailed.

## Emotional States	27,466	emotional_state.parquet

Nice and good data. Maybe same as the others, add 1-2 high level ones (name already a bit detailed, and intensity and valence too broad).
Additionally, add a field "example" that include an example situation or scenarios.

## Instruction Complexity	27,643	instruction_complexity.parquet

This data is really bad.
Bad example: talk about "QoS of network interface" in "description" -> this is a scenario and not a instruction complexity.
Let's redo it.
Probably we need only 2-5k samples with adjusted depth 2.
The instruction complexity should be generic enough to apply to any situation and not be tied to a specific domain or scenario. The description should be about the complexity of the instruction itself and not about a specific scenario or task.
We have an "example" field anyway where we can add the concrete example.

Make sure we support the "high-level" vs "detailed" optionality here as well. The "name" field should be the high-level one, and the "description" should be the detailed one.


## Jobs	32,245	job.parquet

title, required_skills, and description are all very specific, ie. a bit too much even.
It would be fine if there was another attributes that were a bit more high-level, however, there is only "industry" which is too broad and not too useful.
Ideally, we would have 2-3 more broader attributes in addition to the 2-3 specific ones we already have.
This should be obviously documented well, ie. "high-level" vs "detailed"

## Languages	22,600	language.parquet

Cut this extremely. 2k samples, taxonomy tree of depth 1.
Example: Cerreto Laghi Resort-Dialect
Litvish Yeshiva Key Hang Hebrew

We don't need this. "High-school youth language", "Chinese immigrant dialect", "Piracy slang", "Business jargon" are all good examples of high-level categories that are more useful and applicable to a wider range of use-cases.

## Math Categories	25,647	math_category.parquet

Similar issue as with the others: very detailed and specific which is nice but we need the optinallity for high-level category only.

## Personas	26,055	persona.parquet

No issue with the data, just we should should document that:
name, age, gender, and occupation are good "overall" attributes for most use-case and the "personaliy_traits" and background" are optional to add more depth to the persona.

## Reasoning Patterns	29,010	reasoning_pattern.parquet

This was also too detailed. But different than the others where we just want to add high-level attributes, here we want to cut the number of samples and the depth of the taxonomy tree.
Specifically, the generated samples went already very specific philosophical scenarios, eg. end-of-life ethical dilemmas, which is not what we want for the reasoning patterns. We want more general and high-level reasoning patterns that can be applied to a wider range of use-cases.
eg. Counterfactual reasoning, abductive reasoning, analogical reasoning, etc. are all good examples of high-level reasoning patterns that are more useful and applicable to a wider range of use-cases.
Cut it to 1-2k samples and a taxonomy tree of depth 1 or 2.

## Scenarios	32,017	scenario.parquet

Same pattern.
This time, all of the fields are very detailed, ie. even the "setting" and "title". Add 2-3 high-level attributes in addition to the detailed ones, and document well which are the high-level vs detailed ones.
Example:
title          The Roofing Loan Forgiveness
this is already too detailed.
high level: "Loan forgiveness scenario" -> much broader applicable if the user only needs this detail level.


## Science Topics	30,944	science_topic.parquet

Same problem as with the others. Need optinality for high level


## Writing Styles	25,704	writing_style.parquet

Good. Again, 1-2 more high-level attributes would be nice to have in addition to the detailed ones.
High-level here could be "simpler" as well.
eg. one sample talks about "The Hyperinflation Hyperbolist" -> too specific and only for financial domain.

Actually, I think 25k samples and a taxonomy tree of depth 3 is too much here, let's cut it to say 2.5k samples and depth 2.

## Tool Groups	6,565	tool_group.parquet

There is a major issue of the tool_groups is the interface matching:
When we create a group, we need to create the tools either in a single LLM call or sequentially with the previous tool in the context. This is to insure the interface is compatible across all tools in the group, otherwise we may end up with a "search_flight" tool returning "flight_id:uuid" while the "book_flight" tool is expecting "flight_number:int" as input, which is a problem.

Make sure the LLM that generate the tools is aware of this.

Second issue is that this behavior above needs to be consistent across the variations, meaning that all tool in variation 1 should have a compatible interface, and all tools in variation 2 should have a compatible interface, but variation 1 and variation 2 don't need to be compatible with each other.

This is more complex that is sounds at first because when we generate variation 2, we need to ensure that the tools is variation 2 are different from the tools in variation 1.
This become increasingly an issue with more variation.

Note: For parallelization: we may parallelize the tool_groups but have each tool_group be sequential, ie. a long chain.

Other issue what that most "tool_groups" had either 3 or 4 tools. If we could expand this to 3-6 tools, this would be great for diversity and also for testing the model's ability to handle more complex tool interactions.

In summary, the main issues with the tool_groups are:
- Interface compatibility across tools in the same group and across variations. Make sure all tools insice the same variation have compatible interfaces, and that different variations have different interfaces. We don't need and don't want compatibility across variations, but we need compatibility within the same variation.
- Expand the number of tools in each group to 3-6 tools to increase diversity of related tools.


## From the README.md:

- **Tool group cross-variation alignment.** Currently, variations for each tool within a group are generated independently. This means variation N of tool A and variation N of tool B have no guaranteed interface compatibility (matching parameter/return names). A future improvement would be to generate variations at the group level rather than per-tool, ensuring that all tools in a variation set have coherent inter-tool interfaces.
- Tools with empty variation list -> currently need to check if empty and potentially skip. 
- **Over-specificity in some categories.** Some seed data types have far more samples than needed for good diversity coverage. In particular, `language` (~22k samples) and `writing_style` (~25k samples) are over-specified, containing highly niche entries (e.g. obscure professional terminologies, hyper-specific literary styles) that are unlikely to be useful for most generation pipelines. These categories would benefit from being regenerated with a shallower taxonomy (1-2 levels) and a much smaller target count (~500 samples) focused on broad, practical coverage. Most other categories (e.g. `job`, `persona`, `coding_task`) benefit from their large sample counts and are fine as-is.


  cd seed_generation

  # Standard categories (delete old output/ first for a clean run)
python generate.py generate
python generate.py generate-tools

  # Tool groups

  # Upload
python generate.py upload-only --repo-id mlech26l/liquidrandom-data
