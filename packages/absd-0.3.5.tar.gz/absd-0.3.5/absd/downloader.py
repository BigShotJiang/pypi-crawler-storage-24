import os
import shutil
import importlib.resources as resources

FILES = {
    "1": "70726163746963616c32.rar",
    "2": "70726163746963616c33.rar",
    "3": "70726163746963616c37.rar",
    "4": "70726163746963616c38.rar"
}

def down():

    choice = input("Enter file number (1-4): ").strip()

    if choice not in FILES:
        return

    filename = FILES[choice]

    base_folder = os.path.abspath("absd_downloads")
    os.makedirs(base_folder, exist_ok=True)

    dest_path = os.path.join(base_folder, filename)

    if not os.path.exists(dest_path):

        source = resources.files("absd.assets").joinpath(filename)
        shutil.copy(source, dest_path)

    print(base_folder)