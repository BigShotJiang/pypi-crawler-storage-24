def bfs():
    code = '''
graph = {
    'a' : ['b','c'],
    'b' : ['d','e'],
    'c' : ['f'],
    'd' : [],
    'e' : [],
    'f' : []
}

vis = []
q = []
node='a'

vis.append(node)
q.append(node)

while q:
    s=q.pop(0)
    print(s,end=' ')

    for n in graph[s]:
        if n not in vis:
            vis.append(n)
            q.append(n)'''
    print(code)

def dfs():
    code = '''
graph = {
    'a' : ['d','c','b'],
    'b' : ['e'],
    'c' : ['g','f'],
    'd' : ['h'],
    'e' : ['i'],
    'f' : ['j']
}

path=[]
stack=['a']

while(len(stack)!=0):
    s=stack.pop()
    if s not in path:
        path.append(s)
    if s not in graph:
        continue
    for n in graph[s]:
        stack.append(n)

print(path)'''
    print(code)

def waterjug():
    code = '''#3 5 3 7 2 5 3 5
#1 8 4 6 1 8
a=int(input('Enter Jug A Capacity : '))
b=int(input('Enter Jug B Capacity : '))
af=int(input('Enter Final State Capacity of Jug A : '))
ai=0
bi=0

print('List of Operations you can do :')
print('1.) Fill Jug A Completely')
print('2.) Empty Jug A Completely')
print('3.) Fill Jug B Completely')
print('4.) Empty Jug B Completely')
print('5.) Empty Jug A into Jug B')
print('6.) Empty Jug B into Jug A')
print('7.) Pour Jug B into Jug A untill it is full')
print('8.) Pour Jug A into Jug B untill it is full')

while((ai!=af and bi<=b)):
    op = int(input("Enter your operation : "))
    if(op==1):
        ai=a
    elif(op==2):
        ai=0
    elif(op==3):
        bi=b
    elif(op==4):
        bi=0
    elif(op==5):
        if(ai+bi<=a and bi>0):
            ai=ai+bi;
            bi=0;
    elif(op==6):
        if(ai+bi<=b and ai>0):
            bi=ai+bi;
            ai=0;
    elif(op==7):
        if(ai+bi>=5 and bi>0):
            bi=bi-(a-ai);
            ai=a;
    elif(op==8):
        if(ai+bi>=3 and ai>0):
            ai=ai-(b-bi);
            bi=b;
    print(ai,bi)'''
    print(code)

def cards():
    code = '''
import itertools,random

deck = list(itertools.product(range(1,14),['Spades','Heart','Diamond','Clubs']))
random.shuffle(deck)

print("You got : ")
for i in range(5):
    if deck[i][0]==11:
        print('Jack of',deck[i][1])
    elif deck[i][0]==12:
        print('Queen of',deck[i][1])
    elif deck[i][0]== 13:
        print('King of',deck[i][1])
    else:
        print(deck[i][0],'of',deck[i][1])'''
    print(code)

def travel():
    code = '''
from sys import maxsize
from itertools import permutations
v=4

def tsp(g,s):
    ver=[1,2,3]
    print('Vertex : ', ver)
    minpath=maxsize
    nextper=permutations(ver)
    for i in nextper:
        print('i ',i)
        currentpath=0
        k=s
        for j in i: 
            currentpath+=g[k][j]
            print('cw =',currentpath,'g[k][j] =',g[k][j],'k =',k,'j =',j,)
            k=j
        currentpath+=g[k][s]
        print('Final cw at',i,'and graph[k][s]',g[k][s],'=',currentpath,'\n')
        minpath=min(minpath,currentpath)
    return minpath

graph=[[0,10,15,20],[10,0,35,25],[15,35,0,30],[20,25,30,0]]
s=0
print('minimum path = ',tsp(graph,s))'''
    print(code)

def tts():
    code = '''
#pip install googletrans==4.0.0-rc1 
#pip install legacy-cgi
import cgi
import pyttsx3
from googletrans import Translator
from gtts import gTTS
engine = pyttsx3.init()

voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

text = input("Enter Text here: ")

translator = Translator()

translated = translator.translate(text, src='en', dest='fr')

print("Translated Text:", translated.text)

engine.say(translated.text)
engine.runAndWait()

tts = gTTS(text=translated.text, lang='fr')
tts.save("tts.mp3")

print("File saved as tts.mp3")'''
    print(code)

def tower():
    code = '''
def tower(n,a,c,b):
    if n==1:
        print('Move Disk 1 from rod', a , 'to rod', c)
        return
    tower(n-1,a,b,c)
    print('Move Disk',n,'from rod',a,'to rod',c)
    tower(n-1,b,c,a)

n=3
tower(n,'A','C','B')'''
    print(code)

def fuzzy():
    code = '''
elt=['w','x','y','z']
A=[0.5,0.4,0.3,0.2]
B=[0.2,0.1,0.2,1]
def printset(m):
    for i in range(0,4):
         print("(",elt[i],",",m[i],")",end=",")
    print()
print("set A=",end="")
printset(A)
print("set B=")
printset(B)
#union
U=[]
for i in range(0,4):
 if A[i]>B[i]:
     U.append(A[i])
 else:
     U.append(B[i])
print("Union=")
printset(U)
#intersection
I=[]
for i in range(0,4):
 if A[i]<B[i]:
     I.append(A[i])
 else:
     I.append(B[i])
print("Intersection=")
printset(I)
#A complement
AC=[]
for i in range(0,4):
     AC.append(1-A[i])
print("A'=")
printset(AC)
#B complement
BC=[]
for i in range(0,4):
     BC.append(1-B[i])
print("B'=")
printset(BC)
#difference A-B (min(A,BC))
AMB=[]
for i in range(0,4):
 if A[i]<BC[i]:
     AMB.append(A[i])
 else:
     AMB.append(BC[i])
print("difference A-B=")
printset(AMB)
#difference B-A (min(B,AC))
BMA=[]
for i in range(0,4):
 if B[i]<AC[i]:
     BMA.append(B[i])
 else:
     BMA.append(AC[i])
print("difference B-A=")
printset(BMA)'''
    print(code)

def chat():
    code = '''import aiml
kernel=aiml.Kernel()
kernel.learn(path_to_aiml_file) #path to the aiml file
while True:
	print(kernel.respond(input("Enter your message:")))

<aiml version="1.0.1" encoding="UTF-8">
<category>
<pattern>HELLO I AM *</pattern>
<template>HELLO <set name="username"><star/></set></template>
</category>

<category>
<pattern>HOW ARE YOU</pattern>
<template>I AM OK</template>
</category>

<category>
<pattern>WHAT CAN WE DO TODAY</pattern>
<template>
<random>
<li>EXAMPLE 1</li>
<li>EXAMPLE 2</li>
<li>EXAMPLE 3</li>
</random>
</template>
</category>

<category>
<pattern>SHOULD I DO * OR *</pattern>
<template><star index="1"/> SEEMS NICE</template>
</category>

<category>
<pattern>BYE</pattern>
<template>Bye, <get name="username"/> Thank You for your time.</template>
</category>

</aiml>
'''
    print(code)

def pro():
    code = '''
male(ram).
male(ajay).
male(ravi).
male(joy).

female(sudha).
female(priya).
female(jaya).
female(sushma).

parent(ram,sudha,ajay).
parent(ram,sudha,priya).
parent(ajay,jaya,ravi).
parent(ajay,jaya,sushma).

father(X,Y):-parent(X,Z,Y).
mother(X,Y):-parent(Z,X,Y).
'''
    print(code)