#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "eckit" for configuration "MinSizeRel"
set_property(TARGET eckit APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit.so"
  )

list(APPEND _cmake_import_check_targets eckit )
list(APPEND _cmake_import_check_files_for_eckit "${_IMPORT_PREFIX}/lib64/libeckit.so" )

# Import target "eckit_sql" for configuration "MinSizeRel"
set_property(TARGET eckit_sql APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_sql PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_sql.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_sql.so"
  )

list(APPEND _cmake_import_check_targets eckit_sql )
list(APPEND _cmake_import_check_files_for_eckit_sql "${_IMPORT_PREFIX}/lib64/libeckit_sql.so" )

# Import target "eckit_distributed" for configuration "MinSizeRel"
set_property(TARGET eckit_distributed APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_distributed PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_distributed.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_distributed.so"
  )

list(APPEND _cmake_import_check_targets eckit_distributed )
list(APPEND _cmake_import_check_files_for_eckit_distributed "${_IMPORT_PREFIX}/lib64/libeckit_distributed.so" )

# Import target "eckit_geometry" for configuration "MinSizeRel"
set_property(TARGET eckit_geometry APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_geometry PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_geometry.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_geometry.so"
  )

list(APPEND _cmake_import_check_targets eckit_geometry )
list(APPEND _cmake_import_check_files_for_eckit_geometry "${_IMPORT_PREFIX}/lib64/libeckit_geometry.so" )

# Import target "eckit_linalg" for configuration "MinSizeRel"
set_property(TARGET eckit_linalg APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_linalg PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_linalg.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_linalg.so"
  )

list(APPEND _cmake_import_check_targets eckit_linalg )
list(APPEND _cmake_import_check_files_for_eckit_linalg "${_IMPORT_PREFIX}/lib64/libeckit_linalg.so" )

# Import target "eckit_maths" for configuration "MinSizeRel"
set_property(TARGET eckit_maths APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_maths PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_maths.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_maths.so"
  )

list(APPEND _cmake_import_check_targets eckit_maths )
list(APPEND _cmake_import_check_files_for_eckit_maths "${_IMPORT_PREFIX}/lib64/libeckit_maths.so" )

# Import target "eckit_mpi" for configuration "MinSizeRel"
set_property(TARGET eckit_mpi APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_mpi PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_mpi.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_mpi.so"
  )

list(APPEND _cmake_import_check_targets eckit_mpi )
list(APPEND _cmake_import_check_files_for_eckit_mpi "${_IMPORT_PREFIX}/lib64/libeckit_mpi.so" )

# Import target "eckit_option" for configuration "MinSizeRel"
set_property(TARGET eckit_option APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_option PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_option.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_option.so"
  )

list(APPEND _cmake_import_check_targets eckit_option )
list(APPEND _cmake_import_check_files_for_eckit_option "${_IMPORT_PREFIX}/lib64/libeckit_option.so" )

# Import target "eckit_web" for configuration "MinSizeRel"
set_property(TARGET eckit_web APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_web PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_web.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_web.so"
  )

list(APPEND _cmake_import_check_targets eckit_web )
list(APPEND _cmake_import_check_files_for_eckit_web "${_IMPORT_PREFIX}/lib64/libeckit_web.so" )

# Import target "eckit_codec" for configuration "MinSizeRel"
set_property(TARGET eckit_codec APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_codec PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_codec.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_codec.so"
  )

list(APPEND _cmake_import_check_targets eckit_codec )
list(APPEND _cmake_import_check_files_for_eckit_codec "${_IMPORT_PREFIX}/lib64/libeckit_codec.so" )

# Import target "eckit_spec" for configuration "MinSizeRel"
set_property(TARGET eckit_spec APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_spec PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_spec.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_spec.so"
  )

list(APPEND _cmake_import_check_targets eckit_spec )
list(APPEND _cmake_import_check_files_for_eckit_spec "${_IMPORT_PREFIX}/lib64/libeckit_spec.so" )

# Import target "eckit_geo" for configuration "MinSizeRel"
set_property(TARGET eckit_geo APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_geo PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeckit_geo.so"
  IMPORTED_SONAME_MINSIZEREL "libeckit_geo.so"
  )

list(APPEND _cmake_import_check_targets eckit_geo )
list(APPEND _cmake_import_check_files_for_eckit_geo "${_IMPORT_PREFIX}/lib64/libeckit_geo.so" )

# Import target "eckit_version" for configuration "MinSizeRel"
set_property(TARGET eckit_version APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eckit_version PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/eckit-version"
  )

list(APPEND _cmake_import_check_targets eckit_version )
list(APPEND _cmake_import_check_files_for_eckit_version "${_IMPORT_PREFIX}/bin/eckit-version" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
