__version__ = '2.0.6.16'
__commit_hash__ = '03df08e6b2a097fb975d0349054379048aaacae4'
findlibs_dependencies = []
