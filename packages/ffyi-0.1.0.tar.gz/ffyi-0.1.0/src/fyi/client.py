from __future__ import annotations

from typing import Any

import httpx


class FyiClient:
    def __init__(self, *, api_key: str, base_url: str = "https://friends.fyi", timeout: float = 20.0) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        if extra:
            headers.update(extra)
        return headers

    def _request(self, method: str, path: str, *, json: dict[str, Any] | None = None, headers: dict[str, str] | None = None) -> Any:
        url = f"{self.base_url}{path}"
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(method, url, json=json, headers=self._headers(headers))
        response.raise_for_status()
        if response.content:
            return response.json()
        return None

    def send(
        self,
        username: str,
        *,
        message: str | None = None,
        type: str = "http.request",
        subject: str | None = None,
        payload: dict[str, Any] | None = None,
        sender_name: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        resolved_payload: dict[str, Any]
        if payload is not None:
            resolved_payload = payload
        elif message is not None:
            resolved_payload = {"text": message}
        else:
            resolved_payload = {}

        body: dict[str, Any] = {
            "type": type,
            "payload": resolved_payload,
        }
        if subject:
            body["subject"] = subject
        if sender_name:
            body["sender_name"] = sender_name
        if idempotency_key:
            body["idempotency_key"] = idempotency_key

        headers: dict[str, str] | None = None
        if idempotency_key:
            headers = {"Idempotency-Key": idempotency_key}

        return self._request("POST", f"/inbox/{username}", json=body, headers=headers)

    def inbox(self, *, limit: int = 20, status: str | None = None) -> dict[str, Any]:
        params = f"?limit={limit}"
        if status:
            params += f"&status={status}"
        return self._request("GET", f"/inbox{params}")

    def inbox_read(self, message_id: str) -> dict[str, Any]:
        return self._request("GET", f"/inbox/{message_id}")

    def keys_create(self, name: str, *, scopes: list[str] | None = None) -> dict[str, Any]:
        body = {"name": name, "scopes": scopes or ["inbox:write"]}
        return self._request("POST", "/api/keys", json=body)

    def keys_list(self) -> list[dict[str, Any]]:
        return self._request("GET", "/api/keys")

    def keys_revoke(self, key_id: str) -> None:
        self._request("DELETE", f"/api/keys/{key_id}")

    def whoami(self) -> dict[str, Any]:
        return self._request("GET", "/api/me")
