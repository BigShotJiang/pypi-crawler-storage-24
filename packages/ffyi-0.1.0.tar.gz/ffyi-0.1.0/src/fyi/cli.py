from __future__ import annotations

import json
import webbrowser
from typing import Any

import typer

from .client import FyiClient
from .config import FyiConfig, load_config, save_config

app = typer.Typer(help="friends.fyi CLI")
keys_app = typer.Typer(help="API key commands")
inbox_app = typer.Typer(help="Inbox commands")

app.add_typer(keys_app, name="keys")
app.add_typer(inbox_app, name="inbox")


def _print(value: Any, *, as_json: bool) -> None:
    if as_json:
        typer.echo(json.dumps(value, indent=2, sort_keys=True, default=str))
    else:
        if isinstance(value, str):
            typer.echo(value)
        else:
            typer.echo(json.dumps(value, indent=2, default=str))


def _resolve_client(
    *,
    api_key: str | None,
    server: str | None,
) -> FyiClient:
    config = load_config()
    resolved_server = (server or config.server or "https://friends.fyi").rstrip("/")
    resolved_key = api_key or config.api_key
    if not resolved_key:
        raise typer.BadParameter("No API key found. Run `ffyi login --api-key ...` (or `fyi login`).")
    return FyiClient(api_key=resolved_key, base_url=resolved_server)


@app.command()
def login(
    server: str = typer.Option("https://friends.fyi", help="friends.fyi server base URL"),
    api_key: str | None = typer.Option(None, help="API key to store"),
    open_browser: bool = typer.Option(True, help="Open GitHub login page in browser"),
) -> None:
    server = server.rstrip("/")
    if open_browser:
        webbrowser.open(f"{server}/auth/login")
        typer.echo("Opened browser for GitHub login. Create an API key from the web UI if needed.")

    if not api_key:
        api_key = typer.prompt("API key", hide_input=False)

    save_config(FyiConfig(server=server, api_key=api_key))
    typer.echo(f"Saved config at ~/.fyi/config.toml for {server}")


@app.command()
def whoami(
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)
    me = client.whoami()
    _print(me, as_json=json_output)


@app.command()
def send(
    username: str = typer.Argument(..., help="Inbox username"),
    message: str | None = typer.Argument(None, help="Plain text message"),
    type: str = typer.Option("http.request", help="Message type"),
    subject: str | None = typer.Option(None, help="Message subject"),
    payload: str | None = typer.Option(None, help="JSON payload string"),
    sender_name: str | None = typer.Option(None, help="Sender display name"),
    idempotency_key: str | None = typer.Option(None, help="Idempotency key"),
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)

    parsed_payload: dict[str, Any] | None = None
    if payload:
        try:
            loaded = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise typer.BadParameter(f"Invalid payload JSON: {exc}") from exc
        if not isinstance(loaded, dict):
            raise typer.BadParameter("Payload must be a JSON object")
        parsed_payload = loaded

    if message is None and parsed_payload is None:
        raise typer.BadParameter("Provide either <message> or --payload")

    result = client.send(
        username,
        message=message,
        type=type,
        subject=subject,
        payload=parsed_payload,
        sender_name=sender_name,
        idempotency_key=idempotency_key,
    )
    _print(result, as_json=json_output)


@inbox_app.callback(invoke_without_command=True)
def inbox_list(
    ctx: typer.Context,
    limit: int = typer.Option(20, min=1, max=200, help="Number of messages"),
    status: str | None = typer.Option(None, help="Filter by unread/read/archived"),
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    if ctx.invoked_subcommand:
        return
    client = _resolve_client(api_key=api_key, server=server)
    result = client.inbox(limit=limit, status=status)
    _print(result, as_json=json_output)


@inbox_app.command("read")
def inbox_read(
    message_id: str,
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)
    result = client.inbox_read(message_id)
    _print(result, as_json=json_output)


@keys_app.command("create")
def keys_create(
    name: str,
    scopes: str = typer.Option("inbox:write", help="Comma-separated scopes"),
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)
    parsed_scopes = [scope.strip() for scope in scopes.split(",") if scope.strip()]
    result = client.keys_create(name=name, scopes=parsed_scopes)
    _print(result, as_json=json_output)


@keys_app.command("list")
def keys_list(
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON output"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)
    result = client.keys_list()
    _print(result, as_json=json_output)


@keys_app.command("revoke")
def keys_revoke(
    key_id: str,
    api_key: str | None = typer.Option(None, help="Override API key"),
    server: str | None = typer.Option(None, help="Override server URL"),
) -> None:
    client = _resolve_client(api_key=api_key, server=server)
    client.keys_revoke(key_id)
    typer.echo(f"Revoked key {key_id}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
