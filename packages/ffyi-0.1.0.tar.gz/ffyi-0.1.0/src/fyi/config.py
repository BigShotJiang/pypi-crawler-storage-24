from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import tomli_w

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


CONFIG_DIR = Path.home() / ".fyi"
CONFIG_PATH = CONFIG_DIR / "config.toml"


@dataclass
class FyiConfig:
    server: str = "https://friends.fyi"
    api_key: str | None = None


def load_config() -> FyiConfig:
    if not CONFIG_PATH.exists():
        return FyiConfig()

    data = tomllib.loads(CONFIG_PATH.read_text())
    return FyiConfig(
        server=str(data.get("server", "https://friends.fyi")),
        api_key=str(data["api_key"]) if data.get("api_key") else None,
    )


def save_config(config: FyiConfig) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"server": config.server, "api_key": config.api_key}
    CONFIG_PATH.write_text(tomli_w.dumps(payload))
