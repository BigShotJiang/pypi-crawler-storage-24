# ffyi

CLI and Python client for [friends.fyi](https://friends.fyi).

## Install

```bash
uv tool install ffyi
```

Installed commands: `ffyi` and `fyi` (alias).

## CLI usage

```bash
ffyi login --server https://friends.fyi --api-key fyi_xxx
ffyi whoami
ffyi send brother "hello"
ffyi send brother --type timezone.changed --payload '{"timezone":"Europe/London"}'
ffyi inbox
ffyi inbox read <message_id>
ffyi keys create chad-daemon
ffyi keys list
ffyi keys revoke <key_id>
```

Config is stored at `~/.fyi/config.toml`.

## Python usage

```python
from fyi import FyiClient

client = FyiClient(api_key="fyi_xxx", base_url="https://friends.fyi")
client.send("brother", type="timezone.changed", payload={"timezone": "Europe/London"})
messages = client.inbox(limit=10)
```

## Development

```bash
uv sync --extra dev
uv run pytest
uv build --clear
```

## Publish

```bash
export UV_PUBLISH_TOKEN='pypi-...'
uv publish --check-url https://pypi.org/simple --publish-url https://upload.pypi.org/legacy/
```
