from typer.testing import CliRunner

from fyi import cli


runner = CliRunner()


class StubClient:
    def __init__(self, *args, **kwargs):
        pass

    def whoami(self):
        return {"user": {"username": "wil"}}

    def send(self, *args, **kwargs):
        return {"id": "msg_1"}

    def inbox(self, *args, **kwargs):
        return {"items": []}

    def inbox_read(self, *args, **kwargs):
        return {"id": "msg_1"}

    def keys_create(self, *args, **kwargs):
        return {"id": "key_1"}

    def keys_list(self):
        return [{"id": "key_1"}]

    def keys_revoke(self, key_id):
        return None


class StubConfig:
    server = "https://friends.fyi"
    api_key = "fyi_stub"


def test_whoami(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_config", lambda: StubConfig())

    result = runner.invoke(cli.app, ["whoami", "--json"])
    assert result.exit_code == 0
    assert "wil" in result.output


def test_send_requires_message_or_payload(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_config", lambda: StubConfig())

    result = runner.invoke(cli.app, ["send", "brother"])
    assert result.exit_code != 0
    assert "Provide either <message> or --payload" in result.output


def test_keys_revoke(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_config", lambda: StubConfig())

    result = runner.invoke(cli.app, ["keys", "revoke", "key_1"])
    assert result.exit_code == 0
    assert "Revoked key key_1" in result.output
