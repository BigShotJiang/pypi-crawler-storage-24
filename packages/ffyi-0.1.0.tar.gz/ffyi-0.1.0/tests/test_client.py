import httpx

from fyi.client import FyiClient


class DummyClient(FyiClient):
    def __init__(self):
        super().__init__(api_key="fyi_test", base_url="https://friends.fyi")
        self.calls = []

    def _request(self, method, path, *, json=None, headers=None):  # noqa: A003
        self.calls.append({"method": method, "path": path, "json": json, "headers": headers})
        return {"ok": True}


def test_send_from_plain_message():
    client = DummyClient()
    client.send("brother", message="hi")

    call = client.calls[0]
    assert call["method"] == "POST"
    assert call["path"] == "/inbox/brother"
    assert call["json"]["payload"] == {"text": "hi"}


def test_send_with_idempotency_header():
    client = DummyClient()
    client.send("brother", payload={"x": 1}, idempotency_key="abc123")

    call = client.calls[0]
    assert call["headers"] == {"Idempotency-Key": "abc123"}
    assert call["json"]["idempotency_key"] == "abc123"


def test_inbox_query_string():
    client = DummyClient()
    client.inbox(limit=5, status="unread")
    call = client.calls[0]
    assert call["path"] == "/inbox?limit=5&status=unread"


def test_headers_include_api_key():
    client = FyiClient(api_key="fyi_abc", base_url="https://friends.fyi")
    headers = client._headers()
    assert headers["Authorization"] == "Bearer fyi_abc"


def test_request_raises_on_http_error(monkeypatch):
    client = FyiClient(api_key="fyi_abc", base_url="https://friends.fyi")

    class FakeResponse:
        content = b""

        def raise_for_status(self):
            raise httpx.HTTPStatusError("bad", request=httpx.Request("GET", "https://x"), response=httpx.Response(500))

    class FakeHttpxClient:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def request(self, *args, **kwargs):
            return FakeResponse()

    monkeypatch.setattr(httpx, "Client", lambda *a, **k: FakeHttpxClient())

    try:
        client.whoami()
        assert False, "Expected HTTPStatusError"
    except httpx.HTTPStatusError:
        pass
