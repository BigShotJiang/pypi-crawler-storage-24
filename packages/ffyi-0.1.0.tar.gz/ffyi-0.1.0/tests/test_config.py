from pathlib import Path

from fyi.config import CONFIG_DIR, CONFIG_PATH, FyiConfig, load_config, save_config


def test_load_defaults_when_missing(tmp_path, monkeypatch):
    monkeypatch.setattr("fyi.config.CONFIG_DIR", tmp_path / "cfg")
    monkeypatch.setattr("fyi.config.CONFIG_PATH", tmp_path / "cfg" / "config.toml")

    cfg = load_config()
    assert cfg.server == "https://friends.fyi"
    assert cfg.api_key is None


def test_save_and_load_round_trip(tmp_path, monkeypatch):
    config_dir = tmp_path / "cfg"
    config_path = config_dir / "config.toml"
    monkeypatch.setattr("fyi.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("fyi.config.CONFIG_PATH", config_path)

    save_config(FyiConfig(server="https://example.com", api_key="fyi_abc"))
    assert config_path.exists()

    loaded = load_config()
    assert loaded.server == "https://example.com"
    assert loaded.api_key == "fyi_abc"


def test_config_constants_are_paths():
    assert isinstance(CONFIG_DIR, Path)
    assert isinstance(CONFIG_PATH, Path)
