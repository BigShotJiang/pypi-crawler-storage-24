import itertools
from collections import deque


def max_sum_subarray_size_k(nums: list[int], k: int) -> int:
    prefix = {**dict(enumerate(itertools.accumulate(nums))), -2: 0, -1: 0}
    dq = deque()
    dq.append(-1)
    best = float("inf")

    for index, num in enumerate(nums):
        while dq and prefix[index] - prefix[dq[0] - 1] >= k:
            best = min(best, index - dq.popleft())

        while dq and num >= nums[dq[0]]:
            dq.popleft()

        dq.append(index)

    return best


print(max_sum_subarray_size_k(nums=[2, 1, 5, 1, 3, 2], k=3))
