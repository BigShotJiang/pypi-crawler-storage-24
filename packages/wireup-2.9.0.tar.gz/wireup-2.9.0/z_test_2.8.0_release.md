# Wireup 2.8.0 Release Review (vs `v2.7.1`)

## Findings

### 1. High: FastAPI WebSocket scope inconsistency when `middleware_mode=True`

- In `wireup/integration/fastapi.py`, only `APIRoute` uses `get_request_container` in middleware mode.
- `APIWebSocketRoute` falls through to `_context_creator` injection path, which creates a separate scope.
- `get_request_container()` still points to middleware scope (`wireup.integration.starlette.current_request` state container).
- Result: websocket handlers can resolve scoped services from a different scope than `get_request_container()` in the same request lifecycle.

Repro done locally:
- Injected scoped dependency in websocket endpoint.
- Compared it with `await get_request_container().get(ScopedType)`.
- Observed mismatch (`False`), confirming inconsistent scope identity.

Release risk:
- High for users mixing websocket route injection with helper/decorator code that uses `get_request_container()`.

---

### 2. Note (not a blocker): `setup()` is intentionally non-idempotent

- FastAPI docs/code already define `setup(...)` as a one-time bootstrap step:
  - all routes should be added before setup
  - middleware ordering constraints apply after setup
- Starlette and AIOHTTP setup paths are similarly non-idempotent (middleware/lifespan/hooks are appended).
- Given this contract, repeated setup is not supported behavior, so duplicate `WireupTask` registration on repeated calls is consistent with existing setup semantics.

Reclassification:
- Not a release blocker.
- Optional DX improvement only: fail with a clearer explicit error if setup is called twice.

---

### 3. Low: `InvalidAsTypeError` bypassed for falsy invalid `as_type` values

- Validation is guarded by truthiness (`if impl.as_type:`), so falsy invalid values (`0`, `False`) skip validation.
- Behavior falls back to normal registration (`target_type or klass`) instead of raising `InvalidAsTypeError`.

Repro done locally:
- `@injectable(as_type=0)` and `@injectable(as_type=False)` succeeded.

Release risk:
- Low but correctness/API-consistency issue.

---

### 4. Low: Duplicate `"inject"` in `wireup.integration.fastapi.__all__`

- `__all__` includes `"inject"` twice.
- No runtime break, but this is a clean-up/lint quality issue.

Release risk:
- Low.

---

## Test Gaps

1. Missing websocket middleware-mode scope-identity test in FastAPI integration.
- Current websocket tests verify successful behavior/output, but not that scoped injection and `get_request_container()` resolve from the same scope object.

2. Missing FastAPI codegen snapshot for websocket routes in `middleware_mode=True`.
- HTTP middleware-mode snapshot exists.
- Websocket snapshots currently only cover middleware-off paths.

3. Missing `as_type` tests for falsy invalid keys.
- Existing tests cover invalid truthy values (e.g., `1`) but not `0`/`False`.

4. Missing idempotency tests for repeated `setup()` calls.
- No tests asserting repeated integration setup behavior for FastAPI/Starlette.

---

## Validation Performed

Ran locally:

1. `make test`
- Result: `287 passed, 1 skipped`.

2. `uv run pytest test/integration/fastapi -q`
- Result: `44 passed`.

3. Additional integration runs:
- `test/integration/starlette/test_starlette_integration.py`: passed
- `test/integration/aiohttp/test_aiohttp_integration.py`: passed
- `test/integration/typer/test_typer_integration.py`: passed
- `test/integration/fastmcp/test_fastmcp_standalone_usage.py`: passed
- `test/integration/strawberry/test_strawberry_fastapi_usage.py`: passed
- `test/integration/strawberry/test_strawberry_starlette_usage.py`: passed
- `test/integration/strawberry/test_strawberry_django_usage.py`: passed

Conclusion:
- Existing suite is broadly green.
- Confirmed issues above remain release risks because they are currently under-tested, not because tests are failing.
