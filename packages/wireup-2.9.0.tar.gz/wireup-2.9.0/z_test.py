import wireup
from wireup._annotations import injectable

class Foo: ...

@injectable
def foo() -> Foo:


wireup.create_sync_container(injectables=[foo, foo])