from wireup import create_sync_container, injectable


@injectable(lifetime="scoped", qualifier=-2)
def make_b1() -> int:
    return 666


@injectable(lifetime="scoped", qualifier=-1)
def make_b2() -> int:
    return 42


container = create_sync_container(injectables=[make_b1, make_b2])
with container.enter_scope() as scope:
    a = scope.get(int, qualifier=-1)
    b = scope.get(int, qualifier=-2)
    print(a, b)
