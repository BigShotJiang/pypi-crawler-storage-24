Prefer this docs voice across Wireup pages:

- Plainspoken and concrete.
- Short intros. Let examples do most of the work.
- Prefer describing what the user is doing over naming a category for it.
- Use normal engineering language, not product copy.
- Avoid abstract words like `composition`, `patterns`, `capabilities`, and `strategy` unless they add real meaning.
- Avoid repeating the same point in several phrasings before an example.
- Avoid defensive phrasing like `rather than introducing...`.
- Prefer direct wording like:
  - `Build the injectables list in normal Python.`
  - `Use a function that returns injectable factories.`
  - `Register the same services more than once with different settings.`
- Write like an experienced maintainer explaining the tool to another engineer.

In short: practical, direct, low-abstraction, and example-led.
