# Wireup for Django: one DI model across views, DRF, commands, and Django 6 tasks

Hi all,

I built [Wireup](https://github.com/maldoinc/wireup), a type-driven DI library for Python, and I recently spent some
time improving the Django integration.

The problem I was trying to solve was not just "DI in views", but keeping dependency wiring coherent once a Django
project grows beyond request handlers and starts spreading logic across:

- HTTP entry points (Django views, DRF, Ninja)
- management commands
- signal/check code
- Django 6 background tasks

What you get:

- startup graph validation for missing dependencies, cycles, lifetime mismatches, and missing config
- one service graph reusable across Django views, DRF, Ninja, commands, and background tasks
- explicit request-scoped vs app-level resolution, so background work does not accidentally depend on request state
- regular Python services that stay easy to test directly
- the same DI style across HTTP and non-HTTP entry points, instead of each framework surface having its own pattern

Simple view example:

```python
from django.http import HttpRequest, HttpResponse
from wireup import Injected
from wireup.integration.django import inject


@inject
def greet(request: HttpRequest, greeter: Injected[GreeterService]) -> HttpResponse:
    return HttpResponse(greeter.greet(request.GET.get("name", "World")))
```

The same pattern works in DRF and Ninja as well.

For non-request entry points, Wireup uses `@inject_app` instead of `@inject`:

```python
from django.core.management.base import BaseCommand
from wireup import Injected
from wireup.integration.django import inject_app


class Command(BaseCommand):
    @inject_app
    def handle(self, *args, greeter: Injected[GreeterService], **options) -> None:
        self.stdout.write(greeter.greet("World"))
```

Django 6 background tasks fit that same app-level model:

```python
from django.tasks import task
from wireup import Injected
from wireup.integration.django import inject_app


@task
@inject_app
def send_welcome_email(user_id: int, email: Injected[EmailService]) -> None:
    email.send_welcome(user_id)
```

If a project also uses Celery, Wireup has a Celery integration as well, with the same general approach to injecting
dependencies outside the request path.

The part I find most useful is being able to keep one service graph across HTTP, commands, and background work instead
of each entry point ending up with its own wiring style.

Docs:
https://maldoinc.github.io/wireup/latest/integrations/django/

Repo:
https://github.com/maldoinc/wireup

Curious how others are handling this across HTTP and non-HTTP entry points in larger Django projects.
