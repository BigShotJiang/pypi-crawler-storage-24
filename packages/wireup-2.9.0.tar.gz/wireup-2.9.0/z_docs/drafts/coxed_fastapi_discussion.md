# Show and Tell: Wireup for FastAPI, near-manual DI performance, startup graph validation, and background task injection

I maintain [Wireup](https://github.com/maldoinc/wireup), a DI library for Python with a deep FastAPI integration.

I recently benchmarked it against FastAPI `Depends` using real FastAPI + Uvicorn request/responses.

Snapshot from the current run (50 rounds x 100,000 requests):

- Per-request injection: Wireup **11,030 RPS** vs Manual Wiring **11,044 RPS** vs FastAPI `Depends` **3,950 RPS**
- Singleton resolution: Wireup **13,214 RPS**, Wireup Class-Based **13,342 RPS**, Manual Wiring **13,351 RPS**, FastAPI `Depends` **6,153 RPS**
- Relative to FastAPI `Depends`: **2.79x** throughput in per-request injection and **2.15x** in singleton resolution

The feature I think is more interesting for FastAPI users, though, is `WireupTask`.

It lets you inject dependencies into FastAPI background task callbacks, where `Depends` cannot reach.
Each scheduled task runs in its own isolated Wireup scope, separate from the request and from other background tasks, so
it gets its own state, DB session, transaction, or other scoped services while still sharing app-wide singletons with
the rest of the application where appropriate.

The other big thing Wireup brings is proper lifetimes. With plain `Depends`, application services are effectively
request-scoped unless you start layering on manual workarounds like `@lru_cache`, `lifespan`, `app.state`, and custom
yield-based factories. Wireup gives you explicit one instance per app (`singleton`), one instance per-request shared
within that request (`scoped`), and an always-fresh instance (`transient`) lifetimes in one container.

FastAPI example with background task injection:

```python
from fastapi import BackgroundTasks, FastAPI
import wireup
import wireup.integration.fastapi
from wireup import Injected, injectable
from wireup.integration.fastapi import WireupTask


@injectable
class GreeterService:
    def greet(self, name: str) -> str:
        return f"Hello, {name}!"


def write_greeting(name: str, greeter: Injected[GreeterService]) -> None:
    print(greeter.greet(name))


container = wireup.create_async_container(injectables=[GreeterService])
app = FastAPI()


@app.post("/enqueue")
async def enqueue(
    name: str,
    tasks: BackgroundTasks,
    wireup_task: Injected[WireupTask],
):
    tasks.add_task(wireup_task(write_greeting), name)
    return {"ok": True}


wireup.integration.fastapi.setup(container, app)
```

Other things Wireup brings to FastAPI:

- fail-fast startup validation of the full dependency graph: missing deps, cycles, lifetime mismatches, and config errors fail at startup
- proper service lifetimes and lifecycle-managed resources: `singleton`, `scoped`, `transient`
- async singleton resources without manual `lifespan` + `app.state` wiring
- request-scoped services without long `Depends(...)` chains through your service graph
- test overrides with scoped context managers, instead of patching or clearing cached dependency state
- optional class-based handlers with constructor dependencies resolved at startup

If the container starts, the graph is valid.

Background task docs:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/background_tasks/

Migration guide:
https://maldoinc.github.io/wireup/latest/migrations/fastapi_depends/

Benchmarks with methodology and reproducibility:
https://maldoinc.github.io/wireup/latest/benchmarks/

Docs:
https://maldoinc.github.io/wireup/latest/

Repo:
https://github.com/maldoinc/wireup

Happy to answer questions, and if anything in the benchmark looks unfair I’m happy to discuss that too.

@tiangolo let me know if this isn't the right place.
