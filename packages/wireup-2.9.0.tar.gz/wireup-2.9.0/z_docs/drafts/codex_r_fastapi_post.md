## Wireup got a new FastAPI release: background task injection, startup validation, and fast request-time DI

Hi /r/fastapi,

I built [Wireup](https://github.com/maldoinc/wireup), a type-driven DI library for Python, and I recently spent some
time improving the FastAPI integration.

The FastAPI integration is not just route parameter injection. It covers route handlers, WebSockets, request-time
injection, class-based handlers (think fastapi-utils `@cbv`) with zero request-time overhead, request/websocket context in services, testing helpers, and background tasks. If you want to see the full integrations, the docs are here:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/

The new feature I think is most interesting for FastAPI users is `WireupTask`.

It lets you inject dependencies into FastAPI background task callbacks.
Each scheduled task runs in its own isolated Wireup scope, separate from the request and from other background tasks, so
it gets its own state, DB session, transaction, or other scoped services while still sharing app-wide singletons with
the rest of the application where appropriate.

The other big thing Wireup brings is explicit lifetimes. FastAPI's DI works well for request-time dependencies, but
app-wide services usually end up managed through `app.state` and `@lru_cache`. 
Wireup keeps those lifetimes in one place: app-wide (`singleton`), per-request (`scoped`), and always-fresh (`transient`).

It also validates the dependency graph at startup, so missing dependencies, cycles, lifetime mismatches, and config
errors fail early instead of raising on first resolution.

If you're already using `Depends`, there is also a migration guide showing how to keep FastAPI for HTTP concerns and
move just the service graph over incrementally.

```python
from fastapi import BackgroundTasks, FastAPI
import wireup
import wireup.integration.fastapi
from wireup import Injected, injectable
from wireup.integration.fastapi import WireupTask


@injectable
class GreeterService:
    def greet(self, name: str) -> str:
        return f"Hello, {name}!"


def write_greeting(name: str, greeter: Injected[GreeterService]) -> None:
    print(greeter.greet(name))


container = wireup.create_async_container(injectables=[GreeterService])
app = FastAPI()


@app.post("/enqueue")
async def enqueue(
    name: str,
    tasks: BackgroundTasks,
    wireup_task: Injected[WireupTask],
):
    tasks.add_task(wireup_task(write_greeting), name)
    return {"ok": True}


wireup.integration.fastapi.setup(container, app)
```

I also benchmarked it against FastAPI `Depends` using real FastAPI + Uvicorn request/responses.

Snapshot from the current run (50 rounds x 100,000 requests):

- Per-request injection: Wireup **11,030 RPS** vs Manual Wiring **11,044 RPS** vs FastAPI `Depends` **3,950 RPS**
- Singleton resolution: Wireup **13,214 RPS**, Wireup Class-Based **13,342 RPS**, Manual Wiring **13,351 RPS**, FastAPI `Depends` **6,153 RPS**
- Relative to FastAPI `Depends`: **2.79x** throughput in per-request injection and **2.15x** in singleton resolution

Background task docs:
https://maldoinc.github.io/wireup/latest/integrations/fastapi/background_tasks/

Migration guide from `Depends`:
https://maldoinc.github.io/wireup/latest/migrate_to_wireup/fastapi_depends/

Benchmarks with methodology and reproducibility:
https://maldoinc.github.io/wireup/latest/benchmarks/

Docs:
https://maldoinc.github.io/wireup/latest/

Repo:
https://github.com/maldoinc/wireup

Curious how others are handling DI once a FastAPI app has both request handlers and non-request entry points like
background tasks.
