# Open Generics Design

## Goal

Allow Wireup to resolve parameterized generic dependencies such as `Repository[User]` without requiring users to create a concrete subclass only to carry the type argument.

The primary target is patterns like:

```python
from typing import Generic, TypeVar

from wireup import Injected, injectable

T = TypeVar("T")


@injectable
class Repository(Generic[T]):
    def __init__(self, model: GenericType[T], session: Session) -> None:
        self.model = model
        self.session = session


def handler(repo: Injected[Repository[User]]) -> None: ...
```

In this design, requesting `Repository[User]` causes Wireup to instantiate `Repository` with `model=User`.

## Problem

Wireup can inspect `Repository[User]` and determine that `T=User`, but there is currently no standard way to expose that resolved type argument to the provider constructor or factory.

Using a bare `T` or `type[T]` parameter is not sufficient:

- `T` is not a concrete runtime type.
- `type[T]` currently looks like a normal dependency request.
- Wireup would incorrectly try to resolve it from the container.

What is needed is a dedicated binding mode for "this parameter comes from the generic specialization being resolved, not from the container."

## Proposed API

Introduce a special `Inject(...)` mode for generic argument binding and expose a type alias for ergonomic use.

Low-level spelling:

```python
from typing import Annotated, TypeVar

from wireup import Inject

T = TypeVar("T")

GenericType = Annotated[type[T], Inject(generic_arg=True)]
```

Usage:

```python
from typing import Generic, TypeVar

from wireup import Injected, injectable

T = TypeVar("T")


@injectable
class Repository(Generic[T]):
    def __init__(self, session: Session, model: GenericType[T]) -> None:
        self.session = session
        self.model = model


repo: Injected[Repository[User]]
```

When resolving `Repository[User]`, Wireup binds `model` to `User`.

## Why `Annotated[...]`

This keeps generic argument binding inside Wireup's existing injection annotation model instead of introducing a second mechanism.

Benefits:

- It is explicit in the provider signature.
- It does not overload bare `T` or `type[T]`.
- It can be handled by the existing parameter parsing pipeline.
- It keeps normal dependency resolution and generic-argument binding distinct.

## User Experience

Users define a generic provider once and request specialized versions directly.

Example:

```python
from typing import Generic, TypeVar

from sqlalchemy import select
from sqlalchemy.orm import Session

from wireup import Injected, injectable

T = TypeVar("T")

GenericType = Annotated[type[T], Inject(generic_arg=True)]


@injectable
class Repository(Generic[T]):
    def __init__(self, session: Session, model: GenericType[T]) -> None:
        self.session = session
        self.model = model

    def get(self, id: int) -> T | None:
        stmt = select(self.model).where(self.model.id == id)
        return self.session.scalar(stmt)


def get_user(repo: Injected[Repository[User]]) -> User | None:
    return repo.get(1)
```

This removes the need for:

```python
@injectable
class UserRepository(Repository[User]):
    def __init__(self, session: Session) -> None:
        super().__init__(session, User)
```

## Resolution Model

### Dependency Key

Wireup must treat a parameterized generic as a first-class dependency key.

Examples:

- `Repository[User]`
- `Box[int]`
- `Cache[Order, Region]`

This means the resolver must preserve both:

- origin type: `Repository`
- generic arguments: `(User,)`

### Registration Model

Normal `@injectable` registration on a generic class or factory should register the unspecialized origin as an open-generic provider.

Examples:

- class registration: `Repository`
- factory registration: `make_repository`

At resolution time, Wireup specializes the registration using the requested generic arguments.

### Parameter Binding

When resolving a provider for `Repository[User]`:

1. Parse the requested type into origin `Repository` and args `(User,)`.
2. Find the registration for the open generic origin.
3. Build a generic binding context mapping type variables to concrete types.
4. For each provider parameter:
   - normal parameters resolve from the container
   - `Inject(generic_arg=True)` parameters resolve from the generic binding context
5. Instantiate the provider.

## Generic Binding Context

Wireup needs an internal structure similar to:

```python
{T: User}
```

This context exists only during resolution of a specialized generic request.

It should be available to the parameter resolver, but it should not be globally visible as a general container override or runtime object store.

## Supported Shapes

Initial scope should be narrow and predictable.

Recommended first version:

- `Annotated[type[T], Inject(generic_arg=True)]`

Deferred for later:

- direct value binding for `T`
- tuple unpacking for `TypeVarTuple`
- partial specialization
- nested derived expressions like `list[type[T]]`
- constraints involving `ParamSpec`

Starting with `type[T]` matches the main real-world use case: passing a model class, entity type, serializer type, or schema type into a generic provider.

## Factories

The same mechanism should work for factories.

Example:

```python
T = TypeVar("T")
GenericType = Annotated[type[T], Inject(generic_arg=True)]


@injectable
def make_repository(session: Session, model: GenericType[T]) -> Repository[T]:
    return Repository(session=session, model=model)
```

Request:

```python
repo: Injected[Repository[User]]
```

Wireup binds `model=User` before calling the factory.

## Validation Rules

Wireup should fail early and clearly for unsupported or invalid cases.

Validation rules:

- `Inject(generic_arg=True)` is only valid inside a provider that is being resolved as a specialized generic.
- If the requested dependency is not parameterized, resolution fails.
- If the annotation references a type variable that is not part of the provider's generic parameters, registration fails.
- If the requested specialization does not provide enough type arguments, resolution fails.
- If multiple generic-bound parameters refer to the same `T`, they must resolve consistently.

Example error:

> Cannot bind generic argument for parameter `model` in `Repository.__init__`: `Repository` was requested without concrete type parameters.

## Caching and Lifetimes

Specialized generic resolutions should behave like distinct dependency keys.

Examples:

- `Repository[User]` singleton and `Repository[Order]` singleton are different cached instances.
- Scoped/transient semantics apply per specialized key.

This is important because each specialization may carry different generic-bound runtime values such as `User` or `Order`.

## Interaction With Existing Features

### `Injected[...]`

No API change needed. Users request `Injected[Repository[User]]`.

### `as_type`

Open questions remain around whether generic registrations can also be exposed under a different generic type. This should not block the first implementation.

Recommendation: do not support generic `as_type` remapping in v1 unless the implementation falls out naturally.

### Qualifiers

Qualifiers should continue to work, but apply to the open generic registration.

Example:

```python
@injectable(qualifier="readonly")
class Repository(Generic[T]): ...
```

Then users could request a qualified `Repository[User]`.

This likely needs no new syntax, only correct key composition.

## Naming

The underlying flag should be descriptive and implementation-oriented.

Recommended internal/public flag:

- `Inject(generic_arg=True)`

Reasonable alias names:

- `GenericType[T]`
- `GenericArgType[T]`
- `SpecializedType[T]`

Recommendation:

- keep the flag as `generic_arg=True`
- expose `GenericType[T]` as the primary alias

`GenericType[T]` is short and fits the main use case well.

## Alternatives Considered

### 1. Require concrete subclasses

Current workaround:

```python
@injectable
class UserRepository(Repository[User]):
    model = User
```

This works, but it adds boilerplate and scales poorly when many type specializations are needed.

### 2. Treat bare `type[T]` specially

This is too implicit. It becomes difficult to distinguish between:

- "inject the concrete generic type argument"
- "resolve a dependency whose type happens to be `type[Something]`"

The explicit annotation marker is safer.

### 3. Inject bare `T`

This is not suitable for the first version:

- it is not a normal runtime value
- it is ambiguous whether the user wants `User` or an instance of `User`
- it complicates the parameter resolution model unnecessarily

`type[T]` is the more practical unit.

## Recommended Implementation Order

1. Add internal support for parameterized dependency keys.
2. Build generic binding context extraction from requested types.
3. Extend parameter parsing to recognize `Inject(generic_arg=True)`.
4. Bind `Annotated[type[T], Inject(generic_arg=True)]` from the generic context.
5. Ensure lifetime caching uses specialized keys.
6. Add targeted error messages.
7. Document with `Box[T]` and SQLAlchemy repository examples.

## Open Questions

- Should open generic registration require a new decorator, or should existing `@injectable` work automatically for generic classes/factories?
- How should generic `as_type` registrations behave?
- Should Wireup support `Annotated[T, Inject(generic_arg=True)]` later, or keep the model strictly on `type[T]`?
- How should nested specializations be normalized for cache keys?

## Recommendation

Use the existing `@injectable` decorator, add `Inject(generic_arg=True)`, and support `Annotated[type[T], ...]` as the first and only generic-argument binding form in v1.

This keeps the feature:

- explicit
- minimal
- aligned with current Wireup annotation patterns
- sufficient for the main repository/model-class use case

It also leaves room to expand later without committing too early to broader generic injection semantics.
