# New Integrations Plan (Typer, Celery, Strawberry)

## Goal
Extend `wireup.integration` with:
1. `typer` support
2. `celery` support
3. `strawberry` support (thin wrapper over Starlette-style injection)

Keep implementation minimal and aligned with existing `click` / `flask` / `starlette` patterns.

## Final Design Decisions
1. `typer`: full minimal integration module with `setup(...)` + `get_app_container(...)`.
2. `celery`: full minimal integration module with `setup(...)` + `get_app_container(...)`.
3. `strawberry`: thin module exposing `inject` only (no `setup(...)`), reusing Starlette request-container mechanics and `hide_annotated_names=True`.

## Public APIs to Add

### `wireup.integration.typer`
- `setup(container: SyncContainer, app: typer.Typer) -> None`
- `get_app_container(app: typer.Typer) -> SyncContainer`

### `wireup.integration.celery`
- `setup(container: SyncContainer, app: celery.Celery) -> None`
- `get_app_container(app: celery.Celery) -> SyncContainer`

### `wireup.integration.strawberry`
- `inject` decorator only:
  - based on `inject_from_container_unchecked`
  - supplier: `wireup.integration.starlette.get_request_container`
  - with `hide_annotated_names=True`

## Implementation Plan

### 1) Typer integration (`wireup/integration/typer.py`)
- Traverse and wrap:
  - `app.registered_commands[*].callback`
  - `app.registered_callback.callback` (if callable)
  - `app.registered_callback.result_callback` (if callable)
  - recurse into `app.registered_groups[*].typer_instance`
- Wrapper:
  - `inject_from_container(container, hide_annotated_names=True)(callback)`
- Add idempotence marker to avoid double wrapping.
- Store container on app (`app.wireup_container = container`).
- Implement `get_app_container`.

### 2) Celery integration (`wireup/integration/celery.py`)
- Iterate over `app.tasks`.
- Skip built-in tasks (`name.startswith("celery.")`).
- Wrap each task's `run`:
  - `inject_from_container(container, hide_annotated_names=True)(task.run)`
- Add idempotence marker.
- Refresh task header metadata after wrapping (`task.__header__`) to keep arg checking aligned with hidden params.
- Store container on app (`app.wireup_container = container`).
- Implement `get_app_container`.

### 3) Strawberry integration (`wireup/integration/strawberry.py`)
- Export only:
  - `inject = inject_from_container_unchecked(get_request_container, hide_annotated_names=True)`
- No lifecycle/setup logic in this module.
- Document dependency on Starlette/FastAPI integration for request scope.

## Tests to Add

### Typer
File: `test/integration/typer/test_typer_integration.py`
- service injection in command callback
- config injection in command callback
- nested typer groups recursion
- injected args hidden from CLI help/signature behavior
- `get_app_container` returns same container

### Celery
File: `test/integration/celery/test_celery_integration.py`
- eager-mode task with service injection
- config injection in task
- bound task (`bind=True`) works
- injected args not required by caller (arg-check compatibility)
- `get_app_container` returns same container

### Strawberry
File: `test/integration/strawberry/test_strawberry_integration.py`
- resolver uses `@wireup.integration.strawberry.inject`
- injected params are hidden from GraphQL operation args
- request-scoped dependency works via Starlette integration

## Tooling / Matrix Changes
Update `tox.ini`:
- add `py313-typer` (deps: `typer`)
- add `py313-celery` (deps: `celery`)
- add `py313-strawberry` (deps: `strawberry-graphql`, `starlette`, `httpx`)

## Docs Changes
Add:
- `docs/pages/integrations/typer/index.md`
- `docs/pages/integrations/celery/index.md`
- `docs/pages/integrations/strawberry/index.md`
- `docs/pages/class/typer_integration.md`
- `docs/pages/class/celery_integration.md`
- `docs/pages/class/strawberry_integration.md`

Update:
- `docs/mkdocs.yml` nav
- `docs/pages/integrations/index.md` checklist

## How We'll Build This One by One

### Phase A: Typer first
1. Implement `wireup/integration/typer.py`
2. Add Typer integration tests
3. Add Typer tox env
4. Run Typer integration tests and fix issues

### Phase B: Celery second
1. Implement `wireup/integration/celery.py`
2. Add Celery integration tests
3. Add Celery tox env
4. Run Celery integration tests and fix issues

### Phase C: Strawberry third
1. Implement thin `wireup/integration/strawberry.py`
2. Add Strawberry integration tests
3. Add Strawberry tox env
4. Run Strawberry integration tests and fix issues

### Phase D: Docs and polish
1. Add integration docs + class API pages
2. Update nav/checklist
3. Run docs build checks
4. Run full targeted integration test sweep

## Assumptions
- `typer` and `celery` integrations use `SyncContainer`.
- Strawberry remains thin decorator-only support.
- `setup(...)` for Typer/Celery is called after command/task registration.
