# Dependency Injector Knowledge Dump (Practical Reference)

This is a broad, practical knowledge dump for the Python `dependency-injector` library.
It is written as an engineer-facing reference, not a formal specification.

## 1) What Dependency Injector Is

Dependency Injector is an explicit DI framework for Python centered on:

- **Providers**: objects that know how to create/return dependencies.
- **Containers**: objects that group providers and configuration.
- **Wiring**: injection into functions/methods using `@inject` and `Provide[...]`.

Core style: define provider graph in a container, then inject via provider references.

## 2) Mental Model

A container is a registry of providers.
Each provider has a creation/lifecycle policy.
You consume values by:

- calling providers directly (`container.service()`), or
- wiring functions and using `Provide[...]` markers.

Most migration friction (to/from other DI frameworks) is in this model:

- Dependency Injector: provider-first / explicit graph objects.
- Type-first frameworks: class/function signatures drive graph inference.

## 3) Core Container Types

## `containers.DeclarativeContainer`

Class-based declaration of providers.

```python
from dependency_injector import containers, providers

class Container(containers.DeclarativeContainer):
    config = providers.Configuration()
    service = providers.Singleton(Service, api_key=config.api_key)
```

## `containers.DynamicContainer`

Runtime-defined container; providers attached dynamically.
Useful when graph shape is not known at import time.

## 4) Provider Families (Most Important)

## `providers.Factory`

- Returns a new instance each call.
- Equivalent to transient semantics.

```python
user_repo = providers.Factory(UserRepo, db=db)
```

## `providers.Singleton`

- Caches one instance per provider.
- Process/container scoped.

```python
db = providers.Singleton(Database, dsn=config.db_dsn)
```

## `providers.ContextLocalSingleton`

- One instance per context (contextvars/task-local style).
- Commonly used as request/task-scoped equivalent.

## `providers.ThreadLocalSingleton`, `providers.ThreadSafeSingleton`

- Thread-focused singleton variants.
- Useful when concurrency model is thread-oriented.

## `providers.Resource`

- Resource with setup/teardown lifecycle.
- Works with sync/async initializers and generator-style initializers.
- Typically coordinated with `init_resources()` / `shutdown_resources()`.

## `providers.Configuration`

- Structured config provider.
- Supports env and other loading helpers.
- Can pass values directly into providers.

## `providers.Object`

- Wraps constant already-created values.

## `providers.Callable` / `providers.Coroutine`

- Provider for function/coroutine call results.

## `providers.Dependency`

- Placeholder/abstract dependency, supplied later.

## `providers.Selector`

- Conditional provider selection by key.

## Collection providers

- `providers.List`, `providers.Dict` for composing provider outputs.

## 5) Wiring and Injection

Wiring enables injection into plain functions/methods.

Key pieces:

- `@inject`
- `Provide[...]`
- optional `Closing[...]` (resource finalization at call boundary)

```python
from dependency_injector.wiring import inject, Provide

@inject
def handler(service: Service = Provide[Container.service]):
    return service.run()
```

Typical lifecycle:

1. create container
2. configure providers
3. `container.wire(modules=[...], packages=[...])`
4. call wired functions
5. optionally `container.unwire()`

## 6) FastAPI Pattern (Common)

Typical usage pattern in FastAPI:

```python
from fastapi import Depends
from dependency_injector.wiring import inject, Provide

@app.get("/users")
@inject
async def list_users(
    service: UserService = Depends(Provide[Container.user_service]),
):
    return await service.list_all()
```

Container is usually attached to app state and wired during startup/lifespan.
Resources may be initialized in startup and shut down on app shutdown.

## 7) Resources and Lifecycle

Resource initializers often use yield-like structure:

```python
from collections.abc import AsyncIterator

async def session_resource() -> AsyncIterator[ScopedDbSession]:
    session = ScopedDbSession()
    try:
        yield session
    finally:
        await session.close()
```

Registered as:

```python
db_session = providers.Resource(session_resource)
```

Lifecycle control:

- app-level: `container.init_resources()` / `container.shutdown_resources()`
- call-level: `Closing[...]` around injected resource dependency

## 8) Async Notes

- Async resources are supported.
- Async composition with providers is supported.
- Async singleton init patterns are often implemented through resource/lifespan orchestration.

Common pain point in FastAPI integration contexts:

- teams often end up manually managing async client/session lifetimes in app startup/shutdown.

## 9) Overrides and Testing

Strong testing story: provider overriding.

```python
with container.user_service.override(providers.Object(fake_user_service)):
    ...
```

Use cases:

- swap DB clients
- replace external APIs with fakes
- isolate integration boundaries

## 10) Configuration Practices

Configuration provider patterns usually include:

- loading from environment
- type conversion helpers on config values
- centralizing runtime settings in container

Common pattern:

```python
class Container(containers.DeclarativeContainer):
    config = providers.Configuration()
    client = providers.Singleton(Client, base_url=config.api.base_url)
```

## 11) Scoping Patterns You Actually See

## Global singleton graph

- many services as `Singleton`
- easy bootstrapping
- can be over-shared if not careful

## Context-local request scope

- `ContextLocalSingleton` for per-request/task values
- often combined with Resource for cleanup-sensitive objects

## Factory-heavy graph

- explicit object creation per use
- simple mental model, but can increase allocation overhead and boilerplate

## 12) Common Pitfalls

- Wiring not performed (or wrong module/package wired) -> `Provide[...]` not resolved.
- Overuse of global singletons for request-sensitive state.
- Resource cleanup tied only to app shutdown when request-level cleanup was intended.
- Mixing context-local and global providers without explicit boundary.
- Async resources created but not properly finalized.

## 13) Practical Strengths

- Very explicit graph and wiring.
- Mature provider catalog.
- Strong override/testing ergonomics.
- Works well in large applications where explicit provider ownership is desired.

## 14) Practical Tradeoffs

- Provider-object verbosity compared to type-first DI styles.
- Wiring/decorator mechanics add framework glue code.
- Resource/scoping setup can get complex if you need strict per-request semantics plus async cleanup.

## 15) Migration Heuristics (Dependency Injector -> Type-First DI)

When migrating from Dependency Injector, a useful mapping is:

- `Singleton` -> singleton injectable
- `Factory` -> transient injectable
- `ContextLocalSingleton` -> scoped injectable
- `Resource` -> generator/async-generator factory injectable
- `Configuration` -> config injection annotations
- `Provide + @inject` -> signature-based injection marker (`Injected[T]`-style)

Migration order that minimizes risk:

1. migrate stateless/singleton providers first
2. migrate factory/transient providers
3. migrate resources/cleanup-sensitive providers
4. migrate route/function signatures and remove old wiring

## 16) Personal Confidence Notes

High confidence:

- core provider model (Factory/Singleton/Resource/Configuration/Provide)
- container wiring lifecycle concepts
- ContextLocalSingleton as request/task scoped analogue
- override/testing usage pattern

Moderate confidence (verify against exact API docs if needed):

- less common provider variants and edge-case helper methods
- exact signatures/options for some config-loading and selector/aggregate combinations

## 17) Quick Snippet Index

## Declarative container

```python
class Container(containers.DeclarativeContainer):
    config = providers.Configuration()
    db = providers.Singleton(Database, dsn=config.db_dsn)
    repo = providers.Factory(UserRepo, db=db)
```

## Wiring

```python
container = Container()
container.wire(modules=[my_module])
```

## FastAPI endpoint injection

```python
@app.get("/users")
@inject
async def users(repo: UserRepo = Depends(Provide[Container.repo])):
    ...
```

## Resource + cleanup

```python
class Container(containers.DeclarativeContainer):
    http_client = providers.Resource(http_client_resource)
```

## Override in tests

```python
with container.repo.override(providers.Object(fake_repo)):
    ...
```
