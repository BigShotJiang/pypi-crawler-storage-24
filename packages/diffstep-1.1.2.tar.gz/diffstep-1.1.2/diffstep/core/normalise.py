import re

ALLOWED_CHARS = re.compile(r'^[0-9a-zA-Z+\-*/^().\s]+$')
# This module is responsible for validating and normalising the input expression before it is parsed into an AST.

def validate_and_normalise(expr: str) -> str:
    validate_characters(expr)
    expr = normalise(expr)
    check_parenthesis_sandwich(expr)
    expr = insert_implicit_multiplication(expr)
    check_parentheses(expr)
    check_operator_placement(expr)
    check_powers(expr)
    return expr
# The validation functions check for various syntax errors in the input expression, such as invalid characters, unbalanced parentheses, and incorrect operator placement. The normalisation function standardises the expression by removing whitespace and converting uppercase 'X' to lowercase 'x'.

def validate_characters(expr: str):
    if not ALLOWED_CHARS.match(expr):
        raise ValueError("Invalid character found. Only numbers, functions (e.g. trigonometry), x, e, + - * / ^ and () are allowed.")
# This function checks if the input expression contains only allowed characters. If it finds any invalid character, it raises a ValueError with an appropriate message.
    
def normalise(expr: str) -> str:
    expr = expr.replace(" ", "")
    expr = expr.replace("X", "x")
    return expr
# Replaces all whitespace in the expression with nothing (i.e., removes it) and converts all uppercase 'X' to lowercase 'x' for consistency.

def check_parenthesis_sandwich(expr: str):
    pattern = re.compile(r'(\d|x|\))\([^()]*\)(\d|x)')

    if pattern.search(expr):
        raise ValueError(
            "A parenthesised expression cannot have values on both sides, e.g. 2(x+2)2."
        )
# This function checks for the specific case where a parenthesised expression is "sandwiched" between two values (e.g., 2(x+2)2), which is not valid. If such a pattern is found, it raises a ValueError with an appropriate message.

def insert_implicit_multiplication(expr: str) -> str:
    # 2x → 2*x
    expr = re.sub(r'(\d)(x)', r'\1*\2', expr)
    # 2( → 2*(
    expr = re.sub(r'(\d)\(', r'\1*(', expr)
    # x( → x*(
    expr = re.sub(r'(x)\(', r'\1*(', expr)
    # )( → )*(
    expr = re.sub(r'\)\(', r')*(', expr)
    # )x or )2 → )*x or )*2
    expr = re.sub(r'\)(\d|x)', r')*\1', expr)
    return expr
# This funcion allows for implicit multiplication in the input expression. It uses regular expressions to identify patterns where multiplication is implied (e.g., 2x, 2(, x(), )(, )x) and inserts the multiplication operator '*' accordingly.

def check_parentheses(expr: str):
    count = 0
    for c in expr:
        if c == '(':
            count += 1
        elif c == ')':
            count -= 1
        if count < 0:
            raise ValueError("Closing parenthesis without matching opening parenthesis.")
    if count != 0:
        raise ValueError("Unbalanced parentheses.")
# This function checks for balanced parentheses in the expression. It uses a counter to track the number of opening and closing parentheses. If it encounters a closing parenthesis without a matching opening parenthesis, or if there are unbalanced parentheses at the end of the expression, it raises a ValueError with an appropriate message.
    
def check_operator_placement(expr: str):
    if re.search(r'[+*/^]{2,}', expr):
        raise ValueError("Two operators in a row are not allowed.")

    if expr[0] in "+*/^":
        raise ValueError("Expression cannot start with this operator.")

    if expr[-1] in "+-*/^":
        raise ValueError("Expression cannot end with an operator.")
# This function checks for correct operator placement in the expression. It ensures that there are no two operators in a row, and that the expression does not start or end with an operator. If any of these conditions are violated, it raises a ValueError with an appropriate message.
    
def check_powers(expr: str):
    if re.search(r'\^\)', expr):
        raise ValueError("Exponent missing after '^'.")

    if re.search(r'\^$', expr):
        raise ValueError("Expression cannot end with '^'.")
# This function checks for correct usage of the power operator '^'. It ensures that there is an exponent following the '^' operator and that the expression does not end with '^'. If either of these conditions is violated, it raises a ValueError with an appropriate message.