from dataclasses import dataclass
from typing import Optional

# The node classes represent the abstract syntax tree (AST) of the mathematical expressions.
class Node:
    pass


@dataclass
class Num(Node):
    value: float


@dataclass
class Var(Node):
    name: str


@dataclass
class BinOp(Node):
    op: str
    left: Node
    right: Node


@dataclass
class Func(Node):
    name: str
    arg: Node