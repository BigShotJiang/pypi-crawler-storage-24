from .nodes import Num, Var, BinOp, Func

# This parser takes the list of tokens from the tokeniser and builds an abstract syntax tree (AST - expression tree).
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def current(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def eat(self, token_type):
        token = self.current()
        if token and token.type == token_type:
            self.pos += 1
            return token
        raise ValueError(f"Expected {token_type}, got {token}")

    def parse(self):
        node = self.parse_expression()
        if self.current() is not None:
            raise ValueError("Unexpected token at end")
        return node

    def parse_expression(self):
        node = self.parse_term()

        while self.current() and self.current().type in ("PLUS", "MINUS"):
            op = self.current().type
            self.eat(op)
            right = self.parse_term()
            node = BinOp(op, node, right)

        return node

    def parse_term(self):
        node = self.parse_power()

        while self.current() and self.current().type in ("MUL", "DIV"):
            op = self.current().type
            self.eat(op)
            right = self.parse_power()
            node = BinOp(op, node, right)

        return node

    def parse_power(self):
        node = self.parse_factor()

        if self.current() and self.current().type == "POW":
            self.eat("POW")
            right = self.parse_power()
            node = BinOp("POW", node, right)

        return node

    def parse_factor(self):
        token = self.current()

        if token is None:
            raise ValueError("Unexpected end of expression.")

        if token.type == "NUM":
            self.eat("NUM")
            return Num(token.value)

        if token.type == "VAR":
            self.eat("VAR")
            return Var(token.value)

        if token.type == "FUNC":
            func_name = token.value
            self.eat("FUNC")
            self.eat("LPAREN")
            arg = self.parse_expression()
            self.eat("RPAREN")
            return Func(func_name, arg)

        if token.type == "LPAREN":
            self.eat("LPAREN")
            node = self.parse_expression()
            self.eat("RPAREN")
            return node

        if token.type == "MINUS":
            self.eat("MINUS")
            return BinOp("MUL", Num(-1), self.parse_factor())

        raise ValueError(f"Unexpected token: {token}")

def parse(tokens):
    return Parser(tokens).parse()