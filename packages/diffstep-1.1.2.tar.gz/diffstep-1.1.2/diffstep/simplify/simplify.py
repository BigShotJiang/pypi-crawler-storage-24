import sympy as sp
from diffstep.printer.to_string import ast_to_string

x = sp.symbols('x')

def simplify(node):
    expr_str = ast_to_string(node)
    simplified = sp.simplify(expr_str)
    return simplified