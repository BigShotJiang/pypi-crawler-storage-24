# rix

RixDB is currently in development.
Follow https://github.com/Pranav1173/RixDB for updates.