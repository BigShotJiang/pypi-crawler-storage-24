from __future__ import annotations

import base64
import json
import time
from typing import Any
from urllib.parse import parse_qs

from cli.config import CLIConfig, save_config

try:
    import requests
except Exception:  # pragma: no cover - fallback for minimal environments
    requests = None


def _first_str(query_params: dict[str, list[str]], key: str) -> str | None:
    values = query_params.get(key) or []
    if not values:
        return None
    raw = str(values[0]).strip()
    return raw or None


def decode_jwt_payload(token: str | None) -> dict[str, Any] | None:
    try:
        segments = str(token or "").split(".")
        if len(segments) != 3:
            return None
        payload_segment = segments[1]
        padded = payload_segment + "=" * ((4 - len(payload_segment) % 4) % 4)
        decoded = json.loads(base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8"))
        return decoded if isinstance(decoded, dict) else None
    except Exception:
        return None


def token_expiration_epoch(token: str | None) -> int | None:
    payload = decode_jwt_payload(token)
    if not payload:
        return None
    raw_exp = payload.get("exp")
    try:
        exp_value = int(raw_exp)
    except (TypeError, ValueError):
        return None
    return exp_value if exp_value > 0 else None


def is_token_expired(
    token: str | None,
    *,
    now_epoch: int | None = None,
    leeway_seconds: int = 30,
) -> bool:
    exp_epoch = token_expiration_epoch(token)
    if exp_epoch is None:
        return False
    now_value = int(now_epoch if now_epoch is not None else time.time())
    return now_value >= (exp_epoch - max(0, int(leeway_seconds)))


def apply_callback_auth(config: CLIConfig, callback_query: str) -> None:
    params = parse_qs(callback_query)
    token = (
        _first_str(params, "id_token")
        or _first_str(params, "token")
        or _first_str(params, "access_token")
    )
    if token:
        config.token = token
    config.refresh_token = _first_str(params, "refresh_token")
    config.oidc_token_endpoint = _first_str(params, "token_endpoint") or _first_str(
        params, "oidc_token_endpoint"
    )
    config.oidc_client_id = _first_str(params, "client_id") or _first_str(
        params, "oidc_client_id"
    )
    config.oidc_client_secret = _first_str(params, "client_secret") or _first_str(
        params, "oidc_client_secret"
    )


def maybe_refresh_bearer_token(
    config: CLIConfig,
    *,
    force: bool = False,
    leeway_seconds: int = 120,
) -> str | None:
    token = str(config.token or "").strip() or None
    if not force and token and not is_token_expired(token, leeway_seconds=leeway_seconds):
        return token

    refresh_token = str(config.refresh_token or "").strip() or None
    token_endpoint = str(config.oidc_token_endpoint or "").strip() or None
    client_id = str(config.oidc_client_id or "").strip() or None
    if not refresh_token or not token_endpoint or not client_id:
        return token

    if requests is None:
        return token

    data: dict[str, str] = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": client_id,
    }
    client_secret = str(config.oidc_client_secret or "").strip()
    if client_secret:
        data["client_secret"] = client_secret

    try:
        response = requests.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=10,
        )
    except Exception:
        return token

    if response.status_code >= 400:
        return token

    try:
        payload = response.json()
    except Exception:
        return token
    if not isinstance(payload, dict):
        return token

    next_token = (
        str(payload.get("id_token") or "").strip()
        or str(payload.get("token") or "").strip()
        or str(payload.get("access_token") or "").strip()
        or None
    )
    if not next_token:
        return token

    config.token = next_token
    next_refresh_token = str(payload.get("refresh_token") or "").strip()
    if next_refresh_token:
        config.refresh_token = next_refresh_token
    save_config(config)
    return config.token
