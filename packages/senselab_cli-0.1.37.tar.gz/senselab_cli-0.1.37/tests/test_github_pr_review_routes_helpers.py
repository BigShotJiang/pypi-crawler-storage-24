import unittest
import uuid
from flask import Flask
from types import SimpleNamespace

from api.routes.github import (
    _build_artifact_deployment_metrics_payload,
    _compute_setup_diagnostics,
    _compute_trust_summary,
    _resolve_assistant_scope_for_lineage,
    _get_metrics_window,
    _verify_provenance_claims,
    _evaluate_effective_policy,
    _build_mode_workflow_map_for_specialist,
    _refresh_binding_mode_map,
    _infer_review_mode_from_workflow_name,
    _is_internal_worker_call,
    _is_pr_paused,
    _resolve_review_modes_for_event,
    _upsert_pr_pause_state,
    _workflow_ids_for_mode,
)
from unittest.mock import MagicMock, patch


class GitHubPRReviewRouteHelpersTest(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.config["APP_SECRET_KEY"] = "test-secret"

    def test_internal_worker_call_authorized(self):
        with self.app.test_request_context(
            "/api/github/project/pr-reviews/process/worker",
            method="POST",
            headers={"X-Internal-Worker-Key": "test-secret"},
        ):
            self.assertTrue(_is_internal_worker_call(self._request_proxy()))

    def test_internal_worker_call_unauthorized(self):
        with self.app.test_request_context(
            "/api/github/project/pr-reviews/process/worker",
            method="POST",
            headers={"X-Internal-Worker-Key": "wrong"},
        ):
            self.assertFalse(_is_internal_worker_call(self._request_proxy()))

    def test_verify_provenance_claims_marks_verified_when_all_checks_pass(self):
        status, details, errors = _verify_provenance_claims(
            {
                "artifact_digest": "sha256:abc",
                "metadata_json": {
                    "verification": {
                        "signature_valid": True,
                        "identity_valid": True,
                        "provenance_valid": True,
                        "sbom_valid": True,
                        "subject_digest": "sha256:abc",
                    }
                },
            }
        )
        self.assertEqual(status, "verified")
        self.assertEqual(details["verification_status"], "verified")
        self.assertEqual(errors, [])

    def test_verify_provenance_claims_fails_on_subject_digest_mismatch(self):
        status, _, errors = _verify_provenance_claims(
            {
                "artifact_digest": "sha256:abc",
                "metadata_json": {
                    "verification": {
                        "signature_valid": True,
                        "identity_valid": True,
                        "provenance_valid": True,
                        "subject_digest": "sha256:def",
                    }
                },
            }
        )
        self.assertEqual(status, "failed")
        self.assertTrue(any("Subject digest does not match artifact digest" in error for error in errors))

    def test_compute_trust_summary_tracks_claimed_vs_verified_deployments(self):
        records = [
            SimpleNamespace(
                artifact_digest="sha256:a",
                attestation_verified=True,
                verification_status="verified",
                sbom_present=True,
                effective_policy_verdict="pass",
                policy_verdict="pass",
                environment="prod",
                deployment_id="dep-1",
                deployment_verified=True,
                observed_at=None,
                created_on=None,
            ),
            SimpleNamespace(
                artifact_digest="sha256:b",
                attestation_verified=False,
                verification_status="partial",
                sbom_present=False,
                effective_policy_verdict="warn",
                policy_verdict="warn",
                environment="staging",
                deployment_id="dep-2",
                deployment_verified=False,
                observed_at=None,
                created_on=None,
            ),
        ]
        summary = _compute_trust_summary(records)
        self.assertEqual(summary["linked_deployments_claimed"], 2)
        self.assertEqual(summary["linked_deployments_verified"], 1)
        self.assertEqual(summary["linked_deployments"], 1)
        self.assertEqual(summary["verified_link_ratio"], 0.5)

    def test_compute_setup_diagnostics_identifies_missing_critical_fields(self):
        rows = [
            SimpleNamespace(
                deployment_id="dep-1",
                environment="prod",
                deployment_ref_url="https://example.com/deploy/1",
                deployment_provider="github",
                service_ref=None,
                artifact_registry_provider=None,
            ),
            SimpleNamespace(
                deployment_id=None,
                environment="staging",
                deployment_ref_url=None,
                deployment_provider=None,
                service_ref=None,
                artifact_registry_provider=None,
            ),
        ]
        diagnostics = _compute_setup_diagnostics(rows)
        self.assertEqual(diagnostics["records_scanned"], 2)
        self.assertIn("deployment_id", diagnostics["missing_critical_fields"])
        self.assertGreater(len(diagnostics["recommendations"]), 0)

    def test_resolve_assistant_scope_uses_explicit_assistant_guid(self):
        assistant_guid = uuid.uuid4()
        query = MagicMock()
        query.with_entities.return_value.order_by.return_value.limit.return_value.all.return_value = []
        with patch("api.routes.github._apply_pack_metrics_filters", return_value=(query, {})):
            scope = _resolve_assistant_scope_for_lineage(
                project_guid="proj",
                since=None,
                assistant_guid=assistant_guid,
                assistant_type=None,
                repository_full_name=None,
                pull_request_number=None,
                review_mode=None,
                risk_level=None,
            )
        self.assertEqual(scope["matched_by"], "assistant_guid")
        self.assertEqual(scope["resolved_assistant_guid"], str(assistant_guid))

    def test_resolve_assistant_scope_derives_assistant_from_type(self):
        derived_guid = uuid.uuid4()
        typed_query = MagicMock()
        typed_query.order_by.return_value.first.return_value = SimpleNamespace(assistant_guid=derived_guid)
        scoped_query = MagicMock()
        scoped_query.with_entities.return_value.order_by.return_value.limit.return_value.all.return_value = [
            SimpleNamespace(
                id=uuid.uuid4(),
                review_run_id=uuid.uuid4(),
                assistant_guid=derived_guid,
                repository_full_name="org/repo",
                pull_request_number=42,
            )
        ]
        with patch(
            "api.routes.github._apply_pack_metrics_filters",
            side_effect=[(typed_query, {}), (scoped_query, {})],
        ):
            scope = _resolve_assistant_scope_for_lineage(
                project_guid="proj",
                since=None,
                assistant_guid=None,
                assistant_type="SRE_SPECIALIST",
                repository_full_name="org/repo",
                pull_request_number=42,
                review_mode=None,
                risk_level=None,
            )
        self.assertEqual(scope["matched_by"], "assistant_type_latest")
        self.assertEqual(scope["resolved_assistant_guid"], str(derived_guid))
        self.assertEqual(scope["scope_pack_count"], 1)

    def test_artifact_deployment_metrics_payload_has_stable_contract(self):
        record = SimpleNamespace(
            artifact_digest="sha256:abc",
            artifact_uri="registry/repo@sha256:abc",
            artifact_created_at=None,
            created_on=None,
            deployed_at=None,
            observed_at=None,
            deployment_verified=True,
            verification_status="verified",
            deployment_id="dep-1",
            deployment_environment="prod",
            environment="prod",
            deployment_provider="github",
            provider="github",
            deployment_ref_url="https://example/deploy/dep-1",
            service_ref="svc-a",
            workload_ref="deploy/svc-a",
            artifact_registry_provider="ecr",
            artifact_repository="repo",
            artifact_tag="latest",
            artifact_registry_url="123456.dkr.ecr.us-east-1.amazonaws.com/repo",
            cloud_account_or_project="123456",
            region="us-east-1",
            cluster_or_platform="ecs-cluster",
            review_run_id=None,
            evidence_pack_id=None,
        )
        payload = _build_artifact_deployment_metrics_payload(
            project_guid="proj",
            records=[record],
            assistant_guid=None,
            repository_full_name="org/repo",
            pull_request_number=1,
        )
        self.assertIn("totals", payload)
        self.assertIn("timeline", payload)
        self.assertIn("resolver_trace", payload)
        self.assertEqual(payload["totals"]["deployments_verified"], 1)
        self.assertEqual(len(payload["timeline"]), 1)
    def test_effective_policy_verdict_prefers_fail_from_policy_checks(self):
        verdict, reason, checks, summary = _evaluate_effective_policy(
            verification_status="verified",
            verification_details={
                "signature_valid": True,
                "identity_valid": True,
                "provenance_valid": True,
                "sbom_valid": True,
            },
            payload={
                "metadata_json": {
                    "policy_checks": [
                        {
                            "id": "critical_policy",
                            "name": "Critical policy",
                            "status": "fail",
                            "reason": "Denied by policy",
                        }
                    ]
                }
            },
        )
        self.assertEqual(verdict, "fail")
        self.assertIn("failed", reason.lower())
        self.assertTrue(any(check.get("policy_key") == "critical_policy" for check in checks))
        self.assertGreaterEqual(summary["counts"]["fail"], 1)

    def test_metrics_window_defaults(self):
        with self.app.test_request_context("/metrics"):
            bucket, since = _get_metrics_window()
            self.assertEqual(bucket, "day")
            self.assertIsNotNone(since)

    def test_metrics_window_respects_bounds(self):
        with self.app.test_request_context("/metrics?bucket=hour&lookback_days=9999"):
            bucket, since = _get_metrics_window()
            self.assertEqual(bucket, "hour")
            self.assertIsNotNone(since)

    def test_review_mode_inference_for_swe_workflows(self):
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Open PR review"),
            "OPEN_PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Maintainability and Design"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Test and quality analysis"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Tests & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Test & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability & Design Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability Design Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Perf & Cost Review Function"),
            "PERFORMANCE_AND_COST",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Perf Cost Review Function"),
            "PERFORMANCE_AND_COST",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Test & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Security Review Deep Dive Function"),
            "SECURITY_DEEP_DIVE",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Security Deep Dive Function"),
            "SECURITY_DEEP_DIVE",
        )

    def test_review_mode_inference_for_sre_workflow(self):
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Master PR Review"),
            "PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Master PR Review Function"),
            "PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Master Review Function"),
            "PR_REVIEW",
        )

    def test_review_mode_inference_unknown(self):
        self.assertIsNone(_infer_review_mode_from_workflow_name("Daily Infra Summary"))

    def test_workflow_ids_for_mode_supports_string_and_list(self):
        class _Binding:
            mode_workflow_map = {
                "PR_REVIEW": "wf-1",
                "OPEN_PR_REVIEW": ["wf-a", "wf-b"],
            }

        self.assertEqual(_workflow_ids_for_mode(_Binding(), "PR_REVIEW"), ["wf-1"])
        self.assertEqual(_workflow_ids_for_mode(_Binding(), "OPEN_PR_REVIEW"), ["wf-a", "wf-b"])
        self.assertEqual(_workflow_ids_for_mode(_Binding(), "UNKNOWN"), [])

    def test_resolve_review_modes_for_event_full_review_includes_mode_map(self):
        class _Binding:
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {
                "PR_REVIEW": "wf-master",
                "SECURITY_DEEP_DIVE": "wf-security",
                "__workflow_allowlist__": ["wf-master", "wf-security"],
            }

        self.assertEqual(
            _resolve_review_modes_for_event(_Binding(), "full_review"),
            ["PR_REVIEW", "SECURITY_DEEP_DIVE"],
        )
        self.assertEqual(
            _resolve_review_modes_for_event(_Binding(), "review"),
            ["PR_REVIEW"],
        )

    def test_is_pr_paused_returns_true_when_state_exists(self):
        paused_state = SimpleNamespace(is_paused=True)
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = paused_state

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            self.assertTrue(
                _is_pr_paused(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=123,
                    assistant_guid="assistant",
                    review_mode="PR_REVIEW",
                )
            )

    def test_upsert_pr_pause_state_updates_existing_row(self):
        existing = SimpleNamespace(
            is_paused=False,
            source_command="pause",
            updated_by="old",
        )
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = existing

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            with patch("api.routes.github.db.session.add") as mocked_add:
                state = _upsert_pr_pause_state(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=123,
                    assistant_guid="assistant",
                    review_mode="PR_REVIEW",
                    is_paused=True,
                    source_command="resume",
                    updated_by="tester",
                )

        self.assertIs(state, existing)
        self.assertTrue(existing.is_paused)
        self.assertEqual(existing.source_command, "resume")
        self.assertEqual(existing.updated_by, "tester")
        mocked_add.assert_not_called()

    def test_upsert_pr_pause_state_creates_new_row_when_missing(self):
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = None

        created_rows = []

        def _capture_new_row(row):
            created_rows.append(row)

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            with patch("api.routes.github.db.session.add", side_effect=_capture_new_row):
                state = _upsert_pr_pause_state(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=99,
                    assistant_guid="assistant",
                    review_mode="SECURITY_DEEP_DIVE",
                    is_paused=True,
                    source_command="pause",
                    updated_by="tester",
                )

        self.assertEqual(len(created_rows), 1)
        self.assertIs(state, created_rows[0])
        self.assertTrue(state.is_paused)
        self.assertEqual(state.source_command, "pause")
        self.assertEqual(state.updated_by, "tester")

    def test_build_mode_workflow_map_for_specialist_honors_allowed_workflow_ids(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            mode_map = _build_mode_workflow_map_for_specialist(
                specialist_guid="specialist-1",
                allowed_workflow_ids={"wf-security"},
            )

        self.assertEqual(mode_map, {"SECURITY_DEEP_DIVE": "wf-security"})

    def test_build_mode_workflow_map_for_specialist_returns_empty_when_allowlist_has_no_matches(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master]

        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            mode_map = _build_mode_workflow_map_for_specialist(
                specialist_guid="specialist-1",
                allowed_workflow_ids={"wf-other"},
            )

        self.assertEqual(mode_map, {})

    def test_refresh_binding_mode_map_preserves_existing_workflow_allowlist(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        class _Binding:
            assistant_guid = "specialist-1"
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {"PR_REVIEW": "wf-master"}

        binding = _Binding()
        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            changed = _refresh_binding_mode_map(binding)

        self.assertFalse(changed)
        self.assertEqual(binding.mode_workflow_map, {"PR_REVIEW": "wf-master"})
        self.assertEqual(binding.enabled_review_modes, ["PR_REVIEW"])

    def test_refresh_binding_mode_map_ignores_legacy_mapping_subset_without_allowlist(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        class _Binding:
            assistant_guid = "specialist-1"
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {"PR_REVIEW": "wf-master"}

        binding = _Binding()
        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            changed = _refresh_binding_mode_map(binding)

        self.assertTrue(changed)
        self.assertEqual(
            binding.mode_workflow_map,
            {"PR_REVIEW": "wf-master", "SECURITY_DEEP_DIVE": "wf-security"},
        )

    @staticmethod
    def _request_proxy():
        from flask import request

        return request


if __name__ == "__main__":
    unittest.main()
