# specfence

Detects code your tests don't demand. Replaces each statement with `pass` and runs your tests — if they still pass, that line is outside the fence.

## Installation

```bash
uv tool install specfence
```

## Usage

```bash
specfence <file> <test_file>
```

Run from the directory where your imports resolve (i.e. the project root):

```bash
cd my_project
specfence app.py test_app.py
```

## Example

The `example/` directory contains a sample module and test file:

```bash
cd example
specfence app.py test_app.py
```

Output:

```
EXCESS  app.py:7   logger.info("Processing order %s", order_id)
EXCESS  app.py:8   print(f"Starting order {order_id}")
EXCESS  app.py:17   logger.debug("Order %s total: %s", order_id, grand_total)
EXCESS  app.py:18   print(f"Order complete: ${grand_total:.2f}")

4 fence violations — delete these lines, they do not change any observed behavior
```

These lines can be deleted without breaking any test.
