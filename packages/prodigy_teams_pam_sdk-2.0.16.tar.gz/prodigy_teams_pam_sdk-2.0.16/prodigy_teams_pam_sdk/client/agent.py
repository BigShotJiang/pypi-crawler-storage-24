from ..models import (
    AgentCreating,
    AgentDeleting,
    AgentDetail,
    AgentReading,
    AgentSummary,
    AgentUpdating,
)
from .base import ModelClient


class Agent(
    ModelClient[
        AgentCreating,
        AgentReading,
        AgentUpdating,
        AgentDeleting,
        AgentSummary,
        AgentDetail,
    ]
):
    Creating = AgentCreating
    Reading = AgentReading
    Updating = AgentUpdating
    Deleting = AgentDeleting
    Summary = AgentSummary
    Detail = AgentDetail
