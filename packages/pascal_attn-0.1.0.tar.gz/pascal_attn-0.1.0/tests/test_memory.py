"""
Peak VRAM tests for pascal_attn.

Verifies that tiled_attention allocates less peak memory than a naive
full-matrix attention implementation.  Only executed when CUDA is available.

Run with:
    pytest tests/test_memory.py -v
"""

import pytest
import torch
import torch.nn.functional as F

from pascal_attn import tiled_attention, recommended_tile_size


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _measure_peak_bytes(fn, *args, **kwargs) -> int:
    """
    Measure peak CUDA memory allocated (in bytes) during fn(*args, **kwargs).

    Resets the peak stats before the call and reads them after.
    """
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    fn(*args, **kwargs)
    torch.cuda.synchronize()
    return torch.cuda.max_memory_allocated()


def _naive_attention(
    query: torch.Tensor,   # [B, n_h, N_q, d_h]
    key: torch.Tensor,     # [B, n_h, N_k, d_h]   (already expanded)
    value: torch.Tensor,   # [B, n_h, N_k, d_h]
    scale: float,
) -> torch.Tensor:
    """Naive O(N²) attention — materialises full [B, n_h, N_q, N_k] matrix."""
    scores = torch.matmul(query, key.transpose(2, 3)) * scale
    attn = torch.softmax(scores, dim=-1)
    return torch.matmul(attn, value).transpose(1, 2).contiguous()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
class TestPeakVRAM:

    def _setup(self, B=1, n_h=32, n_kv=None, N=2048, d_h=64):
        if n_kv is None:
            n_kv = n_h
        q = torch.randn(B, n_h, N, d_h, device="cuda")
        k = torch.randn(B, n_kv, N, d_h, device="cuda")
        v = torch.randn(B, n_kv, N, d_h, device="cuda")
        return q, k, v

    def test_tiled_uses_less_peak_memory_than_naive_mha(self):
        """Tiled attention should peak significantly less than naive."""
        B, n_h, N, d_h = 1, 16, 1024, 64
        q, k, v = self._setup(B=B, n_h=n_h, n_kv=n_h, N=N, d_h=d_h)
        scale = d_h ** -0.5
        tile = recommended_tile_size()

        # Baseline: tiled peak
        tiled_peak = _measure_peak_bytes(
            tiled_attention, q, k, v, scale=scale, tile_size=tile
        )

        # Naive: expand KV for MHA then matmul
        def _naive_wrap():
            _naive_attention(q, k, v, scale)

        naive_peak = _measure_peak_bytes(_naive_wrap)

        # Tiled should use strictly less than naive
        assert tiled_peak < naive_peak, (
            f"Expected tiled ({tiled_peak/1e6:.1f} MB) < naive ({naive_peak/1e6:.1f} MB)"
        )

    def test_tiled_peak_scales_with_tile_not_seqlen(self):
        """
        As N grows, peak VRAM for tiled attention should grow sub-quadratically
        relative to the naive O(N²) approach.

        Concretely: at tile=64, peak KV allocation for one tile is
        B × n_h × tile × d_h × 4 bytes, which is constant w.r.t. N.
        The scores buffer is B × n_h × tile × tile × 4 bytes — also constant.

        So total peak should be ~linear in N (output buffer grows), not N².
        """
        B, n_h, d_h = 1, 8, 32
        tile = 64
        scale = d_h ** -0.5

        N_small = 256
        N_large = 1024   # 4× larger

        q_s = torch.randn(B, n_h, N_small, d_h, device="cuda")
        k_s = torch.randn(B, n_h, N_small, d_h, device="cuda")
        v_s = torch.randn(B, n_h, N_small, d_h, device="cuda")

        q_l = torch.randn(B, n_h, N_large, d_h, device="cuda")
        k_l = torch.randn(B, n_h, N_large, d_h, device="cuda")
        v_l = torch.randn(B, n_h, N_large, d_h, device="cuda")

        peak_small = _measure_peak_bytes(
            tiled_attention, q_s, k_s, v_s, scale=scale, tile_size=tile
        )
        peak_large = _measure_peak_bytes(
            tiled_attention, q_l, k_l, v_l, scale=scale, tile_size=tile
        )

        ratio = peak_large / peak_small
        # If scaling were O(N²) the ratio would be 16×.
        # For tiled it should be at most ~6× (generous bound) due to ~linear growth.
        assert ratio < 6, (
            f"Peak VRAM ratio {ratio:.2f}× is too high — suggests O(N²) scaling. "
            f"small={peak_small/1e6:.1f} MB, large={peak_large/1e6:.1f} MB"
        )

    def test_tiled_gqa_peak_less_than_expanded_naive(self):
        """
        GQA + tiled: peak should be well below expanding the full KV upfront.

        The fused KV expansion means we never materialise [B, n_h, N, d_h]
        for key/value — only [B, n_h, tile, d_h] per inner-loop step.
        """
        B, n_h, n_kv, N, d_h = 1, 32, 4, 1024, 64
        q, k, v = self._setup(B=B, n_h=n_h, n_kv=n_kv, N=N, d_h=d_h)
        scale = d_h ** -0.5
        tile = 64

        # Tiled peak (fused expansion)
        tiled_peak = _measure_peak_bytes(
            tiled_attention, q, k, v, scale=scale, tile_size=tile
        )

        # Naive peak: expand KV upfront, then naive attention
        def _expanded_naive():
            n_groups = n_h // n_kv
            k_exp = (
                k[:, :, None, :, :]
                .expand(B, n_kv, n_groups, N, d_h)
                .reshape(B, n_h, N, d_h)
            )
            v_exp = (
                v[:, :, None, :, :]
                .expand(B, n_kv, n_groups, N, d_h)
                .reshape(B, n_h, N, d_h)
            )
            _naive_attention(q, k_exp, v_exp, scale)

        naive_peak = _measure_peak_bytes(_expanded_naive)

        assert tiled_peak < naive_peak, (
            f"Expected tiled GQA ({tiled_peak/1e6:.1f} MB) "
            f"< expanded naive ({naive_peak/1e6:.1f} MB)"
        )

    def test_no_oom_at_large_seqlen(self):
        """tiled_attention should complete without OOM at N=4096."""
        B, n_h, N, d_h = 1, 8, 4096, 64
        q = torch.randn(B, n_h, N, d_h, device="cuda")
        k = torch.randn(B, n_h, N, d_h, device="cuda")
        v = torch.randn(B, n_h, N, d_h, device="cuda")
        tile = recommended_tile_size()
        out = tiled_attention(q, k, v, tile_size=tile)
        assert out.shape == (B, N, n_h, d_h)
