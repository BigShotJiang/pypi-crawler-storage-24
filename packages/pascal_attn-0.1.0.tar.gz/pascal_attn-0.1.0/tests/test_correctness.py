"""
Correctness tests for pascal_attn.

Compares tiled_attention against torch.nn.functional.scaled_dot_product_attention
(the reference implementation) across a range of configurations.

Run with:
    pytest tests/test_correctness.py -v
"""

import math
import pytest
import torch
import torch.nn.functional as F

from pascal_attn import tiled_attention, TiledAttention, recommended_tile_size
from pascal_attn._core import tiled_attention as core_tiled_attention


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ref_attention(
    query: torch.Tensor,   # [B, n_h, N_q, d_h]
    key: torch.Tensor,     # [B, n_kv, N_k, d_h]
    value: torch.Tensor,   # [B, n_kv, N_k, d_h]
    scale: float,
    mask=None,
) -> torch.Tensor:         # [B, N_q, n_h, d_h]
    """Reference attention using vanilla PyTorch (no SDPA) — GQA aware."""
    n_h = query.shape[1]
    n_kv = key.shape[1]
    n_groups = n_h // n_kv
    if n_groups > 1:
        B, _, N_k, d_h = key.shape
        key = (
            key[:, :, None, :, :]
            .expand(B, n_kv, n_groups, N_k, d_h)
            .reshape(B, n_h, N_k, d_h)
        )
        value = (
            value[:, :, None, :, :]
            .expand(B, n_kv, n_groups, N_k, d_h)
            .reshape(B, n_h, N_k, d_h)
        )
    scores = torch.matmul(query.float(), key.float().transpose(2, 3)) * scale
    if mask is not None:
        scores = scores + mask.float()
    attn = torch.softmax(scores, dim=-1).to(query.dtype)
    out = torch.matmul(attn, value.float()).to(query.dtype)  # [B, n_h, N_q, d_h]
    return out.transpose(1, 2).contiguous()                   # [B, N_q, n_h, d_h]


def _make_inputs(B, n_h, n_kv, N_q, N_k, d_h, dtype=torch.float32, seed=42):
    torch.manual_seed(seed)
    q = torch.randn(B, n_h, N_q, d_h, dtype=dtype)
    k = torch.randn(B, n_kv, N_k, d_h, dtype=dtype)
    v = torch.randn(B, n_kv, N_k, d_h, dtype=dtype)
    return q, k, v


# ---------------------------------------------------------------------------
# Basic shape and value correctness
# ---------------------------------------------------------------------------

class TestOutputShape:
    def test_mha_shape(self):
        q, k, v = _make_inputs(2, 4, 4, 16, 16, 8)
        out = tiled_attention(q, k, v, tile_size=8)
        assert out.shape == (2, 16, 4, 8), f"Expected (2,16,4,8), got {out.shape}"

    def test_gqa_shape(self):
        # n_h=8, n_kv=2 → groups=4
        q, k, v = _make_inputs(2, 8, 2, 16, 16, 8)
        out = tiled_attention(q, k, v, tile_size=8)
        assert out.shape == (2, 16, 8, 8)

    def test_cross_attention_shape(self):
        """N_q != N_k (cross-attention / KV cache scenario)."""
        q, k, v = _make_inputs(1, 4, 4, 5, 20, 8)
        out = tiled_attention(q, k, v, tile_size=8)
        assert out.shape == (1, 5, 4, 8)

    def test_output_dtype_preserved_fp32(self):
        q, k, v = _make_inputs(1, 4, 4, 8, 8, 8, dtype=torch.float32)
        out = tiled_attention(q, k, v, tile_size=4)
        assert out.dtype == torch.float32

    def test_output_dtype_preserved_fp16(self):
        if not torch.cuda.is_available():
            pytest.skip("fp16 test requires CUDA")
        q, k, v = _make_inputs(1, 4, 4, 8, 8, 8, dtype=torch.float16)
        q, k, v = q.cuda(), k.cuda(), v.cuda()
        out = tiled_attention(q, k, v, tile_size=4)
        assert out.dtype == torch.float16


class TestCorrectnessVsReference:
    """Compare tiled_attention against plain matmul-softmax reference."""

    def _check(self, B, n_h, n_kv, N_q, N_k, d_h, tile_size, atol, mask=None):
        q, k, v = _make_inputs(B, n_h, n_kv, N_q, N_k, d_h)
        scale = d_h ** -0.5
        ref = _ref_attention(q, k, v, scale, mask)
        got = tiled_attention(q, k, v, scale=scale, mask=mask, tile_size=tile_size)
        torch.testing.assert_close(got, ref, atol=atol, rtol=0)

    def test_mha_basic(self):
        self._check(2, 4, 4, 16, 16, 8, tile_size=8, atol=1e-5)

    def test_mha_tile_smaller_than_seqlen(self):
        self._check(1, 4, 4, 32, 32, 8, tile_size=4, atol=1e-5)

    def test_mha_tile_larger_than_seqlen(self):
        """When tile >= N the loop runs once — should still be correct."""
        self._check(1, 4, 4, 8, 8, 8, tile_size=64, atol=1e-5)

    def test_gqa_4groups(self):
        self._check(2, 8, 2, 16, 16, 8, tile_size=8, atol=1e-5)

    def test_gqa_8groups(self):
        self._check(2, 16, 2, 16, 16, 8, tile_size=8, atol=1e-5)

    def test_cross_attention(self):
        self._check(1, 4, 4, 6, 20, 8, tile_size=4, atol=1e-5)

    def test_single_query(self):
        """N_q=1 — decoding step."""
        self._check(2, 4, 4, 1, 64, 8, tile_size=16, atol=1e-5)

    def test_default_scale(self):
        """Omit scale — should default to 1/sqrt(d_h)."""
        d_h = 16
        q, k, v = _make_inputs(1, 4, 4, 8, 8, d_h)
        scale = d_h ** -0.5
        ref = _ref_attention(q, k, v, scale)
        got = tiled_attention(q, k, v, tile_size=4)  # scale=None → auto
        torch.testing.assert_close(got, ref, atol=1e-5, rtol=0)


class TestCausalMask:
    def _make_causal_mask(self, N, dtype=torch.float32):
        """Standard additive causal mask — upper triangle = -1e9."""
        mask = torch.zeros(1, 1, N, N, dtype=dtype)
        mask = mask.masked_fill(torch.ones(N, N).triu(1).bool(), -1e9)
        return mask

    def test_causal_mha(self):
        N = 16
        q, k, v = _make_inputs(2, 4, 4, N, N, 8)
        mask = self._make_causal_mask(N)
        scale = 8 ** -0.5
        ref = _ref_attention(q, k, v, scale, mask)
        got = tiled_attention(q, k, v, scale=scale, mask=mask, tile_size=8)
        torch.testing.assert_close(got, ref, atol=1e-5, rtol=0)

    def test_causal_gqa(self):
        N = 24
        q, k, v = _make_inputs(1, 8, 2, N, N, 8)
        mask = self._make_causal_mask(N)
        scale = 8 ** -0.5
        ref = _ref_attention(q, k, v, scale, mask)
        got = tiled_attention(q, k, v, scale=scale, mask=mask, tile_size=8)
        torch.testing.assert_close(got, ref, atol=1e-5, rtol=0)

    def test_causal_respects_future_masking(self):
        """Each token's output must be independent of future tokens."""
        N = 8
        q, k, v = _make_inputs(1, 2, 2, N, N, 4)
        mask = self._make_causal_mask(N)
        out1 = tiled_attention(q, k, v, mask=mask, tile_size=4)

        # Perturb future tokens for position 0 (tokens 1..N-1)
        v_perturbed = v.clone()
        v_perturbed[:, :, 1:, :] = v_perturbed[:, :, 1:, :] * 2 + 1
        out2 = tiled_attention(q, k, v_perturbed, mask=mask, tile_size=4)

        # Position 0 must be identical; future positions may differ
        torch.testing.assert_close(out1[:, 0, :, :], out2[:, 0, :, :], atol=1e-5, rtol=0)


class TestAllMaskedRows:
    """Fully-masked rows must NOT produce NaN (the -1e9 init guards this)."""

    def test_all_masked_no_nan(self):
        N = 8
        q, k, v = _make_inputs(1, 2, 2, N, N, 4)
        # Mask everything
        mask = torch.full((1, 1, N, N), -1e9)
        out = tiled_attention(q, k, v, mask=mask, tile_size=4)
        assert not torch.isnan(out).any(), "NaN detected with all-masked input"

    def test_partial_masked_no_nan(self):
        """Mask the last half of KV positions."""
        N = 8
        q, k, v = _make_inputs(1, 2, 2, N, N, 4)
        mask = torch.zeros(1, 1, N, N)
        mask[:, :, :, N // 2 :] = -1e9
        out = tiled_attention(q, k, v, mask=mask, tile_size=4)
        assert not torch.isnan(out).any()


# ---------------------------------------------------------------------------
# GQA validation
# ---------------------------------------------------------------------------

class TestGQAConstraints:
    def test_invalid_gqa_raises(self):
        q = torch.randn(1, 6, 8, 4)
        k = torch.randn(1, 4, 8, 4)   # 6 % 4 != 0
        v = torch.randn(1, 4, 8, 4)
        with pytest.raises(ValueError, match="divisible"):
            tiled_attention(q, k, v, tile_size=4)

    def test_mha_is_gqa_with_groups_1(self):
        """MHA == GQA with n_kv == n_h."""
        q, k, v = _make_inputs(1, 4, 4, 8, 8, 8)
        out = tiled_attention(q, k, v, tile_size=4)
        assert out.shape == (1, 8, 4, 8)


# ---------------------------------------------------------------------------
# nn.Module API
# ---------------------------------------------------------------------------

class TestTiledAttentionModule:
    def test_packed_input_shape(self):
        n_h, n_kv, d_h = 4, 2, 8
        attn = TiledAttention(n_heads=n_h, n_kv_heads=n_kv, head_dim=d_h, tile_size=4)
        B, N = 2, 16
        q = torch.randn(B, N, n_h * d_h)
        k = torch.randn(B, N, n_kv * d_h)
        v = torch.randn(B, N, n_kv * d_h)
        out = attn(q, k, v)
        assert out.shape == (B, N, n_h * d_h)

    def test_unpacked_input_shape(self):
        n_h, n_kv, d_h = 4, 2, 8
        attn = TiledAttention(n_heads=n_h, n_kv_heads=n_kv, head_dim=d_h, tile_size=4)
        B, N = 2, 16
        q = torch.randn(B, N, n_h, d_h)
        k = torch.randn(B, N, n_kv, d_h)
        v = torch.randn(B, N, n_kv, d_h)
        out = attn(q, k, v)
        assert out.shape == (B, N, n_h, d_h)

    def test_module_output_matches_functional(self):
        n_h, n_kv, d_h = 4, 2, 8
        tile = 4
        B, N = 1, 16
        torch.manual_seed(7)
        q_raw = torch.randn(B, N, n_h * d_h)
        k_raw = torch.randn(B, N, n_kv * d_h)
        v_raw = torch.randn(B, N, n_kv * d_h)

        # Module output
        attn = TiledAttention(n_heads=n_h, n_kv_heads=n_kv, head_dim=d_h, tile_size=tile)
        mod_out = attn(q_raw, k_raw, v_raw)   # [B, N, n_h*d_h]

        # Functional output
        q = q_raw.view(B, N, n_h, d_h).transpose(1, 2)   # [B, n_h, N, d_h]
        k = k_raw.view(B, N, n_kv, d_h).transpose(1, 2)
        v = v_raw.view(B, N, n_kv, d_h).transpose(1, 2)
        fn_out = tiled_attention(q, k, v, tile_size=tile)  # [B, N, n_h, d_h]
        fn_out = fn_out.reshape(B, N, n_h * d_h)

        torch.testing.assert_close(mod_out, fn_out, atol=1e-6, rtol=0)

    def test_mha_default_n_kv(self):
        attn = TiledAttention(n_heads=4, head_dim=8, tile_size=4)
        assert attn.n_kv_heads == 4

    def test_invalid_heads_raises(self):
        with pytest.raises(ValueError, match="divisible"):
            TiledAttention(n_heads=6, n_kv_heads=4)

    def test_auto_tile_size(self):
        attn = TiledAttention(n_heads=4, n_kv_heads=2, head_dim=8, tile_size="auto")
        q = torch.randn(1, 8, 4 * 8)
        k = torch.randn(1, 8, 2 * 8)
        v = torch.randn(1, 8, 2 * 8)
        out = attn(q, k, v)
        assert out.shape == (1, 8, 4 * 8)


# ---------------------------------------------------------------------------
# GPU detection
# ---------------------------------------------------------------------------

class TestRecommendedTileSize:
    def test_returns_int(self):
        result = recommended_tile_size()
        assert isinstance(result, int)

    def test_sensible_value(self):
        result = recommended_tile_size()
        assert result in (64, 128, 256), f"Unexpected tile size: {result}"

    def test_cpu_fallback(self):
        """On CPU (or when CUDA is unavailable) should return 256."""
        import unittest.mock as mock
        with mock.patch("torch.cuda.is_available", return_value=False):
            from pascal_attn._gpu import recommended_tile_size as _rts
            assert _rts() == 256
