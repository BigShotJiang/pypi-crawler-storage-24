"""
Benchmark: tiled_attention vs torch.nn.functional.scaled_dot_product_attention.

Measures wall-clock time and peak VRAM across multiple sequence lengths.

Usage:
    python benchmarks/benchmark.py [--device cuda] [--dtype fp16] [--tile 64]
                                   [--batch 4] [--heads 32] [--kv-heads 8]
                                   [--head-dim 64]
"""

import argparse
import math
import time
from typing import List, Tuple

import torch
import torch.nn.functional as F

try:
    from pascal_attn import tiled_attention, recommended_tile_size
except ImportError:
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from pascal_attn import tiled_attention, recommended_tile_size


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _reset_peak():
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()


def _peak_mb() -> float:
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        return torch.cuda.max_memory_allocated() / 1e6
    return 0.0


def _time_fn(fn, warmup=3, runs=10) -> float:
    """Return median wall-clock time in milliseconds."""
    # Warmup
    for _ in range(warmup):
        fn()
    if torch.cuda.is_available():
        torch.cuda.synchronize()

    times = []
    for _ in range(runs):
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        fn()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        times.append((time.perf_counter() - t0) * 1000)

    times.sort()
    return times[len(times) // 2]


def _expand_kv_full(k, v, n_groups):
    """Expand KV upfront for SDPA reference (GQA)."""
    if n_groups == 1:
        return k, v
    B, n_kv, N, d = k.shape
    n_h = n_kv * n_groups
    k = k[:, :, None, :, :].expand(B, n_kv, n_groups, N, d).reshape(B, n_h, N, d)
    v = v[:, :, None, :, :].expand(B, n_kv, n_groups, N, d).reshape(B, n_h, N, d)
    return k, v


# ---------------------------------------------------------------------------
# Benchmark runner
# ---------------------------------------------------------------------------

def run_benchmark(
    seq_lens: List[int],
    B: int = 4,
    n_h: int = 32,
    n_kv: int = 8,
    d_h: int = 64,
    tile_size: int = 64,
    device: str = "cuda",
    dtype: torch.dtype = torch.float16,
):
    dev = torch.device(device)
    n_groups = n_h // n_kv

    header = (
        f"\n{'='*72}\n"
        f"  pascal-attn benchmark\n"
        f"  B={B}, n_h={n_h}, n_kv={n_kv}, d_h={d_h}, tile={tile_size}\n"
        f"  device={device}, dtype={dtype}\n"
        f"{'='*72}\n"
        f"{'N':>6}  {'Method':<22} {'Time (ms)':>10} {'Peak VRAM (MB)':>15}\n"
        f"{'-'*58}"
    )
    print(header)

    for N in seq_lens:
        torch.manual_seed(0)
        q = torch.randn(B, n_h, N, d_h, device=dev, dtype=dtype)
        k = torch.randn(B, n_kv, N, d_h, device=dev, dtype=dtype)
        v = torch.randn(B, n_kv, N, d_h, device=dev, dtype=dtype)
        scale = d_h ** -0.5

        # --- tiled_attention ---
        _reset_peak()
        t_tiled = _time_fn(
            lambda: tiled_attention(q, k, v, scale=scale, tile_size=tile_size)
        )
        vram_tiled = _peak_mb()

        print(f"{N:>6}  {'tiled_attention':<22} {t_tiled:>10.2f} {vram_tiled:>15.1f}")

        # --- SDPA (reference) ---
        # SDPA expects [B, n_h, N, d_h] with expanded KV
        k_exp, v_exp = _expand_kv_full(k, v, n_groups)

        _reset_peak()
        t_sdpa = _time_fn(
            lambda: F.scaled_dot_product_attention(q, k_exp, v_exp, scale=scale)
        )
        vram_sdpa = _peak_mb()

        print(f"{N:>6}  {'SDPA (expanded KV)':<22} {t_sdpa:>10.2f} {vram_sdpa:>15.1f}")

        speedup = t_sdpa / t_tiled if t_tiled > 0 else float("nan")
        vram_ratio = vram_sdpa / vram_tiled if vram_tiled > 0 else float("nan")
        print(
            f"{N:>6}  {'  → speedup':<22} {speedup:>10.2f}x {vram_ratio:>14.1f}x\n"
            f"{'-'*58}"
        )

    print()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="pascal-attn benchmark")
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    parser.add_argument("--dtype", default="fp16", choices=["fp16", "fp32", "bf16"])
    parser.add_argument("--tile", type=int, default=None,
                        help="Tile size (default: auto-detect from GPU)")
    parser.add_argument("--batch", type=int, default=4)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--kv-heads", type=int, default=8)
    parser.add_argument("--head-dim", type=int, default=64)
    parser.add_argument("--seq-lens", type=int, nargs="+",
                        default=[512, 1024, 2048, 4096])
    args = parser.parse_args()

    if args.device == "cuda" and not torch.cuda.is_available():
        print("CUDA not available — switching to CPU")
        args.device = "cpu"
        args.dtype = "fp32"

    dtype_map = {
        "fp16": torch.float16,
        "fp32": torch.float32,
        "bf16": torch.bfloat16,
    }
    dtype = dtype_map[args.dtype]

    if args.tile is None:
        if args.device == "cuda":
            args.tile = recommended_tile_size()
        else:
            args.tile = 256
        print(f"Auto tile size: {args.tile}")

    if args.device == "cuda":
        props = torch.cuda.get_device_properties(0)
        print(f"GPU: {props.name}")
        print(f"L2 cache: {props.l2_cache_size / 1e6:.1f} MB")
        print(f"VRAM: {props.total_memory / 1e9:.1f} GB")

    run_benchmark(
        seq_lens=args.seq_lens,
        B=args.batch,
        n_h=args.heads,
        n_kv=args.kv_heads,
        d_h=args.head_dim,
        tile_size=args.tile,
        device=args.device,
        dtype=dtype,
    )


if __name__ == "__main__":
    main()
