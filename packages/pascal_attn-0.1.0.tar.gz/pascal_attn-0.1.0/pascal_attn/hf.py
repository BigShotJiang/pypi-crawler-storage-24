"""
Optional HuggingFace Transformers integration.

Provides helpers to create attention functions compatible with the
``ALL_ATTENTION_FUNCTIONS`` dispatch table used by Transformers >= 4.36,
and to register ``tiled_attention`` under a custom name so it can be
activated via ``config._attn_implementation = "pascal_chunked"``.

This module is only imported when ``transformers`` is available; the rest
of ``pascal_attn`` has no dependency on it.

Example::

    # One-time setup (call before loading the model)
    from pascal_attn.hf import register_with_transformers
    register_with_transformers(tile_size=64, name="pascal_chunked")

    # Then in your config:
    config._attn_implementation = "pascal_chunked"

Or use the function directly in a custom layer::

    from pascal_attn.hf import make_hf_attention_fn
    my_fn = make_hf_attention_fn(tile_size=128)
    # Assign to a LlamaAttention instance:
    layer.self_attn._attention_forward_fn = my_fn
"""

from typing import Optional

import torch

from ._core import tiled_attention


def make_hf_attention_fn(tile_size: int = 64):
    """
    Create an attention function matching the HuggingFace ``ALL_ATTENTION_FUNCTIONS``
    calling convention.

    The returned function signature is::

        fn(module, query, key, value, attention_mask, scaling, dropout=0.0, **kwargs)
            -> (attn_output [B, N_q, n_h, d_h], attn_weights: None)

    When ``kwargs['output_attentions'] is True``, the function falls back to
    the HuggingFace ``eager`` implementation because tiled attention cannot
    materialise a full ``[B, n_h, N, N]`` weight matrix.

    Args:
        tile_size: Tile side length (see :func:`pascal_attn._gpu.recommended_tile_size`).

    Returns:
        A callable suitable for insertion into ``ALL_ATTENTION_FUNCTIONS``.
    """

    def pascal_attention_forward(
        module,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor],
        scaling: float,
        dropout: float = 0.0,
        **kwargs,
    ):
        # Tiled attention cannot return a materialised weight matrix, so we
        # fall back to the eager implementation when the caller needs it.
        if kwargs.get("output_attentions", False):
            try:
                from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS
                eager_fn = ALL_ATTENTION_FUNCTIONS.get("eager")
                if eager_fn is not None:
                    return eager_fn(
                        module, query, key, value, attention_mask, scaling,
                        dropout=dropout, **kwargs
                    )
            except Exception:
                pass
            # Last-resort eager fallback using vanilla PyTorch
            return _eager_fallback(
                module, query, key, value, attention_mask, scaling, dropout
            )

        out = tiled_attention(
            query=query,
            key=key,
            value=value,
            scale=scaling,
            mask=attention_mask,
            tile_size=tile_size,
            dropout_p=dropout,
        )
        # Return (attn_output [B, N_q, n_h, d_h], attn_weights=None)
        return out, None

    pascal_attention_forward.__name__ = f"pascal_attention_forward_tile{tile_size}"
    return pascal_attention_forward


def register_with_transformers(
    tile_size: int = 64,
    name: str = "pascal_chunked",
) -> None:
    """
    Register the tiled attention implementation in HuggingFace's global
    ``ALL_ATTENTION_FUNCTIONS`` dispatch table.

    After calling this, any model whose config has
    ``_attn_implementation = name`` (or ``attn_implementation = name``) will
    use tiled attention for all attention layers.

    Args:
        tile_size: Tile side length passed to :func:`make_hf_attention_fn`.
        name:      Key to register under (default ``"pascal_chunked"``).

    Raises:
        ImportError: If ``transformers`` is not installed.
    """
    from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS  # type: ignore

    fn = make_hf_attention_fn(tile_size=tile_size)
    ALL_ATTENTION_FUNCTIONS[name] = fn


# ---------------------------------------------------------------------------
# Internal pure-torch eager fallback (no transformers dependency)
# ---------------------------------------------------------------------------

def _eager_fallback(
    module,
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attention_mask: Optional[torch.Tensor],
    scaling: float,
    dropout: float,
):
    """
    Minimal pure-PyTorch eager attention for the output_attentions fallback.

    Returns ``(attn_output [B, N_q, n_h, d_h], attn_weights [B, n_h, N_q, N_k])``.
    """
    # GQA expansion
    n_groups = query.shape[1] // key.shape[1]
    if n_groups > 1:
        B, n_kv, N_k, d_h = key.shape
        n_h = n_kv * n_groups
        key = (
            key[:, :, None, :, :]
            .expand(B, n_kv, n_groups, N_k, d_h)
            .reshape(B, n_h, N_k, d_h)
        )
        value = (
            value[:, :, None, :, :]
            .expand(B, n_kv, n_groups, N_k, d_h)
            .reshape(B, n_h, N_k, d_h)
        )

    scores = torch.matmul(query, key.transpose(2, 3)) * scaling
    if attention_mask is not None:
        scores = scores + attention_mask
    attn_weights = torch.softmax(scores, dim=-1, dtype=torch.float32).to(query.dtype)
    if dropout > 0.0:
        attn_weights = torch.nn.functional.dropout(attn_weights, p=dropout)
    out = torch.matmul(attn_weights, value)          # [B, n_h, N_q, d_h]
    out = out.transpose(1, 2).contiguous()           # [B, N_q, n_h, d_h]
    return out, attn_weights
