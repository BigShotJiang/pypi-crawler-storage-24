"""
Functional API for tiled attention.

This module provides the clean, public-facing functional interface.
All heavy lifting is delegated to ``pascal_attn._core.tiled_attention``.

Example usage::

    from pascal_attn.functional import tiled_attention

    # MHA (n_h == n_kv)
    out = tiled_attention(q, k, v, tile_size=64)

    # GQA (n_kv < n_h, implicit from tensor shapes)
    out = tiled_attention(q, k_gqa, v_gqa, tile_size=64)

    # With causal mask
    import torch
    N = q.shape[2]
    causal = torch.full((1, 1, N, N), float('-inf')).triu(1)
    out = tiled_attention(q, k, v, mask=causal, tile_size=64)

    # Auto tile size from GPU L2 detection
    from pascal_attn import recommended_tile_size
    out = tiled_attention(q, k, v, tile_size=recommended_tile_size())
"""

from typing import Optional

import torch

from ._core import tiled_attention as _tiled_attention


def tiled_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    scale: Optional[float] = None,
    mask: Optional[torch.Tensor] = None,
    tile_size: int = 64,
    dropout_p: float = 0.0,
) -> torch.Tensor:
    """
    Memory-efficient tiled online-softmax attention with fused GQA KV expansion.

    This is the recommended entry point for direct use.

    Args:
        query:     ``[B, n_h, N_q, d_h]``
        key:       ``[B, n_kv, N_k, d_h]`` — unexpanded GQA layout.  For
                   standard MHA set ``n_kv = n_h``.
        value:     ``[B, n_kv, N_k, d_h]``
        scale:     QK scaling factor.  Defaults to ``1 / sqrt(d_h)``.
        mask:      Additive bias applied to attention logits, broadcastable
                   to ``[B, 1, N_q, N_k]``.  Use large negative values
                   (e.g. ``-1e9``) to mask positions.  ``None`` = unmasked.
        tile_size: Tile side length.  Tune to the GPU L2 cache size:

                   +--------------------------+--------+-----------+
                   | GPU family               | L2     | tile_size |
                   +==========================+========+===========+
                   | Pascal (P40, 1080 Ti)    | 3 MB   | 64        |
                   +--------------------------+--------+-----------+
                   | Volta (V100) / Turing    | 6 MB   | 128       |
                   +--------------------------+--------+-----------+
                   | Ampere (A100) / Ada      | 40 MB  | 256       |
                   +--------------------------+--------+-----------+

                   Use ``pascal_attn.recommended_tile_size()`` to detect
                   automatically.
        dropout_p: Accepted for API compatibility; not applied inside the
                   tile loop (would violate the online-softmax invariant).

    Returns:
        ``torch.Tensor`` of shape ``[B, N_q, n_h, d_h]``, same dtype as input.

    Raises:
        ValueError: If ``n_h % n_kv != 0``.
    """
    return _tiled_attention(
        query=query,
        key=key,
        value=value,
        scale=scale,
        mask=mask,
        tile_size=tile_size,
        dropout_p=dropout_p,
    )
