"""
Tiled online-softmax attention with fused GQA KV expansion.

This is the core implementation — no dependency on any external framework
beyond PyTorch itself.  All higher-level wrappers (functional.py, nn.py,
hf.py) delegate here.

Algorithm (FlashAttention-style online softmax):
    For each query tile q_i of size [B, n_h, tq, d_h]:
        m, l, o = -1e9, 0, 0         # running max, denom, weighted output
        For each KV tile (unexpanded) [B, n_kv, tk, d_h]:
            expand KV tile to [B, n_h, tk, d_h]   (fused GQA expansion)
            s     = q_i @ k_tile.T * scale         # [B, n_h, tq, tk]
            m_new = max(m, rowmax(s))
            rescale = exp(m - m_new)               # renormalise old accum
            exp_s = exp(s - m_new)
            o     = rescale * o + exp_s @ v_tile
            l     = rescale * l + rowsum(exp_s)
            m     = m_new
        output[i] = o / (l + eps)    # normalise once per query tile

Memory:
    Peak KV allocation: [B, n_h, tile, d_h] per inner-loop iteration, not
    [B, n_h, N, d_h] upfront.  At N=2048, tile=64, B=4, n_h=32, d_h=80:
      Naive:  B × n_h × N × d_h × 4 bytes = 84 MB per KV tensor
      Tiled:  B × n_h × tile × d_h × 4    =  2.6 MB   (32× reduction)
"""

from typing import Optional

import torch


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------

def _repeat_kv(t: torch.Tensor, n_rep: int) -> torch.Tensor:
    """Expand GQA KV heads from [B, n_kv, S, d] to [B, n_kv*n_rep, S, d]."""
    if n_rep == 1:
        return t
    B, n_kv, S, d = t.shape
    return (
        t[:, :, None, :, :]
        .expand(B, n_kv, n_rep, S, d)
        .reshape(B, n_kv * n_rep, S, d)
    )


# ---------------------------------------------------------------------------
# Public core function
# ---------------------------------------------------------------------------

def tiled_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    scale: Optional[float] = None,
    mask: Optional[torch.Tensor] = None,
    tile_size: int = 64,
    dropout_p: float = 0.0,
) -> torch.Tensor:
    """
    Memory-efficient tiled online-softmax attention with fused GQA KV expansion.

    Args:
        query:     ``[B, n_h, N_q, d_h]``  — query tensor.
        key:       ``[B, n_kv, N_k, d_h]`` — key tensor, *unexpanded* for GQA.
        value:     ``[B, n_kv, N_k, d_h]`` — value tensor, *unexpanded* for GQA.
        scale:     Scaling factor applied to QK scores. Defaults to
                   ``1 / sqrt(d_h)``.
        mask:      Additive attention mask, shape broadcastable to
                   ``[B, 1, N_q, N_k]`` (large negative = masked position).
                   ``None`` means no masking.
        tile_size: Side length of each QK tile.  Tune to fit GPU L2 cache:
                   * Pascal (P40, 1080Ti): 3 MB L2  → 64
                   * Volta / Turing:        6 MB L2  → 128
                   * Ampere / Ada:         40 MB L2  → 256
        dropout_p: Accepted for API compatibility; dropout is *not* applied
                   inside the tile loop (would break online-softmax invariant).

    Returns:
        ``torch.Tensor`` of shape ``[B, N_q, n_h, d_h]``, same dtype as input.

    Notes:
        * GQA is handled implicitly: ``n_groups = n_h // n_kv`` is computed
          from tensor shapes; no explicit parameter required.
        * The online-softmax accumulators (m, l, o) are kept in float32 even
          when inputs are fp16/bf16. The final result is cast back to the
          input dtype.
        * ``m`` is initialised to ``-1e9`` (not ``-inf``) to avoid
          ``nan`` in ``exp(-inf - (-inf))`` when every position in a tile is
          masked.
        * ``l + 1e-8`` guards the normalisation against fully-masked rows.
    """
    B, n_h, N_q, d_h = query.shape
    n_kv = key.shape[1]
    N_k = key.shape[2]

    if n_h % n_kv != 0:
        raise ValueError(
            f"n_h ({n_h}) must be divisible by n_kv ({n_kv}) for GQA."
        )
    n_groups: int = n_h // n_kv

    if scale is None:
        scale = d_h ** -0.5

    # Preallocate output — new_empty avoids the zero-init overhead.
    attn_output = query.new_empty(B, n_h, N_q, d_h)

    for q_start in range(0, N_q, tile_size):
        q_end = min(q_start + tile_size, N_q)
        q_tile = query[:, :, q_start:q_end, :]   # [B, n_h, tq, d_h]
        tq = q_end - q_start

        # Online-softmax state — float32 for numerical stability.
        # m_init = -1e9: avoids nan when all tiles are masked out.
        m = query.new_full((B, n_h, tq, 1), -1e9, dtype=torch.float32)
        l = query.new_zeros((B, n_h, tq, 1), dtype=torch.float32)
        o = query.new_zeros((B, n_h, tq, d_h), dtype=torch.float32)

        q_f32 = q_tile.float()

        for k_start in range(0, N_k, tile_size):
            k_end = min(k_start + tile_size, N_k)

            # Fused GQA expansion: slice unexpanded KV then expand the small
            # tile only — peak KV memory is [B, n_h, tile, d_h] per iteration.
            k_raw = key[:, :, k_start:k_end, :]    # [B, n_kv, tk, d_h]
            v_raw = value[:, :, k_start:k_end, :]  # [B, n_kv, tk, d_h]
            k_tile = _repeat_kv(k_raw, n_groups).float()   # [B, n_h, tk, d_h]
            v_tile = _repeat_kv(v_raw, n_groups).float()   # [B, n_h, tk, d_h]

            # Attention scores: [B, n_h, tq, tk]
            s = torch.matmul(q_f32, k_tile.transpose(2, 3)) * scale

            if mask is not None:
                # Slice the mask to this tile; mask is [B, 1, N_q, N_k].
                s = s + mask[:, :, q_start:q_end, k_start:k_end].float()

            # Online softmax update
            m_new = torch.maximum(m, s.amax(dim=-1, keepdim=True))  # [B, n_h, tq, 1]
            rescale = torch.exp(m - m_new)                           # [B, n_h, tq, 1]
            exp_s = torch.exp(s - m_new)                             # [B, n_h, tq, tk]

            o = rescale * o + torch.matmul(exp_s, v_tile)            # [B, n_h, tq, d_h]
            l = rescale * l + exp_s.sum(dim=-1, keepdim=True)        # [B, n_h, tq, 1]
            m = m_new

        # Normalise; eps prevents 0/0 for fully-masked rows.
        attn_output[:, :, q_start:q_end, :] = (o / (l + 1e-8)).to(query.dtype)

    # Return [B, N_q, n_h, d_h] — transpose from [B, n_h, N_q, d_h]
    return attn_output.transpose(1, 2).contiguous()
