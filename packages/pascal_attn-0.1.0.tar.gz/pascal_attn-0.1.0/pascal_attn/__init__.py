"""
pascal-attn: Memory-efficient tiled online-softmax attention with fused GQA
KV expansion, tuned for Pascal and later NVIDIA GPUs.

Quick start::

    from pascal_attn import tiled_attention, TiledAttention, recommended_tile_size

    # Functional API
    tile = recommended_tile_size()          # auto-detect from GPU L2 cache
    out = tiled_attention(q, k, v, tile_size=tile)

    # nn.Module API
    attn = TiledAttention(n_heads=32, n_kv_heads=8, head_dim=64, tile_size='auto')
    out = attn(q, k, v)

    # HuggingFace integration (optional — requires transformers)
    from pascal_attn.hf import register_with_transformers
    register_with_transformers(tile_size=64)   # registers "pascal_chunked"

Input/output conventions:
    tiled_attention / TiledAttention functional path:
        query:  [B, n_h,  N_q, d_h]
        key:    [B, n_kv, N_k, d_h]  (unexpanded GQA — n_kv <= n_h)
        value:  [B, n_kv, N_k, d_h]
        output: [B, N_q,  n_h, d_h]

    TiledAttention nn.Module (packed inputs):
        query:  [B, N_q, n_h * d_h]
        key:    [B, N_k, n_kv * d_h]
        value:  [B, N_k, n_kv * d_h]
        output: [B, N_q, n_h * d_h]
"""

from .functional import tiled_attention
from .nn import TiledAttention
from ._gpu import recommended_tile_size

__all__ = [
    "tiled_attention",
    "TiledAttention",
    "recommended_tile_size",
]

__version__ = "0.1.0"
