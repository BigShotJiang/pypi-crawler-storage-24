"""
GPU L2 cache detection for automatic tile size selection.

Tile size must fit within the GPU's L2 cache to avoid cache thrashing on the
QK matmul.  The cost of a miss in the outer memory hierarchy (DRAM) is ~100×
the cost of an L2 hit, so getting this wrong adds significant latency.

Tile memory formula (float32 attention scores):
    B × n_h × tile × tile × 4 bytes

At B=4, n_h=32:
    tile=64  → 2.0 MB   ← fits Pascal  (3 MB L2)
    tile=128 → 8.0 MB   ← fits Volta/Turing (6 MB ... just tight; 8 MB common)
    tile=256 → 33.6 MB  ← fits Ampere (40 MB L2)

The function below queries PyTorch's device properties to determine the
L2 cache size and returns a conservative tile recommendation.
"""

import torch


def recommended_tile_size(device=None) -> int:
    """
    Return the recommended tile size for the given device based on L2 cache.

    Args:
        device: A ``torch.device``, device index (int), device string, or
                ``None`` to use the current CUDA device.  If CUDA is not
                available, returns 256 (safe for CPU benchmarking).

    Returns:
        Recommended tile size as an integer:

        * Pascal (P40, GTX 1080 Ti) — 3 MB L2  → **64**
        * Volta (V100) / Turing (T4, RTX 20xx) — 6–8 MB L2  → **128**
        * Ampere (A100, RTX 30xx) / Ada (RTX 40xx) — 20–80 MB L2  → **256**
        * Unknown / CPU → **256**
    """
    if not torch.cuda.is_available():
        return 256

    if device is None:
        device = torch.cuda.current_device()

    try:
        props = torch.cuda.get_device_properties(device)
        l2_bytes: int = props.l2_cache_size   # bytes

        # Convert to MB for readability in the decision tree.
        l2_mb = l2_bytes / (1024 * 1024)

        if l2_mb <= 4:
            # Pascal (GTX 1080, 1080 Ti: 2 MB; P40: 3 MB)
            return 64
        elif l2_mb <= 12:
            # Volta V100: 6 MB; Turing T4: 4 MB, RTX 20xx: 5–6 MB
            # (T4 is actually ≤4 MB so falls in the Pascal bucket — fine,
            # 64 is still correct; but most Turing consumer cards have 6 MB)
            return 128
        else:
            # Ampere A100: 40 MB; A40: 48 MB; RTX 3090: 6 MB (will get 128,
            # which is fine). Ada L4: 48 MB; RTX 4090: 72 MB.
            return 256

    except Exception:
        # If device properties are unavailable for any reason, use a
        # conservative value that works everywhere.
        return 256


def device_l2_mb(device=None) -> float:
    """
    Return the L2 cache size in MB for the given device, or 0.0 if unknown.

    Useful for diagnostics.
    """
    if not torch.cuda.is_available():
        return 0.0
    if device is None:
        device = torch.cuda.current_device()
    try:
        props = torch.cuda.get_device_properties(device)
        return props.l2_cache_size / (1024 * 1024)
    except Exception:
        return 0.0
