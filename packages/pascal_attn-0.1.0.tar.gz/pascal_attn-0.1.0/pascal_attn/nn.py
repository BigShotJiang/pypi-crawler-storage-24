"""
nn.Module wrapper for tiled attention.

Provides a drop-in ``nn.Module`` that accepts both packed and unpacked
input shapes and delegates to the functional tiled attention implementation.

Example::

    from pascal_attn.nn import TiledAttention

    attn = TiledAttention(n_heads=32, n_kv_heads=8, head_dim=64, tile_size='auto')

    # Inputs can be [B, N, H] (packed) or [B, N, n_h, d_h] (unpacked)
    # query:  [B, N_q, H_q]   where H_q = n_heads * head_dim
    # key:    [B, N_k, H_kv]  where H_kv = n_kv_heads * head_dim
    # value:  [B, N_k, H_kv]
    output = attn(query, key, value)
    # output: [B, N_q, H_q]
"""

from typing import Optional, Union

import torch
import torch.nn as nn

from ._core import tiled_attention
from ._gpu import recommended_tile_size


class TiledAttention(nn.Module):
    """
    Memory-efficient tiled attention module with fused GQA KV expansion.

    This module does **not** contain any learnable parameters — it is a pure
    computational wrapper around :func:`pascal_attn.functional.tiled_attention`.
    Projection layers (Q/K/V/O) should be managed by the caller.

    Args:
        n_heads:    Number of query attention heads.
        n_kv_heads: Number of key/value heads.  Defaults to ``n_heads``
                    (standard MHA).  Must divide ``n_heads`` evenly.
        head_dim:   Dimensionality of each head.  If ``None``, the module
                    will infer it from the last dimension of the input tensor
                    divided by ``n_heads``.
        tile_size:  Tile side length, or ``'auto'`` to detect from GPU L2
                    cache at the time of the first forward call.
        dropout:    Dropout probability (accepted; not applied inside the
                    tile loop — would break online-softmax invariant).
        scale:      Override the QK scale factor.  Defaults to
                    ``1 / sqrt(head_dim)``.

    Inputs to ``forward``:
        query:  ``[B, N_q, n_heads * head_dim]``  OR
                ``[B, N_q, n_heads, head_dim]``
        key:    ``[B, N_k, n_kv_heads * head_dim]``  OR
                ``[B, N_k, n_kv_heads, head_dim]``
        value:  same shape as key
        mask:   additive mask broadcastable to ``[B, 1, N_q, N_k]``

    Output:
        ``[B, N_q, n_heads * head_dim]``  (packed) when input was packed, or
        ``[B, N_q, n_heads, head_dim]``   (unpacked) when input was unpacked.
    """

    def __init__(
        self,
        n_heads: int,
        n_kv_heads: Optional[int] = None,
        head_dim: Optional[int] = None,
        tile_size: Union[int, str] = "auto",
        dropout: float = 0.0,
        scale: Optional[float] = None,
    ):
        super().__init__()

        if n_kv_heads is None:
            n_kv_heads = n_heads

        if n_heads % n_kv_heads != 0:
            raise ValueError(
                f"n_heads ({n_heads}) must be divisible by n_kv_heads ({n_kv_heads})."
            )

        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.head_dim = head_dim
        self.dropout = dropout
        self.scale = scale

        # Tile size can be 'auto' (resolved lazily) or a fixed int.
        if tile_size == "auto":
            self._tile_size_auto = True
            self._tile_size: int = 64   # default until first forward
        else:
            self._tile_size_auto = False
            self._tile_size = int(tile_size)

        self._auto_resolved = False

    def _resolve_tile_size(self, device: torch.device) -> int:
        """Resolve auto tile size once we know the device."""
        if self._tile_size_auto and not self._auto_resolved:
            self._tile_size = recommended_tile_size(device)
            self._auto_resolved = True
        return self._tile_size

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Compute tiled attention.

        Args:
            query: ``[B, N_q, n_heads * head_dim]`` or
                   ``[B, N_q, n_heads, head_dim]``
            key:   ``[B, N_k, n_kv_heads * head_dim]`` or
                   ``[B, N_k, n_kv_heads, head_dim]``
            value: same shape as key
            mask:  optional additive mask ``[B, 1, N_q, N_k]``

        Returns:
            ``[B, N_q, n_heads * head_dim]`` (packed) or
            ``[B, N_q, n_heads, head_dim]`` (unpacked), matching input format.
        """
        packed = query.dim() == 3

        if packed:
            B, N_q, H_q = query.shape
            _, N_k, H_kv = key.shape

            if self.head_dim is None:
                head_dim = H_q // self.n_heads
            else:
                head_dim = self.head_dim

            # Reshape to [B, N, n_h, d_h] then transpose to [B, n_h, N, d_h]
            query = query.view(B, N_q, self.n_heads, head_dim).transpose(1, 2)
            key = key.view(B, N_k, self.n_kv_heads, head_dim).transpose(1, 2)
            value = value.view(B, N_k, self.n_kv_heads, head_dim).transpose(1, 2)
        else:
            # Input is already [B, N, n_h, d_h] — just transpose
            B, N_q = query.shape[0], query.shape[1]
            head_dim = query.shape[3] if self.head_dim is None else self.head_dim
            query = query.transpose(1, 2)   # [B, n_h, N_q, d_h]
            key = key.transpose(1, 2)
            value = value.transpose(1, 2)

        tile = self._resolve_tile_size(query.device)
        scale = self.scale if self.scale is not None else head_dim ** -0.5

        # output is [B, N_q, n_h, d_h]
        out = tiled_attention(
            query=query,
            key=key,
            value=value,
            scale=scale,
            mask=mask,
            tile_size=tile,
            dropout_p=self.dropout,
        )

        if packed:
            # Merge n_h and d_h back: [B, N_q, n_h, d_h] → [B, N_q, H]
            return out.reshape(B, N_q, self.n_heads * head_dim)
        else:
            # Keep [B, N_q, n_h, d_h]
            return out

    def extra_repr(self) -> str:
        tile_str = "auto" if self._tile_size_auto else str(self._tile_size)
        return (
            f"n_heads={self.n_heads}, n_kv_heads={self.n_kv_heads}, "
            f"head_dim={self.head_dim}, tile_size={tile_str}, "
            f"dropout={self.dropout}"
        )
