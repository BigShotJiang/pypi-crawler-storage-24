"""Surface Distance Shootout.

Test different surface distance calculations to compare accuracy and precision.
"""
