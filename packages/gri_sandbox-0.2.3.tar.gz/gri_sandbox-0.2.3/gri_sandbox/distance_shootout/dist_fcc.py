"""FCC surface distance equations.

https://en.wikipedia.org/wiki/Geographical_distance#FCC's_formula
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    import numpy as np


def surface_dist_fcc_m(
    lla1: np.ndarray | Sequence,
    lla2: np.ndarray | Sequence,
) -> float:
    """Get the approximate great circle distance via the FCC formula.

    Semi-accurate for distances less than 475 km. 3D approximation simply using
    pythagorean.

    Args:
        lla1(np.ndarray|Sequence): Array with Lat(Deg), Lon(Deg) as first two elements
        lla2(np.ndarray|Sequence): Array with Lat(Deg), Lon(Deg) as first two elements

    Returns:
        float: meters
    """
    lat_m = math.radians(lla2[0] + lla1[0]) / 2
    k1 = 111.13209 - 0.56605 * math.cos(2 * lat_m) + 0.00120 * math.cos(4 * lat_m)
    k2 = (
        111.41513 * math.cos(lat_m)
        - 0.09455 * math.cos(3 * lat_m)
        + 0.00012 * math.cos(5 * lat_m)
    )
    return (
        (k1 * (lla2[0] - lla1[0])) ** 2 + (k2 * (lla2[1] - lla1[1])) ** 2
    ) ** 0.5 * 1000
