"""Mahalanobis Curvature examples.

Visually see the distance shortening when viewed through the lens of Mahalanobis.
"""
