"""Testing matrix inversion timings."""

# Notes:
# Compare Numpy linalg.inv to hardcoded methods:
# https://stackoverflow.com/questions/42489310/matrix-inversion-3-3-python-hard-coded-vs-numpy-linalg-inv
# Make sure it works for broadcasting, but also test it in loops
# Note that np.linalg.solve(A,B) solves Ax=B (solve for x) and may be *way* faster
