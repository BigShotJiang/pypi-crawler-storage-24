"""Find emitter - return multiple solutions when ambiguous."""

from __future__ import annotations

# ruff : noqa: PLR0913
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from gri_pos import Pos
from gri_tropo.dgs import dgs_tropo_corrections
from gri_utils.conversion import aer_to_xyz, lla_to_xyz, xyz_to_aer, xyz_to_lla

from gri_sandbox.patent_paper.calculate_wgs84_intersection import (
    calculate_wgs84_intersection,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


@dataclass
class Solution:
    """A candidate emitter solution."""

    emitter_pos: Pos
    residual_rad: float
    residual_mdeg: float
    latitude: float
    consistency_error_m: float
    curvature: float
    apparent_elevation_deg: float | None  # What elevation does this correspond to?


@dataclass
class MultipleSolutionResult:
    """Result containing multiple candidate solutions."""

    solutions: list[Solution]
    num_minima_found: int


def compute_correction_residual(
    candidate_lat: float,
    candidate_lon: float,
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> float:
    """Compute the correction residual for a candidate position."""
    candidate_lla = np.array([candidate_lat, candidate_lon, 0.0])
    candidate_xyz = lla_to_xyz(candidate_lla)

    # Correction computed by tropo model at this position
    correction_at_candidate, _ = dgs_tropo_corrections(
        emitter_loc_lla=candidate_lla,
        collector_pos_xyz=collector_xyz,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    # Correction that would be needed to actually point at candidate
    apparent_aer = xyz_to_aer(collector_xyz, apparent_pointing_vector)

    to_candidate = candidate_xyz - collector_xyz
    to_candidate_unit = to_candidate / np.linalg.norm(to_candidate)
    target_aer = xyz_to_aer(collector_xyz, to_candidate_unit)

    correction_needed = np.deg2rad(target_aer[1] - apparent_aer[1])

    return abs(correction_at_candidate - correction_needed)


def find_all_local_minima(
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    lon: float,
    lat_range: tuple[float, float],
    num_points: int = 400,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> list[tuple[float, float]]:
    """Find all local minima in the residual landscape."""
    lats = np.linspace(lat_range[0], lat_range[1], num_points)
    residuals = []

    for lat in lats:
        residual = compute_correction_residual(
            float(lat),
            lon,
            apparent_pointing_vector,
            collector_xyz,
            n_sur,
            ref_ht,
        )
        residuals.append(residual)

    # Find local minima
    minima = []
    for i in range(1, len(residuals) - 1):
        if residuals[i] <= residuals[i - 1] and residuals[i] <= residuals[i + 1]:
            minima.append((float(lats[i]), residuals[i]))  # noqa: PERF401

    return minima


def refine_minimum(
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    lon: float,
    lat_center: float,
    initial_range: float = 0.2,
    refinement_stages: int = 7,
    points_per_stage: int = 50,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> tuple[float, float]:
    """Refine a local minimum to high precision."""
    lat_min = lat_center - initial_range / 2
    lat_max = lat_center + initial_range / 2

    best_lat = lat_center
    best_residual = float("inf")

    for _ in range(refinement_stages):
        lats = np.linspace(lat_min, lat_max, points_per_stage)

        for lat in lats:
            residual = compute_correction_residual(
                float(lat),
                lon,
                apparent_pointing_vector,
                collector_xyz,
                n_sur,
                ref_ht,
            )
            if residual < best_residual:
                best_residual = residual
                best_lat = float(lat)

        # Narrow range
        range_width = (lat_max - lat_min) / 5
        lat_min = best_lat - range_width / 2
        lat_max = best_lat + range_width / 2

    return best_lat, best_residual


def compute_consistency_error(
    candidate_lat: float,
    candidate_lon: float,
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> float:
    """Compute consistency error for a candidate position."""
    candidate_lla = np.array([candidate_lat, candidate_lon, 0.0])
    candidate_xyz = lla_to_xyz(candidate_lla)

    # Compute tropo correction at candidate
    correction_rad, _ = dgs_tropo_corrections(
        emitter_loc_lla=candidate_lla,
        collector_pos_xyz=collector_xyz,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    # Apply correction to apparent vector
    apparent_aer = xyz_to_aer(collector_xyz, apparent_pointing_vector)
    corrected_elev_deg = apparent_aer[1] + np.rad2deg(correction_rad)
    corrected_aer = np.array([apparent_aer[0], corrected_elev_deg, 1.0])
    corrected_vector = aer_to_xyz(collector_xyz, corrected_aer)
    corrected_vector = corrected_vector / np.linalg.norm(corrected_vector)

    # Find intersection
    intersection_xyz = calculate_wgs84_intersection(collector_xyz, corrected_vector)

    if intersection_xyz is None:
        return float("inf")

    return float(np.linalg.norm(intersection_xyz - candidate_xyz))


def compute_curvature(
    lat: float,
    lon: float,
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    delta: float = 0.001,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> float:
    """Compute second derivative (curvature) at a point."""
    r_center = compute_correction_residual(
        lat,
        lon,
        apparent_pointing_vector,
        collector_xyz,
        n_sur,
        ref_ht,
    )
    r_plus = compute_correction_residual(
        lat + delta,
        lon,
        apparent_pointing_vector,
        collector_xyz,
        n_sur,
        ref_ht,
    )
    r_minus = compute_correction_residual(
        lat - delta,
        lon,
        apparent_pointing_vector,
        collector_xyz,
        n_sur,
        ref_ht,
    )

    return (r_plus - 2 * r_center + r_minus) / (delta**2)


def compute_apparent_elevation(
    candidate_lat: float,
    candidate_lon: float,
    collector_xyz: np.ndarray,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> float | None:
    """Compute what apparent elevation this solution corresponds to."""
    candidate_lla = np.array([candidate_lat, candidate_lon, 0.0])
    candidate_xyz = lla_to_xyz(candidate_lla)

    # Geometric elevation from collector to candidate
    to_candidate = candidate_xyz - collector_xyz
    to_candidate_unit = to_candidate / np.linalg.norm(to_candidate)
    geometric_aer = xyz_to_aer(collector_xyz, to_candidate_unit)
    geometric_elev_deg = geometric_aer[1]

    # Tropo correction at this position
    correction_rad, _ = dgs_tropo_corrections(
        emitter_loc_lla=candidate_lla,
        collector_pos_xyz=collector_xyz,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    # Apparent elevation = geometric - correction
    apparent_elev_deg = geometric_elev_deg - np.rad2deg(correction_rad)

    return float(apparent_elev_deg)


def find_emitter_multiple_solutions(
    apparent_pointing_vector: NDArray[np.floating],
    collector_xyz: NDArray[np.floating],
    initial_lat_range: tuple[float, float] = (-5.0, 5.0),
    initial_points: int = 400,
    refinement_stages: int = 7,
    residual_threshold_rad: float = 1e-6,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> MultipleSolutionResult:
    """Find all emitter solutions with small residuals.

    Returns multiple solutions when the problem is ambiguous (multiple
    self-consistent solutions exist). Each solution includes metadata
    to help discriminate between them.

    Args:
        apparent_pointing_vector: Apparent direction vector.
        collector_xyz: Collector position.
        initial_lat_range: Initial latitude search range.
        initial_points: Points in initial coarse search.
        refinement_stages: Number of refinement iterations per minimum.
        residual_threshold_rad: Residual threshold for accepting solutions.
        n_sur: Surface refractivity.
        ref_ht: Atmospheric scale height.

    Returns:
        MultipleSolutionResult with all valid solutions.
    """
    apparent_pointing_vector = np.asarray(apparent_pointing_vector)
    collector_xyz = np.asarray(collector_xyz)

    collector_lla = xyz_to_lla(collector_xyz)
    lon = collector_lla[1]

    # Find all local minima
    coarse_minima = find_all_local_minima(
        apparent_pointing_vector,
        collector_xyz,
        lon,
        initial_lat_range,
        initial_points,
        n_sur,
        ref_ht,
    )

    solutions = []

    # Refine each minimum
    for lat_coarse, _ in coarse_minima:
        lat_refined, residual_refined = refine_minimum(
            apparent_pointing_vector,
            collector_xyz,
            lon,
            lat_coarse,
            refinement_stages=refinement_stages,
            n_sur=n_sur,
            ref_ht=ref_ht,
        )

        # Only keep solutions below threshold
        if residual_refined < residual_threshold_rad:
            # Compute additional metadata
            consistency = compute_consistency_error(
                lat_refined,
                lon,
                apparent_pointing_vector,
                collector_xyz,
                n_sur,
                ref_ht,
            )
            curvature = compute_curvature(
                lat_refined,
                lon,
                apparent_pointing_vector,
                collector_xyz,
                n_sur=n_sur,
                ref_ht=ref_ht,
            )
            apparent_elev = compute_apparent_elevation(
                lat_refined,
                lon,
                collector_xyz,
                n_sur,
                ref_ht,
            )

            solutions.append(
                Solution(
                    emitter_pos=Pos.LLA(np.array([lat_refined, lon, 0.0])),
                    residual_rad=residual_refined,
                    residual_mdeg=np.rad2deg(residual_refined) * 1000,
                    latitude=lat_refined,
                    consistency_error_m=consistency,
                    curvature=curvature,
                    apparent_elevation_deg=apparent_elev,
                ),
            )

    # Sort by residual (best first)
    solutions.sort(key=lambda s: s.residual_rad)

    return MultipleSolutionResult(
        solutions=solutions,
        num_minima_found=len(coarse_minima),
    )
