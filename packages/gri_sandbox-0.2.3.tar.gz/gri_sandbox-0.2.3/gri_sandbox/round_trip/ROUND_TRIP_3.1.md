# Tropospheric Round-Trip Emitter Location - Algorithm 1

## 3.1 Algorithm 1: Fast Iterative Approach

The iterative algorithm exploits the physical structure of the tropospheric correction to rapidly converge to the emitter position through successive refinement. It is computationally efficient but limited to specific elevation regimes.

### Algorithm Structure

**Step 1: Initialization**

Generate an initial position guess from the apparent pointing vector geometry:
- Convert apparent vector to azimuth-elevation-range (AER) coordinates relative to collector
- Extract apparent azimuth (α_apparent)
- Project collector nadir point onto Earth's surface
- Offset from nadir along apparent azimuth by approximately 500 km (~5° at equator)
- Compute offset as: Δlat = 5° × cos(α), Δlon = 5° × sin(α) / cos(lat_collector)
- Clamp resulting latitude to [-89°, +89°] to avoid polar singularities
- Set initial altitude to 0 meters (force to surface)

This initialization strategy ensures a valid starting point even when apparent elevation is at or below the horizon, where direct geometric projection would fail to intersect Earth.

**Step 2: Iterative Refinement Loop**

For iteration i = 1 to N_max (typically N_max = 20):

1. **Compute Tropospheric Correction at Current Guess**
   - Evaluate DGS model: δ_i = DGS_correction(P_guess,i, P_collector, n_sur, h_ref)
   - This gives cone correction in radians for a ray from P_guess,i to collector

2. **Estimate True Pointing Direction**
   - Convert apparent vector to AER: (α_apparent, el_apparent, r_apparent)
   - Apply correction: el_true,estimate = el_apparent + rad_to_deg(δ_i)
   - Reconstruct true direction vector: v_true = AER_to_XYZ(α_apparent, el_true,estimate, r=1)
   - Normalize: v_true = v_true / ||v_true||

3. **Find WGS-84 Intersection**
   - Solve quadratic equation for ray-ellipsoid intersection
   - Ray: P_collector + t × v_true, where t ≥ 0
   - WGS-84 ellipsoid: x²/a² + y²/a² + z²/b² = 1, where a = 6378137 m, b = 6356752.3142 m
   - Select near intersection (smaller t > 0) as new guess: P_guess,i+1
   - If no intersection exists: return failure (should be rare if correction is valid)

4. **Check Convergence**
   - Compute position change: Δ_i = ||P_guess,i+1 - P_guess,i||
   - If Δ_i < τ_convergence (typically τ = 1 meter): converged → return P_guess,i+1
   - Otherwise: continue to next iteration

5. **Update for Next Iteration**
   - Set P_guess,i+1 as current guess
   - Force altitude to exactly 0 meters (re-project to surface if needed)

**Step 3: Termination**

- If converged (Δ_i < τ): return final position and convergence metrics
- If reached N_max without convergence: return best position with warning flag

### Computational Complexity

**Per-Iteration Cost:**
- DGS tropospheric correction: 1 evaluation (~O(1) with lookup tables, ~O(10) with numerical integration)
- Coordinate conversions (XYZ ↔ AER ↔ LLA): ~O(10) floating-point operations
- WGS-84 intersection: solve quadratic equation, ~O(1)
- Total per iteration: dominated by DGS evaluation

**Total Cost:**
- Best case (high elevation, Regime 1): 3-5 iterations
- Typical case (medium elevation, Regime 1-2): 6-15 iterations
- Worst case (approaches max before failure): 20 iterations
- **Average successful case: ~20 tropospheric evaluations total**

Compared to grid search requiring 400-1200 evaluations, this represents a **20-60× speedup** when applicable.

### Performance by Regime

**Regime 1 (Elevation ≥ 3.08°): Excellent**

Convergence characteristics:
- Iterations to convergence: 3-5 (at 10°), 4-6 (at 5°), 5 (at 3.08°)
- Final position error: <1 meter (high elevation), ~1-2 meters (near bifurcation)
- Convergence rate: superlinear (each iteration reduces error by ~5-10×)
- Success rate: 100%

The single self-consistent solution acts as a strong attractor. The residual landscape is a deep, broad valley that captures the iterative trajectory regardless of initialization. The correction function is well-behaved (smooth, nearly linear locally) at these elevations.

**Regime 2 (Elevation 0.5° - 3.08°): Good to Excellent**

Convergence characteristics:
- Iterations to convergence: 6-20 depending on elevation
- Final position error: 0.7 m (at 0.6°), 14 m (at 0.5°)
- Success rate: 100% (always finds TRUE solution, not spurious)
- Convergence pattern: initially slow, then rapid in final 3-4 iterations

Despite two solutions existing, the iterative trajectory preferentially approaches the TRUE solution. The basin of attraction for the TRUE solution encompasses the typical initialization region (sub-satellite point offset). The spurious solution's basin lies in a different region of the search space not accessed by the standard initialization strategy.

Elevation-dependent performance within Regime 2:
- 2.0° - 3.08°: 5-6 iterations, <0.1 m error
- 1.0° - 2.0°: 6-10 iterations, <0.2 m error
- 0.6° - 1.0°: 10-18 iterations, 0.2-1 m error
- 0.5° - 0.6°: 18-20 iterations, 1-15 m error

**Regime 3 (Elevation < 0.5°): Failure**

Catastrophic failure mode:
- 0.4° elevation: converges to wrong position, 1,105 m error
- 0.3° elevation: converges to wrong position, 14,719 m error
- 0.2° elevation: converges to wrong position, 36,416 m error
- 0.1° elevation: converges to wrong position, 58,505 m error
- 0.0° elevation: converges to wrong position, 80,698 m error

The iterative trajectory crosses into the spurious solution's basin of attraction. The initialization guess, when corrected, points toward the spurious minimum rather than the TRUE minimum. The correction landscape becomes so nonlinear that local gradient information (implicit in the iteration) leads away from the true solution.

Failure mechanism: At these low elevations, the correction function has high curvature and the two minima are separated by a ridge or saddle point. The iterative path, determined by the sequence of intersections, crosses this ridge early and remains trapped in the spurious basin.

### Advantages and Limitations

**Advantages:**
- Extremely fast: 20-60× speedup over grid search when successful
- Simple implementation: no tuning parameters or search grids needed
- Deterministic: same input always produces same output
- Natural convergence criterion: position change provides clear stopping condition
- Works perfectly in most practical scenarios (elevation > 0.5° covers ~95% of cases)

**Limitations:**
- No verification: cannot detect presence of multiple solutions
- Regime-dependent: catastrophic failure below 0.5° elevation
- No error bounds: does not provide uncertainty estimates
- Black box failure: when it fails, gives no indication of failure
- Initialization-sensitive: different initialization strategies might find different solutions
