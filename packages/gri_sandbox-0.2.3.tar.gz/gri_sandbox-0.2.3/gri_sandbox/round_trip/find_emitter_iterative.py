"""Find emitter location from apparent pointing vector using tropospheric model.

Given an apparent pointing vector (the direction a signal appears to arrive from
after atmospheric refraction), this module iteratively solves for the true emitter
location on Earth's surface using the ITU-R 2019 tropospheric model.

Accuracy Summary (tested with 1000 km LEO collector altitude):

| Elevation | Position Error | Notes                          |
|-----------|----------------|--------------------------------|
| 0.0°      | ~80 km         | Very poor - wrong solution     |
| 0.1°      | ~58 km         | Very poor - wrong solution     |
| 0.2°      | ~36 km         | Very poor - wrong solution     |
| 0.3°      | ~15 km         | Poor                           |
| 0.4°      | ~1.1 km        | Marginal                       |
| 0.5°      | ~14 m          | Usable                         |
| ≥0.6°     | <1 m           | Excellent - sub-meter accuracy |

The transition to stable/accurate solutions occurs around 0.5-0.6° elevation.
Above this threshold, the iterative solver reliably recovers the true emitter
position with sub-meter accuracy in 3-4 iterations.

At very low elevation angles (<0.5°), the correction curve becomes highly
nonlinear and the solver may converge to a different consistent solution
rather than the true emitter location.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import Pos
from gri_tropo.dgs import dgs_tropo_corrections
from gri_utils.conversion import aer_to_xyz, xyz_to_aer, xyz_to_lla

from gri_sandbox.patent_paper.calculate_wgs84_intersection import (
    calculate_wgs84_intersection,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


def true_pointing_vector_from_apparent(
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    cone_correction_rad: float,
) -> np.ndarray:
    """Calculate the true pointing vector from the apparent pointing vector.

    This is the inverse of apparent_pointing_vector_from_true. Given the apparent
    direction (what the collector measures) and the cone correction, compute the
    true geometric direction to the emitter.

    Args:
        apparent_pointing_vector: Unit vector in ECEF representing the apparent
            direction of arrival (the bent ray direction).
        collector_xyz: Collector position in ECEF coordinates (meters).
        cone_correction_rad: Angular deflection correction in radians. Positive
            values indicate the true angle is steeper than the apparent angle.

    Returns:
        Unit vector in ECEF pointing from collector toward the true emitter
        location (the geometric straight-line direction).
    """
    # Get apparent elevation angle in AER (azimuth, elevation, range)
    apparent_aer = xyz_to_aer(collector_xyz, apparent_pointing_vector)
    apparent_elev_deg = apparent_aer[1]

    # True elevation is steeper (higher) than apparent due to refraction
    true_elev_deg = apparent_elev_deg + np.rad2deg(cone_correction_rad)

    # Create true pointing vector with same azimuth but true elevation
    true_aer = np.array([apparent_aer[0], true_elev_deg, 1.0])
    true_vector = aer_to_xyz(collector_xyz, true_aer)

    # Normalize to unit vector
    return true_vector / np.linalg.norm(true_vector)


def get_initial_emitter_guess(
    collector_xyz: np.ndarray,
    apparent_pointing_vector: np.ndarray,
) -> np.ndarray:
    """Get initial emitter guess for iterative solver.

    Uses the sub-satellite point (nadir) projected along the apparent azimuth
    as the starting guess. This ensures we have a valid surface point even
    when the apparent elevation is at or below horizon.

    Args:
        collector_xyz: Collector position in ECEF coordinates (meters).
        apparent_pointing_vector: Unit vector in ECEF representing the apparent
            direction of arrival.

    Returns:
        Initial emitter guess as LLA [lat, lon, alt] in degrees and meters.
    """
    # Get collector LLA for sub-satellite point
    collector_lla = xyz_to_lla(collector_xyz)

    # Get apparent azimuth from collector
    apparent_aer = xyz_to_aer(collector_xyz, apparent_pointing_vector)
    azimuth_deg = apparent_aer[0]

    # Start with sub-satellite point at surface, offset along azimuth
    # Use a reasonable offset distance (e.g., 500 km along surface)
    # This gives us a starting point that's roughly in the right direction
    offset_deg = 5.0  # ~500 km at equator

    # Simple approximation: offset latitude for azimuth near 0/180,
    # offset longitude for azimuth near 90/270
    azimuth_rad = np.deg2rad(azimuth_deg)
    lat_offset = offset_deg * np.cos(azimuth_rad)
    lon_offset = offset_deg * np.sin(azimuth_rad) / np.cos(np.deg2rad(collector_lla[0]))

    initial_lat = collector_lla[0] + lat_offset
    initial_lon = collector_lla[1] + lon_offset

    # Clamp latitude to valid range
    initial_lat = np.clip(initial_lat, -89.0, 89.0)

    return np.array([initial_lat, initial_lon, 0.0])


def find_emitter_from_apparent(  # noqa: PLR0913
    apparent_pointing_vector: NDArray[np.floating],
    collector_xyz: NDArray[np.floating],
    max_iterations: int = 20,
    tolerance_m: float = 1.0,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> tuple[Pos | None, int, float]:
    """Find emitter location given apparent pointing vector and tropo model.

    Uses an iterative approach:
    1. Start with initial emitter guess (sub-satellite point offset along azimuth)
    2. Compute tropospheric correction for current geometry
    3. Apply correction to apparent angle to get estimated true direction
    4. Find WGS-84 intersection with corrected direction
    5. Use intersection as new emitter guess
    6. Repeat until convergence

    Args:
        apparent_pointing_vector: Unit vector in ECEF representing the apparent
            direction of arrival (what the collector measures).
        collector_xyz: Collector position in ECEF coordinates (meters).
        max_iterations: Maximum number of iterations before giving up.
        tolerance_m: Convergence tolerance in meters. Iteration stops when
            emitter position changes by less than this amount.
        n_sur: Surface refractivity in N-units (default: 315.0, global mean).
        ref_ht: Atmospheric scale height in km (default: 7.35, global mean).

    Returns:
        Tuple of (emitter_pos, iterations, final_error):
        - emitter_pos: Pos object with estimated emitter location, or None if
          no convergence or no valid intersection found.
        - iterations: Number of iterations performed.
        - final_error: Final position change in meters (convergence metric).
    """
    apparent_pointing_vector = np.asarray(apparent_pointing_vector)
    collector_xyz = np.asarray(collector_xyz)

    # Get initial emitter guess
    emitter_lla = get_initial_emitter_guess(collector_xyz, apparent_pointing_vector)

    prev_emitter_xyz = None
    final_error = float("inf")

    for iteration in range(max_iterations):
        # Compute tropospheric correction for current emitter guess
        cone_correction_rad, _time_correction = dgs_tropo_corrections(
            emitter_loc_lla=emitter_lla,
            collector_pos_xyz=collector_xyz,
            n_sur=n_sur,
            ref_ht=ref_ht,
        )

        # Apply correction to get estimated true pointing direction
        true_pointing_vector = true_pointing_vector_from_apparent(
            apparent_pointing_vector,
            collector_xyz,
            cone_correction_rad,
        )

        # Find WGS-84 intersection with corrected direction
        intersection_xyz = calculate_wgs84_intersection(
            collector_xyz,
            true_pointing_vector,
        )

        if intersection_xyz is None:
            # No valid intersection - this shouldn't happen if correction is right
            # but could occur at very low angles or with bad initial guess
            return None, iteration + 1, final_error

        # Convert intersection to LLA for next iteration
        emitter_lla = xyz_to_lla(intersection_xyz)
        emitter_lla[2] = 0.0  # Force to surface

        # Check convergence
        if prev_emitter_xyz is not None:
            final_error = float(np.linalg.norm(intersection_xyz - prev_emitter_xyz))
            if final_error < tolerance_m:
                # Converged
                return Pos.XYZ(intersection_xyz), iteration + 1, final_error

        prev_emitter_xyz = intersection_xyz.copy()

    # Did not converge within max iterations
    # intersection_xyz is guaranteed to be set since max_iterations >= 1 in practice,
    # but we need to handle the edge case for type safety
    if prev_emitter_xyz is None:
        return None, 0, float("inf")
    return Pos.XYZ(prev_emitter_xyz), max_iterations, final_error
