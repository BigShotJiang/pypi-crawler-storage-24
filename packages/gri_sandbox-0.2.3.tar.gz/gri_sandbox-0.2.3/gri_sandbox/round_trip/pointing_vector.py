"""Pointing vector calculations between positions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from gri_pos import Pos


def calculate_pointing_vector(from_pos: Pos, to_pos: Pos) -> np.ndarray:
    """Calculate normalized pointing vector from one position to another.

    Args:
        from_pos: Source position.
        to_pos: Target position.

    Returns:
        Unit vector pointing from source to target in ECEF.
    """
    vec = from_pos.delta_xyz(to_pos)
    return np.asarray(vec / np.linalg.norm(vec))
