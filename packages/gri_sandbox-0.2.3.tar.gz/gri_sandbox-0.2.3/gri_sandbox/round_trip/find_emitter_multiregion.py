"""Find emitter with optimized multi-region approach.

This module provides an optimized emitter location algorithm that uses a fast
iterative approach for common cases (Regime 1 and 2) and falls back to a full
search only when necessary (Regime 3).

Performance Characteristics:
- Fast path: ~20 troposphere calculations (3-20 iterations)
- Slow path: ~750 troposphere calculations (400 coarse + 350 refinement)
- Speedup: ~37x faster for 95%+ of realistic elevation angles

The three solution regimes:

Regime 1 (≥3.08° elevation):
- Only 1 self-consistent solution exists
- Iterative converges in 3-5 iterations with <1m error
- Fast path always succeeds

Regime 2 (0.5° - 3.0° elevation):
- 2 self-consistent solutions exist
- Iterative converges to correct one in 6-20 iterations with <15m error
- Fast path always succeeds

Regime 3 (<0.5° elevation):
- 2 self-consistent solutions exist
- Iterative fails (converges to wrong solution or doesn't converge)
- Slow path required to find all solutions

Adaptive Resolution (Tier 1):
Near bifurcation (0.34° - 0.39°), the solution finder may miss the TRUE
solution due to extremely shallow minima in the residual landscape. This
module implements automatic detection and refinement:

Detection criteria (requires 2+ indicators):
1. Low curvature (< 0.02): Indicates shallow minimum
2. Few coarse minima (< 3): Only found 1 minimum in coarse search

When detected, automatically runs 2x resolution (1200 points, 10 refinement
stages) to attempt recovery of missing TRUE solution.

Results:
- Detection rate: 100% of problematic cases
- Recovery rate: ~20% (successful at some elevations like 0.40°)
- For unrecoverable cases (0.35° - 0.37°): Returns emitter_pos=None

See claude_ADAPTIVE_DETECTION_FINDINGS.md for analysis details.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.conversion import xyz_to_aer

from gri_sandbox.round_trip.find_emitter_iterative import find_emitter_from_apparent
from gri_sandbox.round_trip.find_emitter_multiple_solutions import (
    MultipleSolutionResult,
    compute_correction_residual,
    find_emitter_multiple_solutions,
)
from gri_sandbox.round_trip.multiregion_result import MultiRegionResult

# Elevation threshold below which the fast iterative path is unreliable.
# Below this elevation, the iterative method converges to the SPURIOUS solution
# instead of the TRUE solution. Must use full residuals search instead.
# See ROUND_TRIP_3.md Section 3.1 "Regime 3 (<0.5° elevation): Failure"
_FAST_PATH_MIN_ELEVATION_DEG = 0.5

if TYPE_CHECKING:
    from numpy.typing import NDArray


def _is_suspicious_single_solution(result: MultipleSolutionResult) -> bool:
    """Detect if a single solution might be spurious (TRUE solution missing).

    Uses Tier 1 adaptive detection criteria based on analysis in
    claude_ADAPTIVE_DETECTION_FINDINGS.md:

    1. Low curvature (< 0.02): TRUE solutions avg 0.074, SPURIOUS-only avg 0.019
    2. Few coarse minima (< 3): TRUE always found with 2+ minima, SPURIOUS-only with 1
    3. Low sharpness (< 1.5e-05): TRUE avg 3.72e-05, SPURIOUS-only avg 9.66e-06

    Requires 2+ indicators to trigger refinement (100% detection, 0% false positives).

    Args:
        result: MultipleSolutionResult from standard resolution search.

    Returns:
        True if solution is suspicious and may be missing TRUE solution.
    """
    if len(result.solutions) != 1:
        return False

    sol = result.solutions[0]
    suspicious_indicators = 0

    # Indicator 1: Low curvature (shallow minimum)
    if sol.curvature < 0.02:  # noqa: PLR2004
        suspicious_indicators += 1

    # Indicator 2: Few coarse minima found (perfect indicator)
    if result.num_minima_found < 3:  # noqa: PLR2004
        suspicious_indicators += 1

    # Indicator 3: Low sharpness (optional - requires computing)
    # Not implemented here to avoid extra computation, but could be added

    # Require 2+ indicators to trigger (conservative)
    return suspicious_indicators >= 2  # noqa: PLR2004


def find_emitter_multiregion(  # noqa: PLR0913, C901, PLR0912
    apparent_pointing_vector: NDArray[np.floating],
    collector_xyz: NDArray[np.floating],
    max_iter_iterations: int = 20,
    iter_tolerance_m: float = 1.0,
    residual_threshold_rad: float = 1e-6,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> MultiRegionResult:
    """Find emitter using optimized multi-region approach with adaptive resolution.

    Strategy:
    1. Try fast iterative approach first (3-20 iterations)
    2. Check if solution is self-consistent (residual < threshold)
    3. If yes: Use it (Regime 1, ~37x faster)
    4. If no: Fall back to full search (Regime 2/3)
    5. For single solutions: Check for spuriousness (Tier 1 adaptive detection)
    6. If suspicious: Run 2x resolution search to attempt recovery

    This makes the common case (Regime 1, elevation ≥ 3.08°) very fast while
    still handling ambiguous cases correctly.

    Adaptive Resolution (NEW):
    Near bifurcation (0.34° - 0.39°), automatically detects potentially
    spurious single solutions and runs higher resolution search. If still
    unrecoverable, returns emitter_pos=None to indicate uncertainty.

    Args:
        apparent_pointing_vector: Apparent direction vector (unit, ECEF).
        collector_xyz: Collector position in ECEF meters.
        max_iter_iterations: Maximum iterations for fast iterative approach.
        iter_tolerance_m: Convergence tolerance for iterative approach.
        residual_threshold_rad: Residual threshold for self-consistency check.
        n_sur: Surface refractivity in N-units.
        ref_ht: Atmospheric scale height in km.

    Returns:
        MultiRegionResult with solution, regime classification, and metadata.
        Note: emitter_pos may be None if single solution is suspicious and
        unrecoverable even with higher resolution (gap elevations 0.35-0.37°).

    Example:
        >>> result = find_emitter_multiregion(apparent_vector, collector_xyz)
        >>> if result.emitter_pos is None:
        ...     # Uncertain - suspicious single solution, unrecoverable
        ...     adaptive = result.used_adaptive_resolution
        ...     print(f"Warning: Used adaptive resolution: {adaptive}")
        >>> elif result.regime == 1:
        ...     # Unambiguous - use the solution
        ...     emitter = result.emitter_pos
        >>> elif result.regime == 2:
        ...     # Ambiguous but solved - use the solution
        ...     emitter = result.emitter_pos
        >>> else:  # regime == 3
        ...     # Truly ambiguous - inspect all solutions
        ...     for sol in result.all_solutions:
        ...         print(f"Candidate at {sol.latitude:.6f}°")
    """
    apparent_pointing_vector = np.asarray(apparent_pointing_vector)
    collector_xyz = np.asarray(collector_xyz)

    # Compute apparent elevation to determine if fast path is safe
    # Below _FAST_PATH_MIN_ELEVATION_DEG, iterative converges to wrong solution
    apparent_aer = xyz_to_aer(collector_xyz, apparent_pointing_vector)
    apparent_elevation_deg = float(apparent_aer[1])

    # STEP 1: Try fast iterative approach first (only if elevation is high enough)
    # This is ~37x faster than full search and works for Regime 1 & 2
    # At low elevations (Regime 3), iterative converges to SPURIOUS solution
    if apparent_elevation_deg >= _FAST_PATH_MIN_ELEVATION_DEG:
        iter_result, num_iterations, final_error = find_emitter_from_apparent(
            apparent_pointing_vector,
            collector_xyz,
            max_iterations=max_iter_iterations,
            tolerance_m=iter_tolerance_m,
            n_sur=n_sur,
            ref_ht=ref_ht,
        )

        # STEP 2: Check if iterative solution is self-consistent
        # Self-consistency (residual ≈ 0) is the natural discriminator
        if iter_result is not None and final_error < iter_tolerance_m:
            # Converged - validate self-consistency
            iter_lat = float(iter_result.lla[0])
            iter_lon = float(iter_result.lla[1])

            residual = compute_correction_residual(
                iter_lat,
                iter_lon,
                apparent_pointing_vector,
                collector_xyz,
                n_sur,
                ref_ht,
            )

            if residual < residual_threshold_rad:
                # FAST PATH SUCCESS
                # Iterative found a self-consistent solution
                # This means Regime 1 (unambiguous) or Regime 2 (iterative succeeded)
                return MultiRegionResult(
                    emitter_pos=iter_result,
                    regime=1,  # Optimistic classification
                    used_fast_path=True,
                    num_solutions=1,  # Assumed
                    all_solutions=None,
                    iterations=num_iterations,
                    residual_rad=residual,
                    error_estimate_m=final_error,
                )

    # STEP 3: Iterative failed, not self-consistent, or elevation too low
    # Fall back to full search to find all solutions (Regime 2/3)
    multi_result = find_emitter_multiple_solutions(
        apparent_pointing_vector,
        collector_xyz,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    num_solutions = len(multi_result.solutions)

    if num_solutions == 0:
        # No solutions found - try higher resolution before giving up
        multi_result_fine = find_emitter_multiple_solutions(
            apparent_pointing_vector,
            collector_xyz,
            initial_lat_range=(-10.0, 10.0),
            initial_points=1200,  # 2x standard
            refinement_stages=10,  # More than standard (default is 7)
            residual_threshold_rad=residual_threshold_rad,
            n_sur=n_sur,
            ref_ht=ref_ht,
        )

        if len(multi_result_fine.solutions) > 0:
            # Higher resolution found solutions - use them
            multi_result = multi_result_fine
            num_solutions = len(multi_result_fine.solutions)
        else:
            # Still no solutions even with higher resolution
            return MultiRegionResult(
                emitter_pos=None,
                regime=0,  # Error state
                used_fast_path=False,
                num_solutions=0,
                all_solutions=None,
                iterations=0,
                residual_rad=float("inf"),
                error_estimate_m=None,
                used_adaptive_resolution=True,
            )

    if num_solutions == 1:
        # REGIME 1: Unambiguous (elevation ≥ 3.08°)
        # Only one self-consistent solution exists
        sol = multi_result.solutions[0]

        # ADAPTIVE RESOLUTION CHECK
        # Near bifurcation (0.34° - 0.39°), single solutions may be spurious
        # with the TRUE solution missing due to shallow minimum.
        # Use Tier 1 adaptive detection to identify and refine.
        if _is_suspicious_single_solution(multi_result):
            # Run higher resolution search (2x points, more refinement stages)
            multi_result_fine = find_emitter_multiple_solutions(
                apparent_pointing_vector,
                collector_xyz,
                initial_lat_range=(-10.0, 10.0),
                initial_points=1200,  # 2x standard (was 600 via defaults)
                refinement_stages=10,  # More than standard (default is 7)
                residual_threshold_rad=residual_threshold_rad,
                n_sur=n_sur,
                ref_ht=ref_ht,
            )

            # If fine resolution found more solutions, it may have recovered TRUE
            if len(multi_result_fine.solutions) > 1:
                # Fine resolution found additional solutions!
                # Fall through to multi-solution handling below
                multi_result = multi_result_fine
                num_solutions = len(multi_result_fine.solutions)
            elif len(multi_result_fine.solutions) == 1:
                # Still only one solution even with higher resolution
                # This is likely a difficult case (0.35° - 0.37° range)
                # Return None to indicate uncertainty
                return MultiRegionResult(
                    emitter_pos=None,
                    regime=1,
                    used_fast_path=False,
                    num_solutions=1,
                    all_solutions=None,
                    iterations=0,
                    residual_rad=multi_result_fine.solutions[0].residual_rad,
                    error_estimate_m=None,
                    used_adaptive_resolution=True,
                )
            # If no solutions found with fine resolution, fall through with original

        if num_solutions == 1:
            # Single solution confirmed (not suspicious or no change)
            return MultiRegionResult(
                emitter_pos=sol.emitter_pos,
                regime=1,
                used_fast_path=False,
                num_solutions=1,
                all_solutions=None,
                iterations=0,  # Full search doesn't report iterations
                residual_rad=sol.residual_rad,
                error_estimate_m=None,
            )

    # num_solutions == 2 (or more, but typically 2)
    # Multiple solutions exist - need to determine Regime 2 vs 3

    # Try iterative approach as tie-breaker, but ONLY if elevation is high enough
    # At low elevations, iterative converges to SPURIOUS solution and cannot
    # be used to discriminate between solutions
    if apparent_elevation_deg >= _FAST_PATH_MIN_ELEVATION_DEG:
        iter_result, num_iterations, final_error = find_emitter_from_apparent(
            apparent_pointing_vector,
            collector_xyz,
            max_iterations=max_iter_iterations,
            tolerance_m=iter_tolerance_m,
            n_sur=n_sur,
            ref_ht=ref_ht,
        )

        # Check if iterative result (if valid) matches one of the solutions
        if iter_result is not None:
            distances = [
                float(np.linalg.norm(sol.emitter_pos.xyz - iter_result.xyz))
                for sol in multi_result.solutions
            ]
            min_distance = min(distances)

            if min_distance < 100.0:  # 100m threshold  # noqa: PLR2004
                # REGIME 2: Ambiguous but solvable (0.5° - 3.0° elevation)
                # Iterative matched one of the self-consistent solutions
                best_idx = int(np.argmin(distances))
                best_sol = multi_result.solutions[best_idx]

                return MultiRegionResult(
                    emitter_pos=best_sol.emitter_pos,
                    regime=2,
                    used_fast_path=False,  # Used full search to verify
                    num_solutions=num_solutions,
                    all_solutions=None,  # Resolved - don't return all
                    iterations=num_iterations,
                    residual_rad=best_sol.residual_rad,
                    error_estimate_m=final_error,
                )

    # REGIME 3: Truly ambiguous (elevation < 0.5° or iterative didn't help)
    # Multiple self-consistent solutions, iterative doesn't help
    # Return all solutions with metadata for user discrimination

    return MultiRegionResult(
        emitter_pos=None,  # Ambiguous - no single answer
        regime=3,
        used_fast_path=False,
        num_solutions=num_solutions,
        all_solutions=multi_result.solutions,
        iterations=0,
        residual_rad=multi_result.solutions[0].residual_rad,  # Best residual
        error_estimate_m=None,
    )
