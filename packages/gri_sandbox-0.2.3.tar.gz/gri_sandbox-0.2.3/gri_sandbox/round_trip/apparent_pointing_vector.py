"""Apparent pointing vector calculations for atmospheric refraction.

This module provides functions to compute the apparent direction of arrival
of signals after atmospheric refraction effects.
"""

from __future__ import annotations

import numpy as np
from gri_utils.conversion import aer_to_xyz, xyz_to_aer


def apparent_pointing_vector_from_true(
    true_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    cone_correction_rad: float,
) -> np.ndarray:
    """Calculate the apparent pointing vector from the true pointing vector.

    Atmospheric refraction causes signals to appear to arrive from a shallower
    (lower elevation) angle than the true geometric direction. This function
    applies the cone correction to compute what the collector actually "sees".

    Args:
        true_pointing_vector: Unit vector in ECEF pointing from collector to emitter
            (the geometric straight-line direction).
        collector_xyz: Collector position in ECEF coordinates (meters).
        cone_correction_rad: Angular deflection correction in radians. Positive
            values indicate the true angle is steeper than the apparent angle.

    Returns:
        Unit vector in ECEF representing the apparent direction of arrival
        (the bent ray direction after atmospheric refraction).
    """
    # Get true elevation angle in AER (azimuth, elevation, range)
    true_aer = xyz_to_aer(collector_xyz, true_pointing_vector)
    true_elev_deg = true_aer[1]

    # Apparent elevation is shallower (lower) than true due to refraction
    apparent_elev_deg = true_elev_deg - np.rad2deg(cone_correction_rad)

    # Create apparent pointing vector with same azimuth but apparent elevation
    apparent_aer = np.array([true_aer[0], apparent_elev_deg, 1.0])
    apparent_vector = aer_to_xyz(collector_xyz, apparent_aer)

    # Normalize to unit vector
    return apparent_vector / np.linalg.norm(apparent_vector)
