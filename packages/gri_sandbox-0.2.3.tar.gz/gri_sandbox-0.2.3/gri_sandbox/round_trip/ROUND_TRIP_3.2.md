# Tropospheric Round-Trip Emitter Location - Algorithm 2

## 3.2 Algorithm 2: Residual Minimization (Full Search)

The residual minimization algorithm exhaustively searches the position space to locate all points where the correction residual approaches zero, guaranteeing discovery of all self-consistent solutions.

### Algorithm Structure

**Phase 1: Coarse Search - Find All Local Minima**

**Input parameters:**
- Latitude search range: [lat_min, lat_max], typically [-5°, +5°] or [-10°, +10°]
- Number of sample points: N_coarse, typically 400 (standard) or 1200 (2× resolution)
- Longitude: fixed at collector longitude (assume same meridian)

**Procedure:**

1. **Generate Sample Grid**
   - Create uniform latitude samples: lat_i = lat_min + i × Δlat, where Δlat = (lat_max - lat_min) / N_coarse
   - For i = 0 to N_coarse - 1

2. **Evaluate Residual at Each Sample**
   - For each lat_i:
     - Construct candidate position: P_i = (lat_i, lon_collector, alt=0)
     - **Compute correction at candidate**: δ_computed,i = DGS_correction(P_i, P_collector)
     - **Compute correction needed**:
       - Vector to candidate: v_to_candidate = (P_i - P_collector) / ||P_i - P_collector||
       - Elevation to candidate: el_candidate = AER_elevation(P_collector, v_to_candidate)
       - Elevation of apparent: el_apparent = AER_elevation(P_collector, v_apparent)
       - Correction needed: δ_needed,i = el_candidate - el_apparent (in radians)
     - **Compute residual**: R_i = |δ_computed,i - δ_needed,i|
     - Store (lat_i, R_i)

3. **Identify Local Minima**
   - Scan through residual sequence {R_i}
   - For each interior point j (1 ≤ j ≤ N_coarse - 2):
     - Check local minimum condition: R_j ≤ R_j-1 AND R_j ≤ R_j+1
     - If satisfied: record (lat_j, R_j) as coarse minimum
   - Typical result: find K = 1 to 3 local minima (usually K = 1 or K = 2)

**Phase 2: Refinement - Precision Location of Each Minimum**

For each coarse minimum k found in Phase 1:

**Input parameters:**
- Coarse minimum location: lat_coarse,k
- Initial refinement window: w_0, typically 0.2° (±0.1° around coarse minimum)
- Number of refinement stages: N_refine, typically 7 (standard) or 10 (2× resolution)
- Points per stage: M_refine, typically 50

**Procedure:**

1. **Initialize Refinement Window**
   - Center: lat_center,0 = lat_coarse,k
   - Bounds: [lat_center,0 - w_0/2, lat_center,0 + w_0/2]

2. **Iterative Refinement Loop**
   - For stage s = 1 to N_refine:

     a. **Sample Within Current Window**
        - Generate M_refine uniform samples: lat_m = lat_min,s + m × (w_s / M_refine)
        - For each sample m = 0 to M_refine - 1:
          - Compute residual R_m exactly as in coarse search
          - Track minimum: if R_m < R_best,s then R_best,s = R_m, lat_best,s = lat_m

     b. **Narrow Window for Next Stage**
        - New window width: w_s+1 = w_s / 5 (reduce by factor of 5)
        - New center: lat_center,s+1 = lat_best,s
        - New bounds: [lat_center,s+1 - w_s+1/2, lat_center,s+1 + w_s+1/2]

     c. **Convergence Check** (optional)
        - If w_s < ε_min (typically 10⁻⁵ degrees): early termination, sufficient precision

3. **Final Refined Minimum**
   - After N_refine stages: lat_refined,k = lat_best,N_refine
   - Final residual: R_refined,k = R_best,N_refine
   - Precision: window width after refinement ≈ w_0 / 5^N_refine
   - With w_0 = 0.2° and N_refine = 7: final precision ~ 0.2° / 78125 ≈ 0.0000026° ≈ 0.3 meters

**Phase 3: Filtering and Metadata Computation**

**Step 1: Filter by Residual Threshold**
- Keep only solutions where R_refined,k < τ_residual (typically τ = 10⁻⁶ radians ≈ 0.00006°)
- Discard solutions with larger residuals (not self-consistent)
- Typical result: K_filtered = 1 or 2 solutions remain

**Step 2: Compute Solution Metadata**

For each filtered solution k:

1. **Curvature (Second Derivative)**
   - Purpose: measure sharpness of residual minimum
   - Method: finite difference approximation
   - Sample points: lat_k - δ, lat_k, lat_k + δ, where δ = 0.001° (1 millidegree)
   - Compute residuals: R_minus = R(lat_k - δ), R_center = R(lat_k), R_plus = R(lat_k + δ)
   - Second derivative: κ_k = (R_plus - 2×R_center + R_minus) / δ²
   - Units: radians per degree²
   - Typical values: TRUE solutions κ ≈ 0.074, spurious-only κ ≈ 0.019, gap region κ < 0.02

2. **Consistency Error**
   - Purpose: verify that corrected ray actually intersects at candidate position
   - Method: forward propagation check
   - Compute correction at candidate: δ_k = DGS_correction(P_k, P_collector)
   - Apply to apparent vector: el_corrected = el_apparent + rad_to_deg(δ_k)
   - Reconstruct corrected vector: v_corrected = AER_to_XYZ(α_apparent, el_corrected, r=1)
   - Find intersection: P_intersection = WGS84_intersect(P_collector, v_corrected)
   - Consistency error: ε_consistency,k = ||P_k - P_intersection||
   - Units: meters
   - Ideal: ε ≈ 0 (perfect self-consistency)
   - Typical: ε < 1 km for valid solutions, ε > 1 km or ε = ∞ (no intersection) for invalid

3. **Apparent Elevation**
   - Purpose: determine what elevation this solution corresponds to
   - Method: reverse calculation from candidate to collector
   - Vector to collector: v_to_coll = (P_collector - P_k) / ||P_collector - P_k||
   - Geometric elevation (from candidate's perspective): el_geometric = AER_elevation(P_k, v_to_coll)
   - Tropospheric correction: δ_k = DGS_correction(P_k, P_collector)
   - Apparent elevation: el_apparent,k = el_geometric - rad_to_deg(δ_k)
   - Units: degrees
   - Use: helps relate solution back to original observation geometry

**Output: Complete Solution Set**

Return list of solutions, each containing:
- Position: (latitude, longitude, altitude=0)
- Residual: R_refined,k (radians)
- Curvature: κ_k (rad/deg²)
- Consistency error: ε_consistency,k (meters)
- Apparent elevation: el_apparent,k (degrees)
- Number of coarse minima found: K (used for gap detection)

### Computational Complexity

**Phase 1: Coarse Search**
- Sample points: N_coarse (400 standard, 1200 for 2×)
- Cost per point: 1 DGS evaluation + coordinate conversions (~O(1))
- **Total Phase 1: N_coarse DGS evaluations**

**Phase 2: Refinement**
- Local minima found: K (typically 1-3, average ~2)
- Stages per minimum: N_refine (7 standard, 10 for 2×)
- Points per stage: M_refine (typically 50)
- **Total Phase 2: K × N_refine × M_refine DGS evaluations**
- Standard: 2 × 7 × 50 = 700
- 2× resolution: 2 × 10 × 50 = 1000

**Phase 3: Metadata**
- Solutions after filtering: K_filtered (typically 1-2)
- Evaluations per solution: 3 (for curvature) + 1 (for consistency) = 4
- **Total Phase 3: 4 × K_filtered ≈ 4-8 DGS evaluations**

**Complete Algorithm:**
- **Standard resolution**: 400 + 700 + 8 = ~1,100 evaluations
- **2× resolution**: 1200 + 1000 + 8 = ~2,200 evaluations
- **4× resolution** (rare): 2400 + 2000 + 8 = ~4,400 evaluations

**Comparison to Iterative:**
- Standard residual: ~1,100 vs. iterative ~20 = **55× slower**
- But: finds ALL solutions, provides verification and metadata
- Worth the cost when: multiple solutions suspected, verification needed, iterative failed

**Scaling Properties:**
- Memory: O(N_coarse) for storing residual array during coarse search
- Time: O(N_coarse + K × N_refine × M_refine) where K typically ≤ 3
- Parallel potential: all K refinement loops are independent, can run concurrently
- Resolution scaling: doubling resolution (N_coarse, N_refine) approximately doubles cost

### Performance by Regime

**All Regimes: Comprehensive Detection**

The grid search reliably finds all self-consistent solutions regardless of elevation:

**Regime 1 (≥ 3.08°):**
- Finds: 1 solution (TRUE)
- Typical residual: 10⁻⁸ to 10⁻¹⁰ radians (numerical precision limit)
- Curvature: 0.05 - 0.15 (well-defined minimum)
- Consistency error: <1 meter
- Reliability: 100%

**Regime 2 (0.5° - 3.08°):**
- Finds: 2 solutions (TRUE + SPURIOUS)
- TRUE residual: 10⁻⁸ to 10⁻⁹ radians
- SPURIOUS residual: 10⁻⁸ to 10⁻⁹ radians (equally valid)
- Separation: 29 km (at 0.5°) to 344 km (at 2.0°)
- Reliability: 100% (both always found)

**Regime 3 (<0.5°):**
- Finds: 2 solutions (TRUE + SPURIOUS) at most elevations
- Both solutions have near-zero residuals
- Separation: 1-80 km depending on elevation
- Reliability: 100% when both present

**Gap Region (0.35° - 0.37°) - Standard Resolution:**
- Finds: 1 solution (SPURIOUS only)
- TRUE solution: **missed** due to extremely shallow minimum (curvature < 0.02)
- Coarse search: typically finds only 1-2 minima (indicator of missing TRUE)
- Problem: TRUE minimum too shallow for 400-point grid to detect
- **Critical failure mode**: returns spurious solution as if unambiguous

**Gap Region (0.35° - 0.37°) - 2× Resolution:**
- Finds: Variable, elevation-dependent
  - 0.40°: 2 solutions (TRUE recovered, ~35m accuracy)
  - 0.38° - 0.39°: 2 solutions sometimes (recovery rate ~20%)
  - 0.35° - 0.37°: 1 solution (SPURIOUS) usually, even with 2× resolution
- Recovery: ~20% success rate across gap region
- When recovery fails: still returns spurious only
- **Requires explicit gap detection to avoid false confidence**

### Advantages and Limitations

**Advantages:**
- Comprehensive: finds ALL self-consistent solutions in search range
- Verifiable: provides residual, curvature, consistency metrics for validation
- Regime-independent: works at any elevation (though may miss gap solutions)
- Predictable: performance scales deterministically with resolution parameters
- Parallelizable: refinement loops independent, can distribute across cores
- Metadata-rich: returns multiple discrimination metrics per solution

**Limitations:**
- Computationally expensive: 55× slower than iterative when iterative works
- Gap vulnerability: misses shallow minima at standard resolution
- Memory intensive: stores full residual array during coarse search (N_coarse × 8 bytes)
- Longitude-fixed: assumes emitter at collector meridian (generalizes to 2D grid with much higher cost)
- Resolution-precision tradeoff: finer grids are expensive, coarse grids miss shallow minima
- No analytical guarantees: grid spacing might miss arbitrarily narrow minima
