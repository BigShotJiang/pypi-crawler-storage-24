"""Tropospheric round-trip delay calculations.

This script calculates the WGS-84 ellipsoid intersection from a LEO satellite
collector's perspective back towards an emitter on Earth's surface.

For each elevation angle (0° horizon to 90° zenith), we:
1. Position an emitter at LLA(0, 0, 0)
2. Position a collector at LEO altitude (1000 km) at that elevation/azimuth
3. Calculate the ECEF pointing vector from collector back to emitter
4. Apply tropospheric corrections (angle and time delay)
5. Use WGS-84 intersection to estimate where the ray hits the ellipsoid
6. Report the estimated intersection LLA
"""

from __future__ import annotations

# ruff: noqa: T201
import numpy as np
from gri_pos import Pos
from gri_tropo.dgs import dgs_tropo_corrections

from gri_sandbox.round_trip.apparent_pointing_vector import (
    apparent_pointing_vector_from_true,
)
from gri_sandbox.round_trip.collector_position import collector_pos_at_elevation
from gri_sandbox.round_trip.find_emitter_multiregion import (
    MultiRegionResult,
    find_emitter_multiregion,
)
from gri_sandbox.round_trip.pointing_vector import calculate_pointing_vector


def main() -> None:
    """Run the tropospheric round-trip analysis."""
    # Emitter at origin (equator, prime meridian, sea level)
    emitter = Pos.LLA(0.0, 0.0, 0.0)

    # LEO altitude in meters (1000 km)
    leo_altitude_m = 1e6

    # Azimuth doesn't matter, use 0 (north)
    azimuth_deg = 0.0

    print("Tropospheric Round-Trip Analysis")
    print("=" * 80)
    print(f"Emitter LLA: {emitter.lla}")
    print(f"Emitter XYZ: {emitter.xyz}")
    print(f"LEO Altitude: {leo_altitude_m / 1e3:.1f} km")
    print("=" * 80)
    print()
    print(
        f"{'Elev (°)':>10} | {'Cone Corr (mrad)':>16} | {'Cone Corr (°)':>14} | "
        f"{'Time Corr (ns)':>14}",
    )
    print("-" * 62)

    # Collect all results for later use
    results: list[MultiRegionResult] = []

    # Iterate through elevation angles
    for elevation_deg in np.arange(-2, 0.5, 0.01):
        # Position collector at LEO altitude at this elevation angle
        collector = collector_pos_at_elevation(
            emitter,
            float(elevation_deg),
            leo_altitude_m,
            azimuth_deg,
        )

        # Calculate true pointing vector from collector back towards emitter
        # This is the geometric straight-line direction
        true_pointing_vector = calculate_pointing_vector(collector, emitter)

        # Get tropospheric corrections
        # cone_correction: angular deflection (true angle is steeper than apparent)
        # time_correction: extra propagation time through atmosphere
        cone_correction_rad, time_correction_sec = dgs_tropo_corrections(
            emitter_loc_lla=emitter.lla,
            collector_pos_xyz=collector.xyz,
        )

        # Calculate apparent pointing vector (what the collector "sees")
        apparent_pointing_vector = apparent_pointing_vector_from_true(
            true_pointing_vector,
            collector.xyz,
            cone_correction_rad,
        )

        # Convert to display units
        cone_correction_mrad = cone_correction_rad * 1000.0
        cone_correction_deg = np.rad2deg(cone_correction_rad)
        time_correction_ns = time_correction_sec * 1e9

        print(
            f"{elevation_deg:>10} | {cone_correction_mrad:>16.4f} | "
            f"{cone_correction_deg:>14.6f} | {time_correction_ns:>14.2f}",
        )

        # Now test the round-trip: from apparent pointing vector, find emitter
        result = find_emitter_multiregion(
            apparent_pointing_vector,
            collector.xyz,
        )
        results.append(result)

        if result.emitter_pos is not None:
            # Calculate error from true emitter position
            position_error_m = float(
                np.linalg.norm(result.emitter_pos.xyz - emitter.xyz),
            )
            print(
                f"           Estimated emitter: "
                f"({result.emitter_pos.lla[0]:10.6f}°, "
                f"{result.emitter_pos.lla[1]:10.6f}°, "
                f"{result.emitter_pos.lla[2]:8.1f}m)",
            )
            print(
                f"           Regime: {result.regime}, "
                f"Iterations: {result.iterations}, "
                f"Position error: {position_error_m:.3f}m",
            )
        else:
            print(
                f"           No solution found (Regime {result.regime}, "
                f"{result.num_solutions} solutions)",
            )

    print()
    print("=" * 70)
    print(f"Analysis complete. Collected {len(results)} results.")


if __name__ == "__main__":
    main()
