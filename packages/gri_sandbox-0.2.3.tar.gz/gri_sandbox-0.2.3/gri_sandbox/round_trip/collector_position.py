"""Collector position calculations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_sandbox.round_trip.slant_range import slant_range_for_altitude

if TYPE_CHECKING:
    from gri_pos import Pos


def collector_pos_at_elevation(
    emitter: Pos,
    elevation_deg: float,
    altitude_m: float,
    azimuth_deg: float = 0.0,
) -> Pos:
    """Calculate collector position at a given elevation and altitude.

    Positions a collector at the specified altitude above Earth's surface,
    along the line of sight from the emitter at the given elevation angle.

    Args:
        emitter: Emitter position.
        elevation_deg: Elevation angle in degrees from emitter (0=horizon, 90=zenith).
        altitude_m: Collector altitude above Earth surface in meters.
        azimuth_deg: Azimuth angle in degrees from emitter (0=north). Defaults to 0.

    Returns:
        Collector position as a Pos object.
    """
    slant_range = slant_range_for_altitude(elevation_deg, altitude_m)
    aer = (azimuth_deg, elevation_deg, slant_range)
    return emitter.translate_aer(aer)
