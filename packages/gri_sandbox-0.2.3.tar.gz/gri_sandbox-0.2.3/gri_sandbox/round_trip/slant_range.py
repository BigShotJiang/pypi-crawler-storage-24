"""Slant range calculations for satellite positioning."""

from __future__ import annotations

import numpy as np
from gri_utils.constants import ER_M


def slant_range_for_altitude(elevation_deg: float, altitude_m: float) -> float:
    """Calculate slant range to achieve a specific satellite altitude.

    Given an elevation angle from a ground observer and a desired satellite
    altitude, calculate the slant range (distance along the line of sight)
    needed to reach that altitude.

    Args:
        elevation_deg: Elevation angle in degrees from ground observer.
        altitude_m: Desired satellite altitude above Earth surface in meters.

    Returns:
        Slant range in meters.
    """
    elev_rad = np.radians(elevation_deg)
    sat_radius = ER_M + altitude_m

    # Quadratic formula: slant_range^2 + 2*R*sin(elev)*slant_range + (R^2 - r_sat^2) = 0
    b = 2 * ER_M * np.sin(elev_rad)
    c = ER_M**2 - sat_radius**2
    discriminant = b**2 - 4 * c

    return float((-b + np.sqrt(discriminant)) / 2)
