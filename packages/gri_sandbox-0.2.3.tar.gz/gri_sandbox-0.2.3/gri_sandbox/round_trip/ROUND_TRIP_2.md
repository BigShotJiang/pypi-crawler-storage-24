# Tropospheric Round-Trip Emitter Location - Technical Summary

## 2. Solution Sensitivity and Nonlinearity

### 2.1 Sensitivity by Elevation Range

The relationship between angular measurement uncertainty and positional error exhibits extreme nonlinearity and dramatic oscillations as a function of elevation angle. The sensitivity, measured in meters of ground position error per millidegree of angular error (m/mdeg), varies by more than 400x across the elevation range from -2° to +2°.

#### High Elevation (≥3.08°): Stable Single Solution

Above the bifurcation point at 3.08° elevation, only one self-consistent solution exists. The sensitivity decreases monotonically as elevation increases:

- **At 3.08° (bifurcation)**: ~1,900 m/mdeg
- **At 5°**: ~1,200 m/mdeg
- **At 10°**: ~600 m/mdeg
- **At 20°+**: <300 m/mdeg

The tropospheric bending at 3.08° is approximately 0.007° (25 arcseconds). The iterative algorithm always converges correctly in this regime, achieving sub-meter to meter-level accuracy within 3-5 iterations. Angular measurement precision requirements are modest: ±40 millidegrees (0.04°) would yield position errors under 80 km.

#### Medium Elevation (0.5° - 3.08°): Dual Solutions, Iterative Reliable

Two self-consistent solutions coexist in this range, but the iterative algorithm reliably converges to the correct one. Sensitivity increases as elevation decreases:

- **At 2.0°**: ~1,900 m/mdeg (±42.6 mdeg for 80 km error)
- **At 1.0°**: ~4,800 m/mdeg (±16.7 mdeg for 80 km error)
- **At 0.5°**: ~14,800 m/mdeg (±5.4 mdeg for 80 km error)

The tropospheric bending ranges from 0.009° to 0.020° (32 to 73 arcseconds) across this regime. The iterative algorithm converges in 6-20 iterations with position errors between 1 and 15 meters. The two solutions remain well-separated (29-344 km apart), and both track smoothly with angular perturbations without merging.

#### Low Elevation (0.4° - 0.5°): Transitional Regime

The transition from reliable to unreliable iterative convergence occurs sharply between 0.4° and 0.5° elevation:

- **At 0.50°**: Iterative error ~14 m, sensitivity ~14,800 m/mdeg
- **At 0.40°**: Iterative error ~1,100 m, sensitivity varies

The factor-of-80 degradation in iterative performance over just 0.1° of elevation change indicates a sharp nonlinear transition in the correction landscape structure. The tropospheric bending is approximately 0.021° (76 arcseconds) in this range.

#### Very Low Elevation (<0.4°): Complex Banded Structure

Below 0.4° elevation, sensitivity no longer increases monotonically. Instead, it exhibits dramatic oscillations with a spatial period of approximately 0.3° - 0.4°, creating alternating bands of extreme and low sensitivity:

An anomalous peak occurs at **0.3° elevation** with sensitivity of ~19,300 m/mdeg - higher than at the horizon (0°). This represents the most challenging discrimination case above 0°: solutions are only 14 km apart and require angular precision better than ±4 millidegrees for reliable discrimination. The proximity to the bifurcation boundary (0.33°) creates geometric conditions where small angular perturbations can cause solutions to disappear entirely.

**Extreme Sensitivity Bands (100,000+ m/mdeg):**

Certain narrow elevation windows exhibit extraordinary sensitivity where angular errors are amplified by factors exceeding 100× the baseline horizon value:

- **-2.0° to -1.7°**: 475,000 - 549,000 m/mdeg (68× higher than 0° horizon)
- **-1.5°**: ~426,000 m/mdeg (isolated peak)
- **-1.2° to -1.1°**: 330,000 - 354,000 m/mdeg
- **-0.8°**: ~260,000 m/mdeg
- **-0.6°**: ~213,000 m/mdeg
- **-0.3°**: ~143,000 m/mdeg

In these extreme zones, solutions are nearly parallel to each other in the correction-latitude space, meaning infinitesimal angular changes cause large positional jumps. The residual discrimination success rate drops to 50-70% due to high susceptibility to measurement noise. For the most extreme case (-2.0°), only ±0.15 millidegrees of angular uncertainty creates an 80 km error region.

**Low Sensitivity "Sweet Spots" (1,000 - 5,000 m/mdeg):**

Interspersed between the extreme bands are narrow windows where sensitivity drops dramatically:

- **-1.6°**: ~1,300 m/mdeg (422× lower than peak at -2.0°)
- **-1.4° to -1.3°**: 1,600 - 1,700 m/mdeg
- **-1.0° to -0.9°**: 2,000 - 2,200 m/mdeg
- **-0.5° to -0.4°**: 3,400 - 3,800 m/mdeg
- **-0.2° to -0.1°**: 5,400 - 6,700 m/mdeg

At these sweet spots, the solution curves cross at steeper angles in correction-latitude space, providing more stable discrimination. Residual discrimination achieves 80-100% success rates. The geometric resonance conditions that create extreme sensitivity in adjacent bands are absent or minimized.

**Horizon (0.0° elevation): High Baseline Sensitivity:**

At the mathematical horizon, sensitivity is ~8,000 m/mdeg for both the true and spurious solutions (differing by only ~1%). Solutions are separated by approximately 80.7 km. The tropospheric bending is 0.026° (94 arcseconds). This represents the baseline reference case for understanding low-elevation behavior.

An angular uncertainty of ±10 millidegrees creates ~80 km position error regions for both solutions. The error regions are discrete, non-overlapping, and approximately circular. The slant range from a 1000 km altitude collector to the horizon is ~3500 km. Simple geometric projection predicts tan(0.001°) × 3500 km ≈ 61 m, but the actual sensitivity of 8000 m represents a 130× amplification factor beyond pure geometry due to tropospheric correction feedback, Earth's curvature effects, and nonlinear position-correction coupling.

### 2.2 Why Multiple Solutions Exist

#### Physical Explanation

At low elevation angles approaching the horizon, electromagnetic signal paths become nearly tangent to Earth's surface. The troposphere's refractive index gradient, decreasing exponentially with altitude according to scale height, bends these near-tangent rays toward the surface. The bending magnitude depends on the integrated refractivity along the entire path through the atmosphere.

When the signal path is near-horizontal, small changes in emitter position create large changes in the atmospheric path geometry. A position shift of 10 km might alter the altitude profile of the ray path by hundreds of meters over a distance of thousands of kilometers. This, in turn, changes the integrated refractivity and thus the angular deflection. The relationship between position and deflection becomes highly nonlinear.

Multiple emitter positions can produce the same apparent angular observation through different combinations of geometric ray path and atmospheric correction. Consider two positions P₁ and P₂ at different latitudes but the same longitude. The ray from P₁ to the collector might pass through more lower-altitude (higher refractivity) atmosphere, producing larger angular deflection. The ray from P₂ might pass through less atmosphere or higher-altitude atmosphere, producing smaller deflection. Through the right geometric arrangement, both deflections can result in identical apparent directions at the collector.

The nonlinearity arises because the atmospheric correction itself depends on the position being solved for. This creates a circular dependency: to determine the correction, you need the position; to determine the position, you need the correction. When this feedback loop produces multiple fixed points (positions where the correction applied equals the correction computed), multiple solutions exist.

#### Mathematical Explanation: Self-Consistency

The self-consistency criterion provides the mathematical formulation of solution validity. Define the correction residual R for a candidate position P as:

```
R(P) = |C_computed(P) - C_needed(P)|
```

where:
- C_computed(P) is the tropospheric angular correction computed by the DGS model for an emitter at position P and the given collector position
- C_needed(P) is the angular correction that would be required for a ray from the apparent direction to actually intersect Earth at position P

For the true emitter position P_true, this residual equals zero: R(P_true) = 0. The tropospheric correction computed at the true position, when applied to the apparent ray, causes that ray to intersect Earth exactly at the true position. This is self-consistency.

At high elevations (>3.08°), the residual function R(P) forms a single-valley landscape with one global minimum at P_true. As elevation decreases below 3.08°, the landscape deforms and a second local minimum appears. Both minima have residual values approaching zero, meaning both corresponding positions are self-consistent fixed points of the correction equation.

The residual landscape topology changes as a function of elevation:

- **Above 3.08°**: Single deep, well-defined minimum at true position
- **2° - 3.08°**: Two minima, true minimum deeper and broader (higher curvature)
- **0.5° - 2°**: Two minima of similar depth, both well-defined
- **0.34° - 0.5°**: Two minima, but true minimum becoming shallower (lower curvature)
- **0.35° - 0.37° "gap"**: True minimum so shallow it becomes undetectable with standard grid resolution
- **Below 0.3°**: Complex multi-valley landscape with oscillating sensitivity patterns

#### The Bifurcation Point: 3.08° Elevation

The appearance of the second solution at 3.08° elevation represents a classic saddle-node bifurcation in the dynamical systems sense. Above this angle, the residual function has a single zero-crossing. As elevation decreases through 3.08°, the function's shape changes such that a second zero-crossing emerges.

The tropospheric bending at the bifurcation point is approximately 0.007° (25 arcseconds). The sensitivity is ~1,900 m/mdeg. The second solution initially appears very close to the true solution (within a few kilometers) and gradually moves further away as elevation decreases further.

Small perturbations near the bifurcation cause dramatic effects. At 0.3° elevation (0.03° below the 0.33° apparent bifurcation), a +1 millidegree angular perturbation can cause both solutions to disappear entirely - the system crosses back above the bifurcation boundary. A -1 millidegree perturbation moves both solutions ~20 km and increases their separation by 2-3×.

The mathematical structure near bifurcation exhibits critical slowing down: the iterative algorithm requires more iterations to converge, and the residual minimum becomes broader and shallower. The second derivative (curvature) of the residual function decreases from ~0.074 well above bifurcation to ~0.02 or less near bifurcation.

#### Gap Regions: 0.35° - 0.37° Elevation

Between approximately 0.35° and 0.37° elevation, the true solution exists mathematically but becomes practically undetectable. The residual minimum corresponding to the true position develops extremely low curvature (second derivative < 0.02), making it nearly flat over a wide latitude range.

A standard grid search with 400 sample points across ±10° latitude (~0.05° spacing) may entirely miss this shallow minimum. The residual at the true position might be 10⁻⁶ radians, while the residual 0.1° away might be 2×10⁻⁶ radians - a difference too small to reliably detect given numerical precision limits and the coarse sampling.

The spurious solution in this range maintains higher curvature (~0.019 average) and remains readily detectable. Consequently, the standard search algorithm finds only the spurious solution and reports a single-solution case. Without additional safeguards, this spurious answer would be returned with high confidence as if it were unambiguous.

The gap phenomenon represents a fundamental limitation of grid-based search methods. The true minimum exists but requires extraordinarily fine sampling (>1000 points) combined with multiple refinement stages (>10 stages) to reliably detect. Even then, recovery succeeds only ~20% of the time at certain elevations (0.38° - 0.40°). At the deepest gap locations (0.35° - 0.37°), the minimum remains undetectable even with 3× standard resolution.

The physical cause of the gap is the near-cancellation of competing geometric effects. As elevation decreases from the bifurcation point, the true solution's residual minimum becomes shallower because the atmospheric correction becomes increasingly sensitive to position while simultaneously the geometric ray-intersection calculation becomes less sensitive. At gap elevations, these effects nearly balance, creating an anomalously flat residual landscape around the true solution.

### 2.3 Nonlinearity and Amplification Mechanisms

The 130× amplification factor observed at 0° elevation (8,000 m/mdeg actual vs. 61 m/mdeg geometric) arises from three interacting nonlinear mechanisms:

**Tropospheric Correction Feedback**: The atmospheric correction is not constant but varies with position. A 10 km position shift at low elevation might change the correction by 0.001° (3.6 arcseconds), which in turn implies a ~8 km position change through geometric projection. This creates a positive feedback loop that amplifies initial position errors.

**Earth's Curvature Effects**: At grazing angles, Earth's curvature means that moving 10 km along the surface changes the local vertical by approximately 0.0009° (3.2 arcseconds) at 1000 km altitude. This geometric effect couples with the atmospheric correction in complex ways, especially when ray paths span thousands of kilometers.

**Nonlinear Position-Correction Coupling**: The correction function C(P) is nonlinear in position, particularly its derivatives. The rate of change ∂C/∂latitude depends on elevation angle, atmospheric parameters, and the geometric configuration. Near horizon angles, |∂C/∂latitude| can exceed 10⁻³ rad/degree, meaning a 1° latitude change causes 0.1° correction change. This strong coupling drives the sensitivity amplification.

The oscillating sensitivity pattern below 0° elevation arises from geometric resonances in the ray-Earth intersection calculation. At certain elevation angles, the ray path geometry creates conditions where solutions are nearly parallel in correction-latitude space (extreme sensitivity), while at other angles, the solutions cross at steeper angles (low sensitivity). The ~0.3° - 0.4° periodicity of these resonances relates to the angular scale over which the atmospheric correction function varies significantly at low elevations.
