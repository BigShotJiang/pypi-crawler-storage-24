# Tropospheric Round-Trip Emitter Location - Executive Summary

## Problem Domain

The inverse geolocation problem for LEO satellite collectors observing ground-based RF emitters is severely complicated by tropospheric refraction. The ITU-R P.2019 DGS model quantifies angular deflection (0.001° - 0.026°), but the inverse problem exhibits extreme nonlinearity at low elevations, creating fundamental multi-valued solutions that cannot be discriminated without additional information.

## Solution Space Characteristics

**Bifurcation at 3.08° elevation**: Above this threshold, unique solutions exist with monotonically decreasing sensitivity (300-1900 m/mdeg). Below 3.08°, two mathematically valid self-consistent solutions emerge, with separation distances ranging from 14 km (minimum at 0.3°) to 344 km (maximum at 2.0°).

**Gap region (0.34°-0.39°)**: The true solution's residual minimum develops curvature <0.02, becoming undetectable with standard grid searches. Standard 400-point searches find only the spurious solution. Adaptive 2× resolution (1200 points) recovers the true solution in ~20% of gap cases, primarily 0.38°-0.40°. Elevations 0.35°-0.37° remain fundamentally unrecoverable.

**Oscillating sensitivity below 0°**: Sensitivity varies 400× due to geometric resonances with ~0.3°-0.4° periodicity. Extreme bands reach 549,000 m/mdeg (-2.0°), requiring ±0.15 millidegree precision for 80 km accuracy. Interspersed "sweet spots" drop to 1,300 m/mdeg, relaxing requirements 400×.

## Algorithmic Strategies

**Fast iterative (20 evaluations)**: Converges in 3-20 iterations for elevations ≥0.5°. Catastrophic failure <0.5° (1-80 km errors). No ambiguity detection. Used in 73.9% of cases via adaptive approach.

**Residual minimization (400-1200 points, 750-2500 evaluations)**: Exhaustive search with 7-10 stage refinement. Finds all self-consistent solutions across all elevations. Gap vulnerability at standard resolution addressed by adaptive triggering based on low curvature (<0.02) and few coarse minima (<3) indicators.

**Multi-region adaptive (production algorithm)**: Fast path attempt with self-consistency verification, automatic fallback to grid search, gap detection triggering 2× resolution, iterative-based disambiguation when two solutions found. Average 410 evaluations weighted by observed frequencies. Returns `None` for unrecoverable gaps rather than spurious answer.

## Key Findings

**Amplification mechanisms**: Observed 8,000 m/mdeg at 0° horizon represents 130× amplification beyond geometric projection (61 m/mdeg). Caused by tropospheric correction feedback, Earth curvature coupling, and nonlinear position-correction coupling where ∂C/∂latitude exceeds 10⁻³ rad/degree.

**Disambiguation**: Above 0.5°, iterative basin of attraction naturally selects true solution despite dual solutions existing. Below 0.5°, both solutions are equally valid given only apparent observation - external constraints (terrain, multi-sensor fusion, temporal tracking) required.

**Precision requirements**: Most stringent at 0.3° elevation (±4 millidegrees for 80 km accuracy, ±0.4 millidegrees for discrimination). Typical LEO systems (5-50 millidegree precision) sufficient >1° but marginal 0.3°-1° and inadequate for extreme bands.

## Production Recommendations

Use adaptive algorithm for unknown elevations with gap detection enabled. Explicitly report `None` for 0.35°-0.37° cases (~3-5% occurrence). Return both solutions below 0.5° when disambiguation fails (~1-2% occurrence). For time-critical applications, exploit sweet spot timing strategy (100-400× sensitivity improvement at -1.6°, -1.4°, -1.0°, -0.5° versus adjacent bands).
