# Tropospheric Round-Trip Emitter Location - Technical Summary

## 4. Solution Space Visualization and Interpretation

### 4.1 Operating Regime Boundaries

The solution space exhibits distinct operating regimes separated by sharp transition boundaries:

**Regime 1 (Elevation ≥ 3.08°): Unambiguous Single Solution**

Above the bifurcation point at 3.08° elevation, only one self-consistent solution exists. The residual landscape contains a single deep, well-defined minimum at the true emitter position. Both the fast iterative algorithm and residual minimization converge reliably to this unique solution within 3-5 iterations for elevations above 5°, and 6-10 iterations between 3.08° and 5°.

The tropospheric bending is relatively modest in this regime, ranging from 0.007° (25 arcseconds) at the bifurcation point to less than 0.001° above 20° elevation. The sensitivity decreases monotonically from approximately 1,900 m/mdeg at 3.08° to under 300 m/mdeg above 20°. Position errors of 1 meter or less are typical when the iterative algorithm converges.

**Regime 2 (Elevation 0.5° - 3.08°): Dual Solutions, Iterative Reliable**

Two self-consistent solutions coexist throughout this range, but the fast iterative algorithm reliably converges to the correct one. The residual landscape contains two distinct minima, with the true solution typically having higher curvature (deeper, narrower minimum) than the spurious solution, particularly near the upper boundary.

The tropospheric bending ranges from 0.009° to 0.020° (32 to 73 arcseconds). The sensitivity increases as elevation decreases, from approximately 1,900 m/mdeg at 2.0° to 14,800 m/mdeg at 0.5°. The iterative algorithm converges in 6-20 iterations with position errors between 1 and 15 meters. The two solutions remain well-separated, with distances ranging from 29 km at 0.5° to 344 km at 2.0°.

**Regime 3 (Elevation < 0.5°): Dual Solutions, Iterative Unreliable**

Below 0.5° elevation, two solutions continue to exist but the iterative algorithm becomes unreliable. The transition from reliable to unreliable iterative performance occurs sharply between 0.4° and 0.5°, with iterative error jumping from approximately 14 m at 0.5° to over 1,100 m at 0.4° - a factor-of-80 degradation over just 0.1° of elevation change.

The tropospheric bending exceeds 0.021° (76 arcseconds) throughout this regime. The sensitivity exhibits dramatic oscillations rather than monotonic increase, creating alternating bands of extreme and low sensitivity as described in Section 2.1.

**Bifurcation Boundary (3.08° Elevation)**

The 3.08° boundary represents a saddle-node bifurcation where the second solution emerges. Above this angle, the residual function has a single zero-crossing. As elevation decreases through 3.08°, the function's shape changes such that a second zero-crossing appears. The second solution initially appears very close to the true solution (within a few kilometers) and gradually moves further away as elevation decreases.

The mathematical structure near bifurcation exhibits critical slowing down: the iterative algorithm requires more iterations to converge (approaching 20 iterations near the boundary versus 3-5 at higher elevations), and the residual minimum becomes broader and shallower. The second derivative (curvature) of the residual function decreases from approximately 0.074 well above bifurcation to 0.02 or less near bifurcation.

**Gap Region (0.34° - 0.39° Elevation)**

A narrow elevation range exists between approximately 0.34° and 0.39° where the true solution's residual minimum becomes extremely shallow. The curvature drops below 0.02, making the minimum nearly flat over a wide latitude range. Standard resolution grid searches (400 points across ±10° latitude, ~0.05° spacing) often miss this shallow minimum entirely, finding only the spurious solution.

The gap phenomenon represents the near-cancellation of competing geometric effects. As elevation decreases from the bifurcation point, the true solution's residual minimum becomes shallower because the atmospheric correction becomes increasingly sensitive to position while simultaneously the geometric ray-intersection calculation becomes less sensitive. At gap elevations, these effects nearly balance.

The deepest gap occurs between 0.35° and 0.37° elevation, where the minimum remains undetectable even with doubled-resolution searches (1200 points, 10 refinement stages). At slightly higher elevations (0.38° - 0.40°), the adaptive 2× resolution approach successfully recovers the true solution in approximately 20% of cases.

### 4.2 Sensitivity Landscape Structure

The relationship between angular measurement uncertainty and positional error varies by more than 400× across the elevation range from -2° to +2°. This variation does not follow a monotonic pattern but instead exhibits complex oscillating behavior.

**High Elevation Monotonic Decrease (≥ 3.08°)**

Above the bifurcation point, sensitivity decreases smoothly and predictably as elevation increases. The function is well-behaved with no oscillations or anomalies. The rate of decrease is approximately exponential, with sensitivity halving roughly every 5° of elevation increase in the 3° - 10° range.

**Medium Elevation Smooth Increase (0.5° - 3.08°)**

Throughout Regime 2, sensitivity increases gradually as elevation decreases, without oscillations. The increase is approximately exponential with a characteristic scale of about 1° - that is, sensitivity roughly doubles for every 1° decrease in elevation. The function remains smooth and predictable throughout this range.

An anomalous peak occurs at 0.3° elevation with sensitivity of approximately 19,300 m/mdeg - higher than at the horizon (0°) and the highest sensitivity observed above 0° elevation. This peak occurs just 0.03° below the apparent bifurcation boundary at 0.33°, where small angular perturbations can cause both solutions to disappear entirely. The geometric conditions at 0.3° create a resonance where the two solutions are only 14 km apart (the closest separation observed above 0°) and require angular precision better than ±4 millidegrees for reliable discrimination.

**Low Elevation Oscillating Pattern (< 0.5°)**

Below 0.5° elevation, sensitivity no longer increases monotonically but instead exhibits dramatic oscillations with a spatial period of approximately 0.3° - 0.4°. This creates alternating bands of extreme sensitivity (100,000+ m/mdeg) and low sensitivity "sweet spots" (1,000 - 5,000 m/mdeg).

The oscillation amplitude is extraordinary: peak sensitivity reaches 549,000 m/mdeg at -2.0° elevation (68× higher than the 8,000 m/mdeg baseline at 0° horizon), while valley sensitivity drops to just 1,300 m/mdeg at -1.6° elevation. The ratio between adjacent peak and valley values can exceed 400×.

The physical origin of this oscillating pattern lies in geometric resonances in the ray-Earth intersection calculation. At extreme sensitivity bands, the solution curves are nearly parallel in correction-latitude space, meaning infinitesimal angular changes cause large positional jumps. At low sensitivity sweet spots, the solution curves cross at steeper angles, providing more stable discrimination.

**Horizon Baseline (0.0° Elevation)**

At the mathematical horizon, sensitivity is approximately 8,000 m/mdeg for both the true and spurious solutions (differing by only ~1%). This represents the baseline reference case for understanding low-elevation behavior. The tropospheric bending is 0.026° (94 arcseconds). Solutions are separated by approximately 80.7 km.

The 8,000 m/mdeg sensitivity represents a 130× amplification factor beyond pure geometric projection. Simple geometry predicts tan(0.001°) × 3500 km ≈ 61 m for a 1000 km altitude collector with 3500 km slant range to horizon. The actual 8,000 m amplification arises from three interacting nonlinear mechanisms: tropospheric correction feedback (the correction itself varies with position), Earth's curvature effects (local vertical changes by ~0.0009° per 10 km at 1000 km altitude), and nonlinear position-correction coupling (∂C/∂latitude can exceed 10⁻³ rad/degree near horizon angles).

### 4.3 Solution Separation Distance

The distance between the two self-consistent solutions (when both exist) provides important information about discrimination difficulty and measurement precision requirements.

**Separation Versus Elevation**

The solution separation exhibits complex behavior as a function of elevation:

- **At 0.0° (horizon)**: 80.7 km separation
- **At 0.3°**: 14.0 km separation (minimum above 0°)
- **At 0.5°**: 29 km separation
- **At 1.0°**: 137 km separation
- **At 2.0°**: 344 km separation
- **At 3.08° (bifurcation)**: Solutions merge (separation → 0)

The separation distance is not monotonic. Starting from the bifurcation point at 3.08° where the solutions initially coincide, the separation increases rapidly as elevation decreases through Regime 2, reaching a maximum of approximately 344 km at 2.0° elevation. As elevation continues to decrease below 2.0°, the separation decreases, reaching a local minimum of 14 km at 0.3° elevation before increasing again toward 0°.

The 0.3° elevation represents the most challenging discrimination case above 0° for two reasons: (1) the solutions are closest together (14 km), and (2) the sensitivity is highest (19,300 m/mdeg). These factors combine to create the most stringent angular measurement requirement: better than ±4 millidegrees to achieve 80 km position accuracy.

**Separation Versus Perturbation**

The solution separation changes in response to angular perturbations in the apparent pointing vector. At 0.0° elevation with ±1 millidegree perturbation, the separation changes from the nominal 80.7 km to a range of 62.5 km to 95.5 km - approximately ±20% variation. At higher elevations (1.0°+), the separation becomes more stable with only ±7% variation for the same perturbation magnitude.

At critical elevations near the bifurcation boundary (0.3° and 0.5°), small positive angular perturbations (+1 millidegree) can cause both solutions to disappear entirely as the system crosses back above the bifurcation boundary. Small negative perturbations (-1 millidegree) cause both solutions to move dramatically (~20 km) and increase their separation by 2-3×.

**Correlation with Discrimination Success**

Solution separation directly impacts discrimination reliability. When separation exceeds 100 km (elevations above ~0.8°), discrimination methods work reliably even with modest angular precision (±10-20 millidegrees). When separation drops below 30 km (elevations below ~0.6°), discrimination requires much higher angular precision (±5 millidegrees or better).

The correlation between separation and sensitivity creates a compounding effect: elevations with small separation also tend to have high sensitivity, making discrimination doubly difficult. Conversely, elevations with large separation tend to have lower sensitivity, making discrimination easier.

### 4.4 Residual Landscape Topology

The correction residual function R(P) = |C_computed(P) - C_needed(P)| defines a landscape over emitter position space whose topology determines solution behavior.

**Regime 1 Landscape (≥ 3.08°)**

The residual landscape forms a single-valley structure with one global minimum at the true emitter position. The valley is deep (residual drops from >0.01 radians at ±5° latitude to <10⁻⁶ radians at the minimum), narrow (curvature typically 0.05 - 0.10), and well-defined with steep walls on all sides.

The landscape curvature (second derivative of residual with respect to latitude) ranges from approximately 0.074 at high elevations (10°+) to 0.030 near the bifurcation point. This high curvature ensures robust detection: even coarse grid searches with 0.1° - 0.2° spacing reliably locate the minimum, and refinement converges rapidly within 2-3 stages.

**Regime 2 Landscape (0.5° - 3.08°)**

The landscape develops a second valley as elevation drops below the bifurcation point. Initially (near 3.08°), the second valley is very shallow and close to the true minimum. As elevation decreases, the second valley deepens and moves away from the true minimum.

At mid-Regime 2 elevations (~1.5°), both valleys have similar depth (residual ~10⁻⁶ radians) but the true minimum maintains higher curvature (0.04 - 0.06) compared to the spurious minimum (0.02 - 0.04). This curvature difference provides a weak discriminator: solutions with higher curvature are more likely to be true, but this heuristic is not perfectly reliable.

Near the Regime 2/3 boundary (~0.5° - 0.7°), both minima have nearly identical depth and curvature, making discrimination by landscape features alone impossible. The iterative algorithm's convergence behavior (which minimum it naturally finds) becomes the primary discriminator.

**Regime 3 Landscape (< 0.5°)**

The landscape develops increasingly complex structure as elevation decreases below 0.5°. The two primary minima persist, but their relative positions and characteristics vary dramatically with elevation due to the oscillating sensitivity pattern.

At extreme sensitivity bands (-2.0°, -1.5°, -1.2°, -0.8°, -0.6°, -0.3°), both minima become elongated in the latitude direction, indicating near-parallel solution curves. The curvature can drop to 0.005 or less. The minima are surrounded by broad, shallow regions where the residual changes very slowly with position. This makes numerical detection challenging and causes the iterative algorithm to converge very slowly or not at all.

At low sensitivity sweet spots (-1.6°, -1.4°, -1.0°, -0.5°), both minima become narrower and deeper with curvature values of 0.02 - 0.04. The residual landscape more closely resembles the well-behaved Regime 2 structure. Discrimination by residual comparison works reliably in these elevation windows, achieving 80-100% success rates.

**Gap Region Landscape (0.34° - 0.39°)**

The gap region represents an anomalous landscape topology where the true solution's minimum becomes extraordinarily shallow. The residual at the minimum might be 10⁻⁶ radians, but the residual just 0.1° away in latitude is only 2×10⁻⁶ radians - a factor-of-two difference that is below the detection threshold given numerical precision limits and grid spacing constraints.

The curvature drops below 0.02 and can approach 0.01 or less at the deepest gap elevations (0.35° - 0.37°). The minimum becomes nearly flat over a ±0.5° latitude range. Standard grid searches with ~0.05° spacing cannot distinguish the minimum from surrounding noise: any of dozens of sample points might appear to have the "lowest" residual value within numerical precision.

The spurious solution in the gap region maintains normal curvature (0.019 average) and remains easily detectable. This asymmetry creates a dangerous situation: the search algorithm confidently returns a single solution (the spurious one) with no indication that a second (true) solution exists but was missed.

The adaptive 2× resolution approach addresses this by increasing sample density to ~0.017° spacing and using 10 refinement stages instead of 7. This finer sampling allows detection of the shallow true minimum at certain elevations (0.38° - 0.40°) where curvature is low but not quite zero. At the deepest gap elevations (0.35° - 0.37°), even doubled resolution cannot reliably detect the minimum: it would require 0.001° - 0.005° spacing (5,000 - 20,000 sample points) with 15+ refinement stages - computationally prohibitive.

### 4.5 Algorithm Selection Strategy

The choice of algorithm should adapt to the expected elevation regime and confidence requirements:

**Known High Elevation (≥ 5°)**

Use the fast iterative approach exclusively. Self-consistency checking is optional but recommended for verification. Expected performance: 3-5 iterations, sub-meter accuracy, <10 millisecond computation time. No ambiguity exists; residual minimization provides no additional value.

**Known Medium Elevation (1° - 5°)**

Use the fast iterative approach with mandatory self-consistency checking. If residual exceeds 10⁻⁶ radians, fall back to residual minimization to verify uniqueness. Expected performance: 6-15 iterations, 1-10 meter accuracy, <15 millisecond computation time. Ambiguity is unlikely but should be verified.

**Known Low Elevation (0.4° - 1°)**

Use residual minimization as primary method. Optionally run iterative approach as tie-breaker if two solutions found. Expected performance: 750-1100 evaluations, 1-50 meter accuracy, 200-400 millisecond computation time. Two solutions exist; discrimination may require external constraints.

**Known Very Low Elevation (< 0.4°)**

Use residual minimization exclusively. Expect two solutions and plan to return both unless external constraints are available. Consider sensitivity band location: if in a "sweet spot" elevation (-1.6°, -1.4°, -1.0°, -0.5°), residual-based discrimination may succeed; if in an extreme band, discrimination is unlikely. Expected performance: 750-1100 evaluations, 10-200 meter accuracy, 200-400 millisecond computation time.

**Unknown Elevation (Most Common Case)**

Use the multi-region adaptive algorithm (Algorithm 3 from Section 3.3). This tries the fast path first and automatically falls back to full search when necessary. Includes adaptive 2× resolution for gap detection. Expected performance: 73.9% of cases use fast path (~20 evaluations, <20 milliseconds); 26.1% use slow path (~1100-2200 evaluations, 200-800 milliseconds). Returns `None` for unrecoverable gap cases (0.35° - 0.37°).

**Critical Applications**

For applications requiring guaranteed solution finding (accepting ambiguity but not missing solutions), always use residual minimization with doubled resolution (1200 points, 10 stages) regardless of elevation. This maximizes detection probability at the cost of ~2500 evaluations and 800-1200 milliseconds computation time. Even this approach cannot guarantee detection in the deepest gap (0.35° - 0.37°).

**Real-Time Applications**

For applications with strict latency constraints (<50 milliseconds), use fast iterative exclusively with a timeout of 20 iterations. If convergence fails, report "ambiguous" rather than attempting slow-path resolution. This achieves 50-70% success rate across all elevations with guaranteed bounded execution time.

### 4.6 Measurement Precision Requirements

The angular measurement precision required for reliable emitter geolocation depends strongly on elevation and the desired position accuracy.

**For 80 km Position Accuracy**

To achieve position accuracy of ±80 km (2σ), the following angular precisions are required:

- **At 3.08° (bifurcation)**: ±42 millidegrees
- **At 2.0°**: ±42 millidegrees
- **At 1.0°**: ±17 millidegrees
- **At 0.5°**: ±5.4 millidegrees
- **At 0.3° (peak sensitivity)**: ±4.1 millidegrees (most stringent)
- **At 0.0° (horizon)**: ±10 millidegrees
- **At -0.5° (sweet spot)**: ±23 millidegrees
- **At -1.0° (sweet spot)**: ±40 millidegrees
- **At -1.5° (extreme)**: ±0.19 millidegrees
- **At -2.0° (peak extreme)**: ±0.15 millidegrees

The most challenging regime for achieving 80 km accuracy is the extreme sensitivity bands below 0° elevation, where sub-millidegree precision is required. The low sensitivity sweet spots offer 100-200× relaxed precision requirements compared to adjacent extreme bands.

**For Solution Discrimination**

To reliably discriminate between the two self-consistent solutions (when both exist), the angular precision must be sufficient that the error regions around each solution do not overlap. This requires precision approximately 5-10× better than the values above.

At 0.0° elevation with 80.7 km solution separation, reliable discrimination requires approximately ±1-2 millidegrees. At 0.3° elevation with only 14 km solution separation and 19,300 m/mdeg sensitivity, reliable discrimination requires approximately ±0.4-0.8 millidegrees - pushing the limits of practical measurement systems.

**For Gap Region Navigation**

In the gap region (0.34° - 0.39°), no amount of angular precision can compensate for the fundamental detection limitation. The issue is not measurement noise but rather the shallow residual minimum structure. Even with perfect angular measurements (zero noise), the standard grid search would still miss the true solution because the minimum is too flat to detect with reasonable sampling density.

The solution is not improved precision but rather improved resolution (finer sampling), which comes at computational cost rather than measurement system cost.

**Practical Implications**

Space-based collectors measuring apparent pointing vectors from LEO orbit typically achieve angular precision of 5-50 millidegrees depending on signal characteristics, antenna aperture, and integration time. This precision is:

- Sufficient for reliable geolocation above 1° elevation
- Marginal for discrimination at 0.3° - 1° elevation
- Insufficient for reliable discrimination below 0.3° elevation
- Completely inadequate for extreme sensitivity bands below 0° elevation

For low-elevation targets, either improved measurement systems (larger apertures, longer integration) or acceptance of fundamental ambiguity is required. The oscillating sensitivity pattern suggests a strategy: time the measurement to occur when the target is at a low-sensitivity sweet spot elevation rather than an extreme band, improving effective precision by 100-400× without hardware changes.
