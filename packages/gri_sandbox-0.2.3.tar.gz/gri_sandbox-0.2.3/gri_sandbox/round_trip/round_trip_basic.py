"""Tropospheric round-trip delay calculations.

This script calculates the WGS-84 ellipsoid intersection from a LEO satellite
collector's perspective back towards an emitter on Earth's surface.

For each elevation angle (0° horizon to 90° zenith), we:
1. Position an emitter at LLA(0, 0, 0)
2. Position a collector at LEO altitude (1000 km) at that elevation/azimuth
3. Calculate the ECEF pointing vector from collector back to emitter
4. Use WGS-84 intersection to estimate where the ray hits the ellipsoid
5. Report the estimated intersection LLA
"""

from __future__ import annotations

# ruff: noqa: T201
from gri_pos import Pos

from gri_sandbox.patent_paper.calculate_wgs84_intersection import (
    calculate_wgs84_intersection,
)
from gri_sandbox.round_trip.collector_position import collector_pos_at_elevation
from gri_sandbox.round_trip.pointing_vector import calculate_pointing_vector


def main() -> None:
    """Run the tropospheric round-trip analysis."""
    # Emitter at origin (equator, prime meridian, sea level)
    emitter = Pos.LLA(0.0, 0.0, 0.0)

    # LEO altitude in meters (1000 km)
    leo_altitude_m = 1e6

    # Azimuth doesn't matter, use 0 (north)
    azimuth_deg = 0.0

    print("Tropospheric Round-Trip Analysis")
    print("=" * 70)
    print(f"Emitter LLA: {emitter.lla}")
    print(f"Emitter XYZ: {emitter.xyz}")
    print(f"LEO Altitude: {leo_altitude_m / 1e3:.1f} km")
    print("=" * 70)
    print()
    print(
        f"{'Elev (°)':>10} | {'Collector LLA':^40} | {'Intersection LLA':^40}",
    )
    print("-" * 95)

    # Iterate through elevation angles from 0 (horizon) to 90 (zenith)
    for elevation_deg in range(0, 91, 10):
        # Position collector at LEO altitude at this elevation angle
        collector = collector_pos_at_elevation(
            emitter,
            elevation_deg,
            leo_altitude_m,
            azimuth_deg,
        )

        # Calculate pointing vector from collector back towards emitter
        pointing_vector = calculate_pointing_vector(collector, emitter)

        # Find where this ray intersects the WGS-84 ellipsoid
        intersection_xyz = calculate_wgs84_intersection(
            collector.xyz,
            pointing_vector,
        )

        if intersection_xyz is not None:
            intersection = Pos.XYZ(intersection_xyz)
            intersection_str = (
                f"({intersection.lla[0]:8.4f}°, "
                f"{intersection.lla[1]:8.4f}°, "
                f"{intersection.lla[2]:8.1f}m)"
            )
        else:
            intersection_str = "No intersection"

        collector_str = (
            f"({collector.lla[0]:8.4f}°, "
            f"{collector.lla[1]:8.4f}°, "
            f"{collector.lla[2] / 1e3:8.1f}km)"
        )

        print(f"{elevation_deg:>10} | {collector_str:^40} | {intersection_str:^40}")

    print()
    print("=" * 70)
    print("Analysis complete.")


if __name__ == "__main__":
    main()
