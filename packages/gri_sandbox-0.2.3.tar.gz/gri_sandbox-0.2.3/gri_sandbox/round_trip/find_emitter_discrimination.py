"""Find emitter with discrimination for ambiguous cases.

This module provides `find_emitter_multiregion_with_discrimination`, the
recommended function for finding emitters across all elevation angles. It
wraps `find_emitter_multiregion` and adds automatic discrimination in
Regime 3 (very low elevation angles) where multiple valid solutions exist.

Usage:
    from gri_sandbox.round_trip.find_emitter_discrimination import (
        find_emitter_multiregion_with_discrimination,
    )

    result = find_emitter_multiregion_with_discrimination(
        apparent_pointing_vector,
        collector_xyz,
    )

    if result.emitter_pos is not None:
        # Got a single best answer
        emitter = result.emitter_pos
    elif result.all_solutions:
        # Ambiguous - got 2 solutions but couldn't discriminate
        for sol in result.all_solutions:
            print(f"Candidate at {sol.emitter_pos.lla}")
    else:
        # No solution found
        pass

Discrimination Techniques:
1. Residual comparison (2x threshold): TRUE solution typically has lower residual
2. Curvature comparison (1.5x threshold): TRUE solution typically has higher curvature

See ROUND_TRIP_3.md for detailed documentation on solution regimes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_sandbox.round_trip.find_emitter_multiregion import find_emitter_multiregion
from gri_sandbox.round_trip.multiregion_result import MultiRegionResult

if TYPE_CHECKING:
    import numpy as np
    from numpy.typing import NDArray


def find_emitter_multiregion_with_discrimination(  # noqa: PLR0913
    apparent_pointing_vector: NDArray[np.floating],
    collector_xyz: NDArray[np.floating],
    max_iter_iterations: int = 20,
    iter_tolerance_m: float = 1.0,
    residual_threshold_rad: float = 1e-6,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> MultiRegionResult:
    """Find emitter with automatic discrimination in Regime 3.

    This is the recommended function for finding emitters across all elevation
    angles. It uses the fast iterative path at high elevations (≥0.5°) and
    falls back to residuals search with discrimination at low elevations.

    At low elevations (<0.5°), tropospheric refraction creates two valid
    "self-consistent" solutions: the TRUE emitter location and a SPURIOUS
    location. This function attempts to discriminate between them using:

    1. Residual comparison: TRUE solution typically has 2x+ lower residual
    2. Curvature comparison: TRUE solution typically has 1.5x+ higher curvature

    Behavior by regime:
    - Regime 1 (≥3.08°): Single solution, returned directly
    - Regime 2 (0.5°-3.08°): Two solutions, iterative picks correct one
    - Regime 3 (<0.5°): Two solutions, discrimination attempted:
        - If discrimination succeeds: returns single emitter_pos
        - If discrimination fails: returns emitter_pos=None with all_solutions

    Args:
        apparent_pointing_vector: Apparent direction vector (unit, ECEF).
        collector_xyz: Collector position in ECEF meters.
        max_iter_iterations: Maximum iterations for fast iterative approach.
        iter_tolerance_m: Convergence tolerance for iterative approach.
        residual_threshold_rad: Residual threshold for self-consistency check.
        n_sur: Surface refractivity in N-units.
        ref_ht: Atmospheric scale height in km.

    Returns:
        MultiRegionResult with:
        - emitter_pos: Best solution if unambiguous or discriminated, else None
        - regime: Solution regime (1, 2, or 3)
        - used_fast_path: Whether fast iterative was used
        - num_solutions: Number of self-consistent solutions found
        - all_solutions: All candidates if ambiguous and unresolved, else None
        - residual_rad: Final correction residual in radians
    """
    # Start with base multi-region approach
    result = find_emitter_multiregion(
        apparent_pointing_vector,
        collector_xyz,
        max_iter_iterations,
        iter_tolerance_m,
        residual_threshold_rad,
        n_sur,
        ref_ht,
    )

    # If not Regime 3, return as-is
    if result.regime != 3 or result.all_solutions is None:  # noqa: PLR2004
        return result

    # REGIME 3: Try additional discrimination
    # At very low elevations (< 0.5°), the TRUE solution typically has:
    # 1. Lower residual (better fit to the self-consistency equation)
    # 2. Higher curvature (sharper minimum in residual landscape)

    solutions = result.all_solutions

    if len(solutions) < 2:  # noqa: PLR2004
        # Only one solution - return as-is
        return result

    # Sort by residual (ascending - lower is better)
    solutions_by_residual = sorted(
        solutions,
        key=lambda s: s.residual_rad,
    )

    best_by_residual = solutions_by_residual[0]
    worst_by_residual = solutions_by_residual[-1]

    # Try residual discrimination first (more reliable at sweet spots)
    # If TRUE solution has significantly lower residual, use it
    if worst_by_residual.residual_rad > 0:
        residual_ratio = worst_by_residual.residual_rad / best_by_residual.residual_rad

        if residual_ratio > 2.0:  # 2x lower residual  # noqa: PLR2004
            # Confident discrimination by residual
            return MultiRegionResult(
                emitter_pos=best_by_residual.emitter_pos,
                regime=3,  # Still Regime 3, but resolved
                used_fast_path=False,
                num_solutions=len(solutions),
                all_solutions=None,  # Resolved
                iterations=result.iterations,
                residual_rad=best_by_residual.residual_rad,
                error_estimate_m=None,
            )

    # Try curvature discrimination as fallback
    # Sort by curvature (descending - higher is better)
    solutions_by_curvature = sorted(
        solutions,
        key=lambda s: s.curvature,
        reverse=True,
    )

    best_by_curvature = solutions_by_curvature[0]

    curvature_ratio = (
        solutions_by_curvature[0].curvature / solutions_by_curvature[1].curvature
    )

    if curvature_ratio > 1.5:  # 50% higher curvature  # noqa: PLR2004
        # Confident discrimination by curvature
        return MultiRegionResult(
            emitter_pos=best_by_curvature.emitter_pos,
            regime=3,  # Still Regime 3, but resolved
            used_fast_path=False,
            num_solutions=len(solutions),
            all_solutions=None,  # Resolved
            iterations=result.iterations,
            residual_rad=best_by_curvature.residual_rad,
            error_estimate_m=None,
        )

    # Could not discriminate - return all solutions
    return result
