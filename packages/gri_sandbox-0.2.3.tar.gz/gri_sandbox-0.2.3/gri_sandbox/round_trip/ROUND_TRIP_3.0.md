# Tropospheric Round-Trip Emitter Location - Technical Summary

## 3. Solution Algorithms

### Key Concepts: Residual and Curvature

Before describing the algorithms, it is essential to understand two metrics used throughout: **residual** and **curvature**. These metrics serve different purposes: residual measures solution validity, while curvature indicates solution reliability.

#### Residual: Measuring Self-Consistency

The **residual** quantifies how well a candidate emitter location satisfies the self-consistency equation. A valid solution must be a "fixed point" where the tropospheric correction mathematics close properly.

**Computation:**

Given a candidate emitter position P_candidate, the residual is computed as:

1. **Compute the correction that would apply**: Using the DGS tropospheric model, calculate the cone angle correction δ_computed for a ray traveling from P_candidate to the collector position.

2. **Compute the correction needed**: From the apparent pointing vector (what the collector measured), determine the geometric elevation to P_candidate. The difference between this geometric elevation and the apparent elevation gives the correction that would be *needed* to explain the observation: δ_needed = el_geometric - el_apparent.

3. **Residual**: The absolute difference between computed and needed corrections:
   ```
   R = |δ_computed - δ_needed|
   ```
   Units: radians (typically 10⁻⁸ to 10⁻¹² for valid solutions)

**Interpretation:**

- **R ≈ 0** (< 10⁻⁶ rad): The candidate is **self-consistent**. If you placed an emitter there, the tropospheric bending would produce exactly the apparent angle that was observed. This is a valid solution.

- **R >> 0**: The candidate is **not self-consistent**. The physics doesn't close—the correction computed for this geometry doesn't match what would be needed to explain the observation.

**Why Both TRUE and SPURIOUS Solutions Have Low Residuals:**

At low elevation angles, tropospheric refraction creates a multi-valued inverse problem. Two different emitter locations can both produce the same apparent pointing vector at the collector—both satisfy the self-consistency equation, so both have residuals near zero.

However, while both solutions are mathematically valid, they are not identical:
- The **TRUE** solution represents the actual physical geometry
- The **SPURIOUS** solution is a mathematical artifact where the equations happen to close

Empirically, the TRUE solution typically has a *slightly* lower residual (often 2× or more lower) because small numerical approximations in the tropospheric model accumulate differently for each geometry. This difference enables **residual-based discrimination**: when one solution has significantly lower residual than another, it is likely the TRUE solution.

**Discrimination threshold**: If one solution has 2× or greater lower residual than the other, the algorithm confidently selects it as TRUE.

#### Curvature: Measuring Minimum Sharpness

The **curvature** (second derivative) measures how "sharp" or "well-defined" a residual minimum is. When searching for solutions by sweeping across candidate latitudes and computing residuals, solutions appear as local minima in this residual landscape.

**Computation:**

At a solution location lat_k, curvature is approximated via finite differences:

```
κ = (R(lat_k + δ) - 2×R(lat_k) + R(lat_k - δ)) / δ²
```

Where δ is a small offset (typically 0.001°) and R(lat) is the residual at latitude lat.

Units: radians per degree²

**Interpretation:**

- **High curvature (κ > 0.05)**: Sharp, V-shaped minimum. The residual rises steeply as you move away from the solution. The optimizer finds it reliably, and the solution is well-determined.

- **Low curvature (κ < 0.02)**: Shallow, flat minimum. The residual barely changes over a wide latitude range. Easy to miss in a coarse search, and indicates a potentially problematic solution.

**Empirical Values:**
- TRUE solutions: average κ ≈ 0.074
- SPURIOUS solutions (when both found): similar to TRUE
- SPURIOUS-only solutions (gap region): average κ ≈ 0.019

**Use in Suspicious Solution Detection:**

Curvature serves as a "canary in the coal mine" for the gap region (0.34°-0.39° elevation). In this region, the TRUE solution's minimum becomes extremely shallow while the SPURIOUS solution remains well-defined. Standard-resolution searches find only the SPURIOUS solution.

When the algorithm finds a single solution with low curvature (κ < 0.02), it indicates:
1. This might be the SPURIOUS solution
2. A TRUE solution might exist but was missed due to its shallow minimum
3. Higher-resolution search should be attempted

Combined with the "few coarse minima" indicator (finding <3 local minima during coarse search), low curvature triggers adaptive 2× resolution retry.

**Curvature-Based Discrimination:**

When two solutions are found and residual discrimination fails (similar residuals), curvature can serve as a secondary discriminator. The TRUE solution typically has 1.5× or higher curvature than the SPURIOUS solution, indicating a more physically well-defined geometry.

#### Summary: Residual vs. Curvature

| Metric | What it Measures | Use Case |
|--------|-----------------|----------|
| **Residual** | Solution validity (self-consistency) | Discriminating between two valid solutions |
| **Curvature** | Minimum sharpness (detectability) | Detecting suspicious single solutions |

- **Residual** tells you *if* a location is a valid solution
- **Curvature** tells you *how reliably* that solution can be found
- Low residual + high curvature = confident, well-determined solution
- Low residual + low curvature = valid but potentially missed TRUE companion
