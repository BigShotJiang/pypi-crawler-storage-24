"""Result dataclass for multi-region emitter location.

This module defines the MultiRegionResult dataclass used by the multi-region
emitter finding algorithms.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gri_pos import Pos


@dataclass
class MultiRegionResult:
    """Result from multi-region emitter location.

    This dataclass contains the result of running find_emitter_multiregion or
    find_emitter_multiregion_with_discrimination.

    Attributes:
        emitter_pos: Best emitter position, or None if ambiguous/not found.
        regime: Solution regime classification:
            - 0: Error state (no solutions found)
            - 1: Unambiguous (single solution, elevation ≥3.08°)
            - 2: Ambiguous but solvable (two solutions, iterative resolved)
            - 3: Truly ambiguous (two solutions, requires discrimination)
        used_fast_path: Whether the fast iterative path was used.
        num_solutions: Number of self-consistent solutions found.
        all_solutions: All solutions if ambiguous (Regime 3), otherwise None.
        iterations: Number of iterations used in solution.
        residual_rad: Final correction residual in radians.
        error_estimate_m: Estimated position error in meters (if available).
        used_adaptive_resolution: Whether adaptive resolution was triggered.
    """

    emitter_pos: Pos | None
    """Best emitter position, or None if ambiguous."""

    regime: int
    """Solution regime: 0 (error), 1 (unambiguous), 2 (ambiguous but solvable),
    3 (truly ambiguous)."""

    used_fast_path: bool
    """Whether the fast iterative path was used."""

    num_solutions: int
    """Number of self-consistent solutions found."""

    all_solutions: list | None
    """All solutions if ambiguous (Regime 3), otherwise None."""

    iterations: int
    """Number of iterations used in solution."""

    residual_rad: float
    """Final correction residual in radians."""

    error_estimate_m: float | None
    """Estimated position error in meters (if available)."""

    used_adaptive_resolution: bool = False
    """Whether adaptive resolution was triggered to find missing solutions."""
