"""Demo of gri_plot Ellipsoid - 3D covariance visualization."""

from __future__ import annotations

import numpy as np
from gri_plot import DEFAULT_COLORS, Ellipsoid, Figure3D


def main() -> None:
    """Generate covariance matrices and display as 3D ellipsoids."""
    # Two uncertainty ellipsoids representing different solution qualities
    center = np.array([0.0, 0.0, 0.0])

    # Tight horizontal, elongated vertical (typical GNSS)
    cov_gnss = np.array(
        [
            [4.0, 1.0, 0.5],
            [1.0, 4.0, 0.5],
            [0.5, 0.5, 25.0],
        ],
    )

    # More spherical uncertainty (well-conditioned solution)
    cov_good = np.array(
        [
            [9.0, 0.0, 0.0],
            [0.0, 9.0, 0.0],
            [0.0, 0.0, 9.0],
        ],
    )

    fig = Figure3D(title="Covariance Ellipsoids")
    fig.add_surface(
        Ellipsoid(center, covariance=cov_gnss, label="Typical GNSS"),
        color=DEFAULT_COLORS[0],
    )
    fig.add_surface(
        Ellipsoid(center, covariance=cov_good, label="Isotropic"),
        color=DEFAULT_COLORS[1],
    )
    fig.show()


if __name__ == "__main__":
    main()
