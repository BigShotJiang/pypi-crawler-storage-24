"""Demo of gri_plot.scatter_map() - geographic scatter plots."""

from __future__ import annotations

import numpy as np
from gri_plot import scatter_map

RNG = np.random.default_rng(42)

# Colorado School of Mines, Golden, CO
CSM_LAT = 39.7514
CSM_LON = -105.2231


def main() -> None:
    """Generate clusters near Colorado School of Mines."""
    # Simulate two solution clusters with different accuracies
    n_points = 50

    # High-accuracy solution (tight cluster) - row 0 = lats, row 1 = lons
    good = np.array(
        [
            CSM_LAT + RNG.standard_normal(n_points) * 0.0001,
            CSM_LON + RNG.standard_normal(n_points) * 0.0001,
        ],
    )

    # Lower-accuracy solution (wider spread)
    poor = np.array(
        [
            CSM_LAT + 0.0003 + RNG.standard_normal(n_points) * 0.0003,
            CSM_LON + 0.0003 + RNG.standard_normal(n_points) * 0.0003,
        ],
    )

    scatter_map(
        good,
        poor,
        zoom=17,
        marker_sizes=[8, 6],
        marker_colors=["#00ff88", "#ff6b6b"],
    )


if __name__ == "__main__":
    main()
