"""Visualizations for TDOA geolocation Monte Carlo statistical validation.

Plots the normalized miss distance distribution against the theoretical
chi-squared(3) distribution to verify covariance calibration.

Run with:
    python -m gri_sandbox.plots.tdoa_monte_carlo
"""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from gri_geosim.geolocation import tdoa_locator
from gri_utils.observables import get_tdoa
from plotly.subplots import make_subplots
from scipy.stats import chi2, kstest

EARTH_RADIUS = 6378137.0
SPEED_OF_LIGHT = 299792458.0
HEO_ALTITUDE = 35_786_000.0  # HEO apogee altitude (~35,786 km, similar to GEO)

# Dark theme template
DARK_TEMPLATE = "plotly_dark"


def _create_good_geometry() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Create test geometry with HEO collectors observing an Earth emitter.

    Creates 4 HEO satellites with north-south latitude diversity observing an
    emitter on the Earth's surface, yielding 6 unique TDOA pairs. This geometry
    provides well-conditioned, low-correlation error estimates in all 3 dimensions.

    Note: TDOA works better with HEO/GEO satellites than LEO because the longer
    baselines between satellites make the time differences less sensitive to
    small timing errors. The north-south latitude spread ensures 3D observability.

    Returns:
        Tuple of (collector1_xyz, collector2_xyz, target_xyz) where collector
        arrays define the pairs for TDOA measurements.
    """
    # Emitter on Earth surface (lat ~30N equivalent position)
    target_xyz = np.array(
        [
            EARTH_RADIUS * np.cos(np.radians(30)),
            0.0,
            EARTH_RADIUS * np.sin(np.radians(30)),
        ],
    )

    # HEO collectors with latitude diversity for 3D observability
    heo_radius = EARTH_RADIUS + HEO_ALTITUDE

    # Create 4 HEO satellites with good geometry for TDOA:
    # - Spread in both longitude AND latitude for full 3D observability
    # - Each pair of satellites has north-south diversity
    collectors = np.array(
        [
            # Satellite 1: Northern latitude, central longitude
            [
                heo_radius * np.cos(np.radians(40)) * np.cos(np.radians(0)),
                heo_radius * np.cos(np.radians(40)) * np.sin(np.radians(0)),
                heo_radius * np.sin(np.radians(40)),
            ],
            # Satellite 2: Southern latitude, east
            [
                heo_radius * np.cos(np.radians(-30)) * np.cos(np.radians(50)),
                heo_radius * np.cos(np.radians(-30)) * np.sin(np.radians(50)),
                heo_radius * np.sin(np.radians(-30)),
            ],
            # Satellite 3: Southern latitude, west
            [
                heo_radius * np.cos(np.radians(-30)) * np.cos(np.radians(-50)),
                heo_radius * np.cos(np.radians(-30)) * np.sin(np.radians(-50)),
                heo_radius * np.sin(np.radians(-30)),
            ],
            # Satellite 4: Northern latitude, offset longitude
            [
                heo_radius * np.cos(np.radians(35)) * np.cos(np.radians(-70)),
                heo_radius * np.cos(np.radians(35)) * np.sin(np.radians(-70)),
                heo_radius * np.sin(np.radians(35)),
            ],
        ],
    )

    # Create all 6 unique pairs from 4 collectors
    n_collectors = 4
    pairs = [(i, j) for i in range(n_collectors) for j in range(i + 1, n_collectors)]
    collector1_xyz = np.array([collectors[i] for i, _ in pairs])
    collector2_xyz = np.array([collectors[j] for _, j in pairs])

    return collector1_xyz, collector2_xyz, target_xyz


def run_monte_carlo(
    n_trials: int = 1000,
    tdoa_sigma: float = 1e-6,  # 1 μs timing noise
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Run Monte Carlo simulation for TDOA geolocation.

    Args:
        n_trials: Number of Monte Carlo trials.
        tdoa_sigma: TDOA measurement noise (1-sigma, seconds). Default 1 μs.
        seed: Random seed for reproducibility.

    Returns:
        Tuple of (normalized_miss_sq, position_errors, target_true).
    """
    rng = np.random.default_rng(seed)

    collector1_xyz, collector2_xyz, target_true = _create_good_geometry()
    n_pairs = len(collector1_xyz)

    tdoa_variances = np.full(n_pairs, tdoa_sigma**2)

    # Compute true TDOAs for each pair
    true_tdoa = np.array(
        [
            get_tdoa(target_true, collector1_xyz[i], collector2_xyz[i])
            for i in range(n_pairs)
        ],
    )

    normalized_miss_sq = []
    position_errors = []

    for _ in range(n_trials):
        noise = rng.standard_normal(n_pairs) * tdoa_sigma
        noisy_tdoa = true_tdoa + noise

        result = tdoa_locator(
            collector1_xyz,
            collector2_xyz,
            noisy_tdoa,
            tdoa_variances,
        )

        delta = result.position - target_true
        cov_inv = np.linalg.inv(result.covariance)
        d_sq = delta @ cov_inv @ delta
        normalized_miss_sq.append(d_sq)
        position_errors.append(delta)

    return np.array(normalized_miss_sq), np.array(position_errors), target_true


def plot_chi2_histogram(normalized_miss_sq: np.ndarray) -> go.Figure:
    """Plot histogram of normalized miss distance vs chi-squared(3) PDF.

    Args:
        normalized_miss_sq: Array of normalized miss distance squared values.

    Returns:
        Plotly figure with histogram and theoretical PDF overlay.
    """
    fig = go.Figure()

    # Histogram of empirical data
    fig.add_trace(
        go.Histogram(
            x=normalized_miss_sq,
            nbinsx=50,
            histnorm="probability density",
            name="Empirical",
            marker_color="rgba(99, 110, 250, 0.7)",
            marker_line_color="rgba(99, 110, 250, 1)",
            marker_line_width=1,
        ),
    )

    # Theoretical chi-squared(3) PDF
    x_theory = np.linspace(0, max(15, np.max(normalized_miss_sq)), 200)
    pdf_theory = chi2.pdf(x_theory, df=3)

    fig.add_trace(
        go.Scatter(
            x=x_theory,
            y=pdf_theory,
            mode="lines",
            name="chi-sq(3) Theory",
            line={"color": "#EF553B", "width": 3},
        ),
    )

    # Add vertical lines for key percentiles
    p95_theory = chi2.ppf(0.95, df=3)
    p95_empirical = np.percentile(normalized_miss_sq, 95)

    fig.add_vline(
        x=p95_theory,
        line_dash="dash",
        line_color="#00CC96",
        annotation_text=f"95% theory: {p95_theory:.2f}",
        annotation_position="top right",
    )
    fig.add_vline(
        x=p95_empirical,
        line_dash="dot",
        line_color="#AB63FA",
        annotation_text=f"95% empirical: {p95_empirical:.2f}",
        annotation_position="top left",
    )

    # Statistics annotation
    mean_d_sq = np.mean(normalized_miss_sq)
    var_d_sq = np.var(normalized_miss_sq)
    _, p_value = kstest(normalized_miss_sq, chi2(3).cdf)

    stats_text = (
        f"<b>Statistics:</b><br>"
        f"Mean: {mean_d_sq:.3f} (theory: 3.0)<br>"
        f"Var: {var_d_sq:.3f} (theory: 6.0)<br>"
        f"KS p-value: {p_value:.4f}"
    )

    fig.add_annotation(
        x=0.98,
        y=0.98,
        xref="paper",
        yref="paper",
        text=stats_text,
        showarrow=False,
        font={"size": 12},
        align="left",
        bgcolor="rgba(0,0,0,0.5)",
        bordercolor="rgba(255,255,255,0.3)",
        borderwidth=1,
        borderpad=8,
        xanchor="right",
        yanchor="top",
    )

    fig.update_layout(
        template=DARK_TEMPLATE,
        title="TDOA Normalized Miss Distance Distribution vs chi-sq(3)",
        xaxis_title="Normalized Miss Distance Squared (d^2)",
        yaxis_title="Probability Density",
        legend={"x": 0.7, "y": 0.5},
        bargap=0.05,
    )

    return fig


def plot_qq(normalized_miss_sq: np.ndarray) -> go.Figure:
    """Plot Q-Q plot of normalized miss distance vs chi-squared(3).

    Args:
        normalized_miss_sq: Array of normalized miss distance squared values.

    Returns:
        Plotly figure with Q-Q plot.
    """
    fig = go.Figure()

    # Sort empirical data
    sorted_data = np.sort(normalized_miss_sq)
    n = len(sorted_data)

    # Theoretical quantiles
    percentiles = (np.arange(1, n + 1) - 0.5) / n
    theoretical_quantiles = chi2.ppf(percentiles, df=3)

    # Q-Q scatter
    fig.add_trace(
        go.Scatter(
            x=theoretical_quantiles,
            y=sorted_data,
            mode="markers",
            name="Q-Q Points",
            marker={"color": "#636EFA", "size": 4, "opacity": 0.6},
        ),
    )

    # Reference line (y=x)
    max_val = max(theoretical_quantiles[-1], sorted_data[-1])
    fig.add_trace(
        go.Scatter(
            x=[0, max_val],
            y=[0, max_val],
            mode="lines",
            name="Perfect Fit (y=x)",
            line={"color": "#EF553B", "dash": "dash", "width": 2},
        ),
    )

    fig.update_layout(
        template=DARK_TEMPLATE,
        title="TDOA Q-Q Plot: Empirical vs chi-sq(3) Distribution",
        xaxis_title="Theoretical Quantiles (chi-sq(3))",
        yaxis_title="Empirical Quantiles",
        xaxis={"scaleanchor": "y", "scaleratio": 1},
    )

    return fig


def plot_position_errors(position_errors: np.ndarray) -> go.Figure:
    """Plot 3D scatter of position errors.

    Args:
        position_errors: Array of position error vectors (n_trials x 3).

    Returns:
        Plotly figure with 3D scatter plot.
    """
    fig = go.Figure()

    fig.add_trace(
        go.Scatter3d(
            x=position_errors[:, 0],
            y=position_errors[:, 1],
            z=position_errors[:, 2],
            mode="markers",
            marker={
                "size": 2,
                "color": np.sqrt(np.sum(position_errors**2, axis=1)),
                "colorscale": "Viridis",
                "colorbar": {"title": "Error (m)"},
                "opacity": 0.6,
            },
            name="Position Errors",
        ),
    )

    # Add origin marker
    fig.add_trace(
        go.Scatter3d(
            x=[0],
            y=[0],
            z=[0],
            mode="markers",
            marker={"size": 8, "color": "#EF553B", "symbol": "cross"},
            name="True Position",
        ),
    )

    fig.update_layout(
        template=DARK_TEMPLATE,
        title="TDOA 3D Position Error Distribution",
        scene={
            "xaxis_title": "X Error (m)",
            "yaxis_title": "Y Error (m)",
            "zaxis_title": "Z Error (m)",
            "aspectmode": "cube",
        },
    )

    return fig


def plot_noise_scaling(
    n_trials: int = 500,
    seed: int = 123,
) -> go.Figure:
    """Plot how position error scales with measurement noise.

    Args:
        n_trials: Number of Monte Carlo trials per noise level.
        seed: Random seed for reproducibility.

    Returns:
        Plotly figure showing error vs noise relationship.
    """
    rng = np.random.default_rng(seed)

    collector1_xyz, collector2_xyz, target_true = _create_good_geometry()
    n_pairs = len(collector1_xyz)

    true_tdoa = np.array(
        [
            get_tdoa(target_true, collector1_xyz[i], collector2_xyz[i])
            for i in range(n_pairs)
        ],
    )

    # Noise levels from 100 ns to 5 μs
    noise_levels = np.array([100e-9, 500e-9, 1e-6, 2e-6, 3e-6, 5e-6])
    mean_errors = []
    std_errors = []

    for tdoa_sigma in noise_levels:
        tdoa_variances = np.full(n_pairs, tdoa_sigma**2)

        errors = []
        for _ in range(n_trials):
            noise = rng.standard_normal(n_pairs) * tdoa_sigma
            noisy_tdoa = true_tdoa + noise

            result = tdoa_locator(
                collector1_xyz,
                collector2_xyz,
                noisy_tdoa,
                tdoa_variances,
            )
            error = np.linalg.norm(result.position - target_true)
            errors.append(error)

        mean_errors.append(np.mean(errors))
        std_errors.append(np.std(errors))

    mean_errors = np.array(mean_errors)
    std_errors = np.array(std_errors)

    fig = go.Figure()

    # Error bars
    fig.add_trace(
        go.Scatter(
            x=noise_levels * 1e9,  # Convert to nanoseconds
            y=mean_errors,
            error_y={"type": "data", "array": std_errors, "visible": True},
            mode="markers+lines",
            name="Mean Position Error",
            marker={"size": 10, "color": "#636EFA"},
            line={"width": 2},
        ),
    )

    # Theoretical scaling (linear with noise)
    # Error ~ sigma * c / sqrt(geometry_factor)
    scale = mean_errors[2] / noise_levels[2]  # Normalize to 10ns point
    theoretical = noise_levels * scale

    fig.add_trace(
        go.Scatter(
            x=noise_levels * 1e9,
            y=theoretical,
            mode="lines",
            name="Linear Scaling Reference",
            line={"color": "#EF553B", "dash": "dash", "width": 2},
        ),
    )

    fig.update_layout(
        template=DARK_TEMPLATE,
        title="Position Error vs TDOA Measurement Noise",
        xaxis_title="TDOA Noise (ns, 1-sigma)",
        yaxis_title="Position Error (m)",
    )

    return fig


def _create_heo_constellation(
    n_collectors: int,
    target_xyz: np.ndarray,  # noqa: ARG001
) -> np.ndarray:
    """Create an HEO constellation with north-south latitude diversity.

    Distributes satellites at HEO altitude with alternating north/south latitudes
    and spread in longitude. This ensures every pair of satellites has some
    north-south diversity, which is critical for 3D TDOA observability.

    Args:
        n_collectors: Number of satellites in the constellation.
        target_xyz: Target position on Earth surface (unused, kept for API consistency).

    Returns:
        Array of collector positions (n_collectors x 3).
    """
    heo_radius = EARTH_RADIUS + HEO_ALTITUDE

    collectors = np.zeros((n_collectors, 3))

    # Distribute satellites with alternating north/south latitudes
    # and spread evenly in longitude
    for i in range(n_collectors):
        # Alternate between northern and southern latitudes
        # Use different magnitudes for variety
        if i % 2 == 0:  # noqa: SIM108
            lat = 35 + (i % 4) * 5  # 35°, 40°, 35°, 40° N
        else:
            lat = -30 - (i % 4) * 5  # -30°, -35°, -30°, -35° S

        # Spread evenly in longitude
        lon = (i * 360 / n_collectors) - 90  # Start at -90° and spread

        lat_rad = np.radians(lat)
        lon_rad = np.radians(lon)

        collectors[i] = np.array(
            [
                heo_radius * np.cos(lat_rad) * np.cos(lon_rad),
                heo_radius * np.cos(lat_rad) * np.sin(lon_rad),
                heo_radius * np.sin(lat_rad),
            ],
        )

    return collectors


def plot_collector_count_effect() -> go.Figure:
    """Plot how covariance trace decreases with more HEO collectors.

    Returns:
        Plotly figure showing trace vs collector count.
    """
    tdoa_sigma = 1e-6  # 1 μs

    # Minimum 4 satellites for unconstrained 3D TDOA geolocation.
    # With n satellites, there are n-1 independent TDOA measurements.
    # 3 satellites give only 2 independent TDOAs (insufficient for 3D).
    collector_counts = [4, 5, 6, 7, 8, 10]
    traces = []

    # Emitter on Earth surface
    target_true = np.array(
        [
            EARTH_RADIUS * np.cos(np.radians(30)),
            0.0,
            EARTH_RADIUS * np.sin(np.radians(30)),
        ],
    )

    for n_collectors in collector_counts:
        collectors = _create_heo_constellation(n_collectors, target_true)

        # Create all unique pairs: n*(n-1)/2
        pairs = [
            (i, j) for i in range(n_collectors) for j in range(i + 1, n_collectors)
        ]

        collector1_xyz = np.array([collectors[i] for i, _ in pairs])
        collector2_xyz = np.array([collectors[j] for _, j in pairs])
        n_pairs = len(pairs)

        tdoa_measurements = np.array(
            [
                get_tdoa(target_true, collector1_xyz[i], collector2_xyz[i])
                for i in range(n_pairs)
            ],
        )
        tdoa_variances = np.full(n_pairs, tdoa_sigma**2)

        result = tdoa_locator(
            collector1_xyz,
            collector2_xyz,
            tdoa_measurements,
            tdoa_variances,
        )
        traces.append(np.trace(result.covariance))

    traces = np.array(traces)

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=collector_counts,
            y=np.sqrt(traces),  # Convert to RMS position error
            mode="markers+lines",
            name="RMS Position Uncertainty",
            marker={"size": 10, "color": "#636EFA"},
            line={"width": 2},
            hovertemplate="%{x} collectors<br>RMS: %{y:.1f} m<extra></extra>",
        ),
    )

    # Theoretical 1/sqrt(n) scaling (normalized to first point)
    ref_idx = 0
    scale = np.sqrt(traces[ref_idx]) * np.sqrt(collector_counts[ref_idx])
    theoretical = scale / np.sqrt(collector_counts)

    fig.add_trace(
        go.Scatter(
            x=collector_counts,
            y=theoretical,
            mode="lines",
            name="1/sqrt(n) Scaling Reference",
            line={"color": "#EF553B", "dash": "dash", "width": 2},
        ),
    )

    fig.update_layout(
        template=DARK_TEMPLATE,
        title="Position Uncertainty vs Number of Collectors",
        xaxis_title="Number of Collectors",
        yaxis_title="RMS Position Uncertainty (m)",
        xaxis={"type": "log"},
        yaxis={"type": "log"},
    )

    return fig


def plot_dashboard(n_trials: int = 1000) -> go.Figure:
    """Create a comprehensive dashboard with all Monte Carlo visualizations.

    Args:
        n_trials: Number of Monte Carlo trials.

    Returns:
        Plotly figure with subplots.
    """
    # Run Monte Carlo
    normalized_miss_sq, position_errors, _ = run_monte_carlo(n_trials=n_trials)

    # Create subplots
    fig = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=[
            "chi-sq Distribution Validation",
            "Q-Q Plot",
            "Position Error Cloud (XY)",
            "Error vs Collector Count",
        ],
        specs=[
            [{"type": "xy"}, {"type": "xy"}],
            [{"type": "xy"}, {"type": "xy"}],
        ],
        vertical_spacing=0.12,
        horizontal_spacing=0.1,
    )

    # --- Subplot 1: Histogram ---
    x_theory = np.linspace(0, 15, 200)
    pdf_theory = chi2.pdf(x_theory, df=3)

    fig.add_trace(
        go.Histogram(
            x=normalized_miss_sq,
            nbinsx=40,
            histnorm="probability density",
            name="Empirical",
            marker_color="rgba(99, 110, 250, 0.7)",
            showlegend=True,
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=x_theory,
            y=pdf_theory,
            mode="lines",
            name="chi-sq(3)",
            line={"color": "#EF553B", "width": 2},
        ),
        row=1,
        col=1,
    )

    # --- Subplot 2: Q-Q Plot ---
    sorted_data = np.sort(normalized_miss_sq)
    n = len(sorted_data)
    percentiles = (np.arange(1, n + 1) - 0.5) / n
    theoretical_quantiles = chi2.ppf(percentiles, df=3)

    fig.add_trace(
        go.Scatter(
            x=theoretical_quantiles,
            y=sorted_data,
            mode="markers",
            name="Q-Q",
            marker={"color": "#636EFA", "size": 3, "opacity": 0.5},
            showlegend=False,
        ),
        row=1,
        col=2,
    )
    max_val = max(theoretical_quantiles[-1], sorted_data[-1])
    fig.add_trace(
        go.Scatter(
            x=[0, max_val],
            y=[0, max_val],
            mode="lines",
            name="y=x",
            line={"color": "#EF553B", "dash": "dash"},
            showlegend=False,
        ),
        row=1,
        col=2,
    )

    # --- Subplot 3: Position errors XY view ---
    fig.add_trace(
        go.Scatter(
            x=position_errors[:, 1],
            y=position_errors[:, 2],
            mode="markers",
            name="Errors",
            marker={
                "color": np.sqrt(np.sum(position_errors**2, axis=1)),
                "colorscale": "Viridis",
                "size": 3,
                "opacity": 0.5,
            },
            showlegend=False,
        ),
        row=2,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=[0],
            y=[0],
            mode="markers",
            marker={"color": "#EF553B", "size": 10, "symbol": "cross"},
            showlegend=False,
        ),
        row=2,
        col=1,
    )

    # --- Subplot 4: Collector count effect (HEO geometry) ---
    tdoa_sigma = 1e-6  # 1 μs
    collector_counts = [4, 5, 6, 7, 8, 10]
    traces_cov = []
    n_pairs_list = []

    # Emitter on Earth surface
    target_true = np.array(
        [
            EARTH_RADIUS * np.cos(np.radians(30)),
            0.0,
            EARTH_RADIUS * np.sin(np.radians(30)),
        ],
    )

    for n_collectors in collector_counts:
        collectors = _create_heo_constellation(n_collectors, target_true)

        pairs = [
            (i, j) for i in range(n_collectors) for j in range(i + 1, n_collectors)
        ]

        collector1_xyz = np.array([collectors[i] for i, _ in pairs])
        collector2_xyz = np.array([collectors[j] for _, j in pairs])
        n_pairs = len(pairs)
        n_pairs_list.append(n_pairs)

        tdoa_measurements = np.array(
            [
                get_tdoa(target_true, collector1_xyz[i], collector2_xyz[i])
                for i in range(n_pairs)
            ],
        )
        tdoa_variances = np.full(n_pairs, tdoa_sigma**2)

        result = tdoa_locator(
            collector1_xyz,
            collector2_xyz,
            tdoa_measurements,
            tdoa_variances,
        )
        traces_cov.append(np.sqrt(np.trace(result.covariance)))

    fig.add_trace(
        go.Scatter(
            x=collector_counts,
            y=traces_cov,
            mode="markers+lines",
            name="RMS Uncertainty",
            marker={"size": 8, "color": "#636EFA"},
            showlegend=False,
        ),
        row=2,
        col=2,
    )

    # Statistics text
    mean_d_sq = np.mean(normalized_miss_sq)
    var_d_sq = np.var(normalized_miss_sq)
    _, p_value = kstest(normalized_miss_sq, chi2(3).cdf)

    fig.add_annotation(
        x=0.25,
        y=0.52,
        xref="paper",
        yref="paper",
        text=(
            f"<b>Stats:</b> mu={mean_d_sq:.2f} (3.0), "
            f"sigma^2={var_d_sq:.2f} (6.0), KS p={p_value:.3f}"
        ),
        showarrow=False,
        font={"size": 11},
        bgcolor="rgba(0,0,0,0.5)",
    )

    # Update axes labels
    fig.update_xaxes(title_text="d^2", row=1, col=1)
    fig.update_yaxes(title_text="Density", row=1, col=1)
    fig.update_xaxes(title_text="Theoretical", row=1, col=2)
    fig.update_yaxes(title_text="Empirical", row=1, col=2)
    fig.update_xaxes(title_text="Y Error (m)", row=2, col=1)
    fig.update_yaxes(title_text="Z Error (m)", row=2, col=1)
    fig.update_xaxes(title_text="# Collectors", row=2, col=2)
    fig.update_yaxes(title_text="RMS (m)", type="log", row=2, col=2)

    fig.update_layout(
        template=DARK_TEMPLATE,
        title=f"TDOA Monte Carlo Validation Dashboard (n={n_trials})",
        height=800,
        showlegend=True,
        legend={"x": 0.4, "y": 0.55},
    )

    return fig


def main() -> None:
    """Run all visualizations."""
    normalized_miss_sq, position_errors, _ = run_monte_carlo(n_trials=1000)

    # Individual plots
    fig1 = plot_chi2_histogram(normalized_miss_sq)
    fig1.show()

    fig2 = plot_qq(normalized_miss_sq)
    fig2.show()

    fig3 = plot_position_errors(position_errors)
    fig3.show()

    fig4 = plot_noise_scaling()
    fig4.show()

    fig5 = plot_collector_count_effect()
    fig5.show()

    # Dashboard
    fig_dashboard = plot_dashboard(n_trials=1000)
    fig_dashboard.show()


if __name__ == "__main__":
    main()
