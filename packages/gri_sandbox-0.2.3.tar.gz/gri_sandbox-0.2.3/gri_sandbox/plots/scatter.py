"""Demo of gri_plot.scatter() - simple Plotly scatter plots."""

from __future__ import annotations

import numpy as np
from gri_plot import scatter

RNG = np.random.default_rng(42)


def main() -> None:
    """Generate synthetic data and demonstrate scatter plot capabilities."""
    # Damped sinc - characteristic impulse response shape
    t = np.linspace(-2, 8, 300)
    sinc = np.sinc(t)  # sin(πt)/(πt)
    damped_sinc = sinc * np.exp(-t / 3)
    noisy = damped_sinc + 0.05 * RNG.standard_normal(len(t))

    scatter(
        (t, noisy, {"name": "Measured", "mode": "markers", "marker": {"size": 4}}),
        (t, damped_sinc, {"name": "Ideal", "line": {"width": 2}}),
        title="Scatter Plot Demo",
        xaxis_title="Time (s)",
        yaxis_title="Amplitude",
    )


if __name__ == "__main__":
    main()
