"""Demonstration module for gri-plot plotting utilities.

This module showcases the plotting capabilities available in gri-plot:
- scatter(): Plotly scatter plots with flexible input formats
- scatter_map(): Geographic scatter maps with satellite imagery
- plot_ellipsoid(): 3D covariance ellipsoid visualization
- aoa_monte_carlo: AOA geolocation Monte Carlo validation visualizations
- tdoa_monte_carlo: TDOA geolocation Monte Carlo validation visualizations
- fdoa_monte_carlo: FDOA geolocation Monte Carlo validation visualizations
- hybrid_monte_carlo: Hybrid AOA+TDOA geolocation Monte Carlo validation
- hybrid_fdoa_monte_carlo: Hybrid TDOA+FDOA geolocation Monte Carlo validation
"""
