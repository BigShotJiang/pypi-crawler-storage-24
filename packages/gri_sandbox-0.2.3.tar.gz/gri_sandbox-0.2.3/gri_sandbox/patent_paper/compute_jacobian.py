"""Compute Jacobian matrix of partial derivatives for IWLSA.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .calculate_clock_cone_aoa import calculate_clock_cone_aoa

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def _wrap_angle(angle: float, lower: float = -180.0, upper: float = 180.0) -> float:
    """Wrap angle to specified range.

    Args:
        angle: Angle to wrap.
        lower: Lower bound of range (default: -180.0).
        upper: Upper bound of range (default: 180.0).

    Returns:
        Wrapped angle in [lower, upper) range.
    """
    range_size = upper - lower
    return ((angle - lower) % range_size) + lower


def compute_jacobian(
    emitter_estimate_xyz_m: NDArray[np.floating] | Sequence[float],
    receiver_positions_xyz_m: NDArray[np.floating] | Sequence[float],
    delta_m: float = 1.0,
) -> NDArray[np.floating]:
    """Compute Jacobian matrix of observation partial derivatives.

    The Jacobian (A matrix) contains partial derivatives of the observations
    (clock and cone angles) with respect to the emitter position (x, y, z).

    For N observations, the Jacobian is a Nx2x3 tensor:
        A[i,j,k] = ∂observation[i,j] / ∂position[k]

    Where:
        - i indexes the observation number (0 to N-1)
        - j indexes the observation type (0=clock, 1=cone)
        - k indexes position component (0=x, 1=y, 2=z)

    This implementation uses numerical differentiation (finite differences).

    Args:
        emitter_estimate_xyz_m: Current emitter position estimate [x,y,z] in ECEF.
        receiver_positions_xyz_m: Nx3 array of receiver positions in ECEF meters.
        delta_m: Step size for finite difference calculation (default: 1.0 meter).

    Returns:
        Nx2x3 Jacobian matrix. For use in IWLSA, reshape to (2N)x3.

    References:
        Patent US20110309983A1, Equations 8-10 and matrix A definition.

    Notes:
        The patent provides analytical derivatives in Equations 8-19, but this
        implementation uses numerical differentiation for simplicity and robustness.
        For production use, analytical derivatives would be more efficient.
    """
    # Convert inputs to arrays (no-op if already arrays)
    emitter_estimate_xyz_m = np.asarray(emitter_estimate_xyz_m)
    receiver_positions_xyz_m = np.asarray(receiver_positions_xyz_m)

    n_obs = receiver_positions_xyz_m.shape[0]
    jacobian = np.zeros((n_obs, 2, 3))

    # Compute base observations at current estimate
    base_observations = np.zeros((n_obs, 2))
    for i in range(n_obs):
        clock, cone = calculate_clock_cone_aoa(
            emitter_estimate_xyz_m,
            receiver_positions_xyz_m[i],
        )
        base_observations[i] = [clock, cone]

    # Compute partial derivatives using central differences
    for dim in range(3):  # x, y, z
        # Create perturbed positions
        delta_vec = np.zeros(3)
        delta_vec[dim] = delta_m

        pos_plus = emitter_estimate_xyz_m + delta_vec
        pos_minus = emitter_estimate_xyz_m - delta_vec

        # Compute observations at perturbed positions
        for i in range(n_obs):
            # Forward perturbation
            clock_plus, cone_plus = calculate_clock_cone_aoa(
                pos_plus,
                receiver_positions_xyz_m[i],
            )

            # Backward perturbation
            clock_minus, cone_minus = calculate_clock_cone_aoa(
                pos_minus,
                receiver_positions_xyz_m[i],
            )

            # Central difference: (f(x+h) - f(x-h)) / (2h)
            # Wrap the angular difference to handle azimuth wraparound
            clock_diff = _wrap_angle(clock_plus - clock_minus)
            d_clock_dx = clock_diff / (2.0 * delta_m)
            d_cone_dx = (cone_plus - cone_minus) / (2.0 * delta_m)

            jacobian[i, 0, dim] = d_clock_dx  # ∂clock/∂position[dim]
            jacobian[i, 1, dim] = d_cone_dx  # ∂cone/∂position[dim]

    return jacobian
