"""Create Line-of-Position (LOP) representation from clock/cone angles.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

import numpy as np

from .calculate_ecef_pointing_vector import calculate_ecef_pointing_vector

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class LineOfPosition(TypedDict):
    """Line-of-Position representation.

    Attributes:
        origin_xyz_m: Origin point of the line (receiver position) in ECEF [x,y,z].
        direction: Unit direction vector in ECEF [dx,dy,dz].
        clock_deg: Clock/azimuth angle in degrees.
        cone_deg: Cone angle in degrees.
    """

    origin_xyz_m: NDArray[np.floating]
    direction: NDArray[np.floating]
    clock_deg: float
    cone_deg: float


def create_lop_from_clock_cone(
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
    clock_deg: float,
    cone_deg: float,
) -> LineOfPosition:
    """Create 3D Line-of-Position from receiver position and angles.

    A Line-of-Position (LOP) is a ray in 3D space defined by:
    - An origin point (receiver position)
    - A direction vector (from clock/cone angles)

    Any point on the LOP can be expressed as:
        P(t) = origin + t * direction, for t >= 0

    Args:
        receiver_xyz_m: Receiver/collector position [x,y,z] in ECEF meters.
        clock_deg: Clock/azimuth angle in degrees (0=North, 90=East).
        cone_deg: Cone angle in degrees (0=horizon, 90=nadir, -90=zenith).

    Returns:
        LineOfPosition dictionary containing:
            - origin_xyz_m: Ray origin (receiver position)
            - direction: Unit direction vector
            - clock_deg: Clock angle (for reference)
            - cone_deg: Cone angle (for reference)

    References:
        Patent US20110309983A1, three-dimensional LOP definition.

    Notes:
        The LOP represents all possible emitter locations consistent with the
        measured angles from this receiver. The actual emitter location is
        determined by intersecting the LOP with terrain or by combining multiple
        LOPs (triangulation).
    """
    # Convert inputs to arrays (no-op if already arrays)
    receiver_xyz_m = np.asarray(receiver_xyz_m)

    # Get unit direction vector from angles
    direction = calculate_ecef_pointing_vector(receiver_xyz_m, clock_deg, cone_deg)

    return LineOfPosition(
        origin_xyz_m=receiver_xyz_m.copy(),
        direction=direction,
        clock_deg=float(clock_deg),
        cone_deg=float(cone_deg),
    )
