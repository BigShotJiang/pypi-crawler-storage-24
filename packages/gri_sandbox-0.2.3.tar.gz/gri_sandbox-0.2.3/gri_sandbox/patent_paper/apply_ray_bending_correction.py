"""Apply atmospheric refraction correction to pointing vector.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
Uses ITU-R 2019 tropospheric correction model from gri_tropo.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_tropo.dgs import dgs_tropo_corrections
from gri_utils.conversion import aer_to_xyz, xyz_to_aer, xyz_to_lla

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def apply_ray_bending_correction(
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
    pointing_vector: NDArray[np.floating] | Sequence[float],
    emitter_xyz_m: NDArray[np.floating] | Sequence[float],
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> NDArray[np.floating]:
    """Apply atmospheric refraction correction to pointing vector.

    Atmospheric refraction causes the apparent angle of arrival to be "more shallow"
    (less steep) than the actual straight-line angle. This function corrects the
    pointing vector to account for ray bending through the atmosphere.

    Uses the ITU-R 2019 tropospheric model (via gri_tropo) to calculate the
    angular deflection correction.

    Args:
        receiver_xyz_m: Receiver/collector position [x, y, z] in ECEF meters.
                        Accepts array or sequence (list/tuple).
        pointing_vector: Apparent unit direction vector [dx, dy, dz] in ECEF.
                         Accepts array or sequence (list/tuple).
        emitter_xyz_m: Estimated emitter position [x, y, z] in ECEF meters.
                       Accepts array or sequence (list/tuple).
        n_sur: Surface refractivity in N-units (default: 315.0, global mean).
        ref_ht: Atmospheric scale height in km (default: 7.35, global mean).

    Returns:
        Corrected unit pointing vector [dx, dy, dz] in ECEF accounting for
        atmospheric refraction.

    References:
        Patent US20110309983A1 - ray-bending correction for depression angle.
        ITU-R 2019 - tropospheric propagation model implementation in gri_tropo.

    Notes:
        The patent mentions ray-bending but doesn't specify the model. We use
        the ITU-R 2019 standard atmospheric model which is well-established for
        angle-of-arrival corrections in geolocation systems.
    """
    # Convert inputs to arrays (no-op if already arrays)
    receiver_xyz_m = np.asarray(receiver_xyz_m)
    pointing_vector = np.asarray(pointing_vector)
    emitter_xyz_m = np.asarray(emitter_xyz_m)

    # Convert emitter position to LLA for tropospheric correction
    emitter_lla = xyz_to_lla(emitter_xyz_m)

    # Get tropospheric cone correction using ITU-R 2019 model
    # Returns (cone_correction_rad, time_correction_sec)
    cone_correction_rad, _ = dgs_tropo_corrections(
        emitter_loc_lla=emitter_lla,
        collector_pos_xyz=receiver_xyz_m,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    # The cone_correction_rad is the angular deflection
    # We need to rotate the pointing vector by this amount

    # Get the current elevation angle
    aer = xyz_to_aer(receiver_xyz_m, pointing_vector)
    azimuth_deg = aer[0]
    elevation_deg = aer[1]

    # Apply correction to elevation (convert correction from radians to degrees)
    # The refraction makes angles appear more shallow, so we add the correction
    # to get the actual (steeper) angle
    correction_deg = np.rad2deg(cone_correction_rad)
    corrected_elevation_deg = elevation_deg + correction_deg

    # Create corrected pointing vector with same azimuth but corrected elevation
    corrected_aer = np.array([azimuth_deg, corrected_elevation_deg, 1.0])
    corrected_vector = aer_to_xyz(receiver_xyz_m, corrected_aer)

    # Normalize to ensure unit vector
    magnitude = np.linalg.norm(corrected_vector)
    if magnitude > 0:
        corrected_unit_vector = corrected_vector / magnitude
    else:
        # Shouldn't happen, but return original if it does
        corrected_unit_vector = pointing_vector

    return corrected_unit_vector
