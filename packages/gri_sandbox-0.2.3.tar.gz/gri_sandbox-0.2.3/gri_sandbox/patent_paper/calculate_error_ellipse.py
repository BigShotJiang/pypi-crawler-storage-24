"""Calculate error ellipse from measurement uncertainty cone.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

import numpy as np
from gri_utils.conversion import xyz_to_aer

from .calculate_wgs84_intersection import calculate_wgs84_intersection

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class ErrorEllipse(TypedDict):
    """Error ellipse parameters.

    Attributes:
        center_xyz_m: Center of ellipse in ECEF coordinates [x, y, z] meters.
        semi_major_m: Semi-major axis length in meters.
        semi_minor_m: Semi-minor axis length in meters.
        orientation_deg: Orientation angle in degrees (0=North, 90=East).
    """

    center_xyz_m: NDArray[np.floating]
    semi_major_m: float
    semi_minor_m: float
    orientation_deg: float


def calculate_error_ellipse(
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
    pointing_vector: NDArray[np.floating] | Sequence[float],
    uncertainty_angle_deg: float,
) -> ErrorEllipse:
    """Calculate error ellipse from measurement uncertainty cone on surface.

    Projects the uncertainty cone (defined by the pointing vector and half-angle)
    onto the WGS-84 ellipsoid surface to create an error ellipse.

    The uncertainty cone represents the angular measurement error. This function
    approximates the ellipse by calculating the projection at the nominal range.

    Args:
        receiver_xyz_m: Receiver/collector position [x, y, z] in ECEF meters.
        pointing_vector: Unit direction vector [dx, dy, dz] in ECEF (normalized).
        uncertainty_angle_deg: Cone half-angle uncertainty in degrees (1-sigma).

    Returns:
        ErrorEllipse dictionary containing:
            - center_xyz_m: Center point of ellipse on surface (ECEF)
            - semi_major_m: Semi-major axis length in meters
            - semi_minor_m: Semi-minor axis length in meters
            - orientation_deg: Orientation of major axis (degrees from North)

    References:
        Patent US20110309983A1, Figures 6-8, error region generation.

    Notes:
        This is a simplified approximation. The actual error region is formed by
        the intersection of a cone with the Earth's surface, which creates an
        ellipse. The shape depends on the range and angles involved.
    """
    # Convert inputs to arrays (no-op if already arrays)
    receiver_xyz_m = np.asarray(receiver_xyz_m)
    pointing_vector = np.asarray(pointing_vector)

    # Get nominal intersection point (center of error ellipse)
    center = calculate_wgs84_intersection(receiver_xyz_m, pointing_vector)

    if center is None:
        # No intersection - return degenerate ellipse
        return ErrorEllipse(
            center_xyz_m=receiver_xyz_m,
            semi_major_m=0.0,
            semi_minor_m=0.0,
            orientation_deg=0.0,
        )

    # Calculate range from receiver to surface intersection
    range_m = np.linalg.norm(center - receiver_xyz_m)

    # Convert uncertainty angle to radians
    uncertainty_rad = np.deg2rad(uncertainty_angle_deg)

    # For small angles, the cone projects approximately as a circle
    # with radius = range * tan(uncertainty_angle)
    # For larger ranges/angles, the projection becomes elliptical
    radius_m = range_m * np.tan(uncertainty_rad)

    # Get elevation angle of pointing vector to determine ellipse eccentricity
    vec_m = center - receiver_xyz_m
    aer = xyz_to_aer(receiver_xyz_m, vec_m)
    elevation_deg = aer[1]
    azimuth_deg = aer[0]

    # At low elevation angles, the cone projection becomes elongated
    # Semi-major axis is in the range direction (radial from receiver)
    # Semi-minor axis is perpendicular (cross-range)
    elevation_rad = np.deg2rad(elevation_deg)

    if elevation_rad < -np.pi / 4:  # Below -45 degrees (looking down steeply)
        # Steep angle - cone projects more circularly
        semi_major_m = radius_m / np.cos(elevation_rad + np.pi / 2)
        semi_minor_m = radius_m
        # Major axis points away from receiver (radial direction)
        orientation_deg = azimuth_deg
    else:
        # Shallow angle or looking up - more elongated projection
        # The elongation factor increases as elevation approaches horizon
        elongation = 1.0 / max(np.cos(elevation_rad), 0.1)
        semi_major_m = radius_m * elongation
        semi_minor_m = radius_m
        # Major axis aligned with range direction
        orientation_deg = azimuth_deg

    return ErrorEllipse(
        center_xyz_m=center,
        semi_major_m=float(semi_major_m),
        semi_minor_m=float(semi_minor_m),
        orientation_deg=float(orientation_deg),
    )
