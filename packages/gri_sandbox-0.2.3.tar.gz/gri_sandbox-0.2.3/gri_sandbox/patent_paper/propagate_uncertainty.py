"""Propagate angle measurement uncertainties to position covariance.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .compute_jacobian import compute_jacobian

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def propagate_uncertainty(
    emitter_xyz_m: NDArray[np.floating] | Sequence[float],
    observations: NDArray[np.floating] | Sequence[float],
    receiver_positions_xyz_m: NDArray[np.floating] | Sequence[float],
    angle_uncertainties_deg: NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Propagate angle measurement uncertainties to position covariance matrix.

    Uses first-order uncertainty propagation (linearization) to compute the
    covariance matrix of the emitter position estimate given the uncertainties
    in the angle measurements.

    The covariance propagates as:
        Cov(x) = (AᵀW⁻¹A)⁻¹

    Where:
        - A is the Jacobian matrix (∂observations/∂position)
        - W⁻¹ is the observation covariance matrix

    Args:
        emitter_xyz_m: Estimated emitter position [x,y,z] in ECEF meters.
        observations: Nx2 array of measured [clock_deg, cone_deg] angles.
        receiver_positions_xyz_m: Nx3 array of receiver positions in ECEF meters.
        angle_uncertainties_deg: Nx2 array of 1-sigma uncertainties
                                 [clock_std_deg, cone_std_deg].

    Returns:
        3x3 covariance matrix in ECEF coordinates (meters²).
        Diagonal elements are variances (σ²) in x, y, z.
        Off-diagonal elements are covariances.

    References:
        Patent US20110309983A1, Equations 55-57 for error region calculation.

    Notes:
        This is a linearized (first-order) approximation. For large uncertainties
        or highly nonlinear geometry, the actual uncertainty region may differ
        from the predicted ellipsoid.

        The returned covariance assumes uncorrelated angle measurements. If
        measurements are correlated, the observation covariance matrix would
        need off-diagonal terms.
    """
    # Convert inputs to arrays (no-op if already arrays)
    emitter_xyz_m = np.asarray(emitter_xyz_m)
    observations = np.asarray(observations)
    receiver_positions_xyz_m = np.asarray(receiver_positions_xyz_m)
    angle_uncertainties_deg = np.asarray(angle_uncertainties_deg)

    n_obs = observations.shape[0]

    # Compute Jacobian matrix (Nx2x3, reshape to 2Nx3)
    jac_tensor = compute_jacobian(emitter_xyz_m, receiver_positions_xyz_m)
    a = jac_tensor.reshape(2 * n_obs, 3)

    # Construct observation covariance matrix (2N x 2N)
    # Assuming uncorrelated measurements, this is diagonal
    obs_variances = np.zeros(2 * n_obs)
    for i in range(n_obs):
        obs_variances[2 * i] = angle_uncertainties_deg[i, 0] ** 2  # clock variance
        obs_variances[2 * i + 1] = angle_uncertainties_deg[i, 1] ** 2  # cone variance

    # Observation covariance matrix (diagonal)
    c_obs = np.diag(obs_variances)

    # Weight matrix is inverse of observation covariance
    # For diagonal matrix, inverse is just reciprocal of diagonal elements
    try:
        w = np.linalg.inv(c_obs)
    except np.linalg.LinAlgError:
        # If singular (zero uncertainties), use pseudo-inverse
        w = np.linalg.pinv(c_obs)

    # Position covariance: C_x = (AᵀWA)⁻¹
    atw = a.T @ w  # 3 x 2N
    atwa = atw @ a  # 3 x 3

    try:
        c_x = np.linalg.inv(atwa)
    except np.linalg.LinAlgError:
        # Singular matrix - use pseudo-inverse
        c_x = np.linalg.pinv(atwa)

    return c_x
