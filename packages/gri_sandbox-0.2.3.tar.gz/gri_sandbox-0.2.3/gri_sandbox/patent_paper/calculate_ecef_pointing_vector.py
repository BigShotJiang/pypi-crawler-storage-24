"""Calculate ECEF pointing vector from receiver position and clock/cone angles.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.conversion import aer_to_xyz

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def calculate_ecef_pointing_vector(
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
    clock_deg: float,
    cone_deg: float,
) -> NDArray[np.floating]:
    """Calculate ECEF unit pointing vector from receiver and clock/cone angles.

    Given a receiver position and angle-of-arrival measurements (clock and cone),
    this function computes the unit vector in ECEF coordinates pointing from the
    receiver toward the emitter.

    Uses clock and cone angle convention where:
    - Clock angle (θ) = azimuth angle
    - Cone angle (φ) = angle from horizon (0=horizon, 90=nadir, -90=zenith)

    Args:
        receiver_xyz_m: Receiver/collector position [x, y, z] in ECEF meters.
        clock_deg: Clock/azimuth angle in degrees (0=North, 90=East).
        cone_deg: Cone angle in degrees (0=horizon, 90=nadir, -90=zenith).

    Returns:
        Unit vector [x, y, z] in ECEF pointing from receiver toward emitter.

    References:
        Patent US20110309983A1, Equations 2-7.
    """
    # Convert inputs to arrays (no-op if already arrays)
    receiver_xyz_m = np.asarray(receiver_xyz_m)

    # Convert cone angle to elevation angle
    # cone_deg: -90=zenith, 0=horizon, 90=nadir
    # elevation_deg: +90=zenith, 0=horizon, -90=nadir
    elevation_deg = -cone_deg

    # Use azimuth and elevation with unit range to get direction vector
    # aer_to_xyz expects [azimuth_deg, elevation_deg, range_m]
    aer = np.array([clock_deg, elevation_deg, 1.0])

    # Get the vector in ECEF (will have magnitude ~1.0)
    vec_m = aer_to_xyz(receiver_xyz_m, aer)

    # Normalize to ensure unit vector (account for any numerical errors)
    magnitude = np.linalg.norm(vec_m)
    if magnitude > 0:  # noqa: SIM108
        unit_vector = vec_m / magnitude
    else:
        # Degenerate case - return zero vector
        unit_vector = np.zeros(3)

    return unit_vector
