"""Calculate residual errors between predicted and measured observations.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .calculate_clock_cone_aoa import calculate_clock_cone_aoa

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def _wrap_angle(angle: float, lower: float = -180.0, upper: float = 180.0) -> float:
    """Wrap angle to specified range.

    Args:
        angle: Angle to wrap.
        lower: Lower bound of range (default: -180.0).
        upper: Upper bound of range (default: 180.0).

    Returns:
        Wrapped angle in [lower, upper) range.
    """
    range_size = upper - lower
    return ((angle - lower) % range_size) + lower


def calculate_residuals(
    emitter_estimate_xyz_m: NDArray[np.floating] | Sequence[float],
    observations: NDArray[np.floating] | Sequence[float],
    receiver_positions_xyz_m: NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Calculate residual errors between predicted and measured observations.

    For each receiver position, predicts what the clock and cone angles should be
    given the current emitter position estimate, then computes the difference
    between predicted and measured angles.

    Residuals are defined as: e = predicted - measured

    Args:
        emitter_estimate_xyz_m: Estimated emitter position [x,y,z] in ECEF meters.
        observations: Nx2 array of measured [clock_deg, cone_deg] angles.
        receiver_positions_xyz_m: Nx3 array of receiver positions in ECEF meters.

    Returns:
        Nx2 array of residual errors [clock_error_deg, cone_error_deg].
        Positive residuals mean predicted angle is greater than measured.

    References:
        Patent US20110309983A1, residual vector 'e' in IWLSA (Equation 20).

    Notes:
        This function is used in the IWLSA to assess how well the current
        estimate matches the observations. The goal is to minimize these residuals.
    """
    # Convert inputs to arrays (no-op if already arrays)
    emitter_estimate_xyz_m = np.asarray(emitter_estimate_xyz_m)
    observations = np.asarray(observations)
    receiver_positions_xyz_m = np.asarray(receiver_positions_xyz_m)

    n_obs = observations.shape[0]
    residuals = np.zeros((n_obs, 2))

    for i in range(n_obs):
        receiver_pos = receiver_positions_xyz_m[i]
        measured_clock, measured_cone = observations[i]

        # Predict what the angles should be given current estimate
        predicted_clock, predicted_cone = calculate_clock_cone_aoa(
            emitter_estimate_xyz_m,
            receiver_pos,
        )

        # Calculate residuals: predicted - measured
        # Wrap clock residual to [-180, 180] to handle azimuth wraparound
        clock_residual = _wrap_angle(predicted_clock - measured_clock)
        cone_residual = predicted_cone - measured_cone

        residuals[i, 0] = clock_residual
        residuals[i, 1] = cone_residual

    return residuals
