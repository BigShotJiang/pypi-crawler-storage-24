"""Transform between ECEF and IJK (collector-centered) coordinate systems.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.conversion import enu_to_xyz, xyz_to_enu

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def ecef_to_ijk(
    ecef_xyz_m: NDArray[np.floating] | Sequence[float],
    collector_xyz_m: NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Transform ECEF coordinates to IJK collector-centered frame.

    The IJK coordinate system is defined in the patent as:
    - i-axis: Along boresight-to-collector slant vector
    - k-axis: Perpendicular to i, in plane with slant and ECEF z-axis
    - j-axis: Perpendicular to both i and k

    When the boresight is selected as the Nadir point (directly below collector),
    the IJK frame aligns with ENU as follows:
    - i → u (up)
    - j → e (east)
    - k → n (north)

    This implementation uses the Nadir boresight configuration.

    Args:
        ecef_xyz_m: Point or vector in ECEF coordinates [x,y,z] meters.
                    Automatically detects if 1D (vector) or position.
        collector_xyz_m: Collector/receiver position in ECEF [x,y,z] meters.

    Returns:
        Coordinates or vector in IJK frame [i,j,k].

    References:
        Patent US20110309983A1, IJK coordinate system definition (line 52, 816).

    Notes:
        The IJK and ENU frames are parallel (same orientation, different origins),
        so vectors remain the same: v=(i,j,k)=(e,n,u) when properly reordered.

        Automatically handles both vectors (1D arrays) and positions based on
        array dimensionality.
    """
    # Convert inputs to arrays (no-op if already arrays)
    ecef_xyz_m = np.asarray(ecef_xyz_m)
    collector_xyz_m = np.asarray(collector_xyz_m)

    # Convert to ENU (handles both vectors and positions)
    enu = xyz_to_enu(collector_xyz_m, ecef_xyz_m)

    # Reorder ENU to IJK: (e,n,u) → (i,j,k) = (u,e,n)
    # enu[0] = east → j
    # enu[1] = north → k
    # enu[2] = up → i
    e, n, u = enu

    return np.array([u, e, n])


def ijk_to_ecef(
    ijk: NDArray[np.floating] | Sequence[float],
    collector_xyz_m: NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Transform IJK collector-centered frame to ECEF coordinates.

    Inverse of ecef_to_ijk.

    Args:
        ijk: Point or vector in IJK coordinates [i,j,k].
             Automatically detects if 1D (vector) or position.
        collector_xyz_m: Collector/receiver position in ECEF [x,y,z] meters.

    Returns:
        Coordinates or vector in ECEF frame [x,y,z] meters.

    References:
        Patent US20110309983A1, IJK coordinate system definition.

    Notes:
        Automatically handles both vectors (1D arrays) and positions based on
        array dimensionality.
    """
    # Convert inputs to arrays (no-op if already arrays)
    ijk = np.asarray(ijk)
    collector_xyz_m = np.asarray(collector_xyz_m)

    # Reorder IJK to ENU: (i,j,k) → (e,n,u)
    # ijk[0] = i → u
    # ijk[1] = j → e
    # ijk[2] = k → n
    i, j, k = ijk
    enu = np.array([j, k, i])  # (e, n, u)

    # Convert ENU back to ECEF (handles both vectors and positions)
    return enu_to_xyz(collector_xyz_m, enu)
