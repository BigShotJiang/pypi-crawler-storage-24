# Patent Summary: US20110309983A1

**Title:** Three-Dimensional Direction Finding for Estimating a Geolocation of an Emitter
**Publication Number:** US20110309983A1
**Publication Date:** December 22, 2011
**Filing Date:** June 21, 2011
**Assignee:** Northrop Grumman Systems Corp
**Inventors:** Tyler Holzer, Bart Peters, David T. Driggs, Greg Manassero
**Status:** Abandoned

## Core Innovation

The key breakthrough is enabling accurate geolocation from a **single aircraft at a single position** by:

1. Using a 3D antenna array to determine both azimuth (horizontal bearing) and depression angle (vertical angle)
2. Intersecting the resulting 3D line-of-position (LOP) with Digital Terrain Elevation Data (DTED)

This eliminates the need for either multiple aircraft or flying to multiple locations, significantly improving operational efficiency.

## Technical Approach

### Primary Algorithm: Iterative Weighted Least-Squares Algorithm (IWLSA)

The core iteration formula:

```
x̂ᵢ = x̂ᵢ₋₁ − (AᵀWA)⁻¹AᵀWe
```

Where:
- `A` = matrix of partial derivatives of observations
- `W` = weighting matrix incorporating measurement uncertainties
- `e` = vector of residual errors

### Key Measurements

**Azimuth angle (θ):**
```
θ = tan⁻¹(j/k)
```
Horizontal bearing from collector to emitter

**Depression angle (DA):**
```
DA = π/2 − cos⁻¹(−u/√(e²+n²+u²))
```
Vertical angle from horizon down to emitter

**Cone angle (φ):**
```
φ = cos⁻¹(−i/√(i²+j²+k²))
```
Used for 3D LOP calculation

## Advanced Features

1. **Ray-bending correction** - Accounts for atmospheric refraction effects
2. **Terrain variance modeling** - Treats terrain as a statistical observable rather than hard constraint
3. **Oscillation compensation** - Prevents bouncing between DTED altitude cells during iteration
4. **Error region generation** - Creates uncertainty ellipses based on measurement accuracy
5. **Step-size limitation** - Prevents overshoot in iterative solution

## Coordinate Systems

The system uses three coordinate frames:

- **IJK (Collector-Centered Cartesian)**: Aircraft-centered frame where measurements are made
- **ENU (East-North-Up)**: Emitter-centered local tangent plane
- **ECEF (Earth-Centered Earth-Fixed)**: Global Cartesian coordinate system

## Problem Solved

Traditional 2D direction finding requires triangulation from multiple positions - either:
- Multiple spatially-separated collection platforms (costly), or
- Single platform collecting at multiple locations over time (time-consuming)

This 3D approach adds the vertical dimension (depression angle), allowing the LOP to intersect with known terrain elevation, providing a geolocation solution from a single measurement position.

## Key Patent Claims

The patent protects:

1. Methods for determining three-dimensional geolocation by intersecting 3D LOPs with DTED
2. Systems with antenna arrays calculating 3D LOPs from phase information
3. Error region generation techniques using measurement uncertainty angles
4. Geolocation components using IWLSA with terrain data integration
5. Techniques handling multiple observations from single or multiple aircraft

## Important Figures

- **Figure 1:** Overall system architecture (antenna array → LOP calculation → geolocation calculation)
- **Figures 2-3:** Geometric diagrams of azimuth and depression angles
- **Figure 4:** Accuracy improvement using DTED vs flat-Earth assumptions over mountainous terrain
- **Figures 6-8:** Error region visualization showing uncertainty cone intersection with Earth's surface
- **Figure 9:** Computer system architecture for implementation
- **Figure 10:** Three-step geolocation method flowchart

## Mathematical Formulation Summary

The system combines:

1. **Direction Finding**: Antenna array → azimuth + depression angles
2. **3D LOP Construction**: Vector from aircraft position along measured direction
3. **Terrain Intersection**: Iterative solution finding where LOP intersects DTED surface
4. **Uncertainty Quantification**: Error ellipse from measurement uncertainty cone

The IWLSA iteratively refines the emitter position estimate by minimizing weighted residuals between predicted and measured angles, incorporating terrain elevation as a constraint/observable.

## References

Full patent text: https://patents.google.com/patent/US20110309983A1/en
