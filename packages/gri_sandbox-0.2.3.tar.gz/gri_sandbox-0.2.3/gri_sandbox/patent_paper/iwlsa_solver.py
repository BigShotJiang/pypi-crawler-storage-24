"""Full Iterative Weighted Least-Squares Algorithm (IWLSA) solver.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

import numpy as np

from .calculate_residuals import calculate_residuals
from .iwlsa_iteration import iwlsa_iteration

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class IWLSAResult(TypedDict):
    """IWLSA solver result.

    Attributes:
        position_xyz_m: Final emitter position estimate in ECEF [x,y,z] meters.
        iterations: Number of iterations performed.
        residual_m: Final RMS residual error in meters.
        converged: Whether the solver converged within tolerance.
    """

    position_xyz_m: NDArray[np.floating]
    iterations: int
    residual_m: float
    converged: bool


def iwlsa_solver(  # noqa: PLR0913
    initial_guess_xyz_m: NDArray[np.floating] | Sequence[float],
    observations: NDArray[np.floating] | Sequence[float],
    receiver_positions_xyz_m: NDArray[np.floating] | Sequence[float],
    weights: NDArray[np.floating] | None = None,
    max_iterations: int = 100,
    tolerance_m: float = 1.0,
) -> IWLSAResult:
    """Solve for emitter position using Iterative Weighted Least-Squares Algorithm.

    Iteratively refines the emitter position estimate until convergence or
    maximum iterations reached.

    Args:
        initial_guess_xyz_m: Initial emitter position guess [x,y,z] in ECEF meters.
        observations: Nx2 array of measured [clock_deg, cone_deg] angles.
        receiver_positions_xyz_m: Nx3 array of receiver positions in ECEF meters.
        weights: Optional 2Nx2N weight matrix. If None, uses equal weights.
        max_iterations: Maximum number of iterations (default: 100).
        tolerance_m: Convergence tolerance in meters (default: 1.0).

    Returns:
        IWLSAResult dictionary containing:
            - position_xyz_m: Final position estimate
            - iterations: Number of iterations performed
            - residual_m: Final RMS residual in meters
            - converged: True if converged within tolerance

    References:
        Patent US20110309983A1, Equation 20 and IWLSA description.

    Notes:
        Convergence is determined by the change in position estimate between
        iterations. If the change is less than tolerance_m, the algorithm stops.
    """
    # Convert inputs to arrays (no-op if already arrays)
    initial_guess_xyz_m = np.asarray(initial_guess_xyz_m)
    observations = np.asarray(observations)
    receiver_positions_xyz_m = np.asarray(receiver_positions_xyz_m)

    current_estimate = initial_guess_xyz_m.copy()
    converged = False

    iterations = 0
    for _ in range(max_iterations):
        # Perform one IWLSA iteration
        iterations += 1
        new_estimate = iwlsa_iteration(
            current_estimate,
            observations,
            receiver_positions_xyz_m,
            weights,
        )

        # Calculate change in estimate
        delta = new_estimate - current_estimate
        change_m = np.linalg.norm(delta)

        # Update current estimate
        current_estimate = new_estimate

        # Check convergence
        if change_m < tolerance_m:
            converged = True
            break

    # Calculate final residual
    final_residuals = calculate_residuals(
        current_estimate,
        observations,
        receiver_positions_xyz_m,
    )

    # Convert angle residuals to approximate distance residuals
    # For each observation, estimate the range and convert angle error to distance
    residual_distances = []
    for i, receiver_pos in enumerate(receiver_positions_xyz_m):
        range_m = np.linalg.norm(current_estimate - receiver_pos)
        # Convert angular errors (degrees) to linear errors at range
        clock_err_rad = np.deg2rad(final_residuals[i, 0])
        cone_err_rad = np.deg2rad(final_residuals[i, 1])
        # Approximate linear error
        linear_err_m = range_m * np.sqrt(clock_err_rad**2 + cone_err_rad**2)
        residual_distances.append(linear_err_m)

    # RMS of residual distances
    residual_m = float(np.sqrt(np.mean(np.array(residual_distances) ** 2)))

    return IWLSAResult(
        position_xyz_m=current_estimate,
        iterations=iterations + 1,
        residual_m=residual_m,
        converged=converged,
    )
