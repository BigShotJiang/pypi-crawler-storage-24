# Three-Dimensional Direction Finding for Geolocation

Implementation of algorithms from **US Patent 20110309983A1** - "Three-Dimensional Direction Finding for Estimating a Geolocation of an Emitter"

**Inventors:** Tyler Holzer, Bart Peters, David T. Driggs, Greg Manassero
**Assignee:** Northrop Grumman Systems Corp
**Publication Date:** December 22, 2011
**Status:** Abandoned
**Patent Link:** https://patents.google.com/patent/US20110309983A1/en

## Overview

This module implements the patent's method for geolocating terrestrial signal emitters using 3D direction finding from airborne platforms. The key innovation is enabling accurate geolocation from a **single aircraft at a single position** by:

1. Using a 3D antenna array to measure both azimuth (clock) and cone angles
2. Intersecting the resulting 3D line-of-position (LOP) with the WGS-84 ellipsoid or terrain
3. Iteratively refining the estimate using the IWLSA (Iterative Weighted Least-Squares Algorithm)

This eliminates the need for multiple aircraft or time-consuming multi-position collection.

## Implemented Functions

### Core Geolocation Functions (1-3)

#### 1. `calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m)`
Calculate clock and cone angles of arrival between emitter and receiver.

- **Input:** Emitter and receiver positions in ECEF (meters)
- **Output:** `(clock_deg, cone_deg)` tuple
  - `clock_deg`: Azimuth angle (0°=North, 90°=East)
  - `cone_deg`: Angle from horizon (0°=horizon, 90°=down/nadir, -90°=up/zenith)
- **File:** [`calculate_clock_cone_aoa.py`](calculate_clock_cone_aoa.py)

#### 2. `calculate_ecef_pointing_vector(receiver_xyz_m, clock_deg, cone_deg)`
Convert clock/cone angles to ECEF unit pointing vector.

- **Input:** Receiver position and angles (degrees)
- **Output:** Unit vector `[dx, dy, dz]` in ECEF
- **File:** [`calculate_ecef_pointing_vector.py`](calculate_ecef_pointing_vector.py)

#### 3. `calculate_wgs84_intersection(receiver_xyz_m, pointing_vector)`
Find intersection of line-of-position with WGS-84 ellipsoid surface.

- **Input:** Receiver position and pointing vector
- **Output:** Intersection point `[x, y, z]` in ECEF, or `None` if no intersection
- **File:** [`calculate_wgs84_intersection.py`](calculate_wgs84_intersection.py)

### Advanced Functions (4-7)

#### 4. `calculate_error_ellipse(receiver_xyz_m, pointing_vector, uncertainty_angle_deg)`
Project measurement uncertainty cone onto surface as error ellipse.

- **Input:** Receiver, pointing vector, and uncertainty half-angle
- **Output:** Dictionary with `center_xyz_m`, `semi_major_m`, `semi_minor_m`, `orientation_deg`
- **File:** [`calculate_error_ellipse.py`](calculate_error_ellipse.py)

#### 5. `apply_ray_bending_correction(receiver_xyz_m, pointing_vector, emitter_xyz_m, ...)`
Apply atmospheric refraction correction using ITU-R 2019 tropospheric model.

- **Input:** Receiver, apparent pointing vector, emitter position, atmospheric parameters
- **Output:** Corrected pointing vector accounting for refraction
- **File:** [`apply_ray_bending_correction.py`](apply_ray_bending_correction.py)
- **Note:** Uses `gri_tropo.dgs.dgs_tropo_corrections` for the correction model

#### 6. `iwlsa_iteration(current_estimate_xyz_m, observations, receiver_positions_xyz_m, weights)`
Perform one iteration of the IWLSA algorithm.

- **Input:** Current estimate, N×2 observations `[clock, cone]`, N×3 receiver positions, optional weights
- **Output:** Updated position estimate
- **Algorithm:** `x̂ᵢ = x̂ᵢ₋₁ - (AᵀWA)⁻¹AᵀWe`
- **File:** [`iwlsa_iteration.py`](iwlsa_iteration.py)

#### 7. `iwlsa_solver(initial_guess_xyz_m, observations, receiver_positions_xyz_m, ...)`
Full iterative IWLSA solver with convergence detection.

- **Input:** Initial guess, observations, receiver positions, convergence parameters
- **Output:** Dictionary with `position_xyz_m`, `iterations`, `residual_m`, `converged`
- **File:** [`iwlsa_solver.py`](iwlsa_solver.py)

### Coordinate Transform Functions (8-9)

#### 8. `ecef_to_ijk(ecef_xyz_m, collector_xyz_m, is_vector)` and `ijk_to_ecef(...)`
Transform between ECEF and IJK (collector-centered) coordinate systems.

- **IJK Frame:** Collector-centered with (i,j,k) → (up, east, north) when boresight = Nadir
- **Input:** Position/vector and collector position
- **Output:** Transformed position/vector
- **File:** [`ecef_to_ijk.py`](ecef_to_ijk.py)

#### 9. `convert_clock_cone_to_az_el(clock_deg, cone_deg)` and inverse
Convert between clock/cone and azimuth/elevation angle representations.

- **Relationships:**
  - Clock = Azimuth
  - Cone = -Elevation
- **File:** [`convert_clock_cone_to_az_el.py`](convert_clock_cone_to_az_el.py)

### Utility Functions (10-14)

#### 10. `calculate_residuals(emitter_estimate_xyz_m, observations, receiver_positions_xyz_m)`
Calculate residual errors between predicted and measured observations.

- **Input:** Emitter estimate, observations, receiver positions
- **Output:** N×2 array of residuals `[clock_error, cone_error]` in degrees
- **File:** [`calculate_residuals.py`](calculate_residuals.py)

#### 11. `compute_jacobian(emitter_estimate_xyz_m, receiver_positions_xyz_m, delta_m)`
Compute Jacobian matrix of observation partial derivatives.

- **Input:** Emitter estimate, receiver positions, finite difference step size
- **Output:** N×2×3 Jacobian tensor `∂[clock,cone]/∂[x,y,z]`
- **File:** [`compute_jacobian.py`](compute_jacobian.py)
- **Note:** Uses numerical differentiation; analytical derivatives would be more efficient

#### 12. `create_lop_from_clock_cone(receiver_xyz_m, clock_deg, cone_deg)`
Create line-of-position representation from angles.

- **Input:** Receiver position and angles
- **Output:** Dictionary with `origin_xyz_m`, `direction`, `clock_deg`, `cone_deg`
- **File:** [`create_lop_from_clock_cone.py`](create_lop_from_clock_cone.py)

#### 13. `multi_observation_triangulation(lops)`
Triangulate emitter position from multiple lines-of-position.

- **Input:** List of LOP dictionaries
- **Output:** Best-fit emitter position in ECEF
- **Method:** Least-squares closest point to multiple rays
- **File:** [`multi_observation_triangulation.py`](multi_observation_triangulation.py)

#### 14. `propagate_uncertainty(emitter_xyz_m, observations, receiver_positions_xyz_m, angle_uncertainties_deg)`
Propagate angle measurement uncertainties to position covariance matrix.

- **Input:** Emitter estimate, observations, receiver positions, N×2 angle standard deviations
- **Output:** 3×3 covariance matrix in ECEF (m²)
- **Formula:** `Cov(x) = (AᵀW⁻¹A)⁻¹`
- **File:** [`propagate_uncertainty.py`](propagate_uncertainty.py)

## Usage Example

```python
import numpy as np
from gri_sandbox.patent_paper import (
    calculate_clock_cone_aoa,
    calculate_ecef_pointing_vector,
    calculate_wgs84_intersection,
    iwlsa_solver,
)

# Known emitter and receiver positions (example)
emitter_xyz = np.array([4000000.0, 3000000.0, 4000000.0])  # ECEF meters
receiver_xyz = np.array([4000000.0, 3000000.0, 4500000.0])  # 500 km above

# 1. Calculate angles of arrival
clock, cone = calculate_clock_cone_aoa(emitter_xyz, receiver_xyz)
print(f"Clock: {clock:.2f}°, Cone: {cone:.2f}°")

# 2. Convert angles to pointing vector
pointing = calculate_ecef_pointing_vector(receiver_xyz, clock, cone)

# 3. Find surface intersection
intersection = calculate_wgs84_intersection(receiver_xyz, pointing)
print(f"Intersection: {intersection}")

# 4. Multi-observation IWLSA example
observations = np.array([
    [45.0, 95.0],   # [clock, cone] from receiver 1
    [50.0, 93.0],   # from receiver 2
])
receiver_positions = np.array([
    [4000000.0, 3000000.0, 4500000.0],
    [4050000.0, 3000000.0, 4500000.0],
])
initial_guess = np.array([4000000.0, 3000000.0, 4000000.0])

result = iwlsa_solver(initial_guess, observations, receiver_positions)
print(f"Converged: {result['converged']}")
print(f"Position: {result['position_xyz_m']}")
print(f"Residual: {result['residual_m']:.2f} m")
```

## Mathematical Foundation

### Key Equations from Patent

**Vector in IJK frame (Equation 2):**
```
v = (i, j, k) where origin is at collector
```

**Clock angle (Equation 4):**
```
θ = tan⁻¹(j/k)
```

**Cone angle (Equation 6):**
```
φ = cos⁻¹(-i/|v|)
```

**IWLSA Update (Equation 20):**
```
x̂ᵢ = x̂ᵢ₋₁ - (AᵀWA)⁻¹AᵀWe
```

Where:
- **A** = Jacobian matrix (partial derivatives)
- **W** = Weight matrix (inverse covariance)
- **e** = Residual vector (predicted - measured)

## Testing

Comprehensive functional tests are available in [`test/patent_paper/`](../../test/patent_paper/). The test suite includes **42 tests** across **14 test files**, with one test file per module:

```bash
# Run all patent_paper tests
pytest test/patent_paper/ -v

# Run specific test file
pytest test/patent_paper/test_iwlsa_solver.py -v
```

Each function has 1-3 focused tests that verify:

- **Correctness:** Functions produce expected outputs for known inputs
- **Robustness:** Edge cases and boundary conditions are handled
- **Consistency:** Roundtrip operations preserve values
- **Type flexibility:** Functions accept both arrays and lists

All tests pass and are designed to ensure the algorithms behave correctly without requiring full code coverage.

## Dependencies

- `numpy` - Array operations
- `gri_utils` - ECEF/LLA conversions, WGS-84 constants
- `gri_tropo` - Tropospheric refraction corrections (ITU-R 2019)

## References

- **Patent:** US20110309983A1 - Full text in [`patent.html`](patent.html) and [`patent_full_text.txt`](patent_full_text.txt)
- **Summary:** [`patent.md`](patent.md)
- **Implementation Notes:** [`implementation_notes.md`](implementation_notes.md)

## Notes

1. **Coordinate Systems:**
   - **ECEF:** Earth-Centered Earth-Fixed (x,y,z in meters)
   - **IJK:** Collector-centered (i=up, j=east, k=north when boresight=Nadir)
   - **LLA:** Latitude, Longitude, Altitude (degrees, degrees, meters)

2. **Angle Conventions:**
   - **Clock/Azimuth:** 0°=North, 90°=East, 180°=South, 270°=West
   - **Cone:** 0°=horizon, 90°=nadir (down), -90°=zenith (up)
   - **Elevation:** +90°=zenith, 0°=horizon, -90°=nadir

3. **Limitations:**
   - Error ellipse calculation (Function 4) is a simplified approximation
   - Jacobian uses numerical differentiation (analytical would be faster)
   - Ray-bending uses ITU-R 2019 model (patent doesn't specify model)

4. **Future Enhancements:**
   - Analytical Jacobian for better performance
   - DTED terrain integration (patent feature not yet implemented)
   - Multi-platform concurrent observations
   - Step-size limitation and oscillation compensation for IWLSA
