# Implementation Notes from Patent US20110309983A1

## IJK Coordinate System (Collector-Centered)

From the patent text (line 52):

> The IJK coordinate system is a Collector-Centered Cartesian coordinate frame in which the **i-axis lies along a boresight-to-collector slant vector**, the **k-axis is perpendicular to the i-axis and lies in the plane containing the slant vector and a vector through the boresight parallel to a z-axis of the Earth-Centered Earth-Fixed (ECEF) Cartesian coordinate frame**. Thus, the **j-axis is the remaining vector perpendicular to both i and k**.

### IJK to ENU Conversion (line 816):

When the boresight is selected as the **Nadir point** (directly below the aircraft):

> Because the k-vector of the IJK coordinate system points North, the IJK coordinate system can be converted to an East-North-Up (ENU) coordinate frame...

**The mapping when boresight = Nadir:**
- **I-axis → Up (U) axis**
- **J-axis → East (E) axis**
- **K-axis → North (N) axis**

So the transformation is:
```
IJK → ENU
i → u (up)
j → e (east)
k → n (north)
```

**Important:** Even though the coordinate systems have different origins (collector vs emitter), they are **parallel**, so vectors remain the same: `v = (i, j, k) = (e, n, u)`

### For Our Implementation (Function 8):

The IJK frame is essentially **ENU rotated** such that:
- When boresight is at Nadir, IJK aligns with ENU as: **(i,j,k) → (u,e,n)**
- This is **NOT standard ENU ordering** - it's a specific collector-centered frame

**Recommendation:** Implement `ecef_to_ijk()` using the ENU transformation from gri_utils, then reorder axes appropriately based on the boresight configuration.

## Ray-Bending Correction (Atmospheric Refraction)

From lines 4521, 4785:

> One example of an additional constraint that can be accounted for by the IWLSA is that the depression angle DA may be subject to ray-bending (i.e., atmospheric refraction). Refraction may change the apparent depression angle DA, making it appear more shallow than it really is.

> Where: **RC corresponds to a correction in radians to transform an apparent depression angle DA into a straight-line-to-target depression angle DA**.

### Implementation Status:

The patent **mentions** ray-bending correction but does **NOT provide the specific formula** for calculating RC. It only states:

1. RC is in radians
2. It corrects apparent depression angle to actual depression angle
3. Refraction makes angles appear "more shallow" (less steep)
4. The correction should be "differentiable in the XYZ coordinate system"

### For Our Implementation (Function 5):

**Options:**

1. **Use standard atmospheric refraction model** (recommended):
   - Simple model: `RC ≈ k * tan(apparent_depression)` where k ≈ 0.00013 for standard atmosphere
   - More complex: Use Bennett's formula or similar

2. **Implement placeholder** that takes RC as a parameter (let user provide correction)

3. **Skip initially** and add as enhancement later

**Recommendation:** Implement a simple atmospheric refraction model based on standard formulas since patent doesn't give specifics. Document that this is an approximation.

## Coordinate System Definitions

### ECEF (Earth-Centered Earth-Fixed)
- Positive **x-axis**: 0° lat, 0° lon (equator, prime meridian)
- Positive **y-axis**: 0° lat, 90° E lon (equator, east)
- Positive **z-axis**: 90° N lat (North Pole)

### ENU (East-North-Up, Emitter-Centered)
- **East-North (EN) plane**: Tangent plane to Earth at emitter location
- **East axis**: Points east in tangent plane
- **North axis**: Points north in tangent plane
- **Up axis**: Points vertically up, perpendicular to Earth surface

### IJK (Collector-Centered)
- **Depends on boresight selection**
- When boresight = Nadir: (i,j,k) maps to (u,e,n) in ENU
- Origin at collector/receiver position

## Angle Definitions

### Azimuth (θ)
```
θ = tan⁻¹(j/k)
```
In ENU with Nadir boresight: `θ = tan⁻¹(e/n)`

### Cone Angle (φ)
```
φ = cos⁻¹(-i/√(i²+j²+k²))
```
Angle from negative i-axis (downward from collector when boresight = Nadir)

### Depression Angle (DA)
```
DA = π/2 - φ
```
Angle down from horizontal

### Relationship
- **Clock angle** = Azimuth (θ)
- **Cone angle** = φ (measured from -i axis)
- **Elevation angle** = π/2 - φ = -DA (up from horizon)

## Key Equations

### Vector in IJK/ENU (Equation 2)
```
v = (i_e, j_e, k_e)
```
When collector is at origin (collector-centered).

### IWLSA Update (Equation 20)
```
x̂ᵢ = x̂ᵢ₋₁ - (AᵀWA)⁻¹AᵀWe
```

Where:
- **A** = Jacobian matrix (partial derivatives of observations w.r.t. position)
- **W** = Weight matrix (inverse of measurement covariance)
- **e** = Residual vector (predicted - measured observations)

## Implementation Strategy

1. **Use gri_utils ENU transforms** as basis for IJK transforms
2. **Implement simple atmospheric refraction** model (not specified in patent)
3. **Focus on Nadir boresight case** initially (simplest IJK↔ENU mapping)
4. **Document assumptions** where patent is ambiguous
