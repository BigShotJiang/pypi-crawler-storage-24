"""Single iteration of Iterative Weighted Least-Squares Algorithm (IWLSA).

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .calculate_residuals import calculate_residuals
from .compute_jacobian import compute_jacobian

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def iwlsa_iteration(
    current_estimate_xyz_m: NDArray[np.floating] | Sequence[float],
    observations: NDArray[np.floating] | Sequence[float],
    receiver_positions_xyz_m: NDArray[np.floating] | Sequence[float],
    weights: NDArray[np.floating] | None = None,
) -> NDArray[np.floating]:
    """Perform one iteration of the Iterative Weighted Least-Squares Algorithm.

    Implements the IWLSA update equation from the patent:
        x̂ᵢ = x̂ᵢ₋₁ - (AᵀWA)⁻¹AᵀWe

    Where:
        - A = Jacobian matrix of partial derivatives (2Nx3)
        - W = Weight matrix (2Nx2N diagonal)
        - e = Residual vector (2Nx1)
        - x̂ = Estimated emitter position (3x1)

    Args:
        current_estimate_xyz_m: Current emitter position estimate [x,y,z] in ECEF.
        observations: Nx2 array of measured [clock_deg, cone_deg] angles.
        receiver_positions_xyz_m: Nx3 array of receiver positions in ECEF.
        weights: Optional 2Nx2N weight matrix (inverse covariance). If None,
                 uses identity (equal weights).

    Returns:
        Updated emitter position estimate [x, y, z] in ECEF meters.

    References:
        Patent US20110309983A1, Equation 20 and surrounding text.

    Notes:
        This function computes the Jacobian numerically using finite differences.
        For production use, analytical derivatives would be more efficient.
    """
    # Convert inputs to arrays (no-op if already arrays)
    current_estimate_xyz_m = np.asarray(current_estimate_xyz_m)
    observations = np.asarray(observations)
    receiver_positions_xyz_m = np.asarray(receiver_positions_xyz_m)

    n_obs = observations.shape[0]

    # Calculate residuals: e = predicted - measured
    residuals = calculate_residuals(
        current_estimate_xyz_m,
        observations,
        receiver_positions_xyz_m,
    )

    # Flatten residuals to column vector (2N x 1)
    e = residuals.flatten()

    # Compute Jacobian matrix (2N x 3)
    # Shape will be (N, 2, 3), need to reshape to (2N, 3)
    jac_tensor = compute_jacobian(current_estimate_xyz_m, receiver_positions_xyz_m)
    a = jac_tensor.reshape(2 * n_obs, 3)

    # Weight matrix (2N x 2N)
    if weights is None:  # noqa: SIM108
        # Default to identity matrix (equal weights)
        w = np.eye(2 * n_obs)
    else:
        w = weights

    # Compute (AᵀWA)
    atw = a.T @ w  # 3 x 2N
    atwa = atw @ a  # 3 x 3

    # Compute (AᵀWA)⁻¹
    try:
        atwa_inv = np.linalg.inv(atwa)
    except np.linalg.LinAlgError:
        # Singular matrix - use pseudo-inverse
        atwa_inv = np.linalg.pinv(atwa)

    # Compute update: Δx = -(AᵀWA)⁻¹AᵀWe
    atwe = atw @ e  # 3 x 1
    delta_x = -atwa_inv @ atwe  # 3 x 1

    # Apply update
    return current_estimate_xyz_m + delta_x
