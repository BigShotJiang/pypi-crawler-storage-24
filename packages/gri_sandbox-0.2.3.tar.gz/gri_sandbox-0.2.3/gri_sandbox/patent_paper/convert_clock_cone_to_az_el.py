"""Convert between clock/cone and azimuth/elevation angle representations.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations


def convert_clock_cone_to_az_el(
    clock_deg: float,
    cone_deg: float,
) -> tuple[float, float]:
    """Convert clock/cone angles to azimuth/elevation angles.

    Angle representations:
    - Clock/Cone: (θ, φ) where θ=azimuth and φ=cone angle from horizon
    - Azimuth/Elevation: Standard navigation angles

    Relationships:
    - Clock angle (θ) = Azimuth angle (same)
    - Cone angle (φ) = -Elevation angle
    - Elevation angle = -Cone angle

    Args:
        clock_deg: Clock/azimuth angle in degrees (0=North, 90=East, 180=South,
            270=West).
        cone_deg: Cone angle in degrees (0=horizon, 90=nadir/down, -90=zenith/up).

    Returns:
        Tuple of (azimuth_deg, elevation_deg):
            - azimuth_deg: Azimuth angle in degrees (0=North, 90=East)
            - elevation_deg: Elevation angle in degrees above horizon
              (+90=zenith, 0=horizon, -90=nadir)

    References:
        Patent US20110309983A1, Equations 3-7.

    Examples:
        >>> convert_clock_cone_to_az_el(0.0, -45.0)
        (0.0, 45.0)  # North, 45° above horizon

        >>> convert_clock_cone_to_az_el(90.0, 0.0)
        (90.0, 0.0)  # East, at horizon

        >>> convert_clock_cone_to_az_el(180.0, 45.0)
        (180.0, -45.0)  # South, 45° below horizon
    """
    # Clock angle is the same as azimuth
    azimuth_deg = clock_deg

    # Convert cone angle to elevation
    # cone = -90° → elevation = 90° (zenith)
    # cone = 0° → elevation = 0° (horizon)
    # cone = 90° → elevation = -90° (nadir)
    elevation_deg = -cone_deg

    return azimuth_deg, elevation_deg


def convert_az_el_to_clock_cone(
    azimuth_deg: float,
    elevation_deg: float,
) -> tuple[float, float]:
    """Convert azimuth/elevation angles to clock/cone angles.

    Inverse of convert_clock_cone_to_az_el.

    Args:
        azimuth_deg: Azimuth angle in degrees (0=North, 90=East).
        elevation_deg: Elevation angle in degrees above horizon
                       (+90=zenith, 0=horizon, -90=nadir).

    Returns:
        Tuple of (clock_deg, cone_deg):
            - clock_deg: Clock/azimuth angle in degrees
            - cone_deg: Cone angle in degrees (0=horizon, 90=nadir, -90=zenith)

    References:
        Patent US20110309983A1, Equations 3-7.

    Examples:
        >>> convert_az_el_to_clock_cone(0.0, 45.0)
        (0.0, -45.0)  # North, cone angle -45° (above horizon)

        >>> convert_az_el_to_clock_cone(90.0, 0.0)
        (90.0, 0.0)  # East, at horizon

        >>> convert_az_el_to_clock_cone(180.0, -45.0)
        (180.0, 45.0)  # South, cone angle 45° (below horizon)
    """
    # Azimuth is the same as clock angle
    clock_deg = azimuth_deg

    # Convert elevation to cone angle
    # elevation = 90° → cone = -90° (zenith)
    # elevation = 0° → cone = 0° (horizon)
    # elevation = -90° → cone = 90° (nadir)
    cone_deg = -elevation_deg

    return clock_deg, cone_deg
