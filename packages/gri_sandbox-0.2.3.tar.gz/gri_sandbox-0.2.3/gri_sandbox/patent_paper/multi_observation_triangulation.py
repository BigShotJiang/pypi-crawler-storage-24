"""Triangulate emitter position from multiple lines-of-position.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .calculate_wgs84_intersection import calculate_wgs84_intersection

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from gri_sandbox.patent_paper.create_lop_from_clock_cone import LineOfPosition


def multi_observation_triangulation(
    lops: list[LineOfPosition],
) -> NDArray[np.floating]:
    """Find best-fit emitter position from multiple Lines-of-Position.

    When multiple LOPs are available (from different receiver positions or times),
    they generally don't intersect at a single point due to measurement errors.
    This function finds the point in 3D space that minimizes the sum of squared
    distances to all LOPs (least-squares best fit).

    Uses the method of finding the point closest to multiple lines in 3D space.

    Args:
        lops: List of LineOfPosition dictionaries, each containing:
              - origin_xyz_m: Ray origin in ECEF
              - direction: Unit direction vector in ECEF

    Returns:
        Best-fit emitter position [x,y,z] in ECEF meters.

    References:
        Patent US20110309983A1 - combining multiple observations.

    Notes:
        This implements the least-squares solution for the "closest point to
        multiple lines" problem. For N lines, we solve:
            minimize Σᵢ ||pᵢ + tᵢdᵢ - x||²
        where pᵢ is origin, dᵢ is direction, and x is the unknown point.

        The solution is: x = (AᵀA)⁻¹Aᵀb
        where A and b are constructed from the line parameters.
    """
    if not lops:
        msg = "At least one LOP is required"
        raise ValueError(msg)

    if len(lops) == 1:
        # Single LOP - can't triangulate, return intersection with surface
        lop = lops[0]
        result = calculate_wgs84_intersection(lop["origin_xyz_m"], lop["direction"])
        if result is None:
            # No intersection - return origin
            return lop["origin_xyz_m"]
        return result

    # Multiple LOPs - find least-squares closest point
    # For each line i: P(t) = pᵢ + t*dᵢ
    # We want to find point x that minimizes Σᵢ ||pᵢ + tᵢ*dᵢ - x||²

    # This is equivalent to solving:
    # (I - dᵢdᵢᵀ)(x - pᵢ) = 0 for all i
    # Which gives us an overdetermined linear system

    n = len(lops)
    a = np.zeros((3 * n, 3))
    b = np.zeros(3 * n)

    for i, lop in enumerate(lops):
        p = lop["origin_xyz_m"]
        d = lop["direction"]

        # Construct (I - ddᵀ) matrix for this line
        # This is the projection onto the plane perpendicular to d
        i_minus_ddt = np.eye(3) - np.outer(d, d)

        # Add to system
        a[3 * i : 3 * i + 3, :] = i_minus_ddt
        b[3 * i : 3 * i + 3] = i_minus_ddt @ p

    # Solve least-squares: x = (AᵀA)⁻¹Aᵀb
    try:
        ata = a.T @ a
        atb = a.T @ b
        x = np.linalg.solve(ata, atb)
    except np.linalg.LinAlgError:
        # Singular matrix - use pseudo-inverse
        x = np.linalg.lstsq(a, b, rcond=None)[0]

    return x
