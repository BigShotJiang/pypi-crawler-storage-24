# Analysis of Patent Paper Functions

This document analyzes each function in the patent_paper module to determine if they can be replaced by or are similar to existing numpy/scipy methods.

## Analysis of Patent Paper Functions

### **1. [calculate_clock_cone_aoa.py](calculate_clock_cone_aoa.py)**

**Purpose:** Calculate clock and cone angles between emitter and receiver positions.

**Can it be replaced?** **Partially - uses existing library**
- Already leverages `gri_utils.conversion.xyz_to_aer` for the heavy lifting
- The actual computation is just coordinate transformation + simple angle conversion
- **Similar to:** Could be done with basic numpy vector math (`arctan2`, `arccos`), but the gri_utils dependency handles ECEF coordinate frame rotations
- **Verdict:** Well-abstracted; clock/cone is just azimuth/elevation with cone being the negative of elevation

---

### **2. [calculate_ecef_pointing_vector.py](calculate_ecef_pointing_vector.py)**

**Purpose:** Convert clock/cone angles back to ECEF unit vector.

**Can it be replaced?** **Partially - uses existing library**
- Uses `gri_utils.conversion.aer_to_xyz`
- Just angle conversion + normalization
- **Similar to:** Basic spherical-to-Cartesian conversion available in `scipy.spatial.transform.Rotation` or manual with `sin`/`cos`
- **Verdict:** Thin wrapper around gri_utils; could be 3 lines of numpy trigonometry

---

### **3. [calculate_wgs84_intersection.py](calculate_wgs84_intersection.py)**

**Purpose:** Find where a ray intersects the WGS-84 ellipsoid.

**Can it be replaced?** **No direct numpy/scipy equivalent**
- Solves quadratic equation for ray-ellipsoid intersection
- **Similar to:** This is a classic computational geometry problem, but numpy/scipy don't have a built-in "ray-ellipsoid intersection" function
- **Could use:** `scipy.optimize.fsolve` to find the intersection numerically, but the analytical quadratic solution is more efficient
- **Verdict:** Custom implementation justified; ~35 lines of math that would be tedious to replace with general-purpose optimizers

---

### **4. [calculate_error_ellipse.py](calculate_error_ellipse.py)**

**Purpose:** Project uncertainty cone onto Earth's surface as error ellipse.

**Can it be replaced?** **No - domain-specific approximation**
- Geometric calculation specific to angle-of-arrival uncertainty projection
- Uses elevation-dependent elongation formulas
- **Similar to:** No direct scipy equivalent; this is application-specific geometry
- **Verdict:** Custom implementation required for this geolocation use case

---

### **5. [apply_ray_bending_correction.py](apply_ray_bending_correction.py)**

**Purpose:** Apply atmospheric refraction correction to pointing vector.

**Can it be replaced?** **No - uses specialized library**
- Depends on `gri_tropo.dgs.dgs_tropo_corrections` (ITU-R 2019 model)
- This is a domain-specific atmospheric physics model
- **Verdict:** Cannot be replaced; wraps a specialized tropospheric correction library

---

### **6. [iwlsa_iteration.py](iwlsa_iteration.py)**

**Purpose:** One iteration of weighted least-squares: `x̂ᵢ = x̂ᵢ₋₁ - (AᵀWA)⁻¹AᵀWe`

**Can it be replaced?** **Yes - scipy has this**
- This is **Gauss-Newton iteration** for nonlinear least squares
- **Direct equivalent:** `scipy.optimize.least_squares` with `method='lm'` (Levenberg-Marquardt) or `method='trf'`
- The manual implementation does:
  - Compute Jacobian numerically
  - Build normal equations `(AᵀWA)x = AᵀWe`
  - Solve with `np.linalg.inv` or `np.linalg.pinv`
- **Verdict:** Entire IWLSA could be replaced with `scipy.optimize.least_squares` with a residual function

---

### **7. [iwlsa_solver.py](iwlsa_solver.py)**

**Purpose:** Full iterative solver with convergence detection.

**Can it be replaced?** **Yes - scipy optimizers**
- This is a **nonlinear least-squares solver**
- **Direct replacement:** `scipy.optimize.least_squares` handles:
  - Iterative refinement
  - Convergence detection
  - Jacobian computation (numerical or analytical)
  - Multiple algorithms (Levenberg-Marquardt, Trust Region Reflective)
- The current implementation manually iterates `iwlsa_iteration`
- **Verdict:** The entire solver (functions 6+7) could be ~10 lines with scipy.optimize

---

### **8. [ecef_to_ijk.py](ecef_to_ijk.py)**

**Purpose:** Transform between ECEF and IJK (collector-centered) frames.

**Can it be replaced?** **Partially - uses existing library**
- Uses `gri_utils.conversion.xyz_to_enu` and `enu_to_xyz`
- Just reorders axes: `(e,n,u) → (u,e,n)`
- **Similar to:** Simple matrix multiplication or `scipy.spatial.transform.Rotation`
- **Verdict:** Thin wrapper; the hard work (ECEF↔ENU) is in gri_utils

---

### **9. [convert_clock_cone_to_az_el.py](convert_clock_cone_to_az_el.py)**

**Purpose:** Convert clock/cone ↔ azimuth/elevation.

**Can it be replaced?** **Trivial - just subtraction**
- **Code is literally:** `elevation = 90 - cone` and `azimuth = clock`
- **Verdict:** 2-line pure Python functions; no numpy/scipy needed

---

### **10. [calculate_residuals.py](calculate_residuals.py)**

**Purpose:** Compute `residual = predicted - measured` for angles.

**Can it be replaced?** **Partially**
- Core logic: loop over observations, predict angles, subtract measured
- Includes angle wrapping (`_wrap_angle` for azimuth 0-360° continuity)
- **Similar to:** This is a standard **residual function** for optimization
- With `scipy.optimize.least_squares`, you'd write this as the objective function
- **Verdict:** Custom implementation needed for the specific observation model, but angle wrapping could use `numpy.angle` or `scipy.stats.circmean` utilities

---

### **11. [compute_jacobian.py](compute_jacobian.py)**

**Purpose:** Numerically compute Jacobian matrix using finite differences.

**Can it be replaced?** **Yes - scipy has this**
- **Direct equivalent:** `scipy.optimize.approx_fprime` or the built-in Jacobian estimation in `scipy.optimize.least_squares`
- The current implementation uses central differences manually
- **Better alternative:** `numdifftools.Jacobian` for higher-order accuracy
- **Verdict:** Could use scipy's built-in numerical differentiation; even better, the patent provides analytical derivatives (Eqs 8-19) that aren't implemented

---

### **12. [create_lop_from_clock_cone.py](create_lop_from_clock_cone.py)**

**Purpose:** Create line-of-position dictionary from angles.

**Can it be replaced?** **No - data structure creation**
- Just calls `calculate_ecef_pointing_vector` and packages result
- Returns a `TypedDict` with metadata
- **Verdict:** Utility wrapper for data organization; no computation to replace

---

### **13. [multi_observation_triangulation.py](multi_observation_triangulation.py)**

**Purpose:** Find best-fit point to multiple 3D lines (least-squares triangulation).

**Can it be replaced?** **Partially - uses numpy, could use scipy**
- Solves **"closest point to N lines"** using least-squares
- Current implementation:
  - Builds overdetermined system `(I - ddᵀ)(x - p) = 0`
  - Solves with `np.linalg.solve` or `np.linalg.lstsq`
- **Could use:** `scipy.optimize.least_squares` with a residual function (distance to lines)
- **Similar to:** No direct scipy function for "3D line intersection," but the linear algebra approach is standard
- **Verdict:** Good numpy implementation; scipy wouldn't simplify much

---

### **14. [propagate_uncertainty.py](propagate_uncertainty.py)**

**Purpose:** Propagate angle uncertainties to position covariance using `Cov(x) = (AᵀWA)⁻¹`.

**Can it be replaced?** **Partially - uses standard formula**
- This is **first-order uncertainty propagation** (linearization)
- Uses the Cramér-Rao bound formula for weighted least-squares
- **Similar to:**
  - `scipy.optimize.least_squares` returns covariance via the `jac` parameter
  - The formula `(JᵀJ)⁻¹` is built into scipy's output when `method='lm'`
- **Verdict:** If using `scipy.optimize.least_squares`, you get this for free from the optimizer's covariance estimation

---

## Summary Table

| Function | Can Be Replaced? | Scipy/Numpy Equivalent | Notes |
|----------|------------------|------------------------|-------|
| 1. calculate_clock_cone_aoa | Partial | numpy trig / gri_utils | Already uses gri_utils |
| 2. calculate_ecef_pointing_vector | Partial | scipy.spatial.transform | Thin wrapper |
| 3. calculate_wgs84_intersection | No | - | Ray-ellipsoid intersection; custom justified |
| 4. calculate_error_ellipse | No | - | Domain-specific geometry |
| 5. apply_ray_bending_correction | No | - | Depends on gri_tropo |
| 6. iwlsa_iteration | **Yes** | scipy.optimize.least_squares | Gauss-Newton step |
| 7. iwlsa_solver | **Yes** | scipy.optimize.least_squares | Nonlinear LS solver |
| 8. ecef_to_ijk | Partial | gri_utils + reordering | Thin wrapper |
| 9. convert_clock_cone_to_az_el | Trivial | Pure Python subtraction | 2 lines |
| 10. calculate_residuals | Partial | Custom residual function | Needed for scipy.optimize |
| 11. compute_jacobian | **Yes** | scipy.optimize.approx_fprime | Built into optimizers |
| 12. create_lop_from_clock_cone | No | - | Data structure wrapper |
| 13. multi_observation_triangulation | Partial | np.linalg.lstsq | Good numpy implementation |
| 14. propagate_uncertainty | Partial | scipy.optimize covariance | Built into least_squares |

---

## Key Findings

1. **Functions 6, 7, 11, and 14 (IWLSA components)** could be **entirely replaced** by `scipy.optimize.least_squares` with appropriate residual/Jacobian functions
2. **Functions 1, 2, 8** are thin wrappers around `gri_utils` conversions
3. **Function 9** is trivial arithmetic
4. **Functions 3, 4, 5, 12, 13** are domain-specific and justified as custom implementations
5. **Function 10** (residuals) would still be needed as the objective function for scipy optimizers

The biggest opportunity for simplification is **replacing the manual IWLSA implementation with scipy.optimize.least_squares**, which would eliminate ~200 lines of code across 4 files.

## Recommendations

### Keep As-Is (Domain-Specific or Well-Abstracted)
- Functions 3, 4, 5: Custom geometry and atmospheric modeling
- Functions 1, 2, 8: Thin wrappers around gri_utils (appropriate abstraction)
- Functions 12, 13: Utility functions with good numpy implementations

### Consider Refactoring
- **Functions 6, 7, 11, 14**: Replace manual IWLSA with `scipy.optimize.least_squares`
  - Benefits: More robust algorithms, automatic Jacobian, covariance estimation
  - Trade-off: Less explicit control over iteration process
  - Would reduce code complexity and maintenance burden

### Alternative Implementation Example

The current IWLSA solver could be simplified to:

```python
from scipy.optimize import least_squares

def iwlsa_solver_scipy(initial_guess_xyz_m, observations, receiver_positions_xyz_m, weights=None):
    """Solve using scipy.optimize.least_squares instead of manual IWLSA."""

    def residual_function(emitter_xyz):
        residuals = calculate_residuals(emitter_xyz, observations, receiver_positions_xyz_m)
        return residuals.flatten()

    result = least_squares(
        residual_function,
        initial_guess_xyz_m,
        method='lm',  # Levenberg-Marquardt (similar to IWLSA)
        ftol=1e-8,
        xtol=1e-8,
    )

    return {
        'position_xyz_m': result.x,
        'iterations': result.nfev,
        'residual_m': result.cost,
        'converged': result.success,
        'covariance_m2': np.linalg.inv(result.jac.T @ result.jac),  # Replaces propagate_uncertainty
    }
```

This would replace iwlsa_iteration.py, iwlsa_solver.py, compute_jacobian.py, and propagate_uncertainty.py with a single ~20 line function.
