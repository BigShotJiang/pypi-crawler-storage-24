"""Calculate intersection of ray with WGS-84 ellipsoid surface.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.constants import ER_M, PR_M

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def calculate_wgs84_intersection(
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
    pointing_vector: NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating] | None:
    """Calculate intersection of line-of-position with WGS-84 ellipsoid surface.

    Solves for the intersection point of a ray (defined by receiver position and
    pointing vector) with the WGS-84 ellipsoid at altitude=0.

    The WGS-84 ellipsoid equation in ECEF coordinates is:
        (x/a)² + (y/a)² + (z/b)² = 1
    where a = equatorial radius, b = polar radius

    The ray is parameterized as:
        P(t) = receiver_xyz_m + t * pointing_vector

    Args:
        receiver_xyz_m: Receiver/collector position [x, y, z] in ECEF meters.
        pointing_vector: Unit direction vector [dx, dy, dz] in ECEF (normalized).

    Returns:
        Intersection point [x, y, z] in ECEF meters, or None if no intersection.
        If two intersections exist (ray passes through ellipsoid), returns the
        one in front of the receiver (smallest positive t).

    References:
        Patent US20110309983A1 - intersection of 3D LOP with terrain/surface.
        WGS-84 parameters from gri_utils.constants.
    """
    # Convert inputs to arrays (no-op if already arrays)
    receiver_xyz_m = np.asarray(receiver_xyz_m)
    pointing_vector = np.asarray(pointing_vector)

    # WGS-84 ellipsoid parameters
    a = ER_M  # Equatorial radius (meters)
    b = PR_M  # Polar radius (meters)

    # Receiver position
    x0, y0, z0 = receiver_xyz_m

    # Pointing vector (should be unit vector, but we'll handle non-unit too)
    dx, dy, dz = pointing_vector

    # Normalize pointing vector to be safe
    mag = np.linalg.norm(pointing_vector)
    if mag < 1e-10:  # noqa: PLR2004
        return None  # Degenerate vector
    dx, dy, dz = dx / mag, dy / mag, dz / mag

    # Ellipsoid equation: (x/a)² + (y/a)² + (z/b)² = 1
    # Ray: P(t) = (x0, y0, z0) + t*(dx, dy, dz)
    # Substitute ray into ellipsoid equation and solve for t:
    # ((x0 + t*dx)/a)² + ((y0 + t*dy)/a)² + ((z0 + t*dz)/b)² = 1

    # Expand to quadratic: A*t² + B*t + C = 0
    a_sq = a * a
    b_sq = b * b

    a = (dx * dx + dy * dy) / a_sq + (dz * dz) / b_sq
    b = 2.0 * ((x0 * dx + y0 * dy) / a_sq + (z0 * dz) / b_sq)
    c = (x0 * x0 + y0 * y0) / a_sq + (z0 * z0) / b_sq - 1.0

    # Solve quadratic equation
    discriminant = b * b - 4.0 * a * c

    if discriminant < 0:
        # No real solutions - ray doesn't intersect ellipsoid
        return None

    sqrt_disc = np.sqrt(discriminant)
    t1 = (-b - sqrt_disc) / (2.0 * a)
    t2 = (-b + sqrt_disc) / (2.0 * a)

    # We want the intersection in front of the receiver (positive t)
    # and prefer the closer one if both are positive
    valid_t = []
    if t1 > 1e-6:  # Small epsilon to avoid numerical issues at surface  # noqa: PLR2004
        valid_t.append(t1)
    if t2 > 1e-6:  # noqa: PLR2004
        valid_t.append(t2)

    if not valid_t:
        # Both intersections behind receiver or at receiver
        return None

    # Take the smallest positive t (closest intersection in front)
    t = min(valid_t)

    # Calculate intersection point
    return receiver_xyz_m + t * pointing_vector
