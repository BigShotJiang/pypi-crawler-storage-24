"""Three-Dimensional Direction Finding for Geolocation.

Implementation of algorithms from US Patent 20110309983A1.
https://patents.google.com/patent/US20110309983A1/en

Inventors: Bart Peters, Dave Driggs, Tyler Holzer, Greg Manassero
Assignee: Northrop Grumman Systems Corp

This module provides functions for 3D direction finding and geolocation
of emitters using angle-of-arrival measurements from airborne collectors.

Core Functions:
    - calculate_clock_cone_aoa: Compute angles between emitter and receiver
    - calculate_ecef_pointing_vector: Convert angles to ECEF direction vector
    - calculate_wgs84_intersection: Find surface intersection of line-of-position

Advanced Functions:
    - calculate_error_ellipse: Project uncertainty cone to surface ellipse
    - apply_ray_bending_correction: Atmospheric refraction correction
    - iwlsa_iteration: Single IWLSA iteration
    - iwlsa_solver: Full iterative least-squares solver

Coordinate Transforms:
    - ecef_to_ijk: ECEF to collector-centered frame
    - ijk_to_ecef: Collector-centered to ECEF frame
    - convert_clock_cone_to_az_el: Angle representation conversions

Utilities:
    - calculate_residuals: Observation residuals
    - compute_jacobian: Partial derivatives matrix
    - create_lop_from_clock_cone: Line-of-position representation
    - multi_observation_triangulation: Multi-LOP geolocation
    - propagate_uncertainty: Angle uncertainties to position covariance
"""

from .apply_ray_bending_correction import apply_ray_bending_correction
from .calculate_clock_cone_aoa import calculate_clock_cone_aoa
from .calculate_ecef_pointing_vector import calculate_ecef_pointing_vector
from .calculate_error_ellipse import calculate_error_ellipse
from .calculate_residuals import calculate_residuals
from .calculate_wgs84_intersection import calculate_wgs84_intersection
from .compute_jacobian import compute_jacobian
from .convert_clock_cone_to_az_el import (
    convert_az_el_to_clock_cone,
    convert_clock_cone_to_az_el,
)
from .create_lop_from_clock_cone import create_lop_from_clock_cone
from .ecef_to_ijk import ecef_to_ijk, ijk_to_ecef
from .iwlsa_iteration import iwlsa_iteration
from .iwlsa_solver import iwlsa_solver
from .multi_observation_triangulation import multi_observation_triangulation
from .propagate_uncertainty import propagate_uncertainty

__all__ = [
    "apply_ray_bending_correction",
    "calculate_clock_cone_aoa",
    "calculate_ecef_pointing_vector",
    "calculate_error_ellipse",
    "calculate_residuals",
    "calculate_wgs84_intersection",
    "compute_jacobian",
    "convert_az_el_to_clock_cone",
    "convert_clock_cone_to_az_el",
    "create_lop_from_clock_cone",
    "ecef_to_ijk",
    "ijk_to_ecef",
    "iwlsa_iteration",
    "iwlsa_solver",
    "multi_observation_triangulation",
    "propagate_uncertainty",
]
