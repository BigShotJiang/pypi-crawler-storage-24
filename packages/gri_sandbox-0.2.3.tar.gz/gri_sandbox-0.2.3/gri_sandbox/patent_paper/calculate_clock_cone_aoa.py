"""Calculate clock and cone angles of arrival between emitter and receiver.

Based on US Patent 20110309983A1 - Three-Dimensional Direction Finding.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.conversion import xyz_to_aer

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def calculate_clock_cone_aoa(
    emitter_xyz_m: NDArray[np.floating] | Sequence[float],
    receiver_xyz_m: NDArray[np.floating] | Sequence[float],
) -> tuple[float, float]:
    """Calculate clock and cone angle of arrival from emitter to receiver.

    Uses clock and cone angle convention where:
    - Clock angle (θ) = azimuth angle
    - Cone angle (φ) = angle from horizon

    Cone angle definition:
    - 0° = horizon
    - 90° = straight down (nadir)
    - -90° = straight up (zenith)

    Args:
        emitter_xyz_m: Emitter position [x, y, z] in ECEF meters.
                       Accepts array or sequence (list/tuple).
        receiver_xyz_m: Receiver/collector position [x, y, z] in ECEF meters.
                        Accepts array or sequence (list/tuple).

    Returns:
        Tuple of (clock_deg, cone_deg):
            - clock_deg: Clock/azimuth angle in degrees (0-360, 0=North, 90=East)
            - cone_deg: Cone angle in degrees (0=horizon, 90=nadir/down, -90=zenith/up)

    References:
        Patent US20110309983A1, Equations 1-7.
    """
    # Convert inputs to arrays (no-op if already arrays)
    emitter_xyz_m = np.asarray(emitter_xyz_m)
    receiver_xyz_m = np.asarray(receiver_xyz_m)

    # Calculate vector from receiver to emitter in ECEF
    vec_m = emitter_xyz_m - receiver_xyz_m

    # Use gri_utils to get azimuth and elevation angles
    # xyz_to_aer returns [azimuth_deg, elevation_deg, range_m]
    aer = xyz_to_aer(receiver_xyz_m, vec_m)
    azimuth_deg = aer[0]  # Already in degrees, 0=North, 90=East
    elevation_deg = aer[1]  # Degrees above horizon

    # Clock angle is the same as azimuth
    clock_deg = azimuth_deg

    # Cone angle is measured from horizon
    # elevation_deg: +90 = zenith, 0 = horizon, -90 = nadir
    # cone_deg: -90 = zenith, 0 = horizon, 90 = nadir
    cone_deg = -elevation_deg

    return clock_deg, cone_deg
