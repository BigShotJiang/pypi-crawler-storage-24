"""Plotting functions for ionospheric correction visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_plot.scatter import scatter

if TYPE_CHECKING:
    from numpy.typing import NDArray


def plot_iono_corrections(  # noqa: PLR0913
    elevations: NDArray,
    angle_min: NDArray,
    angle_max: NDArray,
    time_min: NDArray,
    time_max: NDArray,
    model_name: str,
    frequency: float,
    duration_s: float,
) -> None:
    """Plot ionospheric corrections vs elevation angle with dual Y axes.

    Plots both angular corrections (left Y axis, in degrees) and time corrections
    (right Y axis, in seconds) with min/max shading for each.

    Args:
        elevations: Elevation angles in degrees (0 to 90).
        angle_min: Minimal angular corrections (in radians).
        angle_max: Maximal angular corrections (in radians).
        time_min: Minimal ionospheric time delays (in seconds).
        time_max: Maximal ionospheric time delays (in seconds).
        model_name: Name of the ionospheric model (e.g., "Bent").
        frequency: Signal frequency in Hz.
        duration_s: Processing time in seconds.
    """
    frequency_mhz = frequency / 1e6

    # Convert radians to degrees for display
    angle_min_deg = np.rad2deg(angle_min)
    angle_max_deg = np.rad2deg(angle_max)

    # Colors for each correction type (chosen to stand out on black background)
    angle_color = "#00FFFF"  # Cyan
    time_color = "#FFA500"  # Orange

    scatter(
        # Angular corrections (left Y axis)
        (
            elevations,
            angle_min_deg,
            {"line": {"color": angle_color}, "showlegend": False},
        ),
        (
            elevations,
            angle_max_deg,
            {
                "line": {"color": angle_color},
                "fill": "tonexty",
                "fillcolor": "rgba(0, 255, 255, 0.2)",
                "showlegend": False,
            },
        ),
        # Time corrections (right Y axis)
        (
            elevations,
            time_min,
            {"line": {"color": time_color}, "yaxis": "y2", "showlegend": False},
        ),
        (
            elevations,
            time_max,
            {
                "line": {"color": time_color},
                "fill": "tonexty",
                "fillcolor": "rgba(255, 165, 0, 0.2)",
                "yaxis": "y2",
                "showlegend": False,
            },
        ),
        title=f"{model_name} Ionospheric Corrections: {frequency_mhz:.0f}MHz, Proc Time: {duration_s:,.3f}s",  # noqa: E501
        xaxis_title="Elevation Angle (degrees)",
        yaxis_title="Angular Correction (degrees)",
        yaxis={
            "title": {"font": {"color": angle_color}},
            "tickfont": {"color": angle_color},
        },
        yaxis2={
            "title": {"text": "Time Delay (seconds)", "font": {"color": time_color}},
            "overlaying": "y",
            "side": "right",
            "tickfont": {"color": time_color},
        },
    )
