"""Ionospheric correction min/max visualization.

This module demonstrates the range of ionospheric delay effects across different
ionospheric models (Bent, NeQuick2, NeQuickG) by computing minimal and maximal
corrections as a function of elevation angle.
"""
