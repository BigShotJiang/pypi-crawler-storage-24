"""Interpolator comparison for orbital ephemeris data."""
