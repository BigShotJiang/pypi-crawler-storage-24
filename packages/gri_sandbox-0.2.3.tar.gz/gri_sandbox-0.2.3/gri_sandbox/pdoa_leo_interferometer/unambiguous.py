"""Demo: Unambiguous PDOA Geolocation with Short Baselines.

This demo shows single-measurement geolocation using Phase Difference of Arrival
(PDOA) from a LEO satellite with a short-baseline interferometer array.

Key Concepts:
    - Short baseline: Element spacing = lambda/4 (quarter wavelength)
    - Unambiguous: Phase differences never exceed +/- pi/2, so no phase wrapping
    - Surface constraint: Target altitude assumed = 0 (on Earth's surface)

How It Works:
    1. Satellite observes RF signal from ground target
    2. Each antenna element measures phase relative to reference
    3. Phase differences encode direction cosines (dot products with baselines)
    4. 3D direction recovered from overdetermined system (3 baselines)
    5. Ray-Earth intersection gives ground position

Geometry:
    - 4-element L-shaped array: reference at origin, elements along +X and +Y
    - Element positions: (d,0,0), (2d,0,0), (0,d,0) where d = lambda/4
    - Two x-baselines provide redundancy, y-baseline provides orthogonal measurement

Why Short Baselines?
    With d = lambda/4, the maximum phase difference is:
        phi_max = 2*pi*d/lambda = pi/2 radians
    Since |phi| < pi, there's no ambiguity - each phase difference maps to
    exactly one direction cosine.

Trade-off:
    Short baselines = unambiguous but lower angular resolution
    Long baselines = higher precision but ambiguous (see ambiguous.py)

Usage:
    python -m gri_sandbox.pdoa_leo_interferometer.unambiguous
"""

from __future__ import annotations

# ruff: noqa: T201
import numpy as np
from gri_utils.constants import C
from gri_utils.conversion import cosines_to_unit_vector, lla_to_xyz, xyz_to_lla
from gri_utils.observables.pdoa import get_pdoa
from gri_utils.observables.pdoa_to_aoa import pdoa_to_aoa

from gri_sandbox.pdoa_leo_interferometer._utils import (
    direction_to_ground,
    place_satellite_at_azel,
)


def _print_header() -> None:
    """Print demo header."""
    print("=" * 70)
    print("Demo: Unambiguous PDOA Geolocation (Short Baselines)")
    print("=" * 70)
    print()


def _print_signal_params(frequency: float, wavelength: float) -> None:
    """Print signal parameters."""
    print("Signal Parameters:")
    print(f"  Frequency: {frequency / 1e9:.1f} GHz")
    print(f"  Wavelength: {wavelength:.3f} m")
    print()


def _print_array_geometry(
    spacing_factor: float,
    spacing_m: float,
    element_positions: np.ndarray,
) -> None:
    """Print array geometry information."""
    print("Array Geometry:")
    print(f"  Spacing: {spacing_factor} x wavelength = {spacing_m:.4f} m")
    print("  Element positions (array frame):")
    print("    Reference: [0.0000, 0.0000, 0.0000] m")
    for i, pos in enumerate(element_positions):
        print(f"    Element {i + 1}: [{pos[0]:.4f}, {pos[1]:.4f}, {pos[2]:.4f}] m")
    print()


def _print_target(lat: float, lon: float) -> None:
    """Print target information."""
    print("Target:")
    print(f"  Location: Munich ({lat:.4f} N, {lon:.4f} E)")
    print()


def _print_measurement(
    sat_xyz: np.ndarray,
    aoa: np.ndarray,
    ground_xyz: np.ndarray | None,
    target_xyz: np.ndarray,
) -> None:
    """Print measurement results."""
    sat_lla = xyz_to_lla(sat_xyz)
    print("Measurement:")
    print(
        f"  Satellite: {sat_lla[0]:.4f} N, {sat_lla[1]:.4f} E, "
        f"{sat_lla[2] / 1000:.1f} km alt",
    )
    print(f"  AOA (direction cosines): [{aoa[0]:.6f}, {aoa[1]:.6f}]")
    if ground_xyz is not None:
        ground_lla = xyz_to_lla(ground_xyz)
        error = np.linalg.norm(ground_xyz - target_xyz)
        print(f"  Ground intersection: {ground_lla[0]:.4f} N, {ground_lla[1]:.4f} E")
        print(f"  Position error: {error:.1f} m")
    else:
        print("  No ground intersection (ray missed Earth)")
    print()


def _print_summary() -> None:
    """Print demo summary."""
    print("Summary:")
    print("  - Single PDOA measurement provides 2D direction (azimuth + elevation)")
    print("  - Surface constraint (alt=0) provides the third constraint")
    print("  - Result: Full 3D ground position from one measurement")
    print()


def run_demo() -> None:
    """Run the unambiguous PDOA geolocation demonstration."""
    _print_header()

    # Signal parameters
    frequency = 1e9  # Hz (1 GHz)
    wavelength = C / frequency
    _print_signal_params(frequency, wavelength)

    # Array geometry: L-shaped with spacing = lambda/4 (unambiguous)
    # Two baselines along x-axis, one along y-axis
    spacing_factor = 0.25
    spacing_m = wavelength * spacing_factor
    element_positions = np.array(
        [
            [spacing_m, 0.0, 0.0],  # Element 1: +X at 1*spacing
            [2 * spacing_m, 0.0, 0.0],  # Element 2: +X at 2*spacing
            [0.0, spacing_m, 0.0],  # Element 3: +Y at 1*spacing
        ],
    )
    _print_array_geometry(spacing_factor, spacing_m, element_positions)

    # Target: Munich
    target_lat, target_lon = 48.1351, 11.5820
    target_xyz = lla_to_xyz((target_lat, target_lon, 0.0))
    _print_target(target_lat, target_lon)

    # Satellite: Place at 75 deg elevation, 15 deg azimuth from target
    sat_xyz, sat_quat = place_satellite_at_azel(
        target_xyz,
        azimuth_deg=15.0,
        elevation_deg=75.0,
    )

    # Forward problem: compute true PDOA
    pdoa = get_pdoa(sat_xyz, target_xyz, sat_quat, element_positions, frequency)

    # Inverse problem: recover direction from PDOA
    # pdoa_to_aoa returns (K, 2) array; for unambiguous arrays K=1
    aoas = pdoa_to_aoa(pdoa, element_positions, frequency)
    aoa = aoas[0]
    direction_3d = cosines_to_unit_vector(aoa)

    # Surface constraint: intersect with Earth
    ground_xyz = direction_to_ground(sat_xyz, direction_3d, sat_quat)

    _print_measurement(sat_xyz, aoa, ground_xyz, target_xyz)
    _print_summary()


def main() -> None:
    """Entry point for the demo."""
    run_demo()


if __name__ == "__main__":
    main()
