"""Shared utilities for PDOA LEO interferometer demos.

This module contains common functions used by both the unambiguous and ambiguous
PDOA geolocation demonstrations.

Key Functions:
    place_satellite_at_azel: Place satellite at az/el from target
    direction_to_ground: Intersect direction ray with Earth surface

Physics Background:
    For a signal arriving from direction u (unit vector in array frame), the phase
    at element k relative to the reference element is:
        phi_k = (2*pi*f/c) * dot(element_position_k, u)

    This is the forward problem (implemented in gri_utils.observables.pdoa.get_pdoa).
    The inverse problem (PDOA -> AOA) recovers u from measured phases via
    least-squares (implemented in gri_utils.observables.pdoa_to_aoa.pdoa_to_aoa).
"""

from __future__ import annotations

import numpy as np
from gri_utils.conversion import get_aer, translate_aer
from gri_utils.distance import slant_range
from scipy.spatial.transform import Rotation

# Constants
LEO_ALTITUDE = 550_000.0  # meters (typical Starlink-ish altitude)


def _nadir_pointing_quaternion(sat_xyz: np.ndarray) -> np.ndarray:
    """Create quaternion for nadir-pointing array orientation.

    Array frame convention:
        - Z-axis: points toward Earth center (nadir)
        - X-axis: points East (local East at sub-satellite point)
        - Y-axis: points North (completes right-handed system)

    This orientation puts ground targets in the +Z hemisphere of the array frame.

    Args:
        sat_xyz: Satellite ECEF position (meters).

    Returns:
        Quaternion [x, y, z, w] for ECEF-to-array rotation (scipy convention).
    """
    # Z-axis points toward nadir (Earth center)
    z_array = -sat_xyz / np.linalg.norm(sat_xyz)

    # X-axis is local East: cross(world_up, nadir)
    # where world_up = [0, 0, 1] (ECEF Z-axis, toward North pole)
    world_up = np.array([0.0, 0.0, 1.0])
    x_array = np.cross(world_up, z_array)
    x_norm = np.linalg.norm(x_array)

    # Degenerate case: satellite directly over pole - use arbitrary direction
    x_array = (
        np.array([1.0, 0.0, 0.0]) if x_norm < 1e-10 else x_array / x_norm  # noqa: PLR2004
    )

    # Y-axis completes right-handed system (roughly North)
    y_array = np.cross(z_array, x_array)

    # Rotation matrix: columns = array axes in ECEF = array-to-ECEF
    # We need ECEF-to-array, so transpose
    rot_array_to_ecef = np.column_stack([x_array, y_array, z_array])
    rot_ecef_to_array = rot_array_to_ecef.T

    return Rotation.from_matrix(rot_ecef_to_array).as_quat()


def place_satellite_at_azel(
    ground_xyz: np.ndarray,
    azimuth_deg: float,
    elevation_deg: float,
    altitude_m: float = LEO_ALTITUDE,
) -> tuple[np.ndarray, np.ndarray]:
    """Place satellite at specified azimuth/elevation from target.

    Args:
        ground_xyz: ECEF position on ground (meters).
        azimuth_deg: Azimuth from target to satellite (degrees, 0=North, 90=East).
        elevation_deg: Elevation from target to satellite (degrees above horizon).
        altitude_m: Satellite altitude above Earth surface (meters).

    Returns:
        Tuple of (sat_xyz, sat_quat):
            - sat_xyz: Satellite ECEF position (meters)
            - sat_quat: Array orientation quaternion (scipy [x,y,z,w])

    Raises:
        ValueError: If no valid intersection exists at the specified elevation.
    """
    # Compute range from target to satellite altitude along this direction
    range_m = slant_range(ground_xyz, azimuth_deg, elevation_deg, altitude_m)
    if range_m is None:
        msg = (
            f"No intersection at elevation {elevation_deg} deg "
            f"with altitude {altitude_m} m"
        )
        raise ValueError(msg)

    # Place satellite at this position
    sat_xyz = translate_aer(
        ground_xyz,
        np.array([azimuth_deg, elevation_deg, range_m]),
    )

    # Create nadir-pointing orientation
    sat_quat = _nadir_pointing_quaternion(sat_xyz)

    return sat_xyz, sat_quat


def direction_to_ground(
    sat_xyz: np.ndarray,
    direction_array: np.ndarray,
    sat_quat: np.ndarray,
) -> np.ndarray | None:
    """Intersect direction ray with WGS84 Earth surface (altitude=0).

    Projects a ray from the satellite position along the specified direction
    (in array frame) and finds where it intersects the Earth's surface.

    Args:
        sat_xyz: Satellite ECEF position (meters).
        direction_array: Unit direction in array frame (3D).
        sat_quat: ECEF-to-array rotation quaternion.

    Returns:
        Ground intersection point in ECEF (meters), or None if ray doesn't
        intersect Earth surface (e.g., pointing away from Earth).
    """
    # Rotate direction from array frame to ECEF
    # sat_quat is ECEF-to-array, so inverse transforms array-to-ECEF
    rot = Rotation.from_quat(sat_quat)
    direction_ecef = rot.inv().apply(direction_array)

    # Convert direction to az/el at satellite position using get_aer
    test_point = sat_xyz + direction_ecef * 100_000.0  # 100km along direction
    aer = get_aer(sat_xyz, test_point)
    az_deg, el_deg = aer[0], aer[1]

    # Use slant_range with WGS84 ellipsoid at target altitude = 0
    range_m = slant_range(sat_xyz, az_deg, el_deg, target_altitude_m=0.0)

    if range_m is None:
        return None

    return sat_xyz + direction_ecef * range_m
