"""PDOA LEO Interferometer Geolocation Demo.

Demonstrates Phase Difference of Arrival (PDOA) geolocation using a LEO
satellite with an interferometer array. Two scenarios are provided:

Demos:
    unambiguous.py:
        Short baseline (lambda/4) interferometer. Phase differences never
        wrap, so each measurement uniquely determines direction. Combined
        with surface constraint (altitude=0), a single measurement yields
        ground position.

    ambiguous.py:
        Long baseline (lambda) interferometer. Higher angular precision but
        phase wrapping creates multiple candidate directions. Platform motion
        along the orbit provides changing geometry that enables disambiguation
        via consistency checking.

Usage:
    # Run both demos:
    python -m gri_sandbox.pdoa_leo_interferometer.main

    # Run individual demos:
    python -m gri_sandbox.pdoa_leo_interferometer.unambiguous
    python -m gri_sandbox.pdoa_leo_interferometer.ambiguous

Key Dependencies:
    - gri_utils.observables.pdoa: Forward problem (geometry -> phase differences)
    - gri_utils.observables.pdoa_to_aoa: Inverse problem (phases -> direction)
    - gri_utils.orbit: Orbital mechanics for satellite state propagation
"""
