"""Demo: Ambiguous PDOA Disambiguation with Long Baselines.

This demo shows multi-measurement disambiguation using Phase Difference of
Arrival (PDOA) from a LEO satellite with a long-baseline interferometer array.

Key Concepts:
    - Long baseline: Element spacing = 1 x wavelength
    - Ambiguous: Phase differences can wrap, creating multiple candidate directions
    - Changing geometry: Different satellite positions help distinguish true solutions
    - Consistency check: True direction produces consistent ground positions

The Ambiguity Problem:
    With element spacing d = lambda, the maximum phase difference is:
        phi_max = 2*pi*d/lambda = 2*pi radians

    Since phase is periodic mod 2*pi, a measured phase phi could correspond to
    any of the "unwrapped" values: phi, phi + 2*pi, phi - 2*pi, etc. Each
    unwrapped phase maps to a different direction cosine, creating ambiguity.

    For this L-shaped array with element at 2*lambda, each measurement produces
    multiple valid AOA candidates (grating lobes). The overdetermined system
    constrains valid wrap combinations.

Disambiguation Algorithm:
    1. For each measurement, compute all candidate AOAs (N per measurement)
    2. Project each candidate to a ground position
    3. Find the combination (one per measurement) with minimum position spread
    4. This combination identifies the true direction

    The key insight: the true direction produces consistent ground positions
    across all measurements, while ambiguous directions "move" as geometry changes.

Geometry:
    - 4-element L-shaped array: reference at origin, elements along +X and +Y
    - Element positions: (d,0,0), (2d,0,0), (0,d,0) where d = lambda
    - Multiple measurements at varying az/el to change geometry

Usage:
    python -m gri_sandbox.pdoa_leo_interferometer.ambiguous
"""

from __future__ import annotations

# ruff: noqa: T201
import numpy as np
from gri_utils.constants import C
from gri_utils.conversion import cosines_to_unit_vector, lla_to_xyz, xyz_to_lla
from gri_utils.observables.pdoa import get_pdoa
from gri_utils.observables.pdoa_to_aoa import pdoa_to_aoa

from gri_sandbox.pdoa_leo_interferometer._utils import (
    direction_to_ground,
    place_satellite_at_azel,
)


def _print_header() -> None:
    """Print demo header."""
    print("=" * 70)
    print("Demo: Ambiguous PDOA Disambiguation (Long Baselines)")
    print("=" * 70)
    print()


def _print_signal_params(frequency: float, wavelength: float) -> None:
    """Print signal parameters."""
    print("Signal Parameters:")
    print(f"  Frequency: {frequency / 1e9:.1f} GHz")
    print(f"  Wavelength: {wavelength:.3f} m")
    print()


def _print_array_geometry(
    spacing_factor: float,
    spacing_m: float,
    element_positions: np.ndarray,
) -> None:
    """Print array geometry information."""
    print("Array Geometry:")
    print(f"  Spacing: {spacing_factor} x wavelength = {spacing_m:.4f} m")
    print("  Element positions (array frame):")
    print("    Reference: [0.0000, 0.0000, 0.0000] m")
    for i, pos in enumerate(element_positions):
        print(f"    Element {i + 1}: [{pos[0]:.4f}, {pos[1]:.4f}, {pos[2]:.4f}] m")
    print("  Note: d >= lambda -> phase wrapping -> multiple candidates per meas.")
    print()


def _print_target(lat: float, lon: float) -> None:
    """Print target information."""
    print("Target:")
    print(f"  Location: Munich ({lat:.4f} N, {lon:.4f} E)")
    print()


def _find_consistent_solution(ground_positions: np.ndarray) -> tuple[np.ndarray, float]:
    """Find most consistent ground position combination across measurements.

    Uses vectorized numpy operations to enumerate all valid combinations
    (one candidate per measurement) and find the one with minimum spread.

    Args:
        ground_positions: Shape (M, N, 3) array where M = measurements,
            N = candidates per measurement, values are XYZ coordinates.
            NaN values indicate invalid (no ground intersection) candidates.

    Returns:
        Tuple of (selected_positions, spread) where selected_positions is
        shape (M, 3) and spread is the standard deviation of distances
        from centroid.
    """
    m, n, _ = ground_positions.shape

    # Generate all index combinations: shape (N^M, M)
    # Each row selects one candidate index per measurement
    grids = np.meshgrid(*[np.arange(n)] * m, indexing="ij")
    indices = np.stack(grids, axis=-1).reshape(-1, m)  # (N^M, M)

    # Gather all combinations: shape (N^M, M, 3)
    combos = ground_positions[np.arange(m), indices]

    # Filter out combinations with any NaN values
    valid_mask = ~np.any(np.isnan(combos), axis=(1, 2))
    if not np.any(valid_mask):
        # No valid combinations - return first candidate from each measurement
        return ground_positions[:, 0, :], float("inf")

    valid_combos = combos[valid_mask]
    valid_indices = indices[valid_mask]

    # Compute centroid for each combination: shape (num_valid, 3)
    centroids = valid_combos.mean(axis=1)

    # Distance from centroid for each point: shape (num_valid, M)
    distances = np.linalg.norm(valid_combos - centroids[:, np.newaxis, :], axis=2)

    # Spread (std of distances) for each combination: shape (num_valid,)
    spreads = distances.std(axis=1)

    # Find minimum spread
    best_idx = np.argmin(spreads)
    best_indices = valid_indices[best_idx]

    selected = ground_positions[np.arange(m), best_indices]
    return selected, float(spreads[best_idx])


def _process_measurements(
    states: list[tuple[np.ndarray, np.ndarray]],
    target_xyz: np.ndarray,
    element_positions: np.ndarray,
    frequency: float,
) -> np.ndarray:
    """Process all measurements and return ground position candidates.

    Args:
        states: List of (sat_xyz, sat_quat) tuples for each measurement.
        target_xyz: Target ECEF position.
        element_positions: Array element positions.
        frequency: Signal frequency in Hz.

    Returns:
        Ground positions array of shape (M, N, 3) where M = measurements,
        N = max candidates per measurement. Invalid positions are NaN.
    """
    m = len(states)

    # First pass: get candidate counts to determine N
    all_aoas = []
    for sat_xyz, sat_quat in states:
        pdoa = get_pdoa(sat_xyz, target_xyz, sat_quat, element_positions, frequency)
        aoas = pdoa_to_aoa(pdoa, element_positions, frequency)
        all_aoas.append(aoas)

    n = max(len(aoas) for aoas in all_aoas)

    # Build ground positions array
    ground_positions = np.full((m, n, 3), np.nan)

    for i, ((sat_xyz, sat_quat), aoas) in enumerate(zip(states, all_aoas, strict=True)):
        for j, aoa in enumerate(aoas):
            direction_3d = cosines_to_unit_vector(aoa)
            ground_xyz = direction_to_ground(sat_xyz, direction_3d, sat_quat)
            if ground_xyz is not None:
                ground_positions[i, j, :] = ground_xyz

    return ground_positions


def _print_measurements(
    states: list[tuple[np.ndarray, np.ndarray]],
    ground_positions: np.ndarray,
    target_xyz: np.ndarray,
) -> None:
    """Print measurement details."""
    print("Measurements:")
    print("-" * 60)

    _m, n, _ = ground_positions.shape
    for i, (sat_xyz, _sat_quat) in enumerate(states):
        sat_lla = xyz_to_lla(sat_xyz)
        print(
            f"Measurement {i + 1}: Satellite at "
            f"{sat_lla[0]:.2f} N, {sat_lla[1]:.2f} E, {sat_lla[2] / 1000:.0f} km",
        )

        for j in range(n):
            pos = ground_positions[i, j]
            if np.isnan(pos[0]):
                print(f"  Candidate {j + 1}: No ground intersection")
            else:
                error = np.linalg.norm(pos - target_xyz)
                lla = xyz_to_lla(pos)
                print(
                    f"  Candidate {j + 1}: {lla[0]:.4f} N, {lla[1]:.4f} E "
                    f"(error: {error:.0f} m)",
                )
        print()


def _print_disambiguation_result(
    selected_positions: np.ndarray,
    spread: float,
    target_xyz: np.ndarray,
) -> None:
    """Print disambiguation result."""
    print("Disambiguation Result:")
    print("-" * 60)

    centroid = np.mean(selected_positions, axis=0)
    centroid_lla = xyz_to_lla(centroid)
    final_error = np.linalg.norm(centroid - target_xyz)

    print(f"  Position spread (std): {spread:.1f} m")
    print(f"  Centroid: {centroid_lla[0]:.4f} N, {centroid_lla[1]:.4f} E")
    print(f"  Final position error: {final_error:.1f} m")
    print()

    if spread < 1000:  # noqa: PLR2004
        print("  Result: SUCCESS - Ambiguity resolved")
        print("  Consistent candidate across all measurements is the true solution.")
    else:
        print("  Result: AMBIGUOUS - More measurements needed")
        print("  Position spread too large to confidently identify true solution.")
    print()


def _print_summary() -> None:
    """Print demo summary."""
    print("Summary:")
    print("  - Long baselines (d >= lambda) create multiple candidate AOAs")
    print("  - Changing satellite geometry causes ambiguous solutions to 'move'")
    print("  - True solution remains consistent across all measurements")
    print("  - Vectorized search finds minimum-spread combination efficiently")
    print()


def run_demo() -> None:
    """Run the ambiguous PDOA disambiguation demonstration."""
    _print_header()

    # Signal parameters
    frequency = 1e9  # Hz (1 GHz)
    wavelength = C / frequency
    _print_signal_params(frequency, wavelength)

    # Array geometry: L-shaped with spacing = lambda (ambiguous, high precision)
    spacing_factor = 1.0
    spacing_m = wavelength * spacing_factor
    element_positions = np.array(
        [
            [spacing_m, 0.0, 0.0],  # Element 1: +X at 1*lambda
            [2 * spacing_m, 0.0, 0.0],  # Element 2: +X at 2*lambda
            [0.0, spacing_m, 0.0],  # Element 3: +Y at 1*lambda
        ],
    )
    _print_array_geometry(spacing_factor, spacing_m, element_positions)

    # Target: Munich
    target_lat, target_lon = 48.1351, 11.5820
    target_xyz = lla_to_xyz((target_lat, target_lon, 0.0))
    _print_target(target_lat, target_lon)

    # Observation plan: varying az/el to change geometry
    elevation_angles = [80.0, 75.0, 70.0, 65.0, 60.0]
    azimuth_angles = [0.0, 5.0, 10.0, 15.0, 20.0]

    # Generate satellite positions
    states = [
        place_satellite_at_azel(target_xyz, azimuth_deg=az, elevation_deg=el)
        for az, el in zip(azimuth_angles, elevation_angles, strict=True)
    ]

    # Process all measurements
    ground_positions = _process_measurements(
        states,
        target_xyz,
        element_positions,
        frequency,
    )

    _print_measurements(states, ground_positions, target_xyz)

    # Find consistent solution using vectorized search
    selected_positions, spread = _find_consistent_solution(ground_positions)

    _print_disambiguation_result(selected_positions, spread, target_xyz)
    _print_summary()


def main() -> None:
    """Entry point for the demo."""
    run_demo()


if __name__ == "__main__":
    main()
