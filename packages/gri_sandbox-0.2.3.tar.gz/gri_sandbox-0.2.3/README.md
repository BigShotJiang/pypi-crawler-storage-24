[![GeoSol Research Logo](https://geosolresearch.com/logos/foss_logo.png "GeoSol Research")](https://geosolresearch.com)

# Sandbox

Demos, experiments, and integration tests for the GRI FOSS ecosystem.

gri-sandbox is not a pip-installable library. It is a collection of standalone scripts that exercise functionality from across the GRI package suite.

## Installation

```bash
git clone https://gitlab.com/geosol-foss/python/gri-sandbox.git
cd gri-sandbox
. .init_venv.sh
```

## Organization

Each script lives in its own folder. By convention, the entrypoint is `main.py` or documented in a folder-specific README. Each folder has an `__init__.py` for local imports.

```python
from gri_sandbox.<folder> import <module>
```

To run any script:

```bash
python -m gri_sandbox.<folder>.main
```

## Dependencies

gri-sandbox depends on most packages in the GRI FOSS ecosystem:

- **gri-fitter**, **gri-iono**, **gri-memoize**, **gri-nsepoch**, **gri-plot**, **gri-pos**, **gri-tropo**, **gri-utils**


## Other Projects

Current list of other [GRI FOSS Projects](https://gitlab.com/geosol-foss/python/gri-sandbox/-/blob/main/.docs_other_projects.md) we are building and maintaining.

## License

MIT License. See [LICENSE](https://gitlab.com/geosol-foss/python/gri-sandbox/-/blob/main/LICENSE) for details.
