"""Analyze and plot solution regions across elevation angles.

This module generates:
1. A CSV file with 1μrad crossing points and minima locations for each elevation
2. A plot showing resolving power across elevations from -2° to 0.5°

The CSV columns:
- elevation_deg: The elevation angle
- crossing_1_lat through crossing_4_lat: Latitudes where residual crosses 1μrad
- minima_1_lat, minima_2_lat: Latitudes of residual minima (below 1μrad threshold)
"""

from __future__ import annotations

# ruff: noqa: T201
import csv
from pathlib import Path

import numpy as np
import plotly.graph_objects as go
import pytest
from gri_pos import Pos
from gri_tropo.dgs import dgs_tropo_corrections

from gri_sandbox.round_trip.apparent_pointing_vector import (
    apparent_pointing_vector_from_true,
)
from gri_sandbox.round_trip.collector_position import collector_pos_at_elevation
from gri_sandbox.round_trip.find_emitter_multiple_solutions import (
    compute_correction_residual,
)
from gri_sandbox.round_trip.pointing_vector import calculate_pointing_vector

# Thresholds in radians
CROSSING_THRESHOLD_RAD = 1e-6  # 1 microradian
MINIMA_THRESHOLD_RAD = 5e-6  # 5 microradians (capture all minima in range)

# Output paths
CSV_PATH = Path(__file__).parent / "solution_regions.csv"


def _setup_scenario(elevation_deg: float) -> tuple[np.ndarray, np.ndarray, float]:
    """Set up emitter/collector scenario for a given elevation angle.

    Returns:
        Tuple of (apparent_pointing_vector, collector_xyz, collector_lon)
    """
    emitter = Pos.LLA(0.0, 0.0, 0.0)
    leo_altitude_m = 1e6
    azimuth_deg = 0.0

    collector = collector_pos_at_elevation(
        emitter,
        elevation_deg,
        leo_altitude_m,
        azimuth_deg,
    )

    true_pointing_vector = calculate_pointing_vector(collector, emitter)

    cone_correction_rad, _ = dgs_tropo_corrections(
        emitter_loc_lla=emitter.lla,
        collector_pos_xyz=collector.xyz,
    )

    apparent_pointing_vector = apparent_pointing_vector_from_true(
        true_pointing_vector,
        collector.xyz,
        cone_correction_rad,
    )

    return apparent_pointing_vector, collector.xyz, collector.lla[1]


def _compute_residual_landscape(
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    lon: float,
    lat_range: tuple[float, float] = (-1.0, 1.0),
    num_points: int = 2000,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute residual landscape over latitude range.

    Returns:
        Tuple of (latitudes, residuals)
    """
    lats = np.linspace(lat_range[0], lat_range[1], num_points)
    residuals = np.array(
        [
            compute_correction_residual(
                float(lat),
                lon,
                apparent_pointing_vector,
                collector_xyz,
            )
            for lat in lats
        ],
    )
    return lats, residuals


def _find_crossings(
    lats: np.ndarray,
    residuals: np.ndarray,
    threshold: float,
) -> list[float]:
    """Find latitude values where residual crosses threshold.

    Returns crossings in order (down crossing, up crossing pairs).
    """
    crossings = []
    above = residuals > threshold

    for i in range(len(above) - 1):
        if above[i] != above[i + 1]:
            # Linear interpolation to find exact crossing
            lat1, lat2 = lats[i], lats[i + 1]
            r1, r2 = residuals[i], residuals[i + 1]
            # Solve: r1 + (r2-r1)*(lat-lat1)/(lat2-lat1) = threshold
            crossing_lat = lat1 + (threshold - r1) * (lat2 - lat1) / (r2 - r1)
            crossings.append(float(crossing_lat))

    return crossings


def _find_minima(
    lats: np.ndarray,
    residuals: np.ndarray,
    threshold: float,
) -> list[float]:
    """Find latitude values of local minima below threshold.

    Returns minima latitudes sorted by latitude.
    """
    minima = []

    for i in range(1, len(residuals) - 1):
        if (
            residuals[i] <= residuals[i - 1]
            and residuals[i] <= residuals[i + 1]
            and residuals[i] < threshold
        ):
            # Refine using parabolic interpolation
            lat_m, lat_c, lat_p = lats[i - 1], lats[i], lats[i + 1]
            r_m, r_c, r_p = residuals[i - 1], residuals[i], residuals[i + 1]

            # Parabolic fit: vertex at -b/(2a) where f = a*x^2 + b*x + c
            # Using finite differences
            denom = 2 * (r_p - 2 * r_c + r_m)
            if abs(denom) > 1e-20:
                delta = (lat_p - lat_m) / 2
                offset = -delta * (r_p - r_m) / denom
                refined_lat = lat_c + offset
            else:
                refined_lat = lat_c

            minima.append(float(refined_lat))

    return sorted(minima)


def analyze_elevation(
    elevation_deg: float,
    lat_range: tuple[float, float] = (-1.0, 5.0),
) -> dict[str, float | None]:
    """Analyze solution regions for a single elevation angle.

    Returns:
        Dictionary with crossing and minima latitudes (None if not found)
    """
    apparent_vec, collector_xyz, lon = _setup_scenario(elevation_deg)
    lats, residuals = _compute_residual_landscape(
        apparent_vec,
        collector_xyz,
        lon,
        lat_range=lat_range,
        num_points=20000,  # High resolution needed to catch narrow crossings near lat=0
    )

    crossings = _find_crossings(lats, residuals, CROSSING_THRESHOLD_RAD)
    minima = _find_minima(lats, residuals, MINIMA_THRESHOLD_RAD)

    # Pad to fixed length (up to 4 crossings, 2 minima)
    result: dict[str, float | None] = {"elevation_deg": elevation_deg}

    for i in range(4):
        key = f"crossing_{i + 1}_lat"
        result[key] = crossings[i] if i < len(crossings) else None

    for i in range(2):
        key = f"minima_{i + 1}_lat"
        result[key] = minima[i] if i < len(minima) else None

    return result


def generate_csv(
    elevation_start: float = -2.0,
    elevation_end: float = 0.5,
    elevation_step: float = 0.1,
    lat_range: tuple[float, float] = (-1.0, 5.0),
    output_path: Path = CSV_PATH,
) -> Path:
    """Generate CSV file with solution region data.

    Args:
        elevation_start: Starting elevation angle (degrees)
        elevation_end: Ending elevation angle (degrees)
        elevation_step: Step size (degrees)
        lat_range: Latitude search range (degrees)
        output_path: Output CSV file path

    Returns:
        Path to generated CSV file
    """
    elevations = np.arange(
        elevation_start,
        elevation_end + elevation_step / 2,
        elevation_step,
    )

    fieldnames = [
        "elevation_deg",
        "crossing_1_lat",
        "crossing_2_lat",
        "crossing_3_lat",
        "crossing_4_lat",
        "minima_1_lat",
        "minima_2_lat",
    ]

    rows = []
    for elev in elevations:
        print(f"Processing elevation {elev:.1f}°...")
        row = analyze_elevation(float(elev), lat_range=lat_range)
        rows.append(row)

    with output_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"CSV written to {output_path}")
    return output_path


def load_csv(csv_path: Path = CSV_PATH) -> list[dict[str, float | None]]:
    """Load solution region data from CSV."""
    rows = []
    with csv_path.open() as f:
        reader = csv.DictReader(f)
        for row in reader:
            parsed: dict[str, float | None] = {}
            for key, value in row.items():
                if value == "" or value is None:
                    parsed[key] = None
                else:
                    parsed[key] = float(value)
            rows.append(parsed)
    return rows


def _build_error_regions(  # noqa: C901
    data: list[dict[str, float | None]],
) -> tuple[list[list[float]], list[list[float]]]:
    """Build error region polygons from crossing data.

    Returns two lists of polygons (x_coords, y_coords) for two regions:
    - Region 1: The "low" region (near lat=0, TRUE solution)
    - Region 2: The "high" region (spurious solution at higher latitudes)

    When there are 4 crossings, each region gets its own pair.
    When there are 2 crossings (merged), both regions share the same crossings,
    causing the polygons to meet/cross at that elevation.
    """
    # Region 1 (low): boundaries for the region near lat=0
    region1_lower: list[tuple[float, float]] = []  # (elev, lat)
    region1_upper: list[tuple[float, float]] = []

    # Region 2 (high): boundaries for the spurious solution region
    region2_lower: list[tuple[float, float]] = []
    region2_upper: list[tuple[float, float]] = []

    for row in data:
        elev = row["elevation_deg"]
        if elev is None:
            continue

        # Collect all crossings for this elevation
        crossing_keys = [
            "crossing_1_lat",
            "crossing_2_lat",
            "crossing_3_lat",
            "crossing_4_lat",
        ]
        crossings: list[float] = [
            row[key] for key in crossing_keys if row[key] is not None
        ]  # type: ignore[misc]

        if not crossings:
            continue

        crossings.sort()

        if len(crossings) == 4:
            # Two separate regions: first two = region 1, last two = region 2
            region1_lower.append((elev, crossings[0]))
            region1_upper.append((elev, crossings[1]))
            region2_lower.append((elev, crossings[2]))
            region2_upper.append((elev, crossings[3]))
        elif len(crossings) == 2:
            # Merged region: both polygons share the same crossings
            region1_lower.append((elev, crossings[0]))
            region1_upper.append((elev, crossings[1]))
            region2_lower.append((elev, crossings[0]))
            region2_upper.append((elev, crossings[1]))

    # Build polygon for region 1 (trace lower forward, upper backward)
    region1_x: list[float] = []
    region1_y: list[float] = []
    if region1_lower and region1_upper:
        for elev, lat in region1_lower:
            region1_x.append(elev)
            region1_y.append(lat)
        for elev, lat in reversed(region1_upper):
            region1_x.append(elev)
            region1_y.append(lat)
        # Close the polygon
        region1_x.append(region1_lower[0][0])
        region1_y.append(region1_lower[0][1])

    # Build polygon for region 2
    region2_x: list[float] = []
    region2_y: list[float] = []
    if region2_lower and region2_upper:
        for elev, lat in region2_lower:
            region2_x.append(elev)
            region2_y.append(lat)
        for elev, lat in reversed(region2_upper):
            region2_x.append(elev)
            region2_y.append(lat)
        # Close the polygon
        region2_x.append(region2_lower[0][0])
        region2_y.append(region2_lower[0][1])

    return ([region1_x, region2_x], [region1_y, region2_y])


def create_solution_regions_plot(
    csv_path: Path = CSV_PATH,
    show: bool = True,  # noqa: FBT001, FBT002
) -> go.Figure:
    """Create plot showing solution regions across elevations.

    Y-axis: Latitude (degrees)
    X-axis: Elevation angle (degrees)
    Filled regions: 1μrad error regions (shaded orange)
    Cyan dots: Minima locations (solutions)
    """
    data = load_csv(csv_path)

    # Collect all minima points
    minima_elevs = []
    minima_lats = []
    for row in data:
        elev = row["elevation_deg"]
        for key in ["minima_1_lat", "minima_2_lat"]:
            if row[key] is not None:
                minima_elevs.append(elev)
                minima_lats.append(row[key])

    # Build filled error regions
    region_xs, region_ys = _build_error_regions(data)

    # Create figure
    fig = go.Figure()

    # Add filled error regions (two polygons that may overlap/cross)
    for i, (rx, ry) in enumerate(zip(region_xs, region_ys, strict=True)):
        if rx and ry:
            fig.add_trace(
                go.Scatter(
                    x=rx,
                    y=ry,
                    fill="toself",
                    fillcolor="rgba(255, 140, 0, 0.3)",  # Semi-transparent orange
                    line={"color": "#FF8C00", "width": 1},
                    name="1μrad error region" if i == 0 else None,
                    showlegend=(i == 0),
                    hoverinfo="skip",
                ),
            )

    # Add minima (solutions) - cyan
    fig.add_trace(
        go.Scatter(
            x=minima_elevs,
            y=minima_lats,
            mode="markers",
            name="Minima (solutions)",
            marker={
                "color": "#00FFFF",  # Cyan
                "size": 2,
                "symbol": "circle",
            },
        ),
    )

    # Update layout for dark mode
    fig.update_layout(
        title={
            "text": "Solution Regions vs Elevation Angle",
            "font": {"size": 18, "color": "white"},
            "x": 0.5,
        },
        template="plotly_dark",
        xaxis={
            "title": "Elevation Angle (°)",
            "tickmode": "linear",
            "dtick": 0.2,
        },
        yaxis={
            "title": "Latitude (°)",
        },
        legend={
            "yanchor": "top",
            "y": 0.99,
            "xanchor": "left",
            "x": 0.01,
        },
        height=600,
        width=1000,
    )

    if show:
        fig.show()

    return fig


def create_error_bounds_plot(  # noqa: PLR0915
    csv_path: Path = CSV_PATH,
    show: bool = True,  # noqa: FBT001, FBT002
) -> go.Figure:
    """Create log-scale error bounds plot for real and spurious solutions.

    Shows error bounds (distance from minimum to nearest crossings) centered on y=0.
    Uses log scale on y-axis to visualize data across different magnitudes.

    Real solution = the one closest to lat=0 at each elevation.
    Spurious solution = the other one.
    """
    from plotly.subplots import make_subplots  # noqa: PLC0415

    data = load_csv(csv_path)

    # Extract error bounds for each solution type
    real_elevs: list[float] = []
    real_upper: list[float] = []
    real_lower: list[float] = []

    spurious_elevs: list[float] = []
    spurious_upper: list[float] = []
    spurious_lower: list[float] = []

    crossing_keys = [
        "crossing_1_lat",
        "crossing_2_lat",
        "crossing_3_lat",
        "crossing_4_lat",
    ]

    for row in data:
        elev = row["elevation_deg"]
        if elev is None:
            continue

        # Collect all crossings
        crossings: list[float] = [
            row[key] for key in crossing_keys if row[key] is not None
        ]  # type: ignore[misc]
        crossings.sort()

        # Collect minima with their error bounds: (lat, upper_err, lower_err)
        minima_data: list[tuple[float, float, float]] = []
        for min_key in ["minima_1_lat", "minima_2_lat"]:
            min_lat = row[min_key]
            if min_lat is None:
                continue

            # Find nearest crossings above and below the minimum
            above = [c for c in crossings if c > min_lat]
            below = [c for c in crossings if c < min_lat]

            if above and below:
                upper_err = abs(min(above) - min_lat)
                lower_err = abs(min_lat - max(below))
                minima_data.append((min_lat, upper_err, lower_err))

        # Classify: real = closest to 0, spurious = the other
        if len(minima_data) == 1:
            # Only one solution - it's the real one
            _, upper_err, lower_err = minima_data[0]
            real_elevs.append(elev)
            real_upper.append(upper_err)
            real_lower.append(lower_err)
        elif len(minima_data) == 2:
            # Two solutions - pick closest to 0 as real
            minima_data.sort(key=lambda x: abs(x[0]))
            _, real_u, real_l = minima_data[0]
            _, spur_u, spur_l = minima_data[1]

            real_elevs.append(elev)
            real_upper.append(real_u)
            real_lower.append(real_l)

            spurious_elevs.append(elev)
            spurious_upper.append(spur_u)
            spurious_lower.append(spur_l)

    # Create subplots
    fig = make_subplots(
        rows=2,
        cols=1,
        subplot_titles=["Real Solution Error Bounds", "Spurious Solution Error Bounds"],
        vertical_spacing=0.12,
    )

    # Real solution traces - lines only
    fig.add_trace(
        go.Scatter(
            x=real_elevs,
            y=real_upper,
            mode="lines",
            name="Upper bound (+)",
            line={"color": "#00FFFF", "width": 2},
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=real_elevs,
            y=real_lower,
            mode="lines",
            name="Lower bound (-)",
            line={"color": "#FF8C00", "width": 2},
        ),
        row=1,
        col=1,
    )

    # Spurious solution traces - lines only
    fig.add_trace(
        go.Scatter(
            x=spurious_elevs,
            y=spurious_upper,
            mode="lines",
            name="Upper bound (+)",
            line={"color": "#00FFFF", "width": 2},
            showlegend=False,
        ),
        row=2,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=spurious_elevs,
            y=spurious_lower,
            mode="lines",
            name="Lower bound (-)",
            line={"color": "#FF8C00", "width": 2},
            showlegend=False,
        ),
        row=2,
        col=1,
    )

    # Update layout
    fig.update_layout(
        title={
            "text": "Error Bounds (Log Scale)",
            "font": {"size": 18, "color": "white"},
            "x": 0.5,
        },
        template="plotly_dark",
        height=700,
        width=1000,
    )

    # Set log scale on y-axis for both subplots
    fig.update_yaxes(title_text="Error (°)", type="log", row=1, col=1)
    fig.update_yaxes(title_text="Error (°)", type="log", row=2, col=1)
    fig.update_xaxes(title_text="Elevation Angle (°)", row=2, col=1)

    if show:
        fig.show()

    return fig


@pytest.mark.skip(reason="manual only - generates CSV data")
def test_generate_csv() -> None:
    """Generate the solution regions CSV file."""
    generate_csv()


@pytest.mark.skip(reason="manual only - creates plot from CSV")
def test_create_plot() -> None:
    """Create the solution regions plot from CSV data."""
    create_solution_regions_plot()


@pytest.mark.skip(reason="manual only - full pipeline")
def test_full_analysis() -> None:
    """Run full analysis: generate CSV then create plot."""
    generate_csv()
    create_solution_regions_plot()


if __name__ == "__main__":
    # Run full analysis when executed directly
    print("Generating solution regions CSV...")
    generate_csv()
    print("Creating plot...")
    create_solution_regions_plot()
