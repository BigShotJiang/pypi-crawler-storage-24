"""Tests for clock and cone angle of arrival calculations."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import calculate_clock_cone_aoa


def test_emitter_directly_above_receiver():
    """Test angles when emitter is directly above receiver (zenith)."""
    # Receiver on surface at equator
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    # Emitter 100km directly above
    emitter_xyz_m = np.array([6478137.0, 0.0, 0.0])

    clock_deg, cone_deg = calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m)

    # Cone angle should be ~-90 (zenith/up)
    assert cone_deg < -85.0  # Should be close to -90 degrees
    # Clock angle is undefined at zenith but function should return a value
    assert 0.0 <= clock_deg <= 360.0


def test_emitter_at_horizon():
    """Test angles when emitter is roughly at horizon level."""
    # Receiver at equator
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    # Emitter at similar altitude but displaced north
    emitter_xyz_m = np.array([6378137.0, 0.0, 1000000.0])

    clock_deg, cone_deg = calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m)

    # Cone angle should be around 0 degrees (horizon)
    assert -5.0 < cone_deg < 5.0
    # Clock should point north (0 or 360 degrees)
    assert clock_deg < 5.0 or clock_deg > 355.0


def test_accepts_list_inputs():
    """Test that function accepts lists as well as numpy arrays."""
    receiver_xyz_m = [6378137.0, 0.0, 0.0]
    emitter_xyz_m = [6478137.0, 0.0, 0.0]

    clock_deg, cone_deg = calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m)

    # Should return float values
    assert isinstance(clock_deg, (float, np.floating))
    assert isinstance(cone_deg, (float, np.floating))
    # Should be valid angles
    assert 0.0 <= clock_deg <= 360.0
    assert -90.0 <= cone_deg <= 90.0
