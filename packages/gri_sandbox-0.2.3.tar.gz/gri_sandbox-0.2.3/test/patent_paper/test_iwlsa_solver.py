"""Tests for full IWLSA solver."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import calculate_clock_cone_aoa
from gri_sandbox.patent_paper.iwlsa_solver import iwlsa_solver


def test_solver_converges_to_true_position():
    """Test that IWLSA solver converges to true emitter position."""
    # True emitter position
    true_emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])

    # Multiple receiver positions
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
            [6378137.0, 0.0, 100000.0],
        ],
    )

    # Generate perfect observations
    observations = np.array(
        [
            calculate_clock_cone_aoa(true_emitter, receiver_positions[0]),
            calculate_clock_cone_aoa(true_emitter, receiver_positions[1]),
            calculate_clock_cone_aoa(true_emitter, receiver_positions[2]),
        ],
    )

    # Start with offset guess
    initial_guess = true_emitter + np.array([5000.0, 5000.0, 5000.0])

    result = iwlsa_solver(initial_guess, observations, receiver_positions)

    # Should converge close to true position
    error = np.linalg.norm(result["position_xyz_m"] - true_emitter)
    assert error < 100.0  # Within 100m


def test_solver_returns_expected_fields():
    """Test that solver result has all expected fields."""
    true_emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])
    observations = np.array(
        [calculate_clock_cone_aoa(true_emitter, receiver_positions[0])],
    )
    initial_guess = true_emitter + np.array([1000.0, 1000.0, 1000.0])

    result = iwlsa_solver(initial_guess, observations, receiver_positions)

    # Check all required fields
    assert "position_xyz_m" in result
    assert "iterations" in result
    assert "residual_m" in result
    assert "converged" in result


def test_solver_convergence_flag():
    """Test that solver reports convergence correctly."""
    true_emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
        ],
    )
    observations = np.array(
        [
            calculate_clock_cone_aoa(true_emitter, receiver_positions[0]),
            calculate_clock_cone_aoa(true_emitter, receiver_positions[1]),
        ],
    )

    # Start very close to solution
    initial_guess = true_emitter + np.array([10.0, 10.0, 10.0])

    result = iwlsa_solver(
        initial_guess,
        observations,
        receiver_positions,
        tolerance_m=100.0,
    )

    # Should converge with this tolerance
    assert result["converged"] is True
