"""Tests for residual error calculations."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import (
    calculate_clock_cone_aoa,
)
from gri_sandbox.patent_paper.calculate_residuals import calculate_residuals


def test_zero_residuals_at_true_position():
    """Test that residuals are zero when estimate equals true position."""
    # True emitter position
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])

    # Receiver position
    receiver_xyz_m = np.array([[6378137.0, 0.0, 0.0]])

    # Calculate what the angles should be at true position

    clock_deg, cone_deg = calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m[0])

    # Observations matching true position
    observations = np.array([[clock_deg, cone_deg]])

    residuals = calculate_residuals(emitter_xyz_m, observations, receiver_xyz_m)

    # Residuals should be essentially zero
    np.testing.assert_allclose(residuals, 0.0, atol=1e-6)


def test_residuals_shape():
    """Test that residuals have correct shape for multiple observations."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])

    # Three receivers
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
            [6378137.0, 0.0, 100000.0],
        ],
    )

    # Arbitrary observations
    observations = np.array([[45.0, 60.0], [90.0, 75.0], [180.0, 45.0]])

    residuals = calculate_residuals(emitter_xyz_m, observations, receiver_positions)

    # Should have shape (3, 2) - one row per observation, two columns per observation
    assert residuals.shape == (3, 2)


def test_residuals_sign_convention():
    """Test that residuals follow predicted - measured convention."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_xyz_m = np.array([[6378137.0, 0.0, 0.0]])

    # Get true angles
    true_clock, true_cone = calculate_clock_cone_aoa(emitter_xyz_m, receiver_xyz_m[0])

    # Measure lower than true
    observations = np.array([[true_clock - 5.0, true_cone - 3.0]])

    residuals = calculate_residuals(emitter_xyz_m, observations, receiver_xyz_m)

    # Predicted (true) - measured (lower) should be positive
    assert residuals[0, 0] > 0  # Clock residual
    assert residuals[0, 1] > 0  # Cone residual
