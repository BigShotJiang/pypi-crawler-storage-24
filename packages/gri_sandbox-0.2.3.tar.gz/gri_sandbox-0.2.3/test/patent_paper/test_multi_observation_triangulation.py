"""Tests for multi-observation triangulation."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import (
    calculate_clock_cone_aoa,
)
from gri_sandbox.patent_paper.create_lop_from_clock_cone import (
    create_lop_from_clock_cone,
)
from gri_sandbox.patent_paper.multi_observation_triangulation import (
    multi_observation_triangulation,
)


def test_single_lop_returns_surface_intersection():
    """Test that single LOP returns WGS84 surface intersection."""
    # Receiver above surface
    receiver_xyz_m = np.array([7000000.0, 0.0, 0.0])
    # Point downward (cone > 90 means below horizon)
    clock_deg = 0.0
    cone_deg = 135.0  # 45 degrees below horizon

    lop = create_lop_from_clock_cone(receiver_xyz_m, clock_deg, cone_deg)
    result = multi_observation_triangulation([lop])

    # Should return a position
    assert result.shape == (3,)
    # Result should be closer to Earth than receiver
    assert np.linalg.norm(result) < np.linalg.norm(receiver_xyz_m)


def test_multiple_lops_converge():
    """Test that multiple LOPs from different receivers triangulate to common point."""
    # Target point above surface
    target_xyz_m = np.array([6378137.0 + 10000.0, 50000.0, 30000.0])

    # Two receivers at different locations
    receiver1_xyz_m = np.array([6378137.0, 0.0, 0.0])
    receiver2_xyz_m = np.array([6378137.0, 100000.0, 0.0])

    # Calculate directions to target from each receiver
    clock1, cone1 = calculate_clock_cone_aoa(target_xyz_m, receiver1_xyz_m)
    clock2, cone2 = calculate_clock_cone_aoa(target_xyz_m, receiver2_xyz_m)

    # Create LOPs
    lop1 = create_lop_from_clock_cone(receiver1_xyz_m, clock1, cone1)
    lop2 = create_lop_from_clock_cone(receiver2_xyz_m, clock2, cone2)

    # Triangulate
    result = multi_observation_triangulation([lop1, lop2])

    # Should be close to target (within reasonable error for 2-LOP triangulation)
    error = np.linalg.norm(result - target_xyz_m)
    assert error < 1000.0  # Within 1km


def test_triangulation_returns_3d_position():
    """Test that triangulation always returns 3D position vector."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    lop = create_lop_from_clock_cone(receiver_xyz_m, 45.0, 60.0)

    result = multi_observation_triangulation([lop])

    assert isinstance(result, np.ndarray)
    assert result.shape == (3,)
