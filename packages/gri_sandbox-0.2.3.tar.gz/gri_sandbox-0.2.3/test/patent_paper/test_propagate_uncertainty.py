"""Tests for uncertainty propagation."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import calculate_clock_cone_aoa
from gri_sandbox.patent_paper.propagate_uncertainty import propagate_uncertainty


def test_covariance_matrix_shape():
    """Test that covariance matrix has correct shape."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
        ],
    )
    observations = np.array(
        [
            calculate_clock_cone_aoa(emitter_xyz_m, receiver_positions[0]),
            calculate_clock_cone_aoa(emitter_xyz_m, receiver_positions[1]),
        ],
    )
    angle_uncertainties = np.array([[1.0, 1.0], [1.0, 1.0]])  # 1 degree uncertainties

    cov_matrix = propagate_uncertainty(
        emitter_xyz_m,
        observations,
        receiver_positions,
        angle_uncertainties,
    )

    # Should be 3x3 covariance matrix
    assert cov_matrix.shape == (3, 3)


def test_covariance_matrix_is_symmetric():
    """Test that covariance matrix is symmetric."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])
    observations = np.array(
        [calculate_clock_cone_aoa(emitter_xyz_m, receiver_positions[0])],
    )
    angle_uncertainties = np.array([[2.0, 2.0]])

    cov_matrix = propagate_uncertainty(
        emitter_xyz_m,
        observations,
        receiver_positions,
        angle_uncertainties,
    )

    # Covariance matrix should be symmetric
    np.testing.assert_allclose(cov_matrix, cov_matrix.T, rtol=1e-10)


def test_larger_uncertainty_gives_larger_covariance():
    """Test that larger angle uncertainties result in larger position uncertainties."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
        ],
    )
    observations = np.array(
        [
            calculate_clock_cone_aoa(emitter_xyz_m, receiver_positions[0]),
            calculate_clock_cone_aoa(emitter_xyz_m, receiver_positions[1]),
        ],
    )

    # Small uncertainties
    small_uncertainties = np.array([[0.5, 0.5], [0.5, 0.5]])
    cov_small = propagate_uncertainty(
        emitter_xyz_m,
        observations,
        receiver_positions,
        small_uncertainties,
    )

    # Large uncertainties
    large_uncertainties = np.array([[5.0, 5.0], [5.0, 5.0]])
    cov_large = propagate_uncertainty(
        emitter_xyz_m,
        observations,
        receiver_positions,
        large_uncertainties,
    )

    # Trace (sum of variances) should be larger for larger uncertainties
    assert np.trace(cov_large) > np.trace(cov_small)
