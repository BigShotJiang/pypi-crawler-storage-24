"""Tests for ECEF pointing vector calculation from clock/cone angles."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import (
    calculate_clock_cone_aoa,
)
from gri_sandbox.patent_paper.calculate_ecef_pointing_vector import (
    calculate_ecef_pointing_vector,
)


def test_pointing_vector_is_unit_vector():
    """Test that the returned pointing vector is normalized."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 45.0
    cone_deg = 60.0

    vector = calculate_ecef_pointing_vector(receiver_xyz_m, clock_deg, cone_deg)

    # Should be unit vector (magnitude = 1)
    magnitude = np.linalg.norm(vector)
    np.testing.assert_allclose(magnitude, 1.0, rtol=1e-10)


def test_zenith_pointing_vector():
    """Test pointing vector when looking straight up (cone=-90)."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 0.0  # Arbitrary, doesn't matter at zenith
    cone_deg = -90.0  # Looking up (zenith)

    vector = calculate_ecef_pointing_vector(receiver_xyz_m, clock_deg, cone_deg)

    # Vector should point radially outward from Earth center
    # Normalize receiver position to compare direction
    receiver_direction = receiver_xyz_m / np.linalg.norm(receiver_xyz_m)

    # Dot product should be close to 1 (same direction)
    dot_product = np.dot(vector, receiver_direction)
    assert dot_product > 0.99  # Should be nearly 1


def test_roundtrip_with_angles():
    """Test that vector calculation is consistent with angle calculation."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 90.0  # East
    cone_deg = 45.0  # 45 degrees from zenith

    # Create pointing vector from angles
    vector = calculate_ecef_pointing_vector(receiver_xyz_m, clock_deg, cone_deg)

    # Create a point along this vector
    range_m = 100000.0  # 100 km
    emitter_xyz_m = receiver_xyz_m + range_m * vector

    # Calculate angles back from this point
    recovered_clock, recovered_cone = calculate_clock_cone_aoa(
        emitter_xyz_m,
        receiver_xyz_m,
    )

    # Should recover original angles (within numerical precision)
    np.testing.assert_allclose(recovered_clock, clock_deg, rtol=1e-6, atol=0.01)
    np.testing.assert_allclose(recovered_cone, cone_deg, rtol=1e-6, atol=0.01)
