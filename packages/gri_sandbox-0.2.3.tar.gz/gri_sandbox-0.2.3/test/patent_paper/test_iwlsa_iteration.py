"""Tests for IWLSA single iteration."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_clock_cone_aoa import calculate_clock_cone_aoa
from gri_sandbox.patent_paper.iwlsa_iteration import iwlsa_iteration


def test_iteration_improves_estimate():
    """Test that one IWLSA iteration moves toward true position."""
    # True emitter position
    true_emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])

    # Receiver positions
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
            [6378137.0, 0.0, 100000.0],
        ],
    )

    # Generate true observations
    observations = np.array(
        [
            calculate_clock_cone_aoa(true_emitter, receiver_positions[0]),
            calculate_clock_cone_aoa(true_emitter, receiver_positions[1]),
            calculate_clock_cone_aoa(true_emitter, receiver_positions[2]),
        ],
    )

    # Start with a poor estimate (offset by 10km)
    initial_estimate = true_emitter + np.array([10000.0, 10000.0, 0.0])

    # Run one iteration
    updated_estimate = iwlsa_iteration(
        initial_estimate,
        observations,
        receiver_positions,
    )

    # Updated estimate should be closer to true position
    initial_error = np.linalg.norm(initial_estimate - true_emitter)
    updated_error = np.linalg.norm(updated_estimate - true_emitter)

    assert updated_error < initial_error


def test_iteration_at_solution_stays_stable():
    """Test that iteration at true solution doesn't diverge."""
    true_emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])

    # Observation at true position
    observations = np.array(
        [calculate_clock_cone_aoa(true_emitter, receiver_positions[0])],
    )

    # Start at true position
    updated_estimate = iwlsa_iteration(true_emitter, observations, receiver_positions)

    # Should stay very close to true position
    error = np.linalg.norm(updated_estimate - true_emitter)
    assert error < 100.0  # Within 100m


def test_iteration_output_shape():
    """Test that iteration returns correct shape."""
    emitter = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])
    observations = np.array([[45.0, 60.0]])

    result = iwlsa_iteration(emitter, observations, receiver_positions)

    assert result.shape == (3,)  # Should be [x, y, z]
