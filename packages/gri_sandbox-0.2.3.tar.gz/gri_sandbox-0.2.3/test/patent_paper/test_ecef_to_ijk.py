"""Tests for ECEF to IJK coordinate transformation functions."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.ecef_to_ijk import ecef_to_ijk, ijk_to_ecef


def test_ecef_to_ijk_vector_transformation():
    """Test that a vector transforms correctly from ECEF to IJK frame."""
    # Collector at known location (roughly over equator)
    collector_xyz_m = np.array([6378137.0, 0.0, 0.0])

    # Vector pointing up (in local ENU this is "up")
    # In ECEF at this location, up = radial direction = [1, 0, 0] normalized
    ecef_up = np.array([1000.0, 0.0, 0.0])

    ijk = ecef_to_ijk(ecef_up, collector_xyz_m)

    # In IJK frame: i=up, j=east, k=north
    # An upward vector should have largest i component
    assert ijk[0] > 0  # i (up) should be positive
    assert abs(ijk[0]) > abs(ijk[1])  # i should dominate
    assert abs(ijk[0]) > abs(ijk[2])  # i should dominate


def test_ijk_to_ecef_roundtrip():
    """Test that converting ECEF -> IJK -> ECEF returns original vector."""
    collector_xyz_m = np.array([6378137.0, 0.0, 0.0])
    original_ecef = np.array([1000.0, 500.0, 200.0])

    # Convert to IJK and back
    ijk = ecef_to_ijk(original_ecef, collector_xyz_m)
    recovered_ecef = ijk_to_ecef(ijk, collector_xyz_m)

    # Should recover original vector (within numerical precision)
    np.testing.assert_allclose(recovered_ecef, original_ecef, rtol=1e-10)


def test_ecef_to_ijk_accepts_lists():
    """Test that function accepts lists as well as numpy arrays."""
    collector_xyz_m = [6378137.0, 0.0, 0.0]
    ecef_xyz_m = [1000.0, 500.0, 200.0]

    # Should not raise an exception
    ijk = ecef_to_ijk(ecef_xyz_m, collector_xyz_m)

    # Result should be numpy array
    assert isinstance(ijk, np.ndarray)
    assert ijk.shape == (3,)
