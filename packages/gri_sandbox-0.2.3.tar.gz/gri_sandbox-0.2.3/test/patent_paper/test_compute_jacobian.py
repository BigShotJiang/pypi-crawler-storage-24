"""Tests for Jacobian matrix computation."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.compute_jacobian import compute_jacobian


def test_jacobian_shape():
    """Test that Jacobian has correct shape for given observations."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])

    # Three receiver positions
    receiver_positions = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 100000.0, 0.0],
            [6378137.0, 0.0, 100000.0],
        ],
    )

    jacobian = compute_jacobian(emitter_xyz_m, receiver_positions)

    # Should be (N, 2, 3) where N=3
    # N observations, 2 angles (clock, cone), 3 position components (x, y, z)
    assert jacobian.shape == (3, 2, 3)


def test_jacobian_finite_values():
    """Test that Jacobian contains finite values (no NaN or inf)."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])

    jacobian = compute_jacobian(emitter_xyz_m, receiver_positions)

    # All values should be finite
    assert np.all(np.isfinite(jacobian))


def test_jacobian_sensitivity():
    """Test that Jacobian shows expected sensitivity patterns."""
    emitter_xyz_m = np.array([6378137.0 + 50000.0, 100000.0, 200000.0])
    receiver_positions = np.array([[6378137.0, 0.0, 0.0]])

    jacobian = compute_jacobian(emitter_xyz_m, receiver_positions, delta_m=10.0)

    # Jacobian should have non-zero derivatives (position affects angles)
    assert np.any(np.abs(jacobian) > 1e-10)
