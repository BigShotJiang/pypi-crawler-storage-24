"""Tests for Line-of-Position creation from clock/cone angles."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.create_lop_from_clock_cone import (
    create_lop_from_clock_cone,
)


def test_lop_has_required_fields():
    """Test that created LOP has all required fields."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 45.0
    cone_deg = 60.0

    lop = create_lop_from_clock_cone(receiver_xyz_m, clock_deg, cone_deg)

    # Check all required fields exist
    assert "origin_xyz_m" in lop
    assert "direction" in lop
    assert "clock_deg" in lop
    assert "cone_deg" in lop


def test_lop_direction_is_unit_vector():
    """Test that LOP direction vector is normalized."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 90.0
    cone_deg = 45.0

    lop = create_lop_from_clock_cone(receiver_xyz_m, clock_deg, cone_deg)

    magnitude = np.linalg.norm(lop["direction"])
    np.testing.assert_allclose(magnitude, 1.0, rtol=1e-10)


def test_lop_preserves_angles():
    """Test that LOP stores the input angles correctly."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    clock_deg = 123.45
    cone_deg = 67.89

    lop = create_lop_from_clock_cone(receiver_xyz_m, clock_deg, cone_deg)

    assert lop["clock_deg"] == clock_deg
    assert lop["cone_deg"] == cone_deg
