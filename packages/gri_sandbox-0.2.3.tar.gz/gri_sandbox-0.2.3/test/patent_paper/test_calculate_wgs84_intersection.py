"""Tests for WGS84 ellipsoid intersection calculations."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_wgs84_intersection import (
    calculate_wgs84_intersection,
)


def test_downward_ray_from_space_intersects():
    """Test that a ray pointing down from space intersects the surface."""
    # Start above the surface
    receiver_xyz_m = np.array([7000000.0, 0.0, 0.0])  # ~600km altitude
    # Point straight down (toward Earth center)
    pointing_vector = np.array([-1.0, 0.0, 0.0])

    intersection = calculate_wgs84_intersection(receiver_xyz_m, pointing_vector)

    assert intersection is not None
    # Intersection should be closer to Earth center than receiver
    assert np.linalg.norm(intersection) < np.linalg.norm(receiver_xyz_m)
    # Should be approximately on WGS84 surface (~6378 km)
    surface_radius = np.linalg.norm(intersection)
    assert 6370000 < surface_radius < 6380000


def test_upward_ray_from_surface_no_intersection():
    """Test that a ray pointing up from surface has no intersection ahead."""
    # On the surface
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    # Point outward (away from Earth)
    pointing_vector = np.array([1.0, 0.0, 0.0])

    intersection = calculate_wgs84_intersection(receiver_xyz_m, pointing_vector)

    # Should return None (no intersection ahead of receiver)
    assert intersection is None


def test_tangent_ray_behavior():
    """Test ray that is nearly tangent to surface."""
    # Well above surface
    receiver_xyz_m = np.array([6378137.0 + 100000.0, 0.0, 0.0])  # 100km up
    # Point horizontally (perpendicular to radial)
    pointing_vector = np.array([0.0, 1.0, 0.0])

    intersection = calculate_wgs84_intersection(receiver_xyz_m, pointing_vector)

    # Might or might not intersect depending on geometry, but shouldn't crash
    # If it does intersect, should be on surface
    if intersection is not None:
        surface_radius = np.linalg.norm(intersection)
        assert 6370000 < surface_radius < 6380000
