"""Tests for atmospheric ray bending correction."""

from __future__ import annotations

import numpy as np
from gri_utils.conversion import xyz_to_aer

from gri_sandbox.patent_paper.apply_ray_bending_correction import (
    apply_ray_bending_correction,
)


def test_corrected_vector_is_unit_vector():
    """Test that corrected pointing vector is normalized."""
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    pointing_vector = np.array([0.0, 0.707, 0.707])  # 45 deg elevation
    emitter_xyz_m = np.array([6378137.0 + 10000.0, 100000.0, 100000.0])

    corrected = apply_ray_bending_correction(
        receiver_xyz_m,
        pointing_vector,
        emitter_xyz_m,
    )

    # Should be unit vector
    magnitude = np.linalg.norm(corrected)
    np.testing.assert_allclose(magnitude, 1.0, rtol=1e-10)


def test_correction_makes_angle_steeper():
    """Test that atmospheric correction makes apparent angle steeper.

    Atmospheric refraction causes rays to appear more shallow than they are,
    so the correction should increase elevation (make it steeper).
    """
    receiver_xyz_m = np.array([6378137.0, 0.0, 0.0])
    # Pointing vector at low elevation (where refraction is significant)
    pointing_vector = np.array([0.1, 0.0, 0.9943])  # ~6 deg elevation
    pointing_vector = pointing_vector / np.linalg.norm(pointing_vector)

    emitter_xyz_m = np.array([6378137.0 + 1000.0, 0.0, 100000.0])

    corrected = apply_ray_bending_correction(
        receiver_xyz_m,
        pointing_vector,
        emitter_xyz_m,
    )

    # Get elevations
    original_aer = xyz_to_aer(receiver_xyz_m, pointing_vector)
    corrected_aer = xyz_to_aer(receiver_xyz_m, corrected)

    original_elevation = original_aer[1]
    corrected_elevation = corrected_aer[1]

    # Corrected elevation should be higher (steeper) than apparent
    assert corrected_elevation > original_elevation


def test_accepts_list_inputs():
    """Test that function accepts lists as well as numpy arrays."""
    receiver_xyz_m = [6378137.0, 0.0, 0.0]
    pointing_vector = [0.0, 0.707, 0.707]
    emitter_xyz_m = [6378137.0 + 10000.0, 100000.0, 100000.0]

    corrected = apply_ray_bending_correction(
        receiver_xyz_m,
        pointing_vector,
        emitter_xyz_m,
    )

    # Should return numpy array
    assert isinstance(corrected, np.ndarray)
    assert corrected.shape == (3,)
