"""Tests for clock/cone to azimuth/elevation angle conversions."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.convert_clock_cone_to_az_el import (
    convert_az_el_to_clock_cone,
    convert_clock_cone_to_az_el,
)


def test_zenith_conversion():
    """Test conversion at zenith (cone=-90, elevation=90)."""
    clock_deg = 0.0
    cone_deg = -90.0

    azimuth_deg, elevation_deg = convert_clock_cone_to_az_el(clock_deg, cone_deg)

    assert azimuth_deg == 0.0
    assert elevation_deg == 90.0


def test_horizon_conversion():
    """Test conversion at horizon (cone=0, elevation=0)."""
    clock_deg = 45.0
    cone_deg = 0.0

    azimuth_deg, elevation_deg = convert_clock_cone_to_az_el(clock_deg, cone_deg)

    assert azimuth_deg == 45.0
    assert elevation_deg == 0.0


def test_roundtrip_conversion():
    """Test that converting back and forth preserves angles."""
    original_clock = 123.45
    original_cone = 67.89

    # Convert to az/el and back
    azimuth, elevation = convert_clock_cone_to_az_el(original_clock, original_cone)
    recovered_clock, recovered_cone = convert_az_el_to_clock_cone(azimuth, elevation)

    np.testing.assert_allclose(recovered_clock, original_clock, rtol=1e-10)
    np.testing.assert_allclose(recovered_cone, original_cone, rtol=1e-10)
