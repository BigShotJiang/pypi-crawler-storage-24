"""Tests for error ellipse calculation."""

from __future__ import annotations

import numpy as np

from gri_sandbox.patent_paper.calculate_error_ellipse import calculate_error_ellipse


def test_error_ellipse_has_required_fields():
    """Test that error ellipse has all required fields."""
    receiver_xyz_m = np.array([7000000.0, 0.0, 0.0])  # Above surface
    pointing_vector = np.array([-1.0, 0.0, 0.0])  # Point down
    uncertainty_deg = 2.0

    ellipse = calculate_error_ellipse(receiver_xyz_m, pointing_vector, uncertainty_deg)

    assert "center_xyz_m" in ellipse
    assert "semi_major_m" in ellipse
    assert "semi_minor_m" in ellipse
    assert "orientation_deg" in ellipse


def test_larger_uncertainty_gives_larger_ellipse():
    """Test that larger uncertainty angle produces larger error ellipse."""
    receiver_xyz_m = np.array([7000000.0, 0.0, 0.0])
    pointing_vector = np.array([-1.0, 0.0, 0.0])

    # Small uncertainty
    ellipse_small = calculate_error_ellipse(receiver_xyz_m, pointing_vector, 1.0)

    # Large uncertainty
    ellipse_large = calculate_error_ellipse(receiver_xyz_m, pointing_vector, 5.0)

    # Larger uncertainty should give larger axes
    assert ellipse_large["semi_major_m"] > ellipse_small["semi_major_m"]
    assert ellipse_large["semi_minor_m"] > ellipse_small["semi_minor_m"]


def test_ellipse_center_is_on_surface():
    """Test that ellipse center is approximately on WGS84 surface."""
    receiver_xyz_m = np.array([7000000.0, 0.0, 0.0])  # Above surface
    pointing_vector = np.array([-1.0, 0.0, 0.0])  # Point toward Earth
    uncertainty_deg = 2.0

    ellipse = calculate_error_ellipse(receiver_xyz_m, pointing_vector, uncertainty_deg)

    # Center should be on or near surface
    center_radius = np.linalg.norm(ellipse["center_xyz_m"])
    assert 6370000 < center_radius < 6380000  # WGS84 surface range
