"""Tests for gri_utils geolocation module."""
