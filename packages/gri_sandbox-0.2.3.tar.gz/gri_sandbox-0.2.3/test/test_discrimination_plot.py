"""Plotly chart showing residual and curvature discrimination for three cases.

This test creates a visual comparison of how residual and curvature metrics
discriminate between TRUE and SPURIOUS solutions at different elevation angles:

1. elevation=0.14: Two solutions found, discriminated to one (residual_resolved)
2. elevation=0.37: Gap region - returns None (unrecoverable)
3. elevation=-1.35: Two solutions resolved to one (residual_resolved)
"""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import pytest
from gri_pos import Pos
from gri_tropo.dgs import dgs_tropo_corrections
from plotly.subplots import make_subplots

from gri_sandbox.round_trip.apparent_pointing_vector import (
    apparent_pointing_vector_from_true,
)
from gri_sandbox.round_trip.collector_position import collector_pos_at_elevation
from gri_sandbox.round_trip.find_emitter_multiple_solutions import (
    compute_correction_residual,
    compute_curvature,
    find_emitter_multiple_solutions,
)
from gri_sandbox.round_trip.pointing_vector import calculate_pointing_vector


def _setup_scenario(elevation_deg: float) -> tuple[np.ndarray, np.ndarray, float]:
    """Set up emitter/collector scenario for a given elevation angle.

    Returns:
        Tuple of (apparent_pointing_vector, collector_xyz, collector_lon)
    """
    emitter = Pos.LLA(0.0, 0.0, 0.0)
    leo_altitude_m = 1e6
    azimuth_deg = 0.0

    collector = collector_pos_at_elevation(
        emitter,
        elevation_deg,
        leo_altitude_m,
        azimuth_deg,
    )

    true_pointing_vector = calculate_pointing_vector(collector, emitter)

    cone_correction_rad, _ = dgs_tropo_corrections(
        emitter_loc_lla=emitter.lla,
        collector_pos_xyz=collector.xyz,
    )

    apparent_pointing_vector = apparent_pointing_vector_from_true(
        true_pointing_vector,
        collector.xyz,
        cone_correction_rad,
    )

    return apparent_pointing_vector, collector.xyz, collector.lla[1]


def _compute_residual_landscape_adaptive(
    apparent_pointing_vector: np.ndarray,
    collector_xyz: np.ndarray,
    lon: float,
    lat_range: tuple[float, float] = (-3.0, 3.0),
    coarse_points: int = 200,
    refinement_stages: int = 7,
    points_per_stage: int = 50,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Compute residual, derivative, and curvature with adaptive refinement.

    This mimics the actual solution-finding algorithm: coarse scan followed by
    iterative refinement around each local minimum. All computed points are
    returned, giving true visibility into the refined residual values.

    Returns:
        Tuple of (latitudes, residuals, derivatives, curvatures) - sorted by latitude
    """
    all_lats: list[float] = []
    all_residuals: list[float] = []
    all_curvatures: list[float] = []

    # Step 1: Coarse scan across full range
    coarse_lats = np.linspace(lat_range[0], lat_range[1], coarse_points)
    coarse_residuals: list[float] = []

    for lat in coarse_lats:
        residual = compute_correction_residual(
            float(lat),
            lon,
            apparent_pointing_vector,
            collector_xyz,
        )
        curvature = compute_curvature(
            float(lat),
            lon,
            apparent_pointing_vector,
            collector_xyz,
        )
        all_lats.append(float(lat))
        all_residuals.append(residual)
        all_curvatures.append(curvature)
        coarse_residuals.append(residual)

    # Step 2: Find local minima in coarse scan
    minima_lats: list[float] = []
    for i in range(1, len(coarse_residuals) - 1):
        if (
            coarse_residuals[i] <= coarse_residuals[i - 1]
            and coarse_residuals[i] <= coarse_residuals[i + 1]
        ):
            minima_lats.append(float(coarse_lats[i]))  # noqa: PERF401

    # Step 3: Iterative refinement around each minimum (same as refine_minimum)
    for lat_center in minima_lats:
        initial_range = 0.2
        lat_min = lat_center - initial_range / 2
        lat_max = lat_center + initial_range / 2

        best_lat = lat_center
        best_residual = float("inf")

        for _ in range(refinement_stages):
            stage_lats = np.linspace(lat_min, lat_max, points_per_stage)

            for lat in stage_lats:
                residual = compute_correction_residual(
                    float(lat),
                    lon,
                    apparent_pointing_vector,
                    collector_xyz,
                )
                curvature = compute_curvature(
                    float(lat),
                    lon,
                    apparent_pointing_vector,
                    collector_xyz,
                )
                all_lats.append(float(lat))
                all_residuals.append(residual)
                all_curvatures.append(curvature)

                if residual < best_residual:
                    best_residual = residual
                    best_lat = float(lat)

            # Narrow range for next stage
            range_width = (lat_max - lat_min) / 5
            lat_min = best_lat - range_width / 2
            lat_max = best_lat + range_width / 2

    # Sort all points by latitude
    sorted_indices = np.argsort(all_lats)
    lats = np.array(all_lats)[sorted_indices]
    residuals = np.array(all_residuals)[sorted_indices]
    curvatures = np.array(all_curvatures)[sorted_indices]

    # Remove duplicate latitudes (keep first occurrence) to avoid gradient issues
    _, unique_indices = np.unique(lats, return_index=True)
    unique_indices = np.sort(unique_indices)  # Preserve order
    lats = lats[unique_indices]
    residuals = residuals[unique_indices]
    curvatures = curvatures[unique_indices]

    # Compute first derivative using central differences
    derivatives = np.gradient(residuals, lats)

    return lats, residuals, derivatives, curvatures


def _create_discrimination_chart(
    elev: float,
    outcome: str,
    color: str,
) -> None:
    """Create a single discrimination chart for one elevation angle."""
    apparent_vec, collector_xyz, lon = _setup_scenario(elev)

    # Find solutions first to determine appropriate latitude range
    result = find_emitter_multiple_solutions(
        apparent_vec,
        collector_xyz,
    )

    # Determine latitude range to include all solutions with some margin
    if result.solutions:
        sol_lats = [sol.latitude for sol in result.solutions]
        lat_min = min(sol_lats) - 1.0
        lat_max = max(sol_lats) + 1.0
        # Ensure at least a 2° range
        if lat_max - lat_min < 2.0:
            center = (lat_min + lat_max) / 2
            lat_min = center - 1.0
            lat_max = center + 1.0
        lat_range = (lat_min, lat_max)
    else:
        lat_range = (-3.0, 3.0)

    # Compute landscape over the determined range with adaptive refinement
    lats, residuals, derivatives, curvatures = _compute_residual_landscape_adaptive(
        apparent_vec,
        collector_xyz,
        lon,
        lat_range=lat_range,
    )

    # Create subplot figure: 3 rows (residual, derivative, curvature), 1 col
    fig = make_subplots(
        rows=3,
        cols=1,
        subplot_titles=["Residual", "Derivative (dR/dlat)", "Curvature (d²R/dlat²)"],
        vertical_spacing=0.08,
    )

    # Add residual trace
    fig.add_trace(
        go.Scatter(
            x=lats,
            y=residuals,
            mode="lines",
            name="Residual",
            line={"color": color, "width": 2},
            showlegend=False,
        ),
        row=1,
        col=1,
    )

    # Add derivative trace
    fig.add_trace(
        go.Scatter(
            x=lats,
            y=derivatives,
            mode="lines",
            name="Derivative",
            line={"color": color, "width": 2},
            showlegend=False,
        ),
        row=2,
        col=1,
    )

    # Add curvature trace
    fig.add_trace(
        go.Scatter(
            x=lats,
            y=curvatures,
            mode="lines",
            name="Curvature",
            line={"color": color, "width": 2},
            showlegend=False,
        ),
        row=3,
        col=1,
    )

    # Update layout for dark mode
    fig.update_layout(
        title={
            "text": f"Elevation {elev}° - {outcome}",
            "font": {"size": 16, "color": "white"},
            "x": 0.5,
        },
        template="plotly_dark",
        height=700,
        width=900,
    )

    # Update axes labels
    fig.update_xaxes(title_text="Latitude (°)", row=3, col=1)
    fig.update_yaxes(title_text="Residual (rad)", type="log", row=1, col=1)
    fig.update_yaxes(title_text="dR/dlat (rad/°)", range=[-0.002, 0.002], row=2, col=1)
    fig.update_yaxes(title_text="d²R/dlat² (rad/°²)", row=3, col=1)

    fig.show()


@pytest.mark.skip(reason="manual only for demonstration")
def test_discrimination_chart_014() -> None:
    """Chart for elevation 0.14° - Two solutions, cannot discriminate."""
    _create_discrimination_chart(0.14, "Two Solutions (Ambiguous)", "#00D4FF")


@pytest.mark.skip(reason="manual only for demonstration")
def test_discrimination_chart_037() -> None:
    """Chart for elevation 0.37° - Gap region, returns None."""
    _create_discrimination_chart(0.37, "Gap Region -> None", "#FF6B6B")


@pytest.mark.skip(reason="manual only for demonstration")
def test_discrimination_chart_neg135() -> None:
    """Chart for elevation -1.35° - Two solutions resolved via residual."""
    _create_discrimination_chart(-1.35, "Two Solutions -> Resolved", "#4ECDC4")


if __name__ == "__main__":
    test_discrimination_chart_014()
    test_discrimination_chart_037()
    test_discrimination_chart_neg135()
