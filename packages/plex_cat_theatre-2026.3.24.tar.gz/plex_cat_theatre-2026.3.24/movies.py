#!/usr/bin/env python3
"""CLI controller for movies skill."""

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "movies_config.json"
LOG_PATH = Path.home() / ".openclaw" / "logs" / "movies.log"
SERVER_SCRIPT = ROOT / "movies_server.py"
DEFAULT_PORT = 9245
DEFAULT_HOST = "0.0.0.0"
DEFAULT_THUMBS = ROOT / "cache" / "thumbnails"


def load_json(path: Path):
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def http_ok(port: int) -> bool:
    try:
        with urlopen(f"http://127.0.0.1:{port}/", timeout=2) as resp:
            return 200 <= getattr(resp, "status", 200) < 500
    except Exception:
        return False


def http_rescan(port: int) -> bool:
    try:
        with urlopen(f"http://127.0.0.1:{port}/rescan", timeout=5) as resp:
            body = resp.read().decode("utf-8", errors="ignore").strip().lower()
            return 200 <= getattr(resp, "status", 200) < 500 and body.startswith("ok")
    except Exception:
        return False


def configured_port(cfg: dict) -> int:
    return int(cfg.get("http_port") or cfg.get("port") or DEFAULT_PORT)


def ensure_config(root: str, port: int, host: str, thumbs_dir: Optional[str] = None, http_port: int = None, https_port: int = None):
    rp = Path(root).expanduser().resolve()
    if not rp.exists():
        raise SystemExit(f"Path does not exist: {rp}")
    td = Path(thumbs_dir).expanduser().resolve() if thumbs_dir else DEFAULT_THUMBS
    td.mkdir(parents=True, exist_ok=True)
    cfg = {"root": str(rp), "port": int(port), "host": host, "thumbs_dir": str(td)}
    if http_port is not None:
        cfg["http_port"] = int(http_port)
    if https_port is not None:
        cfg["https_port"] = int(https_port)
    save_json(CONFIG_PATH, cfg)
    print(f"Configuration saved: root={rp} port={port} http_port={http_port or port} https_port={https_port or port}")


def start_server(override_port: int = None):
    cfg = load_json(CONFIG_PATH)
    if not cfg:
        raise SystemExit("No config found. Run: movies.py config --root <path>")
    
    # Allow port override from command line
    if override_port is not None:
        cfg["port"] = override_port
        cfg["http_port"] = override_port
        cfg["https_port"] = override_port

    # Prefer live port health check as the single source of truth.
    port = configured_port(cfg)
    if http_ok(port):
        print(f"Movies server already running at http://{local_ip()}:{port}/")
        return


    logf = open(LOG_PATH, "a", encoding="utf-8")
    p = subprocess.Popen(
        [sys.executable, str(SERVER_SCRIPT), "--config", str(CONFIG_PATH)],
        stdout=logf,
        stderr=logf,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    logf.close()  # Close parent's fd, child has its own copy
    time.sleep(0.6)
    if p.poll() is not None:
        raise SystemExit("Movies server failed to start. Check movies.log")

    http_p = cfg.get("http_port", cfg.get("port", DEFAULT_PORT))
    https_p = cfg.get("https_port", cfg.get("port", DEFAULT_PORT))
    print(f"Movies server running at:")
    print(f"  LAN (HTTP): http://{local_ip()}:{http_p}/")
    if https_p != http_p:
        print(f"  Tunnel:    http://{local_ip()}:{https_p}/")


def stop_server():
    cfg = load_json(CONFIG_PATH)
    if not cfg:
        print("Movies server is not running.")
        return

    port = configured_port(cfg)
    if not http_ok(port):
        print("Movies server is not running.")
        return

    raise SystemExit("Stop is daemon-managed now. Use launchctl to stop com.miranda.movies.")


def status_server():
    cfg = load_json(CONFIG_PATH)
    if not cfg:
        print("STOPPED")
        return

    port = configured_port(cfg)
    if http_ok(port):
        print(f"RUNNING url=http://{local_ip()}:{port}/ root={cfg.get('root', '')}")
    else:
        print("STOPPED")


def rescan_server():
    cfg = load_json(CONFIG_PATH)
    if not cfg:
        raise SystemExit("No config found. Run: movies.py config --root <path>")

    port = configured_port(cfg)
    if http_rescan(port):
        print("Rescan triggered via HTTP endpoint.")
        return

    raise SystemExit("Movies server is not running.")


def setpath(path: str):
    cfg = load_json(CONFIG_PATH)
    if not cfg:
        cfg = {"port": DEFAULT_PORT, "host": DEFAULT_HOST, "thumbs_dir": str(DEFAULT_THUMBS)}
    ensure_config(path, cfg.get("port", DEFAULT_PORT), cfg.get("host", DEFAULT_HOST), cfg.get("thumbs_dir"))


def main():
    parser = argparse.ArgumentParser(description="Miranda movies service control")
    sub = parser.add_subparsers(dest="cmd")

    p_cfg = sub.add_parser("config")
    p_cfg.add_argument("--root", required=True)
    p_cfg.add_argument("--port", type=int, default=DEFAULT_PORT)
    p_cfg.add_argument("--http-port", type=int, default=None, help="HTTP port for LAN (default: same as --port)")
    p_cfg.add_argument("--https-port", type=int, default=None, help="HTTPS port for Tunnel (default: same as --port)")
    p_cfg.add_argument("--host", default=DEFAULT_HOST)
    p_cfg.add_argument("--thumb-dir")

    p_on = sub.add_parser("on")
    p_on.add_argument("--port", type=int, default=None, help="Override port (default: use config)")
    sub.add_parser("off")
    sub.add_parser("status")
    sub.add_parser("rescan")
    sub.add_parser("help")

    p_set = sub.add_parser("setpath")
    p_set.add_argument("path")

    args = parser.parse_args()
    if args.cmd == "config":
        ensure_config(args.root, args.port, args.host, args.thumb_dir, 
                        http_port=args.http_port or args.port, 
                        https_port=args.https_port or args.port)
    elif args.cmd == "setpath":
        setpath(args.path)
    elif args.cmd == "on":
        start_server(args.port)
    elif args.cmd == "off":
        stop_server()
    elif args.cmd == "status":
        status_server()
    elif args.cmd == "rescan":
        rescan_server()
    elif args.cmd == "help":
        parser.print_help()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
