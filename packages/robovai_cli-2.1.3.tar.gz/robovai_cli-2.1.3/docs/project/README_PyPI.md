# 🪐 RobovAI Nova CLI

## The Official Command Line Interface for RobovAI Nova Platform

[Platform](https://nova.robovai.tech) •
[Company Website](https://robovai.tech) •
[Creator & Lead Architect](https://moshaban.me)

---

## 🌍 Overview / نظرة عامة

### 🇬🇧 English

**RobovAI Nova CLI** is the ultimate terminal companion for the Sovereign Edge AI platform. Built for enterprise productivity, it allows developers and system administrators to interact seamlessly with the dynamic multi-agent orchestration ecosystem of RobovAI Nova directly from their command line.

Whether you are configuring dynamic model routing (GPT-4, Claude 3, Gemini), managing AI webhooks, or syncing local environments with the Nova cloud, the CLI brings the total power of the enterprise platform to your fingertips.

### 🇸🇦 العربية

**RobovAI Nova CLI** هي أداة سطر الأوامر الرسمية والاحترافية لمنصة "نوفا" للذكاء الاصطناعي المؤسسي. صُممت خصيصاً للمطورين ومديري الأنظمة للتحكم الكامل في وظائف المنصة عبر الـ Terminal.

تسمح لك الأداة بإدارة وكلاء الذكاء الاصطناعي (AI Agents)، تبديل النماذج الذكية ديناميكياً (GPT-4, Claude 3, Gemini)، ومزامنة بيئة عملك المحلية مع السحابة المركزية الخاصة بمنصة RobovAI بسهولة وأمان تام.

---

## ⚡ Key Features

- **🛡️ Secure Access:** Manage your RobovAI Nova platform authentication securely.
- **🤖 Multi-Agent Handling:** Trigger, monitor, and configure autonomous AI workflows.
- **🔄 Dynamic Local Sync:** Keep your edge devices perfectly in sync with the Nova Cloud.
- **🚀 Ultra-Fast Console:** Built entirely on modern Python standards architectures (`Typer`, `Rich`, `HTTPX`) to provide gorgeous, colorful terminal UI.
- **☁️ Cloud + Offline:** Work with cloud providers and local runtimes from one CLI.
- **🔐 BYOK Controls:** Save and inspect provider credentials for supported backends.
- **🧠 Platform Operations:** Access readiness, skills, guardrails, memory, model routing, and assistant templates.

## 📦 Installation

Installing the CLI adds the `robovai` command for your terminal when your Python Scripts directory is available in `PATH`.

يؤدي تثبيت الأداة إلى توفير أمر `robovai` في الطرفية عندما يكون مجلد Scripts الخاص ببايثون مضافًا إلى PATH.

```bash
python -m pip install --upgrade robovai-cli
```

Then run `robovai` to open the RoboVAI Home Hub for guided setup, status, and chat.

ثم شغّل `robovai` لفتح واجهة RoboVAI Home Hub الخاصة بالإعداد الموجّه والحالة والدردشة.

### Windows Troubleshooting / حل مشكلة Windows

If PowerShell says `robovai` is not recognized, add your Python user Scripts directory to `PATH`, then open a new terminal window.

إذا ظهر في PowerShell أن `robovai` غير معروف، أضف مجلد `Scripts` الخاص ببايثون إلى `PATH` ثم افتح نافذة طرفية جديدة.

Typical path:

```powershell
C:\Users\alien ware\AppData\Roaming\Python\Python314\Scripts
```

Fallback command that works even before PATH is refreshed:

```powershell
python -m robovai_cli
```

## 🛠️ Quick Start

```bash
# Verify installation and sync with platform
robovai
robovai login --method password
robovai login --method browser
robovai account-status
robovai pricing
robovai provider-wizard
robovai chat-shell
robovai update-check

# View all available CLI actions and help
robovai --help

# Inspect providers and platform readiness
robovai providers-status
robovai readiness-matrix

# Save BYOK credentials and route a task
robovai byok-set openai --api-key sk-...
robovai models-route "design a support assistant" --mode builder
```

```powershell
# PowerShell examples on Windows
robovai signup --full-name "Your Name" --email you@example.com
robovai login --method password --email you@example.com
robovai
robovai account-status
robovai pricing
robovai buy-tokens --package-id tokens_500
robovai chat-shell
robovai providers-status
robovai guardrails-policy-show
python -m robovai_cli
```

## 📞 Support & Infrastructure

- **Company / الشركة:** [RobovAI Edge Solutions](https://robovai.tech)
- **Nova Portal / منصة نوفا:** [nova.robovai.tech](https://nova.robovai.tech)
- **Lead Developer / المطور الرئيسي:** [Mo Shaban](https://moshaban.me)
- **Support / الدعم الفني:** [contact.robovai@gmail.com](mailto:contact.robovai@gmail.com)

---

_© 2026 RobovAI Solutions. Built with ⚡ by Mo Shaban._
