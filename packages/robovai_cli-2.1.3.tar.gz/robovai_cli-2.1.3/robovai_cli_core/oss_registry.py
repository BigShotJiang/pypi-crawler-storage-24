from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Dict, List

from .models import OSEntry


def _git_short_revision(repo_path: Path) -> str | None:
    """Return short git commit hash for a local repository if available."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        revision = result.stdout.strip()
        return revision or None
    except Exception:
        return None


def build_oss_index(oss_root: Path, references: Dict[str, str]) -> List[OSEntry]:
    """Build a status index for known OSS references and their local availability."""
    entries: List[OSEntry] = []
    for key, repo_url in sorted(references.items()):
        local_path = oss_root / key
        present = local_path.exists() and (local_path / ".git").exists()
        revision = _git_short_revision(local_path) if present else None
        entries.append(
            OSEntry(
                key=key,
                repo_url=repo_url,
                local_path=local_path,
                present=present,
                revision=revision,
            )
        )
    return entries
