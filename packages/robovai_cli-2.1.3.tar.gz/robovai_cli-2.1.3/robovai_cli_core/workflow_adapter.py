from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Dict


class DeerFlowAdapter:
    """Thin adapter around local deer-flow reference for workflow execution."""

    def __init__(self, deer_flow_path: Path) -> None:
        self.deer_flow_path = deer_flow_path

    def status(self) -> Dict[str, str]:
        """Return a simple status payload for deer-flow local integration."""
        if not self.deer_flow_path.exists():
            return {
                "status": "missing",
                "message": "deer-flow repository is not present under oss_references.",
            }

        backend_path = self.deer_flow_path / "backend"
        frontend_path = self.deer_flow_path / "frontend"
        return {
            "status": "ready",
            "backend": str(backend_path),
            "frontend": str(frontend_path),
        }

    def run_example(self, task: str) -> Dict[str, str]:
        """Run a lightweight local command as a proof-of-integration step."""
        if not self.deer_flow_path.exists():
            return {
                "status": "missing",
                "message": "deer-flow not available. Run `robovai oss-sync` first.",
            }

        marker = self.deer_flow_path / "README.md"
        if not marker.exists():
            return {
                "status": "invalid",
                "message": "deer-flow repository appears incomplete.",
            }

        command = [
            "git",
            "-C",
            str(self.deer_flow_path),
            "rev-parse",
            "--short",
            "HEAD",
        ]
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        revision = result.stdout.strip() if result.returncode == 0 else "unknown"

        return {
            "status": "ok",
            "revision": revision,
            "task": task,
            "message": "deer-flow adapter connected. Next step: map task to backend workflow API.",
        }
