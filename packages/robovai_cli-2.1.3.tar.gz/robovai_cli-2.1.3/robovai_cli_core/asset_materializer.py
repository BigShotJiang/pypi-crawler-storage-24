from __future__ import annotations

import json
import os
import stat
import shutil
from pathlib import Path
from typing import Dict, List


def ensure_assets_root(project_root: Path) -> Path:
    """Create and return the local assets root used by RoboVAI Nova."""
    assets_root = project_root / "robovai_assets"
    assets_root.mkdir(parents=True, exist_ok=True)
    return assets_root


def _handle_remove_readonly(func, path, exc_info) -> None:
    """Allow removing read-only files on Windows while pruning old copies."""
    del exc_info
    os.chmod(path, stat.S_IWRITE)
    func(path)


def materialize_persona_file(
    source_file: Path,
    project_root: Path,
    target_name: str,
) -> Path:
    """Copy a persona file from OSS references into local RoboVAI assets."""
    assets_root = ensure_assets_root(project_root)
    personas_dir = assets_root / "personas"
    personas_dir.mkdir(parents=True, exist_ok=True)

    extension = source_file.suffix if source_file.suffix else ".txt"
    destination = personas_dir / f"{target_name}{extension}"
    shutil.copyfile(source_file, destination)
    return destination


def materialize_registry(
    project_root: Path,
    source_root: Path,
    include: List[str],
) -> Dict[str, str]:
    """
    Copy selected OSS folders into local assets registry.

    Returns a map of item -> destination path.
    """
    assets_root = ensure_assets_root(project_root)
    oss_assets_dir = assets_root / "oss_materialized"
    oss_assets_dir.mkdir(parents=True, exist_ok=True)

    copied: Dict[str, str] = {}
    for item in include:
        src = source_root / item
        if not src.exists() or not src.is_dir():
            continue
        dest = oss_assets_dir / item
        if dest.exists():
            shutil.rmtree(dest, onerror=_handle_remove_readonly)
        shutil.copytree(src, dest)
        copied[item] = str(dest)

    manifest_path = oss_assets_dir / "manifest.json"
    manifest_payload = {
        "source_root": str(source_root),
        "copied": copied,
    }
    manifest_path.write_text(json.dumps(manifest_payload, indent=2), encoding="utf-8")
    return copied


def check_oss_prune_readiness(project_root: Path, oss_root: Path) -> Dict[str, str]:
    """Return readiness status for deleting oss_references."""
    assets_root = project_root / "robovai_assets"
    materialized_dir = assets_root / "oss_materialized"
    manifest = materialized_dir / "manifest.json"

    if not oss_root.exists():
        return {
            "status": "already-pruned",
            "message": "oss_references folder is already removed.",
        }

    if (
        not assets_root.exists()
        or not materialized_dir.exists()
        or not manifest.exists()
    ):
        return {
            "status": "not-ready",
            "message": "Materialized assets are missing. Run oss-materialize first.",
        }

    return {
        "status": "ready",
        "message": "Local assets are materialized. You can remove oss_references safely.",
        "manifest": str(manifest),
    }
