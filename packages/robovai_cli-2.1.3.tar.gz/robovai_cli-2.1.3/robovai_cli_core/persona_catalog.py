from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

from .models import PersonaCandidate

_PROMPT_SUFFIXES = (".md", ".txt", ".prompt", ".prompt.md")


def _looks_like_persona(file_name: str) -> bool:
    lower_name = file_name.lower()
    keywords = ("prompt", "persona", "agent", "system")
    return any(word in lower_name for word in keywords)


def _iter_candidate_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _PROMPT_SUFFIXES:
            continue
        if _looks_like_persona(path.name):
            yield path


def search_personas(root: Path, query: str, limit: int = 20) -> List[PersonaCandidate]:
    """Search persona-like prompt files under system-prompts reference."""
    normalized_query = query.lower().strip()
    candidates: List[PersonaCandidate] = []

    for file_path in _iter_candidate_files(root):
        try:
            text = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        if (
            normalized_query
            and normalized_query not in text.lower()
            and normalized_query not in file_path.name.lower()
        ):
            continue

        lines = [line.strip() for line in text.splitlines() if line.strip()]
        snippet = " ".join(lines[:4])[:220]
        title = lines[0][:120] if lines else file_path.stem

        candidates.append(
            PersonaCandidate(
                title=title,
                file_path=file_path,
                snippet=snippet,
            )
        )
        if len(candidates) >= limit:
            break

    return candidates
