from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class OSEntry:
    """Represents a known open-source reference repository."""

    key: str
    repo_url: str
    local_path: Path
    present: bool
    revision: Optional[str]


@dataclass(frozen=True)
class PersonaCandidate:
    """Represents one persona file candidate discovered in OSS prompts."""

    title: str
    file_path: Path
    snippet: str
