#!/usr/bin/env python3
"""
RoboVAI CLI - Enterprise AI Agent Management Tool
Powered by Nova Platform
https://robovai.tech
"""

import asyncio
import getpass
import hashlib
import json
import logging
import os
import platform
import subprocess
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import httpx
import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from typing_extensions import Annotated

from robovai_cli_core import (
    DeerFlowAdapter,
    build_oss_index,
    check_oss_prune_readiness,
    materialize_persona_file,
    materialize_registry,
    search_personas,
)

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

load_dotenv()

app = typer.Typer(
    name="robovai",
    help="🤖 RoboVAI CLI - Build and manage AI agents locally or in the cloud.",
    rich_markup_mode="rich",
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("robovai-cli")
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Config file paths
CONFIG_DIR = Path.home() / ".robovai"
CONFIG_FILE = CONFIG_DIR / "config.json"
AGENTS_DIR = CONFIG_DIR / "agents"
DEFAULT_OSS_REFERENCES: Dict[str, str] = {
    "deer-flow": "https://github.com/bytedance/deer-flow.git",
    "langflow": "https://github.com/langflow-ai/langflow.git",
    "system-prompts-and-models-of-ai-tools": "https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools.git",
    "opencode": "https://github.com/anomalyco/opencode.git",
    "langchain": "https://github.com/langchain-ai/langchain.git",
    "gemini-cli": "https://github.com/google-gemini/gemini-cli.git",
    "aionui": "https://github.com/iOfficeAI/AionUi.git",
    "plandex": "https://github.com/plandex-ai/plandex.git",
}
OSS_ROOT = Path("oss_references")
PROJECT_ROOT = Path(__file__).resolve().parent

# Initialize directories
CONFIG_DIR.mkdir(exist_ok=True)
AGENTS_DIR.mkdir(exist_ok=True)

console = Console()
CLI_VERSION = "2.1.3"
PYPI_PACKAGE_NAME = "robovai-cli"
DEFAULT_GROQ_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"

# ═══════════════════════════════════════════════════════════════════════════
# STARTUP UI
# ═══════════════════════════════════════════════════════════════════════════


def _build_robovai_ascii_art() -> Text:
    """Create an oversized, space-themed ASCII art logo for ROBOVAI."""
    art_lines = [
        "   ██████╗  ██████╗ ██████╗  ██████╗ ██╗   ██╗ █████╗ ██╗",
        "   ██╔══██╗██╔═══██╗██╔══██╗██╔═══██╗██║   ██║██╔══██╗██║",
        "   ██████╔╝██║   ██║██████╔╝██║   ██║██║   ██║███████║██║",
        "   ██╔══██╗██║   ██║██╔══██╗██║   ██║╚██╗ ██╔╝██╔══██║██║",
        "   ██║  ██║╚██████╔╝██████╔╝╚██████╔╝ ╚████╔╝ ██║  ██║██║",
        "   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝   ╚═══╝  ╚═╝  ╚═╝╚═╝",
    ]

    # Color schemes for each character line (gradient from cyan to magenta)
    colors_per_line = [
        "#00d9ff",  # Cyan
        "#00c9ff",  # Cyan-Blue
        "#5fa5ff",  # Blue
        "#9d5eff",  # Purple
        "#d946ff",  # Magenta
        "#ff1493",  # Deep Magenta
    ]

    result = Text(justify="center")
    result.append("\n", style="")
    for line, color in zip(art_lines, colors_per_line):
        result.append(line + "\n", style=f"bold {color}")

    return result


def print_startup_banner() -> None:
    """Render the first-run product banner for RoboVAI CLI."""
    # Build the main header with ASCII art
    header = _build_robovai_ascii_art()

    # Product position
    info = Text(justify="center")
    info.append("\n")
    info.append("✦ ✦ ✦  ", style="bold #7ef2c8")
    info.append("Nova Account-First CLI", style="bold #7ef2c8")
    info.append("  ✦ ✦ ✦\n", style="bold #7ef2c8")
    info.append("\n")

    # Core paths
    modes = Text(justify="center")
    modes.append("☁️  Nova Plan  •  ", style="bold #68d5ff")
    modes.append("🔑 BYOK  •  ", style="bold #ffcf66")
    modes.append("💻 Offline (Ollama)", style="bold #b57ff6")
    modes.append("\n\n", style="")

    # Product capabilities
    features = Text(justify="center")
    features.append("👤 Sign in  •  ", style="#7ef2c8")
    features.append("💳 Plans & Tokens  •  ", style="#a78bfa")
    features.append("🧭 Provider Setup  •  ", style="#d979df")
    features.append("💬 Chat Shell\n", style="#68d5ff")

    # First-run hint
    hint = Text(justify="center")
    hint.append("\n")
    hint.append("Start with ", style="#8390ae")
    hint.append("1. Sign in", style="bold #68d5ff")
    hint.append("  •  ", style="#8390ae")
    hint.append("2. Account & Pricing", style="bold #ffcf66")
    hint.append("  •  ", style="#8390ae")
    hint.append("3. Provider Setup", style="bold #b57ff6")
    hint.append("\n", style="")

    footer = Text(justify="center")
    footer.append("Type ", style="#8390ae")
    footer.append("robovai --help", style="bold #68d5ff")
    footer.append(" for commands  •  Use ", style="#8390ae")
    footer.append("--no-banner", style="bold #f06fb8")
    footer.append(" to hide", style="#8390ae")

    # Combine all content
    panel_content = Text(justify="center")
    panel_content.append_text(header)
    panel_content.append_text(info)
    panel_content.append_text(modes)
    panel_content.append_text(features)
    panel_content.append_text(hint)
    panel_content.append_text(footer)

    # Render with cosmic panel
    panel = Panel(
        panel_content,
        title="[bold #7ef2c8]🚀 Welcome to RoboVAI[/bold #7ef2c8]",
        subtitle="[bold #8e8bff]⚡ Powered by Nova[/bold #8e8bff]",
        border_style="#2a4a7c",
        padding=(1, 3),
        expand=False,
    )
    console.print(panel)


def print_home_hub(config: Dict[str, Any]) -> None:
    """Render the main interactive home hub shown when robovai starts without a subcommand."""
    auth_state = "Connected" if config.get("authenticated") else "Not connected"
    provider_mode = config.get("provider_mode", "auto")
    api_url = config.get("api_url", "http://localhost:8000")
    tier = config.get("account_tier", "unknown")
    balance = config.get("account_balance", "-")

    body = Text()
    body.append("1. Sign in / Create Nova account\n", style="bold #7ef2c8")
    body.append("2. Account, plan, and token usage\n", style="bold #68d5ff")
    body.append("3. Provider setup (Nova / BYOK / Offline)\n", style="bold #b57ff6")
    body.append("4. Start chat shell\n", style="bold #ffcf66")
    body.append("5. Help and shortcuts\n", style="bold #ff9d5c")
    body.append("6. Exit\n\n", style="bold #ff7c97")
    body.append(f"Auth: {auth_state}\n", style="#d7def0")
    body.append(f"Plan: {tier}\n", style="#d7def0")
    body.append(f"Token balance: {balance}\n", style="#d7def0")
    body.append(f"Provider mode: {provider_mode}\n", style="#d7def0")
    body.append(f"API URL: {api_url}", style="#d7def0")

    console.print(
        Panel(
            body,
            title="[bold #7ef2c8]RoboVAI Home Hub[/bold #7ef2c8]",
            subtitle="Type a number to continue",
            border_style="#2a4a7c",
            padding=(1, 2),
            expand=False,
        )
    )


def run_quick_setup_wizard() -> None:
    """Guide the user through the most common first-run setup paths."""
    console.print(
        Panel.fit(
            "Choose how you want to start:\n"
            "1. Nova account login (email/password)\n"
            "2. Open Nova login/signup in browser\n"
            "3. Use Nova API key\n"
            "4. Bring your own provider API key\n"
            "5. Offline with Ollama\n"
            "6. Keep current settings and return",
            title="Quick Setup",
            border_style="cyan",
        )
    )

    choice = typer.prompt("Setup option", default="1").strip()
    config = load_config()

    if choice == "1":
        email = typer.prompt("Nova account email").strip()
        password = typer.prompt("Nova account password", hide_input=True).strip()
        if not email or not password:
            typer.secho("❌ Email and password are required.", fg=typer.colors.RED)
            return
        login(method="password", email=email, password=password, api_url=config.get("api_url", "http://localhost:8000"))
        return

    if choice == "2":
        login(method="browser", api_url=config.get("api_url", "http://localhost:8000"))
        return

    if choice == "3":
        api_url = typer.prompt(
            "Nova API URL",
            default=config.get("api_url", "http://localhost:8000"),
        ).strip()
        api_key = typer.prompt("Nova API key", hide_input=True).strip()
        if not api_key:
            typer.secho("❌ API key is required for Nova cloud mode.", fg=typer.colors.RED)
            return

        config["api_url"] = api_url
        config["api_key"] = api_key
        config["authenticated"] = True
        config["authenticated_at"] = datetime.now().isoformat()
        config["provider_mode"] = config.get("provider_mode", "auto")
        config["onboarding_completed"] = True
        config["onboarding_completed_at"] = datetime.now().isoformat()
        save_config(config)
        refresh_account_cache()
        typer.secho("✅ Nova cloud access is configured.", fg=typer.colors.GREEN)
        return

    if choice == "4":
        run_provider_setup_wizard()
        return

    if choice == "5":
        ollama_url = typer.prompt(
            "Ollama URL",
            default=config.get("ollama_base_url", "http://localhost:11434"),
        ).strip()
        ollama_model = typer.prompt(
            "Default Ollama model",
            default=config.get("ollama_model", "llama2"),
        ).strip()
        config["provider_mode"] = "offline"
        config["provider_chain"] = "ollama"
        config["ollama_base_url"] = ollama_url
        config["ollama_model"] = ollama_model
        config["onboarding_completed"] = True
        config["onboarding_completed_at"] = datetime.now().isoformat()
        save_config(config)
        typer.secho("✅ Offline mode is configured for Ollama.", fg=typer.colors.GREEN)
        typer.echo("Run 'robovai chat-shell' to start chatting through your local backend.")
        return

    typer.echo("Returning to home hub.")


def show_current_status() -> None:
    """Display a concise runtime summary for the current CLI configuration."""
    config = refresh_account_cache(silent=True)
    account_summary: Dict[str, Any] = {}
    if config.get("authenticated"):
        account_summary = {
            "email": config.get("account_email", "unknown"),
            "name": config.get("account_name", "unknown"),
            "role": config.get("account_role", "user"),
            "tier": config.get("account_tier", "free"),
            "token_balance": config.get("account_balance", 0),
            "daily_used": config.get("account_daily_used", 0),
            "daily_limit": config.get("account_daily_limit", 0),
        }

    config = load_config()
    masked_key = "configured" if config.get("api_key") else "not set"

    body = Text()
    body.append("Connection\n", style="bold cyan underline")
    auth_status = "Yes" if config.get("authenticated", False) else "No"
    body.append(f"  Authenticated: {auth_status}\n", style="green" if config.get("authenticated") else "yellow")
    body.append(f"  API URL:       {config.get('api_url', 'http://localhost:8000')}\n", style="white")
    body.append(f"  API Key:       {masked_key}\n", style="white")
    body.append(f"  Onboarded:     {'Yes' if config.get('onboarding_completed') else 'No'}\n", style="white")
    body.append("\n")

    body.append("Provider\n", style="bold green underline")
    body.append(f"  Mode:  {config.get('provider_mode', 'auto')}\n", style="white")
    body.append(f"  Chain: {config.get('provider_chain', 'groq,nvidia,openrouter,ollama')}\n", style="white")
    body.append(f"  Ollama URL:   {config.get('ollama_base_url', 'http://localhost:11434')}\n", style="dim")
    body.append(f"  Ollama Model: {config.get('ollama_model', 'llama2')}\n", style="dim")

    if account_summary:
        body.append("\n")
        body.append("Account\n", style="bold yellow underline")
        body.append(f"  Email:   {account_summary.get('email', '—')}\n", style="white")
        body.append(f"  Name:    {account_summary.get('name', '—')}\n", style="white")
        body.append(f"  Role:    {account_summary.get('role', 'user')}\n", style="white")
        body.append(f"  Tier:    {account_summary.get('tier', 'free')}\n", style="white")
        tokens = account_summary.get('token_balance', 0)
        body.append(f"  Tokens:  {tokens:,}\n" if isinstance(tokens, (int, float)) else f"  Tokens:  {tokens}\n", style="white")

    console.print(Panel(body, title="[bold cyan]Current RoboVAI Status[/bold cyan]", border_style="cyan", padding=(1, 2), expand=False))


def launch_home_hub() -> None:
    """Launch the interactive home hub for first-run and direct CLI use."""
    while True:
        config = refresh_account_cache(silent=True)
        print_home_hub(config)
        selection = typer.prompt("Select action", default="1").strip()

        if selection == "1":
            run_quick_setup_wizard()
            continue
        if selection == "2":
            account_status()
            continue
        if selection == "3":
            run_provider_setup_wizard()
            continue
        if selection == "4":
            chat_shell()
            continue
        if selection == "5":
            show_help_center()
            continue
        if selection == "6":
            typer.echo("Goodbye.")
            return

        typer.secho("❌ Please choose a valid option from 1 to 6.", fg=typer.colors.RED)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    no_banner: Annotated[
        bool,
        typer.Option("--no-banner", help="Disable startup banner"),
    ] = False,
):
    """RoboVAI CLI root callback."""
    if ctx.invoked_subcommand is None:
        if not no_banner and os.getenv("ROBOVAI_CLI_BANNER", "1").strip() != "0":
            print_startup_banner()
        launch_home_hub()
        raise typer.Exit()


# ═══════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════


def load_config() -> Dict[str, Any]:
    """Load CLI configuration from home directory."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8-sig") as f:
                return json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            logger.warning("Invalid config file at %s: %s", CONFIG_FILE, exc)
            return {}
    return {
        "api_url": os.getenv("NOVA_API_URL", "http://localhost:8000"),
        "api_key": os.getenv("NOVA_API_KEY", ""),
        "authenticated": False,
        "provider_mode": os.getenv("LLM_PROVIDER", "auto"),
        "provider_chain": os.getenv(
            "LLM_PROVIDER_CHAIN", "groq,nvidia,openrouter,ollama"
        ),
        "groq_model": os.getenv("GROQ_MODEL", DEFAULT_GROQ_MODEL),
        "ollama_base_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
        "ollama_model": os.getenv("OLLAMA_MODEL", "llama2"),
    }


def save_config(config: Dict[str, Any]) -> None:
    """Save CLI configuration to home directory."""
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def _masked_secret(secret: str) -> str:
    """Return a safe masked representation of a secret for CLI output."""
    if not secret:
        return "not set"
    return "configured"


def build_absolute_url(base_url: str, path_or_url: str) -> str:
    """Resolve a relative API path against the configured base URL."""
    candidate = (path_or_url or "").strip()
    if candidate.startswith("http://") or candidate.startswith("https://"):
        return candidate
    return f"{base_url.rstrip('/')}/{candidate.lstrip('/')}"


def open_browser_url(target_url: str, label: str = "browser") -> None:
    """Open a URL in the default browser with a safe terminal fallback."""
    try:
        opened = webbrowser.open(target_url)
    except Exception as exc:
        logger.warning("Failed to open %s automatically: %s", label, exc)
        opened = False

    if opened:
        typer.secho(f"✅ Opened {label}: {target_url}", fg=typer.colors.GREEN)
    else:
        typer.echo(f"Open this {label} URL manually:\n  {target_url}")


def fetch_auth_provider_status(api_url: str) -> Dict[str, Any]:
    """Fetch runtime auth provider metadata with a production-safe fallback."""
    target_url = build_absolute_url(api_url, "/auth/providers/status")
    fallback = {
        "status": "fallback",
        "providers": {
            "google": {"enabled": None, "start_url": "/auth/google/start"},
            "facebook": {"enabled": None, "start_url": "/auth/facebook/start"},
            "password_reset": {
                "enabled": None,
                "request_url": "/auth/password-reset/request",
                "confirm_url": "/auth/password-reset/confirm",
                "page_url": "/forgot-password",
            },
            "telegram_bot": {
                "enabled": None,
                "bot_handle": "@robovainova_bot",
                "verify_flow": "/verify",
            },
        },
        "note": "Provider status endpoint is unavailable on this deployment. Using known default auth routes.",
    }

    try:
        response = httpx.get(target_url, timeout=15.0)
        if response.status_code == 200:
            payload = response.json()
            if isinstance(payload, dict):
                return payload
        logger.warning("Auth provider status endpoint returned %s", response.status_code)
    except Exception as exc:
        logger.warning("Failed to fetch auth provider status: %s", exc)

    return fallback


async def api_form_request(
    endpoint: str,
    form_data: Dict[str, str],
    api_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Submit an x-www-form-urlencoded request to the RoboVAI API."""
    config = load_config()
    base_url = api_url or config.get("api_url", "http://localhost:8000")
    url = build_absolute_url(base_url, endpoint)

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            response = await client.post(url, data=form_data)
            response.raise_for_status()
            return response.json() if response.text else {"status": "success"}
        except httpx.HTTPStatusError as exc:
            detail = exc.response.text.strip() or str(exc)
            logger.error("API form request failed: %s", detail)
            typer.secho(
                f"❌ Request failed ({exc.response.status_code}): {detail}",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=1) from exc
        except httpx.HTTPError as exc:
            logger.error("API form request failed: %s", exc)
            typer.secho(f"❌ Request failed: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc


def persist_authenticated_session(
    access_token: str,
    api_url: Optional[str] = None,
    auth_method: str = "password",
) -> Dict[str, Any]:
    """Persist the authenticated CLI session locally."""
    config = load_config()
    if api_url:
        config["api_url"] = api_url
    config["api_key"] = access_token
    config["authenticated"] = True
    config["authenticated_at"] = datetime.now().isoformat()
    config["auth_method"] = auth_method
    config["onboarding_completed"] = True
    config["onboarding_completed_at"] = datetime.now().isoformat()
    save_config(config)
    return config


def clear_account_cache(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Remove cached account details from local configuration."""
    config = config or load_config()
    for key in [
        "account_email",
        "account_name",
        "account_role",
        "account_tier",
        "account_balance",
        "account_daily_used",
        "account_daily_limit",
        "account_can_use",
    ]:
        config.pop(key, None)
    save_config(config)
    return config


def refresh_account_cache(silent: bool = False) -> Dict[str, Any]:
    """Refresh cached account/profile/subscription details from the backend."""
    config = load_config()
    if not config.get("authenticated") or not config.get("api_key"):
        return config

    try:
        me_payload = asyncio.run(api_request("GET", "/auth/me"))
        subscription_payload = asyncio.run(api_request("GET", "/account/subscription"))
    except typer.Exit:
        if not silent:
            typer.secho(
                "❌ Failed to refresh account status from Nova.",
                fg=typer.colors.RED,
            )
        return config

    subscription = subscription_payload.get("subscription", {})
    config["account_email"] = me_payload.get("email", "")
    config["account_name"] = me_payload.get("full_name") or me_payload.get("username", "")
    config["account_role"] = me_payload.get("role", "user")
    config["account_tier"] = subscription.get("tier", me_payload.get("tier", "free"))
    config["account_balance"] = subscription.get("balance", me_payload.get("balance", 0))
    config["account_daily_used"] = subscription.get("daily_used", me_payload.get("daily_used", 0))
    config["account_daily_limit"] = subscription.get("daily_limit", me_payload.get("daily_limit", 0))
    config["account_can_use"] = subscription.get("can_use", True)
    save_config(config)
    return config


def show_help_center() -> None:
    """Display the core commands and first-run shortcuts in one place."""
    help_text = Text()
    help_text.append("Getting Started\n", style="bold #7ef2c8")
    help_text.append("  robovai\n", style="#d7def0")
    help_text.append("  robovai login --method password\n", style="#d7def0")
    help_text.append("  robovai login --method browser\n", style="#d7def0")
    help_text.append("  robovai provider-wizard\n", style="#d7def0")
    help_text.append("  robovai chat-shell\n\n", style="#d7def0")

    help_text.append("Account & Billing\n", style="bold #68d5ff")
    help_text.append("  robovai whoami\n", style="#d7def0")
    help_text.append("  robovai account-status\n", style="#d7def0")
    help_text.append("  robovai pricing\n", style="#d7def0")
    help_text.append("  robovai subscribe --plan pro\n", style="#d7def0")
    help_text.append("  robovai buy-tokens --package-id tokens_500\n", style="#d7def0")
    help_text.append("  robovai logout\n\n", style="#d7def0")

    help_text.append("Providers\n", style="bold #b57ff6")
    help_text.append("  robovai provider-show\n", style="#d7def0")
    help_text.append("  robovai provider-set --mode offline --chain ollama\n", style="#d7def0")
    help_text.append("  robovai byok-show\n", style="#d7def0")
    help_text.append("  robovai byok-set openai --api-key sk-...\n", style="#d7def0")
    help_text.append("  robovai provider-health\n", style="#d7def0")

    console.print(
        Panel(
            help_text,
            title="[bold #7ef2c8]RoboVAI Help Center[/bold #7ef2c8]",
            border_style="#2a4a7c",
            padding=(1, 2),
            expand=False,
        )
    )


def run_provider_setup_wizard() -> None:
    """Guide the user through provider and runtime selection like a professional CLI."""
    console.print(
        Panel.fit(
            "Choose your runtime path:\n"
            "1. Nova-managed cloud (use current plan)\n"
            "2. Bring your own provider API key\n"
            "3. Offline with Ollama\n"
            "4. Hybrid: BYOK primary + Ollama fallback\n"
            "5. Return",
            title="Provider Setup",
            border_style="magenta",
        )
    )

    choice = typer.prompt("Provider option", default="1").strip()
    config = load_config()

    if choice == "1":
        if not config.get("authenticated"):
            typer.secho(
                "❌ Sign in to Nova first so the CLI can use your current plan and token balance.",
                fg=typer.colors.RED,
            )
            return
        provider_set(
            mode="cloud",
            chain="groq,nvidia,openrouter",
            groq_model=config.get("groq_model", DEFAULT_GROQ_MODEL),
        )
        typer.echo("Nova-managed cloud routing is now active.")
        return

    if choice in {"2", "4"}:
        provider_name = typer.prompt(
            "Provider name",
            default="openai",
        ).strip().lower()
        api_key = typer.prompt(f"{provider_name} API key", hide_input=True).strip()
        model_default = ""
        if provider_name == "groq":
            model_default = config.get("groq_model", DEFAULT_GROQ_MODEL)
        model = typer.prompt("Default model", default=model_default).strip()
        base_url = typer.prompt("Base URL (optional)", default="").strip()
        if not api_key:
            typer.secho("❌ API key is required.", fg=typer.colors.RED)
            return

        provider_config(
            provider_name=provider_name,
            api_key=api_key,
            default_model=model,
            base_url=base_url,
        )
        if config.get("authenticated"):
            try:
                byok_set(provider_name=provider_name, api_key=api_key, model=model, base_url=base_url)
            except typer.Exit:
                typer.secho(
                    "⚠️ Saved local provider config, but failed to sync BYOK to your Nova account.",
                    fg=typer.colors.YELLOW,
                )

        if choice == "2":
            chain = provider_name
            mode = "cloud"
        else:
            ollama_model = typer.prompt(
                "Fallback Ollama model",
                default=config.get("ollama_model", "llama2"),
            ).strip()
            chain = f"{provider_name},ollama"
            mode = "hybrid"
            provider_set(
                mode=mode,
                chain=chain,
                groq_model=(
                    model or config.get("groq_model", DEFAULT_GROQ_MODEL)
                    if provider_name == "groq"
                    else config.get("groq_model", DEFAULT_GROQ_MODEL)
                ),
                ollama_base_url=config.get("ollama_base_url", "http://localhost:11434"),
                ollama_model=ollama_model,
            )
            typer.echo("Hybrid routing is configured.")
            return

        provider_set(
            mode=mode,
            chain=chain,
            groq_model=(
                model or config.get("groq_model", DEFAULT_GROQ_MODEL)
                if provider_name == "groq"
                else config.get("groq_model", DEFAULT_GROQ_MODEL)
            ),
        )
        typer.echo(f"{provider_name.upper()} is now the active provider path.")
        return

    if choice == "3":
        ollama_url = typer.prompt(
            "Ollama URL",
            default=config.get("ollama_base_url", "http://localhost:11434"),
        ).strip()
        ollama_model = typer.prompt(
            "Default Ollama model",
            default=config.get("ollama_model", "llama2"),
        ).strip()
        provider_set(
            mode="offline",
            chain="ollama",
            ollama_base_url=ollama_url,
            ollama_model=ollama_model,
        )
        typer.echo("Offline mode is ready.")
        return

    typer.echo("Returning to home hub.")


def get_headers() -> Dict[str, str]:
    """Get HTTP headers with authentication."""
    config = load_config()
    headers = {"Content-Type": "application/json"}
    if config.get("api_key"):
        if config.get("auth_method") == "admin":
            _enforce_local_admin_binding(config)
            headers.update(_build_admin_security_headers())
        headers["Authorization"] = f"Bearer {config['api_key']}"
    return headers


def _current_local_admin_user() -> str:
    """Return the normalized local OS user for CLI admin binding."""
    return getpass.getuser().strip().lower()


def _compute_admin_device_id() -> str:
    """Derive a stable local device fingerprint for admin CLI binding."""
    fingerprint_seed = "|".join(
        [
            _current_local_admin_user(),
            platform.node().strip().lower(),
            platform.system().strip().lower(),
            platform.machine().strip().lower(),
        ]
    )
    return hashlib.sha256(fingerprint_seed.encode("utf-8")).hexdigest()


def _build_admin_security_headers() -> Dict[str, str]:
    """Build extra headers required for protected admin requests."""
    headers = {
        "X-RobovAI-Admin-User": _current_local_admin_user(),
        "X-RobovAI-Admin-Device": _compute_admin_device_id(),
    }
    admin_phrase = os.environ.get("ROBOVAI_ADMIN_PASSPHRASE", "").strip()
    if admin_phrase:
        headers["X-RobovAI-Admin-Phrase"] = admin_phrase
    return headers


def _enforce_local_admin_binding(config: Dict[str, Any]) -> None:
    """Block admin sessions when the config is used by another user or device."""
    bound_user = (config.get("admin_local_user") or "").strip().lower()
    bound_device = (config.get("admin_device_id") or "").strip()
    current_user = _current_local_admin_user()
    current_device = _compute_admin_device_id()

    if bound_user and bound_user != current_user:
        typer.secho(
            "❌ This admin session is locked to a different local user.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    if bound_device and bound_device != current_device:
        typer.secho(
            "❌ This admin session is locked to a different device.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)


async def api_request(
    method: str,
    endpoint: str,
    data: Optional[Dict] = None,
    api_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Make HTTP request to RoboVAI API."""
    config = load_config()
    base_url = api_url or config.get("api_url", "http://localhost:8000")

    url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
    headers = get_headers()

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            if method.upper() == "GET":
                response = await client.get(url, headers=headers)
            elif method.upper() == "POST":
                response = await client.post(url, json=data, headers=headers)
            elif method.upper() == "PUT":
                response = await client.put(url, json=data, headers=headers)
            elif method.upper() == "DELETE":
                response = await client.delete(url, headers=headers)
            else:
                raise ValueError(f"Unsupported method: {method}")

            response.raise_for_status()
            return response.json() if response.text else {"status": "success"}
        except httpx.HTTPError as e:
            logger.error(f"API request failed: {e}")
            raise typer.Exit(code=1)


def load_agent_config(name: str) -> Dict[str, Any]:
    """Load an agent profile from local CLI storage."""
    agent_file = AGENTS_DIR / f"{name}.json"
    if not agent_file.exists():
        typer.secho(f"❌ Agent '{name}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    with open(agent_file, "r", encoding="utf-8") as f:
        return json.load(f)


def require_authentication() -> Dict[str, Any]:
    """Ensure the CLI is authenticated before calling protected backend routes."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)
    if config.get("auth_method") == "admin":
        _enforce_local_admin_binding(config)
    return config


def parse_json_input(raw_value: str, label: str) -> Dict[str, Any]:
    """Parse JSON from an inline string or a file path."""
    candidate = raw_value.strip()
    if not candidate:
        return {}

    try:
        if candidate.startswith("{"):
            payload = json.loads(candidate)
        else:
            with open(candidate, "r", encoding="utf-8-sig") as file_handle:
                payload = json.load(file_handle)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        typer.secho(f"❌ Invalid {label}: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if not isinstance(payload, dict):
        typer.secho(
            f"❌ {label} must resolve to a JSON object.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)
    return payload


def split_csv_values(raw_value: str) -> list[str]:
    """Normalize comma-separated values into a trimmed list."""
    return [item.strip() for item in raw_value.split(",") if item.strip()]


def print_structured_output(title: str, payload: Any) -> None:
    """Render structured data consistently for CLI responses."""
    rendered = json.dumps(payload, indent=2, ensure_ascii=False, default=str)
    console.print(Panel.fit(rendered, title=title, border_style="cyan"))


def _filter_english_fields(data: Any) -> Any:
    """Recursively strip fields ending with '_ar' from dicts/lists."""
    if isinstance(data, dict):
        return {k: _filter_english_fields(v) for k, v in data.items() if not k.endswith("_ar")}
    if isinstance(data, list):
        return [_filter_english_fields(item) for item in data]
    return data


def _format_pricing_output(payload: Any) -> None:
    """Render pricing data as formatted Rich tables instead of raw JSON."""
    if not isinstance(payload, dict):
        print_structured_output("Nova Pricing", payload)
        return

    # --- Subscription Plans ---
    plans = payload.get("plans") or payload.get("subscription_plans") or []
    if isinstance(plans, list) and plans:
        table = Table(
            title="Subscription Plans",
            border_style="cyan",
            show_header=True,
            header_style="bold cyan",
            expand=False,
        )
        table.add_column("Plan", style="bold white", min_width=12)
        table.add_column("Price", style="bold green", justify="right", min_width=10)
        table.add_column("Tokens", style="yellow", justify="right", min_width=10)
        table.add_column("Features", style="white", min_width=30)

        for plan in plans:
            name = plan.get("name_en") or plan.get("name") or plan.get("id", "—")
            price = plan.get("price_usd") or plan.get("price") or plan.get("amount", "—")
            price_str = f"${price}" if isinstance(price, (int, float)) else str(price)
            tokens = plan.get("tokens") or plan.get("token_limit") or plan.get("monthly_tokens", "—")
            tokens_str = f"{tokens:,}" if isinstance(tokens, (int, float)) else str(tokens)

            features = plan.get("features_en") or plan.get("features") or []
            if isinstance(features, list):
                features_str = "\n".join(f"  + {f}" for f in features[:6])
            elif isinstance(features, str):
                features_str = features
            else:
                features_str = "—"

            table.add_row(name, price_str, tokens_str, features_str)

        console.print(table)
        console.print()

    # --- Token Packages ---
    packages = payload.get("token_packages") or payload.get("packages") or []
    if isinstance(packages, list) and packages:
        pkg_table = Table(
            title="Token Packages",
            border_style="yellow",
            show_header=True,
            header_style="bold yellow",
            expand=False,
        )
        pkg_table.add_column("Package", style="bold white", min_width=15)
        pkg_table.add_column("Tokens", style="yellow", justify="right", min_width=10)
        pkg_table.add_column("Price", style="bold green", justify="right", min_width=10)

        for pkg in packages:
            pkg_name = pkg.get("name_en") or pkg.get("name") or pkg.get("id", "—")
            pkg_tokens = pkg.get("tokens") or pkg.get("amount", "—")
            pkg_tokens_str = f"{pkg_tokens:,}" if isinstance(pkg_tokens, (int, float)) else str(pkg_tokens)
            pkg_price = pkg.get("price_usd") or pkg.get("price") or "—"
            pkg_price_str = f"${pkg_price}" if isinstance(pkg_price, (int, float)) else str(pkg_price)
            pkg_table.add_row(pkg_name, pkg_tokens_str, pkg_price_str)

        console.print(pkg_table)
        console.print()

    # --- Payment Providers ---
    providers = payload.get("payment_providers") or payload.get("providers") or []
    if isinstance(providers, list) and providers:
        prov_items = ", ".join(str(p.get("name", p) if isinstance(p, dict) else p) for p in providers)
        console.print(Panel.fit(f"Available: {prov_items}", title="Payment Providers", border_style="green"))
        console.print()

    # Fallback: if no recognized structure, show filtered JSON
    if not plans and not packages and not providers:
        filtered = _filter_english_fields(payload)
        print_structured_output("Nova Pricing", filtered)


def _format_account_status(identity: Any, subscription: Any, balance: Any) -> None:
    """Render account status as a formatted Rich panel with sections."""
    body = Text()

    # Identity section
    body.append("Identity\n", style="bold cyan underline")
    if isinstance(identity, dict):
        body.append(f"  Name:  {identity.get('full_name') or identity.get('name', '—')}\n", style="white")
        body.append(f"  Email: {identity.get('email', '—')}\n", style="white")
        body.append(f"  Role:  {identity.get('role', 'user')}\n", style="white")
        user_id = identity.get("id") or identity.get("user_id", "")
        if user_id:
            body.append(f"  ID:    {user_id}\n", style="dim")
    else:
        body.append(f"  {identity}\n", style="white")

    body.append("\n")

    # Subscription section
    body.append("Subscription\n", style="bold green underline")
    if isinstance(subscription, dict):
        plan = subscription.get("plan") or subscription.get("tier") or subscription.get("plan_name", "free")
        status = subscription.get("status", "active")
        body.append(f"  Plan:   {plan}\n", style="white")
        body.append(f"  Status: {status}\n", style="white")
        expires = subscription.get("expires_at") or subscription.get("end_date", "")
        if expires:
            body.append(f"  Expires: {expires}\n", style="dim")
    else:
        body.append(f"  {subscription}\n", style="white")

    body.append("\n")

    # Balance section
    body.append("Token Balance\n", style="bold yellow underline")
    if isinstance(balance, dict):
        tokens = balance.get("balance") or balance.get("tokens") or balance.get("remaining", 0)
        daily_used = balance.get("daily_used") or balance.get("used_today", 0)
        daily_limit = balance.get("daily_limit") or balance.get("limit", 0)
        body.append(f"  Available: {tokens:,}\n" if isinstance(tokens, (int, float)) else f"  Available: {tokens}\n", style="white")
        body.append(f"  Used today: {daily_used:,}\n" if isinstance(daily_used, (int, float)) else f"  Used today: {daily_used}\n", style="white")
        if daily_limit:
            body.append(f"  Daily limit: {daily_limit:,}\n" if isinstance(daily_limit, (int, float)) else f"  Daily limit: {daily_limit}\n", style="dim")
    else:
        body.append(f"  {balance}\n", style="white")

    console.print(Panel(body, title="[bold cyan]Nova Account Status[/bold cyan]", border_style="cyan", padding=(1, 2), expand=False))


def _format_identity(profile: Any) -> None:
    """Render whoami profile data as a formatted panel."""
    if not isinstance(profile, dict):
        print_structured_output("Nova Identity", profile)
        return

    body = Text()
    body.append(f"Name:  {profile.get('full_name') or profile.get('name', '—')}\n", style="bold white")
    body.append(f"Email: {profile.get('email', '—')}\n", style="white")
    body.append(f"Role:  {profile.get('role', 'user')}\n", style="white")
    user_id = profile.get("id") or profile.get("user_id", "")
    if user_id:
        body.append(f"ID:    {user_id}\n", style="dim")
    verified = profile.get("is_verified") or profile.get("verified")
    if verified is not None:
        status = "Verified" if verified else "Not verified"
        body.append(f"Status: {status}\n", style="green" if verified else "yellow")

    console.print(Panel.fit(body, title="[bold cyan]Nova Identity[/bold cyan]", border_style="cyan"))


def _format_auth_providers(payload: Any) -> None:
    """Render auth provider status as a formatted table."""
    if not isinstance(payload, dict):
        print_structured_output("Nova Auth Providers", payload)
        return

    providers = payload.get("providers", {})
    if isinstance(providers, dict):
        table = Table(title="Auth Providers", border_style="cyan", expand=False)
        table.add_column("Provider", style="bold white", min_width=12)
        table.add_column("Status", min_width=10)
        table.add_column("Start URL", style="dim", min_width=20)

        for name, info in providers.items():
            if isinstance(info, dict):
                enabled = info.get("enabled", False)
                status_text = "[green]Enabled[/green]" if enabled else "[red]Disabled[/red]"
                url = info.get("start_url", "—")
            else:
                status_text = str(info)
                url = "—"
            table.add_row(name.title(), status_text, url)

        console.print(table)
    else:
        print_structured_output("Nova Auth Providers", payload)


def _format_signup_result(result: Any) -> None:
    """Format signup/registration response as a Rich panel."""
    if not isinstance(result, dict):
        print_structured_output("Nova Account Created", result)
        return
    filtered = _filter_english_fields(result)
    lines: list[str] = []
    for key in ("message", "user_id", "email", "status", "next_step"):
        val = filtered.get(key)
        if val:
            label = key.replace("_", " ").title()
            lines.append(f"[bold]{label}:[/bold] {val}")
    # Include remaining keys not already shown
    shown = {"message", "user_id", "email", "status", "next_step"}
    for k, v in filtered.items():
        if k not in shown and v:
            lines.append(f"[bold]{k.replace('_', ' ').title()}:[/bold] {v}")
    body = "\n".join(lines) if lines else str(filtered)
    console.print(Panel.fit(body, title="[bold green]Nova Account Created[/bold green]", border_style="green"))


def _format_checkout_result(result: Any, title: str) -> None:
    """Format subscribe / buy-tokens checkout response as a Rich panel."""
    if not isinstance(result, dict):
        print_structured_output(title, result)
        return
    filtered = _filter_english_fields(result)
    lines: list[str] = []
    for key in ("message", "status", "plan", "package_id", "amount", "currency", "checkout_url"):
        val = filtered.get(key)
        if val:
            label = key.replace("_", " ").title()
            lines.append(f"[bold]{label}:[/bold] {val}")
    shown = {"message", "status", "plan", "package_id", "amount", "currency", "checkout_url"}
    for k, v in filtered.items():
        if k not in shown and v:
            lines.append(f"[bold]{k.replace('_', ' ').title()}:[/bold] {v}")
    body = "\n".join(lines) if lines else str(filtered)
    console.print(Panel.fit(body, title=f"[bold cyan]{title}[/bold cyan]", border_style="cyan"))


def _persona_prompt_from_file(file_path: Path) -> str:
    """Load persona/system prompt text from a source file safely."""
    if not file_path.exists() or not file_path.is_file():
        raise ValueError(f"Persona file not found: {file_path}")
    try:
        text = file_path.read_text(encoding="utf-8-sig").strip()
    except UnicodeDecodeError as exc:
        raise ValueError(f"Persona file encoding is not UTF-8: {file_path}") from exc
    if not text:
        raise ValueError(f"Persona file is empty: {file_path}")
    return text


# ═══════════════════════════════════════════════════════════════════════════
# AUTH COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def login(
    api_key: Annotated[str, typer.Option(help="Your RoboVAI API key")] = "",
    api_url: Annotated[
        str, typer.Option(help="API URL (default: localhost:8000)")
    ] = "",
    method: Annotated[
        str,
        typer.Option(help="api-key | password | browser | google | facebook | admin"),
    ] = "api-key",
    email: Annotated[str, typer.Option(help="Nova account email for password login")] = "",
    password: Annotated[str, typer.Option(help="Nova account password for password login")] = "",
    admin_token: Annotated[str, typer.Option(help="Admin token (or set ROBOVAI_ADMIN_TOKEN env var)")] = "",
    admin_phrase: Annotated[str, typer.Option(help="Admin passphrase (or set ROBOVAI_ADMIN_PASSPHRASE env var)")] = "",
):
    """🔐 Authenticate with RoboVAI using API key, password, browser-assisted login, or admin token."""
    config = load_config()
    resolved_api_url = api_url or config.get("api_url", "http://localhost:8000")

    if api_url:
        config["api_url"] = api_url
        save_config(config)

    normalized_method = method.strip().lower()

    # ── Admin auto-login: bypass registration with admin token ──
    if normalized_method == "admin" or admin_token:
        token = admin_token or os.environ.get("ROBOVAI_ADMIN_TOKEN", "")
        if not token:
            token = typer.prompt("Enter admin token", hide_input=True).strip()
        phrase = admin_phrase or os.environ.get("ROBOVAI_ADMIN_PASSPHRASE", "")
        if not phrase:
            phrase = typer.prompt("Enter admin passphrase", hide_input=True).strip()
        if not token:
            typer.secho("❌ Admin token is required. Set --admin-token or ROBOVAI_ADMIN_TOKEN env var.", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        if not phrase:
            typer.secho("❌ Admin passphrase is required. Set --admin-phrase or ROBOVAI_ADMIN_PASSPHRASE env var.", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        os.environ["ROBOVAI_ADMIN_PASSPHRASE"] = phrase
        persist_authenticated_session(
            access_token=token,
            api_url=resolved_api_url,
            auth_method="admin",
        )
        config = load_config()
        config["account_role"] = "admin"
        config["admin_local_user"] = _current_local_admin_user()
        config["admin_device_id"] = _compute_admin_device_id()
        save_config(config)
        refresh_account_cache(silent=True)
        typer.secho("✅ Logged in as admin.", fg=typer.colors.GREEN)
        typer.echo(f"   API URL: {resolved_api_url}")
        typer.echo(f"   Local user binding: {config['admin_local_user']}")
        typer.echo(f"   Device binding: {config['admin_device_id'][:12]}...")
        typer.echo("   Future admin commands require ROBOVAI_ADMIN_PASSPHRASE in the current terminal session.")
        return

    normalized_method = method.strip().lower()

    if normalized_method in {"browser", "google", "facebook"}:
        providers_payload = fetch_auth_provider_status(resolved_api_url)
        providers = providers_payload.get("providers", {})

        if normalized_method == "browser":
            login_url = build_absolute_url(resolved_api_url, "/login")
            signup_url = build_absolute_url(resolved_api_url, "/signup")
            open_browser_url(login_url, label="Nova login")
            typer.echo("If you need to create a new account first, open:")
            typer.echo(f"  {signup_url}")
            typer.echo(
                "After creating your account, return here and run 'robovai login --method password'."
            )
            return

        provider_key = normalized_method
        provider_info = providers.get(provider_key, {}) if isinstance(providers, dict) else {}
        if provider_info.get("enabled") is False:
            typer.secho(
                f"❌ {provider_key.title()} login is not enabled on this Nova deployment.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=1)

        if provider_info.get("enabled") is None:
            typer.secho(
                "⚠️ Runtime provider status is not available on this deployment yet; opening the general Nova login page instead.",
                fg=typer.colors.YELLOW,
            )
            open_browser_url(build_absolute_url(resolved_api_url, "/login"), label="Nova login")
            typer.echo("After login in the browser, authenticate the CLI with 'robovai login --method password'.")
            return

        start_url = build_absolute_url(
            resolved_api_url,
            provider_info.get("start_url", f"/auth/{provider_key}/start"),
        )
        open_browser_url(f"{start_url}?next=/cli", label=f"Nova {provider_key.title()} sign-in")
        typer.echo(
            "Browser sign-in opens your Nova account flow. For CLI session authentication today,"
        )
        typer.echo("finish sign-in, then run 'robovai login --method password' or use your Nova API key.")
        return

    if normalized_method == "password":
        if not email:
            email = typer.prompt("Nova account email").strip()
        if not password:
            password = typer.prompt("Nova account password", hide_input=True).strip()
        if not email or not password:
            typer.secho("❌ Email and password are required.", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        result = asyncio.run(
            api_form_request(
                "/auth/login",
                {"username": email, "password": password},
                api_url=resolved_api_url,
            )
        )
        access_token = result.get("access_token", "")
        if not access_token:
            typer.secho("❌ Login succeeded but no access token was returned.", fg=typer.colors.RED)
            raise typer.Exit(code=1)
        persist_authenticated_session(
            access_token=access_token,
            api_url=resolved_api_url,
            auth_method="password",
        )
        refresh_account_cache()
        typer.secho("✅ Logged in with your Nova account.", fg=typer.colors.GREEN)
        return

    if not api_key:
        api_key = typer.prompt("Enter your RoboVAI API key")

    persist_authenticated_session(
        access_token=api_key,
        api_url=resolved_api_url,
        auth_method="api-key",
    )
    refresh_account_cache(silent=True)
    typer.secho("✅ Logged in successfully!", fg=typer.colors.GREEN)
    typer.echo(f"   API URL: {resolved_api_url}")


@app.command()
def signup(
    full_name: Annotated[str, typer.Option(help="Your full name")] = "",
    email: Annotated[str, typer.Option(help="Nova account email")] = "",
    password: Annotated[str, typer.Option(help="Nova account password")] = "",
    api_url: Annotated[str, typer.Option(help="API URL (default: localhost:8000)")] = "",
    open_portal: Annotated[
        bool,
        typer.Option(help="Open the Nova signup page after the CLI registration response."),
    ] = True,
):
    """🆕 Create a Nova account from the CLI and guide verification."""
    config = load_config()
    resolved_api_url = api_url or config.get("api_url", "http://localhost:8000")
    if not full_name:
        full_name = typer.prompt("Full name").strip()
    if not email:
        email = typer.prompt("Email").strip()
    if not password:
        password = typer.prompt("Password", hide_input=True).strip()

    if not full_name or not email or not password:
        typer.secho("❌ Full name, email, and password are required.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    result = asyncio.run(
        api_request(
            "POST",
            "/auth/register",
            {"full_name": full_name, "email": email, "password": password},
            api_url=resolved_api_url,
        )
    )
    _format_signup_result(result)
    typer.echo("Next step: verify your account through @robovainova_bot on Telegram if required by the backend.")
    if open_portal:
        open_browser_url(build_absolute_url(resolved_api_url, "/signup"), label="Nova signup")


@app.command()
def logout():
    """🚪 Logout from RoboVAI."""
    config = load_config()
    if config.get("authenticated") and config.get("api_key"):
        try:
            asyncio.run(api_request("POST", "/auth/logout"))
        except typer.Exit:
            typer.secho(
                "⚠️ Local session cleared, but backend session revoke could not be confirmed.",
                fg=typer.colors.YELLOW,
            )
    config["api_key"] = ""
    config["authenticated"] = False
    config.pop("auth_method", None)
    config.pop("admin_local_user", None)
    config.pop("admin_device_id", None)
    clear_account_cache(config)
    typer.secho("✅ Logged out successfully!", fg=typer.colors.GREEN)


@app.command()
def whoami():
    """👤 Show current authenticated user/context."""
    require_authentication()
    profile = asyncio.run(api_request("GET", "/auth/me"))
    _format_identity(profile)


@app.command("account-status")
def account_status():
    """💼 Show Nova account identity, plan, token balance, and recent usage status."""
    require_authentication()
    refresh_account_cache(silent=True)
    identity = asyncio.run(api_request("GET", "/auth/me"))
    subscription = asyncio.run(api_request("GET", "/account/subscription"))
    balance = asyncio.run(api_request("GET", "/user/balance"))
    _format_account_status(identity, subscription, balance)


@app.command()
def pricing():
    """💳 Show available plans, token packages, and payment providers."""
    payload = asyncio.run(api_request("GET", "/payments/pricing"))
    _format_pricing_output(payload)


@app.command()
def subscribe(
    plan: Annotated[str, typer.Option(help="Target plan: pro | enterprise")] = "pro",
    method: Annotated[str, typer.Option(help="Payment method: card | wallet")] = "card",
    phone_number: Annotated[str, typer.Option(help="Phone number for wallet payments")] = "",
    open_checkout: Annotated[bool, typer.Option(help="Open checkout URL in browser when returned")] = True,
):
    """🧾 Start a Nova subscription checkout for the selected plan."""
    require_authentication()
    payload = {"plan": plan, "method": method}
    if phone_number:
        payload["phone_number"] = phone_number
    result = asyncio.run(api_request("POST", "/account/subscribe", payload))
    _format_checkout_result(result, "Subscription Checkout")
    checkout_url = result.get("checkout_url", "") if isinstance(result, dict) else ""
    if checkout_url and open_checkout:
        open_browser_url(checkout_url, label="subscription checkout")


@app.command("buy-tokens")
def buy_tokens(
    package_id: Annotated[str, typer.Option(help="Package id, for example tokens_500")] = "tokens_500",
    method: Annotated[str, typer.Option(help="Payment method: card | wallet")] = "card",
    phone_number: Annotated[str, typer.Option(help="Phone number for wallet payments")] = "",
    open_checkout: Annotated[bool, typer.Option(help="Open checkout URL in browser when returned")] = True,
):
    """🪙 Buy extra Nova token packages from the CLI."""
    require_authentication()
    payload = {"package_id": package_id, "method": method}
    if phone_number:
        payload["phone_number"] = phone_number
    result = asyncio.run(api_request("POST", "/account/buy-tokens", payload))
    _format_checkout_result(result, "Buy Tokens")
    checkout_url = result.get("checkout_url", "") if isinstance(result, dict) else ""
    if checkout_url and open_checkout:
        open_browser_url(checkout_url, label="token checkout")


@app.command("auth-providers")
def auth_providers():
    """🌐 Show which Nova sign-in providers are enabled on the current deployment."""
    config = load_config()
    payload = fetch_auth_provider_status(config.get("api_url", "http://localhost:8000"))
    _format_auth_providers(payload)


@app.command("provider-wizard")
def provider_wizard():
    """🧭 Launch the interactive provider/runtime setup wizard."""
    run_provider_setup_wizard()


@app.command("help-center")
def help_center():
    """🆘 Show the curated RoboVAI onboarding and command shortcuts."""
    show_help_center()


# ═══════════════════════════════════════════════════════════════════════════
# AGENT COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def agent_create(
    name: Annotated[str, typer.Argument(help="Agent name")],
    model: Annotated[
        str, typer.Option(help="Model (claude, gpt-4, ollama/llama2, etc.)")
    ] = "claude",
    description: Annotated[str, typer.Option(help="Agent description")] = "",
    system_prompt: Annotated[str, typer.Option(help="System prompt instructions")] = "",
):
    """🤖 Create a new AI agent."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    agent_data = {
        "name": name,
        "model": model,
        "description": description or f"{name} agent",
        "system_prompt": system_prompt or f"You are {name}, a helpful AI assistant.",
        "created_at": datetime.now().isoformat(),
    }

    agent_file = AGENTS_DIR / f"{name}.json"
    with open(agent_file, "w", encoding="utf-8") as f:
        json.dump(agent_data, f, indent=2, ensure_ascii=False)

    typer.secho(f"✅ Agent '{name}' created successfully!", fg=typer.colors.GREEN)
    typer.echo(f"   Model: {model}")
    typer.echo(f"   Config: {agent_file}")


@app.command()
def agent_list():
    """📋 List all local agents."""
    agents = list(AGENTS_DIR.glob("*.json"))

    if not agents:
        typer.secho("No agents found.", fg=typer.colors.YELLOW)
        return

    console.print("\n[bold]Local Agents:[/bold]")
    for agent_file in agents:
        with open(agent_file, "r", encoding="utf-8") as f:
            agent = json.load(f)
        typer.echo(f"  • {agent['name']} ({agent['model']})")


@app.command()
def agent_delete(
    name: Annotated[str, typer.Argument(help="Agent name")],
):
    """🗑️ Delete an agent."""
    agent_file = AGENTS_DIR / f"{name}.json"

    if not agent_file.exists():
        typer.secho(f"❌ Agent '{name}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if typer.confirm(f"Are you sure you want to delete '{name}'?"):
        agent_file.unlink()
        typer.secho(f"✅ Agent '{name}' deleted.", fg=typer.colors.GREEN)


# ═══════════════════════════════════════════════════════════════════════════
# LOCAL LLM COMMANDS (OLLAMA)
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def ollama_status():
    """🔍 Check Ollama service status."""
    try:
        import subprocess

        result = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            typer.secho("✅ Ollama is running", fg=typer.colors.GREEN)
            typer.echo("\nInstalled models:")
            typer.echo(result.stdout)
        else:
            typer.secho("❌ Ollama error", fg=typer.colors.RED)
            typer.echo(result.stderr)
    except FileNotFoundError:
        typer.secho(
            "❌ Ollama not found. Install it from https://ollama.ai",
            fg=typer.colors.RED,
        )
    except Exception as e:
        typer.secho(f"❌ Error: {e}", fg=typer.colors.RED)


@app.command()
def ollama_pull(
    model_name: Annotated[
        str, typer.Argument(help="Model to pull (e.g., llama2, mistral, neural-chat)")
    ] = "llama2",
):
    """📥 Download an Ollama model locally."""
    try:
        import subprocess

        typer.echo(f"Pulling {model_name}...")
        result = subprocess.run(
            ["ollama", "pull", model_name], capture_output=False, text=True
        )
        if result.returncode == 0:
            typer.secho(
                f"✅ {model_name} downloaded successfully!", fg=typer.colors.GREEN
            )
        else:
            typer.secho(f"❌ Failed to pull {model_name}", fg=typer.colors.RED)
    except FileNotFoundError:
        typer.secho("❌ Ollama not installed.", fg=typer.colors.RED)


@app.command()
def provider_show():
    """🧭 Show current provider mode (cloud/offline/hybrid) and model settings."""
    config = load_config()
    configured_providers = config.get("configured_providers", {})
    groq_provider = configured_providers.get("groq", {})
    groq_api_key = str(groq_provider.get("api_key", "") or os.getenv("GROQ_API_KEY", ""))
    groq_model = str(
        groq_provider.get("default_model")
        or config.get("groq_model")
        or os.getenv("GROQ_MODEL", DEFAULT_GROQ_MODEL)
    )
    console.print("\n[bold]Provider Profile:[/bold]")
    console.print(f"  Mode: {config.get('provider_mode', 'auto')}")
    console.print(
        f"  Chain: {config.get('provider_chain', 'groq,nvidia,openrouter,ollama')}"
    )
    console.print(f"  Groq Model: {groq_model}")
    console.print(f"  Groq API Key: {_masked_secret(groq_api_key)}")
    console.print(
        f"  Ollama URL: {config.get('ollama_base_url', 'http://localhost:11434')}"
    )
    console.print(f"  Ollama Model: {config.get('ollama_model', 'llama2')}")


@app.command()
def provider_set(
    mode: Annotated[
        str,
        typer.Option(help="Provider mode: auto | cloud | hybrid | offline | ollama"),
    ] = "hybrid",
    chain: Annotated[
        str,
        typer.Option(help="Fallback chain, comma-separated providers"),
    ] = "groq,nvidia,openrouter,ollama",
    groq_model: Annotated[
        str,
        typer.Option(help="Default Groq model for cloud and hybrid routing"),
    ] = DEFAULT_GROQ_MODEL,
    ollama_base_url: Annotated[
        str,
        typer.Option(help="Ollama API URL"),
    ] = "http://localhost:11434",
    ollama_model: Annotated[
        str,
        typer.Option(help="Default Ollama model"),
    ] = "llama2",
):
    """⚙️ Configure cloud/offline provider profile for CLI and backend env export."""
    allowed_modes = {"auto", "cloud", "hybrid", "offline", "ollama"}
    if mode not in allowed_modes:
        typer.secho(f"❌ Invalid mode '{mode}'.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    config = load_config()
    config["provider_mode"] = mode
    config["provider_chain"] = chain
    config["groq_model"] = groq_model.strip() or DEFAULT_GROQ_MODEL
    config["ollama_base_url"] = ollama_base_url
    config["ollama_model"] = ollama_model
    save_config(config)

    typer.secho("✅ Provider profile updated.", fg=typer.colors.GREEN)
    typer.echo("Use these env vars in backend deployment:")
    typer.echo(f"  LLM_PROVIDER={mode}")
    typer.echo(f"  LLM_PROVIDER_CHAIN={chain}")
    typer.echo(f"  GROQ_MODEL={config['groq_model']}")
    typer.echo(f"  OLLAMA_BASE_URL={ollama_base_url}")
    typer.echo(f"  OLLAMA_MODEL={ollama_model}")


# ═══════════════════════════════════════════════════════════════════════════
# ADVANCED LLM PROVIDER COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def provider_list():
    """📋 List all configured LLM providers (OpenAI, Anthropic, Gemini, etc)."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _list():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/providers",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                providers = data.get("providers", [])

                if not providers:
                    console.print("[yellow]No providers configured.[/yellow]")
                    return

                console.print("\n[bold cyan]Available LLM Providers:[/bold cyan]")
                for provider in providers:
                    status = (
                        "[green]✓[/green]"
                        if provider.get("available")
                        else "[red]✗[/red]"
                    )
                    console.print(
                        f"  {status} [bright_cyan]{provider['name']}[/bright_cyan]"
                    )
                    if provider.get("default_model"):
                        typer.echo(f"     Default: {provider['default_model']}")
                    if provider.get("models"):
                        typer.echo(f"     Models: {', '.join(provider['models'][:3])}")
                    typer.echo()

        except Exception as e:
            typer.secho(f"❌ Failed to list providers: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_list())


@app.command()
def provider_models(
    provider_name: Annotated[
        str,
        typer.Option(help="Provider name (openai, anthropic, gemini, mistral, ollama)"),
    ] = "openai",
    show_custom: Annotated[
        bool,
        typer.Option(help="Show how to add custom models"),
    ] = False,
):
    """🤖 List all available LATEST models for a specific provider."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _models():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/providers/{provider_name}/models",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                models = data.get("models", [])

                if not models:
                    console.print(f"[yellow]No models found for {provider_name}.[/yellow]")
                    return

                console.print(
                    f"\n[bold cyan]Models for {provider_name.upper()}:[/bold cyan]"
                )
                for model in models:
                    typer.echo(f"  • {model}")
                    typer.echo()
                    console.print("[dim]✓ These are LATEST models from API[/dim]")

                    if show_custom:
                        typer.echo()
                        typer.echo(
                            "[bright_cyan]💡 To use a custom model not in list:[/bright_cyan]"
                        )
                        typer.echo(
                            f"  robovai llm-generate --provider {provider_name} --model my-custom-model"
                        )
                        typer.echo("  (Provider will validate it on use)")

        except Exception as e:
            typer.secho(f"❌ Failed to get models: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_models())


@app.command()
def provider_config(
    provider_name: Annotated[
        str, typer.Argument(help="Provider name (groq, openai, anthropic, gemini, ollama)")
    ],
    api_key: Annotated[
        str,
        typer.Option(help="API key"),
    ] = "",
    default_model: Annotated[
        str,
        typer.Option(help="Default model for this provider"),
    ] = "",
    base_url: Annotated[
        str,
        typer.Option(help="Base URL for custom or self-hosted provider endpoints"),
    ] = "",
):
    """🔑 Configure an LLM provider (API keys, default model)."""
    config = load_config()

    providers_key = "configured_providers"
    if providers_key not in config:
        config[providers_key] = {}

    provider_config = config[providers_key].get(provider_name, {})

    if api_key:
        provider_config["api_key"] = api_key
    if default_model:
        provider_config["default_model"] = default_model
        if provider_name.strip().lower() == "groq":
            config["groq_model"] = default_model
    if base_url:
        provider_config["base_url"] = base_url

    config[providers_key][provider_name] = provider_config
    save_config(config)

    typer.secho(
        f"✅ {provider_name.upper()} configured successfully!", fg=typer.colors.GREEN
    )

    if api_key:
        masked = f"{api_key[:8]}...{api_key[-4:]}"
        typer.echo(f"  API Key: {masked}")
    if default_model:
        typer.echo(f"  Default Model: {default_model}")
    if base_url:
        typer.echo(f"  Base URL: {base_url}")

    # Export environment variable info
    typer.echo("\nSet environment variable:")
    typer.echo(f"  {provider_name.upper()}_API_KEY=<hidden>")
    if default_model:
        typer.echo(f"  {provider_name.upper()}_MODEL={default_model}")
    if base_url:
        typer.echo(f"  {provider_name.upper()}_BASE_URL={base_url}")


@app.command()
def provider_health():
    """🏥 Check health status of all configured LLM providers."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _health():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/health",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                health = data.get("health", {})

                console.print("\n[bold cyan]Provider Health Status:[/bold cyan]")
                for provider, status in health.items():
                    status_color = (
                        typer.colors.GREEN if status == "healthy" else typer.colors.RED
                    )
                    typer.echo(
                        f"  {provider:<15} [{typer.style(status, fg=status_color)}]"
                    )

        except Exception as e:
            typer.secho(f"❌ Failed to check health: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_health())


@app.command()
def local_backends():
    """🖥️ Discover and manage local LLM backends (Ollama, vLLM, LM Studio, LocalAI)."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _backends():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/local-backends",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                backends = data.get("backends", {})

                console.print("\n[bold cyan]Local LLM Backends:[/bold cyan]")

                if not backends:
                    console.print("[yellow]No local backends detected.[/yellow]")
                    typer.echo("\nInstall one of:")
                    typer.echo("  • Ollama: ollama.ai")
                    typer.echo("  • vLLM: https://github.com/vllm-project/vllm")
                    typer.echo("  • LM Studio: lmstudio.ai")
                    typer.echo("  • LocalAI: localai.io")
                    return

                for backend_name, info in backends.items():
                    status = (
                        "[green]✓[/green]" if info.get("available") else "[red]✗[/red]"
                    )
                    console.print(f"  {status} [bright_cyan]{backend_name}[/bright_cyan]")
                    if info.get("models"):
                        models_str = ", ".join(info["models"][:3])
                        typer.echo(f"     Models: {models_str}")

        except Exception as e:
            typer.secho(f"❌ Failed to get backends: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_backends())


@app.command()
def llm_test(
    provider: Annotated[
        str, typer.Option(help="Provider to test (openai, anthropic, gemini, ollama)")
    ] = "auto",
    prompt: Annotated[str, typer.Option(help="Test prompt")] = "What is 2+2?",
):
    """✈️ Test an LLM provider with a sample prompt."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {"Authorization": f"Bearer {token}"} if token else {}

    async def _test():
        try:
            console.print(f"\nTesting provider: [bold cyan]{provider}[/bold cyan]")
            typer.echo(f"Prompt: {prompt}\n")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{api_url}/llm/generate",
                    json={
                        "prompt": prompt,
                        "provider": provider,
                    },
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                result = data.get("response", "No response")
                used_provider = data.get("provider_used", "unknown")

                console.print("[bold]Response:[/bold]")
                typer.echo(f"  {result}\n")
                console.print(f"[dim]Used provider: {used_provider}[/dim]")

        except Exception as e:
            typer.secho(f"❌ Test failed: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_test())


@app.command()
def chat_shell(
    ai_level: Annotated[
        str, typer.Option(help="fast | balanced | powerful")
    ] = "balanced",
    use_agent: Annotated[
        bool,
        typer.Option(help="Use /agent/run when authenticated for full Nova agent routing."),
    ] = True,
    user_id: Annotated[str, typer.Option(help="User id in backend")] = "cli_chat",
):
    """💬 Start an interactive terminal chat with RoboVAI."""
    config = load_config()
    is_authenticated = bool(config.get("authenticated"))
    provider_mode = config.get("provider_mode", "auto")

    if not is_authenticated and provider_mode not in {"offline", "ollama"}:
        console.print(
            Panel.fit(
                "You are not connected yet.\n\n"
                "To use Nova cloud features, run quick setup and add your Nova API key.\n"
                "To use offline mode, choose Ollama in quick setup or run 'robovai provider-set --mode offline --chain ollama'.\n\n"
                "Fallback command: python -m robovai_cli --help",
                title="Connection Required",
                border_style="yellow",
            )
        )
        return

    console.print(
        Panel.fit(
            "Interactive chat started.\n"
            "Type your message and press Enter.\n"
            "Type 'exit' or 'quit' to leave.",
            title="RoboVAI Chat Shell",
            border_style="cyan",
        )
    )

    while True:
        message = typer.prompt("You").strip()
        if not message:
            continue
        if message.lower() in {"exit", "quit"}:
            typer.echo("Ending chat session.")
            return

        try:
            if is_authenticated and use_agent:
                payload = {
                    "message": message,
                    "user_id": user_id,
                    "platform": "cli",
                    "use_agent": True,
                    "bypass_router": False,
                    "ai_level": ai_level,
                }
                result = asyncio.run(api_request("POST", "/agent/run", payload))
                answer = result.get("response", "No response")
            else:
                payload = {
                    "message": message,
                    "user_id": user_id,
                    "platform": "cli",
                    "use_agent": False,
                    "bypass_router": False,
                    "ai_level": ai_level,
                }
                result = asyncio.run(api_request("POST", "/agent/run", payload))
                answer = result.get("response", "No response")

            console.print(Panel.fit(str(answer), title="RoboVAI", border_style="green"))
        except typer.Exit:
            console.print(
                Panel.fit(
                    "Request failed. Check connection and try again.",
                    title="Chat Error",
                    border_style="red",
                )
            )


@app.command()
def agent_run(
    name: Annotated[str, typer.Argument(help="Agent profile name")],
    message: Annotated[str, typer.Argument(help="Task/message for the agent")],
    ai_level: Annotated[
        str, typer.Option(help="fast | balanced | powerful")
    ] = "balanced",
    use_agent: Annotated[
        bool,
        typer.Option(
            help="Use backend agent routing. Set to false for direct LLM generation."
        ),
    ] = True,
    bypass_router: Annotated[
        bool,
        typer.Option(
            help="Skip SmartToolRouter when use_agent is false for deterministic direct LLM runs."
        ),
    ] = False,
    user_id: Annotated[str, typer.Option(help="User id in backend")] = "cli_user",
):
    """▶️ Run a local agent profile against Nova backend /agent/run endpoint."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    if bypass_router and use_agent:
        typer.secho(
            "❌ --bypass-router requires --use-agent false.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    agent = load_agent_config(name)
    prompt = (
        f"Agent Name: {agent.get('name')}\n"
        f"Agent Description: {agent.get('description', '')}\n"
        f"System Prompt: {agent.get('system_prompt', '')}\n\n"
        f"User Task: {message}"
    )

    payload = {
        "message": prompt,
        "user_id": user_id,
        "platform": "cli",
        "use_agent": use_agent,
        "bypass_router": bypass_router,
        "ai_level": ai_level,
    }
    result = asyncio.run(api_request("POST", "/agent/run", payload))
    response = result.get("response", "")
    typer.secho("\n✅ Agent Response:", fg=typer.colors.GREEN)
    typer.echo(response)


@app.command()
def multi_agent_run(
    agents: Annotated[
        str, typer.Argument(help="Comma-separated agent names (execution order)")
    ],
    message: Annotated[str, typer.Argument(help="Shared task for all agents")],
    ai_level: Annotated[
        str, typer.Option(help="fast | balanced | powerful")
    ] = "powerful",
    use_agent: Annotated[
        bool,
        typer.Option(
            help="Use backend agent routing for each step. Set to false for direct LLM chaining."
        ),
    ] = True,
    bypass_router: Annotated[
        bool,
        typer.Option(
            help="Skip SmartToolRouter when use_agent is false for deterministic direct LLM runs."
        ),
    ] = False,
    user_id: Annotated[
        str, typer.Option(help="User id in backend")
    ] = "cli_multi_agent",
):
    """🧠 Run multiple agents in sequence and aggregate outputs."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    agent_names = [a.strip() for a in agents.split(",") if a.strip()]
    if len(agent_names) < 2:
        typer.secho(
            "❌ Provide at least two agents for multi-agent run.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    if bypass_router and use_agent:
        typer.secho(
            "❌ --bypass-router requires --use-agent false.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    conversation_context = message
    outputs: Dict[str, str] = {}
    for agent_name in agent_names:
        agent = load_agent_config(agent_name)
        payload = {
            "message": (
                f"Agent Name: {agent.get('name')}\n"
                f"Role: {agent.get('description', '')}\n"
                f"System Prompt: {agent.get('system_prompt', '')}\n\n"
                f"Shared Task: {message}\n"
                f"Previous Agents Context:\n{conversation_context}"
            ),
            "user_id": user_id,
            "platform": "cli",
            "use_agent": use_agent,
            "bypass_router": bypass_router,
            "ai_level": ai_level,
        }
        result = asyncio.run(api_request("POST", "/agent/run", payload))
        answer = result.get("response", "")
        outputs[agent_name] = answer
        conversation_context += f"\n\n[{agent_name}]\n{answer}"
        typer.secho(f"✅ {agent_name} completed", fg=typer.colors.GREEN)

    console.print("\n[bold]Multi-agent aggregated output:[/bold]")
    for agent_name, answer in outputs.items():
        typer.echo(f"\n--- {agent_name} ---\n{answer}")


@app.command()
def oss_sync(
    target_dir: Annotated[
        str, typer.Option(help="Directory for OSS references")
    ] = "oss_references",
):
    """📦 Clone or update curated OSS references for acceleration and integration study."""
    root = Path(target_dir)
    root.mkdir(parents=True, exist_ok=True)

    typer.echo("Syncing OSS references (shallow clones)...")
    for name, repo_url in DEFAULT_OSS_REFERENCES.items():
        dest = root / name
        if dest.exists():
            typer.echo(f"↻ Updating {name}...")
            result = subprocess.run(
                ["git", "-C", str(dest), "pull", "--ff-only"],
                capture_output=True,
                text=True,
            )
        else:
            typer.echo(f"↓ Cloning {name}...")
            result = subprocess.run(
                ["git", "clone", "--depth", "1", repo_url, str(dest)],
                capture_output=True,
                text=True,
            )

        if result.returncode != 0:
            typer.secho(f"❌ Failed: {name}", fg=typer.colors.RED)
            if result.stderr:
                typer.echo(result.stderr.strip())
            continue
        typer.secho(f"✅ Ready: {name}", fg=typer.colors.GREEN)


@app.command()
def cli_structure():
    """🧱 Print RoboVAI CLI module structure (requested enterprise baseline)."""
    console.print("\n[bold]RoboVAI CLI Module Structure[/bold]")
    typer.echo("robovai-nova/")
    typer.echo("  robovai_cli.py")
    typer.echo("  robovai_cli_core/")
    typer.echo("    __init__.py")
    typer.echo("    models.py")
    typer.echo("    oss_registry.py")
    typer.echo("    persona_catalog.py")
    typer.echo("    workflow_adapter.py")
    typer.echo("  oss_references/")
    typer.echo("    deer-flow/")
    typer.echo("    gemini-cli/")
    typer.echo("    plandex/")
    typer.echo("    langchain/")
    typer.echo("    langflow/")
    typer.echo("    system-prompts-and-models-of-ai-tools/")
    typer.echo("\nUse `robovai oss-index` to verify actual integration status.")


@app.command()
def oss_index(
    target_dir: Annotated[
        str, typer.Option(help="Directory containing OSS references")
    ] = "oss_references",
):
    """📇 Build a local integration index from OSS references."""
    root = Path(target_dir)
    entries = build_oss_index(root, DEFAULT_OSS_REFERENCES)

    console.print("\n[bold]OSS Integration Index[/bold]")
    for entry in entries:
        state = "✅" if entry.present else "❌"
        revision = entry.revision or "n/a"
        typer.echo(f"{state} {entry.key:<22} rev={revision:<8} path={entry.local_path}")

    missing = [entry.key for entry in entries if not entry.present]
    if missing:
        typer.secho(
            f"\nMissing repositories: {', '.join(missing)}", fg=typer.colors.YELLOW
        )
        typer.echo("Run `robovai oss-sync` to fetch missing integrations.")


@app.command()
def persona_search(
    query: Annotated[str, typer.Argument(help="Persona keyword or role")],
    limit: Annotated[int, typer.Option(help="Max results")] = 10,
):
    """🔎 Search system-prompts OSS reference for reusable agent personas."""
    prompt_repo = OSS_ROOT / "system-prompts-and-models-of-ai-tools"
    if not prompt_repo.exists():
        typer.secho(
            "❌ system-prompts reference missing. Run `robovai oss-sync` first.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    candidates = search_personas(prompt_repo, query=query, limit=limit)
    if not candidates:
        typer.secho("No persona candidates found.", fg=typer.colors.YELLOW)
        return

    console.print("\n[bold]Persona Candidates[/bold]")
    for candidate in candidates:
        typer.echo(f"\n• Title: {candidate.title}")
        typer.echo(f"  File: {candidate.file_path}")
        typer.echo(f"  Snippet: {candidate.snippet}")


@app.command()
def agent_import_persona(
    name: Annotated[str, typer.Argument(help="New local agent name")],
    persona_file: Annotated[
        str,
        typer.Argument(help="Absolute or relative file path to persona prompt source"),
    ],
    model: Annotated[
        str, typer.Option(help="Model (claude, gpt-4, ollama/llama3, etc.)")
    ] = "claude",
    description: Annotated[
        str, typer.Option(help="Optional description override")
    ] = "",
    materialize: Annotated[
        bool,
        typer.Option(
            help="Copy persona file into robovai_assets/personas so it remains after pruning oss_references"
        ),
    ] = True,
):
    """🧠 Import an OSS persona file into local RoboVAI agent profile."""
    persona_path = Path(persona_file)
    if not persona_path.is_absolute():
        persona_path = Path.cwd() / persona_path

    try:
        prompt_text = _persona_prompt_from_file(persona_path)
    except ValueError as exc:
        typer.secho(f"❌ {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    effective_source = persona_path
    if materialize:
        try:
            effective_source = materialize_persona_file(
                source_file=persona_path,
                project_root=PROJECT_ROOT,
                target_name=name,
            )
            prompt_text = _persona_prompt_from_file(effective_source)
        except Exception as exc:
            typer.secho(f"❌ Failed to materialize persona: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

    agent_data = {
        "name": name,
        "model": model,
        "description": description or f"Imported persona from {persona_path.name}",
        "system_prompt": prompt_text,
        "source": {
            "type": "materialized-persona" if materialize else "oss-persona",
            "file": str(effective_source),
            "original_file": str(persona_path),
        },
        "created_at": datetime.now().isoformat(),
    }

    agent_file = AGENTS_DIR / f"{name}.json"
    with open(agent_file, "w", encoding="utf-8") as f:
        json.dump(agent_data, f, indent=2, ensure_ascii=False)

    typer.secho(f"✅ Agent '{name}' imported from persona.", fg=typer.colors.GREEN)
    typer.echo(f"   Source: {effective_source}")
    if materialize:
        typer.echo("   Mode: materialized (safe for oss_references deletion)")
    typer.echo(f"   Agent File: {agent_file}")


@app.command()
def oss_materialize(
    include: Annotated[
        str,
        typer.Option(
            help="Comma-separated OSS directories to materialize (default: all known references)"
        ),
    ] = "",
    source_dir: Annotated[
        str,
        typer.Option(help="Source OSS reference directory"),
    ] = "oss_references",
):
    """📦 Copy selected OSS artifacts into local robovai_assets for post-prune independence."""
    source_root = Path(source_dir)
    if not source_root.exists():
        typer.secho(
            "❌ Source oss_references directory not found.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    if include.strip():
        items = [item.strip() for item in include.split(",") if item.strip()]
    else:
        items = sorted(DEFAULT_OSS_REFERENCES.keys())

    copied = materialize_registry(
        project_root=PROJECT_ROOT,
        source_root=source_root,
        include=items,
    )

    console.print("\n[bold]Materialized OSS Assets[/bold]")
    if not copied:
        typer.secho(
            "No folders were copied. Check --include names.", fg=typer.colors.YELLOW
        )
        return

    for key, destination in copied.items():
        typer.echo(f"✅ {key} -> {destination}")


@app.command()
def oss_prune_check(
    source_dir: Annotated[
        str,
        typer.Option(help="OSS reference directory to evaluate for pruning"),
    ] = "oss_references",
):
    """🧪 Verify whether oss_references can be deleted safely."""
    result = check_oss_prune_readiness(
        project_root=PROJECT_ROOT,
        oss_root=Path(source_dir),
    )
    console.print("\n[bold]OSS Prune Readiness[/bold]")
    for key, value in result.items():
        typer.echo(f"  {key}: {value}")


@app.command()
def workflow_status(
    engine: Annotated[
        str,
        typer.Option(help="Workflow engine adapter name: deer-flow"),
    ] = "deer-flow",
):
    """🧩 Show local status of workflow adapters (starting with deer-flow)."""
    if engine != "deer-flow":
        typer.secho(
            "❌ Unsupported engine for now. Supported: deer-flow",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    adapter = DeerFlowAdapter(OSS_ROOT / "deer-flow")
    status = adapter.status()
    console.print("\n[bold]Workflow Adapter Status[/bold]")
    for key, value in status.items():
        typer.echo(f"  {key}: {value}")


@app.command()
def workflow_run(
    task: Annotated[
        str, typer.Argument(help="Business task to run via workflow engine")
    ],
    engine: Annotated[
        str,
        typer.Option(help="Workflow engine adapter name: deer-flow"),
    ] = "deer-flow",
):
    """⚡ Run a lightweight workflow integration proof (deer-flow adapter)."""
    if engine != "deer-flow":
        typer.secho(
            "❌ Unsupported engine for now. Supported: deer-flow",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    adapter = DeerFlowAdapter(OSS_ROOT / "deer-flow")
    result = adapter.run_example(task)

    console.print("\n[bold]Workflow Run Result[/bold]")
    for key, value in result.items():
        typer.echo(f"  {key}: {value}")


# ═══════════════════════════════════════════════════════════════════════════
# CONFIG COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def config_show():
    """⚙️ Show current configuration."""
    config = load_config()
    console.print("\n[bold]RoboVAI CLI Configuration:[/bold]")
    typer.echo(f"  API URL: {config.get('api_url')}")
    typer.echo(f"  Authenticated: {config.get('authenticated')}")
    typer.echo(f"  Config File: {CONFIG_FILE}")


@app.command()
def config_set(
    key: Annotated[str, typer.Argument(help="Config key (api_url, api_key)")],
    value: Annotated[str, typer.Argument(help="Config value")],
):
    """🔧 Set a configuration value."""
    config = load_config()
    config[key] = value
    save_config(config)
    typer.secho(f"✅ Config updated: {key} = {value}", fg=typer.colors.GREEN)


# ═══════════════════════════════════════════════════════════════════════════
# PLATFORM COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def readiness_matrix():
    """📊 Show Nova readiness across auth, providers, and channels."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/readiness-matrix"))
    print_structured_output("Nova Readiness Matrix", result)


@app.command()
def providers_status():
    """☁️ Show cloud and local provider readiness from the backend platform view."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/providers/status"))
    print_structured_output("Provider Status", result)


@app.command()
def byok_show():
    """🔐 Show masked BYOK and local provider credentials for the current user."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/auth/provider-credentials"))
    print_structured_output("User Provider Credentials", result)


@app.command()
def byok_set(
    provider_name: Annotated[str, typer.Argument(help="Provider key, such as openai or ollama")],
    api_key: Annotated[str, typer.Option(help="API key for the provider")] = "",
    model: Annotated[str, typer.Option(help="Default model for this provider")] = "",
    base_url: Annotated[str, typer.Option(help="Base URL for local or custom provider endpoints")] = "",
    extra_json: Annotated[
        str,
        typer.Option(help="Additional provider fields as inline JSON or a file path"),
    ] = "",
):
    """🗝️ Merge and save BYOK provider credentials for the authenticated user."""
    require_authentication()

    current = asyncio.run(api_request("GET", "/auth/provider-credentials"))
    providers = current.get("providers", {}) if isinstance(current, dict) else {}
    if not isinstance(providers, dict):
        providers = {}

    provider_payload = providers.get(provider_name, {})
    if not isinstance(provider_payload, dict):
        provider_payload = {}

    normalized_payload = {
        str(key): str(value)
        for key, value in provider_payload.items()
        if value is not None
    }

    if api_key:
        normalized_payload["api_key"] = api_key
    if model:
        normalized_payload["model"] = model
    if base_url:
        normalized_payload["base_url"] = base_url

    extra_payload = parse_json_input(extra_json, "--extra-json") if extra_json else {}
    for key, value in extra_payload.items():
        normalized_payload[str(key)] = "" if value is None else str(value)

    if not normalized_payload:
        typer.secho(
            "❌ Provide at least one credential field to save.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    providers[provider_name] = normalized_payload
    result = asyncio.run(
        api_request("POST", "/auth/provider-credentials", {"providers": providers})
    )
    print_structured_output(f"BYOK Saved: {provider_name}", result)


@app.command()
def skills_store(
    query: Annotated[str, typer.Option(help="Filter skills by id, source, or name")] = "",
    limit: Annotated[int, typer.Option(help="Maximum number of results to return")] = 50,
):
    """🧩 Browse discoverable skills from Nova's local skill store."""
    require_authentication()
    endpoint = "/platform/skills/store?" + urlencode({"query": query, "limit": limit})
    result = asyncio.run(api_request("GET", endpoint))
    print_structured_output("Skill Store", result)


@app.command()
def skills_registry():
    """📚 Show the installed skills registry tracked by Nova."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/skills/registry"))
    print_structured_output("Skills Registry", result)


@app.command()
def skills_install(
    skill_id: Annotated[str, typer.Argument(help="Skill registry item id")],
    name: Annotated[str, typer.Option(help="Display name for the registry item")] = "",
    source: Annotated[str, typer.Option(help="Source namespace, such as deer-flow or aionui")] = "",
    skill_type: Annotated[str, typer.Option("--type", help="Registry item type: skill or assistant")] = "skill",
):
    """📥 Register a skill from the skill store into Nova's installed registry."""
    require_authentication()
    payload = {
        "id": skill_id,
        "name": name or skill_id,
        "source": source,
        "type": skill_type,
    }
    result = asyncio.run(api_request("POST", "/platform/skills/registry/install", payload))
    print_structured_output("Skill Installed", result)


@app.command()
def skills_auto_install(
    skill_id: Annotated[str, typer.Argument(help="Skill id to materialize/install")],
    target_dir: Annotated[str, typer.Option(help="Optional target directory for installation")] = "",
):
    """⚙️ Trigger Nova's automatic skill materialization flow."""
    require_authentication()
    payload = {"skill_id": skill_id, "target_dir": target_dir or None}
    result = asyncio.run(api_request("POST", "/platform/skills/auto-install", payload))
    print_structured_output("Skill Auto Install", result)


@app.command()
def guardrails_policy_show():
    """🛡️ Display the current platform guardrails policy."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/guardrails/policy"))
    print_structured_output("Guardrails Policy", result)


@app.command()
def guardrails_policy_set(
    enabled: Annotated[bool, typer.Option(help="Enable or disable the guardrails layer")] = True,
    allowed_tools: Annotated[str, typer.Option(help="Comma-separated allowlist of tools")] = "",
    denied_tools: Annotated[str, typer.Option(help="Comma-separated denylist of tools")] = "",
    denied_patterns: Annotated[str, typer.Option(help="Comma-separated blocked payload patterns")] = "",
):
    """🧱 Update Nova's guardrails policy from the CLI."""
    require_authentication()
    payload = {
        "enabled": enabled,
        "allowed_tools": split_csv_values(allowed_tools),
        "denied_tools": split_csv_values(denied_tools),
        "denied_patterns": split_csv_values(denied_patterns),
    }
    result = asyncio.run(api_request("PUT", "/platform/guardrails/policy", payload))
    print_structured_output("Guardrails Policy Updated", result)


@app.command()
def guardrails_evaluate(
    tool_name: Annotated[str, typer.Argument(help="Tool name to evaluate")],
    payload: Annotated[str, typer.Option(help="Payload text to test against guardrails")] = "",
):
    """🔎 Evaluate a tool invocation against the active guardrails policy."""
    require_authentication()
    result = asyncio.run(
        api_request(
            "POST",
            "/platform/guardrails/evaluate",
            {"tool_name": tool_name, "payload": payload},
        )
    )
    print_structured_output("Guardrails Evaluation", result)


@app.command()
def models_profiles():
    """🧠 List configured model profiles used by Nova routing."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/models/profiles"))
    print_structured_output("Model Profiles", result)


@app.command()
def model_profile_upsert(
    profile_json: Annotated[
        str,
        typer.Argument(help="Profile JSON object or a path to a JSON file"),
    ],
):
    """📝 Insert or update a model routing profile."""
    require_authentication()
    payload = {"profile": parse_json_input(profile_json, "profile_json")}
    result = asyncio.run(api_request("POST", "/platform/models/profiles/upsert", payload))
    print_structured_output("Model Profile Upserted", result)


@app.command()
def models_route(
    task_description: Annotated[str, typer.Argument(help="Task description for model routing")],
    mode: Annotated[str, typer.Option(help="chat | do | spec | research | builder | quality | speed")] = "chat",
    priority: Annotated[str, typer.Option(help="quality | speed | economy")] = "quality",
    budget: Annotated[str, typer.Option(help="low | medium | high")] = "medium",
):
    """🧭 Ask Nova to recommend the best model profile for a task."""
    require_authentication()
    payload = {
        "task_description": task_description,
        "mode": mode,
        "priority": priority,
        "budget": budget,
    }
    result = asyncio.run(api_request("POST", "/platform/models/route", payload))
    print_structured_output("Model Routing", result)


@app.command()
def mcp_oauth_registry():
    """🔗 List MCP OAuth servers registered in Nova."""
    require_authentication()
    result = asyncio.run(api_request("GET", "/platform/mcp/oauth-registry"))
    print_structured_output("MCP OAuth Registry", result)


@app.command()
def mcp_oauth_upsert(
    name: Annotated[str, typer.Argument(help="Display name for the MCP OAuth server")],
    url: Annotated[str, typer.Option(help="Base server URL")] = "",
    token_url: Annotated[str, typer.Option(help="OAuth token URL")] = "",
    server_id: Annotated[str, typer.Option(help="Optional server id override")] = "",
    server_type: Annotated[str, typer.Option("--type", help="Server type, usually http")] = "http",
    grant_type: Annotated[str, typer.Option(help="OAuth grant type")] = "client_credentials",
    client_id_env: Annotated[str, typer.Option(help="Env var name for client id")] = "MCP_OAUTH_CLIENT_ID",
    client_secret_env: Annotated[str, typer.Option(help="Env var name for client secret")] = "MCP_OAUTH_CLIENT_SECRET",
    scope: Annotated[str, typer.Option(help="OAuth scope string")] = "",
    refresh_skew_seconds: Annotated[int, typer.Option(help="Refresh skew before token expiry")] = 60,
):
    """🧰 Create or update an MCP OAuth registry entry."""
    require_authentication()
    if not url or not token_url:
        typer.secho("❌ --url and --token-url are required.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    payload = {
        "id": server_id or None,
        "name": name,
        "type": server_type,
        "url": url,
        "token_url": token_url,
        "grant_type": grant_type,
        "client_id_env": client_id_env,
        "client_secret_env": client_secret_env,
        "scope": scope,
        "refresh_skew_seconds": refresh_skew_seconds,
    }
    result = asyncio.run(api_request("PUT", "/platform/mcp/oauth-registry", payload))
    print_structured_output("MCP OAuth Upserted", result)


@app.command()
def mcp_oauth_health(
    server_id: Annotated[str, typer.Argument(help="Registered MCP OAuth server id")],
    timeout_seconds: Annotated[int, typer.Option(help="Health-check timeout in seconds")] = 8,
):
    """🏥 Check health of an MCP OAuth registry entry."""
    require_authentication()
    payload = {"server_id": server_id, "timeout_seconds": timeout_seconds}
    result = asyncio.run(api_request("POST", "/platform/mcp/oauth-registry/health", payload))
    print_structured_output("MCP OAuth Health", result)


@app.command()
def memory_rank(
    user_id: Annotated[str, typer.Argument(help="User id for memory ranking")],
    query: Annotated[str, typer.Argument(help="Query used to rank memories")],
    limit: Annotated[int, typer.Option(help="Maximum ranked memories to return")] = 5,
):
    """🧠 Rank long-term memories relevant to a given query."""
    require_authentication()
    endpoint = "/platform/memory/rank?" + urlencode(
        {"user_id": user_id, "query": query, "limit": limit}
    )
    result = asyncio.run(api_request("GET", endpoint))
    print_structured_output("Memory Ranking", result)


@app.command()
def memory_facts(
    user_id: Annotated[str, typer.Argument(help="User id for persistent facts")],
):
    """📌 List stored user facts in Nova memory."""
    require_authentication()
    result = asyncio.run(api_request("GET", f"/platform/memory/facts/{user_id}"))
    print_structured_output("Memory Facts", result)


@app.command()
def memory_upsert(
    user_id: Annotated[str, typer.Argument(help="User id for the fact")],
    fact_key: Annotated[str, typer.Argument(help="Fact key")],
    fact_value: Annotated[str, typer.Argument(help="Fact value")],
    source: Annotated[str, typer.Option(help="Source label for the fact")] = "user",
):
    """💾 Upsert a persistent user fact into Nova memory."""
    require_authentication()
    payload = {
        "user_id": user_id,
        "fact_key": fact_key,
        "fact_value": fact_value,
        "source": source,
    }
    result = asyncio.run(api_request("POST", "/platform/memory/facts/upsert", payload))
    print_structured_output("Memory Fact Upserted", result)


@app.command()
def memory_delete(
    user_id: Annotated[str, typer.Argument(help="User id for the fact")],
    fact_key: Annotated[str, typer.Argument(help="Fact key to remove")],
):
    """🗑️ Delete a persistent user fact from Nova memory."""
    require_authentication()
    payload = {"user_id": user_id, "fact_key": fact_key}
    result = asyncio.run(api_request("POST", "/platform/memory/facts/delete", payload))
    print_structured_output("Memory Fact Deleted", result)


@app.command()
def memory_injection(
    user_id: Annotated[str, typer.Argument(help="User id for building the memory context")],
    query: Annotated[str, typer.Argument(help="Current user query")],
    session_messages: Annotated[
        str,
        typer.Option(help="Optional session messages as JSON or a JSON file path"),
    ] = "",
    limit: Annotated[int, typer.Option(help="Maximum ranked memory items to inject")] = 10,
):
    """🪄 Build Nova's layered memory injection block for a prompt."""
    require_authentication()
    parsed_messages = parse_json_input(session_messages, "--session-messages") if session_messages else {}
    if parsed_messages and not isinstance(parsed_messages.get("messages"), list):
        typer.secho(
            "❌ --session-messages file/object must contain a top-level 'messages' list.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    payload = {
        "user_id": user_id,
        "query": query,
        "session_messages": parsed_messages.get("messages", []),
        "limit": limit,
    }
    result = asyncio.run(api_request("POST", "/platform/memory/injection", payload))
    print_structured_output("Memory Injection", result)


@app.command()
def assistant_templates(
    category: Annotated[str, typer.Option(help="Optional category filter")] = "",
    domain: Annotated[str, typer.Option(help="Optional domain filter")] = "",
):
    """🧪 List assistant templates available in Nova."""
    require_authentication()
    endpoint = "/platform/assistants/templates?" + urlencode(
        {"category": category, "domain": domain}
    )
    result = asyncio.run(api_request("GET", endpoint))
    print_structured_output("Assistant Templates", result)


@app.command()
def assistant_template_get(
    template_id: Annotated[str, typer.Argument(help="Assistant template id")],
):
    """📄 Fetch a single assistant template by id."""
    require_authentication()
    result = asyncio.run(api_request("GET", f"/platform/assistants/templates/{template_id}"))
    print_structured_output("Assistant Template", result)


@app.command()
def assistant_template_upsert(
    template_json: Annotated[
        str,
        typer.Argument(help="Template JSON object or a path to a JSON file"),
    ],
):
    """🧱 Insert or update a Nova assistant template."""
    require_authentication()
    payload = {"template": parse_json_input(template_json, "template_json")}
    result = asyncio.run(api_request("POST", "/platform/assistants/templates/upsert", payload))
    print_structured_output("Assistant Template Upserted", result)


@app.command()
def assistant_instantiate(
    template_id: Annotated[str, typer.Argument(help="Assistant template id")],
    user_id: Annotated[str, typer.Argument(help="User id receiving the assistant")],
    overrides_json: Annotated[
        str,
        typer.Option(help="Optional overrides JSON object or a JSON file path"),
    ] = "",
):
    """🚀 Instantiate an assistant from a Nova template."""
    require_authentication()
    overrides = parse_json_input(overrides_json, "--overrides-json") if overrides_json else {}
    payload = {
        "template_id": template_id,
        "user_id": user_id,
        "overrides": overrides,
    }
    result = asyncio.run(api_request("POST", "/platform/assistants/instantiate", payload))
    print_structured_output("Assistant Instantiated", result)


# ═══════════════════════════════════════════════════════════════════════════
# MULTI-AGENT COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def multi_agent_list():
    """📋 List all available agents on backend."""

    async def _list():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/agents", headers=headers
                )
                response.raise_for_status()

                data = response.json()
                agents = data.get("agents", [])

                if not agents:
                    console.print("[yellow]ℹ️  No agents registered.[/yellow]")
                    return

                console.print("\n[bold cyan]Available Agents:[/bold cyan]")
                for agent in agents:
                    console.print(
                        f"  • [bright_cyan]{agent['name']}[/bright_cyan] (ID: {agent['id']})"
                    )
                    typer.echo(f"    Role: {agent.get('role', 'custom')}")
                    typer.echo(f"    Model: {agent.get('model', 'unknown')}")
                    typer.echo(
                        f"    Tools: {len(agent.get('available_tools', []))} available"
                    )
                    typer.echo()
        except Exception as e:
            typer.secho(f"❌ Failed to list agents: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_list())


@app.command()
def multi_agent_execute(
    workflow_id: Annotated[str, typer.Argument(help="Workflow ID to execute")],
    input_data: Annotated[
        str,
        typer.Option(help="JSON input data for workflow (or file path)"),
    ] = "{}",
):
    """⚡ Execute a multi-agent workflow."""

    async def _execute():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Parse input data
        try:
            if input_data.startswith("{"):
                payload = json.loads(input_data)
            else:
                # Try to load from file
                with open(input_data, "r", encoding="utf-8-sig") as f:
                    payload = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            typer.secho(f"❌ Invalid input data: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                response = await client.post(
                    f"{api_url}/multi-agent/workflows/{workflow_id}/execute",
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()

                result = response.json()
                execution_id = result.get("execution_id")

                typer.secho("\n✅ Workflow execution started!", fg=typer.colors.GREEN)
                console.print(f"  Execution ID: [cyan]{execution_id}[/cyan]")
                console.print(f"  Status: [yellow]{result.get('status')}[/yellow]")
                console.print("\n[bold]Check status with:[/bold]")
                typer.echo(f"  robovai multi-agent-status {execution_id}")
        except Exception as e:
            typer.secho(f"❌ Failed to execute workflow: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_execute())


@app.command()
def multi_agent_status(
    execution_id: Annotated[str, typer.Argument(help="Execution ID to check status")],
):
    """📊 Check multi-agent workflow execution status."""

    async def _status():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/executions/{execution_id}",
                    headers=headers,
                )
                response.raise_for_status()

                execution = response.json()
                status = execution.get("status", "unknown")

                # Color-code status
                status_color = {
                    "completed": typer.colors.GREEN,
                    "failed": typer.colors.RED,
                    "running": typer.colors.YELLOW,
                    "queued": typer.colors.BLUE,
                }.get(status, typer.colors.WHITE)

                console.print("\n[bold]Execution Status:[/bold]")
                console.print(f"  ID: [cyan]{execution_id}[/cyan]")
                console.print(
                    f"  Status: [bold]{typer.style(status, fg=status_color)}[/bold]"
                )
                typer.echo(f"  Workflow: {execution.get('workflow_id')}")
                typer.echo(f"  Submitted: {execution.get('submitted_at')}")

                # Show result if completed
                if execution.get("result"):
                    console.print("\n[bold]Result:[/bold]")
                    result = execution["result"]
                    typer.echo(f"  Overall Status: {result.get('status')}")
                    typer.echo(f"  Total Duration: {result.get('total_duration')}s")
                    typer.echo(f"  Total Tokens: {result.get('total_tokens')}")

                    # Show agent results
                    agent_results = result.get("agent_results", {})
                    if agent_results:
                        console.print("\n  [bold cyan]Agent Results:[/bold cyan]")
                        for agent_id, agent_result in agent_results.items():
                            typer.echo(f"    • {agent_id}")
                            if isinstance(agent_result, dict):
                                for key, value in agent_result.items():
                                    typer.echo(f"      {key}: {value}")

                # Show error if failed
                if execution.get("error"):
                    typer.secho(
                        f"\n  ❌ Error: {execution['error']}", fg=typer.colors.RED
                    )
        except Exception as e:
            typer.secho(f"❌ Failed to get execution status: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_status())


@app.command()
def multi_agent_workflows():
    """📚 List all defined workflows."""

    async def _workflows():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/workflows", headers=headers
                )
                response.raise_for_status()

                data = response.json()
                workflows = data.get("workflows", [])

                if not workflows:
                    console.print("[yellow]ℹ️  No workflows defined.[/yellow]")
                    return

                console.print("\n[bold cyan]Defined Workflows:[/bold cyan]")
                for workflow in workflows:
                    console.print(
                        f"  • [bright_cyan]{workflow['name']}[/bright_cyan] (ID: {workflow['id']})"
                    )
                    typer.echo(f"    Description: {workflow.get('description', 'N/A')}")
                    typer.echo(f"    Agents: {workflow.get('agents', 0)}")
                    typer.echo(
                        f"    Strategy: {workflow.get('execution_strategy', 'unknown')}"
                    )
                    typer.echo()
        except Exception as e:
            typer.secho(f"❌ Failed to list workflows: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_workflows())


@app.command()
def multi_agent_health():
    """🏥 Check multi-agent system health."""

    async def _health():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/health", headers=headers
                )
                response.raise_for_status()

                health = response.json()
                status = health.get("status", "unknown")

                status_color = (
                    typer.colors.GREEN if status == "healthy" else typer.colors.RED
                )

                console.print("\n[bold]Multi-Agent System Health:[/bold]")
                console.print(
                    f"  Status: [bold]{typer.style(status, fg=status_color)}[/bold]"
                )
                typer.echo(
                    f"  Registered Agents: {health.get('agents_registered', '?')}"
                )
                typer.echo(
                    f"  Defined Workflows: {health.get('workflows_defined', '?')}"
                )
                typer.echo(
                    f"  Active Executions: {health.get('active_executions', '?')}"
                )
                typer.echo(f"  Total Executions: {health.get('total_executions', '?')}")

                if health.get("error"):
                    typer.secho(f"\n  Error: {health['error']}", fg=typer.colors.RED)
        except Exception as e:
            typer.secho(f"❌ Failed to check health: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_health())


@app.command()
def update_check():
    """🚀 Check for RobovAI Nova updates and latest announcements."""
    console.print(
        Panel.fit(
            "[bold gold1]RoboVAI Nova CLI Update Checker[/bold gold1]\n"
            "Checking upstream for new updates...",
            title="Update",
            border_style="cyan",
        )
    )

    try:
        import requests

        api_url = "https://nova.robovai.tech/api/announcements/active"
        latest_version = CLI_VERSION
        try:
            resp = requests.get(api_url, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success") and data.get("announcement"):
                    ann = data["announcement"]
                    console.print(
                        f"\n[bold green]📣 Latest Announcement:[/bold green] {ann['title']}"
                    )
                    console.print(f"[white]{ann['content']}[/white]\n")
        except Exception:
            pass  # Fail gracefully if server is down

        try:
            pypi_response = requests.get(
                f"https://pypi.org/pypi/{PYPI_PACKAGE_NAME}/json",
                timeout=5,
            )
            if pypi_response.status_code == 200:
                latest_version = pypi_response.json().get("info", {}).get(
                    "version", CLI_VERSION
                )
        except Exception:
            latest_version = CLI_VERSION

        current_tuple = parse_version(CLI_VERSION)
        latest_tuple = parse_version(latest_version)
        if latest_tuple > current_tuple:
            status_text = "Update available on PyPI."
            status_style = "bold yellow"
        elif latest_tuple == current_tuple:
            status_text = "You are up to date."
            status_style = "bold green"
        else:
            status_text = "Local build is newer than the latest published PyPI release."
            status_style = "bold cyan"

        console.print(
            f"\n[bold]Current Version:[/bold] v{CLI_VERSION}\n"
            f"[bold green]Latest Release:[/bold green] v{latest_version}\n"
            f"[{status_style}]Status:[/{status_style}] {status_text}\n"
            "\n[link=https://robovai.tech/cli]🔗 CLI Landing Page[/link]"
            "\n[link=https://robovai.tech/changelog]🔗 View Full Changelog[/link]"
        )
    except Exception as e:
        console.print(f"[red]Failed to check for updates: {str(e)}[/red]")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app()
