# RobovAI Nova

RobovAI Nova is a multi-surface AI platform that includes:

- A FastAPI backend for chat, orchestration, auth, and provider routing.
- A polished `robovai-cli` package for account-first terminal operations.
- Cloud deployment assets for container-based environments such as Cloud Run.

## Release Surfaces

- PyPI package: `robovai-cli`
- Backend runtime: `backend.main:app`

## Key Docs

- CLI package overview: `docs/project/README_PyPI.md`
- Deployment notes: `docs/project/DEPLOYMENT.md`
- CLI guide: `docs/project/ROBOVAI_CLI_GUIDE.md`

## Current Release

- Nova CLI version: `2.1.3`
