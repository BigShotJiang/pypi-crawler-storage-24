# langchain-arqondb

LangChain integration for [ArqonDB](https://github.com/AlbericByte/ArqonDB) — VectorStore, ChatHistory, and GraphStore backed by a single self-hosted engine.

## Install

```bash
pip install langchain-arqondb
```

For GraphStore support:
```bash
pip install langchain-arqondb[graph]
```

## Prerequisites

ArqonDB must be running locally:

```bash
curl -sL https://github.com/AlbericByte/ArqonDB/releases/download/v0.1.1/install.sh | bash
```

## Usage

### VectorStore

```python
from langchain_arqondb import ArqonDBVectorStore
from langchain_openai import OpenAIEmbeddings

vectorstore = ArqonDBVectorStore(
    embedding=OpenAIEmbeddings(),
    addr="localhost:9379",
    index_name="my_docs",
)

# Add documents
vectorstore.add_texts(
    ["The cat sat on the mat", "The dog ran in the park"],
    metadatas=[{"source": "a"}, {"source": "b"}],
)

# Search
docs = vectorstore.similarity_search("cat", k=2)

# Use as retriever in a RAG chain
retriever = vectorstore.as_retriever()
```

### Chat Message History

```python
from langchain_arqondb import ArqonDBChatMessageHistory

history = ArqonDBChatMessageHistory(session_id="user-123")

history.add_user_message("hello")
history.add_ai_message("hi there")

print(history.messages)  # [HumanMessage(...), AIMessage(...)]

history.clear()
```

### Graph Store

```python
from langchain_arqondb import ArqonDBGraphStore
from langchain_community.graphs.graph_document import GraphDocument, Node, Relationship
from langchain_core.documents import Document

graph = ArqonDBGraphStore(addr="localhost:9379", graph_name="knowledge")

alice = Node(id="alice", type="Person", properties={"name": "Alice"})
bob = Node(id="bob", type="Person", properties={"name": "Bob"})
rel = Relationship(source=alice, target=bob, type="KNOWS")

graph.add_graph_documents([
    GraphDocument(nodes=[alice, bob], relationships=[rel], source=Document(page_content=""))
])

results = graph.query("*")
schema = graph.get_structured_schema
```

## Why ArqonDB?

ArqonDB is the only single backend that covers all three LangChain storage needs:

| Need | Pinecone | Neo4j | Redis | ArqonDB |
|------|----------|-------|-------|---------|
| VectorStore | Yes | No | Yes | Yes |
| GraphStore | No | Yes | No | Yes |
| ChatHistory | No | No | Yes | Yes |
| Self-hosted | No | Partial | Yes | Yes |
| Single engine | - | - | - | Yes |

Zero extra API keys. Apache-2.0. Self-hosted.
