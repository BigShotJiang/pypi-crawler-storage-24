"""LangChain integration for ArqonDB.

Provides VectorStore, ChatMessageHistory, and GraphStore backed by a single
self-hosted ArqonDB engine (KV + Vector + Graph).

Usage::

    from langchain_arqondb import ArqonDBVectorStore

    vs = ArqonDBVectorStore(embedding=my_embeddings, addr="localhost:9379")
    vs.add_texts(["hello world"])
    docs = vs.similarity_search("hello", k=3)
"""

from langchain_arqondb.vectorstore import ArqonDBVectorStore
from langchain_arqondb.chat_history import ArqonDBChatMessageHistory

__all__ = [
    "ArqonDBVectorStore",
    "ArqonDBChatMessageHistory",
]

try:
    from langchain_arqondb.graph import ArqonDBGraphStore  # noqa: F401

    __all__.append("ArqonDBGraphStore")
except ImportError:
    pass  # langchain-community not installed

try:
    from langchain_arqondb.memory import ArqonDBMemory  # noqa: F401

    __all__.append("ArqonDBMemory")
except ImportError:
    pass
