import time
import random

class Pipeline:

    def __init__(self, source):
        self.source = source
        self._batch_size = None
        self._delay_range = None
        self._batch_pause = None

    def batch (self, size):
        self._batch_size = size
        return self

    def throttle (self, delay=None, pause=None):
        self._delay_range = delay
        self._batch_pause = pause
        return self
    
    def run(self, func):
        results = []  

        data = self.source
        batch_size = self._batch_size or len(data)

        for i in range(0, len(data), batch_size):
            batch = data[i:i+batch_size]

            total_batches = (len(data) + batch_size - 1) // batch_size
            print(f"Processing batch {i//batch_size + 1}/{total_batches}")

            for idx, item in enumerate(batch):

                '''
                I defined this global index for effective error handling. 
                It basically represents the index of a specific data item globally, not in the batch itself.
                For example, an item might be at index 23 in the overall dataset, but if divided in batches of 10, its at 3.
                So if, god forbid, an error occurs while processing it, it prints, "You got a problem at 23 buddy, Im skipping that one"
                '''
                global_idx = i+idx+1
                try:
                    result = func(*item) if isinstance(item, tuple) else func(item)
                    results.append(result)
                except Exception as e:
                    print(f"Error occurred on item {global_idx}: {e}. Skipping item..")
                
                '''
                Even if the function crashes or some error occurs, the delay should happen, because
                we're still communicating with that API, the number of requests sent remains the same.
                '''
                if self._delay_range:
                    delay = random.uniform(*self._delay_range)
                    time.sleep(delay)
            
            if self._batch_pause and i + batch_size < len(data):
                pause = random.uniform(*self._batch_pause)
                print(f"Batch done. Sleeping for {pause:.2f}s")
                time.sleep(pause)
        
        return results