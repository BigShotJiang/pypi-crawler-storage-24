from andor.pipeline import Pipeline
from unittest.mock import patch


def test_runs_all_items():
    data = [1, 2, 3]

    def square(x):
        return x * x
    
    pipeline = Pipeline(source=data)
    result = pipeline.run(square)
    assert result == [1, 4, 9]


def test_tuple_unpacking():
    data = [(2, 3), (4, 5)]

    def add(a, b):
        return a + b

    pipeline = Pipeline(source=data)
    result = pipeline.run(add)
    assert result == [5, 9]


def test_delay_called():
    data = [1, 2]

    def identity(x):
        return x

    pipeline = Pipeline(source=data).throttle(delay=(1, 1))
    with patch("time.sleep") as mock_sleep:
        pipeline.run(identity)
    assert mock_sleep.called


def test_batch_pause():
    data = [1, 2, 3, 4]

    def identity(x):
        return x

    pipeline = Pipeline(source=data)\
        .batch(size=2)\
        .throttle(pause=(1, 1))

    with patch("time.sleep") as mock_sleep:
        pipeline.run(identity)
    assert mock_sleep.call_count == 1