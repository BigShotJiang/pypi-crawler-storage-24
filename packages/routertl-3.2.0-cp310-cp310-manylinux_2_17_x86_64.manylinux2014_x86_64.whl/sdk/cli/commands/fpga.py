# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""CLI command group: fpga — FPGA toolchain queries and device discovery."""

import re
import subprocess
import sys
from pathlib import Path

import rich_click as click

from sdk.cli.console import console
from sdk.cli.resilience import cli_resilient


@cli_resilient("CLI name resolution", default="routertl")
def _cli_name():
    from sdk.cli.main import CLI_NAME

    return CLI_NAME


# ── Vendor-specific device query ──────────────────────────────


@cli_resilient("project config loading", default=("xilinx", ""))
def _load_project_config():
    """Load project.yml from cwd and return (vendor, part) tuple."""
    import yaml

    yml_path = Path("project.yml")
    if not yml_path.exists():
        return None, None
    with open(yml_path) as f:
        config = yaml.safe_load(f) or {}
    hw = config.get("hardware", {})
    return hw.get("vendor", "xilinx"), hw.get("part", "")


def _query_vendor_devices(vendor):
    """Invoke vendor TCL to discover licensed families and parts.

    Returns:
        tuple: (families: list[str], parts: dict[str, list[str]], error: str|None)
            families: sorted list of family names
            parts: mapping from family name to list of part numbers
            error: error message string, or None on success
    """
    sdk_root = Path(__file__).resolve().parent.parent.parent.parent
    tcl_script = sdk_root / "tcl" / vendor / "query_devices.tcl"

    if not tcl_script.exists():
        return [], {}, f"Device query not supported for vendor '{vendor}' (no TCL script)"

    VENDOR_CMDS = {
        "altera": ["quartus_sh", "-t", str(tcl_script)],
        "xilinx": [
            "vivado",
            "-mode",
            "batch",
            "-nolog",
            "-nojournal",
            "-notrace",
            "-source",
            str(tcl_script),
        ],
    }

    cmd = VENDOR_CMDS.get(vendor)
    if not cmd:
        return [], {}, f"No query command defined for vendor '{vendor}'"

    # Check binary exists (respecting hardware.tool_path)
    from sdk.api.tools import resolve_tool_binary

    resolved_bin = resolve_tool_binary(cmd[0])
    if not resolved_bin:
        hints = {
            "altera": "Add Quartus to PATH: export PATH=/opt/altera/quartus/bin:$PATH",
            "xilinx": "Source Vivado settings: source /tools/Xilinx/Vivado/<ver>/settings64.sh",
        }
        hint = hints.get(vendor, f"Ensure {cmd[0]} is on PATH")
        return [], {}, f"Vendor tool '{cmd[0]}' not found on PATH.\n   Fix: {hint}"

    # Use resolved binary path
    resolved_cmd = [resolved_bin] + cmd[1:]

    import traceback as _tb

    try:
        result = subprocess.run(resolved_cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return [], {}, f"Vendor tool '{cmd[0]}' timed out (120s). Is the license server reachable?"
    except OSError as e:
        import logging

        logging.debug("Vendor tool invocation failed:\n%s", _tb.format_exc())
        return [], {}, f"Failed to invoke '{cmd[0]}': {e}"

    if result.returncode != 0:
        stderr_snippet = (result.stderr or "").strip()[:200]
        return [], {}, f"Vendor tool exited with code {result.returncode}.\n   {stderr_snippet}"

    # Parse output
    families = []
    parts = {}
    for line in result.stdout.splitlines():
        if line.startswith("FAMILY:"):
            fam = line[7:].strip()
            if fam and fam not in families:
                families.append(fam)
        elif line.startswith("PART:"):
            tokens = line.split(":", 2)
            if len(tokens) == 3:
                _, fam, part = tokens
                fam = fam.strip()
                part = part.strip()
                if fam not in parts:
                    parts[fam] = []
                parts[fam].append(part)

    return sorted(families), parts, None


def _validate_regex(pattern):
    """Validate a regex pattern. Returns compiled regex or None + error message."""
    try:
        return re.compile(pattern, re.IGNORECASE), None
    except re.error as e:
        return None, f"Invalid regex pattern '{pattern}': {e}"


# ── Click commands ────────────────────────────────────────────


@click.group(name="fpga")
def fpga_group():
    """FPGA toolchain queries — device families, parts, and licenses."""
    pass


@fpga_group.command(name="devices")
@click.option("--family", default=None, help="List parts within a specific FPGA family.")
@click.option("--regexp", "part_regex", default=None, help="Search parts by regex pattern.")
def devices(family, part_regex):
    """Show licensed FPGA device families and parts from the vendor tool.

    \\b
    Examples:
        routertl fpga devices                          # List licensed families
        routertl fpga devices --family "Zynq"          # Parts in Zynq family
        routertl fpga devices --regexp "xc7z020"       # Regex search across all parts
    """
    vendor, current_part = _load_project_config()
    if not vendor:
        console.print("❌ [red]No project.yml found. Cannot determine vendor.[/]")
        sys.exit(1)

    # Validate regex early (before slow vendor query)
    compiled_regex = None
    if part_regex:
        compiled_regex, err = _validate_regex(part_regex)
        if err:
            console.print(f"❌ [red]{err}[/]")
            sys.exit(1)

    console.print(f"\n🔍 [blue]Querying licensed FPGA devices (vendor: {vendor})...[/]")

    families, parts, error = _query_vendor_devices(vendor)
    if error:
        console.print(f"\n❌ [red]{error}[/]")
        sys.exit(1)

    if not families:
        console.print("\n⚠️  [yellow]No device families found.[/]")
        return

    # Determine which family the current part belongs to
    current_family = None
    if current_part:
        for fam, fam_parts in parts.items():
            if current_part in fam_parts:
                current_family = fam
                break

    # ── Mode 1: Regex search across all parts ──
    if compiled_regex:
        matches = []
        for fam, fam_parts in sorted(parts.items()):
            for p in fam_parts:
                if compiled_regex.search(p):
                    matches.append((fam, p))

        if not matches:
            console.print(f"\n⚠️  [yellow]No parts match pattern '{part_regex}'.[/]")
            return

        console.print(f"\n📋 [cyan]Matching Parts[/] (pattern: {part_regex}):\n")
        for fam, p in matches:
            marker = "  [green]← project target[/]" if p == current_part else ""
            console.print(f"  • [cyan]{p}[/]  [dim]({fam})[/]{marker}")
        console.print(f"\n  [dim]{len(matches)} part(s) matched.[/]")
        return

    # ── Mode 2: List parts in a specific family ──
    if family:
        # Case-insensitive family match
        matched_fam = None
        for fam in families:
            if fam.lower() == family.lower():
                matched_fam = fam
                break
        if not matched_fam:
            # Try partial match
            for fam in families:
                if family.lower() in fam.lower():
                    matched_fam = fam
                    break

        if not matched_fam:
            console.print(f"\n❌ [red]Family '{family}' not found.[/]")
            console.print(f"   [dim]Available: {', '.join(families)}[/]")
            return

        fam_parts = parts.get(matched_fam, [])
        console.print(f"\n📋 [cyan]Parts in {matched_fam}[/] ({len(fam_parts)} devices):\n")
        for p in sorted(fam_parts):
            marker = "  [green]← project target[/]" if p == current_part else ""
            click.echo(f"  • {p}{marker}")
        return

    # ── Mode 3: Default — list families ──
    console.print(f"\n📋 [cyan]Licensed Device Families[/] ({len(families)}):\n")
    for fam in families:
        marker = ""
        if fam == current_family:
            marker = f"  [green]← project target ({current_part})[/]"
        console.print(f"  • [cyan]{fam}[/]{marker}")

    total_parts = sum(len(v) for v in parts.values())
    console.print(f"\n  [dim]{total_parts} total parts across {len(families)} families.[/]")
    cli_name = _cli_name()
    console.print("  [dim]Use --family \"<name>\" to list parts in a family.[/]")
    console.print("  [dim]Use --regexp \"<pattern>\" to search parts by regex.[/]")

    if current_part:
        fam_label = f" ({current_family})" if current_family else ""
        console.print(f"\n  📌 Project target: [cyan]{current_part}[/]{fam_label}")
    click.echo()
