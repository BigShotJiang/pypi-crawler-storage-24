use std::collections::HashMap;

use pyo3::prelude::*;

use ::catform::ast::*;

// ── Config loading (pianola's interpretation of param.X) ─────────────────────

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum ConfigValue {
    Int(i64),
    Float(f64),
    Vec(Vec<f64>),
}

fn load_config(path: &str) -> HashMap<String, ConfigValue> {
    let content =
        std::fs::read_to_string(path).unwrap_or_else(|e| panic!("failed to read {path}: {e}"));
    let table: toml::Table = content
        .parse()
        .unwrap_or_else(|e| panic!("failed to parse {path}: {e}"));

    let mut config = HashMap::new();
    for section in ["shape", "scalar", "vector"] {
        if let Some(toml::Value::Table(t)) = table.get(section) {
            for (k, v) in t {
                let cv = match v {
                    toml::Value::Integer(n) => ConfigValue::Int(*n),
                    toml::Value::Float(f) => ConfigValue::Float(*f),
                    toml::Value::Array(arr) => {
                        let vals: Vec<f64> = arr
                            .iter()
                            .map(|v| match v {
                                toml::Value::Float(f) => *f,
                                toml::Value::Integer(n) => *n as f64,
                                _ => panic!("unexpected value in vector section"),
                            })
                            .collect();
                        ConfigValue::Vec(vals)
                    }
                    _ => continue,
                };
                config.insert(k.clone(), cv);
            }
        }
    }
    config
}

// ── Weight mapping (hierarchical [weights] → flat dict-path → safetensors key)

fn load_weight_mapping(path: &str) -> HashMap<String, String> {
    let content =
        std::fs::read_to_string(path).unwrap_or_else(|e| panic!("failed to read {path}: {e}"));
    let table: toml::Table = content
        .parse()
        .unwrap_or_else(|e| panic!("failed to parse {path}: {e}"));

    let mut mapping = HashMap::new();
    if let Some(toml::Value::Table(weights)) = table.get("weights") {
        flatten_weight_table(weights, "weights", &mut mapping);
    }
    mapping
}

fn flatten_weight_table(table: &toml::Table, prefix: &str, out: &mut HashMap<String, String>) {
    for (key, value) in table {
        let full_key = format!("{prefix}.{key}");
        match value {
            toml::Value::String(s) => {
                out.insert(full_key, s.clone());
            }
            toml::Value::Table(sub) => {
                flatten_weight_table(sub, &full_key, out);
            }
            _ => {}
        }
    }
}

/// Resolve a dict path like "weights.transformer.layer.3.attn.q" to a safetensors key.
///
/// Algorithm: split path into segments, separate numeric segments (iteration indices)
/// from key segments, look up the key, substitute {} with numerics.
fn resolve_dict_path(path: &str, mapping: &HashMap<String, String>) -> Option<String> {
    // Direct lookup first (non-layer weights like weights.embedding)
    if let Some(key) = mapping.get(path) {
        return Some(key.clone());
    }

    // Split path, separate numeric segments
    let segments: Vec<&str> = path.split('.').collect();
    let mut key_parts = Vec::new();
    let mut numerics = Vec::new();

    for seg in &segments {
        if seg.chars().all(|c| c.is_ascii_digit()) {
            numerics.push(*seg);
        } else {
            key_parts.push(*seg);
        }
    }

    let key = key_parts.join(".");
    if let Some(pattern) = mapping.get(&key) {
        // Substitute {} with numeric segments in order
        let mut result = pattern.clone();
        for num in &numerics {
            result = result.replacen("{}", num, 1);
        }
        Some(result)
    } else {
        None
    }
}

/// After flattening, resolve all dict-path args to safetensors keys.
fn resolve_weight_paths(m: &mut Module, mapping: &HashMap<String, String>) {
    for f in m.functions.values_mut() {
        for op in &mut f.ops {
            for arg in &mut op.args {
                if let Atom::Name(n) = arg {
                    if n.starts_with("weights.") {
                        if let Some(resolved) = resolve_dict_path(n, mapping) {
                            *arg = Atom::Name(resolved);
                        }
                    }
                }
            }
        }
    }
}

// ── Param substitution (pianola convention: param.X → config lookup) ─────────

fn sub_dim(d: &Dim, config: &HashMap<String, ConfigValue>) -> Dim {
    match d {
        Dim::Named(name) if name.starts_with("param.") => {
            let key = &name[6..];
            match config.get(key) {
                Some(ConfigValue::Int(n)) => Dim::Concrete(*n),
                Some(ConfigValue::Float(f)) => Dim::Concrete(*f as i64),
                _ => d.clone(),
            }
        }
        _ => d.clone(),
    }
}

fn sub_type(t: &TensorType, config: &HashMap<String, ConfigValue>) -> TensorType {
    if t.dtype == "*" {
        return t.clone(); // dict types have no shape to substitute
    }
    TensorType {
        dtype: t.dtype.clone(),
        shape: t.shape.iter().map(|d| sub_dim(d, config)).collect(),
    }
}

fn sub_op(op: &Op, config: &HashMap<String, ConfigValue>) -> Op {
    let kind = match &op.kind {
        OpKind::View { pattern, axes } => OpKind::View {
            pattern: pattern.clone(),
            axes: axes.clone(),
        },
        OpKind::Map { function } => OpKind::Map {
            function: function.clone(),
        },
        OpKind::Fold { pattern, function } => OpKind::Fold {
            pattern: pattern.clone(),
            function: function.clone(),
        },
        OpKind::Tile { pattern, axes } => OpKind::Tile {
            pattern: pattern.clone(),
            axes: axes.clone(),
        },
        OpKind::Gather { pattern } => OpKind::Gather {
            pattern: pattern.clone(),
        },
        OpKind::Scatter { pattern } => OpKind::Scatter {
            pattern: pattern.clone(),
        },
        OpKind::Contract { pattern } => OpKind::Contract {
            pattern: pattern.clone(),
        },
        OpKind::Literal { value } => OpKind::Literal {
            value: value.clone(),
        },
        OpKind::Random { function } => OpKind::Random {
            function: function.clone(),
        },
        OpKind::Call { target } => OpKind::Call {
            target: target.clone(),
        },
        OpKind::Loop { target, count } => {
            let resolved = match count {
                LoopCount::Concrete(n) => LoopCount::Concrete(*n),
                LoopCount::Named(name) => {
                    let key = name.strip_prefix("param.").unwrap_or(name);
                    match config.get(key) {
                        Some(ConfigValue::Int(n)) => LoopCount::Concrete(*n as usize),
                        _ => count.clone(),
                    }
                }
            };
            OpKind::Loop {
                target: target.clone(),
                count: resolved,
            }
        }
    };

    Op {
        kind,
        outputs: op.outputs.clone(),
        output_types: op
            .output_types
            .iter()
            .map(|t| t.as_ref().map(|t| sub_type(t, config)))
            .collect(),
        args: op.args.clone(),
        comments: op.comments.clone(),
    }
}

fn substitute_params(m: &Module, config: &HashMap<String, ConfigValue>) -> Module {
    let functions = m
        .functions
        .iter()
        .map(|(name, f)| {
            let params = f
                .params
                .iter()
                .map(|p| Param {
                    name: p.name.clone(),
                    ty: sub_type(&p.ty, config),
                })
                .collect();
            let returns = f
                .returns
                .iter()
                .map(|r| Param {
                    name: r.name.clone(),
                    ty: sub_type(&r.ty, config),
                })
                .collect();
            let ops = f.ops.iter().map(|op| sub_op(op, config)).collect();
            (
                name.clone(),
                Function {
                    name: f.name.clone(),
                    comments: f.comments.clone(),
                    params,
                    returns,
                    ops,
                },
            )
        })
        .collect();

    Module {
        header_comments: m.header_comments.clone(),
        functions,
    }
}

// -- JSON-based API -----------------------------------------------------------

#[pyfunction]
#[pyo3(name = "load_flat_json", signature = (cat_path, config_path, entry = "main"))]
fn py_load_flat_json(cat_path: &str, config_path: &str, entry: &str) -> String {
    let module = ::catform::parse::parse_file(cat_path);
    let cfg = load_config(config_path);
    let substituted = substitute_params(&module, &cfg);
    let resolved = ::catform::resolve::resolve(&substituted);
    let mut flat = ::catform::flatten::flatten(&resolved, entry);

    // Resolve dict paths to safetensors keys
    let weight_mapping = load_weight_mapping(config_path);
    resolve_weight_paths(&mut flat, &weight_mapping);

    serde_json::to_string(&flat).unwrap()
}

#[pyfunction]
#[pyo3(name = "parse_to_json")]
fn py_parse_to_json(source: &str) -> String {
    let module = ::catform::parse::parse(source);
    serde_json::to_string(&module).unwrap()
}

#[pyfunction]
#[pyo3(name = "resolve_json")]
fn py_resolve_json(module_json: &str, config_json: &str) -> String {
    let module: Module = serde_json::from_str(module_json).unwrap();
    let cfg: HashMap<String, ConfigValue> = serde_json::from_str(config_json).unwrap();
    let substituted = substitute_params(&module, &cfg);
    let resolved = ::catform::resolve::resolve(&substituted);
    serde_json::to_string(&resolved).unwrap()
}

#[pyfunction]
#[pyo3(name = "flatten_json")]
fn py_flatten_json(module_json: &str, entry: &str) -> String {
    let module: Module = serde_json::from_str(module_json).unwrap();
    let flat = ::catform::flatten::flatten(&module, entry);
    serde_json::to_string(&flat).unwrap()
}

#[pyfunction]
#[pyo3(name = "infer_axes_json")]
fn py_infer_axes_json(module_json: &str) -> String {
    let module: Module = serde_json::from_str(module_json).unwrap();
    let result = ::catform::resolve::resolve(&module);
    serde_json::to_string(&result).unwrap()
}

#[pyfunction]
#[pyo3(name = "check_json")]
fn py_check_json(module_json: &str) -> String {
    let module: Module = serde_json::from_str(module_json).unwrap();
    let result = ::catform::check::check(&module);
    serde_json::to_string(&result).unwrap()
}

#[pyfunction]
#[pyo3(name = "fmt_source", signature = (source, *, width = 100))]
fn py_fmt_source(source: &str, width: usize) -> String {
    let module = ::catform::parse::parse(source);
    ::catform::fmt::format_cat(&module, width)
}

#[pyfunction]
#[pyo3(name = "fmt_json", signature = (module_json, *, width = 100))]
fn py_fmt_json(module_json: &str, width: usize) -> String {
    let module: Module = serde_json::from_str(module_json).unwrap();
    ::catform::fmt::format_cat(&module, width)
}

#[pyfunction]
#[pyo3(name = "check_file")]
fn py_check_file(path: &str) -> String {
    let module = ::catform::parse::parse_file(path);
    let result = ::catform::check::check(&module);
    serde_json::to_string(&result).unwrap()
}

#[pyfunction]
#[pyo3(name = "fmt_file", signature = (path, *, width = 100))]
fn py_fmt_file(path: &str, width: usize) -> String {
    let module = ::catform::parse::parse_file(path);
    ::catform::fmt::format_cat(&module, width)
}

// -- Module registration ------------------------------------------------------

#[pymodule]
fn _catform(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(py_load_flat_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_parse_to_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_resolve_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_flatten_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_infer_axes_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_check_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_fmt_source, m)?)?;
    m.add_function(wrap_pyfunction!(py_fmt_json, m)?)?;
    m.add_function(wrap_pyfunction!(py_check_file, m)?)?;
    m.add_function(wrap_pyfunction!(py_fmt_file, m)?)?;
    Ok(())
}
