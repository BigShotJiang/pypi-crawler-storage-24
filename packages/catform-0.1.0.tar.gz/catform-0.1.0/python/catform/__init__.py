"""Catform language toolchain: .cat → dict → flat program.

Dict API (JSON transport is internal):
    parse      : str → dict
    resolve    : dict × dict → dict
    flatten    : dict × str → dict
    format_cat : dict → str
    check      : dict → list[str]
    load_flat  : path × path → dict  (hot path: parse + resolve + flatten)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import orjson

from catform import _catform

# ── Dict API ─────────────────────────────────────────────────────────────────


def parse(source: str) -> dict[str, Any]:
    return orjson.loads(_catform.parse_to_json(source))


def parse_file(path: str | Path) -> dict[str, Any]:
    return orjson.loads(_catform.parse_to_json(Path(path).read_text()))


def resolve(d: dict[str, Any], config: dict[str, int | float]) -> dict[str, Any]:
    return orjson.loads(_catform.resolve_json(json.dumps(d), json.dumps(config)))


def flatten(d: dict[str, Any], entry: str) -> dict[str, Any]:
    return orjson.loads(_catform.flatten_json(json.dumps(d), entry))


def infer_axes(d: dict[str, Any]) -> dict[str, Any]:
    return orjson.loads(_catform.infer_axes_json(json.dumps(d)))


def format_cat(d: dict[str, Any], *, width: int = 100) -> str:
    return _catform.fmt_json(json.dumps(d), width=width)


def check(d: dict[str, Any]) -> dict[str, Any]:
    return orjson.loads(_catform.check_json(json.dumps(d)))


def load_flat(cat_path: str | Path, config_path: str | Path, entry: str = "main") -> dict[str, Any]:
    return orjson.loads(_catform.load_flat_json(str(cat_path), str(config_path), entry))


# ── String API (pass-through) ────────────────────────────────────────────────

fmt_source = _catform.fmt_source
fmt_file = _catform.fmt_file


def check_file(path: str | Path) -> dict[str, Any]:
    return orjson.loads(_catform.check_file(str(path)))


__all__ = [
    "check",
    "check_file",
    "flatten",
    "fmt_file",
    "fmt_source",
    "format_cat",
    "infer_axes",
    "load_flat",
    "parse",
    "parse_file",
    "resolve",
]
