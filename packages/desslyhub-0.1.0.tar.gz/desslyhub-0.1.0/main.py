from __future__ import annotations

from desslyhub import Client


async def main() -> None:
    async with Client(
        api_key="b9b9a02ae4d249e58debe4f320b8eec0",
    ) as client:
        games = await client.get_steam_exchange_rates()
        print(games)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
