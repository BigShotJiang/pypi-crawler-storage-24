# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

desslyhub is an async Python SDK for the DesslyHub API (a Steam game gifting/transaction service). It uses aiohttp for HTTP and Pydantic v2 for response models.

## Commands

```bash
# Install dependencies (uses uv)
uv sync --group dev

# Run all tests
uv run pytest

# Run a single test
uv run pytest tests/test_balance_model.py

# Lint
uv run ruff check desslyhub/

# Format
uv run ruff format desslyhub/

# Type check
uv run mypy desslyhub/
```

## Architecture

The SDK follows a **method-object pattern**: each API endpoint is a Pydantic model class (`DesslyHubMethod[T]`) that knows its URL, HTTP verb, return type, and serializes itself into the request body. The `Client` creates these method objects and calls `method.execute(client)`, which delegates to the session layer.

**Key layers:**

- **`Client`** (`client/client.py`) — async context manager, public API surface. Each method (e.g. `get_balance`, `get_transaction`) instantiates a method object and executes it.
- **`DesslyHubMethod[T]`** (`methods/base.py`) — abstract base. Subclasses set `__api_method__`, `__http_method__`, `__return_type__` as class vars. `transform_response` uses Pydantic `model_validate` with a `{"client": client}` context so response objects can hold a back-reference to the client.
- **`BaseSession` / `AiohttpSession`** (`client/session/`) — transport abstraction. `BaseSession.raise_for_code` maps API error codes to exception classes via `DesslyHubAPIError.__subclasses__()`.
- **`DesslyHubObject`** (`types/base.py`) — base Pydantic model for all response types. Frozen, allows extras, captures client from validation context.
- **Exceptions** (`exceptions.py`) — each API error code has its own class with a `code` class attribute. The error registry is built dynamically from subclasses.

## Code Style

- All files must start with `from __future__ import annotations`.
- Ruff is the linter/formatter (line-length 99, double quotes, LF line endings, space indentation).
- Ruff isort rules: `required-imports = ["from __future__ import annotations"]`, length-sorted imports.
- Python 3.11+ required.