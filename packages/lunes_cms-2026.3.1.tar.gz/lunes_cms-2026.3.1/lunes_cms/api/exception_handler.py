from rest_framework import status
from rest_framework.views import exception_handler


def custom_exception_handler(exc, context):
    """
    Extend the default exception_handler of rest_framework.
    Purpose: Simplify testing by ensuring that the detail message is the same for all 404 responses.
    """

    response = exception_handler(exc, context)

    if getattr(response, "status_code", None) == status.HTTP_404_NOT_FOUND:
        response.data["detail"] = "Not found."

    return response
