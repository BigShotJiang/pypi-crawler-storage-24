"""Subagent manager for background task execution."""

from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from typing import Any

from loguru import logger

from kabot.agent.subagent_registry import SubagentRegistry
from kabot.agent.tools.filesystem import ListDirTool, ReadFileTool, WriteFileTool
from kabot.agent.tools.meta_graph import MetaGraphTool
from kabot.agent.tools.registry import ToolRegistry
from kabot.agent.tools.shell import ExecTool
from kabot.agent.tools.web_fetch import WebFetchTool
from kabot.agent.tools.web_search import WebSearchTool
from kabot.bus.events import InboundMessage
from kabot.bus.queue import MessageBus
from kabot.config.schema import ExecToolConfig, SubagentDefaults
from kabot.providers.base import LLMProvider


class SubagentManager:
    """
    Manages background subagent execution.

    Subagents are lightweight agent instances that run in the background
    to handle specific tasks. They share the same LLM provider but have
    isolated context and a focused system prompt.
    """

    def __init__(
        self,
        provider: LLMProvider,
        workspace: Path,
        bus: MessageBus,
        model: str | None = None,
        brave_api_key: str | None = None,
        web_search_config: Any | None = None,
        exec_config: ExecToolConfig | None = None,
        restrict_to_workspace: bool = False,
        http_guard: Any | None = None,
        meta_config: Any | None = None,
        subagent_config: SubagentDefaults | None = None,
    ):
        self.provider = provider
        self.workspace = workspace
        self.bus = bus
        self.model = model or provider.get_default_model()
        self.brave_api_key = brave_api_key
        self.web_search_config = web_search_config
        self.exec_config = exec_config or ExecToolConfig()
        self.restrict_to_workspace = restrict_to_workspace
        self.http_guard = http_guard
        self.meta_config = meta_config
        self.subagent_config = subagent_config or SubagentDefaults()
        self.current_depth: int = 0
        self._running_tasks: dict[str, asyncio.Task[None]] = {}

        # Phase 13: Persistent subagent registry
        registry_path = Path.home() / ".kabot" / "subagents" / "runs.json"
        self.registry = SubagentRegistry(registry_path)

        # Cleanup old completed runs on startup
        self.registry.cleanup_old_runs(
            max_age_seconds=self.subagent_config.archive_after_minutes * 60
        )

    async def spawn(
        self,
        task: str,
        label: str | None = None,
        origin_channel: str = "cli",
        origin_chat_id: str = "direct",
        parent_session_key: str = "unknown",
    ) -> str:
        """
        Spawn a subagent to execute a task in the background.

        Args:
            task: The task description for the subagent.
            label: Optional human-readable label for the task.
            origin_channel: The channel to announce results to.
            origin_chat_id: The chat ID to announce results to.
            parent_session_key: Parent session key for tracking.

        Returns:
            Status message indicating the subagent was started.
        """
        if self.get_running_count() >= self.subagent_config.max_children_per_agent:
            return (
                f"Cannot spawn: limit of {self.subagent_config.max_children_per_agent} "
                "concurrent subagents reached. Wait for a running task to complete."
            )

        if self.current_depth >= self.subagent_config.max_spawn_depth:
            return (
                f"Cannot spawn: maximum nesting depth of "
                f"{self.subagent_config.max_spawn_depth} reached. "
                "Nested sub-agent spawning is not allowed at this depth."
            )

        task_id = str(uuid.uuid4())[:8]
        display_label = label or task[:30] + ("..." if len(task) > 30 else "")

        origin = {
            "channel": origin_channel,
            "chat_id": origin_chat_id,
        }

        # Phase 13: Register in persistent registry
        self.registry.register(
            run_id=task_id,
            task=task,
            label=display_label,
            parent_session_key=parent_session_key,
            origin_channel=origin_channel,
            origin_chat_id=origin_chat_id,
        )

        # Create background task
        bg_task = asyncio.create_task(
            self._run_subagent(task_id, task, display_label, origin)
        )
        self._running_tasks[task_id] = bg_task

        # Cleanup when done
        bg_task.add_done_callback(lambda _: self._running_tasks.pop(task_id, None))

        logger.info(f"Spawned subagent [{task_id}]: {display_label}")
        return f"Subagent [{display_label}] started (id: {task_id}). I'll notify you when it completes."

    async def _run_subagent(
        self,
        task_id: str,
        task: str,
        label: str,
        origin: dict[str, str],
    ) -> None:
        """Execute the subagent task and announce the result."""
        logger.info(f"Subagent [{task_id}] starting task: {label}")

        try:
            # Build subagent tools (no message tool, no spawn tool)
            tools = ToolRegistry()
            allowed_dir = self.workspace if self.restrict_to_workspace else None
            tools.register(ReadFileTool(allowed_dir=allowed_dir))
            tools.register(WriteFileTool(allowed_dir=allowed_dir))
            tools.register(ListDirTool(allowed_dir=allowed_dir))
            tools.register(ExecTool(
                working_dir=str(self.workspace),
                timeout=self.exec_config.timeout,
                restrict_to_workspace=self.restrict_to_workspace,
                auto_approve=bool(getattr(self.exec_config, "auto_approve", False)),
            ))
            search_cfg = self.web_search_config
            tools.register(
                WebSearchTool(
                    api_key=getattr(search_cfg, "api_key", self.brave_api_key),
                    max_results=getattr(search_cfg, "max_results", 5),
                    provider=getattr(search_cfg, "provider", "brave"),
                    perplexity_api_key=getattr(search_cfg, "perplexity_api_key", ""),
                    perplexity_model=getattr(search_cfg, "perplexity_model", "sonar-pro"),
                    xai_api_key=getattr(search_cfg, "xai_api_key", ""),
                    xai_model=getattr(search_cfg, "xai_model", "grok-3-mini"),
                    kimi_api_key=getattr(search_cfg, "kimi_api_key", ""),
                    kimi_model=getattr(search_cfg, "kimi_model", "moonshot-v1-8k"),
                )
            )
            tools.register(WebFetchTool(http_guard=self.http_guard))
            tools.register(MetaGraphTool(meta_config=self.meta_config))

            # Build messages with subagent-specific prompt
            system_prompt = self._build_subagent_prompt(task)
            messages: list[dict[str, Any]] = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": task},
            ]

            # Run agent loop (limited iterations)
            max_iterations = 15
            iteration = 0
            final_result: str | None = None

            while iteration < max_iterations:
                iteration += 1

                response = await self.provider.chat(
                    messages=messages,
                    tools=tools.get_definitions(),
                    model=self.model,
                )

                if response.has_tool_calls:
                    # Add assistant message with tool calls
                    tool_call_dicts = [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.name,
                                "arguments": json.dumps(tc.arguments),
                            },
                        }
                        for tc in response.tool_calls
                    ]
                    messages.append({
                        "role": "assistant",
                        "content": response.content or "",
                        "tool_calls": tool_call_dicts,
                    })

                    # Execute tools
                    for tool_call in response.tool_calls:
                        args_str = json.dumps(tool_call.arguments)
                        logger.debug(f"Subagent [{task_id}] executing: {tool_call.name} with arguments: {args_str}")
                        result = await tools.execute(tool_call.name, tool_call.arguments)
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "name": tool_call.name,
                            "content": result,
                        })
                else:
                    final_result = response.content
                    break

            if final_result is None:
                final_result = "Task completed but no final response was generated."

            logger.info(f"Subagent [{task_id}] completed successfully")

            # Phase 13: Mark as completed in registry
            self.registry.complete(
                run_id=task_id,
                result=final_result,
                status="completed"
            )

            await self._announce_result(task_id, label, task, final_result, origin, "ok")

        except Exception as e:
            error_msg = f"Error: {str(e)}"
            logger.error(f"Subagent [{task_id}] failed: {e}")

            # Phase 13: Mark as failed in registry
            self.registry.complete(
                run_id=task_id,
                result=error_msg,
                status="failed",
                error=str(e)
            )

            await self._announce_result(task_id, label, task, error_msg, origin, "error")

    async def _announce_result(
        self,
        task_id: str,
        label: str,
        task: str,
        result: str,
        origin: dict[str, str],
        status: str,
    ) -> None:
        """Announce the subagent result to the main agent via the message bus."""
        status_text = "completed successfully" if status == "ok" else "failed"

        announce_content = f"""[Subagent '{label}' {status_text}]

Task: {task}

Result:
{result}

Summarize this naturally for the user. Keep it brief (1-2 sentences). Do not mention technical details like "subagent" or task IDs."""

        # Inject as system message to trigger main agent
        msg = InboundMessage(
            channel="system",
            sender_id="subagent",
            chat_id=f"{origin['channel']}:{origin['chat_id']}",
            content=announce_content,
        )

        await self.bus.publish_inbound(msg)
        logger.debug(f"Subagent [{task_id}] announced result to {origin['channel']}:{origin['chat_id']}")

    def _build_subagent_prompt(self, task: str) -> str:
        """Build a focused system prompt for the subagent."""
        return f"""# Subagent

You are a subagent spawned by the main agent to complete a specific task.

## Your Task
{task}

## Rules
1. Stay focused - complete only the assigned task, nothing else
2. Your final response will be reported back to the main agent
3. Do not initiate conversations or take on side tasks
4. Be concise but informative in your findings

## What You Can Do
- Read and write files in the workspace
- Execute shell commands
- Search the web and fetch web pages
- Complete the task thoroughly

## What You Cannot Do
- Send messages directly to users (no message tool available)
- Spawn other subagents
- Access the main agent's conversation history

## Workspace
Your workspace is at: {self.workspace}

When you have completed the task, provide a clear summary of your findings or actions."""

    def get_running_count(self) -> int:
        """Return the number of currently running subagents."""
        return len(self._running_tasks)
