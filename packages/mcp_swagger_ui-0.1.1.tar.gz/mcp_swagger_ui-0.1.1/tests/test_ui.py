from __future__ import annotations

from mcp_swagger_ui.ui import build_docs_html


def test_build_docs_html_embeds_page_title_and_openapi_url() -> None:
    html = build_docs_html(openapi_json_url="./schema.json", page_title="Custom MCP Docs")

    assert "<!doctype html>" in html
    assert "Custom MCP Docs" in html
    assert "./schema.json" in html
    assert "Search by route, summary, or description" in html
