from __future__ import annotations


def build_docs_html(openapi_json_url: str = "./openapi.json", page_title: str = "MCP Docs UI") -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{page_title}</title>
  <style>
    :root {{
      --bg: #0f172a;
      --panel: #111827;
      --muted: #94a3b8;
      --text: #e2e8f0;
      --accent: #22d3ee;
      --border: #1f2937;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif;
      background: var(--bg);
      color: var(--text);
    }}
    header {{
      padding: 16px 24px;
      border-bottom: 1px solid var(--border);
      position: sticky;
      top: 0;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(6px);
      z-index: 2;
    }}
    h1 {{ margin: 0; font-size: 20px; }}
    .sub {{ margin-top: 6px; color: var(--muted); font-size: 13px; }}
    main {{ padding: 16px 24px 40px; max-width: 1200px; margin: 0 auto; }}
    .bar {{ display: flex; gap: 8px; margin-bottom: 16px; }}
    input {{
      flex: 1;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text);
      padding: 10px 12px;
    }}
    .item {{
      border: 1px solid var(--border);
      background: var(--panel);
      border-radius: 10px;
      margin-bottom: 12px;
      overflow: hidden;
    }}
    .item-head {{
      padding: 12px 14px;
      display: flex;
      gap: 12px;
      align-items: center;
      border-bottom: 1px solid var(--border);
    }}
    .tag {{
      font-size: 11px;
      letter-spacing: .4px;
      text-transform: uppercase;
      border: 1px solid var(--accent);
      color: var(--accent);
      border-radius: 999px;
      padding: 2px 8px;
    }}
    .route {{ font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }}
    .desc {{ color: var(--muted); font-size: 13px; margin-top: 3px; }}
    details {{ padding: 0 14px 14px; }}
    pre {{
      margin: 8px 0 0;
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 10px;
      overflow: auto;
      background: #020617;
      color: #bfdbfe;
      font-size: 12px;
    }}
    .empty {{ color: var(--muted); margin-top: 12px; }}
  </style>
</head>
<body>
  <header>
    <h1>{page_title}</h1>
    <div class="sub">Swagger-like MCP docs for tools, prompts, and resources.</div>
  </header>
  <main>
    <div class="bar">
      <input id="search" placeholder="Search by route, summary, or description..." />
    </div>
    <div id="list"></div>
    <div id="empty" class="empty" hidden>No endpoints match this filter.</div>
  </main>

  <script>
    const list = document.getElementById('list');
    const empty = document.getElementById('empty');
    const search = document.getElementById('search');
    let endpoints = [];

    function asJson(x) {{
      try {{
        return JSON.stringify(x ?? {{}}, null, 2);
      }} catch (_) {{
        return '{{}}';
      }}
    }}

    function render(filter = '') {{
      const q = filter.trim().toLowerCase();
      const shown = endpoints.filter((e) => {{
        if (!q) return true;
        const s = [e.route, e.summary, e.description, ...(e.tags || [])].join(' ').toLowerCase();
        return s.includes(q);
      }});

      list.innerHTML = shown.map((e) => `
        <article class="item">
          <div class="item-head">
            <span class="tag">${{(e.tags && e.tags[0]) || 'mcp'}}</span>
            <div>
              <div class="route">${{e.route}}</div>
              <div class="desc">${{e.summary || ''}}</div>
            </div>
          </div>
          <details>
            <summary>Details</summary>
            <div class="desc">${{e.description || ''}}</div>
            <h4>Request schema</h4>
            <pre>${{asJson(e.requestSchema)}}</pre>
            <h4>Response schema</h4>
            <pre>${{asJson(e.responseSchema)}}</pre>
            <h4>Metadata</h4>
            <pre>${{asJson(e.metadata)}}</pre>
          </details>
        </article>
      `).join('');

      empty.hidden = shown.length !== 0;
    }}

    async function init() {{
      const resp = await fetch('{openapi_json_url}');
      const doc = await resp.json();
      const paths = doc.paths || {{}};
      endpoints = Object.entries(paths).flatMap(([route, methods]) => {{
        const op = methods.get || methods.post || methods.put || methods.patch || methods.delete || {{}};
        return [{{
          route,
          summary: op.summary || '',
          description: op.description || '',
          tags: op.tags || [],
          metadata: op['x-mcp-metadata'] || {{}},
          requestSchema: op.requestBody?.content?.['application/json']?.schema || {{}},
          responseSchema: op.responses?.['200']?.content?.['application/json']?.schema || {{}},
        }}];
      }});
      render('');
    }}

    search.addEventListener('input', (e) => render(e.target.value));
    init().catch((err) => {{
      list.innerHTML = `<pre>${{String(err)}}</pre>`;
    }});
  </script>
</body>
</html>
"""
