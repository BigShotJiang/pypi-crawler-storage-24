import sys
import os
import shutil
import subprocess
from importlib import resources

def main():
    if len(sys.argv) != 2:
        print("Usage: pkzs demo1.ipynb")
        return

    notebook_name = sys.argv[1]

    try:
        with resources.path("pkzs.notebooks", notebook_name) as nb_path:
            destination = os.path.join(os.getcwd(), notebook_name)
            shutil.copy(nb_path, destination)
            print("Notebook copied.")
            subprocess.run(["jupyter", "notebook", destination])
    except FileNotFoundError:
        print("Notebook not found.")