from binascii import Error

from kaq_quant_common.common.modules.limit_order_symbol_monitor import (
    LimitOrderSymbolMonitor,
)
from kaq_quant_common.common.monitor_group import MonitorGroup


class LimitOrderSymbolMonitorGroup(MonitorGroup):
    def __init__(self, exchange: str, default_symbols: list[str], table_name="kaq_all_futures_limit_order_symbols_config"):
        super().__init__()

        # 监听交易对变化
        symbol_monitor = LimitOrderSymbolMonitor(exchange=exchange, default_symbols=default_symbols, table_name=table_name)
        self._symbol_monitor = symbol_monitor
        # 用来创建监听器
        self._create_monitor_fun = None
        self._monitor_cls = None
        # 最大监听次数
        self._max_monitor_count = -1
        self._current_monitor_count = 0
        # 当前分组与监听器的映射表 key: tuple(symbols), value: Monitor
        self._group_monitor_map: dict[tuple, object] = {}

    def set_create_monitor_fun(self, create_monitor_fun):
        self._create_monitor_fun = create_monitor_fun

    def set_monitor_cls(self, monitor_cls):
        self._monitor_cls = monitor_cls
        self._create_monitor_fun = lambda symbols: self._monitor_cls(symbols)

    def start(self, group_size=9):

        # 检查是否设置了创建监听器的函数
        if self._create_monitor_fun is None:
            raise Error("create_monitor_fun is not set")

        #
        symbol_monitor = self._symbol_monitor
        symbol_monitor.start()

        create_monitor_fun = self._create_monitor_fun

        def do_start_monitor(symbols: list[str]):
            new_symbol_set = set(symbols)

            # 计算全部已有的 symbol（在任何现有监听器里的）
            all_existing_symbols = {s for group_key in self._group_monitor_map for s in group_key}
            # 真正新增的 symbol（不在任何现有监听器里的）
            added_symbols = new_symbol_set - all_existing_symbols

            # Step 1: 找出满员且所有 symbol 仍存在的组（无条件保留）
            clean_full_keys = {
                group_key for group_key in self._group_monitor_map if len(group_key) == group_size and all(s in new_symbol_set for s in group_key)
            }

            # Step 2: 找出不满员但所有 symbol 仍存在的 partial 组
            clean_partial_keys = {
                group_key for group_key in self._group_monitor_map if len(group_key) < group_size and all(s in new_symbol_set for s in group_key)
            }

            # Step 3: partial 组是否解散取决于是否有新 symbol 需要分配
            # - 有新 symbol → 解散 partial 组，让 partial 里的 symbol 与新 symbol 合并成完整组
            # - 无新 symbol → partial 组保留不动，避免无意义的停止重建
            if added_symbols:
                keep_partial_keys = set()
            else:
                keep_partial_keys = clean_partial_keys

            # Step 4: 最终干净组 = 满员干净组 + 决定保留的 partial 组
            clean_group_keys = clean_full_keys | keep_partial_keys

            # Step 5: 停止脏组（含被删 symbol 的组 + 决定解散的 partial 组）
            dirty_group_keys = set(self._group_monitor_map.keys()) - clean_group_keys
            for group_key in dirty_group_keys:
                monitor = self._group_monitor_map.pop(group_key)
                self._logger.info(f"停止监听器，交易对组: {list(group_key)}")
                self.stop_monitor(monitor)

            # Step 6: 计算干净组已覆盖的 symbol，得到待分配的 remaining
            covered_symbols = {s for group_key in clean_group_keys for s in group_key}
            remaining = [s for s in symbols if s not in covered_symbols]

            if not remaining:
                self._logger.info(f"无变化，保留 {len(clean_group_keys)} 个监听器")
                return

            # Step 7: 对 remaining 按 group_size 分组，创建新监听器
            new_monitors = []
            for i in range(0, len(remaining), group_size):
                sub_symbols = remaining[i : i + group_size]
                group_key = tuple(sub_symbols)
                self._logger.info(f"创建新监听器，交易对组: {sub_symbols}")
                monitor = create_monitor_fun(sub_symbols)
                self._group_monitor_map[group_key] = monitor
                new_monitors.append(monitor)

            # Step 8: 启动新建的监听器
            self.link(monitors=new_monitors, clear=False)

        # 监听器
        def on_symbol_change(symbols: list[str]):
            # 次数++
            self._current_monitor_count = self._current_monitor_count + 1
            self._logger.info(f"监听变化次数 {self._current_monitor_count}")
            if self._max_monitor_count > 0 and self._current_monitor_count >= self._max_monitor_count:
                self._logger.info(f"超过监听次数 {self._max_monitor_count}，停止")
                self.stop()
                return
            #
            do_start_monitor(symbols=symbols)

        # 设置监听回调
        symbol_monitor.set_handler(on_symbol_change)

        # 订阅一次（首次初始化，所有组都是新建的）
        do_start_monitor(symbols=symbol_monitor.get_symbols())

        #
        super().start()
