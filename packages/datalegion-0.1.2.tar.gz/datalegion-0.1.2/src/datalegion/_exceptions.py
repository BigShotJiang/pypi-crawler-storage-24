"""Exceptions for the Data Legion API client."""

from __future__ import annotations

from typing import Any


class DataLegionError(Exception):
    """Base exception for all Data Legion API errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error: str | None = None,
        details: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error = error
        self.details = details

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"status_code={self.status_code!r}, "
            f"error={self.error!r})"
        )


class AuthenticationError(DataLegionError):
    """Raised when the API key is invalid or missing (HTTP 401)."""


class InsufficientCreditsError(DataLegionError):
    """Raised when the account has insufficient credits (HTTP 402)."""


class ValidationError(DataLegionError):
    """Raised when the request fails validation (HTTP 422)."""


class RateLimitError(DataLegionError):
    """Raised when the rate limit is exceeded (HTTP 429)."""


class APIError(DataLegionError):
    """Raised for server errors (HTTP 500, 503, etc.)."""
