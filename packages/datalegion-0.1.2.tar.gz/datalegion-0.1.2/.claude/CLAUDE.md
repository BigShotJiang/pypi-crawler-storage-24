# CLAUDE.md

Python SDK for the Data Legion API. Provides sync (`DataLegion`) and async (`AsyncDataLegion`) clients for person/company enrichment, search, discover, and utility endpoints. All responses are Pydantic v2 models with dot access and autocomplete.

## Commands

```bash
uv sync --dev          # Install dependencies
uv run lint            # Lint (ruff format + check, mdformat)
uv run pytest tests/   # Run tests (needs DATALEGION_API_KEY env var)
uv build               # Build package
```

## Architecture

- `src/datalegion/__init__.py` - Package exports (clients, exceptions, response types)
- `src/datalegion/_client.py` - Sync + async HTTP clients with resource namespaces and `@overload` for enrich return types
- `src/datalegion/_exceptions.py` - Exception hierarchy (AuthenticationError, RateLimitError, etc.)
- `src/datalegion/_types.py` - Pydantic v2 response models (PersonResponse, CompanyResponse, etc.)
- `scripts/lint.py` - Lint script
- `tests/test_client.py` - Integration tests (call real API)

## Guidelines

- Use `uv run` for all commands
- Run lint and tests after changes
- Keep it simple, no over-engineering
