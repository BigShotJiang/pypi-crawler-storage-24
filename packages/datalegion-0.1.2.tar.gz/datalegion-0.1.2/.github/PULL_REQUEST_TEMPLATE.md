## Summary

<!-- What does this PR do? -->

## Test Plan

<!-- How was this tested? -->

- [ ] Tests pass (`uv run pytest tests/`)
- [ ] Lint passes (`uv run lint`)
