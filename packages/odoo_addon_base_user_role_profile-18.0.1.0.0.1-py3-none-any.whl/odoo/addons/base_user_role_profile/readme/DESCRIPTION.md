Extending the base_user_role module, this one adds the notion of
profiles. Effectively profiles act as an additional filter to how the
roles are used.

This allows users to switch their permission groups dynamically. This can be useful for example to:
- finer grain control on menu and model permissions (with record rules
  this becomes very flexible)
- break down complicated menus into simpler ones
- easily restrict users accidentally editing or creating records in O2M
  fields and in general misusing the interface, instead of excessively
  explaining things to them

When you define a role, you have the possibility to link it to a profile. Roles are applied to users in the following way:
- Apply user's roles without profiles in any case
- Apply user's roles that are linked to the currently selected profile

In addition you can:
- Add a 'no profile' profile to the user's choice of profile, to allow him to select a specific profile which enables only the roles without a profile.
- Restrict the user to change its profile, which can be useful in a security emergency.
