"""
litecrew - Multi-agent orchestration in ~100 lines. No magic.
https://github.com/menonpg/litecrew
"""

import json
import os
from dataclasses import dataclass, field
from typing import Callable, Any
from concurrent.futures import ThreadPoolExecutor

# Optional imports - graceful degradation
try:
    import openai
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    from soul_agent import Soul
    HAS_SOUL = True
except ImportError:
    HAS_SOUL = False


@dataclass
class Agent:
    """An agent = model + tools + personality. That's it."""
    name: str
    model: str = "gpt-4o-mini"
    system: str = "You are a helpful assistant."
    tools: list[Callable] = field(default_factory=list)
    memory: Any = None  # Optional Soul instance
    
    _tokens_in: int = field(default=0, repr=False)
    _tokens_out: int = field(default=0, repr=False)

    def __call__(self, prompt: str, **kwargs) -> str:
        """Run the agent. Returns the response string."""
        messages = self._build_messages(prompt)
        response = self._call_llm(messages, **kwargs)
        return response

    def _build_messages(self, prompt: str) -> list[dict]:
        messages = [{"role": "system", "content": self.system}]
        
        # Add memory context if available
        if self.memory and HAS_SOUL:
            context = self.memory.recall(prompt, limit=3)
            if context:
                messages.append({"role": "system", "content": f"Relevant context:\n{context}"})
        
        messages.append({"role": "user", "content": prompt})
        return messages

    def _call_llm(self, messages: list[dict], **kwargs) -> str:
        """Route to the right provider based on model name."""
        model = self.model.lower()
        
        if "claude" in model:
            return self._call_anthropic(messages, **kwargs)
        else:
            return self._call_openai(messages, **kwargs)

    def _call_openai(self, messages: list[dict], **kwargs) -> str:
        if not HAS_OPENAI:
            raise ImportError("pip install openai")
        
        client = openai.OpenAI()
        tools_schema = self._tools_to_schema() if self.tools else None
        
        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools_schema,
            **kwargs
        )
        
        msg = response.choices[0].message
        self._tokens_in += response.usage.prompt_tokens
        self._tokens_out += response.usage.completion_tokens
        
        # Handle tool calls
        if msg.tool_calls:
            return self._execute_tools(msg, messages, **kwargs)
        
        return msg.content

    def _call_anthropic(self, messages: list[dict], **kwargs) -> str:
        if not HAS_ANTHROPIC:
            raise ImportError("pip install anthropic")
        
        client = anthropic.Anthropic()
        system = next((m["content"] for m in messages if m["role"] == "system"), "")
        user_msgs = [m for m in messages if m["role"] != "system"]
        
        response = client.messages.create(
            model=self.model,
            system=system,
            messages=user_msgs,
            max_tokens=4096,
            **kwargs
        )
        
        self._tokens_in += response.usage.input_tokens
        self._tokens_out += response.usage.output_tokens
        
        return response.content[0].text

    def _tools_to_schema(self) -> list[dict]:
        """Convert Python functions to OpenAI tool schema."""
        schemas = []
        for fn in self.tools:
            schema = {
                "type": "function",
                "function": {
                    "name": fn.__name__,
                    "description": fn.__doc__ or f"Call {fn.__name__}",
                    "parameters": getattr(fn, "_schema", {"type": "object", "properties": {}})
                }
            }
            schemas.append(schema)
        return schemas

    def _execute_tools(self, msg, messages: list[dict], **kwargs) -> str:
        """Execute tool calls and continue conversation."""
        messages.append({"role": "assistant", "tool_calls": msg.tool_calls})
        
        for call in msg.tool_calls:
            fn = next((t for t in self.tools if t.__name__ == call.function.name), None)
            if fn:
                args = json.loads(call.function.arguments)
                result = fn(**args)
            else:
                result = f"Unknown tool: {call.function.name}"
            
            messages.append({
                "role": "tool",
                "tool_call_id": call.id,
                "content": str(result)
            })
        
        return self._call_openai(messages, **kwargs)

    @property
    def tokens(self) -> dict:
        return {"in": self._tokens_in, "out": self._tokens_out}


def sequential(*agents: Agent):
    """Run agents in sequence, passing output to next input."""
    def run(prompt: str) -> str:
        result = prompt
        for agent in agents:
            result = agent(result)
        return result
    return run


def parallel(*agents: Agent):
    """Run agents in parallel, return all results."""
    def run(prompt: str) -> list[str]:
        with ThreadPoolExecutor(max_workers=len(agents)) as pool:
            results = list(pool.map(lambda a: a(prompt), agents))
        return results
    return run


def crew(*agents: Agent, reducer: Callable = None):
    """
    Decorator for multi-agent workflows.
    
    @crew(researcher, writer)
    def write_article(topic):
        research = researcher(f"Research {topic}")
        return writer(f"Write about: {research}")
    """
    def decorator(fn: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            # Inject agents into function's global scope
            fn_globals = fn.__globals__
            for agent in agents:
                fn_globals[agent.name] = agent
            
            result = fn(*args, **kwargs)
            
            # Apply reducer if provided
            if reducer and isinstance(result, list):
                result = reducer(result)
            
            return result
        
        wrapper._agents = agents
        wrapper._tokens = lambda: {a.name: a.tokens for a in agents}
        return wrapper
    return decorator


def tool(schema: dict = None):
    """Decorator to mark a function as a tool with optional schema."""
    def decorator(fn: Callable) -> Callable:
        fn._schema = schema or {"type": "object", "properties": {}}
        return fn
    return decorator


# Convenience: connect to soul-agent memory
def with_memory(agent: Agent, namespace: str = "default") -> Agent:
    """Add soul-agent memory to an agent."""
    if not HAS_SOUL:
        raise ImportError("pip install soul-agent")
    agent.memory = Soul(namespace=namespace)
    return agent


__version__ = "0.1.0"
__all__ = ["Agent", "crew", "sequential", "parallel", "tool", "with_memory"]
