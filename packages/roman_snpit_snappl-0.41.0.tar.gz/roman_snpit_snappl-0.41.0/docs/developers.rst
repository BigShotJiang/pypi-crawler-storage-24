#######################
snappl Developers Guide
#######################

TODO
