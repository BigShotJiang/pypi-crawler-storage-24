from pathlib import Path

import pytest

from airflow_dag_audit import DagAuditConfig, DagBudgetExceeded, assert_dag_budget, audit_dag_file


def test_audit_dag_file_collects_failures(tmp_path: Path) -> None:
    dag_file = tmp_path / "dag.py"
    dag_file.write_text(
        """
import os
import sys
from airflow.models import Variable
from airflow.hooks.base import BaseHook

value = Variable.get("x")
conn = BaseHook.get_connection("x")
query = "SELECT 1"
EmailOperator(task_id="x")
helper()
""".strip(),
        encoding="utf-8",
    )

    result = audit_dag_file(
        dag_file,
        config=DagAuditConfig(max_imports=1, max_import_froms=0, max_variable_gets=0, max_connection_gets=0, max_sql_queries=0, max_operators=0, max_tasks=0, max_top_level_calls=0),
    )

    assert result.ok is False
    assert any("import_count" in failure for failure in result.failures)
    assert any("import_from_count" in failure for failure in result.failures)
    assert any("variable_get_count" in failure for failure in result.failures)
    assert any("connection_get_count" in failure for failure in result.failures)
    assert any("sql_query_count" in failure for failure in result.failures)
    assert any("operator_count" in failure for failure in result.failures)
    assert any("task_count" in failure for failure in result.failures)
    assert any("top_level_call_count" in failure for failure in result.failures)


def test_assert_dag_budget_raises_with_hash_diff(tmp_path: Path) -> None:
    dag_file = tmp_path / "unstable.py"
    dag_file.write_text(
        """
class DynamicRepr:
    def __repr__(self):
        return f"DynamicRepr(id={id(self)})"

class Dag:
    def __init__(self):
        self.dag_id = "unstable"
        self.payload = DynamicRepr()

unstable_dag = Dag()
""".strip(),
        encoding="utf-8",
    )

    with pytest.raises(DagBudgetExceeded, match="stable_hash"):
        assert_dag_budget(dag_file, config=DagAuditConfig(require_stable_hash=True))
