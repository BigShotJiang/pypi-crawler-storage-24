from pathlib import Path

from airflow_dag_audit.discovery import infer_dag_folder
from airflow_dag_audit.static_analysis import collect_static_metrics


def test_collect_static_metrics_counts_expected_patterns(tmp_path: Path) -> None:
    dag_file = tmp_path / "demo.py"
    dag_file.write_text(
        """
import os
from math import sqrt, floor
from airflow.models import Variable
from airflow.hooks.base import BaseHook

SQL = "SELECT * FROM table"

value = Variable.get("name")
conn = BaseHook.get_connection("x")
EmailOperator(task_id="demo")
helper()

@dag(schedule=None)
def build():
    query = "UPDATE table SET value = 1"
    return query
""".strip(),
        encoding="utf-8",
    )

    result = collect_static_metrics(dag_file)

    assert result.import_count == 5
    assert result.import_from_count == 4
    assert result.variable_get_count == 1
    assert result.connection_get_count == 1
    assert result.sql_query_count == 2
    assert result.operator_count == 1
    assert result.task_count == 1
    assert result.top_level_call_count == 4
    assert result.detected_dag_decorators == 1


def test_infer_dag_folder_prefers_named_dags_directory(tmp_path: Path) -> None:
    dag_file = tmp_path / "project" / "dags" / "nested" / "demo.py"
    dag_file.parent.mkdir(parents=True)
    dag_file.write_text("pass\n", encoding="utf-8")

    assert infer_dag_folder(dag_file) == dag_file.parents[1]
