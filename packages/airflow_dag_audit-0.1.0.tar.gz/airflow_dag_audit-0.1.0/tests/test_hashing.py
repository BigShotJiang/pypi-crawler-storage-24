from pathlib import Path

from airflow_dag_audit.hashing import check_stable_hash


def test_stable_hash_for_deterministic_dag_like_object(tmp_path: Path) -> None:
    dag_file = tmp_path / "stable.py"
    dag_file.write_text(
        """
class Dag:
    def __init__(self):
        self.dag_id = "stable"
        self.payload = {"a": 1, "b": [1, 2, 3]}

stable_dag = Dag()
""".strip(),
        encoding="utf-8",
    )

    result = check_stable_hash(dag_file)

    assert result.stable is True
    assert result.first_hashes == result.second_hashes
    assert result.strategy == "generic"


def test_unstable_hash_for_dynamic_repr_object(tmp_path: Path) -> None:
    dag_file = tmp_path / "unstable.py"
    dag_file.write_text(
        """
class DynamicRepr:
    def __repr__(self):
        return f"DynamicRepr(id={id(self)})"

class Dag:
    def __init__(self):
        self.dag_id = "unstable"
        self.payload = DynamicRepr()

unstable_dag = Dag()
""".strip(),
        encoding="utf-8",
    )

    result = check_stable_hash(dag_file)

    assert result.stable is False
    assert result.first_hashes != result.second_hashes
    assert "DynamicRepr" in result.diff
