import os
from pathlib import Path

from typer.testing import CliRunner

from airflow_dag_audit.cli import app

runner = CliRunner()


def test_scan_command_returns_zero_and_prints_summary(tmp_path: Path) -> None:
    dag_file = tmp_path / "stable.py"
    dag_file.write_text(
        """
class Dag:
    def __init__(self):
        self.dag_id = "stable"

stable_dag = Dag()
""".strip(),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["scan", str(dag_file), "--require-stable-hash"])

    assert result.exit_code == 0
    assert "scanned 1 file(s)" in result.stdout
    assert "stable_hash" in result.stdout


def test_assert_command_fails_when_budget_is_exceeded(tmp_path: Path) -> None:
    dag_file = tmp_path / "dag.py"
    dag_file.write_text(
        """
import os
import sys
""".strip(),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["assert", str(dag_file), "--max-imports", "1"])

    assert result.exit_code == 1
    assert "DAG audit failed" in result.stdout


def test_hash_command_fails_for_unstable_file(tmp_path: Path) -> None:
    dag_file = tmp_path / "unstable.py"
    dag_file.write_text(
        """
class DynamicRepr:
    def __repr__(self):
        return f"DynamicRepr(id={id(self)})"

class Dag:
    def __init__(self):
        self.dag_id = "unstable"
        self.payload = DynamicRepr()

unstable_dag = Dag()
""".strip(),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["hash", str(dag_file), "--show-diff"])

    assert result.exit_code == 1
    assert "hash changed across reparses" in result.stdout


def test_assert_command_uses_pyproject_when_path_is_omitted(tmp_path: Path) -> None:
    dags = tmp_path / "dags"
    legacy = dags / "legacy"
    legacy.mkdir(parents=True)
    dag_file = legacy / "heavy.py"
    dag_file.write_text(
        """
import os
import sys
class Dag:
    def __init__(self):
        self.dag_id = "heavy"

heavy_dag = Dag()
""".strip(),
        encoding="utf-8",
    )
    (tmp_path / "pyproject.toml").write_text(
        """
[tool.airflow-dag-audit]
dag_folder = "dags"

[tool.airflow-dag-audit.budget]
imports = 1

[[tool.airflow-dag-audit.overrides]]
match = "dags/legacy/*.py"

[tool.airflow-dag-audit.overrides.budget]
imports = 2
""".strip(),
        encoding="utf-8",
    )

    original_cwd = Path.cwd()
    os.chdir(tmp_path)
    try:
        result = runner.invoke(app, ["assert"])
    finally:
        os.chdir(original_cwd)

    assert result.exit_code == 0
    assert "heavy.py" in result.stdout
