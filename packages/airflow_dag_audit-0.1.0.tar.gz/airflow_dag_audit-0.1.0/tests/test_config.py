from pathlib import Path

from airflow_dag_audit.config import load_project_config


def test_load_project_config_resolves_overrides(tmp_path: Path) -> None:
    dags = tmp_path / "dags"
    legacy = dags / "legacy"
    legacy.mkdir(parents=True)
    good = dags / "good.py"
    good.write_text("good = 1", encoding="utf-8")
    heavy = legacy / "heavy.py"
    heavy.write_text("heavy = 1", encoding="utf-8")

    (tmp_path / "pyproject.toml").write_text(
        """
[tool.airflow-dag-audit]
dag_folder = "dags"
check_hash_stability = true

[tool.airflow-dag-audit.budget]
imports = 10
variable_get_calls = 2

[[tool.airflow-dag-audit.overrides]]
match = "dags/legacy/*.py"

[tool.airflow-dag-audit.overrides.budget]
imports = 50

[[tool.airflow-dag-audit.overrides]]
match = "dags/legacy/heavy.py"
check_hash_stability = false

[tool.airflow-dag-audit.overrides.budget]
variable_get_calls = 9
""".strip(),
        encoding="utf-8",
    )

    config = load_project_config(tmp_path)
    assert config is not None
    assert [path.relative_to(tmp_path).as_posix() for path in config.iter_configured_files()] == [
        "dags/good.py",
        "dags/legacy/heavy.py",
    ]

    good_cfg = config.resolve_for_dag_file(good)
    heavy_cfg = config.resolve_for_dag_file(heavy)

    assert good_cfg.max_imports == 10
    assert good_cfg.require_stable_hash is True
    assert heavy_cfg.max_imports == 50
    assert heavy_cfg.max_variable_gets == 9
    assert heavy_cfg.require_stable_hash is False
