def test_pytest_plugin_reads_defaults_from_pyproject(pytester) -> None:
    pytester.makepyprojecttoml(
        """
[tool.airflow-dag-audit]
dag_folder = "examples"
check_hash_stability = true

[tool.airflow-dag-audit.budget]
imports = 10
""".strip()
    )
    examples_dir = pytester.mkdir("examples")
    (examples_dir / "demo.py").write_text(
        """
class Dag:
    def __init__(self):
        self.dag_id = "demo"
        self.payload = {"a": 1}

demo_dag = Dag()
""".strip(),
        encoding="utf-8",
    )
    pytester.makepyfile(
        test_plugin_defaults=
        """
from airflow_dag_audit import assert_dag_budget


def test_budget(dag_file, dag_audit_config):
    assert dag_audit_config.max_imports == 10
    assert dag_audit_config.require_stable_hash is True
    assert_dag_budget(dag_file, config=dag_audit_config)
""".strip(),
    )

    result = pytester.runpytest()
    result.assert_outcomes(passed=1)


def test_pytest_marker_overrides_defaults(pytester) -> None:
    pytester.makepyprojecttoml(
        """
[tool.airflow-dag-audit]
dag_folder = "dags"

[tool.airflow-dag-audit.budget]
imports = 1
""".strip()
    )
    dags = pytester.mkdir("dags")
    (dags / "demo.py").write_text(
        """
import os
import sys

class Dag:
    def __init__(self):
        self.dag_id = "demo"

demo_dag = Dag()
""".strip(),
        encoding="utf-8",
    )
    pytester.makepyfile(
        test_plugin_marker=
        """
import pytest

from airflow_dag_audit import assert_dag_budget


@pytest.mark.airflow_dag_budget(max_imports=3)
def test_budget(dag_file, dag_audit_config):
    assert dag_audit_config.max_imports == 3
    assert_dag_budget(dag_file, config=dag_audit_config)
""".strip(),
    )

    result = pytester.runpytest()
    result.assert_outcomes(passed=1)


def test_pytest_plugin_uses_override_for_specific_file(pytester) -> None:
    pytester.makepyprojecttoml(
        """
[tool.airflow-dag-audit]
dag_folder = "dags"

[tool.airflow-dag-audit.budget]
imports = 1

[[tool.airflow-dag-audit.overrides]]
match = "dags/legacy/*.py"

[tool.airflow-dag-audit.overrides.budget]
imports = 2
""".strip()
    )
    dags = pytester.mkdir("dags")
    legacy = dags / "legacy"
    legacy.mkdir()
    (legacy / "heavy.py").write_text(
        """
import os
import sys

class Dag:
    def __init__(self):
        self.dag_id = "heavy"

heavy_dag = Dag()
""".strip(),
        encoding="utf-8",
    )
    pytester.makepyfile(
        test_plugin_override=
        """
def test_budget(dag_file, dag_audit_config):
    assert dag_file.name == "heavy.py"
    assert dag_audit_config.max_imports == 2
""".strip(),
    )

    result = pytester.runpytest()
    result.assert_outcomes(passed=1)
