from __future__ import annotations

import argparse
import dataclasses
import hashlib
import importlib.util
import inspect
import json
import sys
import types
import uuid
from datetime import date, datetime, time
from pathlib import Path
from typing import Any


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dag-file", required=True)
    parser.add_argument("--dag-folder", required=True)
    args = parser.parse_args()

    dag_file = Path(args.dag_file).resolve()
    dag_folder = Path(args.dag_folder).resolve()

    try:
        payloads, strategy = _collect_payloads(dag_file=dag_file, dag_folder=dag_folder)
    except Exception as exc:  # pragma: no cover - exercised through parent process
        print(str(exc), file=sys.stderr)
        return 1

    hashes = {
        key: hashlib.md5(value.encode("utf-8"), usedforsecurity=False).hexdigest()
        for key, value in payloads.items()
    }
    print(json.dumps({"strategy": strategy, "payloads": payloads, "hashes": hashes}, sort_keys=True))
    return 0


def _collect_payloads(*, dag_file: Path, dag_folder: Path) -> tuple[dict[str, str], str]:
    try:
        payloads = _collect_airflow_payloads(dag_file=dag_file, dag_folder=dag_folder)
    except ImportError:
        payloads = {}

    if payloads:
        return payloads, "airflow"

    payloads = _collect_generic_payloads(dag_file=dag_file, dag_folder=dag_folder)
    return payloads, "generic"


def _collect_airflow_payloads(*, dag_file: Path, dag_folder: Path) -> dict[str, str]:
    from airflow.models import DagBag  # type: ignore[import-not-found]
    from airflow.serialization.serialized_objects import SerializedDAG  # type: ignore[import-not-found]

    dag_bag = DagBag(dag_folder=str(dag_folder), include_examples=False)
    matching_dags = [
        dag for dag in dag_bag.dags.values() if Path(str(getattr(dag, "fileloc", ""))).resolve() == dag_file
    ]
    if not matching_dags:
        if dag_bag.import_errors and str(dag_file) in dag_bag.import_errors:
            raise RuntimeError(dag_bag.import_errors[str(dag_file)])
        if dag_file.is_file() and dag_folder == dag_file:
            matching_dags = list(dag_bag.dags.values())

    payloads: dict[str, str] = {}
    for dag in matching_dags:
        serialized = SerializedDAG.to_dict(dag)
        payload = json.dumps(serialized, sort_keys=True, indent=2)
        dag_id = str(getattr(dag, "dag_id", dag_file.stem))
        payloads[dag_id] = payload
    return payloads


def _collect_generic_payloads(*, dag_file: Path, dag_folder: Path) -> dict[str, str]:
    sys.path.insert(0, str(dag_folder))
    try:
        module_name = f"_airflow_dag_audit_{uuid.uuid4().hex}"
        spec = importlib.util.spec_from_file_location(module_name, dag_file)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot create a module spec for {dag_file}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)

    payloads: dict[str, str] = {}
    for name, value in vars(module).items():
        if name.startswith("_"):
            continue
        if inspect.ismodule(value) or inspect.isfunction(value) or inspect.isclass(value):
            continue
        key = _candidate_key(name=name, value=value)
        if key is None:
            continue
        normalized = _normalize(value, seen=set())
        payloads[key] = json.dumps(normalized, sort_keys=True, indent=2)

    if not payloads:
        raise RuntimeError(f"No DAG-like objects were found in {dag_file}")
    return payloads


def _candidate_key(*, name: str, value: object) -> str | None:
    if hasattr(value, "dag_id"):
        dag_id = getattr(value, "dag_id")
        return str(dag_id)
    if getattr(value, "__dag_audit_hash__", False):
        return name
    if name.lower().endswith("dag"):
        return name
    return None


def _normalize(value: object, *, seen: set[int]) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(key): _normalize(item, seen=seen) for key, item in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [_normalize(item, seen=seen) for item in value]
    if isinstance(value, (set, frozenset)):
        normalized_items = [_normalize(item, seen=seen) for item in value]
        return sorted(normalized_items, key=lambda item: json.dumps(item, sort_keys=True))
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return _normalize(dataclasses.asdict(value), seen=seen)

    value_id = id(value)
    if value_id in seen:
        return "<cycle>"
    seen.add(value_id)
    try:
        if hasattr(value, "to_dict") and callable(getattr(value, "to_dict")):
            try:
                return _normalize(value.to_dict(), seen=seen)  # type: ignore[misc]
            except TypeError:
                pass

        if hasattr(value, "__dict__"):
            data = {}
            for key, item in vars(value).items():
                if key.startswith("_"):
                    continue
                if isinstance(item, types.ModuleType) or inspect.isfunction(item) or inspect.ismethod(item):
                    continue
                data[key] = _normalize(item, seen=seen)
            if data:
                return data

        return repr(value)
    finally:
        seen.discard(value_id)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
