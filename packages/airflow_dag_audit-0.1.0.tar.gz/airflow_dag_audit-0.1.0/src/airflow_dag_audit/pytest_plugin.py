from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from airflow_dag_audit.config import ProjectConfig, load_project_config
from airflow_dag_audit.discovery import infer_dag_folder
from airflow_dag_audit.models import DagAuditConfig


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("airflow-dag-audit")
    group.addoption("--airflow-dag-file", action="append", default=[], help="DAG file to audit")
    group.addoption("--airflow-dag-folder", action="store", default=None, help="Explicit DAG folder")
    group.addoption("--airflow-dag-config", action="store", default=None, help="Path to pyproject.toml")
    group.addoption("--airflow-dag-max-imports", action="store", type=int, default=None)
    group.addoption("--airflow-dag-max-variable-gets", action="store", type=int, default=None)
    group.addoption("--airflow-dag-max-sql-queries", action="store", type=int, default=None)
    group.addoption("--airflow-dag-max-top-level-calls", action="store", type=int, default=None)
    group.addoption(
        "--airflow-dag-require-stable-hash",
        action="store_true",
        default=None,
        help="Require a stable serialization hash across reparses",
    )

    parser.addini("airflow_dag_audit_dag_files", "DAG files to audit", type="linelist")
    parser.addini("airflow_dag_audit_dag_folder", "DAG folder to use during audit", default="")
    parser.addini("airflow_dag_audit_max_imports", "Default maximum import count", default="")
    parser.addini(
        "airflow_dag_audit_max_variable_gets",
        "Default maximum Variable.get count",
        default="",
    )
    parser.addini("airflow_dag_audit_max_sql_queries", "Default maximum SQL query count", default="")
    parser.addini(
        "airflow_dag_audit_max_top_level_calls",
        "Default maximum top-level call count",
        default="",
    )
    parser.addini(
        "airflow_dag_audit_require_stable_hash",
        "Whether to require a stable hash by default",
        default="",
    )


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "airflow_dag_budget(max_imports=None, max_variable_gets=None, max_sql_queries=None, max_top_level_calls=None, require_stable_hash=None, dag_folder=None): override DAG audit defaults for a single test",
    )


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    if "dag_file" not in metafunc.fixturenames:
        return

    project_config = _load_project_config(metafunc.config)
    option_paths = [Path(item) for item in metafunc.config.getoption("--airflow-dag-file")]
    ini_paths = [Path(item) for item in metafunc.config.getini("airflow_dag_audit_dag_files")]
    configured_paths = project_config.iter_configured_files() if isinstance(project_config, ProjectConfig) else []
    dag_files = option_paths or configured_paths or ini_paths
    if not dag_files:
        raise pytest.UsageError(
            "No DAG files were configured. Use --airflow-dag-file, [tool.airflow-dag-audit], or the airflow_dag_audit_dag_files ini option."
        )

    metafunc.parametrize("dag_file", dag_files, ids=[Path(path).name for path in dag_files])


@pytest.fixture
def dag_audit_config(request: pytest.FixtureRequest, pytestconfig: pytest.Config, dag_file: Path) -> DagAuditConfig:
    marker = request.node.get_closest_marker("airflow_dag_budget")
    overrides = marker.kwargs if marker else {}
    project_config = _load_project_config(pytestconfig)
    base = project_config.resolve_for_dag_file(dag_file) if isinstance(project_config, ProjectConfig) else DagAuditConfig()

    dag_folder_value = _pick(
        overrides.get("dag_folder"),
        pytestconfig.getoption("--airflow-dag-folder"),
        pytestconfig.getini("airflow_dag_audit_dag_folder") or None,
        base.dag_folder,
    )
    dag_folder = Path(dag_folder_value) if dag_folder_value else infer_dag_folder(Path(dag_file))

    return DagAuditConfig(
        max_imports=_as_int(
            _pick(
                overrides.get("max_imports"),
                pytestconfig.getoption("--airflow-dag-max-imports"),
                pytestconfig.getini("airflow_dag_audit_max_imports") or None,
                base.max_imports,
            )
        ),
        max_import_froms=base.max_import_froms,
        max_variable_gets=_as_int(
            _pick(
                overrides.get("max_variable_gets"),
                pytestconfig.getoption("--airflow-dag-max-variable-gets"),
                pytestconfig.getini("airflow_dag_audit_max_variable_gets") or None,
                base.max_variable_gets,
            )
        ),
        max_connection_gets=base.max_connection_gets,
        max_sql_queries=_as_int(
            _pick(
                overrides.get("max_sql_queries"),
                pytestconfig.getoption("--airflow-dag-max-sql-queries"),
                pytestconfig.getini("airflow_dag_audit_max_sql_queries") or None,
                base.max_sql_queries,
            )
        ),
        max_operators=base.max_operators,
        max_tasks=base.max_tasks,
        max_top_level_calls=_as_int(
            _pick(
                overrides.get("max_top_level_calls"),
                pytestconfig.getoption("--airflow-dag-max-top-level-calls"),
                pytestconfig.getini("airflow_dag_audit_max_top_level_calls") or None,
                base.max_top_level_calls,
            )
        ),
        require_stable_hash=_as_bool(
            _pick(
                overrides.get("require_stable_hash"),
                pytestconfig.getoption("--airflow-dag-require-stable-hash"),
                pytestconfig.getini("airflow_dag_audit_require_stable_hash"),
                base.require_stable_hash,
            )
        ),
        hash_parse_repeats=base.hash_parse_repeats,
        dag_folder=dag_folder,
        disabled=base.disabled,
    )


def _load_project_config(config: pytest.Config) -> ProjectConfig | None:
    config_path = config.getoption("--airflow-dag-config")
    start_path = config.rootpath
    return load_project_config(start_path, config_path=config_path)


def _pick(*values: object) -> object:
    for value in values:
        if value is not None and value != "":
            return value
    return None


def _as_int(value: object) -> int | None:
    if value is None or value == "":
        return None
    return int(value)


def _as_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "on"}
