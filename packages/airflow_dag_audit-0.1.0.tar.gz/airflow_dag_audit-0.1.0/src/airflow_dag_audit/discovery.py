from __future__ import annotations

from pathlib import Path


DAG_FILE_SUFFIXES = {".py"}


def iter_dag_files(path: Path) -> list[Path]:
    path = path.resolve()
    if path.is_file():
        return [path]
    return sorted(file for file in path.rglob("*.py") if file.is_file())


def infer_dag_folder(dag_file: Path) -> Path:
    dag_file = dag_file.resolve()

    for parent in dag_file.parents:
        if parent.name == "dags":
            return parent

    package_root: Path | None = None
    cursor = dag_file.parent
    while (cursor / "__init__.py").exists():
        package_root = cursor
        if cursor.parent == cursor:
            break
        cursor = cursor.parent

    if package_root is not None:
        return package_root.parent

    return dag_file.parent
