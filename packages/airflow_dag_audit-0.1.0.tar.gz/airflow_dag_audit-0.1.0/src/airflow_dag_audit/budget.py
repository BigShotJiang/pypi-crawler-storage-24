from __future__ import annotations

from pathlib import Path

from airflow_dag_audit.discovery import infer_dag_folder
from airflow_dag_audit.hashing import HashAuditError, check_stable_hash
from airflow_dag_audit.models import DagAuditConfig, DagAuditResult, DagBudgetExceeded
from airflow_dag_audit.static_analysis import collect_static_metrics


def audit_dag_file(dag_file: str | Path, config: DagAuditConfig | None = None) -> DagAuditResult:
    dag_path = Path(dag_file).resolve()
    cfg = config or DagAuditConfig()
    dag_folder = (cfg.dag_folder or infer_dag_folder(dag_path)).resolve()

    metrics = collect_static_metrics(dag_path)
    failures: list[str] = []
    warnings: list[str] = []

    if cfg.disabled:
        warnings.append("budget checks disabled for this DAG")

    _check_limit(failures=failures, label="import_count", actual=metrics.import_count, limit=cfg.max_imports)
    _check_limit(
        failures=failures,
        label="import_from_count",
        actual=metrics.import_from_count,
        limit=cfg.max_import_froms,
    )
    _check_limit(
        failures=failures,
        label="variable_get_count",
        actual=metrics.variable_get_count,
        limit=cfg.max_variable_gets,
    )
    _check_limit(
        failures=failures,
        label="connection_get_count",
        actual=metrics.connection_get_count,
        limit=cfg.max_connection_gets,
    )
    _check_limit(failures=failures, label="sql_query_count", actual=metrics.sql_query_count, limit=cfg.max_sql_queries)
    _check_limit(failures=failures, label="operator_count", actual=metrics.operator_count, limit=cfg.max_operators)
    _check_limit(failures=failures, label="task_count", actual=metrics.task_count, limit=cfg.max_tasks)
    _check_limit(
        failures=failures,
        label="top_level_call_count",
        actual=metrics.top_level_call_count,
        limit=cfg.max_top_level_calls,
    )

    hash_result = None
    if cfg.require_stable_hash:
        try:
            hash_result = check_stable_hash(dag_path, dag_folder=dag_folder, repeats=cfg.hash_parse_repeats)
        except HashAuditError as exc:
            failures.append(f"stable_hash: could not evaluate hash stability ({exc})")
        else:
            if not hash_result.stable:
                failures.append("stable_hash: DAG serialization changed between parses")

    if not cfg.require_stable_hash:
        warnings.append("stable_hash check disabled")

    return DagAuditResult(
        dag_file=dag_path,
        dag_folder=dag_folder,
        metrics=metrics,
        hash_result=hash_result,
        failures=failures,
        warnings=warnings,
    )


def assert_dag_budget(dag_file: str | Path, config: DagAuditConfig | None = None) -> DagAuditResult:
    result = audit_dag_file(dag_file, config=config)
    if result.failures:
        message = _format_failure_message(result)
        raise DagBudgetExceeded(message)
    return result


def _check_limit(*, failures: list[str], label: str, actual: int, limit: int | None) -> None:
    if limit is None:
        return
    if actual > limit:
        failures.append(f"{label}: expected <= {limit}, got {actual}")


def _format_failure_message(result: DagAuditResult) -> str:
    lines = [f"DAG audit failed for {result.dag_file}"]
    lines.extend(f"- {failure}" for failure in result.failures)
    if result.hash_result and result.hash_result.diff:
        lines.append("")
        lines.append(result.hash_result.diff)
    return "\n".join(lines)
