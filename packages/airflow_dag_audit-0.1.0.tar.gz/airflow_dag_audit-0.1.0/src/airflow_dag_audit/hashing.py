from __future__ import annotations

import difflib
import json
import subprocess
import sys
from pathlib import Path

from airflow_dag_audit.discovery import infer_dag_folder
from airflow_dag_audit.models import HashAuditResult


class HashAuditError(RuntimeError):
    """Raised when the hash worker cannot parse or serialize a DAG file."""


def check_stable_hash(dag_file: Path, dag_folder: Path | None = None, repeats: int = 2) -> HashAuditResult:
    dag_file = dag_file.resolve()
    resolved_folder = (dag_folder or infer_dag_folder(dag_file)).resolve()

    if repeats < 2:
        raise ValueError("repeats must be >= 2")

    first = _run_hash_worker(dag_file=dag_file, dag_folder=resolved_folder)
    last = first
    for _ in range(repeats - 1):
        last = _run_hash_worker(dag_file=dag_file, dag_folder=resolved_folder)
    second = last

    left = json.dumps(first["payloads"], sort_keys=True, indent=2).splitlines(True)
    right = json.dumps(second["payloads"], sort_keys=True, indent=2).splitlines(True)
    diff = "".join(difflib.unified_diff(left, right, fromfile="first", tofile="second"))
    stable = first["hashes"] == second["hashes"] and not diff

    return HashAuditResult(
        stable=stable,
        first_hashes=dict(first["hashes"]),
        second_hashes=dict(second["hashes"]),
        diff=diff,
        strategy=str(first["strategy"]),
    )


def _run_hash_worker(*, dag_file: Path, dag_folder: Path) -> dict[str, object]:
    cmd = [
        sys.executable,
        "-m",
        "airflow_dag_audit._hash_worker",
        "--dag-file",
        str(dag_file),
        "--dag-folder",
        str(dag_folder),
    ]
    process = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if process.returncode != 0:
        stderr = process.stderr.strip()
        stdout = process.stdout.strip()
        detail = stderr or stdout or "hash worker failed without output"
        raise HashAuditError(detail)
    return json.loads(process.stdout)
