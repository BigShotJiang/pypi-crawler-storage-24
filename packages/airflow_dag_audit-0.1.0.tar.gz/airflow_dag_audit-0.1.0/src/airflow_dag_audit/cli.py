from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from airflow_dag_audit.budget import assert_dag_budget, audit_dag_file
from airflow_dag_audit.config import load_project_config
from airflow_dag_audit.discovery import iter_dag_files
from airflow_dag_audit.hashing import check_stable_hash
from airflow_dag_audit.models import DagAuditConfig, DagAuditResult, DagBudgetExceeded

app = typer.Typer(no_args_is_help=True, help="Static budget checks for DAG files.")
console = Console()


@app.callback()
def main() -> None:
    """Audit DAG files from the command line."""


@app.command("scan")
def scan_command(
    path: Annotated[Path | None, typer.Argument(help="DAG file or directory to scan", exists=False)] = None,
    config: Annotated[Path | None, typer.Option(help="Path to pyproject.toml")] = None,
    dag_folder: Annotated[
        Path | None,
        typer.Option(help="Explicit DAG folder. Useful when a single file depends on sibling modules."),
    ] = None,
    max_imports: Annotated[int | None, typer.Option(help="Maximum allowed import count")] = None,
    max_variable_gets: Annotated[
        int | None, typer.Option(help="Maximum allowed Airflow Variable.get() calls")
    ] = None,
    max_sql_queries: Annotated[int | None, typer.Option(help="Maximum allowed SQL-like string literals")] = None,
    max_top_level_calls: Annotated[
        int | None, typer.Option(help="Maximum allowed top-level call expressions")
    ] = None,
    require_stable_hash: Annotated[
        bool | None,
        typer.Option(
            "--require-stable-hash/--no-require-stable-hash",
            help="Check whether reparsing produces the same serialized hash.",
        ),
    ] = None,
    output_json: Annotated[bool, typer.Option("--json", help="Emit JSON instead of a rich table")] = False,
) -> None:
    project_config = load_project_config(path or Path.cwd(), config_path=config)
    dag_files = _resolve_dag_files(path=path, project_config=project_config)
    results = [audit_dag_file(item, config=_config_for_cli(item, project_config=project_config, dag_folder=dag_folder, max_imports=max_imports, max_variable_gets=max_variable_gets, max_sql_queries=max_sql_queries, max_top_level_calls=max_top_level_calls, require_stable_hash=require_stable_hash)) for item in dag_files]

    if output_json:
        console.print_json(json.dumps([result.as_dict() for result in results]))
        return

    for result in results:
        _print_result_table(result)

    failures = sum(1 for result in results if not result.ok)
    emoji = "✅" if failures == 0 else "⚠️"
    style = "green" if failures == 0 else "yellow"
    console.print(Panel.fit(f"{emoji} scanned {len(results)} file(s), failures: {failures}", style=style))


@app.command("assert")
def assert_command(
    path: Annotated[Path | None, typer.Argument(help="DAG file or directory to check", exists=False)] = None,
    config: Annotated[Path | None, typer.Option(help="Path to pyproject.toml")] = None,
    dag_folder: Annotated[
        Path | None,
        typer.Option(help="Explicit DAG folder. Useful when a single file depends on sibling modules."),
    ] = None,
    max_imports: Annotated[int | None, typer.Option(help="Maximum allowed import count")] = None,
    max_variable_gets: Annotated[
        int | None, typer.Option(help="Maximum allowed Airflow Variable.get() calls")
    ] = None,
    max_sql_queries: Annotated[int | None, typer.Option(help="Maximum allowed SQL-like string literals")] = None,
    max_top_level_calls: Annotated[
        int | None, typer.Option(help="Maximum allowed top-level call expressions")
    ] = None,
    require_stable_hash: Annotated[
        bool | None,
        typer.Option(
            "--require-stable-hash/--no-require-stable-hash",
            help="Check whether reparsing produces the same serialized hash.",
        ),
    ] = None,
) -> None:
    project_config = load_project_config(path or Path.cwd(), config_path=config)
    dag_files = _resolve_dag_files(path=path, project_config=project_config)

    errors: list[str] = []
    for dag_file in dag_files:
        cfg = _config_for_cli(dag_file, project_config=project_config, dag_folder=dag_folder, max_imports=max_imports, max_variable_gets=max_variable_gets, max_sql_queries=max_sql_queries, max_top_level_calls=max_top_level_calls, require_stable_hash=require_stable_hash)
        try:
            result = assert_dag_budget(dag_file, config=cfg)
        except DagBudgetExceeded as exc:
            console.print(Panel.fit(f"❌ {dag_file.name}", style="red"))
            console.print(str(exc))
            errors.append(str(exc))
        else:
            console.print(Panel.fit(f"✅ {result.dag_file.name}", style="green"))
            _print_result_table(result)

    if errors:
        raise typer.Exit(code=1)


@app.command("hash")
def hash_command(
    dag_file: Annotated[Path, typer.Argument(help="A single DAG file to hash twice")],
    dag_folder: Annotated[
        Path | None,
        typer.Option(help="Explicit DAG folder. Useful when a single file depends on sibling modules."),
    ] = None,
    repeats: Annotated[int, typer.Option(help="Number of parse attempts to compare")] = 2,
    show_diff: Annotated[bool, typer.Option(help="Print the serialization diff when hashes differ")] = False,
) -> None:
    result = check_stable_hash(dag_file, dag_folder=dag_folder, repeats=repeats)
    if result.stable:
        console.print(Panel.fit("✅ hash is stable across reparses", style="green"))
    else:
        console.print(Panel.fit("❌ hash changed across reparses", style="red"))
        if show_diff and result.diff:
            console.print(result.diff)
        raise typer.Exit(code=1)

    table = Table(title=f"Hash summary for {dag_file.name}")
    table.add_column("DAG")
    table.add_column("Hash")
    for dag_id, hash_value in result.first_hashes.items():
        table.add_row(dag_id, hash_value)
    console.print(table)


def _config_for_cli(
    dag_file: Path,
    *,
    project_config: object,
    dag_folder: Path | None,
    max_imports: int | None,
    max_variable_gets: int | None,
    max_sql_queries: int | None,
    max_top_level_calls: int | None,
    require_stable_hash: bool | None,
) -> DagAuditConfig:
    if project_config is not None:
        from airflow_dag_audit.config import ProjectConfig

        if isinstance(project_config, ProjectConfig):
            cfg = project_config.resolve_for_dag_file(dag_file)
        else:
            cfg = DagAuditConfig()
    else:
        cfg = DagAuditConfig()

    return DagAuditConfig(
        max_imports=max_imports if max_imports is not None else cfg.max_imports,
        max_import_froms=cfg.max_import_froms,
        max_variable_gets=max_variable_gets if max_variable_gets is not None else cfg.max_variable_gets,
        max_connection_gets=cfg.max_connection_gets,
        max_sql_queries=max_sql_queries if max_sql_queries is not None else cfg.max_sql_queries,
        max_operators=cfg.max_operators,
        max_tasks=cfg.max_tasks,
        max_top_level_calls=max_top_level_calls if max_top_level_calls is not None else cfg.max_top_level_calls,
        require_stable_hash=require_stable_hash if require_stable_hash is not None else cfg.require_stable_hash,
        hash_parse_repeats=cfg.hash_parse_repeats,
        dag_folder=dag_folder if dag_folder is not None else cfg.dag_folder,
        disabled=cfg.disabled,
    )


def _resolve_dag_files(path: Path | None, *, project_config: object) -> list[Path]:
    from airflow_dag_audit.config import ProjectConfig

    if path is not None:
        return iter_dag_files(path)
    if isinstance(project_config, ProjectConfig):
        files = project_config.iter_configured_files()
        if files:
            return files
    raise typer.BadParameter("No DAG path was given and no [tool.airflow-dag-audit] dag_folder/files configuration was found.")


def _print_result_table(result: DagAuditResult) -> None:
    table = Table(title=str(result.dag_file))
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    for key, value in result.metrics.as_dict().items():
        table.add_row(key, str(value))

    if result.hash_result is not None:
        table.add_row("stable_hash", "yes" if result.hash_result.stable else "no")
        table.add_row("hash_strategy", result.hash_result.strategy)

    if result.failures:
        emoji = "❌"
        style = "red"
    else:
        emoji = "✅"
        style = "green"

    console.print(table)
    message = "\n".join(result.failures) if result.failures else "within budget"
    console.print(Panel.fit(f"{emoji} {message}", style=style))
