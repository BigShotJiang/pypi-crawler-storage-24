from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path


@dataclass(frozen=True)
class DagAuditConfig:
    max_imports: int | None = None
    max_import_froms: int | None = None
    max_variable_gets: int | None = None
    max_connection_gets: int | None = None
    max_sql_queries: int | None = None
    max_operators: int | None = None
    max_tasks: int | None = None
    max_top_level_calls: int | None = None
    require_stable_hash: bool = False
    hash_parse_repeats: int = 2
    dag_folder: Path | None = None
    disabled: bool = False

    def with_dag_folder(self, dag_folder: Path | None) -> "DagAuditConfig":
        return replace(self, dag_folder=dag_folder)


@dataclass(frozen=True)
class DagStaticMetrics:
    import_count: int = 0
    import_from_count: int = 0
    variable_get_count: int = 0
    connection_get_count: int = 0
    sql_query_count: int = 0
    operator_count: int = 0
    task_count: int = 0
    top_level_call_count: int = 0
    detected_dag_decorators: int = 0

    def as_dict(self) -> dict[str, int]:
        return {
            "import_count": self.import_count,
            "import_from_count": self.import_from_count,
            "variable_get_count": self.variable_get_count,
            "connection_get_count": self.connection_get_count,
            "sql_query_count": self.sql_query_count,
            "operator_count": self.operator_count,
            "task_count": self.task_count,
            "top_level_call_count": self.top_level_call_count,
            "detected_dag_decorators": self.detected_dag_decorators,
        }


@dataclass(frozen=True)
class HashAuditResult:
    stable: bool
    first_hashes: dict[str, str]
    second_hashes: dict[str, str]
    diff: str = ""
    strategy: str = "unknown"


@dataclass(frozen=True)
class DagAuditResult:
    dag_file: Path
    dag_folder: Path
    metrics: DagStaticMetrics
    hash_result: HashAuditResult | None
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.failures

    def as_dict(self) -> dict[str, object]:
        return {
            "dag_file": str(self.dag_file),
            "dag_folder": str(self.dag_folder),
            "metrics": self.metrics.as_dict(),
            "hash_result": None
            if self.hash_result is None
            else {
                "stable": self.hash_result.stable,
                "first_hashes": self.hash_result.first_hashes,
                "second_hashes": self.hash_result.second_hashes,
                "strategy": self.hash_result.strategy,
                "diff": self.hash_result.diff,
            },
            "failures": self.failures,
            "warnings": self.warnings,
        }


class DagBudgetExceeded(AssertionError):
    """Raised when one or more configured DAG budget limits are exceeded."""
