from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from airflow_dag_audit.models import DagAuditConfig

try:  # pragma: no cover - exercised on Python < 3.11 only
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib


DEFAULT_INCLUDE = ["**/*.py"]
DEFAULT_EXCLUDE = ["**/__pycache__/**", "**/tests/**"]


@dataclass(frozen=True)
class ConfigOverride:
    match: str
    budget: dict[str, int | None] = field(default_factory=dict)
    disabled: bool = False
    reason: str | None = None
    check_hash_stability: bool | None = None
    hash_parse_repeats: int | None = None


@dataclass(frozen=True)
class ProjectConfig:
    project_root: Path
    config_path: Path
    dag_folder: Path | None = None
    include: tuple[str, ...] = tuple(DEFAULT_INCLUDE)
    exclude: tuple[str, ...] = tuple(DEFAULT_EXCLUDE)
    files: tuple[Path, ...] = ()
    dag_file_base_folder: Path | None = None
    check_hash_stability: bool = False
    hash_parse_repeats: int = 2
    budget: dict[str, int | None] = field(default_factory=dict)
    overrides: tuple[ConfigOverride, ...] = ()

    def iter_configured_files(self) -> list[Path]:
        if self.files:
            return [path.resolve() for path in self.files]
        if self.dag_folder is None:
            return []
        candidates: list[Path] = []
        for pattern in self.include:
            candidates.extend(self.dag_folder.glob(pattern))
        unique_candidates = sorted({path.resolve() for path in candidates if path.is_file() and path.suffix == ".py"})
        return [path for path in unique_candidates if not _is_excluded(path, root=self.project_root, patterns=self.exclude)]

    def resolve_for_dag_file(self, dag_file: str | Path) -> DagAuditConfig:
        dag_path = Path(dag_file).resolve()
        relative_path = _relative_posix_path(dag_path, root=self.project_root)
        budget = dict(self.budget)
        require_stable_hash = self.check_hash_stability
        hash_parse_repeats = self.hash_parse_repeats
        disabled = False

        for override in self.overrides:
            if Path(relative_path).match(override.match):
                budget.update({key: value for key, value in override.budget.items() if value is not None})
                if override.check_hash_stability is not None:
                    require_stable_hash = override.check_hash_stability
                if override.hash_parse_repeats is not None:
                    hash_parse_repeats = override.hash_parse_repeats
                if override.disabled:
                    disabled = True

        dag_folder = self.dag_file_base_folder or self.dag_folder
        return DagAuditConfig(
            max_imports=budget.get("imports"),
            max_import_froms=budget.get("import_froms"),
            max_variable_gets=budget.get("variable_get_calls"),
            max_connection_gets=budget.get("connection_get_calls"),
            max_sql_queries=budget.get("airflow_query_calls"),
            max_operators=budget.get("operators"),
            max_tasks=budget.get("tasks"),
            max_top_level_calls=budget.get("top_level_call_count"),
            require_stable_hash=require_stable_hash,
            hash_parse_repeats=hash_parse_repeats,
            dag_folder=dag_folder,
            disabled=disabled,
        )


def load_project_config(start_path: str | Path = ".", config_path: str | Path | None = None) -> ProjectConfig | None:
    if config_path is not None:
        resolved_config = Path(config_path).resolve()
    else:
        resolved_config = find_pyproject(start_path)
        if resolved_config is None:
            return None

    document = tomllib.loads(resolved_config.read_text(encoding="utf-8"))
    tool_config = document.get("tool", {}).get("airflow-dag-audit")
    if not isinstance(tool_config, dict):
        return None

    project_root = resolved_config.parent.resolve()
    dag_folder_value = _optional_path(tool_config.get("dag_folder"), root=project_root)
    dag_file_base_folder = _optional_path(tool_config.get("dag_file_base_folder"), root=project_root)
    files = tuple(_coerce_paths(tool_config.get("files"), root=project_root))
    include = tuple(_coerce_strings(tool_config.get("include"), DEFAULT_INCLUDE))
    exclude = tuple(_coerce_strings(tool_config.get("exclude"), DEFAULT_EXCLUDE))
    budget = _parse_budget(tool_config.get("budget"))
    overrides = tuple(_parse_override(item) for item in tool_config.get("overrides", []))

    return ProjectConfig(
        project_root=project_root,
        config_path=resolved_config,
        dag_folder=dag_folder_value,
        include=include,
        exclude=exclude,
        files=files,
        dag_file_base_folder=dag_file_base_folder,
        check_hash_stability=bool(tool_config.get("check_hash_stability", False)),
        hash_parse_repeats=int(tool_config.get("hash_parse_repeats", 2)),
        budget=budget,
        overrides=overrides,
    )


def find_pyproject(start_path: str | Path = ".") -> Path | None:
    start = Path(start_path).resolve()
    cursor = start if start.is_dir() else start.parent
    for directory in [cursor, *cursor.parents]:
        candidate = directory / "pyproject.toml"
        if candidate.exists():
            return candidate
    return None


def _parse_override(raw: object) -> ConfigOverride:
    if not isinstance(raw, dict):
        raise TypeError("Each override entry must be a table")
    match = str(raw["match"])
    return ConfigOverride(
        match=match,
        budget=_parse_budget(raw.get("budget")),
        disabled=bool(raw.get("disabled", False)),
        reason=_optional_string(raw.get("reason")),
        check_hash_stability=_optional_bool(raw.get("check_hash_stability")),
        hash_parse_repeats=_optional_int(raw.get("hash_parse_repeats")),
    )


def _parse_budget(raw: object) -> dict[str, int | None]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise TypeError("budget must be a table")

    allowed_keys = {
        "imports",
        "import_froms",
        "variable_get_calls",
        "connection_get_calls",
        "airflow_query_calls",
        "operators",
        "tasks",
        "top_level_call_count",
    }
    unknown_keys = set(raw) - allowed_keys
    if unknown_keys:
        available = ", ".join(sorted(allowed_keys))
        unknown = ", ".join(sorted(unknown_keys))
        raise ValueError(f"Unknown budget keys: {unknown}. Allowed keys: {available}")

    return {str(key): int(value) for key, value in raw.items()}


def _coerce_strings(raw: object, default: list[str]) -> list[str]:
    if raw is None:
        return list(default)
    if not isinstance(raw, list):
        raise TypeError("Expected a list of strings")
    return [str(item) for item in raw]


def _coerce_paths(raw: object, *, root: Path) -> list[Path]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise TypeError("Expected a list of file paths")
    return [(root / str(item)).resolve() for item in raw]


def _optional_path(raw: object, *, root: Path) -> Path | None:
    if raw is None or raw == "":
        return None
    return (root / str(raw)).resolve()


def _optional_string(raw: object) -> str | None:
    if raw is None or raw == "":
        return None
    return str(raw)


def _optional_bool(raw: object) -> bool | None:
    if raw is None:
        return None
    return bool(raw)


def _optional_int(raw: object) -> int | None:
    if raw is None or raw == "":
        return None
    return int(raw)


def _is_excluded(path: Path, *, root: Path, patterns: tuple[str, ...]) -> bool:
    relative_path = _relative_posix_path(path.resolve(), root=root)
    relative = Path(relative_path)
    return any(relative.match(pattern) for pattern in patterns)


def _relative_posix_path(path: Path, *, root: Path) -> str:
    try:
        relative = path.resolve().relative_to(root.resolve())
    except ValueError:
        return path.resolve().as_posix()
    return relative.as_posix()
