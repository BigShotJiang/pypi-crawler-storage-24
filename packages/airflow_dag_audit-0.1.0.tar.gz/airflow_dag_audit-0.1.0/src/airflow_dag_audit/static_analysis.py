from __future__ import annotations

import ast
import re
from pathlib import Path

from airflow_dag_audit.models import DagStaticMetrics

_SQL_PATTERN = re.compile(
    r"\b(select|insert|update|delete|merge|create\s+table|drop\s+table|with\s+)\b",
    re.IGNORECASE,
)
_OPERATOR_NAME_PATTERN = re.compile(r"[A-Z][A-Za-z0-9]+Operator$")


class _DagAstVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.import_count = 0
        self.import_from_count = 0
        self.variable_get_count = 0
        self.connection_get_count = 0
        self.sql_query_count = 0
        self.operator_count = 0
        self.task_count = 0
        self.top_level_call_count = 0
        self.detected_dag_decorators = 0
        self._stack: list[ast.AST] = []

    def visit(self, node: ast.AST) -> None:  # type: ignore[override]
        self._stack.append(node)
        try:
            super().visit(node)
        finally:
            self._stack.pop()

    @property
    def _parent(self) -> ast.AST | None:
        if len(self._stack) < 2:
            return None
        return self._stack[-2]

    def visit_Import(self, node: ast.Import) -> None:
        self.import_count += len(node.names)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        self.import_count += len(node.names)
        self.import_from_count += len(node.names)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if self._is_top_level_expression_call(node):
            self.top_level_call_count += 1
        if self._is_variable_get_call(node):
            self.variable_get_count += 1
        if self._is_connection_get_call(node):
            self.connection_get_count += 1
        if self._is_dag_decorator_call(node):
            self.detected_dag_decorators += 1
        if self._is_operator_call(node):
            self.operator_count += 1
            self.task_count += 1
        self.generic_visit(node)

    def visit_Constant(self, node: ast.Constant) -> None:
        if isinstance(node.value, str) and _SQL_PATTERN.search(node.value):
            self.sql_query_count += 1
        self.generic_visit(node)

    def _is_top_level_expression_call(self, node: ast.Call) -> bool:
        parent = self._parent
        grandparent = self._stack[-3] if len(self._stack) >= 3 else None
        if not isinstance(parent, (ast.Expr, ast.Assign, ast.AnnAssign, ast.AugAssign)):
            return False
        if not isinstance(grandparent, ast.Module):
            return False
        blocked = (
            ast.FunctionDef,
            ast.AsyncFunctionDef,
            ast.ClassDef,
            ast.Lambda,
            ast.ListComp,
            ast.SetComp,
            ast.DictComp,
            ast.GeneratorExp,
        )
        return not any(isinstance(ancestor, blocked) for ancestor in self._stack[:-1])

    @staticmethod
    def _is_variable_get_call(node: ast.Call) -> bool:
        func = node.func
        return (
            isinstance(func, ast.Attribute)
            and func.attr == "get"
            and isinstance(func.value, ast.Name)
            and func.value.id == "Variable"
        )

    @staticmethod
    def _is_connection_get_call(node: ast.Call) -> bool:
        func = node.func
        if not isinstance(func, ast.Attribute):
            return False
        if func.attr not in {"get_connection", "get_connection_from_secrets"}:
            return False
        value = func.value
        return isinstance(value, ast.Name) and value.id in {"BaseHook", "Connection"}

    @staticmethod
    def _is_dag_decorator_call(node: ast.Call) -> bool:
        func = node.func
        if isinstance(func, ast.Name):
            return func.id == "dag"
        return isinstance(func, ast.Attribute) and func.attr == "dag"

    @staticmethod
    def _is_operator_call(node: ast.Call) -> bool:
        func = node.func
        if isinstance(func, ast.Name):
            return bool(_OPERATOR_NAME_PATTERN.match(func.id))
        if isinstance(func, ast.Attribute):
            return bool(_OPERATOR_NAME_PATTERN.match(func.attr))
        return False


def collect_static_metrics(dag_file: Path) -> DagStaticMetrics:
    tree = ast.parse(dag_file.read_text(encoding="utf-8"), filename=str(dag_file))
    visitor = _DagAstVisitor()
    visitor.visit(tree)
    return DagStaticMetrics(
        import_count=visitor.import_count,
        import_from_count=visitor.import_from_count,
        variable_get_count=visitor.variable_get_count,
        connection_get_count=visitor.connection_get_count,
        sql_query_count=visitor.sql_query_count,
        operator_count=visitor.operator_count,
        task_count=visitor.task_count,
        top_level_call_count=visitor.top_level_call_count,
        detected_dag_decorators=visitor.detected_dag_decorators,
    )
