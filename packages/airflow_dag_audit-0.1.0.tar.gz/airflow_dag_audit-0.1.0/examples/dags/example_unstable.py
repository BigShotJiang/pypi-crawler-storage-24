class DynamicRepr:
    def __repr__(self) -> str:
        return f"DynamicRepr(id={id(self)})"


class ExampleDag:
    def __init__(self) -> None:
        self.dag_id = "example_unstable"
        self.node = DynamicRepr()


unstable_dag = ExampleDag()
