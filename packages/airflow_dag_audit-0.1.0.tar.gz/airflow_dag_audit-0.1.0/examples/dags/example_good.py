from dataclasses import dataclass


@dataclass
class ExampleDag:
    dag_id: str
    sql: str
    variable_name: str


good_dag = ExampleDag(
    dag_id="example_good",
    sql="SELECT 1",
    variable_name="demo",
)
