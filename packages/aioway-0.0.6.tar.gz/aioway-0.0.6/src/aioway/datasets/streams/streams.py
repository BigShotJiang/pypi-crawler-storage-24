# Copyright (c) AIoWay Authors - All Rights Reserved

"The ``Stream`` interfaces live here."

import abc
import dataclasses as dcls
import functools
import typing
from abc import ABC
from collections.abc import Iterator
from typing import ClassVar, Self

from aioway._exprs import Expr, OpSign
from aioway.attrs import AttrSet
from aioway.chunks import Chunk

from ..datasets import Dataset, DatasetViewTypes

__all__ = ["Stream", "StreamState", "Stream", "Stream", "Stream"]


@dcls.dataclass
class StreamState:
    """
    The mutable stream state.

    This is created because ``Stream`` subclasses from a frozen ``dataclass``,
    so the stream state is created to manage mutable parts of the ``Stream``.

    Subclasses of ``Stream`` should also subclass from ``StreamState``.
    """

    idx: int = 0
    "How many steps have been called."

    def step(self):
        self.idx += 1

    @property
    def started(self) -> bool:
        """
        Shortcut function to check if ``self.idx == 0``.
        """

        return self.idx != 0


@dcls.dataclass(frozen=True)
class Stream(Expr[Chunk], Iterator[Chunk], Dataset, ABC):
    """
    ``Stream`` produces a stream of batches of data, in the form of ``TensorDict``s,
    everytime ``__next__`` is called on it, a ``TensorDict`` is yielded.

    ``Stream`` is a stateful operation, compared to the previous implementations,
    it is an external iterator, supporting state inspection, simplifying debugging.
    """

    _SIGNATURE: ClassVar[OpSign]
    "The signature of the current class."

    __match_args__: ClassVar[tuple[str, ...]]
    """
    A ``Stream`` should be able to be decomposed with ``match`` statements.
    """

    @typing.override
    def __iter__(self) -> Self:
        """
        ``__iter__`` allows ``Stream``s to be used in ``for`` loops.

        As it returns ``self``, re-use carefully.
        """

        return self

    @typing.final
    @typing.override
    def __next__(self) -> Chunk:
        """
        ``__next__`` allows ``Stream``s to be used in ``for`` loops.
        """

        if (result := self.compute()).attrs != self.attrs:
            raise TypeError(f"Schema mismatch: {result.attrs=}, {self.attrs=}.")

        self.state.step()
        return result

    @property
    @abc.abstractmethod
    def size(self) -> int:
        """
        The length of the current ``Stream``.
        Does not change when the ``Stream`` is being iterated over.
        """

        ...

    @property
    @abc.abstractmethod
    def attrs(self) -> AttrSet:
        """
        The schema for the current ``Stream``.
        """

        ...

    @abc.abstractmethod
    def _compute(self) -> Chunk:
        """
        Compute the next batch (a ``Chunk``).

        An exception raised here would be translated to ``StopIteration``.

        Note:

            The name ``read`` is inspired by the original release of clickhouse.
            I think this is a great name for a as a method on ``Stream`` to poll data,
            giving it a natural feeling like how we normally work with files.

        """

        ...

    @abc.abstractmethod
    def _inputs(self) -> tuple[Stream, ...]:
        """
        ``Stream``'s children, the dependent ``Stream``s that would also be evaluated
        when calling ``__next__`` on the current ``Stream``.
        """

        ...

    @functools.cached_property
    def state(self) -> StreamState:
        """
        The state of the stream. Should be a field, but a ``cached_property``,
        because if it has a default value it would make subclassing difficult.
        """
        return StreamState()

    @property
    def idx(self) -> int:
        """
        The number of batches completed..
        """

        return self.state.idx

    @property
    def started(self) -> bool:
        """
        Shortcut function to check if ``self.idx == 0``.
        """

        return self.state.started

    @classmethod
    @typing.override
    def view_types(cls):
        from .views import StreamColumnView, StreamSelectView

        return DatasetViewTypes(column=StreamColumnView, select=StreamSelectView)

    def _return_type(self):
        return Chunk
