from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from typing_extensions import override

from usethis._file.pyproject_toml.errors import (
    PyprojectTOMLDecodeError,
    PyprojectTOMLNotFoundError,
    PyprojectTOMLValueAlreadySetError,
    PyprojectTOMLValueMissingError,
    UnexpectedPyprojectTOMLIOError,
    UnexpectedPyprojectTOMLOpenError,
)
from usethis._file.toml.errors import (
    TOMLDecodeError,
    TOMLNotFoundError,
    TOMLValueAlreadySetError,
    TOMLValueMissingError,
    UnexpectedTOMLIOError,
    UnexpectedTOMLOpenError,
)
from usethis._file.toml.io_ import TOMLFileManager

if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Any

    from tomlkit import TOMLDocument
    from typing_extensions import Self

    from usethis._file.types_ import Key


class PyprojectTOMLManager(TOMLFileManager):
    """Manages the pyproject.toml file."""

    @property
    @override
    def relative_path(self) -> Path:
        return Path("pyproject.toml")

    @override
    def __enter__(self) -> Self:
        try:
            return super().__enter__()
        except UnexpectedTOMLOpenError as err:
            raise UnexpectedPyprojectTOMLOpenError(err) from None

    @override
    def read_file(self) -> TOMLDocument:
        try:
            return super().read_file()
        except TOMLNotFoundError as err:
            raise PyprojectTOMLNotFoundError(err) from None
        except UnexpectedTOMLIOError as err:
            raise UnexpectedPyprojectTOMLIOError(err) from None
        except TOMLDecodeError as err:
            raise PyprojectTOMLDecodeError(err) from None

    @override
    def _validate_lock(self) -> None:
        try:
            super()._validate_lock()
        except UnexpectedTOMLIOError as err:
            raise UnexpectedPyprojectTOMLIOError(err) from None

    @override
    def set_value(
        self, *, keys: Sequence[Key], value: Any, exists_ok: bool = False
    ) -> None:
        """Set a value in the pyproject.toml configuration file."""
        try:
            super().set_value(keys=keys, value=value, exists_ok=exists_ok)
        except TOMLValueAlreadySetError as err:
            raise PyprojectTOMLValueAlreadySetError(err) from None

    @override
    def __delitem__(self, keys: Sequence[Key]) -> None:
        """Remove a value from the pyproject.toml configuration file."""
        try:
            super().__delitem__(keys)
        except TOMLValueMissingError as err:
            raise PyprojectTOMLValueMissingError(err) from None
