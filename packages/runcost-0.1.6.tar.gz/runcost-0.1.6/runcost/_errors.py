class BudgetExceededError(RuntimeError):
    pass

