# pypi-token-demo-linkyang-20260309

最小可发布 pip 包 Demo，用来测试 PyPI/TestPyPI token 流程。

## 目录结构

- `pyproject.toml`
- `src/pypi_token_demo/__init__.py`
- `src/pypi_token_demo/cli.py`
- `src/pypi_token_demo/__main__.py`

## 本地构建

```bash
python3 -m pip install --upgrade build twine
python3 -m build
```

构建成功后会生成：

- `dist/pypi_token_demo_linkyang_20260309-0.0.1.tar.gz`
- `dist/pypi_token_demo_linkyang_20260309-0.0.1-py3-none-any.whl`

## 上传到 TestPyPI（推荐先测）

1. 在 https://test.pypi.org/manage/account/token/ 创建 token
2. 设置环境变量（避免明文写进历史）

```bash
export TEST_PYPI_TOKEN='pypi-xxxxxx'
```

3. 上传

```bash
python3 -m twine upload \
  --repository-url https://test.pypi.org/legacy/ \
  -u __token__ \
  -p "$TEST_PYPI_TOKEN" \
  dist/*
```

## 用 token 安装（TestPyPI）

```bash
python3 -m pip install \
  --index-url "https://__token__:${TEST_PYPI_TOKEN}@test.pypi.org/simple/" \
  --extra-index-url https://pypi.org/simple \
  pypi-token-demo-linkyang-20260309==0.0.1
```

安装后验证：

```bash
pypi-token-demo
python3 -m pypi_token_demo
```

## 上传到正式 PyPI（可选）

1. 在 https://pypi.org/manage/account/token/ 创建 token
2. 设置环境变量

```bash
export PYPI_TOKEN='pypi-xxxxxx'
```

3. 上传

```bash
python3 -m twine upload \
  -u __token__ \
  -p "$PYPI_TOKEN" \
  dist/*
```

4. 安装（公开包其实不需要 token；这里只是演示 token 方式）

```bash
python3 -m pip install \
  --index-url "https://__token__:${PYPI_TOKEN}@pypi.org/simple/" \
  pypi-token-demo-linkyang-20260309==0.0.1
```
