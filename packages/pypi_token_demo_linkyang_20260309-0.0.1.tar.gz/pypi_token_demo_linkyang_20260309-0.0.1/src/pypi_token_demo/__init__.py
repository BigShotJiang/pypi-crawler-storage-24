"""Minimal package for PyPI token demo."""

__version__ = "0.0.1"


def hello() -> str:
    return "hello from pypi-token-demo-linkyang-20260309"
