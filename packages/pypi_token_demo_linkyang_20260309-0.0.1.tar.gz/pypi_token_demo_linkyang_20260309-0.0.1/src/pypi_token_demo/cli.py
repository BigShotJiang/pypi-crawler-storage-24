from . import hello


def main() -> None:
    print(hello())
