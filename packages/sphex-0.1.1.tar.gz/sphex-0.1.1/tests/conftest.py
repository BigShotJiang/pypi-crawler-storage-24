"""Shared test fixtures for Sphex tests."""

import pytest

from sphex.core.review import FileChange, ReviewRequest
from tests.fixtures.sample_diff import SAMPLE_FILES, SAMPLE_PR_BODY, SAMPLE_PR_TITLE


@pytest.fixture
def sample_files() -> list[FileChange]:
    return [
        FileChange(
            filename=f["filename"],
            status=f["status"],
            patch=f["patch"],
            additions=f["additions"],
            deletions=f["deletions"],
        )
        for f in SAMPLE_FILES
    ]


@pytest.fixture
def sample_request(sample_files) -> ReviewRequest:
    return ReviewRequest(
        project_id="test-project",
        pr_number=1,
        pr_title=SAMPLE_PR_TITLE,
        pr_body=SAMPLE_PR_BODY,
        files=sample_files,
    )
