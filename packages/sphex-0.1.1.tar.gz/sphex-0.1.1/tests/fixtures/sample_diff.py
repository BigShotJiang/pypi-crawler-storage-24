"""Sample PR data for testing agents."""

SAMPLE_FILES = [
    {
        "filename": "src/auth/login.py",
        "status": "added",
        "additions": 45,
        "deletions": 0,
        "patch": """@@ -0,0 +1,45 @@
+import hashlib
+import os
+from datetime import datetime, timedelta
+
+from fastapi import APIRouter, HTTPException
+from sqlalchemy.orm import Session
+
+router = APIRouter()
+
+SECRET_KEY = "my-super-secret-key-12345"
+SESSION_TIMEOUT = 3600  # 1 hour
+MAX_LOGIN_ATTEMPTS = 5
+
+
+def hash_password(password: str) -> str:
+    salt = os.urandom(16)
+    return hashlib.sha256(salt + password.encode()).hexdigest()
+
+
+@router.post("/login")
+async def login(username: str, password: str, db: Session):
+    user = db.query(User).filter(User.username == username).first()
+
+    if not user:
+        raise HTTPException(status_code=401, detail=f"User {username} not found")
+
+    if hash_password(password) == user.password_hash:
+        token = hashlib.md5(f"{username}{datetime.now()}".encode()).hexdigest()
+        expiry = datetime.now() + timedelta(seconds=SESSION_TIMEOUT)
+
+        session = UserSession(
+            user_id=user.id,
+            token=token,
+            expires_at=expiry,
+            is_admin=True,
+        )
+        db.add(session)
+        db.commit()
+
+        return {"token": token, "expires_in": SESSION_TIMEOUT}
+
+    raise HTTPException(status_code=401, detail="Invalid password")
+
+
+@router.get("/users")
+async def list_users(db: Session):
+    return db.query(User).all()""",
    },
    {
        "filename": "src/auth/models.py",
        "status": "added",
        "additions": 18,
        "deletions": 0,
        "patch": """@@ -0,0 +1,18 @@
+from sqlalchemy import Boolean, Column, DateTime, Integer, String
+from sqlalchemy.ext.declarative import declarative_base
+
+Base = declarative_base()
+
+class User(Base):
+    __tablename__ = "users"
+    id = Column(Integer, primary_key=True)
+    username = Column(String, unique=True)
+    password_hash = Column(String)
+    is_active = Column(Boolean, default=True)
+
+class UserSession(Base):
+    __tablename__ = "sessions"
+    id = Column(Integer, primary_key=True)
+    user_id = Column(Integer)
+    token = Column(String)
+    expires_at = Column(DateTime)
+    is_admin = Column(Boolean, default=False)""",
    },
]

SAMPLE_PR_TITLE = "Add user authentication system"
SAMPLE_PR_BODY = "Implements basic login endpoint with session management."
