"""Tests for core data models — no LLM calls needed."""

from datetime import datetime

from sphex.core.events import SphexEvent
from sphex.core.records import AssumptionRecord, DecisionRecord
from sphex.core.review import AgentReview, FileChange, Finding, ReviewRequest, ReviewResult
from sphex.core.types import (
    AssumptionMaturity,
    AssumptionSeverity,
    Confidence,
    FindingSeverity,
    ReviewStatus,
    ReviewTier,
)


class TestEnums:
    def test_review_status_values(self):
        assert ReviewStatus.APPROVED == "approved"
        assert ReviewStatus.CONCERNS == "concerns"
        assert ReviewStatus.BLOCKED == "blocked"

    def test_confidence_values(self):
        assert Confidence.HIGH == "high"
        assert Confidence.MEDIUM == "medium"
        assert Confidence.LOW == "low"

    def test_finding_severity_values(self):
        assert FindingSeverity.PASS == "pass"
        assert FindingSeverity.WARN == "warn"
        assert FindingSeverity.BLOCK == "block"

    def test_review_tier_values(self):
        assert ReviewTier.MINIMAL == "minimal"
        assert ReviewTier.STANDARD == "standard"
        assert ReviewTier.FULL == "full"

    def test_assumption_maturity_lifecycle(self):
        """Verify the full 4-state maturity lifecycle (SP-14).

        Lifecycle: PROVIDED_DEFAULT → STRICT → CANDIDATE → APPROVED_DEFAULT
        Override hierarchy: APPROVED_DEFAULT > STRICT > PROVIDED_DEFAULT
        """
        assert AssumptionMaturity.PROVIDED_DEFAULT == "provided_default"
        assert AssumptionMaturity.STRICT == "strict"
        assert AssumptionMaturity.CANDIDATE == "candidate"
        assert AssumptionMaturity.APPROVED_DEFAULT == "approved_default"
        # Verify all 4 states exist
        assert len(AssumptionMaturity) == 4


class TestFileChange:
    def test_create_file_change(self):
        fc = FileChange(
            filename="src/main.py",
            status="modified",
            patch="@@ -1,3 +1,4 @@\n+import os",
            additions=1,
            deletions=0,
        )
        assert fc.filename == "src/main.py"
        assert fc.status == "modified"
        assert fc.additions == 1

    def test_defaults(self):
        fc = FileChange(filename="x.py", status="added", patch="")
        assert fc.additions == 0
        assert fc.deletions == 0


class TestReviewRequest:
    def test_create_request(self, sample_files):
        req = ReviewRequest(
            project_id="test",
            pr_number=42,
            pr_title="Test PR",
            pr_body="Description",
            files=sample_files,
        )
        assert req.project_id == "test"
        assert req.pr_number == 42
        assert len(req.files) == 2

    def test_defaults(self):
        req = ReviewRequest(project_id="test", files=[])
        assert req.pr_number is None
        assert req.pr_title == ""
        assert req.review_tier == ReviewTier.STANDARD
        assert req.base_branch == "main"


class TestAgentReview:
    def test_has_blockers(self):
        review = AgentReview(
            agent_name="critic",
            status=ReviewStatus.BLOCKED,
            confidence=Confidence.HIGH,
            findings=[
                Finding(severity=FindingSeverity.BLOCK, category="test", description="bad"),
                Finding(severity=FindingSeverity.PASS, category="test", description="good"),
            ],
        )
        assert review.has_blockers is True
        assert review.block_count == 1
        assert review.warn_count == 0

    def test_no_blockers(self):
        review = AgentReview(
            agent_name="critic",
            status=ReviewStatus.APPROVED,
            confidence=Confidence.HIGH,
            findings=[
                Finding(severity=FindingSeverity.PASS, category="test", description="good"),
            ],
        )
        assert review.has_blockers is False

    def test_warn_count(self):
        review = AgentReview(
            agent_name="sentinel",
            status=ReviewStatus.CONCERNS,
            confidence=Confidence.MEDIUM,
            findings=[
                Finding(severity=FindingSeverity.WARN, category="a", description="x"),
                Finding(severity=FindingSeverity.WARN, category="b", description="y"),
                Finding(severity=FindingSeverity.PASS, category="c", description="z"),
            ],
        )
        assert review.warn_count == 2
        assert review.block_count == 0

    def test_empty_review(self):
        review = AgentReview(
            agent_name="arbiter",
            status=ReviewStatus.APPROVED,
            confidence=Confidence.HIGH,
        )
        assert review.findings == []
        assert review.assumptions == []
        assert review.escalations == []
        assert review.context_gaps == []
        assert review.has_blockers is False


class TestReviewResult:
    def test_from_agent_reviews_blocked(self):
        reviews = {
            "critic": AgentReview(
                agent_name="critic",
                status=ReviewStatus.APPROVED,
                confidence=Confidence.HIGH,
            ),
            "sentinel": AgentReview(
                agent_name="sentinel",
                status=ReviewStatus.BLOCKED,
                confidence=Confidence.HIGH,
                findings=[
                    Finding(severity=FindingSeverity.BLOCK, category="secrets", description="hardcoded key"),
                ],
            ),
        }
        result = ReviewResult.from_agent_reviews("test", 1, ReviewTier.STANDARD, reviews)
        assert result.overall_status == ReviewStatus.BLOCKED
        assert result.total_findings == 1

    def test_from_agent_reviews_concerns(self):
        reviews = {
            "critic": AgentReview(
                agent_name="critic",
                status=ReviewStatus.CONCERNS,
                confidence=Confidence.HIGH,
                findings=[
                    Finding(severity=FindingSeverity.WARN, category="readability", description="x"),
                ],
            ),
            "sentinel": AgentReview(
                agent_name="sentinel",
                status=ReviewStatus.APPROVED,
                confidence=Confidence.HIGH,
            ),
        }
        result = ReviewResult.from_agent_reviews("test", 1, ReviewTier.STANDARD, reviews)
        assert result.overall_status == ReviewStatus.CONCERNS

    def test_from_agent_reviews_all_approved(self):
        reviews = {
            "critic": AgentReview(
                agent_name="critic", status=ReviewStatus.APPROVED, confidence=Confidence.HIGH
            ),
            "sentinel": AgentReview(
                agent_name="sentinel", status=ReviewStatus.APPROVED, confidence=Confidence.HIGH
            ),
            "arbiter": AgentReview(
                agent_name="arbiter", status=ReviewStatus.APPROVED, confidence=Confidence.HIGH
            ),
        }
        result = ReviewResult.from_agent_reviews("test", 1, ReviewTier.MINIMAL, reviews)
        assert result.overall_status == ReviewStatus.APPROVED
        assert result.total_assumptions == 0


class TestSphexEvent:
    def test_create_event(self):
        event = SphexEvent(
            event_type="review",
            source_agent="critic",
            project_id="test",
            payload={"status": "approved"},
        )
        assert event.event_id  # auto-generated UUID
        assert event.timestamp  # auto-generated
        assert event.version == "0.1.0"

    def test_add_relationship(self):
        event = SphexEvent(
            event_type="decision",
            source_agent="arbiter",
            project_id="test",
            payload={},
        )
        event.add_relationship("depends_on", "DEC-00000001")
        event.add_relationship("affects", "ASM-00000001")
        event.add_relationship("depends_on", "DEC-00000002")

        assert len(event.relationships["depends_on"]) == 2
        assert len(event.relationships["affects"]) == 1

    def test_empty_relationships_by_default(self):
        event = SphexEvent(
            event_type="review", source_agent="sentinel", project_id="test", payload={}
        )
        assert event.relationships == {}


class TestDecisionRecord:
    def test_create_record(self):
        record = DecisionRecord(
            record_type="review",
            project_id="test",
            pr_number=1,
            agents_involved=["critic", "sentinel"],
            summary="PR approved with concerns",
            details={"overall_status": "concerns"},
        )
        assert record.record_id.startswith("DEC-")
        assert record.timestamp is not None
        assert isinstance(record.timestamp, datetime)
        assert record.developer_action is None

    def test_record_id_format(self):
        record = DecisionRecord(
            record_type="override",
            project_id="test",
            agents_involved=["arbiter"],
            summary="Developer override",
            details={},
        )
        assert record.record_id.startswith("DEC-")
        assert len(record.record_id) == 12  # "DEC-" + 8 hex chars


class TestAssumptionRecord:
    def test_create_assumption(self):
        record = AssumptionRecord(
            source_agent="arbiter",
            project_id="test",
            severity=AssumptionSeverity.CRITICAL,
            description="Code assumes session timeout is 3600 seconds",
            current_code_behavior="Sessions expire after 1 hour",
            impact_if_wrong="Users could be locked out too quickly or sessions persist too long",
        )
        assert record.assumption_id.startswith("ASM-")
        assert record.status == "open"
        assert record.maturity == AssumptionMaturity.STRICT
        assert record.developer_response is None
        assert record.resolved_at is None

    def test_default_maturity_is_strict(self):
        """New project-level assumptions start as STRICT (SP-14)."""
        record = AssumptionRecord(
            source_agent="sentinel",
            project_id="test",
            severity=AssumptionSeverity.SIGNIFICANT,
            description="test",
            current_code_behavior="test",
            impact_if_wrong="test",
        )
        assert record.maturity == AssumptionMaturity.STRICT

    def test_curated_default_maturity(self):
        """Community-curated assumptions use PROVIDED_DEFAULT (SP-14)."""
        record = AssumptionRecord(
            source_agent="arbiter",
            project_id="test",
            severity=AssumptionSeverity.MINOR,
            description="Session timeout should be configurable",
            current_code_behavior="Uses 3600s default",
            impact_if_wrong="Users locked out or sessions too long",
            maturity=AssumptionMaturity.PROVIDED_DEFAULT,
        )
        assert record.maturity == AssumptionMaturity.PROVIDED_DEFAULT

    def test_maturity_lifecycle_progression(self):
        """Verify assumptions can progress through all 4 states (SP-14)."""
        record = AssumptionRecord(
            source_agent="arbiter",
            project_id="test",
            severity=AssumptionSeverity.SIGNIFICANT,
            description="Pagination limit of 50",
            current_code_behavior="Returns max 50 items per page",
            impact_if_wrong="Too few results or API overload",
            maturity=AssumptionMaturity.PROVIDED_DEFAULT,
        )
        # Simulate lifecycle: PROVIDED_DEFAULT → STRICT → CANDIDATE → APPROVED_DEFAULT
        assert record.maturity == AssumptionMaturity.PROVIDED_DEFAULT
        record.maturity = AssumptionMaturity.STRICT
        assert record.maturity == AssumptionMaturity.STRICT
        record.maturity = AssumptionMaturity.CANDIDATE
        assert record.maturity == AssumptionMaturity.CANDIDATE
        record.maturity = AssumptionMaturity.APPROVED_DEFAULT
        assert record.maturity == AssumptionMaturity.APPROVED_DEFAULT
