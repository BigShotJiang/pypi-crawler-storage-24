"""Sphex — Open standard for multi-agent development governance."""

__version__ = "0.1.0"
