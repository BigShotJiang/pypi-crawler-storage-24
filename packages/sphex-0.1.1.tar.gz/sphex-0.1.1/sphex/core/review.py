"""Review request/response types for the Sphex governance system."""

from __future__ import annotations

from pydantic import BaseModel, Field

from sphex.core.types import (
    AssumptionSeverity,
    Confidence,
    FindingSeverity,
    ReviewStatus,
    ReviewTier,
)


class FileChange(BaseModel):
    """A single file changed in a PR."""

    filename: str
    status: str  # "added", "modified", "deleted", "renamed"
    patch: str  # Unified diff
    additions: int = 0
    deletions: int = 0


class ReviewRequest(BaseModel):
    """Input to the review cycle — a PR or diff to be reviewed."""

    project_id: str
    pr_number: int | None = None
    pr_title: str = ""
    pr_body: str = ""
    files: list[FileChange]
    review_tier: ReviewTier = ReviewTier.STANDARD
    base_branch: str = "main"


class Finding(BaseModel):
    """An individual review finding from an agent."""

    severity: FindingSeverity
    category: str  # "readability", "security", "business_logic", etc.
    description: str
    file: str | None = None
    line: int | None = None
    suggestion: str | None = None


class Assumption(BaseModel):
    """An assumption surfaced by an agent during review."""

    severity: AssumptionSeverity
    description: str
    current_code_behavior: str
    impact_if_wrong: str


class Escalation(BaseModel):
    """A concern escalated to another agent."""

    target_agent: str
    description: str


class AgentReview(BaseModel):
    """Standardized output from a single agent's review."""

    agent_name: str
    status: ReviewStatus
    confidence: Confidence
    context_gaps: list[str] = Field(default_factory=list)
    findings: list[Finding] = Field(default_factory=list)
    assumptions: list[Assumption] = Field(default_factory=list)
    escalations: list[Escalation] = Field(default_factory=list)
    raw_reasoning: str = ""  # Full LLM output for transparency (P-08)

    @property
    def has_blockers(self) -> bool:
        return any(f.severity == FindingSeverity.BLOCK for f in self.findings)

    @property
    def warn_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == FindingSeverity.WARN)

    @property
    def block_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == FindingSeverity.BLOCK)


class ReviewResult(BaseModel):
    """Final synthesized output from the full review cycle."""

    project_id: str
    pr_number: int | None = None
    review_tier: ReviewTier
    agent_reviews: dict[str, AgentReview]
    overall_status: ReviewStatus
    synthesis: str = ""  # Human-readable merged review
    conflicts: list[dict] = Field(default_factory=list)
    total_assumptions: int = 0
    total_findings: int = 0

    @classmethod
    def from_agent_reviews(
        cls,
        project_id: str,
        pr_number: int | None,
        review_tier: ReviewTier,
        reviews: dict[str, AgentReview],
    ) -> ReviewResult:
        """Create a ReviewResult from individual agent reviews."""
        # Overall status is the most severe across all agents
        if any(r.status == ReviewStatus.BLOCKED for r in reviews.values()):
            overall = ReviewStatus.BLOCKED
        elif any(r.status == ReviewStatus.CONCERNS for r in reviews.values()):
            overall = ReviewStatus.CONCERNS
        else:
            overall = ReviewStatus.APPROVED

        total_assumptions = sum(len(r.assumptions) for r in reviews.values())
        total_findings = sum(len(r.findings) for r in reviews.values())

        return cls(
            project_id=project_id,
            pr_number=pr_number,
            review_tier=review_tier,
            agent_reviews=reviews,
            overall_status=overall,
            total_assumptions=total_assumptions,
            total_findings=total_findings,
        )
