"""Shared enums and types for the Sphex governance system."""

from enum import StrEnum


class ReviewStatus(StrEnum):
    """Outcome of an agent's review."""

    APPROVED = "approved"
    CONCERNS = "concerns"
    BLOCKED = "blocked"


class Confidence(StrEnum):
    """Agent self-reported confidence level (DEC-R03, DEC-R04)."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class FindingSeverity(StrEnum):
    """Severity of an individual review finding."""

    PASS = "pass"
    WARN = "warn"
    BLOCK = "block"


class AssumptionSeverity(StrEnum):
    """Impact level of a surfaced assumption."""

    CRITICAL = "critical"
    SIGNIFICANT = "significant"
    MINOR = "minor"


class AssumptionMaturity(StrEnum):
    """Maturity lifecycle state for tracked assumptions (SP-14).

    Lifecycle: PROVIDED_DEFAULT → STRICT → CANDIDATE → APPROVED_DEFAULT
    Override hierarchy: APPROVED_DEFAULT > STRICT > PROVIDED_DEFAULT
    """

    PROVIDED_DEFAULT = "provided_default"  # Curated by Sphex community or industry template
    STRICT = "strict"  # Project-level override forcing ask-every-time
    CANDIDATE = "candidate"  # System detected pattern, not yet approved
    APPROVED_DEFAULT = "approved_default"  # Developer explicitly approved for this project


class ReviewTier(StrEnum):
    """Review depth tier based on change risk (P-32)."""

    MINIMAL = "minimal"
    STANDARD = "standard"
    FULL = "full"


class Environment(StrEnum):
    """Deployment environment for enforcement level (P-09)."""

    LOCAL = "local"
    PR = "pr"
    STAGING = "staging"
    PRODUCTION = "production"
