"""Base agent abstraction for the Sphex governance system."""

from __future__ import annotations

from abc import ABC, abstractmethod

from sphex.core.review import AgentReview, ReviewRequest


class BaseAgent(ABC):
    """Abstract base class for all Sphex governance agents.

    Every agent has:
    - A domain it is responsible for (P-14: Domain Authority)
    - A system prompt defining its review standards
    - A review method that produces structured output
    - A method to determine if it should review given files (consultation matrix)
    """

    name: str  # "critic", "sentinel", "arbiter"
    display_name: str  # "Critic", "Sentinel", "Arbiter"
    tier: int  # 1 for all MVP agents
    domain: str  # "code_quality", "security", "business_logic"

    @abstractmethod
    async def review(self, request: ReviewRequest) -> AgentReview:
        """Execute a review against a code diff.

        Returns a structured AgentReview with findings, assumptions,
        confidence level, and escalations.
        """

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the agent's system prompt."""

    def applies_to(self, file_paths: list[str]) -> bool:
        """Whether this agent should review the given files.

        Default: always review (MVP behavior). Override in subclasses
        for consultation matrix filtering.
        """
        return True
