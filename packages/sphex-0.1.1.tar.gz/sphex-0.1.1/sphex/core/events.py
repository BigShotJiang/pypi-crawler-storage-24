"""SphexEvent — universal governance event envelope (DEC-R10, DEC-R14)."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from pydantic import BaseModel, Field


class SphexEvent(BaseModel):
    """Universal envelope for all governance events.

    Every governance action produces a SphexEvent. Events declare relationships
    to other entities (depends_on, affects, served_by, conflicts_with, supersedes),
    enabling automatic construction of a governance knowledge graph (P-13).
    """

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_type: str  # "review", "decision", "assumption", "conflict", "override"
    source_agent: str  # "critic", "sentinel", "arbiter"
    project_id: str
    pr_number: int | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    payload: dict  # Agent-specific structured data
    relationships: dict[str, list[str]] = Field(default_factory=dict)
    version: str = "0.1.0"

    def add_relationship(self, rel_type: str, target_id: str) -> None:
        """Add a relationship to another entity.

        Relationship types (DEC-R10):
          - depends_on: this event requires another entity
          - affects: this event impacts another entity
          - served_by: this event is served by another entity
          - conflicts_with: this event conflicts with another entity
          - supersedes: this event replaces another entity
        """
        self.relationships.setdefault(rel_type, []).append(target_id)
