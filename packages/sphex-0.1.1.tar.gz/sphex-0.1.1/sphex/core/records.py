"""Immutable governance records — decisions and assumptions (P-07, P-03)."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from pydantic import BaseModel, Field

from sphex.core.types import AssumptionMaturity, AssumptionSeverity


class DecisionRecord(BaseModel):
    """An immutable record of a governance decision (P-07).

    Once created, decision records are never modified. Corrections
    append a new record linking to the original via CORRECTION protocol (DEC-R08).
    """

    record_id: str = Field(default_factory=lambda: f"DEC-{uuid.uuid4().hex[:8].upper()}")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    record_type: str  # "review", "override", "conflict_resolution", "assumption_response"
    project_id: str
    pr_number: int | None = None
    agents_involved: list[str]
    summary: str
    details: dict
    developer_action: str | None = None


class AssumptionRecord(BaseModel):
    """A tracked assumption surfaced by an agent (P-03, P-17).

    Assumptions progress through a maturity lifecycle:
    STRICT -> CANDIDATE -> APPROVED_DEFAULT
    """

    assumption_id: str = Field(default_factory=lambda: f"ASM-{uuid.uuid4().hex[:8].upper()}")
    source_agent: str
    project_id: str
    pr_number: int | None = None
    severity: AssumptionSeverity
    description: str
    current_code_behavior: str
    impact_if_wrong: str
    developer_response: str | None = None
    status: str = "open"  # "open", "resolved", "deferred"
    maturity: AssumptionMaturity = AssumptionMaturity.STRICT
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
