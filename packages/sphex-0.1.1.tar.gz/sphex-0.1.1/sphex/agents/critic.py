"""Critic — Code Review & Quality agent (Tier 1, Essential)."""

from __future__ import annotations

from pathlib import Path

from jinja2 import Template

from sphex.core.agent import BaseAgent
from sphex.core.review import (
    AgentReview,
    Assumption,
    Escalation,
    Finding,
    ReviewRequest,
)
from sphex.core.types import (
    AssumptionSeverity,
    Confidence,
    FindingSeverity,
    ReviewStatus,
)
from sphex.integrations.llm import call_llm_json

PROMPTS_DIR = Path(__file__).parent.parent / "prompts" / "critic"


class Critic(BaseAgent):
    """Code quality and maintainability reviewer.

    Reviews code for readability, structure, patterns, anti-patterns,
    complexity, and naming. Surfaces assumptions about pattern choices,
    structural decisions, and error handling strategies.
    """

    name = "critic"
    display_name = "Critic"
    tier = 1
    domain = "code_quality"

    def __init__(self, model: str = "anthropic/claude-sonnet-4-20250514"):
        self.model = model
        self._system_template = Template(
            (PROMPTS_DIR / "system.j2").read_text()
        )
        self._review_template = Template(
            (PROMPTS_DIR / "review.j2").read_text()
        )

    def get_system_prompt(self) -> str:
        return self._system_template.render()

    async def review(self, request: ReviewRequest) -> AgentReview:
        """Review code changes for quality and maintainability."""
        system_prompt = self.get_system_prompt()
        user_prompt = self._review_template.render(
            pr_title=request.pr_title,
            pr_body=request.pr_body,
            files=request.files,
        )

        raw = await call_llm_json(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            model=self.model,
        )

        return self._parse_response(raw)

    def _parse_response(self, data: dict) -> AgentReview:
        """Parse LLM JSON response into structured AgentReview."""
        findings = [
            Finding(
                severity=FindingSeverity(f["severity"]),
                category=f["category"],
                description=f["description"],
                file=f.get("file"),
                line=f.get("line"),
                suggestion=f.get("suggestion"),
            )
            for f in data.get("findings", [])
        ]

        assumptions = [
            Assumption(
                severity=AssumptionSeverity(a["severity"]),
                description=a["description"],
                current_code_behavior=a["current_code_behavior"],
                impact_if_wrong=a["impact_if_wrong"],
            )
            for a in data.get("assumptions", [])
        ]

        escalations = [
            Escalation(
                target_agent=e["target_agent"],
                description=e["description"],
            )
            for e in data.get("escalations", [])
        ]

        return AgentReview(
            agent_name=self.name,
            status=ReviewStatus(data["status"]),
            confidence=Confidence(data["confidence"]),
            context_gaps=data.get("context_gaps", []),
            findings=findings,
            assumptions=assumptions,
            escalations=escalations,
        )
