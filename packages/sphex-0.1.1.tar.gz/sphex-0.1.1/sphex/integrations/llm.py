"""LLM integration via LiteLLM — vendor-neutral model access."""

from __future__ import annotations

import json
import logging

import litellm

logger = logging.getLogger(__name__)

# Suppress LiteLLM's verbose logging
litellm.suppress_debug_info = True


async def call_llm(
    system_prompt: str,
    user_prompt: str,
    model: str = "anthropic/claude-sonnet-4-20250514",
    temperature: float = 0.1,
    max_tokens: int = 4096,
    response_format: dict | None = None,
) -> str:
    """Call an LLM via LiteLLM and return the response text.

    Uses structured JSON output when response_format is provided.
    Low temperature by default for consistent, deterministic reviews.
    """
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    kwargs: dict = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    if response_format:
        kwargs["response_format"] = response_format

    try:
        response = await litellm.acompletion(**kwargs)
        content = response.choices[0].message.content
        if content is None:
            raise ValueError("LLM returned empty response")
        return content
    except Exception:
        logger.exception("LLM call failed")
        raise


async def call_llm_json(
    system_prompt: str,
    user_prompt: str,
    model: str = "anthropic/claude-sonnet-4-20250514",
    temperature: float = 0.1,
    max_tokens: int = 4096,
) -> dict:
    """Call an LLM and parse the response as JSON.

    Appends explicit JSON instruction to the user prompt.
    Falls back to extracting JSON from markdown code blocks.
    """
    json_instruction = (
        "\n\nIMPORTANT: Respond with valid JSON only. "
        "Do not include markdown code fences or any text outside the JSON object."
    )

    raw = await call_llm(
        system_prompt=system_prompt,
        user_prompt=user_prompt + json_instruction,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )

    # Try direct parse first
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Try extracting from markdown code block
    if "```json" in raw:
        start = raw.index("```json") + 7
        end = raw.index("```", start)
        return json.loads(raw[start:end].strip())

    if "```" in raw:
        start = raw.index("```") + 3
        end = raw.index("```", start)
        return json.loads(raw[start:end].strip())

    # Try finding JSON object boundaries
    first_brace = raw.find("{")
    last_brace = raw.rfind("}")
    if first_brace != -1 and last_brace != -1:
        return json.loads(raw[first_brace : last_brace + 1])

    raise ValueError(f"Could not parse JSON from LLM response: {raw[:200]}...")
