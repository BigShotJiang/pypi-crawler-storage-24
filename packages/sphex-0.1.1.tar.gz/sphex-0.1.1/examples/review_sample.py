"""Smoke test: run all 3 agents against a sample diff.

Usage:
    cd sphex/
    pip install -e .
    python examples/review_sample.py

Requires ANTHROPIC_API_KEY environment variable.
"""

import asyncio
import sys
from pathlib import Path

# Add parent to path for direct execution
sys.path.insert(0, str(Path(__file__).parent.parent))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from sphex.agents import Arbiter, Critic, Sentinel
from sphex.core.review import FileChange, ReviewRequest
from tests.fixtures.sample_diff import SAMPLE_FILES, SAMPLE_PR_BODY, SAMPLE_PR_TITLE

console = Console()


def build_request() -> ReviewRequest:
    files = [
        FileChange(
            filename=f["filename"],
            status=f["status"],
            patch=f["patch"],
            additions=f["additions"],
            deletions=f["deletions"],
        )
        for f in SAMPLE_FILES
    ]
    return ReviewRequest(
        project_id="sphex-test",
        pr_number=1,
        pr_title=SAMPLE_PR_TITLE,
        pr_body=SAMPLE_PR_BODY,
        files=files,
    )


def display_review(review):
    """Pretty-print an agent review."""
    status_icon = {"approved": "[green]APPROVED[/]", "concerns": "[yellow]CONCERNS[/]", "blocked": "[red]BLOCKED[/]"}
    conf_icon = {"high": "[green]HIGH[/]", "medium": "[yellow]MEDIUM[/]", "low": "[red]LOW[/]"}

    console.print(
        Panel(
            f"Status: {status_icon.get(review.status, review.status)}  |  "
            f"Confidence: {conf_icon.get(review.confidence, review.confidence)}  |  "
            f"Findings: {len(review.findings)}  |  "
            f"Assumptions: {len(review.assumptions)}",
            title=f"[bold]{review.agent_name.upper()}[/bold]",
            border_style="blue",
        )
    )

    if review.context_gaps:
        console.print("[dim]Context gaps:[/dim]", ", ".join(review.context_gaps))

    if review.findings:
        table = Table(show_header=True)
        table.add_column("Severity", width=8)
        table.add_column("Category", width=16)
        table.add_column("Description")
        table.add_column("File", width=25)

        for f in review.findings:
            sev_style = {"pass": "green", "warn": "yellow", "block": "red"}.get(f.severity, "white")
            table.add_row(
                f"[{sev_style}]{f.severity.upper()}[/]",
                f.category,
                f.description[:100],
                f.file or "",
            )
        console.print(table)

    if review.assumptions:
        console.print(f"\n[bold]Assumptions Surfaced ({len(review.assumptions)}):[/bold]")
        for a in review.assumptions:
            sev_style = {"critical": "red", "significant": "yellow", "minor": "dim"}.get(a.severity, "white")
            console.print(f"  [{sev_style}][{a.severity.upper()}][/] {a.description}")
            console.print(f"    Code behavior: {a.current_code_behavior}")
            console.print(f"    Impact if wrong: {a.impact_if_wrong}")

    if review.escalations:
        console.print(f"\n[bold]Escalations:[/bold]")
        for e in review.escalations:
            console.print(f"  → {e.target_agent}: {e.description}")

    console.print()


async def main():
    request = build_request()

    console.print("\n[bold]Sphex Governance Review[/bold]")
    console.print(f"PR: {request.pr_title}")
    console.print(f"Files: {len(request.files)} changed\n")

    agents = [Critic(), Sentinel(), Arbiter()]

    for agent in agents:
        console.print(f"[dim]Running {agent.display_name}...[/dim]")
        try:
            review = await agent.review(request)
            display_review(review)
        except Exception as e:
            console.print(f"[red]Error running {agent.display_name}: {e}[/red]\n")


if __name__ == "__main__":
    asyncio.run(main())
