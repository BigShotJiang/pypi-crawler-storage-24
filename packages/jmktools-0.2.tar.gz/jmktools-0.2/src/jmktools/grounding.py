'''
JMK Engineering Inc. Python Tools
by: Jeff MacKinnon

email: jeff@jmkengineering.com

Grounding functions

'''

import pandas as pd
import math


def resistivity_wenner(spacing,resistance):
    '''
    This function calculates the resistivity in ohm-m from the wenner resistance measurements.

    The spacing must be in meters and the resistance in ohms.
    '''

    rho = 2 * math.pi * spacing * resistance
    return rho

def laurent (area,len_conductor,resistivity):
    '''
    This function calculates the expected Rg of a grounding system using the Laurent Method, also known as the IEEE 80 Simplified method.

    Rg_area = (soil_resistivity / (4 * sqrt(Area_of_grounding_system)) 

    Rg_conductors = soil_resistivity / total_buried_conductor_length

    Rg = Rg_area + Rg_conductors

    '''

    rg_area = resistivity / (4 * math.sqrt(area))
    rg_conductor = resistivity / len_conductor

    rg = rg_area + rg_conductor

    return rg

def sverak(area,len_conductor,depth,resistivity):
    '''
    This is IEEE 80, Equation 57 or Sverak method to calcuate the Rg.

    It is:

    Rg = soil_resistivity*[1/total_buried_conductor_length + {(1/sqrt(20*Area_of_grounding_system)) * (1 + 1/(1+buried_depth_grounding_system * sqrt(20 / Area_of_grounding_system)))}]

    This function breaks the function into three parts to make it easier to read.
    '''

    sv_part1 = 1/ len_conductor
    sv_part2 = 1 / math.sqrt(20 * area)
    sv_part3 = 1 + (1 / (1 + depth * math.sqrt(20 / area)))

    rg = resistivity * (sv_part1 + sv_part2 * sv_part3)

    return rg

