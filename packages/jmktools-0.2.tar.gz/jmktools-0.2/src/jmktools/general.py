'''
JMK Engineering Inc. Python Library for design and such.
by: Jeff MacKinnon

email: jeff@jmkengineering.com

Some General Functions and things
----------------------------------
'''
import pandas as pd
import numpy as np
import math
#import sqlite3


def va(voltage, current,phases=3):
    '''
        Calculate the Volt-Amp of a circuit
    '''

    if phases == 3:
        va = (math.sqrt(3) * voltage * current)
    
    elif phases == 1:
        va = voltage * current
    else:
        print("Phases needs to be 1 or 3 for now.")

    return va

def xfmr_sc(kva, voltage, impedance, phases = 3):

    '''
        Calculate the maximum let-through current of a transformer.

        Isc = resulant short circuit
        kva = kilo-voltamps
        impednace in %Z

        Assume 3 phase, but calculate single phase if its selected
    '''
    
    if phases == 1:
        Isc = (kva * 1000) / (voltage * (impedance / 100))

    else:
        Isc = (kva * 1000) / (math.sqrt(3) * voltage * (impedance / 100))

    return Isc
