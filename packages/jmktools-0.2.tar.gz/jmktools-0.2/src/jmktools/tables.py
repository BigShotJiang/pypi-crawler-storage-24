'''
JMK Engineering Inc. Python Library for design and such.
by: Jeff MacKinnon

email: jeff@jmkengineering.com

This module imports all the various tables as shown in the various standards and codes.
'''

#
# Import all the table files. This is for both NEC and CEC and all of the years that we may need.
# 

from .Tables.CEC21Tables import * 
from .Tables.CEC24Tables import * 


#
# Set the default tables for CEC and NEC.
#

'''
This will also allow you to change the table on a case-by-case basis.
Ideally we will be able to select the code year as an option in the future.

'''


cectable1 = cec21table1
cectable2 = cec21table2
cectable3 = cec21table3
cectable4 = cec21table4
cectable16 = cec21table16

# Appendix Tables

cectableD3 = cec24tableD3


#print(cec21table1)

def Test():
    print( "JMK Python Module works! !")


