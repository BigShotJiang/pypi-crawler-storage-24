'''
JMK Engineering Inc. Python Tools
by: Jeff MacKinnon

email: jeff@jmkengineering.com

PV Design functions

'''

def temp_adj_Voc(Voc,temp,beta=-0.5,STCtemp = 25):

    ''' 
        The Voc of a panel will increase as the temperature decreases.
        The datasheet Voc is typically at STC, or 25C. As the temperature decreases this Voc needs to be adjusted.
        This adjustment is linear based on the beta value with the units %/C.
        This beta value will be shown as a negative indicating that as the temperature increases, then the Voc will decrease.
        This Voc decrease results in derating of power during temperature above 25C.

        Voc = The STC panel open circuit voltage
        temp = The min or max temperature for the PV plant.
        beta = The panel temperature coefficient. default -0.5%/C, typical values will range from -0.2 to -0.45.

        The adjusted Voc is Voc minus the voltage shift. When the outside temperature is above the STC value then the Vocadj will be lower.
    '''

    tempadj = STCtemp - temp #-

    percent_shift = tempadj * beta/100 #+

    
    volt_shift = Voc * percent_shift

    Vocadj = Voc - volt_shift # The voltage adjust is the 

    return Vocadj


def panels_per_string(Vmax,Voc,beta=-0.5,temp = 25,STCtemp = 25):

    '''
        This function calculates the maximum number of panels that a string can have.
        It will automatically calculate the temperature shifted number when beta and temp are given.

    '''
    Vocadj = temp_adj_Voc(Voc, temp,beta, STCtemp = 25)

    panels_per_string_max = Vmax // Vocadj

    return int(panels_per_string_max)

def voltage_per_string(panels,Voc,beta=-0.5,temp = 25,STCtemp = 25):
    '''
        This function calculates the temperature adjusted string voltage based on the number of panels, open-circuit voltage (Voc).
        By default it assumes a beta of -0.5, tem of 25C and a tested STCtemp of 25C.
    '''

    vocadj = temp_adj_Voc(Voc, temp,beta, STCtemp = 25)

    voltage = vocadj * panels

    return round(voltage,4)