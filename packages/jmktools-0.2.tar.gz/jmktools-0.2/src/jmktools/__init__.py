from .circuits import *
from .general import *
from .grounding import *
from .pvsolar import *
from .tables import *

def main() -> None:
    print("Hello from jmktools!")
