# JMK Engineering Python Tools

or JMKTools for short.

What it is, is a set of functions that replace calculations that I do on a weekly basis.

The library is broken into sections, including 

- general
- circuits
- grounding 
- and pv.

Some of these modulesrely on publicly accessible information, including manufacturer data sheets.

## What we're missing

Tests, I haven't written any real tests for this set of libraries, yet. That will be coming soon, probably the next time that we have a slow time.


# Limitations

Currently the tools use the CEC, in most cases this will match the NEC, but something we are working on is updating that so we can select from which code version should be used for the calculation.


# Future Features

- [x] Web app (this is started at [Digital Power Systems Toolbox](http://toolbox.digitalpowersystems.net)
- [x] Installable package [The first releases are here](https://git.jmkengineering.com/JMK_Engineering_Inc/JMKTools/releases)
- [ ] Add NEC to the calculations
- [x] Re-do and add PV functions to the package.
- [ ] Detailed documentation (the source is started in this repo)
- [ ] Electrical Safety Calculations
- [ ] Basic Load flow tools
- [ ] Basic Short circuit tools
- [ ] Continue developing the DPS Toolbox