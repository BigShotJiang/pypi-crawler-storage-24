"""HTTP request handler for the config UI."""

from __future__ import annotations

import http.server
import json
import os
import secrets
import threading
import time
import urllib.parse

from .auth import (
    clear_cookie,
    clear_session,
    create_session,
    get_session,
    session_cookie,
    store_session,
)
from .constants import ENV_FILE
from .helpers import read_env, test_qnap, write_env
from .pages import (
    render_dashboard,
    render_login,
    render_logs,
    render_review,
    render_settings,
    render_success,
    render_wizard,
)


class Handler(http.server.BaseHTTPRequestHandler):
    def _get_user(self) -> str | None:
        """Return logged-in username or None."""
        return get_session(self.headers.get("Cookie", ""))

    def _require_auth(self) -> str | None:
        """Check auth. Returns username if ok, None if redirected to login."""
        user = self._get_user()
        if user:
            return user
        self._html(render_login())
        return None

    def do_GET(self) -> None:
        p = self.path.split("?")[0]

        if p == "/login":
            # If already logged in, redirect to dashboard
            if self._get_user():
                self._redirect("/")
                return
            self._html(render_login())
            return

        if p == "/logout":
            clear_session(self.headers.get("Cookie", ""))
            self.send_response(302)
            self.send_header("Location", "/login")
            self.send_header("Set-Cookie", clear_cookie())
            self.end_headers()
            return

        user = self._require_auth()
        if not user:
            return

        env = read_env()
        is_first_run = not env.get("QNAP_USERNAME")

        if p in ("/", ""):
            if is_first_run:
                self._html(render_wizard(1, user=user))
            else:
                self._html(render_dashboard(user=user))
        elif p == "/settings":
            self._html(render_settings(env, user=user))
        elif p == "/logs":
            self._html(render_logs(user=user))
        elif p == "/reset":
            try:
                os.remove(ENV_FILE)
            except FileNotFoundError:
                pass
            self._html(render_settings(
                {}, "Configuration reset.", "info", user=user))
        elif p == "/api/generate-token":
            self._json({"token": secrets.token_urlsafe(48)})
        else:
            self._redirect("/")

    def do_POST(self) -> None:
        form = self._form()
        p = self.path.split("?")[0]

        if p == "/login":
            self._handle_login(form)
            return

        user = self._require_auth()
        if not user:
            return

        if p == "/api/test-connection":
            ok, msg = test_qnap(form)
            self._json({"ok": ok, "message": msg})
        elif p == "/validate":
            ok, msg = test_qnap(form)
            self._html(render_review(form, ok, msg, user=user))
        elif p == "/confirm":
            write_env(form)
            self._html(render_success(form, user=user))
            threading.Thread(target=self._restart, daemon=True).start()
        elif p == "/wizard/1":
            ok, msg = test_qnap(form)
            if ok:
                self._html(render_wizard(2, form, user=user))
            else:
                self._html(render_wizard(1, form, msg, "err", user=user))
        elif p == "/wizard/2":
            if not form.get("MCP_AUTH_TOKEN"):
                self._html(render_wizard(
                    2, form, "Please set a token.", "err", user=user))
                return
            write_env(form)
            self._html(render_success(form, user=user))
            threading.Thread(target=self._restart, daemon=True).start()
        else:
            self._redirect("/")

    def _handle_login(self, form: dict[str, str]) -> None:
        username = form.get("username", "")
        password = form.get("password", "")

        if not username or not password:
            self._html(render_login("Username and password are required."))
            return

        # Validate against QNAP QTS auth API
        env = read_env()
        host = env.get("QNAP_HOST", "localhost")
        port = env.get("QNAP_PORT", "443")
        verify_ssl = env.get("QNAP_VERIFY_SSL", "false")

        ok, msg = test_qnap({
            "QNAP_HOST": host,
            "QNAP_PORT": port,
            "QNAP_USERNAME": username,
            "QNAP_PASSWORD": password,
            "QNAP_VERIFY_SSL": verify_ssl,
        })

        if not ok:
            # If no config exists yet, try localhost directly
            if not env.get("QNAP_HOST"):
                ok, msg = test_qnap({
                    "QNAP_HOST": "localhost",
                    "QNAP_PORT": "443",
                    "QNAP_USERNAME": username,
                    "QNAP_PASSWORD": password,
                    "QNAP_VERIFY_SSL": "false",
                })

        if not ok:
            self._html(render_login(
                "Login failed — check your QNAP credentials."))
            return

        token, login_time = create_session(username)
        store_session(token, username, login_time)
        self.send_response(302)
        self.send_header("Location", "/")
        self.send_header("Set-Cookie", session_cookie(token))
        self.end_headers()

    def _redirect(self, location: str) -> None:
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def _form(self) -> dict[str, str]:
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n).decode()
        return {k: v[0] for k, v in urllib.parse.parse_qs(body).items()}

    def _html(self, body: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode())

    def _json(self, data: dict) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    @staticmethod
    def _restart() -> None:
        time.sleep(3)
        os.system("kill 1 2>/dev/null")

    def log_message(self, fmt: str, *args: object) -> None:
        pass
