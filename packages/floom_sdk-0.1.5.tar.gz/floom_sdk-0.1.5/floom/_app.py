# ABOUTME: floom app class with @app.action decorator for marking functions as floom actions.
# ABOUTME: Syntactic sugar that makes intent explicit.
# ABOUTME: Runner checks _floom_action attribute on functions.


class App:
    """floom application container.

    Use @app.action to mark functions as floom actions.
    The runner uses this to discover which functions to expose.

    Example:
        from floom import app

        @app.action
        def greet(name: str) -> dict:
            return {"message": f"Hello, {name}!"}

        @app.action(name="custom_name")
        def my_func(x: int) -> dict:
            return {"result": x * 2}
    """

    def __init__(self):
        self._actions = []

    def action(self, func=None, *, name=None):
        """Mark a function as a floom action.

        Can be used with or without arguments:
            @app.action
            def my_func(): ...

            @app.action(name="custom")
            def my_func(): ...
        """

        def decorator(f):
            f._floom_action = True
            f._floom_name = name or f.__name__
            self._actions.append(f)
            return f

        if func is not None:
            return decorator(func)
        return decorator

    def schedule(self, cron, *, timezone=None, input=None, timeout=None):
        """Declare a cron schedule for an action.

        This is metadata-only: the runner reads it to generate floom.yaml schedule config.

        Example:
            @app.schedule("0 9 * * *", timezone="America/New_York")
            @app.action
            def daily_report():
                return {"report": "generated"}
        """

        def decorator(f):
            if not hasattr(f, "_floom_schedules"):
                f._floom_schedules = []
            f._floom_schedules.append(
                {
                    "cron": cron,
                    "timezone": timezone,
                    "input": input,
                    "timeout": timeout,
                }
            )
            return f

        return decorator

    @property
    def actions(self):
        """List of registered action functions."""
        return list(self._actions)


# Singleton instance
app = App()
