"""RunnerX package.

Expose the core runner API for import.
"""

from .main import run, main

__all__ = ["run", "main"]
