import subprocess

def run(command, shell: bool = True, capture_out: bool = True, text: bool = True) -> str:
    result = subprocess.run(command, shell=shell, capture_output=capture_out, text=text)
    return result.stdout