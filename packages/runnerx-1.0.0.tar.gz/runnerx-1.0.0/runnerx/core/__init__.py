"""RunnerX core package."""

from .processor import run

__all__ = ["run"]
