import core.processor as p

def main(command, shell: bool = True, capture_out: bool = True, text: bool = True) -> str:
    return p.run(command, shell=shell, capture_out=capture_out, text=text)