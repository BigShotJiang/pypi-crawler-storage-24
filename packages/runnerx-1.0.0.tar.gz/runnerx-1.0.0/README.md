# RunnerX

RunnerX is a small Python library for running shell commands and capturing output.

## Installation

```bash
pip install runnerx
```

## Usage

```python
import runnerx

output = runnerx.run("echo hello")
print(output)
```

## CLI

```bash
runnerx "echo hello"
```
