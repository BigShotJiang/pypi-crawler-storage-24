"""
DataForge v0.2 — Interpreter
Executes a parsed DfgScript against the real (or simulated) filesystem.
"""

from __future__ import annotations

import logging
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import List, Optional

from .parser import (
    AppendOp,
    DeleteOp,
    DfgScript,
    InsertAfterOp,
    Operation,
    WriteOp,
)

_log = logging.getLogger("dataforge")

# ---------------------------------------------------------------------------
# Public errors
# ---------------------------------------------------------------------------

class InterpreterError(Exception):
    """Fatal error — execution must stop."""


class OperationWarning(UserWarning):
    """Non-fatal mismatch during a change-file operation."""


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_one(
    script: DfgScript,
    *,
    dry_run: bool = False,
    backup_dir: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> List[str]:
    """Execute *script* and return the resulting list of lines.

    Parameters
    ----------
    script:
        Parsed :class:`~dataforge.parser.DfgScript`.
    dry_run:
        When *True* no files are written.  The function still returns the
        lines that *would* have been written.
    backup_dir:
        If set, a timestamped ``.bak`` copy of the target is created here
        before any write.
    logger:
        Defaults to the ``dataforge`` logger.

    Raises
    ------
    InterpreterError
        On any fatal condition (e.g. ``create-file`` on an existing path).
    """
    if logger is not None:
        global _log
        _log = logger

    target = Path(script.path)
    _validate_path(target)

    if script.command == "create-file":
        return _cmd_create(script, target, dry_run, backup_dir)
    if script.command == "replace-file":
        return _cmd_replace(script, target, dry_run, backup_dir)
    if script.command == "change-file":
        return _cmd_change(script, target, dry_run, backup_dir)
    if script.command == "remove-file":
        return _cmd_remove(script, target, dry_run, backup_dir)

    raise InterpreterError(f"Unknown file-level command: {script.command!r}")


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def _cmd_create(
    script: DfgScript,
    target: Path,
    dry_run: bool,
    backup_dir: Optional[str],
) -> List[str]:
    if target.exists():
        raise InterpreterError(
            f"create-file: '{target}' already exists. "
            "Use replace-file to overwrite or delete the file first."
        )
    lines = _build_content_lines(script.operations, context="create-file")
    _log.info("create-file '%s'  (%d lines)", target, len(lines))
    _write(target, lines, dry_run=dry_run, backup_dir=backup_dir)
    return lines


def _cmd_replace(
    script: DfgScript,
    target: Path,
    dry_run: bool,
    backup_dir: Optional[str],
) -> List[str]:
    lines = _build_content_lines(script.operations, context="replace-file")
    _log.info("replace-file '%s'  (%d lines)", target, len(lines))
    _write(target, lines, dry_run=dry_run, backup_dir=backup_dir)
    return lines


def _cmd_change(
    script: DfgScript,
    target: Path,
    dry_run: bool,
    backup_dir: Optional[str],
) -> List[str]:
    if target.exists():
        raw = target.read_text(encoding="utf-8")
        # splitlines keeps empty trailing lines if the file ends without \n
        lines: List[str] = raw.splitlines()
    else:
        _log.warning(
            "change-file: '%s' does not exist — starting from empty file.", target
        )
        lines = []

    lines = _apply_change_ops(lines, script.operations)
    _log.info("change-file '%s'  (%d lines after ops)", target, len(lines))
    _write(target, lines, dry_run=dry_run, backup_dir=backup_dir)
    return lines


# ---------------------------------------------------------------------------
# Line builder (create / replace)
# ---------------------------------------------------------------------------

def _build_content_lines(operations: List[Operation], context: str) -> List[str]:
    """Turn a sequence of WriteOp / AppendOp into an ordered list of strings."""
    lines: List[str] = []
    for op in operations:
        if isinstance(op, WriteOp):
            _expand(lines, op.line_num)
            lines[op.line_num - 1] = op.text
        elif isinstance(op, AppendOp):
            lines.append(op.text)
        else:
            raise InterpreterError(
                f"{context} does not support {type(op).__name__}. "
                "Only N+<text> and $+<text> are allowed here."
            )
    return lines


# ---------------------------------------------------------------------------
# Change-file ops engine
# ---------------------------------------------------------------------------

def _apply_change_ops(lines: List[str], operations: List[Operation]) -> List[str]:
    """Apply *operations* sequentially to *lines* (copy-on-write)."""
    lines = list(lines)  # work on a copy

    for op in operations:
        if isinstance(op, WriteOp):
            _expand(lines, op.line_num)
            old = lines[op.line_num - 1]
            lines[op.line_num - 1] = op.text
            _log.debug("  write   line %-4d  %r  →  %r", op.line_num, old, op.text)

        elif isinstance(op, DeleteOp):
            n = op.line_num
            if n > len(lines):
                _log.warning(
                    "  delete  line %-4d  SKIPPED — line does not exist "
                    "(file has %d lines)",
                    n, len(lines),
                )
            elif lines[n - 1] != op.text:
                _log.warning(
                    "  delete  line %-4d  SKIPPED — content mismatch\n"
                    "            expected: %r\n"
                    "            actual:   %r",
                    n, op.text, lines[n - 1],
                )
            else:
                lines.pop(n - 1)
                _log.debug("  delete  line %-4d  OK", n)

        elif isinstance(op, InsertAfterOp):
            n = op.line_num
            _expand(lines, n)
            lines.insert(n, op.text)
            _log.debug("  insert  after %-3d  %r", n, op.text)

        elif isinstance(op, AppendOp):
            lines.append(op.text)
            _log.debug("  append             %r", op.text)

        else:
            raise InterpreterError(f"Unknown operation type: {type(op)}")

    return lines


# ---------------------------------------------------------------------------
# Filesystem helpers
# ---------------------------------------------------------------------------

def _expand(lines: List[str], n: int) -> None:
    """Grow *lines* with empty strings until index *n-1* exists."""
    while len(lines) < n:
        lines.append("")


def _backup(target: Path, backup_dir: str) -> Path:
    ts = int(time.time() * 1000)
    bdir = Path(backup_dir)
    bdir.mkdir(parents=True, exist_ok=True)
    dest = bdir / f"{target.name}.{ts}.bak"
    shutil.copy2(target, dest)
    _log.info("  backup  '%s'  →  '%s'", target, dest)
    return dest


def _write(
    target: Path,
    lines: List[str],
    *,
    dry_run: bool,
    backup_dir: Optional[str],
) -> None:
    if dry_run:
        _log.info("  [dry-run] '%s' — no write performed", target)
        return

    # Backup before touching the original
    if backup_dir and target.exists():
        _backup(target, backup_dir)

    # Atomic write: write to a sibling temp file, then rename
    parent = target.parent
    parent.mkdir(parents=True, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(dir=parent, prefix=".dfg_tmp_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            if lines:
                fh.write("\n".join(lines))
                fh.write("\n")  # POSIX: files should end with a newline
        os.replace(tmp_path, target)
        _log.debug("  wrote   '%s'", target)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------------------
# Security
# ---------------------------------------------------------------------------

def _validate_path(target: Path) -> None:
    """Reject paths that look like traversal attempts."""
    try:
        resolved = target.resolve()
    except Exception as exc:
        raise InterpreterError(f"Cannot resolve path '{target}': {exc}") from exc

    # Block absolute paths that escape via '..'
    parts = target.parts
    if ".." in parts:
        raise InterpreterError(
            f"Path traversal detected in '{target}'. "
            "Use --allow-paths for absolute or traversal paths."
        )


# ---------------------------------------------------------------------------
# Multi-file entry point (v0.3)
# ---------------------------------------------------------------------------

def run(
    scripts,
    *,
    dry_run: bool = False,
    backup_dir=None,
    logger=None,
):
    """Execute one or a list of DfgScript blocks.

    Accepts either a single :class:`DfgScript` or a ``list[DfgScript]``
    (as returned by :func:`~dataforge.parser.parse`).

    Returns a ``dict[path, list[str]]`` mapping each target path to its
    resulting lines.
    """
    if isinstance(scripts, DfgScript):
        scripts = [scripts]

    results = {}
    for script in scripts:
        results[script.path] = run_one(
            script,
            dry_run=dry_run,
            backup_dir=backup_dir,
            logger=logger,
        )
    return results


def _cmd_remove(
    script: DfgScript,
    target: Path,
    dry_run: bool,
    backup_dir: Optional[str],
) -> List[str]:
    if script.operations:
        raise InterpreterError(
            f"remove-file '{target}': line-level operations are not allowed "
            "inside a remove-file block."
        )
    if not target.exists():
        raise InterpreterError(
            f"remove-file: '{target}' does not exist."
        )
    _log.info("remove-file '%s'", target)
    if dry_run:
        _log.info("  [dry-run] '%s' — no delete performed", target)
        return []
    if backup_dir:
        _backup(target, backup_dir)
    target.unlink()
    _log.debug("  deleted  '%s'", target)
    return []
