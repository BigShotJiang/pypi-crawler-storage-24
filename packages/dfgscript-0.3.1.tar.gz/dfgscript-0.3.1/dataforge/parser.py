"""
DataForge v0.3 — Parser
Tokenises and parses .dfg source into one or more DfgScript blocks.

Multi-file syntax (v0.3)
------------------------
Each file block is explicitly closed with `end-file`:

    create-file "notes.txt"
    1+Hello world
    end-file

    change-file "log.txt"
    $+--- done ---
    end-file

Single-file v0.2 .dfg files without `end-file` are still supported —
a trailing end-of-file implicitly closes the last open block.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Union

# ---------------------------------------------------------------------------
# Operation types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class WriteOp:
    """N+<text>  — write/replace line N with text (expands file if needed)."""
    line_num: int
    text: str

    def __str__(self) -> str:
        return f"{self.line_num}+{self.text}"


@dataclass(frozen=True)
class DeleteOp:
    """N-\"<text>\"  — delete line N only if content matches exactly."""
    line_num: int
    text: str

    def __str__(self) -> str:
        return f'{self.line_num}-"{self.text}"'


@dataclass(frozen=True)
class InsertAfterOp:
    """N><text>  — insert <text> after line N, shifting tail down."""
    line_num: int
    text: str

    def __str__(self) -> str:
        return f"{self.line_num}>{self.text}"


@dataclass(frozen=True)
class AppendOp:
    """$+<text>  — append <text> as a new final line."""
    text: str

    def __str__(self) -> str:
        return f"$+{self.text}"


Operation = Union[WriteOp, DeleteOp, InsertAfterOp, AppendOp]

# ---------------------------------------------------------------------------
# Script container
# ---------------------------------------------------------------------------

@dataclass
class DfgScript:
    command: str                          # 'create-file' | 'replace-file' | 'change-file'
    path: str                             # target file path (unquoted)
    operations: List[Operation] = field(default_factory=list)
    source_line: int = 0                  # 1-based line in .dfg where command was found

# ---------------------------------------------------------------------------
# Regexes
# ---------------------------------------------------------------------------

_FILE_CMD_RE = re.compile(r'^(create-file|replace-file|change-file|remove-file)\s+"(.+)"\s*$')
_END_FILE_RE = re.compile(r'^end-file\s*$')
_WRITE_RE    = re.compile(r'^(\d+)\+(.*)$')
_DELETE_RE   = re.compile(r'^(\d+)-"(.*)"$')
_INSERT_RE   = re.compile(r'^(\d+)>(.*)$')
_APPEND_RE   = re.compile(r'^\$\+(.*)$')

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class ParseError(Exception):
    """Raised when a .dfg source file cannot be parsed."""

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse(source: str) -> List[DfgScript]:
    """Parse *source* and return a list of :class:`DfgScript` blocks.

    A single-block .dfg returns a one-element list.
    Raises :class:`ParseError` on any syntax error.
    """
    lines = source.splitlines()
    scripts: List[DfgScript] = []
    current: DfgScript | None = None

    for i, raw in enumerate(lines):
        lineno = i + 1
        stripped = raw.strip()

        # Skip blanks and comments everywhere
        if not stripped or stripped.startswith('#'):
            continue

        # end-file closes the current block
        if _END_FILE_RE.match(stripped):
            if current is None:
                raise ParseError(f"Line {lineno}: 'end-file' with no open block.")
            scripts.append(current)
            current = None
            continue

        # File-level command — opens a new block
        m = _FILE_CMD_RE.match(stripped)
        if m:
            if current is not None:
                raise ParseError(
                    f"Line {lineno}: New file command '{stripped}' opened before "
                    f"previous block ('{current.path}') was closed with 'end-file'."
                )
            current = DfgScript(command=m.group(1), path=m.group(2), source_line=lineno)
            continue

        # Line-level operation — must be inside a block
        if current is None:
            raise ParseError(
                f"Line {lineno}: Operation '{stripped}' found outside a file block. "
                "Expected a file-level command (create-file / replace-file / change-file)."
            )
        current.operations.append(_parse_operation(stripped, lineno))

    # Implicit close — backwards-compatible with v0.2 single-block files
    if current is not None:
        scripts.append(current)

    if not scripts:
        raise ParseError("No file-level command found in source.")

    return scripts


def parse_one(source: str) -> DfgScript:
    """Convenience wrapper — parse a single-block .dfg and return the DfgScript directly.

    Raises :class:`ParseError` if the source does not contain exactly one block.
    Use parse() for multi-file scripts.
    """
    scripts = parse(source)
    if len(scripts) != 1:
        raise ParseError(
            f"Expected exactly one file block, got {len(scripts)}. "
            "Use parse() for multi-file scripts."
        )
    return scripts[0]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_operation(line: str, lineno: int) -> Operation:
    """Parse a single line-level operation. *lineno* is for error messages."""
    m = _WRITE_RE.match(line)
    if m:
        return WriteOp(int(m.group(1)), m.group(2))

    m = _DELETE_RE.match(line)
    if m:
        return DeleteOp(int(m.group(1)), m.group(2))

    m = _INSERT_RE.match(line)
    if m:
        return InsertAfterOp(int(m.group(1)), m.group(2))

    m = _APPEND_RE.match(line)
    if m:
        return AppendOp(m.group(1))

    raise ParseError(f"Line {lineno}: Unrecognised operation syntax: {line!r}")
