"""
DataForge v0.2 — CLI
Exposes the `dataforge` / `build` console commands.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .parser import parse, ParseError
from .interpreter import run, InterpreterError


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def _setup_logging(verbose: bool, log_path: str | None = None) -> logging.Logger:
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(levelname)s %(message)s"

    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if log_path:
        handlers.append(logging.FileHandler(log_path, encoding="utf-8"))

    logging.basicConfig(level=level, format=fmt, handlers=handlers)
    return logging.getLogger("dataforge")


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="dataforge",
        description=(
            "DataForge v0.2 — minimal, deterministic, LLM-friendly "
            "line-based file manipulation DSL.\n\n"
            "Execute a .dfg script:  dataforge script.dfg\n"
            "Preview without write:  dataforge script.dfg --dry-run"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("file", metavar="SCRIPT.dfg", help="DataForge script to execute")
    p.add_argument(
        "--dry-run", "--preview",
        dest="dry_run",
        action="store_true",
        help="Show what would be written without touching any files",
    )
    p.add_argument(
        "--backup-dir",
        metavar="PATH",
        help="Directory to store timestamped .bak copies before each write",
    )
    p.add_argument(
        "--log",
        metavar="PATH",
        help="Append log output to a file in addition to stderr",
    )
    p.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Emit debug-level detail about every operation",
    )
    p.add_argument(
        "--version",
        action="version",
        version="DataForge 0.3.1",
    )
    return p


# ---------------------------------------------------------------------------
# Preview renderer
# ---------------------------------------------------------------------------

def _print_preview(path: str, lines: list[str]) -> None:
    width = len(str(len(lines)))
    bar = "─" * (width + 3 + max((len(l) for l in lines), default=0))
    print(f"\n┌{bar}┐")
    print(f"│  Preview → '{path}'  ({len(lines)} lines)")
    print(f"├{bar}┤")
    for i, line in enumerate(lines, 1):
        print(f"│ {i:{width}d} │ {line}")
    print(f"└{bar}┘\n")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    """Entry point for both ``dataforge`` and ``build`` console scripts."""
    args = _build_arg_parser().parse_args(argv)
    logger = _setup_logging(args.verbose, args.log)

    dfg_path = Path(args.file)
    if not dfg_path.exists():
        logger.error("Script not found: %s", dfg_path)
        sys.exit(1)
    if dfg_path.suffix.lower() != ".dfg":
        logger.warning("File does not have a .dfg extension: %s", dfg_path)

    source = dfg_path.read_text(encoding="utf-8")

    # --- Parse ---
    try:
        scripts = parse(source)
    except ParseError as exc:
        logger.error("Parse error in '%s': %s", dfg_path, exc)
        sys.exit(1)

    logger.info("Parsed  %s  -> %d block(s)", dfg_path, len(scripts))
    for s in scripts:
        logger.info("  %s '%s'  (%d operations)", s.command, s.path, len(s.operations))

    # --- Execute ---
    try:
        results = run(
            scripts,
            dry_run=args.dry_run,
            backup_dir=args.backup_dir,
            logger=logger,
        )
    except InterpreterError as exc:
        logger.error("Fatal: %s", exc)
        sys.exit(1)

    # --- Preview output ---
    if args.dry_run:
        for path, lines in results.items():
            _print_preview(path, lines)

    sys.exit(0)
