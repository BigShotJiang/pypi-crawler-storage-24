from __future__ import annotations

import rerun as rr
from pydantic import Field

from common.message.message import Message


class Point2(Message):
    """
    A point representing a position in 2D space.

    Used in 2D coordinate systems.

    Example:
        ```python
        from common.message import Point2

        # Create a 2D point
        point = Point2(x=100.0, y=200.0)

        # Create using factory method
        origin = Point2.zero()

        # Convert to Rerun for visualization
        rerun_point = point.to_rerun()
        ```
    """

    _type = "antioch/point2"
    x: float = Field(description="X coordinate")
    y: float = Field(description="Y coordinate")

    def __repr__(self) -> str:
        """
        Return a readable string representation.

        :return: String representation.
        """

        return f"Point2(x={self.x}, y={self.y})"

    def __str__(self) -> str:
        """
        Return a readable string representation.

        :return: String representation.
        """

        return f"Point2(x={self.x}, y={self.y})"

    @classmethod
    def new(cls, x: float, y: float) -> Point2:
        """
        Create a new 2D point.

        :param x: The x coordinate.
        :param y: The y coordinate.
        :return: A 2D point.
        """

        return cls(x=x, y=y)

    @classmethod
    def zero(cls) -> Point2:
        """
        Create a point at the origin.

        :return: A point at (0, 0).
        """

        return cls(x=0.0, y=0.0)

    def to_rerun(self) -> rr.Points2D:
        """
        Convert to Rerun Points2D archetype for telemetry.

        :return: Rerun Points2D with this point's position.
        """

        return rr.Points2D(positions=[[self.x, self.y]])


class Point3(Message):
    """
    A point representing a position in 3D space.

    Used in 3D graphics and spatial coordinate systems.

    Example:
        ```python
        from common.message import Point3

        # Create a 3D point
        point = Point3(x=1.0, y=2.0, z=3.0)

        # Create at origin
        origin = Point3.zero()

        # Create using factory method
        p = Point3.new(x=0.5, y=1.0, z=0.0)
        ```
    """

    _type = "antioch/point3"
    x: float = Field(description="X coordinate")
    y: float = Field(description="Y coordinate")
    z: float = Field(description="Z coordinate")

    def __repr__(self) -> str:
        """
        Return a readable string representation.

        :return: String representation.
        """

        return f"Point3(x={self.x}, y={self.y}, z={self.z})"

    def __str__(self) -> str:
        """
        Return a readable string representation.

        :return: String representation.
        """

        return f"Point3(x={self.x}, y={self.y}, z={self.z})"

    @classmethod
    def new(cls, x: float, y: float, z: float) -> Point3:
        """
        Create a new 3D point.

        :param x: The x coordinate.
        :param y: The y coordinate.
        :param z: The z coordinate.
        :return: A 3D point.
        """

        return cls(x=x, y=y, z=z)

    @classmethod
    def zero(cls) -> Point3:
        """
        Create a point at the origin.

        :return: A point at (0, 0, 0).
        """

        return cls(x=0.0, y=0.0, z=0.0)

    def to_rerun(self) -> rr.Points3D:
        """
        Convert to Rerun Points3D archetype for telemetry.

        :return: Rerun Points3D with this point's position.
        """

        return rr.Points3D(positions=[[self.x, self.y, self.z]])
