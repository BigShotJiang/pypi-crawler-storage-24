from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class RerunConvertible(Protocol):
    """
    @docs-exclude
    Protocol for messages that can be converted to Rerun archetype format.

    Implement this protocol for any message type that has a corresponding Rerun
    archetype. The protocol provides a conversion method that returns the Rerun type.
    """

    def to_rerun(self) -> Any | None:
        """
        Convert this message to its Rerun archetype representation.

        :return: The Rerun archetype object, or None if this message should not be logged.
        """

        ...
