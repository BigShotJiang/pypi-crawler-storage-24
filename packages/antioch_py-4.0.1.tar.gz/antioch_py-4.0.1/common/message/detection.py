from __future__ import annotations

import rerun as rr
from pydantic import Field

from common.message.message import Message


class DetectionDistances(Message):
    """
    Detection distances for range-time plotting.

    Example:
        ```python
        from common.message import DetectionDistances

        # Detections at 3.5m and 4.5m
        detections = DetectionDistances(distances=[3.5, 4.5])
        sim.logger.telemetry("radar/detections/combined", detections)
        ```
    """

    _type = "antioch/detection_distances"

    distances: list[float] = Field(
        default_factory=list,
        description="Distances where detections occurred",
    )

    def to_rerun(self) -> rr.Scalars:
        """
        Convert to Rerun Scalars for time-series telemetry.

        :return: Rerun Scalars archetype with detection distances.
        """

        return rr.Scalars(scalars=self.distances)
