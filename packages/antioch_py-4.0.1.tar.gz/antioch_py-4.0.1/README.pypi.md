# antioch-py

The Python Module SDK for the [Antioch](https://antioch.com) autonomy simulation platform.

## Overview

`antioch-py` provides the client library for building Antioch modules — the core computational units that run inside Arks. Modules contain nodes that execute callbacks on a deterministic schedule, communicating via tokens.

## Installation

```bash
pip install antioch-py
```

## Quick Start

```python
from antioch import Module, Execution

def my_callback(execution: Execution) -> None:
    input_data = execution.input("sensor_data")
    result = process(input_data)
    execution.output("processed", result)

module = Module()
module.register("my_node", my_callback)
module.spin()
```

## Key Concepts

- **Module** — main entry point that handles configuration, node registration, and lifecycle management
- **Node** — a computational unit that runs in its own thread on a deterministic schedule
- **Execution** — passed to node callbacks, provides access to inputs, outputs, hardware read/write, and logging

## Documentation

Visit [antioch.com](https://antioch.com) for full documentation.

## License

MIT
