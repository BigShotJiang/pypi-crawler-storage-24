#
# Unified Query Algebra
#
# Copyright (c) 2023-2026 Cognica, Inc.
#

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from uqa.core.posting_list import PostingList
    from uqa.operators.base import ExecutionContext, Operator


@dataclass
class ExecutionStats:
    """Statistics from plan execution."""

    operator_name: str = ""
    elapsed_ms: float = 0.0
    result_count: int = 0
    children: list[ExecutionStats] = field(default_factory=list)


class PlanExecutor:
    """Recursive tree-walking plan executor with timing stats."""

    def __init__(self, context: ExecutionContext):
        self.context = context
        self._stats: ExecutionStats | None = None

    def execute(self, op: Operator) -> PostingList:
        """Execute an operator tree and collect stats."""
        result, stats = self._execute_with_stats(op)
        self._stats = stats
        return result

    def _execute_with_stats(self, op: Operator) -> tuple[PostingList, ExecutionStats]:
        from uqa.operators.boolean import IntersectOperator, UnionOperator, ComplementOperator
        from uqa.operators.primitive import FilterOperator, ScoreOperator
        from uqa.operators.base import ComposedOperator
        from uqa.operators.hybrid import (
            LogOddsFusionOperator,
            ProbBoolFusionOperator,
            ProbNotOperator,
        )

        stats = ExecutionStats(operator_name=type(op).__name__)
        child_stats: list[ExecutionStats] = []

        if isinstance(op, (IntersectOperator, UnionOperator)):
            for child in op.operands:
                _, cs = self._execute_with_stats(child)
                child_stats.append(cs)
        elif isinstance(op, ComplementOperator):
            _, cs = self._execute_with_stats(op.operand)
            child_stats.append(cs)
        elif isinstance(op, ComposedOperator):
            for child in op.operators:
                _, cs = self._execute_with_stats(child)
                child_stats.append(cs)
        elif isinstance(op, (LogOddsFusionOperator, ProbBoolFusionOperator)):
            for sig in op.signals:
                _, cs = self._execute_with_stats(sig)
                child_stats.append(cs)
        elif isinstance(op, ProbNotOperator):
            _, cs = self._execute_with_stats(op.signal)
            child_stats.append(cs)
        elif isinstance(op, ScoreOperator):
            _, cs = self._execute_with_stats(op.source)
            child_stats.append(cs)
        elif isinstance(op, FilterOperator) and op.source is not None:
            _, cs = self._execute_with_stats(op.source)
            child_stats.append(cs)

        start = time.perf_counter()
        result = op.execute(self.context)
        elapsed = (time.perf_counter() - start) * 1000.0

        stats.elapsed_ms = elapsed
        stats.result_count = len(result)
        stats.children = child_stats

        return result, stats

    def explain(self, op: Operator, indent: int = 0) -> str:
        """Return a tree-formatted explanation of the query plan."""
        lines: list[str] = []
        self._explain_recursive(op, lines, indent)
        return "\n".join(lines)

    def _explain_recursive(self, op: Operator, lines: list[str], indent: int) -> None:
        from uqa.operators.boolean import IntersectOperator, UnionOperator, ComplementOperator
        from uqa.operators.primitive import (
            TermOperator,
            VectorSimilarityOperator,
            KNNOperator,
            FilterOperator,
            FacetOperator,
            IndexScanOperator,
            ScoreOperator,
        )
        from uqa.operators.base import ComposedOperator
        from uqa.operators.hybrid import (
            HybridTextVectorOperator,
            LogOddsFusionOperator,
            ProbBoolFusionOperator,
            ProbNotOperator,
            SemanticFilterOperator,
        )
        from uqa.graph.operators import (
            TraverseOperator,
            PatternMatchOperator,
            RegularPathQueryOperator,
        )

        prefix = "  " * indent

        match op:
            case TermOperator(term=t, field=f):
                lines.append(f"{prefix}TermOp(term={t!r}, field={f!r})")
            case VectorSimilarityOperator(threshold=th, field=f):
                lines.append(f"{prefix}VectorSimOp(threshold={th}, field={f!r})")
            case KNNOperator(k=k, field=f):
                lines.append(f"{prefix}KNNOp(k={k}, field={f!r})")
            case IndexScanOperator(field=f, predicate=p):
                lines.append(
                    f"{prefix}IndexScanOp(field={f!r}, "
                    f"index={op.index.index_def.name!r})"
                )
            case ScoreOperator(query_terms=qt, field=f):
                scorer_name = type(op.scorer).__name__
                lines.append(
                    f"{prefix}ScoreOp(scorer={scorer_name}, "
                    f"terms={qt!r}, field={f!r})"
                )
                self._explain_recursive(op.source, lines, indent + 1)
            case FilterOperator(field=f):
                lines.append(f"{prefix}FilterOp(field={f!r})")
                if hasattr(op, "source") and op.source is not None:
                    self._explain_recursive(op.source, lines, indent + 1)
            case LogOddsFusionOperator(signals=sigs):
                lines.append(
                    f"{prefix}LogOddsFusion(alpha={op.alpha}, "
                    f"signals={len(sigs)})"
                )
                for sig in sigs:
                    self._explain_recursive(sig, lines, indent + 1)
            case ProbBoolFusionOperator(signals=sigs):
                lines.append(
                    f"{prefix}ProbBoolFusion(mode={op.mode!r}, "
                    f"signals={len(sigs)})"
                )
                for sig in sigs:
                    self._explain_recursive(sig, lines, indent + 1)
            case ProbNotOperator(signal=sig):
                lines.append(f"{prefix}ProbNot")
                self._explain_recursive(sig, lines, indent + 1)
            case TraverseOperator():
                lines.append(
                    f"{prefix}TraverseOp(start={op.start_vertex}, "
                    f"label={op.label!r}, hops={op.max_hops})"
                )
            case PatternMatchOperator():
                n_vp = len(op.pattern.vertex_patterns)
                n_ep = len(op.pattern.edge_patterns)
                lines.append(
                    f"{prefix}PatternMatchOp(vertices={n_vp}, "
                    f"edges={n_ep})"
                )
            case RegularPathQueryOperator():
                lines.append(
                    f"{prefix}RPQOp(start={op.start_vertex})"
                )
            case IntersectOperator(operands=ops):
                lines.append(f"{prefix}Intersect")
                for child in ops:
                    self._explain_recursive(child, lines, indent + 1)
            case UnionOperator(operands=ops):
                lines.append(f"{prefix}Union")
                for child in ops:
                    self._explain_recursive(child, lines, indent + 1)
            case ComplementOperator(operand=inner):
                lines.append(f"{prefix}Complement")
                self._explain_recursive(inner, lines, indent + 1)
            case ComposedOperator(operators=ops):
                lines.append(f"{prefix}Composed")
                for child in ops:
                    self._explain_recursive(child, lines, indent + 1)
            case _:
                lines.append(f"{prefix}{type(op).__name__}")

    @property
    def last_stats(self) -> ExecutionStats | None:
        return self._stats
