class InterruptException(Exception):
    pass