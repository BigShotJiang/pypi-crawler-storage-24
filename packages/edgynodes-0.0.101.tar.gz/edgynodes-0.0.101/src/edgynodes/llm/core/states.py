import edgygraph as e
from llmir import AIMessages, AITool, AIChunkToolCall
from pydantic import Field
from typing import Callable, Any, Tuple, Protocol, runtime_checkable

from ..core.streams import LLMStream

class StateAttribute(e.StateAttribute):
    messages: list[AIMessages] = Field(default_factory=list[AIMessages])
    new_messages: list[AIMessages] = Field(default_factory=list[AIMessages])

    tools: list[AITool] = Field(default_factory=list[AITool])

    turn_count: int = 0


class SharedAttribute(e.SharedAttribute):
    stream: LLMStream | None = None

    tool_functions: dict[str, Callable[..., Any]] = Field(default_factory=dict[str, Callable[..., Any]]) # name -> function

    new_tool_calls: list[AIChunkToolCall] = Field(default_factory=list[AIChunkToolCall])
    new_tool_call_results: list[Tuple[AIChunkToolCall, Any]] = Field(default_factory=list[Tuple[AIChunkToolCall, Any]])


@runtime_checkable
class StateProtocol(e.StateProtocol, Protocol):

    llm: StateAttribute

@runtime_checkable
class SharedProtocol(e.SharedProtocol, Protocol):

    llm: SharedAttribute