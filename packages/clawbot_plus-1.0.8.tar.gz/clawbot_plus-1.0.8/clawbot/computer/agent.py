"""
🤖 JARVIS — Autonomous Computer Control Agent
Full Windows control with security, app discovery, window management, and persistent memory.
"""
import os
import ollama
import re
import time
import base64
import json
import subprocess
import pyautogui
from io import BytesIO
from pathlib import Path
from datetime import datetime
from PIL import ImageGrab
from rich.console import Console
from rich.panel import Panel

console = Console()
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.4

# ── Import JARVIS modules ──
from actions import (
    reliable_click, reliable_type, smart_wait, ensure_window_focus,
    bring_window_to_front, drag_and_drop, select_all_and_copy
)
from security import is_command_safe, log_action
from system_control import (
    set_volume, mute_toggle, set_brightness, get_brightness,
    wifi_toggle, bluetooth_toggle, get_network_info,
    lock_screen, shutdown, cancel_shutdown, restart, sleep_pc,
    get_system_info, get_running_processes, kill_process, open_app_by_name,
    create_file, read_file, list_directory
)
from window_manager import (
    list_windows, focus_window, minimize_window, maximize_window,
    close_window, resize_window, move_window, snap_window
)

# ════════════════════════════════════════════════════════
# 📁 PATHS
# ════════════════════════════════════════════════════════
COMPUTER_DIR = Path(__file__).parent
MEMORY_FILE = COMPUTER_DIR / "memory.json"
APPS_CACHE  = COMPUTER_DIR / "apps_cache.json"

# ════════════════════════════════════════════════════════
# 🧠 PERSISTENT MEMORY
# ════════════════════════════════════════════════════════

def load_memory() -> dict:
    if MEMORY_FILE.exists():
        try:
            return json.loads(MEMORY_FILE.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {"tasks": [], "learnings": []}


def save_memory(mem: dict):
    try:
        MEMORY_FILE.write_text(json.dumps(mem, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        console.print(f"[red]Memory save error: {e}[/red]")


def record_task(mem: dict, task: str, steps: list[dict], success: bool):
    entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "task": task,
        "steps": [s['summary'] for s in steps[-10:]],
        "success": success,
    }
    mem["tasks"].append(entry)
    mem["tasks"] = mem["tasks"][-50:]

    if success and steps:
        shell_cmds = [s['summary'] for s in steps if s['summary'].startswith('Shell:')]
        if shell_cmds:
            learning = f"Task '{task}' → success via: {shell_cmds[0]}"
            if learning not in mem["learnings"]:
                mem["learnings"].append(learning)
                mem["learnings"] = mem["learnings"][-30:]

    save_memory(mem)


def get_relevant_learnings(mem: dict, task: str) -> str:
    if not mem.get("learnings") and not mem.get("tasks"):
        return ""
    parts = []
    if mem.get("learnings"):
        parts.append("Past successful strategies:")
        for l in mem["learnings"][-10:]:
            parts.append(f"  • {l}")
    task_lower = task.lower()
    keywords = set(task_lower.split())
    similar = []
    for t in reversed(mem.get("tasks", [])[-20:]):
        t_words = set(t["task"].lower().split())
        if keywords & t_words:
            status = "✅" if t["success"] else "❌"
            similar.append(f"  {status} '{t['task']}' → {', '.join(t['steps'][:3])}")
    if similar:
        parts.append("Similar past tasks:")
        parts.extend(similar[:5])
    return "\n".join(parts) if parts else ""


# ════════════════════════════════════════════════════════
# 📱 APP DISCOVERY
# ════════════════════════════════════════════════════════

APP_KNOWLEDGE = {
    "chrome":     {"cat": "Browser",    "open": "start chrome", "tasks": "search web, open URLs, download files, manage tabs", "keys": "Ctrl+T new tab, Ctrl+L address bar, Ctrl+W close tab"},
    "edge":       {"cat": "Browser",    "open": "start msedge", "tasks": "search web, open URLs, download files", "keys": "Ctrl+T new tab, Ctrl+L address bar"},
    "firefox":    {"cat": "Browser",    "open": "start firefox", "tasks": "search web, open URLs, browse privately", "keys": "Ctrl+T new tab, Ctrl+L address bar"},
    "whatsapp":   {"cat": "Chat",       "open": "start whatsapp:", "tasks": "send messages, make voice/video calls, send files/photos", "keys": "Ctrl+N new chat, Ctrl+Shift+M mute"},
    "telegram":   {"cat": "Chat",       "open": "start tg://", "tasks": "send messages, send files, create groups, make calls", "keys": ""},
    "discord":    {"cat": "Chat",       "open": "start discord:", "tasks": "voice chat, text chat, screen share, join servers", "keys": "Ctrl+Shift+M mute, Ctrl+Shift+D deafen"},
    "spotify":    {"cat": "Media",      "open": "start spotify:", "tasks": "play music, create playlists, search songs, podcasts", "keys": "Space pause, Ctrl+Right next track"},
    "vlc":        {"cat": "Media",      "open": "start vlc", "tasks": "play videos, play audio, stream media", "keys": "Space pause, F fullscreen"},
    "notepad":    {"cat": "Editor",     "open": "start notepad", "tasks": "write text, edit files, find/replace text", "keys": "Ctrl+S save, Ctrl+F find"},
    "code":       {"cat": "Dev",        "open": "start code", "tasks": "write code, debug, terminal, extensions, git", "keys": "Ctrl+P open file, Ctrl+Shift+P command palette, Ctrl+` terminal"},
    "word":       {"cat": "Office",     "open": "start winword", "tasks": "write documents, format text, insert tables/images", "keys": "Ctrl+B bold, Ctrl+I italic"},
    "excel":      {"cat": "Office",     "open": "start excel", "tasks": "spreadsheets, formulas, charts, data analysis", "keys": "Ctrl+Shift+L filter, F2 edit cell"},
    "powerpoint": {"cat": "Office",     "open": "start powerpnt", "tasks": "create presentations, add slides, animations", "keys": "F5 slideshow"},
    "outlook":    {"cat": "Office",     "open": "start outlook", "tasks": "email, calendar, contacts, schedule meetings", "keys": "Ctrl+N new email, Ctrl+R reply"},
    "paint":      {"cat": "Creative",   "open": "start ms-paint:", "tasks": "draw, edit images, crop, resize", "keys": ""},
    "photos":     {"cat": "Media",      "open": "start ms-photos:", "tasks": "view photos, edit images, slideshows", "keys": ""},
    "calculator": {"cat": "Utility",    "open": "start calculator:", "tasks": "math calculations, unit conversion", "keys": ""},
    "settings":   {"cat": "System",     "open": "start ms-settings:", "tasks": "WiFi, Bluetooth, display, sound, updates, accounts", "keys": ""},
    "terminal":   {"cat": "System",     "open": "start wt", "tasks": "run commands, PowerShell, CMD, scripts", "keys": "Ctrl+Shift+T new tab"},
    "explorer":   {"cat": "System",     "open": "start explorer", "tasks": "browse files, copy/move/delete files, search files", "keys": "Ctrl+E search, Alt+Up parent folder"},
    "git":        {"cat": "Dev",        "open": "shell", "tasks": "version control, commit, push, pull, branch", "keys": ""},
    "node":       {"cat": "Dev",        "open": "shell", "tasks": "run JavaScript, npm packages, web servers", "keys": ""},
    "python":     {"cat": "Dev",        "open": "shell", "tasks": "run Python scripts, pip install, REPL", "keys": ""},
}


def discover_apps() -> dict:
    if APPS_CACHE.exists():
        try:
            cache = json.loads(APPS_CACHE.read_text(encoding='utf-8'))
            cached_time = datetime.strptime(cache.get("scanned_at", ""), "%Y-%m-%d %H:%M")
            if (datetime.now() - cached_time).total_seconds() < 3600:
                return cache
        except Exception:
            pass

    console.print("[dim]🔍 Scanning installed apps...[/dim]")
    apps_found = {}

    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-StartApps | Select-Object Name, AppID | ConvertTo-Json"],
            capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=10
        )
        if result.stdout:
            start_apps = json.loads(result.stdout)
            if isinstance(start_apps, dict):
                start_apps = [start_apps]
            for app in start_apps:
                name = app.get("Name", "").strip()
                app_id = app.get("AppID", "").strip()
                if name and len(name) > 1:
                    apps_found[name.lower()] = {"name": name, "app_id": app_id, "source": "start_menu"}
    except Exception:
        pass

    try:
        desktop = Path.home() / "Desktop"
        public_desktop = Path("C:/Users/Public/Desktop")
        for d in [desktop, public_desktop]:
            if d.exists():
                for f in d.glob("*.lnk"):
                    apps_found[f.stem.lower()] = {"name": f.stem, "app_id": str(f), "source": "desktop_shortcut"}
    except Exception:
        pass

    enriched = {}
    for key, info in apps_found.items():
        enriched[key] = info
        for kw, knowledge in APP_KNOWLEDGE.items():
            if kw in key or key in kw:
                enriched[key]["knowledge"] = knowledge
                break

    result_data = {
        "scanned_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "app_count": len(enriched),
        "apps": enriched,
    }

    try:
        APPS_CACHE.write_text(json.dumps(result_data, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception:
        pass

    return result_data


def build_app_context(app_data: dict) -> str:
    lines = []
    categorized: dict[str, list] = {}
    for key, info in app_data.get("apps", {}).items():
        k = info.get("knowledge")
        if k:
            cat = k["cat"]
            if cat not in categorized:
                categorized[cat] = []
            categorized[cat].append(
                f"  {info['name']}: open=`{k['open']}` | tasks: {k['tasks']}"
                + (f" | keys: {k['keys']}" if k.get('keys') else "")
            )
    if not categorized:
        return ""
    lines.append("INSTALLED APPS ON THIS PC:")
    for cat in sorted(categorized.keys()):
        lines.append(f"[{cat}]")
        lines.extend(categorized[cat])
    unknown = [info['name'] for info in app_data.get("apps", {}).values() if 'knowledge' not in info]
    if unknown:
        top = unknown[:20]
        lines.append(f"[Other] {', '.join(top)}" + (f" +{len(unknown)-20} more" if len(unknown) > 20 else ""))
    return "\n".join(lines)


# ════════════════════════════════════════════════════════
# 📸 SCREENSHOTS
# ════════════════════════════════════════════════════════

def take_full_screenshot_b64() -> str:
    try:
        screenshot = ImageGrab.grab()
        screenshot.thumbnail((1280, 1024))
        buf = BytesIO()
        screenshot.save(buf, format="JPEG", quality=70)
        return base64.b64encode(buf.getvalue()).decode('utf-8')
    except Exception as e:
        console.print(f"[red]Screenshot error: {e}[/red]")
        return ""


def take_active_window_screenshot_b64() -> tuple[str, tuple[int, int]]:
    try:
        import win32gui
        hwnd = win32gui.GetForegroundWindow()
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        sw, sh = pyautogui.size()
        left, top = max(0, left), max(0, top)
        right, bottom = min(sw, right), min(sh, bottom)
        if right - left < 100 or bottom - top < 100:
            return take_full_screenshot_b64(), (0, 0)
        screenshot = ImageGrab.grab(bbox=(left, top, right, bottom))
        buf = BytesIO()
        screenshot.save(buf, format="JPEG", quality=75)
        return base64.b64encode(buf.getvalue()).decode('utf-8'), (left, top)
    except Exception:
        return take_full_screenshot_b64(), (0, 0)


# ════════════════════════════════════════════════════════
# 🛠️ HELPERS
# ════════════════════════════════════════════════════════

def run_shell(cmd: str) -> str:
    """Run shell command with security check."""
    is_safe, reason = is_command_safe(cmd)
    if not is_safe:
        log_action("shell_blocked", f"{cmd} → {reason}", blocked=True)
        console.print(f"[bold red]{reason}[/bold red]")
        return reason

    log_action("shell", cmd)
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=15
        )
        out = (result.stdout or "").strip()
        err = (result.stderr or "").strip()
        if result.returncode != 0 and err:
            return f"ERROR: {err[:200]}"
        return out if out else "(done)"
    except subprocess.TimeoutExpired:
        return "ERROR: timed out"
    except Exception as e:
        return f"ERROR: {e}"


IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.tiff'}


def load_image_b64(path: str) -> str | None:
    try:
        from PIL import Image
        img = Image.open(path)
        img.thumbnail((1280, 1024))
        buf = BytesIO()
        img.convert('RGB').save(buf, format='JPEG', quality=85)
        return base64.b64encode(buf.getvalue()).decode('utf-8')
    except Exception:
        return None


def extract_file_paths(text: str) -> list[str]:
    patterns = [
        r'[A-Za-z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]+',
        r'/(?:[^/\0]+/)*[^/\0]+',
    ]
    found = []
    for pat in patterns:
        for m in re.finditer(pat, text):
            p = m.group(0).strip('"\'')
            ext = os.path.splitext(p)[1].lower()
            if ext in IMAGE_EXTS and os.path.isfile(p):
                found.append(p)
    return list(dict.fromkeys(found))


async def _ask_llm(llm, prompt: str, b64_img: str | None = None, extra_images: list[str] | None = None):
    from browser_use.llm.messages import UserMessage
    content: list = [{"type": "text", "text": prompt}]
    if b64_img:
        content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64_img}"}})
    if extra_images:
        for img_path in extra_images:
            b64 = load_image_b64(img_path)
            if b64:
                content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    messages = [UserMessage(content=content)]
    response = await llm.ainvoke(messages)
    return response.completion.strip()


def _parse_json(raw: str) -> dict:
    if "```json" in raw:
        raw = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        raw = raw.split("```")[1].split("```")[0].strip()
    s, e = raw.find('{'), raw.rfind('}')
    if s != -1 and e != -1:
        raw = raw[s:e+1]
    return json.loads(raw)


# ════════════════════════════════════════════════════════
# 🚀 JARVIS MAIN LOOP
# ════════════════════════════════════════════════════════

def get_system_context() -> str:
    import getpass, socket, platform
    user = getpass.getuser()
    pc = socket.gethostname()
    cwd = os.getcwd()
    home = str(Path.home())
    paths = {}
    for folder in ['Downloads', 'Documents', 'Desktop']:
        res = subprocess.run(["powershell", "[Environment]::GetFolderPath('"+folder+"')"], capture_output=True, text=True, encoding='utf-8', errors='ignore')
        paths[folder] = res.stdout.strip() or f"{home}\\{folder}"
    return (
        f"--- SYSTEM CONTEXT ---\n"
        f"PC: {pc} | User: {user}\n"
        f"CWD: {cwd} | Home: {home}\n"
        f"Downloads: {paths['Downloads']}\n"
        f"Documents: {paths['Documents']}\n"
        f"Desktop: {paths['Desktop']}\n"
        f"OS: {platform.system()} {platform.release()}\n"
        f"----------------------"
    )


async def run_computer_task(llm, task: str):
    """JARVIS — Full Computer Control Agent."""

    # ── Phase 1: Context & Discovery ──
    sys_context = get_system_context()
    mem = load_memory()
    app_data = discover_apps()
    app_context = build_app_context(app_data)
    learnings = get_relevant_learnings(mem, task)

    console.print(Panel(
        f"[bold cyan]🤖 J.A.R.V.I.S. — Computer Control[/bold cyan]\n"
        f"[dim]Task:[/dim] {task}\n"
        f"[dim]Apps:[/dim] {app_data.get('app_count', 0)} discovered  |  "
        f"[dim]Memory:[/dim] {len(mem.get('tasks', []))} past tasks  |  "
        f"[dim]Learnings:[/dim] {len(mem.get('learnings', []))}  |  "
        f"[dim]Security:[/dim] [green]Active[/green]",
        border_style="cyan", padding=(0, 2)
    ))

    width, height = pyautogui.size()
    memory: list[dict] = []
    needs_screenshot = False
    extra_images = extract_file_paths(task)
    if extra_images:
        console.print(f"[dim]📁 {len(extra_images)} image(s) attached from task[/dim]")
    task_success = False

    # ── JARVIS System Prompt ──
    SYSTEM = f"""You are JARVIS — an intelligent AI assistant with FULL CONTROL of this Windows {width}x{height} PC.
You are precise, efficient, and never repeat failing actions.

{sys_context}

You know every app installed and how humans use them.

{app_context}

{f"MEMORY (learn from past):{chr(10)}{learnings}" if learnings else ""}

STRATEGY (follow in order of preference):
1. Direct system commands FIRST — shell, system_control actions (instant, most reliable)
2. Keyboard shortcuts next — hotkeys, Ctrl+shortcuts (fast, reliable)
3. Focus the target app BEFORE any GUI interaction
4. GUI clicks ONLY as last resort (after 1-3 fail)

ACTIONS — Return ONE JSON per step with "thought":

--- SYSTEM CONTROL (preferred — instant, no GUI needed) ---
Shell:            {{"thought":"...", "action":"shell",            "command":"start chrome"}}
Volume:           {{"thought":"...", "action":"set_volume",       "level":50}}
Mute:             {{"thought":"...", "action":"mute_toggle"}}
Brightness:       {{"thought":"...", "action":"set_brightness",   "level":80}}
WiFi:             {{"thought":"...", "action":"wifi",             "enable":true}}
Bluetooth:        {{"thought":"...", "action":"bluetooth",        "enable":true}}
System info:      {{"thought":"...", "action":"system_info"}}
Running apps:     {{"thought":"...", "action":"list_processes"}}
Kill app:         {{"thought":"...", "action":"kill_process",     "name":"notepad"}}
Lock screen:      {{"thought":"...", "action":"lock_screen"}}
Shutdown:         {{"thought":"...", "action":"shutdown",         "delay":30}}
Restart:          {{"thought":"...", "action":"restart",          "delay":10}}
Sleep:            {{"thought":"...", "action":"sleep"}}
File create:      {{"thought":"...", "action":"create_file",      "path":"C:/test.txt", "content":"hello"}}
Open file/folder: {{"thought":"...", "action":"shell",            "command":"start explorer C:\\Users"}}

--- WINDOW MANAGEMENT ---
Focus app:        {{"thought":"...", "action":"focus_app",        "window_title":"WhatsApp"}}
Minimize:         {{"thought":"...", "action":"minimize_window",  "window_title":"Notepad"}}
Maximize:         {{"thought":"...", "action":"maximize_window",  "window_title":"Chrome"}}
Close window:     {{"thought":"...", "action":"close_window",     "window_title":"Calculator"}}
Snap window:      {{"thought":"...", "action":"snap_window",      "window_title":"Chrome", "position":"left"}}
List windows:     {{"thought":"...", "action":"list_windows"}}

--- GUI INTERACTIONS (use only when system commands won't work) ---
Click:            {{"thought":"...", "action":"click",            "x":500, "y":300}}
Double-click:     {{"thought":"...", "action":"double_click",     "x":500, "y":300}}
Right-click:      {{"thought":"...", "action":"right_click",      "x":500, "y":300}}
Type:             {{"thought":"...", "action":"type",             "text":"hello"}}
Hotkey:           {{"thought":"...", "action":"hotkey",           "keys":["ctrl","c"]}}
Press key:        {{"thought":"...", "action":"press",            "key":"enter"}}
Scroll:           {{"thought":"...", "action":"scroll",           "direction":"down", "amount":3, "x":640, "y":400}}
Drag:             {{"thought":"...", "action":"drag",             "x1":100, "y1":100, "x2":500, "y2":500}}

--- WEB SEARCH (instant info without browser) ---
Web search:       {{"thought":"...", "action":"web_search",       "query":"latest news about AI"}}
Web fetch:        {{"thought":"...", "action":"web_fetch",        "url":"https://example.com"}}

--- FLOW CONTROL ---
Done:             {{"thought":"...", "action":"done",             "result":"what was accomplished"}}
Screenshot:       {{"thought":"...", "action":"take_screenshot"}}

CRITICAL RULES:
- SECURITY: All shell commands are checked. Dangerous commands (format, del /s, system32) are BLOCKED.
- After clicking a text field, IMMEDIATELY type in the next step. Never click the same field twice.
- NEVER repeat the same action more than 2 times. If it fails, use a DIFFERENT approach.
- Before any GUI click/type, use "focus_app" to bring the target app to front.
- WhatsApp: Click search bar ONCE → type contact name → click result → type message → press Enter.
- For information/search tasks, use "web_search" FIRST before opening a browser. It is faster and more reliable.
- Output ONLY valid JSON. No markdown, no extra text."""

    win_offset = (0, 0)
    log_action("task_start", task)

    for step in range(1, 41):  # 40 steps max
        mem_text = ""
        if memory:
            mem_text = "\nSession history:\n" + "\n".join(
                f"  {m['step']}. {m['summary']}" for m in memory[-8:]
            )

        prompt = f"{SYSTEM}{mem_text}\n\nTask: {task}\n"

        # ── Loop Detection ──
        if len(memory) >= 3:
            last_3 = [m['summary'] for m in memory[-3:]]
            if len(set(last_3)) == 1 or all('screen(' in s for s in last_3):
                prompt += "\n⚠️ CRITICAL: You repeated the SAME ACTION 3x! It is NOT WORKING. You MUST use a COMPLETELY DIFFERENT approach NOW.\n"
                prompt += "Try: keyboard shortcut, shell command, or focus_app first.\n"
                console.print(f"[bold red]🔄 Loop detected! Forcing different approach...[/bold red]")
            elif len(memory) >= 2 and memory[-1]['summary'] == memory[-2]['summary']:
                prompt += "\n⚠️ You repeated the same action twice. Switch strategy if it fails again.\n"

        if needs_screenshot:
            prompt += "Screenshot attached. Analyze and decide next action."
        else:
            prompt += "No screenshot. Use system commands/keyboard first. Request screenshot only if needed."

        b64 = None
        if needs_screenshot:
            if step == 1 or len(memory) == 0:
                b64 = take_full_screenshot_b64()
                win_offset = (0, 0)
                console.print(f"\n[bold cyan]📍 Step {step}:[/bold cyan] [dim](full scan)[/dim]", end=" ")
            else:
                time.sleep(0.6)
                b64, win_offset = take_active_window_screenshot_b64()
                ox, oy = win_offset
                console.print(f"\n[bold cyan]📍 Step {step}:[/bold cyan] [dim](window @ {ox},{oy})[/dim]", end=" ")
            needs_screenshot = False
        else:
            console.print(f"\n[bold cyan]📍 Step {step}:[/bold cyan] [dim](thinking)[/dim]", end=" ")

        try:
            with console.status("[dim]JARVIS thinking...[/dim]", spinner="dots"):
                raw = await _ask_llm(llm, prompt, b64_img=b64, extra_images=extra_images)

            action = _parse_json(raw)
            act = action.get('action')
            thought = action.get('thought', '')

            if thought:
                console.print(f"\n[magenta]🧠 {thought}[/magenta]")

            # ══════════════════════════════════════════
            # EXECUTE ACTION
            # ══════════════════════════════════════════

            # --- System Control Actions ---
            if act == 'set_volume':
                level = int(action.get('level', 50))
                console.print(f"[green]🔊 Volume → {level}%[/green]")
                set_volume(level)
                memory.append({"step": step, "summary": f"Volume: {level}%"})
                log_action("set_volume", str(level))

            elif act == 'mute_toggle':
                console.print("[green]🔇 Mute toggle[/green]")
                mute_toggle()
                memory.append({"step": step, "summary": "Mute toggled"})
                log_action("mute_toggle", "toggled")

            elif act == 'set_brightness':
                level = int(action.get('level', 50))
                console.print(f"[green]💡 Brightness → {level}%[/green]")
                out = set_brightness(level)
                console.print(f"[dim]   → {out[:100]}[/dim]")
                memory.append({"step": step, "summary": f"Brightness: {level}%"})

            elif act == 'wifi':
                enable = action.get('enable', True)
                state = "ON" if enable else "OFF"
                console.print(f"[green]📡 WiFi → {state}[/green]")
                out = wifi_toggle(enable)
                console.print(f"[dim]   → {out[:100]}[/dim]")
                memory.append({"step": step, "summary": f"WiFi: {state}"})

            elif act == 'bluetooth':
                enable = action.get('enable', True)
                state = "ON" if enable else "OFF"
                console.print(f"[green]🔵 Bluetooth → {state}[/green]")
                out = bluetooth_toggle(enable)
                console.print(f"[dim]   → {out[:100]}[/dim]")
                memory.append({"step": step, "summary": f"Bluetooth: {state}"})

            elif act == 'system_info':
                console.print("[green]📊 System Info[/green]")
                out = get_system_info()
                console.print(f"[dim]{out}[/dim]")
                memory.append({"step": step, "summary": f"System info: {out[:60]}"})

            elif act == 'list_processes':
                console.print("[green]📋 Running Processes[/green]")
                out = get_running_processes()
                console.print(f"[dim]{out[:300]}[/dim]")
                memory.append({"step": step, "summary": f"Listed processes"})

            elif act == 'kill_process':
                name = action.get('name', '')
                console.print(f"[yellow]💀 Kill: {name}[/yellow]")
                out = kill_process(name)
                console.print(f"[dim]   → {out}[/dim]")
                memory.append({"step": step, "summary": f"Kill: {name} → {out[:40]}"})
                log_action("kill_process", name)

            elif act == 'lock_screen':
                console.print("[yellow]🔒 Locking screen...[/yellow]")
                lock_screen()
                memory.append({"step": step, "summary": "Screen locked"})
                log_action("lock_screen", "locked")

            elif act == 'shutdown':
                delay = int(action.get('delay', 30))
                console.print(f"[bold red]⚡ Shutdown in {delay}s[/bold red]")
                shutdown(delay)
                memory.append({"step": step, "summary": f"Shutdown scheduled: {delay}s"})
                log_action("shutdown", f"delay={delay}")

            elif act == 'restart':
                delay = int(action.get('delay', 10))
                console.print(f"[bold red]🔄 Restart in {delay}s[/bold red]")
                restart(delay)
                memory.append({"step": step, "summary": f"Restart scheduled: {delay}s"})
                log_action("restart", f"delay={delay}")

            elif act == 'sleep':
                console.print("[yellow]😴 Sleeping...[/yellow]")
                sleep_pc()
                memory.append({"step": step, "summary": "PC sleeping"})

            elif act == 'create_file':
                fpath = action.get('path', '')
                content = action.get('content', '')
                console.print(f"[green]📄 Create: {fpath}[/green]")
                out = create_file(fpath, content)
                console.print(f"[dim]   → {out}[/dim]")
                memory.append({"step": step, "summary": f"Created: {fpath}"})
                log_action("create_file", fpath)

            # --- Window Management ---
            elif act == 'focus_app':
                title = action.get('window_title', '')
                console.print(f"[cyan]🪟 Focus: {title}[/cyan]")
                result = focus_window(title)
                console.print(f"[dim]   → {result}[/dim]")
                memory.append({"step": step, "summary": f"Focused: {title}"})
                time.sleep(0.3)
                needs_screenshot = True

            elif act == 'minimize_window':
                title = action.get('window_title', '')
                console.print(f"[cyan]⬇️ Minimize: {title}[/cyan]")
                result = minimize_window(title)
                console.print(f"[dim]   → {result}[/dim]")
                memory.append({"step": step, "summary": f"Minimized: {title}"})

            elif act == 'maximize_window':
                title = action.get('window_title', '')
                console.print(f"[cyan]⬆️ Maximize: {title}[/cyan]")
                result = maximize_window(title)
                console.print(f"[dim]   → {result}[/dim]")
                memory.append({"step": step, "summary": f"Maximized: {title}"})

            elif act == 'close_window':
                title = action.get('window_title', '')
                console.print(f"[cyan]❌ Close: {title}[/cyan]")
                result = close_window(title)
                console.print(f"[dim]   → {result}[/dim]")
                memory.append({"step": step, "summary": f"Closed: {title}"})
                log_action("close_window", title)

            elif act == 'snap_window':
                title = action.get('window_title', '')
                position = action.get('position', 'left')
                console.print(f"[cyan]📐 Snap: {title} → {position}[/cyan]")
                result = snap_window(title, position)
                console.print(f"[dim]   → {result}[/dim]")
                memory.append({"step": step, "summary": f"Snapped: {title} → {position}"})

            elif act == 'list_windows':
                console.print("[cyan]🪟 Listing windows...[/cyan]")
                windows = list_windows()
                for w in windows[:8]:
                    console.print(f"[dim]  • {w.get('title', '?')} ({w.get('width', 0)}x{w.get('height', 0)})[/dim]")
                memory.append({"step": step, "summary": f"Listed {len(windows)} windows"})

            # --- GUI Actions ---
            elif act in ('click', 'double_click', 'right_click'):
                raw_x, raw_y = int(action.get('x', 0)), int(action.get('y', 0))
                ox, oy = win_offset
                x, y = raw_x + ox, raw_y + oy
                label = {'click': '🖱️', 'double_click': '🖱️🖱️', 'right_click': '🖱️R'}[act]
                console.print(f"[yellow]{label} ({raw_x}+{ox}, {raw_y}+{oy}) → ({x},{y})[/yellow]")
                success = reliable_click(x, y, click_type=act)
                if not success:
                    console.print(f"[red]⚠️ Click failed, retrying...[/red]")
                    reliable_click(x, y, click_type=act)
                memory.append({"step": step, "summary": f"{label} screen({x},{y})"})
                smart_wait(act)
                needs_screenshot = True
                log_action(act, f"({x},{y})")

            elif act == 'type':
                text = action.get('text', '')
                console.print(f"[blue]⌨️ Type: '{text[:60]}'[/blue]")
                ensure_window_focus()
                success = reliable_type(text)
                if not success:
                    console.print(f"[red]⚠️ Type failed, retrying...[/red]")
                    reliable_type(text, use_clipboard=False)
                memory.append({"step": step, "summary": f"Typed: '{text[:40]}'"})
                smart_wait('type')
                needs_screenshot = True
                log_action("type", text[:50])

            elif act == 'press':
                key = action.get('key', 'enter')
                console.print(f"[blue]⌨️ Press: {key}[/blue]")
                ensure_window_focus()
                pyautogui.press(key)
                memory.append({"step": step, "summary": f"Pressed: {key}"})
                smart_wait('press')
                needs_screenshot = True

            elif act == 'hotkey':
                keys = action.get('keys', [])
                console.print(f"[blue]⌨️ Hotkey: {'+'.join(keys)}[/blue]")
                ensure_window_focus()
                pyautogui.hotkey(*keys)
                memory.append({"step": step, "summary": f"Hotkey: {'+'.join(keys)}"})
                smart_wait('hotkey')
                needs_screenshot = True

            elif act == 'scroll':
                direction = action.get('direction', 'down')
                amount = int(action.get('amount', 3))
                if 'x' in action and 'y' in action:
                    ox, oy = win_offset
                    sx, sy = int(action['x']) + ox, int(action['y']) + oy
                    pyautogui.moveTo(sx, sy, duration=0.2)
                    console.print(f"[blue]🔄 Scroll {direction} ×{amount} at ({sx},{sy})[/blue]")
                else:
                    console.print(f"[blue]🔄 Scroll {direction} ×{amount}[/blue]")
                pyautogui.scroll(-amount if direction == 'down' else amount)
                memory.append({"step": step, "summary": f"Scrolled {direction} ×{amount}"})
                smart_wait('scroll')
                needs_screenshot = True

            elif act == 'drag':
                x1, y1 = int(action.get('x1', 0)), int(action.get('y1', 0))
                x2, y2 = int(action.get('x2', 0)), int(action.get('y2', 0))
                ox, oy = win_offset
                console.print(f"[yellow]↕️ Drag ({x1+ox},{y1+oy}) → ({x2+ox},{y2+oy})[/yellow]")
                drag_and_drop(x1 + ox, y1 + oy, x2 + ox, y2 + oy)
                memory.append({"step": step, "summary": f"Dragged ({x1+ox},{y1+oy})→({x2+ox},{y2+oy})"})
                smart_wait('click')
                needs_screenshot = True

            # --- Web Search Actions ---
            elif act == 'web_search':
                query = action.get('query', '')
                console.print(f"[bold green]🔍 Web Search:[/bold green] {query}")
                try:
                    api_key = os.environ.get('OLLAMA_API_KEY', '')
                    if not api_key:
                        console.print("[red]❌ OLLAMA_API_KEY set nahi hai! Web search ke liye zaroori hai.[/red]")
                        memory.append({"step": step, "summary": f"Web search failed: no API key"})
                    else:
                        search_results = ollama.web_search(query=query)
                        results_text = ""
                        results_list = getattr(search_results, 'results', []) or []
                        for i, r in enumerate(results_list[:5], 1):
                            title = getattr(r, 'title', '') or ''
                            snippet = getattr(r, 'snippet', '') or getattr(r, 'content', '') or ''
                            url = getattr(r, 'url', '') or ''
                            results_text += f"{i}. {title}\n   {snippet[:150]}\n   URL: {url}\n"
                            console.print(f"[dim]  {i}. {title}[/dim]")
                            console.print(f"[dim]     {snippet[:100]}[/dim]")
                        if results_text:
                            memory.append({"step": step, "summary": f"Web search '{query}': {len(results_list)} results\n{results_text[:300]}"})
                        else:
                            memory.append({"step": step, "summary": f"Web search '{query}': no results"})
                            console.print("[yellow]⚠️ Koi results nahi mile[/yellow]")
                except Exception as e:
                    console.print(f"[red]❌ Web search error: {e}[/red]")
                    memory.append({"step": step, "summary": f"Web search error: {str(e)[:60]}"})

            elif act == 'web_fetch':
                url = action.get('url', '')
                console.print(f"[bold green]🌐 Web Fetch:[/bold green] {url}")
                try:
                    api_key = os.environ.get('OLLAMA_API_KEY', '')
                    if not api_key:
                        console.print("[red]❌ OLLAMA_API_KEY set nahi hai![/red]")
                        memory.append({"step": step, "summary": f"Web fetch failed: no API key"})
                    else:
                        fetch_result = ollama.web_fetch(url=url)
                        content = getattr(fetch_result, 'content', '') or str(fetch_result)
                        # Truncate to avoid overwhelming the model
                        display_content = content[:500]
                        memory_content = content[:1000]
                        console.print(f"[dim]  📄 Fetched {len(content)} chars[/dim]")
                        console.print(f"[dim]  {display_content[:200]}...[/dim]")
                        memory.append({"step": step, "summary": f"Web fetch '{url}': {len(content)} chars\n{memory_content}"})
                except Exception as e:
                    console.print(f"[red]❌ Web fetch error: {e}[/red]")
                    memory.append({"step": step, "summary": f"Web fetch error: {str(e)[:60]}"})

            # --- Flow Control ---
            elif act == 'take_screenshot':
                console.print("[dim]📸 Screenshot requested[/dim]")
                needs_screenshot = True
                memory.append({"step": step, "summary": "Requested screenshot"})

            elif act == 'shell':
                cmd = action.get('command', '')
                console.print(f"[green]⚡ Shell:[/green] {cmd}")
                out = run_shell(cmd)
                console.print(f"[dim]   → {out[:150]}[/dim]")
                memory.append({"step": step, "summary": f"Shell: `{cmd}` → {out[:60]}"})
                smart_wait('shell')
                # Take screenshot after app-opening commands so agent can verify
                if cmd.strip().lower().startswith('start '):
                    needs_screenshot = True

            elif act == 'done':
                result = action.get('result', 'Done.')
                console.print(Panel(
                    f"[bold green]✅ {result}[/bold green]",
                    title="JARVIS — Task Complete", border_style="green"
                ))
                task_success = True
                log_action("task_done", result)
                break

            else:
                console.print(f"[red]❓ Unknown action: {act}[/red]")

        except json.JSONDecodeError:
            console.print(f"[red]❌ Invalid JSON from AI[/red]")
            memory.append({"step": step, "summary": "JSON parse error"})
            time.sleep(0.5)
        except Exception as e:
            console.print(f"[red]❌ Error: {e}[/red]")
            memory.append({"step": step, "summary": f"Error: {str(e)[:60]}"})
            time.sleep(0.5)

    # ── Save to Memory ──
    record_task(mem, task, memory, task_success)
    learned_count = len(mem.get('learnings', []))
    console.print(f"\n[dim]💾 Task saved. Total learnings: {learned_count}[/dim]\n")
