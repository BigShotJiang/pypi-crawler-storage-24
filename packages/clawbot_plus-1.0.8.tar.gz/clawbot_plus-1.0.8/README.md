# 🤖 ClawBot — AI Browser Automation CLI

# 🤖 ClawBot Plus — The Ultimate AI Automation CLI

**ClawBot Plus** (formerly ClawBot) is your AI-powered copilot that takes full control of your **Browser** and your **Windows PC**. You can control your PC directly from the terminal or remotely via **Telegram**!

### 🚀 Install in 1-Click
```bash
pip install clawbot-plus
```

### 🎮 Run the Bot
```bash
clawbot
```

---

## ✨ What's New in ClawBot Plus?

- 💻 **J.A.R.V.I.S. Computer Control:** It can now control your actual PC! Open apps, minimize windows, change volume, adjust brightness, take screenshots, sleep/shutdown, and type anywhere.
- 📱 **Telegram Bot Integration:** Connect your Telegram Bot and control your PC remotely from your phone!
- 🌐 **Web Search Built-in:** Use Ollama Web Search & Web Fetch to get real-time results without opening a browser GUI.
- 🧠 **6 AI Providers:** Gemini, OpenAI, Claude, Groq, DeepSeek, and Local Ollama supported!
- ⚡ **"Both" Mode:** Run both the Terminal CLI and the Telegram Bot in the background simultaneously.

## 🛠️ Features

- **Your Browser:** Uses your own Chrome with logged-in accounts.
- **Smart App Discovery:** Automatically scans your PC for apps and knows how to use them.
- **Persistent Memory:** JARVIS remembers past tasks and learns from successful actions.
- **API Key Management:** Enter your keys once; they are saved securely in `~/.clawbot/.env`.

---

## 📖 Quick Start

```bash
# Install
pip install clawbot-plus

# Run
clawbot
```

That's it! ClawBot will:
1. Ask if you want to connect a Telegram Bot (Optional).
2. Ask which mode to run (Browser, Computer, or Both).
3. Ask which AI Provider and Model to use.
4. Prompt for the API key (saved permanently).
5. Wait for your tasks!

---

## 💡 Example Tasks

**Chrome / Browser Mode:**
> `🤖 Task > open youtube and search for latest AI news`
> `🤖 Task > go to amazon and find the best mouse under 2k`

**JARVIS / Computer Mode:**
> `🤖 Task > open notepad and type a poem about Python`
> `🤖 Task > mute my volume and decrease brightness to 30`
> `🤖 Task > scan my PC and close calculator if it is open`

**Telegram Bot:**
> Just text your bot on Telegram: `"lock my screen"` or `"open Spotify and play a song"`! 

---

## ⌨️ CLI Commands

| Command | Description |
|---------|-------------|
| `quit` | Exit ClawBot gracefully |
| `switch` | Change AI provider/model |
| `chrome` | Restart Chrome browser (Browser mode only) |

## ⚙️ Requirements

- Python 3.11+
- Windows OS (for Full Computer Control)
- Google Chrome browser (for Browser Control)
