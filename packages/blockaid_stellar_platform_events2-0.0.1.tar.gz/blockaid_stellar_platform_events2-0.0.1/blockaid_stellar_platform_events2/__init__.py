"""Reserved package: blockaid-stellar-platform-events2. Internal use only."""
