"""OpenAI-compatible ChatProvider — works with OpenAI, local models, and any compatible API."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator, Sequence

import openai

from cognit.llm.message import Message

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_DELAYS = [1, 3, 5]  # seconds


class OpenAIProvider:
    """ChatProvider backed by OpenAI's Chat Completions API."""

    def __init__(
        self,
        model: str = "gpt-4o",
        base_url: str | None = None,
        api_key: str | None = None,
        temperature: float = 0.0,
        thinking: bool = False,
        thinking_budget: int = 10000,
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._thinking = thinking
        self._thinking_budget = thinking_budget
        self._client = openai.AsyncOpenAI(
            base_url=base_url,
            api_key=api_key,
        )

    @property
    def name(self) -> str:
        return "openai"

    @property
    def model_name(self) -> str:
        return self._model

    async def generate(
        self,
        system_prompt: str,
        tools: Sequence[dict[str, Any]],
        history: Sequence[Message],
    ) -> AsyncIterator[dict[str, Any]]:
        """Call OpenAI Chat Completions (streaming) and yield normalized deltas."""

        messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]
        messages.extend(m.to_openai() for m in history)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "stream": True,
        }

        if self._thinking:
            # Extended thinking: temperature must be 1, pass budget via extra_body
            kwargs["temperature"] = 1
            kwargs["extra_body"] = {
                "thinking": {
                    "type": "enabled",
                    "budget_tokens": self._thinking_budget,
                },
            }
        else:
            kwargs["temperature"] = self._temperature

        if tools:
            kwargs["tools"] = tools

        logger.info("API call — model=%s, messages=%d, tools=%d, thinking=%s",
                    self._model, len(messages), len(tools) if tools else 0, self._thinking)

        # Retry on transient errors (400/429/5xx)
        last_error: Exception | None = None
        for attempt in range(MAX_RETRIES):
            try:
                stream = await self._client.chat.completions.create(**kwargs)
                chunk_count = 0

                async for chunk in stream:
                    chunk_count += 1
                    delta = chunk.choices[0].delta if chunk.choices else None
                    if delta is None:
                        continue

                    # Thinking/reasoning content (extended thinking models)
                    reasoning = getattr(delta, "reasoning_content", None)
                    if reasoning:
                        yield {"type": "thinking_delta", "text": reasoning}

                    # Text content
                    if delta.content:
                        yield {"type": "text_delta", "text": delta.content}

                    # Tool call deltas
                    if delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            yield {
                                "type": "tool_call_delta",
                                "index": tc_delta.index,
                                "id": tc_delta.id or "",
                                "name": (tc_delta.function.name if tc_delta.function else "") or "",
                                "arguments": (tc_delta.function.arguments if tc_delta.function else "") or "",
                            }

                logger.info("Stream completed — received %d chunks", chunk_count)
                yield {"type": "done"}
                return  # success, exit retry loop

            except (openai.APIStatusError, openai.APIConnectionError, openai.APITimeoutError) as e:
                last_error = e
                status = getattr(e, "status_code", None)
                # Don't retry on client errors (auth, bad request, etc.)
                if status and 400 <= status < 500:
                    logger.error("API client error (status=%s), not retrying: %s", status, e)
                    raise
                delay = RETRY_DELAYS[min(attempt, len(RETRY_DELAYS) - 1)]
                logger.warning("API error (attempt %d/%d, status=%s): %s. Retrying in %ds...",
                               attempt + 1, MAX_RETRIES, status, e, delay)
                await asyncio.sleep(delay)

        # All retries exhausted
        logger.error("All %d retries exhausted, raising last error: %s", MAX_RETRIES, last_error)
        raise last_error  # type: ignore[misc]
