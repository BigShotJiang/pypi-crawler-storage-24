/**
 * Visual Workflow Builder
 *
 * Drag-and-drop workflow builder for post-submission actions and approvals.
 */

class WorkflowBuilder {
    constructor(config) {
        this.config = config;
        this.nodes = [];
        this.connections = [];
        this.selectedNode = null;
        this.selectedConnection = null;
        this.nodeIdCounter = 1;
        this.isDraggingNode = false;
        this.isConnecting = false;
        this.connectionStart = null;
        this.tempLine = null;
        this.fields = [];
        this.groups = [];
        this.forms = [];

        // Pan & zoom state
        this.panX = 0;
        this.panY = 0;
        this.zoom = 1;
        this.isPanning = false;
        this.minZoom = 0.25;
        this.maxZoom = 2;

        this.init();
    }

    async init() {
        console.log('Initializing workflow builder...');
        this.setupCanvas();
        this.setupPalette();
        this.setupEventListeners();
        await this.loadWorkflow();

        console.log('After load, nodes count:', this.nodes.length);

        // Create start node if no nodes exist
        if (this.nodes.length === 0) {
            console.log('No nodes found, creating start node');
            this.createStartNode();
        }

        console.log('Rendering workflow...');
        this.render();
        console.log('Workflow builder initialized');
    }

    setupCanvas() {
        this.canvas = document.getElementById('workflowCanvas');
        this.svg = document.getElementById('connectionsSvg');

        // Create a single transform wrapper that holds both SVG and nodes.
        // Applying pan/zoom to one wrapper keeps arrows and nodes aligned.
        this.transformWrapper = document.createElement('div');
        this.transformWrapper.style.position = 'absolute';
        this.transformWrapper.style.top = '0';
        this.transformWrapper.style.left = '0';
        this.transformWrapper.style.width = '100%';
        this.transformWrapper.style.height = '100%';
        this.transformWrapper.style.transformOrigin = '0 0';

        // Move SVG into the wrapper, then add wrapper to canvas
        this.canvas.appendChild(this.transformWrapper);
        this.transformWrapper.appendChild(this.svg);

        // Make canvas droppable
        this.canvas.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        });

        this.canvas.addEventListener('drop', (e) => {
            e.preventDefault();
            const nodeType = e.dataTransfer.getData('nodeType');
            if (nodeType) {
                const [x, y] = this.clientToCanvas(e.clientX, e.clientY);
                this.createNode(nodeType, x, y);
            }
        });

        // Click on canvas background to deselect
        this.canvas.addEventListener('click', (e) => {
            if (e.target === this.canvas || e.target === this.svg
                || e.target === this.transformWrapper) {
                this.deselectAll();
            }
        });

        // ── Pan (middle-click or Ctrl+left-click on background) ─────────
        this.canvas.addEventListener('mousedown', (e) => {
            const isBackground = e.target === this.canvas || e.target === this.svg
                || e.target === this.transformWrapper
                || e.target.tagName === 'svg' || e.target.closest('.connections-svg');
            const shouldPan = isBackground && (e.button === 1 || (e.button === 0 && (e.ctrlKey || e.metaKey || e.shiftKey)));
            if (!shouldPan) return;

            e.preventDefault();
            this.isPanning = true;
            this.canvas.style.cursor = 'grabbing';
            const startX = e.clientX, startY = e.clientY;
            const startPanX = this.panX, startPanY = this.panY;

            const onMove = (ev) => {
                this.panX = startPanX + (ev.clientX - startX);
                this.panY = startPanY + (ev.clientY - startY);
                this.applyTransform();
            };
            const onUp = () => {
                this.isPanning = false;
                this.canvas.style.cursor = '';
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });

        // Prevent default middle-click scroll
        this.canvas.addEventListener('auxclick', (e) => { if (e.button === 1) e.preventDefault(); });

        // ── Zoom (mouse wheel) ──────────────────────────────────────────
        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const rect = this.canvas.getBoundingClientRect();
            // Cursor position relative to canvas element
            const cx = e.clientX - rect.left;
            const cy = e.clientY - rect.top;

            const oldZoom = this.zoom;
            const delta = e.deltaY > 0 ? -0.1 : 0.1;
            this.zoom = Math.min(this.maxZoom, Math.max(this.minZoom, this.zoom + delta));

            // Adjust pan so zoom centres on cursor
            const scale = this.zoom / oldZoom;
            this.panX = cx - scale * (cx - this.panX);
            this.panY = cy - scale * (cy - this.panY);

            this.applyTransform();
            this.updateZoomIndicator();
        }, { passive: false });
    }

    /** Convert client (screen) coordinates to canvas (node) coordinates. */
    clientToCanvas(clientX, clientY) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (clientX - rect.left - this.panX) / this.zoom;
        const y = (clientY - rect.top - this.panY) / this.zoom;
        return [x, y];
    }

    /** Apply the current pan/zoom transform to the single wrapper (nodes + SVG). */
    applyTransform() {
        const t = `translate(${this.panX}px, ${this.panY}px) scale(${this.zoom})`;
        this.transformWrapper.style.transform = t;
    }

    /** Update the zoom percentage indicator. */
    updateZoomIndicator() {
        const el = document.getElementById('zoomLevel');
        if (el) el.textContent = `${Math.round(this.zoom * 100)}%`;
    }

    /** Zoom to a specific level, centred on the canvas midpoint. */
    setZoom(newZoom) {
        const rect = this.canvas.getBoundingClientRect();
        const cx = rect.width / 2, cy = rect.height / 2;
        const oldZoom = this.zoom;
        this.zoom = Math.min(this.maxZoom, Math.max(this.minZoom, newZoom));
        const scale = this.zoom / oldZoom;
        this.panX = cx - scale * (cx - this.panX);
        this.panY = cy - scale * (cy - this.panY);
        this.applyTransform();
        this.updateZoomIndicator();
    }

    /** Reset pan/zoom to default. */
    resetView() {
        this.panX = 0;
        this.panY = 0;
        this.zoom = 1;
        this.applyTransform();
        this.updateZoomIndicator();
    }

    setupPalette() {
        const paletteNodes = document.querySelectorAll('.palette-node');
        paletteNodes.forEach(node => {
            node.addEventListener('dragstart', (e) => {
                const nodeType = node.dataset.nodeType;
                e.dataTransfer.setData('nodeType', nodeType);
                e.dataTransfer.effectAllowed = 'copy';
            });
        });
    }

    setupEventListeners() {
        document.getElementById('btnSave').addEventListener('click', () => this.saveWorkflow());
    }

    async loadWorkflow() {
        try {
            console.log('Loading workflow from:', this.config.apiUrls.load);
            const response = await fetch(this.config.apiUrls.load);
            const data = await response.json();

            console.log('Workflow data received:', data);

            if (data.success) {
                this.nodes = data.workflow.nodes || [];
                this.connections = data.workflow.connections || [];
                this.fields = data.fields || [];
                this.groups = data.groups || [];
                this.forms = data.forms || [];

                console.log('Loaded nodes:', this.nodes);
                console.log('Loaded connections:', this.connections);
                console.log('Available forms:', this.forms);

                // Update node ID counter
                if (this.nodes.length > 0) {
                    const maxId = Math.max(...this.nodes.map(n => {
                        const match = n.id.match(/node_(\d+)/);
                        return match ? parseInt(match[1]) : 0;
                    }));
                    this.nodeIdCounter = maxId + 1;
                }
            } else {
                console.error('Failed to load workflow:', data.error);
            }
        } catch (error) {
            console.error('Error loading workflow:', error);
        }
    }

    async saveWorkflow() {
        const saveBtn = document.getElementById('btnSave');
        const originalText = saveBtn.innerHTML;
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Saving...';
        document.getElementById('saveStatus').textContent = 'Saving...';

        const workflowData = {
            form_id: this.config.formId,
            workflow: {
                nodes: this.nodes,
                connections: this.connections
            }
        };

        console.log('Saving workflow data:', workflowData);
        console.log('Nodes:', this.nodes);
        console.log('Connections:', this.connections);

        try {
            const response = await fetch(this.config.apiUrls.save, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.config.csrfToken
                },
                body: JSON.stringify(workflowData)
            });

            console.log('Response status:', response.status);
            console.log('Response ok:', response.ok);

            const result = await response.json();
            console.log('Response data:', result);

            if (!response.ok || !result.success) {
                throw new Error(result.error || 'Failed to save workflow');
            }

            document.getElementById('saveStatus').textContent = 'Saved successfully';
            alert('Workflow saved successfully!');
            setTimeout(() => {
                document.getElementById('saveStatus').textContent = 'Ready';
            }, 2000);
        } catch (error) {
            console.error('Error saving workflow:', error);
            alert('Failed to save workflow: ' + error.message);
            document.getElementById('saveStatus').textContent = 'Error saving';
        } finally {
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalText;
        }
    }

    createStartNode() {
        const node = {
            id: `node_${this.nodeIdCounter++}`,
            type: 'start',
            x: 100,
            y: 100,
            data: {}
        };
        this.nodes.push(node);
        this.render();
    }

    createNode(type, x, y) {
        const node = {
            id: `node_${this.nodeIdCounter++}`,
            type: type,
            x: x,
            y: y,
            data: this.getDefaultNodeData(type)
        };
        this.nodes.push(node);
        this.render();
    }

    getDefaultNodeData(type) {
        switch (type) {
            case 'form':
                return {
                    form_id: null,
                    form_name: 'Select Form',
                    form_builder_url: '#',
                    field_count: 0,
                    fields: [],
                    has_more_fields: false,
                    is_initial: false,
                };
            case 'stage':
                return {
                    stage_id: null,
                    name: 'New Stage',
                    order: 1,
                    approval_logic: 'all',
                    requires_manager_approval: false,
                    approve_label: '',
                    approval_groups: [],
                };
            case 'workflow_settings':
                return {
                    requires_approval: true,
                    approval_deadline_days: null,
                    send_reminder_after_days: null,
                    auto_approve_after_days: null,
                    notification_cadence: 'immediate',
                    notify_on_submission: true,
                    notify_on_approval: true,
                    notify_on_rejection: true,
                    notify_on_withdrawal: true,
                };
            case 'condition':
                return {
                    field: '',
                    operator: 'equals',
                    value: '',
                    true_path: '',
                    false_path: ''
                };
            case 'action':
                return {
                    name: 'New Action',
                    action_type: 'database',
                    trigger: 'on_approve',
                    config: {}
                };
            case 'email':
                return {
                    name: 'Send Email',
                    to: '',
                    subject: '',
                    template: '',
                    trigger: 'on_approve'
                };
            case 'sub_workflow':
                return {
                    sub_workflow_def_id: null,
                    sub_workflow_id: null,
                    sub_workflow_name: '',
                    count_field: '',
                    label_template: 'Sub-workflow {index}',
                    trigger: 'on_approval',
                    data_prefix: '',
                    detached: false,
                    reject_parent: false,
                };
            case 'join':
                return {};
            case 'end':
                return {
                    status: 'approved'
                };
            default:
                return {};
        }
    }

    deleteNode(nodeId) {
        if (confirm('Delete this node?')) {
            this.nodes = this.nodes.filter(n => n.id !== nodeId);
            this.connections = this.connections.filter(c => c.from !== nodeId && c.to !== nodeId);
            this.deselectAll();
            this.render();
        }
    }

    selectNode(nodeId) {
        this.deselectAll();
        this.selectedNode = nodeId;
        const node = this.nodes.find(n => n.id === nodeId);
        if (node) {
            this.showNodeProperties(node);
        }
        this.render();
    }

    deselectAll() {
        this.selectedNode = null;
        this.selectedConnection = null;
        this.showEmptyProperties();
        this.render();
    }

    showNodeProperties(node) {
        const content = document.getElementById('propertiesContent');
        content.innerHTML = this.buildPropertiesForm(node);

        // Add event listeners for property changes
        content.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('change', (e) => {
                this.updateNodeProperty(node.id, e.target.name, e.target.value);
            });
        });
    }

    showEmptyProperties() {
        const content = document.getElementById('propertiesContent');
        content.innerHTML = `
            <div class="properties-empty">
                <i class="bi bi-info-circle" style="font-size: 2rem; color: #dee2e6;"></i>
                <p>Select a node to edit its properties</p>
            </div>
        `;
    }

    buildPropertiesForm(node) {
        let html = `<h6 class="mb-3">${this.getNodeTypeLabel(node.type)}</h6>`;

        switch (node.type) {
            case 'start':
                html += '<p class="text-muted">This is the workflow start point.</p>';
                break;

            case 'form':
                html += this.buildFormProperties(node);
                break;

            case 'workflow_settings':
                html += this.buildWorkflowSettingsProperties(node);
                break;

            case 'stage':
                html += this.buildStageProperties(node);
                break;


            case 'approval':
                html += this.buildApprovalProperties(node);
                break;

            case 'condition':
                html += this.buildConditionProperties(node);
                break;

            case 'action':
                html += this.buildActionProperties(node);
                break;

            case 'email':
                html += this.buildEmailProperties(node);
                break;

            case 'sub_workflow':
                html += this.buildSubWorkflowProperties(node);
                break;

            case 'join':
                html += '<div class="alert alert-secondary"><i class="bi bi-info-circle"></i> This join node automatically merges parallel approval stages. It cannot be edited or removed independently.</div>';
                break;

            case 'end':
                html += this.buildEndProperties(node);
                break;
        }

        return html;
    }

    buildStageProperties(node) {
        const data = node.data || {};
        const selectedGroupIds = (data.approval_groups || []).map(g => g.id);

        let html = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Configure an approval stage with its own groups and logic.
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Stage Name</strong></label>
                <input type="text" class="form-control" name="name"
                       value="${this.escapeHtml(data.name || '')}"
                       onchange="workflowBuilder.updateStageConfig('${node.id}')" />
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Order</strong></label>
                <input type="number" class="form-control" name="order" min="1"
                       value="${data.order || 1}"
                       onchange="workflowBuilder.updateStageConfig('${node.id}')" />
                <small class="text-muted">Stages with the same order number run in parallel (fork/join).</small>
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Approve Button Label</strong></label>
                <input type="text" class="form-control" name="approve_label"
                       value="${this.escapeHtml(data.approve_label || '')}"
                       placeholder="Approve"
                       onchange="workflowBuilder.updateStageConfig('${node.id}')" />
                <small class="text-muted">Custom label for the approve button (e.g. "Sign Off")</small>
            </div>

            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="stage_requires_manager_${node.id}"
                           name="requires_manager_approval" ${data.requires_manager_approval ? 'checked' : ''}
                           onchange="workflowBuilder.updateStageConfig('${node.id}')">
                    <label class="form-check-label" for="stage_requires_manager_${node.id}">
                        <i class="bi bi-person-badge"></i> <strong>Require Manager Approval</strong>
                    </label>
                </div>
            </div>

            <hr />

            <div class="mb-3">
                <label class="form-label"><i class="bi bi-people"></i> <strong>Approval Groups</strong></label>
                <select class="form-select" id="stage_groups_${node.id}" name="approval_groups" multiple size="6"
                        style="min-height: 140px;"
                        onchange="workflowBuilder.updateStageConfig('${node.id}')">
        `;

        this.groups.forEach(group => {
            const selected = selectedGroupIds.includes(group.id) ? 'selected' : '';
            html += `<option value="${group.id}" ${selected}>${this.escapeHtml(group.name)}</option>`;
        });

        html += `
                </select>
                <small class="text-muted d-block mt-1">Hold Ctrl/Cmd to select multiple groups.</small>
            </div>

            <div class="mb-3">
                <label class="form-label">Approval Logic</label>
                <select class="form-select" name="approval_logic"
                        onchange="workflowBuilder.updateStageConfig('${node.id}')">
                    <option value="any" ${data.approval_logic === 'any' ? 'selected' : ''}>Any (OR)</option>
                    <option value="all" ${data.approval_logic === 'all' ? 'selected' : ''}>All (AND)</option>
                    <option value="sequence" ${data.approval_logic === 'sequence' ? 'selected' : ''}>Sequential</option>
                </select>
            </div>
        `;

        return html;
    }

    buildWorkflowSettingsProperties(node) {
        const data = node.data || {};

        let html = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Workflow-level notification and deadline settings.
            </div>

            <h6 class="mt-3">Deadlines &amp; Reminders</h6>
            <div class="mb-3">
                <label class="form-label">Approval Deadline (days)</label>
                <input type="number" class="form-control" name="approval_deadline_days" min="1"
                       value="${data.approval_deadline_days || ''}" placeholder="No deadline"
                       onchange="workflowBuilder.updateWorkflowSettings('${node.id}')" />
            </div>
            <div class="mb-3">
                <label class="form-label">Send Reminder After (days)</label>
                <input type="number" class="form-control" name="send_reminder_after_days" min="1"
                       value="${data.send_reminder_after_days || ''}" placeholder="No reminder"
                       onchange="workflowBuilder.updateWorkflowSettings('${node.id}')" />
            </div>
            <div class="mb-3">
                <label class="form-label">Auto-Approve After (days)</label>
                <input type="number" class="form-control" name="auto_approve_after_days" min="1"
                       value="${data.auto_approve_after_days || ''}" placeholder="Never"
                       onchange="workflowBuilder.updateWorkflowSettings('${node.id}')" />
            </div>
            <div class="mb-3">
                <label class="form-label">Notification Cadence</label>
                <select class="form-select" name="notification_cadence"
                        onchange="workflowBuilder.updateWorkflowSettings('${node.id}')">
                    <option value="immediate" ${data.notification_cadence === 'immediate' ? 'selected' : ''}>Immediate</option>
                    <option value="daily" ${data.notification_cadence === 'daily' ? 'selected' : ''}>Daily Digest</option>
                    <option value="weekly" ${data.notification_cadence === 'weekly' ? 'selected' : ''}>Weekly Digest</option>
                    <option value="none" ${data.notification_cadence === 'none' ? 'selected' : ''}>None</option>
                </select>
            </div>

            <hr />
            <h6>Notifications</h6>
        `;

        const notifFlags = [
            ['notify_on_submission', 'On Submission'],
            ['notify_on_approval', 'On Approval'],
            ['notify_on_rejection', 'On Rejection'],
            ['notify_on_withdrawal', 'On Withdrawal'],
        ];
        notifFlags.forEach(([key, label]) => {
            html += `
            <div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" id="ws_${key}_${node.id}"
                       name="${key}" ${data[key] !== false ? 'checked' : ''}
                       onchange="workflowBuilder.updateWorkflowSettings('${node.id}')">
                <label class="form-check-label" for="ws_${key}_${node.id}">${label}</label>
            </div>`;
        });

        return html;
    }


    buildFormProperties(node) {
        const data = node.data || {};
        const fields = data.fields || [];
        const hasMoreFields = data.has_more_fields || false;
        const isInitial = data.is_initial !== false;  // Initial form node (default true for backward compatibility)

        let html = `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> This node represents ${isInitial ? 'the initial form' : 'an additional form'} that users fill out and submit.
            </div>
        `;

        // For additional form nodes, show form selector
        if (!isInitial) {
            html += `
                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-file-earmark-text"></i> <strong>Select Form</strong></label>
                    <select class="form-select" name="form_id" onchange="workflowBuilder.updateFormSelection('${node.id}', this.value)">
                        <option value="">-- Select a form --</option>
            `;

            this.forms.forEach(form => {
                const selected = data.form_id == form.id ? 'selected' : '';
                html += `<option value="${form.id}" ${selected}>${this.escapeHtml(form.name)} (${form.field_count} fields)</option>`;
            });

            html += `
                    </select>
                    <small class="form-text text-muted">Choose which form to display at this step</small>
                </div>
            `;
        } else {
            // For initial form node, just show the name (read-only)
            html += `
                <div class="mb-3">
                    <label class="form-label">Form Name</label>
                    <input type="text" class="form-control" value="${this.escapeHtml(data.form_name || '')}" disabled />
                </div>
            `;
        }

        html += `
            <div class="mb-3">
                <label class="form-label">Total Fields</label>
                <input type="text" class="form-control" value="${data.field_count || 0}" disabled />
            </div>
        `;

        // Show multi-step information if enabled
        if (data.enable_multi_step && data.step_count > 0) {
            html += `
                <div class="alert alert-success">
                    <i class="bi bi-list-ol"></i> <strong>Multi-Step Form</strong>
                    <br><small class="text-muted">${data.step_count} step${data.step_count > 1 ? 's' : ''} configured</small>
                </div>
            `;

            // Show step details
            if (data.form_steps && data.form_steps.length > 0) {
                html += `
                    <div class="mb-3">
                        <label class="form-label">Form Steps</label>
                        <div class="list-group">
                `;

                data.form_steps.forEach((step, index) => {
                    const stepFields = step.fields || [];
                    html += `
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><i class="bi bi-${index + 1}-circle"></i> ${this.escapeHtml(step.title || `Step ${index + 1}`)}</strong>
                                    <small class="text-muted d-block">${stepFields.length} field${stepFields.length !== 1 ? 's' : ''}</small>
                                </div>
                                <span class="badge bg-primary">${index + 1}</span>
                            </div>
                        </div>
                    `;
                });

                html += `
                        </div>
                    </div>
                `;
            }
        }

        if (fields.length > 0) {
            html += `
                <div class="mb-3">
                    <label class="form-label">Form Fields</label>
                    <div class="list-group">
            `;

            fields.forEach(field => {
                const prefillBadge = field.prefill_source ?
                    `<span class="badge bg-info ms-2" title="Auto-filled from ${field.prefill_source}"><i class="bi bi-magic"></i> ${field.prefill_source}</span>` : '';
                const requiredBadge = field.required ?
                    `<span class="badge bg-warning ms-1">Required</span>` : '';

                html += `
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <strong>${this.escapeHtml(field.label)}</strong>
                                <small class="text-muted d-block">${field.name} (${field.type})</small>
                            </div>
                            <div>
                                ${requiredBadge}
                                ${prefillBadge}
                            </div>
                        </div>
                    </div>
                `;
            });

            if (hasMoreFields) {
                html += `
                    <div class="list-group-item text-muted text-center">
                        <i class="bi bi-three-dots"></i> More fields available
                    </div>
                `;
            }

            html += `
                    </div>
                </div>
            `;
        }

        html += `
            <div class="mt-3">
                <a href="${data.form_builder_url || '#'}" target="_blank" class="btn btn-outline-primary btn-sm w-100">
                    <i class="bi bi-pencil-square"></i> Edit Form in Form Builder
                </a>
            </div>
        `;

        return html;
    }

    buildApprovalProperties(node) {
        const data = node.data || {};
        let html = `
            <div class="mb-3">
                <label class="form-label">Step Name</label>
                <input type="text" class="form-control" name="step_name" value="${this.escapeHtml(data.step_name || '')}" />
            </div>
            <div class="mb-3">
                <label class="form-label">Approval Type</label>
                <select class="form-select" name="approval_type">
                    <option value="group" ${data.approval_type === 'group' ? 'selected' : ''}>Group Approval</option>
                    <option value="manager" ${data.approval_type === 'manager' ? 'selected' : ''}>Manager Approval</option>
                    <option value="parallel" ${data.approval_type === 'parallel' ? 'selected' : ''}>Parallel Approval</option>
                </select>
            </div>
        `;

        if (data.approval_type === 'group' || !data.approval_type) {
            html += `
                <div class="mb-3">
                    <label class="form-label">Approval Group</label>
                    <select class="form-select" name="group_id">
                        <option value="">Select group...</option>
                        ${this.groups.map(g => `
                            <option value="${g.id}" ${data.group_id == g.id ? 'selected' : ''}>${this.escapeHtml(g.name)}</option>
                        `).join('')}
                    </select>
                </div>
            `;
        }

        return html;
    }

    buildConditionProperties(node) {
        const data = node.data || {};
        return `
            <div class="mb-3">
                <label class="form-label">Condition Name</label>
                <input type="text" class="form-control" name="name" value="${this.escapeHtml(data.name || 'Condition')}" placeholder="e.g., Check Amount" />
            </div>
            <div class="mb-3">
                <label class="form-label">Field to Check</label>
                <select class="form-select" name="field">
                    <option value="">Select field...</option>
                    ${this.fields.map(f => `
                        <option value="${f.field_name}" ${data.field === f.field_name ? 'selected' : ''}>${this.escapeHtml(f.field_label)}</option>
                    `).join('')}
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Operator</label>
                <select class="form-select" name="operator">
                    <option value="equals" ${data.operator === 'equals' ? 'selected' : ''}>Equals (=)</option>
                    <option value="not_equals" ${data.operator === 'not_equals' ? 'selected' : ''}>Not Equals (≠)</option>
                    <option value="greater_than" ${data.operator === 'greater_than' ? 'selected' : ''}>Greater Than (&gt;)</option>
                    <option value="less_than" ${data.operator === 'less_than' ? 'selected' : ''}>Less Than (&lt;)</option>
                    <option value="greater_or_equal" ${data.operator === 'greater_or_equal' ? 'selected' : ''}>Greater or Equal (≥)</option>
                    <option value="less_or_equal" ${data.operator === 'less_or_equal' ? 'selected' : ''}>Less or Equal (≤)</option>
                    <option value="contains" ${data.operator === 'contains' ? 'selected' : ''}>Contains</option>
                    <option value="not_contains" ${data.operator === 'not_contains' ? 'selected' : ''}>Does Not Contain</option>
                    <option value="is_empty" ${data.operator === 'is_empty' ? 'selected' : ''}>Is Empty</option>
                    <option value="is_not_empty" ${data.operator === 'is_not_empty' ? 'selected' : ''}>Is Not Empty</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Compare Value</label>
                <input type="text" class="form-control" name="value" value="${this.escapeHtml(data.value || '')}" placeholder="Value to compare against" />
                <small class="text-muted">Leave empty for "is empty" / "is not empty" operators</small>
            </div>
            <hr class="my-3" />
            <p class="text-muted small mb-2">
                <i class="bi bi-info-circle"></i> Connect the output to different nodes for TRUE and FALSE paths
            </p>
        `;
    }

    buildActionProperties(node) {
        const data = node.data || {};
        return `
            <div class="mb-3">
                <label class="form-label">Action Name</label>
                <input type="text" class="form-control" name="name" value="${this.escapeHtml(data.name || '')}" placeholder="e.g., Update User Record" />
            </div>
            <div class="mb-3">
                <label class="form-label">Action Type</label>
                <select class="form-select" name="action_type">
                    <option value="database" ${data.action_type === 'database' ? 'selected' : ''}>Database Update</option>
                    <option value="ldap" ${data.action_type === 'ldap' ? 'selected' : ''}>LDAP Update</option>
                    <option value="api" ${data.action_type === 'api' ? 'selected' : ''}>API Call</option>
                    <option value="custom" ${data.action_type === 'custom' ? 'selected' : ''}>Custom Handler</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">When to Execute</label>
                <select class="form-select" name="trigger">
                    <option value="on_submit" ${data.trigger === 'on_submit' ? 'selected' : ''}>On Submission</option>
                    <option value="on_approve" ${data.trigger === 'on_approve' ? 'selected' : ''}>On Approval</option>
                    <option value="on_reject" ${data.trigger === 'on_reject' ? 'selected' : ''}>On Rejection</option>
                    <option value="on_complete" ${data.trigger === 'on_complete' ? 'selected' : ''}>On Complete</option>
                </select>
            </div>
            <hr class="my-3" />
            <div class="mb-3">
                <label class="form-label">Configuration (JSON)</label>
                <textarea class="form-control font-monospace" name="config" rows="4" placeholder='{"table": "users", "field": "status", "value": "approved"}'>${this.escapeHtml(JSON.stringify(data.config || {}, null, 2))}</textarea>
                <small class="text-muted">Action-specific configuration in JSON format</small>
            </div>
        `;
    }

    buildEmailProperties(node) {
        const data = node.data || {};
        return `
            <div class="mb-3">
                <label class="form-label">Email Name</label>
                <input type="text" class="form-control" name="name" value="${this.escapeHtml(data.name || '')}" placeholder="e.g., Approval Notification" />
            </div>
            <div class="mb-3">
                <label class="form-label">Recipients</label>
                <input type="text" class="form-control" name="to" value="${this.escapeHtml(data.to || '')}" placeholder="email@example.com or {field_name}" />
                <small class="text-muted">Use {field_name} to reference form fields, or enter email addresses</small>
            </div>
            <div class="mb-3">
                <label class="form-label">Subject</label>
                <input type="text" class="form-control" name="subject" value="${this.escapeHtml(data.subject || '')}" placeholder="Your request has been approved" />
            </div>
            <div class="mb-3">
                <label class="form-label">Email Template</label>
                <select class="form-select" name="template">
                    <option value="">Select template...</option>
                    <option value="approval_notification" ${data.template === 'approval_notification' ? 'selected' : ''}>Approval Notification</option>
                    <option value="rejection_notification" ${data.template === 'rejection_notification' ? 'selected' : ''}>Rejection Notification</option>
                    <option value="submission_confirmation" ${data.template === 'submission_confirmation' ? 'selected' : ''}>Submission Confirmation</option>
                    <option value="custom" ${data.template === 'custom' ? 'selected' : ''}>Custom Template</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">When to Send</label>
                <select class="form-select" name="trigger">
                    <option value="on_submit" ${data.trigger === 'on_submit' ? 'selected' : ''}>On Submission</option>
                    <option value="on_approve" ${data.trigger === 'on_approve' ? 'selected' : ''}>On Approval</option>
                    <option value="on_reject" ${data.trigger === 'on_reject' ? 'selected' : ''}>On Rejection</option>
                    <option value="on_complete" ${data.trigger === 'on_complete' ? 'selected' : ''}>On Complete</option>
                </select>
            </div>
        `;
    }

    buildSubWorkflowProperties(node) {
        const data = node.data || {};

        // Build workflow options from this.forms (available workflows)
        let workflowOptions = '<option value="">-- Select a workflow --</option>';
        this.forms.forEach(f => {
            const selected = (data.sub_workflow_id == f.id) ? 'selected' : '';
            workflowOptions += `<option value="${f.id}" ${selected}>${this.escapeHtml(f.name)} (${f.field_count} fields)</option>`;
        });

        // Build count field options from this.fields
        let fieldOptions = '<option value="">-- Select a field --</option>';
        this.fields.forEach(f => {
            const selected = (data.count_field === f.field_name) ? 'selected' : '';
            fieldOptions += `<option value="${f.field_name}" ${selected}>${this.escapeHtml(f.field_label)} (${f.field_name})</option>`;
        });

        return `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> Configure a sub-workflow that spawns child approval processes based on a form field value.
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Target Workflow</strong></label>
                <select class="form-select" name="sub_workflow_id"
                        onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')">
                    ${workflowOptions}
                </select>
                <small class="text-muted">The workflow definition used for each sub-workflow instance</small>
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Count Field</strong></label>
                <select class="form-select" name="count_field"
                        onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')">
                    ${fieldOptions}
                </select>
                <small class="text-muted">Form field whose value determines how many sub-workflows to spawn</small>
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Label Template</strong></label>
                <input type="text" class="form-control" name="label_template"
                       value="${this.escapeHtml(data.label_template || 'Sub-workflow {index}')}"
                       onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')" />
                <small class="text-muted">Use {index} as placeholder (e.g. "Payment {index}")</small>
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Trigger</strong></label>
                <select class="form-select" name="trigger"
                        onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')">
                    <option value="on_submission" ${data.trigger === 'on_submission' ? 'selected' : ''}>On Submission</option>
                    <option value="on_approval" ${data.trigger === 'on_approval' ? 'selected' : ''}>After Parent Approval</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label"><strong>Data Prefix</strong></label>
                <input type="text" class="form-control" name="data_prefix"
                       value="${this.escapeHtml(data.data_prefix || '')}"
                       onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')" />
                <small class="text-muted">Field prefix to scope data per instance (e.g. "payment" matches payment_type_1, payment_amount_1 …)</small>
            </div>

            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="sub_wf_detached_${node.id}"
                           name="detached" ${data.detached ? 'checked' : ''}
                           onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')">
                    <label class="form-check-label" for="sub_wf_detached_${node.id}">
                        <strong>Detached</strong>
                    </label>
                </div>
                <small class="text-muted">When enabled, sub-workflows run independently and don't affect parent status</small>
            </div>

            <div class="mb-3">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="sub_wf_reject_parent_${node.id}"
                           name="reject_parent" ${data.reject_parent ? 'checked' : ''}
                           onchange="workflowBuilder.updateSubWorkflowConfig('${node.id}')">
                    <label class="form-check-label" for="sub_wf_reject_parent_${node.id}">
                        <strong>Reject Parent on Failure</strong>
                    </label>
                </div>
                <small class="text-muted">When enabled, rejecting any sub-workflow rejects the parent and cancels siblings</small>
            </div>
        `;
    }

    updateSubWorkflowConfig(nodeId) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (!node) return;

        const container = document.getElementById('propertiesContent');
        const subWfSelect = container.querySelector('select[name="sub_workflow_id"]');
        node.data.sub_workflow_id = subWfSelect.value ? parseInt(subWfSelect.value) : null;
        const selectedOption = subWfSelect.selectedOptions[0];
        node.data.sub_workflow_name = selectedOption && selectedOption.value ? selectedOption.text : '';

        node.data.count_field = container.querySelector('select[name="count_field"]').value;
        node.data.label_template = container.querySelector('input[name="label_template"]').value;
        node.data.trigger = container.querySelector('select[name="trigger"]').value;
        node.data.data_prefix = container.querySelector('input[name="data_prefix"]').value;
        node.data.detached = container.querySelector(`#sub_wf_detached_${nodeId}`).checked;
        node.data.reject_parent = container.querySelector(`#sub_wf_reject_parent_${nodeId}`).checked;

        this.render();
        this.selectNode(nodeId);
    }

    buildEndProperties(node) {
        const data = node.data || {};
        return `
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> This is the terminal node where the workflow ends.
            </div>
            <p class="text-muted">
                The workflow completes when it reaches this node. The final status is determined by
                which path led to this end node (e.g., approval path vs. rejection path).
            </p>
        `;
    }

    updateNodeProperty(nodeId, property, value) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (node) {
            node.data[property] = value;
            this.render();
        }
    }

    updateFormSelection(nodeId, formId) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (!node) return;

        // Find the selected form
        const selectedForm = this.forms.find(f => f.id == formId);
        if (!selectedForm) {
            // Clear form data if no form selected
            node.data.form_id = null;
            node.data.form_name = 'Select Form';
            node.data.form_builder_url = '#';
            node.data.field_count = 0;
            node.data.fields = [];
            node.data.has_more_fields = false;
        } else {
            // Update node with selected form data
            node.data.form_id = selectedForm.id;
            node.data.form_name = selectedForm.name;
            node.data.form_builder_url = `/admin/django_forms_workflows/formdefinition/${selectedForm.id}/builder/`;
            node.data.field_count = selectedForm.field_count;
            // Note: We don't load full field details here for performance
            // The backend will load them when needed
            node.data.fields = [];
            node.data.has_more_fields = selectedForm.field_count > 0;
        }

        // Re-render to update the node display and properties panel
        this.render();
        this.selectNode(nodeId); // Re-select to refresh properties panel
    }

    updateStageConfig(nodeId) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (!node) return;

        const container = document.getElementById('propertiesContent');
        node.data.name = container.querySelector('input[name="name"]').value;
        node.data.order = parseInt(container.querySelector('input[name="order"]').value) || 1;
        node.data.approve_label = container.querySelector('input[name="approve_label"]').value;
        node.data.requires_manager_approval = container.querySelector(`#stage_requires_manager_${nodeId}`).checked;

        const groupSelect = container.querySelector(`#stage_groups_${nodeId}`);
        node.data.approval_groups = Array.from(groupSelect.selectedOptions).map(opt => ({
            id: parseInt(opt.value),
            name: opt.text
        }));
        node.data.approval_logic = container.querySelector('select[name="approval_logic"]').value;

        this.render();
        this.selectNode(nodeId);
    }

    updateWorkflowSettings(nodeId) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (!node) return;

        const container = document.getElementById('propertiesContent');

        // Numeric fields (empty → null)
        ['approval_deadline_days', 'send_reminder_after_days', 'auto_approve_after_days'].forEach(key => {
            const val = container.querySelector(`input[name="${key}"]`).value;
            node.data[key] = val ? parseInt(val) : null;
        });

        node.data.notification_cadence = container.querySelector('select[name="notification_cadence"]').value;

        // Notification checkboxes
        ['notify_on_submission', 'notify_on_approval', 'notify_on_rejection', 'notify_on_withdrawal'].forEach(key => {
            node.data[key] = container.querySelector(`#ws_${key}_${nodeId}`).checked;
        });

        this.render();
        this.selectNode(nodeId);
    }



    getNodeTypeLabel(type) {
        const labels = {
            start: 'Start',
            form: 'Form Submission',
            workflow_settings: 'Workflow Settings',
            stage: 'Approval Stage',
            condition: 'Condition',
            action: 'Action',
            email: 'Email Notification',
            sub_workflow: 'Sub-Workflow',
            join: 'Join',
            end: 'End'
        };
        return labels[type] || type;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    render() {
        console.log('Rendering workflow with', this.nodes.length, 'nodes and', this.connections.length, 'connections');
        this.renderNodes();
        this.renderConnections();
        this.applyTransform();
    }

    renderNodes() {
        console.log('Rendering nodes...');
        // Remove existing nodes
        this.transformWrapper.querySelectorAll('.workflow-node').forEach(n => n.remove());

        // Render each node into the transform wrapper (alongside the SVG)
        this.nodes.forEach(node => {
            console.log('Creating node element for:', node);
            const nodeEl = this.createNodeElement(node);
            this.transformWrapper.appendChild(nodeEl);
        });
        console.log('Nodes rendered');
    }

    createNodeElement(node) {
        // Ensure node.data exists (may be missing from saved workflow data)
        if (!node.data) {
            node.data = this.getDefaultNodeData(node.type);
        }

        const div = document.createElement('div');
        div.className = `workflow-node ${node.type}`;
        if (this.selectedNode === node.id) {
            div.className += ' selected';
        }
        div.style.left = `${node.x}px`;
        div.style.top = `${node.y}px`;
        div.dataset.nodeId = node.id;

        const icon = this.getNodeIcon(node.type);
        const label = node.data.step_name || node.data.name || this.getNodeTypeLabel(node.type);

        // Determine if node can be deleted
        // - start, workflow_settings: never deletable
        // - form: only deletable if it's an additional form (is_initial === false)
        // - stage: always deletable
        // - all others: deletable
        const canDelete = node.type !== 'start' &&
                         node.type !== 'workflow_settings' &&
                         node.type !== 'join' &&
                         !(node.type === 'form' && node.data.is_initial !== false);

        div.innerHTML = `
            <div class="node-header">
                <div class="node-icon ${node.type}">
                    <i class="bi bi-${icon}"></i>
                </div>
                <span>${this.escapeHtml(label)}</span>
            </div>
            <div class="node-content">
                ${this.getNodeDescription(node)}
            </div>
            ${canDelete ? `
                <div class="node-actions">
                    <button class="btn btn-sm btn-outline-danger" onclick="workflowBuilder.deleteNode('${node.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            ` : ''}
            <div class="connection-point input" data-node-id="${node.id}" data-point="input"></div>
            <div class="connection-point output" data-node-id="${node.id}" data-point="output"></div>
        `;

        // Add connection point event listeners
        const inputPoint = div.querySelector('.connection-point.input');
        const outputPoint = div.querySelector('.connection-point.output');

        if (outputPoint) {
            outputPoint.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                this.startConnection(e, node.id, 'output');
            });
        }

        if (inputPoint) {
            inputPoint.addEventListener('mouseenter', (e) => {
                if (this.isConnecting) {
                    inputPoint.style.background = '#28a745';
                    inputPoint.style.transform = 'translateY(-50%) scale(1.5)';
                }
            });
            inputPoint.addEventListener('mouseleave', (e) => {
                inputPoint.style.background = '#667eea';
                inputPoint.style.transform = 'translateY(-50%) scale(1)';
            });
        }

        // Make node draggable
        div.addEventListener('mousedown', (e) => {
            if (e.target.closest('.node-actions')) return;
            if (e.target.closest('.connection-point')) return;
            if (e.target.closest('.form-edit-link')) return; // Don't interfere with form edit link

            this.selectNode(node.id);
            this.startDragNode(e, node);
        });

        return div;
    }

    getNodeIcon(type) {
        const icons = {
            start: 'play-circle',
            form: 'file-earmark-text',
            workflow_settings: 'gear',
            stage: 'layers',
            condition: 'diagram-3',
            action: 'lightning',
            email: 'envelope',
            sub_workflow: 'diagram-2',
            join: 'sign-merge-right',
            end: 'flag'
        };
        return icons[type] || 'circle';
    }

    getNodeDescription(node) {
        switch (node.type) {
            case 'start':
                return 'Workflow starts here';
            case 'form':
                const fieldCount = node.data.field_count || 0;
                const formName = node.data.form_name || 'Form';
                const isInitial = node.data.is_initial !== false;
                const isMultiStep = node.data.enable_multi_step && node.data.step_count > 0;

                // Show different description for initial vs additional forms
                if (!isInitial && !node.data.form_id) {
                    return '<span class="badge bg-secondary"><i class="bi bi-exclamation-circle"></i> No Form Selected</span><br><small class="text-muted">Select a form in properties</small>';
                }

                let badges = '';
                if (!isInitial) {
                    badges += '<span class="badge bg-info">Additional Step</span> ';
                }
                if (isMultiStep) {
                    badges += `<span class="badge bg-success"><i class="bi bi-list-ol"></i> ${node.data.step_count} Steps</span> `;
                }

                const badgeHtml = badges ? `${badges}<br>` : '';
                return `${badgeHtml}${fieldCount} field${fieldCount !== 1 ? 's' : ''} • <a href="${node.data.form_builder_url || '#'}" target="_blank" class="text-primary form-edit-link"><i class="bi bi-pencil-square"></i> Edit Form</a>`;
            case 'workflow_settings':
                const parts_ws = [];
                if (node.data.approval_deadline_days) parts_ws.push(`Deadline: ${node.data.approval_deadline_days}d`);
                if (node.data.notification_cadence && node.data.notification_cadence !== 'immediate') parts_ws.push(`Reminders: ${node.data.notification_cadence}`);
                if (node.data.escalation_field) parts_ws.push('Escalation configured');
                return parts_ws.length > 0 ?
                    `<small class="text-muted">${parts_ws.join(' • ')}</small>` :
                    '<small class="text-muted">Default settings</small>';
            case 'stage':
                const stageParts = [];
                if (node.data.requires_manager_approval) stageParts.push('Manager');
                if (node.data.approval_groups && node.data.approval_groups.length > 0) {
                    const gc = node.data.approval_groups.length;
                    stageParts.push(`${gc} group${gc > 1 ? 's' : ''} (${node.data.approval_logic || 'all'})`);
                }
                const label = node.data.approve_label ? ` • "${node.data.approve_label}"` : '';
                return stageParts.length > 0 ?
                    `<span class="badge bg-warning">Stage ${node.data.order || '?'}</span><br><small class="text-muted">${stageParts.join(' + ')}${label}</small>` :
                    `<span class="badge bg-secondary">Stage ${node.data.order || '?'}</span><br><small class="text-muted">No approvers configured</small>`;
            case 'condition':
                if (node.data.field && node.data.operator) {
                    const operatorSymbols = {
                        'equals': '=',
                        'not_equals': '≠',
                        'greater_than': '>',
                        'less_than': '<',
                        'greater_or_equal': '≥',
                        'less_or_equal': '≤',
                        'contains': 'contains',
                        'not_contains': 'not contains',
                        'is_empty': 'is empty',
                        'is_not_empty': 'is not empty'
                    };
                    const op = operatorSymbols[node.data.operator] || node.data.operator;
                    return `If ${node.data.field} ${op} ${node.data.value || ''}`;
                }
                return 'Configure condition';
            case 'action':
                return node.data.action_type ? `${node.data.action_type.toUpperCase()}: ${node.data.trigger || ''}` : 'Configure action';
            case 'email':
                return node.data.to ? `Send to: ${node.data.to}` : 'Configure email';
            case 'join':
                return '<small class="text-muted">Parallel stages merge here</small>';
            case 'sub_workflow':
                const swParts = [];
                if (node.data.sub_workflow_name) swParts.push(node.data.sub_workflow_name);
                if (node.data.count_field) swParts.push(`Count: ${node.data.count_field}`);
                if (node.data.trigger) swParts.push(node.data.trigger === 'on_approval' ? 'After approval' : 'On submission');
                if (node.data.detached) swParts.push('Detached');
                return swParts.length > 0 ?
                    `<span class="badge bg-info">Sub-Workflow</span><br><small class="text-muted">${swParts.join(' • ')}</small>` :
                    '<span class="badge bg-secondary">Sub-Workflow</span><br><small class="text-muted">Not configured</small>';
            case 'end':
                return 'Workflow end';
            default:
                return '';
        }
    }

    startDragNode(e, node) {
        this.isDraggingNode = true;
        const startX = e.clientX;
        const startY = e.clientY;
        const nodeStartX = node.x;
        const nodeStartY = node.y;

        const onMouseMove = (e) => {
            // Divide by zoom so node movement matches cursor speed
            const dx = (e.clientX - startX) / this.zoom;
            const dy = (e.clientY - startY) / this.zoom;
            node.x = nodeStartX + dx;
            node.y = nodeStartY + dy;
            this.render();
        };

        const onMouseUp = () => {
            this.isDraggingNode = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    startConnection(e, nodeId, point) {
        if (point !== 'output') return; // Only start from output

        e.stopPropagation();
        e.preventDefault();
        this.isConnecting = true;
        this.connectionStart = { nodeId, point };

        console.log('Starting connection from node:', nodeId);

        const onMouseMove = (e) => {
            this.updateTempConnection(e);
        };

        const onMouseUp = (e) => {
            this.finishConnection(e);
            this.isConnecting = false;
            this.connectionStart = null;
            if (this.tempLine) {
                this.tempLine.remove();
                this.tempLine = null;
            }
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    updateTempConnection(e) {
        const [x, y] = this.clientToCanvas(e.clientX, e.clientY);

        const startNode = this.nodes.find(n => n.id === this.connectionStart.nodeId);
        if (!startNode) return;

        if (!this.tempLine) {
            this.tempLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            this.tempLine.setAttribute('class', 'connection-line');
            this.tempLine.setAttribute('stroke-dasharray', '5,5');
            this.svg.appendChild(this.tempLine);
        }

        const path = this.createConnectionPath(
            startNode.x + 180, startNode.y + 40,
            x, y
        );
        this.tempLine.setAttribute('d', path);
    }

    finishConnection(e) {
        console.log('Finishing connection, event target:', e.target);
        const target = e.target.closest('.connection-point');
        console.log('Connection point target:', target);

        if (!target || target.dataset.point !== 'input') {
            console.log('Not a valid input connection point');
            return;
        }

        const toNodeId = target.dataset.nodeId;
        console.log('Connecting to node:', toNodeId);

        if (toNodeId === this.connectionStart.nodeId) {
            console.log('Cannot connect to self');
            return; // Can't connect to self
        }

        // Check if connection already exists
        const exists = this.connections.some(c =>
            c.from === this.connectionStart.nodeId && c.to === toNodeId
        );

        if (!exists) {
            console.log('Creating new connection');
            this.connections.push({
                from: this.connectionStart.nodeId,
                to: toNodeId
            });
            this.render();
        } else {
            console.log('Connection already exists');
        }
    }

    renderConnections() {
        // Remove existing connections
        this.svg.querySelectorAll('.connection-line:not([stroke-dasharray])').forEach(l => l.remove());

        // Render each connection
        this.connections.forEach((conn, index) => {
            const fromNode = this.nodes.find(n => n.id === conn.from);
            const toNode = this.nodes.find(n => n.id === conn.to);

            if (!fromNode || !toNode) return;

            const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            line.setAttribute('class', 'connection-line');
            line.setAttribute('data-connection-index', index);
            line.style.cursor = 'pointer';

            const path = this.createConnectionPath(
                fromNode.x + 180, fromNode.y + 40,
                toNode.x, toNode.y + 40
            );
            line.setAttribute('d', path);

            // Add click handler to delete connection
            line.addEventListener('click', (e) => {
                e.stopPropagation();
                if (confirm('Delete this connection?')) {
                    this.connections.splice(index, 1);
                    this.render();
                }
            });

            // Add hover effect
            line.addEventListener('mouseenter', () => {
                line.style.stroke = '#dc3545';
                line.style.strokeWidth = '3';
            });

            line.addEventListener('mouseleave', () => {
                line.style.stroke = '';
                line.style.strokeWidth = '';
            });

            this.svg.appendChild(line);
        });
    }

    createConnectionPath(x1, y1, x2, y2) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const cx1 = x1 + Math.abs(dx) / 2;
        const cx2 = x2 - Math.abs(dx) / 2;

        return `M ${x1} ${y1} C ${cx1} ${y1}, ${cx2} ${y2}, ${x2} ${y2}`;
    }
}

