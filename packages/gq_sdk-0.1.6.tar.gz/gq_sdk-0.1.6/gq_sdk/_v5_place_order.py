"""
Strict place-order entrypoint and payload validation for gq-sdk.
"""

from typing import Any, Dict, Optional, Set

from ._helpers import generate_client_algo_id
from ._http_manager import _HTTPManager
from .exceptions import PayloadValidationError
from .trade import Trade

_BASE_ALLOWED_FIELDS: Set[str] = {
    "algorithm_type",
    "exchange_name",
    "account_name",
    "symbol",
    "notes",
    "tags",
    "input_params",
    "enable_spot_margin_mode",
    "tpsl",
    "enable_smart_order",
    "instrument_type",
    "frontend_inst_type",
    "client_algo_id",
    "reduce_only",
    "smart_order_routing",
    "base_instrument",
    "quote_instrument",
    "directives",
    "display_name",
    "mirror_id",
    "mirror_accounts",
    "is_proportional",
    "round_robin",
    "frontend_duration",
    "rfq_id",
    "simulate",
    "auto_repay_at_cancel",
    "side_effect_type",
    "is_isolated_margin",
    "target_position_config",
    "sor_config_id",
}

_ALGO_CONFIG: Dict[str, Dict[str, Set[str]]] = {
    "market": {
        "required": {"side", "quantity"},
        "allowed": set(),
    },
    "limit": {
        "required": {"side", "quantity", "price"},
        "allowed": {
            "time_in_force",
            "execution_type",
            "visibility",
            "nbbo_protection",
            "aon",
            "min_fill_size",
        },
    },
    "twap": {
        "required": {"side", "quantity", "duration", "interval"},
        "allowed": set(),
    },
    "market_edge": {
        "required": {"side", "quantity", "duration"},
        "allowed": {"decay_factor", "asset1_symbol", "asset2_symbol", "ratio"},
    },
    "limit_edge": {
        "required": {"side", "quantity", "duration", "threshold_value", "threshold_type"},
        "allowed": {
            "price",
            "slippage",
            "delta",
            "target_probability",
        },
    },
    "twap_edge": {
        "required": {"side", "quantity", "duration", "interval", "decay_factor"},
        "allowed": set(),
    },
    "spread_trading": {
        "required": {"side", "quantity"},
        "allowed": {
            "spread_duration",
            "hedge_basket",
            "spread_preset",
            "spread_condition_config",
            "quote_execution_config",
            "hedge_execution_config",
            "imbalance_config",
            "spread_tpsl",
        },
    },
}


class PlaceOrderHTTP(_HTTPManager):
    """Unified strict place-order mixin class."""

    @staticmethod
    def _normalize_optional_string_fields(payload: Dict[str, Any]) -> None:
        """
        Remove optional fields that are present but empty-string.
        """
        optional_string_fields = {
            "instrument_type",
            "frontend_inst_type",
            "display_name",
            "notes",
            "rfq_id",
            "base_instrument",
            "quote_instrument",
        }
        for field in optional_string_fields:
            if payload.get(field) == "":
                payload.pop(field, None)

    def _validate_place_order_payload(self, payload: Dict[str, Any], strict: bool) -> None:
        self._normalize_optional_string_fields(payload)

        if not isinstance(payload, dict):
            raise PayloadValidationError("payload must be a dictionary")

        algorithm_type_raw = payload.get("algorithm_type")
        if not isinstance(algorithm_type_raw, str) or not algorithm_type_raw.strip():
            raise PayloadValidationError("algorithm_type is required and must be a string")

        algorithm_type = algorithm_type_raw.lower().strip()
        payload["algorithm_type"] = algorithm_type

        if algorithm_type not in _ALGO_CONFIG:
            raise PayloadValidationError(
                f"Unsupported algorithm_type '{algorithm_type}'. "
                f"Supported values: {sorted(_ALGO_CONFIG.keys())}"
            )

        common_required = {"exchange_name", "account_name"}
        required_fields = common_required | _ALGO_CONFIG[algorithm_type]["required"]
        missing_required = [f for f in sorted(required_fields) if payload.get(f) is None]
        if missing_required:
            raise PayloadValidationError(f"Missing required fields: {missing_required}")

        if payload.get("is_proportional") and payload.get("round_robin"):
            raise PayloadValidationError(
                "is_proportional and round_robin are mutually exclusive"
            )

        if payload.get("mirror_accounts") is not None and not isinstance(
            payload.get("mirror_accounts"), list
        ):
            raise PayloadValidationError("mirror_accounts must be a list when provided")

        threshold_type = payload.get("threshold_type")
        if threshold_type is not None and threshold_type not in {"percentage", "dollar", "bps"}:
            raise PayloadValidationError(
                "threshold_type must be one of: percentage, dollar, bps"
            )

        if algorithm_type == "spread_trading":
            if "initial_ratio" in payload or "threshold" in payload:
                raise PayloadValidationError(
                    "Top-level spread fields are not supported. Use "
                    "spread_condition_config.initial_ratio and "
                    "spread_condition_config.threshold."
                )

        if strict:
            allowed_fields = (
                _BASE_ALLOWED_FIELDS | _ALGO_CONFIG[algorithm_type]["required"] | _ALGO_CONFIG[algorithm_type]["allowed"]
            )
            unknown_fields = sorted(set(payload.keys()) - allowed_fields)
            if unknown_fields:
                raise PayloadValidationError(
                    f"Unknown fields for algorithm_type '{algorithm_type}': {unknown_fields}"
                )

    def _submit_place_order(
        self,
        payload: Dict[str, Any],
        strict: bool = True,
    ) -> Dict[str, Any]:
        self._validate_place_order_payload(payload, strict=strict)
        response = self._submit_request(
            method="POST",
            path=Trade.PLACE_ORDER,
            query=payload,
            auth_required=True,
        )
        return response if isinstance(response, dict) else {"response": response}

    def place_order(
        self,
        payload: Dict[str, Any],
        strict: bool = True,
    ) -> Dict[str, Any]:
        """
        Place any supported algorithm order with strict payload validation.
        """
        if payload.get("client_algo_id") is None:
            payload["client_algo_id"] = generate_client_algo_id()

        response = self._submit_place_order(payload=payload, strict=strict)
        return {
            "client_algo_id": payload["client_algo_id"],
            "response": response,
        }
