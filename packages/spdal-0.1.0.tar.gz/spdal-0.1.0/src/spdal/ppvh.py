# Compatibility shim — class was renamed to D4 to match the paper.
from .d4 import D4 as PPVH

__all__ = ["PPVH"]
