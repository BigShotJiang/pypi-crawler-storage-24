"""
Regression tests using the Phishing dataset from river.

Baselines were captured from deprecated/spdal.py.
Dataset: river.datasets.Phishing — 1250 samples, 9 binary features, 2 classes.
Split: train=X[:1000], test=X[1000:] (250 test samples).

Two modes are tested per classifier:
  - Batch (single partial_fit with 1000 training samples)
  - Incremental (10 chunks of 100 samples each via repeated partial_fit)

Requires river package (pip install -e ".[experiments]").
Tests are skipped automatically if river is not installed.
"""

import numpy as np
import pytest

pytest.importorskip("river", reason="river not installed; skip Phishing tests")

from river.datasets import Phishing  # noqa: E402 — after importorskip
from spdal import LRHE, VEBF, SCIL, SHEF, D4, TRACED  # noqa: E402


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def phishing_batch():
    """Single partial_fit on 1000 samples; test on remaining 250."""
    data = Phishing()
    X = np.array([np.array(list(s[0].values())) for s in data])
    y = np.array([int(s[1]) for s in data])
    classes = np.unique(y)
    return X[:1000], X[1000:], y[:1000], classes


@pytest.fixture(scope="module")
def phishing_chunks():
    """10 chunks of 100 samples for incremental partial_fit; test on 250."""
    data = Phishing()
    X = np.array([np.array(list(s[0].values())) for s in data])
    y = np.array([int(s[1]) for s in data])
    classes = np.unique(y)
    X_train, y_train = X[:1000], y[:1000]
    chunks = [(X_train[i:i+100], y_train[i:i+100]) for i in range(0, 1000, 100)]
    return chunks, X[1000:], classes


# ---------------------------------------------------------------------------
# Baselines (captured from deprecated/spdal.py)
# ---------------------------------------------------------------------------

LRHE_PHISHING_BATCH_N_NEURONS = 10
LRHE_PHISHING_BATCH_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

VEBF_PHISHING_BATCH_N_NEURONS = 2
VEBF_PHISHING_BATCH_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

SCIL_PHISHING_BATCH_N_NEURONS = 2
SCIL_PHISHING_BATCH_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

SHEF_PHISHING_BATCH_N_NEURONS = 7
SHEF_PHISHING_BATCH_PREDS = [0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0]

D4_PHISHING_BATCH_N_NEURONS = 2
D4_PHISHING_BATCH_PREDS = [0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0]

TRACED_PHISHING_BATCH_N_NEURONS = 4
TRACED_PHISHING_BATCH_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

LRHE_PHISHING_CHUNK_N_NEURONS = 14
LRHE_PHISHING_CHUNK_PREDS = [0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

VEBF_PHISHING_CHUNK_N_NEURONS = 2
VEBF_PHISHING_CHUNK_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

SCIL_PHISHING_CHUNK_N_NEURONS = 2
SCIL_PHISHING_CHUNK_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

SHEF_PHISHING_CHUNK_N_NEURONS = 2
SHEF_PHISHING_CHUNK_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]

D4_PHISHING_CHUNK_N_NEURONS = 2
D4_PHISHING_CHUNK_PREDS = [0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0]

TRACED_PHISHING_CHUNK_N_NEURONS = 2
TRACED_PHISHING_CHUNK_PREDS = [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestLRHEPhishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = LRHE()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == LRHE_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = LRHE()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == LRHE_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = LRHE()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == LRHE_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = LRHE()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == LRHE_PHISHING_CHUNK_PREDS


class TestVEBFPhishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = VEBF()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == VEBF_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = VEBF()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == VEBF_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = VEBF()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == VEBF_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = VEBF()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == VEBF_PHISHING_CHUNK_PREDS


class TestSCILPhishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = SCIL()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == SCIL_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = SCIL()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == SCIL_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = SCIL()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == SCIL_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = SCIL()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == SCIL_PHISHING_CHUNK_PREDS


class TestSHEFPhishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = SHEF()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == SHEF_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = SHEF()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == SHEF_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = SHEF()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == SHEF_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = SHEF()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == SHEF_PHISHING_CHUNK_PREDS


class TestD4Phishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = D4()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == D4_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = D4()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == D4_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = D4()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == D4_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = D4()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == D4_PHISHING_CHUNK_PREDS


class TestTRACEDPhishing:
    def test_batch_neuron_count(self, phishing_batch):
        X_train, _, y_train, classes = phishing_batch
        clf = TRACED()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert len(clf.neuron_list) == TRACED_PHISHING_BATCH_N_NEURONS

    def test_batch_predictions(self, phishing_batch):
        X_train, X_test, y_train, classes = phishing_batch
        clf = TRACED()
        clf.partial_fit(X_train, y_train, classes=classes)
        assert list(clf.predict(X_test)) == TRACED_PHISHING_BATCH_PREDS

    def test_chunk_neuron_count(self, phishing_chunks):
        chunks, _, classes = phishing_chunks
        clf = TRACED()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert len(clf.neuron_list) == TRACED_PHISHING_CHUNK_N_NEURONS

    def test_chunk_predictions(self, phishing_chunks):
        chunks, X_test, classes = phishing_chunks
        clf = TRACED()
        for Xc, yc in chunks:
            clf.partial_fit(Xc, yc, classes=classes)
        assert list(clf.predict(X_test)) == TRACED_PHISHING_CHUNK_PREDS
