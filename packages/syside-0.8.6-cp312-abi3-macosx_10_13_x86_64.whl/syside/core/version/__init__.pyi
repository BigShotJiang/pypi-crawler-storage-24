"""
Structured access to Syside version
"""

import datetime


def date() -> datetime.datetime:
    """Datetime of when Syside was built"""

major: int = 0
"""Major version of Syside"""

minor: int = 8
"""Minor version of Syside"""

patch: int = 6
"""Patch version of Syside"""

sha: str = 'ef3c3fac9f2272ce28bc036256f22b5c8aec6fbf'
"""Commit hash Syside was built from"""

timestamp: str = '2026-03-06T14:57:28Z'
"""Timestamp of when Syside was built"""

