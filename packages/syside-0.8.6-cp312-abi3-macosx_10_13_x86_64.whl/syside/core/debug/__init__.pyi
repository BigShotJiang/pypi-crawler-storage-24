"""
Various debugging related utilities.

Typically, utilities defined here will not be used.
"""



def set_crash_report_upload(arg: bool, /) -> None:
    """
    Toggle automatic anonymous crash report uploads. This is enabled by default.
    """

def set_leak_warnings(arg: bool, /) -> None:
    """Toggle ``nanobind`` leak reporting."""

