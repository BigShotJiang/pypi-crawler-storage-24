"""
AITG-INF-01 — Testing for AI Supply Chain Vulnerabilities

3-Phase OWASP Methodology:
    Phase 1: Scan ML dependencies for known CVEs, typosquatting, unsigned packages
    Phase 2: Quantitative metrics (CVE count, critical CVEs, outdated deps, pinned versions)
    Phase 3: Defense validation (container scanning, CI/CD integration, private mirrors)

Tools: Safety, pip-audit, Trivy, Grype
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-01_Testing_for_Supply_Chain_Tampering.md
"""

import json
import re
import subprocess
from pathlib import Path

from tests.base import Metric, OWASPTestCase, PhaseResult

# Well-known ML packages to focus on during supply chain analysis
ML_PACKAGES = {
    "torch", "torchvision", "torchaudio", "tensorflow", "keras",
    "transformers", "tokenizers", "datasets", "accelerate", "diffusers",
    "onnx", "onnxruntime", "onnxruntime-gpu", "tensorrt",
    "numpy", "scipy", "scikit-learn", "pandas",
    "art", "adversarial-robustness-toolbox", "foolbox", "secml",
    "tritonclient", "vllm", "openai", "langchain",
    "pillow", "opencv-python", "opencv-python-headless",
    "huggingface-hub", "safetensors", "sentencepiece",
}

# Known typosquatting patterns for ML packages
TYPOSQUAT_PATTERNS = [
    (r"^pytorch$", "torch"),
    (r"^tf$", "tensorflow"),
    (r"^numppy$", "numpy"),
    (r"^scikit_learn$", "scikit-learn"),
    (r"^opencv$", "opencv-python"),
    (r"^request$", "requests"),
    (r"^tensorfow$", "tensorflow"),
    (r"^transfomers$", "transformers"),
]


class INF01SupplyChain(OWASPTestCase):
    TEST_ID = "INF-01"
    TEST_NAME = "Testing for AI Supply Chain Vulnerabilities"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-01"
    TOOLS = ["Safety", "pip-audit", "Trivy", "Grype"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._installed_packages = []
        self._requirements_packages = []
        self._vulnerabilities = []
        self._critical_cves = []
        self._outdated_packages = []
        self._unpinned_count = 0
        self._total_req_count = 0

    def _get_installed_packages(self) -> list:
        """Retrieve installed packages via pip list --format=json."""
        try:
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError) as e:
            self.log(f"pip list failed: {e}")
        return []

    def _parse_requirements(self, config: dict) -> list:
        """Parse requirements.txt to identify ML-specific packages and pinning status."""
        req_paths = [
            Path("requirements.txt"),
            Path(config.get("project", {}).get("requirements", "requirements.txt")),
        ]

        packages = []
        for req_path in req_paths:
            if req_path.exists():
                self.log(f"Parsing {req_path}")
                for line in req_path.read_text().splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("-"):
                        continue
                    # Parse package==version, package>=version, package (unpinned)
                    match = re.match(r"^([a-zA-Z0-9_\-\.]+)\s*(==|>=|<=|~=|!=|>|<)?\s*(.*)$", line)
                    if match:
                        name = match.group(1).lower()
                        operator = match.group(2) or ""
                        version = match.group(3) or ""
                        is_pinned = operator == "=="
                        is_ml = name in ML_PACKAGES or any(
                            name.startswith(prefix) for prefix in ["torch", "tf-", "tensorflow-"]
                        )
                        packages.append({
                            "name": name,
                            "operator": operator,
                            "version": version,
                            "pinned": is_pinned,
                            "ml_package": is_ml,
                        })
                break  # Use first found requirements file

        return packages

    def _check_typosquatting(self, packages: list) -> list:
        """Check installed packages against known typosquatting patterns."""
        suspicious = []
        pkg_names = {p.get("name", "").lower() for p in packages}
        for pattern, legit in TYPOSQUAT_PATTERNS:
            for name in pkg_names:
                if re.match(pattern, name):
                    suspicious.append({"name": name, "likely_intended": legit})
        return suspicious

    def _run_pip_audit(self) -> list:
        """Run pip-audit to find known vulnerabilities."""
        vulns = []
        try:
            result = subprocess.run(
                ["pip-audit", "--format=json", "--progress-spinner=off"],
                capture_output=True, text=True, timeout=120,
            )
            if result.stdout:
                data = json.loads(result.stdout)
                # pip-audit JSON format: {"dependencies": [...]}
                for dep in data.get("dependencies", []):
                    for vuln in dep.get("vulns", []):
                        vulns.append({
                            "package": dep.get("name", ""),
                            "version": dep.get("version", ""),
                            "cve": vuln.get("id", ""),
                            "description": vuln.get("description", "")[:200],
                            "fix_versions": vuln.get("fix_versions", []),
                        })
        except FileNotFoundError:
            self.log("pip-audit not installed (pip install pip-audit)")
        except subprocess.TimeoutExpired:
            self.log("pip-audit timed out after 120s")
        except (json.JSONDecodeError, KeyError) as e:
            self.log(f"pip-audit parse error: {e}")
        return vulns

    def _run_safety_check(self) -> list:
        """Run safety check as fallback if pip-audit is unavailable."""
        vulns = []
        try:
            result = subprocess.run(
                ["safety", "check", "--json"],
                capture_output=True, text=True, timeout=120,
            )
            if result.stdout:
                data = json.loads(result.stdout)
                for item in data if isinstance(data, list) else data.get("vulnerabilities", []):
                    vulns.append({
                        "package": item[0] if isinstance(item, list) else item.get("package", ""),
                        "version": item[2] if isinstance(item, list) else item.get("installed_version", ""),
                        "cve": item[4] if isinstance(item, list) else item.get("vulnerability_id", ""),
                        "description": (item[3] if isinstance(item, list) else item.get("advisory", ""))[:200],
                    })
        except FileNotFoundError:
            self.log("safety not installed (pip install safety)")
        except subprocess.TimeoutExpired:
            self.log("safety check timed out after 120s")
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            self.log(f"safety parse error: {e}")
        return vulns

    def _check_outdated(self) -> list:
        """Check for outdated packages via pip list --outdated."""
        outdated = []
        try:
            result = subprocess.run(
                ["pip", "list", "--outdated", "--format=json"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0 and result.stdout:
                data = json.loads(result.stdout)
                for pkg in data:
                    name = pkg.get("name", "").lower()
                    if name in ML_PACKAGES:
                        outdated.append({
                            "name": name,
                            "current": pkg.get("version", ""),
                            "latest": pkg.get("latest_version", ""),
                        })
        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError) as e:
            self.log(f"pip outdated check failed: {e}")
        return outdated

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Scan installed packages for known CVEs and supply chain risks."""
        pr = PhaseResult(phase=1, name="Supply Chain Vulnerability Scan")

        # Step 1: Get installed packages
        self._installed_packages = self._get_installed_packages()
        ml_installed = [
            p for p in self._installed_packages
            if p.get("name", "").lower() in ML_PACKAGES
        ]
        pr.evidence.append(
            f"Installed packages: {len(self._installed_packages)} total, "
            f"{len(ml_installed)} ML-specific"
        )

        # Step 2: Parse requirements.txt
        self._requirements_packages = self._parse_requirements(config)
        if self._requirements_packages:
            self._total_req_count = len(self._requirements_packages)
            self._unpinned_count = sum(
                1 for p in self._requirements_packages if not p["pinned"]
            )
            ml_reqs = [p for p in self._requirements_packages if p["ml_package"]]
            pr.evidence.append(
                f"requirements.txt: {self._total_req_count} packages, "
                f"{self._unpinned_count} unpinned, {len(ml_reqs)} ML-specific"
            )
        else:
            pr.evidence.append("No requirements.txt found or empty")

        # Step 3: Scan for CVEs with pip-audit (primary) or safety (fallback)
        self.log("Running pip-audit for CVE scan...")
        self._vulnerabilities = self._run_pip_audit()
        if not self._vulnerabilities:
            self.log("pip-audit unavailable or found nothing, trying safety...")
            self._vulnerabilities = self._run_safety_check()

        if self._vulnerabilities:
            pr.evidence.append(f"Found {len(self._vulnerabilities)} known vulnerabilities")
            # Identify critical CVEs (heuristic: CRITICAL in description or known critical CVE patterns)
            for v in self._vulnerabilities:
                cve_id = v.get("cve", "")
                desc = v.get("description", "").lower()
                if "critical" in desc or "remote code execution" in desc or "rce" in desc:
                    self._critical_cves.append(v)
                pr.evidence.append(
                    f"  {v.get('package')} {v.get('version')}: {cve_id}"
                )
        else:
            pr.evidence.append("No known CVEs found (or scanning tools unavailable)")

        # Step 4: Check typosquatting
        typo_suspects = self._check_typosquatting(self._installed_packages)
        if typo_suspects:
            for s in typo_suspects:
                pr.evidence.append(
                    f"TYPOSQUATTING RISK: '{s['name']}' — did you mean '{s['likely_intended']}'?"
                )

        # Step 5: Check outdated ML packages
        self.log("Checking for outdated ML packages...")
        self._outdated_packages = self._check_outdated()
        if self._outdated_packages:
            pr.evidence.append(f"Outdated ML packages: {len(self._outdated_packages)}")
            for pkg in self._outdated_packages[:10]:
                pr.evidence.append(
                    f"  {pkg['name']}: {pkg['current']} -> {pkg['latest']}"
                )

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative supply chain security metrics."""
        pr = PhaseResult(phase=2, name="Supply Chain Metrics")

        # Metric 1: Total known CVEs
        cve_count = len(self._vulnerabilities)
        pr.metrics.append(Metric(
            name="Known CVEs in dependencies",
            value=cve_count,
            threshold_pass=0,
            threshold_fail=5,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-01 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-01_Testing_for_Supply_Chain_Tampering.md",
        ))

        # Metric 2: Critical CVEs
        critical_count = len(self._critical_cves)
        pr.metrics.append(Metric(
            name="Critical CVEs",
            value=critical_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-01 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-01_Testing_for_Supply_Chain_Tampering.md",
        ))

        # Metric 3: Outdated ML dependency count
        outdated_count = len(self._outdated_packages)
        pr.metrics.append(Metric(
            name="Outdated ML dependencies",
            value=outdated_count,
            threshold_pass=2,
            threshold_fail=10,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-01 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-01_Testing_for_Supply_Chain_Tampering.md",
        ))

        # Metric 4: Percentage of pinned versions in requirements.txt
        if self._total_req_count > 0:
            pinned_pct = 1.0 - (self._unpinned_count / self._total_req_count)
        else:
            pinned_pct = 0.0
        pr.metrics.append(Metric(
            name="Pinned dependency ratio",
            value=round(pinned_pct, 4),
            threshold_pass=0.90,
            threshold_fail=0.50,
            unit="%",
            operator=">",
            source="OWASP AITG-INF-01 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-01_Testing_for_Supply_Chain_Tampering.md",
        ))

        pr.evidence.append(
            f"CVEs={cve_count}, critical={critical_count}, "
            f"outdated={outdated_count}, pinned={pinned_pct:.0%}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — container scanning, CI/CD checks."""
        pr = PhaseResult(phase=3, name="Supply Chain Defense Validation")

        # Check if Trivy is available for container scanning
        try:
            result = subprocess.run(
                ["trivy", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                pr.evidence.append(f"Trivy available: {result.stdout.strip()}")
            else:
                pr.evidence.append("Trivy: installed but returned error")
        except FileNotFoundError:
            pr.evidence.append("Trivy: not installed (https://aquasecurity.github.io/trivy)")
        except subprocess.TimeoutExpired:
            pr.evidence.append("Trivy: timed out")

        # Check if Grype is available
        try:
            result = subprocess.run(
                ["grype", "version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                pr.evidence.append(f"Grype available: {result.stdout.strip()[:100]}")
            else:
                pr.evidence.append("Grype: installed but returned error")
        except FileNotFoundError:
            pr.evidence.append("Grype: not installed (https://github.com/anchore/grype)")
        except subprocess.TimeoutExpired:
            pr.evidence.append("Grype: timed out")

        # Check if pip-audit is available for CI/CD integration
        try:
            result = subprocess.run(
                ["pip-audit", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                pr.evidence.append(f"pip-audit available for CI/CD: {result.stdout.strip()}")
        except FileNotFoundError:
            pr.evidence.append("pip-audit: not installed (pip install pip-audit)")
        except subprocess.TimeoutExpired:
            pr.evidence.append("pip-audit: timed out")

        self.result.recommendations = [
            {"text": "Pin all dependency versions in requirements.txt (use == not >=)",
             "url": "https://pip.pypa.io/en/stable/topics/repeatable-installs/"},
            {"text": "Run pip-audit in CI/CD pipeline on every build",
             "url": "https://pypi.org/project/pip-audit/"},
            {"text": "Use a private PyPI mirror (e.g., Artifactory, devpi) for ML packages",
             "url": "https://pypi.org/project/pip-audit/"},
            {"text": "Verify package signatures and checksums before installation",
             "url": "https://docs.sigstore.dev/"},
            {"text": "Scan container images with Trivy/Grype before deployment",
             "url": "https://aquasecurity.github.io/trivy/"},
            {"text": "Enable Dependabot or Renovate for automated dependency updates",
             "url": "https://github.com/anchore/grype"},
            {"text": "Audit ML framework packages (torch, transformers) for known supply chain attacks",
             "url": "https://pypi.org/project/safety/"},
            {"text": "Use hash-checking mode: pip install --require-hashes -r requirements.txt",
             "url": "https://pip.pypa.io/en/stable/topics/repeatable-installs/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF01SupplyChain(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
