"""
AITG-INF-05 — Testing for GPU/Accelerator Security

3-Phase OWASP Methodology:
    Phase 1: Check GPU isolation (MIG/MPS/time-slicing), memory leakage, device plugins
    Phase 2: Quantitative metrics (isolation level, shared GPU count, missing resource limits)
    Phase 3: Defense validation (MIG config, time-slicing limits, memory monitoring)

Tools: Custom, Kubernetes
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-05_Testing_for_Fine-tuning_Poisoning.md
"""

import json
import os
import subprocess

from tests.base import Metric, OWASPTestCase, PhaseResult

# GPU isolation levels (ascending security)
GPU_ISOLATION_LEVELS = {
    "none": 0,        # Shared GPU, no isolation
    "time-slice": 1,  # NVIDIA time-slicing (basic isolation)
    "mps": 2,         # NVIDIA Multi-Process Service (process-level)
    "mig": 3,         # NVIDIA Multi-Instance GPU (hardware-level)
    "passthrough": 4, # Dedicated GPU passthrough (full isolation)
}


class INF05GPUSecurity(OWASPTestCase):
    TEST_ID = "INF-05"
    TEST_NAME = "Testing for GPU/Accelerator Security"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-05"
    TOOLS = ["Custom", "Kubernetes"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._gpu_isolation_level = "none"
        self._shared_gpu_count = 0
        self._missing_gpu_limits_count = 0
        self._gpu_findings = {}

    def _check_nvidia_smi(self) -> dict:
        """Check local nvidia-smi output for GPU configuration."""
        findings = {
            "available": False,
            "gpus": [],
            "mig_enabled": False,
            "mps_enabled": False,
            "processes": [],
        }

        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,mig.mode.current",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                findings["available"] = True
                for line in result.stdout.strip().splitlines():
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 4:
                        gpu = {
                            "name": parts[0],
                            "memory_total_mb": parts[1],
                            "memory_used_mb": parts[2],
                            "mig_mode": parts[3],
                        }
                        findings["gpus"].append(gpu)
                        if parts[3].lower() == "enabled":
                            findings["mig_enabled"] = True

            # Check for running GPU processes (multi-tenancy indicator)
            proc_result = subprocess.run(
                ["nvidia-smi", "--query-compute-apps=pid,name,used_gpu_memory",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=15,
            )
            if proc_result.returncode == 0 and proc_result.stdout.strip():
                for line in proc_result.stdout.strip().splitlines():
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 3:
                        findings["processes"].append({
                            "pid": parts[0],
                            "name": parts[1],
                            "gpu_memory_mb": parts[2],
                        })

            # Check for MPS
            mps_result = subprocess.run(
                ["nvidia-smi", "-q", "-d", "COMPUTE"],
                capture_output=True, text=True, timeout=15,
            )
            if mps_result.returncode == 0 and "MPS" in mps_result.stdout:
                if "MPS Server" in mps_result.stdout:
                    findings["mps_enabled"] = True

        except FileNotFoundError:
            pass  # nvidia-smi not available (no GPU or not installed)
        except subprocess.TimeoutExpired:
            findings["error"] = "nvidia-smi timed out"
        except Exception as e:
            findings["error"] = str(e)

        return findings

    def _check_kubernetes_gpu(self, config: dict) -> dict:
        """Check Kubernetes GPU device plugin and resource configurations."""
        findings = {
            "k8s_available": False,
            "gpu_device_plugin": False,
            "time_slicing_config": None,
            "pods_with_gpu": [],
            "pods_without_gpu_limits": [],
            "shared_gpus": [],
            "gpu_nodes": [],
        }

        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if not kubeconfig:
            return findings

        env = os.environ.copy()
        env["KUBECONFIG"] = kubeconfig

        # Check for NVIDIA GPU device plugin daemonset
        try:
            result = subprocess.run(
                ["kubectl", "get", "daemonsets", "--all-namespaces",
                 "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                findings["k8s_available"] = True
                data = json.loads(result.stdout)
                for ds in data.get("items", []):
                    name = ds.get("metadata", {}).get("name", "")
                    if "nvidia" in name.lower() and ("device" in name.lower() or "gpu" in name.lower()):
                        findings["gpu_device_plugin"] = True
                        # Check device plugin env vars for time-slicing
                        for container in ds.get("spec", {}).get("template", {}).get("spec", {}).get("containers", []):
                            for env_var in container.get("env", []):
                                if env_var.get("name") in ("DEVICE_LIST_STRATEGY", "DEVICE_SPLIT_COUNT"):
                                    findings["time_slicing_config"] = env_var
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            findings["error"] = str(e)
            return findings

        # Check for NVIDIA time-slicing ConfigMap
        try:
            result = subprocess.run(
                ["kubectl", "get", "configmaps", "--all-namespaces",
                 "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for cm in data.get("items", []):
                    name = cm.get("metadata", {}).get("name", "")
                    if "time-slic" in name.lower() or "gpu" in name.lower():
                        cm_data = cm.get("data", {})
                        for key, value in cm_data.items():
                            if "replicas" in str(value).lower() or "timeslicing" in str(value).lower():
                                findings["time_slicing_config"] = {
                                    "configmap": name,
                                    "namespace": cm.get("metadata", {}).get("namespace", ""),
                                    "key": key,
                                    "value_preview": str(value)[:300],
                                }
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
            pass

        # Check nodes for GPU capacity and allocatable
        try:
            result = subprocess.run(
                ["kubectl", "get", "nodes", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for node in data.get("items", []):
                    node_name = node.get("metadata", {}).get("name", "")
                    capacity = node.get("status", {}).get("capacity", {})
                    allocatable = node.get("status", {}).get("allocatable", {})
                    gpu_capacity = capacity.get("nvidia.com/gpu", "0")
                    gpu_allocatable = allocatable.get("nvidia.com/gpu", "0")
                    if int(gpu_capacity) > 0:
                        findings["gpu_nodes"].append({
                            "name": node_name,
                            "gpu_capacity": gpu_capacity,
                            "gpu_allocatable": gpu_allocatable,
                        })
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError):
            pass

        # Check pods for GPU resource requests/limits
        try:
            result = subprocess.run(
                ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                gpu_count_per_node = {}  # Track GPU sharing

                for pod in data.get("items", []):
                    pod_name = pod.get("metadata", {}).get("name", "")
                    namespace = pod.get("metadata", {}).get("namespace", "")
                    node_name = pod.get("spec", {}).get("nodeName", "")

                    for container in pod.get("spec", {}).get("containers", []):
                        resources = container.get("resources", {})
                        limits = resources.get("limits", {})
                        requests_r = resources.get("requests", {})

                        has_gpu_limit = "nvidia.com/gpu" in limits
                        has_gpu_request = "nvidia.com/gpu" in requests_r

                        # Is this an inference/ML pod that should have GPU?
                        is_ml_pod = any(kw in pod_name.lower() for kw in
                                        ["triton", "vllm", "inference", "serving",
                                         "model", "gpu", "cuda"])

                        if has_gpu_limit or has_gpu_request:
                            gpu_count = int(limits.get("nvidia.com/gpu",
                                            requests_r.get("nvidia.com/gpu", "0")))
                            findings["pods_with_gpu"].append({
                                "pod": pod_name,
                                "namespace": namespace,
                                "node": node_name,
                                "gpu_count": gpu_count,
                                "container": container.get("name", ""),
                            })
                            # Track per-node GPU usage
                            if node_name:
                                gpu_count_per_node.setdefault(node_name, 0)
                                gpu_count_per_node[node_name] += gpu_count
                        elif is_ml_pod:
                            findings["pods_without_gpu_limits"].append({
                                "pod": pod_name,
                                "namespace": namespace,
                                "container": container.get("name", ""),
                            })

                # Detect shared GPUs (more pods requesting GPU than physical GPUs on node)
                for node_info in findings["gpu_nodes"]:
                    node_name = node_info["name"]
                    physical_gpus = int(node_info["gpu_capacity"])
                    requested_gpus = gpu_count_per_node.get(node_name, 0)
                    if requested_gpus > physical_gpus:
                        findings["shared_gpus"].append({
                            "node": node_name,
                            "physical_gpus": physical_gpus,
                            "requested_gpus": requested_gpus,
                            "oversubscription": f"{requested_gpus}/{physical_gpus}",
                        })

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError, ValueError):
            pass

        return findings

    def _check_gpu_memory_leakage(self, nvidia_smi_findings: dict) -> dict:
        """Analyze GPU memory usage patterns for potential leakage between tenants."""
        findings = {
            "potential_leakage": False,
            "high_memory_processes": [],
        }

        processes = nvidia_smi_findings.get("processes", [])
        gpus = nvidia_smi_findings.get("gpus", [])

        if processes and gpus:
            # Check if GPU memory usage is unexpectedly high when no active inference
            for gpu in gpus:
                try:
                    mem_used = float(gpu.get("memory_used_mb", 0))
                    mem_total = float(gpu.get("memory_total_mb", 1))
                    usage_pct = mem_used / mem_total if mem_total > 0 else 0
                    # If usage is above 90% with multiple processes, potential issue
                    if usage_pct > 0.9 and len(processes) > 1:
                        findings["potential_leakage"] = True
                        findings["high_memory_processes"] = processes
                except (ValueError, ZeroDivisionError):
                    pass

        return findings

    def _determine_isolation_level(self, nvidia_findings: dict, k8s_findings: dict) -> str:
        """Determine the effective GPU isolation level."""
        if nvidia_findings.get("mig_enabled"):
            return "mig"
        if nvidia_findings.get("mps_enabled"):
            return "mps"
        if k8s_findings.get("time_slicing_config"):
            return "time-slice"
        if k8s_findings.get("pods_with_gpu") and not k8s_findings.get("shared_gpus"):
            return "passthrough"
        if k8s_findings.get("shared_gpus"):
            return "none"
        return "none"

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Assess GPU isolation, memory leakage, and device plugin security."""
        pr = PhaseResult(phase=1, name="GPU/Accelerator Security Assessment")

        # Step 1: Check local nvidia-smi
        self.log("Checking nvidia-smi for GPU configuration...")
        nvidia_findings = self._check_nvidia_smi()
        self._gpu_findings["nvidia"] = nvidia_findings

        if nvidia_findings["available"]:
            pr.evidence.append(f"nvidia-smi available: {len(nvidia_findings['gpus'])} GPUs detected")
            for gpu in nvidia_findings["gpus"]:
                pr.evidence.append(
                    f"  GPU: {gpu['name']}, Memory: {gpu['memory_used_mb']}/"
                    f"{gpu['memory_total_mb']}MB, MIG: {gpu['mig_mode']}"
                )
            if nvidia_findings["mig_enabled"]:
                pr.evidence.append("MIG mode: ENABLED (hardware-level isolation)")
            else:
                pr.evidence.append("MIG mode: DISABLED")
            if nvidia_findings["mps_enabled"]:
                pr.evidence.append("MPS: ENABLED (process-level isolation)")
            if nvidia_findings["processes"]:
                pr.evidence.append(f"Active GPU processes: {len(nvidia_findings['processes'])}")
                for proc in nvidia_findings["processes"][:5]:
                    pr.evidence.append(
                        f"  PID {proc['pid']}: {proc['name']} ({proc['gpu_memory_mb']}MB)"
                    )
        else:
            pr.evidence.append(
                "nvidia-smi not available — GPU checks limited to Kubernetes API"
            )

        # Step 2: Check GPU memory leakage
        leakage_findings = self._check_gpu_memory_leakage(nvidia_findings)
        self._gpu_findings["leakage"] = leakage_findings
        if leakage_findings["potential_leakage"]:
            pr.evidence.append(
                "FINDING: Potential GPU memory leakage detected — "
                "high memory usage with multiple concurrent processes"
            )

        # Step 3: Check Kubernetes GPU configuration
        self.log("Checking Kubernetes GPU device plugins and resource config...")
        k8s_findings = self._check_kubernetes_gpu(config)
        self._gpu_findings["k8s"] = k8s_findings

        if k8s_findings["k8s_available"]:
            if k8s_findings["gpu_device_plugin"]:
                pr.evidence.append("NVIDIA GPU device plugin: deployed")
            else:
                pr.evidence.append("NVIDIA GPU device plugin: NOT FOUND")

            if k8s_findings["time_slicing_config"]:
                ts_cfg = k8s_findings["time_slicing_config"]
                if isinstance(ts_cfg, dict) and "configmap" in ts_cfg:
                    pr.evidence.append(
                        f"GPU time-slicing config found: {ts_cfg.get('configmap')} "
                        f"in {ts_cfg.get('namespace')}"
                    )
                else:
                    pr.evidence.append(f"GPU time-slicing config: {ts_cfg}")
            else:
                pr.evidence.append("GPU time-slicing: not configured")

            if k8s_findings["gpu_nodes"]:
                pr.evidence.append(f"GPU nodes: {len(k8s_findings['gpu_nodes'])}")
                for node in k8s_findings["gpu_nodes"]:
                    pr.evidence.append(
                        f"  {node['name']}: capacity={node['gpu_capacity']}, "
                        f"allocatable={node['gpu_allocatable']}"
                    )

            if k8s_findings["pods_with_gpu"]:
                pr.evidence.append(
                    f"Pods with GPU resource limits: {len(k8s_findings['pods_with_gpu'])}"
                )

            if k8s_findings["pods_without_gpu_limits"]:
                self._missing_gpu_limits_count = len(k8s_findings["pods_without_gpu_limits"])
                pr.evidence.append(
                    f"FINDING: {self._missing_gpu_limits_count} ML pods "
                    f"WITHOUT GPU resource limits"
                )
                for p in k8s_findings["pods_without_gpu_limits"][:5]:
                    pr.evidence.append(f"  - {p['namespace']}/{p['pod']}")

            if k8s_findings["shared_gpus"]:
                self._shared_gpu_count = len(k8s_findings["shared_gpus"])
                pr.evidence.append(
                    f"FINDING: {self._shared_gpu_count} nodes with GPU oversubscription"
                )
                for sg in k8s_findings["shared_gpus"]:
                    pr.evidence.append(
                        f"  {sg['node']}: {sg['oversubscription']} "
                        f"(requested/physical GPUs)"
                    )
        else:
            pr.evidence.append("Kubernetes: not available or kubeconfig not configured")

        # Determine isolation level
        self._gpu_isolation_level = self._determine_isolation_level(
            nvidia_findings, k8s_findings)
        pr.evidence.append(
            f"Effective GPU isolation level: {self._gpu_isolation_level.upper()} "
            f"(score: {GPU_ISOLATION_LEVELS.get(self._gpu_isolation_level, 0)}/4)"
        )

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative GPU security metrics."""
        pr = PhaseResult(phase=2, name="GPU Security Metrics")

        # Metric 1: GPU isolation level (0=none, 1=time-slice, 2=mps, 3=mig, 4=passthrough)
        isolation_score = GPU_ISOLATION_LEVELS.get(self._gpu_isolation_level, 0)
        pr.metrics.append(Metric(
            name="GPU isolation level",
            value=isolation_score,
            threshold_pass=2,    # MPS or higher is good
            threshold_fail=0,    # No isolation is bad
            unit="level (0-4)",
            operator=">",
            source="OWASP AITG-INF-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-05_Testing_for_Fine-tuning_Poisoning.md",
        ))

        # Metric 2: Shared (oversubscribed) GPU count
        pr.metrics.append(Metric(
            name="Shared/oversubscribed GPU nodes",
            value=self._shared_gpu_count,
            threshold_pass=0,
            threshold_fail=2,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-05_Testing_for_Fine-tuning_Poisoning.md",
        ))

        # Metric 3: Missing GPU resource limits on ML pods
        pr.metrics.append(Metric(
            name="ML pods without GPU resource limits",
            value=self._missing_gpu_limits_count,
            threshold_pass=0,
            threshold_fail=2,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-05_Testing_for_Fine-tuning_Poisoning.md",
        ))

        pr.evidence.append(
            f"isolation={self._gpu_isolation_level} (score={isolation_score}), "
            f"shared_nodes={self._shared_gpu_count}, "
            f"missing_gpu_limits={self._missing_gpu_limits_count}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — MIG config, monitoring, memory clearing."""
        pr = PhaseResult(phase=3, name="GPU Security Defense Validation")

        nvidia_findings = self._gpu_findings.get("nvidia", {})
        k8s_findings = self._gpu_findings.get("k8s", {})

        # Evaluate current defenses
        if nvidia_findings.get("mig_enabled"):
            pr.evidence.append(
                "DEFENSE: MIG mode enabled — hardware-level GPU isolation in place"
            )
        elif k8s_findings.get("time_slicing_config"):
            pr.evidence.append(
                "PARTIAL DEFENSE: GPU time-slicing configured — "
                "provides basic scheduling but NO memory isolation"
            )
        elif nvidia_findings.get("mps_enabled"):
            pr.evidence.append(
                "PARTIAL DEFENSE: MPS enabled — provides process-level isolation "
                "but not as strong as MIG"
            )
        else:
            pr.evidence.append(
                "NO DEFENSE: No GPU isolation mechanism detected"
            )

        if k8s_findings.get("gpu_device_plugin"):
            pr.evidence.append(
                "DEFENSE: NVIDIA device plugin deployed for GPU resource management"
            )

        # Check for GPU monitoring (DCGM exporter or nvidia-gpu-exporter)
        if k8s_findings.get("k8s_available"):
            env = os.environ.copy()
            kubeconfig = config.get("kubernetes", {}).get("kubeconfig", "")
            if kubeconfig:
                env["KUBECONFIG"] = kubeconfig
                try:
                    result = subprocess.run(
                        ["kubectl", "get", "pods", "--all-namespaces",
                         "-o", "json"],
                        capture_output=True, text=True, timeout=30, env=env,
                    )
                    if result.returncode == 0:
                        data = json.loads(result.stdout)
                        monitoring_pods = [
                            p.get("metadata", {}).get("name", "")
                            for p in data.get("items", [])
                            if any(kw in p.get("metadata", {}).get("name", "").lower()
                                   for kw in ["dcgm", "gpu-exporter", "gpu-monitor"])
                        ]
                        if monitoring_pods:
                            pr.evidence.append(
                                f"GPU monitoring pods: {monitoring_pods}"
                            )
                        else:
                            pr.evidence.append(
                                "No GPU monitoring (DCGM exporter) found — "
                                "recommend deploying for GPU memory/utilization tracking"
                            )
                except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
                    pass

        self.result.recommendations = [
            {"text": "Enable NVIDIA MIG for multi-tenant GPU isolation (requires Ampere+ GPUs)",
             "url": "https://docs.nvidia.com/datacenter/tesla/mig-user-guide/"},
            {"text": "Configure GPU time-slicing with strict resource limits if MIG is not available",
             "url": "https://docs.nvidia.com/datacenter/tesla/mig-user-guide/"},
            {"text": "Monitor GPU memory usage per process to detect leakage between tenants",
             "url": "https://docs.nvidia.com/datacenter/dcgm/latest/"},
            {"text": "Clear GPU memory between inference requests (torch.cuda.empty_cache())",
             "url": "https://docs.nvidia.com/datacenter/dcgm/latest/"},
            {"text": "Restrict nvidia-smi access — do not expose it to unprivileged containers",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Deploy DCGM Exporter for GPU metrics and Prometheus alerts",
             "url": "https://docs.nvidia.com/datacenter/dcgm/latest/"},
            {"text": "Set nvidia.com/gpu resource requests and limits on all ML pods",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Use RuntimeClass with NVIDIA container runtime for GPU pods",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Implement GPU memory quotas per namespace using device plugin config",
             "url": "https://docs.nvidia.com/datacenter/tesla/mig-user-guide/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF05GPUSecurity(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
