"""
AITG-INF-06 — Testing for Dev-Time Model Theft

3-Phase OWASP Methodology:
    Phase 1: Assess model exposure (file permissions, registry access, download endpoints)
    Phase 2: Quantitative metrics (model file accessibility, registry auth, API download endpoints)
    Phase 3: Defense validation (model encryption, access logging, watermarking)

Tools: kubectl, Trivy, Custom scripts
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md
"""

import json
import os
import subprocess

from tests.base import Metric, OWASPTestCase, PhaseResult

# Common model file extensions used across ML frameworks
MODEL_FILE_EXTENSIONS = (
    ".onnx", ".pt", ".pth", ".bin", ".safetensors",
    ".pb", ".tflite", ".plan", ".engine", ".h5",
    ".pkl", ".joblib", ".mar", ".savedmodel",
)

# Kubernetes namespaces commonly used for model serving
MODEL_SERVING_NAMESPACES = (
    "default", "inference", "serving", "triton",
    "seldon", "kserve", "mlflow", "ai", "ml",
)


class INF06ModelTheft(OWASPTestCase):
    TEST_ID = "INF-06"
    TEST_NAME = "Testing for Dev-Time Model Theft"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-06"
    TOOLS = ["kubectl", "Trivy", "Custom scripts"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._exposed_model_files = []
        self._unauthenticated_registries = []
        self._downloadable_endpoints = []
        self._access_log_findings = {}
        self._encryption_findings = {}
        self._pvc_exposure_findings = []
        self._rbac_findings = {}

    def _get_kubectl_env(self, config: dict) -> dict:
        """Build environment dict with KUBECONFIG set from config."""
        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if not kubeconfig:
            return {}
        env = os.environ.copy()
        env["KUBECONFIG"] = kubeconfig
        return env

    def _check_model_file_permissions_on_pvcs(self, config: dict) -> list:
        """Check model file permissions on NFS-backed PVCs via SSH."""
        findings = []

        storage_cfg = config.get("storage", {})
        nfs_server = storage_cfg.get("nfs_server", "")
        ssh_user = storage_cfg.get("ssh_user", "")
        ssh_pass = storage_cfg.get("ssh_pass", "")
        nfs_path = storage_cfg.get("nfs_path", "")
        model_dirs = storage_cfg.get("model_dirs", [])

        if not (nfs_server and ssh_user and nfs_path):
            self.log("NFS storage config missing — skipping remote permission check")
            return findings

        for model_dir in model_dirs:
            full_path = f"{nfs_path}/{model_dir}"
            try:
                ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no",
                           "-o", "ConnectTimeout=10"]
                if ssh_pass:
                    ssh_cmd = ["sshpass", f"-p{ssh_pass}"] + ssh_cmd

                ssh_cmd += [f"{ssh_user}@{nfs_server}"]

                # Find model files and check permissions + ownership
                ext_filter = " -o ".join(
                    f"-name '*{ext}'" for ext in MODEL_FILE_EXTENSIONS
                )
                find_cmd = ssh_cmd + [
                    f"find {full_path} -type f "
                    f"\\( {ext_filter} \\) "
                    f"-exec stat --format='%n %a %U %G %s' {{}} \\; 2>/dev/null"
                ]

                result = subprocess.run(
                    find_cmd, capture_output=True, text=True, timeout=30,
                )

                if result.returncode == 0 and result.stdout.strip():
                    for line in result.stdout.strip().splitlines():
                        parts = line.rsplit(" ", 4)
                        if len(parts) >= 5:
                            filepath, perms, owner, group, size = parts
                            exposed = False
                            reasons = []

                            # World-readable
                            if perms and int(perms[-1]) & 4:
                                reasons.append("world-readable")
                                exposed = True
                            # World-writable (critical — allows replacement)
                            if perms and int(perms[-1]) & 2:
                                reasons.append("world-writable")
                                exposed = True
                            # Group-writable with broad group
                            if perms and len(perms) >= 2 and int(perms[-2]) & 2:
                                reasons.append("group-writable")
                                exposed = True

                            if exposed:
                                findings.append({
                                    "path": filepath,
                                    "permissions": perms,
                                    "owner": owner,
                                    "group": group,
                                    "size_bytes": size,
                                    "reasons": reasons,
                                })

            except FileNotFoundError:
                self.log("sshpass not installed — cannot perform remote permission checks")
                break
            except subprocess.TimeoutExpired:
                self.log(f"SSH to {nfs_server} timed out for {model_dir}")
            except Exception as e:
                self.log(f"SSH permission check error: {e}")

        return findings

    def _check_registry_authentication(self, config: dict) -> list:
        """Check if container registries serving model images require authentication."""
        unauthenticated = []

        env = self._get_kubectl_env(config)
        if not env:
            return unauthenticated

        try:
            # Get all pods and inspect image pull policies and secrets
            result = subprocess.run(
                ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode != 0:
                return unauthenticated

            data = json.loads(result.stdout)
            for pod in data.get("items", []):
                pod_name = pod.get("metadata", {}).get("name", "")
                namespace = pod.get("metadata", {}).get("namespace", "")
                spec = pod.get("spec", {})

                # Check for imagePullSecrets
                has_pull_secrets = bool(spec.get("imagePullSecrets"))

                for container in spec.get("containers", []):
                    image = container.get("image", "")
                    # Check if this is likely a model-serving container
                    model_keywords = [
                        "triton", "torchserve", "seldon", "kserve",
                        "vllm", "tgi", "inference", "model", "serving",
                    ]
                    is_model_serving = any(
                        kw in image.lower() or kw in container.get("name", "").lower()
                        for kw in model_keywords
                    )

                    if is_model_serving and not has_pull_secrets:
                        # Check if image is from a public registry
                        is_public = (
                            "/" not in image.split(":")[0]  # bare image like "nginx"
                            or image.startswith("docker.io/")
                            or image.startswith("ghcr.io/")
                            or image.startswith("quay.io/")
                            or image.startswith("nvcr.io/")
                        )
                        unauthenticated.append({
                            "pod": pod_name,
                            "namespace": namespace,
                            "container": container.get("name", ""),
                            "image": image,
                            "has_pull_secrets": has_pull_secrets,
                            "public_registry": is_public,
                        })

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Registry auth check failed: {e}")

        return unauthenticated

    def _check_model_download_endpoints(self, config: dict) -> list:
        """Check if model-serving APIs expose model download or export endpoints."""
        downloadable = []

        env = self._get_kubectl_env(config)
        if not env:
            return downloadable

        try:
            # Get services that expose model serving
            result = subprocess.run(
                ["kubectl", "get", "services", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode != 0:
                return downloadable

            data = json.loads(result.stdout)
            for svc in data.get("items", []):
                svc_name = svc.get("metadata", {}).get("name", "")
                namespace = svc.get("metadata", {}).get("namespace", "")
                svc_type = svc.get("spec", {}).get("type", "")
                ports = svc.get("spec", {}).get("ports", [])

                # Identify model-serving services
                model_keywords = [
                    "triton", "torchserve", "seldon", "kserve",
                    "vllm", "tgi", "inference", "model", "serving",
                ]
                is_model_svc = any(
                    kw in svc_name.lower() for kw in model_keywords
                )

                if is_model_svc:
                    # Check if exposed externally
                    externally_exposed = svc_type in ("LoadBalancer", "NodePort")
                    port_list = [
                        {"port": p.get("port"), "nodePort": p.get("nodePort"),
                         "protocol": p.get("protocol", "TCP")}
                        for p in ports
                    ]

                    downloadable.append({
                        "service": svc_name,
                        "namespace": namespace,
                        "type": svc_type,
                        "externally_exposed": externally_exposed,
                        "ports": port_list,
                    })

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Model endpoint check failed: {e}")

        # Also check Ingress/HTTPRoute for model paths
        try:
            result = subprocess.run(
                ["kubectl", "get", "ingress", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for ing in data.get("items", []):
                    ing_name = ing.get("metadata", {}).get("name", "")
                    namespace = ing.get("metadata", {}).get("namespace", "")
                    for rule in ing.get("spec", {}).get("rules", []):
                        host = rule.get("host", "")
                        for path_entry in rule.get("http", {}).get("paths", []):
                            path = path_entry.get("path", "")
                            # Look for model-related paths
                            model_path_keywords = [
                                "model", "v2/models", "v1/models",
                                "inference", "predict", "repository",
                            ]
                            if any(kw in path.lower() for kw in model_path_keywords):
                                downloadable.append({
                                    "service": f"ingress/{ing_name}",
                                    "namespace": namespace,
                                    "type": "Ingress",
                                    "externally_exposed": True,
                                    "host": host,
                                    "path": path,
                                    "ports": [],
                                })
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Ingress check failed: {e}")

        return downloadable

    def _check_rbac_model_access(self, config: dict) -> dict:
        """Check RBAC permissions that could allow model file access."""
        findings = {
            "cluster_roles_checked": 0,
            "overprivileged_roles": [],
            "service_accounts_with_pvc_access": [],
            "k8s_available": False,
        }

        env = self._get_kubectl_env(config)
        if not env:
            return findings

        try:
            # Check ClusterRoles for PVC/PV access
            result = subprocess.run(
                ["kubectl", "get", "clusterroles", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode != 0:
                return findings

            findings["k8s_available"] = True
            data = json.loads(result.stdout)

            for role in data.get("items", []):
                role_name = role.get("metadata", {}).get("name", "")
                findings["cluster_roles_checked"] += 1

                for rule in role.get("rules", []):
                    resources = rule.get("resources", [])
                    verbs = rule.get("verbs", [])

                    # Check for PVC/PV access with dangerous verbs
                    pvc_resources = {"persistentvolumeclaims", "persistentvolumes"}
                    has_pvc_access = bool(
                        set(resources) & pvc_resources or "*" in resources
                    )
                    has_dangerous_verbs = bool(
                        {"get", "list", "watch", "*"} & set(verbs)
                    )

                    if has_pvc_access and has_dangerous_verbs:
                        # Skip system roles
                        if not role_name.startswith("system:"):
                            findings["overprivileged_roles"].append({
                                "role": role_name,
                                "resources": resources,
                                "verbs": verbs,
                            })

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"RBAC check failed: {e}")

        return findings

    def _check_access_logs(self, config: dict) -> dict:
        """Check if access logging is enabled for model artifact storage."""
        findings = {
            "audit_policy_exists": False,
            "model_access_logged": False,
            "log_destinations": [],
            "k8s_available": False,
        }

        env = self._get_kubectl_env(config)
        if not env:
            return findings

        # Check Kubernetes audit policy
        try:
            result = subprocess.run(
                ["kubectl", "get", "configmaps", "--all-namespaces",
                 "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                findings["k8s_available"] = True
                data = json.loads(result.stdout)
                for cm in data.get("items", []):
                    cm_name = cm.get("metadata", {}).get("name", "").lower()
                    cm_data = cm.get("data", {})

                    # Look for audit-related configmaps
                    audit_keywords = ["audit", "logging", "falco", "gatekeeper"]
                    if any(kw in cm_name for kw in audit_keywords):
                        findings["audit_policy_exists"] = True
                        findings["log_destinations"].append(cm_name)

                    # Check configmap data for model access patterns
                    for key, value in cm_data.items():
                        if isinstance(value, str) and any(
                            kw in value.lower()
                            for kw in ["model", "artifact", "volume"]
                        ):
                            findings["model_access_logged"] = True

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Access log check failed: {e}")

        # Check for Falco daemonset (runtime security)
        try:
            result = subprocess.run(
                ["kubectl", "get", "daemonsets", "--all-namespaces",
                 "-o", "jsonpath={.items[*].metadata.name}"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                ds_names = result.stdout.strip().split()
                for ds_name in ds_names:
                    if "falco" in ds_name.lower():
                        findings["audit_policy_exists"] = True
                        findings["log_destinations"].append(f"daemonset/{ds_name}")

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            self.log(f"DaemonSet check failed: {e}")

        return findings

    def _check_model_encryption(self, config: dict) -> dict:
        """Check if model files are encrypted at rest."""
        findings = {
            "storage_class_encryption": [],
            "secrets_encryption_enabled": False,
            "encrypted_model_files": 0,
            "total_model_files": 0,
            "k8s_available": False,
        }

        env = self._get_kubectl_env(config)
        if not env:
            return findings

        # Check StorageClass for encryption parameters
        try:
            result = subprocess.run(
                ["kubectl", "get", "storageclasses", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                findings["k8s_available"] = True
                data = json.loads(result.stdout)
                for sc in data.get("items", []):
                    sc_name = sc.get("metadata", {}).get("name", "")
                    params = sc.get("parameters", {})
                    provisioner = sc.get("provisioner", "")

                    encrypted = any(
                        "encrypt" in k.lower() or "encrypt" in str(v).lower()
                        for k, v in params.items()
                    )
                    findings["storage_class_encryption"].append({
                        "name": sc_name,
                        "provisioner": provisioner,
                        "encrypted": encrypted,
                    })

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"StorageClass check failed: {e}")

        # Check encryption config for secrets (etcd encryption)
        try:
            result = subprocess.run(
                ["kubectl", "get", "secrets", "-n", "kube-system",
                 "-o", "jsonpath={.items[*].metadata.name}"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                secret_names = result.stdout.strip().split()
                for name in secret_names:
                    if "encryption" in name.lower():
                        findings["secrets_encryption_enabled"] = True
                        break

        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            self.log(f"Secrets encryption check failed: {e}")

        # Check via SSH if model files on NFS have encryption headers
        storage_cfg = config.get("storage", {})
        nfs_server = storage_cfg.get("nfs_server", "")
        ssh_user = storage_cfg.get("ssh_user", "")
        ssh_pass = storage_cfg.get("ssh_pass", "")
        nfs_path = storage_cfg.get("nfs_path", "")
        model_dirs = storage_cfg.get("model_dirs", [])

        if nfs_server and ssh_user and nfs_path:
            for model_dir in model_dirs:
                full_path = f"{nfs_path}/{model_dir}"
                try:
                    ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no",
                               "-o", "ConnectTimeout=10"]
                    if ssh_pass:
                        ssh_cmd = ["sshpass", f"-p{ssh_pass}"] + ssh_cmd
                    ssh_cmd += [f"{ssh_user}@{nfs_server}"]

                    # Count model files
                    ext_filter = " -o ".join(
                        f"-name '*{ext}'" for ext in MODEL_FILE_EXTENSIONS
                    )
                    count_cmd = ssh_cmd + [
                        f"find {full_path} -type f "
                        f"\\( {ext_filter} \\) 2>/dev/null | wc -l"
                    ]
                    result = subprocess.run(
                        count_cmd, capture_output=True, text=True, timeout=30,
                    )
                    if result.returncode == 0:
                        count = int(result.stdout.strip())
                        findings["total_model_files"] += count

                except (FileNotFoundError, subprocess.TimeoutExpired, ValueError) as e:
                    self.log(f"NFS model file count error: {e}")
                    break

        return findings

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Assess model exposure — file permissions, registry access, download endpoints."""
        pr = PhaseResult(phase=1, name="Model Theft Exposure Assessment")

        # Step 1: Check model file permissions on PVCs
        self.log("Checking model file permissions on PVCs...")
        self._exposed_model_files = self._check_model_file_permissions_on_pvcs(config)
        if self._exposed_model_files:
            pr.evidence.append(
                f"FINDING: {len(self._exposed_model_files)} exposed model files found"
            )
            for f in self._exposed_model_files[:5]:
                reasons = ", ".join(f["reasons"])
                pr.evidence.append(
                    f"  - {f['path']} (perms={f['permissions']}, {reasons})"
                )
            if len(self._exposed_model_files) > 5:
                pr.evidence.append(
                    f"  ... and {len(self._exposed_model_files) - 5} more"
                )
        else:
            pr.evidence.append("Model file permissions: no exposed files found (or SSH unavailable)")

        # Step 2: Check registry authentication
        self.log("Checking container registry authentication...")
        self._unauthenticated_registries = self._check_registry_authentication(config)
        if self._unauthenticated_registries:
            pr.evidence.append(
                f"FINDING: {len(self._unauthenticated_registries)} model-serving "
                f"pods without imagePullSecrets"
            )
            for entry in self._unauthenticated_registries[:5]:
                pr.evidence.append(
                    f"  - {entry['namespace']}/{entry['pod']}: "
                    f"image={entry['image']} (public={entry['public_registry']})"
                )
        else:
            pr.evidence.append("Registry authentication: all model-serving pods "
                               "have imagePullSecrets (or no model pods found)")

        # Step 3: Check model download endpoints
        self.log("Checking model serving endpoints for download capabilities...")
        self._downloadable_endpoints = self._check_model_download_endpoints(config)
        if self._downloadable_endpoints:
            pr.evidence.append(
                f"Model serving endpoints found: {len(self._downloadable_endpoints)}"
            )
            externally_exposed = [
                ep for ep in self._downloadable_endpoints
                if ep.get("externally_exposed")
            ]
            if externally_exposed:
                pr.evidence.append(
                    f"FINDING: {len(externally_exposed)} externally exposed "
                    f"model serving endpoint(s)"
                )
                for ep in externally_exposed[:5]:
                    pr.evidence.append(
                        f"  - {ep['namespace']}/{ep['service']} "
                        f"(type={ep['type']})"
                    )
            else:
                pr.evidence.append("No externally exposed model endpoints found")
        else:
            pr.evidence.append("No model serving services detected")

        # Step 4: Check RBAC for model access
        self.log("Checking RBAC permissions for model artifact access...")
        self._rbac_findings = self._check_rbac_model_access(config)
        if self._rbac_findings.get("k8s_available"):
            pr.evidence.append(
                f"RBAC: {self._rbac_findings['cluster_roles_checked']} ClusterRoles checked"
            )
            overprivileged = self._rbac_findings.get("overprivileged_roles", [])
            if overprivileged:
                pr.evidence.append(
                    f"FINDING: {len(overprivileged)} non-system ClusterRoles "
                    f"with PVC/PV access"
                )
                for role in overprivileged[:5]:
                    pr.evidence.append(
                        f"  - {role['role']}: resources={role['resources']}, "
                        f"verbs={role['verbs']}"
                    )
            else:
                pr.evidence.append("No overprivileged non-system roles with PVC access found")
        else:
            pr.evidence.append("Kubernetes: not available or kubeconfig not configured")

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative model theft risk metrics."""
        pr = PhaseResult(phase=2, name="Model Theft Risk Metrics")

        # Metric 1: Exposed model files (overly permissive)
        exposed_count = len(self._exposed_model_files)
        pr.metrics.append(Metric(
            name="Exposed model files (overly permissive)",
            value=exposed_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md",
        ))

        # Metric 2: Model pods without registry authentication
        unauth_count = len(self._unauthenticated_registries)
        pr.metrics.append(Metric(
            name="Model pods without imagePullSecrets",
            value=unauth_count,
            threshold_pass=0,
            threshold_fail=3,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md",
        ))

        # Metric 3: Externally exposed model endpoints
        external_count = sum(
            1 for ep in self._downloadable_endpoints
            if ep.get("externally_exposed")
        )
        pr.metrics.append(Metric(
            name="Externally exposed model endpoints",
            value=external_count,
            threshold_pass=0,
            threshold_fail=2,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md",
        ))

        # Metric 4: Overprivileged RBAC roles with PVC access
        overprivileged_count = len(
            self._rbac_findings.get("overprivileged_roles", [])
        )
        pr.metrics.append(Metric(
            name="Overprivileged roles with PVC access",
            value=overprivileged_count,
            threshold_pass=2,
            threshold_fail=5,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md",
        ))

        pr.evidence.append(
            f"exposed_files={exposed_count}, unauth_registries={unauth_count}, "
            f"external_endpoints={external_count}, overprivileged_rbac={overprivileged_count}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — encryption, access logging, watermarking."""
        pr = PhaseResult(phase=3, name="Model Theft Defense Validation")

        # Defense 1: Model encryption at rest
        self.log("Checking model encryption at rest...")
        self._encryption_findings = self._check_model_encryption(config)
        if self._encryption_findings.get("k8s_available"):
            sc_list = self._encryption_findings.get("storage_class_encryption", [])
            encrypted_scs = [sc for sc in sc_list if sc.get("encrypted")]
            pr.evidence.append(
                f"StorageClasses: {len(sc_list)} total, "
                f"{len(encrypted_scs)} with encryption enabled"
            )
            for sc in sc_list:
                status = "ENCRYPTED" if sc["encrypted"] else "NOT ENCRYPTED"
                pr.evidence.append(
                    f"  - {sc['name']} ({sc['provisioner']}): {status}"
                )

            if self._encryption_findings.get("total_model_files", 0) > 0:
                pr.evidence.append(
                    f"Model files on NFS: {self._encryption_findings['total_model_files']} found"
                )
            else:
                pr.evidence.append("No model files found on NFS (or SSH unavailable)")
        else:
            pr.evidence.append("Kubernetes: not available for encryption check")

        # Defense 2: Access logging for model artifacts
        self.log("Checking access logging for model artifacts...")
        self._access_log_findings = self._check_access_logs(config)
        if self._access_log_findings.get("k8s_available"):
            if self._access_log_findings.get("audit_policy_exists"):
                pr.evidence.append(
                    f"Audit logging: enabled via "
                    f"{self._access_log_findings['log_destinations']}"
                )
            else:
                pr.evidence.append(
                    "FINDING: No audit logging configured for model artifact access"
                )
            if self._access_log_findings.get("model_access_logged"):
                pr.evidence.append("Model-specific access logging: detected in configuration")
            else:
                pr.evidence.append(
                    "Model-specific access logging: not detected — "
                    "recommend configuring audit rules for model volumes"
                )
        else:
            pr.evidence.append("Kubernetes: not available for access log check")

        # Defense 3: Check for Trivy (vulnerability scanning for model containers)
        try:
            result = subprocess.run(
                ["trivy", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                pr.evidence.append(f"Trivy available: {result.stdout.strip()}")
            else:
                pr.evidence.append("Trivy: installed but returned error")
        except FileNotFoundError:
            pr.evidence.append("Trivy: not installed (https://aquasecurity.github.io/trivy)")
        except subprocess.TimeoutExpired:
            pr.evidence.append("Trivy: timed out")

        # Defense 4: Watermarking / model fingerprinting check
        pr.evidence.append(
            "Model watermarking: verify that deployed models contain "
            "watermarks or fingerprints for theft detection. "
            "Tools: IBM 360 Watermarking, ML Model Watermarking frameworks"
        )

        self.result.recommendations = [
            {"text": "Restrict model file permissions to 640 (owner rw, group r, no world access)",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md"},
            {"text": "Use imagePullSecrets for all model-serving container images from private registries",
             "url": "https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/"},
            {"text": "Encrypt model files at rest using StorageClass encryption or LUKS volumes",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Enable Kubernetes audit logging with rules targeting PVC and model volume access",
             "url": "https://kubernetes.io/docs/tasks/debug/debug-cluster/audit/"},
            {"text": "Deploy Falco for runtime detection of unauthorized model file access",
             "url": "https://falco.org/docs/"},
            {"text": "Implement model watermarking or fingerprinting for theft detection and attribution",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-06_Testing_for_Dev-Time_Model_Theft.md"},
            {"text": "Restrict RBAC roles to minimize PVC/PV access to only required service accounts",
             "url": "https://kubernetes.io/docs/reference/access-authn-authz/rbac/"},
            {"text": "Use NetworkPolicies to restrict egress from model-serving pods (prevent exfiltration)",
             "url": "https://kubernetes.io/docs/concepts/services-networking/network-policies/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF06ModelTheft(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
