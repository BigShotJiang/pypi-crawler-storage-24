"""
AITG-INF-04 — Testing for Resource Exhaustion (DoS)

3-Phase OWASP Methodology:
    Phase 1: Send crafted inputs to measure resource consumption (large inputs, high batch, long prompts)
    Phase 2: Quantitative metrics (baseline vs stress latency, timeout rate, latency ratio)
    Phase 3: Defense validation (k8s resource limits, timeouts, autoscaling, circuit breakers)

Tools: Custom, requests
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-04_Testing_for_Capability_Misuse.md
"""

import json
import os
import subprocess
import time

import numpy as np

from tests.base import Metric, OWASPTestCase, PhaseResult, build_base_url

try:
    import requests as req_lib
except ImportError:
    req_lib = None


class INF04ResourceExhaustion(OWASPTestCase):
    TEST_ID = "INF-04"
    TEST_NAME = "Testing for Resource Exhaustion (DoS)"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-04"
    TOOLS = ["Custom", "requests"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._baseline_latencies = []
        self._stress_latencies = []
        self._timeout_count = 0
        self._total_stress_requests = 0
        self._resource_limit_findings = {}

    def _measure_triton_latency(self, url: str, model_name: str,
                                input_shape: list, payload_scale: float = 1.0) -> dict:
        """Measure Triton inference latency with a given payload scale."""
        result = {"latency_ms": None, "status_code": None, "error": None, "timed_out": False}
        if req_lib is None:
            result["error"] = "requests library not installed"
            return result

        # Build Triton inference request payload
        scaled_shape = list(input_shape)
        # Scale the spatial dimensions (not channels) for stress testing
        if payload_scale > 1.0 and len(scaled_shape) >= 3:
            # Only scale within safe bounds (max 2x for stress testing)
            # Keep the same shape but fill with more complex data patterns
            pass

        # Create input data
        n_elements = 1
        for d in input_shape:
            n_elements *= d
        input_data = np.random.rand(1, *input_shape).astype(np.float32).tolist()

        payload = {
            "inputs": [{
                "name": "images",  # Common Triton input name
                "shape": [1] + list(input_shape),
                "datatype": "FP32",
                "data": input_data,
            }]
        }

        try:
            infer_url = f"{build_base_url(url)}/v2/models/{model_name}/infer"
            start = time.time()
            resp = req_lib.post(
                infer_url,
                json=payload,
                timeout=30,
                verify=False,
            )
            elapsed_ms = (time.time() - start) * 1000
            result["latency_ms"] = elapsed_ms
            result["status_code"] = resp.status_code
        except req_lib.exceptions.Timeout:
            result["timed_out"] = True
            result["latency_ms"] = 30000  # timeout value
        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except Exception as e:
            result["error"] = str(e)

        return result

    def _measure_vllm_latency(self, url: str, api_base: str, model_name: str,
                              prompt_length: str = "short") -> dict:
        """Measure vLLM inference latency with varying prompt sizes."""
        result = {"latency_ms": None, "status_code": None, "error": None, "timed_out": False}
        if req_lib is None:
            result["error"] = "requests library not installed"
            return result

        # Prompt sizes for stress testing
        prompts = {
            "short": "Hello, what is 2+2?",
            "medium": "Explain the concept of machine learning in detail. " * 20,
            "long": "Write a comprehensive analysis of the following topic. " * 100,
            "max": "Analyze this text: " + "A" * 4000,
        }

        payload = {
            "model": model_name,
            "messages": [{"role": "user", "content": prompts.get(prompt_length, prompts["short"])}],
            "max_tokens": 50 if prompt_length == "short" else 200,
            "temperature": 0,
        }

        try:
            chat_url = f"{build_base_url(url, api_base)}/chat/completions"
            start = time.time()
            resp = req_lib.post(
                chat_url,
                json=payload,
                timeout=60,
                verify=False,
            )
            elapsed_ms = (time.time() - start) * 1000
            result["latency_ms"] = elapsed_ms
            result["status_code"] = resp.status_code
        except req_lib.exceptions.Timeout:
            result["timed_out"] = True
            result["latency_ms"] = 60000
        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except Exception as e:
            result["error"] = str(e)

        return result

    def _measure_generic_latency(self, url: str, payload_size: str = "small") -> dict:
        """Measure generic endpoint latency."""
        result = {"latency_ms": None, "status_code": None, "error": None, "timed_out": False}
        if req_lib is None:
            result["error"] = "requests library not installed"
            return result

        try:
            start = time.time()
            resp = req_lib.get(url, timeout=30, verify=False)
            elapsed_ms = (time.time() - start) * 1000
            result["latency_ms"] = elapsed_ms
            result["status_code"] = resp.status_code
        except req_lib.exceptions.Timeout:
            result["timed_out"] = True
            result["latency_ms"] = 30000
        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except Exception as e:
            result["error"] = str(e)

        return result

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Measure baseline vs stress response times (non-destructive)."""
        pr = PhaseResult(phase=1, name="Resource Exhaustion Assessment")

        if req_lib is None:
            pr.evidence.append("requests library not installed — cannot perform latency tests")
            pr.status = "ERROR"
            pr.error = "Missing dependency: requests"
            return pr

        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        num_baseline_samples = config.get("params", {}).get(
            "resource_exhaustion", {}).get("baseline_samples", 3)
        num_stress_samples = config.get("params", {}).get(
            "resource_exhaustion", {}).get("stress_samples", 3)

        # Test Triton endpoints
        triton_cfg = config.get("models", {}).get("triton", {})
        if triton_cfg:
            url = triton_cfg.get("url", "")
            for model in triton_cfg.get("models", [])[:3]:  # Limit to 3 models
                model_name = model.get("name", "")
                input_shape = model.get("input_shape", [3, 224, 224])
                self.log(f"Testing Triton model: {model_name}")

                # Baseline: normal-sized requests
                for i in range(num_baseline_samples):
                    res = self._measure_triton_latency(url, model_name, input_shape)
                    if res["latency_ms"] is not None and not res.get("error"):
                        self._baseline_latencies.append(res["latency_ms"])
                        pr.evidence.append(
                            f"Baseline {model_name} #{i+1}: "
                            f"{res['latency_ms']:.0f}ms (HTTP {res['status_code']})"
                        )

                # Stress: larger payloads
                for i in range(num_stress_samples):
                    res = self._measure_triton_latency(
                        url, model_name, input_shape, payload_scale=2.0)
                    self._total_stress_requests += 1
                    if res.get("timed_out"):
                        self._timeout_count += 1
                    if res["latency_ms"] is not None:
                        self._stress_latencies.append(res["latency_ms"])
                        pr.evidence.append(
                            f"Stress {model_name} #{i+1}: "
                            f"{res['latency_ms']:.0f}ms "
                            f"{'(TIMEOUT)' if res.get('timed_out') else ''}"
                        )

        # Test vLLM endpoints
        vllm_cfg = config.get("models", {}).get("vllm", {})
        if vllm_cfg:
            url = vllm_cfg.get("url", "")
            api_base = vllm_cfg.get("api_base", "/v1")
            for model in vllm_cfg.get("models", [])[:2]:
                model_name = model.get("name", "")
                self.log(f"Testing vLLM model: {model_name}")

                # Baseline: short prompts
                for i in range(num_baseline_samples):
                    res = self._measure_vllm_latency(url, api_base, model_name, "short")
                    if res["latency_ms"] is not None and not res.get("error"):
                        self._baseline_latencies.append(res["latency_ms"])
                        pr.evidence.append(
                            f"Baseline vLLM {model_name} (short) #{i+1}: "
                            f"{res['latency_ms']:.0f}ms"
                        )

                # Stress: long prompts
                for prompt_size in ["medium", "long"]:
                    for i in range(num_stress_samples):
                        res = self._measure_vllm_latency(
                            url, api_base, model_name, prompt_size)
                        self._total_stress_requests += 1
                        if res.get("timed_out"):
                            self._timeout_count += 1
                        if res["latency_ms"] is not None:
                            self._stress_latencies.append(res["latency_ms"])
                            pr.evidence.append(
                                f"Stress vLLM {model_name} ({prompt_size}) #{i+1}: "
                                f"{res['latency_ms']:.0f}ms "
                                f"{'(TIMEOUT)' if res.get('timed_out') else ''}"
                            )

        if not self._baseline_latencies and not self._stress_latencies:
            pr.evidence.append("No endpoints reachable — all connection attempts failed")

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative resource exhaustion metrics."""
        pr = PhaseResult(phase=2, name="Resource Exhaustion Metrics")

        # Metric 1: Baseline inference latency (mean)
        if self._baseline_latencies:
            baseline_mean = np.mean(self._baseline_latencies)
            pr.metrics.append(Metric(
                name="Baseline inference latency (mean)",
                value=round(baseline_mean, 2),
                threshold_pass=500,    # < 500ms is good
                threshold_fail=5000,   # > 5000ms is bad
                unit="ms",
                operator="<",
                source="OWASP AITG-INF-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-04_Testing_for_Capability_Misuse.md",
            ))
        else:
            baseline_mean = 0

        # Metric 2: Stress inference latency (mean)
        if self._stress_latencies:
            stress_mean = np.mean(self._stress_latencies)
            pr.metrics.append(Metric(
                name="Stress inference latency (mean)",
                value=round(stress_mean, 2),
                threshold_pass=2000,    # < 2s is OK under stress
                threshold_fail=30000,   # > 30s is very bad
                unit="ms",
                operator="<",
                source="OWASP AITG-INF-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-04_Testing_for_Capability_Misuse.md",
            ))
        else:
            stress_mean = 0

        # Metric 3: Latency ratio (stress / baseline)
        if baseline_mean > 0 and stress_mean > 0:
            latency_ratio = stress_mean / baseline_mean
            pr.metrics.append(Metric(
                name="Latency ratio (stress/baseline)",
                value=round(latency_ratio, 2),
                threshold_pass=3.0,    # < 3x slowdown is acceptable
                threshold_fail=10.0,   # > 10x is dangerous
                unit="x",
                operator="<",
                source="OWASP AITG-INF-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-04_Testing_for_Capability_Misuse.md",
            ))
        else:
            latency_ratio = 0

        # Metric 4: Timeout rate under stress
        if self._total_stress_requests > 0:
            timeout_rate = self._timeout_count / self._total_stress_requests
        else:
            timeout_rate = 0
        pr.metrics.append(Metric(
            name="Timeout rate under stress",
            value=round(timeout_rate, 4),
            threshold_pass=0.0,
            threshold_fail=0.20,
            unit="%",
            operator="<",
            source="OWASP AITG-INF-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-04_Testing_for_Capability_Misuse.md",
        ))

        pr.evidence.append(
            f"baseline_mean={baseline_mean:.0f}ms, stress_mean={stress_mean:.0f}ms, "
            f"ratio={latency_ratio:.1f}x, timeout_rate={timeout_rate:.0%} "
            f"({self._timeout_count}/{self._total_stress_requests})"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — resource limits, timeouts, autoscaling."""
        pr = PhaseResult(phase=3, name="Resource Exhaustion Defense Validation")

        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")

        if kubeconfig:
            env = os.environ.copy()
            env["KUBECONFIG"] = kubeconfig

            # Check for resource requests/limits on inference pods
            try:
                result = subprocess.run(
                    ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    pods_without_limits = []
                    pods_with_gpu_limits = []

                    for pod in data.get("items", []):
                        pod_name = pod.get("metadata", {}).get("name", "")
                        namespace = pod.get("metadata", {}).get("namespace", "")

                        # Check inference-related pods
                        is_inference = any(kw in pod_name.lower() for kw in
                                           ["triton", "vllm", "inference", "serving",
                                            "model", "predictor"])
                        if not is_inference:
                            continue

                        for container in pod.get("spec", {}).get("containers", []):
                            resources = container.get("resources", {})
                            limits = resources.get("limits", {})
                            requests_r = resources.get("requests", {})

                            has_cpu_limit = "cpu" in limits
                            has_mem_limit = "memory" in limits
                            has_gpu = "nvidia.com/gpu" in limits or "nvidia.com/gpu" in requests_r

                            if not has_cpu_limit or not has_mem_limit:
                                pods_without_limits.append(
                                    f"{namespace}/{pod_name}/{container.get('name', '')}"
                                )
                            if has_gpu:
                                pods_with_gpu_limits.append(
                                    f"{namespace}/{pod_name}: "
                                    f"GPU={limits.get('nvidia.com/gpu', requests_r.get('nvidia.com/gpu', '?'))}"
                                )

                    if pods_without_limits:
                        pr.evidence.append(
                            f"FINDING: {len(pods_without_limits)} inference containers "
                            f"without CPU/memory limits"
                        )
                        for p in pods_without_limits[:5]:
                            pr.evidence.append(f"  - {p}")
                        self._resource_limit_findings["missing_limits"] = pods_without_limits
                    else:
                        pr.evidence.append("All inference containers have CPU/memory limits set")

                    if pods_with_gpu_limits:
                        pr.evidence.append(
                            f"GPU resource limits found on {len(pods_with_gpu_limits)} containers"
                        )
                    else:
                        pr.evidence.append("No GPU resource limits found on inference pods")

            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
                pr.evidence.append(f"Pod resource check failed: {e}")

            # Check for HPA (Horizontal Pod Autoscaler)
            try:
                result = subprocess.run(
                    ["kubectl", "get", "hpa", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    hpas = data.get("items", [])
                    if hpas:
                        pr.evidence.append(f"HorizontalPodAutoscalers found: {len(hpas)}")
                        for hpa in hpas:
                            name = hpa.get("metadata", {}).get("name", "")
                            ns = hpa.get("metadata", {}).get("namespace", "")
                            min_r = hpa.get("spec", {}).get("minReplicas", "?")
                            max_r = hpa.get("spec", {}).get("maxReplicas", "?")
                            pr.evidence.append(f"  HPA {ns}/{name}: min={min_r}, max={max_r}")
                    else:
                        pr.evidence.append("No HPA found — consider autoscaling for inference pods")
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
                pass

            # Check for LimitRange or ResourceQuota
            try:
                result = subprocess.run(
                    ["kubectl", "get", "limitrange,resourcequota",
                     "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    items = data.get("items", [])
                    if items:
                        pr.evidence.append(f"LimitRange/ResourceQuota resources: {len(items)}")
                    else:
                        pr.evidence.append("No LimitRange or ResourceQuota configured")
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
                pass
        else:
            pr.evidence.append("Kubernetes: kubeconfig not configured — skipping k8s checks")

        self.result.recommendations = [
            {"text": "Set CPU and memory resource limits on all inference pods",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Set GPU resource limits (nvidia.com/gpu) on all GPU inference pods",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Implement request timeouts at API gateway level (30s for inference, 60s for LLM)",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Add input size validation — reject payloads exceeding maximum dimensions",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Deploy HorizontalPodAutoscaler (HPA) for inference deployments",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Implement circuit breaker pattern (e.g., Envoy circuit breaking) for inference APIs",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Set max batch size limits in Triton model config",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Configure LimitRange and ResourceQuota for inference namespaces",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
            {"text": "Monitor inference latency with Prometheus alerts for latency spikes",
             "url": "https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF04ResourceExhaustion(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
