"""
AITG-INF-02 — Testing for Insecure Model Storage

3-Phase OWASP Methodology:
    Phase 1: Check file permissions, integrity hashes, PVC security, NFS exports
    Phase 2: Quantitative metrics (world-readable files, missing hashes, writable volumes)
    Phase 3: Defense validation (readOnly mounts, SHA256 CronJob, encryption at rest)

Tools: Custom, Kubernetes
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-02_Testing_for_Resource_Exhaustion.md
"""

import json
import os
import subprocess

from tests.base import Metric, OWASPTestCase, PhaseResult


class INF02ModelStorage(OWASPTestCase):
    TEST_ID = "INF-02"
    TEST_NAME = "Testing for Insecure Model Storage"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-02"
    TOOLS = ["Custom", "Kubernetes"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._world_readable_files = []
        self._missing_integrity_hashes = []
        self._writable_volumes = []
        self._unencrypted_storage = []
        self._storage_findings = {}

    def _check_nfs_permissions(self, config: dict) -> dict:
        """Check NFS model file permissions via SSH if credentials are available."""
        findings = {
            "world_readable": [],
            "world_writable": [],
            "checked_dirs": 0,
            "total_model_files": 0,
            "ssh_available": False,
        }

        storage_cfg = config.get("storage", {})
        nfs_server = storage_cfg.get("nfs_server", "")
        ssh_user = storage_cfg.get("ssh_user", "")
        ssh_pass = storage_cfg.get("ssh_pass", "")
        nfs_path = storage_cfg.get("nfs_path", "")
        model_dirs = storage_cfg.get("model_dirs", [])

        if not (nfs_server and ssh_user and nfs_path):
            return findings

        # Try SSH to check file permissions on NFS server
        for model_dir in model_dirs:
            full_path = f"{nfs_path}/{model_dir}"
            try:
                # Use sshpass for non-interactive SSH if password is available
                ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no",
                           "-o", "ConnectTimeout=10"]
                if ssh_pass:
                    ssh_cmd = ["sshpass", f"-p{ssh_pass}"] + ssh_cmd

                ssh_cmd += [f"{ssh_user}@{nfs_server}"]

                # Find model files and check permissions
                find_cmd = ssh_cmd + [
                    f"find {full_path} -type f "
                    f"\\( -name '*.onnx' -o -name '*.pt' -o -name '*.pth' "
                    f"-o -name '*.bin' -o -name '*.safetensors' -o -name '*.pb' "
                    f"-o -name '*.tflite' -o -name '*.plan' -o -name '*.engine' \\) "
                    f"-exec stat --format='%n %a %U %G' {{}} \\; 2>/dev/null"
                ]

                result = subprocess.run(
                    find_cmd, capture_output=True, text=True, timeout=30,
                )
                findings["ssh_available"] = True
                findings["checked_dirs"] += 1

                if result.returncode == 0 and result.stdout.strip():
                    for line in result.stdout.strip().splitlines():
                        parts = line.rsplit(" ", 3)
                        if len(parts) >= 2:
                            filepath = parts[0]
                            perms = parts[1] if len(parts) > 1 else ""
                            findings["total_model_files"] += 1
                            # Check world-readable (o+r -> last digit includes 4)
                            if perms and int(perms[-1]) & 4:
                                findings["world_readable"].append(filepath)
                            # Check world-writable (o+w -> last digit includes 2)
                            if perms and int(perms[-1]) & 2:
                                findings["world_writable"].append(filepath)

            except FileNotFoundError:
                self.log("sshpass not installed — cannot perform remote permission checks")
                break
            except subprocess.TimeoutExpired:
                self.log(f"SSH to {nfs_server} timed out for {model_dir}")
            except Exception as e:
                self.log(f"SSH check error: {e}")

        return findings

    def _check_integrity_hashes(self, config: dict) -> dict:
        """Check if model files have associated SHA256 integrity hashes."""
        findings = {
            "models_with_hash": [],
            "models_without_hash": [],
        }

        storage_cfg = config.get("storage", {})
        nfs_server = storage_cfg.get("nfs_server", "")
        ssh_user = storage_cfg.get("ssh_user", "")
        ssh_pass = storage_cfg.get("ssh_pass", "")
        nfs_path = storage_cfg.get("nfs_path", "")
        model_dirs = storage_cfg.get("model_dirs", [])

        if not (nfs_server and ssh_user and nfs_path):
            return findings

        for model_dir in model_dirs:
            full_path = f"{nfs_path}/{model_dir}"
            try:
                ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no",
                           "-o", "ConnectTimeout=10"]
                if ssh_pass:
                    ssh_cmd = ["sshpass", f"-p{ssh_pass}"] + ssh_cmd

                ssh_cmd += [f"{ssh_user}@{nfs_server}"]

                # Check for .sha256 sidecar files next to model files
                check_cmd = ssh_cmd + [
                    f"find {full_path} -type f "
                    f"\\( -name '*.onnx' -o -name '*.pt' -o -name '*.pth' "
                    f"-o -name '*.bin' -o -name '*.safetensors' -o -name '*.plan' \\) "
                    f"-exec sh -c 'if [ -f \"$1.sha256\" ]; then echo \"HAS_HASH $1\"; "
                    f"else echo \"NO_HASH $1\"; fi' _ {{}} \\; 2>/dev/null"
                ]

                result = subprocess.run(
                    check_cmd, capture_output=True, text=True, timeout=30,
                )

                if result.returncode == 0 and result.stdout.strip():
                    for line in result.stdout.strip().splitlines():
                        if line.startswith("HAS_HASH "):
                            findings["models_with_hash"].append(line[9:])
                        elif line.startswith("NO_HASH "):
                            findings["models_without_hash"].append(line[8:])

            except (FileNotFoundError, subprocess.TimeoutExpired, Exception) as e:
                self.log(f"Integrity hash check error: {e}")

        return findings

    def _check_kubernetes_pvcs(self, config: dict) -> dict:
        """Check Kubernetes PVC security settings."""
        findings = {
            "pvcs": [],
            "writable_model_volumes": [],
            "readonly_model_volumes": [],
            "unencrypted_pvcs": [],
            "k8s_available": False,
        }

        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if not kubeconfig:
            return findings

        env = os.environ.copy()
        env["KUBECONFIG"] = kubeconfig

        # Get PVCs
        try:
            result = subprocess.run(
                ["kubectl", "get", "pvc", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                findings["k8s_available"] = True
                data = json.loads(result.stdout)
                for item in data.get("items", []):
                    pvc_name = item.get("metadata", {}).get("name", "")
                    namespace = item.get("metadata", {}).get("namespace", "")
                    storage_class = item.get("spec", {}).get("storageClassName", "")
                    findings["pvcs"].append({
                        "name": pvc_name,
                        "namespace": namespace,
                        "storage_class": storage_class,
                    })
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"kubectl PVC check failed: {e}")
            return findings

        # Check pods for readOnly volume mounts
        try:
            result = subprocess.run(
                ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for pod in data.get("items", []):
                    pod_name = pod.get("metadata", {}).get("name", "")
                    namespace = pod.get("metadata", {}).get("namespace", "")
                    for container in pod.get("spec", {}).get("containers", []):
                        for vm in container.get("volumeMounts", []):
                            mount_path = vm.get("mountPath", "")
                            # Detect model-related mounts
                            if any(kw in mount_path.lower() for kw in
                                   ["model", "onnx", "repository", "weights"]):
                                entry = {
                                    "pod": pod_name,
                                    "namespace": namespace,
                                    "container": container.get("name", ""),
                                    "mount_path": mount_path,
                                    "read_only": vm.get("readOnly", False),
                                }
                                if vm.get("readOnly", False):
                                    findings["readonly_model_volumes"].append(entry)
                                else:
                                    findings["writable_model_volumes"].append(entry)
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"kubectl pod mount check failed: {e}")

        return findings

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Check model storage security — permissions, integrity, PVC config."""
        pr = PhaseResult(phase=1, name="Model Storage Security Scan")

        # Step 1: Check NFS file permissions
        self.log("Checking NFS model file permissions...")
        nfs_findings = self._check_nfs_permissions(config)
        self._storage_findings["nfs"] = nfs_findings

        if nfs_findings["ssh_available"]:
            pr.evidence.append(
                f"NFS scan: {nfs_findings['total_model_files']} model files found "
                f"across {nfs_findings['checked_dirs']} directories"
            )
            self._world_readable_files = nfs_findings["world_readable"]
            if nfs_findings["world_readable"]:
                pr.evidence.append(
                    f"FINDING: {len(nfs_findings['world_readable'])} world-readable model files"
                )
                for f in nfs_findings["world_readable"][:5]:
                    pr.evidence.append(f"  - {f}")
            if nfs_findings["world_writable"]:
                pr.evidence.append(
                    f"CRITICAL: {len(nfs_findings['world_writable'])} world-writable model files"
                )
                for f in nfs_findings["world_writable"][:5]:
                    pr.evidence.append(f"  - {f}")
        else:
            pr.evidence.append(
                "NFS SSH check: unavailable (sshpass not installed or SSH failed)"
            )

        # Step 2: Check integrity hashes
        self.log("Checking model integrity hashes...")
        hash_findings = self._check_integrity_hashes(config)
        self._storage_findings["integrity"] = hash_findings
        self._missing_integrity_hashes = hash_findings["models_without_hash"]

        has_hash_count = len(hash_findings["models_with_hash"])
        no_hash_count = len(hash_findings["models_without_hash"])
        pr.evidence.append(
            f"Integrity hashes: {has_hash_count} models with SHA256, "
            f"{no_hash_count} without"
        )
        if hash_findings["models_without_hash"]:
            for m in hash_findings["models_without_hash"][:5]:
                pr.evidence.append(f"  Missing hash: {m}")

        # Step 3: Check Kubernetes PVC security
        self.log("Checking Kubernetes PVC/volume mount security...")
        k8s_findings = self._check_kubernetes_pvcs(config)
        self._storage_findings["k8s"] = k8s_findings
        self._writable_volumes = k8s_findings["writable_model_volumes"]

        if k8s_findings["k8s_available"]:
            pr.evidence.append(f"Kubernetes PVCs found: {len(k8s_findings['pvcs'])}")
            if k8s_findings["writable_model_volumes"]:
                pr.evidence.append(
                    f"FINDING: {len(k8s_findings['writable_model_volumes'])} "
                    f"writable model volume mounts"
                )
                for vol in k8s_findings["writable_model_volumes"][:5]:
                    pr.evidence.append(
                        f"  - {vol['namespace']}/{vol['pod']}:{vol['mount_path']} "
                        f"(readOnly={vol['read_only']})"
                    )
            if k8s_findings["readonly_model_volumes"]:
                pr.evidence.append(
                    f"OK: {len(k8s_findings['readonly_model_volumes'])} "
                    f"read-only model volume mounts"
                )
        else:
            pr.evidence.append("Kubernetes: not available or kubeconfig not configured")

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative model storage security metrics."""
        pr = PhaseResult(phase=2, name="Model Storage Metrics")

        # Metric 1: World-readable model files
        world_readable_count = len(self._world_readable_files)
        pr.metrics.append(Metric(
            name="World-readable model files",
            value=world_readable_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-02 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-02_Testing_for_Resource_Exhaustion.md",
        ))

        # Metric 2: Models missing integrity hashes
        missing_hash_count = len(self._missing_integrity_hashes)
        pr.metrics.append(Metric(
            name="Models missing integrity hash",
            value=missing_hash_count,
            threshold_pass=0,
            threshold_fail=3,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-02 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-02_Testing_for_Resource_Exhaustion.md",
        ))

        # Metric 3: Writable model volumes in Kubernetes
        writable_vol_count = len(self._writable_volumes)
        pr.metrics.append(Metric(
            name="Writable model volume mounts",
            value=writable_vol_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-02 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-02_Testing_for_Resource_Exhaustion.md",
        ))

        # Metric 4: Unencrypted storage (based on storage class analysis)
        unencrypted_count = len(self._unencrypted_storage)
        pr.metrics.append(Metric(
            name="Unencrypted model storage",
            value=unencrypted_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-02 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-02_Testing_for_Resource_Exhaustion.md",
        ))

        pr.evidence.append(
            f"world_readable={world_readable_count}, missing_hashes={missing_hash_count}, "
            f"writable_volumes={writable_vol_count}, unencrypted={unencrypted_count}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — readOnly mounts, integrity CronJobs, encryption."""
        pr = PhaseResult(phase=3, name="Model Storage Defense Validation")

        # Check if any readOnly mounts exist (defense in place)
        k8s_findings = self._storage_findings.get("k8s", {})
        if k8s_findings.get("readonly_model_volumes"):
            pr.evidence.append(
                f"ReadOnly volume mounts deployed: "
                f"{len(k8s_findings['readonly_model_volumes'])} volumes"
            )
        else:
            pr.evidence.append("No readOnly volume mounts found for model directories")

        # Check for integrity CronJob in Kubernetes
        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if kubeconfig:
            env = os.environ.copy()
            env["KUBECONFIG"] = kubeconfig
            try:
                result = subprocess.run(
                    ["kubectl", "get", "cronjobs", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    integrity_jobs = [
                        item for item in data.get("items", [])
                        if any(kw in item.get("metadata", {}).get("name", "").lower()
                               for kw in ["integrity", "hash", "checksum", "model-verify"])
                    ]
                    if integrity_jobs:
                        pr.evidence.append(
                            f"Model integrity CronJobs found: "
                            f"{[j['metadata']['name'] for j in integrity_jobs]}"
                        )
                    else:
                        pr.evidence.append(
                            "No model integrity CronJob found — recommend deploying SHA256 checker"
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
                pr.evidence.append(f"CronJob check failed: {e}")

        self.result.recommendations = [
            {"text": "Mount all model volumes as readOnly in Kubernetes (readOnly: true in volumeMounts)",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Implement SHA256 integrity verification CronJob for all model files",
             "url": "https://docs.sigstore.dev/"},
            {"text": "Encrypt model files at rest using LUKS or storage class encryption",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Use signed model artifacts (e.g., Sigstore/cosign for model signing)",
             "url": "https://docs.sigstore.dev/"},
            {"text": "Restrict NFS exports to specific IPs (no_root_squash is dangerous)",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Set file permissions to 640 (owner rw, group r, no world access) on model files",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Deploy admission controller to enforce readOnly model mounts",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Implement model versioning with immutable storage backend",
             "url": "https://dvc.org/doc"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF02ModelStorage(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
