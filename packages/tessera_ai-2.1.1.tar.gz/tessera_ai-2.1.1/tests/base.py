"""
Base class for all OWASP AI Security Tests.

Every test module (MOD-01, APP-01, INF-01, DAT-01, etc.) inherits from
OWASPTestCase and implements the 3-phase methodology:
    Phase 1: Attack / Detection Simulation
    Phase 2: Quantitative Metrics
    Phase 3: Defense Validation
"""

import json
import time
import traceback
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path


def build_base_url(url: str, api_base: str = "") -> str:
    """Build a base URL that respects existing schemes and uses HTTPS for known providers."""
    if url.startswith("http://") or url.startswith("https://"):
        return f"{url.rstrip('/')}{api_base}"
    if any(h in url for h in ("openai.com", "anthropic.com", "googleapis.com", "azure.com")):
        return f"https://{url}{api_base}"
    return f"http://{url}{api_base}"


@dataclass
class Metric:
    """Single measurable result from a test phase."""
    name: str
    value: float
    threshold_pass: float
    threshold_fail: float
    unit: str = ""
    operator: str = "<"  # "<" means value < threshold_pass = PASS
    source: str = ""     # Reference for threshold (e.g. "OWASP AITG-MOD-01", URL)

    @property
    def status(self) -> str:
        if self.operator == "<":
            if self.value < self.threshold_pass:
                return "PASS"
            elif self.value > self.threshold_fail:
                return "FAIL"
            return "WARN"
        else:  # ">"
            if self.value > self.threshold_pass:
                return "PASS"
            elif self.value < self.threshold_fail:
                return "FAIL"
            return "WARN"


@dataclass
class PhaseResult:
    """Result of one phase (Attack, Measurement, Defense)."""
    phase: int
    name: str
    status: str = "NOT_RUN"
    metrics: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    duration_sec: float = 0.0
    error: str = ""


@dataclass
class TestResult:
    """Complete result of a single OWASP test case."""
    test_id: str
    test_name: str
    category: str
    owasp_ref: str
    status: str = "NOT_RUN"  # PASS / FAIL / WARN / N/A / ERROR
    phases: list = field(default_factory=list)
    tools_used: list = field(default_factory=list)
    recommendations: list = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    duration_sec: float = 0.0
    error: str = ""
    # Per-model metadata (populated when running in per-model mode)
    model_name: str = ""
    model_arch: str = ""
    model_type: str = ""   # "cv" or "llm"
    model_task: str = ""   # e.g. "detection", "classification", "code-generation"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["phases"] = [asdict(p) for p in self.phases]
        return d

    def to_json(self, path: Path):
        path.write_text(json.dumps(self.to_dict(), indent=2, default=str))


class OWASPTestCase(ABC):
    """
    Abstract base for all 32 OWASP AI test cases.

    Subclasses implement:
        phase1_attack(config) -> PhaseResult
        phase2_measure(config) -> PhaseResult
        phase3_defend(config) -> PhaseResult
    """

    # Override in subclass
    TEST_ID = "XXX-00"
    TEST_NAME = "Override Me"
    CATEGORY = "Unknown"
    OWASP_REF = "AITG-XXX-00"
    TOOLS = []  # e.g. ["ART", "Foolbox", "TextAttack"]

    def __init__(self, config: dict, target_model: dict = None):
        self.config = config
        self.target_model = target_model
        self.result = TestResult(
            test_id=self.TEST_ID,
            test_name=self.TEST_NAME,
            category=self.CATEGORY,
            owasp_ref=self.OWASP_REF,
            tools_used=self.TOOLS[:],
        )
        if target_model:
            self.result.model_name = target_model.get("name", "")
            self.result.model_arch = target_model.get("arch", "")
            self.result.model_type = target_model.get("_type", "")
            self.result.model_task = target_model.get("task", "")

    def run(self, phases: list = None) -> TestResult:
        """Execute all 3 phases (or selected phases)."""
        if phases is None:
            phases = [1, 2, 3]

        t0 = time.time()
        try:
            if 1 in phases:
                p1 = self._run_phase(1, "Attack Simulation", self.phase1_attack)
                self.result.phases.append(p1)
            if 2 in phases:
                p2 = self._run_phase(2, "Quantitative Metrics", self.phase2_measure)
                self.result.phases.append(p2)
            if 3 in phases:
                p3 = self._run_phase(3, "Defense Validation", self.phase3_defend)
                self.result.phases.append(p3)

            # Overall status = worst phase status
            statuses = [p.status for p in self.result.phases]
            if "ERROR" in statuses:
                self.result.status = "ERROR"
            elif "FAIL" in statuses:
                self.result.status = "FAIL"
            elif "WARN" in statuses:
                self.result.status = "WARN"
            elif all(s == "PASS" for s in statuses):
                self.result.status = "PASS"
            elif all(s == "N/A" for s in statuses):
                self.result.status = "N/A"
            else:
                self.result.status = "WARN"

        except Exception as e:
            self.result.status = "ERROR"
            self.result.error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"

        self.result.duration_sec = round(time.time() - t0, 2)
        return self.result

    def _run_phase(self, num: int, name: str, fn) -> PhaseResult:
        pr = PhaseResult(phase=num, name=name)
        t0 = time.time()
        try:
            pr = fn(self.config)
            pr.phase = num
            pr.name = name
            if not pr.status or pr.status == "NOT_RUN":
                # Derive from metrics
                metrics_statuses = [m.status for m in pr.metrics if isinstance(m, Metric)]
                if "FAIL" in metrics_statuses:
                    pr.status = "FAIL"
                elif "WARN" in metrics_statuses:
                    pr.status = "WARN"
                elif metrics_statuses and all(s == "PASS" for s in metrics_statuses):
                    pr.status = "PASS"
                else:
                    pr.status = "PASS"
        except ImportError as e:
            pr.status = "ERROR"
            pr.error = f"Missing dependency: {e}. Install with: pip install -r requirements.txt"
        except Exception as e:
            pr.status = "ERROR"
            pr.error = f"{type(e).__name__}: {e}"
        pr.duration_sec = round(time.time() - t0, 2)
        return pr

    @abstractmethod
    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Attack / Detection simulation."""
        ...

    @abstractmethod
    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative measurement (metrics with pass/fail thresholds)."""
        ...

    @abstractmethod
    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation."""
        ...

    def log(self, msg: str):
        prefix = self.TEST_ID
        if self.target_model:
            prefix = f"{self.TEST_ID}:{self.target_model.get('name', '')}"
        print(f"  [{prefix}] {msg}")
