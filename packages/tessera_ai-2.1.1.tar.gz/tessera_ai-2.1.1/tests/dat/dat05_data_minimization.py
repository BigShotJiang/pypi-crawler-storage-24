"""
AITG-DAT-05 — Testing for Data Minimization & Consent

3-Phase OWASP Methodology:
    Phase 1: Assess data collection scope (fields collected vs. required, consent mechanisms)
    Phase 2: Measure data minimization compliance (excess data ratio, consent coverage, retention)
    Phase 3: Validate data governance controls (purpose limitation, consent management, auto-purge)

Tools: Custom, Presidio
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md
"""

import json
import os
import subprocess

from tests.base import Metric, OWASPTestCase, PhaseResult


class DAT05DataMinimization(OWASPTestCase):
    TEST_ID = "DAT-05"
    TEST_NAME = "Testing for Data Minimization & Consent"
    CATEGORY = "AI Data Governance"
    OWASP_REF = "AITG-DAT-05"
    TOOLS = ["Custom", "Presidio"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._collection_findings = {}
        self._consent_findings = {}
        self._retention_findings = {}
        self._k8s_findings = {}

    def _get_kubectl_env(self, config: dict) -> dict:
        """Build environment dict with KUBECONFIG."""
        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if not kubeconfig:
            return {}
        env = os.environ.copy()
        env["KUBECONFIG"] = kubeconfig
        return env

    def _check_data_collection_scope(self, config: dict) -> dict:
        """Assess what data fields are collected by AI services."""
        findings = {
            "services_checked": 0,
            "services_with_excess_data": 0,
            "excess_data_fields": [],
            "pii_fields_found": [],
            "total_fields_collected": 0,
            "total_fields_required": 0,
        }

        # PII field patterns that should be minimized
        pii_patterns = [
            "email", "phone", "ssn", "social_security", "address",
            "name", "first_name", "last_name", "full_name",
            "date_of_birth", "dob", "age", "gender", "race",
            "ethnicity", "religion", "nationality", "passport",
            "driver_license", "credit_card", "bank_account",
            "ip_address", "mac_address", "device_id", "location",
            "gps", "latitude", "longitude", "face_encoding",
            "biometric", "fingerprint", "voice_print",
        ]

        # Check ConfigMaps and environment variables in AI pods
        env = self._get_kubectl_env(config)
        if env:
            try:
                result = subprocess.run(
                    ["kubectl", "get", "configmaps", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    for cm in data.get("items", []):
                        cm_name = cm.get("metadata", {}).get("name", "").lower()
                        cm_data = cm.get("data", {})

                        # Look for data collection configs
                        data_keywords = ["schema", "fields", "collection", "input", "feature"]
                        if any(kw in cm_name for kw in data_keywords):
                            findings["services_checked"] += 1
                            for key, value in cm_data.items():
                                if isinstance(value, str):
                                    value_lower = value.lower()
                                    for pattern in pii_patterns:
                                        if pattern in value_lower:
                                            findings["pii_fields_found"].append({
                                                "configmap": cm_name,
                                                "key": key,
                                                "pii_type": pattern,
                                            })

            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
                self.log(f"ConfigMap data collection check failed: {e}")

            # Check pod environment variables for data collection clues
            try:
                result = subprocess.run(
                    ["kubectl", "get", "pods", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    for pod in data.get("items", []):
                        pod_name = pod.get("metadata", {}).get("name", "")
                        namespace = pod.get("metadata", {}).get("namespace", "")
                        spec = pod.get("spec", {})

                        for container in spec.get("containers", []):
                            env_vars = container.get("env", [])
                            for ev in env_vars:
                                ev_name = ev.get("name", "").lower()
                                ev_value = str(ev.get("value", "")).lower()
                                for pattern in pii_patterns:
                                    if pattern in ev_name or pattern in ev_value:
                                        findings["pii_fields_found"].append({
                                            "pod": f"{namespace}/{pod_name}",
                                            "env_var": ev.get("name", ""),
                                            "pii_type": pattern,
                                        })

            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
                self.log(f"Pod env var check failed: {e}")

        # Assess from config file data schemas
        data_cfg = config.get("data", {})
        schemas = data_cfg.get("schemas", {})
        for service_name, schema in schemas.items():
            findings["services_checked"] += 1
            required = schema.get("required_fields", [])
            collected = schema.get("collected_fields", required)
            findings["total_fields_required"] += len(required)
            findings["total_fields_collected"] += len(collected)
            excess = set(collected) - set(required)
            if excess:
                findings["services_with_excess_data"] += 1
                findings["excess_data_fields"].extend([
                    {"service": service_name, "field": f} for f in excess
                ])

        return findings

    def _check_consent_mechanisms(self, config: dict) -> dict:
        """Check if proper consent collection and management exists."""
        findings = {
            "consent_endpoints_found": 0,
            "consent_storage_found": False,
            "purpose_limitation_defined": False,
            "consent_withdrawal_available": False,
            "k8s_available": False,
        }

        env = self._get_kubectl_env(config)
        if not env:
            return findings

        try:
            # Check for consent-related services or endpoints
            result = subprocess.run(
                ["kubectl", "get", "services", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                findings["k8s_available"] = True
                data = json.loads(result.stdout)
                for svc in data.get("items", []):
                    svc_name = svc.get("metadata", {}).get("name", "").lower()
                    consent_keywords = [
                        "consent", "privacy", "gdpr", "compliance",
                        "data-subject", "data-governance",
                    ]
                    if any(kw in svc_name for kw in consent_keywords):
                        findings["consent_endpoints_found"] += 1

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Consent endpoint check failed: {e}")

        # Check ConfigMaps for consent/privacy policies
        try:
            result = subprocess.run(
                ["kubectl", "get", "configmaps", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for cm in data.get("items", []):
                    cm_data = cm.get("data", {})
                    for key, value in cm_data.items():
                        if isinstance(value, str):
                            val_lower = value.lower()
                            if "consent" in val_lower or "privacy" in val_lower:
                                findings["consent_storage_found"] = True
                            if "purpose" in val_lower and "limitation" in val_lower:
                                findings["purpose_limitation_defined"] = True
                            if "withdraw" in val_lower or "revoke" in val_lower:
                                findings["consent_withdrawal_available"] = True

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"Consent configmap check failed: {e}")

        return findings

    def _check_data_retention(self, config: dict) -> dict:
        """Check data retention policies and auto-purge configurations."""
        findings = {
            "retention_policies_found": 0,
            "auto_purge_configured": False,
            "databases_checked": 0,
            "databases_with_ttl": 0,
        }

        env = self._get_kubectl_env(config)
        if not env:
            return findings

        # Check for CronJobs that handle data purge
        try:
            result = subprocess.run(
                ["kubectl", "get", "cronjobs", "--all-namespaces", "-o", "json"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                for cj in data.get("items", []):
                    cj_name = cj.get("metadata", {}).get("name", "").lower()
                    purge_keywords = [
                        "purge", "cleanup", "retention", "delete-old",
                        "expire", "ttl", "data-lifecycle",
                    ]
                    if any(kw in cj_name for kw in purge_keywords):
                        findings["retention_policies_found"] += 1
                        findings["auto_purge_configured"] = True

        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            self.log(f"CronJob retention check failed: {e}")

        # Check databases in config for TTL settings
        db_cfg = config.get("databases", {})
        for db_name, db_settings in db_cfg.items():
            findings["databases_checked"] += 1
            if db_settings.get("ttl") or db_settings.get("retention_days"):
                findings["databases_with_ttl"] += 1

        return findings

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Assess data collection scope — fields collected vs. required,
        PII exposure, consent mechanisms."""
        pr = PhaseResult(phase=1, name="Data Minimization Assessment")

        # Step 1: Check data collection scope
        self.log("Assessing data collection scope...")
        self._collection_findings = self._check_data_collection_scope(config)

        pr.evidence.append(
            f"Services checked: {self._collection_findings['services_checked']}"
        )

        pii_found = self._collection_findings.get("pii_fields_found", [])
        if pii_found:
            unique_types = set(f["pii_type"] for f in pii_found)
            pr.evidence.append(
                f"FINDING: {len(pii_found)} PII field references found "
                f"({len(unique_types)} unique types: {', '.join(sorted(unique_types))})"
            )
            for finding in pii_found[:5]:
                location = finding.get("configmap") or finding.get("pod", "")
                pr.evidence.append(
                    f"  - {location}: {finding.get('pii_type', '')}"
                )
            if len(pii_found) > 5:
                pr.evidence.append(f"  ... and {len(pii_found) - 5} more")
        else:
            pr.evidence.append("No PII field references found in configs (or k8s unavailable)")

        excess = self._collection_findings.get("excess_data_fields", [])
        if excess:
            pr.evidence.append(
                f"FINDING: {len(excess)} excess data fields collected beyond requirements"
            )
            for f in excess[:5]:
                pr.evidence.append(f"  - {f['service']}: excess field '{f['field']}'")
        else:
            pr.evidence.append("No excess data fields detected in configured schemas")

        # Step 2: Check consent mechanisms
        self.log("Checking consent mechanisms...")
        self._consent_findings = self._check_consent_mechanisms(config)

        if self._consent_findings.get("k8s_available"):
            pr.evidence.append(
                f"Consent endpoints: {self._consent_findings['consent_endpoints_found']} found"
            )
            pr.evidence.append(
                f"Consent storage: {'found' if self._consent_findings['consent_storage_found'] else 'NOT FOUND'}"
            )
            pr.evidence.append(
                f"Purpose limitation: {'defined' if self._consent_findings['purpose_limitation_defined'] else 'NOT DEFINED'}"
            )
            pr.evidence.append(
                f"Consent withdrawal: {'available' if self._consent_findings['consent_withdrawal_available'] else 'NOT AVAILABLE'}"
            )
        else:
            pr.evidence.append("Kubernetes: not available for consent mechanism check")

        # Step 3: Check data retention
        self.log("Checking data retention policies...")
        self._retention_findings = self._check_data_retention(config)

        pr.evidence.append(
            f"Retention policies: {self._retention_findings['retention_policies_found']} found"
        )
        pr.evidence.append(
            f"Auto-purge: {'configured' if self._retention_findings['auto_purge_configured'] else 'NOT CONFIGURED'}"
        )
        if self._retention_findings["databases_checked"] > 0:
            pr.evidence.append(
                f"Database TTL: {self._retention_findings['databases_with_ttl']}/"
                f"{self._retention_findings['databases_checked']} databases have TTL configured"
            )

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Measure data minimization compliance — excess data ratio,
        consent coverage, retention policy compliance."""
        pr = PhaseResult(phase=2, name="Data Minimization Metrics")

        # Metric 1: PII exposure count
        pii_count = len(self._collection_findings.get("pii_fields_found", []))
        pr.metrics.append(Metric(
            name="PII field references in configs",
            value=pii_count,
            threshold_pass=5,
            threshold_fail=15,
            unit="count",
            operator="<",
            source="OWASP AITG-DAT-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md",
        ))

        # Metric 2: Excess data field ratio
        total_collected = self._collection_findings.get("total_fields_collected", 0)
        total_required = self._collection_findings.get("total_fields_required", 0)
        if total_required > 0:
            excess_ratio = (total_collected - total_required) / total_required
        else:
            excess_ratio = 0.0 if total_collected == 0 else 1.0

        pr.metrics.append(Metric(
            name="Excess data collection ratio",
            value=round(excess_ratio, 4),
            threshold_pass=0.10,
            threshold_fail=0.50,
            unit="ratio",
            operator="<",
            source="OWASP AITG-DAT-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md",
        ))
        pr.evidence.append(
            f"Data scope: {total_collected} fields collected vs {total_required} required "
            f"(excess ratio: {excess_ratio:.2%})"
        )

        # Metric 3: Consent mechanism score (0-4)
        consent_score = 0
        if self._consent_findings.get("consent_endpoints_found", 0) > 0:
            consent_score += 1
        if self._consent_findings.get("consent_storage_found"):
            consent_score += 1
        if self._consent_findings.get("purpose_limitation_defined"):
            consent_score += 1
        if self._consent_findings.get("consent_withdrawal_available"):
            consent_score += 1

        pr.metrics.append(Metric(
            name="Consent mechanism completeness (0-4)",
            value=consent_score,
            threshold_pass=3,
            threshold_fail=1,
            unit="score",
            operator=">",
            source="OWASP AITG-DAT-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md",
        ))
        pr.evidence.append(
            f"Consent score: {consent_score}/4 "
            f"(endpoints={self._consent_findings.get('consent_endpoints_found', 0) > 0}, "
            f"storage={self._consent_findings.get('consent_storage_found', False)}, "
            f"purpose_limit={self._consent_findings.get('purpose_limitation_defined', False)}, "
            f"withdrawal={self._consent_findings.get('consent_withdrawal_available', False)})"
        )

        # Metric 4: Data retention policy coverage
        db_checked = self._retention_findings.get("databases_checked", 0)
        db_with_ttl = self._retention_findings.get("databases_with_ttl", 0)
        retention_rate = db_with_ttl / db_checked if db_checked > 0 else 0.0

        pr.metrics.append(Metric(
            name="Database retention policy coverage",
            value=round(retention_rate, 4),
            threshold_pass=0.80,
            threshold_fail=0.30,
            unit="ratio",
            operator=">",
            source="OWASP AITG-DAT-05 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md",
        ))
        pr.evidence.append(
            f"Retention coverage: {db_with_ttl}/{db_checked} databases "
            f"({retention_rate:.0%})"
        )

        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Validate data governance controls — purpose limitation,
        consent management, auto-purge policies."""
        pr = PhaseResult(phase=3, name="Data Minimization Defense Validation")

        # Defense 1: Data minimization by design
        pr.evidence.append(
            "Data minimization by design: review all AI service input schemas and "
            "remove fields not strictly required for the model's task. Apply "
            "GDPR Article 5(1)(c) — data must be adequate, relevant, and limited "
            "to what is necessary for the purpose."
        )

        # Defense 2: Purpose limitation
        pr.evidence.append(
            "Purpose limitation: define and document the specific purpose for each "
            "data field collected. Implement technical controls to prevent data "
            "from being used beyond its stated purpose. Example: training data "
            "collected for model X should not be accessible by model Y."
        )

        # Defense 3: Consent management
        pr.evidence.append(
            "Consent management: implement a consent management platform (CMP) that "
            "tracks per-user, per-purpose consent. Ensure consent is: freely given, "
            "specific, informed, unambiguous (GDPR Art. 7). Provide easy consent "
            "withdrawal mechanism with <72h processing SLA."
        )

        # Defense 4: Automated data purge
        pr.evidence.append(
            "Automated data purge: configure TTL (time-to-live) on all databases "
            "storing AI training data and inference logs. MongoDB: use TTL indexes. "
            "PostgreSQL: use pg_cron with DELETE queries. Elasticsearch: use ILM policies. "
            "Default retention: 90 days for inference logs, 1 year for training data."
        )

        # Defense 5: PII detection and anonymization
        try:
            from presidio_analyzer import AnalyzerEngine  # noqa: F401
            pr.evidence.append(
                "Presidio Analyzer available — deploy as PII detection pipeline "
                "on all data ingestion paths. Auto-anonymize or redact PII before "
                "storing in training datasets."
            )
        except ImportError:
            pr.evidence.append(
                "Presidio Analyzer: not installed (pip install presidio-analyzer). "
                "Recommended for automated PII detection and anonymization."
            )
        except Exception as e:
            pr.evidence.append(f"Presidio Analyzer: ERROR — {e}")

        # Defense 6: Data access audit
        pr.evidence.append(
            "Data access audit: enable audit logging on all databases used by AI services. "
            "Log WHO accessed WHAT data WHEN and WHY. MongoDB: enable auditLog. "
            "PostgreSQL: use pgAudit extension. Review logs weekly for "
            "unauthorized or excessive data access."
        )

        self.result.recommendations = [
            {"text": "Audit all AI service input schemas — remove fields not strictly required for model task",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md"},
            {"text": "Implement purpose limitation: document and enforce specific purposes for each data field",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md"},
            {"text": "Deploy consent management platform (CMP) with per-user, per-purpose consent tracking",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md"},
            {"text": "Configure TTL/auto-purge on all databases: 90 days inference logs, 1 year training data",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md"},
            {"text": "Deploy Presidio for automated PII detection and anonymization on data ingestion pipelines",
             "url": "https://microsoft.github.io/presidio/"},
            {"text": "Enable database audit logging (pgAudit for PostgreSQL, auditLog for MongoDB)",
             "url": "https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-05_Testing_for_Data_Minimization.md"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = DAT05DataMinimization(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
