"""
AITG-DAT-03 — Testing for Data Lineage & Provenance

3-Phase OWASP Methodology:
    Phase 1: Check data version control (DVC), experiment tracking (MLflow),
             model metadata, and repository structure
    Phase 2: Lineage coverage and reproducibility metrics
    Phase 3: Defense validation (DVC, MLflow availability, best practices)

Tools: DVC, MLflow, Custom
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-03_Testing_for_Dataset_Diversity_and_Coverage.md
"""

from pathlib import Path

from tests.base import Metric, OWASPTestCase, PhaseResult


class DAT03DataLineage(OWASPTestCase):
    TEST_ID = "DAT-03"
    TEST_NAME = "Testing for Data Lineage & Provenance"
    CATEGORY = "AI Data Governance"
    OWASP_REF = "AITG-DAT-03"
    TOOLS = ["DVC", "MLflow", "Custom"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._dvc_status = {}
        self._mlflow_status = {}
        self._model_metadata = {}
        self._repo_structure = {}

    def _check_dvc(self, config: dict) -> dict:
        """Check for DVC initialization and tracked files."""
        status = {
            "initialized": False,
            "tracked_files": 0,
            "remote_configured": False,
            "pipelines": 0,
        }

        project_root = Path(config.get("project_root", "."))

        # Check .dvc directory
        dvc_dir = project_root / ".dvc"
        if dvc_dir.is_dir():
            status["initialized"] = True

            # Check DVC config for remote
            dvc_config = dvc_dir / "config"
            if dvc_config.exists():
                content = dvc_config.read_text(errors="replace")
                if "remote" in content.lower():
                    status["remote_configured"] = True

        # Count .dvc files (tracked datasets)
        dvc_files = list(project_root.rglob("*.dvc"))
        status["tracked_files"] = len(dvc_files)

        # Check for DVC pipelines (dvc.yaml)
        pipeline_files = list(project_root.rglob("dvc.yaml"))
        status["pipelines"] = len(pipeline_files)

        return status

    def _check_mlflow(self, config: dict) -> dict:
        """Check for MLflow tracking directory and experiment metadata."""
        status = {
            "tracking_dir_exists": False,
            "experiments": 0,
            "runs": 0,
            "tracking_uri_configured": False,
        }

        project_root = Path(config.get("project_root", "."))

        # Check mlruns directory
        mlruns_dir = project_root / "mlruns"
        if mlruns_dir.is_dir():
            status["tracking_dir_exists"] = True
            # Count experiment directories (skip .trash)
            experiments = [
                d for d in mlruns_dir.iterdir()
                if d.is_dir() and d.name != ".trash"
            ]
            status["experiments"] = len(experiments)
            # Count runs across all experiments
            for exp_dir in experiments:
                runs = [
                    d for d in exp_dir.iterdir()
                    if d.is_dir() and (d / "meta.yaml").exists()
                ]
                status["runs"] += len(runs)

        # Check MLflow config in project config
        mlflow_cfg = config.get("mlflow", {})
        if mlflow_cfg.get("tracking_uri"):
            status["tracking_uri_configured"] = True

        return status

    def _check_model_metadata(self, config: dict) -> dict:
        """Check if model files have associated metadata."""
        metadata = {
            "models_found": 0,
            "with_metadata": 0,
            "metadata_fields": {},
        }

        project_root = Path(config.get("project_root", "."))

        # Scan for model files
        model_extensions = ("*.pt", "*.pth", "*.onnx", "*.h5", "*.pkl",
                            "*.joblib", "*.safetensors", "*.bin")
        model_files = []
        for ext in model_extensions:
            model_files.extend(project_root.rglob(ext))

        metadata["models_found"] = len(model_files)

        # Check for associated metadata files
        metadata_patterns = [
            "model_card.*", "MODEL_CARD.*", "metadata.*",
            "config.json", "config.yaml", "training_args.*",
            "hyperparameters.*", "params.*",
        ]

        for model_file in model_files:
            parent = model_file.parent
            has_meta = False
            fields = set()
            for pattern in metadata_patterns:
                meta_files = list(parent.glob(pattern))
                if meta_files:
                    has_meta = True
                    for mf in meta_files:
                        fields.add(mf.name)
            if has_meta:
                metadata["with_metadata"] += 1
                for field in fields:
                    metadata["metadata_fields"][field] = (
                        metadata["metadata_fields"].get(field, 0) + 1
                    )

        # Also check config-listed models
        models_cfg = config.get("models", {})
        for server_type in ("triton", "vllm", "custom"):
            server_cfg = models_cfg.get(server_type, {})
            # custom is a list of models directly; triton/vllm are dicts with "models" key
            if isinstance(server_cfg, list):
                model_list = server_cfg
            elif isinstance(server_cfg, dict):
                model_list = server_cfg.get("models", [])
            else:
                model_list = []
            if isinstance(model_list, list):
                for m in model_list:
                    if isinstance(m, dict):
                        has_fields = []
                        for field in ("training_date", "dataset_version",
                                      "hyperparameters", "version", "commit"):
                            if field in m:
                                has_fields.append(field)
                        if has_fields:
                            metadata["with_metadata"] += 1
                            for f in has_fields:
                                metadata["metadata_fields"][f] = (
                                    metadata["metadata_fields"].get(f, 0) + 1
                                )
                        metadata["models_found"] += 1

        return metadata

    def _check_repo_structure(self, config: dict) -> dict:
        """Verify repository structure matches ML best practices."""
        project_root = Path(config.get("project_root", "."))
        best_practice_dirs = {
            "data": False,
            "models": False,
            "notebooks": False,
            "src": False,
            "tests": False,
            "configs": False,
        }
        best_practice_files = {
            "requirements.txt": False,
            "Makefile": False,
            "Dockerfile": False,
            ".gitignore": False,
        }

        for dir_name in best_practice_dirs:
            candidates = [dir_name, dir_name.replace("s", ""), dir_name + "s"]
            for c in candidates:
                if (project_root / c).is_dir():
                    best_practice_dirs[dir_name] = True
                    break

        for file_name in best_practice_files:
            if (project_root / file_name).exists():
                best_practice_files[file_name] = True

        return {
            "directories": best_practice_dirs,
            "files": best_practice_files,
        }

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Assess data lineage, versioning, and provenance controls."""
        pr = PhaseResult(phase=1, name="Data Lineage & Provenance Assessment")

        # Check DVC
        self._dvc_status = self._check_dvc(config)
        pr.evidence.append(
            f"DVC: initialized={self._dvc_status['initialized']}, "
            f"tracked_files={self._dvc_status['tracked_files']}, "
            f"remote={self._dvc_status['remote_configured']}, "
            f"pipelines={self._dvc_status['pipelines']}"
        )

        # Check MLflow
        self._mlflow_status = self._check_mlflow(config)
        pr.evidence.append(
            f"MLflow: tracking_dir={self._mlflow_status['tracking_dir_exists']}, "
            f"experiments={self._mlflow_status['experiments']}, "
            f"runs={self._mlflow_status['runs']}, "
            f"uri_configured={self._mlflow_status['tracking_uri_configured']}"
        )

        # Check model metadata
        self._model_metadata = self._check_model_metadata(config)
        pr.evidence.append(
            f"Model metadata: models_found={self._model_metadata['models_found']}, "
            f"with_metadata={self._model_metadata['with_metadata']}"
        )
        if self._model_metadata["metadata_fields"]:
            pr.evidence.append(
                f"  Metadata files found: {self._model_metadata['metadata_fields']}"
            )

        # Check repository structure
        self._repo_structure = self._check_repo_structure(config)
        dirs_present = sum(1 for v in self._repo_structure["directories"].values() if v)
        dirs_total = len(self._repo_structure["directories"])
        files_present = sum(1 for v in self._repo_structure["files"].values() if v)
        files_total = len(self._repo_structure["files"])
        pr.evidence.append(
            f"Repository structure: {dirs_present}/{dirs_total} recommended dirs, "
            f"{files_present}/{files_total} recommended files"
        )
        for name, present in self._repo_structure["directories"].items():
            if not present:
                pr.evidence.append(f"  Missing directory: {name}/")
        for name, present in self._repo_structure["files"].items():
            if not present:
                pr.evidence.append(f"  Missing file: {name}")

        # Check data file integrity (hash sampling)
        project_root = Path(config.get("project_root", "."))
        data_files = list(project_root.rglob("*.dvc"))
        hashed_count = 0
        for dvc_file in data_files[:10]:
            try:
                content = dvc_file.read_text(errors="replace")
                if "md5" in content or "sha256" in content:
                    hashed_count += 1
            except Exception:
                pass
        if data_files:
            pr.evidence.append(
                f"DVC file integrity: {hashed_count}/{min(len(data_files), 10)} "
                f"files have hash checksums"
            )

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Data lineage and reproducibility metrics."""
        pr = PhaseResult(phase=2, name="Lineage & Reproducibility Metrics")

        # Metric 1: DVC tracked files count
        dvc_tracked = self._dvc_status.get("tracked_files", 0)
        pr.metrics.append(Metric(
            name="DVC tracked files",
            value=float(dvc_tracked),
            threshold_pass=1.0,
            threshold_fail=0.0,
            unit="files",
            operator=">",
            source="OWASP AITG-DAT-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-03_Testing_for_Dataset_Diversity_and_Coverage.md",
        ))

        # Metric 2: Versioned datasets count
        versioned_count = dvc_tracked + self._mlflow_status.get("runs", 0)
        pr.metrics.append(Metric(
            name="Versioned datasets/experiments",
            value=float(versioned_count),
            threshold_pass=1.0,
            threshold_fail=0.0,
            unit="count",
            operator=">",
            source="OWASP AITG-DAT-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-03_Testing_for_Dataset_Diversity_and_Coverage.md",
        ))

        # Metric 3: Model metadata completeness score
        models_found = self._model_metadata.get("models_found", 0)
        with_metadata = self._model_metadata.get("with_metadata", 0)
        if models_found > 0:
            metadata_completeness = with_metadata / models_found
        else:
            metadata_completeness = 0.0
        pr.metrics.append(Metric(
            name="Model metadata completeness",
            value=round(metadata_completeness, 4),
            threshold_pass=0.80,
            threshold_fail=0.25,
            unit="ratio",
            operator=">",
            source="OWASP AITG-DAT-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-03_Testing_for_Dataset_Diversity_and_Coverage.md",
        ))

        # Metric 4: Reproducibility score
        # Based on: DVC initialized + MLflow tracking + pipeline defined + remote configured
        repro_factors = [
            self._dvc_status.get("initialized", False),
            self._dvc_status.get("remote_configured", False),
            self._dvc_status.get("pipelines", 0) > 0,
            self._mlflow_status.get("tracking_dir_exists", False) or
            self._mlflow_status.get("tracking_uri_configured", False),
            metadata_completeness > 0.5,
        ]
        reproducibility_score = sum(1 for f in repro_factors if f) / len(repro_factors)
        pr.metrics.append(Metric(
            name="Reproducibility score",
            value=round(reproducibility_score, 4),
            threshold_pass=0.60,
            threshold_fail=0.20,
            unit="ratio",
            operator=">",
            source="OWASP AITG-DAT-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-DAT-03_Testing_for_Dataset_Diversity_and_Coverage.md",
        ))

        pr.evidence.append(
            f"Summary: dvc_files={dvc_tracked}, versioned={versioned_count}, "
            f"metadata_completeness={metadata_completeness:.2%}, "
            f"reproducibility={reproducibility_score:.2%}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — DVC, MLflow, and lineage best practices."""
        pr = PhaseResult(phase=3, name="Lineage Defense Validation")

        # Defense 1: Check DVC CLI availability
        try:
            import subprocess
            result = subprocess.run(
                ["dvc", "version"], capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                version = result.stdout.strip().split("\n")[0]
                pr.evidence.append(f"DVC available: {version}")
            else:
                pr.evidence.append("DVC: installed but returned error")
        except FileNotFoundError:
            pr.evidence.append("DVC: not installed (pip install dvc)")
        except Exception as e:
            pr.evidence.append(f"DVC check: ERROR -- {e}")

        # Defense 2: Check MLflow availability
        try:
            import mlflow
            pr.evidence.append(f"MLflow available: version {mlflow.__version__}")
        except ImportError:
            pr.evidence.append("MLflow: not installed (pip install mlflow)")

        # Defense 3: Data integrity hashing recommendation
        pr.evidence.append(
            "Data integrity: hash all training data files with SHA-256 and store "
            "checksums alongside data. Use DVC for automatic hash tracking."
        )

        # Defense 4: Model card template
        pr.evidence.append(
            "Model card: each model should have metadata documenting — "
            "training date, dataset version, hyperparameters, performance metrics, "
            "intended use, limitations, and ethical considerations"
        )

        self.result.recommendations = [
            {"text": "Use DVC for all training data versioning (dvc init, dvc add, dvc push)",
             "url": "https://dvc.org/doc"},
            {"text": "Track all experiments with MLflow (mlflow.log_params, mlflow.log_metrics)",
             "url": "https://mlflow.org/docs/latest/"},
            {"text": "Maintain model cards with training metadata for every deployed model",
             "url": "https://mlflow.org/docs/latest/"},
            {"text": "Implement CI/CD for model training pipelines (DVC pipelines + GitHub Actions)",
             "url": "https://dvc.org/doc"},
            {"text": "Hash all data files with SHA-256 for integrity verification",
             "url": "https://docs.sigstore.dev/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution --------------------------------------------------
if __name__ == "__main__":
    import json
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = DAT03DataLineage(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
