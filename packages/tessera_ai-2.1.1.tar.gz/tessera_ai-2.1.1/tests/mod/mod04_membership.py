"""
AITG-MOD-04 — Testing for Membership Inference Attacks

3-Phase OWASP Methodology:
    Phase 1: MIA attack simulation (BlackBox, RuleBased, LabelOnly, Shadow)
    Phase 2: Privacy metrics (MIA accuracy, AUC, precision/recall, membership advantage)
    Phase 3: Defense validation (Opacus DP-SGD, regularisation, output perturbation)

Tools: ART (mandatory), ML Privacy Meter, TensorFlow Privacy, Opacus
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-04_Testing_for_Membership_Inference.md
"""

import numpy as np

from tests.base import Metric, OWASPTestCase, PhaseResult


class MOD04Membership(OWASPTestCase):
    TEST_ID = "MOD-04"
    TEST_NAME = "Testing for Membership Inference Attacks"
    CATEGORY = "AI Model Testing"
    OWASP_REF = "AITG-MOD-04"
    TOOLS = ["ART", "ML Privacy Meter", "TensorFlow Privacy", "Opacus"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._model = None
        self._x_train = None
        self._y_train = None
        self._x_test = None
        self._y_test = None
        self._attack_results = {}

    def _build_target(self):
        """Build a target model for MIA testing."""
        from sklearn.neural_network import MLPClassifier

        n_features = 50
        n_classes = 5
        if self.target_model:
            shape = self.target_model.get("input_shape", [])
            if shape:
                import operator
                from functools import reduce
                n_features = min(reduce(operator.mul, shape, 1), 500)
            n_classes = self.target_model.get("num_classes", n_classes)
        n_train = 500
        n_test = 200

        np.random.seed(42)
        self._x_train = np.random.rand(n_train, n_features).astype(np.float32)
        self._y_train = np.random.randint(0, n_classes, n_train)
        self._x_test = np.random.rand(n_test, n_features).astype(np.float32)
        self._y_test = np.random.randint(0, n_classes, n_test)

        self._model = MLPClassifier(hidden_layer_sizes=(64, 32),
                                     max_iter=300, random_state=42)
        self._model.fit(self._x_train, self._y_train)
        acc = self._model.score(self._x_test, self._y_test)
        self.log(f"Target model accuracy: {acc:.2%}")

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Run multiple MIA attack variants."""
        from art.attacks.inference.membership_inference import (
            LabelOnlyDecisionBoundary,
            MembershipInferenceBlackBox,
            MembershipInferenceBlackBoxRuleBased,
        )
        from art.estimators.classification import SklearnClassifier

        pr = PhaseResult(phase=1, name="MIA Attack Simulation")
        self._build_target()

        art_clf = SklearnClassifier(model=self._model)
        attack_types = config.get("params", {}).get("membership", {}).get(
            "attack_types", ["black_box", "rule_based", "label_only"])

        # ── BlackBox MIA ──
        if "black_box" in attack_types:
            try:
                self.log("Running BlackBox MIA...")
                attack = MembershipInferenceBlackBox(art_clf, attack_model_type="nn")
                attack.fit(
                    self._x_train[:200], self._y_train[:200],
                    self._x_test[:200], self._y_test[:200],
                )

                # Infer membership: members=train, non-members=test
                inferred_train = attack.infer(self._x_train[:200], self._y_train[:200])
                inferred_test = attack.infer(self._x_test[:200], self._y_test[:200])

                tp = np.sum(inferred_train == 1)
                fp = np.sum(inferred_test == 1)
                tn = np.sum(inferred_test == 0)
                fn = np.sum(inferred_train == 0)

                accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0
                advantage = abs(accuracy - 0.5) * 2  # membership advantage

                self._attack_results["black_box"] = {
                    "accuracy": accuracy, "precision": precision,
                    "recall": recall, "advantage": advantage,
                }
                pr.evidence.append(
                    f"BlackBox MIA: acc={accuracy:.2%}, prec={precision:.2%}, "
                    f"recall={recall:.2%}, advantage={advantage:.2%}"
                )
            except Exception as e:
                pr.evidence.append(f"BlackBox MIA: ERROR — {e}")

        # ── RuleBased MIA ──
        if "rule_based" in attack_types:
            try:
                self.log("Running RuleBased MIA...")
                attack_rb = MembershipInferenceBlackBoxRuleBased(art_clf)

                inferred_train = attack_rb.infer(self._x_train[:200], self._y_train[:200])
                inferred_test = attack_rb.infer(self._x_test[:200], self._y_test[:200])

                tp = np.sum(inferred_train == 1)
                fp = np.sum(inferred_test == 1)
                tn = np.sum(inferred_test == 0)
                fn = np.sum(inferred_train == 0)
                accuracy = (tp + tn) / (tp + tn + fp + fn)
                advantage = abs(accuracy - 0.5) * 2

                self._attack_results["rule_based"] = {
                    "accuracy": accuracy, "advantage": advantage,
                }
                pr.evidence.append(
                    f"RuleBased MIA: acc={accuracy:.2%}, advantage={advantage:.2%}"
                )
            except Exception as e:
                pr.evidence.append(f"RuleBased MIA: ERROR — {e}")

        # ── LabelOnly Decision Boundary ──
        if "label_only" in attack_types:
            try:
                self.log("Running LabelOnly MIA...")
                attack_lo = LabelOnlyDecisionBoundary(art_clf)
                attack_lo.calibrate_distance_threshold(
                    self._x_train[:100], self._y_train[:100],
                    self._x_test[:100], self._y_test[:100],
                )

                inferred_train = attack_lo.infer(self._x_train[:100], self._y_train[:100])
                inferred_test = attack_lo.infer(self._x_test[:100], self._y_test[:100])

                tp = np.sum(inferred_train == 1)
                fp = np.sum(inferred_test == 1)
                tn = np.sum(inferred_test == 0)
                fn = np.sum(inferred_train == 0)
                accuracy = (tp + tn) / (tp + tn + fp + fn)

                self._attack_results["label_only"] = {"accuracy": accuracy}
                pr.evidence.append(f"LabelOnly MIA: acc={accuracy:.2%}")
            except Exception as e:
                pr.evidence.append(f"LabelOnly MIA: ERROR — {e}")

        # ── Shadow Model attack (ML Privacy Meter style) ──
        try:
            self.log("Running Shadow Model MIA...")
            from sklearn.neural_network import MLPClassifier as MLP
            shadow = MLP(hidden_layer_sizes=(64, 32), max_iter=300, random_state=99)
            # Train shadow on different split
            np.random.seed(99)
            x_shadow = np.random.rand(500, self._x_train.shape[1]).astype(np.float32)
            y_shadow = np.random.randint(0, 5, 500)
            shadow.fit(x_shadow, y_shadow)

            # Compare confidence distributions
            conf_in = np.max(self._model.predict_proba(self._x_train[:200]), axis=1)
            conf_out = np.max(self._model.predict_proba(self._x_test[:200]), axis=1)
            conf_gap = np.mean(conf_in) - np.mean(conf_out)

            self._attack_results["shadow"] = {"confidence_gap": float(conf_gap)}
            pr.evidence.append(
                f"Shadow Model: mean_conf_in={np.mean(conf_in):.4f}, "
                f"mean_conf_out={np.mean(conf_out):.4f}, gap={conf_gap:.4f}"
            )
        except Exception as e:
            pr.evidence.append(f"Shadow Model MIA: ERROR — {e}")

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Privacy leakage quantification."""
        pr = PhaseResult(phase=2, name="Privacy Leakage Metrics")

        if not self._attack_results:
            pr.status = "N/A"
            return pr

        thresholds = config.get("params", {}).get("membership", {})
        acc_threshold = thresholds.get("accuracy_threshold", 0.55)

        # Worst-case MIA accuracy across all attacks
        accuracies = [r.get("accuracy", 0) for r in self._attack_results.values()
                      if "accuracy" in r]
        worst_acc = max(accuracies) if accuracies else 0.0

        pr.metrics.append(Metric(
            name="Worst-case MIA accuracy",
            value=round(worst_acc, 4),
            threshold_pass=acc_threshold,
            threshold_fail=0.70,
            unit="%",
            operator="<",
            source="OWASP AITG-MOD-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-04_Testing_for_Membership_Inference.md",
        ))

        # Membership advantage (should be near 0 for good privacy)
        advantages = [r.get("advantage", 0) for r in self._attack_results.values()
                      if "advantage" in r]
        worst_adv = max(advantages) if advantages else 0.0
        pr.metrics.append(Metric(
            name="Membership advantage",
            value=round(worst_adv, 4),
            threshold_pass=0.10,
            threshold_fail=0.40,
            unit="%",
            operator="<",
            source="OWASP AITG-MOD-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-04_Testing_for_Membership_Inference.md",
        ))

        # AUC via sklearn
        try:
            from sklearn.metrics import roc_auc_score
            # Compute AUC for BlackBox if available
            if "black_box" in self._attack_results:
                conf_in = np.max(self._model.predict_proba(self._x_train[:200]), axis=1)
                conf_out = np.max(self._model.predict_proba(self._x_test[:200]), axis=1)
                y_true = np.concatenate([np.ones(len(conf_in)), np.zeros(len(conf_out))])
                y_scores = np.concatenate([conf_in, conf_out])
                auc = roc_auc_score(y_true, y_scores)
                pr.metrics.append(Metric(
                    name="MIA AUC-ROC",
                    value=round(auc, 4),
                    threshold_pass=0.55,
                    threshold_fail=0.75,
                    operator="<",
                    source="OWASP AITG-MOD-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-04_Testing_for_Membership_Inference.md",
                ))
                pr.evidence.append(f"MIA AUC-ROC: {auc:.4f}")
        except Exception as e:
            pr.evidence.append(f"AUC computation: ERROR — {e}")

        # Confidence gap (from shadow model)
        if "shadow" in self._attack_results:
            gap = self._attack_results["shadow"]["confidence_gap"]
            pr.metrics.append(Metric(
                name="Confidence gap (in vs out)",
                value=round(abs(gap), 4),
                threshold_pass=0.05,
                threshold_fail=0.15,
                operator="<",
                source="OWASP AITG-MOD-04 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-04_Testing_for_Membership_Inference.md",
            ))

        pr.evidence.append(
            f"Worst MIA acc={worst_acc:.2%}, advantage={worst_adv:.2%}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Privacy defense validation."""
        pr = PhaseResult(phase=3, name="Privacy Defense Validation")

        # Defense 1: L2 Regularization
        try:
            from sklearn.neural_network import MLPClassifier
            self.log("Testing L2 regularization defense...")
            reg_model = MLPClassifier(hidden_layer_sizes=(64, 32),
                                       max_iter=300, random_state=42,
                                       alpha=1.0)  # Strong L2
            reg_model.fit(self._x_train, self._y_train)

            conf_in = np.max(reg_model.predict_proba(self._x_train[:200]), axis=1)
            conf_out = np.max(reg_model.predict_proba(self._x_test[:200]), axis=1)
            gap_reg = abs(np.mean(conf_in) - np.mean(conf_out))

            original_gap = abs(self._attack_results.get("shadow", {}).get(
                "confidence_gap", 0))
            reduction = (original_gap - gap_reg) / original_gap if original_gap > 0 else 0

            pr.evidence.append(
                f"L2 regularization: gap reduced from {original_gap:.4f} to "
                f"{gap_reg:.4f} ({reduction:.0%} reduction)"
            )
        except Exception as e:
            pr.evidence.append(f"L2 regularization defense: ERROR — {e}")

        # Defense 2: Output perturbation (add noise to logits)
        try:
            self.log("Testing output perturbation defense...")
            probs = self._model.predict_proba(self._x_train[:200])
            # Add Laplace noise
            noisy_probs = probs + np.random.laplace(0, 0.05, probs.shape)
            noisy_probs = np.clip(noisy_probs, 0, 1)
            noisy_probs = noisy_probs / noisy_probs.sum(axis=1, keepdims=True)

            conf_noisy = np.max(noisy_probs, axis=1)
            conf_original = np.max(probs, axis=1)
            noise_reduction = np.mean(conf_original) - np.mean(conf_noisy)

            pr.evidence.append(
                f"Output perturbation (Laplace σ=0.05): mean confidence reduced by "
                f"{noise_reduction:.4f}"
            )
        except Exception as e:
            pr.evidence.append(f"Output perturbation: ERROR — {e}")

        # Defense 3: Opacus DP-SGD (documented, needs PyTorch model)
        pr.evidence.append(
            "Opacus DP-SGD: Apply differential privacy during training "
            "(epsilon=1.0, delta=1e-5, max_grad_norm=1.0). "
            "Requires PyTorch model — integrate via `opacus.PrivacyEngine`."
        )

        # Defense 4: ML Privacy Meter audit
        pr.evidence.append(
            "ML Privacy Meter: Run population/reference metric audits to "
            "quantify privacy leakage at sample level. "
            "Install: pip install ml-privacy-meter"
        )

        self.result.recommendations = [
            {"text": "Train with Opacus DP-SGD (epsilon <= 10, delta = 1/N)",
             "url": "https://opacus.ai/tutorials/building_text_classifier"},
            {"text": "Add Laplace noise to prediction confidence scores",
             "url": "https://adversarial-robustness-toolbox.readthedocs.io/en/latest/modules/defences/postprocessor.html"},
            {"text": "Increase L2 regularization (alpha >= 0.1) to reduce memorization",
             "url": "https://adversarial-robustness-toolbox.readthedocs.io/en/latest/modules/defences/preprocessor.html"},
            {"text": "Quantize output probabilities (top-k only, fewer decimal places)",
             "url": "https://adversarial-robustness-toolbox.readthedocs.io/en/latest/modules/defences/postprocessor.html"},
            {"text": "Run ML Privacy Meter audit before model deployment",
             "url": "https://adversarial-robustness-toolbox.readthedocs.io/en/latest/modules/attacks/inference/membership_inference.html"},
            {"text": "Monitor inference logs for repeated membership probing patterns",
             "url": "https://opacus.ai/"},
        ]

        pr.status = "PASS"
        return pr


if __name__ == "__main__":
    import json
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = MOD04Membership(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
