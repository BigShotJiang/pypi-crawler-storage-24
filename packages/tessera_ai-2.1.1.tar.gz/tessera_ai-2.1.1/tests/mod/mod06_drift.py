"""
AITG-MOD-06 — Testing for Robustness Against Distribution Changes

3-Phase OWASP Methodology:
    Phase 1: Drift & OOD injection (synthetic drift, covariate shift, Alibi OOD)
    Phase 2: Quantitative metrics (PSI, KS test, OOD detection rate, Evidently drift)
    Phase 3: Defense validation (WhyLogs, Evidently monitor, Alibi retraining triggers)

Tools: Evidently AI (mandatory), Alibi Detect, DeepChecks, WhyLogs
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md
"""

import numpy as np

from tests.base import Metric, OWASPTestCase, PhaseResult


class MOD06Drift(OWASPTestCase):
    TEST_ID = "MOD-06"
    TEST_NAME = "Testing for Robustness Against Distribution Changes"
    CATEGORY = "AI Model Testing"
    OWASP_REF = "AITG-MOD-06"
    TOOLS = ["Evidently AI", "Alibi Detect", "DeepChecks", "WhyLogs"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._reference = None
        self._current = None
        self._drift_results = {}

    def _generate_data(self, config: dict):
        """Generate reference + drifted data for testing."""
        data_cfg = config.get("data", {})

        if data_cfg.get("training_data") and data_cfg.get("production_data"):
            import pandas as pd
            self._reference = pd.read_csv(data_cfg["training_data"])
            self._current = pd.read_csv(data_cfg["production_data"])
            return

        # Synthetic: reference = normal, current = shifted
        self.log("Generating synthetic reference + drifted data...")
        np.random.seed(42)
        n_features = 20
        if self.target_model:
            shape = self.target_model.get("input_shape", [])
            if shape:
                import operator
                from functools import reduce
                n_features = min(reduce(operator.mul, shape, 1), 100)
        n_ref = 1000
        n_cur = 500

        # Reference distribution
        ref = np.random.randn(n_ref, n_features).astype(np.float32)

        # Current = reference + drift on some features
        cur = np.random.randn(n_cur, n_features).astype(np.float32)
        # Inject drift: shift mean of first 5 features
        cur[:, :5] += 1.5
        # Inject variance change on features 5-10
        cur[:, 5:10] *= 2.0
        # Features 10-20 remain stable

        import pandas as pd
        cols = [f"feature_{i}" for i in range(n_features)]
        self._reference = pd.DataFrame(ref, columns=cols)
        self._current = pd.DataFrame(cur, columns=cols)

        # Add labels
        self._reference["label"] = np.random.randint(0, 5, n_ref)
        self._current["label"] = np.random.randint(0, 5, n_cur)

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Drift injection + OOD detection."""
        pr = PhaseResult(phase=1, name="Drift & OOD Detection")
        self._generate_data(config)

        # ── Evidently AI DataDrift ──
        try:
            self.log("Running Evidently AI drift detection...")
            from evidently import Report
            from evidently.metrics import DriftedColumnsCount

            report = Report([DriftedColumnsCount()])
            report.run(reference_data=self._reference, current_data=self._current)

            # v0.7 API: access result via items()
            result = list(report.items())[0]
            drift_share = getattr(result, "drift_share", 0.5)
            feature_cols = [c for c in self._reference.columns if c != "label"]
            n_total = len(feature_cols)
            n_drifted = int(drift_share * n_total)

            self._drift_results["evidently"] = {
                "drift_share": drift_share,
                "n_drifted": n_drifted,
                "n_total": n_total,
                "dataset_drift": drift_share > 0.5,
            }
            pr.evidence.append(
                f"Evidently: {n_drifted}/{n_total} features drifted "
                f"({drift_share:.0%}), dataset_drift={drift_share > 0.5}"
            )
        except Exception as e:
            pr.evidence.append(f"Evidently AI: ERROR — {e}")

        # ── Per-Feature PSI (Population Stability Index) ──
        try:
            self.log("Computing per-feature PSI...")
            feature_cols = [c for c in self._reference.columns if c != "label"]
            psi_values = {}

            for col in feature_cols:
                ref_vals = self._reference[col].values
                cur_vals = self._current[col].values
                psi = self._compute_psi(ref_vals, cur_vals)
                psi_values[col] = psi

            avg_psi = np.mean(list(psi_values.values()))
            max_psi = max(psi_values.values())
            drifted_features = [k for k, v in psi_values.items() if v > 0.25]

            self._drift_results["psi"] = {
                "per_feature": psi_values,
                "avg_psi": avg_psi,
                "max_psi": max_psi,
                "drifted_features": drifted_features,
            }
            pr.evidence.append(
                f"PSI: avg={avg_psi:.4f}, max={max_psi:.4f}, "
                f"{len(drifted_features)}/{len(feature_cols)} drifted (>0.25)"
            )
        except Exception as e:
            pr.evidence.append(f"PSI computation: ERROR — {e}")

        # ── Kolmogorov-Smirnov Test ──
        try:
            self.log("Running KS tests...")
            from scipy.stats import ks_2samp

            ks_results = {}
            feature_cols = [c for c in self._reference.columns if c != "label"]
            for col in feature_cols:
                stat, pvalue = ks_2samp(
                    self._reference[col].values, self._current[col].values
                )
                ks_results[col] = {"statistic": stat, "pvalue": pvalue}

            sig_features = [k for k, v in ks_results.items() if v["pvalue"] < 0.05]
            self._drift_results["ks"] = {
                "per_feature": ks_results,
                "n_significant": len(sig_features),
            }
            pr.evidence.append(
                f"KS test: {len(sig_features)}/{len(feature_cols)} features "
                f"with p < 0.05"
            )
        except Exception as e:
            pr.evidence.append(f"KS test: ERROR — {e}")

        # ── Alibi Detect OOD (OutlierVAE or KS detector) ──
        try:
            self.log("Running Alibi Detect OOD...")
            from alibi_detect.od import KSDrift

            feature_cols = [c for c in self._reference.columns if c != "label"]
            ref_np = self._reference[feature_cols].values.astype(np.float32)
            cur_np = self._current[feature_cols].values.astype(np.float32)

            cd = KSDrift(ref_np, p_val=0.05)
            preds = cd.predict(cur_np, return_p_val=True)

            is_drift = preds["data"]["is_drift"]
            p_val = preds["data"].get("p_val", None)

            self._drift_results["alibi"] = {
                "is_drift": int(is_drift),
                "p_val": float(p_val) if p_val is not None else None,
            }
            pr.evidence.append(
                f"Alibi KSDrift: drift_detected={bool(is_drift)}, p_val={p_val}"
            )
        except Exception as e:
            pr.evidence.append(f"Alibi Detect: ERROR — {e}")

        # ── DeepChecks Data Integrity ──
        try:
            self.log("Running DeepChecks data integrity...")
            from deepchecks.tabular import Dataset
            from deepchecks.tabular.checks import FeatureDrift

            ref_ds = Dataset(self._reference, label="label")
            cur_ds = Dataset(self._current, label="label")

            check = FeatureDrift()
            dc_result = check.run(ref_ds, cur_ds)

            pr.evidence.append(
                f"DeepChecks FeatureDrift: {dc_result.header}"
            )
            self._drift_results["deepchecks"] = {"ran": True}
        except Exception as e:
            pr.evidence.append(f"DeepChecks: ERROR — {e}")

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Drift severity metrics."""
        pr = PhaseResult(phase=2, name="Drift Severity Metrics")

        if not self._drift_results:
            pr.status = "N/A"
            return pr

        thresholds = config.get("params", {}).get("drift", {})

        # Metric 1: Average PSI
        if "psi" in self._drift_results:
            avg_psi = self._drift_results["psi"]["avg_psi"]
            pr.metrics.append(Metric(
                name="Average PSI (Population Stability)",
                value=round(avg_psi, 4),
                threshold_pass=thresholds.get("psi_threshold", 0.25),
                threshold_fail=0.50,
                unit="",
                operator="<",
                source="OWASP AITG-MOD-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md",
            ))

            max_psi = self._drift_results["psi"]["max_psi"]
            pr.metrics.append(Metric(
                name="Max feature PSI",
                value=round(max_psi, 4),
                threshold_pass=0.25,
                threshold_fail=1.0,
                operator="<",
                source="OWASP AITG-MOD-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md",
            ))

        # Metric 2: Evidently drift share
        if "evidently" in self._drift_results:
            share = self._drift_results["evidently"]["drift_share"]
            pr.metrics.append(Metric(
                name="Drifted features share",
                value=round(share, 4),
                threshold_pass=0.30,
                threshold_fail=0.60,
                unit="%",
                operator="<",
                source="OWASP AITG-MOD-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md",
            ))

        # Metric 3: KS significant features ratio
        if "ks" in self._drift_results:
            n_sig = self._drift_results["ks"]["n_significant"]
            n_total = len(self._drift_results["ks"]["per_feature"])
            sig_ratio = n_sig / n_total if n_total > 0 else 0
            pr.metrics.append(Metric(
                name="KS-significant feature ratio",
                value=round(sig_ratio, 4),
                threshold_pass=0.30,
                threshold_fail=0.60,
                unit="%",
                operator="<",
                source="OWASP AITG-MOD-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md",
            ))

        # Metric 4: Alibi drift detection
        if "alibi" in self._drift_results:
            is_drift = self._drift_results["alibi"]["is_drift"]
            pr.metrics.append(Metric(
                name="Alibi drift detected",
                value=float(is_drift),
                threshold_pass=0.5,
                threshold_fail=1.5,
                operator="<",
                source="OWASP AITG-MOD-06 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-MOD-06_Testing_for_Robustness_to_New_Data.md",
            ))

        pr.evidence.append("Drift metrics computed from all detectors")
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Drift monitoring & defense validation."""
        pr = PhaseResult(phase=3, name="Drift Monitoring & Defense")

        # Defense 1: Evidently continuous monitoring
        try:
            self.log("Validating Evidently monitoring setup...")
            from evidently import Report
            from evidently.presets import DataSummaryPreset

            report = Report([DataSummaryPreset()])
            report.run(reference_data=self._reference, current_data=self._current)

            pr.evidence.append(
                "Evidently DataQuality report generated — "
                "integrate as Prometheus collector or Grafana dashboard"
            )
        except Exception as e:
            pr.evidence.append(f"Evidently monitoring: ERROR — {e}")

        # Defense 2: WhyLogs profiling
        try:
            self.log("Testing WhyLogs data profiling...")
            import whylogs as why

            ref_profile = why.log(self._reference).profile()
            why.log(self._current).profile()  # validate current data profiles

            ref_view = ref_profile.view()

            pr.evidence.append(
                f"WhyLogs: reference profile ({ref_view.get_columns().keys()}) "
                f"vs current profile — ready for WhyLabs integration"
            )
        except Exception as e:
            pr.evidence.append(f"WhyLogs: ERROR — {e}")

        # Defense 3: Automated retraining trigger
        pr.evidence.append(
            "Retraining trigger: when PSI > 0.25 on >30% features, "
            "OR Alibi KSDrift p_val < 0.01, trigger model retraining pipeline. "
            "Implement as CronJob checking drift scores from Evidently/WhyLabs."
        )

        # Defense 4: Feature store validation
        pr.evidence.append(
            "Feature store validation: validate input distributions "
            "before inference using Great Expectations or Pandera. "
            "Reject batches with >50% OOD samples."
        )

        self.result.recommendations = [
            {"text": "Deploy Evidently AI as continuous drift monitor (CronJob + Prometheus)",
             "url": "https://docs.evidentlyai.com/docs/platform/monitoring_overview"},
            {"text": "Integrate WhyLogs profiling into inference pipeline",
             "url": "https://whylogs.readthedocs.io/en/stable/"},
            {"text": "Set PSI > 0.25 alert threshold for individual features",
             "url": "https://docs.evidentlyai.com/"},
            {"text": "Implement Alibi Detect KSDrift in pre-processing pipeline",
             "url": "https://docs.seldon.io/projects/alibi-detect/en/stable/cd/methods/ksdrift.html"},
            {"text": "Add automated retraining trigger when drift exceeds thresholds",
             "url": "https://docs.evidentlyai.com/docs/platform/monitoring_overview"},
            {"text": "Monitor label drift separately (concept drift vs covariate drift)",
             "url": "https://docs.seldon.io/projects/alibi-detect/en/stable/cd/background.html"},
            {"text": "Log all feature distributions to time-series DB for trend analysis",
             "url": "https://whylogs.readthedocs.io/en/stable/"},
        ]

        pr.status = "PASS"
        return pr

    @staticmethod
    def _compute_psi(reference: np.ndarray, current: np.ndarray,
                     n_bins: int = 10) -> float:
        """Compute Population Stability Index between two distributions."""
        # Create bins from reference
        breakpoints = np.percentile(reference, np.linspace(0, 100, n_bins + 1))
        breakpoints = np.unique(breakpoints)

        ref_counts = np.histogram(reference, bins=breakpoints)[0]
        cur_counts = np.histogram(current, bins=breakpoints)[0]

        # Normalize to proportions
        ref_pct = (ref_counts + 1) / (len(reference) + len(breakpoints))
        cur_pct = (cur_counts + 1) / (len(current) + len(breakpoints))

        psi = np.sum((cur_pct - ref_pct) * np.log(cur_pct / ref_pct))
        return float(psi)


if __name__ == "__main__":
    import json
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = MOD06Drift(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
