"""CRUD operations for scans."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from tessera.db.models import Scan, ScanResult


def create_scan(db: Session, config: dict, user_id: str = None, org_id: str = None) -> Scan:
    scan = Scan(config=config, user_id=user_id, org_id=org_id)
    db.add(scan)
    db.commit()
    db.refresh(scan)
    return scan


def get_scan(db: Session, scan_id: str) -> Optional[Scan]:
    return db.query(Scan).filter(Scan.id == scan_id).first()


def list_scans(
    db: Session,
    skip: int = 0,
    limit: int = 20,
    org_id: str = None,
) -> list[Scan]:
    q = db.query(Scan)
    if org_id:
        q = q.filter(Scan.org_id == org_id)
    return q.order_by(Scan.created_at.desc()).offset(skip).limit(limit).all()


def update_scan_status(
    db: Session,
    scan_id: str,
    status: str,
    result_data: dict = None,
    duration_sec: float = None,
    error: str = None,
    counts: dict = None,
):
    scan = get_scan(db, scan_id)
    if not scan:
        return
    scan.status = status
    if result_data is not None:
        scan.result_data = result_data
    if duration_sec is not None:
        scan.duration_sec = duration_sec
    if error is not None:
        scan.error = error
    if counts:
        scan.tests_total = counts.get("total", scan.tests_total)
        scan.tests_completed = counts.get("completed", scan.tests_completed)
        scan.tests_passed = counts.get("passed", scan.tests_passed)
        scan.tests_failed = counts.get("failed", scan.tests_failed)
    if status == "completed":
        scan.completed_at = datetime.utcnow()
    db.commit()


def delete_scan(db: Session, scan_id: str) -> bool:
    scan = get_scan(db, scan_id)
    if not scan:
        return False
    db.delete(scan)
    db.commit()
    return True


def add_scan_result(
    db: Session,
    scan_id: str,
    test_id: str,
    model_name: str,
    status: str,
    phases: list,
    metrics: list,
    recommendations: list,
    duration_sec: float,
    error: str = None,
) -> ScanResult:
    result = ScanResult(
        scan_id=scan_id,
        test_id=test_id,
        model_name=model_name,
        status=status,
        phases=phases,
        metrics=metrics,
        recommendations=recommendations,
        duration_sec=duration_sec,
        error=error,
    )
    db.add(result)
    db.commit()
    db.refresh(result)
    return result
