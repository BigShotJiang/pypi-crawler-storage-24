"""CRUD operations for users."""

from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from tessera.db.models import User


def create_user(db: Session, email: str, hashed_password: str, role: str = "analyst", org_id: str = None) -> User:
    user = User(email=email, hashed_password=hashed_password, role=role, org_id=org_id)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def get_user_by_email(db: Session, email: str) -> Optional[User]:
    return db.query(User).filter(User.email == email).first()


def get_user(db: Session, user_id: str) -> Optional[User]:
    return db.query(User).filter(User.id == user_id).first()
