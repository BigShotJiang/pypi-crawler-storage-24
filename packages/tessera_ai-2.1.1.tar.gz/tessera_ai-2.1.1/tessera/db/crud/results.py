"""CRUD operations for scan results."""

from __future__ import annotations

from sqlalchemy.orm import Session

from tessera.db.models import ScanResult


def get_results(
    db: Session,
    scan_id: str = None,
    test_id: str = None,
    model_name: str = None,
    status: str = None,
    skip: int = 0,
    limit: int = 50,
) -> list[ScanResult]:
    q = db.query(ScanResult)
    if scan_id:
        q = q.filter(ScanResult.scan_id == scan_id)
    if test_id:
        q = q.filter(ScanResult.test_id == test_id)
    if model_name:
        q = q.filter(ScanResult.model_name == model_name)
    if status:
        q = q.filter(ScanResult.status == status)
    return q.order_by(ScanResult.created_at.desc()).offset(skip).limit(limit).all()
