"""CRUD operations for model entries."""

from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from tessera.db.models import ModelEntry


def create_model(db: Session, **kwargs) -> ModelEntry:
    model = ModelEntry(**kwargs)
    db.add(model)
    db.commit()
    db.refresh(model)
    return model


def get_model(db: Session, model_id: str) -> Optional[ModelEntry]:
    return db.query(ModelEntry).filter(ModelEntry.id == model_id).first()


def list_models(db: Session, org_id: str = None) -> list[ModelEntry]:
    q = db.query(ModelEntry)
    if org_id:
        q = q.filter(ModelEntry.org_id == org_id)
    return q.order_by(ModelEntry.created_at.desc()).all()


def delete_model(db: Session, model_id: str) -> bool:
    model = get_model(db, model_id)
    if not model:
        return False
    db.delete(model)
    db.commit()
    return True
