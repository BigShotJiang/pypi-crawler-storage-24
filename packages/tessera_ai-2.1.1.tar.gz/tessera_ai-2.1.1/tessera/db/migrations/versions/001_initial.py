"""Initial schema — 7 tables

Revision ID: 001_initial
Revises:
Create Date: 2026-03-24
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "organizations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("license_key", sa.String(512), nullable=True),
        sa.Column("tier", sa.String(50), server_default="community"),
        sa.Column("limits", sa.JSON, server_default="{}"),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), unique=True, nullable=False),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("role", sa.String(50), server_default="analyst"),
        sa.Column("is_active", sa.Boolean, server_default=sa.text("true")),
        sa.Column("org_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "scans",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("config", sa.JSON, server_default="{}"),
        sa.Column("status", sa.String(20), server_default="pending"),
        sa.Column("tests_total", sa.Integer, server_default="0"),
        sa.Column("tests_completed", sa.Integer, server_default="0"),
        sa.Column("tests_passed", sa.Integer, server_default="0"),
        sa.Column("tests_failed", sa.Integer, server_default="0"),
        sa.Column("duration_sec", sa.Float, nullable=True),
        sa.Column("error", sa.Text, nullable=True),
        sa.Column("result_data", sa.JSON, nullable=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("org_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime, nullable=True),
    )

    op.create_table(
        "scan_results",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("scan_id", sa.String(36), sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("test_id", sa.String(10), nullable=False),
        sa.Column("model_name", sa.String(255), server_default=""),
        sa.Column("status", sa.String(10), nullable=False),
        sa.Column("phases", sa.JSON, server_default="[]"),
        sa.Column("metrics", sa.JSON, server_default="[]"),
        sa.Column("recommendations", sa.JSON, server_default="[]"),
        sa.Column("duration_sec", sa.Float, server_default="0"),
        sa.Column("error", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "models",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("server_type", sa.String(50), server_default=""),
        sa.Column("url", sa.String(512), server_default=""),
        sa.Column("model_type", sa.String(10), server_default="cv"),
        sa.Column("arch", sa.String(255), server_default=""),
        sa.Column("task", sa.String(100), server_default=""),
        sa.Column("config", sa.JSON, server_default="{}"),
        sa.Column("last_scan_at", sa.DateTime, nullable=True),
        sa.Column("org_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "configs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("config", sa.JSON, server_default="{}"),
        sa.Column("is_default", sa.Boolean, server_default=sa.text("false")),
        sa.Column("org_id", sa.String(36), sa.ForeignKey("organizations.id"), nullable=True),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("resource_type", sa.String(50), server_default=""),
        sa.Column("resource_id", sa.String(36), server_default=""),
        sa.Column("details", sa.JSON, server_default="{}"),
        sa.Column("ip_address", sa.String(45), server_default=""),
        sa.Column("timestamp", sa.DateTime, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("audit_logs")
    op.drop_table("configs")
    op.drop_table("models")
    op.drop_table("scan_results")
    op.drop_table("scans")
    op.drop_table("users")
    op.drop_table("organizations")
