"""
Tessera — Database engine configuration.

Uses TESSERA_DATABASE_URL env var. Falls back to SQLite for dev/testing.
CLI works without any database configured.
"""

from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.environ.get(
    "TESSERA_DATABASE_URL",
    "sqlite:///tessera.db",
)

# Sync engine (used by Celery workers and Alembic)
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    **({"connect_args": {"check_same_thread": False}} if DATABASE_URL.startswith("sqlite") else {}),
)

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


def get_session():
    """Yield a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_tables():
    """Create all tables (dev/testing convenience)."""
    Base.metadata.create_all(bind=engine)
