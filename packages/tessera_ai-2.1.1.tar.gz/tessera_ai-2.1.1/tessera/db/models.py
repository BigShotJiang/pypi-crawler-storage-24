"""
Tessera — SQLAlchemy ORM models.

6 core tables: scans, scan_results, models, configs, users, organizations.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from tessera.db.engine import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class Organization(Base):
    __tablename__ = "organizations"

    id = Column(String(36), primary_key=True, default=_uuid)
    name = Column(String(255), nullable=False)
    license_key = Column(String(512), nullable=True)
    tier = Column(String(50), default="community")  # community, pro, enterprise
    limits = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

    users = relationship("User", back_populates="organization")


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=_uuid)
    email = Column(String(255), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(50), default="analyst")  # admin, analyst, viewer
    is_active = Column(Boolean, default=True)
    org_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    organization = relationship("Organization", back_populates="users")
    scans = relationship("Scan", back_populates="user")


class Scan(Base):
    __tablename__ = "scans"

    id = Column(String(36), primary_key=True, default=_uuid)
    config = Column(JSON, default=dict)
    status = Column(String(20), default="pending")
    tests_total = Column(Integer, default=0)
    tests_completed = Column(Integer, default=0)
    tests_passed = Column(Integer, default=0)
    tests_failed = Column(Integer, default=0)
    duration_sec = Column(Float, nullable=True)
    error = Column(Text, nullable=True)
    result_data = Column(JSON, nullable=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    org_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="scans")
    results = relationship("ScanResult", back_populates="scan", cascade="all, delete-orphan")


class ScanResult(Base):
    __tablename__ = "scan_results"

    id = Column(String(36), primary_key=True, default=_uuid)
    scan_id = Column(String(36), ForeignKey("scans.id"), nullable=False)
    test_id = Column(String(10), nullable=False)
    model_name = Column(String(255), default="")
    status = Column(String(10), nullable=False)
    phases = Column(JSON, default=list)
    metrics = Column(JSON, default=list)
    recommendations = Column(JSON, default=list)
    duration_sec = Column(Float, default=0.0)
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    scan = relationship("Scan", back_populates="results")


class ModelEntry(Base):
    __tablename__ = "models"

    id = Column(String(36), primary_key=True, default=_uuid)
    name = Column(String(255), nullable=False)
    server_type = Column(String(50), default="")
    url = Column(String(512), default="")
    model_type = Column(String(10), default="cv")
    arch = Column(String(255), default="")
    task = Column(String(100), default="")
    config = Column(JSON, default=dict)
    last_scan_at = Column(DateTime, nullable=True)
    org_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Config(Base):
    __tablename__ = "configs"

    id = Column(String(36), primary_key=True, default=_uuid)
    name = Column(String(255), nullable=False)
    config = Column(JSON, default=dict)
    is_default = Column(Boolean, default=False)
    org_id = Column(String(36), ForeignKey("organizations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True, default=_uuid)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False)
    resource_type = Column(String(50), default="")
    resource_id = Column(String(36), default="")
    details = Column(JSON, default=dict)
    ip_address = Column(String(45), default="")
    timestamp = Column(DateTime, default=datetime.utcnow)
