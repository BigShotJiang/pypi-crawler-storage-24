"""
Tessera — Celery tasks for async scan execution.
"""

from __future__ import annotations

from tessera.config import load_config
from tessera.engine import (
    build_executive_summary,
    build_flat_report,
    build_model_report,
    run_per_model,
    run_tests,
)
from tessera.registry import get_test_ids
from tessera.worker.celery_app import celery_app


@celery_app.task(bind=True, name="tessera.run_scan")
def run_scan_task(self, scan_id: str, request: dict):
    """Execute a scan asynchronously.

    Args:
        scan_id: Scan UUID.
        request: Serialized ScanRequest dict.
    """
    from tessera.worker.callbacks import on_complete, on_error, on_progress

    try:
        config = load_config(request.get("config_path", "config.yaml"))
        overrides = request.get("config_override", {})
        if overrides:
            config.update(overrides)

        test_ids = get_test_ids(
            category=request.get("category"),
            test_ids=request.get("test_ids") or None,
        )
        phases = request.get("phases", [1, 2, 3])
        per_model = request.get("per_model", False)

        def progress_cb(info: dict):
            info["scan_id"] = scan_id
            on_progress(scan_id, info)
            self.update_state(state="PROGRESS", meta=info)

        if per_model:
            all_results, all_models, duration = run_per_model(
                config=config,
                test_ids=test_ids,
                phases=phases,
                model_filter=request.get("model_filter") or None,
                model_type_filter=request.get("model_type_filter"),
                on_progress=progress_cb,
            )
            model_reports = {}
            for model in all_models:
                name = model["name"]
                if name in all_results:
                    model_reports[name] = build_model_report(config, model, all_results[name])

            summary = build_executive_summary(config, all_models, all_results, duration)
            result_data = {"summary": summary, "model_reports": model_reports}
        else:
            results, duration = run_tests(
                config=config,
                test_ids=test_ids,
                phases=phases,
                on_progress=progress_cb,
            )
            result_data = build_flat_report(config, results, duration)

        on_complete(scan_id, result_data, duration)
        return {"scan_id": scan_id, "status": "completed", "duration": duration}

    except Exception as e:
        on_error(scan_id, str(e))
        raise
