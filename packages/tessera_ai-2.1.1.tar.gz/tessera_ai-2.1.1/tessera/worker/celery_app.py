"""
Tessera — Celery application configuration.

Uses TESSERA_REDIS_URL (default: redis://localhost:6379/0) for broker and backend.
"""

import os

from celery import Celery

REDIS_URL = os.environ.get("TESSERA_REDIS_URL", "redis://localhost:6379/0")

celery_app = Celery(
    "tessera",
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=["tessera.worker.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
)
