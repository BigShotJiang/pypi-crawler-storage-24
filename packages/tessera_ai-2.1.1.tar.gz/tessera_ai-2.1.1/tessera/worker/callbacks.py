"""
Tessera — Worker callbacks for progress updates.

Updates DB and broadcasts progress via WebSocket when running inside
the API server process. Falls back gracefully when DB is not available.
"""

from __future__ import annotations

import os


def _get_db_session():
    """Try to get a DB session. Returns None if DB is not configured."""
    if not os.environ.get("TESSERA_DATABASE_URL"):
        return None
    try:
        from tessera.db.engine import SessionLocal
        return SessionLocal()
    except Exception:
        return None


def on_progress(scan_id: str, info: dict):
    """Called during scan execution with progress updates."""
    db = _get_db_session()
    if db:
        try:
            from tessera.db.crud.scans import update_scan_status
            update_scan_status(
                db, scan_id, "running",
                counts={
                    "completed": info.get("tests_completed", 0),
                    "total": info.get("tests_total", 0),
                },
            )
        except Exception:
            pass
        finally:
            db.close()

    # Try WebSocket broadcast
    try:
        from tessera.api.websocket import broadcast_progress
        broadcast_progress(scan_id, info)
    except Exception:
        pass


def on_complete(scan_id: str, result_data: dict, duration: float):
    """Called when scan completes successfully."""
    db = _get_db_session()
    if db:
        try:
            from tessera.db.crud.scans import update_scan_status
            update_scan_status(
                db, scan_id, "completed",
                result_data=result_data,
                duration_sec=duration,
            )
        except Exception:
            pass
        finally:
            db.close()

    try:
        from tessera.api.websocket import broadcast_progress
        broadcast_progress(scan_id, {
            "scan_id": scan_id,
            "status": "completed",
            "message": "Scan complete.",
        })
    except Exception:
        pass


def on_error(scan_id: str, error: str):
    """Called when scan fails."""
    db = _get_db_session()
    if db:
        try:
            from tessera.db.crud.scans import update_scan_status
            update_scan_status(db, scan_id, "failed", error=error)
        except Exception:
            pass
        finally:
            db.close()

    try:
        from tessera.api.websocket import broadcast_progress
        broadcast_progress(scan_id, {
            "scan_id": scan_id,
            "status": "failed",
            "message": f"Scan failed: {error}",
        })
    except Exception:
        pass
