"""
Tessera — Interactive Config Wizard.

Generates a config.yaml for first-time users by detecting available providers
and guiding through model selection. Goal: time-to-first-scan under 60 seconds.
"""

from __future__ import annotations

import os
import socket
from pathlib import Path

import yaml

# Provider detection table
PROVIDERS = {
    "openai": {
        "env_key": "OPENAI_API_KEY",
        "default_model": "gpt-4o",
        "server_type": "vllm",
        "url": "https://api.openai.com",
        "api_base": "/v1",
        "task": "chat",
    },
    "anthropic": {
        "env_key": "ANTHROPIC_API_KEY",
        "default_model": "claude-sonnet-4-20250514",
        "server_type": "vllm",
        "url": "https://api.anthropic.com",
        "api_base": "/v1",
        "task": "chat",
    },
    "ollama": {
        "env_key": None,
        "probe": ("localhost", 11434),
        "default_model": "llama3",
        "server_type": "ollama",
        "url": "http://localhost:11434",
        "api_base": "/v1",
        "task": "chat",
    },
    "vllm": {
        "env_key": None,
        "probe": ("localhost", 8000),
        "default_model": "auto",
        "server_type": "vllm",
        "url": "http://localhost:8000",
        "api_base": "/v1",
        "task": "chat",
    },
}


def _probe_port(host: str, port: int, timeout: float = 1.0) -> bool:
    """Check if a TCP port is open."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, ConnectionRefusedError):
        return False


class ConfigWizard:
    """Interactive config wizard for first-time Tessera setup."""

    def __init__(self):
        self.detected: list[str] = []
        self.selected_provider: str = ""
        self.model_name: str = ""
        self.project_name: str = "my-project"
        self.config: dict = {}

    def detect_providers(self) -> list[str]:
        """Detect available AI providers from env vars and local probes."""
        detected = []
        for name, info in PROVIDERS.items():
            env_key = info.get("env_key")
            if env_key and os.environ.get(env_key):
                detected.append(name)
                continue
            probe = info.get("probe")
            if probe and _probe_port(probe[0], probe[1]):
                detected.append(name)
        self.detected = detected
        return detected

    def prompt_selection(self):
        """Interactively prompt user for provider, model, and project name."""
        print("\n  Tessera — Config Wizard")
        print("  " + "=" * 40)

        # Detect providers
        detected = self.detect_providers()
        if detected:
            print(f"\n  Detected providers: {', '.join(detected)}")
        else:
            print("\n  No providers auto-detected.")

        # Provider selection
        all_providers = list(PROVIDERS.keys())
        print("\n  Available providers:")
        for i, p in enumerate(all_providers, 1):
            marker = " [detected]" if p in detected else ""
            print(f"    {i}. {p}{marker}")

        default_idx = all_providers.index(detected[0]) + 1 if detected else 1
        choice = input(f"\n  Select provider [{default_idx}]: ").strip()
        idx = int(choice) - 1 if choice.isdigit() else default_idx - 1
        idx = max(0, min(idx, len(all_providers) - 1))
        self.selected_provider = all_providers[idx]

        # Model name
        default_model = PROVIDERS[self.selected_provider]["default_model"]
        model_input = input(f"  Model name [{default_model}]: ").strip()
        self.model_name = model_input or default_model

        # Project name
        project_input = input(f"  Project name [{self.project_name}]: ").strip()
        self.project_name = project_input or self.project_name

    def generate_config(self) -> dict:
        """Build the config dict from user selections."""
        provider = PROVIDERS[self.selected_provider]
        api_key_ref = ""
        env_key = provider.get("env_key")
        if env_key:
            api_key_ref = os.environ.get(env_key, "YOUR_API_KEY_HERE")

        server_type = provider["server_type"]
        self.config = {
            "project": {
                "name": self.project_name,
                "environment": "development",
            },
            "models": {
                server_type: {
                    "url": provider["url"],
                    "api_base": provider["api_base"],
                    "api_key": api_key_ref,
                    "models": [
                        {
                            "name": self.model_name,
                            "task": provider["task"],
                        },
                    ],
                },
            },
        }
        return self.config

    def write_config(self, path: str = "config.yaml"):
        """Write the generated config to a YAML file."""
        Path(path).write_text(yaml.dump(self.config, default_flow_style=False, sort_keys=False))
        print(f"\n  Config written to: {path}")

    def offer_first_scan(self) -> bool:
        """Ask the user if they want to run a scan immediately."""
        answer = input("\n  Run first scan now? [Y/n]: ").strip().lower()
        return answer in ("", "y", "yes")

    def run(self):
        """Execute the full wizard flow."""
        self.prompt_selection()
        self.generate_config()
        self.write_config()
