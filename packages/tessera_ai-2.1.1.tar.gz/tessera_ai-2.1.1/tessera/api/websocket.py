"""
Tessera — WebSocket for live scan progress.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

# Active WebSocket connections per scan_id
_connections: dict[str, list[WebSocket]] = defaultdict(list)

# Thread-safe queue for broadcasting from sync threads
_progress_queue: asyncio.Queue | None = None


def _init_ws_broadcaster():
    """Initialize the WebSocket broadcast queue and background task."""
    global _progress_queue
    _progress_queue = asyncio.Queue()
    asyncio.create_task(_broadcast_loop())


def register_websocket(app: FastAPI):
    """Register WebSocket route on the app."""

    @app.websocket("/api/v1/scans/{scan_id}/ws")
    async def scan_progress_ws(websocket: WebSocket, scan_id: str):
        await websocket.accept()
        _connections[scan_id].append(websocket)
        try:
            while True:
                # Keep connection alive, wait for client messages (ping)
                await websocket.receive_text()
        except WebSocketDisconnect:
            _connections[scan_id].remove(websocket)


async def _broadcast_loop():
    """Background task that reads from the progress queue and sends to WebSocket clients."""
    while True:
        scan_id, data = await _progress_queue.get()
        conns = _connections.get(scan_id, [])
        dead = []
        for ws in conns:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            conns.remove(ws)


def broadcast_progress(scan_id: str, data: dict):
    """Thread-safe: enqueue a progress update for WebSocket broadcast."""
    if _progress_queue is not None:
        try:
            _progress_queue.put_nowait((scan_id, data))
        except Exception:
            pass
