"""Scan management endpoints."""

from __future__ import annotations

import threading
import uuid

from fastapi import APIRouter, HTTPException, Query

from tessera.api.deps import (
    delete_scan,
    get_scan,
    list_scans,
    store_scan,
    update_scan,
)
from tessera.api.websocket import broadcast_progress
from tessera.config import load_config
from tessera.engine import (
    build_executive_summary,
    build_flat_report,
    build_model_report,
    run_per_model,
    run_tests,
)
from tessera.models import ScanRequest, ScanStatus
from tessera.registry import get_test_ids

router = APIRouter(tags=["scans"])


def _execute_scan(scan_id: str, request: ScanRequest):
    """Run scan in background thread."""
    try:
        update_scan(scan_id, {"status": ScanStatus.RUNNING})

        config = load_config(request.config_path)
        if request.config_override:
            config.update(request.config_override)

        test_ids = get_test_ids(category=request.category, test_ids=request.test_ids or None)

        def on_progress(info: dict):
            info["scan_id"] = scan_id
            info["status"] = ScanStatus.RUNNING
            update_scan(scan_id, {"progress": info})
            broadcast_progress(scan_id, info)

        if request.per_model:
            all_results, all_models, duration = run_per_model(
                config=config,
                test_ids=test_ids,
                phases=request.phases,
                model_filter=request.model_filter or None,
                model_type_filter=request.model_type_filter,
                on_progress=on_progress,
            )
            # Build per-model reports
            model_reports = {}
            for model in all_models:
                name = model["name"]
                if name in all_results:
                    model_reports[name] = build_model_report(config, model, all_results[name])

            summary = build_executive_summary(config, all_models, all_results, duration)
            update_scan(scan_id, {
                "status": ScanStatus.COMPLETED,
                "result": summary,
                "model_reports": model_reports,
                "duration": duration,
            })
        else:
            results, duration = run_tests(
                config=config,
                test_ids=test_ids,
                phases=request.phases,
                on_progress=on_progress,
            )
            report = build_flat_report(config, results, duration)
            update_scan(scan_id, {
                "status": ScanStatus.COMPLETED,
                "result": report,
                "duration": duration,
            })

        broadcast_progress(scan_id, {
            "scan_id": scan_id,
            "status": ScanStatus.COMPLETED,
            "message": "Scan complete.",
        })

    except Exception as e:
        update_scan(scan_id, {
            "status": ScanStatus.FAILED,
            "error": str(e),
        })
        broadcast_progress(scan_id, {
            "scan_id": scan_id,
            "status": ScanStatus.FAILED,
            "message": f"Scan failed: {e}",
        })


@router.post("/scans")
async def create_scan(request: ScanRequest):
    """Create and start a new scan."""
    scan_id = str(uuid.uuid4())
    scan_data = {
        "scan_id": scan_id,
        "status": ScanStatus.PENDING,
        "request": request.model_dump(),
    }
    store_scan(scan_data)

    # Run in background thread (replaced by Celery in Phase 2)
    thread = threading.Thread(target=_execute_scan, args=(scan_id, request), daemon=True)
    thread.start()

    return {"scan_id": scan_id, "status": ScanStatus.PENDING}


@router.get("/scans")
async def get_scans(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
):
    """List all scans with pagination."""
    scans = list_scans(skip=skip, limit=limit)
    return {"scans": scans, "total": len(scans)}


@router.get("/scans/{scan_id}")
async def get_scan_detail(scan_id: str):
    """Get scan details and status."""
    scan = get_scan(scan_id)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return scan


@router.delete("/scans/{scan_id}")
async def remove_scan(scan_id: str):
    """Delete a scan."""
    if not delete_scan(scan_id):
        raise HTTPException(status_code=404, detail="Scan not found")
    return {"deleted": True}
