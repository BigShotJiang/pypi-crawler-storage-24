"""Health check endpoints."""

from __future__ import annotations

import os
from typing import Any

from fastapi import APIRouter

from tessera import __version__
from tessera.api.deps import is_db_configured
from tessera.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["health"])


async def _check_redis() -> dict[str, Any]:
    """Check Redis connectivity. Returns component status dict."""
    redis_url = os.environ.get("TESSERA_REDIS_URL")
    if not redis_url:
        return {"status": "skipped", "reason": "TESSERA_REDIS_URL not set"}

    try:
        import redis.asyncio as aioredis

        client = aioredis.from_url(redis_url, socket_connect_timeout=2)
        pong = await client.ping()
        await client.aclose()
        return {"status": "ok" if pong else "error"}
    except ImportError:
        return {"status": "skipped", "reason": "redis package not installed"}
    except Exception as exc:
        logger.warning("Redis health check failed: %s", exc)
        return {"status": "error", "reason": str(exc)}


async def _check_database() -> dict[str, Any]:
    """Check database connectivity. Returns component status dict."""
    db_url = os.environ.get("TESSERA_DATABASE_URL")
    if not db_url:
        return {"status": "skipped", "reason": "TESSERA_DATABASE_URL not set"}

    try:
        from sqlalchemy import text
        from sqlalchemy.ext.asyncio import create_async_engine

        engine = create_async_engine(db_url, pool_pre_ping=True)
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        await engine.dispose()
        return {"status": "ok"}
    except ImportError:
        return {"status": "skipped", "reason": "sqlalchemy async not installed"}
    except Exception as exc:
        logger.warning("Database health check failed: %s", exc)
        return {"status": "error", "reason": str(exc)}


async def _check_workers() -> dict[str, Any]:
    """Check Celery worker status via Redis (inspect ping).

    Returns worker count if Redis is available, otherwise skips.
    """
    redis_url = os.environ.get("TESSERA_REDIS_URL")
    if not redis_url:
        return {"status": "skipped", "reason": "TESSERA_REDIS_URL not set"}

    try:
        from tessera.worker.celery_app import celery_app

        # inspect().ping() is a blocking call — run briefly with a short timeout
        inspector = celery_app.control.inspect(timeout=2)
        pings = inspector.ping()
        if pings:
            worker_count = len(pings)
            return {"status": "ok", "workers": worker_count}
        return {"status": "degraded", "workers": 0, "reason": "No workers responded"}
    except ImportError:
        return {"status": "skipped", "reason": "celery not installed"}
    except Exception as exc:
        logger.warning("Worker health check failed: %s", exc)
        return {"status": "error", "reason": str(exc)}


@router.get("/health")
async def health():
    """Basic health check. Always returns ``{"status": "ok"}`` when the API
    process is running — suitable for load balancer probes."""
    return {"status": "ok", "version": __version__}


@router.get("/health/detailed")
async def health_detailed():
    """Detailed health check with component statuses.

    Checks Redis, database, and Celery workers when the corresponding
    environment variables are configured. Components that are not configured
    are reported as ``skipped``.
    """
    components: dict[str, Any] = {
        "api": {"status": "ok"},
    }

    components["database"] = await _check_database()
    components["redis"] = await _check_redis()
    components["workers"] = await _check_workers()

    # Determine overall status
    statuses = [c.get("status") for c in components.values()]
    if all(s in ("ok", "skipped") for s in statuses):
        overall = "ok"
    elif "error" in statuses:
        overall = "degraded"
    else:
        overall = "degraded"

    return {
        "status": overall,
        "version": __version__,
        "components": components,
    }


@router.get("/ready")
async def ready():
    """Readiness check — reports whether the service can accept traffic."""
    checks: dict[str, Any] = {
        "api": True,
        "database": is_db_configured(),
    }

    # If Redis is configured, include a quick reachability check
    redis_url = os.environ.get("TESSERA_REDIS_URL")
    if redis_url:
        redis_result = await _check_redis()
        checks["redis"] = redis_result.get("status") == "ok"
    else:
        checks["redis"] = None  # not configured

    healthy = checks["api"]
    return {
        "status": "ready" if healthy else "degraded",
        "checks": checks,
    }
