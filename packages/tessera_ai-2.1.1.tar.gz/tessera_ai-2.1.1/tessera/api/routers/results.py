"""Results query endpoints."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from tessera.api.deps import get_scan, list_scans

router = APIRouter(tags=["results"])


@router.get("/results")
async def query_results(
    scan_id: Optional[str] = None,
    model_name: Optional[str] = None,
    test_id: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
):
    """Query test results with filtering."""
    results = []

    if scan_id:
        scan = get_scan(scan_id)
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        scan_result = scan.get("result", {})
        tests = scan_result.get("tests", [])

        # Also gather from model_reports if per-model
        model_reports = scan.get("model_reports", {})
        for report in model_reports.values():
            tests.extend(report.get("tests", []))

        for t in tests:
            if model_name and t.get("model_name") != model_name:
                continue
            if test_id and t.get("test_id") != test_id:
                continue
            if status and t.get("status") != status:
                continue
            results.append(t)
    else:
        # Search across all scans
        for scan in list_scans(skip=0, limit=1000):
            scan_result = scan.get("result", {})
            for t in scan_result.get("tests", []):
                if model_name and t.get("model_name") != model_name:
                    continue
                if test_id and t.get("test_id") != test_id:
                    continue
                if status and t.get("status") != status:
                    continue
                results.append(t)

    total = len(results)
    return {"results": results[skip:skip + limit], "total": total}


@router.get("/results/compare")
async def compare_results(
    scan_a: str = Query(..., description="First scan ID"),
    scan_b: str = Query(..., description="Second scan ID"),
):
    """Compare results between two scans for regression detection."""
    a = get_scan(scan_a)
    b = get_scan(scan_b)
    if not a or not b:
        raise HTTPException(status_code=404, detail="One or both scans not found")

    a_tests = {t["test_id"]: t for t in a.get("result", {}).get("tests", [])}
    b_tests = {t["test_id"]: t for t in b.get("result", {}).get("tests", [])}

    all_ids = sorted(set(a_tests.keys()) | set(b_tests.keys()))
    comparison = []
    regressions = 0
    improvements = 0

    for tid in all_ids:
        a_status = a_tests.get(tid, {}).get("status", "N/A")
        b_status = b_tests.get(tid, {}).get("status", "N/A")
        rank = {"PASS": 0, "WARN": 1, "FAIL": 2, "ERROR": 3, "N/A": -1}
        change = "unchanged"
        if rank.get(b_status, -1) > rank.get(a_status, -1):
            change = "regression"
            regressions += 1
        elif rank.get(b_status, -1) < rank.get(a_status, -1):
            change = "improvement"
            improvements += 1

        comparison.append({
            "test_id": tid,
            "scan_a_status": a_status,
            "scan_b_status": b_status,
            "change": change,
        })

    return {
        "scan_a": scan_a,
        "scan_b": scan_b,
        "regressions": regressions,
        "improvements": improvements,
        "comparison": comparison,
    }
