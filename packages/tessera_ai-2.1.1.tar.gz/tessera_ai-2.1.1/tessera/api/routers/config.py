"""Configuration management endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from tessera.api.deps import get_config, list_configs, store_config
from tessera.registry import CATEGORY_MAP, MODEL_TYPE_TESTS, TEST_REGISTRY

router = APIRouter(tags=["config"])


class ConfigCreateRequest(BaseModel):
    name: str
    config: dict[str, Any] = Field(default_factory=dict)
    is_default: bool = False


@router.get("/config/tests")
async def get_test_catalog():
    """Get the full test catalog with categories and model-type mappings."""
    # Build human-readable test names by loading the TEST_NAME class attribute
    test_names: dict[str, str] = {}
    for tid, (mod, cls_name) in TEST_REGISTRY.items():
        try:
            import importlib
            module = importlib.import_module(mod)
            cls = getattr(module, cls_name, None)
            test_names[tid] = getattr(cls, "TEST_NAME", tid) if cls else tid
        except Exception:
            test_names[tid] = tid

    return {
        "tests": test_names,
        "categories": CATEGORY_MAP,
        "model_type_tests": MODEL_TYPE_TESTS,
    }


@router.post("/config/saved")
async def create_config(request: ConfigCreateRequest):
    """Save a named configuration."""
    config_id = store_config(request.model_dump())
    return {"id": config_id, **request.model_dump()}


@router.get("/config/saved")
async def get_saved_configs():
    """List all saved configurations."""
    return {"configs": list_configs()}


@router.get("/config/saved/{config_id}")
async def get_saved_config(config_id: str):
    """Get a saved configuration."""
    config = get_config(config_id)
    if not config:
        raise HTTPException(status_code=404, detail="Config not found")
    return config
