"""Authentication endpoints."""

from __future__ import annotations

import os
import secrets
import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field

from tessera.api.deps import get_db
from tessera.enterprise.auth.jwt import (
    create_access_token,
    require_auth,
)
from tessera.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["auth"])

# ── Configurable demo credentials for standalone (no-DB) mode ──
_DEMO_EMAIL = os.environ.get("TESSERA_ADMIN_EMAIL", "admin@tessera.dev")
_DEMO_PASSWORD = os.environ.get("TESSERA_ADMIN_PASSWORD", "admin")

# ── GitHub OAuth configuration ──
_GITHUB_CLIENT_ID = os.environ.get("TESSERA_GITHUB_CLIENT_ID", "")
_GITHUB_CLIENT_SECRET = os.environ.get("TESSERA_GITHUB_CLIENT_SECRET", "")
_GITHUB_REDIRECT_URI = os.environ.get(
    "TESSERA_GITHUB_REDIRECT_URI", ""
)
_FRONTEND_URL = os.environ.get("TESSERA_FRONTEND_URL", "http://localhost:3000")

# ── OAuth state store (CSRF protection) ──
# Maps state token -> expiry timestamp. Entries are pruned on each insertion.
_OAUTH_STATE_TTL = 600  # 10 minutes
_oauth_states: dict[str, float] = {}


def _store_oauth_state(state: str) -> None:
    """Store an OAuth state token with a TTL and prune expired entries."""
    now = time.monotonic()
    # Prune expired states
    expired = [k for k, v in _oauth_states.items() if v < now]
    for k in expired:
        _oauth_states.pop(k, None)
    _oauth_states[state] = now + _OAUTH_STATE_TTL


def _validate_oauth_state(state: str) -> bool:
    """Validate and consume an OAuth state token. Returns True if valid."""
    expiry = _oauth_states.pop(state, None)
    if expiry is None:
        return False
    return time.monotonic() < expiry


def _auth_enabled() -> bool:
    """Return True when authentication validation is enabled."""
    return os.environ.get("TESSERA_AUTH_ENABLED", "false").lower() in ("1", "true", "yes")


# ── Request / Response schemas ──

class LoginRequest(BaseModel):
    email: str
    password: str


class RegisterRequest(BaseModel):
    email: str
    password: str = Field(..., min_length=8)
    role: str = "analyst"


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserInfo(BaseModel):
    user_id: str
    email: str
    role: str
    org_id: Optional[str] = None


# ── Helpers ──

def _verify_password(plain: str, hashed: str) -> bool:
    """Verify a plaintext password against a passlib bcrypt hash."""
    try:
        from passlib.context import CryptContext
        ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        return ctx.verify(plain, hashed)
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Password verification requires passlib[bcrypt]. Install with: pip install passlib[bcrypt]",
        )


def _hash_password(plain: str) -> str:
    """Return a bcrypt hash of *plain*."""
    try:
        from passlib.context import CryptContext
        ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        return ctx.hash(plain)
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Password hashing requires passlib[bcrypt]. Install with: pip install passlib[bcrypt]",
        )


# ── Endpoints ──

@router.post("/auth/login", response_model=TokenResponse)
async def login(body: LoginRequest, db=Depends(get_db)):
    """Authenticate a user and return a JWT access token.

    When ``TESSERA_AUTH_ENABLED`` is *false* (the default), any credentials
    are accepted and the returned token carries ``role=admin`` — handy for
    local development.

    In standalone mode (no database) the demo credentials configured via
    ``TESSERA_ADMIN_EMAIL`` / ``TESSERA_ADMIN_PASSWORD`` are accepted.

    In DB mode the user is looked up by email and the password is verified
    against the stored bcrypt hash.
    """
    # Dev convenience: auth disabled -> accept anything
    if not _auth_enabled():
        logger.info("Auth disabled — issuing admin token for %s", body.email)
        token = create_access_token(
            user_id="dev-user",
            email=body.email,
            role="admin",
        )
        return TokenResponse(access_token=token)

    # Standalone mode (no DB) — demo credentials only
    if db is None:
        if _DEMO_PASSWORD == "admin":
            logger.warning(
                "Demo mode is active with default credentials (admin/admin). "
                "Set TESSERA_ADMIN_EMAIL and TESSERA_ADMIN_PASSWORD environment variables "
                "to use stronger credentials."
            )
        if body.email == _DEMO_EMAIL and body.password == _DEMO_PASSWORD:
            token = create_access_token(
                user_id="demo-admin",
                email=_DEMO_EMAIL,
                role="admin",
            )
            return TokenResponse(access_token=token)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    # DB mode — look up user
    try:
        from tessera.db.crud.users import get_user_by_email
        user = get_user_by_email(db, body.email)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error while looking up user",
        )

    if user is None or not _verify_password(body.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled",
        )

    token = create_access_token(
        user_id=str(user.id),
        email=user.email,
        role=user.role,
        org_id=user.org_id,
    )
    logger.info("User logged in: %s", user.email)
    return TokenResponse(access_token=token)


@router.post("/auth/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(body: RegisterRequest, db=Depends(get_db)):
    """Register a new user account.

    Only available in DB mode. Returns ``501 Not Implemented`` in standalone
    mode because there is no persistent user store.
    """
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Registration requires a database. Set TESSERA_DATABASE_URL to enable.",
        )

    try:
        from tessera.db.crud.users import create_user, get_user_by_email

        existing = get_user_by_email(db, body.email)
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A user with this email already exists",
            )

        hashed = _hash_password(body.password)
        user = create_user(db, email=body.email, hashed_password=hashed, role=body.role)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Registration failed for %s", body.email)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {exc}",
        )

    token = create_access_token(
        user_id=str(user.id),
        email=user.email,
        role=user.role,
        org_id=user.org_id,
    )
    logger.info("New user registered: %s (role=%s)", user.email, user.role)
    return TokenResponse(access_token=token)


@router.post("/auth/refresh", response_model=TokenResponse)
async def refresh_token(user: dict = Depends(require_auth)):
    """Return a fresh access token for an authenticated user.

    The caller must provide a valid (non-expired) JWT in the
    ``Authorization: Bearer <token>`` header. A new token is minted with
    a full expiration window.
    """
    token = create_access_token(
        user_id=user["sub"],
        email=user["email"],
        role=user["role"],
        org_id=user.get("org_id"),
    )
    logger.info("Token refreshed for %s", user["email"])
    return TokenResponse(access_token=token)


@router.get("/auth/me", response_model=UserInfo)
async def me(user: dict = Depends(require_auth)):
    """Return information about the currently authenticated user."""
    return UserInfo(
        user_id=user["sub"],
        email=user["email"],
        role=user["role"],
        org_id=user.get("org_id"),
    )


# ── GitHub OAuth endpoints ──


class GitHubStatusResponse(BaseModel):
    configured: bool
    authorization_url: str = ""


@router.get("/auth/github/status", response_model=GitHubStatusResponse)
async def github_status():
    """Check if GitHub OAuth is configured and return the authorization URL."""
    configured = bool(_GITHUB_CLIENT_ID and _GITHUB_CLIENT_SECRET)
    auth_url = ""
    if configured:
        state = secrets.token_urlsafe(32)
        _store_oauth_state(state)
        redirect_uri = _GITHUB_REDIRECT_URI or f"{_FRONTEND_URL}/api/v1/auth/github/callback"
        from urllib.parse import urlencode
        params = {
            "client_id": _GITHUB_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "scope": "read:user user:email",
            "state": state,
        }
        auth_url = f"https://github.com/login/oauth/authorize?{urlencode(params)}"
    return GitHubStatusResponse(configured=configured, authorization_url=auth_url)


@router.get("/auth/github")
async def github_login():
    """Redirect to GitHub OAuth authorization page."""
    if not _GITHUB_CLIENT_ID:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="GitHub OAuth is not configured. Set TESSERA_GITHUB_CLIENT_ID and TESSERA_GITHUB_CLIENT_SECRET environment variables.",
        )

    state = secrets.token_urlsafe(32)
    _store_oauth_state(state)
    redirect_uri = _GITHUB_REDIRECT_URI or f"{_FRONTEND_URL}/api/v1/auth/github/callback"

    from urllib.parse import urlencode
    params = {
        "client_id": _GITHUB_CLIENT_ID,
        "redirect_uri": redirect_uri,
        "scope": "read:user user:email",
        "state": state,
    }
    url = f"https://github.com/login/oauth/authorize?{urlencode(params)}"
    return RedirectResponse(url=url)


@router.get("/auth/github/callback")
async def github_callback(code: str = "", state: str = "", error: str = ""):
    """Handle GitHub OAuth callback — exchange code for token, create JWT."""
    if error:
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=github_denied")

    if not code:
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=missing_code")

    if not state or not _validate_oauth_state(state):
        logger.warning("GitHub OAuth callback with invalid or expired state parameter")
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=invalid_state")

    if not _GITHUB_CLIENT_ID or not _GITHUB_CLIENT_SECRET:
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=github_not_configured")

    try:
        import httpx

        # Exchange code for access token
        async with httpx.AsyncClient() as client:
            token_resp = await client.post(
                "https://github.com/login/oauth/access_token",
                json={
                    "client_id": _GITHUB_CLIENT_ID,
                    "client_secret": _GITHUB_CLIENT_SECRET,
                    "code": code,
                },
                headers={"Accept": "application/json"},
            )
            token_data = token_resp.json()

        gh_access_token = token_data.get("access_token")
        if not gh_access_token:
            logger.error("GitHub token exchange failed: %s", token_data)
            return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=token_exchange_failed")

        # Fetch user profile from GitHub
        async with httpx.AsyncClient() as client:
            user_resp = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {gh_access_token}",
                    "Accept": "application/json",
                },
            )
            gh_user = user_resp.json()

            # Fetch primary email if not public
            email = gh_user.get("email")
            if not email:
                emails_resp = await client.get(
                    "https://api.github.com/user/emails",
                    headers={
                        "Authorization": f"Bearer {gh_access_token}",
                        "Accept": "application/json",
                    },
                )
                emails = emails_resp.json()
                for e in emails:
                    if e.get("primary") and e.get("verified"):
                        email = e["email"]
                        break
                if not email and emails:
                    email = emails[0].get("email", "")

        if not email:
            return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=no_email")

        # Create Tessera JWT for the GitHub user
        github_id = str(gh_user.get("id", ""))
        username = gh_user.get("login", "")
        tessera_token = create_access_token(
            user_id=f"github-{github_id}",
            email=email,
            role="analyst",
        )

        logger.info("GitHub OAuth login: %s (%s)", username, email)

        # Redirect to frontend with token
        from urllib.parse import urlencode
        params = urlencode({
            "token": tessera_token,
            "provider": "github",
            "email": email,
        })
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?{params}")

    except Exception:
        logger.exception("GitHub OAuth callback error")
        return RedirectResponse(url=f"{_FRONTEND_URL}/login?error=github_error")
