"""Report generation endpoints."""

from __future__ import annotations

import tempfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response

from tessera.api.deps import get_scan
from tessera.reports import (
    write_docx,
    write_executive_docx,
    write_executive_html,
    write_html,
)

router = APIRouter(tags=["reports"])


@router.get("/reports/{scan_id}")
async def get_report(
    scan_id: str,
    format: str = Query("json", pattern="^(json|html|docx)$"),
):
    """Download a scan report in the specified format."""
    scan = get_scan(scan_id)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    result = scan.get("result")
    if not result:
        raise HTTPException(status_code=400, detail="Scan has no results yet")

    if format == "json":
        return JSONResponse(content=result)

    # Generate file in temp directory, read content before cleanup
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)

        if format == "html":
            path = tmppath / "report.html"
            if result.get("mode") == "per-model":
                write_executive_html(result, path)
            else:
                write_html(result, path)
            content = path.read_text(encoding="utf-8")
            return HTMLResponse(content=content)

        if format == "docx":
            path = tmppath / "report.docx"
            try:
                if result.get("mode") == "per-model":
                    write_executive_docx(result, path)
                else:
                    write_docx(result, path)
            except ImportError:
                raise HTTPException(status_code=500, detail="python-docx not installed")
            content = path.read_bytes()
            return Response(
                content=content,
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                headers={
                    "Content-Disposition": f'attachment; filename="tessera-{scan_id[:8]}.docx"',
                },
            )
