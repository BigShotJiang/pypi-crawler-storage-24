"""Model registry endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from tessera.api.deps import delete_model, get_model, list_models, store_model

router = APIRouter(tags=["models"])


class ModelCreateRequest(BaseModel):
    name: str
    arch: str = ""
    model_type: str = "cv"
    server_type: str = ""
    url: str = ""
    task: str = ""
    config: dict[str, Any] = Field(default_factory=dict)


@router.post("/models")
async def create_model(request: ModelCreateRequest):
    """Register a new model endpoint."""
    model_id = store_model(request.model_dump())
    return {"id": model_id, **request.model_dump()}


@router.get("/models")
async def get_models():
    """List all registered models."""
    return {"models": list_models()}


@router.get("/models/{model_id}")
async def get_model_detail(model_id: str):
    """Get model details."""
    model = get_model(model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    return model


@router.delete("/models/{model_id}")
async def remove_model(model_id: str):
    """Delete a registered model."""
    if not delete_model(model_id):
        raise HTTPException(status_code=404, detail="Model not found")
    return {"deleted": True}
