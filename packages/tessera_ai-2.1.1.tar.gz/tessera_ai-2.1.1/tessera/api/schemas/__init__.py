"""Tessera API schemas."""
