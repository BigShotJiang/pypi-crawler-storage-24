"""
Tessera — FastAPI application factory.
"""

import json
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from tessera import __version__

_DEFAULT_CORS_ORIGINS = "http://localhost:3000,http://localhost:5173"


class NumpySafeEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types from scan results."""

    def default(self, obj):
        try:
            import numpy as np
            if isinstance(obj, (np.integer,)):
                return int(obj)
            if isinstance(obj, (np.floating,)):
                return float(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
        except ImportError:
            pass
        return super().default(obj)


class NumpySafeResponse(JSONResponse):
    """JSONResponse that serializes numpy types."""

    def render(self, content) -> bytes:
        return json.dumps(
            content,
            ensure_ascii=False,
            allow_nan=False,
            cls=NumpySafeEncoder,
        ).encode("utf-8")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    # Configure structured logging first
    from tessera.logging import setup_logging
    setup_logging()

    # Startup: initialize DB if configured
    from tessera.api.deps import init_db
    await init_db()
    # Initialize WebSocket broadcaster
    from tessera.api.websocket import _init_ws_broadcaster
    _init_ws_broadcaster()
    yield
    # Shutdown: cleanup


def create_app() -> FastAPI:
    """Application factory — use with uvicorn tessera.api.app:create_app --factory."""
    app = FastAPI(
        title="Tessera",
        description="OWASP AI Security Testing Framework API",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
        default_response_class=NumpySafeResponse,
    )

    # ── Production middleware (outermost first) ──
    from tessera.api.middleware import (
        RequestIdMiddleware,
        RequestLoggingMiddleware,
        SecurityHeadersMiddleware,
    )
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(RequestIdMiddleware)

    # CORS — read allowed origins from env, default to localhost dev servers
    cors_origins_raw = os.environ.get("TESSERA_CORS_ORIGINS", _DEFAULT_CORS_ORIGINS)
    cors_origins = [o.strip() for o in cors_origins_raw.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register routers
    from tessera.api.routers import (
        auth,
        config,
        health,
        models,
        reports,
        results,
        scans,
    )
    app.include_router(health.router)
    app.include_router(auth.router, prefix="/api/v1")
    app.include_router(scans.router, prefix="/api/v1")
    app.include_router(models.router, prefix="/api/v1")
    app.include_router(results.router, prefix="/api/v1")
    app.include_router(reports.router, prefix="/api/v1")
    app.include_router(config.router, prefix="/api/v1")

    # WebSocket
    from tessera.api.websocket import register_websocket
    register_websocket(app)

    return app
