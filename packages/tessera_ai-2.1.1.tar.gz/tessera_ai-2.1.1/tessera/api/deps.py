"""
Tessera — Dependency injection for API routes.

Provides database sessions and shared state.
Works without a database (standalone mode) when TESSERA_DATABASE_URL is not set.
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime

# In-memory store for standalone mode (no DB)
_scans: dict[str, dict] = {}
_models_store: dict[str, dict] = {}
_configs: dict[str, dict] = {}

# Database engine (set on startup if DB URL is configured)
_db_engine = None
_session_factory = None


def get_database_url() -> str | None:
    """Get database URL from environment."""
    return os.environ.get("TESSERA_DATABASE_URL")


def is_db_configured() -> bool:
    return get_database_url() is not None


async def init_db():
    """Initialize database connection if configured."""
    global _db_engine, _session_factory
    db_url = get_database_url()
    if not db_url:
        return

    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        _db_engine = create_engine(db_url, echo=False)
        _session_factory = sessionmaker(bind=_db_engine, expire_on_commit=False)
    except ImportError:
        pass


async def get_db():
    """Yield a database session if configured, else None."""
    if _session_factory:
        session = _session_factory()
        try:
            yield session
        finally:
            session.close()
    else:
        yield None


# ── In-memory store operations (standalone mode) ──

def store_scan(scan_data: dict) -> str:
    scan_id = scan_data.get("scan_id", str(uuid.uuid4()))
    scan_data["scan_id"] = scan_id
    scan_data["created_at"] = datetime.now().isoformat()
    _scans[scan_id] = scan_data
    return scan_id


def get_scan(scan_id: str) -> dict | None:
    return _scans.get(scan_id)


def list_scans(skip: int = 0, limit: int = 20) -> list[dict]:
    all_scans = sorted(_scans.values(), key=lambda s: s.get("created_at", ""), reverse=True)
    return all_scans[skip:skip + limit]


def update_scan(scan_id: str, updates: dict):
    if scan_id in _scans:
        _scans[scan_id].update(updates)


def delete_scan(scan_id: str) -> bool:
    return _scans.pop(scan_id, None) is not None


def store_model(model_data: dict) -> str:
    model_id = model_data.get("id", str(uuid.uuid4()))
    model_data["id"] = model_id
    _models_store[model_id] = model_data
    return model_id


def get_model(model_id: str) -> dict | None:
    return _models_store.get(model_id)


def list_models() -> list[dict]:
    return list(_models_store.values())


def delete_model(model_id: str) -> bool:
    return _models_store.pop(model_id, None) is not None


def store_config(config_data: dict) -> str:
    config_id = config_data.get("id", str(uuid.uuid4()))
    config_data["id"] = config_id
    _configs[config_id] = config_data
    return config_id


def get_config(config_id: str) -> dict | None:
    return _configs.get(config_id)


def list_configs() -> list[dict]:
    return list(_configs.values())
