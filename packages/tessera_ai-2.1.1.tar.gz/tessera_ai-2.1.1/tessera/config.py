"""
Tessera — Config loader with environment variable expansion.

Supports ${VAR} and ${VAR:-default} syntax in YAML values.
"""

import os
import re

import yaml

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def _expand_env(value):
    """Expand ${VAR} and ${VAR:-default} in a string value."""
    if not isinstance(value, str):
        return value

    def _replace(match):
        expr = match.group(1)
        if ":-" in expr:
            var_name, default = expr.split(":-", 1)
            return os.environ.get(var_name.strip(), default)
        return os.environ.get(expr.strip(), match.group(0))

    return _ENV_PATTERN.sub(_replace, value)


def _expand_recursive(obj):
    """Recursively expand env vars in a nested dict/list."""
    if isinstance(obj, dict):
        return {k: _expand_recursive(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_recursive(item) for item in obj]
    if isinstance(obj, str):
        return _expand_env(obj)
    return obj


def load_config(path: str = "config.yaml") -> dict:
    """Load a YAML config file with ${ENV_VAR} expansion.

    Args:
        path: Path to the YAML config file.

    Returns:
        Config dict with all environment variables expanded.
    """
    with open(path) as f:
        raw = yaml.safe_load(f)
    return _expand_recursive(raw or {})
