"""
Tessera — Pydantic schemas for API and engine data exchange.

These wrap the existing dataclasses in tests/base.py (Metric, PhaseResult,
TestResult) for JSON serialization and API validation.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field

# ── Enums ──

class ScanStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TestStatus(str, enum.Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"
    ERROR = "ERROR"
    NA = "N/A"
    NOT_RUN = "NOT_RUN"


class ModelType(str, enum.Enum):
    CV = "cv"
    LLM = "llm"


# ── Model schemas ──

class ModelConfig(BaseModel):
    """Configuration for a single model endpoint."""
    name: str
    arch: str = ""
    model_type: ModelType = ModelType.CV
    server_type: str = ""  # triton, vllm, ollama, custom, etc.
    url: str = ""
    task: str = ""
    config: dict[str, Any] = Field(default_factory=dict)


# ── Scan schemas ──

class ScanRequest(BaseModel):
    """Request to create and run a scan."""
    test_ids: list[str] = Field(default_factory=list)
    category: Optional[str] = None
    phases: list[int] = Field(default_factory=lambda: [1, 2, 3])
    config_path: str = "config.yaml"
    config_override: dict[str, Any] = Field(default_factory=dict)
    output_dir: str = "reports"
    formats: list[str] = Field(default_factory=lambda: ["json"])
    per_model: bool = False
    model_filter: list[str] = Field(default_factory=list)
    model_type_filter: Optional[str] = None


class MetricResult(BaseModel):
    """Single metric from a test phase."""
    name: str
    value: float
    threshold_pass: float = 0.0
    threshold_fail: float = 0.0
    unit: str = ""
    operator: str = "<"
    source: str = ""
    status: str = ""


class PhaseResultSchema(BaseModel):
    """Result of one test phase."""
    phase: int
    name: str
    status: str = "NOT_RUN"
    metrics: list[MetricResult] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    duration_sec: float = 0.0
    error: str = ""


class TestResultSchema(BaseModel):
    """Complete result of a single test case."""
    test_id: str
    test_name: str
    category: str
    owasp_ref: str
    status: str = "NOT_RUN"
    phases: list[PhaseResultSchema] = Field(default_factory=list)
    tools_used: list[str] = Field(default_factory=list)
    recommendations: list[Any] = Field(default_factory=list)
    timestamp: str = ""
    duration_sec: float = 0.0
    error: str = ""
    model_name: str = ""
    model_arch: str = ""
    model_type: str = ""
    model_task: str = ""


class ScanSummary(BaseModel):
    """Aggregate counts for a scan."""
    total: int = 0
    passed: int = Field(0, alias="pass")
    fail: int = 0
    warn: int = 0
    error: int = 0
    na: int = 0

    model_config = {"populate_by_name": True}


class ScanResult(BaseModel):
    """Complete scan result returned by the engine."""
    scan_id: str = ""
    framework: str = "Tessera"
    version: str = "2.0.0"
    project: dict[str, Any] = Field(default_factory=dict)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    total_duration_sec: float = 0.0
    status: ScanStatus = ScanStatus.COMPLETED
    summary: ScanSummary = Field(default_factory=ScanSummary)
    tests: list[TestResultSchema] = Field(default_factory=list)
    model: dict[str, Any] = Field(default_factory=dict)
    # Per-model mode fields
    mode: str = "flat"
    models_tested: int = 0
    models_total: int = 0
    matrix: dict[str, dict[str, str]] = Field(default_factory=dict)
    per_model_summary: dict[str, Any] = Field(default_factory=dict)


class ScanProgress(BaseModel):
    """Real-time progress update for WebSocket streaming."""
    scan_id: str
    status: ScanStatus
    current_test: str = ""
    current_model: str = ""
    tests_completed: int = 0
    tests_total: int = 0
    models_completed: int = 0
    models_total: int = 0
    message: str = ""
