"""Tessera — Structured JSON logging."""

from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime, timezone
from typing import Any


class JSONFormatter(logging.Formatter):
    """Format log records as single-line JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Include exception info if present
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Merge extra fields (skip standard LogRecord attributes)
        _standard = {
            "name", "msg", "args", "created", "relativeCreated", "exc_info",
            "exc_text", "stack_info", "lineno", "funcName", "pathname",
            "filename", "module", "thread", "threadName", "process",
            "processName", "levelname", "levelno", "msecs", "message",
            "taskName",
        }
        for key, value in record.__dict__.items():
            if key not in _standard and not key.startswith("_"):
                log_entry[key] = value

        return json.dumps(log_entry, default=str)


class TextFormatter(logging.Formatter):
    """Human-readable formatter for development use."""

    FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

    def __init__(self) -> None:
        super().__init__(fmt=self.FORMAT, datefmt=self.DATE_FORMAT)


def setup_logging() -> None:
    """Configure Python logging based on environment variables.

    Environment variables:
        TESSERA_LOG_LEVEL  — DEBUG, INFO, WARNING, ERROR, CRITICAL (default: INFO)
        TESSERA_LOG_FORMAT — ``json`` or ``text`` (default: text)
    """
    level_name = os.environ.get("TESSERA_LOG_LEVEL", "INFO").upper()
    log_format = os.environ.get("TESSERA_LOG_FORMAT", "text").lower()

    level = getattr(logging, level_name, logging.INFO)

    # Choose formatter
    if log_format == "json":
        formatter: logging.Formatter = JSONFormatter()
    else:
        formatter = TextFormatter()

    # Configure root logger
    root = logging.getLogger()
    root.setLevel(level)

    # Remove existing handlers to avoid duplicate output on re-init
    for handler in root.handlers[:]:
        root.removeHandler(handler)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(formatter)
    root.addHandler(handler)

    # Quiet down noisy third-party loggers
    for noisy in ("uvicorn.access", "uvicorn.error", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(max(level, logging.WARNING))

    logging.getLogger("tessera").info(
        "Logging initialised — level=%s format=%s", level_name, log_format,
    )


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger for the given module/component.

    Usage::

        from tessera.logging import get_logger
        logger = get_logger(__name__)
        logger.info("scan started", extra={"scan_id": sid})
    """
    return logging.getLogger(name)
