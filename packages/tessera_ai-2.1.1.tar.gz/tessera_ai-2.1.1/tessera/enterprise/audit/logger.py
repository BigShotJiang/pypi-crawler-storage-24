"""
Audit logging — tracks who ran what, when, from where.
"""

from __future__ import annotations

import os


def log_action(
    action: str,
    user_id: str = None,
    resource_type: str = "",
    resource_id: str = "",
    details: dict = None,
    ip_address: str = "",
):
    """Log an audit event to the database."""
    db_url = os.environ.get("TESSERA_DATABASE_URL")
    if not db_url:
        return

    try:
        from tessera.db.engine import SessionLocal
        from tessera.db.models import AuditLog

        db = SessionLocal()
        try:
            log = AuditLog(
                user_id=user_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                details=details or {},
                ip_address=ip_address,
            )
            db.add(log)
            db.commit()
        finally:
            db.close()
    except Exception:
        pass


def get_audit_logs(
    user_id: str = None,
    action: str = None,
    resource_type: str = None,
    limit: int = 100,
) -> list[dict]:
    """Query audit logs with filtering."""
    try:
        from tessera.db.engine import SessionLocal
        from tessera.db.models import AuditLog

        db = SessionLocal()
        try:
            q = db.query(AuditLog)
            if user_id:
                q = q.filter(AuditLog.user_id == user_id)
            if action:
                q = q.filter(AuditLog.action == action)
            if resource_type:
                q = q.filter(AuditLog.resource_type == resource_type)
            logs = q.order_by(AuditLog.timestamp.desc()).limit(limit).all()
            return [
                {
                    "id": log.id,
                    "user_id": log.user_id,
                    "action": log.action,
                    "resource_type": log.resource_type,
                    "resource_id": log.resource_id,
                    "details": log.details,
                    "ip_address": log.ip_address,
                    "timestamp": log.timestamp.isoformat() if log.timestamp else "",
                }
                for log in logs
            ]
        finally:
            db.close()
    except Exception:
        return []
