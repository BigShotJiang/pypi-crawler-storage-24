"""
Multi-tenant middleware — isolates data by org_id.

Injects org_id from the authenticated user's token into all DB queries
via a request-scoped context.
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

# Current org context (set per-request)
current_org_id: ContextVar[Optional[str]] = ContextVar("current_org_id", default=None)


class TenantMiddleware(BaseHTTPMiddleware):
    """Extract org_id from JWT and set in request context."""

    async def dispatch(self, request: Request, call_next):
        # Try to extract org_id from auth header
        org_id = None
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            try:
                from tessera.enterprise.auth.jwt import decode_token
                payload = decode_token(auth_header[7:])
                org_id = payload.get("org_id")
            except Exception:
                pass

        token = current_org_id.set(org_id)
        try:
            response = await call_next(request)
            return response
        finally:
            current_org_id.reset(token)


def get_current_org_id() -> Optional[str]:
    """Get the org_id for the current request."""
    return current_org_id.get()
