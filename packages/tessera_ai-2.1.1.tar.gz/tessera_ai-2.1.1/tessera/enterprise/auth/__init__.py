"""Enterprise authentication — JWT, SSO, RBAC."""
