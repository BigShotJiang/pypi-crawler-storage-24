"""
JWT authentication for API access.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_logger = logging.getLogger(__name__)

security = HTTPBearer(auto_error=False)

_DEFAULT_SECRET = "tessera-dev-secret-change-in-production"
SECRET_KEY = os.environ.get("TESSERA_JWT_SECRET", _DEFAULT_SECRET)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24

if SECRET_KEY == _DEFAULT_SECRET:
    _env = os.environ.get("TESSERA_ENV", "development").lower()
    if _env == "production":
        _logger.critical(
            "FATAL: TESSERA_JWT_SECRET is set to the default value. "
            "Set a strong secret via the TESSERA_JWT_SECRET environment variable before running in production."
        )
        sys.exit(1)
    else:
        _logger.warning(
            "WARNING: Using default JWT secret. This is acceptable for development but MUST be "
            "changed in production. Set TESSERA_JWT_SECRET to a random 256-bit key."
        )


def create_access_token(user_id: str, email: str, role: str, org_id: str = None) -> str:
    """Create a JWT access token."""
    from jose import jwt

    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "org_id": org_id,
        "exp": datetime.now(timezone.utc) + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    """Decode and validate a JWT token."""
    from jose import JWTError, jwt

    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {e}",
        )


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[dict]:
    """Extract current user from JWT token. Returns None if no auth."""
    if not credentials:
        return None
    return decode_token(credentials.credentials)


async def require_auth(
    user: Optional[dict] = Depends(get_current_user),
) -> dict:
    """Require authenticated user."""
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    return user


async def require_role(role: str):
    """Factory for role-checking dependencies."""
    async def _check(user: dict = Depends(require_auth)):
        roles = {"viewer": 0, "analyst": 1, "admin": 2}
        if roles.get(user.get("role", "viewer"), 0) < roles.get(role, 0):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Role '{role}' required")
        return user
    return _check
