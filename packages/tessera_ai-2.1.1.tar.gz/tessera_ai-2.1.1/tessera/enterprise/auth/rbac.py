"""
Role-Based Access Control.

Roles: admin, analyst, viewer
"""

from __future__ import annotations

# Permission matrix: role -> allowed actions
PERMISSIONS = {
    "admin": {
        "scans.create", "scans.read", "scans.delete",
        "models.create", "models.read", "models.delete",
        "results.read",
        "reports.read", "reports.download",
        "config.read", "config.write",
        "users.create", "users.read", "users.update", "users.delete",
        "audit.read",
        "schedule.create", "schedule.read", "schedule.delete",
    },
    "analyst": {
        "scans.create", "scans.read",
        "models.create", "models.read",
        "results.read",
        "reports.read", "reports.download",
        "config.read",
        "schedule.read",
    },
    "viewer": {
        "scans.read",
        "models.read",
        "results.read",
        "reports.read",
    },
}


def has_permission(role: str, action: str) -> bool:
    """Check if a role has permission for an action."""
    return action in PERMISSIONS.get(role, set())


def get_permissions(role: str) -> set[str]:
    """Get all permissions for a role."""
    return PERMISSIONS.get(role, set())
