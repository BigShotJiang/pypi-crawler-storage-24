"""
SSO integration — SAML and OIDC support (Enterprise tier).
"""

from __future__ import annotations

import os


class OIDCProvider:
    """OpenID Connect authentication provider."""

    def __init__(
        self,
        issuer: str = None,
        client_id: str = None,
        client_secret: str = None,
        redirect_uri: str = None,
    ):
        self.issuer = issuer or os.environ.get("TESSERA_OIDC_ISSUER", "")
        self.client_id = client_id or os.environ.get("TESSERA_OIDC_CLIENT_ID", "")
        self.client_secret = client_secret or os.environ.get("TESSERA_OIDC_CLIENT_SECRET", "")
        self.redirect_uri = redirect_uri or os.environ.get("TESSERA_OIDC_REDIRECT_URI", "")

    @property
    def is_configured(self) -> bool:
        return bool(self.issuer and self.client_id)

    def get_authorization_url(self, state: str = "") -> str:
        """Build the OIDC authorization URL."""
        from urllib.parse import urlencode
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "scope": "openid email profile",
            "redirect_uri": self.redirect_uri,
            "state": state,
        }
        return f"{self.issuer}/authorize?{urlencode(params)}"

    async def exchange_code(self, code: str) -> dict:
        """Exchange authorization code for tokens."""
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.issuer}/token",
                data={
                    "grant_type": "authorization_code",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "code": code,
                    "redirect_uri": self.redirect_uri,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def get_userinfo(self, access_token: str) -> dict:
        """Fetch user info from OIDC provider."""
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.issuer}/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            resp.raise_for_status()
            return resp.json()
