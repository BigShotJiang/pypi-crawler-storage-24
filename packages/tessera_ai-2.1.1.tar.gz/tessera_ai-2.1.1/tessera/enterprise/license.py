"""
Tessera — License validation.

Simple JWT-based license validation. TESSERA_LICENSE_KEY env var contains
a signed JWT with tier, org, expiry, and limits.

Trust-based B2B model — no DRM, no call-home.
"""

from __future__ import annotations

import os

_LICENSE_CACHE: dict | None = None


def _decode_license(token: str) -> dict | None:
    """Decode and validate license JWT."""
    try:
        from jose import jwt
        # Public key for verification (distributed with the product)
        # In production, this would be an RSA public key
        payload = jwt.decode(
            token,
            os.environ.get("TESSERA_LICENSE_PUBLIC_KEY", "tessera-dev-key"),
            algorithms=["HS256"],
            options={"verify_exp": True},
        )
        return payload
    except Exception:
        return None


def get_license() -> dict | None:
    """Get the current license payload, cached."""
    global _LICENSE_CACHE
    if _LICENSE_CACHE is not None:
        return _LICENSE_CACHE

    token = os.environ.get("TESSERA_LICENSE_KEY")
    if not token:
        return None

    _LICENSE_CACHE = _decode_license(token)
    return _LICENSE_CACHE


def is_enterprise_licensed() -> bool:
    """Check if a valid enterprise license is present."""
    license_data = get_license()
    if not license_data:
        return False
    return license_data.get("tier") in ("pro", "enterprise")


def get_license_tier() -> str:
    """Return the current tier: 'community', 'pro', or 'enterprise'."""
    license_data = get_license()
    if not license_data:
        return "community"
    return license_data.get("tier", "community")


def require_tier(minimum: str) -> bool:
    """Check if current license meets minimum tier requirement."""
    tiers = {"community": 0, "pro": 1, "enterprise": 2}
    current = get_license_tier()
    return tiers.get(current, 0) >= tiers.get(minimum, 0)


def get_model_limit() -> int:
    """Get max number of models allowed by license."""
    tier = get_license_tier()
    limits = {"community": 10, "pro": 100, "enterprise": 999999}
    license_data = get_license()
    if license_data and "max_models" in license_data:
        return license_data["max_models"]
    return limits.get(tier, 10)
