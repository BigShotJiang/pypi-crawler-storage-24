"""
ISO 27001:2022 — Annex A controls mapping for AI systems.
"""

ISO27001_MAPPING = {
    "INF-01": {"control": "A.8.19", "title": "Installation of software on operational systems", "description": "Supply chain integrity for ML dependencies"},
    "INF-02": {"control": "A.8.10", "title": "Information deletion", "description": "Secure model storage and lifecycle"},
    "INF-03": {"control": "A.8.26", "title": "Application security requirements", "description": "API security for AI services"},
    "INF-04": {"control": "A.8.6", "title": "Capacity management", "description": "Resource exhaustion prevention"},
    "MOD-01": {"control": "A.8.12", "title": "Data leakage prevention", "description": "Adversarial evasion attack protection"},
    "MOD-02": {"control": "A.8.11", "title": "Data masking", "description": "Training data poisoning prevention"},
    "MOD-06": {"control": "A.8.16", "title": "Monitoring activities", "description": "Model drift and performance monitoring"},
    "APP-01": {"control": "A.8.28", "title": "Secure coding", "description": "Prompt injection prevention"},
    "APP-03": {"control": "A.8.11", "title": "Data masking", "description": "Sensitive data disclosure prevention"},
    "DAT-02": {"control": "A.8.11", "title": "Data masking", "description": "PII leakage in AI outputs"},
    "DAT-03": {"control": "A.5.12", "title": "Classification of information", "description": "Data lineage and classification"},
    "DAT-04": {"control": "A.8.10", "title": "Information deletion", "description": "Right to erasure in ML models"},
}


def get_compliance_report(test_results: list[dict]) -> dict:
    findings = []
    for result in test_results:
        test_id = result.get("test_id", "")
        mapping = ISO27001_MAPPING.get(test_id)
        if mapping:
            findings.append({
                "test_id": test_id,
                "test_status": result.get("status", ""),
                "control": mapping["control"],
                "title": mapping["title"],
                "description": mapping["description"],
                "implemented": result.get("status") in ("PASS", "N/A"),
            })

    implemented = sum(1 for f in findings if f["implemented"])
    return {
        "framework": "ISO 27001:2022",
        "total_controls": len(findings),
        "implemented": implemented,
        "gaps": len(findings) - implemented,
        "score": round(implemented / max(len(findings), 1) * 100, 1),
        "findings": findings,
    }
