"""
NIST AI Risk Management Framework (AI RMF 1.0) compliance mapping.
"""

NIST_AI_RMF_MAPPING = {
    "MOD-01": {
        "function": "MANAGE",
        "category": "MG-2.3 — Risks from Adversarial Attacks",
        "subcategory": "Robustness against evasion attacks",
    },
    "MOD-02": {
        "function": "MANAGE",
        "category": "MG-2.3 — Data Integrity",
        "subcategory": "Data poisoning detection and mitigation",
    },
    "MOD-03": {
        "function": "MAP",
        "category": "MP-4.1 — Data Quality",
        "subcategory": "Training data quality and integrity verification",
    },
    "MOD-06": {
        "function": "MEASURE",
        "category": "MS-2.6 — Performance Monitoring",
        "subcategory": "Continuous monitoring for model drift and degradation",
    },
    "MOD-07": {
        "function": "GOVERN",
        "category": "GV-3.2 — Value Alignment",
        "subcategory": "AI system alignment with organizational values",
    },
    "APP-01": {
        "function": "MANAGE",
        "category": "MG-2.3 — Input Validation",
        "subcategory": "Protection against prompt injection attacks",
    },
    "APP-03": {
        "function": "MANAGE",
        "category": "MG-3.1 — Data Privacy",
        "subcategory": "Prevention of sensitive information disclosure",
    },
    "APP-10": {
        "function": "MEASURE",
        "category": "MS-2.11 — Bias and Fairness",
        "subcategory": "Bias detection across demographic groups",
    },
    "APP-14": {
        "function": "MEASURE",
        "category": "MS-2.8 — Explainability",
        "subcategory": "Model decision explainability and interpretability",
    },
    "INF-01": {
        "function": "MANAGE",
        "category": "MG-3.2 — Supply Chain",
        "subcategory": "Third-party AI component risk management",
    },
    "INF-03": {
        "function": "MANAGE",
        "category": "MG-2.4 — API Security",
        "subcategory": "Securing AI system interfaces and endpoints",
    },
    "DAT-02": {
        "function": "GOVERN",
        "category": "GV-6.1 — Privacy",
        "subcategory": "PII leakage prevention in AI outputs",
    },
    "DAT-03": {
        "function": "MAP",
        "category": "MP-4.2 — Data Provenance",
        "subcategory": "Data lineage tracking and documentation",
    },
}


def get_compliance_report(test_results: list[dict]) -> dict:
    """Generate NIST AI RMF compliance report from test results."""
    findings = []
    for result in test_results:
        test_id = result.get("test_id", "")
        mapping = NIST_AI_RMF_MAPPING.get(test_id)
        if mapping:
            findings.append({
                "test_id": test_id,
                "test_name": result.get("test_name", ""),
                "test_status": result.get("status", ""),
                "function": mapping["function"],
                "category": mapping["category"],
                "subcategory": mapping["subcategory"],
                "addressed": result.get("status") in ("PASS", "N/A"),
            })

    addressed = sum(1 for f in findings if f["addressed"])
    by_function = {}
    for f in findings:
        fn = f["function"]
        if fn not in by_function:
            by_function[fn] = {"total": 0, "addressed": 0}
        by_function[fn]["total"] += 1
        if f["addressed"]:
            by_function[fn]["addressed"] += 1

    return {
        "framework": "NIST AI RMF 1.0",
        "total_requirements": len(findings),
        "addressed": addressed,
        "gaps": len(findings) - addressed,
        "score": round(addressed / max(len(findings), 1) * 100, 1),
        "by_function": by_function,
        "findings": findings,
    }
