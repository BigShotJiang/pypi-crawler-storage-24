"""
SOC 2 Type II — Trust Service Criteria mapping for AI systems.
"""

SOC2_MAPPING = {
    "INF-01": {"criteria": "CC8.1", "principle": "Change Management", "description": "Supply chain and dependency integrity"},
    "INF-02": {"criteria": "CC6.1", "principle": "Logical Access", "description": "Model storage access controls"},
    "INF-03": {"criteria": "CC6.6", "principle": "System Boundaries", "description": "API security and boundary protection"},
    "INF-04": {"criteria": "A1.2", "principle": "Availability", "description": "Resource exhaustion prevention"},
    "INF-06": {"criteria": "CC6.7", "principle": "Data Protection", "description": "Model theft and IP protection"},
    "DAT-01": {"criteria": "P3.1", "principle": "Privacy — Notice", "description": "Consent management for AI training data"},
    "DAT-02": {"criteria": "P4.3", "principle": "Privacy — Use", "description": "PII leakage prevention"},
    "DAT-03": {"criteria": "PI1.3", "principle": "Processing Integrity", "description": "Data lineage and provenance"},
    "DAT-05": {"criteria": "P5.1", "principle": "Privacy — Retention", "description": "Data minimization practices"},
    "MOD-01": {"criteria": "CC7.2", "principle": "System Operations", "description": "Adversarial attack detection"},
    "MOD-06": {"criteria": "CC7.1", "principle": "System Operations", "description": "Model performance monitoring"},
    "APP-03": {"criteria": "P6.5", "principle": "Privacy — Disclosure", "description": "Sensitive information disclosure prevention"},
}


def get_compliance_report(test_results: list[dict]) -> dict:
    findings = []
    for result in test_results:
        test_id = result.get("test_id", "")
        mapping = SOC2_MAPPING.get(test_id)
        if mapping:
            findings.append({
                "test_id": test_id,
                "test_status": result.get("status", ""),
                "criteria": mapping["criteria"],
                "principle": mapping["principle"],
                "description": mapping["description"],
                "met": result.get("status") in ("PASS", "N/A"),
            })

    met = sum(1 for f in findings if f["met"])
    return {
        "framework": "SOC 2 Type II",
        "total_criteria": len(findings),
        "met": met,
        "gaps": len(findings) - met,
        "score": round(met / max(len(findings), 1) * 100, 1),
        "findings": findings,
    }
