"""
EU AI Act — Regulation (EU) 2024/1689 compliance mapping.

Maps Tessera test IDs to relevant articles and requirements.
"""

EU_AI_ACT_MAPPING = {
    # MOD — AI Model Security
    "MOD-01": {
        "article": "Article 15 — Accuracy, Robustness & Cybersecurity",
        "requirement": "High-risk AI systems shall be resilient against attempts by unauthorized third parties to alter their use, outputs or performance by exploiting system vulnerabilities.",
        "risk_level": "high",
    },
    "MOD-02": {
        "article": "Article 15(4) — Resilience to Data Poisoning",
        "requirement": "Technical solutions to address AI specific vulnerabilities including data poisoning.",
        "risk_level": "high",
    },
    "MOD-03": {
        "article": "Article 10 — Data and Data Governance",
        "requirement": "Training, validation and testing data sets shall be relevant, sufficiently representative and, to the best extent possible, free of errors and complete.",
        "risk_level": "high",
    },
    "MOD-04": {
        "article": "Article 10(4) — Data Examination",
        "requirement": "Examination of training data for membership inference vulnerabilities that may reveal private information.",
        "risk_level": "high",
    },
    "MOD-05": {
        "article": "Article 15(3) — Model Integrity",
        "requirement": "Protection against model inversion attacks that reconstruct training data from model outputs.",
        "risk_level": "high",
    },
    "MOD-06": {
        "article": "Article 9 — Risk Management System",
        "requirement": "Continuous iterative risk management process throughout the lifecycle, including monitoring for performance drift.",
        "risk_level": "high",
    },
    "MOD-07": {
        "article": "Article 14 — Human Oversight",
        "requirement": "High-risk AI systems shall be designed so they can be effectively overseen by natural persons.",
        "risk_level": "high",
    },
    # APP — AI Application Security
    "APP-01": {
        "article": "Article 15 — Cybersecurity",
        "requirement": "Protection against prompt injection and manipulation of AI system inputs.",
        "risk_level": "high",
    },
    "APP-02": {
        "article": "Article 15(1) — Output Integrity",
        "requirement": "AI system outputs shall be accurate, robust, and not exploitable for unintended purposes.",
        "risk_level": "high",
    },
    "APP-03": {
        "article": "Article 10(5) — Personal Data Processing",
        "requirement": "Appropriate data governance and management practices, including safeguards for personal data.",
        "risk_level": "high",
    },
    "APP-04": {
        "article": "Article 14(4) — Overreliance Prevention",
        "requirement": "Measures to prevent overreliance on AI system outputs by deployers and end-users.",
        "risk_level": "high",
    },
    "APP-05": {
        "article": "Article 15(2) — Output Safety",
        "requirement": "AI systems shall not produce unsafe outputs that could cause harm.",
        "risk_level": "high",
    },
    "APP-06": {
        "article": "Article 14(3) — Proportionate Agency",
        "requirement": "AI systems shall not exercise excessive agency beyond their intended scope.",
        "risk_level": "high",
    },
    "APP-07": {
        "article": "Article 13(3)(b)(ii) — System Prompt Confidentiality",
        "requirement": "Protection of system configuration and prompts from unauthorized disclosure.",
        "risk_level": "medium",
    },
    "APP-08": {
        "article": "Article 15 — Cross-Plugin Security",
        "requirement": "Protection against cross-plugin exploitation and unauthorized lateral movement.",
        "risk_level": "high",
    },
    "APP-09": {
        "article": "Article 15(4) — Model Extraction Prevention",
        "requirement": "Technical measures to prevent unauthorized extraction or replication of AI models.",
        "risk_level": "high",
    },
    "APP-10": {
        "article": "Article 10(2)(f) — Bias Detection",
        "requirement": "Examination in view of possible biases that are likely to affect the health and safety of persons.",
        "risk_level": "high",
    },
    "APP-11": {
        "article": "Article 15(1) — Accuracy",
        "requirement": "AI systems shall achieve appropriate levels of accuracy and not generate hallucinated outputs.",
        "risk_level": "high",
    },
    "APP-12": {
        "article": "Article 5(1) — Prohibited Practices",
        "requirement": "AI systems shall not generate toxic, harmful, or manipulative content.",
        "risk_level": "high",
    },
    "APP-13": {
        "article": "Article 14(4)(b) — Overreliance Mitigation",
        "requirement": "Deployers shall take measures to prevent automation bias and overreliance on AI outputs.",
        "risk_level": "high",
    },
    "APP-14": {
        "article": "Article 13 — Transparency",
        "requirement": "High-risk AI systems shall be designed to ensure that their operation is sufficiently transparent to enable deployers to interpret the system's output.",
        "risk_level": "high",
    },
    # INF — AI Infrastructure Security
    "INF-01": {
        "article": "Article 15(4) — Supply Chain Security",
        "requirement": "Technical measures addressing cybersecurity throughout the AI supply chain.",
        "risk_level": "high",
    },
    "INF-02": {
        "article": "Article 15(3) — Model Storage Security",
        "requirement": "Secure storage and protection of AI model artifacts and weights.",
        "risk_level": "high",
    },
    "INF-03": {
        "article": "Article 15 — API Security",
        "requirement": "Protection of AI system interfaces against unauthorized access and exploitation.",
        "risk_level": "high",
    },
    "INF-04": {
        "article": "Article 15(1) — Resource Resilience",
        "requirement": "AI systems shall be resilient against resource exhaustion and denial of service.",
        "risk_level": "high",
    },
    "INF-05": {
        "article": "Article 15 — Hardware Security",
        "requirement": "Protection of GPU/accelerator infrastructure against side-channel and hardware attacks.",
        "risk_level": "medium",
    },
    "INF-06": {
        "article": "Article 15(4) — Model Theft Prevention",
        "requirement": "Technical measures to prevent unauthorized copying or theft of AI models.",
        "risk_level": "high",
    },
    # DAT — AI Data Governance
    "DAT-01": {
        "article": "Article 10(2) — Data Governance",
        "requirement": "Training, validation, testing data sets subject to appropriate data governance practices.",
        "risk_level": "high",
    },
    "DAT-02": {
        "article": "GDPR Article 5(1)(f) — Integrity and Confidentiality",
        "requirement": "Personal data processed in a manner that ensures appropriate security and confidentiality.",
        "risk_level": "high",
    },
    "DAT-03": {
        "article": "Article 10(2)(b) — Data Lineage",
        "requirement": "Documentation of data provenance, collection processes, and lineage for traceability.",
        "risk_level": "high",
    },
    "DAT-04": {
        "article": "GDPR Article 17 — Right to Erasure",
        "requirement": "The data subject shall have the right to obtain erasure of personal data.",
        "risk_level": "high",
    },
    "DAT-05": {
        "article": "GDPR Article 5(1)(c) — Data Minimization",
        "requirement": "Personal data shall be adequate, relevant, and limited to what is necessary.",
        "risk_level": "high",
    },
    # AGT — AI Agent Security
    "AGT-01": {
        "article": "Article 15(4) — Agent Supply Chain",
        "requirement": "Technical measures to prevent tool poisoning and supply chain attacks on AI agents.",
        "risk_level": "high",
    },
    "AGT-02": {
        "article": "Article 14(3) — Agent Tool Governance",
        "requirement": "AI agents shall only use tools within their authorized scope and intended purpose.",
        "risk_level": "high",
    },
    "AGT-03": {
        "article": "Article 9(2)(a) — Agent Goal Alignment",
        "requirement": "AI agents shall remain aligned with their intended objectives and resist goal hijacking.",
        "risk_level": "high",
    },
    "AGT-04": {
        "article": "Article 15(4) — Agent Memory Integrity",
        "requirement": "Protection of agent memory and context against poisoning and unauthorized modification.",
        "risk_level": "high",
    },
    "AGT-05": {
        "article": "Article 9(8) — Identity & Access Control",
        "requirement": "AI agents shall enforce strict identity verification and least-privilege access controls.",
        "risk_level": "high",
    },
    "AGT-06": {
        "article": "Article 15(4) — Code Execution Safety",
        "requirement": "AI agents shall not execute arbitrary code without sandboxing and human authorization.",
        "risk_level": "high",
    },
    "AGT-07": {
        "article": "Article 15 — Secure Agent Communications",
        "requirement": "Inter-agent communications shall be authenticated, encrypted, and tamper-proof.",
        "risk_level": "high",
    },
    "AGT-08": {
        "article": "Article 15(1) — Failure Resilience",
        "requirement": "Multi-agent systems shall be resilient against cascading failures and error propagation.",
        "risk_level": "high",
    },
    "AGT-09": {
        "article": "Article 14 — Human-Agent Trust",
        "requirement": "AI agents shall not exploit human trust through false urgency, authority claims, or social engineering.",
        "risk_level": "high",
    },
    "AGT-10": {
        "article": "Article 14(1) — Agent Oversight",
        "requirement": "AI agents shall operate under continuous human oversight and not pursue covert goals or self-replicate.",
        "risk_level": "high",
    },
}


def get_compliance_report(test_results: list[dict]) -> dict:
    """Generate EU AI Act compliance report from test results."""
    findings = []
    for result in test_results:
        test_id = result.get("test_id", "")
        mapping = EU_AI_ACT_MAPPING.get(test_id)
        if mapping:
            findings.append({
                "test_id": test_id,
                "test_name": result.get("test_name", ""),
                "test_status": result.get("status", ""),
                "article": mapping["article"],
                "requirement": mapping["requirement"],
                "risk_level": mapping["risk_level"],
                "compliant": result.get("status") in ("PASS", "N/A"),
            })

    compliant_count = sum(1 for f in findings if f["compliant"])
    return {
        "framework": "EU AI Act (Regulation 2024/1689)",
        "total_requirements": len(findings),
        "compliant": compliant_count,
        "non_compliant": len(findings) - compliant_count,
        "compliance_score": round(compliant_count / max(len(findings), 1) * 100, 1),
        "findings": findings,
    }
