"""Compliance mapping templates."""
