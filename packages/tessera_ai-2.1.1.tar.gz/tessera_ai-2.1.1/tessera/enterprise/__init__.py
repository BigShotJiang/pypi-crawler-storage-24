"""
Tessera Enterprise Features.

These features require a valid TESSERA_LICENSE_KEY to function.
Without a license, all 32 tests + CLI + API + Web UI work normally.
Enterprise endpoints return 403.
"""

from .license import (
    get_license_tier as get_license_tier,
)
from .license import (
    is_enterprise_licensed as is_enterprise_licensed,
)
