"""Scheduled scan support."""
