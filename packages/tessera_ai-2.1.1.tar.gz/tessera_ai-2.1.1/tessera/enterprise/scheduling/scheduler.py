"""
Scheduled scans — uses Celery Beat for periodic scan execution.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class ScheduledScan:
    """Scheduled scan configuration."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    cron_expression: str = "0 2 * * 1"  # Default: Monday 2AM
    config_path: str = "config.yaml"
    category: str = "all"
    per_model: bool = False
    formats: list[str] = field(default_factory=lambda: ["json", "html"])
    enabled: bool = True
    org_id: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_run_at: Optional[str] = None
    next_run_at: Optional[str] = None


# In-memory store (replaced by DB in production)
_schedules: dict[str, ScheduledScan] = {}


def create_schedule(name: str, cron: str, **kwargs) -> ScheduledScan:
    """Create a new scheduled scan."""
    schedule = ScheduledScan(name=name, cron_expression=cron, **kwargs)
    _schedules[schedule.id] = schedule
    _register_celery_beat(schedule)
    return schedule


def list_schedules(org_id: str = None) -> list[ScheduledScan]:
    """List all scheduled scans."""
    schedules = list(_schedules.values())
    if org_id:
        schedules = [s for s in schedules if s.org_id == org_id]
    return schedules


def delete_schedule(schedule_id: str) -> bool:
    """Delete a scheduled scan."""
    if schedule_id in _schedules:
        _unregister_celery_beat(schedule_id)
        del _schedules[schedule_id]
        return True
    return False


def _register_celery_beat(schedule: ScheduledScan):
    """Register schedule with Celery Beat."""
    try:
        from celery.schedules import crontab

        from tessera.worker.celery_app import celery_app

        parts = schedule.cron_expression.split()
        if len(parts) == 5:
            celery_app.conf.beat_schedule[f"tessera-{schedule.id}"] = {
                "task": "tessera.run_scan",
                "schedule": crontab(
                    minute=parts[0],
                    hour=parts[1],
                    day_of_month=parts[2],
                    month_of_year=parts[3],
                    day_of_week=parts[4],
                ),
                "args": [schedule.id, {
                    "config_path": schedule.config_path,
                    "category": schedule.category,
                    "per_model": schedule.per_model,
                    "formats": schedule.formats,
                }],
            }
    except ImportError:
        pass


def _unregister_celery_beat(schedule_id: str):
    """Remove schedule from Celery Beat."""
    try:
        from tessera.worker.celery_app import celery_app
        celery_app.conf.beat_schedule.pop(f"tessera-{schedule_id}", None)
    except ImportError:
        pass
