"""
ASR Types - Type definitions for ASR data structures.
"""

from .definitions import AsrRawData, Segment, Word

__version__ = "1.0.4"

__all__ = [
    "Word",
    "Segment",
    "AsrRawData",
]
