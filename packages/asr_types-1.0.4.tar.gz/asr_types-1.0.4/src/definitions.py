from typing import TypedDict


class Word(TypedDict):
    word: str
    startMs: int
    endMs: int


class Segment(TypedDict):
    text: str
    startMs: int
    endMs: int
    words: list[Word]


class AsrRawData(TypedDict):
    chunks: list[str]
    words: list[Word]
