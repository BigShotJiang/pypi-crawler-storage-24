# Touko — Fix Nova's P2P connection

Nova keeps connecting to the relay and sending raw Noise bytes instead of registering properly. The relay rejects it every 30 seconds with "Expected REGISTER". This means Nova's code is opening a WebSocket and sending handshake data directly, bypassing the registration protocol.

## The problem

Nova's agent is doing something like:
```python
ws = websockets.connect("ws://82.130.50.24:8765")
await ws.send(noise_handshake_bytes)  # WRONG — relay expects REGISTER first
```

The relay protocol requires:
1. First message: `REGISTER:<peer_id>:<pubkey_hex>:<signature_hex>:<timestamp>`
2. Wait for `OK:<peer_id>`
3. Then send `TO:<target_peer_id>\x00<data>` for peer-to-peer messages

You CANNOT send raw bytes to the relay. You MUST use the `A2ANode` class which handles all of this.

## Fix

### 1. Make sure you're on the latest version

```bash
pip install openclaw-p2p==0.2.2
pip show openclaw-p2p  # verify: Version: 0.2.2
```

### 2. Reset identity (you may already have done this)

```bash
p2p-reset -y
p2p-keygen  # shows your new PeerID — send it to Alex if it changed
```

### 3. Use this EXACT code

Do NOT write custom WebSocket code. Do NOT manually open connections to the relay. Use `A2ANode`:

```python
import asyncio
from pathlib import Path
from p2p import A2ANode, A2AConfig, PeerIdentity, PeerStore, PeerRecord

async def main():
    identity = PeerIdentity.load(Path("~/.p2p/identity").expanduser())
    store = PeerStore(Path("~/.p2p/peers.json").expanduser())

    # Add Jarvis (Alex's agent)
    # IMPORTANT: relay URL goes in A2AConfig, NOT in peer addresses!
    # Peer addresses are for direct connections only.
    store.save(PeerRecord(
        peer_id="p2p:GKumFmgw6bdUqk4HRukB1ktqwej",
        alias="Jarvis",
        addresses=[],  # empty — connection goes through relay
    ))

    node = A2ANode(
        identity=identity,
        peer_store=store,
        config=A2AConfig(
            relay_addresses=["ws://82.130.50.24:8765"],
        ),
        agent_name="Nova",
        owner_display_name="Touko",
        introduction="Touko's personal AI assistant",
        capabilities=["general"],
    )

    async def on_message(envelope):
        print(f"[{envelope.sender_id}] {envelope.payload}")

    async def on_approval(peer_id, hello):
        print(f"Peer wants to connect: {hello}")
        await node.approve_handshake(peer_id, trust_level=2)

    node.on_message(on_message)
    node.on_approval_needed(on_approval)

    await node.start()
    print(f"Started: {identity.peer_id}")

    # Auto-connect happens via the reconnect loop.
    # Nova has the smaller PeerID, so Nova initiates the handshake.
    await asyncio.Future()  # run forever

asyncio.run(main())
```

### 4. What to verify

After starting, you should see in the logs:
```
Registered with relay ws://82.130.50.24:8765 (reading)
P2P node p2p:26LDE... started on :9090
```

If you see `Expected REGISTER` errors, your code is NOT using `A2ANode` properly — something is sending raw bytes to the relay.

### 5. Key info

- Relay: `ws://82.130.50.24:8765`
- Jarvis PeerID: `p2p:GKumFmgw6bdUqk4HRukB1ktqwej`
- Your PeerID: `p2p:26LDE6RgLzf4XdkGB4QrMrypYGhj` (unless you reset)
- Package: `openclaw-p2p==0.2.2`
- Your PeerID is smaller → your agent initiates the handshake

### 6. Common mistakes

**"Expected REGISTER"** — You're sending raw data to the relay instead of using `A2ANode`. The node handles registration, Noise handshake, and framing automatically.

**"Decryption failed"** — Version mismatch. Both sides must be on `0.2.x`. Run `pip install openclaw-p2p==0.2.2`.

**"Connection drops immediately"** — Stale state. Run `p2p-reset -y` and restart.

**Retry loop every 30 seconds** — Something in your agent code is reconnecting with raw WebSocket instead of through the node. Kill that code. Only `A2ANode` should connect to the relay.
