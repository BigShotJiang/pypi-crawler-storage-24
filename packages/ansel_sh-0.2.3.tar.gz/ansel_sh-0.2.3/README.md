# ansel

Demand forecasting CLI for AI agents.

```bash
pip install ansel-sh
ansel files ./sales.csv
```
