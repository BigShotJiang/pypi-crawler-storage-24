"""Detect authentication credentials for the Ansel API."""

from __future__ import annotations

import os


def get_token() -> str | None:
    """Return the best available auth token.

    Priority:
    1. ANTHROPIC_API_KEY (direct API key)
    2. CLAUDE_CODE_OAUTH_TOKEN (OAuth from Claude Code / Cowork)
    """
    return os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_CODE_OAUTH_TOKEN')
