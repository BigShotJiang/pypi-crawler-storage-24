"""ansel CLI — demand forecasting for AI agents."""

from __future__ import annotations

import sys

from .commands import files as files_cmd

COMMANDS = {
    'files': files_cmd.run,
}


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ('-h', '--help', 'help'):
        print('Usage: ansel <command> [args]')
        print()
        print('Commands:')
        print('  files <path>        Upload and classify CSV data files')
        print('  files list          List all classified files')
        sys.exit(0)

    if args[0] in ('-v', '--version'):
        print('ansel 0.2.3')
        sys.exit(0)

    command = args[0]
    handler = COMMANDS.get(command)

    if handler is None:
        print(f"error: unknown command '{command}'", file=sys.stderr)
        print("Run 'ansel --help' for usage.", file=sys.stderr)
        sys.exit(1)

    sys.exit(handler(args[1:]))
