import pytest
from datetime import datetime, timedelta, UTC

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID

from snaffler.analysis.certificates import CertificateChecker


# ---------- helpers ----------

def gen_key():
    return rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )


def gen_cert(key, cn: str = "test.local"):
    name = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, cn),
        ]
    )

    now = datetime.now(UTC)

    return (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=30))
        .sign(key, hashes.SHA256())
    )


# ---------- tests ----------

def test_invalid_certificate():
    checker = CertificateChecker()
    assert checker.check_certificate(b"not a cert", "bad.bin") == []


def test_pem_without_private_key():
    key = gen_key()
    cert = gen_cert(key)

    data = cert.public_bytes(serialization.Encoding.PEM)

    checker = CertificateChecker()
    assert checker.check_certificate(data, "cert.pem") == []


def test_pem_with_private_key_no_password():
    key = gen_key()
    cert = gen_cert(key)

    data = (
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
        + cert.public_bytes(serialization.Encoding.PEM)
    )

    checker = CertificateChecker()
    res = checker.check_certificate(data, "server.pem")

    assert "HasPrivateKey" in res
    assert "NoPasswordRequired" in res
    assert any(r.startswith("Subject:") for r in res)


def test_pem_with_private_key_password():
    key = gen_key()
    cert = gen_cert(key)

    password = b"secret123"

    data = (
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.BestAvailableEncryption(password),
        )
        + cert.public_bytes(serialization.Encoding.PEM)
    )

    checker = CertificateChecker(custom_passwords=["secret123"])
    res = checker.check_certificate(data, "secure.pem")

    assert "HasPrivateKey" in res
    assert "PasswordCracked:secret123" in res


def test_standalone_pem_private_key_no_cert():
    """BUG-C: Bare PEM private key (no cert block) returns HasPrivateKey."""
    key = gen_key()

    # Private key only — no certificate block
    data = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    )

    checker = CertificateChecker()
    res = checker.check_certificate(data, "key.pem")

    assert "HasPrivateKey" in res
    assert "NoPasswordRequired" in res
    # No Subject since there's no certificate
    assert not any(r.startswith("Subject:") for r in res)


def test_pkcs12_no_password():
    key = gen_key()
    cert = gen_cert(key)

    pfx = pkcs12.serialize_key_and_certificates(
        name=b"test",
        key=key,
        cert=cert,
        cas=None,
        encryption_algorithm=serialization.NoEncryption(),
    )

    checker = CertificateChecker()
    res = checker.check_certificate(pfx, "cert.pfx")

    assert "HasPrivateKey" in res
    assert "NoPasswordRequired" in res


def test_pkcs12_with_password():
    key = gen_key()
    cert = gen_cert(key)

    password = b"pfxpass"

    pfx = pkcs12.serialize_key_and_certificates(
        name=b"test",
        key=key,
        cert=cert,
        cas=None,
        encryption_algorithm=serialization.BestAvailableEncryption(password),
    )

    checker = CertificateChecker(custom_passwords=["pfxpass"])
    res = checker.check_certificate(pfx, "vault.pfx")

    assert "HasPrivateKey" in res
    assert "PasswordCracked:pfxpass" in res


# ---------- BUG-K: custom_passwords replaces defaults ----------


def test_pem_unsupported_algorithm_falls_through_to_passwords():
    """BUG-04: UnsupportedAlgorithm from load_pem_private_key should fall
    through to the password loop, not skip it entirely."""
    from unittest.mock import patch, MagicMock
    from cryptography.exceptions import UnsupportedAlgorithm

    key = gen_key()
    cert = gen_cert(key)

    # Encrypted PEM — needs password to load
    data = (
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.BestAvailableEncryption(b"mypass"),
        )
        + cert.public_bytes(serialization.Encoding.PEM)
    )

    real_load = serialization.load_pem_private_key

    def load_raising_unsupported(data, password, **kwargs):
        """First call (password=None) raises UnsupportedAlgorithm;
        subsequent calls with a password delegate to the real loader."""
        if password is None:
            raise UnsupportedAlgorithm("simulated unsupported algo")
        return real_load(data, password=password, **kwargs)

    checker = CertificateChecker(custom_passwords=["mypass"])

    with patch(
        "snaffler.analysis.certificates.serialization.load_pem_private_key",
        side_effect=load_raising_unsupported,
    ):
        res = checker.check_certificate(data, "weird_algo.pem")

    # Password loop must have been reached and cracked the key
    assert "HasPrivateKey" in res
    assert "PasswordCracked:mypass" in res


def test_custom_passwords_replace_defaults():
    """BUG-K: custom_passwords replaces defaults, not appended to them."""
    checker = CertificateChecker(custom_passwords=["foo", "bar"])
    assert checker.passwords == ["foo", "bar"]


def test_no_custom_passwords_uses_defaults():
    """BUG-K: omitting custom_passwords uses DEFAULT_PASSWORDS."""
    checker = CertificateChecker()
    assert checker.passwords == CertificateChecker.DEFAULT_PASSWORDS


def test_empty_custom_passwords_uses_empty():
    """BUG-K: empty list is a valid custom list, not treated as None."""
    checker = CertificateChecker(custom_passwords=[])
    assert checker.passwords == []
