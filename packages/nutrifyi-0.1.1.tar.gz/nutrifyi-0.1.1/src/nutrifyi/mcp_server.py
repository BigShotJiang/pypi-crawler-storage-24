"""MCP server for nutrifyi — AI assistant tools for nutrifyi.com.

Run: uvx --from "nutrifyi[mcp]" python -m nutrifyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("NutriFYI")


@mcp.tool()
def list_foods(limit: int = 20, offset: int = 0) -> str:
    """List foods from nutrifyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from nutrifyi.api import NutriFYI

    with NutriFYI() as api:
        data = api.list_foods(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No foods found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_food(slug: str) -> str:
    """Get detailed information about a specific food.

    Args:
        slug: URL slug identifier for the food.
    """
    from nutrifyi.api import NutriFYI

    with NutriFYI() as api:
        data = api.get_food(slug)
        return str(data)


@mcp.tool()
def list_diets(limit: int = 20, offset: int = 0) -> str:
    """List diets from nutrifyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from nutrifyi.api import NutriFYI

    with NutriFYI() as api:
        data = api.list_diets(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No diets found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_nutri(query: str) -> str:
    """Search nutrifyi.com for foods, nutrition data, and dietary analysis.

    Args:
        query: Search query string.
    """
    from nutrifyi.api import NutriFYI

    with NutriFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
