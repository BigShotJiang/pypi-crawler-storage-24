"""Python API client for nutrifyi.com."""

__version__ = "0.1.0"
