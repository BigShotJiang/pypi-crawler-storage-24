from yta_editor_nodes.compositor.base import _NodeCompositor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.compositor.displacement_with_rotation import DisplacementWithRotationNodeCompositorCPU
from yta_editor_nodes_gpu.compositor.displacement_with_rotation import DisplacementWithRotationNodeCompositorGPU


class DisplacementWithRotationNodeCompositor(_NodeCompositor):
    """
    The frame, but moving and rotating over other frame.

    Mandatory inputs:
    - `overlay_input`

    Optional inputs:
    - `base_input`

    Parameters:
    - `*x`
    - `*y`
    - `*width`
    - `*height`
    - `*rotation`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['overlay_input']
    optional_inputs = ['base_input']
    parameters_specifications = [
        # TODO: Check if these limits below are ok
        ParameterSpecification(
            name = 'x',
            type = int,
            is_required = True,
            default = int(1920 / 2),
            min = -9999,
            max = 9999
        ),
        ParameterSpecification(
            name = 'y',
            type = int,
            is_required = True,
            default = int(1080 / 2),
            min = -9999,
            max = 9999
        ),
        ParameterSpecification(
            name = 'width',
            type = int,
            is_required = True,
            default = int(1920 / 2),
            min = -9999,
            max = 9999
        ),
        ParameterSpecification(
            name = 'height',
            type = int,
            is_required = True,
            default = int(1080 / 2),
            min = -9999,
            max = 9999
        ),
        ParameterSpecification(
            name = 'rotation',
            type = int,
            is_required = True,
            default = 45,
            min = -360 * 10,
            max = 360 * 10
        )
    ]
    cpu_class = DisplacementWithRotationNodeCompositorCPU
    gpu_class = DisplacementWithRotationNodeCompositorGPU

    def _format_parameters(
        self,
        parameters: dict[str, any]
    ) -> dict[str, any]:
        # The 'x' and 'y' exist always
        parameters['position'] = (parameters.pop('x'), parameters.pop('y'))
        # The 'width' and 'height' exist always
        parameters['size'] = (parameters.pop('width'), parameters.pop('height'))

        return parameters