from typing import Union


def _do_use_gpu(
    # TODO: Set type
    node_processor: any,
    do_use_gpu: bool = True
) -> bool:
    """
    *For internal use only*

    Check if we should use GPU or not, according
    to what the user is requesting with the
    `do_use_gpu` parameter but checking if it is
    available in the `node_processor` or not.

    This method is useful to know if we have to
    transform a frame to a specific format (for
    GPU or CPU) before sending it as an argument.
    """
    # TODO: Validate 'node_processor'
    return (
        (
            do_use_gpu and
            node_processor.is_gpu_available
        )
    ) or (
        (
            not do_use_gpu and
            not node_processor.is_cpu_available
        )
    )

def validate_render_target(
    render_target: Union['RenderTarget', None],
    do_use_gpu: bool
):
    """
    The `do_use_gpu` parameter must be resolved based
    on the user's request and the availability
    according to the node we will use to process.

    This method must be implemented by the nodes that
    are able to work with GPU as we need a 
    `render_target` parameter to be able to process it,
    that is not needed when CPU is being applied.
    """
    if (
        do_use_gpu and
        render_target is None
    ):
        raise Exception('The "render_target" was not provided and is needed for GPU processing.')
    
# TODO: Maybe move from here (?)
def render_context_to_gpu_render_context(
    render_context: 'RenderContext'
) -> 'GPURenderContext':
    """
    Adapt the `render_context` provided to a
    `GPURenderContext` instance to be able to send
    it to the nodes that works with GPU.
    """
    from yta_editor_nodes_gpu.context import GPURenderContext

    return GPURenderContext(
        # TODO: Maybe provide the 'Accessor' instead (?)
        render_target_provider = render_context.render_resources._render_target_provider,
        opengl_context = render_context.render_resources.opengl_context
    )

def render_context_to_cpu_render_context(
    render_context: 'RenderContext'
) -> 'CPURenderContext':
    """
    Adapt the `render_context` provided to a
    `CPURenderContext` instance to be able to send
    it to the nodes that works with CPU.
    """
    from yta_editor_nodes_cpu.context import CPURenderContext

    return CPURenderContext(
        output_size = render_context.render_config.size
    )