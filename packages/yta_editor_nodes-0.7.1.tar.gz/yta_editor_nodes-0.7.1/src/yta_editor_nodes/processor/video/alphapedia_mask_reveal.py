from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_nodes_gpu.processor.video.alphapedia_mask_reveal import AlphaPediaMaskRevealVideoNodeProcessorGPU


class AlphaPediaMaskRevealVideoNodeProcessor(_VideoNodeProcessor):
    """
    A transition made by using a custom mask to
    reveal a video. This mask is specifically obtained
    from the AlphaPediaYT channel in which we upload
    specific masking videos.

    The video will be placed ocuppying the whole scene
    and revealed progressively by using the video mask.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `base_input`
    - `mask_input`

    Optional inputs:
    - `None`

    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input', 'mask_input']
    optional_inputs = []
    parameters_specifications = []
    cpu_class = None
    gpu_class = AlphaPediaMaskRevealVideoNodeProcessorGPU