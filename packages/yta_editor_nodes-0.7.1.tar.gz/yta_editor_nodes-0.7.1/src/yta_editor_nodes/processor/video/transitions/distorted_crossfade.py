from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_gpu.processor.video.transitions.distorted_crossfade import DistortedCrossfadeTransitionNodeProcessorGPU


class DistortedCrossfadeTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos,
    transforming the first one into the second one
    with a distortion in between.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*intensity`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'intensity',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.1,
            max = 10.0
        )
    ]
    cpu_class = None
    gpu_class = DistortedCrossfadeTransitionNodeProcessorGPU