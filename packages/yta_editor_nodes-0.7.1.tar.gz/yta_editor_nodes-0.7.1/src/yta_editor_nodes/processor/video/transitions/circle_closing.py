from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_gpu.processor.video.transitions.circle_closing import CircleClosingTransitionNodeProcessorGPU


class CircleClosingTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos in
    which the frames are mixed by generating a circle
    that decreases its size from the whole screen
    until disappearing.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `*border_smoothness`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'border_smoothness',
            type = float,
            is_required = True,
            default = 0.02,
            min = 0.001,
            max = 1.0
        )
    ]
    cpu_class = None
    gpu_class = CircleClosingTransitionNodeProcessorGPU