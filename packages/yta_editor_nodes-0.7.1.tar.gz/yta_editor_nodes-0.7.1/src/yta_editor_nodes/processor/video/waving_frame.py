from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.processor.video.waving_frame import WavingFrameVideoNodeProcessorCPU
from yta_editor_nodes_gpu.processor.video.waving_frame import WavingFrameVideoNodeProcessorGPU


class WavingFrameVideoNodeProcessor(_VideoNodeProcessor):
    """
    The frame but as if it is moving like a wave.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
       
    Parameters:
    - `*amplitude`
    - `*frequency`
    - `*speed`
    - `*do_use_transparent_pixels`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'amplitude',
            type = float,
            is_required = True,
            default = 0.05,
            min = 0.001,
            max = 0.5
        ),
        ParameterSpecification(
            name = 'frequency',
            type = float,
            is_required = True,
            default = 10.0,
            min = 0.1,
            max = 100.0
        ),
        ParameterSpecification(
            name = 'speed',
            type = float,
            is_required = True,
            default = 2.0,
            min = 0.1,
            max = 10.0
        ),
        ParameterSpecification(
            name = 'do_use_transparent_pixels',
            type = bool,
            is_required = True,
            default = False,
            min = None,
            max = None
        )
    ]
    cpu_class = WavingFrameVideoNodeProcessorCPU
    gpu_class = WavingFrameVideoNodeProcessorGPU