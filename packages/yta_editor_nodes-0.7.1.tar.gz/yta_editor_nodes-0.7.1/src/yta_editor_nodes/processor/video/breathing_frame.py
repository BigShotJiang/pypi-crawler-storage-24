from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_gpu.processor.video.breathing_frame import BreathingFrameVideoNodeProcessorGPU


class BreathingFrameVideoNodeProcessor(_VideoNodeProcessor):
    """
    The frame but as if it was breathing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `*zoom`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'zoom',
            type = float,
            is_required = True,
            default = 0.05,
            min = 0.001,
            max = 1.0
        )
    ]
    cpu_class = None
    gpu_class = BreathingFrameVideoNodeProcessorGPU