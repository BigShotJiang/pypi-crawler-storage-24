from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_nodes_gpu.processor.pad_to_size import PadToSizeNodeProcessorGPU
from yta_editor_nodes_cpu.processor.pad_to_size import PadToSizeNodeProcessorCPU


class PadToSizeNodeProcessor(_NodeProcessor):
    """
    The node to modify the input to center it
    and fill the outside with transparency

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = []
    # Nodes
    gpu_class = PadToSizeNodeProcessorGPU
    cpu_class = PadToSizeNodeProcessorCPU