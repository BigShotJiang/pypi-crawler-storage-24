from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.processor.color_contrast import ColorContrastNodeProcessorCPU
from yta_editor_nodes_gpu.processor.color_contrast import ColorContrastNodeProcessorGPU


class ColorContrastNodeProcessor(_NodeProcessor):
    """
    The node to modify the color contrast of an input
    by using the CPU or the GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`

    Parameters:
    - `factor`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'factor',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.0,
            max = 5.0
        )
    ]
    cpu_class = ColorContrastNodeProcessorCPU
    gpu_class = ColorContrastNodeProcessorGPU