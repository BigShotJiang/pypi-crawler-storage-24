from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_nodes_cpu.processor.black_and_white import BlackAndWhiteNodeProcessorCPU
from yta_editor_nodes_gpu.processor.black_and_white import BlackAndWhiteNodeProcessorGPU


class BlackAndWhiteNodeProcessor(_NodeProcessor):
    """
    The node to modify the input provided and set
    it as black and white by using CPU or GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = []
    # Nodes
    gpu_class = BlackAndWhiteNodeProcessorGPU
    cpu_class = BlackAndWhiteNodeProcessorCPU