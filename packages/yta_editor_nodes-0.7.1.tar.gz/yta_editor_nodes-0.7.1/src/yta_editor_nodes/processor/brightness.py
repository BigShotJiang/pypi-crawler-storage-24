from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_cpu.processor.brightness import BrightnessNodeProcessorCPU
from yta_editor_nodes_gpu.processor.brightness import BrightnessNodeProcessorGPU


class BrightnessNodeProcessor(_NodeProcessor):
    """
    The node to modify the brightness of an input
    by using the CPU or the GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `factor`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'factor',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.0,
            max = 5.0
        )
    ]
    cpu_class = BrightnessNodeProcessorCPU
    gpu_class = BrightnessNodeProcessorGPU