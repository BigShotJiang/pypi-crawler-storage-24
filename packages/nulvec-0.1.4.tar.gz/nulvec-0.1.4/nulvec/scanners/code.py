"""
Heuristic code scanner for Python, JavaScript, TypeScript, shell, and similar text files.

Focuses on high-signal supply-chain patterns:
1. Credential exfiltration from sensitive files or environment variables
2. Remote shell bootstrap patterns
3. Prompt-injection comments hidden in code
"""

from __future__ import annotations

import re
import time
from pathlib import Path

from nulvec.models import ScanResult, Severity, Threat, ThreatType
from nulvec.utils import is_adversarial_instruction

_REMOTE_SHELL = re.compile(
    r"(?:curl|wget)\s+[^\n|]+\|\s*(?:ba)?sh",
    re.IGNORECASE,
)

_EXFIL_PATTERNS = [
    re.compile(
        r"(?:curl|wget|requests\.(?:post|put)|httpx\.(?:post|put)|fetch\s*\().*?"
        r"(?:~?/\.ssh|~?/\.aws|~?/\.kube|id_rsa|credentials|printenv|process\.env|os\.environ)",
        re.IGNORECASE,
    ),
    re.compile(
        r"(?:cat|open|read_text|readFileSync|fs\.readFileSync).*?"
        r"(?:id_rsa|\.ssh|\.aws/credentials|\.kube/config)",
        re.IGNORECASE,
    ),
]

_COMMENT_PREFIXES = ("#", "//", "/*", "*", "<!--")


def scan(file_path: str | Path) -> ScanResult:
    """Scan a code file for agent-supply-chain threats."""
    path = Path(file_path)
    start = time.monotonic()
    text = path.read_text(encoding="utf-8", errors="replace")
    threats: list[Threat] = []

    for pattern in _EXFIL_PATTERNS:
        match = pattern.search(text)
        if match:
            threats.append(
                Threat(
                    type=ThreatType.EXFILTRATION_ATTEMPT,
                    severity=Severity.CRITICAL,
                    confidence=0.96,
                    description=(
                        "Code contains a high-signal credential exfiltration pattern "
                        "targeting secrets, cloud credentials, or SSH material."
                    ),
                    extracted_content=_extract_line(text, match.start()),
                    location=f"line:{_line_number(text, match.start())}",
                )
            )
            break

    match = _REMOTE_SHELL.search(text)
    if match:
        threats.append(
            Threat(
                type=ThreatType.HIDDEN_INSTRUCTION,
                severity=Severity.HIGH,
                confidence=0.9,
                description=(
                    "Code contains a remote shell bootstrap pattern. Fetching a remote "
                    "script and piping it into a shell is a strong supply-chain signal."
                ),
                extracted_content=_extract_line(text, match.start()),
                location=f"line:{_line_number(text, match.start())}",
            )
        )

    for lineno, comment in _iter_comment_lines(text):
        if is_adversarial_instruction(comment):
            threats.append(
                Threat(
                    type=ThreatType.HIDDEN_INSTRUCTION,
                    severity=Severity.HIGH,
                    confidence=0.87,
                    description=(
                        "Adversarial instruction detected in a code comment. This can "
                        "poison agent context when repos are indexed or summarized."
                    ),
                    extracted_content=comment[:300],
                    location=f"line:{lineno}",
                )
            )
            break

    duration_ms = (time.monotonic() - start) * 1000
    return ScanResult(
        file_path=str(path),
        scanner="code",
        modality="code",
        threats=threats,
        scan_duration_ms=round(duration_ms, 2),
        metadata={"lines": text.count("\n") + 1, "size_bytes": len(text.encode())},
    )


def _iter_comment_lines(text: str) -> list[tuple[int, str]]:
    comments: list[tuple[int, str]] = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if stripped.startswith(_COMMENT_PREFIXES):
            comment = stripped.lstrip("#/*!- ").strip()
            if comment:
                comments.append((lineno, comment))
    return comments


def _extract_line(text: str, char_offset: int) -> str:
    start = text.rfind("\n", 0, char_offset) + 1
    end = text.find("\n", char_offset)
    return text[start: end if end != -1 else len(text)].strip()


def _line_number(text: str, char_offset: int) -> int:
    return text.count("\n", 0, char_offset) + 1
