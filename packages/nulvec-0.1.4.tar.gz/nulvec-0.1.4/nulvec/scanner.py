"""
Top-level scan() API — two-stage pipeline.

Usage:
    import nulvec
    result = nulvec.scan("invoice.pdf")
    result = nulvec.scan("banner.png")
    result = nulvec.scan("SKILL.md")

    if result.blocked:
        for threat in result.threats:
            print(threat.type, threat.confidence, threat.extracted_content)

Pipeline:
    Stage 1 (always): fast triage, <5ms, runs synchronously
    Stage 2 (suspicious only): deep scan, <200ms, runs full scanner modules
"""

from __future__ import annotations

import tempfile
import time
from pathlib import Path

from nulvec.models import ScanResult
from nulvec.stage1.triage import triage
from nulvec.stage2.deep import deep_scan


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif"}
PDF_EXTENSIONS   = {".pdf"}
SKILL_EXTENSIONS = {".md", ".markdown"}
CODE_EXTENSIONS  = {".py", ".js", ".ts", ".go", ".rb", ".sh", ".bash"}
MCP_EXTENSIONS   = {".json"}  # MCP tool responses are typically JSON
SUPPORTED_EXTENSIONS = (
    IMAGE_EXTENSIONS
    | PDF_EXTENSIONS
    | SKILL_EXTENSIONS
    | CODE_EXTENSIONS
    | MCP_EXTENSIONS
)


def _modality(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in IMAGE_EXTENSIONS: return "image"
    if ext in PDF_EXTENSIONS:   return "pdf"
    if ext in SKILL_EXTENSIONS: return "skill"
    if ext in CODE_EXTENSIONS:  return "code"
    if ext in MCP_EXTENSIONS:   return "mcp"
    return "unknown"


def is_supported_path(path: Path) -> bool:
    """Return True when the path uses a supported extension."""
    return path.suffix.lower() in SUPPORTED_EXTENSIONS


def scan(file_path: str | Path) -> ScanResult:
    """
    Scan a file for adversarial injections using the two-stage pipeline.

    Stage 1 (fast triage) runs on every call.
    Stage 2 (deep inspection) runs only if Stage 1 flags the input as SUSPICIOUS.

    Raises ValueError for unsupported file types.
    """
    path = Path(file_path)
    ext  = path.suffix.lower()

    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type: '{ext}'. "
            f"Supported: {sorted(SUPPORTED_EXTENSIONS)}"
        )

    modality = _modality(path)

    # ── Stage 1: fast triage ─────────────────────────────────────────────────
    t1 = triage(path, modality)

    if t1.verdict == "clean":
        # Return a clean ScanResult immediately — no deep scan needed
        return ScanResult(
            file_path=str(path),
            scanner=modality,
            modality=modality,
            threats=[],
            stage=1,
            scan_duration_ms=round(t1.duration_ms, 2),
            metadata={"triage_checks": t1.checks_run},
        )

    # ── Stage 2: deep inspection ─────────────────────────────────────────────
    return deep_scan(path, modality, t1)


def scan_content(
    content: str | bytes,
    *,
    filename: str | None = None,
    modality_hint: str | None = None,
) -> ScanResult:
    """Scan in-memory content using the existing file-oriented pipeline."""
    temp_name = _content_filename(filename, modality_hint)
    payload = content.encode("utf-8") if isinstance(content, str) else content

    with tempfile.NamedTemporaryFile(suffix=Path(temp_name).suffix, delete=True) as tmp:
        tmp.write(payload)
        tmp.flush()
        return scan(tmp.name)


def _content_filename(filename: str | None, modality_hint: str | None) -> str:
    if filename:
        return filename

    hint = (modality_hint or "").lower()
    if hint == "mcp":
        return "payload.json"
    if hint == "skill":
        return "SKILL.md"
    if hint == "code":
        return "snippet.py"
    if hint == "pdf":
        return "document.pdf"
    if hint == "image":
        return "image.png"
    return "payload.json"
