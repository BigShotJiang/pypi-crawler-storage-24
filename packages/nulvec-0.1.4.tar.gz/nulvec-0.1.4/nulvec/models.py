"""Core data models for Nulvec — matches PRD Section 3.3 exactly."""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Literal, Optional


class ThreatType(str, Enum):
    HIDDEN_INSTRUCTION   = "hidden_instruction"    # prompt injection (PDF layers, white text)
    STEGANOGRAPHIC       = "steganographic"         # LSB / pixel encoding
    CSS_INJECTION        = "css_injection"          # DOM hidden text
    METADATA_POISON      = "metadata_poison"        # PDF/EXIF metadata abuse
    SKILL_MALWARE        = "skill_malware"          # SKILL.md supply chain attack
    MCP_SSRF             = "mcp_ssrf"               # MCP SSRF vulnerability
    EXFILTRATION_ATTEMPT = "exfiltration_attempt"   # credential theft pattern
    SCALING_ATTACK       = "scaling_attack"         # image scaling injection (Trail of Bits)
    EMBEDDED_JS          = "embedded_js"            # executable JS in PDF/SVG


class Severity(str, Enum):
    CRITICAL = "critical"   # block immediately
    HIGH     = "high"       # block + alert
    MEDIUM   = "medium"     # warn + log
    LOW      = "low"        # log only


@dataclass
class Threat:
    type:              ThreatType
    severity:          Severity
    confidence:        float           # 0.0 – 1.0
    description:       str
    extracted_content: str             # the actual adversarial text found
    location:          Optional[str] = None  # 'pdf_annotation_layer', 'image_lsb', etc.


@dataclass
class ScanResult:
    file_path:    str
    scanner:      str                                          # 'pdf' | 'image' | 'skill' | 'mcp' | 'code'
    modality:     str                                          # same as scanner, used in API
    threats:      list[Threat] = field(default_factory=list)
    stage:        int = 1                                      # 1 = fast triage, 2 = deep inspection
    scan_duration_ms: float = 0.0
    metadata:     dict = field(default_factory=dict)

    # Set on __post_init__
    scan_id:      str = field(default_factory=lambda: str(uuid.uuid4()))
    scanned_at:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    input_hash:   str = ""

    def __post_init__(self) -> None:
        if not self.input_hash and self.file_path:
            try:
                with open(self.file_path, "rb") as f:
                    self.input_hash = hashlib.sha256(f.read()).hexdigest()
            except Exception:
                self.input_hash = ""

    @property
    def decision(self) -> Literal["clean", "suspicious", "blocked"]:
        if not self.threats:
            return "clean"
        max_sev = max(self.threats, key=lambda t: ["low","medium","high","critical"].index(t.severity.value))
        if max_sev.severity in (Severity.CRITICAL, Severity.HIGH):
            return "blocked"
        return "suspicious"

    @property
    def clean(self) -> bool:
        return self.decision == "clean"

    @property
    def blocked(self) -> bool:
        return self.decision == "blocked"

    @property
    def latency_ms(self) -> int:
        return int(self.scan_duration_ms)

    @property
    def confidence(self) -> float:
        if not self.threats:
            return 1.0
        return round(max(t.confidence for t in self.threats), 3)
