"""
CLI entry point.

Usage:
    nulvec scan invoice.pdf
    nulvec scan . --summary
    nulvec install
    nulvec status
    nulvec doctor
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.request import urlopen

from nulvec.machine import (
    append_event,
    current_repo_root,
    discover_real_clawhub_binary,
    discover_real_git_binary,
    doctor_report,
    install_managed_hooks,
    install_hook,
    install_machine,
    load_approved_hashes,
    load_policy,
    log_path,
    skill_install_root,
    write_approved_hashes,
    status_report,
)
from nulvec.mcp_proxy.stdio import run_stdio_proxy
from nulvec.models import ScanResult, Severity
from nulvec.report import generate_threat_report
from nulvec.scanner import is_supported_path, scan


IGNORED_DIR_NAMES = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
}
SEVERITY_ORDER = {
    Severity.LOW.value: 0,
    Severity.MEDIUM.value: 1,
    Severity.HIGH.value: 2,
    Severity.CRITICAL.value: 3,
}
POLICY_ACTIONS = ("block", "warn", "log")

# Exit codes for `nulvec scan` — used for CI integration
EXIT_CLEAN = 0
EXIT_BLOCKED = 1
EXIT_WARNED = 2


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="nulvec",
        description="Nulvec — Perceptual AI Security Scanner",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    scan_cmd = sub.add_parser("scan", help="Scan a file or directory for adversarial content")
    scan_cmd.add_argument("target", type=Path, help="Path to file or directory")
    scan_cmd.add_argument("--json", action="store_true", help="Output as JSON")
    scan_cmd.add_argument("--summary", action="store_true", help="Group output by modality and severity (directory scans only)")
    scan_cmd.add_argument(
        "--block-on",
        type=_severity_arg,
        default=Severity.LOW.value,
        choices=tuple(SEVERITY_ORDER),
        help="Exit non-zero only when a threat meets or exceeds this severity",
    )

    report_cmd = sub.add_parser("report", help="Scan multiple files and generate a PDF Threat Report")
    report_cmd.add_argument("files", nargs="+", type=Path, help="Paths to files to scan")
    report_cmd.add_argument("--output", type=Path, default=Path("threat_report.pdf"), help="Output PDF path")

    hook_cmd = sub.add_parser("install-hook", help="Install git hooks that scan repos after checkout/merge")
    hook_cmd.add_argument(
        "--scope",
        choices=("global", "local"),
        default="global",
        help="Install hooks globally or only in the current repository",
    )
    hook_cmd.add_argument(
        "--block-on",
        type=_severity_arg,
        default=Severity.HIGH.value,
        choices=tuple(SEVERITY_ORDER),
        help="Severity threshold used when the hook runs nulvec scan",
    )
    hook_cmd.add_argument(
        "--action",
        choices=POLICY_ACTIONS,
        default="warn",
        help="Policy action when threats meet or exceed the severity threshold",
    )

    install_cmd = sub.add_parser("install", help="Set up machine-level Nulvec protection and default policy")
    install_cmd.add_argument(
        "--block-on",
        type=_severity_arg,
        default=Severity.HIGH.value,
        choices=tuple(SEVERITY_ORDER),
        help="Default severity threshold used by installed protections",
    )
    install_cmd.add_argument(
        "--action",
        choices=POLICY_ACTIONS,
        default="warn",
        help="Default policy action used by installed protections",
    )

    status_cmd = sub.add_parser("status", help="Show installed protections and supported integrations")
    status_cmd.add_argument("--json", action="store_true", help="Output as JSON")

    doctor_cmd = sub.add_parser("doctor", help="Run installation health checks")
    doctor_cmd.add_argument("--json", action="store_true", help="Output as JSON")

    logs_cmd = sub.add_parser("logs", help="Show recent local Nulvec audit events")
    logs_cmd.add_argument("--json", action="store_true", help="Output as JSON")
    logs_cmd.add_argument("--limit", type=int, default=20, help="Number of recent events to show")

    config_cmd = sub.add_parser("config", help="Inspect local Nulvec configuration")
    config_sub = config_cmd.add_subparsers(dest="config_command", required=True)
    config_show_cmd = config_sub.add_parser("show", help="Show the effective local policy")
    config_show_cmd.add_argument("--json", action="store_true", help="Output as JSON")

    skill_cmd = sub.add_parser("skill", help="Protected skill workflows")
    skill_sub = skill_cmd.add_subparsers(dest="skill_command", required=True)
    skill_install_cmd = skill_sub.add_parser("install", help="Scan and install a skill artifact through Nulvec")
    skill_install_cmd.add_argument("source", help="Local path or direct URL to a skill artifact")
    skill_install_cmd.add_argument("--name", help="Override the installed skill name")
    skill_install_cmd.add_argument("--dest", type=Path, help="Override the destination directory")
    skill_install_cmd.add_argument("--force", action="store_true", help="Replace an existing installed skill")

    mcp_proxy_cmd = sub.add_parser("mcp-proxy", help="Proxy stdio MCP traffic through Nulvec scanning")
    mcp_proxy_cmd.add_argument("server_command", nargs=argparse.REMAINDER, help="Command to run the real MCP server")

    hook_runner_cmd = sub.add_parser("_git-hook-run", help=argparse.SUPPRESS)
    hook_runner_cmd.add_argument("hook_name")
    hook_runner_cmd.add_argument("repo_root", type=Path)
    hook_runner_cmd.add_argument("block_on", choices=tuple(SEVERITY_ORDER))
    hook_runner_cmd.add_argument("action", choices=POLICY_ACTIONS)

    git_shim_cmd = sub.add_parser("_git-shim", help=argparse.SUPPRESS)
    git_shim_cmd.add_argument("git_args", nargs=argparse.REMAINDER)

    clawhub_shim_cmd = sub.add_parser("_clawhub-shim", help=argparse.SUPPRESS)
    clawhub_shim_cmd.add_argument("clawhub_args", nargs=argparse.REMAINDER)

    args = parser.parse_args()

    if args.command == "scan":
        try:
            target = args.target.resolve()
            if target.is_dir():
                _run_directory_scan(target, args.json, args.block_on, getattr(args, "summary", False))
                return

            result = scan(target)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        if args.json:
            print(json.dumps(asdict(result), indent=2, default=str))
        else:
            _print_single_scan_result(result)

        sys.exit(_scan_cli_exit_code([result], args.block_on))

    elif args.command == "report":
        print(f"Scanning {len(args.files)} files for comprehensive threat report...")
        results = []
        for file_path in args.files:
            try:
                res = scan(file_path)
                results.append(res)
                status_char = "+" if res.clean else "x"
                print(f"  {status_char} Scanned {file_path.name} -> {res.decision.upper()}")
            except Exception as e:
                print(f"  ! Error scanning {file_path.name}: {e}")

        pdf_path = generate_threat_report(results, args.output)
        print(f"\nPDF Compliance Report written to: {pdf_path}")
        sys.exit(0)

    elif args.command == "install-hook":
        try:
            installed = install_hook(args.scope, args.block_on, args.action, cwd=Path.cwd())
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        for path in installed:
            print(f"Installed hook: {path}")
        sys.exit(0)

    elif args.command == "install":
        try:
            report = install_machine(args.block_on, args.action, cwd=Path.cwd())
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        _print_install_report(report, args.action)
        sys.exit(0)

    elif args.command == "status":
        report = status_report(Path.cwd())
        if args.json:
            print(json.dumps(report, indent=2))
        else:
            _print_status(report)
        sys.exit(0)

    elif args.command == "doctor":
        report = doctor_report(Path.cwd())
        if args.json:
            print(json.dumps(report, indent=2))
        else:
            _print_doctor(report)
        sys.exit(1 if report["summary"]["failed"] else 0)

    elif args.command == "logs":
        records = _read_recent_events(args.limit)
        if args.json:
            print(json.dumps(records, indent=2))
        else:
            _print_logs(records)
        sys.exit(0)

    elif args.command == "config":
        if args.config_command == "show":
            policy = load_policy()
            if args.json:
                print(json.dumps(policy, indent=2))
            else:
                _print_config(policy)
            sys.exit(0)

    elif args.command == "skill":
        if args.skill_command == "install":
            sys.exit(_run_skill_install(args.source, args.name, args.dest, args.force))

    elif args.command == "mcp-proxy":
        sys.exit(run_stdio_proxy(args.server_command))

    elif args.command == "_git-hook-run":
        sys.exit(_run_git_hook(args.hook_name, args.repo_root, args.block_on, args.action))

    elif args.command == "_git-shim":
        sys.exit(_run_git_shim(args.git_args))

    elif args.command == "_clawhub-shim":
        sys.exit(_run_clawhub_shim(args.clawhub_args))


def _scan_cli_exit_code(results: list[ScanResult], block_on: str) -> int:
    """Return 0 (CLEAN), 1 (BLOCKED), or 2 (WARNED) for CI integration.

    0 = no threats found at all
    1 = at least one threat at or above block_on threshold (BLOCKED)
    2 = threats exist but all below block_on threshold (WARNED)
    """
    threshold = SEVERITY_ORDER[block_on]
    blocked = False
    warned = False
    for result in results:
        for threat in result.threats:
            sev_order = SEVERITY_ORDER[threat.severity.value]
            if sev_order >= threshold:
                blocked = True
            else:
                warned = True
    if blocked:
        return EXIT_BLOCKED
    if warned:
        return EXIT_WARNED
    return EXIT_CLEAN


def _run_directory_scan(target: Path, json_output: bool, block_on: str, summary: bool = False) -> None:
    results, skipped_files = _scan_directory(target)
    exit_code = _scan_cli_exit_code(results, block_on)

    if json_output:
        scan_summary = _summarize_results(results, skipped_files)
        print(json.dumps({
            "target": str(target),
            "block_on": block_on,
            "exit_code": exit_code,
            "summary": scan_summary,
            "items": [asdict(result) for result in results],
        }, indent=2, default=str))
    elif summary:
        _print_scan_summary(results, skipped_files, target, block_on)
    else:
        scan_summary = _summarize_results(results, skipped_files)
        print(f"\n{'='*60}")
        print("  Nulvec Scan Report")
        print(f"{'='*60}")
        print(f"  Target   : {target}")
        print(f"  Block on : {block_on.upper()}")
        print(f"  Files    : {scan_summary['scanned_files']} scanned, {scan_summary['skipped_files']} skipped")
        print(f"  Clean    : {scan_summary['clean']}")
        print(f"  Warning  : {scan_summary['suspicious']}")
        print(f"  Blocked  : {scan_summary['blocked']}")
        print(f"  Avg time : {scan_summary['avg_duration_ms']:.1f}ms")

        if not results:
            print("\n  No supported files found.\n")
        else:
            findings = [result for result in results if not result.clean]
            if findings:
                print("\n  Findings")
                for result in findings:
                    rel_path = _display_path(target, Path(result.file_path))
                    print(
                        f"  - {result.decision.upper():10} {result.modality:5} "
                        f"{rel_path} ({len(result.threats)} threat(s))"
                    )
            print(f"\n{'='*60}\n")

    sys.exit(exit_code)


def _print_scan_summary(results: list[ScanResult], skipped_files: int, target: Path, block_on: str) -> None:
    """Print grouped output by modality and severity for CI/summary use."""
    scan_summary = _summarize_results(results, skipped_files)
    exit_code = _scan_cli_exit_code(results, block_on)

    print(f"\n{'='*60}")
    print("  Nulvec Scan Summary")
    print(f"{'='*60}")
    print(f"  Target   : {target}")
    print(f"  Block on : {block_on.upper()}")
    print(f"  Files    : {scan_summary['scanned_files']} scanned, {scan_summary['skipped_files']} skipped")

    by_modality: dict[str, list[ScanResult]] = {}
    for result in results:
        by_modality.setdefault(result.modality, []).append(result)

    if by_modality:
        print("\n  By Modality")
        for modality, mod_results in sorted(by_modality.items()):
            threat_results = [r for r in mod_results if not r.clean]
            if not threat_results:
                print(f"    {modality:<10} {len(mod_results)} file(s)  clean")
            else:
                sev_counts: dict[str, int] = {}
                for r in threat_results:
                    for t in r.threats:
                        sev_counts[t.severity.value] = sev_counts.get(t.severity.value, 0) + 1
                sev_str = ", ".join(
                    f"{count} {sev.upper()}"
                    for sev, count in sorted(
                        sev_counts.items(),
                        key=lambda x: SEVERITY_ORDER[x[0]],
                        reverse=True,
                    )
                )
                print(f"    {modality:<10} {len(mod_results)} file(s)  {sev_str}")

    by_severity: dict[str, list[tuple[str, str]]] = {}
    for result in results:
        for threat in result.threats:
            sev = threat.severity.value
            by_severity.setdefault(sev, []).append(
                (_display_path(target, Path(result.file_path)), threat.type.value)
            )

    if by_severity:
        print("\n  By Severity")
        for sev in sorted(by_severity, key=lambda s: SEVERITY_ORDER[s], reverse=True):
            items = by_severity[sev]
            print(f"    {sev.upper()}")
            for file_path, threat_type in items[:5]:
                print(f"      {file_path}  ({threat_type})")
            if len(items) > 5:
                print(f"      ... and {len(items) - 5} more")

    exit_label = {EXIT_CLEAN: "CLEAN", EXIT_BLOCKED: "BLOCKED", EXIT_WARNED: "WARNED"}.get(exit_code, "UNKNOWN")
    print(f"\n  Result   : {exit_label} (exit {exit_code})")
    print(f"{'='*60}\n")


def _scan_directory(target: Path) -> tuple[list[ScanResult], int]:
    results: list[ScanResult] = []
    skipped_files = 0

    for root, dirnames, filenames in os.walk(target):
        dirnames[:] = sorted(
            dirname for dirname in dirnames
            if dirname not in IGNORED_DIR_NAMES
        )
        for filename in sorted(filenames):
            path = Path(root) / filename
            if not is_supported_path(path):
                skipped_files += 1
                continue
            results.append(scan(path))

    return results, skipped_files


def _summarize_results(results: list[ScanResult], skipped_files: int) -> dict[str, Any]:
    clean = sum(1 for result in results if result.clean)
    suspicious = sum(1 for result in results if result.decision == "suspicious")
    blocked = sum(1 for result in results if result.blocked)
    avg_duration_ms = (
        sum(result.scan_duration_ms for result in results) / len(results)
        if results else 0.0
    )
    return {
        "scanned_files": len(results),
        "skipped_files": skipped_files,
        "clean": clean,
        "suspicious": suspicious,
        "blocked": blocked,
        "avg_duration_ms": round(avg_duration_ms, 2),
    }


def _display_path(root: Path, path: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _severity_arg(value: str) -> str:
    return value.lower()


def _exit_code_for_results(results: list[ScanResult], block_on: str) -> int:
    """Internal threshold check: 0 if no threats at or above block_on, 1 otherwise."""
    threshold = SEVERITY_ORDER[block_on]
    for result in results:
        for threat in result.threats:
            if SEVERITY_ORDER[threat.severity.value] >= threshold:
                return 1
    return 0


def _run_git_hook(hook_name: str, repo_root: Path, block_on: str, action: str) -> int:
    target = repo_root.resolve()
    results, skipped_files = _scan_directory(target)
    summary = _summarize_results(results, skipped_files)
    exit_code = _exit_code_for_results(results, block_on)

    event = {
        "event": "git_hook_scan",
        "hook": hook_name,
        "repo_root": str(target),
        "block_on": block_on,
        "action": action,
        "summary": summary,
    }
    append_event(event)

    if exit_code == 0:
        return 0

    if action in {"warn", "block"}:
        print(
            f"[nulvec] {hook_name}: detected {summary['blocked']} blocked file(s) "
            f"at threshold {block_on.upper()}. Run `nulvec scan {target}` for details.",
            file=sys.stderr,
        )

    return 1 if action == "block" else 0


def _print_install_report(report: dict[str, Any], action: str) -> None:
    _print_banner("Protection wiring complete.")

    print("Activated")
    print(f"  [ready ] git shim      {report['git_shim']}")
    print(f"  [ready ] clawhub shim  {report['clawhub_shim']}")
    print(f"  [active] template hooks {_hook_summary(report['template_hooks'])}")
    if report["current_repo"] is None:
        print("  [scope ] local hooks    skipped (not inside a git repository)")
    else:
        print(f"  [active] local hooks    {_hook_summary(report['local_hooks'])}")
        print(f"  [scope ] current repo   {report['current_repo']}")
    print(f"  [active] skill install  {report['skill_install_root']}")
    mcp_clients = report.get("mcp_clients", {})
    if mcp_clients:
        for _client_id, client_info in mcp_clients.items():
            name = client_info["name"]
            status = client_info.get("status", "unknown")
            servers_patched = client_info.get("servers_patched", 0)
            error = client_info.get("error")
            if status == "patched" and servers_patched > 0:
                print(f"  [active] mcp {name:<16} patched ({servers_patched} server(s))")
            elif status == "patched":
                print(f"  [active] mcp {name:<16} patched (no servers configured yet)")
            elif status == "not_found":
                print(f"  [ready ] mcp {name:<16} config not found — install {name} to enable")
            else:
                print(f"  [ready ] mcp {name:<16} {status}: {error or 'unknown error'}")
    else:
        print("  [ready ] mcp proxy      manual client setup still required")
    print(f"  [file  ] policy         {report['policy_file']}")
    print(f"  [file  ] audit log      {report['log_file']}")
    print(f"  [file  ] shell rc       {report['shell_rc']}")
    print(f"  [file  ] git template   {report['git_template_dir']}\n")

    print("Next")
    print(f"  1. Activate the git shim: source {report['shell_rc']}")
    print("  2. Check live status: nulvec status")
    print("  3. Run health checks: nulvec doctor")
    if action == "block":
        print("  4. Block mode is active for git clone, pull, and skill install flows")


def _print_status(report: dict[str, Any]) -> None:
    _print_banner("Status")

    # Integration summary table
    git_active = report["git"]["shim_active"]
    clawhub_shim_exists = report["clawhub"].get("shim_exists", False)
    mcp_clients = report["mcp"].get("clients", {})
    any_mcp_patched = any(c.get("status") in {"patched", "partial"} for c in mcp_clients.values())

    block_on = report["git"]["block_on"]
    threshold = SEVERITY_ORDER[block_on]
    blocked_sevs = [
        s.upper()
        for s, o in sorted(SEVERITY_ORDER.items(), key=lambda x: x[1], reverse=True)
        if o >= threshold
    ]
    policy_detail = "block on " + " + ".join(blocked_sevs)

    git_detail = (
        f"{report['git']['shim_path']} in PATH"
        if git_active
        else "shim not active; open a new shell or source " + report["git"]["shell_rc"]
    )
    mcp_client_parts = []
    for client_info in mcp_clients.values():
        name = client_info["name"]
        client_status = client_info.get("status", "unknown")
        if client_status == "patched":
            mcp_client_parts.append(f"{name} (patched)")
        elif client_status == "partial":
            mcp_client_parts.append(f"{name} (partial)")
        elif client_status == "not_found":
            mcp_client_parts.append(f"{name} (not found)")
        else:
            mcp_client_parts.append(f"{name} ({client_status})")
    mcp_detail = ", ".join(mcp_client_parts) if mcp_client_parts else "no clients found"

    git_label = "ACTIVE  " if git_active else "INACTIVE"
    mcp_label = "ACTIVE  " if any_mcp_patched else "INACTIVE"
    clawhub_label = "ACTIVE  " if clawhub_shim_exists else "INACTIVE"
    clawhub_detail = "clawhub shim installed" if clawhub_shim_exists else "clawhub shim missing; run `nulvec install`"

    print("Integrations")
    print(f"  {'Git clone protection':<22} {git_label} {git_detail}")
    print(f"  {'MCP proxy':<22} {mcp_label} {mcp_detail}")
    print(f"  {'Skill install':<22} {clawhub_label} {clawhub_detail}")
    print(f"  {'Policy':<22}          {policy_detail}")
    print()

    print("Runtime")
    print(f"  install     {'ready' if report['installed'] else 'not installed'}")
    print(
        f"  policy      {'present' if report['policy_exists'] else 'missing'} "
        f"({report['policy_file']})"
    )
    print(f"  logs        {report['log_file']}")
    print(f"  repo        {report['current_repo'] or 'not inside a git repository'}\n")

    print("Git")
    print(f"  policy      action={report['git']['action']} block_on={report['git']['block_on']}")
    print(
        f"  shim        {'active' if report['git']['shim_active'] else 'inactive'} "
        f"({report['git']['shim_path']})"
    )
    print(
        f"  shell rc    {'managed' if report['git']['shell_rc_managed'] else 'missing block'} "
        f"({report['git']['shell_rc']})"
    )
    print(
        "  hooks       "
        f"template={report['git']['template_hooks']['post-checkout']}/{report['git']['template_hooks']['post-merge']} "
        f"local={report['git']['local_hooks']['post-checkout']}/{report['git']['local_hooks']['post-merge']}"
    )
    print(f"  template    {report['git']['template_dir_configured'] or 'not configured'}")
    if not report["git"]["shim_active"]:
        print("  note        open a new shell or source your shell rc file to activate the git shim")
    print()

    print("Skills")
    print(f"  root        {report['clawhub']['install_root']}")
    print(f"  shim        {report['clawhub'].get('shim_path', 'n/a')}")
    print(f"  cache       {report['clawhub']['approved_hash_count']} approved artifact hashes")
    print(f"  policy      action={report['clawhub']['action']} block_on={report['clawhub']['block_on']}\n")

    print("MCP")
    print(f"  mode        {report['mcp']['mode']}")
    print(f"  policy      action={report['mcp']['action']} block_on={report['mcp']['block_on']}")
    for client_info in mcp_clients.values():
        client_status = client_info.get("status", "unknown")
        config_path = client_info.get("config_path", "n/a")
        print(f"  {client_info['name']:<18} {client_status} ({config_path})")
    print()

    print("Supported")
    for name, data in report["integrations"].items():
        support = "supported" if data["supported"] else "planned"
        enabled = "enabled" if data.get("enabled") else "disabled"
        print(f"  {name:7} {support:9} {enabled:8} {data['notes']}")


def _print_doctor(report: dict[str, Any]) -> None:
    print("Nulvec doctor")
    for item in report["checks"]:
        label = item["status"].upper().ljust(4)
        print(f"[{label}] {item['name']}: {item['detail']}")


def _read_recent_events(limit: int) -> list[dict[str, Any]]:
    if limit <= 0:
        return []

    path = log_path()
    if not path.exists():
        return []

    records: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records[-limit:]


def _print_logs(records: list[dict[str, Any]]) -> None:
    print("Nulvec logs")
    if not records:
        print("No local audit events recorded yet.")
        return

    for record in records:
        event_name = record.get("event", "unknown")
        action = record.get("action", "-")
        recorded_at = record.get("recorded_at", "-")
        summary = record.get("summary", {})
        summary_text = ""
        if isinstance(summary, dict) and summary:
            summary_text = (
                f" scanned={summary.get('scanned_files', 0)}"
                f" blocked={summary.get('blocked', 0)}"
                f" suspicious={summary.get('suspicious', 0)}"
            )
        print(f"[{recorded_at}] {event_name} action={action}{summary_text}")


def _print_config(policy: dict[str, Any]) -> None:
    print("Nulvec config")
    print(json.dumps(policy, indent=2))


def _print_banner(label: str) -> None:
    print("N   N U   U L     V   V EEEEE CCCCC")
    print("NN  N U   U L     V   V E     C")
    print("N N N U   U L      V V  EEEE  C")
    print("N  NN U   U L      V V  E     C")
    print("N   N  UUU  LLLLL   V   EEEEE CCCCC")
    print()
    print(label)
    print("-" * len(label))
    print()


def _hook_summary(paths: list[str]) -> str:
    if not paths:
        return "none"
    return ", ".join(Path(path).name for path in paths)


def _print_single_scan_result(result: ScanResult) -> None:
    if result.clean:
        print(f"✓ CLEAN · {result.scan_duration_ms:.1f}ms · 0 threats")
        return

    threat = _primary_threat(result)
    decision_label = "BLOCKED" if result.blocked else "WARN"
    severity_label = threat.severity.value.upper()
    threat_label = threat.type.value.upper()
    print(f"✗ {decision_label} · {severity_label} · {threat_label}")
    print(f"File: {_format_scan_location(result.file_path, threat.location)}")

    evidence = (threat.extracted_content or "").strip() or threat.description
    if "\n" in evidence:
        print("Found:")
        print(evidence)
    else:
        print(f"Found: {evidence}")

    print()
    print(_remediation_hint(threat))
    if len(result.threats) > 1:
        print(f"+ {len(result.threats) - 1} more threat(s) found")


def _primary_threat(result: ScanResult) -> Any:
    return max(
        result.threats,
        key=lambda threat: (
            SEVERITY_ORDER[threat.severity.value],
            threat.confidence,
            len(threat.extracted_content or ""),
        ),
    )


def _format_scan_location(file_path: str, location: str | None) -> str:
    if not location:
        return file_path
    return f"{file_path} ({location})"


def _remediation_hint(threat: Any) -> str:
    hints = {
        "skill_malware": "Remove this skill. The installer executes hostile or remote shell instructions.",
        "exfiltration_attempt": "Remove this file or skill. It contains explicit data exfiltration behavior.",
        "mcp_ssrf": "Do not trust this MCP response. It attempts to redirect the agent to unsafe infrastructure.",
        "embedded_js": "Remove the embedded script before allowing this document into an agent workflow.",
        "hidden_instruction": "Remove the hidden instruction before letting an agent read this file.",
        "steganographic": "Do not pass this image to an agent until the hidden payload is removed.",
        "scaling_attack": "Do not pass this image to an agent until the scaling payload is removed.",
        "metadata_poison": "Strip hostile metadata before using this file with an agent.",
        "css_injection": "Remove the hidden content before letting an agent parse this asset.",
    }
    return hints.get(
        threat.type.value,
        "Review and remove the malicious content before letting an agent read this file.",
    )


def _run_skill_install(source: str, name: str | None, dest: Path | None, force: bool) -> int:
    policy = load_policy()
    skill_policy = policy.get("integrations", {}).get("clawhub", {})
    cleanup = lambda: None

    try:
        materialized = _resolve_skill_source(source)
        source_path, cleanup = materialized
        if not _artifact_contains_skill_definition(source_path):
            raise RuntimeError("Skill artifact must contain a markdown skill definition.")

        artifact_hash = _hash_artifact(source_path)
        approved_hashes = load_approved_hashes()
        cached_entry = approved_hashes.get(artifact_hash)
        skill_name = _resolve_skill_name(source_path, source, name)
        destination = _resolve_skill_destination(dest, skill_name)

        if cached_entry is None:
            blocked, summary, first_threat = _scan_skill_artifact(
                source_path,
                skill_policy,
                source=source,
                artifact_hash=artifact_hash,
            )
            if blocked:
                if first_threat is not None:
                    print(
                        f"[nulvec] blocked skill install: {first_threat.description} "
                        f"Evidence: {first_threat.extracted_content[:160]}",
                        file=sys.stderr,
                    )
                return 1

            approved_hashes[artifact_hash] = {
                "name": skill_name,
                "source": source,
                "approved_at": int(time.time()),
                "summary": summary,
            }
            write_approved_hashes(approved_hashes)
        else:
            summary = cached_entry.get("summary", {})
            print(f"[nulvec] approved hash cache hit for {skill_name}; skipping re-scan.", file=sys.stderr)

        _install_skill_artifact(source_path, destination, force)
        append_event(
            {
                "event": "skill_install",
                "source": source,
                "artifact_hash": artifact_hash,
                "destination": str(destination),
                "cached_approval": cached_entry is not None,
                "summary": summary,
            }
        )
        print(f"Installed skill: {destination}")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        cleanup()


def _resolve_skill_source(source: str) -> tuple[Path, Any]:
    candidate = Path(source).expanduser()
    if candidate.exists():
        return candidate.resolve(), (lambda: None)

    parsed = urlparse(source)
    if parsed.scheme in {"http", "https"}:
        temp_dir = Path(tempfile.mkdtemp(prefix=".nulvec-skill-"))
        filename = Path(parsed.path).name or "SKILL.md"
        download_path = temp_dir / filename
        with urlopen(source) as response:
            download_path.write_bytes(response.read())
        return download_path, (lambda: shutil.rmtree(temp_dir, ignore_errors=True))

    raise RuntimeError("Skill source must be an existing local path or a direct http(s) URL.")


def _artifact_contains_skill_definition(path: Path) -> bool:
    if path.is_file():
        return path.suffix.lower() in {".md", ".markdown"}

    return any(
        child.is_file() and child.suffix.lower() in {".md", ".markdown"}
        for child in path.rglob("*")
    )


def _resolve_skill_name(source_path: Path, source: str, name: str | None) -> str:
    candidate = name or (source_path.name if source_path.is_dir() else source_path.stem)
    if candidate.lower() == "skill" and source_path.parent.name:
        candidate = source_path.parent.name
    candidate = candidate.strip().replace(" ", "-")
    sanitized = "".join(ch for ch in candidate if ch.isalnum() or ch in {"-", "_", "."}).strip("-.")
    if sanitized:
        return sanitized
    raise RuntimeError(f"Could not derive a skill name from {source!r}.")


def _resolve_skill_destination(dest: Path | None, skill_name: str) -> Path:
    if dest is not None:
        return dest.expanduser().resolve()
    return (skill_install_root() / skill_name).resolve()


def _scan_skill_artifact(
    source_path: Path,
    skill_policy: dict[str, Any],
    *,
    source: str,
    artifact_hash: str,
) -> tuple[bool, dict[str, Any], Any]:
    if source_path.is_dir():
        results, skipped_files = _scan_directory(source_path)
    else:
        if not is_supported_path(source_path):
            raise RuntimeError(f"Unsupported skill artifact: {source_path.name}")
        results = [scan(source_path)]
        skipped_files = 0

    if not results:
        raise RuntimeError("No supported files were found in the skill artifact.")

    summary = _summarize_results(results, skipped_files)
    block_on = skill_policy.get("block_on", Severity.HIGH.value)
    action = skill_policy.get("action", "block")
    exit_code = _exit_code_for_results(results, block_on)
    blocked = exit_code != 0 and action == "block"
    first_threat = next((threat for result in results for threat in result.threats), None)

    append_event(
        {
            "event": "skill_install_scan",
            "source": source,
            "artifact_hash": artifact_hash,
            "block_on": block_on,
            "action": action,
            "summary": summary,
        }
    )
    if not blocked and action == "warn" and summary["blocked"]:
        print(
            f"[nulvec] warning: skill scan found {summary['blocked']} blocked file(s); policy action is WARN so install will continue.",
            file=sys.stderr,
        )

    return blocked, summary, first_threat


def _install_skill_artifact(source_path: Path, destination: Path, force: bool) -> None:
    if destination.exists():
        if not force:
            raise RuntimeError(f"Destination already exists: {destination}. Use --force to replace it.")
        if destination.is_dir():
            shutil.rmtree(destination)
        else:
            destination.unlink()

    destination.parent.mkdir(parents=True, exist_ok=True)
    if source_path.is_dir():
        shutil.copytree(source_path, destination)
        return

    destination.mkdir(parents=True, exist_ok=True)
    target_name = "SKILL.md" if source_path.suffix.lower() in {".md", ".markdown"} else source_path.name
    shutil.copy2(source_path, destination / target_name)


def _hash_artifact(path: Path) -> str:
    digest = hashlib.sha256()
    if path.is_file():
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
        return digest.hexdigest()

    for file_path in sorted(child for child in path.rglob("*") if child.is_file()):
        digest.update(str(file_path.relative_to(path)).encode("utf-8"))
        digest.update(file_path.read_bytes())
    return digest.hexdigest()


def _run_git_shim(git_args: list[str]) -> int:
    policy = load_policy()
    git_policy = policy.get("integrations", {}).get("git", {})
    try:
        real_git = discover_real_git_binary(policy)
    except RuntimeError:
        print("Error: could not locate the real git binary.", file=sys.stderr)
        return 1

    if not git_args:
        return _run_real_git(real_git, [])

    command = git_args[0]
    if command == "clone":
        return _intercept_git_clone(real_git, git_args, git_policy)
    if command == "pull":
        return _intercept_git_pull(real_git, git_args, git_policy)
    return _run_real_git(real_git, git_args)


def _run_clawhub_shim(clawhub_args: list[str]) -> int:
    """Intercept 'clawhub install <source>' and route through nulvec skill scanning."""
    if clawhub_args and clawhub_args[0] == "install" and len(clawhub_args) >= 2:
        source = clawhub_args[1]
        return _run_skill_install(source, None, None, False)

    real_clawhub = discover_real_clawhub_binary()
    if real_clawhub is None:
        print(
            "Error: clawhub not found on PATH. Install clawhub or use `nulvec skill install <path>`.",
            file=sys.stderr,
        )
        return 1
    return subprocess.run([real_clawhub, *clawhub_args], check=False).returncode


def _intercept_git_clone(real_git: str, git_args: list[str], git_policy: dict[str, Any]) -> int:
    parsed = _parse_clone_args(git_args[1:])
    if parsed is None:
        return _run_real_git(real_git, git_args)

    clone_args, final_dir = parsed
    final_dir = final_dir.resolve()
    if final_dir.exists():
        return _run_real_git(real_git, git_args)

    final_dir.parent.mkdir(parents=True, exist_ok=True)
    temp_dir = Path(tempfile.mkdtemp(prefix=f".nulvec-clone-{final_dir.name}-", dir=str(final_dir.parent)))
    clone_with_temp = [*clone_args, str(temp_dir)]

    try:
        result = _run_real_git(real_git, ["clone", *clone_with_temp], nulvec_internal=True)
        if result != 0:
            return result

        blocked, summary = _scan_repo_for_git_action(temp_dir, git_policy, "git_clone_scan")
        if blocked:
            print(
                f"[nulvec] blocked git clone into {final_dir} after scan found {summary['blocked']} blocked file(s).",
                file=sys.stderr,
            )
            shutil.rmtree(temp_dir, ignore_errors=True)
            return 1

        temp_dir.replace(final_dir)
        try:
            install_managed_hooks(
                final_dir / ".git" / "hooks",
                block_on=git_policy.get("block_on", Severity.HIGH.value),
                action=git_policy.get("action", "warn"),
                backup_existing=True,
            )
        except Exception:
            pass

        return 0
    finally:
        if temp_dir.exists():
            shutil.rmtree(temp_dir, ignore_errors=True)


def _intercept_git_pull(real_git: str, git_args: list[str], git_policy: dict[str, Any]) -> int:
    pull_args = git_args[1:]
    if any(arg.startswith("-") for arg in pull_args):
        return _run_real_git(real_git, git_args)

    repo_root = current_repo_root(Path.cwd())
    if repo_root is None:
        return _run_real_git(real_git, git_args)

    remote_args = pull_args
    fetch_cmd = [real_git, "fetch", *remote_args]
    if subprocess.run(fetch_cmd, env=_nulvec_internal_env()).returncode != 0:
        return 1

    ref_to_scan = "FETCH_HEAD"
    if not remote_args:
        upstream = subprocess.run(
            [real_git, "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}"],
            check=False,
            capture_output=True,
            text=True,
        ).stdout.strip()
        if upstream:
            ref_to_scan = upstream

    worktree_dir = Path(tempfile.mkdtemp(prefix=".nulvec-pull-", dir=str(repo_root.parent)))
    try:
        add_worktree = subprocess.run(
            [real_git, "worktree", "add", "--detach", str(worktree_dir), ref_to_scan],
            check=False,
            env=_nulvec_internal_env(),
        )
        if add_worktree.returncode != 0:
            return _run_real_git(real_git, git_args)

        blocked, summary = _scan_repo_for_git_action(worktree_dir, git_policy, "git_pull_scan")
        subprocess.run(
            [real_git, "worktree", "remove", "--force", str(worktree_dir)],
            check=False,
            env=_nulvec_internal_env(),
        )
        if blocked:
            print(
                f"[nulvec] blocked git pull after scan found {summary['blocked']} blocked file(s) in fetched changes.",
                file=sys.stderr,
            )
            return 1

        return _run_real_git(real_git, git_args)
    finally:
        if worktree_dir.exists():
            shutil.rmtree(worktree_dir, ignore_errors=True)


def _scan_repo_for_git_action(target: Path, git_policy: dict[str, Any], event_name: str) -> tuple[bool, dict[str, Any]]:
    block_on = git_policy.get("block_on", Severity.HIGH.value)
    action = git_policy.get("action", "warn")
    results, skipped_files = _scan_directory(target)
    summary = _summarize_results(results, skipped_files)
    blocked = _exit_code_for_results(results, block_on) != 0 and action == "block"
    append_event(
        {
            "event": event_name,
            "repo_root": str(target),
            "block_on": block_on,
            "action": action,
            "summary": summary,
        }
    )
    if not blocked and action == "warn" and summary["blocked"]:
        print(
            f"[nulvec] warning: scan found {summary['blocked']} blocked file(s); policy action is WARN so git will continue.",
            file=sys.stderr,
        )
    return blocked, summary


def _parse_clone_args(args: list[str]) -> tuple[list[str], Path] | None:
    option_args: list[str] = []
    positionals: list[str] = []
    i = 0
    options_with_values = {
        "--branch",
        "--depth",
        "--origin",
        "--template",
        "--config",
        "--reference",
        "--reference-if-able",
        "--separate-git-dir",
        "--upload-pack",
        "--filter",
        "--server-option",
        "--jobs",
        "-b",
        "-o",
        "-c",
        "-j",
        "-u",
    }

    while i < len(args):
        token = args[i]
        if token == "--":
            positionals.extend(args[i + 1 :])
            break
        if token.startswith("--"):
            option_args.append(token)
            if "=" not in token and token in options_with_values:
                i += 1
                if i >= len(args):
                    return None
                option_args.append(args[i])
        elif token.startswith("-") and token != "-":
            if len(token) > 2 and token not in options_with_values:
                return None
            option_args.append(token)
            if token in options_with_values:
                i += 1
                if i >= len(args):
                    return None
                option_args.append(args[i])
        else:
            positionals.append(token)
        i += 1

    if len(positionals) not in {1, 2}:
        return None

    repo = positionals[0]
    final_dir = Path(positionals[1]) if len(positionals) == 2 else Path(_default_clone_dir(repo))
    return [*option_args, repo], final_dir


def _default_clone_dir(repo: str) -> str:
    candidate = repo.rstrip("/").split("/")[-1]
    if candidate.endswith(".git"):
        candidate = candidate[:-4]
    return candidate or "repo"


def _nulvec_internal_env() -> dict[str, str]:
    return {**os.environ, "NULVEC_HOOK_ACTIVE": "1"}


def _run_real_git(real_git: str, args: list[str], *, nulvec_internal: bool = False) -> int:
    env = _nulvec_internal_env() if nulvec_internal else None
    return subprocess.run([real_git, *args], check=False, env=env).returncode


if __name__ == "__main__":
    main()
