"""
Stage 1: Fast Triage — runs on every input.

Target: <5ms on clean path (95%+ of inputs).
Returns CLEAN immediately for safe inputs.
Returns SUSPICIOUS for inputs that need Stage 2 deep inspection.

Checks (ordered fastest → slowest):
  1. Size anomaly    — reject empty or absurdly oversized files
  2. Magic bytes     — confirm format matches claimed extension
  3. Structural scan — modality-specific fast heuristics (no OCR)
  4. Quick text scan — is_adversarial_instruction() for text-based modalities
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from nulvec.utils import is_adversarial_instruction


# ── Size limits ───────────────────────────────────────────────────────────────
# Files over these limits are suspicious (DoS vector or anomalous payload)
_MAX_BYTES: dict[str, int] = {
    "image": 50 * 1024 * 1024,    # 50 MB
    "pdf":   100 * 1024 * 1024,   # 100 MB
    "skill": 1 * 1024 * 1024,     # 1 MB  — SKILL.md has no reason to be large
    "code":  5 * 1024 * 1024,     # 5 MB
    "mcp":   512 * 1024,          # 512 KB — tool responses are small
}
_MIN_BYTES = 4  # Anything smaller can't be a valid file


# ── Magic byte signatures ─────────────────────────────────────────────────────
_MAGIC: dict[str, bytes] = {
    ".pdf":  b"%PDF",
    ".png":  b"\x89PNG\r\n\x1a\n",
    ".jpg":  b"\xff\xd8\xff",
    ".jpeg": b"\xff\xd8\xff",
    ".bmp":  b"BM",
    ".gif":  b"GIF8",
}

# WEBP is RIFF....WEBP — special case
_WEBP_RIFF = b"RIFF"
_WEBP_TAG  = b"WEBP"


# ── Skill/code quick-scan patterns ────────────────────────────────────────────
# These are fast regex checks done before any OCR or PDF parsing.
_QUICK_PATTERNS = [
    re.compile(r"(?:curl|wget)\s+[^\n|]+\|\s*(?:ba)?sh", re.IGNORECASE),  # pipe-to-shell
    re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"),           # bare IP URL
    re.compile(r"(?:cat|base64)\s+~?/\.ssh/", re.IGNORECASE),              # SSH key read
    re.compile(r"(?:curl|wget).+@~?/\.ssh/", re.IGNORECASE),               # SSH key exfil
    re.compile(r"(?:curl|wget).+@~?/\.aws/", re.IGNORECASE),               # AWS credential exfil
    re.compile(r"(?:curl|wget).+@~?/\.kube/", re.IGNORECASE),              # kube config exfil
    re.compile(r"printenv|~/.aws/credentials|~/.kube/config", re.IGNORECASE),
    re.compile(r"<\|im_start\|>|<\|system\|>|\[INST\]|<<SYS>>"),           # LLM tokens
]


# ── Result type ───────────────────────────────────────────────────────────────

@dataclass
class TriageResult:
    verdict:    Literal["clean", "suspicious"]
    reason:     str
    checks_run: list[str] = field(default_factory=list)
    duration_ms: float = 0.0


# ── Public API ────────────────────────────────────────────────────────────────

def triage(file_path: str | Path, modality: str) -> TriageResult:
    """
    Fast triage pass. Returns CLEAN or SUSPICIOUS.

    This runs synchronously in the request path.
    CLEAN returns immediately — no Stage 2 needed.
    SUSPICIOUS triggers Stage 2 deep inspection.
    """
    path = Path(file_path)
    start = time.monotonic()
    checks: list[str] = []

    # 1. Size check
    size_result = _check_size(path, modality)
    checks.append("size")
    if size_result:
        return TriageResult(
            verdict="suspicious",
            reason=size_result,
            checks_run=checks,
            duration_ms=_ms(start),
        )

    # 2. Magic bytes (binary formats only)
    ext = path.suffix.lower()
    if ext in _MAGIC or ext == ".webp":
        magic_result = _check_magic(path, ext)
        checks.append("magic_bytes")
        if magic_result:
            return TriageResult(
                verdict="suspicious",
                reason=magic_result,
                checks_run=checks,
                duration_ms=_ms(start),
            )

    # 3. Modality-specific structural checks
    if modality in ("skill", "code", "mcp"):
        text_result = _check_text_content(path)
        checks.append("quick_text_scan")
        if text_result:
            return TriageResult(
                verdict="suspicious",
                reason=text_result,
                checks_run=checks,
                duration_ms=_ms(start),
            )

    elif modality == "pdf":
        pdf_result = _check_pdf_structure(path)
        checks.append("pdf_structure")
        if pdf_result:
            return TriageResult(
                verdict="suspicious",
                reason=pdf_result,
                checks_run=checks,
                duration_ms=_ms(start),
            )

    elif modality == "image":
        img_result = _check_image_structure(path)
        checks.append("image_structure")
        if img_result:
            return TriageResult(
                verdict="suspicious",
                reason=img_result,
                checks_run=checks,
                duration_ms=_ms(start),
            )
        # Images always proceed to Stage 2 — structural cleanliness does not
        # imply content safety. Scaling attacks and steganography require OCR
        # and pixel analysis, neither of which Stage 1 performs.
        return TriageResult(
            verdict="suspicious",
            reason="image requires Stage 2 OCR and steganography inspection",
            checks_run=checks,
            duration_ms=_ms(start),
        )

    # PDF: same reasoning — hidden-text detection requires full text extraction.
    if modality == "pdf":
        return TriageResult(
            verdict="suspicious",
            reason="PDF requires Stage 2 text extraction to detect hidden content",
            checks_run=checks,
            duration_ms=_ms(start),
        )

    return TriageResult(
        verdict="clean",
        reason="all triage checks passed",
        checks_run=checks,
        duration_ms=_ms(start),
    )


# ── Check implementations ─────────────────────────────────────────────────────

def _check_size(path: Path, modality: str) -> str | None:
    """Return error string if size is anomalous, else None."""
    try:
        size = path.stat().st_size
    except OSError:
        return "file not accessible"

    if size < _MIN_BYTES:
        return f"file too small ({size} bytes) — likely empty or truncated"

    limit = _MAX_BYTES.get(modality, 100 * 1024 * 1024)
    if size > limit:
        return f"file size {size:,} bytes exceeds {limit // 1024 // 1024}MB limit for {modality}"

    return None


def _check_magic(path: Path, ext: str) -> str | None:
    """Return error string if magic bytes don't match extension, else None."""
    try:
        with open(path, "rb") as f:
            header = f.read(16)
    except OSError:
        return None  # Can't read — let Stage 2 handle it

    if ext == ".webp":
        if not (header[:4] == _WEBP_RIFF and header[8:12] == _WEBP_TAG):
            return f"file claims .webp extension but magic bytes don't match RIFF/WEBP"
        return None

    expected = _MAGIC.get(ext)
    if expected and not header[: len(expected)] == expected:
        return (
            f"magic bytes mismatch for {ext}: "
            f"expected {expected.hex()}, got {header[:len(expected)].hex()} "
            f"— possible format spoofing"
        )
    return None


def _check_text_content(path: Path) -> str | None:
    """
    Quick scan of text content for known-bad patterns.
    Runs is_adversarial_instruction() on a sample to avoid full parse.
    """
    try:
        # Read first 64KB — enough to catch patterns in preamble
        text = path.read_text(encoding="utf-8", errors="replace")[:65536]
    except OSError:
        return None

    # Fast regex sweep
    for pattern in _QUICK_PATTERNS:
        m = pattern.search(text)
        if m:
            snippet = m.group(0)[:80]
            return f"suspicious pattern detected: {snippet!r}"

    # Sample lines for adversarial instruction check
    lines = [l.strip() for l in text.splitlines() if len(l.strip()) > 15]
    for line in lines[:200]:  # cap at 200 lines for speed
        if is_adversarial_instruction(line):
            return f"adversarial instruction pattern in text: {line[:80]!r}"

    return None


def _check_pdf_structure(path: Path) -> str | None:
    """
    Lightweight PDF structure check without full parse.
    Reads raw bytes to look for suspicious markers.
    """
    try:
        with open(path, "rb") as f:
            raw = f.read(8192)  # First 8KB covers header + object table start
    except OSError:
        return None

    raw_lower = raw.lower()

    # JavaScript in PDF is almost always suspicious in agent pipelines
    if b"/javascript" in raw_lower:
        return "PDF contains /JavaScript action in first 8KB"

    # Embedded files (can contain payloads)
    if b"/embeddedfile" in raw_lower:
        return "PDF contains /EmbeddedFile — may carry payload"

    # Launch actions (execute arbitrary programs)
    if b"/launch" in raw_lower:
        return "PDF contains /Launch action"

    return None


def _check_image_structure(path: Path) -> str | None:
    """
    Lightweight image structure check.
    Checks resolution vs file size ratio for anomaly detection.
    """
    try:
        from PIL import Image
        with Image.open(path) as img:
            w, h = img.size
            file_size = path.stat().st_size

            # Images with suspiciously high data density may carry steganographic payload
            pixels = w * h
            if pixels > 0:
                bytes_per_pixel = file_size / pixels
                # Uncompressed RGB = 3 bytes/pixel; PNG can be <1; JPEG typically 0.1-0.5
                # Unusually high ratio suggests non-image data appended
                if bytes_per_pixel > 10:
                    return (
                        f"anomalous file size vs resolution: "
                        f"{file_size:,} bytes for {w}×{h} ({bytes_per_pixel:.1f} bytes/pixel)"
                    )

            # Very small images are suspicious as scaling attack vectors
            # (they render as tiny thumbnails that hide text)
            if w < 32 or h < 32:
                return f"unusually small image ({w}×{h}) — potential scaling attack vector"

    except Exception:
        return None  # Let Stage 2 handle parse errors

    return None


def _ms(start: float) -> float:
    return round((time.monotonic() - start) * 1000, 3)
