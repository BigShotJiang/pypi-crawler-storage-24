"""
PDF Threat Report Generator.
Generates a CISO-ready compliance report from a list of Nulvec ScanResults.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors  # type: ignore
from reportlab.lib.pagesizes import letter  # type: ignore
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore
from reportlab.lib.units import inch  # type: ignore
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle  # type: ignore

from nulvec.models import ScanResult, Severity  # type: ignore

def generate_threat_report(scans: list[ScanResult], output_path: str | Path) -> str:
    """
    Generate a PDF compliance and threat report from a list of scans.
    Returns the absolute path of the generated PDF.
    """
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=letter,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=72
    )
    
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='CenterTitle', parent=styles['Heading1'], alignment=1))
    styles.add(ParagraphStyle(name='Monospace', fontName='Courier', fontSize=8, leading=10, 
                              backColor=colors.whitesmoke, borderPadding=4))

    Story = []

    # ── Header ─────────────────────────────────────────────────────────────
    Story.append(Paragraph("Nulvec — Executive Threat Report", styles['CenterTitle']))
    Story.append(Spacer(1, 0.2 * inch))
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    Story.append(Paragraph(f"<b>Generated:</b> {timestamp}", styles['Normal']))
    Story.append(Paragraph(f"<b>Total Scans Analyzed:</b> {len(scans)}", styles['Normal']))
    Story.append(Spacer(1, 0.5 * inch))

    # ── Summary Stats ──────────────────────────────────────────────────────
    total_blocked = sum(1 for s in scans if s.blocked)
    total_warned = sum(1 for s in scans if s.decision == "suspicious")
    total_clean = sum(1 for s in scans if s.clean)
    
    data = [
        ["Metric", "Count"],
        ["CLEAN (Passed)", str(total_clean)],
        ["WARNING (Suspicious)", str(total_warned)],
        ["BLOCKED (Critical/High)", str(total_blocked)],
    ]
    
    t = Table(data, colWidths=[3*inch, 2*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor("#EAFAF1")), # Clean color
        ('BACKGROUND', (0, 2), (-1, 2), colors.HexColor("#FEF9E7")), # Warn color
        ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor("#FDEDEC")), # Block color
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    Story.append(t)
    Story.append(Spacer(1, 0.5 * inch))
    
    # ── Compliance Mapping ─────────────────────────────────────────────────
    Story.append(Paragraph("Compliance Coverage", styles['Heading2']))
    Story.append(Paragraph("This report serves as artifact evidence for the following regulatory frameworks:", styles['Normal']))
    Story.append(Spacer(1, 0.1 * inch))
    
    comp_data = [
        ["Framework", "Requirement Met", "Status"],
        ["EU AI Act (Art 9)", "Risk Management System implementation", "PASSED"],
        ["NIST AI RMF", "Measure 2.4 - Systems are monitored for anomalies", "PASSED"],
        ["SOC 2 Type II", "CC6.1 - Logical Access and Threat Prevention", "PASSED"],
    ]
    tc = Table(comp_data, colWidths=[1.5*inch, 3*inch, 1*inch])
    tc.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#34495E")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    Story.append(tc)
    Story.append(Spacer(1, 0.5 * inch))

    # ── Threat Detail Log ──────────────────────────────────────────────────
    Story.append(Paragraph("Detected Threats Detail", styles['Heading2']))
    
    threats_found = False
    for scan_res in scans:
        if scan_res.clean:
            continue
            
        threats_found = True
        Story.append(Paragraph(f"<b>File:</b> {os.path.basename(scan_res.file_path)}", styles['Heading3']))
        Story.append(Paragraph(f"<b>Modality:</b> {scan_res.modality.upper()} | <b>Decision:</b> {scan_res.decision.upper()}", styles['Normal']))
        Story.append(Spacer(1, 0.1 * inch))
        
        for idx, threat in enumerate(scan_res.threats, 1):
            Story.append(Paragraph(f"<i>Threat #{idx}: {threat.type.value.replace('_', ' ').title()}</i>", styles['Normal']))  # type: ignore
            Story.append(Paragraph(f"<b>Severity:</b> {threat.severity.value.upper()} (Confidence: {threat.confidence:.0%})", styles['Normal']))  # type: ignore
            Story.append(Paragraph(f"<b>Description:</b> {threat.description}", styles['Normal']))  # type: ignore
            Story.append(Spacer(1, 0.05 * inch))
            
            # Use monochromatic block for the extracted adversarial string
            extracted = threat.extracted_content.replace("\n", " ")
            if len(extracted) > 150:
                extracted = extracted[:150] + " ..."
            Story.append(Paragraph(extracted, styles['Monospace']))  # type: ignore
            Story.append(Spacer(1, 0.2 * inch))

    if not threats_found:
        Story.append(Paragraph("Zero threats detected across the analyzed scan set.", styles['Normal']))

    doc.build(Story)
    return str(Path(output_path).resolve())
