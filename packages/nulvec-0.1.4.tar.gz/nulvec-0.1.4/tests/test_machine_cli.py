from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from nulvec.cli import main


def _configure_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    nulvec_home = tmp_path / "nulvec-home"
    git_config = tmp_path / "gitconfig"
    shell_rc = tmp_path / ".zshrc"
    monkeypatch.setenv("NULVEC_HOME", str(nulvec_home))
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(git_config))
    monkeypatch.setenv("NULVEC_SHELL_RC", str(shell_rc))
    return nulvec_home


def test_install_creates_policy_and_git_template(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path):
    nulvec_home = _configure_home(monkeypatch, tmp_path)
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("sys.argv", ["nulvec", "install", "--block-on", "critical", "--action", "warn"])

    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0

    policy = json.loads((nulvec_home / "policy.json").read_text())
    assert policy["integrations"]["git"]["block_on"] == "critical"
    assert policy["integrations"]["git"]["action"] == "warn"
    assert Path(policy["integrations"]["git"]["real_binary"]).exists()
    assert Path(policy["integrations"]["git"]["real_binary"]).resolve() != (nulvec_home / "bin" / "git").resolve()

    template_hook = nulvec_home / "git-template" / "hooks" / "post-checkout"
    local_hook = repo / ".git" / "hooks" / "post-checkout"
    git_shim = nulvec_home / "bin" / "git"
    shell_rc = tmp_path / ".zshrc"
    assert template_hook.exists()
    assert local_hook.exists()
    assert git_shim.exists()
    assert shell_rc.exists()
    assert 'export PATH="' in shell_rc.read_text()
    assert str(nulvec_home / "bin") in shell_rc.read_text()

    configured_template = subprocess.run(
        ["git", "config", "--global", "--get", "init.templateDir"],
        check=True,
        capture_output=True,
        text=True,
        cwd=repo,
    ).stdout.strip()
    assert configured_template == str(nulvec_home / "git-template")

    output = capsys.readouterr().out
    assert "N   N U   U L     V   V EEEEE CCCCC" in output
    assert "Protection wiring complete." in output
    assert "Activated" in output
    assert "source " in output


def test_status_json_reports_supported_integrations(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
):
    _configure_home(monkeypatch, tmp_path)
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("sys.argv", ["nulvec", "install"])
    with pytest.raises(SystemExit):
        main()
    capsys.readouterr()

    monkeypatch.setattr("sys.argv", ["nulvec", "status", "--json"])
    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["installed"] is True
    assert payload["git"]["shim_exists"] is True
    assert payload["git"]["shell_rc_managed"] is True
    assert payload["git"]["real_binary"]
    assert payload["clawhub"]["install_root_exists"] is True
    assert payload["clawhub"]["approved_hashes_file"]
    assert payload["integrations"]["git"]["supported"] is True
    assert payload["integrations"]["clawhub"]["supported"] is True
    assert payload["integrations"]["mcp"]["supported"] is True


def test_status_human_output_is_grouped(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
):
    _configure_home(monkeypatch, tmp_path)
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("sys.argv", ["nulvec", "install"])
    with pytest.raises(SystemExit):
        main()
    capsys.readouterr()

    monkeypatch.setattr("sys.argv", ["nulvec", "status"])
    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0
    output = capsys.readouterr().out
    assert "N   N U   U L     V   V EEEEE CCCCC" in output
    assert "Status" in output
    assert "Runtime" in output
    assert "Git" in output
    assert "Skills" in output
    assert "MCP" in output
    assert "Supported" in output


def test_doctor_fails_before_install(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path):
    _configure_home(monkeypatch, tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["nulvec", "doctor", "--json"])

    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 1
    payload = json.loads(capsys.readouterr().out)
    failed_checks = [item for item in payload["checks"] if item["status"] == "fail"]
    assert any(item["name"] == "policy_file" for item in failed_checks)


def test_doctor_passes_after_install(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path):
    _configure_home(monkeypatch, tmp_path)
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)

    monkeypatch.chdir(repo)
    monkeypatch.setattr("sys.argv", ["nulvec", "install"])
    with pytest.raises(SystemExit):
        main()
    capsys.readouterr()

    monkeypatch.setattr("sys.argv", ["nulvec", "doctor", "--json"])
    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["summary"]["failed"] is False
