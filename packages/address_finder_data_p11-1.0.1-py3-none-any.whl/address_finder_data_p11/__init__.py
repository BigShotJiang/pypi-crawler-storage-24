import importlib.resources as _ir
from pathlib import Path as _P

# Chunk metadata
CANONICAL_NAME = 'numex.dat'
FILE_CHUNK_INDEX = 0
TOTAL_FILE_CHUNKS = 1
CHUNK_SHA256 = '1195717690a2230e444106886fff0f0e85d9eb33f52422fde01772a3eecf3b3f'
FILE_ORIGINAL_SIZE = 396966

def chunk_path() -> _P:
    """Return path to the raw compressed chunk file."""            try:
        ref = _ir.files(__name__) / "data" / "chunk.bin"
        return _P(str(ref))
    except AttributeError:
        import pkg_resources
        return _P(pkg_resources.resource_filename(__name__, "data/chunk.bin"))
