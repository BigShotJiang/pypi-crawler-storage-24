import pytest

from tests.examples.ExamplePlugin import ExamplePlugin
from tests.examples.ExamplePluginConfig import ExamplePluginConfig


@pytest.fixture
def plugin():
    return ExamplePlugin(context={})


def test_config_schema_returns_example_plugin_config(plugin):
    assert plugin.config_schema() is ExamplePluginConfig


def test_configure_with_dict(plugin):
    plugin.configure({"greeting": "Hi", "retries": 2})
    assert plugin.config.greeting == "Hi"
    assert plugin.config.retries == 2


def test_configure_defaults(plugin):
    plugin.configure({})
    assert plugin.config.greeting == "Hello"
    assert plugin.config.retries == 3


def test_config_raises_before_configure(plugin):
    with pytest.raises(AssertionError):
        _ = plugin.config


def test_configure_invalid_config_raises(plugin):
    with pytest.raises(Exception):
        plugin.configure({"retries": "not-an-int"})


def test_repr_unconfigured(plugin):
    assert "configured=False" in repr(plugin)
    assert "initialised=False" in repr(plugin)


def test_repr_configured(plugin):
    plugin.configure({})
    assert "configured=True" in repr(plugin)
    assert "initialised=False" in repr(plugin)


def test_repr_initialised(plugin):
    plugin.configure({}).setup()
    assert "configured=True" in repr(plugin)
    assert "initialised=True" in repr(plugin)


def test_fluent_api_configure_returns_self(plugin):
    result = plugin.configure({})
    assert result is plugin


def test_fluent_api_initialise_returns_self(plugin):
    plugin.configure({})
    result = plugin.setup()
    assert result is plugin


def test_fluent_api_chaining(plugin):
    result = plugin.configure({"greeting": "Yo"}).setup()
    assert result is plugin
    assert plugin.config.greeting == "Yo"
    assert plugin._initialised is True


def test_teardown_callable(plugin):
    plugin.configure({}).setup()
    plugin.teardown()  # Should not raise


def test_context_access(plugin):
    # Plugin should be able to access context
    assert plugin.context == {}


def test_context_with_logger():
    import logging
    logger = logging.getLogger("test")
    context = {"logger": logger}
    plugin = ExamplePlugin(context)
    assert plugin.context["logger"] is logger


def test_init_accepts_any_type():
    # context is now generic — any type is valid
    plugin = ExamplePlugin(context="not-a-dict")  # type: ignore[arg-type]
    assert plugin.context == "not-a-dict"


def test_init_accepts_none():
    plugin = ExamplePlugin(context=None)
    assert plugin.context is None
