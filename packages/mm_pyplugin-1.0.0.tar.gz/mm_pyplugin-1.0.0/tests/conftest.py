"""Pytest configuration: register test example plugins as discoverable entry points."""
import pytest
from unittest.mock import MagicMock, patch

from tests.examples.ExamplePlugin import ExamplePlugin
from tests.examples.ExampleParentPlugin import ExampleParentPlugin
from mm_pyplugin.PluginUtils import PluginUtils


def _make_ep(cls):
    ep = MagicMock()
    ep.load.return_value = cls
    return ep


_TEST_ENTRY_POINTS = [_make_ep(ExamplePlugin), _make_ep(ExampleParentPlugin)]


@pytest.fixture(autouse=True)
def _register_test_plugins():
    """Patch entry_points so PluginUtils can discover the test example plugins."""
    PluginUtils.find_plugins.cache_clear()
    with patch("mm_pyplugin.PluginUtils.entry_points", return_value=_TEST_ENTRY_POINTS):
        yield
    PluginUtils.find_plugins.cache_clear()
