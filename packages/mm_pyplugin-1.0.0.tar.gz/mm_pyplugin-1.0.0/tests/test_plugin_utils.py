import pytest

from tests.examples.ExampleParentPlugin import ExampleParentPlugin
from tests.examples.ExamplePlugin import ExamplePlugin
from mm_pyplugin.PluginInstanceConfig import PluginInstanceConfig
from mm_pyplugin.PluginUtils import PluginUtils


EXAMPLE_PLUGIN_FULL_NAME = "tests.examples.ExamplePlugin.ExamplePlugin"


EXAMPLE_PARENT_PLUGIN_FULL_NAME = "tests.examples.ExampleParentPlugin.ExampleParentPlugin"


def test_find_plugins_contains_example_plugin():
    plugins = PluginUtils.find_plugins()
    assert EXAMPLE_PLUGIN_FULL_NAME in plugins
    assert plugins[EXAMPLE_PLUGIN_FULL_NAME] is ExamplePlugin


def test_find_plugins_contains_example_parent_plugin():
    plugins = PluginUtils.find_plugins()
    assert EXAMPLE_PARENT_PLUGIN_FULL_NAME in plugins
    assert plugins[EXAMPLE_PARENT_PLUGIN_FULL_NAME] is ExampleParentPlugin


def test_create_plugin_returns_configured_and_initialised_instance():
    instance_config = PluginInstanceConfig(
        plugin_class=EXAMPLE_PLUGIN_FULL_NAME,
        config={"greeting": "Hey", "retries": 1},
    )
    plugin = PluginUtils(context={}).create_plugin(instance_config)
    assert isinstance(plugin, ExamplePlugin)
    assert plugin.config.greeting == "Hey"
    assert plugin.config.retries == 1
    assert plugin._initialised is True


def test_create_plugin_uses_default_config():
    instance_config = PluginInstanceConfig(plugin_class=EXAMPLE_PLUGIN_FULL_NAME)
    plugin = PluginUtils(context={}).create_plugin(instance_config)
    assert plugin.config.greeting == "Hello"
    assert plugin.config.retries == 3
    assert plugin._initialised is True


def test_create_plugin_uses_instance_context():
    instance_config = PluginInstanceConfig(plugin_class=EXAMPLE_PLUGIN_FULL_NAME)
    default_ctx = {"source": "default"}
    plugin = PluginUtils(context=default_ctx).create_plugin(instance_config)
    assert isinstance(plugin, ExamplePlugin)


def test_create_plugin_context_override():
    instance_config = PluginInstanceConfig(plugin_class=EXAMPLE_PLUGIN_FULL_NAME)
    utils = PluginUtils(context={"source": "default"})
    override_ctx = {"source": "override"}
    plugin = utils.create_plugin(instance_config, context=override_ctx)
    assert isinstance(plugin, ExamplePlugin)


def test_create_plugin_unknown_class_raises():
    instance_config = PluginInstanceConfig(plugin_class="no.such.Plugin")
    with pytest.raises(KeyError, match="no.such.Plugin"):
        PluginUtils(context={}).create_plugin(instance_config)
