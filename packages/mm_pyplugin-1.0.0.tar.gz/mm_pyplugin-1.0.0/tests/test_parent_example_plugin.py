import pytest

from tests.examples.ExamplePlugin import ExamplePlugin
from tests.examples.ExampleParentPlugin import ExampleParentPlugin
from tests.examples.ExampleParentPluginConfig import ExampleParentPluginConfig
from mm_pyplugin.PluginInstanceConfig import PluginInstanceConfig

EXAMPLE_PLUGIN_FULL_NAME = "tests.examples.ExamplePlugin.ExamplePlugin"


@pytest.fixture
def plugin():
    p = ExampleParentPlugin(context={})
    p.configure({
        "child": {
            "plugin_class": EXAMPLE_PLUGIN_FULL_NAME,
            "config": {"greeting": "Hi", "retries": 2},
        }
    }).setup()
    return p


def test_config_schema_returns_parent_example_plugin_config():
    assert ExampleParentPlugin.config_schema() is ExampleParentPluginConfig


def test_config_child_is_plugin_instance_config(plugin):
    assert isinstance(plugin.config.child, PluginInstanceConfig)
    assert plugin.config.child.plugin_class == EXAMPLE_PLUGIN_FULL_NAME


def test_example_plugin_property_is_example_plugin(plugin):
    assert isinstance(plugin.example_plugin, ExamplePlugin)


def test_example_plugin_is_configured(plugin):
    assert plugin.example_plugin.config.greeting == "Hi"
    assert plugin.example_plugin.config.retries == 2


def test_example_plugin_default_config():
    p = ExampleParentPlugin(context={})
    p.configure({"child": {"plugin_class": EXAMPLE_PLUGIN_FULL_NAME}}).setup()
    assert p.example_plugin.config.greeting == "Hello"
    assert p.example_plugin.config.retries == 3


def test_example_plugin_not_available_before_configure():
    p = ExampleParentPlugin(context={})
    with pytest.raises(AttributeError):
        _ = p.example_plugin


def test_composite_plugin_fluent_api():
    p = ExampleParentPlugin(context={})
    result = p.configure({"child": {"plugin_class": EXAMPLE_PLUGIN_FULL_NAME}}).setup()
    assert result is p
    assert p._initialised is True


def test_composite_plugin_child_is_initialised():
    p = ExampleParentPlugin(context={})
    p.configure({"child": {"plugin_class": EXAMPLE_PLUGIN_FULL_NAME}}).setup()
    assert p.example_plugin._initialised is True


def test_composite_plugin_teardown():
    p = ExampleParentPlugin(context={})
    p.configure({"child": {"plugin_class": EXAMPLE_PLUGIN_FULL_NAME}}).setup()
    p.teardown()  # Should teardown child without raising
