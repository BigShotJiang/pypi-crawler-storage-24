from __future__ import annotations

from typing import Type, cast

from pydantic import BaseModel

from tests.examples.ExamplePlugin import ExamplePlugin
from tests.examples.ExampleParentPluginConfig import ExampleParentPluginConfig
from mm_pyplugin.CompositePlugin import CompositePlugin
from mm_pyplugin.PluginUtils import PluginUtils


class ExampleParentPlugin(CompositePlugin):
    """Example composite plugin that owns a child ExamplePlugin instance.

    Demonstrates how to use CompositePlugin for hierarchical plugin management
    and dependency injection with shared context.
    """

    _example_plugin: ExamplePlugin

    @classmethod
    def config_schema(cls) -> Type[BaseModel]:
        return ExampleParentPluginConfig

    def configure(self, config) -> "ExampleParentPlugin":
        """Configure parent and create child plugin."""
        super().configure(config)
        # Create child plugin using PluginUtils, passing same context for DI
        self._example_plugin = cast(
            ExamplePlugin,
            PluginUtils(self.context).create_plugin(self.config.child),
        )
        # Register child for lifecycle management
        self._register_child(self._example_plugin)
        return self

    def setup(self) -> "ExampleParentPlugin":
        """Initialize parent and all children."""
        logger = self.context.get("logger") if self.context is not None else None
        if logger:
            logger.info("Initializing ExampleParentPlugin")

        self._initialised = True
        # Initialize all registered children (they inherit same context)
        self._setup_children()
        return self

    @property
    def config(self) -> ExampleParentPluginConfig:
        assert self._config_obj is not None, "Plugin not configured; call configure() first"
        return cast(ExampleParentPluginConfig, self._config_obj)

    @property
    def example_plugin(self) -> ExamplePlugin:
        return self._example_plugin
