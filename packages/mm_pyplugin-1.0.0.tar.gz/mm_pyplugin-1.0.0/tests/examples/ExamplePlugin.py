from __future__ import annotations

from typing import Type, cast

from pydantic import BaseModel

from mm_pyplugin.PluginBase import PluginBase
from tests.examples.ExamplePluginConfig import ExamplePluginConfig


class ExamplePlugin(PluginBase):
    """Minimal concrete plugin demonstrating the full lifecycle and dependency injection."""

    @classmethod
    def config_schema(cls) -> Type[BaseModel]:
        return ExamplePluginConfig

    def setup(self) -> "ExamplePlugin":
        """
        Initialize the plugin (fluent API - returns self).

        Demonstrates accessing dependencies from context.
        """
        # Access logger from context if available
        logger = self.context.get("logger") if self.context is not None else None
        if logger:
            logger.info(f"Initializing ExamplePlugin with greeting='{self.config.greeting}'")

        self._initialised = True
        return self

    def teardown(self) -> None:
        """Cleanup resources."""
        logger = self.context.get("logger") if self.context is not None else None
        if logger:
            logger.info("Tearing down ExamplePlugin")

    @property
    def config(self) -> ExamplePluginConfig:
        assert self._config_obj is not None, "Plugin not configured; call configure() first"
        return cast(ExamplePluginConfig, self._config_obj)
