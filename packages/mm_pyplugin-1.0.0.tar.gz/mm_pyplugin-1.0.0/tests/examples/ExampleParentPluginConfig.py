from __future__ import annotations

from pydantic import BaseModel

from mm_pyplugin.PluginInstanceConfig import PluginInstanceConfig


class ExampleParentPluginConfig(BaseModel):
    """Config for ExampleParentPlugin, holds a child plugin instance config."""
    child: PluginInstanceConfig
