from __future__ import annotations

from pydantic import BaseModel


class ExamplePluginConfig(BaseModel):
    """Minimal config schema for the example plugin."""
    greeting: str = "Hello"
    retries: int = 3
