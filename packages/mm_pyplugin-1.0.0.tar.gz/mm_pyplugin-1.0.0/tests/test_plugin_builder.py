import pytest

from mm_pyplugin import PluginBuilder, CompositePluginBuilder
from tests.examples.ExamplePlugin import ExamplePlugin
from tests.examples.ExampleParentPlugin import ExampleParentPlugin


def test_plugin_builder_basic():
    ctx = {"env": "test"}
    plugin = (PluginBuilder(ExamplePlugin, ctx)
        .with_config({"greeting": "Builder says hi", "retries": 5})
        .build())

    assert isinstance(plugin, ExamplePlugin)
    assert plugin.config.greeting == "Builder says hi"
    assert plugin.config.retries == 5
    assert plugin._initialised is True
    assert plugin.context["env"] == "test"


def test_plugin_builder_without_context():
    plugin = (PluginBuilder(ExamplePlugin)
        .with_config({"greeting": "Test"})
        .build())

    assert isinstance(plugin, ExamplePlugin)
    assert plugin._initialised is True
    assert plugin.context is None


def test_plugin_builder_requires_config():
    ctx = {"env": "test"}
    builder = PluginBuilder(ExamplePlugin, ctx)

    with pytest.raises(ValueError, match="Configuration required"):
        builder.build()


def test_plugin_builder_default_config():
    ctx = {"env": "test"}
    plugin = (PluginBuilder(ExamplePlugin, ctx)
        .with_config({})
        .build())

    assert plugin.config.greeting == "Hello"
    assert plugin.config.retries == 3


def test_composite_plugin_builder_basic():
    ctx = {"env": "test"}

    # Note: ExampleParentPlugin creates children internally,
    # so we can't easily test CompositePluginBuilder with it.
    # This test verifies the builder works with the pattern.
    from mm_pyplugin import CompositePlugin
    from pydantic import BaseModel
    from typing import Type

    class SimpleCompositeConfig(BaseModel):
        name: str = "default"

    class SimpleComposite(CompositePlugin):
        @classmethod
        def config_schema(cls) -> Type[BaseModel]:
            return SimpleCompositeConfig

        @property
        def config(self):
            return self._config_obj

        def setup(self):
            self._initialised = True
            self._setup_children()
            return self

    child1 = ExamplePlugin(ctx)
    child2 = ExamplePlugin(ctx)

    composite = (CompositePluginBuilder(SimpleComposite, ctx)
        .with_config({"name": "test-composite"})
        .add_child(child1, {"greeting": "Child 1"})
        .add_child(child2, {"greeting": "Child 2"})
        .build())

    assert isinstance(composite, SimpleComposite)
    assert composite.config.name == "test-composite"
    assert composite._initialised is True
    # Children should be configured
    assert child1._config_obj is not None
    assert child2._config_obj is not None


def test_composite_plugin_builder_requires_config():
    ctx = {"env": "test"}
    from mm_pyplugin import CompositePlugin
    from pydantic import BaseModel
    from typing import Type

    class SimpleCompositeConfig(BaseModel):
        name: str = "default"

    class SimpleComposite(CompositePlugin):
        @classmethod
        def config_schema(cls) -> Type[BaseModel]:
            return SimpleCompositeConfig

        @property
        def config(self):
            return self._config_obj

        def setup(self):
            self._initialised = True
            return self

    builder = CompositePluginBuilder(SimpleComposite, ctx)

    with pytest.raises(ValueError, match="Configuration required"):
        builder.build()


def test_composite_plugin_builder_validates_plugin_type():
    """CompositePluginBuilder should reject non-CompositePlugin classes."""
    ctx = {"env": "test"}

    builder = CompositePluginBuilder(ExamplePlugin, ctx)  # type: ignore

    with pytest.raises(TypeError, match="must be a CompositePlugin subclass"):
        builder.with_config({}).build()
