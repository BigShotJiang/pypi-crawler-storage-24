from __future__ import annotations

from typing import Any, Dict

from pydantic import BaseModel


class PluginInstanceConfig(BaseModel):
    """Holds the class name and configuration for a plugin instance."""
    plugin_class: str
    config: Dict[str, Any] = {}
