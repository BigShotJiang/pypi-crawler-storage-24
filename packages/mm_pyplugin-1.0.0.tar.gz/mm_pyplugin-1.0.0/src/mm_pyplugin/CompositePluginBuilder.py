from __future__ import annotations

from typing import Type, List, Tuple

from mm_pyplugin.PluginBase import PluginBase, ConfigInput, TContext
from mm_pyplugin.PluginBuilder import PluginBuilder
from mm_pyplugin.CompositePlugin import CompositePlugin


class CompositePluginBuilder(PluginBuilder[TContext]):
    """
    Builder for composite plugins with child plugin management.

    Extends ``PluginBuilder`` to handle child plugin registration,
    configuration, and initialization in the correct order.

    Example
    -------
    .. code-block:: python

        transformer = (CompositePluginBuilder(DataTransformer, ctx)
            .with_config(transformer_config)
            .add_child(TimestampParser(ctx), ts_config)
            .add_child(LogLevelMapper(ctx), level_config)
            .build())
    """

    def __init__(self, plugin_class: Type[CompositePlugin[TContext]], context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        plugin_class:
            The composite plugin class to instantiate. Must be a subclass
            of ``CompositePlugin``.
        context:
            Optional dependency injection container for plugin construction.
        """
        super().__init__(plugin_class, context)
        self._children: List[Tuple[PluginBase, ConfigInput]] = []

    def add_child(
            self, child_plugin: PluginBase, config: ConfigInput
    ) -> "CompositePluginBuilder":
        """
        Register a child plugin with its configuration.

        Parameters
        ----------
        child_plugin:
            The child plugin instance.
        config:
            Configuration for the child plugin.

        Returns
        -------
        self
            Returns builder for chaining.
        """
        self._children.append((child_plugin, config))
        return self

    def build(self) -> CompositePlugin:
        """
        Build the composite plugin with all children.

        Initialization order:
        1. Configure parent plugin
        2. Configure all child plugins
        3. Initialize parent plugin
        4. Initialize all child plugins

        Returns
        -------
        CompositePlugin
            The fully initialized composite plugin.

        Raises
        ------
        ValueError
            If parent configuration has not been set.
        TypeError
            If the plugin class is not a CompositePlugin subclass.
        """
        if self._config is None:
            raise ValueError("Configuration required before build()")

        # Instantiate parent
        plugin = self._plugin_class(self._context)
        if not isinstance(plugin, CompositePlugin):
            raise TypeError(
                f"{self._plugin_class.__name__} must be a CompositePlugin subclass"
            )

        # Configure parent
        plugin.configure(self._config)

        # Configure all children
        for child, child_config in self._children:
            child.configure(child_config)

        # Initialize parent (subclass should handle its own initialization)
        plugin.setup()

        # Initialize children (parent's setup should call _setup_children)
        # but we can also do it here for safety if parent doesn't
        for child, _ in self._children:
            if not child._initialised:
                child.setup()

        return plugin
