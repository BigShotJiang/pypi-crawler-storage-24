"""
Plugin Abstract Base Class
==========================
Provides a structured base for building configurable, lifecycle-aware plugins
using ABC for interface enforcement and Pydantic for configuration validation.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Generic, List, Tuple, Type, TypeVar, Union

from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Type aliases / TypeVars
# ---------------------------------------------------------------------------

ConfigInput = Union[str, Path, Dict[str, Any]]
T = TypeVar("T", bound="PluginBase")  # type: ignore[type-arg]
TContext = TypeVar("TContext")


# ---------------------------------------------------------------------------
# Plugin Base
# ---------------------------------------------------------------------------

class PluginBase(ABC, Generic[TContext]):
    """
    Abstract base class for all plugins.

    ``TContext`` is the type of the dependency injection container passed at
    construction time.  Plugins that prefer a typed dataclass or Pydantic model
    can parameterise accordingly::

        class MyContext:
            logger: logging.Logger
            db: Database

        class MyPlugin(PluginBase[MyContext]):
            def setup(self) -> "MyPlugin":
                self.context.logger.info("hello")   # fully typed
                ...

    For untyped / legacy usage simply leave the type parameter unspecified::

        class MyPlugin(PluginBase):  # equivalent to PluginBase[Any]
            ...

    Lifecycle
    ---------
    1. ``__init__``      – receives and stores context (DI container)
    2. ``configure``     – loads, validates and stores configuration (returns self)
    3. ``setup``    – initialization logic (returns self)
    4. ``teardown``      – cleanup and resource release

    Context (Dependency Injection)
    -------------------------------
    Context is a dependency injection container holding shared services
    (loggers, databases, event buses, etc.) that plugins can access via
    ``self.context``. This allows:

    * Sharing services across all plugins
    * Easy testing (inject mocks instead of real services)
    * Flexible configuration (different contexts for dev/prod)

    Example (typed context):

    .. code-block:: python

        @dataclass
        class AppContext:
            logger: logging.Logger
            database: Database
            event_bus: EventBus

        ctx = AppContext(logger=..., database=..., event_bus=...)
        plugin = MyPlugin(ctx).configure(config).setup()
        plugin.context.logger.info("Plugin ready")

    Configuration
    -------------
    Subclasses **must** override ``config_schema`` to return a concrete
    ``pydantic.BaseModel`` subclass.  ``configure`` will validate the
    resolved config dict against that schema before storing it.

    Fluent API
    ----------
    Both ``configure`` and ``setup`` return ``self`` for method chaining:

    .. code-block:: python

        plugin = MyPlugin(context).configure(config).setup()
    """

    _config_obj: BaseModel  # set by configure()

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        context:
            Optional dependency injection container. Can be any type — a plain
            ``dict``, a typed dataclass, a Pydantic model, etc. Stored and
            accessible via ``self.context`` throughout the plugin lifecycle.
        """
        self._context: TContext | None = context
        self._config_obj: BaseModel | None = None
        self._initialised: bool = False

    @property
    def context(self) -> TContext | None:
        """
        Access the dependency injection container.

        The type matches the ``TContext`` parameter supplied to ``PluginBase``.
        Returns ``None`` if no context was provided at construction time.

        Example (typed context):

        .. code-block:: python

            def setup(self):
                if self.context is not None:
                    self.context.logger.info("Initializing plugin")
                self._initialised = True
                return self
        """
        return self._context

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @abstractmethod
    def setup(self) -> "PluginBase":
        """
        Initialise the plugin.

        This is called after ``configure()`` and should perform any
        resource allocation, connection setup, or state initialization.

        Access dependencies via ``self.context`` as needed.

        Returns
        -------
        self
            Returns the plugin instance for method chaining.

        Example
        -------
        .. code-block:: python

            def setup(self):
                logger = self.context.get("logger")
                if logger:
                    logger.info(f"Initializing {self.__class__.__name__}")
                self._initialised = True
                return self
        """

    @abstractmethod
    def teardown(self) -> None:
        """
        Release resources and perform cleanup.

        Called when the plugin is no longer needed. Should release any
        resources acquired during ``setup()`` (e.g., file handles,
        network connections, database connections).

        For composite plugins, should teardown child plugins in reverse
        initialization order.
        """

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    @classmethod
    @abstractmethod
    def config_schema(cls) -> Type[BaseModel]:  # type: ignore[override]
        """
        Return the Pydantic model class used to validate plugin configuration.

        Example
        -------
        .. code-block:: python

            @classmethod
            def config_schema(cls) -> Type[BaseModel]:
                return MyPluginConfig
        """

    def configure(self, config: ConfigInput) -> "PluginBase":
        """
        Load, validate, and store the plugin configuration.

        Parameters
        ----------
        config:
            Configuration source – one of:

            * ``str``  – path to a JSON file
            * ``Path`` – path to a JSON file
            * ``dict`` – pre-built mapping (used as-is)

        Returns
        -------
        self
            Returns the plugin instance for method chaining.

        Raises
        ------
        TypeError
            If *config* is not a recognised type.
        FileNotFoundError
            If a file path does not exist.
        pydantic.ValidationError
            If the resolved dict fails schema validation.
        """
        raw: Dict[str, Any] = self._load_config(config)
        schema: Type[BaseModel] = self.config_schema()  # type: ignore[operator]
        self._config_obj = schema(**raw)
        return self

    @property
    @abstractmethod
    def config(self) -> BaseModel:
        """
        Return the validated Pydantic configuration object.

        Subclasses should narrow the return type to their specific model:

        .. code-block:: python

            @property
            def config(self) -> MyPluginConfig:
                return self._config_obj
        """

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_config(self, config: ConfigInput) -> Dict[str, Any]:
        """Resolve *config* to a plain dictionary.

        Subclasses can override this method to customize config loading
        (e.g. to resolve environment variables, fetch from remote sources,
        or use services from ``self.context``).

        Parameters
        ----------
        config:
            Configuration source — a file path (``str`` or ``Path``) or a
            pre-built ``dict``.

        Returns
        -------
        dict
            The resolved configuration dictionary.
        """
        if isinstance(config, dict):
            return config
        if isinstance(config, (str, Path)):
            path = Path(config)
            if not path.exists():
                raise FileNotFoundError(f"Config file not found: {path}")
            with path.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        raise TypeError(
            f"config must be a str path, Path, or dict – got {type(config).__name__!r}"
        )

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"<{type(self).__name__} "
            f"configured={self._config_obj is not None} "
            f"initialised={self._initialised}>"
        )


# ---------------------------------------------------------------------------
# Composite Plugin Base
# ---------------------------------------------------------------------------

class CompositePlugin(PluginBase[TContext]):
    """
    Base class for plugins that contain child plugins.

    Provides helpers for managing hierarchical plugin initialization
    and teardown. Child plugins are configured and initialized in order,
    and torn down in reverse order.

    Example
    -------
    .. code-block:: python

        class DataTransformer(CompositePlugin):
            def __init__(self, context=None):
                super().__init__(context)
                self._parser = TimestampParser(context)
                self._mapper = LogLevelMapper(context)
                self._register_child(self._parser)
                self._register_child(self._mapper)

            def setup(self) -> "DataTransformer":
                # Initialize self first if needed
                self._initialised = True
                # Then initialize children
                self._setup_children()
                return self
    """

    def __init__(self, context: TContext | None = None) -> None:
        super().__init__(context)
        self._children: List[PluginBase[Any]] = []

    # ------------------------------------------------------------------
    # Child management
    # ------------------------------------------------------------------

    def _register_child(self, child: PluginBase) -> None:
        """
        Register a child plugin.

        Parameters
        ----------
        child:
            The child plugin to register.
        """
        self._children.append(child)

    def _configure_children(
        self, configs: List[Tuple[PluginBase, ConfigInput]]
    ) -> None:
        """
        Configure all registered children with their respective configs.

        Parameters
        ----------
        configs:
            List of (child_plugin, config) tuples. Must match the order
            and count of registered children.

        Raises
        ------
        ValueError
            If the number of configs doesn't match the number of children.
        """
        if len(configs) != len(self._children):
            raise ValueError(
                f"Config count mismatch: {len(configs)} configs "
                f"for {len(self._children)} children"
            )
        for (child, _), config_input in zip(configs, configs):
            child.configure(config_input[1])

    def _setup_children(self) -> None:
        """
        Initialize all registered children in order.

        Children inherit the parent's context automatically.
        """
        for child in self._children:
            child.setup()

    def teardown(self) -> None:
        """
        Teardown all children in reverse initialization order.

        Override this method if the parent plugin needs custom cleanup,
        but always call ``super().teardown()`` to ensure children are
        properly cleaned up.
        """
        for child in reversed(self._children):
            child.teardown()


# ---------------------------------------------------------------------------
# Plugin Builder
# ---------------------------------------------------------------------------

class PluginBuilder(Generic[TContext]):
    """
    Builder for constructing and initializing plugins with validation.

    Provides a fluent interface for configuring complex plugins,
    especially useful for composite plugins with multiple children.

    Example
    -------
    .. code-block:: python

        transformer = (PluginBuilder(DataTransformer, ctx)
            .with_config({"output_format": "json"})
            .build())

    For composite plugins with children:

    .. code-block:: python

        transformer = (CompositePluginBuilder(DataTransformer, ctx)
            .with_config(transformer_config)
            .add_child(TimestampParser(ctx), ts_config)
            .add_child(LogLevelMapper(ctx), level_config)
            .build())
    """

    def __init__(self, plugin_class: Type[T], context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        plugin_class:
            The plugin class to instantiate.
        context:
            Optional dependency injection container for plugin construction.
        """
        self._plugin_class = plugin_class
        self._context = context
        self._config: ConfigInput | None = None

    def with_config(self, config: ConfigInput) -> "PluginBuilder":
        """
        Set the plugin configuration.

        Parameters
        ----------
        config:
            Configuration source (dict, str path, or Path).

        Returns
        -------
        self
            Returns builder for chaining.
        """
        self._config = config
        return self

    def build(self) -> PluginBase:
        """
        Construct, configure, and initialize the plugin.

        Returns
        -------
        PluginBase
            The fully initialized plugin instance.

        Raises
        ------
        ValueError
            If configuration has not been set via ``with_config()``.
        """
        if self._config is None:
            raise ValueError("Configuration required before build()")

        plugin = self._plugin_class(self._context)
        plugin.configure(self._config)
        plugin.setup()
        return plugin


# ---------------------------------------------------------------------------
# Composite Plugin Builder
# ---------------------------------------------------------------------------

class CompositePluginBuilder(PluginBuilder[TContext]):
    """
    Builder for composite plugins with child plugin management.

    Extends ``PluginBuilder`` to handle child plugin registration,
    configuration, and initialization in the correct order.

    Example
    -------
    .. code-block:: python

        transformer = (CompositePluginBuilder(DataTransformer, ctx)
            .with_config(transformer_config)
            .add_child(TimestampParser(ctx), ts_config)
            .add_child(LogLevelMapper(ctx), level_config)
            .build())
    """

    def __init__(self, plugin_class: Type[CompositePlugin[TContext]], context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        plugin_class:
            The composite plugin class to instantiate. Must be a subclass
            of ``CompositePlugin``.
        context:
            Optional dependency injection container for plugin construction.
        """
        super().__init__(plugin_class, context)
        self._children: List[Tuple[PluginBase, ConfigInput]] = []

    def add_child(
        self, child_plugin: PluginBase, config: ConfigInput
    ) -> "CompositePluginBuilder":
        """
        Register a child plugin with its configuration.

        Parameters
        ----------
        child_plugin:
            The child plugin instance.
        config:
            Configuration for the child plugin.

        Returns
        -------
        self
            Returns builder for chaining.
        """
        self._children.append((child_plugin, config))
        return self

    def build(self) -> CompositePlugin:
        """
        Build the composite plugin with all children.

        Initialization order:
        1. Configure parent plugin
        2. Configure all child plugins
        3. Initialize parent plugin
        4. Initialize all child plugins

        Returns
        -------
        CompositePlugin
            The fully initialized composite plugin.

        Raises
        ------
        ValueError
            If parent configuration has not been set.
        TypeError
            If the plugin class is not a CompositePlugin subclass.
        """
        if self._config is None:
            raise ValueError("Configuration required before build()")

        # Instantiate parent
        plugin = self._plugin_class(self._context)
        if not isinstance(plugin, CompositePlugin):
            raise TypeError(
                f"{self._plugin_class.__name__} must be a CompositePlugin subclass"
            )

        # Configure parent
        plugin.configure(self._config)

        # Configure all children
        for child, child_config in self._children:
            child.configure(child_config)

        # Initialize parent (subclass should handle its own initialization)
        plugin.setup()

        # Initialize children (parent's setup should call _setup_children)
        # but we can also do it here for safety if parent doesn't
        for child, _ in self._children:
            if not child._initialised:
                child.setup()

        return plugin
