from __future__ import annotations

from typing import List, Any, Tuple

from mm_pyplugin.PluginBase import PluginBase, ConfigInput, TContext


class CompositePlugin(PluginBase[TContext]):
    """
    Base class for plugins that contain child plugins.

    Provides helpers for managing hierarchical plugin initialization
    and teardown. Child plugins are configured and initialized in order,
    and torn down in reverse order.

    Example
    -------
    .. code-block:: python

        class DataTransformer(CompositePlugin):
            def __init__(self, context=None):
                super().__init__(context)
                self._parser = TimestampParser(context)
                self._mapper = LogLevelMapper(context)
                self._register_child(self._parser)
                self._register_child(self._mapper)

            def setup(self) -> "DataTransformer":
                # Initialize self first if needed
                self._initialised = True
                # Then initialize children
                self._setup_children()
                return self
    """

    def __init__(self, context: TContext | None = None) -> None:
        super().__init__(context)
        self._children: List[PluginBase[Any]] = []

    # ------------------------------------------------------------------
    # Child management
    # ------------------------------------------------------------------

    def _register_child(self, child: PluginBase) -> None:
        """
        Register a child plugin.

        Parameters
        ----------
        child:
            The child plugin to register.
        """
        self._children.append(child)

    def _configure_children(
        self, configs: List[Tuple[PluginBase, ConfigInput]]
    ) -> None:
        """
        Configure all registered children with their respective configs.

        Parameters
        ----------
        configs:
            List of (child_plugin, config) tuples. Must match the order
            and count of registered children.

        Raises
        ------
        ValueError
            If the number of configs doesn't match the number of children.
        """
        if len(configs) != len(self._children):
            raise ValueError(
                f"Config count mismatch: {len(configs)} configs "
                f"for {len(self._children)} children"
            )
        for (child, _), config_input in zip(configs, configs):
            child.configure(config_input[1])

    def _setup_children(self) -> None:
        """
        Initialize all registered children in order.

        Children inherit the parent's context automatically.
        """
        for child in self._children:
            child.setup()

    def teardown(self) -> None:
        """
        Teardown all children in reverse initialization order.

        Override this method if the parent plugin needs custom cleanup,
        but always call ``super().teardown()`` to ensure children are
        properly cleaned up.
        """
        for child in reversed(self._children):
            child.teardown()
