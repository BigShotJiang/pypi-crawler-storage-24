from __future__ import annotations

from typing import Generic, Type

from mm_pyplugin.PluginBase import ConfigInput, PluginBase, TContext, T


class PluginBuilder(Generic[TContext]):
    """
    Builder for constructing and initializing plugins with validation.

    Provides a fluent interface for configuring complex plugins,
    especially useful for composite plugins with multiple children.

    Example
    -------
    .. code-block:: python

        transformer = (PluginBuilder(DataTransformer, ctx)
            .with_config({"output_format": "json"})
            .build())

    For composite plugins with children:

    .. code-block:: python

        transformer = (CompositePluginBuilder(DataTransformer, ctx)
            .with_config(transformer_config)
            .add_child(TimestampParser(ctx), ts_config)
            .add_child(LogLevelMapper(ctx), level_config)
            .build())
    """

    def __init__(self, plugin_class: Type[T], context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        plugin_class:
            The plugin class to instantiate.
        context:
            Optional dependency injection container for plugin construction.
        """
        self._plugin_class = plugin_class
        self._context = context
        self._config: ConfigInput | None = None

    def with_config(self, config: ConfigInput) -> "PluginBuilder":
        """
        Set the plugin configuration.

        Parameters
        ----------
        config:
            Configuration source (dict, str path, or Path).

        Returns
        -------
        self
            Returns builder for chaining.
        """
        self._config = config
        return self

    def build(self) -> PluginBase:
        """
        Construct, configure, and initialize the plugin.

        Returns
        -------
        PluginBase
            The fully initialized plugin instance.

        Raises
        ------
        ValueError
            If configuration has not been set via ``with_config()``.
        """
        if self._config is None:
            raise ValueError("Configuration required before build()")

        plugin = self._plugin_class(self._context)
        plugin.configure(self._config)
        plugin.setup()
        return plugin
