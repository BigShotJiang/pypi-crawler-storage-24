from __future__ import annotations

from functools import cache
from importlib.metadata import entry_points
from typing import Dict, Generic, Optional, Type, TypeVar

from mm_pyplugin.PluginBase import PluginBase
from mm_pyplugin.PluginInstanceConfig import PluginInstanceConfig

ENTRY_POINT_GROUP = "mm_pyplugin"

TContext = TypeVar("TContext")


class PluginUtils(Generic[TContext]):

    def __init__(self, context: TContext | None = None) -> None:
        """
        Parameters
        ----------
        context:
            Optional dependency injection container to use when creating plugins.
        """
        self.context: TContext | None = context

    @staticmethod
    @cache
    def find_plugins() -> Dict[str, Type[PluginBase]]:
        """Return all plugin classes registered under the 'mm-pyplugin' entry point group.

        Returns
        -------
        Dict[str, Type[PluginBase]]
            Mapping of entry point name to the loaded plugin class.
        """
        plugins: Dict[str, Type[PluginBase]] = {}
        for ep in entry_points(group=ENTRY_POINT_GROUP):
            cls = ep.load()
            full_name = f"{cls.__module__}.{cls.__qualname__}"
            plugins[full_name] = cls
        return plugins

    def create_plugin(self, instance_config: PluginInstanceConfig, context: Optional[TContext] = None) -> PluginBase[TContext]:
        """Instantiate, configure, and initialize a plugin from a PluginInstanceConfig.

        Parameters
        ----------
        instance_config:
            Holds the plugin class name and its configuration.
        context:
            Dependency injection container to pass to the plugin constructor.
            If None, uses the context stored in this PluginUtils instance.

        Returns
        -------
        PluginBase
            The fully configured and initialized plugin instance.

        Raises
        ------
        KeyError
            If the plugin class name is not found in the registered entry points.
        """
        ctx = context if context is not None else self.context
        plugins = PluginUtils.find_plugins()
        if instance_config.plugin_class not in plugins:
            raise KeyError(
                f"Plugin {instance_config.plugin_class!r} not found. "
                f"Available: {list(plugins)}"
            )
        cls = plugins[instance_config.plugin_class]
        # Use fluent API for configuration and initialization
        plugin = cls(context=ctx).configure(instance_config.config).setup()
        return plugin
