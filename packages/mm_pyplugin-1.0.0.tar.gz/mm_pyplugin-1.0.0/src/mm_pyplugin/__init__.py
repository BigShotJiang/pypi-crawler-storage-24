"""
mm-pyplugin - Plugin infrastructure for Python applications
============================================================

Provides base classes and utilities for building configurable,
lifecycle-aware plugins with Pydantic configuration validation.
"""

from mm_pyplugin.PluginBase import (
    ConfigInput,
    PluginBase,
)
from mm_pyplugin.CompositePluginBuilder import CompositePluginBuilder
from mm_pyplugin.PluginBuilder import PluginBuilder
from mm_pyplugin.CompositePlugin import CompositePlugin
from mm_pyplugin.PluginInstanceConfig import PluginInstanceConfig
from mm_pyplugin.PluginUtils import PluginUtils

__all__ = [
    # Core plugin classes
    "PluginBase",
    "CompositePlugin",
    # Builder pattern classes
    "PluginBuilder",
    "CompositePluginBuilder",
    # Type aliases
    "ConfigInput",
    # Configuration
    "PluginInstanceConfig",
    # Utilities
    "PluginUtils",
]

__version__ = "0.1.0"
