# TODO

## High Priority

- [x] **Add file logging** - RotatingFileHandler in `server.py` logs all MCP tool calls, Tally XML requests/responses, and errors to `tally-mcp.log` with timestamps.

## Features

- [ ] GST report tools (GSTR-1, GSTR-3B summary)
- [ ] Cost centre reports
- [ ] Godown/warehouse reports
- [ ] Voucher alteration tool (modify existing vouchers)
- [ ] Multi-currency support
- [ ] Voucher search/lookup by number

## Performance

- [ ] Caching layer for frequently-accessed master data (ledger list, groups)
- [ ] Connection pooling for Tally HTTP client
- [ ] Rate limiting on write operations

## Packaging & Deployment

- [ ] Windows service installer (run as background service)
- [ ] Docker packaging
- [ ] PyPI publishing
- [ ] Configuration wizard / setup UI

## Observability

- [ ] **Remote log access** - MCP tool (`get_server_logs`) that returns recent log entries so a remote user/agent can diagnose issues without SSH access to the Tally machine
- [ ] **Feedback command** - MCP tool or CLI command to send error reports / feedback to the maintainer (webhook, email, or GitHub issue)
- [ ] Audit logging (who did what, when)

## Security

- [ ] Read-only mode option (disable write tools)
- [ ] IP allowlist for remote connections

## Manual notes
- What if the tally mcp responses also told the AI application to store lessons either in a memory or in a file, so agent prompts the user to check if they would like to maintain a tally personal instruction sets in a local file somewhere - and somehow it was read at the time of each session - why am I suggesting this - I asked the mcp to build be a month X customer - sales grid - it went through a cycle of iterations - tried to use sales register then realized that it only has monthly numbers - then it tried to look for sales ledgers - that did not work because it did not know what sales group is called - so then it wnet on to get all groups - then find 
