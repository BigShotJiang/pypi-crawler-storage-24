"""Tally MCP Server - Bridge MCP clients to TallyPrime."""
