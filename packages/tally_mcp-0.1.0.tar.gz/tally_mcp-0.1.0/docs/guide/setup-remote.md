# Setup: Remote / Team Access

This guide walks a server admin through setting up Tally MCP for multiple users connecting remotely. The MCP server runs on the Tally machine; team members connect from their own machines.

## Architecture

```
Team members (anywhere)                    Tally machine (office)
┌──────────────┐                    ┌─────────────────────────────┐
│ Alice        │                    │                             │
│  Claude Code ├──HTTPS──┐         │  ┌──────────┐  ┌─────────┐ │
├──────────────┤         │         │  │tally-mcp │  │ Tally   │ │
│ Bob          │         ├────────►│  │ :8765    ├─►│ :9000   │ │
│  Claude Code ├──HTTPS──┤ Tunnel  │  │(HTTP+auth│◄─│         │ │
├──────────────┤         │         │  └──────────┘  └─────────┘ │
│ Admin        │         │         │                             │
│  Claude Code ├──HTTPS──┘         └─────────────────────────────┘
└──────────────┘
```

## What you'll need

**On the Tally machine:**
- TallyPrime running with server mode on port 9000
- Python 3.11+ (or `uv`)
- `cloudflared` (for the tunnel) — [install guide](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/)

**For each team member:**
- An MCP client (Claude Code, Claude Desktop, etc.)
- Their access token (you'll generate these in Step 4)

## Step 1: Install and start the server

On the Tally machine:

```bash
pip install tally-mcp
```

Create a `.env` file (optional, for convenience):

```bash
TALLY_MCP_TALLY_HOST=localhost
TALLY_MCP_TALLY_PORT=9000
TALLY_MCP_TALLY_DEFAULT_COMPANY=Your Company Name Pvt Ltd
```

Start in HTTP mode:

```bash
tally-mcp --http
```

The server starts on `0.0.0.0:8765`.

## Step 2: Set up the tunnel

In a separate terminal on the Tally machine:

```bash
cloudflared tunnel --url http://localhost:8765
```

Cloudflare gives you a public URL like `https://random-words.trycloudflare.com`. Note this URL.

For a permanent subdomain (recommended for teams), create a named tunnel:

```bash
cloudflared tunnel create tally-mcp
cloudflared tunnel route dns tally-mcp tally.yourdomain.com
cloudflared tunnel run --url http://localhost:8765 tally-mcp
```

## Step 3: Onboard companies

Connect to the server yourself first (use the tunnel URL or `localhost:8765` if you're on the same machine) and run the onboarding flow:

1. `discover_companies()` — finds open companies
2. Discuss grouping, date ranges, aliases
3. `save_company_config()` — saves the config

See [Adding Companies](adding-companies.md) for details.

## Step 4: Generate access tokens

Ask the assistant:

> "Generate access tokens for the team"

This calls `generate_tokens()` which creates:

| Token | Prefix | Access |
|-------|--------|--------|
| Admin token | `tmcp_adm_...` | All companies |
| Per-company token | `tmcp_co_...` | One specific company |

**Save these immediately.** Tokens are shown only once and cannot be retrieved later.

See [Managing Access](managing-access.md) for the full token lifecycle.

## Step 5: Distribute access to team members

Send each team member:
1. The tunnel URL
2. Their scoped token

Tell them to add this to their MCP client config:

### Claude Code

Add to `.mcp.json` in their project:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://tally.yourdomain.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_THEIR_TOKEN_HERE"
      }
    }
  }
}
```

### Claude Desktop

Add to `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "tally": {
      "url": "https://tally.yourdomain.com/mcp",
      "headers": {
        "Authorization": "Bearer tmcp_co_THEIR_TOKEN_HERE"
      }
    }
  }
}
```

## Step 6: Verify

Ask each team member to run a health check from their MCP client:

> "Check if Tally is connected"

If it fails, check:
- Is the tunnel running?
- Is `tally-mcp --http` running?
- Is the token correct (no extra spaces, correct prefix)?
- Is TallyPrime open with their company loaded?

## Keeping it running

For production use, you'll want both processes to survive reboots:

**Option A: Windows Task Scheduler**
Create two scheduled tasks (trigger: "At startup"):
1. `tally-mcp --http`
2. `cloudflared tunnel run ...`

**Option B: Run as a Windows Service**
Use [NSSM](https://nssm.cc/) to wrap both commands as Windows services.

**Option C: PowerShell startup script**
```powershell
# start-tally-mcp.ps1
Start-Process -NoNewWindow tally-mcp "--http"
Start-Process -NoNewWindow cloudflared "tunnel run --url http://localhost:8765 tally-mcp"
```

## Security checklist

- [ ] Never expose port 8765 directly to the internet — always use a tunnel
- [ ] Use scoped tokens — give each user only the companies they need
- [ ] Keep the admin token with the server operator only
- [ ] Cycle tokens immediately if compromised (see [Managing Access](managing-access.md))
- [ ] Consider IP allowlisting on the Cloudflare tunnel for extra protection
