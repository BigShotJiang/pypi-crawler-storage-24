maturin build --release
