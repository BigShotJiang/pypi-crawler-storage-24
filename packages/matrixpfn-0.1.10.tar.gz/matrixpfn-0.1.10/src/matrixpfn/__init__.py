from importlib.metadata import version

__version__ = version("matrixpfn")

from .generator import (
    BatchMatrixData,
    GeneratorConfig,
    MatrixDomain,
    MatrixGeneratorRegistry,
    build_training_registry,
    build_eval_registry,
)
from .nn import ContextResGCN, BaselineResGCN, ContextResMPNN
from .precond import MatrixPFN
from .precond.matrix_pfn import TrainingConfig
from .solver import FGMRES, Arnoldi, SolverResult
