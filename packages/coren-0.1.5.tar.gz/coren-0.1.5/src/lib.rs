//! # coren: compute and resource normalization
//!
//! Two layers:
//!
//! 1. **FnCost** -- deterministic descriptor of what a function requires.
//!    Absolute physical units (ops, bytes). Same on every machine.
//! 2. **MachCap** -- what this machine can do. Measured locally.
//!
//! One answer:
//!
//! ```text
//! let v = cap.verdict(&cost);
//! if v.score > 0.0 { fetch from network }
//! if v.score < 0.0 { compute locally }
//! // magnitude = seconds saved by choosing the better option
//! ```
//!
//! ## FnCost fields (all deterministic, all u64)
//!
//! | Field        | Meaning                                  |
//! |--------------|------------------------------------------|
//! | ops          | Total arithmetic operations               |
//! | mem_bytes    | Memory traffic (cold-cache model)         |
//! | peak_mem     | Peak footprint (max simultaneously live)  |
//! | result_bytes | Output size (what gets cached/sent)       |
//!
//! These use integer arithmetic throughout. No floats in constructors.
//! Two machines cannot disagree on a FnCost.
//!
//! ## Example
//!
//! ```no_run
//! use coren::{FnCost, MachCap};
//!
//! let cost = FnCost::sort(1_000_000, 64, 64_000_000);
//! let cap = MachCap::read(".");
//! let v = cap.verdict(&cost);
//!
//! if v.score > 0.0 {
//!     println!("fetch: saves {:.2}s", v.score);
//! } else {
//!     println!("compute: saves {:.2}s", -v.score);
//! }
//! ```

#[cfg(feature = "python")]
mod py;

use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::OnceLock;
use std::time::Instant;
use sysinfo::System;

// ── FnCost ─────────────────────────────────────────────────────

/// Deterministic descriptor of a function's resource requirements.
///
/// Properties of the algorithm + inputs, in absolute physical units.
/// Uses u64 integer arithmetic throughout -- bitwise identical on
/// every architecture, OS, and CPU.
///
/// For a memoization system: the framework computes FnCost from the
/// function's AST and parameters, publishes it with the cache entry,
/// and every node can independently verify the values match.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct FnCost {
    /// W: total arithmetic operations (op count, not per-second).
    pub ops: u64,
    /// Q: bytes moved between CPU and RAM (algorithmic cold-cache model).
    pub mem_bytes: u64,
    /// M: peak memory footprint (max bytes simultaneously resident).
    pub peak_mem: u64,
    /// R: result size in bytes. What gets cached, stored, or transferred.
    pub result_bytes: u64,
}

impl FnCost {
    pub const fn new(ops: u64, mem_bytes: u64, peak_mem: u64, result_bytes: u64) -> Self {
        Self { ops, mem_bytes, peak_mem, result_bytes }
    }

    pub const ZERO: FnCost = FnCost::new(0, 0, 0, 0);

    /// Arithmetic intensity I = W/Q (ops per byte).
    /// High = compute-bound. Low = memory-bound.
    pub fn intensity(&self) -> f64 {
        if self.mem_bytes == 0 { return f64::INFINITY; }
        self.ops as f64 / self.mem_bytes as f64
    }

    // ── Combinators ────────────────────────────────────────────

    /// Sequential: self then other.
    /// W sums, Q sums, M = max, R = last stage's output.
    pub const fn then(self, other: FnCost) -> FnCost {
        FnCost {
            ops: self.ops + other.ops,
            mem_bytes: self.mem_bytes + other.mem_bytes,
            peak_mem: if self.peak_mem > other.peak_mem { self.peak_mem } else { other.peak_mem },
            result_bytes: other.result_bytes,
        }
    }

    /// Parallel: run both concurrently.
    /// W = max, Q = max, M sums (both resident), R sums.
    pub const fn par(self, other: FnCost) -> FnCost {
        FnCost {
            ops: if self.ops > other.ops { self.ops } else { other.ops },
            mem_bytes: if self.mem_bytes > other.mem_bytes { self.mem_bytes } else { other.mem_bytes },
            peak_mem: self.peak_mem + other.peak_mem,
            result_bytes: self.result_bytes + other.result_bytes,
        }
    }

    /// Repeat k times. M and R unchanged.
    pub const fn repeat(self, k: u64) -> FnCost {
        FnCost {
            ops: self.ops * k, // saturating not available in const
            mem_bytes: self.mem_bytes * k,
            ..self
        }
    }

    // ── Common algorithm costs ─────────────────────────────────
    // All use integer arithmetic. All deterministic.

    /// Linear scan of `n_bytes`. ~1 comparison per 8 bytes, read once.
    pub const fn scan(n_bytes: u64, result_bytes: u64) -> FnCost {
        FnCost::new(n_bytes / 8, n_bytes, n_bytes, result_bytes)
    }

    /// Merge sort: n items of item_bytes each.
    /// ceil(log2(n)) via integer bit ops.
    pub fn sort(n: u64, item_bytes: u64, result_bytes: u64) -> FnCost {
        let lg = ilog2_ceil(n);
        FnCost::new(
            n * lg * 10,
            n * item_bytes * lg,
            n * item_bytes,
            result_bytes,
        )
    }

    /// Cryptographic hash. ~2 ops/byte, result = 32-byte digest.
    pub const fn hash(n_bytes: u64) -> FnCost {
        FnCost::new(n_bytes * 2, n_bytes, 4096, 32)
    }

    /// Dense matmul (m x k) * (k x n), f64.
    pub const fn matmul(m: u64, n: u64, k: u64, result_bytes: u64) -> FnCost {
        let ops = 2 * m * n * k;
        let traffic = (m * k + k * n + m * n) * 8;
        FnCost::new(ops, traffic, traffic, result_bytes)
    }

    /// ETL: read rows, process, write.
    pub const fn etl(n_rows: u64, row_bytes: u64, ops_per_row: u64, result_bytes: u64) -> FnCost {
        FnCost::new(
            n_rows * ops_per_row,
            n_rows * row_bytes * 2, // read + write
            n_rows * row_bytes,
            result_bytes,
        )
    }

    /// File copy / passthrough. Zero ops, Q = R = size.
    pub const fn copy(size: u64) -> FnCost {
        FnCost::new(0, size, 0, size)
    }
}

impl std::ops::Add for FnCost {
    type Output = FnCost;
    fn add(self, rhs: FnCost) -> FnCost { self.then(rhs) }
}

fn ilog2_ceil(n: u64) -> u64 {
    if n <= 1 { return 1; }
    (n - 1).ilog2() as u64 + 1
}

// ── Verdict ────────────────────────────────────────────────────

/// The answer: should this machine compute or fetch?
///
/// `score > 0` => fetch from network (saves `score` seconds).
/// `score < 0` => compute locally (saves `-score` seconds).
/// `score = 0` => break-even.
///
/// `f64::INFINITY`  => must fetch (cannot compute: insufficient RAM).
/// `f64::NEG_INFINITY` => must compute (cannot fetch: no network).
///
/// Magnitude = seconds saved by choosing the better option.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Verdict {
    /// The summary. Positive = fetch, negative = compute.
    pub score: f64,

    // ── Full breakdown ─────────────────────────────────────────

    /// Seconds to compute locally (roofline: max(W/pi, Q/beta)).
    pub t_compute: f64,
    /// Seconds to download result from network (R / nic_bw).
    pub t_fetch: f64,
    /// Seconds to write result to local disk (R / disk_bw).
    pub t_store: f64,

    /// Which roofline ceiling limits computation.
    pub bottleneck: Bottleneck,
    /// Can this machine fit the computation in RAM?
    pub can_compute: bool,
    /// Can this machine store the result on disk?
    pub can_store: bool,
    /// Can this machine fetch from the network?
    pub can_fetch: bool,

    /// Device bias applied to T_compute.
    pub bias: f64,
}

impl Verdict {
    /// True if fetch is the better choice (or the only viable one).
    pub fn should_fetch(&self) -> bool { self.score > 0.0 }
    /// True if local compute is the better choice (or the only viable one).
    pub fn should_compute(&self) -> bool { self.score <= 0.0 }

    /// Human-readable recommendation.
    pub fn recommendation(&self) -> &'static str {
        if self.score == f64::INFINITY { "must fetch (insufficient RAM)" }
        else if self.score == f64::NEG_INFINITY { "must compute (no network)" }
        else if self.score > 0.0 { "fetch" }
        else if self.score < 0.0 { "compute" }
        else { "break-even" }
    }
}

impl std::fmt::Display for Verdict {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        if self.score > 0.0 {
            write!(f, "fetch (saves {:.3}s)", self.score)
        } else {
            write!(f, "compute (saves {:.3}s)", -self.score)
        }
    }
}

// ── Bottleneck ─────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Bottleneck { Compute, Memory, None }

impl Bottleneck {
    pub fn as_str(&self) -> &'static str {
        match self { Self::Compute => "compute", Self::Memory => "memory", Self::None => "none" }
    }
}

impl std::fmt::Display for Bottleneck {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result { f.write_str(self.as_str()) }
}

// ── Roofline ───────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Roofline {
    pub peak_gflops: f64,
    pub mem_bw_gbs: f64,
    pub single_core_gflops: f64,
    pub core_scaling: f64,
}

impl Roofline {
    pub fn ridge_point(&self) -> f64 {
        if self.mem_bw_gbs <= 0.0 { return f64::INFINITY; }
        self.peak_gflops / self.mem_bw_gbs
    }

    pub fn compute_time(&self, cost: &FnCost) -> f64 {
        let t_f = if self.peak_gflops > 0.0 { cost.ops as f64 / (self.peak_gflops * 1e9) }
                  else if cost.ops > 0 { f64::INFINITY } else { 0.0 };
        let t_m = if self.mem_bw_gbs > 0.0 { cost.mem_bytes as f64 / (self.mem_bw_gbs * 1e9) }
                  else if cost.mem_bytes > 0 { f64::INFINITY } else { 0.0 };
        f64::max(t_f, t_m)
    }

    pub fn bottleneck(&self, cost: &FnCost) -> Bottleneck {
        if cost.ops == 0 && cost.mem_bytes == 0 { return Bottleneck::None; }
        let t_f = cost.ops as f64 / (self.peak_gflops * 1e9).max(1.0);
        let t_m = cost.mem_bytes as f64 / (self.mem_bw_gbs * 1e9).max(1.0);
        if t_f >= t_m { Bottleneck::Compute } else { Bottleneck::Memory }
    }
}

// ── MachCap ────────────────────────────────────────────────────

/// Local machine capabilities. Translates deterministic FnCost into
/// a Verdict: compute or fetch?
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MachCap {
    pub cores_physical: usize,
    pub cores_logical: usize,
    pub freq_mhz: f64,
    pub mem_total: u64,
    pub mem_available: u64,
    pub disk_total: u64,
    pub disk_free: u64,
    pub nic_mbps: f64,
    pub disk_bw_gbs: f64,
    pub has_battery: bool,
    pub battery_pct: Option<f64>,
    pub roofline: Roofline,
}

impl MachCap {
    pub fn read(store_path: impl AsRef<Path>) -> Self {
        Self::read_opts(store_path, true, true)
    }

    pub fn read_opts(store_path: impl AsRef<Path>, detect_net: bool, run_bench: bool) -> Self {
        let mut sys = System::new();
        sys.refresh_cpu_all();
        sys.refresh_memory();

        let cores_physical = sys.physical_core_count().unwrap_or(1);
        let cores_logical = sys.cpus().len().max(1);
        let freq_mhz = sys.cpus().iter()
            .map(|c| c.frequency() as f64).fold(0.0_f64, f64::max);
        let mem_total = sys.total_memory();
        let mem_available = sys.available_memory();

        let store = store_path.as_ref().canonicalize()
            .unwrap_or_else(|_| std::env::current_dir().unwrap_or_default());
        let disk = disk_usage_for(&store);
        let nic_mbps = if detect_net { detect_nic_speed() } else { 0.0 };
        let dbw = if run_bench { bench_disk_bw(&store) } else { 0.5 };

        let roofline = if run_bench {
            let b = cached_cpu_bench(cores_physical);
            Roofline {
                peak_gflops: b.single_core_gflops * cores_physical as f64 * b.core_scaling,
                mem_bw_gbs: b.mem_bw_gbs,
                single_core_gflops: b.single_core_gflops,
                core_scaling: b.core_scaling,
            }
        } else {
            let ghz = if freq_mhz > 0.0 { freq_mhz / 1000.0 } else { 2.5 };
            Roofline {
                peak_gflops: cores_physical as f64 * ghz * 4.0,
                mem_bw_gbs: 20.0,
                single_core_gflops: ghz * 4.0,
                core_scaling: 0.8,
            }
        };

        let (has_battery, battery_pct) = detect_battery();

        Self {
            cores_physical, cores_logical, freq_mhz,
            mem_total, mem_available,
            disk_total: disk.0, disk_free: disk.1,
            nic_mbps, disk_bw_gbs: dbw,
            has_battery, battery_pct, roofline,
        }
    }

    // ── The primary API ────────────────────────────────────────

    /// Produce a Verdict for a given FnCost.
    ///
    /// `score > 0` => fetch is better (saves `score` seconds).
    /// `score < 0` => compute is better (saves `-score` seconds).
    pub fn verdict(&self, cost: &FnCost) -> Verdict {
        let bias = self.compute_bias();
        let can_compute = cost.peak_mem <= self.compute_budget();
        let can_fetch = self.nic_mbps > 0.0;
        let can_store = self.can_store(cost.result_bytes);

        let t_compute = if can_compute {
            self.roofline.compute_time(cost) * bias
        } else { f64::INFINITY };

        let t_fetch = if can_fetch {
            (cost.result_bytes as f64 * 8.0) / (self.nic_mbps * 1e6)
        } else { f64::INFINITY };

        let t_store = if self.disk_bw_gbs > 0.0 {
            cost.result_bytes as f64 / (self.disk_bw_gbs * 1e9)
        } else { f64::INFINITY };

        // score = T_compute - T_fetch
        // positive => fetch is cheaper, negative => compute is cheaper
        let score = if t_compute.is_infinite() && t_fetch.is_infinite() {
            f64::INFINITY // can do neither; signal infeasible
        } else {
            t_compute - t_fetch
        };

        Verdict {
            score, t_compute, t_fetch, t_store,
            bottleneck: self.roofline.bottleneck(cost),
            can_compute, can_store, can_fetch, bias,
        }
    }

    // ── Convenience methods that delegate to verdict ───────────

    /// Convert a wall-clock measurement into a machine-independent FnCost.
    ///
    /// # WARNING: NOT DETERMINISTIC
    ///
    /// The returned FnCost depends on the producing machine's benchmarked
    /// capabilities. Two different machines running the same function will
    /// produce **different** FnCost values from `normalize()`.
    ///
    /// **DO NOT use `normalize()`-produced FnCost values as cache keys,
    /// content addresses, or any identifier that must match across peers.**
    /// For cache keys, use the static constructors (`sort`, `hash`, `matmul`,
    /// etc.) or `FnCost::new()` with values derived from the function's AST
    /// and parameters -- never from wall-clock measurements.
    ///
    /// The intended use is local verdict computation: a producer measures
    /// wall time, calls `normalize()`, and passes the result to `verdict()`
    /// to decide whether the result is worth caching. The normalized FnCost
    /// is a safe overestimate suitable for verdict math, not for identity.
    ///
    /// # How it works
    ///
    /// After executing a function, the producer knows:
    ///   - `compute_ns`: wall-clock time in nanoseconds
    ///   - `peak_mem`:   peak RSS delta during execution (bytes)
    ///   - `result_bytes`: output size (bytes)
    ///
    /// The roofline model relates wall time to work:
    ///
    ///   t = max(W / pi, Q / beta)
    ///
    /// From one measurement we have one equation and two unknowns, so we
    /// take upper bounds:
    ///
    ///   W_upper = t * pi       (exact if compute-bound)
    ///   Q_upper = t * beta     (exact if memory-bound)
    ///
    /// This is a safe overestimate: it can only make compute look more
    /// expensive (biasing toward fetch), and it correctly handles
    /// bottleneck shifts between machines.
    pub fn normalize(&self, compute_ns: u64, peak_mem: u64, result_bytes: u64) -> FnCost {
        let secs = compute_ns as f64 / 1e9;
        let ops = (secs * self.roofline.peak_gflops * 1e9) as u64;
        let mem_bytes = (secs * self.roofline.mem_bw_gbs * 1e9) as u64;
        FnCost::new(ops, mem_bytes, peak_mem, result_bytes)
    }

    /// True if local compute is the better choice.
    pub fn should_compute(&self, cost: &FnCost) -> bool {
        self.verdict(cost).should_compute()
    }

    /// Seconds to compute locally (roofline, no bias).
    pub fn compute_time(&self, cost: &FnCost) -> f64 {
        self.roofline.compute_time(cost)
    }

    /// Seconds to download the result.
    pub fn fetch_time(&self, cost: &FnCost) -> f64 {
        if self.nic_mbps <= 0.0 { return f64::INFINITY; }
        (cost.result_bytes as f64 * 8.0) / (self.nic_mbps * 1e6)
    }

    /// Seconds to write the result to disk.
    pub fn store_time(&self, cost: &FnCost) -> f64 {
        if self.disk_bw_gbs <= 0.0 { return f64::INFINITY; }
        cost.result_bytes as f64 / (self.disk_bw_gbs * 1e9)
    }

    /// Which roofline ceiling limits this cost.
    pub fn bottleneck(&self, cost: &FnCost) -> Bottleneck {
        self.roofline.bottleneck(cost)
    }

    /// Can peak_mem fit in the compute budget?
    pub fn can_execute(&self, cost: &FnCost) -> bool {
        cost.peak_mem <= self.compute_budget()
    }

    /// Can the result fit on disk?
    pub fn can_store(&self, bytes: u64) -> bool {
        self.disk_free > bytes + self.min_free_bytes()
    }

    /// Seconds saved by caching. Positive = caching worthwhile.
    pub fn cache_value(&self, cost: &FnCost) -> f64 {
        self.compute_time(cost) - self.fetch_time(cost)
    }

    /// Suggested TTL proportional to compute/fetch ratio.
    pub fn suggest_ttl(&self, cost: &FnCost, base_ttl: f64) -> f64 {
        let tf = self.fetch_time(cost);
        if tf <= 0.0 || tf.is_infinite() { return base_ttl; }
        base_ttl * (self.compute_time(cost) / tf).clamp(0.1, 1000.0)
    }

    // ── ETL / buffer sizing ────────────────────────────────────

    /// Suggested row buffer for ETL. Fraction of available RAM, row-aligned.
    pub fn etl_buffer_bytes(&self, row_bytes: usize) -> usize {
        let budget = (self.compute_budget() / 2) as usize;
        (budget / row_bytes.max(1)) * row_bytes
    }

    // ── Device classification ──────────────────────────────────

    pub fn device_class(&self) -> DeviceClass {
        let mem_gb = self.mem_total as f64 / GB;
        let c = self.cores_physical;
        if self.has_battery && mem_gb < 6.0 { return DeviceClass::Constrained; }
        if mem_gb < 4.0 || c <= 2 { return DeviceClass::Constrained; }
        if self.has_battery { return DeviceClass::Laptop; }
        if c >= 16 || mem_gb >= 64.0 { return DeviceClass::Server; }
        DeviceClass::Desktop
    }

    pub fn mem_pressure(&self) -> f64 {
        if self.mem_total == 0 { 0.5 }
        else { 1.0 - self.mem_available as f64 / self.mem_total as f64 }
    }

    pub fn disk_pressure(&self) -> f64 {
        if self.disk_total == 0 { 0.5 }
        else { 1.0 - self.disk_free as f64 / self.disk_total as f64 }
    }

    fn compute_budget(&self) -> u64 {
        let frac = match self.device_class() {
            DeviceClass::Server => 0.70,
            DeviceClass::Desktop => 0.50,
            DeviceClass::Laptop => 0.40,
            DeviceClass::Constrained => 0.25,
        };
        (self.mem_available as f64 * frac) as u64
    }

    fn compute_bias(&self) -> f64 {
        match self.device_class() {
            DeviceClass::Server => 0.7,      // prefers compute
            DeviceClass::Desktop => 1.0,     // break-even
            DeviceClass::Laptop => 1.5,      // prefers fetch
            DeviceClass::Constrained => 3.0, // strongly prefers fetch
        }
    }

    fn min_free_bytes(&self) -> u64 {
        match self.device_class() {
            DeviceClass::Server => 4 << 30,
            DeviceClass::Desktop | DeviceClass::Laptop => 2 << 30,
            DeviceClass::Constrained => 512 << 20,
        }
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_default()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DeviceClass { Server, Desktop, Laptop, Constrained }

impl DeviceClass {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Server => "server", Self::Desktop => "desktop",
            Self::Laptop => "laptop", Self::Constrained => "constrained",
        }
    }
}

impl std::fmt::Display for DeviceClass {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result { f.write_str(self.as_str()) }
}

// ── Benchmarks ─────────────────────────────────────────────────

/// Cached CPU benchmarks. These are pure hardware characteristics that
/// cannot change without a physical CPU/RAM swap. Computed once per process.
struct CpuBench {
    single_core_gflops: f64,
    core_scaling: f64,
    mem_bw_gbs: f64,
}

static CPU_BENCH: OnceLock<CpuBench> = OnceLock::new();

fn cached_cpu_bench(cores_physical: usize) -> &'static CpuBench {
    CPU_BENCH.get_or_init(|| {
        let single = bench_gflops();
        let scaling = measure_core_scaling(cores_physical, single);
        CpuBench { single_core_gflops: single, core_scaling: scaling, mem_bw_gbs: bench_mem_bw() }
    })
}

pub fn bench_gflops() -> f64 {
    let iters: u64 = 10_000_000;
    let (mut a0, mut a1, mut a2, mut a3): (f64, f64, f64, f64) = (1.0, 1.1, 1.2, 1.3);
    let (mut a4, mut a5, mut a6, mut a7): (f64, f64, f64, f64) = (1.4, 1.5, 1.6, 1.7);
    let c = 0.9999;
    let t0 = Instant::now();
    for _ in 0..iters {
        a0 = a0.mul_add(c, a0); a1 = a1.mul_add(c, a1);
        a2 = a2.mul_add(c, a2); a3 = a3.mul_add(c, a3);
        a4 = a4.mul_add(c, a4); a5 = a5.mul_add(c, a5);
        a6 = a6.mul_add(c, a6); a7 = a7.mul_add(c, a7);
    }
    let elapsed = t0.elapsed().as_secs_f64();
    std::hint::black_box(a0 + a1 + a2 + a3 + a4 + a5 + a6 + a7);
    (iters as f64 * 16.0) / elapsed / 1e9
}

pub fn bench_mem_bw() -> f64 {
    let n = 32 * 1024 * 1024_usize;
    let mut a = vec![0.0_f64; n];
    let b: Vec<f64> = (0..n).map(|i| (i as f64) * 1e-12).collect();
    let cv: Vec<f64> = (0..n).map(|i| (i as f64) * 2e-12).collect();
    let s = 3.0_f64;
    for i in 0..n { a[i] = b[i] + s * cv[i]; }
    let reps = 3;
    let t0 = Instant::now();
    for _ in 0..reps { for i in 0..n { a[i] = b[i] + s * cv[i]; } }
    let elapsed = t0.elapsed().as_secs_f64();
    std::hint::black_box(&a);
    (n as f64 * 24.0 * reps as f64) / elapsed / 1e9
}

pub fn bench_disk_bw(dir: &Path) -> f64 {
    let size = 64 * 1024 * 1024_usize;
    let data = vec![0xA5_u8; size];
    let path = dir.join(".coren_bench_tmp");
    let t0 = Instant::now();
    if std::fs::write(&path, &data).is_err() { return 0.5; }
    let tw = t0.elapsed().as_secs_f64();
    let t0 = Instant::now();
    let ok = std::fs::read(&path).is_ok();
    let tr = t0.elapsed().as_secs_f64();
    let _ = std::fs::remove_file(&path);
    if !ok { return 0.5; }
    (size as f64 / tw / 1e9 + size as f64 / tr / 1e9) / 2.0
}

fn measure_core_scaling(cores: usize, single: f64) -> f64 {
    if cores <= 1 { return 1.0; }
    let results: Vec<f64> = std::thread::scope(|s| {
        let handles: Vec<_> = (0..cores).map(|_| s.spawn(bench_gflops)).collect();
        handles.into_iter().map(|h| h.join().unwrap_or(0.0)).collect()
    });
    let total: f64 = results.iter().sum();
    if single > 0.0 { total / (single * cores as f64) } else { 0.8 }
}

pub fn detect_nic_speed() -> f64 {
    #[cfg(target_os = "linux")]
    {
        let mut best = 0.0_f64;
        if let Ok(entries) = std::fs::read_dir("/sys/class/net") {
            for entry in entries.flatten() {
                let name = entry.file_name();
                if name.to_string_lossy() == "lo" { continue; }
                if let Ok(s) = std::fs::read_to_string(entry.path().join("speed")) {
                    if let Ok(mbps) = s.trim().parse::<f64>() {
                        if mbps > best { best = mbps; }
                    }
                }
            }
        }
        if best > 0.0 { return best; }
    }
    #[cfg(target_os = "macos")]
    {
        // Check en0-en9 (covers WiFi, Ethernet, Thunderbolt adapters).
        let mut best = 0.0_f64;
        for i in 0..10 {
            let iface = format!("en{}", i);
            if let Ok(out) = std::process::Command::new("ifconfig").arg(&iface).output() {
                let s = String::from_utf8_lossy(&out.stdout);
                let speed = if s.contains("10Gbase") { 10000.0 }
                    else if s.contains("5Gbase") || s.contains("5000base") { 5000.0 }
                    else if s.contains("2.5Gbase") || s.contains("2500base") { 2500.0 }
                    else if s.contains("1000base") { 1000.0 }
                    else if s.contains("100base") { 100.0 }
                    else { 0.0 };
                if speed > best { best = speed; }
            }
        }
        if best > 0.0 { return best; }
    }
    #[cfg(target_os = "windows")]
    {
        if let Ok(out) = std::process::Command::new("powershell")
            .args(["-NoProfile", "-Command",
                   "(Get-NetAdapter|Where Status -eq Up|Sort LinkSpeed -Desc|Select -First 1).LinkSpeed"])
            .output()
        {
            let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
            if let Some(n) = s.split_whitespace().next().and_then(|n| n.parse::<f64>().ok()) {
                if s.contains("Gbps") { return n * 1000.0; }
                if s.contains("Mbps") { return n; }
            }
        }
    }
    0.0
}

// ── Helpers ────────────────────────────────────────────────────

const GB: f64 = (1u64 << 30) as f64;

fn disk_usage_for(path: &Path) -> (u64, u64) {
    let total = fs2::total_space(path).unwrap_or(0);
    let free = fs2::available_space(path).unwrap_or(0);
    (total, free)
}

fn detect_battery() -> (bool, Option<f64>) {
    use battery::units::ratio::percent;
    let Ok(manager) = battery::Manager::new() else { return (false, None) };
    let Ok(mut batteries) = manager.batteries() else { return (false, None) };
    let Some(Ok(bat)) = batteries.next() else { return (false, None) };
    let pct = bat.state_of_charge().get::<percent>() as f64;
    (bat.state() != battery::State::Full, Some(pct))
}

// ── CLI ────────────────────────────────────────────────────────

pub fn print_report(cap: &MachCap) {
    let p = |l: &str, v: &str| println!("  {:<24} {}", l, v);
    let r = &cap.roofline;

    println!("\ncoren  [{}]\n", cap.device_class());
    p("cores", &format!("{}p / {}l", cap.cores_physical, cap.cores_logical));
    p("frequency", &format!("{:.0} MHz", cap.freq_mhz));

    println!("\n  roofline (measured)");
    p("  peak (1 core)", &format!("{:.1} GFLOPS", r.single_core_gflops));
    p("  core scaling", &format!("{:.0}%", r.core_scaling * 100.0));
    p("  peak (all cores)", &format!("{:.1} GFLOPS", r.peak_gflops));
    p("  mem bandwidth", &format!("{:.1} GB/s", r.mem_bw_gbs));
    p("  disk bandwidth", &format!("{:.2} GB/s", cap.disk_bw_gbs));
    p("  ridge point", &format!("{:.2} ops/byte", r.ridge_point()));

    println!();
    p("mem total", &format!("{:.1} GB", cap.mem_total as f64 / GB));
    p("mem available", &format!("{:.1} GB", cap.mem_available as f64 / GB));
    p("disk total", &format!("{:.1} GB", cap.disk_total as f64 / GB));
    p("disk free", &format!("{:.1} GB", cap.disk_free as f64 / GB));
    p("nic speed", &if cap.nic_mbps > 0.0 { format!("{:.0} Mbps", cap.nic_mbps) }
                     else { "none".into() });
    p("battery", &cap.battery_pct.map(|v| format!("{:.0}%", v))
        .unwrap_or_else(|| "none".into()));
    p("compute bias", &format!("{:.1}x ({})", cap.compute_bias(), cap.device_class()));

    println!("\n  verdicts (what should this machine do?)");
    println!("    {:<22} {:>9} {:>9} {:>9} {:>8} {:>10} action",
        "task", "W", "Q", "R", "score", "neck");
    println!("    {}", "-".repeat(78));

    let tasks: &[(FnCost, &str)] = &[
        (FnCost::sort(1_000_000, 64, 10 << 20), "sort 1M x 64B"),
        (FnCost::scan(1 << 30, 10 << 20), "scan 1 GB"),
        (FnCost::hash(1 << 30), "hash 1 GB"),
        (FnCost::matmul(1000, 1000, 1000, 10 << 20), "matmul 1k^3"),
        (FnCost::etl(1_000_000, 256, 100, 10 << 20), "etl 1M rows"),
        (FnCost::copy(1 << 30), "copy 1 GB"),
    ];
    for (cost, label) in tasks {
        let v = cap.verdict(cost);
        let score_s = if v.score == f64::NEG_INFINITY { "-inf".into() }
                      else if v.score == f64::INFINITY { "+inf".into() }
                      else { format!("{:+.3}", v.score) };
        println!("    {:<22} {:>9} {:>9} {:>9} {:>8} {:>10} {}",
            label, fmt_si(cost.ops), fmt_si_b(cost.mem_bytes),
            fmt_si_b(cost.result_bytes), score_s, v.bottleneck, v.recommendation());
    }
    println!();
}

fn fmt_si(n: u64) -> String {
    if n >= 1_000_000_000 { format!("{:.1}G", n as f64 / 1e9) }
    else if n >= 1_000_000 { format!("{:.1}M", n as f64 / 1e6) }
    else if n >= 1_000 { format!("{:.1}K", n as f64 / 1e3) }
    else { format!("{}", n) }
}

fn fmt_si_b(n: u64) -> String {
    if n >= 1 << 30 { format!("{:.1}GB", n as f64 / GB) }
    else if n >= 1 << 20 { format!("{:.1}MB", n as f64 / (1 << 20) as f64) }
    else if n >= 1 << 10 { format!("{:.1}KB", n as f64 / 1024.0) }
    else { format!("{}B", n) }
}
