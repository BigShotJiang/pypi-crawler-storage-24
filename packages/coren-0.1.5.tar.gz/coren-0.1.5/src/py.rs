use crate::{FnCost, MachCap, Verdict};
use pyo3::prelude::*;
use pyo3::types::PyDict;

#[pyclass(name = "FnCost", module = "coren")]
#[derive(Clone)]
struct PyFnCost(FnCost);

#[pymethods]
impl PyFnCost {
    #[new]
    fn new(ops: u64, mem_bytes: u64, peak_mem: u64, result_bytes: u64) -> Self {
        Self(FnCost::new(ops, mem_bytes, peak_mem, result_bytes))
    }

    #[getter]
    fn ops(&self) -> u64 {
        self.0.ops
    }
    #[getter]
    fn mem_bytes(&self) -> u64 {
        self.0.mem_bytes
    }
    #[getter]
    fn peak_mem(&self) -> u64 {
        self.0.peak_mem
    }
    #[getter]
    fn result_bytes(&self) -> u64 {
        self.0.result_bytes
    }
    #[getter]
    fn intensity(&self) -> f64 {
        self.0.intensity()
    }

    fn then(&self, other: &PyFnCost) -> PyFnCost {
        PyFnCost(self.0.then(other.0))
    }
    fn par(&self, other: &PyFnCost) -> PyFnCost {
        PyFnCost(self.0.par(other.0))
    }
    fn repeat(&self, k: u64) -> PyFnCost {
        PyFnCost(self.0.repeat(k))
    }

    #[staticmethod]
    fn scan(n: u64, r: u64) -> PyFnCost {
        PyFnCost(FnCost::scan(n, r))
    }
    #[staticmethod]
    fn sort(n: u64, ib: u64, r: u64) -> PyFnCost {
        PyFnCost(FnCost::sort(n, ib, r))
    }
    #[staticmethod]
    fn hash(n: u64) -> PyFnCost {
        PyFnCost(FnCost::hash(n))
    }
    #[staticmethod]
    fn matmul(m: u64, n: u64, k: u64, r: u64) -> PyFnCost {
        PyFnCost(FnCost::matmul(m, n, k, r))
    }
    #[staticmethod]
    fn etl(rows: u64, rb: u64, fpr: u64, r: u64) -> PyFnCost {
        PyFnCost(FnCost::etl(rows, rb, fpr, r))
    }
    #[staticmethod]
    fn copy(size: u64) -> PyFnCost {
        PyFnCost(FnCost::copy(size))
    }

    fn __add__(&self, other: &PyFnCost) -> PyFnCost {
        PyFnCost(self.0.then(other.0))
    }
    fn __eq__(&self, other: &PyFnCost) -> bool {
        self.0 == other.0
    }
    fn __repr__(&self) -> String {
        format!(
            "FnCost(ops={}, Q={}, M={}, R={})",
            self.0.ops, self.0.mem_bytes, self.0.peak_mem, self.0.result_bytes
        )
    }
}

#[pyclass(name = "Verdict", module = "coren")]
#[derive(Clone)]
struct PyVerdict(Verdict);

#[pymethods]
impl PyVerdict {
    #[getter]
    fn score(&self) -> f64 {
        self.0.score
    }
    #[getter]
    fn t_compute(&self) -> f64 {
        self.0.t_compute
    }
    #[getter]
    fn t_fetch(&self) -> f64 {
        self.0.t_fetch
    }
    #[getter]
    fn t_store(&self) -> f64 {
        self.0.t_store
    }
    #[getter]
    fn bottleneck(&self) -> String {
        self.0.bottleneck.as_str().to_string()
    }
    #[getter]
    fn can_compute(&self) -> bool {
        self.0.can_compute
    }
    #[getter]
    fn can_store(&self) -> bool {
        self.0.can_store
    }
    #[getter]
    fn can_fetch(&self) -> bool {
        self.0.can_fetch
    }
    #[getter]
    fn bias(&self) -> f64 {
        self.0.bias
    }
    #[getter]
    fn recommendation(&self) -> String {
        self.0.recommendation().to_string()
    }

    fn should_fetch(&self) -> bool {
        self.0.should_fetch()
    }
    fn should_compute(&self) -> bool {
        self.0.should_compute()
    }

    fn as_dict<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let d = PyDict::new_bound(py);
        d.set_item("score", self.0.score)?;
        d.set_item("t_compute", self.0.t_compute)?;
        d.set_item("t_fetch", self.0.t_fetch)?;
        d.set_item("t_store", self.0.t_store)?;
        d.set_item("bottleneck", self.0.bottleneck.as_str())?;
        d.set_item("can_compute", self.0.can_compute)?;
        d.set_item("can_store", self.0.can_store)?;
        d.set_item("can_fetch", self.0.can_fetch)?;
        d.set_item("recommendation", self.0.recommendation())?;
        Ok(d)
    }

    fn __repr__(&self) -> String {
        format!("Verdict({})", self.0)
    }
    fn __str__(&self) -> String {
        format!("{}", self.0)
    }
    fn __bool__(&self) -> bool {
        self.0.should_fetch()
    }
}

#[pyclass(name = "MachCap", module = "coren")]
#[derive(Clone)]
struct PyMachCap(MachCap);

#[pymethods]
impl PyMachCap {
    #[staticmethod]
    #[pyo3(signature = (store_path=".", detect_net=true, run_bench=true))]
    fn read(store_path: &str, detect_net: bool, run_bench: bool) -> Self {
        Self(MachCap::read_opts(store_path, detect_net, run_bench))
    }

    fn verdict(&self, cost: &PyFnCost) -> PyVerdict {
        PyVerdict(self.0.verdict(&cost.0))
    }
    fn normalize(&self, compute_ns: u64, peak_mem: u64, result_bytes: u64) -> PyFnCost {
        PyFnCost(self.0.normalize(compute_ns, peak_mem, result_bytes))
    }
    fn should_compute(&self, cost: &PyFnCost) -> bool {
        self.0.should_compute(&cost.0)
    }
    fn compute_time(&self, cost: &PyFnCost) -> f64 {
        self.0.compute_time(&cost.0)
    }
    fn fetch_time(&self, cost: &PyFnCost) -> f64 {
        self.0.fetch_time(&cost.0)
    }
    fn store_time(&self, cost: &PyFnCost) -> f64 {
        self.0.store_time(&cost.0)
    }
    fn bottleneck(&self, cost: &PyFnCost) -> String {
        self.0.bottleneck(&cost.0).as_str().to_string()
    }
    fn can_execute(&self, cost: &PyFnCost) -> bool {
        self.0.can_execute(&cost.0)
    }
    fn can_store(&self, bytes: u64) -> bool {
        self.0.can_store(bytes)
    }
    fn cache_value(&self, cost: &PyFnCost) -> f64 {
        self.0.cache_value(&cost.0)
    }
    fn suggest_ttl(&self, cost: &PyFnCost, base: f64) -> f64 {
        self.0.suggest_ttl(&cost.0, base)
    }
    fn etl_buffer_bytes(&self, row_bytes: usize) -> usize {
        self.0.etl_buffer_bytes(row_bytes)
    }

    #[getter]
    fn device_class(&self) -> String {
        self.0.device_class().as_str().to_string()
    }
    #[getter]
    fn cores_physical(&self) -> usize {
        self.0.cores_physical
    }
    #[getter]
    fn mem_total(&self) -> u64 {
        self.0.mem_total
    }
    #[getter]
    fn mem_available(&self) -> u64 {
        self.0.mem_available
    }
    #[getter]
    fn disk_total(&self) -> u64 {
        self.0.disk_total
    }
    #[getter]
    fn disk_free(&self) -> u64 {
        self.0.disk_free
    }
    #[getter]
    fn nic_mbps(&self) -> f64 {
        self.0.nic_mbps
    }
    #[getter]
    fn peak_gflops(&self) -> f64 {
        self.0.roofline.peak_gflops
    }
    #[getter]
    fn mem_bw_gbs(&self) -> f64 {
        self.0.roofline.mem_bw_gbs
    }
    #[getter]
    fn ridge_point(&self) -> f64 {
        self.0.roofline.ridge_point()
    }

    fn to_json(&self) -> String {
        self.0.to_json()
    }
    fn __repr__(&self) -> String {
        format!(
            "MachCap(class={}, pi={:.1}GF, beta={:.1}GB/s, nic={:.0}Mbps)",
            self.0.device_class(),
            self.0.roofline.peak_gflops,
            self.0.roofline.mem_bw_gbs,
            self.0.nic_mbps
        )
    }
}

#[pymodule]
fn coren(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyFnCost>()?;
    m.add_class::<PyVerdict>()?;
    m.add_class::<PyMachCap>()?;
    Ok(())
}
