use coren::*;

// ── FnCost determinism ─────────────────────────────────────────

#[test]
fn fncost_bitwise_identical() {
    let a = FnCost::sort(1_000_000, 64, 10_000_000);
    let b = FnCost::sort(1_000_000, 64, 10_000_000);
    assert_eq!(a, b);
    assert_eq!(a.ops, b.ops);
    assert_eq!(a.mem_bytes, b.mem_bytes);
}

#[test]
fn sort_uses_integer_log2() {
    let c = FnCost::sort(1_000_000, 64, 0);
    assert_eq!(c.ops, 1_000_000 * 20 * 10); // ceil(log2(1M)) = 20
    assert_eq!(c.mem_bytes, 1_000_000 * 64 * 20);
}

#[test]
fn hash_exact_values() {
    let c = FnCost::hash(1_000_000);
    assert_eq!(c.ops, 2_000_000);
    assert_eq!(c.mem_bytes, 1_000_000);
    assert_eq!(c.result_bytes, 32);
}

#[test]
fn matmul_exact_values() {
    let c = FnCost::matmul(100, 100, 100, 80_000);
    assert_eq!(c.ops, 2_000_000);
    assert_eq!(c.mem_bytes, 30_000 * 8);
}

#[test]
fn copy_zero_ops() {
    let c = FnCost::copy(1 << 30);
    assert_eq!(c.ops, 0);
    assert_eq!(c.result_bytes, 1 << 30);
}

// ── Combinators ────────────────────────────────────────────────

#[test]
fn then_composition() {
    let a = FnCost::new(100, 200, 50, 10);
    let b = FnCost::new(300, 400, 80, 20);
    let c = a.then(b);
    assert_eq!(c.ops, 400);
    assert_eq!(c.mem_bytes, 600);
    assert_eq!(c.peak_mem, 80);
    assert_eq!(c.result_bytes, 20); // last stage
}

#[test]
fn par_composition() {
    let a = FnCost::new(100, 200, 50, 10);
    let b = FnCost::new(300, 400, 80, 20);
    let c = a.par(b);
    assert_eq!(c.ops, 300);
    assert_eq!(c.peak_mem, 130);
    assert_eq!(c.result_bytes, 30);
}

#[test]
fn repeat_preserves_peak_mem() {
    let c = FnCost::new(100, 200, 50, 10).repeat(5);
    assert_eq!(c.ops, 500);
    assert_eq!(c.peak_mem, 50);
}

#[test]
fn pipeline_works() {
    let pipe = FnCost::scan(64_000_000, 0)
        .then(FnCost::sort(1_000_000, 64, 0))
        .then(FnCost::hash(64_000_000));
    assert!(pipe.ops > 0);
    assert_eq!(pipe.result_bytes, 32);
}

// ── Verdict sign semantics ─────────────────────────────────────

fn test_cap() -> MachCap {
    let mut cap = MachCap::read_opts(".", false, false);
    cap.roofline = Roofline {
        peak_gflops: 100.0, mem_bw_gbs: 20.0,
        single_core_gflops: 25.0, core_scaling: 1.0,
    };
    cap.nic_mbps = 1000.0;
    cap.disk_bw_gbs = 1.0;
    cap.cores_physical = 8; // force desktop classification
    cap.mem_available = 8 << 30;
    cap.mem_total = 16 << 30;
    cap.disk_total = 100 << 30;
    cap.disk_free = 50 << 30;
    cap.has_battery = false;
    cap
}

#[test]
fn verdict_negative_means_compute() {
    let cap = test_cap();
    // Fast compute, large result to fetch.
    // T_compute: few ms. T_fetch: 100MB * 8 / 1e9 = 0.8s.
    let cost = FnCost::sort(100_000, 64, 100 << 20);
    let v = cap.verdict(&cost);
    assert!(v.score < 0.0, "score={} should be negative (compute)", v.score);
    assert!(v.should_compute());
    assert!(!v.should_fetch());
}

#[test]
fn verdict_positive_means_fetch() {
    let cap = test_cap();
    // Huge compute, tiny result.
    // T_compute: 1e14 / 100e9 = 1000s. T_fetch: 1KB * 8 / 1e9 = 0.000008s.
    let cost = FnCost::new(100_000_000_000_000, 0, 0, 1000);
    let v = cap.verdict(&cost);
    assert!(v.score > 0.0, "score={} should be positive (fetch)", v.score);
    assert!(v.should_fetch());
}

#[test]
fn verdict_infinity_when_cannot_compute() {
    let cap = test_cap(); // 8GB avail, desktop 50% = 4GB budget
    let cost = FnCost::new(1000, 1000, 100 << 30, 1000); // 100GB peak
    let v = cap.verdict(&cost);
    assert_eq!(v.score, f64::INFINITY);
    assert!(!v.can_compute);
    assert!(v.should_fetch());
    assert_eq!(v.recommendation(), "must fetch (insufficient RAM)");
}

#[test]
fn verdict_neg_infinity_when_cannot_fetch() {
    let mut cap = test_cap();
    cap.nic_mbps = 0.0; // no network
    let cost = FnCost::sort(1_000_000, 64, 10 << 20);
    let v = cap.verdict(&cost);
    assert_eq!(v.score, f64::NEG_INFINITY);
    assert!(!v.can_fetch);
    assert!(v.should_compute());
    assert_eq!(v.recommendation(), "must compute (no network)");
}

#[test]
fn verdict_has_full_breakdown() {
    let cap = test_cap();
    let cost = FnCost::sort(1_000_000, 64, 10 << 20);
    let v = cap.verdict(&cost);
    assert!(v.t_compute > 0.0);
    assert!(v.t_fetch > 0.0);
    assert!(v.t_store > 0.0);
    assert!(v.bias == 1.0); // desktop
}

#[test]
fn verdict_bias_shifts_threshold() {
    let mut cap = test_cap();

    // Make it a laptop (battery + enough cores/ram to not be constrained).
    cap.has_battery = true;
    cap.cores_physical = 8;
    cap.mem_total = 16 << 30;
    let cost = FnCost::new(10_000_000_000, 1_000_000_000, 0, 10 << 20);
    let v_laptop = cap.verdict(&cost);

    // Make it a desktop.
    cap.has_battery = false;
    let v_desktop = cap.verdict(&cost);

    // Laptop bias = 1.5 (penalizes compute), desktop = 1.0.
    assert!(v_laptop.score > v_desktop.score,
        "laptop score {} should exceed desktop score {}", v_laptop.score, v_desktop.score);
}

#[test]
fn verdict_display() {
    let cap = test_cap();
    let cost = FnCost::sort(1_000_000, 64, 100 << 20);
    let v = cap.verdict(&cost);
    let s = format!("{}", v);
    assert!(s.contains("compute") || s.contains("fetch"));
}

// ── Roofline math ──────────────────────────────────────────────

#[test]
fn compute_bound_time() {
    let r = Roofline { peak_gflops: 100.0, mem_bw_gbs: 10.0,
                        single_core_gflops: 25.0, core_scaling: 1.0 };
    let cost = FnCost::new(10_000_000_000, 100_000_000, 0, 0);
    assert!((r.compute_time(&cost) - 0.1).abs() < 1e-6);
}

#[test]
fn memory_bound_time() {
    let r = Roofline { peak_gflops: 100.0, mem_bw_gbs: 10.0,
                        single_core_gflops: 25.0, core_scaling: 1.0 };
    let cost = FnCost::new(100_000_000, 10_000_000_000, 0, 0);
    assert!((r.compute_time(&cost) - 1.0).abs() < 1e-6);
}

#[test]
fn bottleneck_classification() {
    let r = Roofline { peak_gflops: 100.0, mem_bw_gbs: 10.0,
                        single_core_gflops: 25.0, core_scaling: 1.0 };
    assert_eq!(r.bottleneck(&FnCost::new(10_000_000_000, 100_000_000, 0, 0)), Bottleneck::Compute);
    assert_eq!(r.bottleneck(&FnCost::new(1_000_000, 10_000_000_000, 0, 0)), Bottleneck::Memory);
    assert_eq!(r.bottleneck(&FnCost::ZERO), Bottleneck::None);
}

// ── Fetch / store time ─────────────────────────────────────────

#[test]
fn fetch_time_1gbps() {
    let cap = test_cap(); // 1 Gbps
    let cost = FnCost::new(0, 0, 0, 125_000_000); // 125 MB
    assert!((cap.fetch_time(&cost) - 1.0).abs() < 1e-6);
}

#[test]
fn store_time_1gbs() {
    let cap = test_cap(); // 1.0 GB/s disk
    let cost = FnCost::new(0, 0, 0, 1_000_000_000);
    assert!((cap.store_time(&cost) - 1.0).abs() < 1e-6);
}

// ── Other use cases ────────────────────────────────────────────

#[test]
fn etl_buffer_row_aligned() {
    let cap = test_cap();
    let buf = cap.etl_buffer_bytes(256);
    assert!(buf > 0);
    assert_eq!(buf % 256, 0);
}

#[test]
fn cache_value_positive_expensive() {
    let cap = test_cap();
    let cost = FnCost::new(1_000_000_000_000, 0, 0, 10 << 20);
    assert!(cap.cache_value(&cost) > 0.0);
}

#[test]
fn suggest_ttl_scales() {
    let cap = test_cap();
    let cheap = FnCost::new(1_000_000, 0, 0, 10 << 20);
    let expensive = FnCost::new(1_000_000_000_000, 0, 0, 10 << 20);
    assert!(cap.suggest_ttl(&expensive, 3600.0) > cap.suggest_ttl(&cheap, 3600.0));
}

// ── Benchmarks run ─────────────────────────────────────────────

#[test]
fn bench_gflops_positive() { assert!(bench_gflops() > 0.0); }

#[test]
fn bench_mem_bw_positive() { assert!(bench_mem_bw() > 0.0); }

#[test]
fn read_valid() {
    let cap = MachCap::read_opts(".", false, false);
    assert!(cap.cores_physical >= 1);
    assert!(cap.mem_total > 0);
}

#[test]
fn json_parses() {
    let cap = MachCap::read_opts(".", false, false);
    let _: serde_json::Value = serde_json::from_str(&cap.to_json()).unwrap();
}
