"""Gauss-Hermite quadrature utilities for the EM E-step.

The EM algorithm requires integrating over the random effects distribution.
We use Gauss-Hermite quadrature (GHQ), which is the standard approach for
this class of problem — see Rizopoulos (2012) Chapter 3.

For a dim=2 random effects vector (random intercept + slope), a product rule
with 7 points per dimension gives 49 evaluation points. This is accurate
enough for typical problems. Higher dimensions need adaptive GHQ or MCMC.

The key identities used:

1-D: ∫ f(b) N(b; μ, σ²) db = (1/√π) Σₖ wₖ f(μ + √2 σ xₖ)

2-D: ∫ f(b) N(b; μ, Σ) db = (1/π) Σₖ wₖ f(μ + √2 L xₖ)

where (xₖ, wₖ) are the Gauss-Hermite abscissae and weights from hermgauss
(which approximate ∫ g(x) exp(-x²) dx), and L = Cholesky(Σ).

Derivation of the 1-D formula:
  Substitute b = μ + √2 σ x, db = √2 σ dx.
  ∫ f(b) · (1/√(2πσ²)) exp(-(b-μ)²/2σ²) db
  = (1/√(2πσ²)) · √2σ · ∫ f(μ + √2σ x) exp(-x²) dx
  = (1/√π) Σₖ wₖ f(μ + √2σ xₖ)

The (√2σ) from the Jacobian and the (1/√(2π)σ) from the Gaussian density
combine to give 1/√π. The factor det(L) in the 2-D case similarly cancels.
"""

from __future__ import annotations

import numpy as np
from numpy.polynomial.hermite import hermgauss


def gauss_hermite_points(n_points: int) -> tuple[np.ndarray, np.ndarray]:
    """Return standard Gauss-Hermite abscissae and weights.

    These approximate ∫ g(x) exp(-x²) dx ≈ Σ wₖ g(xₖ).
    Weights sum to √π. Abscissae are in ascending order.

    Parameters
    ----------
    n_points:
        Number of quadrature points. 7 is the standard choice for dim(b)=2.

    Returns
    -------
    abscissae:
        Shape (n_points,). Quadrature nodes.
    weights:
        Shape (n_points,). Corresponding weights (sum to sqrt(π)).
    """
    abscissae, weights = hermgauss(n_points)
    return abscissae, weights


def product_rule_2d(
    n_points: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Build a 2-D product Gauss-Hermite rule.

    For integrating f(b1, b2) exp(-(b1² + b2²)) db1 db2, we take the
    Cartesian product of the 1-D rule.

    Parameters
    ----------
    n_points:
        Points per dimension. Total evaluation points = n_points².

    Returns
    -------
    nodes:
        Shape (n_points², 2). Each row is a (b1, b2) quadrature node.
    weights:
        Shape (n_points²,). Product weights (sum to π).
    """
    pts, wts = gauss_hermite_points(n_points)
    # Cartesian product
    b1, b2 = np.meshgrid(pts, pts, indexing="ij")
    w1, w2 = np.meshgrid(wts, wts, indexing="ij")
    nodes = np.column_stack([b1.ravel(), b2.ravel()])
    weights = (w1 * w2).ravel()
    return nodes, weights


def ghq_integral_1d(
    func: "callable",
    mean: float,
    var: float,
    n_points: int,
) -> float:
    """Approximate ∫ func(b) * N(b; mean, var) db via GHQ.

    Uses the identity:
      ∫ f(b) N(b; μ, σ²) db = (1/√π) Σₖ wₖ f(μ + √2 σ xₖ)

    Parameters
    ----------
    func:
        Function of a scalar b.
    mean:
        Mean of the Gaussian.
    var:
        Variance (not std) of the Gaussian.
    n_points:
        GHQ points.

    Returns
    -------
    Approximation of the integral.
    """
    pts, wts = gauss_hermite_points(n_points)
    sd = np.sqrt(var)
    # Transform: b = mean + sqrt(2) * sd * x
    b_vals = mean + np.sqrt(2.0) * sd * pts
    # The 1/sqrt(pi) normalisation factor
    return np.sum(wts * func(b_vals)) / np.sqrt(np.pi)


def ghq_integral_2d(
    func: "callable",
    mean: np.ndarray,
    cov: np.ndarray,
    n_points: int,
) -> float:
    """Approximate ∫ func(b) * N(b; mean, cov) db via 2-D product GHQ.

    Uses the identity:
      ∫ f(b) N(b; μ, Σ) db = (1/π) Σₖ wₖ f(μ + √2 L xₖ)

    where L = Cholesky(Σ). The Jacobian det(√2 L) and Gaussian normalisation
    factor 1/(2π det(L)) combine to give 1/π.

    Parameters
    ----------
    func:
        Function of a length-2 array b. Should return a scalar.
    mean:
        Shape (2,). Mean vector.
    cov:
        Shape (2, 2). Covariance matrix. Must be positive definite.
    n_points:
        GHQ points per dimension.

    Returns
    -------
    Approximation of the 2-D integral.
    """
    nodes, weights = product_rule_2d(n_points)
    L = np.linalg.cholesky(cov)
    # Transform: b = mean + sqrt(2) * L @ x
    b_vals = mean + np.sqrt(2.0) * (nodes @ L.T)
    # Evaluate integrand at all nodes
    f_vals = np.array([func(b) for b in b_vals])
    # The 1/pi normalisation factor
    return np.sum(weights * f_vals) / np.pi


def posterior_covariance_approx(
    log_posterior_hessian: np.ndarray,
) -> np.ndarray:
    """Compute posterior covariance from the Hessian of the log-posterior.

    At the posterior mode, the Laplace approximation gives:
      Var(b | data) ≈ -H⁻¹  where H = ∇² log p(b | data)

    Parameters
    ----------
    log_posterior_hessian:
        Shape (d, d). Hessian of the log-posterior at the mode. Should be
        negative definite.

    Returns
    -------
    Shape (d, d). Approximate posterior covariance matrix.
    """
    H = np.asarray(log_posterior_hessian)
    cov = np.linalg.solve(-H, np.eye(H.shape[0]))
    # Symmetrise to guard against numerical drift
    return 0.5 * (cov + cov.T)
