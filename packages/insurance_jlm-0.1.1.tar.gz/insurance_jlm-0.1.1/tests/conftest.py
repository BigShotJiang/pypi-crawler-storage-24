"""Shared fixtures for insurance-jlm tests.

The session-scoped fixtures are designed to be as fast as possible while
still exercising the full EM loop. Key choices:
- 100 subjects (minimum for stable EM, fast enough for CI)
- 2 EM iterations (enough to test the loop mechanics, not enough for convergence)
- 3 GHQ points (minimum, 7 is production standard)
- se_method='none' (skip bootstrap SEs — they would triple test time)
"""

import numpy as np
import pandas as pd
import pytest


@pytest.fixture(scope="session")
def small_dataset():
    """Minimal synthetic dataset: 80 subjects, 2-4 monthly readings each."""
    rng = np.random.default_rng(0)
    n = 80
    rows = []

    D = np.array([[4.0, 0.5], [0.5, 0.25]])
    b_effects = rng.multivariate_normal([0.0, 0.0], D, size=n)
    ages = rng.uniform(20, 60, size=n)
    veh_ages = rng.uniform(0, 10, size=n)

    for i in range(n):
        b0, b1 = b_effects[i]
        age = ages[i]
        veh = veh_ages[i]
        n_obs = rng.integers(2, 5)
        T_i = rng.exponential(8.0)
        T_i = min(T_i, 12.0)
        had_claim = 1 if T_i < 12.0 else 0

        for m in range(1, int(min(T_i + 1, n_obs + 1))):
            score = 70 + 0.1 * age - 0.5 * m + b0 + b1 * m + rng.normal(0, 3)
            rows.append({
                "policy_id": f"P{i:04d}",
                "month": float(m),
                "telematics_score": score,
                "age": age,
                "vehicle_age": veh,
                "claim_month": T_i,
                "had_claim": had_claim,
            })

    return pd.DataFrame(rows)


@pytest.fixture(scope="session")
def medium_dataset():
    """100-subject dataset for EM fitting tests.

    Kept small deliberately — the EM in pure Python takes ~1 min per 100
    subjects at 3 quad points. Larger datasets belong in the demo notebook.
    """
    from insurance_jlm.data import make_synthetic_telematics
    telem, claims = make_synthetic_telematics(n_subjects=100, random_state=1)
    data = telem.merge(
        claims[["policy_id", "claim_month", "had_claim"]],
        on="policy_id",
    )
    return data, telem, claims


@pytest.fixture(scope="session")
def fitted_model(medium_dataset):
    """Pre-fitted JointModel (2 iterations, 3 quad points, no SEs).

    This fixture is session-scoped so it is fitted once and shared across
    all tests that need a fitted model. The 2-iteration limit means the model
    will not have converged but the parameter structures will be populated.
    """
    from insurance_jlm import JointModel
    data, _, _ = medium_dataset
    model = JointModel(
        n_quad_points=3,
        max_iter=2,
        se_method="none",
        random_state=42,
    )
    model.fit(
        data=data,
        id_col="policy_id",
        time_col="month",
        y_col="telematics_score",
        event_time_col="claim_month",
        event_col="had_claim",
        long_covariates=["age"],
        surv_covariates=["age", "vehicle_age"],
    )
    return model, data
