# Databricks notebook source
# COMMAND ----------
# MAGIC %pip install statsmodels lifelines matplotlib pytest pytest-cov

# COMMAND ----------
dbutils.library.restartPython()

# COMMAND ----------
import subprocess
import sys
import os

sys.path.insert(0, "/Workspace/insurance-jlm/src")

import insurance_jlm
print(f"insurance_jlm loaded from: {insurance_jlm.__file__}")
print(f"Version: {insurance_jlm.__version__}")

# COMMAND ----------
env = {
    **os.environ,
    "PYTHONPATH": "/Workspace/insurance-jlm/src",
    "PYTHONDONTWRITEBYTECODE": "1",
}

result = subprocess.run(
    [
        sys.executable, "-m", "pytest",
        "/Workspace/insurance-jlm/tests",
        "-v", "--tb=short",
        "--import-mode=importlib",
        "-p", "no:cacheprovider",
        f"--rootdir=/Workspace/insurance-jlm",
    ],
    capture_output=True,
    text=True,
    env=env,
)
output = result.stdout + "\n" + result.stderr
print(output)
dbutils.notebook.exit(output[-8000:] if len(output) > 8000 else output)
