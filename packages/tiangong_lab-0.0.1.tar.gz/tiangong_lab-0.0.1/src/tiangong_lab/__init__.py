"""
TianGong Lab -- Experimental playground and sandbox for AI Agent development.
"""
__version__ = "0.0.1"
