# tiangong-lab

> TianGong Lab -- Experimental playground and sandbox for AI Agent development.

Part of the [TianGong](https://github.com/JinNing6/TianGong) ecosystem.

## Status

Planning -- This package is under active development. Stay tuned!

## License

MIT
