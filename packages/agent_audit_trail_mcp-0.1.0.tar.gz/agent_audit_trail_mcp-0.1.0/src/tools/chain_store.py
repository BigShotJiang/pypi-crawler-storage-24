"""
Hash-verketteter Append-Only Log Store.

Jeder Eintrag enthält den SHA-256-Hash des vorherigen Eintrags,
sodass nachträgliche Manipulation erkennbar ist.
"""

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any


# Basis-Verzeichnis für alle Audit-Logs
AUDIT_DIR = Path.home() / ".agent-audit-trail"


def _agent_log_path(agent_id: str) -> Path:
    """Gibt den Pfad zur Log-Datei eines Agents zurück."""
    # Agent-ID bereinigen (nur sichere Zeichen)
    safe_id = "".join(c if c.isalnum() or c in "-_" else "_" for c in agent_id)
    return AUDIT_DIR / f"{safe_id}.jsonl"


def _compute_hash(entry: dict) -> str:
    """Berechnet SHA-256 Hash eines Eintrags (ohne das hash-Feld selbst)."""
    # Deterministisches JSON für konsistente Hashes
    data = {k: v for k, v in entry.items() if k != "hash"}
    raw = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _get_last_hash(agent_id: str) -> str:
    """Liest den Hash des letzten Eintrags oder gibt Genesis-Hash zurück."""
    log_path = _agent_log_path(agent_id)
    if not log_path.exists():
        return "0" * 64  # Genesis-Hash

    last_line = ""
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                last_line = line

    if not last_line:
        return "0" * 64

    try:
        entry = json.loads(last_line)
        return entry.get("hash", "0" * 64)
    except json.JSONDecodeError:
        return "0" * 64


def append_event(
    agent_id: str,
    event_type: str,
    action: str,
    details: str,
    outcome: str,
) -> dict:
    """
    Fügt ein neues Event an die Hash-Kette an.

    Gibt den vollständigen Eintrag inkl. Hash zurück.
    """
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)

    prev_hash = _get_last_hash(agent_id)

    entry = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "agent_id": agent_id,
        "event_type": event_type,
        "action": action,
        "details": details,
        "outcome": outcome,
        "prev_hash": prev_hash,
    }

    # Hash berechnen und anfügen
    entry["hash"] = _compute_hash(entry)

    # Append-Only: An Datei anhängen
    log_path = _agent_log_path(agent_id)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    return entry


def read_trail(agent_id: str, limit: int = 50) -> list[dict]:
    """Liest die letzten N Einträge eines Agents."""
    log_path = _agent_log_path(agent_id)
    if not log_path.exists():
        return []

    entries = []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

    # Letzte N Einträge zurückgeben (neueste zuerst)
    return list(reversed(entries[-limit:]))


def read_all_entries(agent_id: str) -> list[dict]:
    """Liest alle Einträge eines Agents (chronologisch)."""
    log_path = _agent_log_path(agent_id)
    if not log_path.exists():
        return []

    entries = []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

    return entries


def verify_chain(agent_id: str) -> dict:
    """
    Prüft die Integrität der Hash-Kette.

    Gibt Status und Details zurück.
    """
    entries = read_all_entries(agent_id)

    if not entries:
        return {
            "agent_id": agent_id,
            "status": "empty",
            "message": "Keine Einträge vorhanden",
            "total_entries": 0,
            "valid_entries": 0,
            "tampered_entries": [],
        }

    genesis_hash = "0" * 64
    tampered = []
    valid_count = 0

    for i, entry in enumerate(entries):
        # Hash des Eintrags prüfen
        expected_hash = _compute_hash(entry)
        if entry.get("hash") != expected_hash:
            tampered.append({
                "index": i,
                "timestamp": entry.get("timestamp"),
                "reason": "Hash stimmt nicht mit Inhalt überein",
            })
            continue

        # Verkettung prüfen
        expected_prev = genesis_hash if i == 0 else entries[i - 1].get("hash")
        if entry.get("prev_hash") != expected_prev:
            tampered.append({
                "index": i,
                "timestamp": entry.get("timestamp"),
                "reason": "Verkettung unterbrochen (prev_hash falsch)",
            })
            continue

        valid_count += 1

    status = "intact" if not tampered else "tampered"
    message = (
        f"Hash-Kette intakt — {valid_count} Einträge verifiziert"
        if not tampered
        else f"MANIPULATION ERKANNT — {len(tampered)} von {len(entries)} Einträgen betroffen"
    )

    return {
        "agent_id": agent_id,
        "status": status,
        "message": message,
        "total_entries": len(entries),
        "valid_entries": valid_count,
        "tampered_entries": tampered,
    }


def get_all_agent_ids() -> list[str]:
    """Gibt alle Agent-IDs zurück, die Log-Dateien haben."""
    if not AUDIT_DIR.exists():
        return []

    ids = []
    for f in AUDIT_DIR.glob("*.jsonl"):
        ids.append(f.stem)
    return sorted(ids)


def search_all_events(
    query: str,
    event_type: str | None = None,
    agent_id: str | None = None,
) -> list[dict]:
    """
    Durchsucht alle Audit-Events nach einem Suchbegriff.

    Filtert optional nach event_type und agent_id.
    """
    agent_ids = [agent_id] if agent_id else get_all_agent_ids()
    query_lower = query.lower()
    results = []

    for aid in agent_ids:
        entries = read_all_entries(aid)
        for entry in entries:
            # Event-Type Filter
            if event_type and entry.get("event_type") != event_type:
                continue

            # Textsuche über alle relevanten Felder
            searchable = " ".join([
                str(entry.get("action", "")),
                str(entry.get("details", "")),
                str(entry.get("outcome", "")),
                str(entry.get("event_type", "")),
            ]).lower()

            if query_lower in searchable:
                results.append(entry)

    # Neueste zuerst
    results.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return results[:100]  # Max 100 Ergebnisse


def compute_statistics(agent_id: str | None = None) -> dict:
    """
    Berechnet Audit-Statistiken.

    Wenn agent_id angegeben, nur für diesen Agent.
    Sonst über alle Agents.
    """
    agent_ids = [agent_id] if agent_id else get_all_agent_ids()

    total_events = 0
    events_by_type: dict[str, int] = {}
    events_by_day: dict[str, int] = {}
    actions: dict[str, int] = {}
    outcomes: dict[str, int] = {}
    agents_seen: set[str] = set()

    for aid in agent_ids:
        entries = read_all_entries(aid)
        for entry in entries:
            total_events += 1
            agents_seen.add(entry.get("agent_id", aid))

            # Nach Event-Type
            et = entry.get("event_type", "unknown")
            events_by_type[et] = events_by_type.get(et, 0) + 1

            # Nach Tag
            ts = entry.get("timestamp", "")
            day = ts[:10] if len(ts) >= 10 else "unknown"
            events_by_day[day] = events_by_day.get(day, 0) + 1

            # Häufigste Aktionen
            act = entry.get("action", "unknown")
            actions[act] = actions.get(act, 0) + 1

            # Outcomes
            out = entry.get("outcome", "unknown")
            outcomes[out] = outcomes.get(out, 0) + 1

    # Top-Aktionen sortiert
    top_actions = sorted(actions.items(), key=lambda x: x[1], reverse=True)[:10]

    # Fehlerrate berechnen
    error_outcomes = sum(
        v for k, v in outcomes.items()
        if any(word in k.lower() for word in ["error", "fail", "fehler"])
    )
    error_rate = (error_outcomes / total_events * 100) if total_events > 0 else 0

    return {
        "total_events": total_events,
        "total_agents": len(agents_seen),
        "events_by_type": events_by_type,
        "events_by_day": dict(sorted(events_by_day.items(), reverse=True)[:30]),
        "top_actions": [{"action": a, "count": c} for a, c in top_actions],
        "error_rate": round(error_rate, 2),
        "outcomes": outcomes,
    }
