"""
Audit-Trail MCP Tools.

Stellt Tools für manipulationssichere Audit-Protokollierung bereit:
- Events loggen mit Hash-Verkettung
- Audit-Trail abrufen
- Integritätsprüfung
- Compliance-Reports exportieren
- Events durchsuchen
- Statistiken abrufen
"""

import json
from mcp.server.fastmcp import FastMCP

from src.tools.chain_store import (
    append_event,
    read_trail,
    verify_chain,
    read_all_entries,
    search_all_events,
    compute_statistics,
)


def register_tools(mcp: FastMCP) -> None:
    """Registriert alle Audit-Tools beim MCP-Server."""

    @mcp.tool()
    def log_event(
        agent_id: str,
        event_type: str,
        action: str,
        details: str,
        outcome: str,
    ) -> str:
        """Loggt ein unveränderliches Audit-Event mit Zeitstempel und Hash-Verkettung.

        Jeder Eintrag enthält den Hash des vorherigen Eintrags zur Manipulationserkennung.
        Daten werden in ~/.agent-audit-trail/ gespeichert.

        Args:
            agent_id: Eindeutige ID des AI-Agents (z.B. "agent-gpt4-prod-01")
            event_type: Kategorie des Events (z.B. "decision", "action", "error", "access", "data_processing")
            action: Was der Agent getan hat (z.B. "api_call", "data_query", "user_response")
            details: Detaillierte Beschreibung der Aktion
            outcome: Ergebnis der Aktion (z.B. "success", "error: timeout", "blocked by policy")
        """
        entry = append_event(agent_id, event_type, action, details, outcome)
        return json.dumps({
            "status": "logged",
            "hash": entry["hash"],
            "timestamp": entry["timestamp"],
            "prev_hash": entry["prev_hash"][:16] + "...",
            "message": f"Event für Agent '{agent_id}' protokolliert",
        }, indent=2, ensure_ascii=False)

    @mcp.tool()
    def get_trail(agent_id: str, limit: int = 50) -> str:
        """Ruft den Audit-Trail eines Agents ab.

        Gibt die letzten N Einträge zurück (neueste zuerst),
        jeweils mit Zeitstempel, Aktion, Hash und Verkettung.

        Args:
            agent_id: ID des Agents
            limit: Maximale Anzahl Einträge (Standard: 50)
        """
        entries = read_trail(agent_id, limit=limit)

        if not entries:
            return json.dumps({
                "agent_id": agent_id,
                "message": "Kein Audit-Trail vorhanden",
                "entries": [],
            }, indent=2, ensure_ascii=False)

        return json.dumps({
            "agent_id": agent_id,
            "total_returned": len(entries),
            "entries": entries,
        }, indent=2, ensure_ascii=False)

    @mcp.tool()
    def verify_integrity(agent_id: str) -> str:
        """Prüft die Integrität der Hash-Kette eines Agents.

        Verifiziert, dass:
        1. Jeder Hash korrekt berechnet wurde
        2. Die Verkettung (prev_hash) nicht unterbrochen ist
        3. Keine Einträge manipuliert oder gelöscht wurden

        Gibt detaillierten Integritätsbericht zurück.

        Args:
            agent_id: ID des zu prüfenden Agents
        """
        result = verify_chain(agent_id)
        return json.dumps(result, indent=2, ensure_ascii=False)

    @mcp.tool()
    def export_report(agent_id: str, format: str = "json") -> str:
        """Exportiert den Audit-Trail als Compliance-Report.

        Erstellt einen vollständigen Bericht mit Integritätsprüfung,
        geeignet für EU AI Act Compliance-Nachweise.

        Args:
            agent_id: ID des Agents
            format: Ausgabeformat — "json" oder "text" (menschenlesbar)
        """
        entries = read_all_entries(agent_id)
        integrity = verify_chain(agent_id)
        stats = compute_statistics(agent_id)

        if format == "text":
            # Menschenlesbarer Report
            lines = [
                "=" * 60,
                "AUDIT-TRAIL COMPLIANCE REPORT",
                "=" * 60,
                f"Agent-ID:        {agent_id}",
                f"Gesamte Events:  {integrity['total_entries']}",
                f"Integritäts-Status: {integrity['status'].upper()}",
                f"Gültige Einträge:   {integrity['valid_entries']}",
                f"Fehlerrate:         {stats['error_rate']}%",
                "-" * 60,
            ]

            if integrity["tampered_entries"]:
                lines.append("WARNUNG: Manipulierte Einträge erkannt!")
                for t in integrity["tampered_entries"]:
                    lines.append(f"  Index {t['index']}: {t['reason']}")
                lines.append("-" * 60)

            lines.append("\nCHRONOLOGISCHER AUDIT-TRAIL:")
            lines.append("-" * 60)

            for i, entry in enumerate(entries):
                lines.append(f"\n[{i+1}] {entry.get('timestamp', 'N/A')}")
                lines.append(f"    Typ:     {entry.get('event_type', 'N/A')}")
                lines.append(f"    Aktion:  {entry.get('action', 'N/A')}")
                lines.append(f"    Details: {entry.get('details', 'N/A')}")
                lines.append(f"    Ergebnis: {entry.get('outcome', 'N/A')}")
                lines.append(f"    Hash:    {entry.get('hash', 'N/A')[:32]}...")

            lines.extend([
                "\n" + "=" * 60,
                "EU AI Act Artikel 12 — Aufzeichnungspflichten",
                "Dieser Report dokumentiert alle Aktionen des AI-Systems.",
                "=" * 60,
            ])

            return "\n".join(lines)

        # JSON-Report
        report = {
            "report_type": "EU AI Act Compliance Audit Trail",
            "agent_id": agent_id,
            "integrity": integrity,
            "statistics": stats,
            "entries": entries,
        }
        return json.dumps(report, indent=2, ensure_ascii=False)

    @mcp.tool()
    def search_events(
        query: str,
        event_type: str | None = None,
        agent_id: str | None = None,
    ) -> str:
        """Durchsucht alle Audit-Events nach einem Suchbegriff.

        Sucht in Aktionen, Details, Outcomes und Event-Types.
        Kann optional nach Event-Type und Agent-ID gefiltert werden.

        Args:
            query: Suchbegriff (durchsucht action, details, outcome)
            event_type: Optional — nur Events dieses Typs (z.B. "error", "decision")
            agent_id: Optional — nur Events dieses Agents
        """
        results = search_all_events(query, event_type=event_type, agent_id=agent_id)

        return json.dumps({
            "query": query,
            "filters": {
                "event_type": event_type,
                "agent_id": agent_id,
            },
            "total_results": len(results),
            "results": results,
        }, indent=2, ensure_ascii=False)

    @mcp.tool()
    def get_statistics(agent_id: str | None = None) -> str:
        """Liefert Audit-Statistiken (Events pro Tag, häufigste Aktionen, Fehlerrate).

        Ohne agent_id werden Statistiken über alle Agents aggregiert.

        Args:
            agent_id: Optional — nur Statistiken für diesen Agent
        """
        stats = compute_statistics(agent_id)
        return json.dumps(stats, indent=2, ensure_ascii=False)
