"""
Agent Audit Trail MCP Server.

Manipulationssichere Audit-Protokollierung für AI-Agents.
Hash-verkettetes Event-Log mit Integritätsprüfung —
für EU AI Act Compliance (ab August 2026).
"""

from mcp.server.fastmcp import FastMCP

from src.tools.audit import register_tools

mcp = FastMCP(
    "Agent Audit Trail",
    instructions=(
        "Manipulationssichere Audit-Protokollierung für AI-Agents. "
        "Loggt alle Agent-Aktionen mit SHA-256 Hash-Verkettung, "
        "ermöglicht Integritätsprüfung und Compliance-Reports. "
        "Erfüllt EU AI Act Artikel 12 Aufzeichnungspflichten (ab August 2026). "
        "Nutze log_event() für jede relevante Agent-Aktion, "
        "verify_integrity() zur Manipulationsprüfung, "
        "und export_report() für Compliance-Nachweise."
    ),
)

# Audit-Tools registrieren
register_tools(mcp)


def main():
    """Startet den MCP-Server über stdio-Transport."""
    mcp.run()


if __name__ == "__main__":
    main()
