"""Pre-built econometric models."""
