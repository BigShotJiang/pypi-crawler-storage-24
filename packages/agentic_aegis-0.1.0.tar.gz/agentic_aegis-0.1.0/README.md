# AgenticAegis Python SDK

Streaming validation shield for AI agents -- runtime gate checks and output validation.

## Install

```bash
pip install agentic-aegis
```

## Usage

```python
from agentic_aegis import AegisEngine

ae = AegisEngine("project.aegis")
ae.create_gate("pii-filter", rule="no-personal-data")
ae.validate_stream("User output text here")
```

Requires the `aegis` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/aegis | bash
```
