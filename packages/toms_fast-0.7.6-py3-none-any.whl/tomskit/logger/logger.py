import atexit
import logging
import queue
import time
from abc import ABC, abstractmethod
from contextvars import ContextVar
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Literal, Optional

from logging.handlers import QueueHandler, QueueListener
from concurrent_log_handler import ConcurrentRotatingFileHandler

from tomskit.logger.config import LoggerConfig

AppType = Literal["fastapi", "celery", "alembic"]
NOISY_LOGGERS = ("httpx", "httpcore", "urllib3", "asyncio", "boto3", "botocore")


@dataclass(frozen=True)
class ContextField:
    """
    Definition of a single log context field.
    
    Attributes:
        name: Field name, will be used as LogRecord attribute name
        var: ContextVar instance for storing values in coroutines
        default: Default value when ContextVar is not set
    """
    name: str
    var: Optional[ContextVar] = None
    default: Any = ""


class ContextRegistry:
    """
    Manages log context fields and injects ContextVar values into LogRecord.
    
    This is the core of the logging system, maintaining all context fields
    that need to be injected and providing a unified injection interface.
    """

    def __init__(self, fields: Iterable[ContextField]):
        self._fields = list(fields)

    def inject(self, record: logging.LogRecord) -> None:
        """
        Inject current ContextVar values into LogRecord.
        
        For each field:
        1. If field has no ContextVar, use default value
        2. If field has ContextVar, try to get its value
        3. If retrieval fails (LookupError), use default value
        4. Set value as LogRecord attribute
        """
        for field in self._fields:
            if field.var is None:
                value = field.default
            else:
                try:
                    value = field.var.get()
                except LookupError:
                    value = field.default
            setattr(record, field.name, value if value is not None else field.default)

    def defaults(self) -> Dict[str, Any]:
        """Return default values for all fields as a dictionary."""
        return {f.name: f.default for f in self._fields}


class ContextFilter(logging.Filter):
    """
    Logging filter that injects context information into log records.
    
    This filter calls registry.inject() when a log record is processed,
    adding ContextVar values to the LogRecord for use in formatting.
    """

    def __init__(self, registry: ContextRegistry):
        super().__init__()
        self.registry = registry

    def filter(self, record: logging.LogRecord) -> bool:
        """Inject context information. Always returns True (no filtering)."""
        self.registry.inject(record)
        return True


class SafeFormatter(logging.Formatter):
    """
    Safe log formatter with fallback default values.
    
    If LogRecord is missing attributes required for formatting,
    this formatter uses provided defaults to avoid KeyError or AttributeError.
    This is a defensive programming design serving as a safety net.
    """

    def __init__(
        self,
        fmt: str,
        datefmt: Optional[str] = None,
        defaults: Optional[dict[str, Any]] = None,
        use_utc: bool = False,
    ) -> None:
        super().__init__(fmt, datefmt)
        self._defaults = defaults or {}
        if use_utc:
            self.converter = time.gmtime  # 日志时间戳使用 UTC 时区

    def format(self, record: logging.LogRecord) -> str:
        """Format log record, ensuring all required attributes exist before formatting."""
        for key, default in self._defaults.items():
            if not hasattr(record, key):
                setattr(record, key, default)
        return super().format(record)


def create_concurrent_handler(
    filename: str,
    max_bytes: int,
    backup_count: int,
) -> ConcurrentRotatingFileHandler:
    """
    Create a multiprocess-safe rotating file handler.

    Uses ConcurrentRotatingFileHandler (file lock) to prevent log corruption
    in gunicorn prefork / multiprocess deployments. Rotates by file size.
    Daily rotation is handled by system logrotate (copytruncate).

    Args:
        filename: Log file path
        max_bytes: Max file size before rotation (e.g. 2GB)
        backup_count: Number of backup files to retain (9999 = keep all)

    Returns:
        Configured ConcurrentRotatingFileHandler instance
    """
    return ConcurrentRotatingFileHandler(
        filename=filename,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
        use_gzip=False,
    )


# Backward-compatible alias
create_timed_handler = create_concurrent_handler


def create_error_handler(
    filename: str,
    max_bytes: int,
    backup_count: int,
) -> ConcurrentRotatingFileHandler:
    """
    Create a multiprocess-safe ERROR-only file handler.

    Only records ERROR and above, written to a dedicated error log file
    for quick incident investigation and alerting.
    """
    handler = create_concurrent_handler(filename, max_bytes, backup_count)
    handler.setLevel(logging.ERROR)
    return handler


class ContextAwareQueueHandler(QueueHandler):
    """
    QueueHandler that supports ContextVar.
    
    Since log queues are processed in background threads and ContextVar is
    coroutine-local, we must "solidify" ContextVar values into LogRecord
    attributes before the record is queued (while still in the coroutine),
    otherwise these values will be lost in the background thread.
    
    This class overrides prepare() to inject context before serialization.
    """
    
    def __init__(self, queue: queue.Queue, registry: ContextRegistry):
        super().__init__(queue)
        self.registry = registry
    
    def prepare(self, record: logging.LogRecord) -> logging.LogRecord:
        """
        Prepare log record before queuing.
        
        Critical steps:
        1. Call registry.inject() to inject ContextVar values into record attributes
        2. Call parent's prepare() for serialization
        3. Now LogRecord contains all context info even in background thread
        """
        self.registry.inject(record)
        return super().prepare(record)


class AsyncQueueHandler(logging.Handler):
    """
    Asynchronous queue-based log handler.
    
    Uses in-memory queue + background listener thread to decouple log I/O
    from main thread:
    1. Main thread (or coroutine) quickly puts log records into memory queue
    2. Background thread retrieves logs from queue and writes to file/console
    3. Avoids blocking main thread with disk I/O
    
    Key design:
    - Uses ContextAwareQueueHandler to solidify ContextVar values before queuing
    - Uses class-level instance list + atexit to ensure proper cleanup on exit
    """
    
    _instances: List['AsyncQueueHandler'] = []

    def __init__(
        self,
        registry: ContextRegistry,
        filename: Optional[str] = None,
        error_handler: Optional[logging.Handler] = None,
        fmt: str = "%(message)s",
        datefmt: str = "%Y-%m-%d %H:%M:%S",
        queue_size: int = 8192,
        max_bytes: int = 2 * 1024 * 1024 * 1024,
        backup_count: int = 9999,
        use_utc: bool = False,
    ) -> None:
        super().__init__()
        self.registry = registry
        self._queue: queue.Queue = queue.Queue(maxsize=queue_size)
        self._closed = False

        # Automatically get defaults from registry (single source of truth)
        defaults = self.registry.defaults()
        formatter = SafeFormatter(fmt, datefmt, defaults, use_utc=use_utc)

        # Create actual handlers (console and file)
        handlers: List[logging.Handler] = []

        console_h = logging.StreamHandler()
        console_h.setFormatter(formatter)
        handlers.append(console_h)

        if filename:
            file_h = create_concurrent_handler(filename, max_bytes, backup_count)
            file_h.setFormatter(formatter)
            handlers.append(file_h)

        # Shared error handler passed in from LoggingBase — not created here
        if error_handler:
            handlers.append(error_handler)

        # Use ContextAwareQueueHandler to ensure context is solidified before queuing
        self._q_handler = ContextAwareQueueHandler(self._queue, self.registry)
        
        # Create background listener to dispatch logs from queue to actual handlers
        self._listener = QueueListener(
            self._queue, *handlers, respect_handler_level=True
        )
        self._listener.start()
        
        # Register instance for atexit cleanup
        AsyncQueueHandler._instances.append(self)

    def emit(self, record: logging.LogRecord) -> None:
        """
        Send log record to queue.
        
        Called in main thread/coroutine, should be fast:
        1. Check if handler is closed
        2. Quickly put record into memory queue
        3. Use standard error handling if something goes wrong
        """
        if self._closed:
            return
        try:
            self._q_handler.emit(record)
        except Exception:
            self.handleError(record)
    
    def close(self) -> None:
        """
        Close handler and stop background listener.
        
        This method will:
        1. Mark as closed to prevent new logs
        2. Stop background listener (waits for queue to drain)
        3. Call parent's close() method
        """
        if self._closed:
            return
        self._closed = True
        if self._listener:
            self._listener.stop()
        super().close()
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} (queue_size={self._queue.maxsize})>"

    @classmethod
    def close_all(cls) -> None:
        """
        Class method to cleanup all AsyncQueueHandler instances.
        
        Called by atexit to ensure on program exit:
        1. All log queues are drained
        2. All background listeners are properly stopped
        3. All file handles are closed
        
        Even if one handler cleanup fails, others are not affected.
        """
        for instance in cls._instances:
            try:
                instance.close()
            except Exception as e:
                import sys
                print(f"Error closing AsyncQueueHandler: {e}", file=sys.stderr)
        cls._instances.clear()


# Register atexit cleanup function when module loads
# Ensures all AsyncQueueHandler instances are properly cleaned up
atexit.register(AsyncQueueHandler.close_all)


def configure_third_party(level: str) -> None:
    """
    Configure log level for third-party libraries to reduce noise.
    
    Some libraries (like httpx, boto3) produce excessive DEBUG/INFO logs.
    This function raises their log level to WARNING to reduce noise.
    """
    lvl = getattr(logging, level.upper(), logging.WARNING)
    for name in NOISY_LOGGERS:
        logging.getLogger(name).setLevel(lvl)


class LoggingBase(ABC):
    """
    Abstract base class for logging configuration.
    
    Provides common logging setup logic. Specific application types
    (FastAPI, Celery, Alembic) inherit this class and implement
    _setup_loggers() to customize their logging configuration.
    """

    def __init__(
        self,
        config: LoggerConfig,
        context_registry: ContextRegistry,
        fmt: Optional[str] = None,
    ):
        self.config = config
        self.registry = context_registry
        self.fmt = fmt
        self._shared_error_handler: Optional[logging.Handler] = None
        Path(config.LOG_DIR).mkdir(parents=True, exist_ok=True)

    def _create_shared_error_handler(self) -> logging.Handler:
        """
        Create one shared ERROR-only handler for all loggers in this setup.

        All loggers (root, app, uvicorn, celery, tasks …) reuse this single
        instance so there is only one file handle and one lock on error.log,
        eliminating lock contention under high concurrency.

        In sync mode a ContextFilter is attached here so context fields are
        injected when the record is emitted.  In async mode the filter is
        omitted because ContextAwareQueueHandler.prepare() already injects
        context before the record enters the queue.
        """
        error_filepath = f"{self.config.LOG_DIR}/{self.config.LOG_ERROR_NAME}.log"
        error_fmt = SafeFormatter(
            self.config.LOG_FORMAT,
            self.config.LOG_DATE_FORMAT,
            self.registry.defaults(),
            use_utc=self.config.LOG_USE_UTC,
        )
        handler = create_error_handler(
            error_filepath,
            self.config.LOG_MAX_BYTES,
            self.config.LOG_BACKUP_COUNT,
        )
        handler.setFormatter(error_fmt)
        # Sync mode: inject context at emit time via filter.
        # Async mode: context already injected by ContextAwareQueueHandler.prepare(),
        # adding the filter here would overwrite correct values with empty thread-local ones.
        if not self.config.LOG_ASYNC_ENABLED:
            handler.addFilter(ContextFilter(self.registry))
        return handler

    def setup(self) -> None:
        """
        Setup logging system.

        Entry point for logging configuration:
        1. Configure root logger level and filter
        2. Clear existing handlers (avoid duplicates)
        3. Create shared error handler (single instance for all loggers)
        4. Call subclass's _setup_loggers() to configure specific loggers
        5. Configure third-party library log levels
        """
        root = logging.getLogger()
        root.setLevel(self.config.LOG_LEVEL)
        root.handlers.clear()
        # Add context filter to root logger
        # All loggers with propagate=True will use this filter
        root.addFilter(ContextFilter(self.registry))
        # Create once — _file_logger() will reuse this instance for every logger
        self._shared_error_handler = self._create_shared_error_handler()
        self._setup_loggers()
        configure_third_party(self.config.LOG_THIRD_PARTY_LEVEL)

    @abstractmethod
    def _setup_loggers(self) -> None:
        """Setup specific loggers. Implemented by subclasses."""
        ...

    def _file_logger(
        self,
        name: str,
        filename: str,
        fmt: str,
        level: str,
    ) -> logging.Logger:
        """
        Create and configure a file logger.
        
        Core logging configuration method. Configures for specified logger:
        1. Log level
        2. Propagation (only non-root loggers set propagate=False)
        3. Handler (async or sync)
        4. Formatter
        5. Filter (only sync mode needs filter on handler)
        
        Args:
            name: Logger name, empty string means root logger
            filename: Log filename (without path)
            fmt: Log format string
            level: Log level
            
        Returns:
            Configured Logger instance
        """
        logger = logging.getLogger(name)
        logger.handlers.clear()
        logger.setLevel(level)
        
        # Only set propagate=False for non-root loggers
        # Prevents duplicate logging (handled by own handler, not propagating to root)
        if name:
            logger.propagate = False

        filepath = f"{self.config.LOG_DIR}/{filename}.log"

        # Create formatter (for sync mode)
        # Automatically gets defaults from registry
        fmt_obj = SafeFormatter(
            fmt,
            self.config.LOG_DATE_FORMAT,
            self.registry.defaults(),
            use_utc=self.config.LOG_USE_UTC,
        )

        if self.config.LOG_ASYNC_ENABLED:
            # Async mode: AsyncQueueHandler internally creates console + file handlers.
            # Shared error handler is passed in — not created per logger.
            # ContextAwareQueueHandler injects context in prepare(), no extra filter needed.
            handler = AsyncQueueHandler(
                registry=self.registry,
                filename=filepath,
                error_handler=self._shared_error_handler,
                fmt=fmt,
                datefmt=self.config.LOG_DATE_FORMAT,
                queue_size=self.config.LOG_ASYNC_QUEUE_SIZE,
                max_bytes=self.config.LOG_MAX_BYTES,
                backup_count=self.config.LOG_BACKUP_COUNT,
                use_utc=self.config.LOG_USE_UTC,
            )
            logger.addHandler(handler)
        else:
            # Sync mode: file handler + shared error handler + console handler.
            # Console handler is required so logs appear in Docker/container stdout.
            # Shared error handler is reused across all loggers — only one lock on error.log.
            ctx_filter = ContextFilter(self.registry)

            file_handler = create_concurrent_handler(
                filename=filepath,
                max_bytes=self.config.LOG_MAX_BYTES,
                backup_count=self.config.LOG_BACKUP_COUNT,
            )
            file_handler.setFormatter(fmt_obj)
            file_handler.addFilter(ctx_filter)
            logger.addHandler(file_handler)

            # Shared instance — filter already attached in _create_shared_error_handler()
            # logger.addHandler(self._shared_error_handler)
            if self._shared_error_handler is not None:
                logger.addHandler(self._shared_error_handler)

            console_handler = logging.StreamHandler()
            console_handler.setFormatter(fmt_obj)
            console_handler.addFilter(ctx_filter)
            logger.addHandler(console_handler)

        return logger


class FastAPILogging(LoggingBase):
    """
    Logging configuration for FastAPI applications.
    
    Configures the following loggers:
    1. Root logger: Application logs
    2. uvicorn logger: Access logs (HTTP request logs)
    3. sqlalchemy logger (optional): SQL query logs
    """

    def _setup_loggers(self) -> None:
        loggers = [
            ("", self.config.LOG_NAME, self.fmt or self.config.LOG_FORMAT, self.config.LOG_LEVEL),
            ("app", self.config.LOG_NAME, self.config.LOG_APP_FORMAT, self.config.LOG_LEVEL),
            ("app.middleware", self.config.LOG_NAME, self.config.LOG_FORMAT, self.config.LOG_LEVEL),
            ("uvicorn", self.config.LOG_NAME, self.config.LOG_FORMAT, self.config.LOG_LEVEL),
            ("uvicorn.access", self.config.LOG_ACCESS_NAME, self.fmt or self.config.LOG_ACCESS_FORMAT, "INFO"),
        ]
        
        if self.config.LOG_SQL_ENABLED:
            loggers.append((
                "sqlalchemy",
                self.config.LOG_SQL_NAME,
                self.fmt or self.config.LOG_FORMAT,
                self.config.LOG_SQL_LEVEL,
            ))
        
        for name, filename, fmt, level in loggers:
            self._file_logger(name, filename, fmt, level)


class CeleryLogging(LoggingBase):
    """
    Logging configuration for Celery applications.
    
    Configures the following loggers:
    1. Root logger: General logs
    2. celery logger: Celery framework logs
    3. tasks logger: Task function logs (independent format)
    4. schedule logger: Scheduled task logs (independent format)
    5. sqlalchemy logger (optional): SQL query logs
    
    Note: tasks and schedule use independent log formats (can include only task_id).
    """

    def _setup_loggers(self) -> None:
        default_fmt = self.fmt or self.config.LOG_CELERY_FORMAT
        
        loggers = [
            ("", self.config.LOG_CELERY_NAME, default_fmt, self.config.LOG_CELERY_LEVEL),
            ("celery", self.config.LOG_CELERY_NAME, default_fmt, self.config.LOG_CELERY_LEVEL),
            ("tasks", self.config.LOG_CELERY_NAME, self.config.LOG_CELERY_TASKS_FORMAT, self.config.LOG_CELERY_LEVEL),
            ("schedule", self.config.LOG_CELERY_NAME, self.config.LOG_CELERY_SCHEDULE_FORMAT, self.config.LOG_CELERY_LEVEL),
        ]
        
        if self.config.LOG_SQL_ENABLED:
            loggers.append((
                "sqlalchemy",
                self.config.LOG_SQL_NAME,
                default_fmt,
                self.config.LOG_SQL_LEVEL,
            ))
        
        for name, filename, fmt, level in loggers:
            self._file_logger(name, filename, fmt, level)


class AlembicLogging(LoggingBase):
    """
    Logging configuration for Alembic database migration tool.
    
    Only configures root logger for recording migration operations.
    """

    def _setup_loggers(self) -> None:
        self._file_logger(
            "",
            "alembic",
            self.fmt or self.config.LOG_FORMAT,
            self.config.LOG_LEVEL,
        )


def configure_logging(
    settings: LoggerConfig,
    context_registry: Optional[Iterable[ContextField]] = None,
    app_type: AppType = "fastapi",
) -> None:
    """
    Entry function for configuring the logging system.
    
    Selects appropriate logging configuration class based on application type:
    - fastapi: FastAPILogging
    - celery: CeleryLogging
    - alembic: AlembicLogging
    
    Usage example:
    ```python
    from contextvars import ContextVar
    from tomskit.logger import configure_logging, ContextField
    from tomskit.logger.config import LoggerConfig
    
    # Define context variables
    trace_id_var = ContextVar("trace_id", default="")
    user_id_var = ContextVar("user_id", default="")
    
    # Create configuration
    config = LoggerConfig(
        LOG_ASYNC_ENABLED=True,
        LOG_DIR="logs",
        LOG_LEVEL="INFO",
    )
    
    # Configure logging system
    configure_logging(
        settings=config,
        context_registry=[
            ContextField(name="trace_id", var=trace_id_var, default="N/A"),
            ContextField(name="user_id", var=user_id_var, default="anonymous"),
        ],
        app_type="fastapi",
    )
    
    # Use in code
    trace_id_var.set("abc-123")
    user_id_var.set("user-456")
    
    import logging
    logger = logging.getLogger(__name__)
    logger.info("User logged in")  # Log automatically includes trace_id and user_id
    ```
    
    Args:
        settings: Logger configuration object
        context_registry: List of context fields defining context info to inject
        app_type: Application type, determines which logging config class to use
    """
    registry = (
        ContextRegistry(context_registry)
        if context_registry is not None
        else ContextRegistry([])
    )
    
    if app_type == "celery":
        CeleryLogging(settings, registry).setup()
    elif app_type == "alembic":
        AlembicLogging(settings, registry).setup()
    else:
        FastAPILogging(settings, registry).setup()
