import asyncio
import logging
from typing import Any, Awaitable, Callable, Optional

from tomskit.sqlalchemy.database import db

logger = logging.getLogger(__name__)

TaskTarget = Callable[..., Awaitable[Any]]

_SENTINEL = object()


class AsyncTaskManager:
    """
    异步任务管理器，支持批量/单次任务并发执行，可选 db 会话。

    - 结果按任务添加顺序返回
    - 任务之间互相独立，一个失败不影响其他任务执行
    - db 会话通过 db.scope() 管理，支持嵌套，不污染外层 ContextVar
    """
    def __init__(
        self,
        task_name: str = __name__,
        use_db: bool = False,
    ):
        self.task_name = task_name
        self.use_db = use_db
        self._tasks: list[Callable[[], Awaitable[Any]]] = []
        self.results: list[Any] = []
        self.exceptions: list[Exception] = []

    def add_task(
        self,
        target: TaskTarget,
        args: tuple = (),
        kwargs: Optional[dict[str, Any]] = None,
    ) -> None:
        """添加一个异步任务"""
        if kwargs is None:
            kwargs = {}
        index = len(self._tasks)

        async def wrapper() -> Any:
            try:
                if self.use_db:
                    async with db.scope():
                        result = await target(*args, **kwargs)
                else:
                    result = await target(*args, **kwargs)
                self.results[index] = result
            except Exception as e:
                func_name = getattr(target, '__name__', repr(target))
                logger.exception(f"[{self.task_name}] Error in {func_name} (task {index})")
                self.results[index] = e
                raise

        self._tasks.append(wrapper)

    def add_tasks(
        self,
        targets: list[tuple[TaskTarget, tuple] | tuple[TaskTarget, tuple, Optional[dict[str, Any]]]],
    ) -> None:
        """批量添加任务: [(func, args), ...] 或 [(func, args, kwargs), ...]"""
        for item in targets:
            if len(item) == 2:
                target, args = item  # type: ignore
                self.add_task(target, args=args)
            else:
                target, args, kwargs = item  # type: ignore
                self.add_task(target, args=args, kwargs=kwargs)

    async def run_all(self) -> list[Any]:
        """
        并发执行所有任务。

        任务之间互相独立，一个任务失败不会取消其他任务。
        结果按添加顺序存储在 self.results 中。
        异常收集在 self.exceptions 中。

        Returns:
            按添加顺序排列的结果列表（失败的任务位置为 _SENTINEL）
        """
        self.results = [_SENTINEL] * len(self._tasks)
        self.exceptions.clear()

        outcomes = await asyncio.gather(
            *(wrapper() for wrapper in self._tasks),
            return_exceptions=True,
        )

        for outcome in outcomes:
            if isinstance(outcome, BaseException) and not isinstance(outcome, asyncio.CancelledError):
                self.exceptions.append(outcome if isinstance(outcome, Exception) else Exception(str(outcome)))

        self._tasks.clear()
        return self.results

    async def run_task(
        self,
        target: TaskTarget,
        args: tuple = (),
        kwargs: Optional[dict[str, Any]] = None,
    ) -> Any:
        """快捷单任务调用，失败时直接抛出异常"""
        self._tasks.clear()
        self.add_task(target, args=args, kwargs=kwargs)
        await self.run_all()
        if self.exceptions:
            raise self.exceptions[0]
        if not self.results or self.results[0] is _SENTINEL:
            return None
        return self.results[0]
