"""协程警告捕获工具"""

import sys
import warnings
import logging

logger = logging.getLogger(__name__)

_COROUTINE_NEVER_AWAITED = "was never awaited"


def enable_unawaited_warning(tracking_depth: int = 5) -> None:
    """
    捕获未被 await 的协程产生的 RuntimeWarning，
    以 logger.critical 记录文件名和行号。

    Args:
        tracking_depth: 协程 origin tracking 深度，默认 5。
                        值越大追踪信息越详细，但性能开销略增。
    """
    _orig_showwarning = warnings.showwarning

    def _warning_handler(message, category, filename, lineno, file=None, line=None):
        if issubclass(category, RuntimeWarning) and _COROUTINE_NEVER_AWAITED in str(message):
            logger.critical(f"(File: {filename}, Line: {lineno}) {message}")
        else:
            _orig_showwarning(message, category, filename, lineno, file, line)

    sys.set_coroutine_origin_tracking_depth(tracking_depth)
    warnings.simplefilter("always", RuntimeWarning)
    warnings.showwarning = _warning_handler
