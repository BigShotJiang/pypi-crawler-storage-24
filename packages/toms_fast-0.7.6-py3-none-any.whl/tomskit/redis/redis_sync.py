"""
Redis 同步客户端模块

支持单机、Sentinel、Cluster 三种模式。
兼容 dict 和 RedisConfig 两种配置传入方式。
"""
from typing import Any, Union

from redis import Redis, Connection, ConnectionPool, Sentinel, SSLConnection, RedisCluster
from redis.cluster import ClusterNode

from tomskit.redis.config import RedisConfig


def _get(config: Any, key: str, default: Any = None) -> Any:
    """Unified config accessor: supports both RedisConfig (attr) and dict."""
    if isinstance(config, dict):
        return config.get(key, default)
    return getattr(config, key, default)


def redis_sync_client(config: RedisConfig | dict) -> Redis | None:
    """
    Create a synchronous Redis client.

    Args:
        config: RedisConfig instance (recommended) or legacy dict.

    Returns:
        Redis client instance, or None on failure.
    """
    redis: Redis | None = None

    connection_class: type[Union[Connection, SSLConnection]] = Connection
    if _get(config, "REDIS_USE_SSL"):
        connection_class = SSLConnection

    redis_params = {
        "username": _get(config, "REDIS_USERNAME"),
        "password": _get(config, "REDIS_PASSWORD"),
        "db": _get(config, "REDIS_DB"),
        "encoding": "utf-8",
        "encoding_errors": "strict",
        "decode_responses": True,
        "max_connections": 1,
    }

    if _get(config, "REDIS_USE_SENTINEL"):
        sentinel_hosts = [
            (node.split(":")[0], int(node.split(":")[1]))
            for node in _get(config, "REDIS_SENTINELS").split(",")
        ]
        sentinel = Sentinel(
            sentinel_hosts,
            sentinel_kwargs={
                "socket_timeout": _get(config, "REDIS_SENTINEL_SOCKET_TIMEOUT", 0.1),
                "username": _get(config, "REDIS_SENTINEL_USERNAME"),
                "password": _get(config, "REDIS_SENTINEL_PASSWORD"),
            },
        )
        redis = sentinel.master_for(
            _get(config, "REDIS_SENTINEL_SERVICE_NAME"), **redis_params
        )
    elif _get(config, "REDIS_USE_CLUSTERS") or _get(config, "REDIS_USE_CLUSTER"):
        nodes = [
            ClusterNode(host=node.split(":")[0], port=int(node.split(":")[1]))
            for node in _get(config, "REDIS_CLUSTERS").split(",")
        ]
        # RedisCluster 不支持 db 和 max_connections，单独构造参数
        cluster_params: dict[str, Any] = {
            "username": _get(config, "REDIS_USERNAME"),
            "password": _get(config, "REDIS_CLUSTERS_PASSWORD"),
            "encoding": "utf-8",
            "encoding_errors": "strict",
            "decode_responses": True,
        }
        redis = RedisCluster(  # type: ignore
            startup_nodes=nodes,
            **cluster_params,
        )
    else:
        redis_params.update({
            "host": _get(config, "REDIS_HOST"),
            "port": _get(config, "REDIS_PORT"),
            "max_connections": 1,
            "connection_class": connection_class,
        })
        pool = ConnectionPool(**redis_params)
        redis = Redis(connection_pool=pool)

    return redis
