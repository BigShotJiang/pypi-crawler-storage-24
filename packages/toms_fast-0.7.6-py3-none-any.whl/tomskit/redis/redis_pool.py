"""
Redis 扩展模块
"""
import ssl
from typing import Any, Union, Optional, TypeVar, Generic
from redis.asyncio import Connection, ConnectionPool, Redis, Sentinel, SSLConnection, RedisCluster
from redis.asyncio.cluster import ClusterNode
from tomskit.redis.config import RedisConfig

T = TypeVar("T", bound=Redis)


def _get_redis_ssl_context(settings: RedisConfig) -> ssl.SSLContext | None:
    """Build an ``ssl.SSLContext`` from *settings*, or return ``None`` when SSL is disabled."""
    if not settings.REDIS_USE_SSL:
        return None

    cert_reqs_map = {
        "CERT_NONE": ssl.CERT_NONE,
        "CERT_OPTIONAL": ssl.CERT_OPTIONAL,
        "CERT_REQUIRED": ssl.CERT_REQUIRED,
    }
    cert_reqs = cert_reqs_map.get(settings.REDIS_SSL_CERT_REQS, ssl.CERT_NONE)

    ctx = ssl.create_default_context(cafile=settings.REDIS_SSL_CA_CERTS)
    ctx.check_hostname = cert_reqs == ssl.CERT_REQUIRED
    ctx.verify_mode = cert_reqs

    # 客户端双向 mTLS 证书
    if settings.REDIS_SSL_CERTFILE and settings.REDIS_SSL_KEYFILE:
        ctx.load_cert_chain(certfile=settings.REDIS_SSL_CERTFILE, keyfile=settings.REDIS_SSL_KEYFILE)

    return ctx


def _get_redis_ssl_params(settings: RedisConfig) -> dict[str, Any]:
    """Return flat SSL keyword arguments consumed by ``redis-py`` connection classes."""
    if not settings.REDIS_USE_SSL:
        return {}

    cert_reqs_map = {
        "CERT_NONE": ssl.CERT_NONE,
        "CERT_OPTIONAL": ssl.CERT_OPTIONAL,
        "CERT_REQUIRED": ssl.CERT_REQUIRED,
    }

    return {
        "ssl": True,
        "ssl_cert_reqs": cert_reqs_map.get(settings.REDIS_SSL_CERT_REQS, ssl.CERT_NONE),
        "ssl_ca_certs": settings.REDIS_SSL_CA_CERTS,
        "ssl_certfile": settings.REDIS_SSL_CERTFILE,
        "ssl_keyfile": settings.REDIS_SSL_KEYFILE,
    }


class RedisClientWrapper(Generic[T]):
    def __init__(self) -> None:
        self._client: T | None = None
    
    def __getattr__(self, item) -> Any:
        if self._client is None:
            raise RuntimeError("Redis client is not initialized. Call initialize first.")
        return getattr(self._client, item)

    def set_client(self, client: T) -> None:
        if self._client is None:
            self._client = client

    @staticmethod
    def initialize(settings: RedisConfig) -> None:
        global redis_client
        connection_class: type[Union[Connection, SSLConnection]] = Connection
        if settings.REDIS_USE_SSL:
            connection_class = SSLConnection

        # 通用连接参数（单机 & Sentinel 共用）
        redis_params: dict[str, Any] = {
            "username": settings.REDIS_USERNAME,
            "password": settings.REDIS_PASSWORD,
            "db": settings.REDIS_DB,
            "encoding": "utf-8",
            "encoding_errors": "strict",
            "decode_responses": True,
            "max_connections": settings.REDIS_MAX_CONNECTIONS,
        }
        
        if settings.REDIS_USE_SENTINEL:
            if not settings.REDIS_SENTINELS:
                raise ValueError("REDIS_SENTINELS must be set when REDIS_USE_SENTINEL is True")
            if not settings.REDIS_SENTINEL_SERVICE_NAME:
                raise ValueError("REDIS_SENTINEL_SERVICE_NAME must be set when REDIS_USE_SENTINEL is True")
            
            sentinel_hosts = [
                (node.split(":")[0], int(node.split(":")[1])) 
                for node in settings.REDIS_SENTINELS.split(",")
            ]

            sentinel_kwargs: dict[str, Any] = {
                "socket_timeout": settings.REDIS_SENTINEL_SOCKET_TIMEOUT or 0.1,
                "username": settings.REDIS_SENTINEL_USERNAME,
                "password": settings.REDIS_SENTINEL_PASSWORD,
            }

            # Sentinel 自身连接也走 SSL
            ssl_context = _get_redis_ssl_context(settings)
            if ssl_context is not None:
                sentinel_kwargs["ssl"] = True
                sentinel_kwargs["ssl_context"] = ssl_context

            sentinel = Sentinel(
                sentinel_hosts,
                sentinel_kwargs=sentinel_kwargs,
            )

            # master_for 连接同样需要 SSL 参数
            ssl_params = _get_redis_ssl_params(settings)
            redis_params.update(ssl_params)

            master = sentinel.master_for(settings.REDIS_SENTINEL_SERVICE_NAME, **redis_params)
            redis_client.set_client(master)
        elif settings.REDIS_USE_CLUSTERS:
            if not settings.REDIS_CLUSTERS:
                raise ValueError("REDIS_CLUSTERS must be set when REDIS_USE_CLUSTERS is True")
            
            nodes = [
                ClusterNode(host=node.split(":")[0], port=int(node.split(":")[1])) 
                for node in settings.REDIS_CLUSTERS.split(",")
            ]

            # RedisCluster 不支持 db（固定 db 0）和 max_connections，
            # 需要使用 max_connections_per_node 代替
            cluster_params: dict[str, Any] = {
                "username": settings.REDIS_USERNAME,
                "password": settings.REDIS_CLUSTERS_PASSWORD,
                "encoding": "utf-8",
                "encoding_errors": "strict",
                "decode_responses": True,
                "max_connections_per_node": settings.REDIS_MAX_CONNECTIONS,
            }

            # Cluster 模式 SSL
            ssl_params = _get_redis_ssl_params(settings)
            cluster_params.update(ssl_params)

            cluster = RedisCluster(
                startup_nodes=nodes,
                **cluster_params
            )
            redis_client.set_client(cluster)  # type: ignore
        else:
            redis_params.update(
                {
                    "host": settings.REDIS_HOST,
                    "port": settings.REDIS_PORT,
                    "connection_class": connection_class,
                }
            )

            # 单机模式 SSL 参数注入到 ConnectionPool
            if settings.REDIS_USE_SSL:
                ssl_params = _get_redis_ssl_params(settings)
                redis_params.update(ssl_params)

            pool = ConnectionPool(**redis_params)
            redis_client.set_client(Redis(connection_pool=pool))

    @staticmethod
    async def shutdown() -> None:
        global redis_client
        if redis_client._client is not None:
            await redis_client._client.aclose()
            redis_client._client = None

redis_client: RedisClientWrapper[Redis] = RedisClientWrapper()
