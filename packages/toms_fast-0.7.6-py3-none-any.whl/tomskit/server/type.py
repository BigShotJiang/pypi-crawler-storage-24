import uuid
from typing import Annotated, Any
from pydantic import Field, BeforeValidator
from datetime import datetime


def IntRange(minimum: int, maximum: int):
    """
    Factory for a constrained int type: value must be in [minimum, maximum].

    Usage:
        class User(BaseModel):
            age: IntRange(18, 35)
    """
    if minimum > maximum:
        raise ValueError(f"IntRange: minimum ({minimum}) cannot exceed maximum ({maximum})")
    return Annotated[
        int,
        Field(ge=minimum, le=maximum, description=f"Integer in range [{minimum}, {maximum}]"),
    ]

def _parse_bool(v: Any) -> bool:
    """Parse 'true'/'false'/'1'/'0' (case-insensitive) or pass through bool."""
    if isinstance(v, bool):
        return v
    if v is None or (isinstance(v, str) and not v):
        raise ValueError("Boolean type must be non-null")
    s = str(v).lower()
    if s in ("true", "1"):
        return True
    if s in ("false", "0"):
        return False
    raise ValueError(f"Invalid literal for Boolean: {v!r}")


Boolean = Annotated[
    bool,
    Field(description="Accepts true/false/1/0 (case-insensitive)"),
    BeforeValidator(_parse_bool),
]


PhoneNumber = Annotated[
    str,
    Field(pattern=r"^1[3-9]\d{9}$", description="Chinese mobile phone number"),
]


EmailStr = Annotated[
    str,
    Field(
        pattern=r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$",
        description="Email address",
        json_schema_extra={"format": "email"},
    ),
]


def StrLen(max_length: int, min_length: int = 0):
    """
    Factory for a constrained string type: length must be in [min_length, max_length].

    Usage:
        class User(BaseModel):
            username: StrLen(20, 3)   # between 3-20 characters
            name: StrLen(50, 1)      # between 1-50 characters
            code: StrLen(10)         # 0-10 characters (max_length only)
    """
    if min_length < 0:
        raise ValueError(f"StrLen: min_length ({min_length}) cannot be negative")
    if min_length > max_length:
        raise ValueError(f"StrLen: min_length ({min_length}) cannot exceed max_length ({max_length})")
    return Annotated[
        str,
        Field(
            min_length=min_length,
            max_length=max_length,
            description=f"String with length between {min_length} and {max_length} characters",
        ),
    ]

def DatetimeString(format: str, argument: str = "datetime"):
    """
    Factory for datetime string type with custom format validation.

    Usage:
        class Event(BaseModel):
            created_at: DatetimeString("%Y-%m-%d %H:%M:%S")
            date_only: DatetimeString("%Y-%m-%d", "date")
    """

    def _validate_datetime(value: Any) -> str:
        s = value if isinstance(value, str) else str(value)
        try:
            datetime.strptime(s, format)
            return s
        except ValueError:
            raise ValueError(f"Invalid {argument}: '{s}', expected format: {format}")

    is_datetime = any(x in format for x in ["%H", "%M", "%S"])
    return Annotated[
        str,
        Field(
            description=f"{argument.title()} string in format: {format}",
            json_schema_extra={
                "format": "date-time" if is_datetime else "date",
                "example": datetime.now().strftime(format),
            },
        ),
        BeforeValidator(_validate_datetime),
    ]


def _validate_uuid(value: Any) -> str:
    """Validate and normalize to UUID string."""
    if value is None or (isinstance(value, str) and not value):
        raise ValueError("UUID value must be non-empty")
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError):
        raise ValueError(f"{value} is not a valid UUID")


def is_valid_uuid(value: str) -> bool:
    """Return True if value is a valid UUID string, else False."""
    if not value:
        return False
    try:
        uuid.UUID(value)
        return True
    except (ValueError, TypeError):
        return False


UUIDType = Annotated[
    str,
    Field(description="A valid UUID string", json_schema_extra={"format": "uuid"}),
    BeforeValidator(_validate_uuid),
]


# 预定义的常用日期时间格式
class CommonDateFormats:
    """常用的日期时间格式"""
    ISO_DATE = "%Y-%m-%d"                    # 2023-12-25
    ISO_DATETIME = "%Y-%m-%d %H:%M:%S"       # 2023-12-25 14:30:00
    ISO_DATETIME_MS = "%Y-%m-%d %H:%M:%S.%f" # 2023-12-25 14:30:00.123456
    US_DATE = "%m/%d/%Y"                     # 12/25/2023
    EU_DATE = "%d/%m/%Y"                     # 25/12/2023
    TIME_24H = "%H:%M:%S"                    # 14:30:00
    TIME_12H = "%I:%M:%S %p"                 # 02:30:00 PM


# 便捷的预定义类型
ISODate = DatetimeString(CommonDateFormats.ISO_DATE, "date")
ISODateTime = DatetimeString(CommonDateFormats.ISO_DATETIME, "datetime")
USDate = DatetimeString(CommonDateFormats.US_DATE, "date")
EUDate = DatetimeString(CommonDateFormats.EU_DATE, "date")
Time24H = DatetimeString(CommonDateFormats.TIME_24H, "time")
Time12H = DatetimeString(CommonDateFormats.TIME_12H, "time")


