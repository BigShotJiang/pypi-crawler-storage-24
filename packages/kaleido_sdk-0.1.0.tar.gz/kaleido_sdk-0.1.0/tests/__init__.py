"""Tests for Kaleidoswap SDK."""
