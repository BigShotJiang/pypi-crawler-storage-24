"""Utility commands — clean, hash, validate."""

from __future__ import annotations

import json
import sys
from typing import Annotated

import typer

from datalegion_cli.async_typer import async_command
from datalegion_cli.client import APIError, LegionClient
from datalegion_cli.output import emit_error, emit_json

app = typer.Typer(name="utility", help="Data cleaning, hashing, and validation.")


@app.command()
@async_command
async def clean(
    fields: Annotated[
        str | None,
        typer.Argument(
            help='JSON object of fields to clean, e.g. \'{"email":"John+tag@gmail.com"}\'.'
        ),
    ] = None,
    stdin: Annotated[bool, typer.Option("--stdin", help="Read JSON fields from stdin.")] = False,
    default_region: Annotated[str, typer.Option("--region", help="Default phone region.")] = "US",
) -> None:
    """Clean and normalize data fields.

    Examples:
        datalegion-cli utility clean '{"email":"John+tag@gmail.com"}'
        datalegion-cli utility clean '{"phone":"(415) 555-1234"}' --region US
        echo '{"email":"test@EXAMPLE.com","phone":"5551234"}' | datalegion-cli utility clean --stdin
    """
    if stdin:
        data = json.load(sys.stdin)
    elif fields:
        data = json.loads(fields)
    else:
        raise typer.BadParameter("Provide fields as argument or use --stdin.")

    client = LegionClient()
    try:
        result = await client.utility_clean(fields=data, default_region=default_region)
        emit_json(result)
    except APIError as e:
        emit_error(e.message, code=e.error, details=e.details, as_json=True)
        raise typer.Exit(1) from e
    finally:
        await client.close()


@app.command("hash")
@async_command
async def hash_email(
    email: Annotated[str, typer.Argument(help="Email address to hash.")],
) -> None:
    """Hash an email address (SHA-256, SHA-1, MD5) for privacy-preserving lookups.

    Examples:
        datalegion-cli utility hash john@example.com
    """
    client = LegionClient()
    try:
        result = await client.utility_hash(email)
        emit_json(result)
    except APIError as e:
        emit_error(e.message, code=e.error, details=e.details, as_json=True)
        raise typer.Exit(1) from e
    finally:
        await client.close()


@app.command()
@async_command
async def validate(
    email: Annotated[str | None, typer.Option("--email", help="Email to validate.")] = None,
    phone: Annotated[str | None, typer.Option("--phone", help="Phone to validate.")] = None,
    full_name: Annotated[str | None, typer.Option("--name", help="Name to validate.")] = None,
    domain: Annotated[str | None, typer.Option("--domain", help="Domain to validate.")] = None,
    social_url: Annotated[
        str | None, typer.Option("--social-url", help="Social URL to validate.")
    ] = None,
    company: Annotated[
        str | None, typer.Option("--company", help="Company name to validate.")
    ] = None,
    ticker_symbol: Annotated[
        str | None, typer.Option("--ticker", help="Ticker symbol to validate.")
    ] = None,
    stdin: Annotated[bool, typer.Option("--stdin", help="Read JSON from stdin.")] = False,
) -> None:
    """Validate data fields and get cleaning suggestions.

    Examples:
        datalegion-cli utility validate --email john@example.com
        datalegion-cli utility validate --phone "+14155551234" --domain example.com
        echo '{"email":"test@example.com","company":"Acme"}' | datalegion-cli utility validate --stdin
    """
    if stdin:
        kwargs = json.load(sys.stdin)
    else:
        kwargs = dict(
            email=email,
            phone=phone,
            full_name=full_name,
            domain=domain,
            social_url=social_url,
            company=company,
            ticker_symbol=ticker_symbol,
        )

    client = LegionClient()
    try:
        result = await client.utility_validate(**kwargs)
        emit_json(result)
    except APIError as e:
        emit_error(e.message, code=e.error, details=e.details, as_json=True)
        raise typer.Exit(1) from e
    finally:
        await client.close()
