"""Data Legion CLI."""

from importlib.metadata import version

__version__ = version("datalegion-cli")
