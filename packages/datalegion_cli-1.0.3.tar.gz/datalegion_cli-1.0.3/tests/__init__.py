"""Tests for datalegion-cli."""
