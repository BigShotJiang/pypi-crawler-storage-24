"""
rvid.log — single-file, zero-dependency Python logger.

Usage:
    from rvid.log import getLogger
    log = getLogger("rvid.log")
    log.important("Hello!")
    > [2026-03-07 23:30:39] INFO [rvid.log] Hello!

Features:
    * Useful default formatter and level config
    * Post-deployment, per-module level configuration via environment
      variables (SpringBoot-style). Including global file-redirect.
    * TRACE level for extreme detail, IMPORTANT level between WARNING and ERROR
    * A single switch to redirect all output through stdlib logging instead

For manual source deployment, copy this file (__init__.py) to your project and
give it whatever name you like.
"""

import atexit
import os
import sys
import threading
import traceback
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
    Sequence,
    TextIO,
    Tuple,
    Union,
    cast,
)

if TYPE_CHECKING:
    import logging


# ── Level constants and lookups ────────────────────────────────

FATAL = 50
ERROR = 40
IMPORTANT = 35
WARNING = 30
INFO = 20
DEBUG = 10
TRACE = 5

LEVEL_NAMES = {
    FATAL: "FATAL",
    ERROR: "ERROR",
    IMPORTANT: "IMPORTANT",
    WARNING: "WARNING",
    INFO: "INFO",
    DEBUG: "DEBUG",
    TRACE: "TRACE",
}

LEVEL_VALUES = {
    "FATAL": FATAL,
    "ERROR": ERROR,
    "IMPORTANT": IMPORTANT,
    "WARN": WARNING,
    "WARNING": WARNING,
    "INFO": INFO,
    "DEBUG": DEBUG,
    "TRACE": TRACE,
}


# ── Target types and sink specs ────────────────────────────────


class LogTargetType(str, Enum):
    path = "path"
    io = "io"


SinkSpec = Tuple[LogTargetType, Union[os.PathLike, TextIO]]  # type: ignore[type-arg]


# ── Sink ───────────────────────────────────────────────────────


class Sink:
    """Thread-safe write-and-flush wrapper around a text stream."""

    __slots__ = ("_stream", "_lock", "owned")

    def __init__(self, stream: TextIO, owned: bool):
        self._stream = stream
        self._lock = threading.Lock()
        self.owned = owned

    def write(self, msg: str) -> None:
        with self._lock:
            self._stream.write(msg)
            self._stream.write("\n")
            self._stream.flush()

    def close(self) -> None:
        if self.owned:
            with self._lock:
                self._stream.close()


# ── File sink registry ─────────────────────────────────────────
# Multiple loggers writing to the same path share one Sink.

_OPEN_SINKS: Dict[Path, Sink] = {}
_ATEXIT_REGISTERED = False
_SINK_REGISTRY_LOCK = threading.Lock()


def _get_file_sink(path: Path) -> Sink:
    global _ATEXIT_REGISTERED
    with _SINK_REGISTRY_LOCK:
        if path not in _OPEN_SINKS:
            f = open(path, "a", encoding="utf-8")
            _OPEN_SINKS[path] = Sink(f, owned=True)

            if not _ATEXIT_REGISTERED:
                atexit.register(_close_all_sinks)
                _ATEXIT_REGISTERED = True

    return _OPEN_SINKS[path]


def _close_all_sinks() -> None:
    for sink in _OPEN_SINKS.values():
        try:
            sink.close()
        except Exception:
            pass


def _after_fork_child() -> None:
    for sink in _OPEN_SINKS.values():
        try:
            sink.close()
        except Exception:
            pass

    _OPEN_SINKS.clear()
    _LOGGER_CACHE.clear()


if sys.version_info >= (3, 7):
    os.register_at_fork(after_in_child=_after_fork_child)


# ── RvidLog ────────────────────────────────────────────────────


class RvidLog:
    """A logger instance bound to a name, level, and one or more sinks."""

    def __init__(
        self,
        name: str,
        sink_specs: Sequence[SinkSpec],
        level: int = INFO,
        meta: Optional[List[str]] = None,
    ):
        self.level = level
        self.name = name
        self.sinks: List[Sink] = []

        self.meta = meta or ["no meta provided to __init__"]
        self.meta.append("instantiated: %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

        for sink_type, sink_obj in sink_specs:
            if sink_type == LogTargetType.io:
                self.sinks.append(Sink(cast(TextIO, sink_obj), owned=False))
            elif sink_type == LogTargetType.path:
                self.sinks.append(_get_file_sink(Path(cast(os.PathLike, sink_obj))))  # type: ignore[type-arg]

    def emit(
        self,
        level: int,
        template: str,
        payloads: Any,
    ) -> None:
        if level < self.level:
            return

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            if not payloads:
                content = template
            else:
                content = template % payloads
        except Exception:
            content = "(FORMAT ERROR) %s %s" % (str(template), str(payloads))

        msg = "[%s] %s [%s] %s" % (
            ts,
            LEVEL_NAMES.get(level, str(level)),
            self.name,
            content,
        )

        for sink in self.sinks:
            sink.write(msg)

    def fatal(self, message: str, *args: Any) -> None:
        self.emit(level=FATAL, template=message, payloads=args)

    def error(self, message: str, *args: Any) -> None:
        self.emit(level=ERROR, template=message, payloads=args)

    def important(self, message: str, *args: Any) -> None:
        self.emit(level=IMPORTANT, template=message, payloads=args)

    def warning(self, message: str, *args: Any) -> None:
        self.emit(level=WARNING, template=message, payloads=args)

    def warn(self, message: str, *args: Any) -> None:
        self.emit(level=WARNING, template=message, payloads=args)

    def info(self, message: str, *args: Any) -> None:
        self.emit(level=INFO, template=message, payloads=args)

    def debug(self, message: str, *args: Any) -> None:
        self.emit(level=DEBUG, template=message, payloads=args)

    def trace(self, message: str, *args: Any) -> None:
        self.emit(level=TRACE, template=message, payloads=args)

    def exception(self, message: str, *args: Any) -> None:
        try:
            content = message % args
        except Exception:
            content = "(FORMAT ERROR) %s %s" % (str(message), str(args))
        self.emit(level=ERROR, template="%s\n%s", payloads=(content, traceback.format_exc()))


# ── Environment-based configuration helpers ────────────────────


def level_from_env(name: str) -> Tuple[Optional[int], str]:
    """Match logger name against LOGGING_LEVEL_* env vars (most specific wins).

    Returns (level, description) where level is None if no match found.
    """

    # Turn rvid.apa.bepa into (RVID, APA, BEPA)
    mod_path_tuple = tuple(name.upper().split("."))

    matches = {}
    originals = {}

    for k, v in os.environ.items():
        if not k.startswith("LOGGING_LEVEL"):
            continue

        # Store LOGGING_LEVEL_RVID_APA=INFO as {(RVID, APA): INFO}
        matches[tuple(k.split("_")[2:])] = v.upper()
        originals[tuple(k.split("_")[2:])] = k

    for offset in range(len(mod_path_tuple), -1, -1):
        prefix = mod_path_tuple[:offset]
        if prefix in matches:
            level_for_mod_path = matches[prefix]
            if level_for_mod_path in LEVEL_VALUES:
                return (
                    LEVEL_VALUES[level_for_mod_path],
                    f"level_from_env: {originals[prefix]}={level_for_mod_path}",
                )
            else:
                print("Error in log config for %s, no such level: '%s'" % (prefix, matches[prefix]))
                return (
                    WARNING,
                    f"level_from_env: error parsing level name {level_for_mod_path}",
                )

    return None, "level_from_env: no match in env"


def _caller_module_name() -> str:
    """Derive logger name from the call site's module or filename."""
    try:
        frame = sys._getframe(2)
        name = frame.f_globals.get("__name__", "")
        if name and name != "__main__":
            return str(name)
        return frame.f_code.co_filename.split(os.path.sep)[-1]
    except (AttributeError, ValueError):
        return "<unknown>"


def log_path_from_env() -> Optional[Path]:
    path_str = os.environ.get("LOGGING_PATH")
    if path_str:
        return Path(path_str).resolve()

    return None


# ── stdlib logging bridge ──────────────────────────────────────


class UsePythonLogging:
    """Flip .enabled to route all getLogger() calls through stdlib logging."""

    enabled = False

    @staticmethod
    def get_logger(name: str) -> "logging.Logger":
        import logging

        logger = logging.getLogger(name)
        if not getattr(logger, "important", None):
            setattr(logger, "important", lambda *args: logger.warning(*args))
        if not getattr(logger, "trace", None):
            setattr(logger, "trace", lambda *args: logger.debug(*args))
        return logger


# ── Public API: getLogger ──────────────────────────────────────

_LOGGER_CACHE: Dict[str, "RvidLog"] = {}


def getLogger(
    name: Optional[str] = None,
    target_io: Optional[TextIO] = None,
    target_file_path: Optional[os.PathLike] = None,  # type: ignore[type-arg]
) -> Union["logging.Logger", "RvidLog"]:
    """Create or retrieve a cached logger by name.

    Configures level from LOGGING_LEVEL_* env vars and output target from
    arguments, LOGGING_PATH env var, or stderr (in that priority order).
    """

    if name is None:
        name = _caller_module_name()

    if name in _LOGGER_CACHE:
        return _LOGGER_CACHE[name]

    if UsePythonLogging.enabled:
        return UsePythonLogging.get_logger(name)

    meta: List[str] = []

    env_level, why = level_from_env(name)
    meta.append(why)
    if env_level is not None:
        level = env_level
    else:
        level = INFO

    sink_specs: List[SinkSpec] = []

    if target_file_path is not None:
        sink_specs.append((LogTargetType.path, Path(target_file_path)))
        meta.append(f"target_file_path: {target_file_path}")

    if target_io is not None:
        sink_specs.append((LogTargetType.io, target_io))
        meta.append("target_io: <from getLogger argument>")

    path_from_env = log_path_from_env()
    if path_from_env:
        sink_specs.append((LogTargetType.path, path_from_env))
        meta.append(f"path_from_env: {path_from_env}")

    if not sink_specs:
        sink_specs.append((LogTargetType.io, sys.stderr))
        meta.append("default: sys.stderr")

    _LOGGER_CACHE[name] = RvidLog(name=name, level=level, sink_specs=sink_specs, meta=meta)
    return _LOGGER_CACHE[name]
