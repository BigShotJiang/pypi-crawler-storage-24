# mille 開発 TODO

本リストは、`spec.md` に定義された仕様に基づく残タスクです。
完了済みのPRは削除済み（git履歴で参照可）。

---

## 実装状況サマリー

現在の `mille check` は以下を正常に動作させています：
- ✅ 内部レイヤー依存チェック (`dependency_mode`)
- ✅ 外部ライブラリ依存チェック (`external_mode`)
- ✅ DIエントリーポイントのメソッド呼び出しチェック (`allow_call_patterns`)
- ✅ Rust / Go / TypeScript / JavaScript / Python サポート
- ✅ `[resolve.typescript]` tsconfig.json paths エイリアス解決
- ✅ cargo / npm(WASM) / go install / pip パッケージ配布
- ✅ リリース後のバージョン自動同期（`update-version` ジョブ）— `mille --version` がリリースタグと一致
- ✅ `--format terminal / json / github-actions` 出力フォーマット切り替え（PR 10）
- ✅ `[ignore]` セクション — `paths` / `test_patterns` 適用（PR 12）
- ✅ `mille init` コマンド — プロジェクトスキャンして `mille.toml` 自動生成（PR 11）

以下は **設定ファイルにフィールドが存在しても、まだ動作していない** 項目です（README に掲載しないよう修正済み）：
- ❌ `[severity]` — パースされるが無視される（常に Error で出力）
- ❌ `--fail-on` オプション
- ❌ `mille analyze` / `mille report external` コマンド

---

## フェーズ 3: 出力・CI連携（バズりやすい順）

### PR 10: GitHub Actions アノテーション出力 (`--format github-actions`) ✅ 完了

**バズりポイント**: PRレビュー画面に `::error file=...` が差し込まれるため、mille を使っているリポジトリのPRを見た人が「これ何？」となりやすい。CI を通じたパッシブな口コミ効果が最大。

- [x] CLI に `--format` オプションを追加（`terminal` / `json` / `github-actions`）
- [x] GitHub Actions (`::error file=<path>,line=<n>::<msg>`) フォーマッターの実装
- [x] JSON フォーマッターの実装
- [x] CI ドキュメントに GitHub Actions 設定例を追記（`docs/github-actions-usage.md`）

### PR 11: `mille init` コマンド（インタラクティブ設定生成）✅ 完了

**バズりポイント**: 「`mille init` を叩くだけで始められる」というオンボーディング体験は口コミで広まりやすい。Time-to-first-value の短縮が採用数に直結する。

- [x] `mille init` サブコマンドの追加
- [x] 実際のインポート文を解析してレイヤーと依存関係を推論する（トポロジカルソート）
- [x] `--output <path>` / `--force` フラグのサポート
- [x] `mille.toml` 自動生成（副作用なし純粋関数 + E2E テスト）、`external_allow` も実インポートから生成
- [x] `--depth N` フラグ + 自動深度検出（深いネスト構造を正しくロールアップ）

### PR 12: `[ignore]` セクションの実装 ✅ 完了

**バズりポイント**: テストファイルの除外は必須ユースケース。これがないと「mille 使えない」という評価につながる。採用の障壁を下げるために優先度高。

- [x] `check_architecture::check()` で `ignore.paths` のグロブパターンを除外
- [x] `check_architecture::check()` でテストファイルに対して依存ルールを緩める（`test_patterns`）
- [x] E2E テストの追加

### PR 13: `mille analyze` コマンド（依存グラフ可視化）

**バズりポイント**: DOT/SVG グラフはスクリーンショットとして SNS に貼りやすく、「自分のプロジェクトのアーキテクチャが可視化された」という体験は Twitter/X やブログで紹介されやすい。

- [ ] `mille analyze` サブコマンドの追加
- [ ] DOT 形式での依存グラフ出力 (`--format dot`)
- [ ] レイヤー間エッジの集計（ファイルレベルではなくレイヤーレベル）

### PR 14: `[severity]` 設定の実装

**バズりポイント**: warning/error の区別は段階的導入を可能にし、「既存プロジェクトへの追加しやすさ」を向上させる。採用率に寄与。

- [ ] `ViolationDetector` に `SeverityConfig` を渡すようにする
- [ ] `detect()` / `detect_external()` / `detect_call_patterns()` で severity を設定値から取得する
- [ ] `--fail-on warning` オプションで warning でも exit code 1 にする
- [ ] 終了コード `2`（warning あり、`--fail-on warning` 指定時）の実装
- [ ] E2E テストの追加

### PR 15: `mille report external` コマンド

- [ ] `mille report external` サブコマンドの追加
- [ ] 外部ライブラリ依存をレイヤーごとにテーブル形式で出力

---

## フェーズ 4: 言語・エコシステム拡張

### PR 16: Java / Kotlin サポート

- [ ] `infrastructure::parser::java` / `kotlin` 実装 (tree-sitter-java)
- [ ] `infrastructure::resolver::java` 実装
- [ ] Java/Kotlin E2E テスト追加

---

## 優先度の考え方（バズりやすい順）

| 順位 | PR | 理由 |
|---|---|---|
| 1 | PR 10 (GitHub Actions) | CI経由のパッシブ口コミ。PRレビュー画面への露出が最大 |
| 2 | PR 11 (`mille init`) | オンボーディング摩擦の除去。「試してみた」投稿が増える |
| 3 | PR 12 (`[ignore]`) | 採用障壁の除去。テストファイル除外は必須 |
| 4 | PR 13 (`mille analyze`) | ビジュアルなデモ素材になる。SNS・ブログ投稿向き |
| 5 | PR 14 (`[severity]`) | 既存プロジェクトへの段階的導入を可能にする |
| 6 | PR 15 (`report external`) | 高度なユーザー向け |
| 7 | PR 16 (Java/Kotlin) | エンタープライズ層への展開 |
