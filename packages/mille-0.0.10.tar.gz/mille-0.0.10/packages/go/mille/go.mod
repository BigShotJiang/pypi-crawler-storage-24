module github.com/makinzm/mille/packages/go/mille

go 1.24.0

require github.com/tetratelabs/wazero v1.11.0

require golang.org/x/sys v0.38.0 // indirect
