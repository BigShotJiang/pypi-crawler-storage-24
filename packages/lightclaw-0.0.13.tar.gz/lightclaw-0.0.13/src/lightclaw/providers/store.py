# -*- coding: utf-8 -*-
"""Provider configuration access — backed by lightclaw.json via config.models."""

from __future__ import annotations
import json
import logging
import time
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field

from .models import (
    CustomProviderData,
    ModelInfo,
    ModelSlotConfig,
    ProviderEntry,
    ProviderSettings,
    ProvidersData,
    ResolvedModelConfig,
    ResolvedModelInfo,
)
from .registry import (
    PROVIDERS,
    is_builtin,
    register_custom_provider,
    sync_custom_providers,
    sync_ollama_models,
    unregister_custom_provider,
    validate_custom_provider_id,
)

logger = logging.getLogger(__name__)

# Default TTL for the in-memory provider cache (seconds).
_CACHE_TTL_SECONDS: float = 2.0


def sync_local_models() -> None:
    """Compatibility stub for the removed local-model sync hook."""
    return


class LegacyProvidersData(BaseModel):
    """Backward-compatible providers.json view used by cache tests."""

    providers: dict[str, ProviderSettings] = Field(default_factory=dict)
    custom_providers: dict[str, CustomProviderData] = Field(default_factory=dict)
    active_llm: ModelSlotConfig = Field(default_factory=ModelSlotConfig)

    def get_credentials(self, provider_id: str) -> tuple[str, str]:
        custom = self.custom_providers.get(provider_id)
        if custom is not None:
            return custom.base_url or custom.default_base_url, custom.api_key
        settings = self.providers.get(provider_id)
        if settings is None:
            return "", ""
        return settings.base_url, settings.api_key

    def is_configured(self, defn) -> bool:
        if defn.id == "ollama":
            return True
        if defn.is_custom:
            custom = self.custom_providers.get(defn.id)
            return bool(custom and (custom.base_url or custom.default_base_url))
        settings = self.providers.get(defn.id)
        return bool(settings and settings.api_key)


# ---------------------------------------------------------------------------
# Internal helpers (also imported by config/utils.py for migration)
# ---------------------------------------------------------------------------


def _ensure_base_url(entry: ProviderEntry, defn) -> None:
    if not entry.base_url and defn.default_base_url:
        entry.base_url = defn.default_base_url


def _entry_to_custom_data(pid: str, entry: ProviderEntry) -> CustomProviderData:
    """Convert a ProviderEntry (custom) to CustomProviderData for the registry."""
    return CustomProviderData(
        id=pid,
        name=entry.name or pid,
        default_base_url=entry.default_base_url or "",
        api_key_prefix=entry.api_key_prefix or "",
        models=list(entry.models),
        base_url=entry.base_url,
        api_key=entry.api_key,
        chat_model=entry.chat_model or "OpenAIChatModel",
    )


# ---------------------------------------------------------------------------
# Legacy migration helpers (also imported by config/utils.py)
# ---------------------------------------------------------------------------


def _migrate_legacy_custom(
    providers: dict[str, ProviderEntry],
    old_custom: dict[str, CustomProviderData],
) -> None:
    """Merge old ``custom_providers`` entries into the flat ``providers`` dict."""
    for cpid, cpd in old_custom.items():
        if cpid in providers:
            entry = providers[cpid]
            if cpd.api_key and not entry.api_key:
                entry.api_key = cpd.api_key
            if cpd.base_url and not entry.base_url:
                entry.base_url = cpd.base_url
        else:
            providers[cpid] = ProviderEntry(
                base_url=cpd.base_url,
                api_key=cpd.api_key,
                name=cpd.name,
                default_base_url=cpd.default_base_url or None,
                api_key_prefix=cpd.api_key_prefix or None,
                is_custom=True,
                models=list(cpd.models),
                chat_model=cpd.chat_model
                if cpd.chat_model != "OpenAIChatModel"
                else "",
            )


def _parse_new_format(raw: dict) -> tuple[dict[str, ProviderEntry], str]:
    """Parse in the new flat camelCase format. Returns (providers, active_llm)."""
    providers: dict[str, ProviderEntry] = {}
    for key, value in raw.get("providers", {}).items():
        if isinstance(value, dict):
            providers[key] = ProviderEntry.model_validate(value)

    active_llm = raw.get("activeLlm", "")
    if not isinstance(active_llm, str):
        active_llm = ""

    return providers, active_llm


def _parse_split_format(raw: dict) -> tuple[dict[str, ProviderEntry], str]:
    """Parse old split format (providers + custom_providers). Returns (providers, active_llm)."""
    providers: dict[str, ProviderEntry] = {}
    for key, value in raw.get("providers", {}).items():
        if isinstance(value, dict):
            try:
                ps = ProviderSettings.model_validate(value)
                providers[key] = ProviderEntry(
                    base_url=ps.base_url,
                    api_key=ps.api_key,
                    extra_models=list(ps.extra_models),
                    chat_model=ps.chat_model,
                )
            except Exception:
                pass

    old_custom: dict[str, CustomProviderData] = {}
    for key, value in raw.get("custom_providers", {}).items():
        if isinstance(value, dict):
            try:
                old_custom[key] = CustomProviderData.model_validate(value)
            except Exception:
                pass

    _migrate_legacy_custom(providers, old_custom)

    llm_raw = raw.get("active_llm")
    active_llm = ""
    if isinstance(llm_raw, dict):
        slot = ModelSlotConfig.model_validate(llm_raw)
        active_llm = (
            f"{slot.provider_id}/{slot.model}"
            if slot.provider_id and slot.model
            else ""
        )
    elif isinstance(llm_raw, str):
        active_llm = llm_raw

    return providers, active_llm


def _parse_legacy_format(raw: dict) -> tuple[dict[str, ProviderEntry], str]:
    """Parse oldest format (flat per-provider keys at top level). Returns (providers, active_llm)."""
    providers: dict[str, ProviderEntry] = {}
    old_active = raw.get("active_provider", "")
    old_model = ""
    for key, value in raw.items():
        if key in ("active_provider", "active_llm"):
            continue
        if not isinstance(value, dict):
            continue
        model_val = value.pop("model", "")
        try:
            ps = ProviderSettings.model_validate(value)
            providers[key] = ProviderEntry(
                base_url=ps.base_url,
                api_key=ps.api_key,
                extra_models=list(ps.extra_models),
                chat_model=ps.chat_model,
            )
        except Exception:
            pass
        if key == old_active and model_val:
            old_model = model_val

    active_llm = (
        f"{old_active}/{old_model}" if old_active and old_model else (old_active or "")
    )
    return providers, active_llm


def _validate_active_llm(
    data: ProvidersData | LegacyProvidersData,
    *,
    check_ollama: bool = True,
) -> None:
    """Clear active_llm if its provider is not configured or stale."""
    if isinstance(data, LegacyProvidersData):
        pid = data.active_llm.provider_id
        model = data.active_llm.model

        def clear_active() -> None:
            setattr(data, "active_llm", ModelSlotConfig())

    else:
        pid, model = data.parse_active_llm()

        def clear_active() -> None:  # type: ignore[misc]
            setattr(data, "active_llm", "")

    if not pid:
        return
    defn = PROVIDERS.get(pid)
    if defn is None or not data.is_configured(defn):
        clear_active()
        return

    if check_ollama and defn.id == "ollama" and model:
        try:
            from ..providers.ollama_manager import is_ollama_sdk_available

            if not is_ollama_sdk_available():
                # SDK not installed — skip validation, keep current slot.
                return

            from ..providers.ollama_manager import OllamaModelManager

            names = {m.name for m in OllamaModelManager.list_models()}
            if model not in names:
                clear_active()
        except Exception:
            pass


def _ensure_all_providers(providers: dict[str, ProviderEntry]) -> None:
    """Ensure every built-in has an entry; skip stale custom ones."""
    for pid, defn in PROVIDERS.items():
        if defn.is_custom:
            continue
        if pid not in providers:
            providers[pid] = ProviderEntry(base_url=defn.default_base_url)
        else:
            _ensure_base_url(providers[pid], defn)


def _legacy_ensure_all_providers(providers: dict[str, ProviderSettings]) -> None:
    """Ensure every built-in has a ProviderSettings entry for legacy JSON."""
    for pid, defn in PROVIDERS.items():
        if defn.is_custom:
            continue
        if pid not in providers:
            providers[pid] = ProviderSettings(base_url=defn.default_base_url)
        else:
            _ensure_base_url(providers[pid], defn)


# ---------------------------------------------------------------------------
# Load / Save
# ---------------------------------------------------------------------------


def _get_models_config_path() -> Path:
    from ..config.utils import get_config_path  # noqa: PLC0415

    return get_config_path()


def _read_providers_from_config(path: Path) -> ProvidersData:
    """Read only the ``models`` section from lightclaw.json without sync IO."""
    data = ProvidersData()
    if path.is_file():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            raw = {}
        models_raw = raw.get("models", {})
        if isinstance(models_raw, dict):
            try:
                data = ProvidersData.model_validate(models_raw)
            except Exception:
                data = ProvidersData()

    custom_map = {
        pid: _entry_to_custom_data(pid, entry)
        for pid, entry in data.providers.items()
        if entry.is_custom
    }
    sync_custom_providers(custom_map)
    _ensure_all_providers(data.providers)
    return data


def _read_legacy_providers_json(path: Path) -> LegacyProvidersData:
    """Read a legacy providers.json-compatible file for tests/compatibility."""
    provider_entries: dict[str, ProviderEntry] = {}
    active_llm = ""

    if path.is_file():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            raw = {}

        if "providers" in raw and isinstance(raw.get("providers"), dict):
            if "activeLlm" in raw:
                provider_entries, active_llm = _parse_new_format(raw)
            else:
                provider_entries, active_llm = _parse_split_format(raw)
        elif isinstance(raw, dict):
            provider_entries, active_llm = _parse_legacy_format(raw)

    providers: dict[str, ProviderSettings] = {}
    custom_providers: dict[str, CustomProviderData] = {}
    for pid, entry in provider_entries.items():
        if entry.is_custom:
            custom_providers[pid] = _entry_to_custom_data(pid, entry)
            continue
        providers[pid] = ProviderSettings(
            base_url=entry.base_url,
            api_key=entry.api_key,
            extra_models=list(entry.extra_models),
            chat_model=entry.chat_model,
        )

    sync_custom_providers(custom_providers)
    _legacy_ensure_all_providers(providers)

    provider_id, _, model = active_llm.partition("/")
    return LegacyProvidersData(
        providers=providers,
        custom_providers=custom_providers,
        active_llm=ModelSlotConfig(provider_id=provider_id, model=model),
    )


class _CachedProviderStore:
    """Process-level cache keyed by path mtime plus a short TTL."""

    __slots__ = ("_data", "_mtime_ns", "_last_check", "_path", "_mode")

    def __init__(self) -> None:
        self._data: ProvidersData | LegacyProvidersData | None = None
        self._mtime_ns: int = 0
        self._last_check: float = 0.0
        self._path: Path | None = None
        self._mode: str | None = None

    def get(
        self,
        path: Path,
        *,
        mode: str,
        loader,
        check_ollama: bool,
    ) -> ProvidersData | LegacyProvidersData:
        now = time.monotonic()
        if (
            self._data is not None
            and self._path == path
            and self._mode == mode
            and (now - self._last_check) < _CACHE_TTL_SECONDS
        ):
            return self._data

        self._last_check = now
        try:
            current_mtime = path.stat().st_mtime_ns
        except FileNotFoundError:
            current_mtime = 0

        if (
            self._data is not None
            and self._path == path
            and self._mode == mode
            and current_mtime == self._mtime_ns
        ):
            return self._data

        data = loader(path)
        _validate_active_llm(data, check_ollama=check_ollama)
        self._data = data
        self._mtime_ns = current_mtime
        self._last_check = now
        self._path = path
        self._mode = mode
        return data

    def invalidate(self) -> None:
        self._data = None
        self._mtime_ns = 0
        self._last_check = 0.0
        self._path = None
        self._mode = None


_provider_cache = _CachedProviderStore()


def invalidate_provider_cache() -> None:
    """Force the next provider read to re-parse from disk."""
    _provider_cache.invalidate()


def _serialize_legacy_providers_data(data: LegacyProvidersData) -> dict:
    return {
        "providers": {
            pid: settings.model_dump(mode="json")
            for pid, settings in data.providers.items()
        },
        "custom_providers": {
            pid: cpd.model_dump(mode="json")
            for pid, cpd in data.custom_providers.items()
        },
        "active_llm": data.active_llm.model_dump(mode="json"),
    }


def load_providers_json(
    path: Optional[Path] = None,
    *,
    refresh_models: bool = False,
) -> ProvidersData | LegacyProvidersData:
    """Load provider data, using a hot-path cache by default."""
    if path is None:
        path = _get_models_config_path()
        if refresh_models:
            data = _read_providers_from_config(path)
            sync_local_models()
            sync_ollama_models()
            _validate_active_llm(data, check_ollama=True)
            save_providers_json(data)
            return data
        return _provider_cache.get(
            path,
            mode="config",
            loader=_read_providers_from_config,
            check_ollama=False,
        )

    if refresh_models:
        data = _read_legacy_providers_json(path)
        sync_local_models()
        sync_ollama_models()
        _validate_active_llm(data, check_ollama=True)
        save_providers_json(data, path)
        return data

    return _provider_cache.get(
        path,
        mode="legacy",
        loader=_read_legacy_providers_json,
        check_ollama=False,
    )


def save_providers_json(
    data: ProvidersData | LegacyProvidersData,
    path: Optional[Path] = None,
) -> None:
    """Persist provider data, skipping writes when the content is unchanged."""
    if path is None:
        path = _get_models_config_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.is_file():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                raw = {}
        else:
            raw = {}

        new_models = data.model_dump(mode="json", by_alias=True, exclude_none=True)
        if raw.get("models") == new_models:
            return

        raw["models"] = new_models
        path.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")
        invalidate_provider_cache()
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    if not isinstance(data, LegacyProvidersData):
        raise TypeError("path-based provider persistence requires LegacyProvidersData")

    new_content = json.dumps(
        _serialize_legacy_providers_data(data),
        indent=2,
        ensure_ascii=False,
    )
    try:
        existing = path.read_text(encoding="utf-8")
        if existing == new_content:
            return
    except FileNotFoundError:
        pass

    path.write_text(new_content, encoding="utf-8")
    invalidate_provider_cache()


def refresh_provider_models(
    path: Optional[Path] = None,
) -> ProvidersData | LegacyProvidersData:
    """Explicit refresh entry point for management code and tests."""
    return load_providers_json(path, refresh_models=True)


def _save_config_and_invalidate(config) -> None:
    from ..config.utils import save_config  # noqa: PLC0415

    save_config(config)
    invalidate_provider_cache()


# ---------------------------------------------------------------------------
# Mutators
# ---------------------------------------------------------------------------


def update_provider_settings(
    provider_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> ProvidersData:
    """Partially update a provider's settings. Returns updated state."""
    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models
    entry = data.providers.get(provider_id)

    if entry is None:
        defn = PROVIDERS.get(provider_id)
        entry = ProviderEntry(base_url=defn.default_base_url if defn else "")
        data.providers[provider_id] = entry

    if api_key is not None:
        entry.api_key = api_key
    if base_url is not None:
        entry.base_url = base_url

    if not entry.base_url:
        defn = PROVIDERS.get(provider_id)
        if defn:
            entry.base_url = defn.default_base_url
        elif entry.default_base_url:
            entry.base_url = entry.default_base_url

    if entry.is_custom:
        register_custom_provider(_entry_to_custom_data(provider_id, entry))

    if api_key == "":
        pid, _ = data.parse_active_llm()
        if pid == provider_id:
            data.active_llm = ""

    _save_config_and_invalidate(config)
    return data


def set_active_llm(provider_id: str, model: str) -> ProvidersData:
    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models
    data.active_llm = data.format_active_llm(provider_id, model)
    _save_config_and_invalidate(config)
    return data


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------


def _resolve_slot(
    slot: ModelSlotConfig,
    data: ProvidersData,
) -> Optional[ResolvedModelConfig]:
    pid = slot.provider_id
    if not pid or not slot.model:
        return None

    if pid not in data.providers:
        return None
    base_url, api_key = data.get_credentials(pid)
    provider_def = PROVIDERS.get(pid)
    if provider_def is not None and not base_url:
        base_url = provider_def.default_base_url
    return ResolvedModelConfig(
        model=slot.model,
        base_url=base_url,
        api_key=api_key,
        provider_id=pid,
    )


def get_active_llm_config() -> Optional[ResolvedModelConfig]:
    data = load_providers_json()
    pid, model = data.parse_active_llm()
    if not pid or not model:
        return None
    slot = ModelSlotConfig(provider_id=pid, model=model)
    return _resolve_slot(slot, data)


def list_resolved_llm_configs(
    data: Optional[ProvidersData] = None,
) -> list[ResolvedModelInfo]:
    """Return all configured LLM candidates with routing metadata."""
    if data is None:
        data = load_providers_json()

    resolved: list[ResolvedModelInfo] = []
    for provider_id, provider_def in PROVIDERS.items():
        if provider_def.is_custom:
            continue
        entry = data.providers.get(provider_id)
        if entry is None or not data.is_configured(provider_def):
            continue

        base_url, api_key = data.get_credentials(provider_id)
        if not base_url:
            base_url = provider_def.default_base_url
        # Build override map from extra_models (user-added or enabled overrides)
        extra_by_id: dict[str, ModelInfo] = {m.id: m for m in entry.extra_models}
        # Process built-in models, applying overrides from extra_models
        for model in provider_def.models:
            override = extra_by_id.pop(model.id, None)
            effective = override if override is not None else model
            if not effective.enabled:
                continue
            resolved.append(
                ResolvedModelInfo(
                    model=effective.id,
                    base_url=base_url,
                    api_key=api_key,
                    provider_id=provider_id,
                    provider_name=provider_def.name,
                    name=effective.name,
                    context_window=effective.context_window,
                    max_tokens=effective.max_tokens,
                    reasoning=effective.reasoning,
                    input=list(effective.input) if effective.input else None,
                    cost=effective.cost,
                )
            )
        # Process remaining extra_models (truly user-added, not overrides)
        for model in extra_by_id.values():
            if not model.enabled:
                continue
            resolved.append(
                ResolvedModelInfo(
                    model=model.id,
                    base_url=base_url,
                    api_key=api_key,
                    provider_id=provider_id,
                    provider_name=provider_def.name,
                    name=model.name,
                    context_window=model.context_window,
                    max_tokens=model.max_tokens,
                    reasoning=model.reasoning,
                    input=list(model.input) if model.input else None,
                    cost=model.cost,
                )
            )

    for provider_id, entry in data.providers.items():
        if not entry.is_custom:
            continue
        provider_def = PROVIDERS.get(provider_id)
        if provider_def is None or not data.is_configured(provider_def):
            continue

        base_url, api_key = data.get_credentials(provider_id)
        if not base_url:
            base_url = provider_def.default_base_url
        for model in entry.models:
            if not model.enabled:
                continue
            resolved.append(
                ResolvedModelInfo(
                    model=model.id,
                    base_url=base_url,
                    api_key=api_key,
                    provider_id=provider_id,
                    provider_name=provider_def.name,
                    name=model.name,
                    context_window=model.context_window,
                    max_tokens=model.max_tokens,
                    reasoning=model.reasoning,
                    input=list(model.input) if model.input else None,
                    cost=model.cost,
                )
            )

    return resolved


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def mask_api_key(api_key: str, visible_chars: int = 4) -> str:
    if not api_key:
        return ""
    if len(api_key) <= visible_chars:
        return "*" * len(api_key)
    prefix = api_key[:3] if len(api_key) > 3 else ""
    suffix = api_key[-visible_chars:]
    hidden_len = len(api_key) - len(prefix) - visible_chars
    return f"{prefix}{'*' * max(hidden_len, 4)}{suffix}"


# ---------------------------------------------------------------------------
# Custom provider CRUD
# ---------------------------------------------------------------------------


def create_custom_provider(
    provider_id: str,
    name: str,
    *,
    default_base_url: str = "",
    api_key_prefix: str = "",
    api_key: str = "",
    models: Optional[list[ModelInfo]] = None,
) -> ProvidersData:
    err = validate_custom_provider_id(provider_id)
    if err:
        raise ValueError(err)

    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models

    if provider_id in data.providers and data.providers[provider_id].is_custom:
        raise ValueError(f"Custom provider '{provider_id}' already exists.")

    entry = ProviderEntry(
        base_url=default_base_url,
        api_key=api_key,
        name=name,
        default_base_url=default_base_url or None,
        api_key_prefix=api_key_prefix or None,
        is_custom=True,
        models=models or [],
    )
    data.providers[provider_id] = entry
    register_custom_provider(_entry_to_custom_data(provider_id, entry))
    _save_config_and_invalidate(config)
    return data


def delete_custom_provider(provider_id: str) -> ProvidersData:
    if is_builtin(provider_id):
        raise ValueError(f"Cannot delete built-in provider '{provider_id}'.")

    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models
    entry = data.providers.get(provider_id)
    if entry is None or not entry.is_custom:
        raise ValueError(f"Custom provider '{provider_id}' not found.")

    del data.providers[provider_id]
    unregister_custom_provider(provider_id)

    pid, _ = data.parse_active_llm()
    if pid == provider_id:
        data.active_llm = ""

    _save_config_and_invalidate(config)
    return data


def add_model(provider_id: str, model: ModelInfo) -> ProvidersData:
    defn = PROVIDERS.get(provider_id)
    if defn is None:
        raise ValueError(f"Provider '{provider_id}' not found.")

    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models

    if is_builtin(provider_id):
        if provider_id == "ollama":
            raise ValueError(
                "Cannot add models to built-in provider 'ollama'. "
                "Ollama models are managed by the Ollama daemon itself.",
            )
        entry = data.providers.setdefault(
            provider_id,
            ProviderEntry(base_url=defn.default_base_url),
        )
        all_ids = {m.id for m in defn.models} | {m.id for m in entry.extra_models}
        if model.id in all_ids:
            raise ValueError(
                f"Model '{model.id}' already exists in provider '{provider_id}'.",
            )
        entry.extra_models.append(model)
    else:
        entry = data.providers.get(provider_id)
        if entry is None or not entry.is_custom:
            raise ValueError(f"Custom provider '{provider_id}' not found.")
        if any(m.id == model.id for m in entry.models):
            raise ValueError(
                f"Model '{model.id}' already exists in provider '{provider_id}'.",
            )
        entry.models.append(model)
        register_custom_provider(_entry_to_custom_data(provider_id, entry))

    _save_config_and_invalidate(config)
    return data


def remove_model(provider_id: str, model_id: str) -> ProvidersData:
    defn = PROVIDERS.get(provider_id)
    if defn is None:
        raise ValueError(f"Provider '{provider_id}' not found.")

    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models

    if is_builtin(provider_id):
        if provider_id == "ollama":
            raise ValueError(
                "Cannot remove models from built-in provider 'ollama'. "
                "Ollama models are managed by the Ollama daemon itself.",
            )
        if any(m.id == model_id for m in defn.models):
            raise ValueError(
                f"Model '{model_id}' is a built-in model of "
                f"'{provider_id}' and cannot be removed.",
            )
        entry = data.providers.get(provider_id)
        if entry is None:
            raise ValueError(
                f"Model '{model_id}' not found in provider '{provider_id}'.",
            )
        original_len = len(entry.extra_models)
        entry.extra_models = [m for m in entry.extra_models if m.id != model_id]
        if len(entry.extra_models) == original_len:
            raise ValueError(
                f"Model '{model_id}' not found in provider '{provider_id}'.",
            )
    else:
        entry = data.providers.get(provider_id)
        if entry is None or not entry.is_custom:
            raise ValueError(f"Custom provider '{provider_id}' not found.")
        original_len = len(entry.models)
        entry.models = [m for m in entry.models if m.id != model_id]
        if len(entry.models) == original_len:
            raise ValueError(
                f"Model '{model_id}' not found in provider '{provider_id}'.",
            )
        register_custom_provider(_entry_to_custom_data(provider_id, entry))

    pid_active, model_active = data.parse_active_llm()
    if pid_active == provider_id and model_active == model_id:
        data.active_llm = ""

    _save_config_and_invalidate(config)
    return data


def toggle_model_enabled(
    provider_id: str, model_id: str, enabled: bool
) -> ProvidersData:
    """Toggle the enabled state of a model.

    For built-in providers, the model may be in the built-in list or in
    extra_models.  For built-in models we persist the enabled override in
    extra_models (by cloning the model with enabled=False).
    For custom providers, the model is in entry.models.
    """
    defn = PROVIDERS.get(provider_id)
    if defn is None:
        raise ValueError(f"Provider '{provider_id}' not found.")

    from ..config.utils import load_config  # noqa: PLC0415

    config = load_config()
    data = config.models

    if is_builtin(provider_id):
        entry = data.providers.get(provider_id)
        if entry is None:
            entry = ProviderEntry(base_url=defn.default_base_url)
            data.providers[provider_id] = entry

        # Check extra_models first
        for m in entry.extra_models:
            if m.id == model_id:
                m.enabled = enabled
                # If disabling the active model, clear active_llm
                if not enabled:
                    pid_active, model_active = data.parse_active_llm()
                    if pid_active == provider_id and model_active == model_id:
                        data.active_llm = ""
                _save_config_and_invalidate(config)
                return data

        # Check built-in models
        builtin_model = next((m for m in defn.models if m.id == model_id), None)
        if builtin_model is not None:
            # For built-in models, we store an override in extra_models
            # with the enabled field set
            override = ModelInfo(
                id=builtin_model.id,
                name=builtin_model.name,
                enabled=enabled,
                context_window=builtin_model.context_window,
                max_tokens=builtin_model.max_tokens,
                reasoning=builtin_model.reasoning,
                input=list(builtin_model.input) if builtin_model.input else None,
                cost=builtin_model.cost,
            )
            entry.extra_models.append(override)
            if not enabled:
                pid_active, model_active = data.parse_active_llm()
                if pid_active == provider_id and model_active == model_id:
                    data.active_llm = ""
            _save_config_and_invalidate(config)
            return data

        raise ValueError(
            f"Model '{model_id}' not found in provider '{provider_id}'.",
        )
    else:
        entry = data.providers.get(provider_id)
        if entry is None or not entry.is_custom:
            raise ValueError(f"Custom provider '{provider_id}' not found.")
        for m in entry.models:
            if m.id == model_id:
                m.enabled = enabled
                if not enabled:
                    pid_active, model_active = data.parse_active_llm()
                    if pid_active == provider_id and model_active == model_id:
                        data.active_llm = ""
                register_custom_provider(_entry_to_custom_data(provider_id, entry))
                _save_config_and_invalidate(config)
                return data
        raise ValueError(
            f"Model '{model_id}' not found in provider '{provider_id}'.",
        )
