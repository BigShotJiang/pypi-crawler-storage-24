# -*- coding: utf-8 -*-
"""lightclaw update — check for a newer release on PyPI and upgrade if needed."""

from __future__ import annotations

import subprocess
import sys
from typing import Optional

import click


_PACKAGE_NAME = "lightclaw"
_PYPI_URL = f"https://pypi.org/pypi/{_PACKAGE_NAME}/json"


def _get_installed_version(python_exe: Optional[str] = None) -> Optional[str]:
    """Query the installed version by spawning a fresh interpreter.

    Because importlib.metadata caches metadata for the lifetime of the current
    process, calling it after an in-process upgrade still returns the old
    version.  Spawning a subprocess with the target interpreter bypasses the
    cache and always reflects what is on disk.
    """
    exe = python_exe or sys.executable
    try:
        result = subprocess.run(
            [
                exe,
                "-c",
                f"from importlib.metadata import version; print(version({_PACKAGE_NAME!r}))",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except Exception:  # noqa: BLE001
        pass
    return None


def _get_local_version() -> str:
    """Return the currently installed package version.

    Prefer importlib.metadata so the version reflects what is actually
    installed on disk rather than the in-process source tree (important
    when the package is installed in editable mode).
    """
    try:
        from importlib.metadata import version

        return version(_PACKAGE_NAME)
    except Exception:  # noqa: BLE001
        from ..__version__ import __version__

        return __version__


def _get_pypi_version(timeout: int = 10) -> Optional[str]:
    """Fetch the latest version string from PyPI. Returns None on failure."""
    import json
    import urllib.error
    import urllib.request

    try:
        req = urllib.request.Request(
            _PYPI_URL,
            headers={"User-Agent": f"{_PACKAGE_NAME}-updater/1.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["info"]["version"]
    except urllib.error.URLError as exc:
        click.echo(
            click.style(f"Network error while checking PyPI: {exc}", fg="yellow"),
            err=True,
        )
    except Exception as exc:  # noqa: BLE001
        click.echo(
            click.style(f"Failed to fetch version from PyPI: {exc}", fg="yellow"),
            err=True,
        )
    return None


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple, ignoring non-numeric parts."""
    parts = []
    for segment in v.split("."):
        # Strip pre-release suffixes (a, b, rc, post, dev …)
        numeric = ""
        for ch in segment:
            if ch.isdigit():
                numeric += ch
            else:
                break
        try:
            parts.append(int(numeric))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _is_newer(remote: str, local: str) -> bool:
    """Return True if *remote* is strictly newer than *local*."""
    return _parse_version(remote) > _parse_version(local)


def _get_editable_path() -> Optional[str]:
    """Return the source directory path if installed in editable mode, else None."""
    try:
        import importlib.metadata as meta
        import json

        dist = meta.distribution(_PACKAGE_NAME)
        direct_url = dist.read_text("direct_url.json")
        if direct_url:
            info = json.loads(direct_url)
            if info.get("dir_info", {}).get("editable", False):
                return info.get("url", "").replace("file://", "") or None
    except Exception:  # noqa: BLE001
        pass
    return None


def _get_venv_python() -> Optional[str]:
    """Return the Python executable of the current venv, if running inside one.

    When installed via install.sh the process runs inside ~/.lightclaw/venv.
    Returning sys.executable (which already points to the venv interpreter)
    lets uv / pip upgrade the package in the correct environment without
    needing --system or --break-system-packages.
    """
    import os

    # sys.prefix != sys.base_prefix  →  we are inside a virtual environment
    if sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        return sys.executable

    # Also honour the VIRTUAL_ENV env-var (set by the wrapper script or shell)
    venv = os.environ.get("VIRTUAL_ENV", "")
    if venv:
        python = os.path.join(venv, "bin", "python")
        if os.path.isfile(python):
            return python

    return None


def _detect_installer() -> str:
    """Detect whether the package was installed via uv or pip."""
    import shutil

    if shutil.which("uv"):
        return "uv"
    return "pip"


def _run_upgrade(installer: str, verbose: bool) -> bool:
    """Run the upgrade command and return True on success."""
    venv_python = _get_venv_python()

    if installer == "uv":
        if venv_python:
            # Install into the active venv by passing its Python interpreter.
            # This is the normal path for installs done via install.sh.
            cmd = [
                "uv",
                "pip",
                "install",
                "--python",
                venv_python,
                "--upgrade",
                _PACKAGE_NAME,
            ]
        else:
            # Fallback: no venv detected — install into the system Python.
            cmd = [
                "uv",
                "pip",
                "install",
                "--system",
                "--break-system-packages",
                "--upgrade",
                _PACKAGE_NAME,
            ]
    else:
        # pip always installs into the environment of the running interpreter.
        cmd = [
            venv_python or sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade",
            _PACKAGE_NAME,
        ]

    click.echo(f"Running: {' '.join(cmd)}")
    result = subprocess.run(
        cmd,
        check=False,
        capture_output=not verbose,
        text=True,
    )
    if result.returncode != 0:
        if not verbose and result.stderr:
            click.echo(result.stderr, err=True)
        return False
    if verbose and result.stdout:
        click.echo(result.stdout)
    return True


@click.command("update")
@click.option(
    "--check",
    "check_only",
    is_flag=True,
    default=False,
    help="Only check for a newer version; do not install.",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt and upgrade immediately.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show full installer output.",
)
def update_cmd(check_only: bool, yes: bool, verbose: bool) -> None:
    """Check PyPI for a newer version and upgrade if available.

    \b
    Examples:
      lightclaw update              # interactive upgrade
      lightclaw update --check      # print version info, no install
      lightclaw update --yes        # non-interactive upgrade
    """
    local_ver = _get_local_version()
    click.echo(f"Current version : {click.style(local_ver, bold=True)}")
    click.echo("Checking PyPI for latest version …")

    remote_ver = _get_pypi_version()
    if remote_ver is None:
        click.echo(click.style("Could not determine the latest version.", fg="red"))
        raise SystemExit(1)

    click.echo(f"Latest version  : {click.style(remote_ver, bold=True)}")

    if not _is_newer(remote_ver, local_ver):
        click.echo(
            click.style(
                f"\n{_PACKAGE_NAME} {local_ver} is already up to date.",
                fg="green",
            )
        )
        return

    click.echo(
        click.style(
            f"\nNew version available: {local_ver} → {remote_ver}",
            fg="cyan",
        )
    )

    if check_only:
        click.echo(
            "Run `lightclaw update` (without --check) to install the new version."
        )
        return

    # Editable installs: upgrading via pip/uv would install a separate copy in
    # site-packages while the entry-point still runs from the source checkout.
    # Guide the user to use git instead, which is the correct workflow.
    editable_path = _get_editable_path()
    if editable_path:
        click.echo(
            click.style(
                f"\nThis installation is running from source ({editable_path}).",
                fg="yellow",
            )
        )
        click.echo(
            "To upgrade a source / editable install, pull the latest code:\n"
            f"  cd {editable_path} && git pull"
        )
        return

    if not yes:
        ok = click.confirm(
            f"Upgrade {_PACKAGE_NAME} to {remote_ver}?",
            default=True,
        )
        if not ok:
            click.echo("Upgrade cancelled.")
            return

    installer = _detect_installer()
    click.echo(f"Using installer  : {installer}")

    success = _run_upgrade(installer, verbose)
    if success:
        # Verify by spawning a fresh interpreter — importlib.metadata caches
        # the old version for the lifetime of this process, so we cannot rely
        # on calling it directly after the upgrade.
        venv_python = _get_venv_python()
        actual_ver = _get_installed_version(venv_python)
        if actual_ver and actual_ver == remote_ver:
            click.echo(
                click.style(
                    f"\n{_PACKAGE_NAME} successfully upgraded to {actual_ver}.",
                    fg="green",
                )
            )
        elif actual_ver and _is_newer(actual_ver, local_ver):
            # Upgraded, but to a different version than expected (e.g. pre-release)
            click.echo(
                click.style(
                    f"\n{_PACKAGE_NAME} upgraded to {actual_ver}.",
                    fg="green",
                )
            )
        elif actual_ver == local_ver:
            # Installer reported success but version did not change
            click.echo(
                click.style(
                    f"\nWarning: upgrade reported success but version is still "
                    f"{actual_ver}. You may need to restart your shell.",
                    fg="yellow",
                )
            )
        else:
            # Could not verify — trust the installer exit code
            click.echo(
                click.style(
                    f"\n{_PACKAGE_NAME} successfully upgraded to {remote_ver}.",
                    fg="green",
                )
            )
        click.echo("Please restart lightclaw for the changes to take effect.")
    else:
        click.echo(
            click.style(
                "\nUpgrade failed. Check the output above for details.", fg="red"
            )
        )
        raise SystemExit(1)
