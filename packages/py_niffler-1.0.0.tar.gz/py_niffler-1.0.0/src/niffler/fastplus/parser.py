import importlib.resources as import_resources
from pathlib import Path
from typing import Sequence

from lark import Lark, Token, Transformer, v_args

from .node import (
    Alpha,
    Assignment,
    BinaryArithmetic,
    Constant,
    FastPlusExpression,
    Operation,
    Variable,
)


@v_args(inline=True)
class FastPlusTransformer(Transformer):
    """FastPlus 语法解析器"""

    def VARIABLE(self, t: Token) -> str:
        return str(t)

    def NUMBER(self, t: Token):
        s = str(t)
        if "e" in s.lower() or "." in s:
            return Constant(value=float(s))
        try:
            return Constant(value=int(s))
        except ValueError:
            return Constant(value=float(s))

    def DQUOTE_STRING(self, t: Token):
        s = str(t)
        return Constant(value=s[1:-1] if len(s) >= 2 else "")

    def SINGLE_STRING(self, t: Token):
        s = str(t)
        return Constant(value=s[1:-1] if len(s) >= 2 else "")

    def start(self, alpha: Alpha) -> Alpha:
        return alpha

    def signal(self, expr: FastPlusExpression):
        return expr

    def alpha(self, *children):
        if len(children) == 1:
            return Alpha(assignments=[], signal=children[0])

        assignment, rest = children[0], children[1]
        return Alpha(assignments=[assignment] + rest.assignments, signal=rest.signal)

    def assignment(self, var: Variable, expr: FastPlusExpression):
        # check
        if isinstance(expr, Constant):
            raise ValueError("常数不可作为赋值的值")
        return Assignment(variable=str(var), value=expr)

    def unary_plus(self, expr: FastPlusExpression):
        return expr

    def unary_minus(self, expr: FastPlusExpression):
        return Operation(op="reverse", positional_args=[expr])

    def ne(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("!=", left, right)

    def eq(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("==", left, right)

    def ge(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic(">=", left, right)

    def le(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("<=", left, right)

    def gt(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic(">", left, right)

    def lt(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("<", left, right)

    def add(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("+", left, right)

    def sub(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("-", left, right)

    def mul(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("*", left, right)

    def div(self, left: FastPlusExpression, right: FastPlusExpression):
        return BinaryArithmetic("/", left, right)

    def term(self, *children: Token | str | FastPlusExpression):
        if len(children) == 3:
            return children[1]  # "(" expr ")" -> expr
        x = children[0]
        if isinstance(x, Token):
            return Variable(str(x))
        if isinstance(x, str):
            return Variable(x)
        return x

    def expression(self, x: FastPlusExpression):
        return x

    def operation(
        self, op: Token, args: tuple[list[FastPlusExpression], list[tuple[str, FastPlusExpression]]]
    ):
        pos, kw = args
        return Operation(op=str(op), positional_args=list(pos), keyword_args=list(kw))

    def keyword_arg(self, name: str, expr: FastPlusExpression):
        return (str(name), expr)

    def positional_arg(self, expr: FastPlusExpression):
        return expr

    def args(self, *children: Sequence[Token | tuple]):
        positionals = []
        keywords = []
        for c in children:
            if isinstance(c, tuple):
                if len(c) == 2:
                    keywords.append(c)
                else:
                    positionals.append(c[0])
            else:
                positionals.append(c)
        return (positionals, keywords)


class FastPlusParser:
    def __init__(self, grammar_file: Path | str | None = None) -> None:
        if grammar_file is None:
            grammar_content = (
                import_resources.files(__package__).joinpath("fastplus.lark").read_text(encoding="utf-8")
            )
        else:
            grammar_file = Path(grammar_file)
            if not grammar_file.exists():
                raise FileNotFoundError(grammar_file)
            grammar_content = grammar_file.read_text(encoding="utf-8")

        self._parser = Lark(grammar_content, parser="lalr")
        self._transformer = FastPlusTransformer()

    def parse(self, source: str) -> Alpha:
        tree = self._parser.parse(source)
        alpha = self._transformer.transform(tree)
        return alpha
