from __future__ import annotations

import copy
from abc import abstractmethod
from dataclasses import dataclass, field
from typing import Self

from .operators import OP_SIGNATURES, ParamType


@dataclass
class FastPlusExpression:
    @abstractmethod
    def to_expr(self) -> str:
        raise NotImplementedError

    def copy(self) -> Self:
        """深拷贝当前节点及其所有子节点。"""
        return copy.deepcopy(self)

    def _remove_unary_op(self, op: str) -> Self:
        expr = self.copy()
        match expr:
            case Alpha(assignments=_assignments, signal=_signal):
                expr.assignments = [assignment._remove_unary_op(op) for assignment in _assignments]
                expr.signal = _signal._remove_unary_op(op)
            case Assignment(variable=_, value=_value):
                expr.value = _value._remove_unary_op(op)
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_key_args):
                if _op == op:
                    expr = _pos_args[0]
                else:
                    expr.positional_args = [_p._remove_unary_op(op) for _p in _pos_args]
            case BinaryArithmetic(op=_, left=_left, right=_right):
                expr.left = _left._remove_unary_op(op)
                expr.right = _right._remove_unary_op(op)
            case _:
                pass
        return expr

    def replace_lookback(self, days: int, op: str | list[str] | None = None) -> Self:
        expr = self.copy()
        if op is None:
            ops = None
        elif isinstance(op, str):
            ops = [op]
        else:
            ops = op
        match expr:
            case Alpha(assignments=_assignments, signal=_signal):
                expr.assignments = [assignment.replace_lookback(days, ops) for assignment in _assignments]
                expr.signal = _signal.replace_lookback(days, ops)
            case Assignment(variable=_, value=_value):
                expr.value = _value.replace_lookback(days, ops)
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_key_args):
                if _op in ["ts_corr", "ts_regression"] and (ops is None or _op in ops):
                    # 二元运算符 op(x, y, lookback)
                    expr.positional_args[2] = Constant(days)
                    expr.positional_args[0] = expr.positional_args[0].replace_lookback(days, ops)
                    expr.positional_args[1] = expr.positional_args[1].replace_lookback(days, ops)
                elif _op in ["ts_step", "ts_target_tvr_decay", "ts_target_tvr_hump"]:
                    # 没有 lookback 参数
                    pass
                elif _op.startswith("ts_") and (ops is None or _op in ops):
                    # 一元运算符 op(x, lookback)
                    expr.positional_args[1] = Constant(days)
                    expr.positional_args[0] = expr.positional_args[0].replace_lookback(days, ops)
                else:
                    expr.positional_args = [_p.replace_lookback(days, ops) for _p in _pos_args]
            case BinaryArithmetic(op=_, left=_left, right=_right):
                expr.left = _left.replace_lookback(days, ops)
                expr.right = _right.replace_lookback(days, ops)
            case _:
                pass
        return expr

    def _collect_ops(self) -> list[str]:
        ops = []
        match self:
            case Alpha(assignments=_assignments, signal=_signal):
                for _assign in _assignments:
                    ops.extend(_assign._collect_ops())
                ops.extend(_signal._collect_ops())
            case Assignment(variable=_, value=_value):
                ops.extend(_value._collect_ops())
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_key_args):
                # FIXME
                ops.extend(_pos_args[0]._collect_ops())
                ops.append(_op)
            case BinaryArithmetic(op=_, left=_left, right=_right):
                # FIXME
                ops.extend(_left._collect_ops())
                ops.extend(_right._collect_ops())
            case _:
                pass
        return ops

    def replace_group(self, group: str, op: str | list[str] | None = None) -> Self:
        expr = self.copy()
        if op is None:
            ops = None
        elif isinstance(op, str):
            ops = [op]
        else:
            ops = op
        match expr:
            case Alpha(assignments=_assignments, signal=_signal):
                expr.assignments = [assignment.replace_group(group, ops) for assignment in _assignments]
                expr.signal = _signal.replace_group(group, ops)
            case Assignment(variable=_, value=_value):
                expr.value = _value.replace_group(group, ops)
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_key_args):
                if (_op == "group_backfill") and (ops is None or _op in ops):
                    # group_backfill(x, group, d, std = 4.0)
                    expr.positional_args[1] = Variable(group)
                elif _op == "group_cartesian_product":
                    # group_cartesian_product(g1, g2)
                    pass
                elif _op.startswith("group_") and (ops is None or _op in ops):
                    expr.positional_args[-1] = Variable(group)
                else:
                    expr.positional_args = [_p.replace_group(group, ops) for _p in _pos_args]
            case BinaryArithmetic(op=_, left=_left, right=_right):
                expr.left = _left.replace_group(group, ops)
                expr.right = _right.replace_group(group, ops)
            case _:
                pass
        return expr

    def _collect_variables(self) -> list[str]:
        variables = []
        match self:
            case Alpha(assignments=_assignments, signal=_):
                for _assign in _assignments:
                    variables.extend(_assign._collect_variables())
            case Assignment(variable=_variable, value=_):
                variables.append(_variable)
            case _:
                pass
        return list(set(variables))

    def _collect_fields(self) -> list[str]:
        fields = []
        match self:
            case Alpha(assignments=_assignments, signal=_signal):
                for _assign in _assignments:
                    fields.extend(_assign._collect_fields())
                fields.extend(_signal._collect_fields())
            case Assignment(variable=_, value=_value):
                fields.extend(_value._collect_fields())
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_):
                if _op.startswith("vec_"):
                    _fields = [_arg.to_expr() for _arg in _pos_args]
                    # 所有的 vec_ 都是单元操作符, 如果发生多元必然有误
                    fields.append("|".join(_fields))
                else:
                    for arg in _pos_args:
                        fields.extend(arg._collect_fields())
            case BinaryArithmetic(op=_, left=_left, right=_right):
                fields.extend(_left._collect_fields())
                fields.extend(_right._collect_fields())
            case Variable(name=_name):
                fields.append(_name)
        return list(set(fields))

    def _collect_group_fields(self) -> list[str]:
        fields = []
        match self:
            case Alpha(assignments=_assignments, signal=_signal):
                for _assign in _assignments:
                    fields.extend(_assign._collect_group_fields())
                fields.extend(_signal._collect_group_fields())
            case Assignment(variable=_, value=_value):
                fields.extend(_value._collect_group_fields())
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_):
                if _op == "group_backfill":
                    # group_backfill(x, group, d, std = 4.0)
                    fields.append(_pos_args[1].to_expr())
                elif _op == "group_cartesian_product":
                    # group_cartesian_product(g1, g2)
                    fields.append(_pos_args[0].to_expr())
                    fields.append(_pos_args[1].to_expr())
                elif _op.startswith("group_"):
                    fields.append(_pos_args[-1].to_expr())
                else:
                    for arg in _pos_args:
                        fields.extend(arg._collect_group_fields())
            case BinaryArithmetic(op=_, left=_left, right=_right):
                fields.extend(_left._collect_group_fields())
                fields.extend(_right._collect_group_fields())
            case _:
                pass
        return list(set(fields))

    def _collect_vector_fields(self) -> list[str]:
        fields = []
        match self:
            case Alpha(assignments=_assignments, signal=_signal):
                for _assign in _assignments:
                    fields.extend(_assign._collect_vector_fields())
                fields.extend(_signal._collect_vector_fields())
            case Assignment(variable=_, value=_value):
                fields.extend(_value._collect_vector_fields())
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_):
                if _op.startswith("vec_"):
                    _fields = [_arg.to_expr() for _arg in _pos_args]
                    # 所有的 vec_ 都是单元操作符, 如果发生多元必然有误
                    fields.append("|".join(_fields))
                else:
                    for arg in _pos_args:
                        fields.extend(arg._collect_vector_fields())
            case BinaryArithmetic(op=_, left=_left, right=_right):
                fields.extend(_left._collect_vector_fields())
                fields.extend(_right._collect_vector_fields())
            case _:
                pass
        return list(set(fields))

    def _check_ops(self) -> list[str]:
        errors = []
        match self:
            case Alpha(assignments=_assignments, signal=_signal):
                for _assign in _assignments:
                    errors.extend(_assign._check_ops())
                errors.extend(_signal._check_ops())
            case Assignment(variable=_, value=_value):
                errors.extend(_value._check_ops())
            case Operation(op=_op, positional_args=_pos_args, keyword_args=_key_args):
                sig = OP_SIGNATURES.get(_op)
                if not sig:
                    errors.append(f"未知操作符: {_op}")
                else:
                    # 检查位置参数个数
                    if sig.nary == -1:
                        if len(_pos_args) < 2:
                            errors.append(f"操作符 {_op} 至少需要 2 个位置参数，当前 {len(_pos_args)} 个")
                    elif len(_pos_args) != sig.nary:
                        errors.append(f"操作符 {_op} 需要 {sig.nary} 个位置参数，当前 {len(_pos_args)} 个")
                    # TODO: 检查位置参数类型
                    for _args in _pos_args:
                        errors.extend(_args._check_ops())

                    # 检查关键字参数
                    for kw_name, kw_value in _key_args:
                        spec = sig.get_keyword_spec(kw_name)
                        if spec is None:
                            errors.append(f"未知关键字参数: {_op}(..., {kw_name}=?)")
                            continue

                        # 特殊情况处理: driver 参数可以不加字符串, 可能会被识别为变量
                        _driver_constants = ["gaussian", "uniform", "cauchy"]
                        if spec.name == "driver":
                            if isinstance(kw_value, Variable) and kw_value.name not in _driver_constants:
                                errors.append(
                                    f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前为 {type(kw_value)}({kw_value.name})"
                                )
                                continue
                            if isinstance(kw_value, Constant) and kw_value.value not in _driver_constants:
                                errors.append(
                                    f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前常量为 {kw_value.value}"
                                )
                                continue

                        # 特殊情况处理: boolean 只能为 true or false, 会被解析为变量
                        elif spec.param_type[0] == ParamType.BOOLEAN:
                            if isinstance(kw_value, Variable) and kw_value.name not in ["true", "false"]:
                                errors.append(
                                    f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前为 {type(kw_value)}({kw_value.name})"
                                )
                                continue
                            elif isinstance(kw_value, Constant):
                                errors.append(
                                    f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前常量为 {kw_value.value}"
                                )
                                continue

                        elif isinstance(kw_value, Constant) and not spec.check_keyword_constant(
                            kw_value.value
                        ):
                            errors.append(
                                f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前常量为 {kw_value.value}"
                            )
                        elif isinstance(kw_value, Variable):
                            errors.append(
                                f"关键字参数 {_op}(..., {kw_name}=?) 应为 {spec.param_type}，当前解析异常 {type(kw_value)}({kw_value.to_expr()})"
                            )

            case BinaryArithmetic(op=_, left=_left, right=_right):
                errors.extend(_left._check_ops())
                errors.extend(_right._check_ops())
            case _:
                pass

        return errors


@dataclass
class Assignment(FastPlusExpression):
    """Assignment 赋值语句"""

    variable: str
    value: FastPlusExpression

    def to_expr(self) -> str:
        return f"{self.variable} = {self.value.to_expr()};"


@dataclass
class Variable(FastPlusExpression):
    """Variable 变量引用"""

    name: str

    def to_expr(self) -> str:
        return self.name


@dataclass
class Constant(FastPlusExpression):
    """Constant 常量"""

    value: int | float | str | bool

    def to_expr(self) -> str:
        match self.value:
            case str(v):
                return '"' + v + '"'
            case float(v):
                return format(v, ".15f").rstrip("0").rstrip(".") if "e" in str(v).lower() else repr(v)
            case bool(v):
                return "true" if v else "false"
            case _:
                return repr(self.value)


@dataclass
class Operation(FastPlusExpression):
    """Operation 算子运算 op(*args, **kwargs)"""

    op: str
    positional_args: list[FastPlusExpression] = field(default_factory=list)
    keyword_args: list[tuple[str, FastPlusExpression]] = field(default_factory=list)

    def to_expr(self) -> str:
        parts = [a.to_expr() for a in self.positional_args]
        parts.extend(f"{k}={v.to_expr()}" for k, v in self.keyword_args)
        return f"{self.op}({', '.join(parts)})"


@dataclass
class BinaryArithmetic(FastPlusExpression):
    """二元算术表达式"""

    op: str
    left: FastPlusExpression
    right: FastPlusExpression

    def to_expr(self) -> str:
        return f"{self.left.to_expr()} {self.op} {self.right.to_expr()}"


@dataclass
class Alpha(FastPlusExpression):
    """Alpha 程序：赋值序列 + 信号表达式"""

    assignments: list[Assignment]
    signal: FastPlusExpression

    def to_expr(self) -> str:
        assignments_expr = [a.to_expr() for a in self.assignments]
        signal_expr = self.signal.to_expr()
        return "\n".join(assignments_expr + [signal_expr])

    def remove_winsorize(self) -> Self:
        return self._remove_unary_op("winsorize")

    def remove_ts_backfill(self) -> Self:
        return self._remove_unary_op("ts_backfill")

    def get_group_ops(self) -> list[str]:
        ops_all = self._collect_ops()
        return [op for op in ops_all if op.startswith("group_")]

    def get_ts_ops(self) -> list[str]:
        ops_all = self._collect_ops()
        return [op for op in ops_all if op.startswith("ts_")]

    def get_fields(self) -> dict:
        fields = self._collect_fields()
        variables = self._collect_variables()
        fields = [f for f in fields if f not in variables]
        fields_group = self._collect_group_fields()
        fields_vector = self._collect_vector_fields()
        fields_matrix = [f for f in fields if f not in fields_group and f not in fields_vector]
        return {
            "GROUP": fields_group,
            "VECTOR": fields_vector,
            "MATRIX": fields_matrix,
        }
