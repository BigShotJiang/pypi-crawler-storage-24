"""FastPlus 语法解析"""

from .parser import FastPlusParser

__all__ = ["FastPlusParser"]
