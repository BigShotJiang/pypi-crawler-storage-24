from dataclasses import dataclass
from enum import StrEnum


class ParamType(StrEnum):
    """参数类型

    所有的 NUMBER 也是 MATRIX 的一种
    """

    MATRIX = "MATRIX"
    VECTOR = "VECTOR"
    GROUP = "GROUP"
    NUMBER = "NUMBER"
    INT = "INT"
    POSITIVE_INT = "POSITIVE_INT"
    NON_NEGATIVE_INT = "NON_NEGATIVE_INT"
    STRING = "STRING"
    BOOLEAN = "BOOLEAN"


@dataclass
class ParamSpec:
    """参数规范"""

    name: str
    param_type: list[ParamType]
    default_value: str | int | float | bool | None = None

    def check_keyword_constant(self, value: str | int | float | bool) -> bool:
        match self.param_type[0]:
            case ParamType.MATRIX:
                return isinstance(value, int | float)
            case ParamType.VECTOR:
                return False
            case ParamType.GROUP:
                return False
            case ParamType.NUMBER:
                return isinstance(value, int | float)
            case ParamType.INT:
                return isinstance(value, int)
            case ParamType.POSITIVE_INT:
                return isinstance(value, int) and value > 0
            case ParamType.NON_NEGATIVE_INT:
                return isinstance(value, int) and value >= 0
            case ParamType.STRING:
                return isinstance(value, str)
            case ParamType.BOOLEAN:
                return isinstance(value, bool)
            case _:
                return False


@dataclass
class OperatorSignature:
    """算子签名

    nary : 表示算子的参数个数, -1 表示无穷多, 例如 max, min, add, multiply 等
    """

    name: str
    positional: list[ParamType]
    keyword: list[ParamSpec]
    nary: int
    description: str

    def get_keyword_spec(self, name: str) -> ParamSpec | None:
        for spec in self.keyword:
            if spec.name == name:
                return spec
        return None


OP_SIGNATURES: dict[str, OperatorSignature] = {
    # ---- Arithmetic ----
    "add": OperatorSignature(
        name="add",
        positional=[ParamType.MATRIX],
        keyword=[ParamSpec(name="filter", param_type=[ParamType.BOOLEAN], default_value=False)],
        nary=-1,
        description="Add all inputs (at least 2 inputs required). If filter = true, filter all input NaN to 0 before adding",
    ),
    "subtract": OperatorSignature(
        name="subtract",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[ParamSpec(name="filter", param_type=[ParamType.BOOLEAN], default_value=False)],
        nary=2,
        description="Subtracts inputs left to right. Supports two or more inputs. Set filter=true to treat NaNs as 0 before subtraction.",
    ),
    "multiply": OperatorSignature(
        name="multiply",
        positional=[ParamType.MATRIX],
        keyword=[ParamSpec(name="filter", param_type=[ParamType.BOOLEAN], default_value=False)],
        nary=-1,
        description="Multiplies two or more inputs element wise. Set filter=true to treat NaNs as 0 before multiplication",
    ),
    "divide": OperatorSignature(
        name="divide",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="x / y",
    ),
    "sign": OperatorSignature(
        name="sign",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Returns the sign of a number: +1 for positive, -1 for negative, and 0 for zero. If the input is NaN, returns NaN.",
    ),
    "abs": OperatorSignature(
        name="abs",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Returns the absolute value of a number, removing any negative sign.",
    ),
    "log": OperatorSignature(
        name="log",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Calculates the natural logarithm of the input value. Commonly used to transform data that has positive values.",
    ),
    "sqrt": OperatorSignature(
        name="sqrt",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Returns the non negative square root of x. Equivalent to power(x, 0.5); for signed roots use signed_power(x, 0.5).",
    ),
    "reverse": OperatorSignature(
        name="reverse",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="-x",
    ),
    "inverse": OperatorSignature(
        name="inverse",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="1 / x",
    ),
    "power": OperatorSignature(
        name="power",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="x ^ y",
    ),
    "signed_power": OperatorSignature(
        name="signed_power",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="x raised to the power of y such that final result preserves sign of x",
    ),
    "max": OperatorSignature(
        name="max",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=-1,
        description="Maximum value of all inputs. At least 2 inputs are required",
    ),
    "min": OperatorSignature(
        name="min",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=-1,
        description="Minimum value of all inputs. At least 2 inputs are required",
    ),
    "pasteurize": OperatorSignature(
        name="pasteurize",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Set to NaN if x is INF or if the underlying instrument is not in the Alpha universe. This operator may help reduce outliers.",
    ),
    "densify": OperatorSignature(
        name="densify",
        positional=[ParamType.GROUP],
        keyword=[],
        nary=1,
        description="Converts a grouping field of many buckets into lesser number of only available buckets so as to make working with grouping fields computationally efficient",
    ),
    # ---- Logical ----
    "and": OperatorSignature(
        name="and",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="Returns 1 ('true') if both inputs are 1 ('true'). Otherwise, returns 0 ('false').",
    ),
    "or": OperatorSignature(
        name="or",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="Returns 1 if either input is true (either input1 or input2 has a value of 1), otherwise it returns 0.",
    ),
    "not": OperatorSignature(
        name="not",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Returns the logical negation of x. Returns 0 when x is 1 ('true') and 1 when x is 0 ('false').",
    ),
    "is_nan": OperatorSignature(
        name="is_nan",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="If (input == NaN) return 1 else return 0",
    ),
    "if_else": OperatorSignature(
        name="if_else",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=3,
        description="The if_else operator returns one of two values based on a condition. If the condition is true, it returns the first value; if false, it returns the second value.",
    ),
    # ---- Time Series ----
    "ts_corr": OperatorSignature(
        name="ts_corr",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=3,
        description="Calculates the Pearson correlation between two variables, x and y, over the past d days, showing how closely they move together.",
    ),
    "ts_zscore": OperatorSignature(
        name="ts_zscore",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Calculates the Z-score of a time series, showing how far today's value is from the recent average, measured in standard deviations.",
    ),
    "ts_sum": OperatorSignature(
        name="ts_sum",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Sum values of x for the past d days.",
    ),
    "ts_mean": OperatorSignature(
        name="ts_mean",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Calculates the simple average (mean) value of a variable x over the past d days.",
    ),
    "ts_delay": OperatorSignature(
        name="ts_delay",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns the value of a variable x from d days ago. Use this operator to access historical data points by specifying the desired time lag in days.",
    ),
    "ts_delta": OperatorSignature(
        name="ts_delta",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Calculates the difference between a value and its delayed version over a specified period. Useful for measuring changes or momentum in time-series data.",
    ),
    "ts_backfill": OperatorSignature(
        name="ts_backfill",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="k", param_type=[ParamType.INT], default_value=1)],
        nary=2,
        description="Replaces missing (NaN) values in a time series with the most recent valid value from a specified lookback window, improving data coverage and reducing risk from missing data.",
    ),
    "ts_rank": OperatorSignature(
        name="ts_rank",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="constant", param_type=[ParamType.INT], default_value=0)],
        nary=2,
        description="Ranks the value of a variable for each instrument over a specified number of past days, returning the rank of the current value (optionally adjusted by a constant).",
    ),
    "ts_scale": OperatorSignature(
        name="ts_scale",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="constant", param_type=[ParamType.INT], default_value=0)],
        nary=2,
        description="Scales a time series to a 0–1 range based on its minimum and maximum values over a specified period, with an optional constant shift.",
    ),
    # TODO: mode
    "ts_returns": OperatorSignature(
        name="ts_returns",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="mode", param_type=[ParamType.INT], default_value=1)],
        nary=2,
        description="Returns the relative change in the x value, mode can be 1 or 2",
    ),
    "ts_std_dev": OperatorSignature(
        name="ts_std_dev",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Calculates the standard deviation of a data series x over the past d days, measuring how much the values deviate from their mean during that period.",
    ),
    "ts_product": OperatorSignature(
        name="ts_product",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns the product of the values of x over the past d days. Useful for calculating geometric means and compounding returns or growth rates.",
    ),
    "ts_decay_linear": OperatorSignature(
        name="ts_decay_linear",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="dense", param_type=[ParamType.BOOLEAN], default_value=False)],
        nary=2,
        description="Applies a linear decay to time-series data over a set number of days, smoothing the data by averaging recent values and reducing the impact of older or missing data.",
    ),
    # TODO: driver: gaussian, uniform, cauchy
    "ts_quantile": OperatorSignature(
        name="ts_quantile",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="driver", param_type=[ParamType.STRING], default_value="gaussian")],
        nary=2,
        description="Calculates the ts_rank of the input and transforms it using the inverse cumulative distribution function (quantile function) of a specified probability distribution (default: Gaussian/normal).",
    ),
    # TODO: regression
    "ts_regression": OperatorSignature(
        name="ts_regression",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[
            ParamSpec(name="lag", param_type=[ParamType.INT], default_value=0),
            ParamSpec(name="rettype", param_type=[ParamType.INT], default_value=0),
        ],
        nary=3,
        description="Returns various parameters related to regression function",
    ),
    "ts_covariance": OperatorSignature(
        name="ts_covariance",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=3,
        description="Calculates the covariance between two time-series variables, y and x, over the past d days. Useful for measuring how two variables move together within a specified historical window.",
    ),
    "ts_arg_max": OperatorSignature(
        name="ts_arg_max",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns the number of days since the maximum value occurred in the last d days of a time series. If today's value is the maximum, returns 0; if it was yesterday, returns 1, and so on.",
    ),
    "ts_arg_min": OperatorSignature(
        name="ts_arg_min",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns the number of days since the minimum value occurred in a time series over the past d days. If today's value is the minimum, returns 0; if it was yesterday, returns 1, and so on.",
    ),
    "ts_av_diff": OperatorSignature(
        name="ts_av_diff",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Calculates the difference between a value and its mean over a specified period, ignoring NaN values in the mean calculation. In short, it returns x – ts_mean(x, d) with NaNs ignored.",
    ),
    "ts_ir": OperatorSignature(
        name="ts_ir",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Return information ratio ts_mean(x, d) / ts_std_dev(x, d)",
    ),
    "ts_kurtosis": OperatorSignature(
        name="ts_kurtosis",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns kurtosis of x for the last d days",
    ),
    "ts_count_nans": OperatorSignature(
        name="ts_count_nans",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Counts the number of missing (NaN) values in a data series over a specified number of days.",
    ),
    "ts_max_diff": OperatorSignature(
        name="ts_max_diff",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns x - ts_max(x, d)",
    ),
    "days_from_last_change": OperatorSignature(
        name="days_from_last_change",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Calculates the number of days since the last change in the value of a given variable.",
    ),
    "last_diff_value": OperatorSignature(
        name="last_diff_value",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT],
        keyword=[],
        nary=2,
        description="Returns the most recent value of x from the past d days that is different from the current value of x.",
    ),
    "kth_element": OperatorSignature(
        name="kth_element",
        positional=[ParamType.MATRIX, ParamType.POSITIVE_INT, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="ignore", param_type=[ParamType.STRING], default_value="NaN")],
        nary=3,
        description="Returns the K-th value from a time series by looking back over a specified number of ('d') days, with the option to ignore certain values. Commonly used for backfilling missing data.",
    ),
    "hump": OperatorSignature(
        name="hump",
        positional=[ParamType.MATRIX],
        keyword=[ParamSpec(name="hump", param_type=[ParamType.NUMBER], default_value=0.01)],
        nary=1,
        description="Limits amount and magnitude of changes in input (thus reducing turnover)",
    ),
    "ts_step": OperatorSignature(
        name="ts_step",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Returns a counter of days, incrementing by one each day.",
    ),
    # ---- Cross Sectional ----
    "winsorize": OperatorSignature(
        name="winsorize",
        positional=[ParamType.MATRIX],
        keyword=[ParamSpec(name="std", param_type=[ParamType.POSITIVE_INT], default_value=4)],
        nary=1,
        description="Winsorizes x to make sure that all values in x are between the lower and upper limits, which are specified as multiple of std.",
    ),
    # TODO: rank
    "rank": OperatorSignature(
        name="rank",
        positional=[ParamType.MATRIX],
        keyword=[ParamSpec(name="rate", param_type=[ParamType.INT, ParamType.NUMBER], default_value=2)],
        nary=1,
        description="Ranks the input among all the instruments and returns an equally distributed number between 0.0 and 1.0. For precise sort, use the rate as 0",
    ),
    "zscore": OperatorSignature(
        name="zscore",
        positional=[ParamType.MATRIX],
        keyword=[],
        nary=1,
        description="Z-score is a numerical measurement that describes a value's relationship to the mean of a group of values. Z-score is measured in terms of standard deviations from the mean",
    ),
    # TODO: Scale
    "scale": OperatorSignature(
        name="scale",
        positional=[ParamType.MATRIX],
        keyword=[
            ParamSpec(name="scale", param_type=[ParamType.NUMBER, ParamType.INT], default_value=1),
            ParamSpec(name="longscale", param_type=[ParamType.NUMBER, ParamType.INT], default_value=1),
            ParamSpec(name="shortscale", param_type=[ParamType.NUMBER, ParamType.INT], default_value=1),
        ],
        nary=1,
        description="Scales input to booksize. We can also scale the long positions and short positions to separate scales by mentioning additional parameters to the operator",
    ),
    "normalize": OperatorSignature(
        name="normalize",
        positional=[ParamType.MATRIX, ParamType.VECTOR],
        keyword=[
            ParamSpec(name="useStd", param_type=[ParamType.BOOLEAN], default_value=False),
            ParamSpec(name="limit", param_type=[ParamType.NUMBER], default_value=0.0),
        ],
        nary=1,
        description="Calculates the mean value of all valid alpha values for a certain date, then subtracts that mean from each element",
    ),
    "quantile": OperatorSignature(
        name="quantile",
        positional=[ParamType.MATRIX],
        keyword=[
            ParamSpec(name="driver", param_type=[ParamType.STRING], default_value="gaussian"),
            ParamSpec(name="sigma", param_type=[ParamType.NUMBER], default_value=1.0),
        ],
        nary=1,
        description="Rank the raw vector, shift the ranked Alpha vector, apply distribution (gaussian, cauchy, uniform). If driver is uniform, it simply subtract each Alpha value with the mean of all Alpha values in the Alpha vector",
    ),
    "vector_neut": OperatorSignature(
        name="vector_neut",
        positional=[ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=2,
        description="For given vectors x and y, it finds a new vector x* (output) such that x* is orthogonal to y",
    ),
    # ---- Vector ----
    "vec_min": OperatorSignature(
        name="vec_min",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Minimum value from vector field x",
    ),
    "vec_max": OperatorSignature(
        name="vec_max",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Maximum value from vector field x",
    ),
    "vec_sum": OperatorSignature(
        name="vec_sum",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Sum of vector field x",
    ),
    "vec_avg": OperatorSignature(
        name="vec_avg",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Taking mean of the vector field x",
    ),
    "vec_count": OperatorSignature(
        name="vec_count",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Number of elements in vector field x",
    ),
    "vec_stddev": OperatorSignature(
        name="vec_stddev",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Standard Deviation of vector field x",
    ),
    "vec_range": OperatorSignature(
        name="vec_range",
        positional=[ParamType.VECTOR],
        keyword=[],
        nary=1,
        description="Difference between maximum and minimum element in vector field x",
    ),
    # ---- Transformational ----
    # TODO: Bucket
    "bucket": OperatorSignature(
        name="bucket",
        positional=[ParamType.MATRIX],
        keyword=[
            ParamSpec(name="range", param_type=[ParamType.STRING], default_value="0, 1, 0.1"),
            ParamSpec(name="buckets", param_type=[ParamType.STRING], default_value="2,5,6,7,10"),
        ],
        nary=1,
        description="Convert float values into indexes for user-specified buckets. Bucket is useful for creating group values, which can be passed to GROUP as input",
    ),
    "tail": OperatorSignature(
        name="tail",
        positional=[ParamType.MATRIX],
        keyword=[
            ParamSpec(name="lower", param_type=[ParamType.NUMBER], default_value=0),
            ParamSpec(name="upper", param_type=[ParamType.NUMBER], default_value=0),
            ParamSpec(name="newval", param_type=[ParamType.NUMBER], default_value=0),
        ],
        nary=1,
        description="If (x > lower AND x < upper) return newval, else return x. Lower, upper, newval should be constants",
    ),
    "trade_when": OperatorSignature(
        name="trade_when",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.MATRIX],
        keyword=[],
        nary=3,
        description="Used in order to change Alpha values only under a specified condition and to hold Alpha values in other cases. It also allows to close Alpha positions (assign NaN values) under a specified condition",
    ),
    # ---- Group ----
    "group_neutralize": OperatorSignature(
        name="group_neutralize",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Neutralizes Alpha against groups. These groups can be subindustry, industry, sector, country or a constant",
    ),
    "group_zscore": OperatorSignature(
        name="group_zscore",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Calculates group Z-score - numerical measurement that describes a value's relationship to the mean of a group of values. Z-score is measured in terms of standard deviations from the mean.",
    ),
    "group_rank": OperatorSignature(
        name="group_rank",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Each elements in a group is assigned the corresponding rank in this group",
    ),
    "group_scale": OperatorSignature(
        name="group_scale",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Normalizes the values in a group to be between 0 and 1. (x - groupmin) / (groupmax - groupmin)",
    ),
    "group_backfill": OperatorSignature(
        name="group_backfill",
        positional=[ParamType.MATRIX, ParamType.STRING, ParamType.POSITIVE_INT],
        keyword=[ParamSpec(name="std", param_type=[ParamType.NUMBER], default_value=4.0)],
        nary=3,
        description="If a certain value for a certain date and instrument is NaN, from the set of same group instruments, calculate winsorized mean of all non-NaN values over last d days",
    ),
    "group_mean": OperatorSignature(
        name="group_mean",
        positional=[ParamType.MATRIX, ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=3,
        description="All elements in group equals to the mean",
    ),
    "group_sum": OperatorSignature(
        name="group_sum",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Sum of x for all instruments in the same group.",
    ),
    "group_std_dev": OperatorSignature(
        name="group_std_dev",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="All elements in group equals to the standard deviation of the group.",
    ),
    "group_count": OperatorSignature(
        name="group_count",
        positional=[ParamType.MATRIX, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Gives the number of instruments in the same group (e.g. sector) which have valid values of x. This operator improves weight coverage and may help to reduce drawdown risk.",
    ),
    "group_cartesian_product": OperatorSignature(
        name="group_cartesian_product",
        positional=[ParamType.GROUP, ParamType.GROUP],
        keyword=[],
        nary=2,
        description="Merge two groups into one group. If originally there are len_1 and len_2 group indices in g1 and g2, there will be len_1 * len_2 indices in the new group.",
    ),
}
