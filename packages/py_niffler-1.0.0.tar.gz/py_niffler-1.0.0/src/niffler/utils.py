from datetime import date
from typing import Any

import numpy as np
import polars as pl

from .models import RegularAlpha


def parse_record(record: dict[str, Any]) -> pl.DataFrame:
    """Records 解析器

    平台大量的返回数据都是 schema + records 格式, 可统一用
    该函数返回

    Record Example
    --------------
    {
      'schema': {
        'name' / 'title' /
        'properties': [{'name' / 'title', 'type'}] # 列名
      },
      'records': [
        [], [], [], # 行数据
      ]
    }
    """
    schema_mapping = {
        "date": pl.String,
        "amount": pl.Float64,
        "integer": pl.Int64,
        "percent": pl.Float64,
        "decimal": pl.Float64,
        "permyriad": pl.Float64,
    }

    schema = {p["name"]: schema_mapping.get(p["type"]) or pl.String for p in record["schema"]["properties"]}
    data = pl.DataFrame(data=record["records"], schema=schema, orient="row")

    for f in filter(lambda x: x["type"] == "date", record["schema"]["properties"]):
        data = data.with_columns(pl.col(f["name"]).str.to_date())
    return data


def interval_scoring(
    sharpe: float, fitness: float, turnover: float, margin: float, returns: float, drawdown: float
) -> dict:
    # Sharpe: 1.0 - 1.58 - 2.58 - 3.5
    sharpe = abs(sharpe)
    if sharpe <= 0:
        sharpe_score = 0
    elif sharpe <= 1.0:
        sharpe_score = 60 * sharpe**2
    elif sharpe <= 1.58:
        sharpe_score = 60 + 20 / 0.58 * (2 * (sharpe - 1) - (sharpe - 1) ** 2)
    elif sharpe <= 2.58:
        sharpe_score = 88 + 20 * (sharpe - 1.58)
    elif sharpe <= 3.5:
        sharpe_score = 108 + 20 / (3.5 - 2.58) * (sharpe - 2.58)
    else:
        sharpe_score = 128

    # Fitness: 0.7 - 1.0 - 1.5 - 2.0
    fitness = abs(fitness)
    if fitness <= 0:
        fitness_score = 0
    elif fitness <= 0.7:
        fitness_score = 60 / 0.7 / 0.7 * fitness**2
    elif fitness <= 1.0:
        fitness_score = 60 + 20 / 0.3 * (fitness - 0.7)
    elif fitness <= 1.5:
        fitness_score = 80 + (-((fitness - 1) ** 2) + 2 * 0.58 * (fitness - 1) + 1 - 0.58**2) * 20
    elif fitness <= 2.0:
        fitness_score = 100 + 20 / (0.5) * (fitness - 1.5)
    else:
        fitness_score = 120

    # Turnover: 1% - 5% - 12.5% - 20% - 70%
    if turnover <= 0.01:
        turnover_score = 0
    elif turnover <= 0.05:
        turnover_score = 80 / 0.05 / 0.05 * turnover**2
    elif turnover <= 0.2:
        turnover_score = 80 + (1 - abs(turnover - 0.125) / (0.125 - 0.05)) * 20
    elif turnover <= 0.7:
        turnover_score = 80 - (turnover - 0.2) / 0.5 * 80
    else:
        turnover_score = 0

    # Margin: 0.0005 ~ 0.0100
    margin_score = min(200, abs(margin) * 40000)

    # Returns & Drawdown
    returns_score = min(120, abs(returns) * 800)

    if drawdown > returns:
        if returns == 0:
            drawdown_penalty = 0
        else:
            drawdown_penalty = max(0, 1 - (drawdown - returns) / returns)
    else:
        drawdown_penalty = 1.0

    score = {
        "sharpe": int(sharpe_score),
        "fitness": int(fitness_score),
        "turnover": int(turnover_score),
        "margin": int(margin_score),
        "returns": int(returns_score * drawdown_penalty),
    }

    return score


def calc_corr(pnls_all: dict, base: str) -> dict:
    pnls_df = parse_record(pnls_all[base]).select(["date", "pnl"]).rename({"pnl": base})

    for aid, a_pnl in pnls_all.items():
        if aid == base:
            continue
        pnls_df = pnls_df.join(
            parse_record(a_pnl).select(["date", "pnl"]).rename({"pnl": aid}),
            how="left",
            on=["date"],
        ).select(pl.selectors.exclude(["date_right"]))

    max_date = pnls_df["date"].max()
    assert isinstance(max_date, date)
    begin_date = pl.date(year=max_date.year - 4, month=max_date.month, day=max_date.day)

    pnls_df = pnls_df.with_columns(
        *[
            pl.col(p) - pl.col(p).fill_null(strategy="forward").shift(1)
            for p in pnls_df.columns
            if p != "date"
        ],
    ).filter(pl.col("date") > begin_date)

    self_corr = (
        pnls_df.select(pl.selectors.exclude(["date"]))
        .fill_null(0)
        .corr()
        .with_columns(alpha=pl.Series(pnls_df.select(pl.selectors.exclude(["date"])).columns))
        .select(["alpha", base])
        .sort(base, descending=True)
        .filter(pl.col("alpha") != base)
    )
    pnl_corr = dict(zip(*self_corr))
    return pnl_corr


def calc_metrics(
    alpha: RegularAlpha,
    pnl: dict,
    recent: int | None = None,
    weight_sharpe: float = 250,
    weight_fitness: float = 100,
    weight_margin: float = 150,
    weight_turnover: float = 100,
    weight_returns: float = 100,
) -> dict:
    pnl_data = parse_record(pnl)
    if recent is not None:
        pnl_data = pnl_data.tail(recent)

    metrics = dict(
        zip(
            *pnl_data.filter(pl.col("pnl").eq(0).not_())
            .select(
                sharpe=(
                    pl.col("pnl").diff().mean().truediv(pl.col("pnl").diff().std()).mul(np.sqrt(252))
                ).round(2),
                returns=pl.col("pnl").diff().mean().mul(252).truediv(1e7).round(4),
                drawdown=((pl.col("pnl").cum_max() - pl.col("pnl")).max() / 1e7).round(4),
                margin=(pl.col("pnl").last() - pl.col("pnl").first()) / (alpha.is_turnover * 2e7) / pl.len(),
            )
            .with_columns(
                fitness=(
                    pl.col("sharpe") * ((pl.col("returns").abs() / max(alpha.is_turnover, 0.125)).pow(0.5))
                ).round(2),
                turnover=alpha.is_turnover,
            )
            .transpose(include_header=True, header_name="Metric", column_names=["Value"])
        )
    )

    # Sharpe: 1.0 - 1.58 - 2.58 - 3.5
    sharpe = abs(metrics["sharpe"])
    if sharpe <= 0:
        sharpe_score = 0
    elif sharpe <= 1.0:
        sharpe_score = 60 * sharpe**2
    elif sharpe <= 1.58:
        sharpe_score = 60 + 20 / 0.58 * (2 * (sharpe - 1) - (sharpe - 1) ** 2)
    elif sharpe <= 2.58:
        sharpe_score = 88 + 20 * (sharpe - 1.58)
    elif sharpe <= 3.5:
        sharpe_score = 108 + 20 / (3.5 - 2.58) * (sharpe - 2.58)
    else:
        sharpe_score = 128

    # Fitness: 0.7 - 1.0 - 1.5 - 2.0
    fitness = abs(metrics["fitness"])
    if fitness <= 0:
        fitness_score = 0
    elif fitness <= 0.7:
        fitness_score = 60 / 0.7 / 0.7 * fitness**2
    elif fitness <= 1.0:
        fitness_score = 60 + 20 / 0.3 * (fitness - 0.7)
    elif fitness <= 1.5:
        fitness_score = 80 + (-((fitness - 1) ** 2) + 2 * 0.58 * (fitness - 1) + 1 - 0.58**2) * 20
    elif fitness <= 2.0:
        fitness_score = 100 + 20 / (0.5) * (fitness - 1.5)
    else:
        fitness_score = 120

    # Turnover: 1% - 5% - 12.5% - 20% - 70%
    turnover = metrics["turnover"]
    if turnover <= 0.01:
        turnover_score = 0
    elif turnover <= 0.05:
        turnover_score = 80 / 0.05 / 0.05 * turnover**2
    elif turnover <= 0.2:
        turnover_score = 80 + (1 - abs(turnover - 0.125) / (0.125 - 0.05)) * 20
    elif turnover <= 0.7:
        turnover_score = 80 - (turnover - 0.2) / 0.5 * 80
    else:
        turnover_score = 0

    # Margin: 0.0005 ~ 0.0100
    margin_score = min(200, abs(metrics["margin"]) * 40000)

    # Returns & Drawdown
    returns_score = min(120, abs(metrics["returns"]) * 800)

    if metrics["drawdown"] > metrics["returns"]:
        if metrics["returns"] == 0:
            drawdown_penalty = 0
        else:
            drawdown_penalty = max(0, 1 - (metrics["drawdown"] - metrics["returns"]) / metrics["returns"])
    else:
        drawdown_penalty = 1.0

    score = {
        "sharpe": int(sharpe_score),
        "fitness": int(fitness_score),
        "turnover": int(turnover_score),
        "margin": int(margin_score),
        "returns": int(returns_score * drawdown_penalty),
    }

    weighted_score = (
        score["sharpe"] * weight_sharpe
        + score["fitness"] * weight_fitness
        + score["turnover"] * weight_turnover
        + score["margin"] * weight_margin
        + score["returns"] * weight_returns
    ) / (weight_sharpe + weight_fitness + weight_turnover + weight_margin + weight_returns)

    return {
        "metrics": metrics,
        "scores": score,
        "weighted_score": round(weighted_score, 2),
    }
