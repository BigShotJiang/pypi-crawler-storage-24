import click

from .mcp.server import mcp


@click.group()
def main():
    """Niffler CLI."""
    pass


@main.group()
def run():
    pass


@run.command("mcp")
def run_mcp():
    mcp.run()
