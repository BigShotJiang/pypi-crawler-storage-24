from typing import Any, AsyncGenerator

from fastmcp import FastMCP
from fastmcp.server.context import Context
from fastmcp.server.lifespan import lifespan

from ..client import NifflerClient
from ..config import NifflerConfig


@lifespan
async def app_lifespan(server: FastMCP) -> AsyncGenerator[dict[str, Any], None]:
    client = NifflerClient()
    try:
        await client.setup()
        yield {"client": client}
    finally:
        await client.close()


mcp = FastMCP("niffler", lifespan=app_lifespan)


@mcp.tool()
async def get_user(ctx: Context) -> dict[str, str]:
    """获取当前登录用户名

    Returns
    -------
    username : str, 当前登录用户名
    id : str, 当前登录用户ID
    """
    user = await ctx.lifespan_context["client"].get_user()
    return {
        "username": user.username,
        "id": user.id,
    }


@mcp.tool()
async def get_config(ctx: Context) -> dict[str, Any]:
    """获取当前配置信息

    获取当前 NifflerClient 的配置信息, 包括数据库连接信息, 登录账户, 配置时区, 请求并发, 最大重试,
    重试间隔, 权鉴缓存容错时间等.

    Returns
    -------
    database : str, 数据库链接串
    username : str, 登录账户
    timezone : str, 配置时区
    concurrency : int, 请求并发
    max_retry : int, 最大重试
    retry_delay : float, 重试间隔
    expire_redun : float, 权鉴缓存容错时间
    """
    config: NifflerConfig = ctx.lifespan_context["client"]._config
    return {
        "database": config.database.connection,
        "username": config.username,
        "timezone": config.timezone,
        "concurrency": config.concurrency,
        "max_retry": config.max_retry,
        "retry_delay": config.retry_delay,
        "expire_redun": config.expire_redun,
    }


@mcp.tool()
async def get_dataset(dataset_id: str, ctx: Context) -> dict[str, Any]:
    """获取数据集

    根据数据集 ID 获取数据集基础信息

    Parameters
    ----------
    dataset_id : str, 数据集 ID

    Returns
    -------
    dataset : dict, 数据集基础信息
        - id : str, 数据集 ID
        - name : str, 数据集名称
        - description : str, 数据集描述
        - category : dict, 数据集分类
        - subcategory : dict, 数据集子类别
        - data : list[dict], 分区域/股票池/Delay的字段信息, 包括日期覆盖率, 股票覆盖率, 质量因子, 用户数, 因子数
        - researchPapers : list[dict], 数据集分析参考文献
    """
    client: NifflerClient = ctx.lifespan_context["client"]
    dataset = await client.get_dataset(dataset_id)
    return dataset


@mcp.tool
async def get_community_posts(url: str, ctx: Context) -> dict:
    """获取社区帖子"""
    client: NifflerClient = ctx.lifespan_context["client"]
    content = await client.get(url=url, base_url="")
