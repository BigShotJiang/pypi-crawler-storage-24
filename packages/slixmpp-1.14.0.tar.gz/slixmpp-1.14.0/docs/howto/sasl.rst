How SASL Authentication Works
=============================
