#
# Copyright 2009-2026 Ghent University
#
# This file is part of vsc-mympirun,
# originally created by the HPC team of Ghent University (http://ugent.be/hpc/en),
# with support of Ghent University (http://ugent.be/hpc),
# the Flemish Supercomputer Centre (VSC) (https://www.vscentrum.be),
# the Flemish Research Foundation (FWO) (http://www.fwo.be/en)
# and the Department of Economy, Science and Innovation (EWI) (http://www.ewi-vlaanderen.be/en).
#
# https://github.com/hpcugent/vsc-mympirun
#
# vsc-mympirun is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation v2.
#
# vsc-mympirun is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with vsc-mympirun.  If not, see <http://www.gnu.org/licenses/>.
#
"""
OpenMPI specific classes
Documentation can be found at https://www.open-mpi.org/doc/
"""
import logging
import math
import os
import re
import sys
from vsc.utils.missing import nub
from vsc.utils.run import CmdList, run

from vsc.mympirun.common import version_in_range
from vsc.mympirun.mpi.mpi import MPI


SLURM_EXPORT_ENV = 'SLURM_EXPORT_ENV'


class OpenMPI(MPI):

    """An implementation of the MPI class for OpenMPI"""

    _mpiscriptname_for = ['ompirun']
    _mpirun_for = 'OpenMPI'
    _mpirun_version = staticmethod(lambda ver: version_in_range(ver, None, '1.7.0'))

    DEVICE_MPIDEVICE_MAP = {
        'det': 'sm,tcp,self',
        'ib': 'sm,openib,self',
        'shm': 'sm,self',
        'socket': 'sm,tcp,self',
    }

    MPIEXEC_TEMPLATE_GLOBAL_OPTION = ['--mca', '%(name)s', "%(value)s"]

    REMOTE_OPTION_TEMPLATE = ['--mca', 'pls_rsh_agent', '%(rsh)s']

    def use_ucx_pml(self):
        """Determine whether or not to use the UCX Point-to-Point Messaging Layer (PML)."""
        # don't use UCX by default (mostly because of backwards-compatibility)
        return False

    def set_mpiexec_global_options(self):
        """Set mpiexec global options"""

        if self.use_ucx_pml():
            self.mpiexec_global_options['pml'] = 'ucx'
            # always disable uct btl when using UCX,
            # see https://openucx.readthedocs.io/en/master/running.html#runtime-tunings
            if self.options.libfabric:
                self.mpiexec_global_options['btl'] = '^uct'
            else:
                # also disable libfabric (OFI) btl, since it can cause trouble on Infiniband systems
                self.mpiexec_global_options['btl'] = '^uct,ofi'
                # disable libfabric (OFI) mtl as well
                self.mpiexec_global_options['mtl'] = '^ofi'

            if self.options.debuglvl > 3:
                os.environ['UCX_LOG_LEVEL'] = 'debug'
                self.mpiexec_global_options['pml_ucx_verbose'] = self.options.debuglvl

            if self.options.stats:
                # report UCX stats at the end to stdout
                os.environ['UCX_STATS_TRIGGER'] = 'exit'
                os.environ['UCX_STATS_DEST'] = 'stdout'
        else:
            # default PML (ob1) uses Byte Transport Layer (BTL)
            self.mpiexec_global_options['btl'] = self.device

        if self.options.debuglvl > 3:
            # need to add toggle switches like --abc (i.e. without value)
            value = (None, "--%(name)s")
            for key in ['report-bindings', 'display-map', 'display-allocation', 'tag-output']:
                self.mpiexec_global_options[key] = value

        # make sure Open Run-Time Environment (ORTE) uses FQDN hostnames
        # using short hostnames may cause problems (e.g. if SLURM is configured to use FQDN hostnames)
        self.mpiexec_global_options['orte_keep_fqdn_hostnames'] = '1'

        super().set_mpiexec_global_options()

    def _map_by_option_value(self):
        """
        Return value for --map-by option
        """

        # make sure we start enough per node so it can fill the total_number_of_processes
        tot_processes = self.total_number_of_processes()
        unique_nodes = len(self.nodes_uniq)
        processes_per_node = int(math.ceil(tot_processes / unique_nodes))
        logging.debug("Setting up map for %s (%s total number of processes on %s unique nodes)",
                      processes_per_node, tot_processes, unique_nodes)

        # determine whether we should oversubscribe or not
        if self.is_oversubscribed():
            logging.debug("Allow oversubscription")
            over = ''
        else:
            over = 'NO'

        # See https://www.open-mpi.org/doc/v4.1/man1/mpirun.1.php "Mapping, Ranking, and Binding: Oh My!"
        mapby = [
            'ppr', str(processes_per_node), 'node',
            f"PE={self.get_threads()}",
            "SPAN",
            f"{over}OVERSUBSCRIBE",
        ]

        return mapby

    def set_mpiexec_options(self):
        """Set mpiexec options"""
        super().set_mpiexec_options()

        mapby = self._map_by_option_value()
        self.mpiexec_options.add(['--map-by', ':'.join(mapby)])

    def _make_final_mpirun_cmd(self):
        """
        Create the acual mpirun command
        OpenMPI doesn't need mpdboot options
        """
        self.mpirun_cmd.add(self.mpiexec_options)

    def determine_sockets_per_node(self):
        """
        Try to determine the number of sockets per node; either specified by --sockets-per-node or using /proc/cupinfo
        """
        sockets_per_node = self.options.sockets_per_node
        if sockets_per_node == 0:
            try:
                with open('/proc/cpuinfo') as fih:
                    proc_cpuinfo = fih.read()
            except OSError as err:
                error_msg = f"Failed to read /proc/cpuinfo to determine number of sockets per node: {err}"
                error_msg += "; use --sockets-per-node to override"
                logging.error(error_msg)
                sys.exit(1)

            if proc_cpuinfo:
                res = re.findall('^physical id.*', proc_cpuinfo, re.M)
                sockets_per_node = len(nub(res))
                logging.debug("Sockets per node found in cpuinfo: set to %s", sockets_per_node)

            if sockets_per_node == 0:
                logging.warning("Could not derive number of sockets per node from /proc/cpuinfo. "
                                "Assuming a single socket, use --sockets-per-node to override.")
                sockets_per_node = 1

        return sockets_per_node

    def pinning_override(self):
        """ pinning """

        override_type = self.pinning_override_type

        logging.debug("pinning_override: type %s ", override_type)

        ranktxt = ""
        sockets_per_node = self.determine_sockets_per_node()
        universe = self.options.universe or self.nodes_tot_cnt

        try:
            rankfn = os.path.join(self.mympirundir, 'rankfile')

            if override_type in ('packed', 'compact', 'bunch'):
                # pack ranks, filling every consecutive slot on every consecutive node
                for rank in range(universe):
                    node = rank / self.ppn
                    socket = rank / (self.ppn / sockets_per_node)
                    slot = rank % (self.ppn / sockets_per_node)
                    ranktxt += f"rank {int(rank)}=+n{int(node)} slot={int(socket)}:{int(slot)}\n"

            elif override_type in ('spread', 'scatter'):
                # spread ranks evenly across nodes, but also spread them across sockets
                for rank in range(universe):
                    node = rank % self.nodes_tot_cnt
                    socket = (rank % self.ppn) % sockets_per_node
                    slot = (rank % self.ppn) / sockets_per_node
                    ranktxt += f"rank {int(rank)}=+n{int(node)} slot={int(socket)}:{int(slot)}\n"

            else:
                raise Exception(f"pinning_override: unsupported pinning_override_type  {self.pinning_override_type}")

            with open(rankfn, 'w') as fp:
                fp.write(ranktxt)
            logging.debug("pinning_override: wrote rankfile %s:\n%s", rankfn, ranktxt)
            cmd = CmdList('-rf', rankfn)

        except OSError as err:
            raise Exception(f'pinning_override: failed to write rankfile {rankfn}: {err}')

        return cmd

    def make_machine_file(self, nodetxt=None, universe=None):
        """
        Make the machinefile.
        Parses the list of nodes that run an MPI process and writes this information to a machinefile.
        """
        if self.mpinodes is None:
            self.set_mpinodes()

        if nodetxt is None:
            nodetxt = ''
            # if --universe is specified, we control how many processes per node are run via 'slots='
            if universe is not None and universe > 0:
                universe_ppn = self.get_universe_ncpus()
                for node in nub(self.mpinodes):
                    nodetxt += f"{node} slots={universe_ppn[node]}\n"

            # in case of oversubscription or multinode, also use 'slots='
            elif self.is_oversubscribed():
                for node in nub(self.mpinodes):
                    nodetxt += f'{node} slots={self.ppn}\n'
            else:
                nodetxt = '\n'.join(self.mpinodes)

        super().make_machine_file(nodetxt=nodetxt, universe=universe)

    def prepare(self):
        """Prepare environment"""
        # undefine $SLURM_EXPORT_ENV if it is set;
        # $SLURM_EXPORT_ENV is defined as 'NONE' by qsub wrappers for SLURM,
        # and then gets passed down to srun via mpirun, which may cause problems with 'orted' being found
        # because $PATH and $LD_LIBRARY_PATH are no longer set
        # (unless OpenMPI installation was configured with --enable-orterun-prefix-by-default)
        # cfr. https://www.mail-archive.com/devel@lists.open-mpi.org/msg17305.html
        if SLURM_EXPORT_ENV in os.environ:
            logging.info("Undefining $%s (was '%s')", SLURM_EXPORT_ENV, os.getenv(SLURM_EXPORT_ENV))
            del os.environ[SLURM_EXPORT_ENV]

        super().prepare()


class OpenMpiOversubscribe(OpenMPI):

    """
    An implementation of the MPI class for OpenMPI. Starting from version 1.7, --oversubscribe has to be used
    when requesting more processes than available processors.
    """

    _mpirun_version = staticmethod(lambda ver: version_in_range(ver, '1.7.0', '3'))

    def set_mpiexec_options(self):

        super().set_mpiexec_options()

        if self.is_oversubscribed():
            self.mpiexec_options.add("--oversubscribe")


class OpenMpi3(OpenMpiOversubscribe):

    """
    An implementation of the MPI class for OpenMPI 3.x & more recent.
    """

    _mpirun_version = staticmethod(lambda ver: version_in_range(ver, '3', '4'))

    # 'sm' BTL (Byte Transfer Layer) was replaced by the 'vader' BTL
    # cfr. https://www.open-mpi.org/faq/?category=sm
    DEVICE_MPIDEVICE_MAP = {
        'det': 'vader,tcp,self',
        'ib': 'vader,openib,self',
        'shm': 'vader,self',
        'socket': 'vader,tcp,self',
    }


class OpenMpi4(OpenMpi3):

    """
    An implementation of the MPI class for OpenMPI 4.x & more recent.
    """

    _mpirun_version = staticmethod(lambda ver: version_in_range(ver, '4', '5'))

    def use_ucx_pml(self):
        """Determine whether or not to use the UCX Point-to-Point Messaging Layer (PML)."""

        # use UCX if 'ompi_info' reports that it is a supported PML;
        # only for OpenMPI 4.x and newer, as recommended by UCX:
        # "OpenMPI supports UCX starting from version 3.0, but it's recommended to use
        # "version 4.0 or higher due to stability and performance improvements."
        # (see https://openucx.github.io/ucx/running.html#openmpi-with-ucx)
        cmd = "ompi_info"
        ec, out = run(cmd)
        if ec:
            raise Exception(f"use_ucx_pml: failed to run cmd '{cmd}', ec: {ec}, out: {out}")

        pml_ucx_pattern = ' pml: ucx '
        return bool(re.search(pml_ucx_pattern, out))


class OpenMpi5(OpenMpi4):

    """
    An implementation of the MPI class for OpenMPI 5.x & more recent.
    """

    _mpirun_version = staticmethod(lambda ver: version_in_range(ver, '5', None))

    # 'vader' BTL (Byte Transfer Layer) was renamed back to 'sm' in OpenMPI 5.x,
    # see https://docs.open-mpi.org/en/v5.0.x/tuning-apps/networking/shared-memory.html#the-sm-btl
    DEVICE_MPIDEVICE_MAP = {
        'det': 'sm,tcp,self',
        'ib': 'sm,openib,self',
        'shm': 'sm,self',
        'socket': 'sm,tcp,self',
    }

    def set_mpiexec_options(self):
        """Set mpiexec options"""
        # don't set orte_keep_fqdn_hostnames, since ORTE is no longer used starting OpenMPI 5.0,
        # see also https://docs.open-mpi.org/en/v5.0.x/launching-apps/pmix-and-prrte.html,
        del self.mpiexec_global_options['orte_keep_fqdn_hostnames']

        super().set_mpiexec_options()

        # use keep_fqdn_hostname PRRTE MCA parameter instead: --prtemca keep_fqdn_hostnames 1;
        # see also https://docs.open-mpi.org/en/v5.0.x/mca.html#label-running-setting-mca-param-values
        self.mpiexec_options.add(['--prtemca', 'prte_keep_fqdn_hostnames', '1'])

    def _map_by_option_value(self):
        """
        Return value for --map-by option
        """
        mapby = super()._map_by_option_value()

        # filter out use of 'SPAN' qualifiers, which can't be combined with 'ppr' and 'node' in OpenMPI 5.x;
        # see https://docs.open-mpi.org/en/v5.0.x/man-openmpi/man1/mpirun.1.html#the-map-by-option
        mapby = [x for x in mapby if x != 'SPAN']

        return mapby
