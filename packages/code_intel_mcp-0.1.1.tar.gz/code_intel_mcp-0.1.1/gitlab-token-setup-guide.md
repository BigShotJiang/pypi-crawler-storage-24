# GitLab Token Setup Guide for macOS

## Overview

This guide walks you through securely creating, storing, and using a GitLab Personal Access Token on macOS using the native Keychain — the most secure approach for local development.

---

## Step 1: Create a GitLab Personal Access Token

1. Open your browser and go to:
   ```
   https://gitlab.sbs-software.com/-/user_settings/personal_access_tokens
   ```
   (Or navigate: GitLab → Click your avatar (top-left) → **Edit Profile** → **Access Tokens** in the left sidebar)

2. Click **"Add new token"**

3. Fill in the form:
   - **Token name**: Something descriptive, e.g. `macbook-dev-token`
   - **Expiration date**: Set a reasonable expiry (e.g. 1 year). GitLab enforces a max, so pick what's allowed.
   - **Scopes** — check the following:
     - `read_api` — needed to list repos/groups
     - `read_repository` — needed to clone via HTTPS
     - `write_repository` — needed if you push via HTTPS (skip if you use SSH for push)

4. Click **"Create personal access token"**

5. **IMPORTANT**: Copy the token immediately. It looks like `glpat-xxxxxxxxxxxxxxxxxxxx`. You will **never** see it again after leaving this page.

6. Paste it somewhere temporarily (e.g. a text editor) — you'll store it in Keychain in the next step, then delete this temporary copy.

---

## Step 2: Store the Token in macOS Keychain

The macOS Keychain is an encrypted, OS-level credential store protected by your login password and (optionally) Touch ID. This is far more secure than putting the token in a dotfile.

### Option A: Store via Terminal (Recommended)

Open Terminal and run:

```bash
security add-generic-password \
  -a "$USER" \
  -s "gitlab-token" \
  -w "glpat-xxxxxxxxxxxxxxxxxxxx"
```

Replace `glpat-xxxxxxxxxxxxxxxxxxxx` with your actual token.

**What each flag means:**
| Flag | Meaning |
|------|---------|
| `-a "$USER"` | The "account" field — uses your macOS username |
| `-s "gitlab-token"` | The "service" field — a label to find it later |
| `-w "glpat-xxx..."` | The "password" field — your actual token value |

### Option B: Store via Keychain Access GUI

1. Open **Keychain Access** (Spotlight → search "Keychain Access")
2. Make sure **"login"** keychain is selected in the left sidebar
3. Click the **"+"** button (or File → New Password Item)
4. Fill in:
   - **Keychain Item Name**: `gitlab-token`
   - **Account Name**: your macOS username (e.g. `arunveer.singh`)
   - **Password**: paste your token `glpat-xxxxxxxxxxxxxxxxxxxx`
5. Click **"Add"**

### Verify It Was Stored

Run this in Terminal:

```bash
security find-generic-password -a "$USER" -s "gitlab-token" -w
```

It should print your token. If it asks for your password or Touch ID, that's expected — it's the Keychain protecting access.

---

## Step 3: Make the Token Available in Your Shell

You have two approaches depending on how you want to use it.

### Approach A: Export Globally in Shell Profile (Convenient)

Add this line to your `~/.zshrc`:

```bash
# GitLab token from Keychain (secure)
export GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w 2>/dev/null)
```

Then reload your shell:

```bash
source ~/.zshrc
```

**Verify it works:**

```bash
echo $GITLAB_TOKEN
```

You should see your token printed.

**Pros:**
- Token is available in every terminal session automatically
- Works with any tool that reads `GITLAB_TOKEN` env var

**Cons:**
- Any child process in your shell can read the env var (low risk on a personal machine)

### Approach B: Inline Per-Command (Most Secure)

Don't add anything to `~/.zshrc`. Instead, fetch the token only when you need it:

```bash
GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w) \
  curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.sbs-software.com/api/v4/projects"
```

Or in a script:

```bash
#!/bin/bash
GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w)

# Use $GITLAB_TOKEN for the rest of the script
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" ...
```

**Pros:**
- Token never sits in your global environment
- Maximum security

**Cons:**
- Slightly more verbose in scripts

---

## Step 4: Test the Token

Run this to verify everything works end-to-end:

```bash
# If using Approach A (global export), just run:
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.sbs-software.com/api/v4/user" | python3 -m json.tool
```

```bash
# If using Approach B (inline), run:
GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w) \
  curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.sbs-software.com/api/v4/user" | python3 -m json.tool
```

You should see JSON output with your GitLab user info:

```json
{
    "id": 123,
    "username": "arunveer.singh1",
    "name": "Arunveer Singh",
    "state": "active",
    ...
}
```

---

## Step 5: Update or Rotate the Token

### When Your Token Expires

1. Create a new token in GitLab (repeat Step 1)
2. Delete the old Keychain entry:
   ```bash
   security delete-generic-password -a "$USER" -s "gitlab-token"
   ```
3. Add the new one:
   ```bash
   security add-generic-password -a "$USER" -s "gitlab-token" -w "glpat-new-token-here"
   ```
4. If using Approach A, open a new terminal (or `source ~/.zshrc`) to pick up the new value.

### Quick One-Liner to Update

```bash
security delete-generic-password -a "$USER" -s "gitlab-token" 2>/dev/null; \
security add-generic-password -a "$USER" -s "gitlab-token" -w "glpat-new-token-here"
```

---

## Step 6: Configure Git Credential Storage (Optional but Recommended)

If you clone repos over HTTPS (not SSH), you can tell Git to use the macOS Keychain for storing credentials so you don't get prompted for username/password on every operation.

```bash
git config --global credential.helper osxkeychain
```

Then the first time you `git clone` or `git pull` over HTTPS, enter:
- **Username**: your GitLab username (e.g. `arunveer.singh1`)
- **Password**: your personal access token (not your GitLab password)

Git will store this in Keychain and never ask again (until the token expires).

---

## Security Summary

| Method | Security Level | Notes |
|--------|---------------|-------|
| ❌ Hardcoded in `~/.zshrc` | Low | Plaintext, leaks via dotfile sharing/backups |
| ❌ In a `.env` file | Low | Plaintext on disk |
| ✅ macOS Keychain + shell export | High | Encrypted at rest, protected by login/Touch ID |
| ✅ macOS Keychain + inline only | Highest | Never in global env, fetched on demand |

---

## Quick Reference

```bash
# Store token
security add-generic-password -a "$USER" -s "gitlab-token" -w "glpat-your-token"

# Retrieve token
security find-generic-password -a "$USER" -s "gitlab-token" -w

# Delete token
security delete-generic-password -a "$USER" -s "gitlab-token"

# Use in shell profile (~/.zshrc)
export GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w 2>/dev/null)

# Use inline (most secure)
GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "gitlab-token" -w) your-command-here
```
