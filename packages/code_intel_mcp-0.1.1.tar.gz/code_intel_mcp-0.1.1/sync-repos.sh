#!/bin/bash
# =============================================================================
# GitLab Repo Sync Script
# Clones all repos preserving the GitLab subgroup folder structure.
# Uses HTTPS cloning with token-based auth.
# Re-run anytime to pick up new repos (existing ones are skipped).
# =============================================================================

set -euo pipefail

# --- Configuration ---
GITLAB_HOST="https://gitlab.sbs-software.com"
BASE_DIR="/Users/arunveer.singh/source-of-truth/code"

# Fetch token from Keychain
GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "GITLAB_TOKEN" -w 2>/dev/null)

if [ -z "$GITLAB_TOKEN" ]; then
  echo "❌ ERROR: Could not retrieve GITLAB_TOKEN from Keychain."
  echo "   Run: security add-generic-password -a \"\$USER\" -s \"GITLAB_TOKEN\" -w \"your-token\""
  exit 1
fi

echo "✅ Token loaded from Keychain"
echo "📁 Base directory: $BASE_DIR"
echo ""

# --- Helper Functions ---

get_group_id() {
  local group_path="$1"
  local encoded_path
  encoded_path=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$group_path', safe=''))")
  curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "$GITLAB_HOST/api/v4/groups/$encoded_path" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id', ''))" 2>/dev/null
}

to_https_url() {
  local http_url="$1"
  echo "$http_url" | sed "s|https://|https://oauth2:${GITLAB_TOKEN}@|"
}

# Clone all projects under a GitLab group, preserving subgroup folder structure
clone_group() {
  local group_path="$1"
  local local_base="$2"

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "🔍 Processing group: $group_path"
  echo "📂 Base folder:      $local_base"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  local group_id
  group_id=$(get_group_id "$group_path")

  if [ -z "$group_id" ]; then
    echo "⚠️  Could not find group: $group_path (check path or permissions)"
    echo ""
    return
  fi

  echo "   Group ID: $group_id"

  local page=1

  while true; do
    local response
    response=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
      "$GITLAB_HOST/api/v4/groups/$group_id/projects?include_subgroups=true&per_page=100&page=$page&archived=false")

    local count
    count=$(echo "$response" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")

    [ "$count" = "0" ] && break

    # Extract http_url and path_with_namespace for each project
    # path_with_namespace gives us the full GitLab path like "sbs-cloud/dbpp/ipce/bundles/bundle-ipce-core-be"
    # We strip the group_path prefix to get the relative subgroup path
    echo "$response" | python3 -c "
import sys, json
group_path = '$group_path'
projects = json.load(sys.stdin)
for p in projects:
    full_path = p.get('path_with_namespace', '')
    http_url = p.get('http_url_to_repo', '')
    # Get the path relative to the group: e.g. 'bundles/bundle-ipce-core-be'
    if full_path.startswith(group_path + '/'):
        relative_path = full_path[len(group_path) + 1:]
    else:
        relative_path = p.get('path', '')
    print(http_url + '|' + relative_path)
" 2>/dev/null | while IFS='|' read -r http_url relative_path; do
      if [ -z "$http_url" ] || [ -z "$relative_path" ]; then
        continue
      fi

      local target_dir="$local_base/$relative_path"

      if [ -d "$target_dir" ]; then
        echo "   ⏭️  Skipping (exists): $relative_path"
      else
        mkdir -p "$(dirname "$target_dir")"
        local clone_url
        clone_url=$(to_https_url "$http_url")
        echo "   📥 Cloning: $relative_path"
        git clone --quiet "$clone_url" "$target_dir" 2>&1 | sed 's/^/      /'
      fi
    done

    page=$((page + 1))
  done

  echo "   ✅ Done with $group_path"
  echo ""
}

# Clone personal projects (flat structure — no subgroups for personal)
clone_personal() {
  local local_dir="$1"

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "🔍 Processing: Personal Projects"
  echo "📂 Target folder: $local_dir"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  mkdir -p "$local_dir"

  local user_id
  user_id=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "$GITLAB_HOST/api/v4/user" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id', ''))" 2>/dev/null)

  if [ -z "$user_id" ]; then
    echo "⚠️  Could not determine user ID. Check your token."
    echo ""
    return
  fi

  echo "   User ID: $user_id"

  local page=1

  while true; do
    local response
    response=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
      "$GITLAB_HOST/api/v4/users/$user_id/projects?per_page=100&page=$page")

    local count
    count=$(echo "$response" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")

    [ "$count" = "0" ] && break

    echo "$response" | python3 -c "
import sys, json
projects = json.load(sys.stdin)
for p in projects:
    print(p.get('http_url_to_repo', '') + '|' + p.get('path', ''))
" 2>/dev/null | while IFS='|' read -r http_url repo_name; do
      if [ -z "$http_url" ] || [ -z "$repo_name" ]; then
        continue
      fi

      if [ -d "$local_dir/$repo_name" ]; then
        echo "   ⏭️  Skipping (exists): $repo_name"
      else
        local clone_url
        clone_url=$(to_https_url "$http_url")
        echo "   📥 Cloning: $repo_name"
        git clone --quiet "$clone_url" "$local_dir/$repo_name" 2>&1 | sed 's/^/      /'
      fi
    done

    page=$((page + 1))
  done

  echo "   ✅ Done with personal projects"
  echo ""
}

# --- Main Execution ---

echo "🚀 Starting repo sync..."
echo ""

# 1. IPCE group (14 repos including prj-ipce)
clone_group "ipce" "$BASE_DIR/ipce"

# 2. DBPP - ipce (group ID: 69836)
clone_group "sbs-cloud/dbpp/ipce" "$BASE_DIR/dbpp/ipce"

# 2. DBPP - ink
clone_group "sbs-cloud/dbpp/ink" "$BASE_DIR/dbpp/ink"

# 3. Personal projects
clone_personal "$BASE_DIR/personal"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎉 All done! Your repos are at: $BASE_DIR"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
