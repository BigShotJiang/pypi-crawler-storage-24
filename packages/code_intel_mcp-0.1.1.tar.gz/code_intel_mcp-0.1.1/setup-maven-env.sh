#!/bin/bash

# Setup Maven environment variables in ~/.zshrc
# Usage: ./setup-maven-env.sh

ZSHRC="$HOME/.zshrc"

read -p "MAVEN_REPO_USERNAME: " MAVEN_USER
read -sp "MAVEN_REPO_PASSWORD: " MAVEN_PASS
echo
read -p "NEXUS_USERNAME: " NEXUS_USER
read -sp "NEXUS_PASSWORD: " NEXUS_PASS
echo

# Remove old entries if they exist
sed -i '' '/^export MAVEN_REPO_USERNAME=/d' "$ZSHRC" 2>/dev/null
sed -i '' '/^export MAVEN_REPO_PASSWORD=/d' "$ZSHRC" 2>/dev/null
sed -i '' '/^export NEXUS_USERNAME=/d' "$ZSHRC" 2>/dev/null
sed -i '' '/^export NEXUS_PASSWORD=/d' "$ZSHRC" 2>/dev/null

# Append new values
cat >> "$ZSHRC" <<EOF

# Maven & Nexus credentials
export MAVEN_REPO_USERNAME="$MAVEN_USER"
export MAVEN_REPO_PASSWORD="$MAVEN_PASS"
export NEXUS_USERNAME="$NEXUS_USER"
export NEXUS_PASSWORD="$NEXUS_PASS"
EOF

echo ""
echo "Done. Added to $ZSHRC"
echo "Run: source ~/.zshrc"
