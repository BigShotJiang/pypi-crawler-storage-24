# GitLab Repo Sync — Setup & Usage Guide

## Overview

This guide explains how to use the `sync-repos.sh` script to bulk-clone all your GitLab repositories into a clean, organized folder structure on your Mac. The script is re-runnable — it skips repos that already exist locally.

---

## Prerequisites

Before running the script, make sure you have the following in place:

### 1. Git Installed

```bash
git --version
```

If not installed, it will prompt you to install Xcode Command Line Tools.

### 2. SSH Key Configured with GitLab

The script clones repos via SSH. Verify your SSH key is set up:

```bash
ssh -T git@gitlab.sbs-software.com
```

You should see something like:
```
Welcome to GitLab, @arunveer.singh1!
```

If not, set up an SSH key:

```bash
# Generate a new key (if you don't have one)
ssh-keygen -t ed25519 -C "a.x@mail.com"

# Copy the public key
pbcopy < ~/.ssh/id_ed25519.pub
```

Then go to **GitLab → Preferences → SSH Keys** and paste it.

### 3. GitLab Personal Access Token in Keychain

The script reads your token from macOS Keychain. If you haven't set this up yet, see `gitlab-token-setup-guide.md` or run:

```bash
# Store token
security add-generic-password -a "$USER" -s "GITLAB_TOKEN" -w "glpat-your-token-here"

# Verify
security find-generic-password -a "$USER" -s "GITLAB_TOKEN" -w
```

Your token needs at minimum the `read_api` scope.

### 4. GITLAB_TOKEN in Your Shell

Add this to your `~/.zshrc` (between your exports and the Kiro post block):

```bash
export GITLAB_TOKEN=$(security find-generic-password -a "$USER" -s "GITLAB_TOKEN" -w 2>/dev/null)
```

Then reload:

```bash
source ~/.zshrc
```

---

## Folder Structure

The script organizes repos to mirror the GitLab group hierarchy:

```
/Users/arunveer.singh/source-of-truth/code/
│
├── ipce/
│   └── prj-ipce/
│       ├── repo-a/
│       ├── repo-b/
│       └── ...
│
├── dbpp/
│   ├── ipce/
│   │   ├── repo-a/
│   │   └── ...
│   └── ink/
│       ├── repo-a/
│       └── ...
│
└── personal/
    ├── my-project-1/
    ├── my-project-2/
    └── ...
```

### Source Groups

| Local Path | GitLab Group |
|---|---|
| `ipce/prj-ipce/` | `https://gitlab.sbs-software.com/ipce/prj-ipce` |
| `dbpp/ipce/` | `https://gitlab.sbs-software.com/sbs-cloud/dbpp/ipce` |
| `dbpp/ink/` | `https://gitlab.sbs-software.com/sbs-cloud/dbpp/ink` |
| `personal/` | `https://gitlab.sbs-software.com/users/arunveer.singh1/projects` |

---

## How to Run

### First Time

```bash
# Navigate to where the script is
cd /Users/arunveer.singh/source-of-truth/code

# Make it executable (only needed once)
chmod +x sync-repos.sh

# Run it
./sync-repos.sh
```

### Subsequent Runs

Just run it again. It will:
- Skip repos that are already cloned locally
- Clone any new repos that were added to the GitLab groups
- Ignore archived repos

```bash
./sync-repos.sh
```

---

## What the Script Does (Step by Step)

1. **Loads your GitLab token** from macOS Keychain using the `security` CLI
2. **For each GitLab group**, it:
   - Looks up the group's numeric ID via the GitLab API (using the group path)
   - Fetches all projects under that group (including subgroups), paginated at 100 per page
   - For each project:
     - If the repo folder already exists locally → skips it
     - If it's new → clones it via SSH
3. **For personal projects**, it:
   - Looks up your GitLab user ID
   - Fetches all your personal projects
   - Clones new ones, skips existing ones
4. Prints a summary when done

---

## Troubleshooting

### "Could not retrieve GITLAB_TOKEN from Keychain"

Your token isn't stored in Keychain, or the account/service name doesn't match.

```bash
# Check if it exists
security find-generic-password -a "$USER" -s "GITLAB_TOKEN" -w

# If not found, add it
security add-generic-password -a "$USER" -s "GITLAB_TOKEN" -w "glpat-your-token"
```

### "Could not find group: ..."

Either:
- The group path is wrong (check it on GitLab)
- Your token doesn't have `read_api` access to that group
- You're not a member of that group

### SSH clone fails with "Permission denied"

Your SSH key isn't set up with GitLab:

```bash
# Test SSH connection
ssh -T git@gitlab.sbs-software.com

# If it fails, check your key is added
ssh-add -l

# Add your key if needed
ssh-add ~/.ssh/id_ed25519
```

### "rate limit" or empty responses

The GitLab API has rate limits. If you have hundreds of repos, you might hit them. Wait a few minutes and re-run — the script will skip already-cloned repos and continue where it left off.

---

## Customization

### Add a New Group

Edit `sync-repos.sh` and add a new `clone_group` call before the personal projects section:

```bash
# Example: add a new group
clone_group "your-group/path" "$BASE_DIR/your/local/path"
```

### Switch from SSH to HTTPS Cloning

In the script, the clone URL comes from GitLab's `ssh_url_to_repo` field. To use HTTPS instead, change `ssh_url_to_repo` to `http_url_to_repo` in both the `clone_group` and `clone_personal` functions.

### Pull Updates for Existing Repos

The script only clones — it doesn't pull. To add a pull-for-existing feature, you could replace the skip logic:

```bash
# Instead of just skipping:
if [ -d "$local_dir/$repo_name" ]; then
  echo "   🔄 Pulling: $repo_name"
  git -C "$local_dir/$repo_name" pull --quiet 2>&1 | sed 's/^/      /'
fi
```

---

## Quick Reference

```bash
# Run the sync
./sync-repos.sh

# Check your token is working
curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  "https://gitlab.sbs-software.com/api/v4/user" | python3 -m json.tool

# Test SSH to GitLab
ssh -T git@gitlab.sbs-software.com

# Re-store token in Keychain
security delete-generic-password -a "$USER" -s "GITLAB_TOKEN" 2>/dev/null
security add-generic-password -a "$USER" -s "GITLAB_TOKEN" -w "glpat-new-token"
```
