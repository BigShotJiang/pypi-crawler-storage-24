# CarveMeGut

CarveMeGut is a Python package designed for metabolic model reconstruction 
and curation, particularly tailored for gut microbiome studies. It 
automates the process of extracting, curating, and refining genome-scale 
metabolic models using various datasets and computational methods.

## Features
- Automated metabolic model reconstruction from genome sequences
- Integration with public metabolic databases
- Gap-filling for incomplete metabolic networks
- Support for various file formats (FASTA, SBML, etc.)
- CLI tools for streamlined workflows

## Installation

CarveMeGut requires Python 3.7 or higher. Install it using pip:

```sh
pip install carvemegut
```

Alternatively, you can install the latest development version from GitHub:

```sh
git clone https://github.com/yourusername/carvemegut.git
cd carvemegut
pip install .
```

## Usage

### CLI Usage

CarveMeGut provides a command-line interface (CLI) for ease of use. After 
installation, you can use:

```sh
carvemegut build-universe --input genome.fasta --output model.xml
```

For a list of available commands:

```sh
carvemegut --help
```

### Python API

You can also use CarveMeGut as a Python module:

```python
import carvemegut

model = carvemegut.build_universe("genome.fasta")
model.save("model.xml")
```

## Configuration

CarveMeGut allows customization through a configuration file 
(`config.cfg`). This file contains parameters for model reconstruction, 
database paths, and computational settings.

## Data Sources
CarveMeGut integrates with multiple external metabolic databases, 
including:
- BiGG Models
- MetaNetX
- KEGG

## Contributing

We welcome contributions! To contribute:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature-branch`)
3. Commit changes (`git commit -m "Add new feature"`)
4. Push to the branch (`git push origin feature-branch`)
5. Open a Pull Request

## License

CarveMeGut is released under the MIT License.

## Contact
For questions or issues, please open an issue on 
[GitHub](https://github.com/yourusername/carvemegut/issues).


