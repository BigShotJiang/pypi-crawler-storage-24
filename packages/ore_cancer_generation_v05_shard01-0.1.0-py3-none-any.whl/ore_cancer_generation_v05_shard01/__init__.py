"""Data shard 1 for a generated asset package."""

PART_FILENAME = "part-0001.bin"
