"""Load structured JSON/YAML system profile input for compliance analysis."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from scanner.schemas import EvidenceItem, InputProfile


class InputValidationError(ValueError):
    """Raised when input file content is invalid."""


def load_input_profile(path: Path) -> InputProfile:
    """Load and validate an input profile from JSON or YAML."""

    if not path.exists():
        raise InputValidationError(f"Input file does not exist: {path}")

    suffix = path.suffix.lower()
    raw_text = path.read_text(encoding="utf-8")

    if suffix == ".json":
        payload = json.loads(raw_text)
    elif suffix in {".yaml", ".yml"}:
        payload = yaml.safe_load(raw_text)
    else:
        raise InputValidationError(
            f"Unsupported input extension '{suffix}'. Use .json, .yaml, or .yml."
        )

    if not isinstance(payload, dict):
        raise InputValidationError("Input document must be a JSON/YAML object.")

    metadata = _coerce_metadata(payload.get("metadata"))
    description = _coerce_string(payload.get("description"), "description")
    use_case = _coerce_string(payload.get("use_case"), "use_case")
    domain = _coerce_optional_string(payload.get("domain"), "domain")
    controls = _coerce_controls(payload.get("controls"))
    evidence = _coerce_evidence(payload.get("evidence"))

    return InputProfile(
        metadata=metadata,
        description=description,
        use_case=use_case,
        domain=domain,
        controls=controls,
        evidence=evidence,
    )


def _coerce_metadata(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise InputValidationError("'metadata' must be an object.")
    return value


def _coerce_string(value: Any, field_name: str) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise InputValidationError(f"'{field_name}' must be a string.")
    return value.strip()


def _coerce_optional_string(value: Any, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise InputValidationError(f"'{field_name}' must be a string when provided.")
    stripped = value.strip()
    return stripped or None


def _coerce_controls(value: Any) -> dict[str, bool]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise InputValidationError("'controls' must be an object of boolean-like values.")

    controls: dict[str, bool] = {}
    for raw_key, raw_value in value.items():
        if not isinstance(raw_key, str):
            raise InputValidationError("Control keys must be strings.")
        controls[raw_key] = _to_bool(raw_value)
    return controls


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y", "on"}:
            return True
        if normalized in {"false", "0", "no", "n", "off", ""}:
            return False
    raise InputValidationError(f"Invalid boolean-like value in controls: {value!r}")


def _coerce_evidence(value: Any) -> list[EvidenceItem]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise InputValidationError("'evidence' must be a list.")

    evidence_items: list[EvidenceItem] = []
    for index, item in enumerate(value):
        if isinstance(item, str):
            evidence_items.append(
                EvidenceItem(
                    id=f"evidence-{index + 1}",
                    description=item.strip(),
                    tags=[],
                )
            )
            continue

        if not isinstance(item, dict):
            raise InputValidationError("Each evidence item must be a string or object.")

        item_id = item.get("id") or f"evidence-{index + 1}"
        if not isinstance(item_id, str):
            raise InputValidationError("Evidence 'id' must be a string.")

        description = item.get("description", "")
        if not isinstance(description, str):
            raise InputValidationError("Evidence 'description' must be a string.")

        raw_tags = item.get("tags", [])
        if not isinstance(raw_tags, list) or not all(isinstance(tag, str) for tag in raw_tags):
            raise InputValidationError("Evidence 'tags' must be a list of strings.")

        evidence_items.append(
            EvidenceItem(
                id=item_id.strip() or f"evidence-{index + 1}",
                description=description.strip(),
                tags=[tag.strip() for tag in raw_tags if tag.strip()],
            )
        )

    return evidence_items
