"""CLI interface for AI Regulation Compliance Scanner."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from scanner import __version__
from scanner.analyzers.compliance import ComplianceAnalyzer
from scanner.classifiers.risk import RiskCategory, RiskClassifier
from scanner.input_loader import InputValidationError, load_input_profile
from scanner.reporters.compliance import ComplianceReporter
from scanner.schemas import ComplianceReport, InputProfile

EXIT_OK = 0
EXIT_HIGH_RISK = 1
EXIT_PROHIBITED = 2
EXIT_VALIDATION_ERROR = 3

SUPPORTED_REGULATIONS = {"eu-ai-act", "uk-ai", "nist-rmf"}
SUPPORTED_FORMATS = {"json", "text", "html", "pdf"}


def main(argv: Sequence[str] | None = None) -> int:
    """Main CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.format not in SUPPORTED_FORMATS:
        supported_formats = ", ".join(sorted(SUPPORTED_FORMATS))
        _print_error(
            f"Unsupported format '{args.format}'. Supported formats: {supported_formats}."
        )
        return EXIT_VALIDATION_ERROR

    try:
        regulations = _parse_regulations(args.regulation)
    except ValueError as exc:
        _print_error(str(exc))
        return EXIT_VALIDATION_ERROR

    if args.format == "pdf" and not args.output:
        _print_error("PDF output requires --output <file.pdf>.")
        return EXIT_VALIDATION_ERROR

    try:
        profile = _build_input_profile(args)
    except InputValidationError as exc:
        _print_error(str(exc))
        return EXIT_VALIDATION_ERROR

    classifier = RiskClassifier()
    risk_result = classifier.classify(
        system_description=profile.description,
        use_case=profile.use_case,
        domain=profile.domain,
    )

    compliance_analyzer = ComplianceAnalyzer()
    report = compliance_analyzer.analyze(
        profile=profile,
        regulations=regulations,
        risk_assessment=risk_result,
    )

    reporter = ComplianceReporter()
    rendered = _render_report(reporter, report, args.format)

    if args.output:
        if not _write_output(args.output, rendered):
            return EXIT_VALIDATION_ERROR
    else:
        if isinstance(rendered, bytes):
            _print_error("Binary output format requires --output.")
            return EXIT_VALIDATION_ERROR
        print(rendered, end="" if rendered.endswith("\n") else "\n")

    return _risk_exit_code(risk_result.category)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ai-scan",
        description="Scan AI systems for multi-regulation compliance (EU/UK/NIST)",
    )
    parser.add_argument(
        "--input",
        "-i",
        type=Path,
        help="Structured input file (.json/.yaml/.yml) with system profile and evidence",
    )
    parser.add_argument(
        "--model",
        "-m",
        type=Path,
        help="Path to model artifact (adds metadata and fallback description)",
    )
    parser.add_argument(
        "--description",
        "-d",
        help="Description of the AI system (overrides input file value)",
    )
    parser.add_argument(
        "--use-case",
        "-u",
        help="Primary use case (overrides input file value)",
    )
    parser.add_argument(
        "--domain",
        help="Application domain (overrides input file value)",
    )
    parser.add_argument(
        "--regulation",
        "-r",
        default="eu-ai-act",
        help="Comma-separated regulations (eu-ai-act,uk-ai,nist-rmf)",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output file path for report content",
    )
    parser.add_argument(
        "--format",
        "-f",
        default="text",
        help="Output format (text, json, html, pdf)",
    )
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def _parse_regulations(raw: str) -> list[str]:
    regulations = [item.strip() for item in raw.split(",") if item.strip()]
    if not regulations:
        raise ValueError("At least one regulation must be provided.")

    unsupported = [item for item in regulations if item not in SUPPORTED_REGULATIONS]
    if unsupported:
        supported = ", ".join(sorted(SUPPORTED_REGULATIONS))
        raise ValueError(
            f"Unsupported regulation(s): {', '.join(unsupported)}. Supported: {supported}."
        )
    return regulations


def _build_input_profile(args: argparse.Namespace) -> InputProfile:
    if args.input:
        profile = load_input_profile(args.input)
    else:
        profile = InputProfile(
            metadata={},
            description="",
            use_case="",
            domain=None,
            controls={},
            evidence=[],
        )

    if args.model:
        if not args.model.exists():
            raise InputValidationError(f"Model path does not exist: {args.model}")
        profile.metadata["model_path"] = str(args.model)
        if not profile.description:
            profile.description = f"Model at {args.model}"

    if args.description:
        profile.description = args.description.strip()
    if args.use_case:
        profile.use_case = args.use_case.strip()
    if args.domain:
        profile.domain = args.domain.strip() or None

    if not profile.description:
        raise InputValidationError("Provide --description, --model, or --input with description.")

    if not profile.use_case:
        profile.use_case = "unspecified"

    return profile


def _render_report(
    reporter: ComplianceReporter,
    report: ComplianceReport,
    format_type: str,
) -> str | bytes:
    if format_type == "json":
        return reporter.render_json(report) + "\n"
    if format_type == "html":
        return reporter.render_html(report)
    if format_type == "pdf":
        return reporter.render_pdf(report)
    return reporter.render_text(report)


def _write_output(output_path: Path, content: str | bytes) -> bool:
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            output_path.write_bytes(content)
        else:
            output_path.write_text(content, encoding="utf-8")
    except OSError as exc:
        _print_error(f"Failed to write output to '{output_path}': {exc}")
        return False
    return True


def _risk_exit_code(category: RiskCategory) -> int:
    if category == RiskCategory.PROHIBITED:
        return EXIT_PROHIBITED
    if category == RiskCategory.HIGH_RISK:
        return EXIT_HIGH_RISK
    return EXIT_OK


def _print_error(message: str) -> None:
    print(f"Error: {message}", file=sys.stderr)


if __name__ == "__main__":
    raise SystemExit(main())
