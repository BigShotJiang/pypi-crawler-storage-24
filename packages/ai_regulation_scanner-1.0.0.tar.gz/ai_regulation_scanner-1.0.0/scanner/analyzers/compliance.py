"""Multi-regulation compliance analyzer using YAML rule packs."""

from __future__ import annotations

from collections.abc import Iterable

from scanner.analyzers.documentation import DocumentationAnalyzer
from scanner.analyzers.rules import load_rule_pack
from scanner.classifiers.risk import RiskAssessment
from scanner.schemas import (
    ComplianceReport,
    InputProfile,
    RegulationResult,
    RequirementDefinition,
    RequirementResult,
    utc_now_iso,
)

PASS = "pass"
PARTIAL = "partial"
FAIL = "fail"
NOT_APPLICABLE = "not_applicable"


class ComplianceAnalyzer:
    """Evaluate controls and evidence against regulation rule packs."""

    def __init__(self) -> None:
        self._documentation_analyzer = DocumentationAnalyzer()

    def analyze(
        self,
        profile: InputProfile,
        regulations: Iterable[str],
        risk_assessment: RiskAssessment,
    ) -> ComplianceReport:
        """Evaluate the input profile against the requested regulations."""

        regulation_results: list[RegulationResult] = []
        findings: list[dict[str, object]] = []
        recommendations: list[str] = []

        for regulation in regulations:
            rule_pack = load_rule_pack(regulation)
            requirement_results: list[RequirementResult] = []
            earned = 0.0
            possible = 0.0

            for requirement in rule_pack.requirements:
                result = self._evaluate_requirement(profile, requirement)
                requirement_results.append(result)

                if result.status != NOT_APPLICABLE:
                    earned += result.score_earned
                    possible += result.score_possible

                findings.append(
                    {
                        "regulation": rule_pack.regulation,
                        "requirement_id": result.id,
                        "title": result.title,
                        "status": result.status,
                        "references": result.references,
                        "missing_controls": result.missing_controls,
                        "missing_evidence_keywords": result.missing_evidence_keywords,
                    }
                )

                if result.status in {FAIL, PARTIAL} and result.recommendation:
                    recommendations.append(result.recommendation)

            compliance_score = round((earned / possible) * 100, 2) if possible > 0 else 100.0

            regulation_results.append(
                RegulationResult(
                    regulation=rule_pack.regulation,
                    title=rule_pack.title,
                    compliance_score=compliance_score,
                    score_earned=round(earned, 2),
                    score_possible=round(possible, 2),
                    requirements=requirement_results,
                )
            )

        evidence_gaps = self._documentation_analyzer.extract_gaps(regulation_results)
        summary_scores = {
            result.regulation: result.compliance_score
            for result in regulation_results
        }

        deduplicated_recommendations = list(dict.fromkeys(recommendations))

        return ComplianceReport(
            metadata=dict(profile.metadata),
            generated_at=utc_now_iso(),
            risk_assessment=risk_assessment,
            regulations=regulation_results,
            summary_scores=summary_scores,
            findings=findings,
            recommendations=deduplicated_recommendations,
            evidence_gaps=evidence_gaps,
        )

    def _evaluate_requirement(
        self,
        profile: InputProfile,
        requirement: RequirementDefinition,
    ) -> RequirementResult:
        if not self._is_domain_applicable(profile.domain, requirement.domains):
            return RequirementResult(
                id=requirement.id,
                title=requirement.title,
                status=NOT_APPLICABLE,
                score_earned=0.0,
                score_possible=0.0,
                references=requirement.references,
                matched_controls=[],
                matched_evidence=[],
                missing_controls=[],
                missing_evidence_keywords=[],
                recommendation="",
            )

        matched_controls = [
            control_key
            for control_key in requirement.controls_any
            if profile.controls.get(control_key, False)
        ]
        missing_controls = [
            control_key
            for control_key in requirement.controls_any
            if control_key not in matched_controls
        ]

        evidence_texts = [
            " ".join([evidence.description, " ".join(evidence.tags)]).lower()
            for evidence in profile.evidence
        ]
        matched_evidence_keywords = [
            keyword
            for keyword in requirement.evidence_keywords
            if any(keyword.lower() in text for text in evidence_texts)
        ]
        missing_evidence_keywords = [
            keyword
            for keyword in requirement.evidence_keywords
            if keyword not in matched_evidence_keywords
        ]

        has_control_signal = bool(matched_controls)
        has_evidence_signal = bool(matched_evidence_keywords)

        if has_control_signal and has_evidence_signal:
            status = PASS
            score_earned = requirement.weight
        elif has_control_signal or has_evidence_signal:
            status = PARTIAL
            score_earned = requirement.weight * 0.5
        else:
            status = FAIL
            score_earned = 0.0

        return RequirementResult(
            id=requirement.id,
            title=requirement.title,
            status=status,
            score_earned=round(score_earned, 2),
            score_possible=requirement.weight,
            references=requirement.references,
            matched_controls=matched_controls,
            matched_evidence=matched_evidence_keywords,
            missing_controls=missing_controls,
            missing_evidence_keywords=missing_evidence_keywords,
            recommendation=requirement.recommendation,
        )

    def _is_domain_applicable(self, domain: str | None, allowed_domains: list[str] | None) -> bool:
        if not allowed_domains:
            return True
        if not domain:
            return False
        normalized_domain = domain.strip().lower()
        normalized_allowed_domains = {item.strip().lower() for item in allowed_domains}
        return normalized_domain in normalized_allowed_domains
