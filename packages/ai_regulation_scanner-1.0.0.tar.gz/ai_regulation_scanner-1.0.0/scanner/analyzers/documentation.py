"""Documentation/evidence gap analysis."""

from __future__ import annotations

from scanner.schemas import EvidenceGap, RegulationResult


class DocumentationAnalyzer:
    """Extract evidence and control gaps from regulation evaluation results."""

    def extract_gaps(self, regulation_results: list[RegulationResult]) -> list[EvidenceGap]:
        """Return evidence gaps for failed and partial requirements."""

        gaps: list[EvidenceGap] = []
        for regulation_result in regulation_results:
            for requirement in regulation_result.requirements:
                if requirement.status not in {"fail", "partial"}:
                    continue
                gaps.append(
                    EvidenceGap(
                        regulation=regulation_result.regulation,
                        requirement_id=requirement.id,
                        requirement_title=requirement.title,
                        missing_controls=requirement.missing_controls,
                        missing_evidence_keywords=requirement.missing_evidence_keywords,
                    )
                )
        return gaps
