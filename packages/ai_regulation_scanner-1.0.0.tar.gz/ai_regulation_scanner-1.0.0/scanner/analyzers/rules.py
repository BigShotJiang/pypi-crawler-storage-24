"""Rule pack loading utilities for regulation analyzers."""

from __future__ import annotations

from importlib import resources
from typing import Any

import yaml  # type: ignore[import-untyped]

from scanner.schemas import RegulationRulePack, RequirementDefinition

RULE_PACK_FILES = {
    "eu-ai-act": "eu-ai-act.yaml",
    "uk-ai": "uk-ai.yaml",
    "nist-rmf": "nist-rmf.yaml",
}


class RulePackError(ValueError):
    """Raised when a rule pack cannot be loaded or validated."""


def load_rule_pack(regulation: str) -> RegulationRulePack:
    """Load and validate a regulation rule pack from bundled YAML resources."""

    filename = RULE_PACK_FILES.get(regulation)
    if not filename:
        supported = ", ".join(sorted(RULE_PACK_FILES))
        raise RulePackError(f"Unsupported regulation '{regulation}'. Supported: {supported}")

    raw = resources.files("scanner.regulations").joinpath(filename).read_text(encoding="utf-8")
    payload = yaml.safe_load(raw)

    if not isinstance(payload, dict):
        raise RulePackError(f"Rule pack '{filename}' must contain an object at top level.")

    regulation_name = _require_str(payload.get("regulation"), "regulation")
    title = _require_str(payload.get("title"), "title")
    requirements_raw = payload.get("requirements")

    if not isinstance(requirements_raw, list) or not requirements_raw:
        raise RulePackError(f"Rule pack '{filename}' has no requirements.")

    requirements: list[RequirementDefinition] = []
    for requirement_raw in requirements_raw:
        if not isinstance(requirement_raw, dict):
            raise RulePackError("Requirement entries must be objects.")

        requirements.append(
            RequirementDefinition(
                id=_require_str(requirement_raw.get("id"), "requirements[].id"),
                title=_require_str(requirement_raw.get("title"), "requirements[].title"),
                description=_require_str(
                    requirement_raw.get("description"),
                    "requirements[].description",
                ),
                references=_require_str_list(
                    requirement_raw.get("references", []),
                    "requirements[].references",
                ),
                controls_any=_require_str_list(
                    requirement_raw.get("controls_any", []),
                    "requirements[].controls_any",
                ),
                evidence_keywords=_require_str_list(
                    requirement_raw.get("evidence_keywords", []),
                    "requirements[].evidence_keywords",
                ),
                weight=_require_float(requirement_raw.get("weight", 1), "requirements[].weight"),
                recommendation=_require_str(
                    requirement_raw.get("recommendation", ""),
                    "requirements[].recommendation",
                ),
                domains=_optional_str_list(
                    requirement_raw.get("domains"),
                    "requirements[].domains",
                ),
            )
        )

    return RegulationRulePack(
        regulation=regulation_name,
        title=title,
        requirements=requirements,
    )


def _require_str(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise RulePackError(f"Field '{field_name}' must be a non-empty string.")
    return value.strip()


def _require_str_list(value: Any, field_name: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise RulePackError(f"Field '{field_name}' must be a list of strings.")
    return [item.strip() for item in value if item.strip()]


def _optional_str_list(value: Any, field_name: str) -> list[str] | None:
    if value is None:
        return None
    return _require_str_list(value, field_name)


def _require_float(value: Any, field_name: str) -> float:
    if not isinstance(value, (int, float)):
        raise RulePackError(f"Field '{field_name}' must be a number.")
    if float(value) <= 0:
        raise RulePackError(f"Field '{field_name}' must be > 0.")
    return float(value)
