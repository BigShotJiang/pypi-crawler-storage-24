"""Risk classification modules."""

from scanner.classifiers.risk import RiskCategory, RiskClassifier

__all__ = ["RiskClassifier", "RiskCategory"]
