"""Risk classification for AI systems under the EU AI Act."""

from dataclasses import dataclass
from enum import Enum


class RiskCategory(Enum):
    """AI Act risk categories."""

    PROHIBITED = "prohibited"
    HIGH_RISK = "high_risk"
    LIMITED = "limited"
    MINIMAL = "minimal"


@dataclass
class RiskAssessment:
    """Result of risk classification."""

    category: RiskCategory
    confidence: float
    reasons: list[str]
    required_actions: list[str]
    applicable_articles: list[str]


class RiskClassifier:
    """Classify AI systems by risk level per EU AI Act."""

    # Prohibited use cases (Article 5)
    PROHIBITED_KEYWORDS = {
        "social_scoring": ["social credit", "social scoring", "citizen scoring"],
        "subliminal": ["subliminal manipulation", "subliminal techniques"],
        "exploitation": ["exploit vulnerabilities", "exploit children", "exploit elderly"],
        "biometric_realtime": [
            "real-time biometric",
            "live facial recognition",
            "mass surveillance",
        ],
    }

    # High-risk categories (Annex III)
    HIGH_RISK_DOMAINS = {
        "biometric": [
            "biometric identification",
            "biometric categorisation",
            "emotion recognition",
        ],
        "critical_infrastructure": ["electricity", "gas", "water supply", "transport"],
        "education": ["student assessment", "admission decisions", "learning analytics"],
        "employment": ["recruitment", "hiring decisions", "performance monitoring", "termination"],
        "essential_services": [
            "credit scoring",
            "insurance",
            "social benefits",
            "emergency services",
        ],
        "law_enforcement": ["crime prediction", "evidence assessment", "profiling"],
        "migration": ["visa assessment", "asylum", "border control"],
        "justice": ["legal interpretation", "sentencing", "judicial decisions"],
        "healthcare": [
            "medical diagnosis",
            "clinical decision",
            "triage",
            "treatment recommendation",
        ],
    }

    # Limited risk (transparency obligations)
    LIMITED_RISK_KEYWORDS = [
        "chatbot",
        "conversational ai",
        "emotion detection",
        "deepfake",
        "synthetic content",
        "ai-generated",
    ]

    def __init__(self) -> None:
        """Initialize the risk classifier."""
        self._assessment_cache: dict[str, RiskAssessment] = {}

    def classify(
        self,
        system_description: str,
        use_case: str,
        domain: str | None = None,
    ) -> RiskAssessment:
        """
        Classify an AI system's risk level.

        Args:
            system_description: Description of the AI system
            use_case: Primary use case
            domain: Application domain (optional)

        Returns:
            RiskAssessment with category, confidence, and recommendations
        """
        combined_text = f"{system_description} {use_case} {domain or ''}".lower()

        # Check for prohibited uses first
        prohibited_reasons = self._check_prohibited(combined_text)
        if prohibited_reasons:
            return RiskAssessment(
                category=RiskCategory.PROHIBITED,
                confidence=0.95,
                reasons=prohibited_reasons,
                required_actions=[
                    "This AI system appears to fall under prohibited use cases",
                    "Deployment in the EU is not permitted",
                    "Consult legal counsel immediately",
                ],
                applicable_articles=["Article 5 - Prohibited AI Practices"],
            )

        # Check for high-risk domains
        high_risk_reasons = self._check_high_risk(combined_text, domain)
        if high_risk_reasons:
            return RiskAssessment(
                category=RiskCategory.HIGH_RISK,
                confidence=0.85,
                reasons=high_risk_reasons,
                required_actions=[
                    "Implement risk management system",
                    "Ensure data governance compliance",
                    "Provide technical documentation",
                    "Implement human oversight mechanisms",
                    "Register in EU database (if applicable)",
                ],
                applicable_articles=[
                    "Article 9 - Risk Management System",
                    "Article 10 - Data Governance",
                    "Article 11 - Technical Documentation",
                    "Article 13 - Transparency",
                    "Article 14 - Human Oversight",
                ],
            )

        # Check for limited risk (transparency obligations)
        limited_reasons = self._check_limited_risk(combined_text)
        if limited_reasons:
            return RiskAssessment(
                category=RiskCategory.LIMITED,
                confidence=0.80,
                reasons=limited_reasons,
                required_actions=[
                    "Inform users they are interacting with AI",
                    "Label AI-generated content appropriately",
                    "Provide opt-out mechanisms where applicable",
                ],
                applicable_articles=[
                    "Article 52 - Transparency Obligations",
                ],
            )

        # Default to minimal risk
        return RiskAssessment(
            category=RiskCategory.MINIMAL,
            confidence=0.70,
            reasons=["No specific risk indicators identified"],
            required_actions=[
                "Consider voluntary codes of conduct",
                "Maintain basic documentation",
            ],
            applicable_articles=[
                "Article 69 - Codes of Conduct",
            ],
        )

    def _check_prohibited(self, text: str) -> list[str]:
        """Check for prohibited use case indicators."""
        reasons = []
        for category, keywords in self.PROHIBITED_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    reasons.append(f"Prohibited indicator: {category} (matched: '{keyword}')")
        return reasons

    def _check_high_risk(self, text: str, domain: str | None) -> list[str]:
        """Check for high-risk domain indicators."""
        reasons = []

        # Check domain keywords
        for risk_domain, keywords in self.HIGH_RISK_DOMAINS.items():
            for keyword in keywords:
                if keyword in text:
                    reasons.append(f"High-risk domain: {risk_domain} (matched: '{keyword}')")

        # Check explicit domain
        if domain and domain.lower() in self.HIGH_RISK_DOMAINS:
            reasons.append(f"Explicitly high-risk domain: {domain}")

        return reasons

    def _check_limited_risk(self, text: str) -> list[str]:
        """Check for limited risk indicators."""
        reasons = []
        for keyword in self.LIMITED_RISK_KEYWORDS:
            if keyword in text:
                reasons.append(f"Transparency obligation trigger: '{keyword}'")
        return reasons


def main() -> None:
    """CLI entry point for risk classification."""
    import argparse

    parser = argparse.ArgumentParser(description="Classify AI system risk level")
    parser.add_argument("--description", "-d", required=True, help="System description")
    parser.add_argument("--use-case", "-u", required=True, help="Primary use case")
    parser.add_argument("--domain", help="Application domain")

    args = parser.parse_args()

    classifier = RiskClassifier()
    result = classifier.classify(
        system_description=args.description,
        use_case=args.use_case,
        domain=args.domain,
    )

    print(f"\nRisk Category: {result.category.value.upper()}")
    print(f"Confidence: {result.confidence:.0%}")
    print("\nReasons:")
    for reason in result.reasons:
        print(f"  - {reason}")
    print("\nRequired Actions:")
    for action in result.required_actions:
        print(f"  - {action}")
    print("\nApplicable Articles:")
    for article in result.applicable_articles:
        print(f"  - {article}")


if __name__ == "__main__":
    main()
