"""Core data models for compliance evaluation and reporting."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from scanner.classifiers.risk import RiskAssessment


@dataclass(slots=True)
class EvidenceItem:
    """Evidence artifact supplied by users."""

    id: str
    description: str
    tags: list[str] = field(default_factory=list)


@dataclass(slots=True)
class InputProfile:
    """Structured profile describing an AI system and compliance controls."""

    metadata: dict[str, Any]
    description: str
    use_case: str
    domain: str | None
    controls: dict[str, bool]
    evidence: list[EvidenceItem]


@dataclass(slots=True)
class RequirementDefinition:
    """Rule-pack requirement definition."""

    id: str
    title: str
    description: str
    references: list[str]
    controls_any: list[str]
    evidence_keywords: list[str]
    weight: float
    recommendation: str
    domains: list[str] | None = None


@dataclass(slots=True)
class RegulationRulePack:
    """Collection of requirements for a regulation."""

    regulation: str
    title: str
    requirements: list[RequirementDefinition]


@dataclass(slots=True)
class RequirementResult:
    """Evaluation result for a single requirement."""

    id: str
    title: str
    status: str
    score_earned: float
    score_possible: float
    references: list[str]
    matched_controls: list[str]
    matched_evidence: list[str]
    missing_controls: list[str]
    missing_evidence_keywords: list[str]
    recommendation: str


@dataclass(slots=True)
class RegulationResult:
    """Evaluation result for one regulation."""

    regulation: str
    title: str
    compliance_score: float
    score_earned: float
    score_possible: float
    requirements: list[RequirementResult]


@dataclass(slots=True)
class EvidenceGap:
    """Missing evidence/control summary for a failed or partial requirement."""

    regulation: str
    requirement_id: str
    requirement_title: str
    missing_controls: list[str]
    missing_evidence_keywords: list[str]


@dataclass(slots=True)
class ComplianceReport:
    """Canonical multi-regulation compliance report."""

    metadata: dict[str, Any]
    generated_at: str
    risk_assessment: RiskAssessment
    regulations: list[RegulationResult]
    summary_scores: dict[str, float]
    findings: list[dict[str, Any]]
    recommendations: list[str]
    evidence_gaps: list[EvidenceGap]


def utc_now_iso() -> str:
    """Return RFC3339 timestamp in UTC."""

    return datetime.now(tz=timezone.utc).replace(microsecond=0).isoformat()
