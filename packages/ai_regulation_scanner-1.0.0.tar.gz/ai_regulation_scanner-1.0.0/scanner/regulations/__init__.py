"""Bundled regulation rule packs."""
