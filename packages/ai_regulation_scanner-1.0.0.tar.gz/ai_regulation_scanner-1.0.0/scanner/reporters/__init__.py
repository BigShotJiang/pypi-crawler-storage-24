"""Compliance report renderers."""

from scanner.reporters.compliance import ComplianceReporter

__all__ = ["ComplianceReporter"]
