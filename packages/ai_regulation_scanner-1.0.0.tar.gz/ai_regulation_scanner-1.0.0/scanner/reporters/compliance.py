"""Compliance report rendering (JSON, text, HTML, PDF)."""

from __future__ import annotations

import html
import json
from io import BytesIO
from typing import Any

from scanner.schemas import ComplianceReport, EvidenceGap, RegulationResult, RequirementResult


class ComplianceReporter:
    """Render compliance reports in multiple formats."""

    def to_dict(self, report: ComplianceReport) -> dict[str, Any]:
        """Return canonical report dictionary for machine processing."""

        regulations = [self._regulation_to_dict(result) for result in report.regulations]
        evidence_gaps = [self._gap_to_dict(gap) for gap in report.evidence_gaps]

        return {
            "metadata": report.metadata,
            "generated_at": report.generated_at,
            "risk_assessment": {
                "category": report.risk_assessment.category.value,
                "confidence": report.risk_assessment.confidence,
                "reasons": report.risk_assessment.reasons,
                "required_actions": report.risk_assessment.required_actions,
                "applicable_articles": report.risk_assessment.applicable_articles,
            },
            "regulations": regulations,
            "summary_scores": report.summary_scores,
            "findings": report.findings,
            "recommendations": report.recommendations,
            "evidence_gaps": evidence_gaps,
        }

    def render_json(self, report: ComplianceReport) -> str:
        """Render report as pretty JSON."""

        return json.dumps(self.to_dict(report), indent=2)

    def render_text(self, report: ComplianceReport) -> str:
        """Render report as human-readable text."""

        lines = [
            "AI Compliance Report",
            f"Generated At: {report.generated_at}",
            f"Risk Category: {report.risk_assessment.category.value.upper()}",
            f"Risk Confidence: {report.risk_assessment.confidence:.0%}",
            "",
            "Regulation Scores:",
        ]

        for regulation in report.regulations:
            lines.append(
                f"  - {regulation.regulation}: {regulation.compliance_score:.2f}% "
                f"({regulation.score_earned:.2f}/{regulation.score_possible:.2f})"
            )

        lines.extend(["", "Top Gaps:"])
        for gap in report.evidence_gaps[:10]:
            lines.append(
                f"  - [{gap.regulation}] {gap.requirement_id}: "
                f"controls={','.join(gap.missing_controls) or 'none'}; "
                f"evidence={','.join(gap.missing_evidence_keywords) or 'none'}"
            )

        lines.extend(["", "Recommendations:"])
        for recommendation in report.recommendations:
            lines.append(f"  - {recommendation}")

        return "\n".join(lines) + "\n"

    def render_html(self, report: ComplianceReport) -> str:
        """Render report as lightweight HTML."""

        regulation_rows = "\n".join(
            [
                "<tr>"
                f"<td>{html.escape(result.regulation)}</td>"
                f"<td>{result.compliance_score:.2f}%</td>"
                f"<td>{result.score_earned:.2f}/{result.score_possible:.2f}</td>"
                "</tr>"
                for result in report.regulations
            ]
        )

        gap_rows = "\n".join(
            [
                "<tr>"
                f"<td>{html.escape(gap.regulation)}</td>"
                f"<td>{html.escape(gap.requirement_id)}</td>"
                f"<td>{html.escape(', '.join(gap.missing_controls) or 'n/a')}</td>"
                f"<td>{html.escape(', '.join(gap.missing_evidence_keywords) or 'n/a')}</td>"
                "</tr>"
                for gap in report.evidence_gaps
            ]
        )

        recommendation_items = "\n".join(
            [f"<li>{html.escape(item)}</li>" for item in report.recommendations]
        )

        return f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <title>AI Compliance Report</title>
  <style>
    :root {{ color-scheme: light; }}
    body {{ font-family: 'Segoe UI', Tahoma, sans-serif; margin: 2rem; color: #1f2937; }}
    h1, h2 {{ margin-bottom: 0.4rem; }}
    table {{ border-collapse: collapse; width: 100%; margin-bottom: 1.5rem; }}
    th, td {{ border: 1px solid #d1d5db; padding: 0.5rem; text-align: left; }}
    th {{ background: #f3f4f6; }}
    .meta {{ margin-bottom: 1.5rem; }}
  </style>
</head>
<body>
  <h1>AI Compliance Report</h1>
  <div class=\"meta\">
    <p><strong>Generated At:</strong> {html.escape(report.generated_at)}</p>
    <p><strong>Risk Category:</strong> {html.escape(report.risk_assessment.category.value)}</p>
    <p><strong>Risk Confidence:</strong> {report.risk_assessment.confidence:.0%}</p>
  </div>

  <h2>Regulation Scores</h2>
  <table>
    <thead><tr><th>Regulation</th><th>Score</th><th>Points</th></tr></thead>
    <tbody>
      {regulation_rows}
    </tbody>
  </table>

  <h2>Evidence Gaps</h2>
  <table>
    <thead>
      <tr>
        <th>Regulation</th>
        <th>Requirement</th>
        <th>Missing Controls</th>
        <th>Missing Evidence</th>
      </tr>
    </thead>
    <tbody>
      {gap_rows}
    </tbody>
  </table>

  <h2>Recommendations</h2>
  <ul>
    {recommendation_items}
  </ul>
</body>
</html>
"""

    def render_pdf(self, report: ComplianceReport) -> bytes:
        """Render report into a basic valid PDF document."""

        text_lines = [
            "AI Compliance Report",
            f"Generated At: {report.generated_at}",
            f"Risk Category: {report.risk_assessment.category.value}",
            f"Risk Confidence: {report.risk_assessment.confidence:.0%}",
            "",
            "Regulation Scores:",
        ]
        text_lines.extend(
            [
                (
                    f"- {result.regulation}: {result.compliance_score:.2f}% "
                    f"({result.score_earned:.2f}/{result.score_possible:.2f})"
                )
                for result in report.regulations
            ]
        )
        text_lines.extend(["", "Recommendations:"])
        text_lines.extend([f"- {item}" for item in report.recommendations])

        return _simple_text_pdf(text_lines)

    def _regulation_to_dict(self, result: RegulationResult) -> dict[str, Any]:
        return {
            "regulation": result.regulation,
            "title": result.title,
            "compliance_score": result.compliance_score,
            "score_earned": result.score_earned,
            "score_possible": result.score_possible,
            "requirements": [self._requirement_to_dict(item) for item in result.requirements],
        }

    def _requirement_to_dict(self, result: RequirementResult) -> dict[str, Any]:
        return {
            "id": result.id,
            "title": result.title,
            "status": result.status,
            "score_earned": result.score_earned,
            "score_possible": result.score_possible,
            "references": result.references,
            "matched_controls": result.matched_controls,
            "matched_evidence": result.matched_evidence,
            "missing_controls": result.missing_controls,
            "missing_evidence_keywords": result.missing_evidence_keywords,
            "recommendation": result.recommendation,
        }

    def _gap_to_dict(self, gap: EvidenceGap) -> dict[str, Any]:
        return {
            "regulation": gap.regulation,
            "requirement_id": gap.requirement_id,
            "requirement_title": gap.requirement_title,
            "missing_controls": gap.missing_controls,
            "missing_evidence_keywords": gap.missing_evidence_keywords,
        }


def _simple_text_pdf(lines: list[str]) -> bytes:
    """Create a minimal one-page PDF from text lines without external dependencies."""

    escaped_lines = [_escape_pdf_text(line) for line in lines]
    content_parts = ["BT", "/F1 11 Tf", "50 800 Td", "14 TL"]
    for line in escaped_lines:
        content_parts.append(f"({line}) Tj")
        content_parts.append("T*")
    content_parts.append("ET")
    content = "\n".join(content_parts).encode("latin-1", errors="replace")

    objects: list[bytes] = [
        b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
        b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
        (
            b"3 0 obj\n"
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] "
            b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\n"
            b"endobj\n"
        ),
        b"4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n",
        b"5 0 obj\n<< /Length " + str(len(content)).encode("ascii") + b" >>\nstream\n"
        + content
        + b"\nendstream\nendobj\n",
    ]

    buffer = BytesIO()
    buffer.write(b"%PDF-1.4\n")

    offsets = [0]
    for obj in objects:
        offsets.append(buffer.tell())
        buffer.write(obj)

    xref_start = buffer.tell()
    buffer.write(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    buffer.write(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        buffer.write(f"{offset:010} 00000 n \n".encode("ascii"))

    trailer = (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_start}\n%%EOF\n"
    )
    buffer.write(trailer.encode("ascii"))
    return buffer.getvalue()


def _escape_pdf_text(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("(", "\\(")
        .replace(")", "\\)")
    )
