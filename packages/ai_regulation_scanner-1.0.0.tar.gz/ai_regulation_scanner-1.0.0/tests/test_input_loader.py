"""Tests for structured input loader."""

from pathlib import Path

import pytest

from scanner.input_loader import InputValidationError, load_input_profile

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def test_loads_yaml_profile() -> None:
    profile = load_input_profile(FIXTURES_DIR / "system_profile.yaml")

    assert profile.description.startswith("Clinical decision support")
    assert profile.use_case == "medical diagnosis support"
    assert profile.domain == "healthcare"
    assert profile.controls["risk_management_system"] is True
    assert profile.controls["human_oversight"] is False
    assert len(profile.evidence) == 5


def test_loads_json_profile_with_string_evidence() -> None:
    profile = load_input_profile(FIXTURES_DIR / "system_profile.json")

    assert profile.domain == "finance"
    assert profile.controls["user_transparency"] is True
    assert profile.evidence[1].id == "evidence-2"
    assert profile.evidence[1].description == "risk management plan"


def test_rejects_unsupported_extension(tmp_path: Path) -> None:
    file_path = tmp_path / "profile.txt"
    file_path.write_text("hello", encoding="utf-8")

    with pytest.raises(InputValidationError):
        load_input_profile(file_path)
