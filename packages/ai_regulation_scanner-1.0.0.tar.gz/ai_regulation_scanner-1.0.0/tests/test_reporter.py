"""Tests for compliance report renderers."""

import json
from pathlib import Path

from scanner.analyzers.compliance import ComplianceAnalyzer
from scanner.classifiers.risk import RiskClassifier
from scanner.input_loader import load_input_profile
from scanner.reporters.compliance import ComplianceReporter

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _sample_report():
    profile = load_input_profile(FIXTURES_DIR / "system_profile.yaml")
    risk = RiskClassifier().classify(
        system_description=profile.description,
        use_case=profile.use_case,
        domain=profile.domain,
    )
    return ComplianceAnalyzer().analyze(
        profile=profile,
        regulations=["eu-ai-act", "uk-ai"],
        risk_assessment=risk,
    )


def test_json_renderer_returns_canonical_keys() -> None:
    report = _sample_report()
    rendered = ComplianceReporter().render_json(report)
    payload = json.loads(rendered)

    assert set(payload.keys()) == {
        "metadata",
        "generated_at",
        "risk_assessment",
        "regulations",
        "summary_scores",
        "findings",
        "recommendations",
        "evidence_gaps",
    }


def test_html_renderer_contains_expected_sections() -> None:
    report = _sample_report()
    html_content = ComplianceReporter().render_html(report)

    assert "<h1>AI Compliance Report</h1>" in html_content
    assert "Regulation Scores" in html_content
    assert "Evidence Gaps" in html_content


def test_pdf_renderer_produces_pdf_bytes() -> None:
    report = _sample_report()
    pdf_bytes = ComplianceReporter().render_pdf(report)

    assert pdf_bytes.startswith(b"%PDF-1.4")
    assert b"AI Compliance Report" in pdf_bytes
