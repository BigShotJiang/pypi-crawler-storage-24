"""Tests for CLI contract and output behavior."""

from __future__ import annotations

import json
from pathlib import Path

from scanner.cli import (
    EXIT_HIGH_RISK,
    EXIT_OK,
    EXIT_PROHIBITED,
    EXIT_VALIDATION_ERROR,
    main,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def test_requires_model_description_or_input(capsys) -> None:
    exit_code = main(["--use-case", "support"])
    captured = capsys.readouterr()

    assert exit_code == EXIT_VALIDATION_ERROR
    assert "Provide --description, --model, or --input" in captured.err


def test_rejects_unknown_regulation(capsys) -> None:
    exit_code = main(
        [
            "--description",
            "Customer support chatbot",
            "--use-case",
            "support",
            "--regulation",
            "foo-reg",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_VALIDATION_ERROR
    assert "Unsupported regulation(s): foo-reg" in captured.err


def test_rejects_unsupported_format(capsys) -> None:
    exit_code = main(
        [
            "--description",
            "Customer support chatbot",
            "--use-case",
            "support",
            "--format",
            "docx",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_VALIDATION_ERROR
    assert "Unsupported format 'docx'" in captured.err


def test_json_output_file_with_multi_regulation(tmp_path: Path, capsys) -> None:
    output_file = tmp_path / "report.json"

    exit_code = main(
        [
            "--input",
            str(FIXTURES_DIR / "system_profile.yaml"),
            "--regulation",
            "eu-ai-act,uk-ai,nist-rmf",
            "--format",
            "json",
            "--output",
            str(output_file),
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_HIGH_RISK
    assert captured.out == ""
    assert output_file.exists()

    payload = json.loads(output_file.read_text(encoding="utf-8"))
    assert set(payload["summary_scores"].keys()) == {"eu-ai-act", "uk-ai", "nist-rmf"}
    assert payload["risk_assessment"]["category"] == "high_risk"
    assert payload["regulations"]


def test_pdf_requires_output_path(capsys) -> None:
    exit_code = main(
        [
            "--description",
            "Customer support chatbot",
            "--use-case",
            "support",
            "--format",
            "pdf",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_VALIDATION_ERROR
    assert "PDF output requires --output" in captured.err


def test_pdf_writes_file(tmp_path: Path) -> None:
    output_file = tmp_path / "report.pdf"

    exit_code = main(
        [
            "--input",
            str(FIXTURES_DIR / "system_profile.json"),
            "--regulation",
            "eu-ai-act,uk-ai",
            "--format",
            "pdf",
            "--output",
            str(output_file),
        ]
    )

    assert exit_code == EXIT_OK
    content = output_file.read_bytes()
    assert content.startswith(b"%PDF-1.4")


def test_exit_codes_by_risk() -> None:
    prohibited_code = main(
        [
            "--description",
            "social scoring system for citizens",
            "--use-case",
            "social scoring",
        ]
    )
    high_risk_code = main(
        [
            "--description",
            "clinical assistant model",
            "--use-case",
            "medical diagnosis",
        ]
    )
    minimal_code = main(
        [
            "--description",
            "board game recommendation helper",
            "--use-case",
            "entertainment",
        ]
    )

    assert prohibited_code == EXIT_PROHIBITED
    assert high_risk_code == EXIT_HIGH_RISK
    assert minimal_code == EXIT_OK
