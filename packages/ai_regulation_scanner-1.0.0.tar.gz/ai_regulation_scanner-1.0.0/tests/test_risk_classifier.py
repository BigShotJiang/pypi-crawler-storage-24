"""Tests for EU AI Act risk classifier."""

from scanner.classifiers.risk import RiskCategory, RiskClassifier


def test_classifies_prohibited_use_case() -> None:
    classifier = RiskClassifier()

    result = classifier.classify(
        system_description="Citizen social scoring platform",
        use_case="social scoring",
        domain="public sector",
    )

    assert result.category == RiskCategory.PROHIBITED
    assert result.applicable_articles == ["Article 5 - Prohibited AI Practices"]


def test_classifies_high_risk_use_case() -> None:
    classifier = RiskClassifier()

    result = classifier.classify(
        system_description="Clinical support model for hospitals",
        use_case="medical diagnosis",
        domain="healthcare",
    )

    assert result.category == RiskCategory.HIGH_RISK
    assert any("High-risk domain: healthcare" in reason for reason in result.reasons)


def test_classifies_limited_risk_use_case() -> None:
    classifier = RiskClassifier()

    result = classifier.classify(
        system_description="Conversational AI chatbot",
        use_case="customer support",
        domain="retail",
    )

    assert result.category == RiskCategory.LIMITED
    assert result.applicable_articles == ["Article 52 - Transparency Obligations"]


def test_classifies_minimal_risk_use_case() -> None:
    classifier = RiskClassifier()

    result = classifier.classify(
        system_description="Turn-based board game assistant",
        use_case="game recommendations",
        domain="gaming",
    )

    assert result.category == RiskCategory.MINIMAL
    assert result.applicable_articles == ["Article 69 - Codes of Conduct"]
