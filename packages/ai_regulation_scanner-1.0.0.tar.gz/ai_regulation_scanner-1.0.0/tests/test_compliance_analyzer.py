"""Tests for multi-regulation compliance analyzer."""

from pathlib import Path

from scanner.analyzers.compliance import ComplianceAnalyzer
from scanner.classifiers.risk import RiskClassifier
from scanner.input_loader import load_input_profile

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def test_analyzes_multiple_regulations() -> None:
    profile = load_input_profile(FIXTURES_DIR / "system_profile.yaml")
    risk = RiskClassifier().classify(
        system_description=profile.description,
        use_case=profile.use_case,
        domain=profile.domain,
    )

    report = ComplianceAnalyzer().analyze(
        profile=profile,
        regulations=["eu-ai-act", "uk-ai", "nist-rmf"],
        risk_assessment=risk,
    )

    assert set(report.summary_scores.keys()) == {"eu-ai-act", "uk-ai", "nist-rmf"}
    assert len(report.regulations) == 3
    assert report.findings
    assert report.recommendations

    statuses = {
        requirement.status
        for regulation in report.regulations
        for requirement in regulation.requirements
    }
    assert statuses.issubset({"pass", "partial", "fail", "not_applicable"})


def test_generates_evidence_gaps_for_missing_controls() -> None:
    profile = load_input_profile(FIXTURES_DIR / "system_profile.yaml")
    risk = RiskClassifier().classify(
        system_description=profile.description,
        use_case=profile.use_case,
        domain=profile.domain,
    )

    report = ComplianceAnalyzer().analyze(
        profile=profile,
        regulations=["eu-ai-act"],
        risk_assessment=risk,
    )

    assert report.evidence_gaps
    assert any("human_oversight" in gap.missing_controls for gap in report.evidence_gaps)
