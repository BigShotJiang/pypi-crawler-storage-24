# AI Regulation Compliance Scanner

Open-source CLI to evaluate AI systems against **EU AI Act**, **UK AI principles**, and **NIST AI RMF**.

## v1.0 Scope

### Implemented

- Multi-regulation rule evaluation via YAML rule packs (`eu-ai-act`, `uk-ai`, `nist-rmf`)
- Structured system profile input (`--input` JSON/YAML)
- Compliance statuses per requirement: `pass`, `partial`, `fail`, `not_applicable`
- Gap scoring and recommendation generation
- Report outputs:
  - `text`
  - `json` (canonical machine-readable schema)
  - `html`
  - `pdf`
- CI quality gates:
  - `pytest -q`
  - `ruff check .`
  - `mypy scanner`
  - `python -m build`

### Out of Scope

- Automatic legal interpretation beyond rule-based checks
- Fairlearn/AIF360 and SHAP/LIME runtime integrations

## Install

```bash
pip install ai-regulation-scanner
```

For local development:

```bash
pip install -e '.[dev]'
```

## Quick Start

```bash
# Evaluate all supported regulations from a structured profile
ai-scan --input ./profile.yaml --regulation eu-ai-act,uk-ai,nist-rmf --format json --output ./report.json

# Render HTML report
ai-scan --input ./profile.yaml --regulation eu-ai-act,uk-ai --format html --output ./report.html

# Render PDF report
ai-scan --input ./profile.yaml --regulation eu-ai-act,uk-ai,nist-rmf --format pdf --output ./report.pdf
```

## Input Model (`--input`)

Supported extensions: `.json`, `.yaml`, `.yml`.

```yaml
metadata:
  system_name: "Example AI System"
  owner: "AI Governance"
description: "Clinical triage assistant"
use_case: "medical diagnosis support"
domain: "healthcare"
controls:
  risk_management_system: true
  data_governance: true
  technical_documentation: true
  human_oversight: false
evidence:
  - id: "ev-1"
    description: "Risk management plan and risk register"
    tags: ["risk management"]
  - "model card and technical documentation"
```

## CLI Contract

- `--regulation`: comma-separated values from `eu-ai-act,uk-ai,nist-rmf`
- `--format`: `text|json|html|pdf`
- `--output`: optional for text/json/html, required for pdf

### Exit Codes

- `0`: Minimal/limited risk category
- `1`: High-risk category
- `2`: Prohibited category
- `3`: Validation/runtime error (input/args/output)

## Canonical JSON Report Shape

Top-level keys:

- `metadata`
- `generated_at`
- `risk_assessment`
- `regulations`
- `summary_scores`
- `findings`
- `recommendations`
- `evidence_gaps`

## Release & Publishing

- GitHub Actions `CI` workflow enforces quality gates on PR/main.
- GitHub Actions `Release` workflow runs on `v*` tags.
- PyPI publish uses **Trusted Publishing** (`id-token: write`).
- Setup guide: [docs/pypi-trusted-publishing.md](docs/pypi-trusted-publishing.md)

## License

Apache 2.0 - See [LICENSE](LICENSE)

## Disclaimer

This tool provides compliance guidance only and does not constitute legal advice.
Always consult qualified legal counsel for regulatory decisions.
