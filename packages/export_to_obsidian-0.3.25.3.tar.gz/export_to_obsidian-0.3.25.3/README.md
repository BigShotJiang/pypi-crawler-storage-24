[![Contributors](https://img.shields.io/github/contributors/bGZo/playground.svg?style=for-the-badge)](https://github.com/bGZo/playground/graphs/contributors)
[![Forks](https://img.shields.io/github/forks/bGZo/playground.svg?style=for-the-badge)](https://github.com/bGZo/playground/network/members)
[![Stargazers](https://img.shields.io/github/stars/bGZo/playground.svg?style=for-the-badge)](https://github.com/bGZo/playground/stargazers)
[![Issues](https://img.shields.io/github/issues/bGZo/playground.svg?style=for-the-badge)](https://github.com/bGZo/playground/issues)
[![Licence](https://img.shields.io/github/license/bGZo/playground.svg?style=for-the-badge)](https://github.com/bGZo/playground/blob/template/LICENCE)
[![Telegram](https://img.shields.io/badge/-telegram-black.svg?style=for-the-badge&logo=telegram&colorB=555)](https://t.me/imbGZo)

# Export all your data into Obsidian

Your data is your asset, you should own it. This tool helps you export your data from various platforms into markdown files that can be easily imported and managed by Obsidian.

## Getting Started

Before you start, make sure you have Git installed on your machine. You can download it from [here](https://git-scm.com/downloads).

```python
pipx install export_to_obsidian
```


Get your token or cookies from the target platform, then input in `.env.bak` and rename it to `.env`, source it via:

```shell
chmod +x ./export-env.sh
./export-env.sh
```

## Usage

### 博客园

```shell
export CNBLOG_ACCESS_TOKEN=xxx
eto cnblog --output output/cnblog
```

### Bangumi 

```shell
export BGM_ACCESS_TOKEN=xxx
eto bangumi -t ./config/sync-bangumi-template.md -s 1 -o ./bangumi/
eto bangumi -t ./config/sync-bangumi-template.md -s 2 -o ./bangumi/
eto bangumi -t ./config/sync-bangumi-template.md -s 3 -o ./bangumi/
eto bangumi -t ./config/sync-bangumi-template.md -s 4 -o ./bangumi/
```

### Zhihu

```shell
eto zhihu -c xxx -o ./zhihu/
```

### V2ex

```shell
eto v2ex -o ./v2ex/
```

### Weibo

```shell
eto weibo -u xxx -o ./weibo/
```

### bilibili

```shell
eto bilibili -f xxx -o ./bilibili/
```

## Contributing

Any contributions made are **greatly appreciated**.

If you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement".
Don't forget to give the project a star! Thanks again!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'feat(module):add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

Top contributors:

<a href="https://github.com/bGZo/playground/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=bGZo/playground" alt="contrib.rocks image" />
</a>

## License

All code is licensed under the AGPL-3.0 license. See `LICENSE` for more information.
