<div align="center">

# CoCoLIT (AAAI'26)

<a><img src='https://img.shields.io/badge/PyTorch-%23EE4C2C.svg?style=for-the-badge&logo=PyTorch&logoColor=white' alt='PyTorch'></a>
<a href="https://arxiv.org/abs/2508.01292"><img src='https://img.shields.io/badge/Paper-PDF-green?style=for-the-badge&logo=adobeacrobatreader&logoWidth=20&logoColor=white&labelColor=66cc00&color=94DD15' alt='Paper PDF'></a>
<a href="https://huggingface.co/lemuelpuglisi/CoCoLIT/tree/main"><img src="https://img.shields.io/badge/Hugging%20Face-Model-yellow?style=for-the-badge&logo=huggingface" alt="Hugging Face Model"></a>
<a href="https://creativecommons.org/licenses/by-nc/4.0/" target="_blank">
    <img src="https://img.shields.io/badge/License-CC_BY--NC_4.0-lightgrey?style=for-the-badge" alt="License: Attribution-NonCommercial 4.0 International">
</a>


<strong>CoCoLIT: ControlNet-Conditioned Latent Image Translation for MRI to Amyloid PET Synthesis</strong><br>
<a href="https://scholar.google.com/citations?user=9kuYeWcAAAAJ&hl=it&oi=ao">Alec Sargood</a>\*, 
<a href="https://lemuelpuglisi.github.io/">Lemuel Puglisi</a>\*, 
<a href="https://profiles.ucl.ac.uk/32379-james-cole">James Cole</a>, 
<a href="https://neiloxtoby.com/science/">Neil Oxtoby</a>, 
<a href="https://daniravi.wixsite.com/researchblog">Daniele Ravì</a><sup>†</sup>, 
<a href="https://profiles.ucl.ac.uk/3589-daniel-alexander">Daniel C. Alexander</a><sup>†</sup><br>
<small>* <i>Joint first authors</i></small>,
<small>† <i>Joint senior authors</i></small>
</p>


</div>

![](docs/assets/preview.gif)

<div align="center">
  <a href="#installation" style="margin: 0 15px;">Installation</a> •
  <a href="#usage" style="margin: 0 15px;">Usage</a> •
  <a href="#training--reproducibility" style="margin: 0 15px;">Training & Reproducibility</a> •
  <a href="#disclaimer" style="margin: 0 15px;">Disclaimer</a> •
  <a href="#citing" style="margin: 0 15px;">Citing</a>
</div>

## News

- **2025-10:** Our paper *CoCoLIT* has been **accepted at AAAI 2026** (17% acceptance rate).


## Installation

This repository requires Python 3.10 and PyTorch 2.0 or later. To install the latest version, run:

```bash
pip install cocolit
```

## Usage

After installing the package, you can convert a T1-weighted MRI to a Florbetapir SUVR map by running:

```bash
mri2pet --i /path/to/t1.nii.gz --o /path/to/output.nii.gz
```

If your MRI has **not** been preprocessed yet, you can run the full preprocessing pipeline directly from the CLI (skull-stripping, affine registration to MNI space, and WhiteStripe normalization):

```bash
mri2pet --i /path/to/t1.nii.gz --o /path/to/output.nii.gz \
  --preprocess
```

Optionally, save intermediate preprocessing files with:

```bash
mri2pet --i /path/to/t1.nii.gz --o /path/to/output.nii.gz \
  --preprocess \
  --preprocess_out /path/to/preproc_outputs
```

To replicate the results presented in the paper, include the `--m 64` flag.

<img width="100%" src="docs/assets/cocolit-cli.svg">


## Training & Reproducibility

> [!NOTE]
> If you wish to compare your MRI-to-PET model against CoCoLIT but prefer not to retrain our models due to limited compute or time, please [email us](#contacts) and we will provide the exact training splits used in this work to enable benchmarking with our pretrained models.

To reproduce the experiments reported in the paper, please follow the [reproducibility guide](./docs/reproducibility.md).

## Disclaimer

This software is not intended for clinical use. The code is not available for commercial applications. For commercial inquiries, please contact the corresponding authors.

## Citing

Arxiv Preprint:

```bib
@article{sargood2025cocolit,
  title={CoCoLIT: ControlNet-Conditioned Latent Image Translation for MRI to Amyloid PET Synthesis},
  author={Sargood, Alec and Puglisi, Lemuel and Cole, James H and Oxtoby, Neil P and Rav{\`\i}, Daniele and Alexander, Daniel C},
  journal={arXiv preprint arXiv:2508.01292},
  year={2025}
}
```

## Contacts
For any inquiries, please contact:
* Alec Sargood: alec.sargood.23@ucl.ac.uk
* Lemuel Puglisi: lemuel.puglisi@phd.unict.it
