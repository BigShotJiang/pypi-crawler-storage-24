import copy
import warnings
import numpy as np
import os
from functools import cached_property
from collections import defaultdict
import glob

from ..fourier.rvectors import Rvectors
from .system import System
from ..utility import clear_cached, one2three, pauli_xyz
from ..symmetry.point_symmetry import PointGroup
from ..symmetry.wyckoff_position import split_into_orbits
from packaging import version


class System_R(System):
    """
        The base class for describing a system. Does not have its own constructor,
        please use the child classes, e.g  :class:`System_w90` or :class:`System_tb`


        Parameters
        -----------
        berry : bool
            set ``True`` to enable evaluation of external term in  Berry connection or Berry curvature and their
            derivatives.
        spin : bool
            set ``True`` if quantities derived from spin  will be used.
        morb : bool
            set ``True`` to enable calculation of external terms in orbital moment and its derivatives.
            Requires the ``.uHu`` file.
        OSD : bool
            set ``True`` to enable calculation of external terms in orbital contribution to Optical Spatial dispersion
            Requires the `uIu`` and ``.uHu`` files.
        periodic : [bool,bool,bool]
            set ``True`` for periodic directions and ``False`` for confined (e.g. slab direction for 2D systems). If less then 3 values provided, the rest are treated as ``False`` .
        SHCryoo : bool
            set ``True`` if quantities derived from Ryoo's spin-current elements will be used. (RPS 2019)
        SHCqiao : bool
            set ``True`` if quantities derived from Qiao's approximated spin-current elements will be used. (QZYZ 2018).
        FF : bool
            generate the FF_R matrix based on the uIu file. 
        npar : int
            number of nodes used for parallelization in the `__init__` method. Default: `multiprocessing.cpu_count()`
        ws_dist_tol : float
            the tolerance for the Wigner-Seitz distance. Default: 1e-5

        Notes
        -----
        * The system is described by its real lattice, symmetry group, and Hamiltonian and other real-space matrices.
        * The lattice is given by the lattice vectors in the Cartesian coordinates.
        * The system can be either periodic or confined in some directions.


        Attributes
        ----------
        needed_R_matrices : set
            the set of matrices that are needed for the current calculation. The matrices are set in the constructor.
        npar : int
            number of nodes used for parallelization in the `__init__` method. Default: `multiprocessing.cpu_count()`
        _XX_R : dict(str:array)
            dictionary of real-space matrices. The keys are the names of the matrices, the values are the matrices themselves.
        wannier_centers_cart : array(float)
            the positions of the Wannier centers in the Cartesian coordinates.
        wannier_centers_red : array(float)
            the positions of the Wannier centers in the reduced coordinates.
        num_wann : int
            the number of Wannier functions.
        real_lattice : array(float, shape=(3,3))
            the lattice vectors of the model.
        NKFFT_recommended : int
            the recommended size of the FFT grid to be used in the interpolation.
        """

    half_wann_matrices = set()

    def __init__(self, **parameters):

        super().__init__(**parameters)

        self._XX_R = dict()


    def set_wannier_centers(self, wannier_centers_cart=None, wannier_centers_red=None):
        """
            set self.wannier_centers_cart. Only one of parameters should be provided.
            If both are None: self.wannier_centers_cart is set to zero.
        """
        lcart = (wannier_centers_cart is not None)
        lred = (wannier_centers_red is not None)
        if lred:
            _wannier_centers_cart = wannier_centers_red.dot(self.real_lattice)
            if lcart:
                assert abs(wannier_centers_cart - _wannier_centers_cart).max() < 1e-8
            else:
                self.wannier_centers_cart = _wannier_centers_cart
        else:
            if lcart:
                self.wannier_centers_cart = wannier_centers_cart
            else:
                self.wannier_centers_cart = np.zeros((self.num_wann, 3))
        self.clear_cached_wcc()

    def get_R_mat(self, key):
        try:
            return self._XX_R[key]
        except KeyError:
            raise ValueError(f"The real-space matrix elements '{key}' are not set in the system," +
                             " but are required for the current calculation. please check parameters of the System() initializer")

    def has_R_mat(self, key):
        return key in self._XX_R


    def set_R_mat(self, key, value, diag=False, R=None, reset=False, add=False, Hermitian=False):
        """
        Set real-space matrix specified by `key`. Either diagonal, specific R or full matrix.  Useful for model calculations

        Parameters
        ----------
        key : str
            'SS', 'AA' , etc
        value : array
            * `array(num_wann,...)` if `diag=True` . Sets the diagonal part ( if `R` not set, `R=[0,0,0]`)
            * `array(num_wann,num_wann,..)`  matrix for `R` (`R` should be set )
            * `array(Rvec, num_wann,num_wann,...)` full spin matrix for all R

            `...` denotes the vector/tensor cartesian dimensions of the matrix element
        diag : bool
            set only the diagonal for a specific R-vector (if specified), or fpr R=[0,0,0]
        R : list(int)
            list of 3 integer values specifying R. if
        reset : bool
            allows to reset matrix if it is already set
        add : bool
            add matrix to the already existing
        Hermitian : bool
            force the value to be Hermitian (only if all vectors are set at once)
        """
        if key in self.half_wann_matrices:
            num_wann = self.num_wann // 2
            range_wann = np.arange(num_wann)
        else:
            num_wann = self.num_wann
            range_wann = self.range_wann

        if diag:
            assert value.shape[0] == num_wann, f"the 0th dimension for 'diag=True' of value should be {num_wann}, found {value.shape[0]}"
            if R is None:
                R = [0, 0, 0]
            XX = np.zeros((num_wann, num_wann) + value.shape[1:], dtype=value.dtype)
            XX[range_wann, range_wann] = value
            self.set_R_mat(key, XX, R=R, reset=reset, add=add)
        elif R is not None:
            assert value.shape[0:2] == (num_wann, num_wann), f"the 0th and 1st dimensions of value for R={R}!=None should be nW={num_wann}, found {value.shape[0:2]}"
            XX = np.zeros((self.rvec.nRvec, num_wann, num_wann) + value.shape[2:], dtype=value.dtype)
            XX[self.rvec.iR(R), :, :] = value
            self.set_R_mat(key, XX, reset=reset, add=add)
        else:
            assert value.shape[1:3] == (num_wann, num_wann), f"for R=None  the 1st and 2nd dimensions should be nw={num_wann}, found {value.shape[1:3]}"
            if hasattr(self, 'rvec'):
                assert value.shape[0] == self.rvec.nRvec, f"the 0th dimension of value should be nR={self.rvec.nRvec}, found {value.shape[0]}"
            if Hermitian:
                value = 0.5 * (value + self.rvec.conj_XX_R(value))
            if key in self._XX_R:
                if reset:
                    self._XX_R[key] = value
                elif add:
                    self._XX_R[key] += value
                else:
                    raise RuntimeError(f"setting {key} for the second time without explicit permission. smth is wrong")
            else:
                self._XX_R[key] = value

    def clear_R_mat(self, keys):
        if not isinstance(keys, (list, tuple)):
            keys = [keys]
        for key in keys:
            if key in self._XX_R:
                del self._XX_R[key]

    def spin_block2interlace(self, backward=False):
        """
        Convert the spin ordering from block (like in the amn file old versions of VASP) to interlace (like in the amn file of QE and new versions of VASP)
        """
        nw2 = self.num_wann // 2
        mapping = np.zeros(self.num_wann, dtype=int)

        if backward:
            mapping[:nw2] = np.arange(nw2) * 2
            mapping[nw2:] = np.arange(nw2) * 2 + 1
        else:
            mapping[::2] = np.arange(nw2)
            mapping[1::2] = np.arange(nw2) + nw2

        for key, val in self._XX_R.items():
            self._XX_R[key] = val[:, :, mapping][:, mapping, :]
        self.wannier_centers_cart = self.wannier_centers_cart[mapping]
        self.rvec.reorder(mapping)
        self.clear_cached_wcc()


    def spin_interlace2block(self, backward=False):
        """
        Convert the spin ordering from interlace (like in the amn file of QE and new versions of VASP) to block (like in the amn file old versions of VASP)
        """
        self.spin_block2interlace(backward=not backward)


    @property
    def Ham_R(self):
        return self.get_R_mat('Ham')

    def symmetrize2(self, symmetrizer, silent=True, use_symmetries_index=None,
                    cutoff=-1, cutoff_dict=None):
        """
        Symmetrize the system according to the Symmetrizer object.

        Parameters
        ----------
        symmetrizer : :class:`wanierberri.symmetry.sawf.SymmetrizerSAWF`
            The symmetrizer object that will be used for symmetrization. (make sure it is consistent with the order of projections)
        silent : bool
            If True, do not print the symmetrization process. (set to False to see more debug information)
        use_symmetries_index : list of int
            List of symmetry indices to use for symmetrization. If None, all symmetries will be used.
        """
        from ..symmetry.sym_wann_2 import SymWann
        symmetrize_wann = SymWann(
            symmetrizer=symmetrizer,
            iRvec=self.rvec.iRvec,
            silent=self.silent or silent,
            use_symmetries_index=use_symmetries_index,
        )

        # self.check_AA_diag_zero(msg="before symmetrization", set_zero=True)
        logfile = self.logfile

        if not silent:
            logfile.write(f"Wannier Centers cart (raw):\n {self.wannier_centers_cart}\n")
            logfile.write(f"Wannier Centers red: (raw):\n {self.wannier_centers_red}\n")
        print(f"number o R-vectors before symmetrization: {len(self.rvec.iRvec)}")
        self._XX_R, iRvec = symmetrize_wann.symmetrize(XX_R=self._XX_R, cutoff=cutoff, cutoff_dict=cutoff_dict)
        self.wannier_centers_cart = symmetrizer.symmetrize_WCC(self.wannier_centers_cart)
        print(f"number o R-vectors after symmetrization: {len(iRvec)}")
        self.clear_cached_wcc()
        rvec_new = Rvectors(
            lattice=self.real_lattice,
            iRvec=iRvec,
            shifts_left_red=self.wannier_centers_red,
        )
        try:
            rvec_new.mp_grid = self.rvec.mp_grid,
        except AttributeError:
            pass
        self.rvec = rvec_new
        self.set_pointgroup(spacegroup=symmetrizer.spacegroup, use_symmetries_index=use_symmetries_index)
        self.set_structure_from_sg(symmetrizer.spacegroup)

        if not silent:
            logfile.write(f"Wannier Centers cart (symetrized):\n {self.wannier_centers_cart}\n")
            logfile.write(f"Wannier Centers red: (symmetrized):\n {self.wannier_centers_red}\n")

        self.clear_cached_R()
        self.clear_cached_wcc()
        self.symmetrized = True


    def symmetrize(self, proj, positions, atom_name, soc=False, magmom=True, silent=True,
                   reorder_back=False):
        """
        Symmetrize Wannier matrices in real space: Ham_R, AA_R, BB_R, SS_R,... , as well as Wannier centers
        Also sets the pointgroup (with method "new")


        Parameters
        ----------
        positions: array
            Positions of each atom.
        atom_name: list
            Name of each atom.
        proj: list
            Projections from the corresponding ``wannier90.win`` file.

            Examples:

            - ``['Te:s', 'Te:p']``
            - ``['Fe:sp3d2;t2g']`` instead of ``['Fe:sp3d2;dxz,dyz,dxy]``
            - ``['X:sp;p2']`` instead of ``['X:sp;pz,py]``

            If ``wannier90.win`` contains several projections in one line, for example
            ``['Fe:d;sp3]``, the actual order written to ``wannier90.nnkp`` may differ.
            It is ordered by the orbital quantum number `l`, and hybrids are assigned
            negative values (for example, for `sp3`, `l=-3`; see the
            `Wannier90 user guide <https://raw.githubusercontent.com/wannier-developers/wannier90/v3.1.0/doc/compiled_docs/user_guide.pdf>`__, chapter 3).
            In that case the actual order becomes ``['Fe:sp3;d]``. To avoid confusion,
            it is recommended to put different projection groups on separate lines of
            ``wannier90.win``. See also `Wannier90 issue #463 <https://github.com/wannier-developers/wannier90/issues/463>`__.
        soc: bool
            Spin orbital coupling.
        magmom: 2D array
            Magnetic momens of each atoms.
        silent: bool
            If True, do not print the symmetrization process.
        reorder_back: bool
            If True, reorder the wannier functions back to the original order after symmetrization. (if the order happened to be changed (see note below))

        Returns
        -------
        symmetrizer : :class:`~wannierberri.symmetry.sawf.SymmetrizerSAWF`
            the symmetrizer object that was used for symmetrization. Can be used for further analysis of the symmetry properties of the system.

        Notes
        -----
                * After symmetrization, the Wannier functions may be reordered to group atoms
                    by the same Wyckoff positions. In this case, the symmetrizer is not returned,
                    because it would be inconsistent with the order of the projections.

                * Works only with phase convention I (`use_wcc_phase=True`), which is now the
                    only supported option.

                * Spin ordering is assumed to be interlaced (like in the amn file of QE and
                    new versions of VASP). If it is not, use
                    :func:`~wannierberri.system.System.spin_block2interlace` to convert it.
        """
        from irrep import __version__ as irrep_version
        from irrep.spacegroup import SpaceGroup
        from ..symmetry.sawf import SymmetrizerSAWF
        from ..symmetry.projections import Projection

        index = {key: i for i, key in enumerate(set(atom_name))}
        atom_num = np.array([index[key] for key in atom_name])

        if version.parse(irrep_version) < version.parse("2.2.0"):
            spacegroup = SpaceGroup(cell=(self.real_lattice, positions, atom_num),
                                magmom=magmom, include_TR=True,
                                spinor=soc,)
        else:
            spacegroup = SpaceGroup.from_cell(real_lattice=self.real_lattice,
                                              positions=positions,
                                              typat=atom_num,
                                              magmom=magmom,
                                              include_TR=True,
                                              spinor=soc,)
        spacegroup.show()

        assert len(atom_name) == len(positions), "atom_name and positions should have the same length"

        proj_list = []
        new_wann_indices = []
        num_wann_loc = 0
        for proj_str in proj:
            atom, orbital = [l.strip() for l in proj_str.split(':')]
            # pos = []
            # ipos = []
            # for ia, a in enumerate(atom_name):
            #     if a == atom:
            #         pos.append(positions[ia])
            #         ipos.append(ia)
            pos = np.array([positions[i] for i, name in enumerate(atom_name) if name == atom])
            suborbit_list = split_into_orbits(pos, spacegroup=spacegroup)
            if len(suborbit_list) > 1:
                warnings.warn(f"Positions of  {atom} belong to different wyckoff positions. This case is not much tested."
                         "it is recommentded to name atoms at different wyckoff positions differently:\n"
                         "\n".join(f"{atom}{i + 1}:" + ";".join(str(pos[j]) for j in suborbit) for i, suborbit in enumerate(suborbit_list))
                )
            print(f"pos_list: {suborbit_list}")
            if ";" in orbital:
                warnings.warn("for effeciency of symmetrization, it is recommended to give orbitals separately, not combined by a ';' sign."
                              "But you need to do it consistently in wannier90 ")
            for suborbit in suborbit_list:
                pos_loc = pos[suborbit]
                proj = Projection(position_num=pos_loc, orbital=orbital, spacegroup=spacegroup,
                                  do_not_split_projections=True, rotate_basis=False)
                proj_list.append(proj)
                print(f"proj: {proj}")
                num_wann_per_position = proj.num_wann_per_site
                print(f"orbital = {orbital}, num wann per site = {num_wann_per_position}")
                for i in suborbit:
                    for j in range(num_wann_per_position):
                        new_wann_indices.append(num_wann_loc + i * num_wann_per_position + j)
            num_wann_loc = len(new_wann_indices)

        print(f"new_wann_indices: {new_wann_indices}")
        self.reorder(new_wann_indices)
        symmetrizer = SymmetrizerSAWF().set_spacegroup(spacegroup).set_D_wann_from_projections(projections=proj_list)
        self.symmetrize2(symmetrizer, silent=silent)
        if reorder_back:
            self.reorder(np.argsort(new_wann_indices))
            if np.all(np.array(new_wann_indices) == np.arange(self.num_wann)):
                return symmetrizer
            else:
                return None
        else:
            return symmetrizer

    def reorder(self, new_wann_indices):
        """
        Reorder the wannier functions according to the new indices

        Parameters
        ----------
        new_wann_indices : list
            list of new indices for the wannier functions. The length should be equal to the number of wannier functions.
        """
        assert len(new_wann_indices) == self.num_wann, f"new_wann_indices should have length {self.num_wann}, found {len(new_wann_indices)}"
        self.wannier_centers_cart = self.wannier_centers_cart[new_wann_indices]
        for key, val in self._XX_R.items():
            self._XX_R[key] = val[:, :, new_wann_indices][:, new_wann_indices, :]
        self.rvec.reorder(new_wann_indices)
        if hasattr(self, 'wannier_names'):
            self.wannier_names = self.wannier_names[new_wann_indices]
        self.clear_cached_wcc()
        self.clear_cached_R()

    def double_spin(self):
        """
        If the system is spinless, one can trivially dounle 
        """
        assert not self.spinor, "the system is already spinful, cannot double the spin"
        self.spinor = True
        num_wann_old = self.num_wann
        self.num_wann = 2 * num_wann_old
        for key in self._XX_R:
            if key in ['SS', "SHR", "SHA", "SH", "SA"]:
                raise RuntimeError("the SS matrix is already set, it cannot be a spinless system")
            XX = self.get_R_mat(key)
            XX_new = np.zeros((XX.shape[0], num_wann_old * 2, num_wann_old * 2) + XX.shape[3:], dtype=XX.dtype)
            for i in range(2):
                XX_new[:, i::2, i::2] = XX
            self.set_R_mat(key, XX_new, reset=True)
        wannier_centers_cart_old = self.wannier_centers_cart.copy()
        self.wannier_centers_cart = np.zeros((self.num_wann, 3), dtype=float)
        for i in range(2):
            self.wannier_centers_cart[i::2] = wannier_centers_cart_old
        self.rvec.double_spin()
        self.clear_cached_wcc()
        self.clear_cached_R()
        self.set_spin_pairs([(2 * i, 2 * i + 1) for i in range(num_wann_old)])


    def check_AA_diag_zero(self, msg="", set_zero=True, threshold=1e-5):
        if self.has_R_mat('AA'):
            A_diag = self.get_R_mat('AA')[self.rvec.iR0].diagonal().T
            A_diag_max = abs(A_diag).max()
            if A_diag_max > threshold:
                warnings.warn(
                    f"the maximal value of diagonal position matrix elements {msg} is {A_diag_max}."
                    f"This may signal a problem\n {A_diag}")
                if set_zero:
                    warnings.warn("setting AA diagonal to zero")
            if set_zero:
                self.get_R_mat('AA')[self.rvec.iR0, self.range_wann, self.range_wann, :] = 0

    def check_periodic(self):
        exclude = np.zeros(self.rvec.nRvec, dtype=bool)
        for i, per in enumerate(self.periodic):
            if not per:
                sel = (self.rvec.iRvec[:, i] != 0)
                if np.any(sel):
                    warnings.warn(f"you declared your system as non-periodic along direction {i},"
                                  f"but there are {sum(sel)} of total {self.nRvec} R-vectors with R[{i}]!=0."
                                  "They will be excluded, please make sure you know what you are doing")
                    exclude[sel] = True
        if np.any(exclude):
            notexclude = np.logical_not(exclude)
            self.iRvec = self.iRvec[notexclude]
            for X in ['Ham', 'AA', 'BB', 'CC', 'SS', 'FF']:
                if X in self._XX_R:
                    self.set_R_mat(X, self.get_X_mat(X)[:, :, notexclude], reset=True)

    def set_spin_eigenstates(self, spins, axis=(0, 0, 1), **kwargs):
        """
        Set spins along axis in  SS(R=0).  Useful for model calculations.
        Note : The spin matrix is purely diagonal, so that <up | sigma_x | down> = 0
        For more cversatility use :func:`~wannierberri.system.System.set_R_mat`
        :func:`~wannierberri.system.System.set_spin_pairs`, :func:`~wannierberri.system.System.set_spin_interlaced`

        Parameters
        ----------
        spin : one on the following
            1D `array(num_wann)` of `+1` or `-1` spins are along `axis`
        axis : array(3)
            spin quantization axis (if spin is a 1D array)
        **kwargs :
            optional arguments 'R', 'reset', 'add' see :func:`~wannierberri.system.System.set_R_mat`
        """
        spins = np.array(spins)
        if max(abs(spins) - 1) > 1e-3:
            warnings.warn("some of your spins are not +1 or -1, are you sure you want it like this?")
        axis = np.array(axis) / np.linalg.norm(axis)
        value = np.array([s * axis for s in spins], dtype=complex)
        self.set_R_mat(key='SS', value=value, diag=True, **kwargs)

    def set_spin_pairs(self, pairs):
        """set SS_R, assuming that each Wannier function is an eigenstate of Sz,

        Parameters
        ----------
        pairs : list of tuple
            list of pairs of indices of bands `[(up1,down1), (up2,down2), ..]`

        Notes
        -----
        * For abinitio calculations this is a rough approximation, that may be used on own risk.
        * See also :func:`~wannierberri.system.System.set_spin_interlaced`

        """
        assert all(len(p) == 2 for p in pairs)
        all_states = np.array(sum((list(p) for p in pairs), []))
        assert np.all(all_states >= 0) and (np.all(all_states < self.num_wann)), (
            f"indices of states should be 0<=i<num_wann-{self.num_wann}, found {pairs}")
        assert len(set(all_states)) == len(all_states), "some states appear more then once in pairs"
        if len(pairs) < self.num_wann / 2:
            warnings.warn(f"number of spin pairs {len(pairs)} is less then num_wann/2 = {self.num_wann / 2}."
                          "For other states spin properties will be set to zero. are yoiu sure ?")
        SS_R0 = np.zeros((self.num_wann, self.num_wann, 3), dtype=complex)
        for i, j in pairs:
            dist = np.linalg.norm(self.wannier_centers_cart[i] - self.wannier_centers_cart[j])
            if dist > 1e-3:
                warnings.warn(f"setting spin pair for Wannier function {i} and {j}, distance between them {dist}")
            SS_R0[i, i] = pauli_xyz[0, 0]
            SS_R0[i, j] = pauli_xyz[0, 1]
            SS_R0[j, i] = pauli_xyz[1, 0]
            SS_R0[j, j] = pauli_xyz[1, 1]
            self.set_R_mat(key='SS', value=SS_R0, diag=False, R=[0, 0, 0], reset=True)

    def set_spin_interlaced(self):
        """set SS_R, assuming that each Wannier function is an eigenstate of Sz,
         with interlaced spin ordering, which  means that the orbitals of the two spins are interlaced. (like in the amn file of QE and new versions of VASP)

        Notes
        -------
        * This is a rough approximation, that may be used on own risk
        * The pure-spin character may be broken by maximal localization. Recommended to use `num_iter=0` in Wannier90
        also see   :func:`~wannierberri.system.System.set_spin_pairs`
        """
        assert self.num_wann % 2 == 0, f"odd number of Wannier functions {self.num_wann} cannot be grouped into spin pairs"
        nw2 = self.num_wann // 2
        pairs = [(2 * i, 2 * i + 1) for i in range(nw2)]
        self.set_spin_pairs(pairs)

    def set_spacegroup(self, spacegroup):
        """
        Set the space group of the :class:`System`, which will be used for symmetrization
        R-space and k-space 
        Also sets the pointgroup

        Parameters
        ----------
        spacegroup : :class:`irrep.spacegroup.SpaceGroup`
            The space group of the system. The point group will be evaluated by the space group.
        """
        self.spacegroup = spacegroup
        self.set_pointgroup(spacegroup=spacegroup)

    def do_at_end_of_init(self):
        self.set_pointgroup()
        self.check_periodic()
        logfile = self.logfile
        logfile.write(f"Real-space lattice:\n {self.real_lattice}\n")
        logfile.write(f"Number of wannier functions: {self.num_wann}\n")
        logfile.write(f"Number of R points: {self.rvec.nRvec}\n")
        logfile.write(f"Recommended size of FFT grid {self.NKFFT_recommended}\n")


    def do_ws_dist(self, mp_grid, wannier_centers_cart=None, ws_dist_tol=1e-5):
        logfile = self.logfile
        try:
            mp_grid = one2three(mp_grid)
            assert mp_grid is not None
        except AssertionError:
            raise ValueError(f"mp_greid should be one integer, of three integers. found {mp_grid}")
        self._NKFFT_recommended = mp_grid
        if wannier_centers_cart is None:
            wannier_centers_cart = self.wannier_centers_cart
        iRvec_old = self.rvec.iRvec
        self.rvec = Rvectors(lattice=self.real_lattice, shifts_left_red=self.wannier_centers_red)
        self.rvec.set_Rvec(mp_grid, ws_tolerance=ws_dist_tol)
        for key, val in self._XX_R.items():
            logfile.write(f"using new ws_dist for {key}\n")
            self.set_R_mat(key, self.rvec.remap_XX_R(val, iRvec_old=iRvec_old), reset=True)
        self._XX_R, self.rvec = self.rvec.exclude_zeros(self._XX_R)


    def to_tb_file(self, tb_file=None, use_convention_II=True):
        """
        Write the system in the format of the wannier90_tb.dat file
        Note : it is written in phase convention II (as inb wannier90), unless use_convention_II=False
        """
        logfile = self.logfile
        if tb_file is None:
            tb_file = self.seedname + "_fromchk_tb.dat"
        f = open(tb_file, "w")
        f.write("written by wannier-berri form the chk file\n")
        logfile.write(f"writing TB file {tb_file}\n")
        np.savetxt(f, self.real_lattice)
        f.write(f"{self.num_wann}\n")
        f.write(f"{self.rvec.nRvec}\n")
        Ndegen = np.ones(self.rvec.nRvec, dtype=int)
        for i in range(0, self.rvec.nRvec, 15):
            a = Ndegen[i:min(i + 15, self.rvec.nRvec)]
            f.write("  ".join(f"{x:2d}" for x in a) + "\n")
        for iR in range(self.rvec.nRvec):
            f.write("\n  {0:3d}  {1:3d}  {2:3d}\n".format(*tuple(self.rvec.iRvec[iR])))
            _ham = self.Ham_R[iR] * Ndegen[iR]
            f.write(
                "".join(
                    f"{m + 1:3d} {n + 1:3d} {_ham[m, n].real:15.8e} {_ham[m, n].imag:15.8e}\n"
                    for n in self.range_wann for m in self.range_wann)
            )
        if self.has_R_mat('AA'):
            AA = np.copy(self.get_R_mat('AA'))
            if use_convention_II:
                AA[self.rvec.iR0, self.range_wann, self.range_wann] += self.wannier_centers_cart
            for iR in range(self.rvec.nRvec):
                f.write("\n  {0:3d}  {1:3d}  {2:3d}\n".format(*tuple(self.rvec.iRvec[iR])))
                _aa = AA[iR] * Ndegen[iR]
                f.write(
                    "".join(
                        f"{m + 1:3d} {n + 1:3d} " + " ".join(f"{a.real:15.8e} {a.imag:15.8e}" for a in _aa[m, n]) + "\n"
                        for n in self.range_wann for m in self.range_wann
                    )
                )
        f.close()

    @property
    def NKFFT_recommended(self):
        """finds a minimal FFT grid on which different R-vectors do not overlap"""
        if hasattr(self, '_NKFFT_recommended'):
            return self._NKFFT_recommended
        else:
            return self.rvec.NKFFT_recommended()

    def clear_cached_R(self):
        self.rvec.clear_cached()

    def clear_cached_wcc(self):
        clear_cached(self, ["wannier_centers_red"])
        if hasattr(self, 'rvec'):
            self.rvec.clear_cached()


    @cached_property
    def wannier_centers_red(self):
        return self.wannier_centers_cart.dot(np.linalg.inv(self.real_lattice))

    def get_sparse(self, min_values={'Ham': 1e-3}):
        min_values = copy.copy(min_values)
        ret_dic = dict(
            real_lattice=self.real_lattice,
            wannier_centers_red=self.wannier_centers_red,
            matrices={},
        )
        if hasattr(self, 'symmetrize_info'):
            ret_dic['symmetrize_info'] = self.symmetrize_info

        def array_to_dict(A, minval):
            A_tmp = abs(A.reshape(A.shape[:3] + (-1,))).max(axis=-1)
            wh = np.argwhere(A_tmp >= minval)
            dic = defaultdict(lambda: dict())
            for w in wh:
                iR = tuple(self.rvec.iRvec[w[0]])
                dic[iR][(w[1], w[2])] = A[tuple(w)]
            return dict(dic)

        for k, v in min_values.items():
            ret_dic['matrices'][k] = array_to_dict(self.get_R_mat(k), v)
        return ret_dic

    @cached_property
    def essential_properties(self):
        return ['num_wann', 'real_lattice', 'iRvec', 'periodic',
                'is_phonon', 'wannier_centers_cart', 'pointgroup']

    @cached_property
    def optional_properties(self):
        return ["positions", "magnetic_moments", "atom_labels"]

    def _R_mat_npz_filename(self, key, xxr=True):
        if xxr:
            return "_XX_R_" + key + ".npz"
        else:
            return key + ".npz"

    def to_npz(self, path, extra_properties=(), exclude_properties=(), R_matrices=None, overwrite=True):
        """
        Save system to a directory of npz files
        Parameters
        ----------
        path : str
            path to saved files. If does not exist - will be created (unless overwrite=False)
        extra_properties : list of str
            names of properties which are not essential for reconstruction, but will also be saved
        exclude_properties : list of str
            dp not save certain properties - duse on your own risk
        R_matrices : list of str
            list of the R matrices, e.g. ```['Ham','AA',...]``` to be saved. if None: all R-matrices will be saved
        overwrite : bool
            if the directory already exiists, it will be overwritten
        """
        logfile = self.logfile

        properties = [x for x in self.essential_properties + list(extra_properties) if x not in exclude_properties]
        print(f"saving system of class {self.__class__.__name__} to {path}\n properties: {properties}")
        if R_matrices is None:
            R_matrices = list(self._XX_R.keys())

        try:
            os.makedirs(path, exist_ok=overwrite)
        except FileExistsError:
            raise FileExistsError(f"Directorry {path} already exists. To overwrite it set overwrite=True")

        for key in properties:
            logfile.write(f"saving {key}\n")
            fullpath = os.path.join(path, key + ".npz")
            print(f"saving {key} to {fullpath}")
            if key == 'iRvec':
                val = self.rvec.iRvec
            else:
                val = getattr(self, key)
            if key in ['pointgroup']:
                np.savez(fullpath, **val.as_dict())
            elif key in ['cell']:
                np.savez(fullpath, **val)
            else:
                np.savez(fullpath, val)
            logfile.write(" - Ok!\n")
        for key in self.optional_properties:
            if key not in properties:
                fullpath = os.path.join(path, key + ".npz")
                if hasattr(self, key):
                    val = getattr(self, key)
                    np.savez(fullpath, val)
        for key in R_matrices:
            logfile.write(f"saving {key}")
            np.savez_compressed(os.path.join(path, self._R_mat_npz_filename(key)), self.get_R_mat(key))
            logfile.write(" - Ok!\n")


    @classmethod
    def from_npz(cls, path, exclude_properties=(), legacy=False, matrices=None):
        """
        Load system from a directory of npz files
        Parameters
        ----------
        matrices : list of str
            list of the R matrices, e.g. ```['Ham','AA',...]``` to be loaded. if None: all R-matrices will be loaded
        path : str
            path to saved files. If does not exist - will be created (unless overwrite=False)
        exclude_properties : list of str
            dp not save certain properties - duse on your own risk
        legacy : bool
            if True, the order of indices in the XX_R matrices will be expected as in older verisons of wannierberri : [m,n,iR, ...]
            in the newer versions the order is [iR, m ,n,...]
        """
        system = cls()
        system.load_npz(path, exclude_properties=exclude_properties, legacy=legacy, matrices=matrices)
        return system

    def load_npz(self, path, exclude_properties=(), legacy=False, matrices=None):
        """
        Save system to a directory of npz files
        Parameters
        ----------
        matrices : list of str
            list of the R matrices, e.g. ```['Ham','AA',...]``` to be loaded. if None: all R-matrices will be loaded
        path : str
            path to saved files. If does not exist - will be created (unless overwrite=False)
        exclude_properties : list of str
            dp not save certain properties - duse on your own risk
        legacy : bool
            if True, the order of indices in the XX_R matrices will be expected as in older verisons of wannierberri : [m,n,iR, ...]
            in the newer versions the order is [iR, m ,n,...]
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"directory {path} does not exist")
        logfile = self.logfile
        all_files = glob.glob(os.path.join(path, "*.npz"))
        all_names = [os.path.splitext(os.path.split(x)[-1])[0] for x in all_files]
        properties = [x for x in all_names if not x.startswith('_XX_R_') and x not in exclude_properties]
        assert "real_lattice" in properties, "real_lattice is required to load the system"
        properties = ["real_lattice", "wannier_centers_cart"] + properties
        keys_processed = set()
        for key in properties:
            if key in keys_processed:
                continue
            logfile.write(f"loading {key}")
            a = np.load(os.path.join(path, key + ".npz"), allow_pickle=False)

            # pointgroup was previouslly named symgroup. This is for backward compatibility
            if key == 'symgroup':
                key_loc = 'pointgroup'
            else:
                key_loc = key

            if key_loc == 'pointgroup':
                val = PointGroup(dictionary=a)
            elif key_loc == 'cell':
                val = dict(**a)
            else:
                val = a['arr_0']

            if key == "iRvec":
                self.rvec = Rvectors(lattice=self.real_lattice,
                                     iRvec=val,
                                     shifts_left_red=self.wannier_centers_red
                                     )
            elif "key" == "pointgroup":
                self.set_pointgroup(pointgroup=val)
            else:
                setattr(self, key_loc, val)
            logfile.write(" - Ok!\n")
            keys_processed.add(key)

        if matrices is None:
            R_files = glob.glob(os.path.join(path, "_XX_R_*.npz"))
            matrices = [os.path.splitext(os.path.split(x)[-1])[0][6:] for x in R_files]
        for key in matrices:
            logfile.write(f"loading R_matrix {key}")
            a = np.load(os.path.join(path, self._R_mat_npz_filename(key)), allow_pickle=False)['arr_0']

            if legacy:
                a = np.transpose(a, (2, 0, 1) + tuple(range(3, a.ndim)))
            self.set_R_mat(key, a)
            logfile.write(" - Ok!\n")
        return self

    @classmethod
    def from_wannierdata(cls,
        wandata,
        *args, **kwargs,
    ):
        """
        Create a System_R object from a Wannier90 data object (wandata). 
        Wannierized either by wannier90 or by WannierBerri

        see :func:`~wannierberri.system.system_w90.get_system_w90` for input data and details
        """
        from .system_w90 import get_system_w90
        return get_system_w90(wandata=wandata, *args, **kwargs)


    @classmethod
    def from_tb_dat(cls, *args, **kwargs):
        """
        Create a System_R object from a wannier90_tb.dat file. 
        see :func:`~wannierberri.system.system_tb.get_system_tb` for input data and details
        """
        from .system_tb import system_tb
        return system_tb(*args, **kwargs)

    @classmethod
    def from_pythtb(cls, *args, **kwargs):
        """
        Create a System_R object from a pythtb model. 
        see :func:`~wannierberri.system.system_tb_py.get_system_pythtb` for input data and details
        """
        from .system_tb_py import get_system_pythtb
        return get_system_pythtb(*args, **kwargs)

    @classmethod
    def from_tbmodels(cls, *args, **kwargs):
        """
        Create a System_R object from a TBmodels model. 
        see :func:`~wannierberri.system.system_tb_py.get_system_tbmodels` for input data and details
        """
        from .system_tb_py import get_system_tbmodels
        return get_system_tbmodels(*args, **kwargs)

    @classmethod
    def from_fplo(cls, *args, **kwargs):
        """
        Create a System_R object from a FPLO calculation. 
        see :func:`~wannierberri.system.system_fplo.get_system_fplo` for input data and details
        """
        from .system_fplo import get_system_fplo
        return get_system_fplo(*args, **kwargs)

    @classmethod
    def from_ase(cls, *args, **kwargs):
        """
        Create a System_R object from an ASE Atoms object. 
        see :func:`~wannierberri.system.system_ase.get_system_ase` for input data and details
        """
        from .system_ase import get_system_ase
        return get_system_ase(*args, **kwargs)

    @classmethod
    def from_phonons_qe(cls, *args, **kwargs):
        """
        Create a System_R object for phonons from a Quantum Espresso calculation. 
        see :func:`~wannierberri.system.system_phonon_qe.get_system_phonons_qe` for input data and details
        """
        from .system_phonon_qe import get_system_phonons_qe
        return get_system_phonons_qe(*args, **kwargs)

    @classmethod
    def from_random(cls, *args, **kwargs):
        """
        Create a System_R object with random parameters. 
        see :func:`~wannierberri.system.system_random.get_system_random` for input data and details
        """
        from .system_random import get_system_random
        return get_system_random(*args, **kwargs)

    @classmethod
    def from_sparse(cls, *args, **kwargs):
        """
        Create a System_R object from a sparse representation. 
        see :func:`~wannierberri.system.system_sparse.get_system_sparse` for input data and details
        """
        from .system_sparse import get_system_sparse
        return get_system_sparse(*args, **kwargs)
