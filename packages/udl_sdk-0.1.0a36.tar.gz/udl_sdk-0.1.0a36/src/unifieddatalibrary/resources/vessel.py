# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    vessel_get_params,
    vessel_list_params,
    vessel_count_params,
    vessel_tuple_params,
    vessel_create_params,
    vessel_update_params,
    vessel_create_bulk_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.entity_ingest_param import EntityIngestParam
from ..types.vessel_get_response import VesselGetResponse
from ..types.vessel_list_response import VesselListResponse
from ..types.vessel_tuple_response import VesselTupleResponse
from ..types.vessel_queryhelp_response import VesselQueryhelpResponse

__all__ = ["VesselResource", "AsyncVesselResource"]


class VesselResource(SyncAPIResource):
    """
    This service provides operations for manipulation and querying of maritime Vessel and Vessel Status data. Vessel contains the static data of the specific vessel: mmsi, cruise speed, max speed, etc.
    """

    @cached_property
    def with_raw_response(self) -> VesselResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return VesselResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VesselResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return VesselResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        alt_vessel_id: str | Omit = omit,
        callsign: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        first_seen: Union[str, datetime] | Omit = omit,
        hull_num: str | Omit = omit,
        id_entity: str | Omit = omit,
        id_organization: str | Omit = omit,
        imon: int | Omit = omit,
        length: float | Omit = omit,
        max_draught: float | Omit = omit,
        max_speed: float | Omit = omit,
        mmsi: str | Omit = omit,
        num_blades: int | Omit = omit,
        num_shafts: int | Omit = omit,
        origin: str | Omit = omit,
        prop_type: str | Omit = omit,
        sconum: str | Omit = omit,
        status: str | Omit = omit,
        stern_type: str | Omit = omit,
        vessel_builder: str | Omit = omit,
        vessel_class: str | Omit = omit,
        vessel_description: str | Omit = omit,
        vessel_flag: str | Omit = omit,
        vessel_name: str | Omit = omit,
        vessel_type: str | Omit = omit,
        vsl_wt: float | Omit = omit,
        width: float | Omit = omit,
        year_built: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single vessel record as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          alt_vessel_id: The original source Id for this vessel.

          callsign: A uniquely designated identifier for the vessel's transmitter station. All radio
              transmissions must be individually identified by the call sign. Merchant and
              naval vessels are assigned call signs by their national licensing authorities.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          first_seen: The date this vessel was first seen.

          hull_num: The vessel hull number designation of this maritime vessel. The hull number is a
              1-6 character alphanumeric entry assigned to a ship and painted on the hull.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_organization: The UDL ID of the organization that owns the vessel.

          imon: The International Maritime Organization Number of the vessel. IMON is a
              seven-digit number that uniquely identifies the vessel.

          length: The overall length of the vessel, in meters. A value of 511 indicates a vessel
              length of 511 meters or greater.

          max_draught: The maximum static draught, in meters, of the vessel defined as the distance
              between the ship’s keel and the waterline of the vessel.

          max_speed: The maximum possible speed of this vessel in meters per second.

          mmsi: The Maritime Mobile Service Identity of the vessel. MMSI is a nine-digit number
              that identifies the transmitter station of the vessel.

          num_blades: The number of blades per shaft for this vessel.

          num_shafts: The number of shafts on this vessel.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          prop_type: The type of propulsion employed by this vessel.

          sconum: The Ship Control Number (SCONUM) is a naval vessel identification number
              (alphanumeric code) assigned by the Office of Naval Intelligence. SCONUM is
              sometimes referred to as NOIC ID. SCONUMs are typically of the form A#####,
              where A is an alpha character and # is numerical.

          status: The status of this vessel.

          stern_type: The stern type code (Counter, Cruiser) associated with this vessel.

          vessel_builder: The shipbuilder who built this vessel.

          vessel_class: The common name for a group of ships with similar design, usually named for the
              first vessel of the class.

          vessel_description: Further description or explanation of the vessel or type.

          vessel_flag: The flag of the subject vessel.

          vessel_name: The name of this vessel. Vessel names that exceed the AIS 20 character are
              shortened (not truncated) to 15 character-spaces, followed by an underscore and
              the last 4 characters-spaces of the vessel full name.

          vessel_type: The reported ship type (e.g. Passenger, Tanker, Cargo, Other, etc.).

          vsl_wt: The weight in tons, of this vessel.

          width: The breadth of the vessel, in meters. A value of 63 indicates a vessel breadth
              of 63 meters or greater.

          year_built: Year the vessel went into service.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/vessel",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "alt_vessel_id": alt_vessel_id,
                    "callsign": callsign,
                    "entity": entity,
                    "first_seen": first_seen,
                    "hull_num": hull_num,
                    "id_entity": id_entity,
                    "id_organization": id_organization,
                    "imon": imon,
                    "length": length,
                    "max_draught": max_draught,
                    "max_speed": max_speed,
                    "mmsi": mmsi,
                    "num_blades": num_blades,
                    "num_shafts": num_shafts,
                    "origin": origin,
                    "prop_type": prop_type,
                    "sconum": sconum,
                    "status": status,
                    "stern_type": stern_type,
                    "vessel_builder": vessel_builder,
                    "vessel_class": vessel_class,
                    "vessel_description": vessel_description,
                    "vessel_flag": vessel_flag,
                    "vessel_name": vessel_name,
                    "vessel_type": vessel_type,
                    "vsl_wt": vsl_wt,
                    "width": width,
                    "year_built": year_built,
                },
                vessel_create_params.VesselCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        body_id: str | Omit = omit,
        alt_vessel_id: str | Omit = omit,
        callsign: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        first_seen: Union[str, datetime] | Omit = omit,
        hull_num: str | Omit = omit,
        id_entity: str | Omit = omit,
        id_organization: str | Omit = omit,
        imon: int | Omit = omit,
        length: float | Omit = omit,
        max_draught: float | Omit = omit,
        max_speed: float | Omit = omit,
        mmsi: str | Omit = omit,
        num_blades: int | Omit = omit,
        num_shafts: int | Omit = omit,
        origin: str | Omit = omit,
        prop_type: str | Omit = omit,
        sconum: str | Omit = omit,
        status: str | Omit = omit,
        stern_type: str | Omit = omit,
        vessel_builder: str | Omit = omit,
        vessel_class: str | Omit = omit,
        vessel_description: str | Omit = omit,
        vessel_flag: str | Omit = omit,
        vessel_name: str | Omit = omit,
        vessel_type: str | Omit = omit,
        vsl_wt: float | Omit = omit,
        width: float | Omit = omit,
        year_built: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single vessel record.

        A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          alt_vessel_id: The original source Id for this vessel.

          callsign: A uniquely designated identifier for the vessel's transmitter station. All radio
              transmissions must be individually identified by the call sign. Merchant and
              naval vessels are assigned call signs by their national licensing authorities.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          first_seen: The date this vessel was first seen.

          hull_num: The vessel hull number designation of this maritime vessel. The hull number is a
              1-6 character alphanumeric entry assigned to a ship and painted on the hull.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_organization: The UDL ID of the organization that owns the vessel.

          imon: The International Maritime Organization Number of the vessel. IMON is a
              seven-digit number that uniquely identifies the vessel.

          length: The overall length of the vessel, in meters. A value of 511 indicates a vessel
              length of 511 meters or greater.

          max_draught: The maximum static draught, in meters, of the vessel defined as the distance
              between the ship’s keel and the waterline of the vessel.

          max_speed: The maximum possible speed of this vessel in meters per second.

          mmsi: The Maritime Mobile Service Identity of the vessel. MMSI is a nine-digit number
              that identifies the transmitter station of the vessel.

          num_blades: The number of blades per shaft for this vessel.

          num_shafts: The number of shafts on this vessel.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          prop_type: The type of propulsion employed by this vessel.

          sconum: The Ship Control Number (SCONUM) is a naval vessel identification number
              (alphanumeric code) assigned by the Office of Naval Intelligence. SCONUM is
              sometimes referred to as NOIC ID. SCONUMs are typically of the form A#####,
              where A is an alpha character and # is numerical.

          status: The status of this vessel.

          stern_type: The stern type code (Counter, Cruiser) associated with this vessel.

          vessel_builder: The shipbuilder who built this vessel.

          vessel_class: The common name for a group of ships with similar design, usually named for the
              first vessel of the class.

          vessel_description: Further description or explanation of the vessel or type.

          vessel_flag: The flag of the subject vessel.

          vessel_name: The name of this vessel. Vessel names that exceed the AIS 20 character are
              shortened (not truncated) to 15 character-spaces, followed by an underscore and
              the last 4 characters-spaces of the vessel full name.

          vessel_type: The reported ship type (e.g. Passenger, Tanker, Cargo, Other, etc.).

          vsl_wt: The weight in tons, of this vessel.

          width: The breadth of the vessel, in meters. A value of 63 indicates a vessel breadth
              of 63 meters or greater.

          year_built: Year the vessel went into service.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/vessel/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "body_id": body_id,
                    "alt_vessel_id": alt_vessel_id,
                    "callsign": callsign,
                    "entity": entity,
                    "first_seen": first_seen,
                    "hull_num": hull_num,
                    "id_entity": id_entity,
                    "id_organization": id_organization,
                    "imon": imon,
                    "length": length,
                    "max_draught": max_draught,
                    "max_speed": max_speed,
                    "mmsi": mmsi,
                    "num_blades": num_blades,
                    "num_shafts": num_shafts,
                    "origin": origin,
                    "prop_type": prop_type,
                    "sconum": sconum,
                    "status": status,
                    "stern_type": stern_type,
                    "vessel_builder": vessel_builder,
                    "vessel_class": vessel_class,
                    "vessel_description": vessel_description,
                    "vessel_flag": vessel_flag,
                    "vessel_name": vessel_name,
                    "vessel_type": vessel_type,
                    "vsl_wt": vsl_wt,
                    "width": width,
                    "year_built": year_built,
                },
                vessel_update_params.VesselUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[VesselListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/vessel",
            page=SyncOffsetPage[VesselListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_list_params.VesselListParams,
                ),
            ),
            model=VesselListResponse,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/vessel/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_count_params.VesselCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[vessel_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        vessel records as a POST body and ingest into the database. This operation is
        not intended to be used for automated feeds into UDL. Data providers should
        contact the UDL team for specific role assignments and for instructions on
        setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/vessel/createBulk",
            body=maybe_transform(body, Iterable[vessel_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselGetResponse:
        """
        Service operation to get a single vessel record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/vessel/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_get_params.VesselGetParams,
                ),
            ),
            cast_to=VesselGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/vessel/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VesselQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/vessel/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_tuple_params.VesselTupleParams,
                ),
            ),
            cast_to=VesselTupleResponse,
        )


class AsyncVesselResource(AsyncAPIResource):
    """
    This service provides operations for manipulation and querying of maritime Vessel and Vessel Status data. Vessel contains the static data of the specific vessel: mmsi, cruise speed, max speed, etc.
    """

    @cached_property
    def with_raw_response(self) -> AsyncVesselResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncVesselResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVesselResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncVesselResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        alt_vessel_id: str | Omit = omit,
        callsign: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        first_seen: Union[str, datetime] | Omit = omit,
        hull_num: str | Omit = omit,
        id_entity: str | Omit = omit,
        id_organization: str | Omit = omit,
        imon: int | Omit = omit,
        length: float | Omit = omit,
        max_draught: float | Omit = omit,
        max_speed: float | Omit = omit,
        mmsi: str | Omit = omit,
        num_blades: int | Omit = omit,
        num_shafts: int | Omit = omit,
        origin: str | Omit = omit,
        prop_type: str | Omit = omit,
        sconum: str | Omit = omit,
        status: str | Omit = omit,
        stern_type: str | Omit = omit,
        vessel_builder: str | Omit = omit,
        vessel_class: str | Omit = omit,
        vessel_description: str | Omit = omit,
        vessel_flag: str | Omit = omit,
        vessel_name: str | Omit = omit,
        vessel_type: str | Omit = omit,
        vsl_wt: float | Omit = omit,
        width: float | Omit = omit,
        year_built: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single vessel record as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          alt_vessel_id: The original source Id for this vessel.

          callsign: A uniquely designated identifier for the vessel's transmitter station. All radio
              transmissions must be individually identified by the call sign. Merchant and
              naval vessels are assigned call signs by their national licensing authorities.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          first_seen: The date this vessel was first seen.

          hull_num: The vessel hull number designation of this maritime vessel. The hull number is a
              1-6 character alphanumeric entry assigned to a ship and painted on the hull.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_organization: The UDL ID of the organization that owns the vessel.

          imon: The International Maritime Organization Number of the vessel. IMON is a
              seven-digit number that uniquely identifies the vessel.

          length: The overall length of the vessel, in meters. A value of 511 indicates a vessel
              length of 511 meters or greater.

          max_draught: The maximum static draught, in meters, of the vessel defined as the distance
              between the ship’s keel and the waterline of the vessel.

          max_speed: The maximum possible speed of this vessel in meters per second.

          mmsi: The Maritime Mobile Service Identity of the vessel. MMSI is a nine-digit number
              that identifies the transmitter station of the vessel.

          num_blades: The number of blades per shaft for this vessel.

          num_shafts: The number of shafts on this vessel.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          prop_type: The type of propulsion employed by this vessel.

          sconum: The Ship Control Number (SCONUM) is a naval vessel identification number
              (alphanumeric code) assigned by the Office of Naval Intelligence. SCONUM is
              sometimes referred to as NOIC ID. SCONUMs are typically of the form A#####,
              where A is an alpha character and # is numerical.

          status: The status of this vessel.

          stern_type: The stern type code (Counter, Cruiser) associated with this vessel.

          vessel_builder: The shipbuilder who built this vessel.

          vessel_class: The common name for a group of ships with similar design, usually named for the
              first vessel of the class.

          vessel_description: Further description or explanation of the vessel or type.

          vessel_flag: The flag of the subject vessel.

          vessel_name: The name of this vessel. Vessel names that exceed the AIS 20 character are
              shortened (not truncated) to 15 character-spaces, followed by an underscore and
              the last 4 characters-spaces of the vessel full name.

          vessel_type: The reported ship type (e.g. Passenger, Tanker, Cargo, Other, etc.).

          vsl_wt: The weight in tons, of this vessel.

          width: The breadth of the vessel, in meters. A value of 63 indicates a vessel breadth
              of 63 meters or greater.

          year_built: Year the vessel went into service.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/vessel",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "alt_vessel_id": alt_vessel_id,
                    "callsign": callsign,
                    "entity": entity,
                    "first_seen": first_seen,
                    "hull_num": hull_num,
                    "id_entity": id_entity,
                    "id_organization": id_organization,
                    "imon": imon,
                    "length": length,
                    "max_draught": max_draught,
                    "max_speed": max_speed,
                    "mmsi": mmsi,
                    "num_blades": num_blades,
                    "num_shafts": num_shafts,
                    "origin": origin,
                    "prop_type": prop_type,
                    "sconum": sconum,
                    "status": status,
                    "stern_type": stern_type,
                    "vessel_builder": vessel_builder,
                    "vessel_class": vessel_class,
                    "vessel_description": vessel_description,
                    "vessel_flag": vessel_flag,
                    "vessel_name": vessel_name,
                    "vessel_type": vessel_type,
                    "vsl_wt": vsl_wt,
                    "width": width,
                    "year_built": year_built,
                },
                vessel_create_params.VesselCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        body_id: str | Omit = omit,
        alt_vessel_id: str | Omit = omit,
        callsign: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        first_seen: Union[str, datetime] | Omit = omit,
        hull_num: str | Omit = omit,
        id_entity: str | Omit = omit,
        id_organization: str | Omit = omit,
        imon: int | Omit = omit,
        length: float | Omit = omit,
        max_draught: float | Omit = omit,
        max_speed: float | Omit = omit,
        mmsi: str | Omit = omit,
        num_blades: int | Omit = omit,
        num_shafts: int | Omit = omit,
        origin: str | Omit = omit,
        prop_type: str | Omit = omit,
        sconum: str | Omit = omit,
        status: str | Omit = omit,
        stern_type: str | Omit = omit,
        vessel_builder: str | Omit = omit,
        vessel_class: str | Omit = omit,
        vessel_description: str | Omit = omit,
        vessel_flag: str | Omit = omit,
        vessel_name: str | Omit = omit,
        vessel_type: str | Omit = omit,
        vsl_wt: float | Omit = omit,
        width: float | Omit = omit,
        year_built: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single vessel record.

        A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          alt_vessel_id: The original source Id for this vessel.

          callsign: A uniquely designated identifier for the vessel's transmitter station. All radio
              transmissions must be individually identified by the call sign. Merchant and
              naval vessels are assigned call signs by their national licensing authorities.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          first_seen: The date this vessel was first seen.

          hull_num: The vessel hull number designation of this maritime vessel. The hull number is a
              1-6 character alphanumeric entry assigned to a ship and painted on the hull.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_organization: The UDL ID of the organization that owns the vessel.

          imon: The International Maritime Organization Number of the vessel. IMON is a
              seven-digit number that uniquely identifies the vessel.

          length: The overall length of the vessel, in meters. A value of 511 indicates a vessel
              length of 511 meters or greater.

          max_draught: The maximum static draught, in meters, of the vessel defined as the distance
              between the ship’s keel and the waterline of the vessel.

          max_speed: The maximum possible speed of this vessel in meters per second.

          mmsi: The Maritime Mobile Service Identity of the vessel. MMSI is a nine-digit number
              that identifies the transmitter station of the vessel.

          num_blades: The number of blades per shaft for this vessel.

          num_shafts: The number of shafts on this vessel.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          prop_type: The type of propulsion employed by this vessel.

          sconum: The Ship Control Number (SCONUM) is a naval vessel identification number
              (alphanumeric code) assigned by the Office of Naval Intelligence. SCONUM is
              sometimes referred to as NOIC ID. SCONUMs are typically of the form A#####,
              where A is an alpha character and # is numerical.

          status: The status of this vessel.

          stern_type: The stern type code (Counter, Cruiser) associated with this vessel.

          vessel_builder: The shipbuilder who built this vessel.

          vessel_class: The common name for a group of ships with similar design, usually named for the
              first vessel of the class.

          vessel_description: Further description or explanation of the vessel or type.

          vessel_flag: The flag of the subject vessel.

          vessel_name: The name of this vessel. Vessel names that exceed the AIS 20 character are
              shortened (not truncated) to 15 character-spaces, followed by an underscore and
              the last 4 characters-spaces of the vessel full name.

          vessel_type: The reported ship type (e.g. Passenger, Tanker, Cargo, Other, etc.).

          vsl_wt: The weight in tons, of this vessel.

          width: The breadth of the vessel, in meters. A value of 63 indicates a vessel breadth
              of 63 meters or greater.

          year_built: Year the vessel went into service.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/vessel/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "body_id": body_id,
                    "alt_vessel_id": alt_vessel_id,
                    "callsign": callsign,
                    "entity": entity,
                    "first_seen": first_seen,
                    "hull_num": hull_num,
                    "id_entity": id_entity,
                    "id_organization": id_organization,
                    "imon": imon,
                    "length": length,
                    "max_draught": max_draught,
                    "max_speed": max_speed,
                    "mmsi": mmsi,
                    "num_blades": num_blades,
                    "num_shafts": num_shafts,
                    "origin": origin,
                    "prop_type": prop_type,
                    "sconum": sconum,
                    "status": status,
                    "stern_type": stern_type,
                    "vessel_builder": vessel_builder,
                    "vessel_class": vessel_class,
                    "vessel_description": vessel_description,
                    "vessel_flag": vessel_flag,
                    "vessel_name": vessel_name,
                    "vessel_type": vessel_type,
                    "vsl_wt": vsl_wt,
                    "width": width,
                    "year_built": year_built,
                },
                vessel_update_params.VesselUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[VesselListResponse, AsyncOffsetPage[VesselListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/vessel",
            page=AsyncOffsetPage[VesselListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_list_params.VesselListParams,
                ),
            ),
            model=VesselListResponse,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/vessel/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_count_params.VesselCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[vessel_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        vessel records as a POST body and ingest into the database. This operation is
        not intended to be used for automated feeds into UDL. Data providers should
        contact the UDL team for specific role assignments and for instructions on
        setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/vessel/createBulk",
            body=await async_maybe_transform(body, Iterable[vessel_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselGetResponse:
        """
        Service operation to get a single vessel record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/vessel/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_get_params.VesselGetParams,
                ),
            ),
            cast_to=VesselGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/vessel/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VesselQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VesselTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/vessel/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    vessel_tuple_params.VesselTupleParams,
                ),
            ),
            cast_to=VesselTupleResponse,
        )


class VesselResourceWithRawResponse:
    def __init__(self, vessel: VesselResource) -> None:
        self._vessel = vessel

        self.create = to_raw_response_wrapper(
            vessel.create,
        )
        self.update = to_raw_response_wrapper(
            vessel.update,
        )
        self.list = to_raw_response_wrapper(
            vessel.list,
        )
        self.count = to_raw_response_wrapper(
            vessel.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            vessel.create_bulk,
        )
        self.get = to_raw_response_wrapper(
            vessel.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            vessel.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            vessel.tuple,
        )


class AsyncVesselResourceWithRawResponse:
    def __init__(self, vessel: AsyncVesselResource) -> None:
        self._vessel = vessel

        self.create = async_to_raw_response_wrapper(
            vessel.create,
        )
        self.update = async_to_raw_response_wrapper(
            vessel.update,
        )
        self.list = async_to_raw_response_wrapper(
            vessel.list,
        )
        self.count = async_to_raw_response_wrapper(
            vessel.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            vessel.create_bulk,
        )
        self.get = async_to_raw_response_wrapper(
            vessel.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            vessel.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            vessel.tuple,
        )


class VesselResourceWithStreamingResponse:
    def __init__(self, vessel: VesselResource) -> None:
        self._vessel = vessel

        self.create = to_streamed_response_wrapper(
            vessel.create,
        )
        self.update = to_streamed_response_wrapper(
            vessel.update,
        )
        self.list = to_streamed_response_wrapper(
            vessel.list,
        )
        self.count = to_streamed_response_wrapper(
            vessel.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            vessel.create_bulk,
        )
        self.get = to_streamed_response_wrapper(
            vessel.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            vessel.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            vessel.tuple,
        )


class AsyncVesselResourceWithStreamingResponse:
    def __init__(self, vessel: AsyncVesselResource) -> None:
        self._vessel = vessel

        self.create = async_to_streamed_response_wrapper(
            vessel.create,
        )
        self.update = async_to_streamed_response_wrapper(
            vessel.update,
        )
        self.list = async_to_streamed_response_wrapper(
            vessel.list,
        )
        self.count = async_to_streamed_response_wrapper(
            vessel.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            vessel.create_bulk,
        )
        self.get = async_to_streamed_response_wrapper(
            vessel.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            vessel.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            vessel.tuple,
        )
