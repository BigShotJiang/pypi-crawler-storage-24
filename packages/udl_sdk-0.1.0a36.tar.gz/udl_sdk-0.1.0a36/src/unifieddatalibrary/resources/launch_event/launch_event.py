# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    launch_event_get_params,
    launch_event_list_params,
    launch_event_count_params,
    launch_event_tuple_params,
    launch_event_create_params,
    launch_event_create_bulk_params,
    launch_event_unvalidated_publish_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.launch_event_get_response import LaunchEventGetResponse
from ...types.launch_event_list_response import LaunchEventListResponse
from ...types.launch_event_tuple_response import LaunchEventTupleResponse
from ...types.launch_event_queryhelp_response import LaunchEventQueryhelpResponse

__all__ = ["LaunchEventResource", "AsyncLaunchEventResource"]


class LaunchEventResource(SyncAPIResource):
    """
    These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
    """

    @cached_property
    def history(self) -> HistoryResource:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> LaunchEventResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return LaunchEventResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LaunchEventResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return LaunchEventResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        msg_create_date: Union[str, datetime],
        source: str,
        id: str | Omit = omit,
        be_number: str | Omit = omit,
        declassification_date: Union[str, datetime] | Omit = omit,
        declassification_string: str | Omit = omit,
        derived_from: str | Omit = omit,
        launch_date: Union[str, datetime] | Omit = omit,
        launch_facility_name: str | Omit = omit,
        launch_failure_code: str | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        o_suffix: str | Omit = omit,
        sat_no: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single LaunchEvent as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          be_number: The Basic Encyclopedia Number, if applicable.

          declassification_date: The declassification date of this data, in ISO 8601 UTC format.

          declassification_string: Declassification string of this data.

          derived_from: The sources or SCG references from which the classification of this data is
              derived.

          launch_date: The launch date, in ISO8601 UTC format.

          launch_facility_name: The Launch facility name.

          launch_failure_code: The DISOB launch Failure Code, if applicable.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional target-id, if missing in UDL.

          o_suffix: The OSuffix, if applicable.

          sat_no: Satellite/catalog number of the target on-orbit object.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/launchevent",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "msg_create_date": msg_create_date,
                    "source": source,
                    "id": id,
                    "be_number": be_number,
                    "declassification_date": declassification_date,
                    "declassification_string": declassification_string,
                    "derived_from": derived_from,
                    "launch_date": launch_date,
                    "launch_facility_name": launch_facility_name,
                    "launch_failure_code": launch_failure_code,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "o_suffix": o_suffix,
                    "sat_no": sat_no,
                },
                launch_event_create_params.LaunchEventCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[LaunchEventListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/launchevent",
            page=SyncOffsetPage[LaunchEventListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_list_params.LaunchEventListParams,
                ),
            ),
            model=LaunchEventListResponse,
        )

    def count(
        self,
        *,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/launchevent/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_count_params.LaunchEventCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[launch_event_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        LaunchEvent as a POST body and ingest into the database. This operation is not
        intended to be used for automated feeds into UDL. Data providers should contact
        the UDL team for specific role assignments and for instructions on setting up a
        permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/launchevent/createBulk",
            body=maybe_transform(body, Iterable[launch_event_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventGetResponse:
        """
        Service operation to get a single LaunchEvent record by its unique ID passed as
        a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/launchevent/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_get_params.LaunchEventGetParams,
                ),
            ),
            cast_to=LaunchEventGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/launchevent/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LaunchEventQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/launchevent/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_tuple_params.LaunchEventTupleParams,
                ),
            ),
            cast_to=LaunchEventTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[launch_event_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take LaunchEvent entries as a POST body and ingest into the
        database. This operation is intended to be used for automated feeds into UDL. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-launchevent",
            body=maybe_transform(body, Iterable[launch_event_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncLaunchEventResource(AsyncAPIResource):
    """
    These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
    """

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncLaunchEventResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncLaunchEventResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLaunchEventResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncLaunchEventResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        msg_create_date: Union[str, datetime],
        source: str,
        id: str | Omit = omit,
        be_number: str | Omit = omit,
        declassification_date: Union[str, datetime] | Omit = omit,
        declassification_string: str | Omit = omit,
        derived_from: str | Omit = omit,
        launch_date: Union[str, datetime] | Omit = omit,
        launch_facility_name: str | Omit = omit,
        launch_failure_code: str | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        o_suffix: str | Omit = omit,
        sat_no: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single LaunchEvent as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          be_number: The Basic Encyclopedia Number, if applicable.

          declassification_date: The declassification date of this data, in ISO 8601 UTC format.

          declassification_string: Declassification string of this data.

          derived_from: The sources or SCG references from which the classification of this data is
              derived.

          launch_date: The launch date, in ISO8601 UTC format.

          launch_facility_name: The Launch facility name.

          launch_failure_code: The DISOB launch Failure Code, if applicable.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional target-id, if missing in UDL.

          o_suffix: The OSuffix, if applicable.

          sat_no: Satellite/catalog number of the target on-orbit object.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/launchevent",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "msg_create_date": msg_create_date,
                    "source": source,
                    "id": id,
                    "be_number": be_number,
                    "declassification_date": declassification_date,
                    "declassification_string": declassification_string,
                    "derived_from": derived_from,
                    "launch_date": launch_date,
                    "launch_facility_name": launch_facility_name,
                    "launch_failure_code": launch_failure_code,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "o_suffix": o_suffix,
                    "sat_no": sat_no,
                },
                launch_event_create_params.LaunchEventCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[LaunchEventListResponse, AsyncOffsetPage[LaunchEventListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/launchevent",
            page=AsyncOffsetPage[LaunchEventListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_list_params.LaunchEventListParams,
                ),
            ),
            model=LaunchEventListResponse,
        )

    async def count(
        self,
        *,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/launchevent/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_count_params.LaunchEventCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[launch_event_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        LaunchEvent as a POST body and ingest into the database. This operation is not
        intended to be used for automated feeds into UDL. Data providers should contact
        the UDL team for specific role assignments and for instructions on setting up a
        permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/launchevent/createBulk",
            body=await async_maybe_transform(body, Iterable[launch_event_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventGetResponse:
        """
        Service operation to get a single LaunchEvent record by its unique ID passed as
        a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/launchevent/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_get_params.LaunchEventGetParams,
                ),
            ),
            cast_to=LaunchEventGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/launchevent/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LaunchEventQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        msg_create_date: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchEventTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          msg_create_date: Timestamp of the originating message in ISO8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/launchevent/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "msg_create_date": msg_create_date,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_event_tuple_params.LaunchEventTupleParams,
                ),
            ),
            cast_to=LaunchEventTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[launch_event_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take LaunchEvent entries as a POST body and ingest into the
        database. This operation is intended to be used for automated feeds into UDL. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-launchevent",
            body=await async_maybe_transform(body, Iterable[launch_event_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class LaunchEventResourceWithRawResponse:
    def __init__(self, launch_event: LaunchEventResource) -> None:
        self._launch_event = launch_event

        self.create = to_raw_response_wrapper(
            launch_event.create,
        )
        self.list = to_raw_response_wrapper(
            launch_event.list,
        )
        self.count = to_raw_response_wrapper(
            launch_event.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            launch_event.create_bulk,
        )
        self.get = to_raw_response_wrapper(
            launch_event.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            launch_event.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            launch_event.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            launch_event.unvalidated_publish,
        )

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return HistoryResourceWithRawResponse(self._launch_event.history)


class AsyncLaunchEventResourceWithRawResponse:
    def __init__(self, launch_event: AsyncLaunchEventResource) -> None:
        self._launch_event = launch_event

        self.create = async_to_raw_response_wrapper(
            launch_event.create,
        )
        self.list = async_to_raw_response_wrapper(
            launch_event.list,
        )
        self.count = async_to_raw_response_wrapper(
            launch_event.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            launch_event.create_bulk,
        )
        self.get = async_to_raw_response_wrapper(
            launch_event.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            launch_event.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            launch_event.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            launch_event.unvalidated_publish,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return AsyncHistoryResourceWithRawResponse(self._launch_event.history)


class LaunchEventResourceWithStreamingResponse:
    def __init__(self, launch_event: LaunchEventResource) -> None:
        self._launch_event = launch_event

        self.create = to_streamed_response_wrapper(
            launch_event.create,
        )
        self.list = to_streamed_response_wrapper(
            launch_event.list,
        )
        self.count = to_streamed_response_wrapper(
            launch_event.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            launch_event.create_bulk,
        )
        self.get = to_streamed_response_wrapper(
            launch_event.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            launch_event.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            launch_event.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            launch_event.unvalidated_publish,
        )

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return HistoryResourceWithStreamingResponse(self._launch_event.history)


class AsyncLaunchEventResourceWithStreamingResponse:
    def __init__(self, launch_event: AsyncLaunchEventResource) -> None:
        self._launch_event = launch_event

        self.create = async_to_streamed_response_wrapper(
            launch_event.create,
        )
        self.list = async_to_streamed_response_wrapper(
            launch_event.list,
        )
        self.count = async_to_streamed_response_wrapper(
            launch_event.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            launch_event.create_bulk,
        )
        self.get = async_to_streamed_response_wrapper(
            launch_event.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            launch_event.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            launch_event.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            launch_event.unvalidated_publish,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of LaunchEvent data. Launch Event data are known space launches, either future or historic records containing items such as the launch site, launch epoch, and object.
        """
        return AsyncHistoryResourceWithStreamingResponse(self._launch_event.history)
