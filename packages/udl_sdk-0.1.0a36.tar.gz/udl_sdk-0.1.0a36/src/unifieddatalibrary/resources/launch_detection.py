# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    launch_detection_get_params,
    launch_detection_list_params,
    launch_detection_count_params,
    launch_detection_tuple_params,
    launch_detection_create_params,
    launch_detection_update_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.launch_detection_get_response import LaunchDetectionGetResponse
from ..types.launch_detection_list_response import LaunchDetectionListResponse
from ..types.launch_detection_tuple_response import LaunchDetectionTupleResponse
from ..types.launch_detection_queryhelp_response import LaunchDetectionQueryhelpResponse

__all__ = ["LaunchDetectionResource", "AsyncLaunchDetectionResource"]


class LaunchDetectionResource(SyncAPIResource):
    """
    Collection of launch related services which provide operations for querying and manipulation of launch site data and detailed information on launch vehicles including engines, stages, and manufacturers. Sites, engines, and stages can each have multiple 'detail' records which may be compiled by different sources.
    """

    @cached_property
    def with_raw_response(self) -> LaunchDetectionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return LaunchDetectionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LaunchDetectionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return LaunchDetectionResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        message_type: str,
        observation_latitude: float,
        observation_longitude: float,
        observation_time: Union[str, datetime],
        sequence_number: int,
        source: str,
        id: str | Omit = omit,
        descriptor: str | Omit = omit,
        event_id: str | Omit = omit,
        high_zenith_azimuth: bool | Omit = omit,
        inclination: float | Omit = omit,
        launch_azimuth: float | Omit = omit,
        launch_latitude: float | Omit = omit,
        launch_longitude: float | Omit = omit,
        launch_time: Union[str, datetime] | Omit = omit,
        observation_altitude: float | Omit = omit,
        origin: str | Omit = omit,
        raan: float | Omit = omit,
        stereo_flag: bool | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single launch detection as a POST body and ingest
        into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          message_type: Type of message for the data.

          observation_latitude: Latitude of launch vehicle at observation time (in Degrees). -90 to 90 degrees
              (negative values south of equator).

          observation_longitude: Longitude of launch vehicle at observation time (in Degrees).

          observation_time: Time of observation.

          sequence_number: Integer indicating how messages should be sequenced for a specific event.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          event_id: Id to be able to correlate different messages to a specific event.

          high_zenith_azimuth: Flag indicating that the Launch azimuth is uncertain due to near vertical flight
              path.

          inclination: Orbit Inclination (in Degrees).

          launch_azimuth: Angle measured clockwise from North for the launch heading (in Degrees).

          launch_latitude: Geodetic Latitude of launch origin (in Degrees). -90 to 90 degrees (negative
              values south of equator).

          launch_longitude: Geodetic Longitude of launch origin (in Degrees). -180 to 180 degrees (negative
              values west of Prime Meridian).

          launch_time: Time of Launch.

          observation_altitude: Altitude of launch vehicle at observation time (in KM).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          raan: Orbit Right Ascension of Ascending Node (in Degrees).

          stereo_flag: Flag indicating multiple observers were used.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/launchdetection",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "message_type": message_type,
                    "observation_latitude": observation_latitude,
                    "observation_longitude": observation_longitude,
                    "observation_time": observation_time,
                    "sequence_number": sequence_number,
                    "source": source,
                    "id": id,
                    "descriptor": descriptor,
                    "event_id": event_id,
                    "high_zenith_azimuth": high_zenith_azimuth,
                    "inclination": inclination,
                    "launch_azimuth": launch_azimuth,
                    "launch_latitude": launch_latitude,
                    "launch_longitude": launch_longitude,
                    "launch_time": launch_time,
                    "observation_altitude": observation_altitude,
                    "origin": origin,
                    "raan": raan,
                    "stereo_flag": stereo_flag,
                    "tags": tags,
                },
                launch_detection_create_params.LaunchDetectionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        message_type: str,
        observation_latitude: float,
        observation_longitude: float,
        observation_time: Union[str, datetime],
        sequence_number: int,
        source: str,
        body_id: str | Omit = omit,
        descriptor: str | Omit = omit,
        event_id: str | Omit = omit,
        high_zenith_azimuth: bool | Omit = omit,
        inclination: float | Omit = omit,
        launch_azimuth: float | Omit = omit,
        launch_latitude: float | Omit = omit,
        launch_longitude: float | Omit = omit,
        launch_time: Union[str, datetime] | Omit = omit,
        observation_altitude: float | Omit = omit,
        origin: str | Omit = omit,
        raan: float | Omit = omit,
        stereo_flag: bool | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single launch detection.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          message_type: Type of message for the data.

          observation_latitude: Latitude of launch vehicle at observation time (in Degrees). -90 to 90 degrees
              (negative values south of equator).

          observation_longitude: Longitude of launch vehicle at observation time (in Degrees).

          observation_time: Time of observation.

          sequence_number: Integer indicating how messages should be sequenced for a specific event.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          event_id: Id to be able to correlate different messages to a specific event.

          high_zenith_azimuth: Flag indicating that the Launch azimuth is uncertain due to near vertical flight
              path.

          inclination: Orbit Inclination (in Degrees).

          launch_azimuth: Angle measured clockwise from North for the launch heading (in Degrees).

          launch_latitude: Geodetic Latitude of launch origin (in Degrees). -90 to 90 degrees (negative
              values south of equator).

          launch_longitude: Geodetic Longitude of launch origin (in Degrees). -180 to 180 degrees (negative
              values west of Prime Meridian).

          launch_time: Time of Launch.

          observation_altitude: Altitude of launch vehicle at observation time (in KM).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          raan: Orbit Right Ascension of Ascending Node (in Degrees).

          stereo_flag: Flag indicating multiple observers were used.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/launchdetection/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "message_type": message_type,
                    "observation_latitude": observation_latitude,
                    "observation_longitude": observation_longitude,
                    "observation_time": observation_time,
                    "sequence_number": sequence_number,
                    "source": source,
                    "body_id": body_id,
                    "descriptor": descriptor,
                    "event_id": event_id,
                    "high_zenith_azimuth": high_zenith_azimuth,
                    "inclination": inclination,
                    "launch_azimuth": launch_azimuth,
                    "launch_latitude": launch_latitude,
                    "launch_longitude": launch_longitude,
                    "launch_time": launch_time,
                    "observation_altitude": observation_altitude,
                    "origin": origin,
                    "raan": raan,
                    "stereo_flag": stereo_flag,
                    "tags": tags,
                },
                launch_detection_update_params.LaunchDetectionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[LaunchDetectionListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/launchdetection",
            page=SyncOffsetPage[LaunchDetectionListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_list_params.LaunchDetectionListParams,
                ),
            ),
            model=LaunchDetectionListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a launch detection object specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/launchdetection/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/launchdetection/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_count_params.LaunchDetectionCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionGetResponse:
        """
        Service operation to get a single launch detection record by its unique ID
        passed as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/launchdetection/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_get_params.LaunchDetectionGetParams,
                ),
            ),
            cast_to=LaunchDetectionGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/launchdetection/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LaunchDetectionQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/launchdetection/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_tuple_params.LaunchDetectionTupleParams,
                ),
            ),
            cast_to=LaunchDetectionTupleResponse,
        )


class AsyncLaunchDetectionResource(AsyncAPIResource):
    """
    Collection of launch related services which provide operations for querying and manipulation of launch site data and detailed information on launch vehicles including engines, stages, and manufacturers. Sites, engines, and stages can each have multiple 'detail' records which may be compiled by different sources.
    """

    @cached_property
    def with_raw_response(self) -> AsyncLaunchDetectionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncLaunchDetectionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLaunchDetectionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncLaunchDetectionResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        message_type: str,
        observation_latitude: float,
        observation_longitude: float,
        observation_time: Union[str, datetime],
        sequence_number: int,
        source: str,
        id: str | Omit = omit,
        descriptor: str | Omit = omit,
        event_id: str | Omit = omit,
        high_zenith_azimuth: bool | Omit = omit,
        inclination: float | Omit = omit,
        launch_azimuth: float | Omit = omit,
        launch_latitude: float | Omit = omit,
        launch_longitude: float | Omit = omit,
        launch_time: Union[str, datetime] | Omit = omit,
        observation_altitude: float | Omit = omit,
        origin: str | Omit = omit,
        raan: float | Omit = omit,
        stereo_flag: bool | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single launch detection as a POST body and ingest
        into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          message_type: Type of message for the data.

          observation_latitude: Latitude of launch vehicle at observation time (in Degrees). -90 to 90 degrees
              (negative values south of equator).

          observation_longitude: Longitude of launch vehicle at observation time (in Degrees).

          observation_time: Time of observation.

          sequence_number: Integer indicating how messages should be sequenced for a specific event.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          event_id: Id to be able to correlate different messages to a specific event.

          high_zenith_azimuth: Flag indicating that the Launch azimuth is uncertain due to near vertical flight
              path.

          inclination: Orbit Inclination (in Degrees).

          launch_azimuth: Angle measured clockwise from North for the launch heading (in Degrees).

          launch_latitude: Geodetic Latitude of launch origin (in Degrees). -90 to 90 degrees (negative
              values south of equator).

          launch_longitude: Geodetic Longitude of launch origin (in Degrees). -180 to 180 degrees (negative
              values west of Prime Meridian).

          launch_time: Time of Launch.

          observation_altitude: Altitude of launch vehicle at observation time (in KM).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          raan: Orbit Right Ascension of Ascending Node (in Degrees).

          stereo_flag: Flag indicating multiple observers were used.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/launchdetection",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "message_type": message_type,
                    "observation_latitude": observation_latitude,
                    "observation_longitude": observation_longitude,
                    "observation_time": observation_time,
                    "sequence_number": sequence_number,
                    "source": source,
                    "id": id,
                    "descriptor": descriptor,
                    "event_id": event_id,
                    "high_zenith_azimuth": high_zenith_azimuth,
                    "inclination": inclination,
                    "launch_azimuth": launch_azimuth,
                    "launch_latitude": launch_latitude,
                    "launch_longitude": launch_longitude,
                    "launch_time": launch_time,
                    "observation_altitude": observation_altitude,
                    "origin": origin,
                    "raan": raan,
                    "stereo_flag": stereo_flag,
                    "tags": tags,
                },
                launch_detection_create_params.LaunchDetectionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        message_type: str,
        observation_latitude: float,
        observation_longitude: float,
        observation_time: Union[str, datetime],
        sequence_number: int,
        source: str,
        body_id: str | Omit = omit,
        descriptor: str | Omit = omit,
        event_id: str | Omit = omit,
        high_zenith_azimuth: bool | Omit = omit,
        inclination: float | Omit = omit,
        launch_azimuth: float | Omit = omit,
        launch_latitude: float | Omit = omit,
        launch_longitude: float | Omit = omit,
        launch_time: Union[str, datetime] | Omit = omit,
        observation_altitude: float | Omit = omit,
        origin: str | Omit = omit,
        raan: float | Omit = omit,
        stereo_flag: bool | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single launch detection.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          message_type: Type of message for the data.

          observation_latitude: Latitude of launch vehicle at observation time (in Degrees). -90 to 90 degrees
              (negative values south of equator).

          observation_longitude: Longitude of launch vehicle at observation time (in Degrees).

          observation_time: Time of observation.

          sequence_number: Integer indicating how messages should be sequenced for a specific event.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          event_id: Id to be able to correlate different messages to a specific event.

          high_zenith_azimuth: Flag indicating that the Launch azimuth is uncertain due to near vertical flight
              path.

          inclination: Orbit Inclination (in Degrees).

          launch_azimuth: Angle measured clockwise from North for the launch heading (in Degrees).

          launch_latitude: Geodetic Latitude of launch origin (in Degrees). -90 to 90 degrees (negative
              values south of equator).

          launch_longitude: Geodetic Longitude of launch origin (in Degrees). -180 to 180 degrees (negative
              values west of Prime Meridian).

          launch_time: Time of Launch.

          observation_altitude: Altitude of launch vehicle at observation time (in KM).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          raan: Orbit Right Ascension of Ascending Node (in Degrees).

          stereo_flag: Flag indicating multiple observers were used.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/launchdetection/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "message_type": message_type,
                    "observation_latitude": observation_latitude,
                    "observation_longitude": observation_longitude,
                    "observation_time": observation_time,
                    "sequence_number": sequence_number,
                    "source": source,
                    "body_id": body_id,
                    "descriptor": descriptor,
                    "event_id": event_id,
                    "high_zenith_azimuth": high_zenith_azimuth,
                    "inclination": inclination,
                    "launch_azimuth": launch_azimuth,
                    "launch_latitude": launch_latitude,
                    "launch_longitude": launch_longitude,
                    "launch_time": launch_time,
                    "observation_altitude": observation_altitude,
                    "origin": origin,
                    "raan": raan,
                    "stereo_flag": stereo_flag,
                    "tags": tags,
                },
                launch_detection_update_params.LaunchDetectionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[LaunchDetectionListResponse, AsyncOffsetPage[LaunchDetectionListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/launchdetection",
            page=AsyncOffsetPage[LaunchDetectionListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_list_params.LaunchDetectionListParams,
                ),
            ),
            model=LaunchDetectionListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a launch detection object specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/launchdetection/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/launchdetection/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_count_params.LaunchDetectionCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionGetResponse:
        """
        Service operation to get a single launch detection record by its unique ID
        passed as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/launchdetection/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_get_params.LaunchDetectionGetParams,
                ),
            ),
            cast_to=LaunchDetectionGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/launchdetection/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LaunchDetectionQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LaunchDetectionTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/launchdetection/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    launch_detection_tuple_params.LaunchDetectionTupleParams,
                ),
            ),
            cast_to=LaunchDetectionTupleResponse,
        )


class LaunchDetectionResourceWithRawResponse:
    def __init__(self, launch_detection: LaunchDetectionResource) -> None:
        self._launch_detection = launch_detection

        self.create = to_raw_response_wrapper(
            launch_detection.create,
        )
        self.update = to_raw_response_wrapper(
            launch_detection.update,
        )
        self.list = to_raw_response_wrapper(
            launch_detection.list,
        )
        self.delete = to_raw_response_wrapper(
            launch_detection.delete,
        )
        self.count = to_raw_response_wrapper(
            launch_detection.count,
        )
        self.get = to_raw_response_wrapper(
            launch_detection.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            launch_detection.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            launch_detection.tuple,
        )


class AsyncLaunchDetectionResourceWithRawResponse:
    def __init__(self, launch_detection: AsyncLaunchDetectionResource) -> None:
        self._launch_detection = launch_detection

        self.create = async_to_raw_response_wrapper(
            launch_detection.create,
        )
        self.update = async_to_raw_response_wrapper(
            launch_detection.update,
        )
        self.list = async_to_raw_response_wrapper(
            launch_detection.list,
        )
        self.delete = async_to_raw_response_wrapper(
            launch_detection.delete,
        )
        self.count = async_to_raw_response_wrapper(
            launch_detection.count,
        )
        self.get = async_to_raw_response_wrapper(
            launch_detection.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            launch_detection.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            launch_detection.tuple,
        )


class LaunchDetectionResourceWithStreamingResponse:
    def __init__(self, launch_detection: LaunchDetectionResource) -> None:
        self._launch_detection = launch_detection

        self.create = to_streamed_response_wrapper(
            launch_detection.create,
        )
        self.update = to_streamed_response_wrapper(
            launch_detection.update,
        )
        self.list = to_streamed_response_wrapper(
            launch_detection.list,
        )
        self.delete = to_streamed_response_wrapper(
            launch_detection.delete,
        )
        self.count = to_streamed_response_wrapper(
            launch_detection.count,
        )
        self.get = to_streamed_response_wrapper(
            launch_detection.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            launch_detection.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            launch_detection.tuple,
        )


class AsyncLaunchDetectionResourceWithStreamingResponse:
    def __init__(self, launch_detection: AsyncLaunchDetectionResource) -> None:
        self._launch_detection = launch_detection

        self.create = async_to_streamed_response_wrapper(
            launch_detection.create,
        )
        self.update = async_to_streamed_response_wrapper(
            launch_detection.update,
        )
        self.list = async_to_streamed_response_wrapper(
            launch_detection.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            launch_detection.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            launch_detection.count,
        )
        self.get = async_to_streamed_response_wrapper(
            launch_detection.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            launch_detection.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            launch_detection.tuple,
        )
