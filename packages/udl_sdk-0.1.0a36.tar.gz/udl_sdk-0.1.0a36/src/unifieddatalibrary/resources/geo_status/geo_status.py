# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import date
from typing_extensions import Literal

import httpx

from ...types import (
    geo_status_get_params,
    geo_status_list_params,
    geo_status_count_params,
    geo_status_tuple_params,
    geo_status_create_params,
    geo_status_create_bulk_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.geo_status_list_response import GeoStatusListResponse
from ...types.geo_status_tuple_response import GeoStatusTupleResponse
from ...types.geo_status.geo_status_full import GeoStatusFull
from ...types.geo_status_queryhelp_response import GeoStatusQueryhelpResponse

__all__ = ["GeoStatusResource", "AsyncGeoStatusResource"]


class GeoStatusResource(SyncAPIResource):
    """
    These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
    """

    @cached_property
    def history(self) -> HistoryResource:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> GeoStatusResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return GeoStatusResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> GeoStatusResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return GeoStatusResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        confidence_level: str | Omit = omit,
        longitude_max: float | Omit = omit,
        longitude_min: float | Omit = omit,
        longitude_rate: float | Omit = omit,
        lost_flag: bool | Omit = omit,
        object_status: str | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        plane_change_status: str | Omit = omit,
        raw_file_uri: str | Omit = omit,
        relative_energy: float | Omit = omit,
        sat_no: int | Omit = omit,
        sc: float | Omit = omit,
        semi_annual_corr_flag: bool | Omit = omit,
        ss: float | Omit = omit,
        trough_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single GEOStatus record as a POST body and ingest
        into the database. This operation is not intended to be used for automated feeds
        into UDL. Data providers should contact the UDL team for specific role
        assignments and for instructions on setting up a permanent feed through an
        alternate mechanism.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          confidence_level: Indicates the confidence level in the entry. (Low, Medium, High).

          longitude_max: Maximum longitude for this object. WGS-84 longitude of the spacecraft position,
              in degrees. 0 to 360 degrees.

          longitude_min: Minimum longitude for this object. WGS-84 longitude of the spacecraft position,
              in degrees. 0 to 360 degrees.

          longitude_rate: Corrective or overriding long term trend for longitudinal change in degrees/day.

          lost_flag: Lost space object indicator. (True or False).

          object_status: Space object status. (Active, Dead, Unknown).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional identifier provided to indicate the target onorbit. This may be an
              internal identifier and not necessarily map to a valid satellite number.

          plane_change_status: Geosynchronous plane changing status. (Current, Never, Former, Future).

          raw_file_uri: Optional URI location in the document repository of the raw file parsed by the
              system to produce this record. To download the raw file, prepend
              https://udl-hostname/scs/download?id= to this value.

          relative_energy: Objects displacement from geostationary orbit in deg^2/day^2.

          sat_no: Satellite/catalog number of the target on-orbit object.

          sc: Sine of inclination times the cosine of right ascension.

          semi_annual_corr_flag: Semi-annual correction. (True or False).

          ss: Sine of inclination times the sine of right ascension.

          trough_type:
              Indicates the trough (gravity well) or drift direction of a space object:

              255 - Influenced by 255° longitude trough.

              75 - Influenced by 75° longitude trough.

              Both - Oscillating between both 255 and 75 troughs.

              East - Drifting eastward; large relative energy and a period less than 1436.1
              minutes.

              West - Drifting westward; large relative energy and a period greater than 1436.2
              minutes.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/geostatus",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "confidence_level": confidence_level,
                    "longitude_max": longitude_max,
                    "longitude_min": longitude_min,
                    "longitude_rate": longitude_rate,
                    "lost_flag": lost_flag,
                    "object_status": object_status,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "plane_change_status": plane_change_status,
                    "raw_file_uri": raw_file_uri,
                    "relative_energy": relative_energy,
                    "sat_no": sat_no,
                    "sc": sc,
                    "semi_annual_corr_flag": semi_annual_corr_flag,
                    "ss": ss,
                    "trough_type": trough_type,
                },
                geo_status_create_params.GeoStatusCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[GeoStatusListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/geostatus",
            page=SyncOffsetPage[GeoStatusListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_list_params.GeoStatusListParams,
                ),
            ),
            model=GeoStatusListResponse,
        )

    def count(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/geostatus/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_count_params.GeoStatusCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[geo_status_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        GEOStatus records as a POST body and ingest into the database. This operation is
        not intended to be used for automated feeds into UDL. Data providers should
        contact the UDL team for specific role assignments and for instructions on
        setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/geostatus/createBulk",
            body=maybe_transform(body, Iterable[geo_status_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusFull:
        """
        Service operation to get a single GEOStatus record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/geostatus/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_get_params.GeoStatusGetParams,
                ),
            ),
            cast_to=GeoStatusFull,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/geostatus/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GeoStatusQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/geostatus/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_tuple_params.GeoStatusTupleParams,
                ),
            ),
            cast_to=GeoStatusTupleResponse,
        )


class AsyncGeoStatusResource(AsyncAPIResource):
    """
    These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
    """

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncGeoStatusResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncGeoStatusResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncGeoStatusResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncGeoStatusResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        confidence_level: str | Omit = omit,
        longitude_max: float | Omit = omit,
        longitude_min: float | Omit = omit,
        longitude_rate: float | Omit = omit,
        lost_flag: bool | Omit = omit,
        object_status: str | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        plane_change_status: str | Omit = omit,
        raw_file_uri: str | Omit = omit,
        relative_energy: float | Omit = omit,
        sat_no: int | Omit = omit,
        sc: float | Omit = omit,
        semi_annual_corr_flag: bool | Omit = omit,
        ss: float | Omit = omit,
        trough_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single GEOStatus record as a POST body and ingest
        into the database. This operation is not intended to be used for automated feeds
        into UDL. Data providers should contact the UDL team for specific role
        assignments and for instructions on setting up a permanent feed through an
        alternate mechanism.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          confidence_level: Indicates the confidence level in the entry. (Low, Medium, High).

          longitude_max: Maximum longitude for this object. WGS-84 longitude of the spacecraft position,
              in degrees. 0 to 360 degrees.

          longitude_min: Minimum longitude for this object. WGS-84 longitude of the spacecraft position,
              in degrees. 0 to 360 degrees.

          longitude_rate: Corrective or overriding long term trend for longitudinal change in degrees/day.

          lost_flag: Lost space object indicator. (True or False).

          object_status: Space object status. (Active, Dead, Unknown).

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional identifier provided to indicate the target onorbit. This may be an
              internal identifier and not necessarily map to a valid satellite number.

          plane_change_status: Geosynchronous plane changing status. (Current, Never, Former, Future).

          raw_file_uri: Optional URI location in the document repository of the raw file parsed by the
              system to produce this record. To download the raw file, prepend
              https://udl-hostname/scs/download?id= to this value.

          relative_energy: Objects displacement from geostationary orbit in deg^2/day^2.

          sat_no: Satellite/catalog number of the target on-orbit object.

          sc: Sine of inclination times the cosine of right ascension.

          semi_annual_corr_flag: Semi-annual correction. (True or False).

          ss: Sine of inclination times the sine of right ascension.

          trough_type:
              Indicates the trough (gravity well) or drift direction of a space object:

              255 - Influenced by 255° longitude trough.

              75 - Influenced by 75° longitude trough.

              Both - Oscillating between both 255 and 75 troughs.

              East - Drifting eastward; large relative energy and a period less than 1436.1
              minutes.

              West - Drifting westward; large relative energy and a period greater than 1436.2
              minutes.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/geostatus",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "confidence_level": confidence_level,
                    "longitude_max": longitude_max,
                    "longitude_min": longitude_min,
                    "longitude_rate": longitude_rate,
                    "lost_flag": lost_flag,
                    "object_status": object_status,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "plane_change_status": plane_change_status,
                    "raw_file_uri": raw_file_uri,
                    "relative_energy": relative_energy,
                    "sat_no": sat_no,
                    "sc": sc,
                    "semi_annual_corr_flag": semi_annual_corr_flag,
                    "ss": ss,
                    "trough_type": trough_type,
                },
                geo_status_create_params.GeoStatusCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[GeoStatusListResponse, AsyncOffsetPage[GeoStatusListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/geostatus",
            page=AsyncOffsetPage[GeoStatusListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_list_params.GeoStatusListParams,
                ),
            ),
            model=GeoStatusListResponse,
        )

    async def count(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/geostatus/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_count_params.GeoStatusCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[geo_status_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        GEOStatus records as a POST body and ingest into the database. This operation is
        not intended to be used for automated feeds into UDL. Data providers should
        contact the UDL team for specific role assignments and for instructions on
        setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/geostatus/createBulk",
            body=await async_maybe_transform(body, Iterable[geo_status_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusFull:
        """
        Service operation to get a single GEOStatus record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/geostatus/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_get_params.GeoStatusGetParams,
                ),
            ),
            cast_to=GeoStatusFull,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/geostatus/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=GeoStatusQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> GeoStatusTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          created_at: Time the row was created in the database, auto-populated by the system.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/geostatus/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    geo_status_tuple_params.GeoStatusTupleParams,
                ),
            ),
            cast_to=GeoStatusTupleResponse,
        )


class GeoStatusResourceWithRawResponse:
    def __init__(self, geo_status: GeoStatusResource) -> None:
        self._geo_status = geo_status

        self.create = to_raw_response_wrapper(
            geo_status.create,
        )
        self.list = to_raw_response_wrapper(
            geo_status.list,
        )
        self.count = to_raw_response_wrapper(
            geo_status.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            geo_status.create_bulk,
        )
        self.get = to_raw_response_wrapper(
            geo_status.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            geo_status.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            geo_status.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return HistoryResourceWithRawResponse(self._geo_status.history)


class AsyncGeoStatusResourceWithRawResponse:
    def __init__(self, geo_status: AsyncGeoStatusResource) -> None:
        self._geo_status = geo_status

        self.create = async_to_raw_response_wrapper(
            geo_status.create,
        )
        self.list = async_to_raw_response_wrapper(
            geo_status.list,
        )
        self.count = async_to_raw_response_wrapper(
            geo_status.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            geo_status.create_bulk,
        )
        self.get = async_to_raw_response_wrapper(
            geo_status.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            geo_status.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            geo_status.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return AsyncHistoryResourceWithRawResponse(self._geo_status.history)


class GeoStatusResourceWithStreamingResponse:
    def __init__(self, geo_status: GeoStatusResource) -> None:
        self._geo_status = geo_status

        self.create = to_streamed_response_wrapper(
            geo_status.create,
        )
        self.list = to_streamed_response_wrapper(
            geo_status.list,
        )
        self.count = to_streamed_response_wrapper(
            geo_status.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            geo_status.create_bulk,
        )
        self.get = to_streamed_response_wrapper(
            geo_status.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            geo_status.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            geo_status.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return HistoryResourceWithStreamingResponse(self._geo_status.history)


class AsyncGeoStatusResourceWithStreamingResponse:
    def __init__(self, geo_status: AsyncGeoStatusResource) -> None:
        self._geo_status = geo_status

        self.create = async_to_streamed_response_wrapper(
            geo_status.create,
        )
        self.list = async_to_streamed_response_wrapper(
            geo_status.list,
        )
        self.count = async_to_streamed_response_wrapper(
            geo_status.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            geo_status.create_bulk,
        )
        self.get = async_to_streamed_response_wrapper(
            geo_status.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            geo_status.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            geo_status.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
        """
        return AsyncHistoryResourceWithStreamingResponse(self._geo_status.history)
