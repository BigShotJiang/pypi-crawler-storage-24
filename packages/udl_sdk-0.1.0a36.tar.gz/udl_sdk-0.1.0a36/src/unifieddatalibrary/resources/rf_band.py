# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal

import httpx

from ..types import (
    rf_band_get_params,
    rf_band_list_params,
    rf_band_count_params,
    rf_band_tuple_params,
    rf_band_create_params,
    rf_band_update_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.shared.rf_band_full import RfBandFull
from ..types.rf_band_list_response import RfBandListResponse
from ..types.rf_band_tuple_response import RfBandTupleResponse
from ..types.rf_band_queryhelp_response import RfBandQueryhelpResponse

__all__ = ["RfBandResource", "AsyncRfBandResource"]


class RfBandResource(SyncAPIResource):
    """
    This collection of services provides operations for querying and manipulation of RF related information to include RFEmitters which could potentially interfere with communications/operations of space related entities, and RFBands commonly used by various space related entities.
    """

    @cached_property
    def with_raw_response(self) -> RfBandResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return RfBandResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RfBandResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return RfBandResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_entity: str,
        name: str,
        source: str,
        id: str | Omit = omit,
        band: str | Omit = omit,
        bandwidth: float | Omit = omit,
        bandwidth_settings: Iterable[float] | Omit = omit,
        beamwidth: float | Omit = omit,
        beamwidth_settings: Iterable[float] | Omit = omit,
        center_freq: float | Omit = omit,
        delay_settings: Iterable[float] | Omit = omit,
        edge_gain: float | Omit = omit,
        eirp: float | Omit = omit,
        erp: float | Omit = omit,
        freq_max: float | Omit = omit,
        freq_min: float | Omit = omit,
        frequency_settings: Iterable[float] | Omit = omit,
        gain_settings: Iterable[float] | Omit = omit,
        mode: Literal["TX", "RX"] | Omit = omit,
        noise_settings: Iterable[float] | Omit = omit,
        origin: str | Omit = omit,
        peak_gain: float | Omit = omit,
        polarization: Literal["H", "V", "R", "L"] | Omit = omit,
        purpose: Literal["COMM", "TTC", "OPS", "OTHER"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single RFBand record as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_entity: Unique identifier of the parent Entity which uses this band.

          name: RF Band name.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          band: Name of the band of this RF range (e.g.
              X,K,Ku,Ka,L,S,C,UHF,VHF,EHF,SHF,UNK,VLF,HF,E,Q,V,W). See RFBandType for more
              details and descriptions of each band name.

          bandwidth: RF Band frequency range bandwidth in megahertz.

          bandwidth_settings: Array of frequency range bandwidth settings, in megahertz for this RFBand. If
              this array is specified then it must be the same size as the frequencySettings
              array. A null value may be used for one or more of the frequencies in the
              frequencySettings array if there is no corresponding value for a given
              frequency.

          beamwidth: Angle between the half-power (-3 dB) points of the main lobe of the antenna, in
              degrees.

          beamwidth_settings: Array of beamwidth settings, in degrees for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          center_freq: Center frequency of RF frequency range, if applicable, in megahertz.

          delay_settings: Array of delay settings, in seconds for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          edge_gain: RF Range edge gain, in decibel relative to isotrope.

          eirp: EIRP is defined as the RMS power input in decibel watts required to a lossless
              half-wave dipole antenna to give the same maximum power density far from the
              antenna as the actual transmitter. It is equal to the power input to the
              transmitter's antenna multiplied by the antenna gain relative to a half-wave
              dipole. Effective radiated power and effective isotropic radiated power both
              measure the amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          erp: Effective Radiated Power (ERP) is the total power in decibel watts radiated by
              an actual antenna relative to a half-wave dipole rather than a theoretical
              isotropic antenna. A half-wave dipole has a gain of 2.15 dB compared to an
              isotropic antenna. EIRP(dB) = ERP (dB)+2.15 dB or EIRP (W) = 1.64\\**ERP(W).
              Effective radiated power and effective isotropic radiated power both measure the
              amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          freq_max: End/maximum of transmit RF frequency range, if applicable, in megahertz.

          freq_min: Start/minimum of transmit RF frequency range, if applicable, in megahertz.

          frequency_settings: Array of frequency settings, in megahertz for this RFBand. This array and the
              settings arrays must match in size.

          gain_settings: Array of gain settings, in decibels for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          mode: RF Band mode (e.g. TX, RX).

          noise_settings: Array of signal noise settings, in decibels for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          peak_gain: RF Range maximum gain, in decibel relative to isotrope.

          polarization: Transponder polarization e.g. H - (Horizontally Polarized) Perpendicular to
              Earth's surface, V - (Vertically Polarized) Parallel to Earth's surface, L -
              (Left Hand Circularly Polarized) Rotating left relative to the Earth's surface,
              R - (Right Hand Circularly Polarized) Rotating right relative to the Earth's
              surface.

          purpose: Purpose or use of the RF Band -- COMM = communications, TTC =
              Telemetry/Tracking/Control, OPS = Operations, OTHER = Other.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/rfband",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_entity": id_entity,
                    "name": name,
                    "source": source,
                    "id": id,
                    "band": band,
                    "bandwidth": bandwidth,
                    "bandwidth_settings": bandwidth_settings,
                    "beamwidth": beamwidth,
                    "beamwidth_settings": beamwidth_settings,
                    "center_freq": center_freq,
                    "delay_settings": delay_settings,
                    "edge_gain": edge_gain,
                    "eirp": eirp,
                    "erp": erp,
                    "freq_max": freq_max,
                    "freq_min": freq_min,
                    "frequency_settings": frequency_settings,
                    "gain_settings": gain_settings,
                    "mode": mode,
                    "noise_settings": noise_settings,
                    "origin": origin,
                    "peak_gain": peak_gain,
                    "polarization": polarization,
                    "purpose": purpose,
                },
                rf_band_create_params.RfBandCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_entity: str,
        name: str,
        source: str,
        body_id: str | Omit = omit,
        band: str | Omit = omit,
        bandwidth: float | Omit = omit,
        bandwidth_settings: Iterable[float] | Omit = omit,
        beamwidth: float | Omit = omit,
        beamwidth_settings: Iterable[float] | Omit = omit,
        center_freq: float | Omit = omit,
        delay_settings: Iterable[float] | Omit = omit,
        edge_gain: float | Omit = omit,
        eirp: float | Omit = omit,
        erp: float | Omit = omit,
        freq_max: float | Omit = omit,
        freq_min: float | Omit = omit,
        frequency_settings: Iterable[float] | Omit = omit,
        gain_settings: Iterable[float] | Omit = omit,
        mode: Literal["TX", "RX"] | Omit = omit,
        noise_settings: Iterable[float] | Omit = omit,
        origin: str | Omit = omit,
        peak_gain: float | Omit = omit,
        polarization: Literal["H", "V", "R", "L"] | Omit = omit,
        purpose: Literal["COMM", "TTC", "OPS", "OTHER"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single RFBand record.

        A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_entity: Unique identifier of the parent Entity which uses this band.

          name: RF Band name.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          band: Name of the band of this RF range (e.g.
              X,K,Ku,Ka,L,S,C,UHF,VHF,EHF,SHF,UNK,VLF,HF,E,Q,V,W). See RFBandType for more
              details and descriptions of each band name.

          bandwidth: RF Band frequency range bandwidth in megahertz.

          bandwidth_settings: Array of frequency range bandwidth settings, in megahertz for this RFBand. If
              this array is specified then it must be the same size as the frequencySettings
              array. A null value may be used for one or more of the frequencies in the
              frequencySettings array if there is no corresponding value for a given
              frequency.

          beamwidth: Angle between the half-power (-3 dB) points of the main lobe of the antenna, in
              degrees.

          beamwidth_settings: Array of beamwidth settings, in degrees for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          center_freq: Center frequency of RF frequency range, if applicable, in megahertz.

          delay_settings: Array of delay settings, in seconds for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          edge_gain: RF Range edge gain, in decibel relative to isotrope.

          eirp: EIRP is defined as the RMS power input in decibel watts required to a lossless
              half-wave dipole antenna to give the same maximum power density far from the
              antenna as the actual transmitter. It is equal to the power input to the
              transmitter's antenna multiplied by the antenna gain relative to a half-wave
              dipole. Effective radiated power and effective isotropic radiated power both
              measure the amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          erp: Effective Radiated Power (ERP) is the total power in decibel watts radiated by
              an actual antenna relative to a half-wave dipole rather than a theoretical
              isotropic antenna. A half-wave dipole has a gain of 2.15 dB compared to an
              isotropic antenna. EIRP(dB) = ERP (dB)+2.15 dB or EIRP (W) = 1.64\\**ERP(W).
              Effective radiated power and effective isotropic radiated power both measure the
              amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          freq_max: End/maximum of transmit RF frequency range, if applicable, in megahertz.

          freq_min: Start/minimum of transmit RF frequency range, if applicable, in megahertz.

          frequency_settings: Array of frequency settings, in megahertz for this RFBand. This array and the
              settings arrays must match in size.

          gain_settings: Array of gain settings, in decibels for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          mode: RF Band mode (e.g. TX, RX).

          noise_settings: Array of signal noise settings, in decibels for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          peak_gain: RF Range maximum gain, in decibel relative to isotrope.

          polarization: Transponder polarization e.g. H - (Horizontally Polarized) Perpendicular to
              Earth's surface, V - (Vertically Polarized) Parallel to Earth's surface, L -
              (Left Hand Circularly Polarized) Rotating left relative to the Earth's surface,
              R - (Right Hand Circularly Polarized) Rotating right relative to the Earth's
              surface.

          purpose: Purpose or use of the RF Band -- COMM = communications, TTC =
              Telemetry/Tracking/Control, OPS = Operations, OTHER = Other.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/rfband/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_entity": id_entity,
                    "name": name,
                    "source": source,
                    "body_id": body_id,
                    "band": band,
                    "bandwidth": bandwidth,
                    "bandwidth_settings": bandwidth_settings,
                    "beamwidth": beamwidth,
                    "beamwidth_settings": beamwidth_settings,
                    "center_freq": center_freq,
                    "delay_settings": delay_settings,
                    "edge_gain": edge_gain,
                    "eirp": eirp,
                    "erp": erp,
                    "freq_max": freq_max,
                    "freq_min": freq_min,
                    "frequency_settings": frequency_settings,
                    "gain_settings": gain_settings,
                    "mode": mode,
                    "noise_settings": noise_settings,
                    "origin": origin,
                    "peak_gain": peak_gain,
                    "polarization": polarization,
                    "purpose": purpose,
                },
                rf_band_update_params.RfBandUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[RfBandListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/rfband",
            page=SyncOffsetPage[RfBandListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_list_params.RfBandListParams,
                ),
            ),
            model=RfBandListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a RFBand record specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/rfband/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/rfband/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_count_params.RfBandCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandFull:
        """
        Service operation to get a single RFBand record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/rfband/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_get_params.RfBandGetParams,
                ),
            ),
            cast_to=RfBandFull,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/rfband/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RfBandQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/rfband/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_tuple_params.RfBandTupleParams,
                ),
            ),
            cast_to=RfBandTupleResponse,
        )


class AsyncRfBandResource(AsyncAPIResource):
    """
    This collection of services provides operations for querying and manipulation of RF related information to include RFEmitters which could potentially interfere with communications/operations of space related entities, and RFBands commonly used by various space related entities.
    """

    @cached_property
    def with_raw_response(self) -> AsyncRfBandResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncRfBandResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRfBandResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncRfBandResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_entity: str,
        name: str,
        source: str,
        id: str | Omit = omit,
        band: str | Omit = omit,
        bandwidth: float | Omit = omit,
        bandwidth_settings: Iterable[float] | Omit = omit,
        beamwidth: float | Omit = omit,
        beamwidth_settings: Iterable[float] | Omit = omit,
        center_freq: float | Omit = omit,
        delay_settings: Iterable[float] | Omit = omit,
        edge_gain: float | Omit = omit,
        eirp: float | Omit = omit,
        erp: float | Omit = omit,
        freq_max: float | Omit = omit,
        freq_min: float | Omit = omit,
        frequency_settings: Iterable[float] | Omit = omit,
        gain_settings: Iterable[float] | Omit = omit,
        mode: Literal["TX", "RX"] | Omit = omit,
        noise_settings: Iterable[float] | Omit = omit,
        origin: str | Omit = omit,
        peak_gain: float | Omit = omit,
        polarization: Literal["H", "V", "R", "L"] | Omit = omit,
        purpose: Literal["COMM", "TTC", "OPS", "OTHER"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single RFBand record as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_entity: Unique identifier of the parent Entity which uses this band.

          name: RF Band name.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          band: Name of the band of this RF range (e.g.
              X,K,Ku,Ka,L,S,C,UHF,VHF,EHF,SHF,UNK,VLF,HF,E,Q,V,W). See RFBandType for more
              details and descriptions of each band name.

          bandwidth: RF Band frequency range bandwidth in megahertz.

          bandwidth_settings: Array of frequency range bandwidth settings, in megahertz for this RFBand. If
              this array is specified then it must be the same size as the frequencySettings
              array. A null value may be used for one or more of the frequencies in the
              frequencySettings array if there is no corresponding value for a given
              frequency.

          beamwidth: Angle between the half-power (-3 dB) points of the main lobe of the antenna, in
              degrees.

          beamwidth_settings: Array of beamwidth settings, in degrees for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          center_freq: Center frequency of RF frequency range, if applicable, in megahertz.

          delay_settings: Array of delay settings, in seconds for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          edge_gain: RF Range edge gain, in decibel relative to isotrope.

          eirp: EIRP is defined as the RMS power input in decibel watts required to a lossless
              half-wave dipole antenna to give the same maximum power density far from the
              antenna as the actual transmitter. It is equal to the power input to the
              transmitter's antenna multiplied by the antenna gain relative to a half-wave
              dipole. Effective radiated power and effective isotropic radiated power both
              measure the amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          erp: Effective Radiated Power (ERP) is the total power in decibel watts radiated by
              an actual antenna relative to a half-wave dipole rather than a theoretical
              isotropic antenna. A half-wave dipole has a gain of 2.15 dB compared to an
              isotropic antenna. EIRP(dB) = ERP (dB)+2.15 dB or EIRP (W) = 1.64\\**ERP(W).
              Effective radiated power and effective isotropic radiated power both measure the
              amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          freq_max: End/maximum of transmit RF frequency range, if applicable, in megahertz.

          freq_min: Start/minimum of transmit RF frequency range, if applicable, in megahertz.

          frequency_settings: Array of frequency settings, in megahertz for this RFBand. This array and the
              settings arrays must match in size.

          gain_settings: Array of gain settings, in decibels for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          mode: RF Band mode (e.g. TX, RX).

          noise_settings: Array of signal noise settings, in decibels for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          peak_gain: RF Range maximum gain, in decibel relative to isotrope.

          polarization: Transponder polarization e.g. H - (Horizontally Polarized) Perpendicular to
              Earth's surface, V - (Vertically Polarized) Parallel to Earth's surface, L -
              (Left Hand Circularly Polarized) Rotating left relative to the Earth's surface,
              R - (Right Hand Circularly Polarized) Rotating right relative to the Earth's
              surface.

          purpose: Purpose or use of the RF Band -- COMM = communications, TTC =
              Telemetry/Tracking/Control, OPS = Operations, OTHER = Other.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/rfband",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_entity": id_entity,
                    "name": name,
                    "source": source,
                    "id": id,
                    "band": band,
                    "bandwidth": bandwidth,
                    "bandwidth_settings": bandwidth_settings,
                    "beamwidth": beamwidth,
                    "beamwidth_settings": beamwidth_settings,
                    "center_freq": center_freq,
                    "delay_settings": delay_settings,
                    "edge_gain": edge_gain,
                    "eirp": eirp,
                    "erp": erp,
                    "freq_max": freq_max,
                    "freq_min": freq_min,
                    "frequency_settings": frequency_settings,
                    "gain_settings": gain_settings,
                    "mode": mode,
                    "noise_settings": noise_settings,
                    "origin": origin,
                    "peak_gain": peak_gain,
                    "polarization": polarization,
                    "purpose": purpose,
                },
                rf_band_create_params.RfBandCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_entity: str,
        name: str,
        source: str,
        body_id: str | Omit = omit,
        band: str | Omit = omit,
        bandwidth: float | Omit = omit,
        bandwidth_settings: Iterable[float] | Omit = omit,
        beamwidth: float | Omit = omit,
        beamwidth_settings: Iterable[float] | Omit = omit,
        center_freq: float | Omit = omit,
        delay_settings: Iterable[float] | Omit = omit,
        edge_gain: float | Omit = omit,
        eirp: float | Omit = omit,
        erp: float | Omit = omit,
        freq_max: float | Omit = omit,
        freq_min: float | Omit = omit,
        frequency_settings: Iterable[float] | Omit = omit,
        gain_settings: Iterable[float] | Omit = omit,
        mode: Literal["TX", "RX"] | Omit = omit,
        noise_settings: Iterable[float] | Omit = omit,
        origin: str | Omit = omit,
        peak_gain: float | Omit = omit,
        polarization: Literal["H", "V", "R", "L"] | Omit = omit,
        purpose: Literal["COMM", "TTC", "OPS", "OTHER"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single RFBand record.

        A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_entity: Unique identifier of the parent Entity which uses this band.

          name: RF Band name.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          band: Name of the band of this RF range (e.g.
              X,K,Ku,Ka,L,S,C,UHF,VHF,EHF,SHF,UNK,VLF,HF,E,Q,V,W). See RFBandType for more
              details and descriptions of each band name.

          bandwidth: RF Band frequency range bandwidth in megahertz.

          bandwidth_settings: Array of frequency range bandwidth settings, in megahertz for this RFBand. If
              this array is specified then it must be the same size as the frequencySettings
              array. A null value may be used for one or more of the frequencies in the
              frequencySettings array if there is no corresponding value for a given
              frequency.

          beamwidth: Angle between the half-power (-3 dB) points of the main lobe of the antenna, in
              degrees.

          beamwidth_settings: Array of beamwidth settings, in degrees for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          center_freq: Center frequency of RF frequency range, if applicable, in megahertz.

          delay_settings: Array of delay settings, in seconds for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          edge_gain: RF Range edge gain, in decibel relative to isotrope.

          eirp: EIRP is defined as the RMS power input in decibel watts required to a lossless
              half-wave dipole antenna to give the same maximum power density far from the
              antenna as the actual transmitter. It is equal to the power input to the
              transmitter's antenna multiplied by the antenna gain relative to a half-wave
              dipole. Effective radiated power and effective isotropic radiated power both
              measure the amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          erp: Effective Radiated Power (ERP) is the total power in decibel watts radiated by
              an actual antenna relative to a half-wave dipole rather than a theoretical
              isotropic antenna. A half-wave dipole has a gain of 2.15 dB compared to an
              isotropic antenna. EIRP(dB) = ERP (dB)+2.15 dB or EIRP (W) = 1.64\\**ERP(W).
              Effective radiated power and effective isotropic radiated power both measure the
              amount of power a radio transmitter and antenna (or other source of
              electromagnetic waves) radiates in a specific direction: in the direction of
              maximum signal strength (the main lobe) of its radiation pattern.

          freq_max: End/maximum of transmit RF frequency range, if applicable, in megahertz.

          freq_min: Start/minimum of transmit RF frequency range, if applicable, in megahertz.

          frequency_settings: Array of frequency settings, in megahertz for this RFBand. This array and the
              settings arrays must match in size.

          gain_settings: Array of gain settings, in decibels for this RFBand. If this array is specified
              then it must be the same size as the frequencySettings array. A null value may
              be used for one or more of the frequencies in the frequencySettings array if
              there is no corresponding value for a given frequency.

          mode: RF Band mode (e.g. TX, RX).

          noise_settings: Array of signal noise settings, in decibels for this RFBand. If this array is
              specified then it must be the same size as the frequencySettings array. A null
              value may be used for one or more of the frequencies in the frequencySettings
              array if there is no corresponding value for a given frequency.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          peak_gain: RF Range maximum gain, in decibel relative to isotrope.

          polarization: Transponder polarization e.g. H - (Horizontally Polarized) Perpendicular to
              Earth's surface, V - (Vertically Polarized) Parallel to Earth's surface, L -
              (Left Hand Circularly Polarized) Rotating left relative to the Earth's surface,
              R - (Right Hand Circularly Polarized) Rotating right relative to the Earth's
              surface.

          purpose: Purpose or use of the RF Band -- COMM = communications, TTC =
              Telemetry/Tracking/Control, OPS = Operations, OTHER = Other.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/rfband/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_entity": id_entity,
                    "name": name,
                    "source": source,
                    "body_id": body_id,
                    "band": band,
                    "bandwidth": bandwidth,
                    "bandwidth_settings": bandwidth_settings,
                    "beamwidth": beamwidth,
                    "beamwidth_settings": beamwidth_settings,
                    "center_freq": center_freq,
                    "delay_settings": delay_settings,
                    "edge_gain": edge_gain,
                    "eirp": eirp,
                    "erp": erp,
                    "freq_max": freq_max,
                    "freq_min": freq_min,
                    "frequency_settings": frequency_settings,
                    "gain_settings": gain_settings,
                    "mode": mode,
                    "noise_settings": noise_settings,
                    "origin": origin,
                    "peak_gain": peak_gain,
                    "polarization": polarization,
                    "purpose": purpose,
                },
                rf_band_update_params.RfBandUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[RfBandListResponse, AsyncOffsetPage[RfBandListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/rfband",
            page=AsyncOffsetPage[RfBandListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_list_params.RfBandListParams,
                ),
            ),
            model=RfBandListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a RFBand record specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/rfband/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/rfband/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_count_params.RfBandCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandFull:
        """
        Service operation to get a single RFBand record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/rfband/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_get_params.RfBandGetParams,
                ),
            ),
            cast_to=RfBandFull,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/rfband/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RfBandQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RfBandTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/rfband/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    rf_band_tuple_params.RfBandTupleParams,
                ),
            ),
            cast_to=RfBandTupleResponse,
        )


class RfBandResourceWithRawResponse:
    def __init__(self, rf_band: RfBandResource) -> None:
        self._rf_band = rf_band

        self.create = to_raw_response_wrapper(
            rf_band.create,
        )
        self.update = to_raw_response_wrapper(
            rf_band.update,
        )
        self.list = to_raw_response_wrapper(
            rf_band.list,
        )
        self.delete = to_raw_response_wrapper(
            rf_band.delete,
        )
        self.count = to_raw_response_wrapper(
            rf_band.count,
        )
        self.get = to_raw_response_wrapper(
            rf_band.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            rf_band.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            rf_band.tuple,
        )


class AsyncRfBandResourceWithRawResponse:
    def __init__(self, rf_band: AsyncRfBandResource) -> None:
        self._rf_band = rf_band

        self.create = async_to_raw_response_wrapper(
            rf_band.create,
        )
        self.update = async_to_raw_response_wrapper(
            rf_band.update,
        )
        self.list = async_to_raw_response_wrapper(
            rf_band.list,
        )
        self.delete = async_to_raw_response_wrapper(
            rf_band.delete,
        )
        self.count = async_to_raw_response_wrapper(
            rf_band.count,
        )
        self.get = async_to_raw_response_wrapper(
            rf_band.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            rf_band.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            rf_band.tuple,
        )


class RfBandResourceWithStreamingResponse:
    def __init__(self, rf_band: RfBandResource) -> None:
        self._rf_band = rf_band

        self.create = to_streamed_response_wrapper(
            rf_band.create,
        )
        self.update = to_streamed_response_wrapper(
            rf_band.update,
        )
        self.list = to_streamed_response_wrapper(
            rf_band.list,
        )
        self.delete = to_streamed_response_wrapper(
            rf_band.delete,
        )
        self.count = to_streamed_response_wrapper(
            rf_band.count,
        )
        self.get = to_streamed_response_wrapper(
            rf_band.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            rf_band.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            rf_band.tuple,
        )


class AsyncRfBandResourceWithStreamingResponse:
    def __init__(self, rf_band: AsyncRfBandResource) -> None:
        self._rf_band = rf_band

        self.create = async_to_streamed_response_wrapper(
            rf_band.create,
        )
        self.update = async_to_streamed_response_wrapper(
            rf_band.update,
        )
        self.list = async_to_streamed_response_wrapper(
            rf_band.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            rf_band.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            rf_band.count,
        )
        self.get = async_to_streamed_response_wrapper(
            rf_band.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            rf_band.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            rf_band.tuple,
        )
