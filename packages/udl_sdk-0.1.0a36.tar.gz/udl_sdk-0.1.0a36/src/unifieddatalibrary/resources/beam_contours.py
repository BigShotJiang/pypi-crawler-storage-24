# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal

import httpx

from ..types import (
    beam_contour_list_params,
    beam_contour_count_params,
    beam_contour_tuple_params,
    beam_contour_create_params,
    beam_contour_update_params,
    beam_contour_retrieve_params,
    beam_contour_create_bulk_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.beamcontour_abridged import BeamcontourAbridged
from ..types.shared.beamcontour_full import BeamcontourFull
from ..types.beam_contour_tuple_response import BeamContourTupleResponse
from ..types.beam_contour_query_help_response import BeamContourQueryHelpResponse

__all__ = ["BeamContoursResource", "AsyncBeamContoursResource"]


class BeamContoursResource(SyncAPIResource):
    """
    This collection of services provides operations for querying and manipulation of satellite antenna beams, and querying of beam contours and service areas.   Beam contours are the geographic representation of the relative gain levels of beam power off of the maximum gain boresight points.  Similarly, service areas are the geographic footprints of the areas served by a particular beam, and may be made up of multiple service regions.  Well-Known Text (WKT) and GeoJSON formats are used for GIS representation and query support (see https://www.opengeospatial.org/standards/wkt-crs and https://geojson.org/ for more information on these formats).
    """

    @cached_property
    def with_raw_response(self) -> BeamContoursResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return BeamContoursResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BeamContoursResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return BeamContoursResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_beam: str,
        source: str,
        type: Literal["BORESIGHT", "CONTOUR", "SVC AREA"],
        id: str | Omit = omit,
        contour_idx: int | Omit = omit,
        gain: float | Omit = omit,
        geography: str | Omit = omit,
        geography_json: str | Omit = omit,
        geography_ndims: int | Omit = omit,
        geography_srid: int | Omit = omit,
        geography_text: str | Omit = omit,
        geography_type: str | Omit = omit,
        origin: str | Omit = omit,
        region_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single BeamContour as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_beam: ID of the beam.

          source: Source of the data.

          type: The type of object represented in this record (BORESIGHT, CONTOUR, SVC AREA).
              Boresight refers to the point of maximum/peak gain, and should not be confused
              with the 'aim point' of the related beam. Gain contours are regions of coverage
              referenced to the relative gain of the related beam. Service Areas are composed
              of one or more service regions, with each region being either discrete point(s)
              or a continuous contour.

          id: Unique identifier of the record, auto-generated by the system.

          contour_idx: The index number of this contour. The value is required if type = CONTOUR.

          gain: The relative gain level in dB associated with this boresight or contour. Gain
              does not apply to service area records. The value is required if type =
              BORESIGHT or CONTOUR.

          geography: GeoJSON or Well Known Text expression of the boresight point, service area point
              or region, or the gain contour region in geographic longitude, latitude pairs.
              Boresight and service area point(s) are represented as a 'Point' or
              'MultiPoint', service areas and closed gain contours as 'Polygon', and open
              contours as 'LineString'. This is an optional convenience field only used for
              create operations. The system will auto-detect the format (Well Known Text or
              GeoJSON) and populate both geographyText and geographyJson fields appropriately.
              A create request must contain one of the geography, geographyText, or
              geographyJson.

          geography_json: Geographical region or polygon (lat/lon pairs), as depicted by the GeoJSON
              representation of the geometry/geography, of the image as projected on the
              ground. GeoJSON Reference: https://geojson.org/. Ignored if included with a POST
              or PUT request that also specifies a valid 'area' or 'atext' field.

          geography_ndims: Number of dimensions of the geometry depicted by region.

          geography_srid: Geographical spatial_ref_sys for region.

          geography_text: Geographical region or polygon (lon/lat pairs), as depicted by the Well-Known
              Text representation of the geometry/geography, of the image as projected on the
              ground. WKT reference: https://www.opengeospatial.org/standards/wkt-crs. Ignored
              if included with a POST or PUT request that also specifies a valid 'area' field.

          geography_type: Type of region as projected.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          region_name: The region name within the service area.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/beamcontour",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_beam": id_beam,
                    "source": source,
                    "type": type,
                    "id": id,
                    "contour_idx": contour_idx,
                    "gain": gain,
                    "geography": geography,
                    "geography_json": geography_json,
                    "geography_ndims": geography_ndims,
                    "geography_srid": geography_srid,
                    "geography_text": geography_text,
                    "geography_type": geography_type,
                    "origin": origin,
                    "region_name": region_name,
                },
                beam_contour_create_params.BeamContourCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamcontourFull:
        """
        Service operation to get a single BeamContour by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/beamcontour/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_retrieve_params.BeamContourRetrieveParams,
                ),
            ),
            cast_to=BeamcontourFull,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_beam: str,
        source: str,
        type: Literal["BORESIGHT", "CONTOUR", "SVC AREA"],
        body_id: str | Omit = omit,
        contour_idx: int | Omit = omit,
        gain: float | Omit = omit,
        geography: str | Omit = omit,
        geography_json: str | Omit = omit,
        geography_ndims: int | Omit = omit,
        geography_srid: int | Omit = omit,
        geography_text: str | Omit = omit,
        geography_type: str | Omit = omit,
        origin: str | Omit = omit,
        region_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single BeamContour.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_beam: ID of the beam.

          source: Source of the data.

          type: The type of object represented in this record (BORESIGHT, CONTOUR, SVC AREA).
              Boresight refers to the point of maximum/peak gain, and should not be confused
              with the 'aim point' of the related beam. Gain contours are regions of coverage
              referenced to the relative gain of the related beam. Service Areas are composed
              of one or more service regions, with each region being either discrete point(s)
              or a continuous contour.

          body_id: Unique identifier of the record, auto-generated by the system.

          contour_idx: The index number of this contour. The value is required if type = CONTOUR.

          gain: The relative gain level in dB associated with this boresight or contour. Gain
              does not apply to service area records. The value is required if type =
              BORESIGHT or CONTOUR.

          geography: GeoJSON or Well Known Text expression of the boresight point, service area point
              or region, or the gain contour region in geographic longitude, latitude pairs.
              Boresight and service area point(s) are represented as a 'Point' or
              'MultiPoint', service areas and closed gain contours as 'Polygon', and open
              contours as 'LineString'. This is an optional convenience field only used for
              create operations. The system will auto-detect the format (Well Known Text or
              GeoJSON) and populate both geographyText and geographyJson fields appropriately.
              A create request must contain one of the geography, geographyText, or
              geographyJson.

          geography_json: Geographical region or polygon (lat/lon pairs), as depicted by the GeoJSON
              representation of the geometry/geography, of the image as projected on the
              ground. GeoJSON Reference: https://geojson.org/. Ignored if included with a POST
              or PUT request that also specifies a valid 'area' or 'atext' field.

          geography_ndims: Number of dimensions of the geometry depicted by region.

          geography_srid: Geographical spatial_ref_sys for region.

          geography_text: Geographical region or polygon (lon/lat pairs), as depicted by the Well-Known
              Text representation of the geometry/geography, of the image as projected on the
              ground. WKT reference: https://www.opengeospatial.org/standards/wkt-crs. Ignored
              if included with a POST or PUT request that also specifies a valid 'area' field.

          geography_type: Type of region as projected.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          region_name: The region name within the service area.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/beamcontour/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_beam": id_beam,
                    "source": source,
                    "type": type,
                    "body_id": body_id,
                    "contour_idx": contour_idx,
                    "gain": gain,
                    "geography": geography,
                    "geography_json": geography_json,
                    "geography_ndims": geography_ndims,
                    "geography_srid": geography_srid,
                    "geography_text": geography_text,
                    "geography_type": geography_type,
                    "origin": origin,
                    "region_name": region_name,
                },
                beam_contour_update_params.BeamContourUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[BeamcontourAbridged]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/beamcontour",
            page=SyncOffsetPage[BeamcontourAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_list_params.BeamContourListParams,
                ),
            ),
            model=BeamcontourAbridged,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a BeamContour object specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/beamcontour/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/beamcontour/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_count_params.BeamContourCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[beam_contour_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a list of BeamContours as a POST body and ingest into
        the database. This operation is not intended to be used for automated feeds into
        UDL. Data providers should contact the UDL team for specific role assignments
        and for instructions on setting up a permanent feed through an alternate
        mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/beamcontour/createBulk",
            body=maybe_transform(body, Iterable[beam_contour_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamContourQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/beamcontour/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BeamContourQueryHelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamContourTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/beamcontour/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_tuple_params.BeamContourTupleParams,
                ),
            ),
            cast_to=BeamContourTupleResponse,
        )


class AsyncBeamContoursResource(AsyncAPIResource):
    """
    This collection of services provides operations for querying and manipulation of satellite antenna beams, and querying of beam contours and service areas.   Beam contours are the geographic representation of the relative gain levels of beam power off of the maximum gain boresight points.  Similarly, service areas are the geographic footprints of the areas served by a particular beam, and may be made up of multiple service regions.  Well-Known Text (WKT) and GeoJSON formats are used for GIS representation and query support (see https://www.opengeospatial.org/standards/wkt-crs and https://geojson.org/ for more information on these formats).
    """

    @cached_property
    def with_raw_response(self) -> AsyncBeamContoursResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncBeamContoursResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBeamContoursResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncBeamContoursResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_beam: str,
        source: str,
        type: Literal["BORESIGHT", "CONTOUR", "SVC AREA"],
        id: str | Omit = omit,
        contour_idx: int | Omit = omit,
        gain: float | Omit = omit,
        geography: str | Omit = omit,
        geography_json: str | Omit = omit,
        geography_ndims: int | Omit = omit,
        geography_srid: int | Omit = omit,
        geography_text: str | Omit = omit,
        geography_type: str | Omit = omit,
        origin: str | Omit = omit,
        region_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single BeamContour as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_beam: ID of the beam.

          source: Source of the data.

          type: The type of object represented in this record (BORESIGHT, CONTOUR, SVC AREA).
              Boresight refers to the point of maximum/peak gain, and should not be confused
              with the 'aim point' of the related beam. Gain contours are regions of coverage
              referenced to the relative gain of the related beam. Service Areas are composed
              of one or more service regions, with each region being either discrete point(s)
              or a continuous contour.

          id: Unique identifier of the record, auto-generated by the system.

          contour_idx: The index number of this contour. The value is required if type = CONTOUR.

          gain: The relative gain level in dB associated with this boresight or contour. Gain
              does not apply to service area records. The value is required if type =
              BORESIGHT or CONTOUR.

          geography: GeoJSON or Well Known Text expression of the boresight point, service area point
              or region, or the gain contour region in geographic longitude, latitude pairs.
              Boresight and service area point(s) are represented as a 'Point' or
              'MultiPoint', service areas and closed gain contours as 'Polygon', and open
              contours as 'LineString'. This is an optional convenience field only used for
              create operations. The system will auto-detect the format (Well Known Text or
              GeoJSON) and populate both geographyText and geographyJson fields appropriately.
              A create request must contain one of the geography, geographyText, or
              geographyJson.

          geography_json: Geographical region or polygon (lat/lon pairs), as depicted by the GeoJSON
              representation of the geometry/geography, of the image as projected on the
              ground. GeoJSON Reference: https://geojson.org/. Ignored if included with a POST
              or PUT request that also specifies a valid 'area' or 'atext' field.

          geography_ndims: Number of dimensions of the geometry depicted by region.

          geography_srid: Geographical spatial_ref_sys for region.

          geography_text: Geographical region or polygon (lon/lat pairs), as depicted by the Well-Known
              Text representation of the geometry/geography, of the image as projected on the
              ground. WKT reference: https://www.opengeospatial.org/standards/wkt-crs. Ignored
              if included with a POST or PUT request that also specifies a valid 'area' field.

          geography_type: Type of region as projected.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          region_name: The region name within the service area.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/beamcontour",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_beam": id_beam,
                    "source": source,
                    "type": type,
                    "id": id,
                    "contour_idx": contour_idx,
                    "gain": gain,
                    "geography": geography,
                    "geography_json": geography_json,
                    "geography_ndims": geography_ndims,
                    "geography_srid": geography_srid,
                    "geography_text": geography_text,
                    "geography_type": geography_type,
                    "origin": origin,
                    "region_name": region_name,
                },
                beam_contour_create_params.BeamContourCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamcontourFull:
        """
        Service operation to get a single BeamContour by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/beamcontour/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_retrieve_params.BeamContourRetrieveParams,
                ),
            ),
            cast_to=BeamcontourFull,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_beam: str,
        source: str,
        type: Literal["BORESIGHT", "CONTOUR", "SVC AREA"],
        body_id: str | Omit = omit,
        contour_idx: int | Omit = omit,
        gain: float | Omit = omit,
        geography: str | Omit = omit,
        geography_json: str | Omit = omit,
        geography_ndims: int | Omit = omit,
        geography_srid: int | Omit = omit,
        geography_text: str | Omit = omit,
        geography_type: str | Omit = omit,
        origin: str | Omit = omit,
        region_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single BeamContour.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_beam: ID of the beam.

          source: Source of the data.

          type: The type of object represented in this record (BORESIGHT, CONTOUR, SVC AREA).
              Boresight refers to the point of maximum/peak gain, and should not be confused
              with the 'aim point' of the related beam. Gain contours are regions of coverage
              referenced to the relative gain of the related beam. Service Areas are composed
              of one or more service regions, with each region being either discrete point(s)
              or a continuous contour.

          body_id: Unique identifier of the record, auto-generated by the system.

          contour_idx: The index number of this contour. The value is required if type = CONTOUR.

          gain: The relative gain level in dB associated with this boresight or contour. Gain
              does not apply to service area records. The value is required if type =
              BORESIGHT or CONTOUR.

          geography: GeoJSON or Well Known Text expression of the boresight point, service area point
              or region, or the gain contour region in geographic longitude, latitude pairs.
              Boresight and service area point(s) are represented as a 'Point' or
              'MultiPoint', service areas and closed gain contours as 'Polygon', and open
              contours as 'LineString'. This is an optional convenience field only used for
              create operations. The system will auto-detect the format (Well Known Text or
              GeoJSON) and populate both geographyText and geographyJson fields appropriately.
              A create request must contain one of the geography, geographyText, or
              geographyJson.

          geography_json: Geographical region or polygon (lat/lon pairs), as depicted by the GeoJSON
              representation of the geometry/geography, of the image as projected on the
              ground. GeoJSON Reference: https://geojson.org/. Ignored if included with a POST
              or PUT request that also specifies a valid 'area' or 'atext' field.

          geography_ndims: Number of dimensions of the geometry depicted by region.

          geography_srid: Geographical spatial_ref_sys for region.

          geography_text: Geographical region or polygon (lon/lat pairs), as depicted by the Well-Known
              Text representation of the geometry/geography, of the image as projected on the
              ground. WKT reference: https://www.opengeospatial.org/standards/wkt-crs. Ignored
              if included with a POST or PUT request that also specifies a valid 'area' field.

          geography_type: Type of region as projected.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          region_name: The region name within the service area.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/beamcontour/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_beam": id_beam,
                    "source": source,
                    "type": type,
                    "body_id": body_id,
                    "contour_idx": contour_idx,
                    "gain": gain,
                    "geography": geography,
                    "geography_json": geography_json,
                    "geography_ndims": geography_ndims,
                    "geography_srid": geography_srid,
                    "geography_text": geography_text,
                    "geography_type": geography_type,
                    "origin": origin,
                    "region_name": region_name,
                },
                beam_contour_update_params.BeamContourUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[BeamcontourAbridged, AsyncOffsetPage[BeamcontourAbridged]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/beamcontour",
            page=AsyncOffsetPage[BeamcontourAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_list_params.BeamContourListParams,
                ),
            ),
            model=BeamcontourAbridged,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a BeamContour object specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/beamcontour/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/beamcontour/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_count_params.BeamContourCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[beam_contour_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a list of BeamContours as a POST body and ingest into
        the database. This operation is not intended to be used for automated feeds into
        UDL. Data providers should contact the UDL team for specific role assignments
        and for instructions on setting up a permanent feed through an alternate
        mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/beamcontour/createBulk",
            body=await async_maybe_transform(body, Iterable[beam_contour_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamContourQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/beamcontour/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BeamContourQueryHelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        id_beam: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BeamContourTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_beam: ID of the beam.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/beamcontour/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "id_beam": id_beam,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    beam_contour_tuple_params.BeamContourTupleParams,
                ),
            ),
            cast_to=BeamContourTupleResponse,
        )


class BeamContoursResourceWithRawResponse:
    def __init__(self, beam_contours: BeamContoursResource) -> None:
        self._beam_contours = beam_contours

        self.create = to_raw_response_wrapper(
            beam_contours.create,
        )
        self.retrieve = to_raw_response_wrapper(
            beam_contours.retrieve,
        )
        self.update = to_raw_response_wrapper(
            beam_contours.update,
        )
        self.list = to_raw_response_wrapper(
            beam_contours.list,
        )
        self.delete = to_raw_response_wrapper(
            beam_contours.delete,
        )
        self.count = to_raw_response_wrapper(
            beam_contours.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            beam_contours.create_bulk,
        )
        self.query_help = to_raw_response_wrapper(
            beam_contours.query_help,
        )
        self.tuple = to_raw_response_wrapper(
            beam_contours.tuple,
        )


class AsyncBeamContoursResourceWithRawResponse:
    def __init__(self, beam_contours: AsyncBeamContoursResource) -> None:
        self._beam_contours = beam_contours

        self.create = async_to_raw_response_wrapper(
            beam_contours.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            beam_contours.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            beam_contours.update,
        )
        self.list = async_to_raw_response_wrapper(
            beam_contours.list,
        )
        self.delete = async_to_raw_response_wrapper(
            beam_contours.delete,
        )
        self.count = async_to_raw_response_wrapper(
            beam_contours.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            beam_contours.create_bulk,
        )
        self.query_help = async_to_raw_response_wrapper(
            beam_contours.query_help,
        )
        self.tuple = async_to_raw_response_wrapper(
            beam_contours.tuple,
        )


class BeamContoursResourceWithStreamingResponse:
    def __init__(self, beam_contours: BeamContoursResource) -> None:
        self._beam_contours = beam_contours

        self.create = to_streamed_response_wrapper(
            beam_contours.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            beam_contours.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            beam_contours.update,
        )
        self.list = to_streamed_response_wrapper(
            beam_contours.list,
        )
        self.delete = to_streamed_response_wrapper(
            beam_contours.delete,
        )
        self.count = to_streamed_response_wrapper(
            beam_contours.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            beam_contours.create_bulk,
        )
        self.query_help = to_streamed_response_wrapper(
            beam_contours.query_help,
        )
        self.tuple = to_streamed_response_wrapper(
            beam_contours.tuple,
        )


class AsyncBeamContoursResourceWithStreamingResponse:
    def __init__(self, beam_contours: AsyncBeamContoursResource) -> None:
        self._beam_contours = beam_contours

        self.create = async_to_streamed_response_wrapper(
            beam_contours.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            beam_contours.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            beam_contours.update,
        )
        self.list = async_to_streamed_response_wrapper(
            beam_contours.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            beam_contours.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            beam_contours.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            beam_contours.create_bulk,
        )
        self.query_help = async_to_streamed_response_wrapper(
            beam_contours.query_help,
        )
        self.tuple = async_to_streamed_response_wrapper(
            beam_contours.tuple,
        )
