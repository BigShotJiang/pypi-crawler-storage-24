# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date
from typing_extensions import Literal

import httpx

from ...types import (
    notification_get_params,
    notification_list_params,
    notification_count_params,
    notification_tuple_params,
    notification_create_params,
    notification_create_raw_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.shared.notification_full import NotificationFull
from ...types.notification_list_response import NotificationListResponse
from ...types.notification_tuple_response import NotificationTupleResponse
from ...types.notification_queryhelp_response import NotificationQueryhelpResponse

__all__ = ["NotificationResource", "AsyncNotificationResource"]


class NotificationResource(SyncAPIResource):
    """
    A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
    """

    @cached_property
    def history(self) -> HistoryResource:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> NotificationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return NotificationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> NotificationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return NotificationResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        msg_body: str,
        msg_type: str,
        source: str,
        id: str | Omit = omit,
        origin: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to push a generic Notification/Alert JSON message into the
        UDL.

        This operation accepts a UDL-formatted Notification JSON notification/alert
        message. See the Notification schema for required fields such as
        classificationMarking, msgType, etc. Messages pushed through this service may be
        pulled via Secure Messaging and historical REST services. A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          msg_body: The message body content as a text string, XML, JSON, etc. If JSON is used for
              the msgBody, it should be 'inline' with the notification message JSON (without
              quotation marks or escape characters). Size of the msg body cannot be over 1MB.

          msg_type: Source provided message type.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          tags: Optional array of provider/source specific tags for this data, used for
              implementing data owner conditional access controls to restrict access to the
              data.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/notification",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "msg_body": msg_body,
                    "msg_type": msg_type,
                    "source": source,
                    "id": id,
                    "origin": origin,
                    "tags": tags,
                },
                notification_create_params.NotificationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[NotificationListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/notification",
            page=SyncOffsetPage[NotificationListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_list_params.NotificationListParams,
                ),
            ),
            model=NotificationListResponse,
        )

    def count(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/notification/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_count_params.NotificationCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_raw(
        self,
        *,
        classification_marking: str,
        data_mode: str,
        msg_type: str,
        origin: str,
        source: str,
        body: str,
        msg_id: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to push a Notification/Alert message into the UDL.

        This
        operation uses query parameters to pass UDL-required fields such as
        classificationMarking, msgType, etc and takes a raw string payload which can be
        XML, JSON, or plain text. The preferred mechanism for posting notifications is
        to use the standard POST which takes the proper UDL JSON Notification schema as
        this service may convert the message in an undesirable manner. The service will
        wrap the passed payload with the appropriate UDL JSON schema, using escape
        characters as necessary for the payload to produce a valid JSON document. XML
        payloads (not recommended) are automatically converted to JSON. Messages pushed
        through this service may be pulled via Secure Messaging and historical REST
        services. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is EXERCISE, REAL, SIMULATED, or TEST data:

              EXERCISE: Data pertaining to a government or military exercise. The data may
              include both real and simulated data.

              REAL: Data collected or produced that pertains to real-world objects, events,
              and analysis.

              SIMULATED: Synthetic data generated by a model to mimic real-world datasets.

              TEST: Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

          msg_type: Source provided message type.

          origin: Origin of the data.

          source: Source of the data.

          msg_id: Optional message identifier...if not provided an id will be automatically
              created.

          tags: Optional list of provider/source specific tags for this data.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/notification/createRaw",
            body=maybe_transform(body, notification_create_raw_params.NotificationCreateRawParams),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "classification_marking": classification_marking,
                        "data_mode": data_mode,
                        "msg_type": msg_type,
                        "origin": origin,
                        "source": source,
                        "msg_id": msg_id,
                        "tags": tags,
                    },
                    notification_create_raw_params.NotificationCreateRawParams,
                ),
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationFull:
        """
        Service operation to get a single notification by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/notification/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_get_params.NotificationGetParams,
                ),
            ),
            cast_to=NotificationFull,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/notification/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/notification/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_tuple_params.NotificationTupleParams,
                ),
            ),
            cast_to=NotificationTupleResponse,
        )


class AsyncNotificationResource(AsyncAPIResource):
    """
    A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
    """

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncNotificationResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncNotificationResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncNotificationResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncNotificationResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        msg_body: str,
        msg_type: str,
        source: str,
        id: str | Omit = omit,
        origin: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to push a generic Notification/Alert JSON message into the
        UDL.

        This operation accepts a UDL-formatted Notification JSON notification/alert
        message. See the Notification schema for required fields such as
        classificationMarking, msgType, etc. Messages pushed through this service may be
        pulled via Secure Messaging and historical REST services. A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          msg_body: The message body content as a text string, XML, JSON, etc. If JSON is used for
              the msgBody, it should be 'inline' with the notification message JSON (without
              quotation marks or escape characters). Size of the msg body cannot be over 1MB.

          msg_type: Source provided message type.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          tags: Optional array of provider/source specific tags for this data, used for
              implementing data owner conditional access controls to restrict access to the
              data.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/notification",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "msg_body": msg_body,
                    "msg_type": msg_type,
                    "source": source,
                    "id": id,
                    "origin": origin,
                    "tags": tags,
                },
                notification_create_params.NotificationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[NotificationListResponse, AsyncOffsetPage[NotificationListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/notification",
            page=AsyncOffsetPage[NotificationListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_list_params.NotificationListParams,
                ),
            ),
            model=NotificationListResponse,
        )

    async def count(
        self,
        *,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/notification/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_count_params.NotificationCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_raw(
        self,
        *,
        classification_marking: str,
        data_mode: str,
        msg_type: str,
        origin: str,
        source: str,
        body: str,
        msg_id: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to push a Notification/Alert message into the UDL.

        This
        operation uses query parameters to pass UDL-required fields such as
        classificationMarking, msgType, etc and takes a raw string payload which can be
        XML, JSON, or plain text. The preferred mechanism for posting notifications is
        to use the standard POST which takes the proper UDL JSON Notification schema as
        this service may convert the message in an undesirable manner. The service will
        wrap the passed payload with the appropriate UDL JSON schema, using escape
        characters as necessary for the payload to produce a valid JSON document. XML
        payloads (not recommended) are automatically converted to JSON. Messages pushed
        through this service may be pulled via Secure Messaging and historical REST
        services. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is EXERCISE, REAL, SIMULATED, or TEST data:

              EXERCISE: Data pertaining to a government or military exercise. The data may
              include both real and simulated data.

              REAL: Data collected or produced that pertains to real-world objects, events,
              and analysis.

              SIMULATED: Synthetic data generated by a model to mimic real-world datasets.

              TEST: Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

          msg_type: Source provided message type.

          origin: Origin of the data.

          source: Source of the data.

          msg_id: Optional message identifier...if not provided an id will be automatically
              created.

          tags: Optional list of provider/source specific tags for this data.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/notification/createRaw",
            body=await async_maybe_transform(body, notification_create_raw_params.NotificationCreateRawParams),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "classification_marking": classification_marking,
                        "data_mode": data_mode,
                        "msg_type": msg_type,
                        "origin": origin,
                        "source": source,
                        "msg_id": msg_id,
                        "tags": tags,
                    },
                    notification_create_raw_params.NotificationCreateRawParams,
                ),
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationFull:
        """
        Service operation to get a single notification by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/notification/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_get_params.NotificationGetParams,
                ),
            ),
            cast_to=NotificationFull,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/notification/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NotificationQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        created_at: Union[str, date],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NotificationTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          created_at: Time the row was created in the database. (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/notification/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "created_at": created_at,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    notification_tuple_params.NotificationTupleParams,
                ),
            ),
            cast_to=NotificationTupleResponse,
        )


class NotificationResourceWithRawResponse:
    def __init__(self, notification: NotificationResource) -> None:
        self._notification = notification

        self.create = to_raw_response_wrapper(
            notification.create,
        )
        self.list = to_raw_response_wrapper(
            notification.list,
        )
        self.count = to_raw_response_wrapper(
            notification.count,
        )
        self.create_raw = to_raw_response_wrapper(
            notification.create_raw,
        )
        self.get = to_raw_response_wrapper(
            notification.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            notification.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            notification.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return HistoryResourceWithRawResponse(self._notification.history)


class AsyncNotificationResourceWithRawResponse:
    def __init__(self, notification: AsyncNotificationResource) -> None:
        self._notification = notification

        self.create = async_to_raw_response_wrapper(
            notification.create,
        )
        self.list = async_to_raw_response_wrapper(
            notification.list,
        )
        self.count = async_to_raw_response_wrapper(
            notification.count,
        )
        self.create_raw = async_to_raw_response_wrapper(
            notification.create_raw,
        )
        self.get = async_to_raw_response_wrapper(
            notification.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            notification.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            notification.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return AsyncHistoryResourceWithRawResponse(self._notification.history)


class NotificationResourceWithStreamingResponse:
    def __init__(self, notification: NotificationResource) -> None:
        self._notification = notification

        self.create = to_streamed_response_wrapper(
            notification.create,
        )
        self.list = to_streamed_response_wrapper(
            notification.list,
        )
        self.count = to_streamed_response_wrapper(
            notification.count,
        )
        self.create_raw = to_streamed_response_wrapper(
            notification.create_raw,
        )
        self.get = to_streamed_response_wrapper(
            notification.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            notification.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            notification.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return HistoryResourceWithStreamingResponse(self._notification.history)


class AsyncNotificationResourceWithStreamingResponse:
    def __init__(self, notification: AsyncNotificationResource) -> None:
        self._notification = notification

        self.create = async_to_streamed_response_wrapper(
            notification.create,
        )
        self.list = async_to_streamed_response_wrapper(
            notification.list,
        )
        self.count = async_to_streamed_response_wrapper(
            notification.count,
        )
        self.create_raw = async_to_streamed_response_wrapper(
            notification.create_raw,
        )
        self.get = async_to_streamed_response_wrapper(
            notification.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            notification.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            notification.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """
        A Notification Service allowing the broadcast of generic messages to the community. Users can send free-form messages, publish lists, and notify the community about events or alerts across various domains. Notifications and alerts are categorized by a 'msgType' field and are accessible via the UDL Secure Messaging API and REST API services.
        """
        return AsyncHistoryResourceWithStreamingResponse(self._notification.history)
