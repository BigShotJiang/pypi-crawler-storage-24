# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ...types.site import (
    operation_list_params,
    operation_count_params,
    operation_tuple_params,
    operation_create_params,
    operation_update_params,
    operation_retrieve_params,
    operation_create_bulk_params,
    operation_unvalidated_publish_params,
)
from ..._base_client import AsyncPaginator, make_request_options
from ...types.site.operation_list_response import OperationListResponse
from ...types.site.operation_tuple_response import OperationTupleResponse
from ...types.site.operation_retrieve_response import OperationRetrieveResponse
from ...types.site.operation_query_help_response import OperationQueryHelpResponse

__all__ = ["OperationsResource", "AsyncOperationsResource"]


class OperationsResource(SyncAPIResource):
    """
    This collection of services provide operations for manipulating and querying of various site related data, including site status, site operations, and site type-specific records.
    """

    @cached_property
    def with_raw_response(self) -> OperationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return OperationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OperationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return OperationsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_site: str,
        source: str,
        id: str | Omit = omit,
        daily_operations: Iterable[operation_create_params.DailyOperation] | Omit = omit,
        dops_last_changed_by: str | Omit = omit,
        dops_last_changed_date: Union[str, datetime] | Omit = omit,
        dops_last_changed_reason: str | Omit = omit,
        id_launch_site: str | Omit = omit,
        maximum_on_grounds: Iterable[operation_create_params.MaximumOnGround] | Omit = omit,
        mogs_last_changed_by: str | Omit = omit,
        mogs_last_changed_date: Union[str, datetime] | Omit = omit,
        mogs_last_changed_reason: str | Omit = omit,
        operational_deviations: Iterable[operation_create_params.OperationalDeviation] | Omit = omit,
        operational_plannings: Iterable[operation_create_params.OperationalPlanning] | Omit = omit,
        origin: str | Omit = omit,
        pathways: Iterable[operation_create_params.Pathway] | Omit = omit,
        waivers: Iterable[operation_create_params.Waiver] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single siteoperations object as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_site: The ID of the parent site.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          daily_operations: Collection providing hours of operation and other information specific to a day
              of the week.

          dops_last_changed_by: The name of the person who made the most recent change to data in the
              DailyOperations collection.

          dops_last_changed_date: The datetime of the most recent change made to data in the DailyOperations
              collection, in ISO 8601 UTC format with millisecond precision.

          dops_last_changed_reason: The reason for the most recent change to data in the dailyOperations collection.

          id_launch_site: Id of the associated launchSite entity.

          maximum_on_grounds: Collection providing maximum on ground (MOG) information for specific aircraft
              at the site associated with this SiteOperations record.

          mogs_last_changed_by: The name of the person who made the most recent change to data in the
              MaximumOnGrounds collection.

          mogs_last_changed_date: The datetime of the most recent change made to data in the MaximumOnGrounds
              collection, in ISO 8601 UTC format with millisecond precision.

          mogs_last_changed_reason: The reason for the most recent change to data in the MaximumOnGrounds
              collection.

          operational_deviations: Collection providing relevant information in the event of deviations/exceptions
              to normal operations.

          operational_plannings: Collection of planning information associated with this SiteOperations record.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pathways: Collection detailing operational pathways at the Site associated with this
              SiteOperations record.

          waivers: Collection documenting operational waivers that have been issued for the Site
              associated with this record.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/siteoperations",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_site": id_site,
                    "source": source,
                    "id": id,
                    "daily_operations": daily_operations,
                    "dops_last_changed_by": dops_last_changed_by,
                    "dops_last_changed_date": dops_last_changed_date,
                    "dops_last_changed_reason": dops_last_changed_reason,
                    "id_launch_site": id_launch_site,
                    "maximum_on_grounds": maximum_on_grounds,
                    "mogs_last_changed_by": mogs_last_changed_by,
                    "mogs_last_changed_date": mogs_last_changed_date,
                    "mogs_last_changed_reason": mogs_last_changed_reason,
                    "operational_deviations": operational_deviations,
                    "operational_plannings": operational_plannings,
                    "origin": origin,
                    "pathways": pathways,
                    "waivers": waivers,
                },
                operation_create_params.OperationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationRetrieveResponse:
        """
        Service operation to get a single siteoperations record by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/siteoperations/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_retrieve_params.OperationRetrieveParams,
                ),
            ),
            cast_to=OperationRetrieveResponse,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_site: str,
        source: str,
        body_id: str | Omit = omit,
        daily_operations: Iterable[operation_update_params.DailyOperation] | Omit = omit,
        dops_last_changed_by: str | Omit = omit,
        dops_last_changed_date: Union[str, datetime] | Omit = omit,
        dops_last_changed_reason: str | Omit = omit,
        id_launch_site: str | Omit = omit,
        maximum_on_grounds: Iterable[operation_update_params.MaximumOnGround] | Omit = omit,
        mogs_last_changed_by: str | Omit = omit,
        mogs_last_changed_date: Union[str, datetime] | Omit = omit,
        mogs_last_changed_reason: str | Omit = omit,
        operational_deviations: Iterable[operation_update_params.OperationalDeviation] | Omit = omit,
        operational_plannings: Iterable[operation_update_params.OperationalPlanning] | Omit = omit,
        origin: str | Omit = omit,
        pathways: Iterable[operation_update_params.Pathway] | Omit = omit,
        waivers: Iterable[operation_update_params.Waiver] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single siteoperations record.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_site: The ID of the parent site.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          daily_operations: Collection providing hours of operation and other information specific to a day
              of the week.

          dops_last_changed_by: The name of the person who made the most recent change to data in the
              DailyOperations collection.

          dops_last_changed_date: The datetime of the most recent change made to data in the DailyOperations
              collection, in ISO 8601 UTC format with millisecond precision.

          dops_last_changed_reason: The reason for the most recent change to data in the dailyOperations collection.

          id_launch_site: Id of the associated launchSite entity.

          maximum_on_grounds: Collection providing maximum on ground (MOG) information for specific aircraft
              at the site associated with this SiteOperations record.

          mogs_last_changed_by: The name of the person who made the most recent change to data in the
              MaximumOnGrounds collection.

          mogs_last_changed_date: The datetime of the most recent change made to data in the MaximumOnGrounds
              collection, in ISO 8601 UTC format with millisecond precision.

          mogs_last_changed_reason: The reason for the most recent change to data in the MaximumOnGrounds
              collection.

          operational_deviations: Collection providing relevant information in the event of deviations/exceptions
              to normal operations.

          operational_plannings: Collection of planning information associated with this SiteOperations record.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pathways: Collection detailing operational pathways at the Site associated with this
              SiteOperations record.

          waivers: Collection documenting operational waivers that have been issued for the Site
              associated with this record.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/siteoperations/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_site": id_site,
                    "source": source,
                    "body_id": body_id,
                    "daily_operations": daily_operations,
                    "dops_last_changed_by": dops_last_changed_by,
                    "dops_last_changed_date": dops_last_changed_date,
                    "dops_last_changed_reason": dops_last_changed_reason,
                    "id_launch_site": id_launch_site,
                    "maximum_on_grounds": maximum_on_grounds,
                    "mogs_last_changed_by": mogs_last_changed_by,
                    "mogs_last_changed_date": mogs_last_changed_date,
                    "mogs_last_changed_reason": mogs_last_changed_reason,
                    "operational_deviations": operational_deviations,
                    "operational_plannings": operational_plannings,
                    "origin": origin,
                    "pathways": pathways,
                    "waivers": waivers,
                },
                operation_update_params.OperationUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[OperationListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/siteoperations",
            page=SyncOffsetPage[OperationListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_list_params.OperationListParams,
                ),
            ),
            model=OperationListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a siteoperations record specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/siteoperations/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/siteoperations/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_count_params.OperationCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[operation_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        siteoperations records as a POST body and ingest into the database. This
        operation is not intended to be used for automated feeds into UDL. Data
        providers should contact the UDL team for specific role assignments and for
        instructions on setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/siteoperations/createBulk",
            body=maybe_transform(body, Iterable[operation_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/siteoperations/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OperationQueryHelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/siteoperations/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_tuple_params.OperationTupleParams,
                ),
            ),
            cast_to=OperationTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[operation_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple siteoperations records as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-siteoperations",
            body=maybe_transform(body, Iterable[operation_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncOperationsResource(AsyncAPIResource):
    """
    This collection of services provide operations for manipulating and querying of various site related data, including site status, site operations, and site type-specific records.
    """

    @cached_property
    def with_raw_response(self) -> AsyncOperationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncOperationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOperationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncOperationsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_site: str,
        source: str,
        id: str | Omit = omit,
        daily_operations: Iterable[operation_create_params.DailyOperation] | Omit = omit,
        dops_last_changed_by: str | Omit = omit,
        dops_last_changed_date: Union[str, datetime] | Omit = omit,
        dops_last_changed_reason: str | Omit = omit,
        id_launch_site: str | Omit = omit,
        maximum_on_grounds: Iterable[operation_create_params.MaximumOnGround] | Omit = omit,
        mogs_last_changed_by: str | Omit = omit,
        mogs_last_changed_date: Union[str, datetime] | Omit = omit,
        mogs_last_changed_reason: str | Omit = omit,
        operational_deviations: Iterable[operation_create_params.OperationalDeviation] | Omit = omit,
        operational_plannings: Iterable[operation_create_params.OperationalPlanning] | Omit = omit,
        origin: str | Omit = omit,
        pathways: Iterable[operation_create_params.Pathway] | Omit = omit,
        waivers: Iterable[operation_create_params.Waiver] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single siteoperations object as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_site: The ID of the parent site.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          daily_operations: Collection providing hours of operation and other information specific to a day
              of the week.

          dops_last_changed_by: The name of the person who made the most recent change to data in the
              DailyOperations collection.

          dops_last_changed_date: The datetime of the most recent change made to data in the DailyOperations
              collection, in ISO 8601 UTC format with millisecond precision.

          dops_last_changed_reason: The reason for the most recent change to data in the dailyOperations collection.

          id_launch_site: Id of the associated launchSite entity.

          maximum_on_grounds: Collection providing maximum on ground (MOG) information for specific aircraft
              at the site associated with this SiteOperations record.

          mogs_last_changed_by: The name of the person who made the most recent change to data in the
              MaximumOnGrounds collection.

          mogs_last_changed_date: The datetime of the most recent change made to data in the MaximumOnGrounds
              collection, in ISO 8601 UTC format with millisecond precision.

          mogs_last_changed_reason: The reason for the most recent change to data in the MaximumOnGrounds
              collection.

          operational_deviations: Collection providing relevant information in the event of deviations/exceptions
              to normal operations.

          operational_plannings: Collection of planning information associated with this SiteOperations record.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pathways: Collection detailing operational pathways at the Site associated with this
              SiteOperations record.

          waivers: Collection documenting operational waivers that have been issued for the Site
              associated with this record.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/siteoperations",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_site": id_site,
                    "source": source,
                    "id": id,
                    "daily_operations": daily_operations,
                    "dops_last_changed_by": dops_last_changed_by,
                    "dops_last_changed_date": dops_last_changed_date,
                    "dops_last_changed_reason": dops_last_changed_reason,
                    "id_launch_site": id_launch_site,
                    "maximum_on_grounds": maximum_on_grounds,
                    "mogs_last_changed_by": mogs_last_changed_by,
                    "mogs_last_changed_date": mogs_last_changed_date,
                    "mogs_last_changed_reason": mogs_last_changed_reason,
                    "operational_deviations": operational_deviations,
                    "operational_plannings": operational_plannings,
                    "origin": origin,
                    "pathways": pathways,
                    "waivers": waivers,
                },
                operation_create_params.OperationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationRetrieveResponse:
        """
        Service operation to get a single siteoperations record by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/siteoperations/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_retrieve_params.OperationRetrieveParams,
                ),
            ),
            cast_to=OperationRetrieveResponse,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_site: str,
        source: str,
        body_id: str | Omit = omit,
        daily_operations: Iterable[operation_update_params.DailyOperation] | Omit = omit,
        dops_last_changed_by: str | Omit = omit,
        dops_last_changed_date: Union[str, datetime] | Omit = omit,
        dops_last_changed_reason: str | Omit = omit,
        id_launch_site: str | Omit = omit,
        maximum_on_grounds: Iterable[operation_update_params.MaximumOnGround] | Omit = omit,
        mogs_last_changed_by: str | Omit = omit,
        mogs_last_changed_date: Union[str, datetime] | Omit = omit,
        mogs_last_changed_reason: str | Omit = omit,
        operational_deviations: Iterable[operation_update_params.OperationalDeviation] | Omit = omit,
        operational_plannings: Iterable[operation_update_params.OperationalPlanning] | Omit = omit,
        origin: str | Omit = omit,
        pathways: Iterable[operation_update_params.Pathway] | Omit = omit,
        waivers: Iterable[operation_update_params.Waiver] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single siteoperations record.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_site: The ID of the parent site.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          daily_operations: Collection providing hours of operation and other information specific to a day
              of the week.

          dops_last_changed_by: The name of the person who made the most recent change to data in the
              DailyOperations collection.

          dops_last_changed_date: The datetime of the most recent change made to data in the DailyOperations
              collection, in ISO 8601 UTC format with millisecond precision.

          dops_last_changed_reason: The reason for the most recent change to data in the dailyOperations collection.

          id_launch_site: Id of the associated launchSite entity.

          maximum_on_grounds: Collection providing maximum on ground (MOG) information for specific aircraft
              at the site associated with this SiteOperations record.

          mogs_last_changed_by: The name of the person who made the most recent change to data in the
              MaximumOnGrounds collection.

          mogs_last_changed_date: The datetime of the most recent change made to data in the MaximumOnGrounds
              collection, in ISO 8601 UTC format with millisecond precision.

          mogs_last_changed_reason: The reason for the most recent change to data in the MaximumOnGrounds
              collection.

          operational_deviations: Collection providing relevant information in the event of deviations/exceptions
              to normal operations.

          operational_plannings: Collection of planning information associated with this SiteOperations record.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pathways: Collection detailing operational pathways at the Site associated with this
              SiteOperations record.

          waivers: Collection documenting operational waivers that have been issued for the Site
              associated with this record.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/siteoperations/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_site": id_site,
                    "source": source,
                    "body_id": body_id,
                    "daily_operations": daily_operations,
                    "dops_last_changed_by": dops_last_changed_by,
                    "dops_last_changed_date": dops_last_changed_date,
                    "dops_last_changed_reason": dops_last_changed_reason,
                    "id_launch_site": id_launch_site,
                    "maximum_on_grounds": maximum_on_grounds,
                    "mogs_last_changed_by": mogs_last_changed_by,
                    "mogs_last_changed_date": mogs_last_changed_date,
                    "mogs_last_changed_reason": mogs_last_changed_reason,
                    "operational_deviations": operational_deviations,
                    "operational_plannings": operational_plannings,
                    "origin": origin,
                    "pathways": pathways,
                    "waivers": waivers,
                },
                operation_update_params.OperationUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[OperationListResponse, AsyncOffsetPage[OperationListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/siteoperations",
            page=AsyncOffsetPage[OperationListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_list_params.OperationListParams,
                ),
            ),
            model=OperationListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a siteoperations record specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/siteoperations/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/siteoperations/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_count_params.OperationCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[operation_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        siteoperations records as a POST body and ingest into the database. This
        operation is not intended to be used for automated feeds into UDL. Data
        providers should contact the UDL team for specific role assignments and for
        instructions on setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/siteoperations/createBulk",
            body=await async_maybe_transform(body, Iterable[operation_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/siteoperations/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OperationQueryHelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        id_site: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OperationTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_site: The ID of the parent site.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/siteoperations/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "id_site": id_site,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    operation_tuple_params.OperationTupleParams,
                ),
            ),
            cast_to=OperationTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[operation_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple siteoperations records as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-siteoperations",
            body=await async_maybe_transform(body, Iterable[operation_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class OperationsResourceWithRawResponse:
    def __init__(self, operations: OperationsResource) -> None:
        self._operations = operations

        self.create = to_raw_response_wrapper(
            operations.create,
        )
        self.retrieve = to_raw_response_wrapper(
            operations.retrieve,
        )
        self.update = to_raw_response_wrapper(
            operations.update,
        )
        self.list = to_raw_response_wrapper(
            operations.list,
        )
        self.delete = to_raw_response_wrapper(
            operations.delete,
        )
        self.count = to_raw_response_wrapper(
            operations.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            operations.create_bulk,
        )
        self.query_help = to_raw_response_wrapper(
            operations.query_help,
        )
        self.tuple = to_raw_response_wrapper(
            operations.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            operations.unvalidated_publish,
        )


class AsyncOperationsResourceWithRawResponse:
    def __init__(self, operations: AsyncOperationsResource) -> None:
        self._operations = operations

        self.create = async_to_raw_response_wrapper(
            operations.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            operations.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            operations.update,
        )
        self.list = async_to_raw_response_wrapper(
            operations.list,
        )
        self.delete = async_to_raw_response_wrapper(
            operations.delete,
        )
        self.count = async_to_raw_response_wrapper(
            operations.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            operations.create_bulk,
        )
        self.query_help = async_to_raw_response_wrapper(
            operations.query_help,
        )
        self.tuple = async_to_raw_response_wrapper(
            operations.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            operations.unvalidated_publish,
        )


class OperationsResourceWithStreamingResponse:
    def __init__(self, operations: OperationsResource) -> None:
        self._operations = operations

        self.create = to_streamed_response_wrapper(
            operations.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            operations.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            operations.update,
        )
        self.list = to_streamed_response_wrapper(
            operations.list,
        )
        self.delete = to_streamed_response_wrapper(
            operations.delete,
        )
        self.count = to_streamed_response_wrapper(
            operations.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            operations.create_bulk,
        )
        self.query_help = to_streamed_response_wrapper(
            operations.query_help,
        )
        self.tuple = to_streamed_response_wrapper(
            operations.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            operations.unvalidated_publish,
        )


class AsyncOperationsResourceWithStreamingResponse:
    def __init__(self, operations: AsyncOperationsResource) -> None:
        self._operations = operations

        self.create = async_to_streamed_response_wrapper(
            operations.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            operations.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            operations.update,
        )
        self.list = async_to_streamed_response_wrapper(
            operations.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            operations.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            operations.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            operations.create_bulk,
        )
        self.query_help = async_to_streamed_response_wrapper(
            operations.query_help,
        )
        self.tuple = async_to_streamed_response_wrapper(
            operations.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            operations.unvalidated_publish,
        )
