# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal

import httpx

from ..types import (
    aviation_risk_management_list_params,
    aviation_risk_management_count_params,
    aviation_risk_management_tuple_params,
    aviation_risk_management_create_params,
    aviation_risk_management_update_params,
    aviation_risk_management_retrieve_params,
    aviation_risk_management_create_bulk_params,
    aviation_risk_management_unvalidated_publish_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.aviation_risk_management_list_response import AviationRiskManagementListResponse
from ..types.aviation_risk_management_tuple_response import AviationRiskManagementTupleResponse
from ..types.aviation_risk_management_retrieve_response import AviationRiskManagementRetrieveResponse
from ..types.aviation_risk_management_query_help_response import AviationRiskManagementQueryHelpResponse

__all__ = ["AviationRiskManagementResource", "AsyncAviationRiskManagementResource"]


class AviationRiskManagementResource(SyncAPIResource):
    """
    These services provide operations for manipulating and querying Aircraft Sortie, Aircraft Mission, Item Tracking, Flight Plan, Air Event, Sortie Prior Permission Required (PPR), Diplomatic Clearance, Diplomatic Clearance Country, Airspace Control Order, Air Tasking Order, Navigational Obstruction, Logistics Support, Track Route, Air Load Plan, and Aviation Risk Management data. Aircraft Sortie information contains static and dynamic aircraft assignments, departure and arrival times, and remarks. Aircraft Mission information contains static data for mission planning to include assigned aircraft and crews, cargo pickup and dropoff locations, unique identifiers, and prioritization. Item Tracking information contains data for tracking an item from its origin to destination and how it may be configured during transport. Flight Plan information contains schedule and route details. Air Event provides information concerning various aerial events such as fuel transfer and air drops, as well as the associated aircraft involved. Sortie PPR information contains details on operational access to a runway, taxiway, or airport service. Diplomatic Clearance information contains details on the issuance and coordination of aircraft clearance requests. Diplomatic Clearance Country provides information such as entry/exit points, requirements, and points of contact for countries diplomatic clearances are being created for. Airspace Control Order provides information concerning the allocation, restriction, and deconfliction of airspace. Air Tasking Order information contains details on the coordination of air missions and their tasks, resources, and timelines. Navigational Obstruction provides the locations, characteristics, and boundaries of obstacles and structures that can restrict or interfere with navigation. Logistics Support contains information regarding the transport and maintenance of resources and equipment to sustain air operations. Track Route information defines specific flight paths used by aircraft during the transport of fuel and other resources. Air Load Plan information provides mission actuals concerning the loading and air transport of cargo and passengers. Aviation Risk Management information help aid in mission planning by accounting for factors such as mission complexity and crew fatigue.
    """

    @cached_property
    def with_raw_response(self) -> AviationRiskManagementResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AviationRiskManagementResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AviationRiskManagementResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AviationRiskManagementResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_mission: str,
        source: str,
        id: str | Omit = omit,
        aviation_risk_management_worksheet_record: Iterable[
            aviation_risk_management_create_params.AviationRiskManagementWorksheetRecord
        ]
        | Omit = omit,
        ext_mission_id: str | Omit = omit,
        mission_number: str | Omit = omit,
        org_id: str | Omit = omit,
        origin: str | Omit = omit,
        unit_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single Aviation Risk Management record as a POST
        body and ingest into the database. A specific role is required to perform this
        service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system if not provided on
              create operations.

          aviation_risk_management_worksheet_record: Collection of Aviation Risk Management Worksheet Records.

          ext_mission_id: Optional mission ID from external systems. This field has no meaning within UDL
              and is provided as a convenience for systems that require tracking of an
              internal system generated ID.

          mission_number: The mission number of the mission associated with this record.

          org_id: Identifier for the organization which this risk management record is evaluated.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          unit_id: Identifier for the unit which this risk management record is evaluated.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/aviationriskmanagement",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_mission": id_mission,
                    "source": source,
                    "id": id,
                    "aviation_risk_management_worksheet_record": aviation_risk_management_worksheet_record,
                    "ext_mission_id": ext_mission_id,
                    "mission_number": mission_number,
                    "org_id": org_id,
                    "origin": origin,
                    "unit_id": unit_id,
                },
                aviation_risk_management_create_params.AviationRiskManagementCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementRetrieveResponse:
        """
        Service operation to get a single Aviation Risk Management record by its unique
        ID passed as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/aviationriskmanagement/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_retrieve_params.AviationRiskManagementRetrieveParams,
                ),
            ),
            cast_to=AviationRiskManagementRetrieveResponse,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_mission: str,
        source: str,
        body_id: str | Omit = omit,
        aviation_risk_management_worksheet_record: Iterable[
            aviation_risk_management_update_params.AviationRiskManagementWorksheetRecord
        ]
        | Omit = omit,
        ext_mission_id: str | Omit = omit,
        mission_number: str | Omit = omit,
        org_id: str | Omit = omit,
        origin: str | Omit = omit,
        unit_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Aviation Risk Management record.

        A specific
        role is required to perform this service operation. Please contact the UDL team
        for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system if not provided on
              create operations.

          aviation_risk_management_worksheet_record: Collection of Aviation Risk Management Worksheet Records.

          ext_mission_id: Optional mission ID from external systems. This field has no meaning within UDL
              and is provided as a convenience for systems that require tracking of an
              internal system generated ID.

          mission_number: The mission number of the mission associated with this record.

          org_id: Identifier for the organization which this risk management record is evaluated.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          unit_id: Identifier for the unit which this risk management record is evaluated.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/aviationriskmanagement/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_mission": id_mission,
                    "source": source,
                    "body_id": body_id,
                    "aviation_risk_management_worksheet_record": aviation_risk_management_worksheet_record,
                    "ext_mission_id": ext_mission_id,
                    "mission_number": mission_number,
                    "org_id": org_id,
                    "origin": origin,
                    "unit_id": unit_id,
                },
                aviation_risk_management_update_params.AviationRiskManagementUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[AviationRiskManagementListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/aviationriskmanagement",
            page=SyncOffsetPage[AviationRiskManagementListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_list_params.AviationRiskManagementListParams,
                ),
            ),
            model=AviationRiskManagementListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete an Aviation Risk Management record specified by the
        passed ID path parameter. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/aviationriskmanagement/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/aviationriskmanagement/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_count_params.AviationRiskManagementCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[aviation_risk_management_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        Aviation Risk Management records as a POST body and ingest into the database.
        This operation is not intended to be used for automated feeds into UDL. Data
        providers should contact the UDL team for specific role assignments and for
        instructions on setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/aviationriskmanagement/createBulk",
            body=maybe_transform(body, Iterable[aviation_risk_management_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/aviationriskmanagement/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AviationRiskManagementQueryHelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/aviationriskmanagement/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_tuple_params.AviationRiskManagementTupleParams,
                ),
            ),
            cast_to=AviationRiskManagementTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[aviation_risk_management_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple Aviation Risk Management records as a POST
        body and ingest into the database. This operation is intended to be used for
        automated feeds into UDL. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-aviationriskmanagement",
            body=maybe_transform(body, Iterable[aviation_risk_management_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncAviationRiskManagementResource(AsyncAPIResource):
    """
    These services provide operations for manipulating and querying Aircraft Sortie, Aircraft Mission, Item Tracking, Flight Plan, Air Event, Sortie Prior Permission Required (PPR), Diplomatic Clearance, Diplomatic Clearance Country, Airspace Control Order, Air Tasking Order, Navigational Obstruction, Logistics Support, Track Route, Air Load Plan, and Aviation Risk Management data. Aircraft Sortie information contains static and dynamic aircraft assignments, departure and arrival times, and remarks. Aircraft Mission information contains static data for mission planning to include assigned aircraft and crews, cargo pickup and dropoff locations, unique identifiers, and prioritization. Item Tracking information contains data for tracking an item from its origin to destination and how it may be configured during transport. Flight Plan information contains schedule and route details. Air Event provides information concerning various aerial events such as fuel transfer and air drops, as well as the associated aircraft involved. Sortie PPR information contains details on operational access to a runway, taxiway, or airport service. Diplomatic Clearance information contains details on the issuance and coordination of aircraft clearance requests. Diplomatic Clearance Country provides information such as entry/exit points, requirements, and points of contact for countries diplomatic clearances are being created for. Airspace Control Order provides information concerning the allocation, restriction, and deconfliction of airspace. Air Tasking Order information contains details on the coordination of air missions and their tasks, resources, and timelines. Navigational Obstruction provides the locations, characteristics, and boundaries of obstacles and structures that can restrict or interfere with navigation. Logistics Support contains information regarding the transport and maintenance of resources and equipment to sustain air operations. Track Route information defines specific flight paths used by aircraft during the transport of fuel and other resources. Air Load Plan information provides mission actuals concerning the loading and air transport of cargo and passengers. Aviation Risk Management information help aid in mission planning by accounting for factors such as mission complexity and crew fatigue.
    """

    @cached_property
    def with_raw_response(self) -> AsyncAviationRiskManagementResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAviationRiskManagementResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAviationRiskManagementResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncAviationRiskManagementResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_mission: str,
        source: str,
        id: str | Omit = omit,
        aviation_risk_management_worksheet_record: Iterable[
            aviation_risk_management_create_params.AviationRiskManagementWorksheetRecord
        ]
        | Omit = omit,
        ext_mission_id: str | Omit = omit,
        mission_number: str | Omit = omit,
        org_id: str | Omit = omit,
        origin: str | Omit = omit,
        unit_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single Aviation Risk Management record as a POST
        body and ingest into the database. A specific role is required to perform this
        service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system if not provided on
              create operations.

          aviation_risk_management_worksheet_record: Collection of Aviation Risk Management Worksheet Records.

          ext_mission_id: Optional mission ID from external systems. This field has no meaning within UDL
              and is provided as a convenience for systems that require tracking of an
              internal system generated ID.

          mission_number: The mission number of the mission associated with this record.

          org_id: Identifier for the organization which this risk management record is evaluated.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          unit_id: Identifier for the unit which this risk management record is evaluated.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/aviationriskmanagement",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_mission": id_mission,
                    "source": source,
                    "id": id,
                    "aviation_risk_management_worksheet_record": aviation_risk_management_worksheet_record,
                    "ext_mission_id": ext_mission_id,
                    "mission_number": mission_number,
                    "org_id": org_id,
                    "origin": origin,
                    "unit_id": unit_id,
                },
                aviation_risk_management_create_params.AviationRiskManagementCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementRetrieveResponse:
        """
        Service operation to get a single Aviation Risk Management record by its unique
        ID passed as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/aviationriskmanagement/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_retrieve_params.AviationRiskManagementRetrieveParams,
                ),
            ),
            cast_to=AviationRiskManagementRetrieveResponse,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        id_mission: str,
        source: str,
        body_id: str | Omit = omit,
        aviation_risk_management_worksheet_record: Iterable[
            aviation_risk_management_update_params.AviationRiskManagementWorksheetRecord
        ]
        | Omit = omit,
        ext_mission_id: str | Omit = omit,
        mission_number: str | Omit = omit,
        org_id: str | Omit = omit,
        origin: str | Omit = omit,
        unit_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Aviation Risk Management record.

        A specific
        role is required to perform this service operation. Please contact the UDL team
        for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system if not provided on
              create operations.

          aviation_risk_management_worksheet_record: Collection of Aviation Risk Management Worksheet Records.

          ext_mission_id: Optional mission ID from external systems. This field has no meaning within UDL
              and is provided as a convenience for systems that require tracking of an
              internal system generated ID.

          mission_number: The mission number of the mission associated with this record.

          org_id: Identifier for the organization which this risk management record is evaluated.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          unit_id: Identifier for the unit which this risk management record is evaluated.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/aviationriskmanagement/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "id_mission": id_mission,
                    "source": source,
                    "body_id": body_id,
                    "aviation_risk_management_worksheet_record": aviation_risk_management_worksheet_record,
                    "ext_mission_id": ext_mission_id,
                    "mission_number": mission_number,
                    "org_id": org_id,
                    "origin": origin,
                    "unit_id": unit_id,
                },
                aviation_risk_management_update_params.AviationRiskManagementUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[AviationRiskManagementListResponse, AsyncOffsetPage[AviationRiskManagementListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/aviationriskmanagement",
            page=AsyncOffsetPage[AviationRiskManagementListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_list_params.AviationRiskManagementListParams,
                ),
            ),
            model=AviationRiskManagementListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete an Aviation Risk Management record specified by the
        passed ID path parameter. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/aviationriskmanagement/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/aviationriskmanagement/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_count_params.AviationRiskManagementCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[aviation_risk_management_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        Aviation Risk Management records as a POST body and ingest into the database.
        This operation is not intended to be used for automated feeds into UDL. Data
        providers should contact the UDL team for specific role assignments and for
        instructions on setting up a permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/aviationriskmanagement/createBulk",
            body=await async_maybe_transform(body, Iterable[aviation_risk_management_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/aviationriskmanagement/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AviationRiskManagementQueryHelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        id_mission: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AviationRiskManagementTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          id_mission: The unique identifier of the mission to which this risk management record is
              assigned.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/aviationriskmanagement/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "id_mission": id_mission,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aviation_risk_management_tuple_params.AviationRiskManagementTupleParams,
                ),
            ),
            cast_to=AviationRiskManagementTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[aviation_risk_management_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple Aviation Risk Management records as a POST
        body and ingest into the database. This operation is intended to be used for
        automated feeds into UDL. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-aviationriskmanagement",
            body=await async_maybe_transform(body, Iterable[aviation_risk_management_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AviationRiskManagementResourceWithRawResponse:
    def __init__(self, aviation_risk_management: AviationRiskManagementResource) -> None:
        self._aviation_risk_management = aviation_risk_management

        self.create = to_raw_response_wrapper(
            aviation_risk_management.create,
        )
        self.retrieve = to_raw_response_wrapper(
            aviation_risk_management.retrieve,
        )
        self.update = to_raw_response_wrapper(
            aviation_risk_management.update,
        )
        self.list = to_raw_response_wrapper(
            aviation_risk_management.list,
        )
        self.delete = to_raw_response_wrapper(
            aviation_risk_management.delete,
        )
        self.count = to_raw_response_wrapper(
            aviation_risk_management.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            aviation_risk_management.create_bulk,
        )
        self.query_help = to_raw_response_wrapper(
            aviation_risk_management.query_help,
        )
        self.tuple = to_raw_response_wrapper(
            aviation_risk_management.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            aviation_risk_management.unvalidated_publish,
        )


class AsyncAviationRiskManagementResourceWithRawResponse:
    def __init__(self, aviation_risk_management: AsyncAviationRiskManagementResource) -> None:
        self._aviation_risk_management = aviation_risk_management

        self.create = async_to_raw_response_wrapper(
            aviation_risk_management.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            aviation_risk_management.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            aviation_risk_management.update,
        )
        self.list = async_to_raw_response_wrapper(
            aviation_risk_management.list,
        )
        self.delete = async_to_raw_response_wrapper(
            aviation_risk_management.delete,
        )
        self.count = async_to_raw_response_wrapper(
            aviation_risk_management.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            aviation_risk_management.create_bulk,
        )
        self.query_help = async_to_raw_response_wrapper(
            aviation_risk_management.query_help,
        )
        self.tuple = async_to_raw_response_wrapper(
            aviation_risk_management.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            aviation_risk_management.unvalidated_publish,
        )


class AviationRiskManagementResourceWithStreamingResponse:
    def __init__(self, aviation_risk_management: AviationRiskManagementResource) -> None:
        self._aviation_risk_management = aviation_risk_management

        self.create = to_streamed_response_wrapper(
            aviation_risk_management.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            aviation_risk_management.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            aviation_risk_management.update,
        )
        self.list = to_streamed_response_wrapper(
            aviation_risk_management.list,
        )
        self.delete = to_streamed_response_wrapper(
            aviation_risk_management.delete,
        )
        self.count = to_streamed_response_wrapper(
            aviation_risk_management.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            aviation_risk_management.create_bulk,
        )
        self.query_help = to_streamed_response_wrapper(
            aviation_risk_management.query_help,
        )
        self.tuple = to_streamed_response_wrapper(
            aviation_risk_management.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            aviation_risk_management.unvalidated_publish,
        )


class AsyncAviationRiskManagementResourceWithStreamingResponse:
    def __init__(self, aviation_risk_management: AsyncAviationRiskManagementResource) -> None:
        self._aviation_risk_management = aviation_risk_management

        self.create = async_to_streamed_response_wrapper(
            aviation_risk_management.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            aviation_risk_management.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            aviation_risk_management.update,
        )
        self.list = async_to_streamed_response_wrapper(
            aviation_risk_management.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            aviation_risk_management.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            aviation_risk_management.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            aviation_risk_management.create_bulk,
        )
        self.query_help = async_to_streamed_response_wrapper(
            aviation_risk_management.query_help,
        )
        self.tuple = async_to_streamed_response_wrapper(
            aviation_risk_management.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            aviation_risk_management.unvalidated_publish,
        )
