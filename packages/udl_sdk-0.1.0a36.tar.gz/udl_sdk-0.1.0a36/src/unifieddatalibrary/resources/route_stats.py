# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    route_stat_list_params,
    route_stat_count_params,
    route_stat_tuple_params,
    route_stat_create_params,
    route_stat_update_params,
    route_stat_retrieve_params,
    route_stat_create_bulk_params,
    route_stat_unvalidated_publish_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.route_stat_list_response import RouteStatListResponse
from ..types.route_stat_tuple_response import RouteStatTupleResponse
from ..types.route_stat_retrieve_response import RouteStatRetrieveResponse
from ..types.route_stat_query_help_response import RouteStatQueryHelpResponse

__all__ = ["RouteStatsResource", "AsyncRouteStatsResource"]


class RouteStatsResource(SyncAPIResource):
    """
    These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
    """

    @cached_property
    def with_raw_response(self) -> RouteStatsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return RouteStatsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RouteStatsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return RouteStatsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        location_end: str,
        location_start: str,
        source: str,
        id: str | Omit = omit,
        avg_duration: float | Omit = omit,
        avg_speed: float | Omit = omit,
        data_pts_used: int | Omit = omit,
        distance: float | Omit = omit,
        dist_unit: str | Omit = omit,
        first_pt: Union[str, datetime] | Omit = omit,
        ideal_desc: str | Omit = omit,
        ideal_duration: float | Omit = omit,
        id_site_end: str | Omit = omit,
        id_site_start: str | Omit = omit,
        last_pt: Union[str, datetime] | Omit = omit,
        location_type: str | Omit = omit,
        max_duration: float | Omit = omit,
        max_speed: float | Omit = omit,
        min_duration: float | Omit = omit,
        min_speed: float | Omit = omit,
        origin: str | Omit = omit,
        partial_desc: str | Omit = omit,
        partial_duration: float | Omit = omit,
        speed_unit: str | Omit = omit,
        time_period: str | Omit = omit,
        vehicle_category: str | Omit = omit,
        vehicle_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single routeStats record as a POST body and ingest
        into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          location_end: End location of the vehicle.

          location_start: Starting location of the vehicle.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          avg_duration: Average travel duration for the indicated distance and type of vehicle in hours.

          avg_speed: Average speed during travel in the indicated unit of measurement, speedUnit.

          data_pts_used: The number of data points used in this travel duration calculation.

          distance: Distance between the departure and arrival locations in the indicated unit of
              measurement, distUnit.

          dist_unit: The unit of measurement used for distance in this calculation.

          first_pt: Date of the first data point used in this calculation, in ISO8601 UTC format
              with millisecond precision.

          ideal_desc: Description of the portion of travel used to estimate the value of the
              idealDuration field.

          ideal_duration: Estimated ideal travel duration in hours for the full distance using the
              indicated vehicle type. The field "idealDesc" should be used to describe the
              ideal travel route.

          id_site_end: Unique identifier of the Site at the route's end location. This ID can be used
              to obtain additional information on a Site using the 'get by ID' operation (e.g.
              /udl/site/{id}). For example, the Site object with idSite = abc would be queried
              as /udl/site/abc.

          id_site_start: Unique identifier of the Site at the route's starting location. This ID can be
              used to obtain additional information on a Site using the 'get by ID' operation
              (e.g. /udl/site/{id}). For example, the Site object with idSite = abc would be
              queried as /udl/site/abc.

          last_pt: Date of the last data point used in this calculation, in ISO8601 UTC format with
              millisecond precision.

          location_type: Type of location used for route start and end points (e.g., ICAO, PORT, etc.).

          max_duration: Maximum travel duration for the indicated distance and type of vehicle in hours.

          max_speed: Maximum speed during travel in the indicated unit of measurement, speedUnit.

          min_duration: Minimum travel duration for the indicated distance and type of vehicle in hours.

          min_speed: Minimum speed during travel in the indicated unit of measurement, speedUnit.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          partial_desc: Description of the portion of travel used to estimate the value of the
              partialDuration field.

          partial_duration: Estimated ideal travel duration in hours for a partial distance using the
              indicated vehicle type. The field "partialDesc" should be used to specify the
              intended portion of travel.

          speed_unit: The unit of measurement used for speed in this calculation.

          time_period: The time period this data was collected.

          vehicle_category: The vehicle category that is the subject of this calculation (e.g., AIRCRAFT,
              CAR, BOAT, etc.).

          vehicle_type: The vehicle type that is the subject of this calculation (e.g., C-17, F-15,
              etc.).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/routestats",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "location_end": location_end,
                    "location_start": location_start,
                    "source": source,
                    "id": id,
                    "avg_duration": avg_duration,
                    "avg_speed": avg_speed,
                    "data_pts_used": data_pts_used,
                    "distance": distance,
                    "dist_unit": dist_unit,
                    "first_pt": first_pt,
                    "ideal_desc": ideal_desc,
                    "ideal_duration": ideal_duration,
                    "id_site_end": id_site_end,
                    "id_site_start": id_site_start,
                    "last_pt": last_pt,
                    "location_type": location_type,
                    "max_duration": max_duration,
                    "max_speed": max_speed,
                    "min_duration": min_duration,
                    "min_speed": min_speed,
                    "origin": origin,
                    "partial_desc": partial_desc,
                    "partial_duration": partial_duration,
                    "speed_unit": speed_unit,
                    "time_period": time_period,
                    "vehicle_category": vehicle_category,
                    "vehicle_type": vehicle_type,
                },
                route_stat_create_params.RouteStatCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatRetrieveResponse:
        """
        Service operation to get a single routeStats record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/routestats/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_retrieve_params.RouteStatRetrieveParams,
                ),
            ),
            cast_to=RouteStatRetrieveResponse,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        location_end: str,
        location_start: str,
        source: str,
        body_id: str | Omit = omit,
        avg_duration: float | Omit = omit,
        avg_speed: float | Omit = omit,
        data_pts_used: int | Omit = omit,
        distance: float | Omit = omit,
        dist_unit: str | Omit = omit,
        first_pt: Union[str, datetime] | Omit = omit,
        ideal_desc: str | Omit = omit,
        ideal_duration: float | Omit = omit,
        id_site_end: str | Omit = omit,
        id_site_start: str | Omit = omit,
        last_pt: Union[str, datetime] | Omit = omit,
        location_type: str | Omit = omit,
        max_duration: float | Omit = omit,
        max_speed: float | Omit = omit,
        min_duration: float | Omit = omit,
        min_speed: float | Omit = omit,
        origin: str | Omit = omit,
        partial_desc: str | Omit = omit,
        partial_duration: float | Omit = omit,
        speed_unit: str | Omit = omit,
        time_period: str | Omit = omit,
        vehicle_category: str | Omit = omit,
        vehicle_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single RouteStats.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          location_end: End location of the vehicle.

          location_start: Starting location of the vehicle.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          avg_duration: Average travel duration for the indicated distance and type of vehicle in hours.

          avg_speed: Average speed during travel in the indicated unit of measurement, speedUnit.

          data_pts_used: The number of data points used in this travel duration calculation.

          distance: Distance between the departure and arrival locations in the indicated unit of
              measurement, distUnit.

          dist_unit: The unit of measurement used for distance in this calculation.

          first_pt: Date of the first data point used in this calculation, in ISO8601 UTC format
              with millisecond precision.

          ideal_desc: Description of the portion of travel used to estimate the value of the
              idealDuration field.

          ideal_duration: Estimated ideal travel duration in hours for the full distance using the
              indicated vehicle type. The field "idealDesc" should be used to describe the
              ideal travel route.

          id_site_end: Unique identifier of the Site at the route's end location. This ID can be used
              to obtain additional information on a Site using the 'get by ID' operation (e.g.
              /udl/site/{id}). For example, the Site object with idSite = abc would be queried
              as /udl/site/abc.

          id_site_start: Unique identifier of the Site at the route's starting location. This ID can be
              used to obtain additional information on a Site using the 'get by ID' operation
              (e.g. /udl/site/{id}). For example, the Site object with idSite = abc would be
              queried as /udl/site/abc.

          last_pt: Date of the last data point used in this calculation, in ISO8601 UTC format with
              millisecond precision.

          location_type: Type of location used for route start and end points (e.g., ICAO, PORT, etc.).

          max_duration: Maximum travel duration for the indicated distance and type of vehicle in hours.

          max_speed: Maximum speed during travel in the indicated unit of measurement, speedUnit.

          min_duration: Minimum travel duration for the indicated distance and type of vehicle in hours.

          min_speed: Minimum speed during travel in the indicated unit of measurement, speedUnit.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          partial_desc: Description of the portion of travel used to estimate the value of the
              partialDuration field.

          partial_duration: Estimated ideal travel duration in hours for a partial distance using the
              indicated vehicle type. The field "partialDesc" should be used to specify the
              intended portion of travel.

          speed_unit: The unit of measurement used for speed in this calculation.

          time_period: The time period this data was collected.

          vehicle_category: The vehicle category that is the subject of this calculation (e.g., AIRCRAFT,
              CAR, BOAT, etc.).

          vehicle_type: The vehicle type that is the subject of this calculation (e.g., C-17, F-15,
              etc.).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/routestats/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "location_end": location_end,
                    "location_start": location_start,
                    "source": source,
                    "body_id": body_id,
                    "avg_duration": avg_duration,
                    "avg_speed": avg_speed,
                    "data_pts_used": data_pts_used,
                    "distance": distance,
                    "dist_unit": dist_unit,
                    "first_pt": first_pt,
                    "ideal_desc": ideal_desc,
                    "ideal_duration": ideal_duration,
                    "id_site_end": id_site_end,
                    "id_site_start": id_site_start,
                    "last_pt": last_pt,
                    "location_type": location_type,
                    "max_duration": max_duration,
                    "max_speed": max_speed,
                    "min_duration": min_duration,
                    "min_speed": min_speed,
                    "origin": origin,
                    "partial_desc": partial_desc,
                    "partial_duration": partial_duration,
                    "speed_unit": speed_unit,
                    "time_period": time_period,
                    "vehicle_category": vehicle_category,
                    "vehicle_type": vehicle_type,
                },
                route_stat_update_params.RouteStatUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[RouteStatListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/routestats",
            page=SyncOffsetPage[RouteStatListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_list_params.RouteStatListParams,
                ),
            ),
            model=RouteStatListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a routeStats record specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/routestats/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/routestats/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_count_params.RouteStatCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[route_stat_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        RouteStats as a POST body and ingest into the database. This operation is not
        intended to be used for automated feeds into UDL. Data providers should contact
        the UDL team for specific role assignments and for instructions on setting up a
        permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/routestats/createBulk",
            body=maybe_transform(body, Iterable[route_stat_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/routestats/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RouteStatQueryHelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/routestats/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_tuple_params.RouteStatTupleParams,
                ),
            ),
            cast_to=RouteStatTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[route_stat_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple routestats records as a POST body and ingest
        into the database. This operation is intended to be used for automated feeds
        into UDL. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-routestats",
            body=maybe_transform(body, Iterable[route_stat_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncRouteStatsResource(AsyncAPIResource):
    """
    These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
    """

    @cached_property
    def with_raw_response(self) -> AsyncRouteStatsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncRouteStatsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRouteStatsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncRouteStatsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        location_end: str,
        location_start: str,
        source: str,
        id: str | Omit = omit,
        avg_duration: float | Omit = omit,
        avg_speed: float | Omit = omit,
        data_pts_used: int | Omit = omit,
        distance: float | Omit = omit,
        dist_unit: str | Omit = omit,
        first_pt: Union[str, datetime] | Omit = omit,
        ideal_desc: str | Omit = omit,
        ideal_duration: float | Omit = omit,
        id_site_end: str | Omit = omit,
        id_site_start: str | Omit = omit,
        last_pt: Union[str, datetime] | Omit = omit,
        location_type: str | Omit = omit,
        max_duration: float | Omit = omit,
        max_speed: float | Omit = omit,
        min_duration: float | Omit = omit,
        min_speed: float | Omit = omit,
        origin: str | Omit = omit,
        partial_desc: str | Omit = omit,
        partial_duration: float | Omit = omit,
        speed_unit: str | Omit = omit,
        time_period: str | Omit = omit,
        vehicle_category: str | Omit = omit,
        vehicle_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single routeStats record as a POST body and ingest
        into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          location_end: End location of the vehicle.

          location_start: Starting location of the vehicle.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          avg_duration: Average travel duration for the indicated distance and type of vehicle in hours.

          avg_speed: Average speed during travel in the indicated unit of measurement, speedUnit.

          data_pts_used: The number of data points used in this travel duration calculation.

          distance: Distance between the departure and arrival locations in the indicated unit of
              measurement, distUnit.

          dist_unit: The unit of measurement used for distance in this calculation.

          first_pt: Date of the first data point used in this calculation, in ISO8601 UTC format
              with millisecond precision.

          ideal_desc: Description of the portion of travel used to estimate the value of the
              idealDuration field.

          ideal_duration: Estimated ideal travel duration in hours for the full distance using the
              indicated vehicle type. The field "idealDesc" should be used to describe the
              ideal travel route.

          id_site_end: Unique identifier of the Site at the route's end location. This ID can be used
              to obtain additional information on a Site using the 'get by ID' operation (e.g.
              /udl/site/{id}). For example, the Site object with idSite = abc would be queried
              as /udl/site/abc.

          id_site_start: Unique identifier of the Site at the route's starting location. This ID can be
              used to obtain additional information on a Site using the 'get by ID' operation
              (e.g. /udl/site/{id}). For example, the Site object with idSite = abc would be
              queried as /udl/site/abc.

          last_pt: Date of the last data point used in this calculation, in ISO8601 UTC format with
              millisecond precision.

          location_type: Type of location used for route start and end points (e.g., ICAO, PORT, etc.).

          max_duration: Maximum travel duration for the indicated distance and type of vehicle in hours.

          max_speed: Maximum speed during travel in the indicated unit of measurement, speedUnit.

          min_duration: Minimum travel duration for the indicated distance and type of vehicle in hours.

          min_speed: Minimum speed during travel in the indicated unit of measurement, speedUnit.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          partial_desc: Description of the portion of travel used to estimate the value of the
              partialDuration field.

          partial_duration: Estimated ideal travel duration in hours for a partial distance using the
              indicated vehicle type. The field "partialDesc" should be used to specify the
              intended portion of travel.

          speed_unit: The unit of measurement used for speed in this calculation.

          time_period: The time period this data was collected.

          vehicle_category: The vehicle category that is the subject of this calculation (e.g., AIRCRAFT,
              CAR, BOAT, etc.).

          vehicle_type: The vehicle type that is the subject of this calculation (e.g., C-17, F-15,
              etc.).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/routestats",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "location_end": location_end,
                    "location_start": location_start,
                    "source": source,
                    "id": id,
                    "avg_duration": avg_duration,
                    "avg_speed": avg_speed,
                    "data_pts_used": data_pts_used,
                    "distance": distance,
                    "dist_unit": dist_unit,
                    "first_pt": first_pt,
                    "ideal_desc": ideal_desc,
                    "ideal_duration": ideal_duration,
                    "id_site_end": id_site_end,
                    "id_site_start": id_site_start,
                    "last_pt": last_pt,
                    "location_type": location_type,
                    "max_duration": max_duration,
                    "max_speed": max_speed,
                    "min_duration": min_duration,
                    "min_speed": min_speed,
                    "origin": origin,
                    "partial_desc": partial_desc,
                    "partial_duration": partial_duration,
                    "speed_unit": speed_unit,
                    "time_period": time_period,
                    "vehicle_category": vehicle_category,
                    "vehicle_type": vehicle_type,
                },
                route_stat_create_params.RouteStatCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatRetrieveResponse:
        """
        Service operation to get a single routeStats record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/routestats/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_retrieve_params.RouteStatRetrieveParams,
                ),
            ),
            cast_to=RouteStatRetrieveResponse,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        location_end: str,
        location_start: str,
        source: str,
        body_id: str | Omit = omit,
        avg_duration: float | Omit = omit,
        avg_speed: float | Omit = omit,
        data_pts_used: int | Omit = omit,
        distance: float | Omit = omit,
        dist_unit: str | Omit = omit,
        first_pt: Union[str, datetime] | Omit = omit,
        ideal_desc: str | Omit = omit,
        ideal_duration: float | Omit = omit,
        id_site_end: str | Omit = omit,
        id_site_start: str | Omit = omit,
        last_pt: Union[str, datetime] | Omit = omit,
        location_type: str | Omit = omit,
        max_duration: float | Omit = omit,
        max_speed: float | Omit = omit,
        min_duration: float | Omit = omit,
        min_speed: float | Omit = omit,
        origin: str | Omit = omit,
        partial_desc: str | Omit = omit,
        partial_duration: float | Omit = omit,
        speed_unit: str | Omit = omit,
        time_period: str | Omit = omit,
        vehicle_category: str | Omit = omit,
        vehicle_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single RouteStats.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          location_end: End location of the vehicle.

          location_start: Starting location of the vehicle.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          avg_duration: Average travel duration for the indicated distance and type of vehicle in hours.

          avg_speed: Average speed during travel in the indicated unit of measurement, speedUnit.

          data_pts_used: The number of data points used in this travel duration calculation.

          distance: Distance between the departure and arrival locations in the indicated unit of
              measurement, distUnit.

          dist_unit: The unit of measurement used for distance in this calculation.

          first_pt: Date of the first data point used in this calculation, in ISO8601 UTC format
              with millisecond precision.

          ideal_desc: Description of the portion of travel used to estimate the value of the
              idealDuration field.

          ideal_duration: Estimated ideal travel duration in hours for the full distance using the
              indicated vehicle type. The field "idealDesc" should be used to describe the
              ideal travel route.

          id_site_end: Unique identifier of the Site at the route's end location. This ID can be used
              to obtain additional information on a Site using the 'get by ID' operation (e.g.
              /udl/site/{id}). For example, the Site object with idSite = abc would be queried
              as /udl/site/abc.

          id_site_start: Unique identifier of the Site at the route's starting location. This ID can be
              used to obtain additional information on a Site using the 'get by ID' operation
              (e.g. /udl/site/{id}). For example, the Site object with idSite = abc would be
              queried as /udl/site/abc.

          last_pt: Date of the last data point used in this calculation, in ISO8601 UTC format with
              millisecond precision.

          location_type: Type of location used for route start and end points (e.g., ICAO, PORT, etc.).

          max_duration: Maximum travel duration for the indicated distance and type of vehicle in hours.

          max_speed: Maximum speed during travel in the indicated unit of measurement, speedUnit.

          min_duration: Minimum travel duration for the indicated distance and type of vehicle in hours.

          min_speed: Minimum speed during travel in the indicated unit of measurement, speedUnit.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          partial_desc: Description of the portion of travel used to estimate the value of the
              partialDuration field.

          partial_duration: Estimated ideal travel duration in hours for a partial distance using the
              indicated vehicle type. The field "partialDesc" should be used to specify the
              intended portion of travel.

          speed_unit: The unit of measurement used for speed in this calculation.

          time_period: The time period this data was collected.

          vehicle_category: The vehicle category that is the subject of this calculation (e.g., AIRCRAFT,
              CAR, BOAT, etc.).

          vehicle_type: The vehicle type that is the subject of this calculation (e.g., C-17, F-15,
              etc.).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/routestats/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "location_end": location_end,
                    "location_start": location_start,
                    "source": source,
                    "body_id": body_id,
                    "avg_duration": avg_duration,
                    "avg_speed": avg_speed,
                    "data_pts_used": data_pts_used,
                    "distance": distance,
                    "dist_unit": dist_unit,
                    "first_pt": first_pt,
                    "ideal_desc": ideal_desc,
                    "ideal_duration": ideal_duration,
                    "id_site_end": id_site_end,
                    "id_site_start": id_site_start,
                    "last_pt": last_pt,
                    "location_type": location_type,
                    "max_duration": max_duration,
                    "max_speed": max_speed,
                    "min_duration": min_duration,
                    "min_speed": min_speed,
                    "origin": origin,
                    "partial_desc": partial_desc,
                    "partial_duration": partial_duration,
                    "speed_unit": speed_unit,
                    "time_period": time_period,
                    "vehicle_category": vehicle_category,
                    "vehicle_type": vehicle_type,
                },
                route_stat_update_params.RouteStatUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[RouteStatListResponse, AsyncOffsetPage[RouteStatListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/routestats",
            page=AsyncOffsetPage[RouteStatListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_list_params.RouteStatListParams,
                ),
            ),
            model=RouteStatListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a routeStats record specified by the passed ID path
        parameter. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/routestats/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/routestats/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_count_params.RouteStatCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[route_stat_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation intended for initial integration only, to take a list of
        RouteStats as a POST body and ingest into the database. This operation is not
        intended to be used for automated feeds into UDL. Data providers should contact
        the UDL team for specific role assignments and for instructions on setting up a
        permanent feed through an alternate mechanism.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/routestats/createBulk",
            body=await async_maybe_transform(body, Iterable[route_stat_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/routestats/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RouteStatQueryHelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RouteStatTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/routestats/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    route_stat_tuple_params.RouteStatTupleParams,
                ),
            ),
            cast_to=RouteStatTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[route_stat_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple routestats records as a POST body and ingest
        into the database. This operation is intended to be used for automated feeds
        into UDL. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-routestats",
            body=await async_maybe_transform(body, Iterable[route_stat_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class RouteStatsResourceWithRawResponse:
    def __init__(self, route_stats: RouteStatsResource) -> None:
        self._route_stats = route_stats

        self.create = to_raw_response_wrapper(
            route_stats.create,
        )
        self.retrieve = to_raw_response_wrapper(
            route_stats.retrieve,
        )
        self.update = to_raw_response_wrapper(
            route_stats.update,
        )
        self.list = to_raw_response_wrapper(
            route_stats.list,
        )
        self.delete = to_raw_response_wrapper(
            route_stats.delete,
        )
        self.count = to_raw_response_wrapper(
            route_stats.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            route_stats.create_bulk,
        )
        self.query_help = to_raw_response_wrapper(
            route_stats.query_help,
        )
        self.tuple = to_raw_response_wrapper(
            route_stats.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            route_stats.unvalidated_publish,
        )


class AsyncRouteStatsResourceWithRawResponse:
    def __init__(self, route_stats: AsyncRouteStatsResource) -> None:
        self._route_stats = route_stats

        self.create = async_to_raw_response_wrapper(
            route_stats.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            route_stats.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            route_stats.update,
        )
        self.list = async_to_raw_response_wrapper(
            route_stats.list,
        )
        self.delete = async_to_raw_response_wrapper(
            route_stats.delete,
        )
        self.count = async_to_raw_response_wrapper(
            route_stats.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            route_stats.create_bulk,
        )
        self.query_help = async_to_raw_response_wrapper(
            route_stats.query_help,
        )
        self.tuple = async_to_raw_response_wrapper(
            route_stats.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            route_stats.unvalidated_publish,
        )


class RouteStatsResourceWithStreamingResponse:
    def __init__(self, route_stats: RouteStatsResource) -> None:
        self._route_stats = route_stats

        self.create = to_streamed_response_wrapper(
            route_stats.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            route_stats.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            route_stats.update,
        )
        self.list = to_streamed_response_wrapper(
            route_stats.list,
        )
        self.delete = to_streamed_response_wrapper(
            route_stats.delete,
        )
        self.count = to_streamed_response_wrapper(
            route_stats.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            route_stats.create_bulk,
        )
        self.query_help = to_streamed_response_wrapper(
            route_stats.query_help,
        )
        self.tuple = to_streamed_response_wrapper(
            route_stats.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            route_stats.unvalidated_publish,
        )


class AsyncRouteStatsResourceWithStreamingResponse:
    def __init__(self, route_stats: AsyncRouteStatsResource) -> None:
        self._route_stats = route_stats

        self.create = async_to_streamed_response_wrapper(
            route_stats.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            route_stats.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            route_stats.update,
        )
        self.list = async_to_streamed_response_wrapper(
            route_stats.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            route_stats.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            route_stats.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            route_stats.create_bulk,
        )
        self.query_help = async_to_streamed_response_wrapper(
            route_stats.query_help,
        )
        self.tuple = async_to_streamed_response_wrapper(
            route_stats.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            route_stats.unvalidated_publish,
        )
