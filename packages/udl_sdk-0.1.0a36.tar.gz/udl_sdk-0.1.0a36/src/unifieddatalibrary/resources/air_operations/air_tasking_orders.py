# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.air_operations import (
    air_tasking_order_list_params,
    air_tasking_order_count_params,
    air_tasking_order_tuple_params,
    air_tasking_order_create_params,
    air_tasking_order_retrieve_params,
    air_tasking_order_unvalidated_publish_params,
)
from ...types.shared.air_tasking_order_full import AirTaskingOrderFull
from ...types.air_operations.airtaskingorder_abridged import AirtaskingorderAbridged
from ...types.air_operations.air_tasking_order_tuple_response import AirTaskingOrderTupleResponse
from ...types.air_operations.air_tasking_order_query_help_response import AirTaskingOrderQueryHelpResponse

__all__ = ["AirTaskingOrdersResource", "AsyncAirTaskingOrdersResource"]


class AirTaskingOrdersResource(SyncAPIResource):
    """
    These services provide operations for manipulating and querying Aircraft Sortie, Aircraft Mission, Item Tracking, Flight Plan, Air Event, Sortie Prior Permission Required (PPR), Diplomatic Clearance, Diplomatic Clearance Country, Airspace Control Order, Air Tasking Order, Navigational Obstruction, Logistics Support, Track Route, Air Load Plan, and Aviation Risk Management data. Aircraft Sortie information contains static and dynamic aircraft assignments, departure and arrival times, and remarks. Aircraft Mission information contains static data for mission planning to include assigned aircraft and crews, cargo pickup and dropoff locations, unique identifiers, and prioritization. Item Tracking information contains data for tracking an item from its origin to destination and how it may be configured during transport. Flight Plan information contains schedule and route details. Air Event provides information concerning various aerial events such as fuel transfer and air drops, as well as the associated aircraft involved. Sortie PPR information contains details on operational access to a runway, taxiway, or airport service. Diplomatic Clearance information contains details on the issuance and coordination of aircraft clearance requests. Diplomatic Clearance Country provides information such as entry/exit points, requirements, and points of contact for countries diplomatic clearances are being created for. Airspace Control Order provides information concerning the allocation, restriction, and deconfliction of airspace. Air Tasking Order information contains details on the coordination of air missions and their tasks, resources, and timelines. Navigational Obstruction provides the locations, characteristics, and boundaries of obstacles and structures that can restrict or interfere with navigation. Logistics Support contains information regarding the transport and maintenance of resources and equipment to sustain air operations. Track Route information defines specific flight paths used by aircraft during the transport of fuel and other resources. Air Load Plan information provides mission actuals concerning the loading and air transport of cargo and passengers. Aviation Risk Management information help aid in mission planning by accounting for factors such as mission complexity and crew fatigue.
    """

    @cached_property
    def with_raw_response(self) -> AirTaskingOrdersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AirTaskingOrdersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AirTaskingOrdersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AirTaskingOrdersResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        begin_ts: Union[str, datetime],
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        op_exer_name: str,
        source: str,
        id: str | Omit = omit,
        ack_req_ind: str | Omit = omit,
        ack_unit_instructions: str | Omit = omit,
        ac_msn_tasking: Iterable[air_tasking_order_create_params.AcMsnTasking] | Omit = omit,
        end_ts: Union[str, datetime] | Omit = omit,
        gen_text: Iterable[air_tasking_order_create_params.GenText] | Omit = omit,
        msg_month: str | Omit = omit,
        msg_originator: str | Omit = omit,
        msg_qualifier: str | Omit = omit,
        msg_sn: str | Omit = omit,
        naval_flt_ops: Iterable[air_tasking_order_create_params.NavalFltOp] | Omit = omit,
        origin: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single airtaskingorder record as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          begin_ts: The effective begin time for this ATO in ISO 8601 UTC format with millisecond
              precision.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          op_exer_name: Specifies the unique operation or exercise name, nickname, or codeword assigned
              to a joint exercise or operation plan.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          ack_req_ind: The indicator specifying an affirmative or a negatice condition for this
              message.

          ack_unit_instructions: Specifies textual data amplifying the data contained in the acknowledgement
              requirement indicator (ackRedInd) field or the unit required to acknowledge.

          ac_msn_tasking: A collection that specifies the tasked country, tasked service, unit and mission
              level tasking for this ATO.

          end_ts: The effective end time for this ATO in ISO 8601 UTC format with millisecond
              precision.

          gen_text: A collection that details special instructions, important information, guidance,
              and amplifying information regarding this ATO.

          msg_month: The month in which the message originated.

          msg_originator: The identifier of the originator of the message.

          msg_qualifier: The qualifier which caveats the message status.

          msg_sn: The unique message identifier sequentially assigned by the originator.

          naval_flt_ops: A collection that specifies the naval flight operations for this ATO.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/airtaskingorder",
            body=maybe_transform(
                {
                    "begin_ts": begin_ts,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "op_exer_name": op_exer_name,
                    "source": source,
                    "id": id,
                    "ack_req_ind": ack_req_ind,
                    "ack_unit_instructions": ack_unit_instructions,
                    "ac_msn_tasking": ac_msn_tasking,
                    "end_ts": end_ts,
                    "gen_text": gen_text,
                    "msg_month": msg_month,
                    "msg_originator": msg_originator,
                    "msg_qualifier": msg_qualifier,
                    "msg_sn": msg_sn,
                    "naval_flt_ops": naval_flt_ops,
                    "origin": origin,
                },
                air_tasking_order_create_params.AirTaskingOrderCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderFull:
        """
        Service operation to get a single airtaskingorder record by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/airtaskingorder/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_retrieve_params.AirTaskingOrderRetrieveParams,
                ),
            ),
            cast_to=AirTaskingOrderFull,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[AirtaskingorderAbridged]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/airtaskingorder",
            page=SyncOffsetPage[AirtaskingorderAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_list_params.AirTaskingOrderListParams,
                ),
            ),
            model=AirtaskingorderAbridged,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/airtaskingorder/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_count_params.AirTaskingOrderCountParams,
                ),
            ),
            cast_to=str,
        )

    def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/airtaskingorder/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AirTaskingOrderQueryHelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/airtaskingorder/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_tuple_params.AirTaskingOrderTupleParams,
                ),
            ),
            cast_to=AirTaskingOrderTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[air_tasking_order_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple airtaskingorder records as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-airtaskingorder",
            body=maybe_transform(body, Iterable[air_tasking_order_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncAirTaskingOrdersResource(AsyncAPIResource):
    """
    These services provide operations for manipulating and querying Aircraft Sortie, Aircraft Mission, Item Tracking, Flight Plan, Air Event, Sortie Prior Permission Required (PPR), Diplomatic Clearance, Diplomatic Clearance Country, Airspace Control Order, Air Tasking Order, Navigational Obstruction, Logistics Support, Track Route, Air Load Plan, and Aviation Risk Management data. Aircraft Sortie information contains static and dynamic aircraft assignments, departure and arrival times, and remarks. Aircraft Mission information contains static data for mission planning to include assigned aircraft and crews, cargo pickup and dropoff locations, unique identifiers, and prioritization. Item Tracking information contains data for tracking an item from its origin to destination and how it may be configured during transport. Flight Plan information contains schedule and route details. Air Event provides information concerning various aerial events such as fuel transfer and air drops, as well as the associated aircraft involved. Sortie PPR information contains details on operational access to a runway, taxiway, or airport service. Diplomatic Clearance information contains details on the issuance and coordination of aircraft clearance requests. Diplomatic Clearance Country provides information such as entry/exit points, requirements, and points of contact for countries diplomatic clearances are being created for. Airspace Control Order provides information concerning the allocation, restriction, and deconfliction of airspace. Air Tasking Order information contains details on the coordination of air missions and their tasks, resources, and timelines. Navigational Obstruction provides the locations, characteristics, and boundaries of obstacles and structures that can restrict or interfere with navigation. Logistics Support contains information regarding the transport and maintenance of resources and equipment to sustain air operations. Track Route information defines specific flight paths used by aircraft during the transport of fuel and other resources. Air Load Plan information provides mission actuals concerning the loading and air transport of cargo and passengers. Aviation Risk Management information help aid in mission planning by accounting for factors such as mission complexity and crew fatigue.
    """

    @cached_property
    def with_raw_response(self) -> AsyncAirTaskingOrdersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAirTaskingOrdersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAirTaskingOrdersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncAirTaskingOrdersResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        begin_ts: Union[str, datetime],
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        op_exer_name: str,
        source: str,
        id: str | Omit = omit,
        ack_req_ind: str | Omit = omit,
        ack_unit_instructions: str | Omit = omit,
        ac_msn_tasking: Iterable[air_tasking_order_create_params.AcMsnTasking] | Omit = omit,
        end_ts: Union[str, datetime] | Omit = omit,
        gen_text: Iterable[air_tasking_order_create_params.GenText] | Omit = omit,
        msg_month: str | Omit = omit,
        msg_originator: str | Omit = omit,
        msg_qualifier: str | Omit = omit,
        msg_sn: str | Omit = omit,
        naval_flt_ops: Iterable[air_tasking_order_create_params.NavalFltOp] | Omit = omit,
        origin: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single airtaskingorder record as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          begin_ts: The effective begin time for this ATO in ISO 8601 UTC format with millisecond
              precision.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          op_exer_name: Specifies the unique operation or exercise name, nickname, or codeword assigned
              to a joint exercise or operation plan.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          ack_req_ind: The indicator specifying an affirmative or a negatice condition for this
              message.

          ack_unit_instructions: Specifies textual data amplifying the data contained in the acknowledgement
              requirement indicator (ackRedInd) field or the unit required to acknowledge.

          ac_msn_tasking: A collection that specifies the tasked country, tasked service, unit and mission
              level tasking for this ATO.

          end_ts: The effective end time for this ATO in ISO 8601 UTC format with millisecond
              precision.

          gen_text: A collection that details special instructions, important information, guidance,
              and amplifying information regarding this ATO.

          msg_month: The month in which the message originated.

          msg_originator: The identifier of the originator of the message.

          msg_qualifier: The qualifier which caveats the message status.

          msg_sn: The unique message identifier sequentially assigned by the originator.

          naval_flt_ops: A collection that specifies the naval flight operations for this ATO.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/airtaskingorder",
            body=await async_maybe_transform(
                {
                    "begin_ts": begin_ts,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "op_exer_name": op_exer_name,
                    "source": source,
                    "id": id,
                    "ack_req_ind": ack_req_ind,
                    "ack_unit_instructions": ack_unit_instructions,
                    "ac_msn_tasking": ac_msn_tasking,
                    "end_ts": end_ts,
                    "gen_text": gen_text,
                    "msg_month": msg_month,
                    "msg_originator": msg_originator,
                    "msg_qualifier": msg_qualifier,
                    "msg_sn": msg_sn,
                    "naval_flt_ops": naval_flt_ops,
                    "origin": origin,
                },
                air_tasking_order_create_params.AirTaskingOrderCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderFull:
        """
        Service operation to get a single airtaskingorder record by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/airtaskingorder/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_retrieve_params.AirTaskingOrderRetrieveParams,
                ),
            ),
            cast_to=AirTaskingOrderFull,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[AirtaskingorderAbridged, AsyncOffsetPage[AirtaskingorderAbridged]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/airtaskingorder",
            page=AsyncOffsetPage[AirtaskingorderAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_list_params.AirTaskingOrderListParams,
                ),
            ),
            model=AirtaskingorderAbridged,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/airtaskingorder/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_count_params.AirTaskingOrderCountParams,
                ),
            ),
            cast_to=str,
        )

    async def query_help(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderQueryHelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/airtaskingorder/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AirTaskingOrderQueryHelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AirTaskingOrderTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/airtaskingorder/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    air_tasking_order_tuple_params.AirTaskingOrderTupleParams,
                ),
            ),
            cast_to=AirTaskingOrderTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[air_tasking_order_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple airtaskingorder records as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-airtaskingorder",
            body=await async_maybe_transform(body, Iterable[air_tasking_order_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AirTaskingOrdersResourceWithRawResponse:
    def __init__(self, air_tasking_orders: AirTaskingOrdersResource) -> None:
        self._air_tasking_orders = air_tasking_orders

        self.create = to_raw_response_wrapper(
            air_tasking_orders.create,
        )
        self.retrieve = to_raw_response_wrapper(
            air_tasking_orders.retrieve,
        )
        self.list = to_raw_response_wrapper(
            air_tasking_orders.list,
        )
        self.count = to_raw_response_wrapper(
            air_tasking_orders.count,
        )
        self.query_help = to_raw_response_wrapper(
            air_tasking_orders.query_help,
        )
        self.tuple = to_raw_response_wrapper(
            air_tasking_orders.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            air_tasking_orders.unvalidated_publish,
        )


class AsyncAirTaskingOrdersResourceWithRawResponse:
    def __init__(self, air_tasking_orders: AsyncAirTaskingOrdersResource) -> None:
        self._air_tasking_orders = air_tasking_orders

        self.create = async_to_raw_response_wrapper(
            air_tasking_orders.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            air_tasking_orders.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            air_tasking_orders.list,
        )
        self.count = async_to_raw_response_wrapper(
            air_tasking_orders.count,
        )
        self.query_help = async_to_raw_response_wrapper(
            air_tasking_orders.query_help,
        )
        self.tuple = async_to_raw_response_wrapper(
            air_tasking_orders.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            air_tasking_orders.unvalidated_publish,
        )


class AirTaskingOrdersResourceWithStreamingResponse:
    def __init__(self, air_tasking_orders: AirTaskingOrdersResource) -> None:
        self._air_tasking_orders = air_tasking_orders

        self.create = to_streamed_response_wrapper(
            air_tasking_orders.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            air_tasking_orders.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            air_tasking_orders.list,
        )
        self.count = to_streamed_response_wrapper(
            air_tasking_orders.count,
        )
        self.query_help = to_streamed_response_wrapper(
            air_tasking_orders.query_help,
        )
        self.tuple = to_streamed_response_wrapper(
            air_tasking_orders.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            air_tasking_orders.unvalidated_publish,
        )


class AsyncAirTaskingOrdersResourceWithStreamingResponse:
    def __init__(self, air_tasking_orders: AsyncAirTaskingOrdersResource) -> None:
        self._air_tasking_orders = air_tasking_orders

        self.create = async_to_streamed_response_wrapper(
            air_tasking_orders.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            air_tasking_orders.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            air_tasking_orders.list,
        )
        self.count = async_to_streamed_response_wrapper(
            air_tasking_orders.count,
        )
        self.query_help = async_to_streamed_response_wrapper(
            air_tasking_orders.query_help,
        )
        self.tuple = async_to_streamed_response_wrapper(
            air_tasking_orders.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            air_tasking_orders.unvalidated_publish,
        )
