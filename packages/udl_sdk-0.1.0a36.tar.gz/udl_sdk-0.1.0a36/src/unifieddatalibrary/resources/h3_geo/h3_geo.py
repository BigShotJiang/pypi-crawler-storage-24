# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    h3_geo_get_params,
    h3_geo_list_params,
    h3_geo_count_params,
    h3_geo_tuple_params,
    h3_geo_create_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.h3_geo_get_response import H3GeoGetResponse
from ...types.h3_geo_list_response import H3GeoListResponse
from ...types.h3_geo_tuple_response import H3GeoTupleResponse
from ...types.h3_geo_queryhelp_response import H3GeoQueryhelpResponse

__all__ = ["H3GeoResource", "AsyncH3GeoResource"]


class H3GeoResource(SyncAPIResource):
    """
    These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
    """

    @cached_property
    def history(self) -> HistoryResource:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> H3GeoResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return H3GeoResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> H3GeoResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return H3GeoResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        cells: Iterable[h3_geo_create_params.Cell],
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        num_cells: int,
        source: str,
        start_time: Union[str, datetime],
        id: str | Omit = omit,
        center_freq: float | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        origin: str | Omit = omit,
        resolution: int | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single H3Geo record as a POST body and ingest into
        the database. This operation does not persist any H3GeoHexCell points that may
        be present in the body of the request. This operation is not intended to be used
        for automated feeds into UDL. Data providers should contact the UDL team for
        specific role assignments and for instructions on setting up a permanent feed
        through an alternate mechanism.

        Args:
          cells: The collection of hex cells contained in this H3 data set. The number of cells
              is a function of the specified resolution.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          num_cells: The number of cells associated with this H3 Geo data set. At this time, UDL
              supports up to 50,000 cells.

          source: Source of the data.

          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.

          id: Unique identifier of the record, auto-generated by the system.

          center_freq: The center frequency of this H3 Geo data set measured in megahertz.

          end_time: End time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          resolution: H3 resolution (0 – 15) for the data set. At this time, UDL supports a resolution
              of 3 or less.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          type: An optional field containing the type of data that is represented by this H3 Geo
              data set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/h3geo",
            body=maybe_transform(
                {
                    "cells": cells,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "num_cells": num_cells,
                    "source": source,
                    "start_time": start_time,
                    "id": id,
                    "center_freq": center_freq,
                    "end_time": end_time,
                    "origin": origin,
                    "resolution": resolution,
                    "tags": tags,
                    "type": type,
                },
                h3_geo_create_params.H3GeoCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[H3GeoListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/h3geo",
            page=SyncOffsetPage[H3GeoListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_list_params.H3GeoListParams,
                ),
            ),
            model=H3GeoListResponse,
        )

    def count(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/h3geo/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_count_params.H3GeoCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoGetResponse:
        """
        Service operation to get a single RF geolocation by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/h3geo/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_get_params.H3GeoGetParams,
                ),
            ),
            cast_to=H3GeoGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/h3geo/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=H3GeoQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/h3geo/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_tuple_params.H3GeoTupleParams,
                ),
            ),
            cast_to=H3GeoTupleResponse,
        )


class AsyncH3GeoResource(AsyncAPIResource):
    """
    These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
    """

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncH3GeoResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncH3GeoResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncH3GeoResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncH3GeoResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        cells: Iterable[h3_geo_create_params.Cell],
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        num_cells: int,
        source: str,
        start_time: Union[str, datetime],
        id: str | Omit = omit,
        center_freq: float | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        origin: str | Omit = omit,
        resolution: int | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single H3Geo record as a POST body and ingest into
        the database. This operation does not persist any H3GeoHexCell points that may
        be present in the body of the request. This operation is not intended to be used
        for automated feeds into UDL. Data providers should contact the UDL team for
        specific role assignments and for instructions on setting up a permanent feed
        through an alternate mechanism.

        Args:
          cells: The collection of hex cells contained in this H3 data set. The number of cells
              is a function of the specified resolution.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          num_cells: The number of cells associated with this H3 Geo data set. At this time, UDL
              supports up to 50,000 cells.

          source: Source of the data.

          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.

          id: Unique identifier of the record, auto-generated by the system.

          center_freq: The center frequency of this H3 Geo data set measured in megahertz.

          end_time: End time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          resolution: H3 resolution (0 – 15) for the data set. At this time, UDL supports a resolution
              of 3 or less.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          type: An optional field containing the type of data that is represented by this H3 Geo
              data set.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/h3geo",
            body=await async_maybe_transform(
                {
                    "cells": cells,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "num_cells": num_cells,
                    "source": source,
                    "start_time": start_time,
                    "id": id,
                    "center_freq": center_freq,
                    "end_time": end_time,
                    "origin": origin,
                    "resolution": resolution,
                    "tags": tags,
                    "type": type,
                },
                h3_geo_create_params.H3GeoCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[H3GeoListResponse, AsyncOffsetPage[H3GeoListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/h3geo",
            page=AsyncOffsetPage[H3GeoListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_list_params.H3GeoListParams,
                ),
            ),
            model=H3GeoListResponse,
        )

    async def count(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/h3geo/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_count_params.H3GeoCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoGetResponse:
        """
        Service operation to get a single RF geolocation by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/h3geo/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_get_params.H3GeoGetParams,
                ),
            ),
            cast_to=H3GeoGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/h3geo/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=H3GeoQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> H3GeoTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          start_time: Start time for this H3 Geo data set in ISO 8601 UTC with millisecond precision.
              (YYYY-MM-DDTHH:MM:SS.sssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/h3geo/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    h3_geo_tuple_params.H3GeoTupleParams,
                ),
            ),
            cast_to=H3GeoTupleResponse,
        )


class H3GeoResourceWithRawResponse:
    def __init__(self, h3_geo: H3GeoResource) -> None:
        self._h3_geo = h3_geo

        self.create = to_raw_response_wrapper(
            h3_geo.create,
        )
        self.list = to_raw_response_wrapper(
            h3_geo.list,
        )
        self.count = to_raw_response_wrapper(
            h3_geo.count,
        )
        self.get = to_raw_response_wrapper(
            h3_geo.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            h3_geo.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            h3_geo.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return HistoryResourceWithRawResponse(self._h3_geo.history)


class AsyncH3GeoResourceWithRawResponse:
    def __init__(self, h3_geo: AsyncH3GeoResource) -> None:
        self._h3_geo = h3_geo

        self.create = async_to_raw_response_wrapper(
            h3_geo.create,
        )
        self.list = async_to_raw_response_wrapper(
            h3_geo.list,
        )
        self.count = async_to_raw_response_wrapper(
            h3_geo.count,
        )
        self.get = async_to_raw_response_wrapper(
            h3_geo.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            h3_geo.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            h3_geo.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return AsyncHistoryResourceWithRawResponse(self._h3_geo.history)


class H3GeoResourceWithStreamingResponse:
    def __init__(self, h3_geo: H3GeoResource) -> None:
        self._h3_geo = h3_geo

        self.create = to_streamed_response_wrapper(
            h3_geo.create,
        )
        self.list = to_streamed_response_wrapper(
            h3_geo.list,
        )
        self.count = to_streamed_response_wrapper(
            h3_geo.count,
        )
        self.get = to_streamed_response_wrapper(
            h3_geo.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            h3_geo.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            h3_geo.tuple,
        )

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return HistoryResourceWithStreamingResponse(self._h3_geo.history)


class AsyncH3GeoResourceWithStreamingResponse:
    def __init__(self, h3_geo: AsyncH3GeoResource) -> None:
        self._h3_geo = h3_geo

        self.create = async_to_streamed_response_wrapper(
            h3_geo.create,
        )
        self.list = async_to_streamed_response_wrapper(
            h3_geo.list,
        )
        self.count = async_to_streamed_response_wrapper(
            h3_geo.count,
        )
        self.get = async_to_streamed_response_wrapper(
            h3_geo.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            h3_geo.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            h3_geo.tuple,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """
        These services provide operations for manipulation and querying of Report and Activity information. This information includes analytic reports, significant events, route statistics, EMI Reports, and other georeferenced reports and activities.
        """
        return AsyncHistoryResourceWithStreamingResponse(self._h3_geo.history)
