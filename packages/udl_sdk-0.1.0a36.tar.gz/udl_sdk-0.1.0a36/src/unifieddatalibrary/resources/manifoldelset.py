# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    manifoldelset_get_params,
    manifoldelset_list_params,
    manifoldelset_count_params,
    manifoldelset_tuple_params,
    manifoldelset_create_params,
    manifoldelset_update_params,
    manifoldelset_create_bulk_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.manifoldelset_get_response import ManifoldelsetGetResponse
from ..types.manifoldelset_list_response import ManifoldelsetListResponse
from ..types.manifoldelset_tuple_response import ManifoldelsetTupleResponse
from ..types.manifoldelset_queryhelp_response import ManifoldelsetQueryhelpResponse

__all__ = ["ManifoldelsetResource", "AsyncManifoldelsetResource"]


class ManifoldelsetResource(SyncAPIResource):
    """
    These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
    """

    @cached_property
    def with_raw_response(self) -> ManifoldelsetResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return ManifoldelsetResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ManifoldelsetResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return ManifoldelsetResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        epoch: Union[str, datetime],
        id_manifold: str,
        source: str,
        tmp_sat_no: int,
        id: str | Omit = omit,
        apogee: float | Omit = omit,
        arg_of_perigee: float | Omit = omit,
        b_star: float | Omit = omit,
        eccentricity: float | Omit = omit,
        inclination: float | Omit = omit,
        mean_anomaly: float | Omit = omit,
        mean_motion: float | Omit = omit,
        mean_motion_d_dot: float | Omit = omit,
        mean_motion_dot: float | Omit = omit,
        origin: str | Omit = omit,
        perigee: float | Omit = omit,
        period: float | Omit = omit,
        raan: float | Omit = omit,
        rev_no: int | Omit = omit,
        semi_major_axis: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single ManifoldElset as a POST body and ingest into
        the database. A ManifoldElset represents theoretical Keplarian orbital elements
        belonging to an object of interest's manifold describing a possible/theoretical
        orbit for an object of interest for tasking purposes. A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.

          id_manifold: Identifier of the parent Manifold record.

          source: Source of the data.

          tmp_sat_no: A placeholder satellite number and not a true NORAD catalog number.

          id: Unique identifier of the record, auto-generated by the system.

          apogee: The Orbit point furthest from the center of the earth in kilometers.

          arg_of_perigee: The argument of perigee is the angle in degrees formed between the perigee and
              the ascending node. If the perigee would occur at the ascending node, the
              argument of perigee would be 0.

          b_star: The drag term for SGP4 orbital model, used for calculating decay constants for
              altitude, eccentricity etc, measured in inverse earth radii.

          eccentricity: The orbital eccentricity of an astronomical object is a parameter that
              determines the amount by which its orbit around another body deviates from a
              perfect circle. A value of 0 is a circular orbit, values between 0 and 1 form an
              elliptic orbit, 1 is a parabolic escape orbit, and greater than 1 is a
              hyperbolic escape orbit.

          inclination: The angle between the equator and the orbit when looking from the center of the
              Earth. If the orbit went exactly around the equator from left to right, then the
              inclination would be 0. The inclination ranges from 0 to 180 degrees.

          mean_anomaly: Where the satellite is in its orbital path. The mean anomaly ranges from 0 to
              360 degrees. The mean anomaly is referenced to the perigee. If the satellite
              were at the perigee, the mean anomaly would be 0.

          mean_motion: The constant angular speed required for the body to complete one circular orbit
              in the same amount of time as the actual elliptical orbit with variable speed.
              Measured in revolutions per day.

          mean_motion_d_dot: 2nd derivative of the mean motion with respect to time. Units are revolutions
              per day cubed.

          mean_motion_dot: 1st derivative of the mean motion with respect to time. Units are revolutions
              per day squared.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          perigee: The orbit point nearest to the center of the earth in kilometers.

          period: Period of the orbit equal to inverse of mean motion.

          raan: Right ascension of the ascending node, or RAAN is the angle as measured in
              degrees eastwards (or, as seen from the north, counterclockwise) from the First
              Point of Aries to the ascending node, which is where the orbit crosses the
              equator when traveling north.

          rev_no: The current revolution number. The value is incremented when a satellite crosses
              the equator on an ascending pass.

          semi_major_axis: The sum of the periapsis and apoapsis distances divided by two. For circular
              orbits, the semimajor axis is the distance between the centers of the bodies,
              not the distance of the bodies from the center of mass.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/manifoldelset",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "epoch": epoch,
                    "id_manifold": id_manifold,
                    "source": source,
                    "tmp_sat_no": tmp_sat_no,
                    "id": id,
                    "apogee": apogee,
                    "arg_of_perigee": arg_of_perigee,
                    "b_star": b_star,
                    "eccentricity": eccentricity,
                    "inclination": inclination,
                    "mean_anomaly": mean_anomaly,
                    "mean_motion": mean_motion,
                    "mean_motion_d_dot": mean_motion_d_dot,
                    "mean_motion_dot": mean_motion_dot,
                    "origin": origin,
                    "perigee": perigee,
                    "period": period,
                    "raan": raan,
                    "rev_no": rev_no,
                    "semi_major_axis": semi_major_axis,
                },
                manifoldelset_create_params.ManifoldelsetCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        epoch: Union[str, datetime],
        id_manifold: str,
        source: str,
        tmp_sat_no: int,
        body_id: str | Omit = omit,
        apogee: float | Omit = omit,
        arg_of_perigee: float | Omit = omit,
        b_star: float | Omit = omit,
        eccentricity: float | Omit = omit,
        inclination: float | Omit = omit,
        mean_anomaly: float | Omit = omit,
        mean_motion: float | Omit = omit,
        mean_motion_d_dot: float | Omit = omit,
        mean_motion_dot: float | Omit = omit,
        origin: str | Omit = omit,
        perigee: float | Omit = omit,
        period: float | Omit = omit,
        raan: float | Omit = omit,
        rev_no: int | Omit = omit,
        semi_major_axis: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single ManifoldElset.

        A ManifoldElset represents
        theoretical Keplarian orbital elements belonging to an object of interest's
        manifold describing a possible/theoretical orbit for an object of interest for
        tasking purposes. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.

          id_manifold: Identifier of the parent Manifold record.

          source: Source of the data.

          tmp_sat_no: A placeholder satellite number and not a true NORAD catalog number.

          body_id: Unique identifier of the record, auto-generated by the system.

          apogee: The Orbit point furthest from the center of the earth in kilometers.

          arg_of_perigee: The argument of perigee is the angle in degrees formed between the perigee and
              the ascending node. If the perigee would occur at the ascending node, the
              argument of perigee would be 0.

          b_star: The drag term for SGP4 orbital model, used for calculating decay constants for
              altitude, eccentricity etc, measured in inverse earth radii.

          eccentricity: The orbital eccentricity of an astronomical object is a parameter that
              determines the amount by which its orbit around another body deviates from a
              perfect circle. A value of 0 is a circular orbit, values between 0 and 1 form an
              elliptic orbit, 1 is a parabolic escape orbit, and greater than 1 is a
              hyperbolic escape orbit.

          inclination: The angle between the equator and the orbit when looking from the center of the
              Earth. If the orbit went exactly around the equator from left to right, then the
              inclination would be 0. The inclination ranges from 0 to 180 degrees.

          mean_anomaly: Where the satellite is in its orbital path. The mean anomaly ranges from 0 to
              360 degrees. The mean anomaly is referenced to the perigee. If the satellite
              were at the perigee, the mean anomaly would be 0.

          mean_motion: The constant angular speed required for the body to complete one circular orbit
              in the same amount of time as the actual elliptical orbit with variable speed.
              Measured in revolutions per day.

          mean_motion_d_dot: 2nd derivative of the mean motion with respect to time. Units are revolutions
              per day cubed.

          mean_motion_dot: 1st derivative of the mean motion with respect to time. Units are revolutions
              per day squared.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          perigee: The orbit point nearest to the center of the earth in kilometers.

          period: Period of the orbit equal to inverse of mean motion.

          raan: Right ascension of the ascending node, or RAAN is the angle as measured in
              degrees eastwards (or, as seen from the north, counterclockwise) from the First
              Point of Aries to the ascending node, which is where the orbit crosses the
              equator when traveling north.

          rev_no: The current revolution number. The value is incremented when a satellite crosses
              the equator on an ascending pass.

          semi_major_axis: The sum of the periapsis and apoapsis distances divided by two. For circular
              orbits, the semimajor axis is the distance between the centers of the bodies,
              not the distance of the bodies from the center of mass.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/manifoldelset/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "epoch": epoch,
                    "id_manifold": id_manifold,
                    "source": source,
                    "tmp_sat_no": tmp_sat_no,
                    "body_id": body_id,
                    "apogee": apogee,
                    "arg_of_perigee": arg_of_perigee,
                    "b_star": b_star,
                    "eccentricity": eccentricity,
                    "inclination": inclination,
                    "mean_anomaly": mean_anomaly,
                    "mean_motion": mean_motion,
                    "mean_motion_d_dot": mean_motion_d_dot,
                    "mean_motion_dot": mean_motion_dot,
                    "origin": origin,
                    "perigee": perigee,
                    "period": period,
                    "raan": raan,
                    "rev_no": rev_no,
                    "semi_major_axis": semi_major_axis,
                },
                manifoldelset_update_params.ManifoldelsetUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[ManifoldelsetListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/manifoldelset",
            page=SyncOffsetPage[ManifoldelsetListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_list_params.ManifoldelsetListParams,
                ),
            ),
            model=ManifoldelsetListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a ManifoldElset object specified by the passed ID
        path parameter. A ManifoldElset represents theoretical Keplarian orbital
        elements belonging to an object of interest's manifold describing a
        possible/theoretical orbit for an object of interest for tasking purposes. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/manifoldelset/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/manifoldelset/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_count_params.ManifoldelsetCountParams,
                ),
            ),
            cast_to=str,
        )

    def create_bulk(
        self,
        *,
        body: Iterable[manifoldelset_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple ManifoldElsets as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/manifoldelset/createBulk",
            body=maybe_transform(body, Iterable[manifoldelset_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetGetResponse:
        """
        Service operation to get a single ManifoldElset record by its unique ID passed
        as a path parameter. A ManifoldElset represents theoretical Keplarian orbital
        elements belonging to an object of interest's manifold describing a
        possible/theoretical orbit for an object of interest for tasking purposes.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/manifoldelset/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_get_params.ManifoldelsetGetParams,
                ),
            ),
            cast_to=ManifoldelsetGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/manifoldelset/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ManifoldelsetQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/manifoldelset/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_tuple_params.ManifoldelsetTupleParams,
                ),
            ),
            cast_to=ManifoldelsetTupleResponse,
        )


class AsyncManifoldelsetResource(AsyncAPIResource):
    """
    These services provide operations for manipulation and querying of on-orbit objects of interest, their components, and various lists and status of those objects.
    """

    @cached_property
    def with_raw_response(self) -> AsyncManifoldelsetResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncManifoldelsetResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncManifoldelsetResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncManifoldelsetResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        epoch: Union[str, datetime],
        id_manifold: str,
        source: str,
        tmp_sat_no: int,
        id: str | Omit = omit,
        apogee: float | Omit = omit,
        arg_of_perigee: float | Omit = omit,
        b_star: float | Omit = omit,
        eccentricity: float | Omit = omit,
        inclination: float | Omit = omit,
        mean_anomaly: float | Omit = omit,
        mean_motion: float | Omit = omit,
        mean_motion_d_dot: float | Omit = omit,
        mean_motion_dot: float | Omit = omit,
        origin: str | Omit = omit,
        perigee: float | Omit = omit,
        period: float | Omit = omit,
        raan: float | Omit = omit,
        rev_no: int | Omit = omit,
        semi_major_axis: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single ManifoldElset as a POST body and ingest into
        the database. A ManifoldElset represents theoretical Keplarian orbital elements
        belonging to an object of interest's manifold describing a possible/theoretical
        orbit for an object of interest for tasking purposes. A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.

          id_manifold: Identifier of the parent Manifold record.

          source: Source of the data.

          tmp_sat_no: A placeholder satellite number and not a true NORAD catalog number.

          id: Unique identifier of the record, auto-generated by the system.

          apogee: The Orbit point furthest from the center of the earth in kilometers.

          arg_of_perigee: The argument of perigee is the angle in degrees formed between the perigee and
              the ascending node. If the perigee would occur at the ascending node, the
              argument of perigee would be 0.

          b_star: The drag term for SGP4 orbital model, used for calculating decay constants for
              altitude, eccentricity etc, measured in inverse earth radii.

          eccentricity: The orbital eccentricity of an astronomical object is a parameter that
              determines the amount by which its orbit around another body deviates from a
              perfect circle. A value of 0 is a circular orbit, values between 0 and 1 form an
              elliptic orbit, 1 is a parabolic escape orbit, and greater than 1 is a
              hyperbolic escape orbit.

          inclination: The angle between the equator and the orbit when looking from the center of the
              Earth. If the orbit went exactly around the equator from left to right, then the
              inclination would be 0. The inclination ranges from 0 to 180 degrees.

          mean_anomaly: Where the satellite is in its orbital path. The mean anomaly ranges from 0 to
              360 degrees. The mean anomaly is referenced to the perigee. If the satellite
              were at the perigee, the mean anomaly would be 0.

          mean_motion: The constant angular speed required for the body to complete one circular orbit
              in the same amount of time as the actual elliptical orbit with variable speed.
              Measured in revolutions per day.

          mean_motion_d_dot: 2nd derivative of the mean motion with respect to time. Units are revolutions
              per day cubed.

          mean_motion_dot: 1st derivative of the mean motion with respect to time. Units are revolutions
              per day squared.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          perigee: The orbit point nearest to the center of the earth in kilometers.

          period: Period of the orbit equal to inverse of mean motion.

          raan: Right ascension of the ascending node, or RAAN is the angle as measured in
              degrees eastwards (or, as seen from the north, counterclockwise) from the First
              Point of Aries to the ascending node, which is where the orbit crosses the
              equator when traveling north.

          rev_no: The current revolution number. The value is incremented when a satellite crosses
              the equator on an ascending pass.

          semi_major_axis: The sum of the periapsis and apoapsis distances divided by two. For circular
              orbits, the semimajor axis is the distance between the centers of the bodies,
              not the distance of the bodies from the center of mass.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/manifoldelset",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "epoch": epoch,
                    "id_manifold": id_manifold,
                    "source": source,
                    "tmp_sat_no": tmp_sat_no,
                    "id": id,
                    "apogee": apogee,
                    "arg_of_perigee": arg_of_perigee,
                    "b_star": b_star,
                    "eccentricity": eccentricity,
                    "inclination": inclination,
                    "mean_anomaly": mean_anomaly,
                    "mean_motion": mean_motion,
                    "mean_motion_d_dot": mean_motion_d_dot,
                    "mean_motion_dot": mean_motion_dot,
                    "origin": origin,
                    "perigee": perigee,
                    "period": period,
                    "raan": raan,
                    "rev_no": rev_no,
                    "semi_major_axis": semi_major_axis,
                },
                manifoldelset_create_params.ManifoldelsetCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        epoch: Union[str, datetime],
        id_manifold: str,
        source: str,
        tmp_sat_no: int,
        body_id: str | Omit = omit,
        apogee: float | Omit = omit,
        arg_of_perigee: float | Omit = omit,
        b_star: float | Omit = omit,
        eccentricity: float | Omit = omit,
        inclination: float | Omit = omit,
        mean_anomaly: float | Omit = omit,
        mean_motion: float | Omit = omit,
        mean_motion_d_dot: float | Omit = omit,
        mean_motion_dot: float | Omit = omit,
        origin: str | Omit = omit,
        perigee: float | Omit = omit,
        period: float | Omit = omit,
        raan: float | Omit = omit,
        rev_no: int | Omit = omit,
        semi_major_axis: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single ManifoldElset.

        A ManifoldElset represents
        theoretical Keplarian orbital elements belonging to an object of interest's
        manifold describing a possible/theoretical orbit for an object of interest for
        tasking purposes. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.

          id_manifold: Identifier of the parent Manifold record.

          source: Source of the data.

          tmp_sat_no: A placeholder satellite number and not a true NORAD catalog number.

          body_id: Unique identifier of the record, auto-generated by the system.

          apogee: The Orbit point furthest from the center of the earth in kilometers.

          arg_of_perigee: The argument of perigee is the angle in degrees formed between the perigee and
              the ascending node. If the perigee would occur at the ascending node, the
              argument of perigee would be 0.

          b_star: The drag term for SGP4 orbital model, used for calculating decay constants for
              altitude, eccentricity etc, measured in inverse earth radii.

          eccentricity: The orbital eccentricity of an astronomical object is a parameter that
              determines the amount by which its orbit around another body deviates from a
              perfect circle. A value of 0 is a circular orbit, values between 0 and 1 form an
              elliptic orbit, 1 is a parabolic escape orbit, and greater than 1 is a
              hyperbolic escape orbit.

          inclination: The angle between the equator and the orbit when looking from the center of the
              Earth. If the orbit went exactly around the equator from left to right, then the
              inclination would be 0. The inclination ranges from 0 to 180 degrees.

          mean_anomaly: Where the satellite is in its orbital path. The mean anomaly ranges from 0 to
              360 degrees. The mean anomaly is referenced to the perigee. If the satellite
              were at the perigee, the mean anomaly would be 0.

          mean_motion: The constant angular speed required for the body to complete one circular orbit
              in the same amount of time as the actual elliptical orbit with variable speed.
              Measured in revolutions per day.

          mean_motion_d_dot: 2nd derivative of the mean motion with respect to time. Units are revolutions
              per day cubed.

          mean_motion_dot: 1st derivative of the mean motion with respect to time. Units are revolutions
              per day squared.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          perigee: The orbit point nearest to the center of the earth in kilometers.

          period: Period of the orbit equal to inverse of mean motion.

          raan: Right ascension of the ascending node, or RAAN is the angle as measured in
              degrees eastwards (or, as seen from the north, counterclockwise) from the First
              Point of Aries to the ascending node, which is where the orbit crosses the
              equator when traveling north.

          rev_no: The current revolution number. The value is incremented when a satellite crosses
              the equator on an ascending pass.

          semi_major_axis: The sum of the periapsis and apoapsis distances divided by two. For circular
              orbits, the semimajor axis is the distance between the centers of the bodies,
              not the distance of the bodies from the center of mass.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/manifoldelset/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "epoch": epoch,
                    "id_manifold": id_manifold,
                    "source": source,
                    "tmp_sat_no": tmp_sat_no,
                    "body_id": body_id,
                    "apogee": apogee,
                    "arg_of_perigee": arg_of_perigee,
                    "b_star": b_star,
                    "eccentricity": eccentricity,
                    "inclination": inclination,
                    "mean_anomaly": mean_anomaly,
                    "mean_motion": mean_motion,
                    "mean_motion_d_dot": mean_motion_d_dot,
                    "mean_motion_dot": mean_motion_dot,
                    "origin": origin,
                    "perigee": perigee,
                    "period": period,
                    "raan": raan,
                    "rev_no": rev_no,
                    "semi_major_axis": semi_major_axis,
                },
                manifoldelset_update_params.ManifoldelsetUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[ManifoldelsetListResponse, AsyncOffsetPage[ManifoldelsetListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/manifoldelset",
            page=AsyncOffsetPage[ManifoldelsetListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_list_params.ManifoldelsetListParams,
                ),
            ),
            model=ManifoldelsetListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a ManifoldElset object specified by the passed ID
        path parameter. A ManifoldElset represents theoretical Keplarian orbital
        elements belonging to an object of interest's manifold describing a
        possible/theoretical orbit for an object of interest for tasking purposes. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/manifoldelset/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/manifoldelset/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_count_params.ManifoldelsetCountParams,
                ),
            ),
            cast_to=str,
        )

    async def create_bulk(
        self,
        *,
        body: Iterable[manifoldelset_create_bulk_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take multiple ManifoldElsets as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/manifoldelset/createBulk",
            body=await async_maybe_transform(body, Iterable[manifoldelset_create_bulk_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetGetResponse:
        """
        Service operation to get a single ManifoldElset record by its unique ID passed
        as a path parameter. A ManifoldElset represents theoretical Keplarian orbital
        elements belonging to an object of interest's manifold describing a
        possible/theoretical orbit for an object of interest for tasking purposes.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/manifoldelset/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_get_params.ManifoldelsetGetParams,
                ),
            ),
            cast_to=ManifoldelsetGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/manifoldelset/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ManifoldelsetQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        epoch: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ManifoldelsetTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          epoch: Elset epoch time in ISO 8601 UTC format, with microsecond precision.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/manifoldelset/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "epoch": epoch,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    manifoldelset_tuple_params.ManifoldelsetTupleParams,
                ),
            ),
            cast_to=ManifoldelsetTupleResponse,
        )


class ManifoldelsetResourceWithRawResponse:
    def __init__(self, manifoldelset: ManifoldelsetResource) -> None:
        self._manifoldelset = manifoldelset

        self.create = to_raw_response_wrapper(
            manifoldelset.create,
        )
        self.update = to_raw_response_wrapper(
            manifoldelset.update,
        )
        self.list = to_raw_response_wrapper(
            manifoldelset.list,
        )
        self.delete = to_raw_response_wrapper(
            manifoldelset.delete,
        )
        self.count = to_raw_response_wrapper(
            manifoldelset.count,
        )
        self.create_bulk = to_raw_response_wrapper(
            manifoldelset.create_bulk,
        )
        self.get = to_raw_response_wrapper(
            manifoldelset.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            manifoldelset.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            manifoldelset.tuple,
        )


class AsyncManifoldelsetResourceWithRawResponse:
    def __init__(self, manifoldelset: AsyncManifoldelsetResource) -> None:
        self._manifoldelset = manifoldelset

        self.create = async_to_raw_response_wrapper(
            manifoldelset.create,
        )
        self.update = async_to_raw_response_wrapper(
            manifoldelset.update,
        )
        self.list = async_to_raw_response_wrapper(
            manifoldelset.list,
        )
        self.delete = async_to_raw_response_wrapper(
            manifoldelset.delete,
        )
        self.count = async_to_raw_response_wrapper(
            manifoldelset.count,
        )
        self.create_bulk = async_to_raw_response_wrapper(
            manifoldelset.create_bulk,
        )
        self.get = async_to_raw_response_wrapper(
            manifoldelset.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            manifoldelset.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            manifoldelset.tuple,
        )


class ManifoldelsetResourceWithStreamingResponse:
    def __init__(self, manifoldelset: ManifoldelsetResource) -> None:
        self._manifoldelset = manifoldelset

        self.create = to_streamed_response_wrapper(
            manifoldelset.create,
        )
        self.update = to_streamed_response_wrapper(
            manifoldelset.update,
        )
        self.list = to_streamed_response_wrapper(
            manifoldelset.list,
        )
        self.delete = to_streamed_response_wrapper(
            manifoldelset.delete,
        )
        self.count = to_streamed_response_wrapper(
            manifoldelset.count,
        )
        self.create_bulk = to_streamed_response_wrapper(
            manifoldelset.create_bulk,
        )
        self.get = to_streamed_response_wrapper(
            manifoldelset.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            manifoldelset.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            manifoldelset.tuple,
        )


class AsyncManifoldelsetResourceWithStreamingResponse:
    def __init__(self, manifoldelset: AsyncManifoldelsetResource) -> None:
        self._manifoldelset = manifoldelset

        self.create = async_to_streamed_response_wrapper(
            manifoldelset.create,
        )
        self.update = async_to_streamed_response_wrapper(
            manifoldelset.update,
        )
        self.list = async_to_streamed_response_wrapper(
            manifoldelset.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            manifoldelset.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            manifoldelset.count,
        )
        self.create_bulk = async_to_streamed_response_wrapper(
            manifoldelset.create_bulk,
        )
        self.get = async_to_streamed_response_wrapper(
            manifoldelset.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            manifoldelset.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            manifoldelset.tuple,
        )
