# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    seradata_optical_payload_get_params,
    seradata_optical_payload_list_params,
    seradata_optical_payload_count_params,
    seradata_optical_payload_tuple_params,
    seradata_optical_payload_create_params,
    seradata_optical_payload_update_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.seradata_optical_payload_get_response import SeradataOpticalPayloadGetResponse
from ..types.seradata_optical_payload_list_response import SeradataOpticalPayloadListResponse
from ..types.seradata_optical_payload_tuple_response import SeradataOpticalPayloadTupleResponse
from ..types.seradata_optical_payload_queryhelp_response import SeradataOpticalPayloadQueryhelpResponse

__all__ = ["SeradataOpticalPayloadResource", "AsyncSeradataOpticalPayloadResource"]


class SeradataOpticalPayloadResource(SyncAPIResource):
    """This service provides operations for querying and manipulation of sensor data.

    Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
    """

    @cached_property
    def with_raw_response(self) -> SeradataOpticalPayloadResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SeradataOpticalPayloadResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SeradataOpticalPayloadResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return SeradataOpticalPayloadResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        spacecraft_id: str,
        id: str | Omit = omit,
        best_resolution: float | Omit = omit,
        field_of_regard: float | Omit = omit,
        field_of_view: float | Omit = omit,
        ground_station_locations: str | Omit = omit,
        ground_stations: str | Omit = omit,
        hosted_for_company_org_id: str | Omit = omit,
        id_sensor: str | Omit = omit,
        imaging_payload_category: str | Omit = omit,
        manufacturer_org_id: str | Omit = omit,
        name: str | Omit = omit,
        notes: str | Omit = omit,
        number_of_film_return_canisters: int | Omit = omit,
        origin: str | Omit = omit,
        pointing_method: str | Omit = omit,
        recorder_size: str | Omit = omit,
        spectral_band: str | Omit = omit,
        spectral_frequency_limits: str | Omit = omit,
        swath_width: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single SeradataOpticalPayload as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          spacecraft_id: Seradata ID of the spacecraft (SeradataSpacecraftDetails ID).

          id: Unique identifier of the record, auto-generated by the system.

          best_resolution: Best resolution.

          field_of_regard: Field of regard of this radar in degrees.

          field_of_view: Field of view of this radar in kilometers.

          ground_station_locations: Ground Station Locations for this payload.

          ground_stations: Ground Station info for this payload.

          hosted_for_company_org_id: Hosted for company/Organization Id.

          id_sensor: UUID of the Sensor record.

          imaging_payload_category: Imaging category for this payload, e.g. Multispectral, Infrared, Panchromatic.

          manufacturer_org_id: Manufacturer Organization Id.

          name: Sensor name from Seradata, e.g. TOURNESOL, MESSR (Multispectral Self-Scanning
              Radiometer), AWFI, etc.

          notes: Payload notes.

          number_of_film_return_canisters: Number of film return canisters.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pointing_method: Point method for this radar, e.g. Spacecraft.

          recorder_size: Recorder size.

          spectral_band: Spectral Band supported by this payload, e.g. Green, Red, Mid-wave infrared,
              etc.

          spectral_frequency_limits: Frequency limit for this payload, e.g. 0.51 - 0.59.

          swath_width: Swath width in kilometers.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/seradataopticalpayload",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "spacecraft_id": spacecraft_id,
                    "id": id,
                    "best_resolution": best_resolution,
                    "field_of_regard": field_of_regard,
                    "field_of_view": field_of_view,
                    "ground_station_locations": ground_station_locations,
                    "ground_stations": ground_stations,
                    "hosted_for_company_org_id": hosted_for_company_org_id,
                    "id_sensor": id_sensor,
                    "imaging_payload_category": imaging_payload_category,
                    "manufacturer_org_id": manufacturer_org_id,
                    "name": name,
                    "notes": notes,
                    "number_of_film_return_canisters": number_of_film_return_canisters,
                    "origin": origin,
                    "pointing_method": pointing_method,
                    "recorder_size": recorder_size,
                    "spectral_band": spectral_band,
                    "spectral_frequency_limits": spectral_frequency_limits,
                    "swath_width": swath_width,
                },
                seradata_optical_payload_create_params.SeradataOpticalPayloadCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        spacecraft_id: str,
        body_id: str | Omit = omit,
        best_resolution: float | Omit = omit,
        field_of_regard: float | Omit = omit,
        field_of_view: float | Omit = omit,
        ground_station_locations: str | Omit = omit,
        ground_stations: str | Omit = omit,
        hosted_for_company_org_id: str | Omit = omit,
        id_sensor: str | Omit = omit,
        imaging_payload_category: str | Omit = omit,
        manufacturer_org_id: str | Omit = omit,
        name: str | Omit = omit,
        notes: str | Omit = omit,
        number_of_film_return_canisters: int | Omit = omit,
        origin: str | Omit = omit,
        pointing_method: str | Omit = omit,
        recorder_size: str | Omit = omit,
        spectral_band: str | Omit = omit,
        spectral_frequency_limits: str | Omit = omit,
        swath_width: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update an SeradataOpticalPayload.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          spacecraft_id: Seradata ID of the spacecraft (SeradataSpacecraftDetails ID).

          body_id: Unique identifier of the record, auto-generated by the system.

          best_resolution: Best resolution.

          field_of_regard: Field of regard of this radar in degrees.

          field_of_view: Field of view of this radar in kilometers.

          ground_station_locations: Ground Station Locations for this payload.

          ground_stations: Ground Station info for this payload.

          hosted_for_company_org_id: Hosted for company/Organization Id.

          id_sensor: UUID of the Sensor record.

          imaging_payload_category: Imaging category for this payload, e.g. Multispectral, Infrared, Panchromatic.

          manufacturer_org_id: Manufacturer Organization Id.

          name: Sensor name from Seradata, e.g. TOURNESOL, MESSR (Multispectral Self-Scanning
              Radiometer), AWFI, etc.

          notes: Payload notes.

          number_of_film_return_canisters: Number of film return canisters.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pointing_method: Point method for this radar, e.g. Spacecraft.

          recorder_size: Recorder size.

          spectral_band: Spectral Band supported by this payload, e.g. Green, Red, Mid-wave infrared,
              etc.

          spectral_frequency_limits: Frequency limit for this payload, e.g. 0.51 - 0.59.

          swath_width: Swath width in kilometers.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/seradataopticalpayload/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "spacecraft_id": spacecraft_id,
                    "body_id": body_id,
                    "best_resolution": best_resolution,
                    "field_of_regard": field_of_regard,
                    "field_of_view": field_of_view,
                    "ground_station_locations": ground_station_locations,
                    "ground_stations": ground_stations,
                    "hosted_for_company_org_id": hosted_for_company_org_id,
                    "id_sensor": id_sensor,
                    "imaging_payload_category": imaging_payload_category,
                    "manufacturer_org_id": manufacturer_org_id,
                    "name": name,
                    "notes": notes,
                    "number_of_film_return_canisters": number_of_film_return_canisters,
                    "origin": origin,
                    "pointing_method": pointing_method,
                    "recorder_size": recorder_size,
                    "spectral_band": spectral_band,
                    "spectral_frequency_limits": spectral_frequency_limits,
                    "swath_width": swath_width,
                },
                seradata_optical_payload_update_params.SeradataOpticalPayloadUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[SeradataOpticalPayloadListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/seradataopticalpayload",
            page=SyncOffsetPage[SeradataOpticalPayloadListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_list_params.SeradataOpticalPayloadListParams,
                ),
            ),
            model=SeradataOpticalPayloadListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete an SeradataOpticalPayload specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/seradataopticalpayload/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/seradataopticalpayload/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_count_params.SeradataOpticalPayloadCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadGetResponse:
        """
        Service operation to get a single SeradataOpticalPayload by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/seradataopticalpayload/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_get_params.SeradataOpticalPayloadGetParams,
                ),
            ),
            cast_to=SeradataOpticalPayloadGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/seradataopticalpayload/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeradataOpticalPayloadQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/seradataopticalpayload/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_tuple_params.SeradataOpticalPayloadTupleParams,
                ),
            ),
            cast_to=SeradataOpticalPayloadTupleResponse,
        )


class AsyncSeradataOpticalPayloadResource(AsyncAPIResource):
    """This service provides operations for querying and manipulation of sensor data.

    Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
    """

    @cached_property
    def with_raw_response(self) -> AsyncSeradataOpticalPayloadResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSeradataOpticalPayloadResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSeradataOpticalPayloadResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncSeradataOpticalPayloadResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        spacecraft_id: str,
        id: str | Omit = omit,
        best_resolution: float | Omit = omit,
        field_of_regard: float | Omit = omit,
        field_of_view: float | Omit = omit,
        ground_station_locations: str | Omit = omit,
        ground_stations: str | Omit = omit,
        hosted_for_company_org_id: str | Omit = omit,
        id_sensor: str | Omit = omit,
        imaging_payload_category: str | Omit = omit,
        manufacturer_org_id: str | Omit = omit,
        name: str | Omit = omit,
        notes: str | Omit = omit,
        number_of_film_return_canisters: int | Omit = omit,
        origin: str | Omit = omit,
        pointing_method: str | Omit = omit,
        recorder_size: str | Omit = omit,
        spectral_band: str | Omit = omit,
        spectral_frequency_limits: str | Omit = omit,
        swath_width: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single SeradataOpticalPayload as a POST body and
        ingest into the database. A specific role is required to perform this service
        operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          spacecraft_id: Seradata ID of the spacecraft (SeradataSpacecraftDetails ID).

          id: Unique identifier of the record, auto-generated by the system.

          best_resolution: Best resolution.

          field_of_regard: Field of regard of this radar in degrees.

          field_of_view: Field of view of this radar in kilometers.

          ground_station_locations: Ground Station Locations for this payload.

          ground_stations: Ground Station info for this payload.

          hosted_for_company_org_id: Hosted for company/Organization Id.

          id_sensor: UUID of the Sensor record.

          imaging_payload_category: Imaging category for this payload, e.g. Multispectral, Infrared, Panchromatic.

          manufacturer_org_id: Manufacturer Organization Id.

          name: Sensor name from Seradata, e.g. TOURNESOL, MESSR (Multispectral Self-Scanning
              Radiometer), AWFI, etc.

          notes: Payload notes.

          number_of_film_return_canisters: Number of film return canisters.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pointing_method: Point method for this radar, e.g. Spacecraft.

          recorder_size: Recorder size.

          spectral_band: Spectral Band supported by this payload, e.g. Green, Red, Mid-wave infrared,
              etc.

          spectral_frequency_limits: Frequency limit for this payload, e.g. 0.51 - 0.59.

          swath_width: Swath width in kilometers.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/seradataopticalpayload",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "spacecraft_id": spacecraft_id,
                    "id": id,
                    "best_resolution": best_resolution,
                    "field_of_regard": field_of_regard,
                    "field_of_view": field_of_view,
                    "ground_station_locations": ground_station_locations,
                    "ground_stations": ground_stations,
                    "hosted_for_company_org_id": hosted_for_company_org_id,
                    "id_sensor": id_sensor,
                    "imaging_payload_category": imaging_payload_category,
                    "manufacturer_org_id": manufacturer_org_id,
                    "name": name,
                    "notes": notes,
                    "number_of_film_return_canisters": number_of_film_return_canisters,
                    "origin": origin,
                    "pointing_method": pointing_method,
                    "recorder_size": recorder_size,
                    "spectral_band": spectral_band,
                    "spectral_frequency_limits": spectral_frequency_limits,
                    "swath_width": swath_width,
                },
                seradata_optical_payload_create_params.SeradataOpticalPayloadCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        spacecraft_id: str,
        body_id: str | Omit = omit,
        best_resolution: float | Omit = omit,
        field_of_regard: float | Omit = omit,
        field_of_view: float | Omit = omit,
        ground_station_locations: str | Omit = omit,
        ground_stations: str | Omit = omit,
        hosted_for_company_org_id: str | Omit = omit,
        id_sensor: str | Omit = omit,
        imaging_payload_category: str | Omit = omit,
        manufacturer_org_id: str | Omit = omit,
        name: str | Omit = omit,
        notes: str | Omit = omit,
        number_of_film_return_canisters: int | Omit = omit,
        origin: str | Omit = omit,
        pointing_method: str | Omit = omit,
        recorder_size: str | Omit = omit,
        spectral_band: str | Omit = omit,
        spectral_frequency_limits: str | Omit = omit,
        swath_width: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update an SeradataOpticalPayload.

        A specific role is
        required to perform this service operation. Please contact the UDL team for
        assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          spacecraft_id: Seradata ID of the spacecraft (SeradataSpacecraftDetails ID).

          body_id: Unique identifier of the record, auto-generated by the system.

          best_resolution: Best resolution.

          field_of_regard: Field of regard of this radar in degrees.

          field_of_view: Field of view of this radar in kilometers.

          ground_station_locations: Ground Station Locations for this payload.

          ground_stations: Ground Station info for this payload.

          hosted_for_company_org_id: Hosted for company/Organization Id.

          id_sensor: UUID of the Sensor record.

          imaging_payload_category: Imaging category for this payload, e.g. Multispectral, Infrared, Panchromatic.

          manufacturer_org_id: Manufacturer Organization Id.

          name: Sensor name from Seradata, e.g. TOURNESOL, MESSR (Multispectral Self-Scanning
              Radiometer), AWFI, etc.

          notes: Payload notes.

          number_of_film_return_canisters: Number of film return canisters.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          pointing_method: Point method for this radar, e.g. Spacecraft.

          recorder_size: Recorder size.

          spectral_band: Spectral Band supported by this payload, e.g. Green, Red, Mid-wave infrared,
              etc.

          spectral_frequency_limits: Frequency limit for this payload, e.g. 0.51 - 0.59.

          swath_width: Swath width in kilometers.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/seradataopticalpayload/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "spacecraft_id": spacecraft_id,
                    "body_id": body_id,
                    "best_resolution": best_resolution,
                    "field_of_regard": field_of_regard,
                    "field_of_view": field_of_view,
                    "ground_station_locations": ground_station_locations,
                    "ground_stations": ground_stations,
                    "hosted_for_company_org_id": hosted_for_company_org_id,
                    "id_sensor": id_sensor,
                    "imaging_payload_category": imaging_payload_category,
                    "manufacturer_org_id": manufacturer_org_id,
                    "name": name,
                    "notes": notes,
                    "number_of_film_return_canisters": number_of_film_return_canisters,
                    "origin": origin,
                    "pointing_method": pointing_method,
                    "recorder_size": recorder_size,
                    "spectral_band": spectral_band,
                    "spectral_frequency_limits": spectral_frequency_limits,
                    "swath_width": swath_width,
                },
                seradata_optical_payload_update_params.SeradataOpticalPayloadUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SeradataOpticalPayloadListResponse, AsyncOffsetPage[SeradataOpticalPayloadListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/seradataopticalpayload",
            page=AsyncOffsetPage[SeradataOpticalPayloadListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_list_params.SeradataOpticalPayloadListParams,
                ),
            ),
            model=SeradataOpticalPayloadListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete an SeradataOpticalPayload specified by the passed ID
        path parameter. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/seradataopticalpayload/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/seradataopticalpayload/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_count_params.SeradataOpticalPayloadCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadGetResponse:
        """
        Service operation to get a single SeradataOpticalPayload by its unique ID passed
        as a path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/seradataopticalpayload/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_get_params.SeradataOpticalPayloadGetParams,
                ),
            ),
            cast_to=SeradataOpticalPayloadGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/seradataopticalpayload/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SeradataOpticalPayloadQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SeradataOpticalPayloadTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/seradataopticalpayload/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    seradata_optical_payload_tuple_params.SeradataOpticalPayloadTupleParams,
                ),
            ),
            cast_to=SeradataOpticalPayloadTupleResponse,
        )


class SeradataOpticalPayloadResourceWithRawResponse:
    def __init__(self, seradata_optical_payload: SeradataOpticalPayloadResource) -> None:
        self._seradata_optical_payload = seradata_optical_payload

        self.create = to_raw_response_wrapper(
            seradata_optical_payload.create,
        )
        self.update = to_raw_response_wrapper(
            seradata_optical_payload.update,
        )
        self.list = to_raw_response_wrapper(
            seradata_optical_payload.list,
        )
        self.delete = to_raw_response_wrapper(
            seradata_optical_payload.delete,
        )
        self.count = to_raw_response_wrapper(
            seradata_optical_payload.count,
        )
        self.get = to_raw_response_wrapper(
            seradata_optical_payload.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            seradata_optical_payload.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            seradata_optical_payload.tuple,
        )


class AsyncSeradataOpticalPayloadResourceWithRawResponse:
    def __init__(self, seradata_optical_payload: AsyncSeradataOpticalPayloadResource) -> None:
        self._seradata_optical_payload = seradata_optical_payload

        self.create = async_to_raw_response_wrapper(
            seradata_optical_payload.create,
        )
        self.update = async_to_raw_response_wrapper(
            seradata_optical_payload.update,
        )
        self.list = async_to_raw_response_wrapper(
            seradata_optical_payload.list,
        )
        self.delete = async_to_raw_response_wrapper(
            seradata_optical_payload.delete,
        )
        self.count = async_to_raw_response_wrapper(
            seradata_optical_payload.count,
        )
        self.get = async_to_raw_response_wrapper(
            seradata_optical_payload.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            seradata_optical_payload.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            seradata_optical_payload.tuple,
        )


class SeradataOpticalPayloadResourceWithStreamingResponse:
    def __init__(self, seradata_optical_payload: SeradataOpticalPayloadResource) -> None:
        self._seradata_optical_payload = seradata_optical_payload

        self.create = to_streamed_response_wrapper(
            seradata_optical_payload.create,
        )
        self.update = to_streamed_response_wrapper(
            seradata_optical_payload.update,
        )
        self.list = to_streamed_response_wrapper(
            seradata_optical_payload.list,
        )
        self.delete = to_streamed_response_wrapper(
            seradata_optical_payload.delete,
        )
        self.count = to_streamed_response_wrapper(
            seradata_optical_payload.count,
        )
        self.get = to_streamed_response_wrapper(
            seradata_optical_payload.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            seradata_optical_payload.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            seradata_optical_payload.tuple,
        )


class AsyncSeradataOpticalPayloadResourceWithStreamingResponse:
    def __init__(self, seradata_optical_payload: AsyncSeradataOpticalPayloadResource) -> None:
        self._seradata_optical_payload = seradata_optical_payload

        self.create = async_to_streamed_response_wrapper(
            seradata_optical_payload.create,
        )
        self.update = async_to_streamed_response_wrapper(
            seradata_optical_payload.update,
        )
        self.list = async_to_streamed_response_wrapper(
            seradata_optical_payload.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            seradata_optical_payload.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            seradata_optical_payload.count,
        )
        self.get = async_to_streamed_response_wrapper(
            seradata_optical_payload.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            seradata_optical_payload.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            seradata_optical_payload.tuple,
        )
