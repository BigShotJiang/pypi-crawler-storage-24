# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    aircraft_list_params,
    aircraft_count_params,
    aircraft_tuple_params,
    aircraft_create_params,
    aircraft_update_params,
    aircraft_retrieve_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncOffsetPage, AsyncOffsetPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.aircraft_abridged import AircraftAbridged
from ..types.entity_ingest_param import EntityIngestParam
from ..types.shared.aircraft_full import AircraftFull
from ..types.aircraft_tuple_response import AircraftTupleResponse
from ..types.aircraft_queryhelp_response import AircraftQueryhelpResponse

__all__ = ["AircraftResource", "AsyncAircraftResource"]


class AircraftResource(SyncAPIResource):
    """
    This service provides operations for manipulation and querying of Aircraft and Aircraft Status data. Aircraft contains the static data of the specific aircraft: tail number, cruise speed, max speed, minimum required runway length, etc. The Aircraft Status contains the dynamic data associated with the specific aircraft: remaining fuel, mission readiness, and inventory for example.
    """

    @cached_property
    def with_raw_response(self) -> AircraftResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AircraftResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AircraftResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AircraftResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        aircraft_mds: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        category: str | Omit = omit,
        command: str | Omit = omit,
        cruise_speed: float | Omit = omit,
        dtd: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        id_entity: str | Omit = omit,
        max_speed: float | Omit = omit,
        min_req_runway_ft: int | Omit = omit,
        min_req_runway_m: int | Omit = omit,
        nominal_ta_time: int | Omit = omit,
        notes: str | Omit = omit,
        origin: str | Omit = omit,
        owner: str | Omit = omit,
        serial_number: str | Omit = omit,
        tail_number: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single Aircraft as a POST body and ingest into the
        database. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          aircraft_mds: The aircraft Model Design Series (MDS) designation (e.g. E-2C HAWKEYE, F-15
              EAGLE, KC-130 HERCULES, etc.) of this aircraft. Intended as, but not constrained
              to, MIL-STD-6016 environment dependent specific type designations.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          category: The category of aircraft (e.g. M = Military, C = Commercial).

          command: The Air Force major command (MAJCOM) overseeing the aircraft.

          cruise_speed: The cruise speed of the aircraft, in kilometers/hour.

          dtd: Military data network data transfer device ID for this aircraft.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: ID of the parent entity for this aircraft.

          max_speed: The maximum air speed of the aircraft, in kilometers/hour.

          min_req_runway_ft: The minimum length of runway required to land this aircraft, in feet. Note: The
              corresponding equivalent field is not converted by the UDL and may or may not be
              supplied by the provider. The provider/consumer is responsible for all unit
              conversions.

          min_req_runway_m:
              The minimum length of runway required to land this aircraft, in meters. Note:
              The corresponding equivalent field is not converted by the UDL and may or may
              not be supplied by the provider. The provider/consumer is responsible for all
              unit conversions.

          nominal_ta_time: The nominal turnaround time for this aircraft, in minutes.

          notes: Optional notes/comments for this aircraft.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          owner: The wing or unit that owns the aircraft.

          serial_number: Full serial number of the aircraft.

          tail_number: The tail number of this aircraft.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/aircraft",
            body=maybe_transform(
                {
                    "aircraft_mds": aircraft_mds,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "category": category,
                    "command": command,
                    "cruise_speed": cruise_speed,
                    "dtd": dtd,
                    "entity": entity,
                    "id_entity": id_entity,
                    "max_speed": max_speed,
                    "min_req_runway_ft": min_req_runway_ft,
                    "min_req_runway_m": min_req_runway_m,
                    "nominal_ta_time": nominal_ta_time,
                    "notes": notes,
                    "origin": origin,
                    "owner": owner,
                    "serial_number": serial_number,
                    "tail_number": tail_number,
                },
                aircraft_create_params.AircraftCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftFull:
        """
        Service operation to get a single Aircraft record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/aircraft/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_retrieve_params.AircraftRetrieveParams,
                ),
            ),
            cast_to=AircraftFull,
        )

    def update(
        self,
        path_id: str,
        *,
        aircraft_mds: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        body_id: str | Omit = omit,
        category: str | Omit = omit,
        command: str | Omit = omit,
        cruise_speed: float | Omit = omit,
        dtd: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        id_entity: str | Omit = omit,
        max_speed: float | Omit = omit,
        min_req_runway_ft: int | Omit = omit,
        min_req_runway_m: int | Omit = omit,
        nominal_ta_time: int | Omit = omit,
        notes: str | Omit = omit,
        origin: str | Omit = omit,
        owner: str | Omit = omit,
        serial_number: str | Omit = omit,
        tail_number: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Aircraft.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          aircraft_mds: The aircraft Model Design Series (MDS) designation (e.g. E-2C HAWKEYE, F-15
              EAGLE, KC-130 HERCULES, etc.) of this aircraft. Intended as, but not constrained
              to, MIL-STD-6016 environment dependent specific type designations.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          category: The category of aircraft (e.g. M = Military, C = Commercial).

          command: The Air Force major command (MAJCOM) overseeing the aircraft.

          cruise_speed: The cruise speed of the aircraft, in kilometers/hour.

          dtd: Military data network data transfer device ID for this aircraft.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: ID of the parent entity for this aircraft.

          max_speed: The maximum air speed of the aircraft, in kilometers/hour.

          min_req_runway_ft: The minimum length of runway required to land this aircraft, in feet. Note: The
              corresponding equivalent field is not converted by the UDL and may or may not be
              supplied by the provider. The provider/consumer is responsible for all unit
              conversions.

          min_req_runway_m:
              The minimum length of runway required to land this aircraft, in meters. Note:
              The corresponding equivalent field is not converted by the UDL and may or may
              not be supplied by the provider. The provider/consumer is responsible for all
              unit conversions.

          nominal_ta_time: The nominal turnaround time for this aircraft, in minutes.

          notes: Optional notes/comments for this aircraft.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          owner: The wing or unit that owns the aircraft.

          serial_number: Full serial number of the aircraft.

          tail_number: The tail number of this aircraft.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/aircraft/{path_id}",
            body=maybe_transform(
                {
                    "aircraft_mds": aircraft_mds,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "body_id": body_id,
                    "category": category,
                    "command": command,
                    "cruise_speed": cruise_speed,
                    "dtd": dtd,
                    "entity": entity,
                    "id_entity": id_entity,
                    "max_speed": max_speed,
                    "min_req_runway_ft": min_req_runway_ft,
                    "min_req_runway_m": min_req_runway_m,
                    "nominal_ta_time": nominal_ta_time,
                    "notes": notes,
                    "origin": origin,
                    "owner": owner,
                    "serial_number": serial_number,
                    "tail_number": tail_number,
                },
                aircraft_update_params.AircraftUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[AircraftAbridged]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/aircraft",
            page=SyncOffsetPage[AircraftAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_list_params.AircraftListParams,
                ),
            ),
            model=AircraftAbridged,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/aircraft/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_count_params.AircraftCountParams,
                ),
            ),
            cast_to=str,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/aircraft/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AircraftQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/aircraft/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_tuple_params.AircraftTupleParams,
                ),
            ),
            cast_to=AircraftTupleResponse,
        )


class AsyncAircraftResource(AsyncAPIResource):
    """
    This service provides operations for manipulation and querying of Aircraft and Aircraft Status data. Aircraft contains the static data of the specific aircraft: tail number, cruise speed, max speed, minimum required runway length, etc. The Aircraft Status contains the dynamic data associated with the specific aircraft: remaining fuel, mission readiness, and inventory for example.
    """

    @cached_property
    def with_raw_response(self) -> AsyncAircraftResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAircraftResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAircraftResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncAircraftResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        aircraft_mds: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        id: str | Omit = omit,
        category: str | Omit = omit,
        command: str | Omit = omit,
        cruise_speed: float | Omit = omit,
        dtd: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        id_entity: str | Omit = omit,
        max_speed: float | Omit = omit,
        min_req_runway_ft: int | Omit = omit,
        min_req_runway_m: int | Omit = omit,
        nominal_ta_time: int | Omit = omit,
        notes: str | Omit = omit,
        origin: str | Omit = omit,
        owner: str | Omit = omit,
        serial_number: str | Omit = omit,
        tail_number: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single Aircraft as a POST body and ingest into the
        database. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          aircraft_mds: The aircraft Model Design Series (MDS) designation (e.g. E-2C HAWKEYE, F-15
              EAGLE, KC-130 HERCULES, etc.) of this aircraft. Intended as, but not constrained
              to, MIL-STD-6016 environment dependent specific type designations.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          id: Unique identifier of the record, auto-generated by the system.

          category: The category of aircraft (e.g. M = Military, C = Commercial).

          command: The Air Force major command (MAJCOM) overseeing the aircraft.

          cruise_speed: The cruise speed of the aircraft, in kilometers/hour.

          dtd: Military data network data transfer device ID for this aircraft.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: ID of the parent entity for this aircraft.

          max_speed: The maximum air speed of the aircraft, in kilometers/hour.

          min_req_runway_ft: The minimum length of runway required to land this aircraft, in feet. Note: The
              corresponding equivalent field is not converted by the UDL and may or may not be
              supplied by the provider. The provider/consumer is responsible for all unit
              conversions.

          min_req_runway_m:
              The minimum length of runway required to land this aircraft, in meters. Note:
              The corresponding equivalent field is not converted by the UDL and may or may
              not be supplied by the provider. The provider/consumer is responsible for all
              unit conversions.

          nominal_ta_time: The nominal turnaround time for this aircraft, in minutes.

          notes: Optional notes/comments for this aircraft.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          owner: The wing or unit that owns the aircraft.

          serial_number: Full serial number of the aircraft.

          tail_number: The tail number of this aircraft.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/aircraft",
            body=await async_maybe_transform(
                {
                    "aircraft_mds": aircraft_mds,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "id": id,
                    "category": category,
                    "command": command,
                    "cruise_speed": cruise_speed,
                    "dtd": dtd,
                    "entity": entity,
                    "id_entity": id_entity,
                    "max_speed": max_speed,
                    "min_req_runway_ft": min_req_runway_ft,
                    "min_req_runway_m": min_req_runway_m,
                    "nominal_ta_time": nominal_ta_time,
                    "notes": notes,
                    "origin": origin,
                    "owner": owner,
                    "serial_number": serial_number,
                    "tail_number": tail_number,
                },
                aircraft_create_params.AircraftCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def retrieve(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftFull:
        """
        Service operation to get a single Aircraft record by its unique ID passed as a
        path parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/aircraft/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_retrieve_params.AircraftRetrieveParams,
                ),
            ),
            cast_to=AircraftFull,
        )

    async def update(
        self,
        path_id: str,
        *,
        aircraft_mds: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        source: str,
        body_id: str | Omit = omit,
        category: str | Omit = omit,
        command: str | Omit = omit,
        cruise_speed: float | Omit = omit,
        dtd: str | Omit = omit,
        entity: EntityIngestParam | Omit = omit,
        id_entity: str | Omit = omit,
        max_speed: float | Omit = omit,
        min_req_runway_ft: int | Omit = omit,
        min_req_runway_m: int | Omit = omit,
        nominal_ta_time: int | Omit = omit,
        notes: str | Omit = omit,
        origin: str | Omit = omit,
        owner: str | Omit = omit,
        serial_number: str | Omit = omit,
        tail_number: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Aircraft.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          aircraft_mds: The aircraft Model Design Series (MDS) designation (e.g. E-2C HAWKEYE, F-15
              EAGLE, KC-130 HERCULES, etc.) of this aircraft. Intended as, but not constrained
              to, MIL-STD-6016 environment dependent specific type designations.

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          source: Source of the data.

          body_id: Unique identifier of the record, auto-generated by the system.

          category: The category of aircraft (e.g. M = Military, C = Commercial).

          command: The Air Force major command (MAJCOM) overseeing the aircraft.

          cruise_speed: The cruise speed of the aircraft, in kilometers/hour.

          dtd: Military data network data transfer device ID for this aircraft.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: ID of the parent entity for this aircraft.

          max_speed: The maximum air speed of the aircraft, in kilometers/hour.

          min_req_runway_ft: The minimum length of runway required to land this aircraft, in feet. Note: The
              corresponding equivalent field is not converted by the UDL and may or may not be
              supplied by the provider. The provider/consumer is responsible for all unit
              conversions.

          min_req_runway_m:
              The minimum length of runway required to land this aircraft, in meters. Note:
              The corresponding equivalent field is not converted by the UDL and may or may
              not be supplied by the provider. The provider/consumer is responsible for all
              unit conversions.

          nominal_ta_time: The nominal turnaround time for this aircraft, in minutes.

          notes: Optional notes/comments for this aircraft.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          owner: The wing or unit that owns the aircraft.

          serial_number: Full serial number of the aircraft.

          tail_number: The tail number of this aircraft.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/aircraft/{path_id}",
            body=await async_maybe_transform(
                {
                    "aircraft_mds": aircraft_mds,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "source": source,
                    "body_id": body_id,
                    "category": category,
                    "command": command,
                    "cruise_speed": cruise_speed,
                    "dtd": dtd,
                    "entity": entity,
                    "id_entity": id_entity,
                    "max_speed": max_speed,
                    "min_req_runway_ft": min_req_runway_ft,
                    "min_req_runway_m": min_req_runway_m,
                    "nominal_ta_time": nominal_ta_time,
                    "notes": notes,
                    "origin": origin,
                    "owner": owner,
                    "serial_number": serial_number,
                    "tail_number": tail_number,
                },
                aircraft_update_params.AircraftUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[AircraftAbridged, AsyncOffsetPage[AircraftAbridged]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/aircraft",
            page=AsyncOffsetPage[AircraftAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_list_params.AircraftListParams,
                ),
            ),
            model=AircraftAbridged,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/aircraft/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_count_params.AircraftCountParams,
                ),
            ),
            cast_to=str,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/aircraft/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AircraftQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AircraftTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/aircraft/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    aircraft_tuple_params.AircraftTupleParams,
                ),
            ),
            cast_to=AircraftTupleResponse,
        )


class AircraftResourceWithRawResponse:
    def __init__(self, aircraft: AircraftResource) -> None:
        self._aircraft = aircraft

        self.create = to_raw_response_wrapper(
            aircraft.create,
        )
        self.retrieve = to_raw_response_wrapper(
            aircraft.retrieve,
        )
        self.update = to_raw_response_wrapper(
            aircraft.update,
        )
        self.list = to_raw_response_wrapper(
            aircraft.list,
        )
        self.count = to_raw_response_wrapper(
            aircraft.count,
        )
        self.queryhelp = to_raw_response_wrapper(
            aircraft.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            aircraft.tuple,
        )


class AsyncAircraftResourceWithRawResponse:
    def __init__(self, aircraft: AsyncAircraftResource) -> None:
        self._aircraft = aircraft

        self.create = async_to_raw_response_wrapper(
            aircraft.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            aircraft.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            aircraft.update,
        )
        self.list = async_to_raw_response_wrapper(
            aircraft.list,
        )
        self.count = async_to_raw_response_wrapper(
            aircraft.count,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            aircraft.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            aircraft.tuple,
        )


class AircraftResourceWithStreamingResponse:
    def __init__(self, aircraft: AircraftResource) -> None:
        self._aircraft = aircraft

        self.create = to_streamed_response_wrapper(
            aircraft.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            aircraft.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            aircraft.update,
        )
        self.list = to_streamed_response_wrapper(
            aircraft.list,
        )
        self.count = to_streamed_response_wrapper(
            aircraft.count,
        )
        self.queryhelp = to_streamed_response_wrapper(
            aircraft.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            aircraft.tuple,
        )


class AsyncAircraftResourceWithStreamingResponse:
    def __init__(self, aircraft: AsyncAircraftResource) -> None:
        self._aircraft = aircraft

        self.create = async_to_streamed_response_wrapper(
            aircraft.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            aircraft.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            aircraft.update,
        )
        self.list = async_to_streamed_response_wrapper(
            aircraft.list,
        )
        self.count = async_to_streamed_response_wrapper(
            aircraft.count,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            aircraft.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            aircraft.tuple,
        )
