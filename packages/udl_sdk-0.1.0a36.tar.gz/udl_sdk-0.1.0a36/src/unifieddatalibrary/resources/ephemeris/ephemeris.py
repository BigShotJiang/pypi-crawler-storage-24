# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    ephemeris_list_params,
    ephemeris_count_params,
    ephemeris_tuple_params,
    ephemeris_file_upload_params,
    ephemeris_unvalidated_publish_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.ephemeris_abridged import EphemerisAbridged
from .attitude_data.attitude_data import (
    AttitudeDataResource,
    AsyncAttitudeDataResource,
    AttitudeDataResourceWithRawResponse,
    AsyncAttitudeDataResourceWithRawResponse,
    AttitudeDataResourceWithStreamingResponse,
    AsyncAttitudeDataResourceWithStreamingResponse,
)
from ...types.ephemeris_tuple_response import EphemerisTupleResponse
from ...types.ephemeris_queryhelp_response import EphemerisQueryhelpResponse

__all__ = ["EphemerisResource", "AsyncEphemerisResource"]


class EphemerisResource(SyncAPIResource):
    """
    These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
    """

    @cached_property
    def attitude_data(self) -> AttitudeDataResource:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AttitudeDataResource(self._client)

    @cached_property
    def history(self) -> HistoryResource:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> EphemerisResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return EphemerisResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EphemerisResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return EphemerisResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[EphemerisAbridged]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/ephemeris",
            page=SyncOffsetPage[EphemerisAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_list_params.EphemerisListParams,
                ),
            ),
            model=EphemerisAbridged,
        )

    def count(
        self,
        *,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/ephemeris/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_count_params.EphemerisCountParams,
                ),
            ),
            cast_to=str,
        )

    def file_upload(
        self,
        *,
        category: str,
        classification: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        ephem_format_type: Literal["ModITC", "GOO", "NASA", "OEM", "OASYS"],
        has_mnvr: bool,
        sat_no: int,
        source: str,
        type: str,
        body: str,
        origin: str | Omit = omit,
        tags: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to post/store Ephemeris data.

        This operation is intended to be
        used for automated feeds into UDL. The payload is in Ephemeris format as
        described by the "Flight Safety Handbook" published by 18th Space Command. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        **Example:**
        /filedrop/ephem?classification=U&dataMode=TEST&source=Bluestaq&satNo=25544&ephemFormatType=NASA&hasMnvr=false&type=ROUTINE&category=EXTERNAL&origin=NASA&tags=tag1,tag2

        Args:
          category: Ephemeris category.

          classification: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode: Indicator of whether the data is REAL, TEST, SIMULATED, or EXERCISE data.

          ephem_format_type: Ephemeris format as documented in Flight Safety Handbook.

          has_mnvr: Boolean indicating whether maneuver(s) are incorporated into the ephemeris.

          sat_no: Satellite/Catalog number of the target on-orbit object.

          source: Source of the Ephemeris data.

          type: Ephemeris type.

          origin: Optional origin of the Ephemeris.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/ephem",
            body=maybe_transform(body, ephemeris_file_upload_params.EphemerisFileUploadParams),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "category": category,
                        "classification": classification,
                        "data_mode": data_mode,
                        "ephem_format_type": ephem_format_type,
                        "has_mnvr": has_mnvr,
                        "sat_no": sat_no,
                        "source": source,
                        "type": type,
                        "origin": origin,
                        "tags": tags,
                    },
                    ephemeris_file_upload_params.EphemerisFileUploadParams,
                ),
            ),
            cast_to=NoneType,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EphemerisQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/ephemeris/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EphemerisQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EphemerisTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/ephemeris/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_tuple_params.EphemerisTupleParams,
                ),
            ),
            cast_to=EphemerisTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        category: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        num_points: int,
        point_end_time: Union[str, datetime],
        point_start_time: Union[str, datetime],
        source: str,
        type: str,
        id: str | Omit = omit,
        b_dot: float | Omit = omit,
        cent_body: str | Omit = omit,
        comments: str | Omit = omit,
        cov_reference_frame: Literal["J2000", "UVW", "EFG/TDR", "ECR/ECEF", "TEME", "GCRF"] | Omit = omit,
        description: str | Omit = omit,
        descriptor: str | Omit = omit,
        drag_model: str | Omit = omit,
        edr: float | Omit = omit,
        ephemeris_list: Iterable[ephemeris_unvalidated_publish_params.EphemerisList] | Omit = omit,
        filename: str | Omit = omit,
        geopotential_model: str | Omit = omit,
        has_accel: bool | Omit = omit,
        has_cov: bool | Omit = omit,
        has_mnvr: bool | Omit = omit,
        id_maneuvers: SequenceNotStr[str] | Omit = omit,
        id_on_orbit: str | Omit = omit,
        id_state_vector: str | Omit = omit,
        integrator: str | Omit = omit,
        interpolation: str | Omit = omit,
        interpolation_degree: int | Omit = omit,
        lunar_solar: bool | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        pedigree: str | Omit = omit,
        reference_frame: Literal["J2000", "EFG/TDR", "ECR/ECEF", "TEME", "ITRF", "GCRF"] | Omit = omit,
        sat_no: int | Omit = omit,
        solid_earth_tides: bool | Omit = omit,
        step_size: int | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        transaction_id: str | Omit = omit,
        usable_end_time: Union[str, datetime] | Omit = omit,
        usable_start_time: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single EphemerisSet and many associated Ephemeris
        records as a POST body for ingest into the database. A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        The following rules apply to this operation:

        <h3>
          * Ephemeris Set numPoints value must correspond exactly to the number of Ephemeris states associated with that Ephemeris Set. The numPoints value is checked against the actual posted number of states, and a mismatch will result in the post being rejected.
          * Ephemeris Set pointStartTime and pointEndTime must correspond to the earliest and latest state times, respectively, of the associated Ephemeris states.
          * Either satNo, idOnOrbit, or origObjectId must be provided. The preferred option is to post with satNo for a cataloged object, and with (only) origObjectId for an unknown, uncataloged, or internal/test object. There are several cases for the logic associated with these fields:
            + If satNo is provided and correlates to a known UDL sat number then the idOnOrbit will be populated appropriately in addition to the satNo.
            + If satNo is provided and does not correlate to a known UDL sat number then the provided satNo value will be moved to the origObjectId field and satNo left null.
            + If origObjectId and a valid satNo or idOnOrbit are provided then both the satNo/idOnOrbit and origObjectId will maintain the provided values.
            + If only origObjectId is provided then origObjectId will be populated with the posted value. In this case, no checks are made against existing UDL sat numbers.
        </h3>

        Args:
          category: The source category of the ephemeris (e.g. OWNER_OPERATOR, ANALYST, EXTERNAL).

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          num_points: Number of points contained in the ephemeris.

          point_end_time: End time/last time point of the ephemeris, in ISO 8601 UTC format.

          point_start_time: Start time/first time point of the ephemeris, in ISO 8601 UTC format.

          source: Source of the data.

          type: The type/purpose of the ephemeris (e.g., CALIBRATION, LAUNCH, MNVR_PLAN,
              ROUTINE, SCREENING).

          id: Unique identifier of the record, auto-generated by the system.

          b_dot: First derivative of ballistic coefficient (m^2/kg-s).

          cent_body: The Central Body of the ephemeris. Assumed to be Earth, unless otherwise
              indicated.

          comments: Additional source provided comments associated with the ephemeris.

          cov_reference_frame: The reference frame of the covariance matrix elements. If the covReferenceFrame
              is null it is assumed to be J2000.

          description: Notes/description of the provided ephemeris. A value of DSTOP signifies the
              ephemeris were generated using the last observation available.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          drag_model: Drag model used in ephemeris generation (e.g. JAC70, MSIS90, NONE, etc.).

          edr: Model parameter value for energy dissipation rate (EDR), expressed in w/kg.

          ephemeris_list: The list of ephemeris states belonging to the EphemerisSet. Each ephemeris point
              is associated with a parent Ephemeris Set via the EphemerisSet ID (esId).

          filename: Filename of the raw file used to provide the ephemeris data including filetype
              extension, if applicable. This file may be retrieved using the 'getFile'
              operation as specified in the 'EphemerisSet' OpenAPI docs.

          geopotential_model: Geopotential model used in ephemeris generation (e.g. EGM-96, WGS-84, WGS-72,
              JGM-2, GEM-T3), including mm degree zonals, nn degree/order tesserals (e.g.
              EGM-96 24Z,24T).

          has_accel: Boolean indicating whether acceleration data is provided with the ephemeris.

          has_cov: Boolean indicating whether covariance data is provided with the ephemeris.

          has_mnvr: Boolean indicating whether maneuver(s) are incorporated into the ephemeris.

          id_maneuvers: Array of the maneuver IDs of all maneuvers incorporated in the ephemeris.

          id_on_orbit: Unique identifier of the primary satellite on-orbit object.

          id_state_vector: ID of the State Vector used to generate the ephemeris.

          integrator: Integrator used in ephemeris generation (e.g. RK7(8), RK8(9), COWELL, TWO-BODY).

          interpolation: The recommended interpolation method for the ephemeris data.

          interpolation_degree: The recommended interpolation degree for the ephemeris data.

          lunar_solar: Boolean indicating use of lunar/solar data in ephemeris generation.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional identifier provided by ephemeris source to indicate the target object
              of this ephemeris. This may be an internal identifier and not necessarily map to
              a valid satellite number.

          pedigree: The pedigree of the ephemeris or source data used for ephemeris generation (e.g.
              DOPPLER, GPS, HYBRID, PROPAGATED, RANGING, SLR).

          reference_frame: The reference frame of the cartesian orbital states. If the referenceFrame is
              null it is assumed to be J2000.

          sat_no: Satellite/catalog number of the target on-orbit object.

          solid_earth_tides: Boolean indicating use of solid earth tide data in ephemeris generation.

          step_size: Ephemeris step size, in seconds.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          transaction_id: Optional identifier to track a commercial or marketplace transaction executed to
              produce this data.

          usable_end_time: Optional end time of the usable time span for the ephemeris data, in ISO 8601
              UTC format with microsecond precision.

          usable_start_time: Optional start time of the usable time span for the ephemeris data, in ISO 8601
              UTC format with microsecond precision.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-ephset",
            body=maybe_transform(
                {
                    "category": category,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "num_points": num_points,
                    "point_end_time": point_end_time,
                    "point_start_time": point_start_time,
                    "source": source,
                    "type": type,
                    "id": id,
                    "b_dot": b_dot,
                    "cent_body": cent_body,
                    "comments": comments,
                    "cov_reference_frame": cov_reference_frame,
                    "description": description,
                    "descriptor": descriptor,
                    "drag_model": drag_model,
                    "edr": edr,
                    "ephemeris_list": ephemeris_list,
                    "filename": filename,
                    "geopotential_model": geopotential_model,
                    "has_accel": has_accel,
                    "has_cov": has_cov,
                    "has_mnvr": has_mnvr,
                    "id_maneuvers": id_maneuvers,
                    "id_on_orbit": id_on_orbit,
                    "id_state_vector": id_state_vector,
                    "integrator": integrator,
                    "interpolation": interpolation,
                    "interpolation_degree": interpolation_degree,
                    "lunar_solar": lunar_solar,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "pedigree": pedigree,
                    "reference_frame": reference_frame,
                    "sat_no": sat_no,
                    "solid_earth_tides": solid_earth_tides,
                    "step_size": step_size,
                    "tags": tags,
                    "transaction_id": transaction_id,
                    "usable_end_time": usable_end_time,
                    "usable_start_time": usable_start_time,
                },
                ephemeris_unvalidated_publish_params.EphemerisUnvalidatedPublishParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncEphemerisResource(AsyncAPIResource):
    """
    These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
    """

    @cached_property
    def attitude_data(self) -> AsyncAttitudeDataResource:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncAttitudeDataResource(self._client)

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncEphemerisResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncEphemerisResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEphemerisResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncEphemerisResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[EphemerisAbridged, AsyncOffsetPage[EphemerisAbridged]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/ephemeris",
            page=AsyncOffsetPage[EphemerisAbridged],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_list_params.EphemerisListParams,
                ),
            ),
            model=EphemerisAbridged,
        )

    async def count(
        self,
        *,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/ephemeris/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_count_params.EphemerisCountParams,
                ),
            ),
            cast_to=str,
        )

    async def file_upload(
        self,
        *,
        category: str,
        classification: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        ephem_format_type: Literal["ModITC", "GOO", "NASA", "OEM", "OASYS"],
        has_mnvr: bool,
        sat_no: int,
        source: str,
        type: str,
        body: str,
        origin: str | Omit = omit,
        tags: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to post/store Ephemeris data.

        This operation is intended to be
        used for automated feeds into UDL. The payload is in Ephemeris format as
        described by the "Flight Safety Handbook" published by 18th Space Command. A
        specific role is required to perform this service operation. Please contact the
        UDL team for assistance.

        **Example:**
        /filedrop/ephem?classification=U&dataMode=TEST&source=Bluestaq&satNo=25544&ephemFormatType=NASA&hasMnvr=false&type=ROUTINE&category=EXTERNAL&origin=NASA&tags=tag1,tag2

        Args:
          category: Ephemeris category.

          classification: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode: Indicator of whether the data is REAL, TEST, SIMULATED, or EXERCISE data.

          ephem_format_type: Ephemeris format as documented in Flight Safety Handbook.

          has_mnvr: Boolean indicating whether maneuver(s) are incorporated into the ephemeris.

          sat_no: Satellite/Catalog number of the target on-orbit object.

          source: Source of the Ephemeris data.

          type: Ephemeris type.

          origin: Optional origin of the Ephemeris.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/ephem",
            body=await async_maybe_transform(body, ephemeris_file_upload_params.EphemerisFileUploadParams),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "category": category,
                        "classification": classification,
                        "data_mode": data_mode,
                        "ephem_format_type": ephem_format_type,
                        "has_mnvr": has_mnvr,
                        "sat_no": sat_no,
                        "source": source,
                        "type": type,
                        "origin": origin,
                        "tags": tags,
                    },
                    ephemeris_file_upload_params.EphemerisFileUploadParams,
                ),
            ),
            cast_to=NoneType,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EphemerisQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/ephemeris/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EphemerisQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        es_id: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EphemerisTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          es_id: Unique identifier of the parent EphemerisSet, auto-generated by the system. The
              esId (ephemerisSet id) is used to identify all individual ephemeris states
              associated with a parent ephemerisSet. (uuid)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/ephemeris/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "es_id": es_id,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    ephemeris_tuple_params.EphemerisTupleParams,
                ),
            ),
            cast_to=EphemerisTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        category: str,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        num_points: int,
        point_end_time: Union[str, datetime],
        point_start_time: Union[str, datetime],
        source: str,
        type: str,
        id: str | Omit = omit,
        b_dot: float | Omit = omit,
        cent_body: str | Omit = omit,
        comments: str | Omit = omit,
        cov_reference_frame: Literal["J2000", "UVW", "EFG/TDR", "ECR/ECEF", "TEME", "GCRF"] | Omit = omit,
        description: str | Omit = omit,
        descriptor: str | Omit = omit,
        drag_model: str | Omit = omit,
        edr: float | Omit = omit,
        ephemeris_list: Iterable[ephemeris_unvalidated_publish_params.EphemerisList] | Omit = omit,
        filename: str | Omit = omit,
        geopotential_model: str | Omit = omit,
        has_accel: bool | Omit = omit,
        has_cov: bool | Omit = omit,
        has_mnvr: bool | Omit = omit,
        id_maneuvers: SequenceNotStr[str] | Omit = omit,
        id_on_orbit: str | Omit = omit,
        id_state_vector: str | Omit = omit,
        integrator: str | Omit = omit,
        interpolation: str | Omit = omit,
        interpolation_degree: int | Omit = omit,
        lunar_solar: bool | Omit = omit,
        origin: str | Omit = omit,
        orig_object_id: str | Omit = omit,
        pedigree: str | Omit = omit,
        reference_frame: Literal["J2000", "EFG/TDR", "ECR/ECEF", "TEME", "ITRF", "GCRF"] | Omit = omit,
        sat_no: int | Omit = omit,
        solid_earth_tides: bool | Omit = omit,
        step_size: int | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        transaction_id: str | Omit = omit,
        usable_end_time: Union[str, datetime] | Omit = omit,
        usable_start_time: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single EphemerisSet and many associated Ephemeris
        records as a POST body for ingest into the database. A specific role is required
        to perform this service operation. Please contact the UDL team for assistance.

        The following rules apply to this operation:

        <h3>
          * Ephemeris Set numPoints value must correspond exactly to the number of Ephemeris states associated with that Ephemeris Set. The numPoints value is checked against the actual posted number of states, and a mismatch will result in the post being rejected.
          * Ephemeris Set pointStartTime and pointEndTime must correspond to the earliest and latest state times, respectively, of the associated Ephemeris states.
          * Either satNo, idOnOrbit, or origObjectId must be provided. The preferred option is to post with satNo for a cataloged object, and with (only) origObjectId for an unknown, uncataloged, or internal/test object. There are several cases for the logic associated with these fields:
            + If satNo is provided and correlates to a known UDL sat number then the idOnOrbit will be populated appropriately in addition to the satNo.
            + If satNo is provided and does not correlate to a known UDL sat number then the provided satNo value will be moved to the origObjectId field and satNo left null.
            + If origObjectId and a valid satNo or idOnOrbit are provided then both the satNo/idOnOrbit and origObjectId will maintain the provided values.
            + If only origObjectId is provided then origObjectId will be populated with the posted value. In this case, no checks are made against existing UDL sat numbers.
        </h3>

        Args:
          category: The source category of the ephemeris (e.g. OWNER_OPERATOR, ANALYST, EXTERNAL).

          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          num_points: Number of points contained in the ephemeris.

          point_end_time: End time/last time point of the ephemeris, in ISO 8601 UTC format.

          point_start_time: Start time/first time point of the ephemeris, in ISO 8601 UTC format.

          source: Source of the data.

          type: The type/purpose of the ephemeris (e.g., CALIBRATION, LAUNCH, MNVR_PLAN,
              ROUTINE, SCREENING).

          id: Unique identifier of the record, auto-generated by the system.

          b_dot: First derivative of ballistic coefficient (m^2/kg-s).

          cent_body: The Central Body of the ephemeris. Assumed to be Earth, unless otherwise
              indicated.

          comments: Additional source provided comments associated with the ephemeris.

          cov_reference_frame: The reference frame of the covariance matrix elements. If the covReferenceFrame
              is null it is assumed to be J2000.

          description: Notes/description of the provided ephemeris. A value of DSTOP signifies the
              ephemeris were generated using the last observation available.

          descriptor: Optional source-provided and searchable metadata or descriptor of the data.

          drag_model: Drag model used in ephemeris generation (e.g. JAC70, MSIS90, NONE, etc.).

          edr: Model parameter value for energy dissipation rate (EDR), expressed in w/kg.

          ephemeris_list: The list of ephemeris states belonging to the EphemerisSet. Each ephemeris point
              is associated with a parent Ephemeris Set via the EphemerisSet ID (esId).

          filename: Filename of the raw file used to provide the ephemeris data including filetype
              extension, if applicable. This file may be retrieved using the 'getFile'
              operation as specified in the 'EphemerisSet' OpenAPI docs.

          geopotential_model: Geopotential model used in ephemeris generation (e.g. EGM-96, WGS-84, WGS-72,
              JGM-2, GEM-T3), including mm degree zonals, nn degree/order tesserals (e.g.
              EGM-96 24Z,24T).

          has_accel: Boolean indicating whether acceleration data is provided with the ephemeris.

          has_cov: Boolean indicating whether covariance data is provided with the ephemeris.

          has_mnvr: Boolean indicating whether maneuver(s) are incorporated into the ephemeris.

          id_maneuvers: Array of the maneuver IDs of all maneuvers incorporated in the ephemeris.

          id_on_orbit: Unique identifier of the primary satellite on-orbit object.

          id_state_vector: ID of the State Vector used to generate the ephemeris.

          integrator: Integrator used in ephemeris generation (e.g. RK7(8), RK8(9), COWELL, TWO-BODY).

          interpolation: The recommended interpolation method for the ephemeris data.

          interpolation_degree: The recommended interpolation degree for the ephemeris data.

          lunar_solar: Boolean indicating use of lunar/solar data in ephemeris generation.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_object_id: Optional identifier provided by ephemeris source to indicate the target object
              of this ephemeris. This may be an internal identifier and not necessarily map to
              a valid satellite number.

          pedigree: The pedigree of the ephemeris or source data used for ephemeris generation (e.g.
              DOPPLER, GPS, HYBRID, PROPAGATED, RANGING, SLR).

          reference_frame: The reference frame of the cartesian orbital states. If the referenceFrame is
              null it is assumed to be J2000.

          sat_no: Satellite/catalog number of the target on-orbit object.

          solid_earth_tides: Boolean indicating use of solid earth tide data in ephemeris generation.

          step_size: Ephemeris step size, in seconds.

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          transaction_id: Optional identifier to track a commercial or marketplace transaction executed to
              produce this data.

          usable_end_time: Optional end time of the usable time span for the ephemeris data, in ISO 8601
              UTC format with microsecond precision.

          usable_start_time: Optional start time of the usable time span for the ephemeris data, in ISO 8601
              UTC format with microsecond precision.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-ephset",
            body=await async_maybe_transform(
                {
                    "category": category,
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "num_points": num_points,
                    "point_end_time": point_end_time,
                    "point_start_time": point_start_time,
                    "source": source,
                    "type": type,
                    "id": id,
                    "b_dot": b_dot,
                    "cent_body": cent_body,
                    "comments": comments,
                    "cov_reference_frame": cov_reference_frame,
                    "description": description,
                    "descriptor": descriptor,
                    "drag_model": drag_model,
                    "edr": edr,
                    "ephemeris_list": ephemeris_list,
                    "filename": filename,
                    "geopotential_model": geopotential_model,
                    "has_accel": has_accel,
                    "has_cov": has_cov,
                    "has_mnvr": has_mnvr,
                    "id_maneuvers": id_maneuvers,
                    "id_on_orbit": id_on_orbit,
                    "id_state_vector": id_state_vector,
                    "integrator": integrator,
                    "interpolation": interpolation,
                    "interpolation_degree": interpolation_degree,
                    "lunar_solar": lunar_solar,
                    "origin": origin,
                    "orig_object_id": orig_object_id,
                    "pedigree": pedigree,
                    "reference_frame": reference_frame,
                    "sat_no": sat_no,
                    "solid_earth_tides": solid_earth_tides,
                    "step_size": step_size,
                    "tags": tags,
                    "transaction_id": transaction_id,
                    "usable_end_time": usable_end_time,
                    "usable_start_time": usable_start_time,
                },
                ephemeris_unvalidated_publish_params.EphemerisUnvalidatedPublishParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class EphemerisResourceWithRawResponse:
    def __init__(self, ephemeris: EphemerisResource) -> None:
        self._ephemeris = ephemeris

        self.list = to_raw_response_wrapper(
            ephemeris.list,
        )
        self.count = to_raw_response_wrapper(
            ephemeris.count,
        )
        self.file_upload = to_raw_response_wrapper(
            ephemeris.file_upload,
        )
        self.queryhelp = to_raw_response_wrapper(
            ephemeris.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            ephemeris.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            ephemeris.unvalidated_publish,
        )

    @cached_property
    def attitude_data(self) -> AttitudeDataResourceWithRawResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AttitudeDataResourceWithRawResponse(self._ephemeris.attitude_data)

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return HistoryResourceWithRawResponse(self._ephemeris.history)


class AsyncEphemerisResourceWithRawResponse:
    def __init__(self, ephemeris: AsyncEphemerisResource) -> None:
        self._ephemeris = ephemeris

        self.list = async_to_raw_response_wrapper(
            ephemeris.list,
        )
        self.count = async_to_raw_response_wrapper(
            ephemeris.count,
        )
        self.file_upload = async_to_raw_response_wrapper(
            ephemeris.file_upload,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            ephemeris.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            ephemeris.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            ephemeris.unvalidated_publish,
        )

    @cached_property
    def attitude_data(self) -> AsyncAttitudeDataResourceWithRawResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncAttitudeDataResourceWithRawResponse(self._ephemeris.attitude_data)

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncHistoryResourceWithRawResponse(self._ephemeris.history)


class EphemerisResourceWithStreamingResponse:
    def __init__(self, ephemeris: EphemerisResource) -> None:
        self._ephemeris = ephemeris

        self.list = to_streamed_response_wrapper(
            ephemeris.list,
        )
        self.count = to_streamed_response_wrapper(
            ephemeris.count,
        )
        self.file_upload = to_streamed_response_wrapper(
            ephemeris.file_upload,
        )
        self.queryhelp = to_streamed_response_wrapper(
            ephemeris.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            ephemeris.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            ephemeris.unvalidated_publish,
        )

    @cached_property
    def attitude_data(self) -> AttitudeDataResourceWithStreamingResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AttitudeDataResourceWithStreamingResponse(self._ephemeris.attitude_data)

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return HistoryResourceWithStreamingResponse(self._ephemeris.history)


class AsyncEphemerisResourceWithStreamingResponse:
    def __init__(self, ephemeris: AsyncEphemerisResource) -> None:
        self._ephemeris = ephemeris

        self.list = async_to_streamed_response_wrapper(
            ephemeris.list,
        )
        self.count = async_to_streamed_response_wrapper(
            ephemeris.count,
        )
        self.file_upload = async_to_streamed_response_wrapper(
            ephemeris.file_upload,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            ephemeris.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            ephemeris.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            ephemeris.unvalidated_publish,
        )

    @cached_property
    def attitude_data(self) -> AsyncAttitudeDataResourceWithStreamingResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncAttitudeDataResourceWithStreamingResponse(self._ephemeris.attitude_data)

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """
        These services provide operations for the posting and querying of satellite Ephemeris Point data. Each point contains a position and velocity vector and optionally, an acceleration vector and/or covariance matrix at a specified time. ECI J2K is the preferred reference frame for ephemeris and covariance, however, several user specified reference frames are accommodated. The EphemerisSet ID (esId) identifies the 'EphemerisSet' record which contains details of the underlying data and models used in the generation of the ephemeris as well as a collection of ephemeris points. Points must be retrieved by first identifying a desired EphemerisSet and pulling its points by that EphemerisSet 'esId'.
        """
        return AsyncHistoryResourceWithStreamingResponse(self._ephemeris.history)
