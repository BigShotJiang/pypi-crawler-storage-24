# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal

import httpx

from ...types import (
    sensor_get_params,
    sensor_list_params,
    sensor_count_params,
    sensor_tuple_params,
    sensor_create_params,
    sensor_update_params,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from .calibration.calibration import (
    CalibrationResource,
    AsyncCalibrationResource,
    CalibrationResourceWithRawResponse,
    AsyncCalibrationResourceWithRawResponse,
    CalibrationResourceWithStreamingResponse,
    AsyncCalibrationResourceWithStreamingResponse,
)
from ...types.sensor_get_response import SensorGetResponse
from ...types.sensor_list_response import SensorListResponse
from ...types.sensor_tuple_response import SensorTupleResponse
from ...types.sensor_queryhelp_response import SensorQueryhelpResponse

__all__ = ["SensorResource", "AsyncSensorResource"]


class SensorResource(SyncAPIResource):
    """This service provides operations for querying and manipulation of sensor data.

    Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
    """

    @cached_property
    def calibration(self) -> CalibrationResource:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return CalibrationResource(self._client)

    @cached_property
    def with_raw_response(self) -> SensorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SensorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SensorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return SensorResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        sensor_name: str,
        source: str,
        active: bool | Omit = omit,
        af_id: str | Omit = omit,
        asr_type: str | Omit = omit,
        data_control: str | Omit = omit,
        entity: sensor_create_params.Entity | Omit = omit,
        id_entity: str | Omit = omit,
        id_sensor: str | Omit = omit,
        origin: str | Omit = omit,
        sensorcharacteristics: Iterable[sensor_create_params.Sensorcharacteristic] | Omit = omit,
        sensorlimits_collection: Iterable[sensor_create_params.SensorlimitsCollection] | Omit = omit,
        sensor_number: int | Omit = omit,
        sensor_observation_type: sensor_create_params.SensorObservationType | Omit = omit,
        sensor_stats: Iterable[sensor_create_params.SensorStat] | Omit = omit,
        sensor_type: sensor_create_params.SensorType | Omit = omit,
        short_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single sensor as a POST body and ingest into the
        database. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          sensor_name: Unique name of this sensor.

          source: Source of the data.

          active: Optional flag indicating if the sensor is active.

          af_id: Optional US Air Force identifier for the sensor/ASR site, typically for air
              surveillance radar (ASR) sensors.

          asr_type: The sensor type at the site. Optional field, intended primarily for ASRs.

          data_control: Optional dissemination control required for accessing data (e.g observations)
              produced by this sensor. This is typically a proprietary data owner control for
              commercial sensors.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_sensor: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          sensorcharacteristics: Collection of Sensorcharacteristics which define characteristics and
              capabilities of a sensor.

          sensorlimits_collection: Sensorlimits define 0 to many limits of a particular sensor in terms of
              observation coverage of on-orbit objects.

          sensor_number: Number assigned to this sensor. Since there is no authoritative numbering
              scheme, these numbers sometimes collide across sensors (especially commercial
              sensors). It is therefore not a unique identifier.

          sensor_stats: Collection of SensorStats which contain statistics of a sensor.

          short_name: Optional short name for the sensor.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/sensor",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "sensor_name": sensor_name,
                    "source": source,
                    "active": active,
                    "af_id": af_id,
                    "asr_type": asr_type,
                    "data_control": data_control,
                    "entity": entity,
                    "id_entity": id_entity,
                    "id_sensor": id_sensor,
                    "origin": origin,
                    "sensorcharacteristics": sensorcharacteristics,
                    "sensorlimits_collection": sensorlimits_collection,
                    "sensor_number": sensor_number,
                    "sensor_observation_type": sensor_observation_type,
                    "sensor_stats": sensor_stats,
                    "sensor_type": sensor_type,
                    "short_name": short_name,
                },
                sensor_create_params.SensorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        sensor_name: str,
        source: str,
        active: bool | Omit = omit,
        af_id: str | Omit = omit,
        asr_type: str | Omit = omit,
        data_control: str | Omit = omit,
        entity: sensor_update_params.Entity | Omit = omit,
        id_entity: str | Omit = omit,
        id_sensor: str | Omit = omit,
        origin: str | Omit = omit,
        sensorcharacteristics: Iterable[sensor_update_params.Sensorcharacteristic] | Omit = omit,
        sensorlimits_collection: Iterable[sensor_update_params.SensorlimitsCollection] | Omit = omit,
        sensor_number: int | Omit = omit,
        sensor_observation_type: sensor_update_params.SensorObservationType | Omit = omit,
        sensor_stats: Iterable[sensor_update_params.SensorStat] | Omit = omit,
        sensor_type: sensor_update_params.SensorType | Omit = omit,
        short_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Sensor.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          sensor_name: Unique name of this sensor.

          source: Source of the data.

          active: Optional flag indicating if the sensor is active.

          af_id: Optional US Air Force identifier for the sensor/ASR site, typically for air
              surveillance radar (ASR) sensors.

          asr_type: The sensor type at the site. Optional field, intended primarily for ASRs.

          data_control: Optional dissemination control required for accessing data (e.g observations)
              produced by this sensor. This is typically a proprietary data owner control for
              commercial sensors.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_sensor: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          sensorcharacteristics: Collection of Sensorcharacteristics which define characteristics and
              capabilities of a sensor.

          sensorlimits_collection: Sensorlimits define 0 to many limits of a particular sensor in terms of
              observation coverage of on-orbit objects.

          sensor_number: Number assigned to this sensor. Since there is no authoritative numbering
              scheme, these numbers sometimes collide across sensors (especially commercial
              sensors). It is therefore not a unique identifier.

          sensor_stats: Collection of SensorStats which contain statistics of a sensor.

          short_name: Optional short name for the sensor.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/sensor/{id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "sensor_name": sensor_name,
                    "source": source,
                    "active": active,
                    "af_id": af_id,
                    "asr_type": asr_type,
                    "data_control": data_control,
                    "entity": entity,
                    "id_entity": id_entity,
                    "id_sensor": id_sensor,
                    "origin": origin,
                    "sensorcharacteristics": sensorcharacteristics,
                    "sensorlimits_collection": sensorlimits_collection,
                    "sensor_number": sensor_number,
                    "sensor_observation_type": sensor_observation_type,
                    "sensor_stats": sensor_stats,
                    "sensor_type": sensor_type,
                    "short_name": short_name,
                },
                sensor_update_params.SensorUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[SensorListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/sensor",
            page=SyncOffsetPage[SensorListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_list_params.SensorListParams,
                ),
            ),
            model=SensorListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a Sensor specified by the passed ID path parameter.
        A specific role is required to perform this service operation. Please contact
        the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            f"/udl/sensor/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/sensor/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_count_params.SensorCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorGetResponse:
        """
        Service operation to get a single Sensor by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/sensor/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_get_params.SensorGetParams,
                ),
            ),
            cast_to=SensorGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/sensor/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SensorQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/sensor/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_tuple_params.SensorTupleParams,
                ),
            ),
            cast_to=SensorTupleResponse,
        )


class AsyncSensorResource(AsyncAPIResource):
    """This service provides operations for querying and manipulation of sensor data.

    Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
    """

    @cached_property
    def calibration(self) -> AsyncCalibrationResource:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return AsyncCalibrationResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSensorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSensorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSensorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncSensorResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        sensor_name: str,
        source: str,
        active: bool | Omit = omit,
        af_id: str | Omit = omit,
        asr_type: str | Omit = omit,
        data_control: str | Omit = omit,
        entity: sensor_create_params.Entity | Omit = omit,
        id_entity: str | Omit = omit,
        id_sensor: str | Omit = omit,
        origin: str | Omit = omit,
        sensorcharacteristics: Iterable[sensor_create_params.Sensorcharacteristic] | Omit = omit,
        sensorlimits_collection: Iterable[sensor_create_params.SensorlimitsCollection] | Omit = omit,
        sensor_number: int | Omit = omit,
        sensor_observation_type: sensor_create_params.SensorObservationType | Omit = omit,
        sensor_stats: Iterable[sensor_create_params.SensorStat] | Omit = omit,
        sensor_type: sensor_create_params.SensorType | Omit = omit,
        short_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single sensor as a POST body and ingest into the
        database. A specific role is required to perform this service operation. Please
        contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          sensor_name: Unique name of this sensor.

          source: Source of the data.

          active: Optional flag indicating if the sensor is active.

          af_id: Optional US Air Force identifier for the sensor/ASR site, typically for air
              surveillance radar (ASR) sensors.

          asr_type: The sensor type at the site. Optional field, intended primarily for ASRs.

          data_control: Optional dissemination control required for accessing data (e.g observations)
              produced by this sensor. This is typically a proprietary data owner control for
              commercial sensors.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_sensor: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          sensorcharacteristics: Collection of Sensorcharacteristics which define characteristics and
              capabilities of a sensor.

          sensorlimits_collection: Sensorlimits define 0 to many limits of a particular sensor in terms of
              observation coverage of on-orbit objects.

          sensor_number: Number assigned to this sensor. Since there is no authoritative numbering
              scheme, these numbers sometimes collide across sensors (especially commercial
              sensors). It is therefore not a unique identifier.

          sensor_stats: Collection of SensorStats which contain statistics of a sensor.

          short_name: Optional short name for the sensor.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/sensor",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "sensor_name": sensor_name,
                    "source": source,
                    "active": active,
                    "af_id": af_id,
                    "asr_type": asr_type,
                    "data_control": data_control,
                    "entity": entity,
                    "id_entity": id_entity,
                    "id_sensor": id_sensor,
                    "origin": origin,
                    "sensorcharacteristics": sensorcharacteristics,
                    "sensorlimits_collection": sensorlimits_collection,
                    "sensor_number": sensor_number,
                    "sensor_observation_type": sensor_observation_type,
                    "sensor_stats": sensor_stats,
                    "sensor_type": sensor_type,
                    "short_name": short_name,
                },
                sensor_create_params.SensorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        sensor_name: str,
        source: str,
        active: bool | Omit = omit,
        af_id: str | Omit = omit,
        asr_type: str | Omit = omit,
        data_control: str | Omit = omit,
        entity: sensor_update_params.Entity | Omit = omit,
        id_entity: str | Omit = omit,
        id_sensor: str | Omit = omit,
        origin: str | Omit = omit,
        sensorcharacteristics: Iterable[sensor_update_params.Sensorcharacteristic] | Omit = omit,
        sensorlimits_collection: Iterable[sensor_update_params.SensorlimitsCollection] | Omit = omit,
        sensor_number: int | Omit = omit,
        sensor_observation_type: sensor_update_params.SensorObservationType | Omit = omit,
        sensor_stats: Iterable[sensor_update_params.SensorStat] | Omit = omit,
        sensor_type: sensor_update_params.SensorType | Omit = omit,
        short_name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single Sensor.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          sensor_name: Unique name of this sensor.

          source: Source of the data.

          active: Optional flag indicating if the sensor is active.

          af_id: Optional US Air Force identifier for the sensor/ASR site, typically for air
              surveillance radar (ASR) sensors.

          asr_type: The sensor type at the site. Optional field, intended primarily for ASRs.

          data_control: Optional dissemination control required for accessing data (e.g observations)
              produced by this sensor. This is typically a proprietary data owner control for
              commercial sensors.

          entity: An entity is a generic representation of any object within a space/SSA system
              such as sensors, on-orbit objects, RF Emitters, space craft buses, etc. An
              entity can have an operating unit, a location (if terrestrial), and statuses.

          id_entity: Unique identifier of the parent entity. idEntity is required for Put.

          id_sensor: Unique identifier of the record, auto-generated by the system.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          sensorcharacteristics: Collection of Sensorcharacteristics which define characteristics and
              capabilities of a sensor.

          sensorlimits_collection: Sensorlimits define 0 to many limits of a particular sensor in terms of
              observation coverage of on-orbit objects.

          sensor_number: Number assigned to this sensor. Since there is no authoritative numbering
              scheme, these numbers sometimes collide across sensors (especially commercial
              sensors). It is therefore not a unique identifier.

          sensor_stats: Collection of SensorStats which contain statistics of a sensor.

          short_name: Optional short name for the sensor.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/sensor/{id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "sensor_name": sensor_name,
                    "source": source,
                    "active": active,
                    "af_id": af_id,
                    "asr_type": asr_type,
                    "data_control": data_control,
                    "entity": entity,
                    "id_entity": id_entity,
                    "id_sensor": id_sensor,
                    "origin": origin,
                    "sensorcharacteristics": sensorcharacteristics,
                    "sensorlimits_collection": sensorlimits_collection,
                    "sensor_number": sensor_number,
                    "sensor_observation_type": sensor_observation_type,
                    "sensor_stats": sensor_stats,
                    "sensor_type": sensor_type,
                    "short_name": short_name,
                },
                sensor_update_params.SensorUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SensorListResponse, AsyncOffsetPage[SensorListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/sensor",
            page=AsyncOffsetPage[SensorListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_list_params.SensorListParams,
                ),
            ),
            model=SensorListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to delete a Sensor specified by the passed ID path parameter.
        A specific role is required to perform this service operation. Please contact
        the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            f"/udl/sensor/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def count(
        self,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/sensor/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_count_params.SensorCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorGetResponse:
        """
        Service operation to get a single Sensor by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/sensor/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_get_params.SensorGetParams,
                ),
            ),
            cast_to=SensorGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/sensor/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SensorQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/sensor/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_tuple_params.SensorTupleParams,
                ),
            ),
            cast_to=SensorTupleResponse,
        )


class SensorResourceWithRawResponse:
    def __init__(self, sensor: SensorResource) -> None:
        self._sensor = sensor

        self.create = to_raw_response_wrapper(
            sensor.create,
        )
        self.update = to_raw_response_wrapper(
            sensor.update,
        )
        self.list = to_raw_response_wrapper(
            sensor.list,
        )
        self.delete = to_raw_response_wrapper(
            sensor.delete,
        )
        self.count = to_raw_response_wrapper(
            sensor.count,
        )
        self.get = to_raw_response_wrapper(
            sensor.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            sensor.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            sensor.tuple,
        )

    @cached_property
    def calibration(self) -> CalibrationResourceWithRawResponse:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return CalibrationResourceWithRawResponse(self._sensor.calibration)


class AsyncSensorResourceWithRawResponse:
    def __init__(self, sensor: AsyncSensorResource) -> None:
        self._sensor = sensor

        self.create = async_to_raw_response_wrapper(
            sensor.create,
        )
        self.update = async_to_raw_response_wrapper(
            sensor.update,
        )
        self.list = async_to_raw_response_wrapper(
            sensor.list,
        )
        self.delete = async_to_raw_response_wrapper(
            sensor.delete,
        )
        self.count = async_to_raw_response_wrapper(
            sensor.count,
        )
        self.get = async_to_raw_response_wrapper(
            sensor.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            sensor.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            sensor.tuple,
        )

    @cached_property
    def calibration(self) -> AsyncCalibrationResourceWithRawResponse:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return AsyncCalibrationResourceWithRawResponse(self._sensor.calibration)


class SensorResourceWithStreamingResponse:
    def __init__(self, sensor: SensorResource) -> None:
        self._sensor = sensor

        self.create = to_streamed_response_wrapper(
            sensor.create,
        )
        self.update = to_streamed_response_wrapper(
            sensor.update,
        )
        self.list = to_streamed_response_wrapper(
            sensor.list,
        )
        self.delete = to_streamed_response_wrapper(
            sensor.delete,
        )
        self.count = to_streamed_response_wrapper(
            sensor.count,
        )
        self.get = to_streamed_response_wrapper(
            sensor.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            sensor.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            sensor.tuple,
        )

    @cached_property
    def calibration(self) -> CalibrationResourceWithStreamingResponse:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return CalibrationResourceWithStreamingResponse(self._sensor.calibration)


class AsyncSensorResourceWithStreamingResponse:
    def __init__(self, sensor: AsyncSensorResource) -> None:
        self._sensor = sensor

        self.create = async_to_streamed_response_wrapper(
            sensor.create,
        )
        self.update = async_to_streamed_response_wrapper(
            sensor.update,
        )
        self.list = async_to_streamed_response_wrapper(
            sensor.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            sensor.delete,
        )
        self.count = async_to_streamed_response_wrapper(
            sensor.count,
        )
        self.get = async_to_streamed_response_wrapper(
            sensor.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            sensor.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            sensor.tuple,
        )

    @cached_property
    def calibration(self) -> AsyncCalibrationResourceWithStreamingResponse:
        """This service provides operations for querying and manipulation of sensor data.

        Sensors are terrestrial or on-orbit equipment capable of taking measurements or 'observations' of on-orbit objects via several phenomenologies such as Electro-Optical (EO), Radar, and Radio Frequency (RF). This collection of operations includes 'SensorMaintenance' schedules which define known/planned future maintenance and associated operational impact of sensors as well as 'SensorCalibration' records which contains data about a sensor's overall accuracy and is used to adjust sensor settings.
        """
        return AsyncCalibrationResourceWithStreamingResponse(self._sensor.calibration)
