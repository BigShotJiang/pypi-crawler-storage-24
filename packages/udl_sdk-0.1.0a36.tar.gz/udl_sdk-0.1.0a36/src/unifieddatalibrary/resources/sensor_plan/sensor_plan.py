# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...types import (
    sensor_plan_get_params,
    sensor_plan_list_params,
    sensor_plan_count_params,
    sensor_plan_tuple_params,
    sensor_plan_create_params,
    sensor_plan_update_params,
    sensor_plan_unvalidated_publish_params,
)
from .history import (
    HistoryResource,
    AsyncHistoryResource,
    HistoryResourceWithRawResponse,
    AsyncHistoryResourceWithRawResponse,
    HistoryResourceWithStreamingResponse,
    AsyncHistoryResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPage, AsyncOffsetPage
from ..._base_client import AsyncPaginator, make_request_options
from ...types.sensor_plan_get_response import SensorPlanGetResponse
from ...types.sensor_plan_list_response import SensorPlanListResponse
from ...types.sensor_plan_tuple_response import SensorPlanTupleResponse
from ...types.sensor_plan_queryhelp_response import SensorPlanQueryhelpResponse

__all__ = ["SensorPlanResource", "AsyncSensorPlanResource"]


class SensorPlanResource(SyncAPIResource):
    """These services provide operations for posting and querying Sensor Tasking data."""

    @cached_property
    def history(self) -> HistoryResource:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return HistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> SensorPlanResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SensorPlanResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SensorPlanResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return SensorPlanResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        rec_type: str,
        source: str,
        start_time: Union[str, datetime],
        type: str,
        id: str | Omit = omit,
        collect_requests: Iterable[sensor_plan_create_params.CollectRequest] | Omit = omit,
        customer: str | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        id_sensor: str | Omit = omit,
        name: str | Omit = omit,
        origin: str | Omit = omit,
        orig_sensor_id: str | Omit = omit,
        purpose: str | Omit = omit,
        req_total: int | Omit = omit,
        sen_network: str | Omit = omit,
        status: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single sensor plan as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          rec_type: The type of records that comprise this parent set (COLLECT, CONTACT).

          source: Source of the data.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.

          type: The type of this sensor plan/schedule (PLAN, REQUEST, SCHEDULE).

          id: Unique identifier of the record, auto-generated by the system.

          collect_requests: The list of collect requests belonging to the SensorPlan. Each collect request
              is associated with a parent SensorPlan via the IdPlan. If provided, the list
              must have the same size as reqTotal.

          customer: The customer for this plan or schedule.

          end_time: The end time of the plan or schedule, in ISO 8601 UTC format.

          id_sensor: Unique identifier of the requested/schedule/planned sensor associated with this
              request.

          name: Name associated with this plan or schedule.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_sensor_id: Optional identifier provided by the source to indicate the sensor identifier
              requested/scheduled/planned for this request. This may be an internal identifier
              and not necessarily a valid sensor ID.

          purpose: The purpose/description of this plan or schedule.

          req_total: The total number of requests contained in this plan or schedule. Value of this
              field must match the size of collectRequest list if the list is provided and can
              be null or any value otherwise.

          sen_network: The sensor or ground network associated with this plan or schedule.

          status: The status of this plan or schedule (ACCEPTED, APPROVED, COMPLETED, PROPOSED,
              REJECTED, REQUESTED, SCHEDULED).

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/udl/sensorplan",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "rec_type": rec_type,
                    "source": source,
                    "start_time": start_time,
                    "type": type,
                    "id": id,
                    "collect_requests": collect_requests,
                    "customer": customer,
                    "end_time": end_time,
                    "id_sensor": id_sensor,
                    "name": name,
                    "origin": origin,
                    "orig_sensor_id": orig_sensor_id,
                    "purpose": purpose,
                    "req_total": req_total,
                    "sen_network": sen_network,
                    "status": status,
                    "tags": tags,
                },
                sensor_plan_create_params.SensorPlanCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        rec_type: str,
        source: str,
        start_time: Union[str, datetime],
        type: str,
        body_id: str | Omit = omit,
        collect_requests: Iterable[sensor_plan_update_params.CollectRequest] | Omit = omit,
        customer: str | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        id_sensor: str | Omit = omit,
        name: str | Omit = omit,
        origin: str | Omit = omit,
        orig_sensor_id: str | Omit = omit,
        purpose: str | Omit = omit,
        req_total: int | Omit = omit,
        sen_network: str | Omit = omit,
        status: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single SensorPlan.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          rec_type: The type of records that comprise this parent set (COLLECT, CONTACT).

          source: Source of the data.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.

          type: The type of this sensor plan/schedule (PLAN, REQUEST, SCHEDULE).

          body_id: Unique identifier of the record, auto-generated by the system.

          collect_requests: The list of collect requests belonging to the SensorPlan. Each collect request
              is associated with a parent SensorPlan via the IdPlan. If provided, the list
              must have the same size as reqTotal.

          customer: The customer for this plan or schedule.

          end_time: The end time of the plan or schedule, in ISO 8601 UTC format.

          id_sensor: Unique identifier of the requested/schedule/planned sensor associated with this
              request.

          name: Name associated with this plan or schedule.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_sensor_id: Optional identifier provided by the source to indicate the sensor identifier
              requested/scheduled/planned for this request. This may be an internal identifier
              and not necessarily a valid sensor ID.

          purpose: The purpose/description of this plan or schedule.

          req_total: The total number of requests contained in this plan or schedule. Value of this
              field must match the size of collectRequest list if the list is provided and can
              be null or any value otherwise.

          sen_network: The sensor or ground network associated with this plan or schedule.

          status: The status of this plan or schedule (ACCEPTED, APPROVED, COMPLETED, PROPOSED,
              REJECTED, REQUESTED, SCHEDULED).

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._put(
            f"/udl/sensorplan/{path_id}",
            body=maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "rec_type": rec_type,
                    "source": source,
                    "start_time": start_time,
                    "type": type,
                    "body_id": body_id,
                    "collect_requests": collect_requests,
                    "customer": customer,
                    "end_time": end_time,
                    "id_sensor": id_sensor,
                    "name": name,
                    "origin": origin,
                    "orig_sensor_id": orig_sensor_id,
                    "purpose": purpose,
                    "req_total": req_total,
                    "sen_network": sen_network,
                    "status": status,
                    "tags": tags,
                },
                sensor_plan_update_params.SensorPlanUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPage[SensorPlanListResponse]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/sensorplan",
            page=SyncOffsetPage[SensorPlanListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_list_params.SensorPlanListParams,
                ),
            ),
            model=SensorPlanListResponse,
        )

    def count(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return self._get(
            "/udl/sensorplan/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_count_params.SensorPlanCountParams,
                ),
            ),
            cast_to=str,
        )

    def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanGetResponse:
        """
        Service operation to get a single SensorPlan by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/udl/sensorplan/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_get_params.SensorPlanGetParams,
                ),
            ),
            cast_to=SensorPlanGetResponse,
        )

    def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return self._get(
            "/udl/sensorplan/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SensorPlanQueryhelpResponse,
        )

    def tuple(
        self,
        *,
        columns: str,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/udl/sensorplan/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "columns": columns,
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_tuple_params.SensorPlanTupleParams,
                ),
            ),
            cast_to=SensorPlanTupleResponse,
        )

    def unvalidated_publish(
        self,
        *,
        body: Iterable[sensor_plan_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take one or more sensorplan record(s) as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._post(
            "/filedrop/udl-sensorplan",
            body=maybe_transform(body, Iterable[sensor_plan_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class AsyncSensorPlanResource(AsyncAPIResource):
    """These services provide operations for posting and querying Sensor Tasking data."""

    @cached_property
    def history(self) -> AsyncHistoryResource:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return AsyncHistoryResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSensorPlanResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSensorPlanResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSensorPlanResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Bluestaq/udl-python-sdk#with_streaming_response
        """
        return AsyncSensorPlanResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        rec_type: str,
        source: str,
        start_time: Union[str, datetime],
        type: str,
        id: str | Omit = omit,
        collect_requests: Iterable[sensor_plan_create_params.CollectRequest] | Omit = omit,
        customer: str | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        id_sensor: str | Omit = omit,
        name: str | Omit = omit,
        origin: str | Omit = omit,
        orig_sensor_id: str | Omit = omit,
        purpose: str | Omit = omit,
        req_total: int | Omit = omit,
        sen_network: str | Omit = omit,
        status: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take a single sensor plan as a POST body and ingest into
        the database. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          rec_type: The type of records that comprise this parent set (COLLECT, CONTACT).

          source: Source of the data.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.

          type: The type of this sensor plan/schedule (PLAN, REQUEST, SCHEDULE).

          id: Unique identifier of the record, auto-generated by the system.

          collect_requests: The list of collect requests belonging to the SensorPlan. Each collect request
              is associated with a parent SensorPlan via the IdPlan. If provided, the list
              must have the same size as reqTotal.

          customer: The customer for this plan or schedule.

          end_time: The end time of the plan or schedule, in ISO 8601 UTC format.

          id_sensor: Unique identifier of the requested/schedule/planned sensor associated with this
              request.

          name: Name associated with this plan or schedule.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_sensor_id: Optional identifier provided by the source to indicate the sensor identifier
              requested/scheduled/planned for this request. This may be an internal identifier
              and not necessarily a valid sensor ID.

          purpose: The purpose/description of this plan or schedule.

          req_total: The total number of requests contained in this plan or schedule. Value of this
              field must match the size of collectRequest list if the list is provided and can
              be null or any value otherwise.

          sen_network: The sensor or ground network associated with this plan or schedule.

          status: The status of this plan or schedule (ACCEPTED, APPROVED, COMPLETED, PROPOSED,
              REJECTED, REQUESTED, SCHEDULED).

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/udl/sensorplan",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "rec_type": rec_type,
                    "source": source,
                    "start_time": start_time,
                    "type": type,
                    "id": id,
                    "collect_requests": collect_requests,
                    "customer": customer,
                    "end_time": end_time,
                    "id_sensor": id_sensor,
                    "name": name,
                    "origin": origin,
                    "orig_sensor_id": orig_sensor_id,
                    "purpose": purpose,
                    "req_total": req_total,
                    "sen_network": sen_network,
                    "status": status,
                    "tags": tags,
                },
                sensor_plan_create_params.SensorPlanCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def update(
        self,
        path_id: str,
        *,
        classification_marking: str,
        data_mode: Literal["REAL", "TEST", "SIMULATED", "EXERCISE"],
        rec_type: str,
        source: str,
        start_time: Union[str, datetime],
        type: str,
        body_id: str | Omit = omit,
        collect_requests: Iterable[sensor_plan_update_params.CollectRequest] | Omit = omit,
        customer: str | Omit = omit,
        end_time: Union[str, datetime] | Omit = omit,
        id_sensor: str | Omit = omit,
        name: str | Omit = omit,
        origin: str | Omit = omit,
        orig_sensor_id: str | Omit = omit,
        purpose: str | Omit = omit,
        req_total: int | Omit = omit,
        sen_network: str | Omit = omit,
        status: str | Omit = omit,
        tags: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Service operation to update a single SensorPlan.

        A specific role is required to
        perform this service operation. Please contact the UDL team for assistance.

        Args:
          classification_marking: Classification marking of the data in IC/CAPCO Portion-marked format.

          data_mode:
              Indicator of whether the data is REAL, TEST, EXERCISE, or SIMULATED data:

              REAL:&nbsp;Data collected or produced that pertains to real-world objects,
              events, and analysis.

              TEST:&nbsp;Specific datasets used to evaluate compliance with specifications and
              requirements, and for validating technical, functional, and performance
              characteristics.

              EXERCISE:&nbsp;Data pertaining to a government or military exercise. The data
              may include both real and simulated data.

              SIMULATED:&nbsp;Synthetic data generated by a model to mimic real-world
              datasets.

          rec_type: The type of records that comprise this parent set (COLLECT, CONTACT).

          source: Source of the data.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.

          type: The type of this sensor plan/schedule (PLAN, REQUEST, SCHEDULE).

          body_id: Unique identifier of the record, auto-generated by the system.

          collect_requests: The list of collect requests belonging to the SensorPlan. Each collect request
              is associated with a parent SensorPlan via the IdPlan. If provided, the list
              must have the same size as reqTotal.

          customer: The customer for this plan or schedule.

          end_time: The end time of the plan or schedule, in ISO 8601 UTC format.

          id_sensor: Unique identifier of the requested/schedule/planned sensor associated with this
              request.

          name: Name associated with this plan or schedule.

          origin: Originating system or organization which produced the data, if different from
              the source. The origin may be different than the source if the source was a
              mediating system which forwarded the data on behalf of the origin system. If
              null, the source may be assumed to be the origin.

          orig_sensor_id: Optional identifier provided by the source to indicate the sensor identifier
              requested/scheduled/planned for this request. This may be an internal identifier
              and not necessarily a valid sensor ID.

          purpose: The purpose/description of this plan or schedule.

          req_total: The total number of requests contained in this plan or schedule. Value of this
              field must match the size of collectRequest list if the list is provided and can
              be null or any value otherwise.

          sen_network: The sensor or ground network associated with this plan or schedule.

          status: The status of this plan or schedule (ACCEPTED, APPROVED, COMPLETED, PROPOSED,
              REJECTED, REQUESTED, SCHEDULED).

          tags: Optional array of provider/source specific tags for this data, where each
              element is no longer than 32 characters, used for implementing data owner
              conditional access controls to restrict access to the data. Should be left null
              by data providers unless conditional access controls are coordinated with the
              UDL team.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not path_id:
            raise ValueError(f"Expected a non-empty value for `path_id` but received {path_id!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._put(
            f"/udl/sensorplan/{path_id}",
            body=await async_maybe_transform(
                {
                    "classification_marking": classification_marking,
                    "data_mode": data_mode,
                    "rec_type": rec_type,
                    "source": source,
                    "start_time": start_time,
                    "type": type,
                    "body_id": body_id,
                    "collect_requests": collect_requests,
                    "customer": customer,
                    "end_time": end_time,
                    "id_sensor": id_sensor,
                    "name": name,
                    "origin": origin,
                    "orig_sensor_id": orig_sensor_id,
                    "purpose": purpose,
                    "req_total": req_total,
                    "sen_network": sen_network,
                    "status": status,
                    "tags": tags,
                },
                sensor_plan_update_params.SensorPlanUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def list(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SensorPlanListResponse, AsyncOffsetPage[SensorPlanListResponse]]:
        """
        Service operation to dynamically query data by a variety of query parameters not
        specified in this API documentation. See the queryhelp operation
        (/udl/&lt;datatype&gt;/queryhelp) for more details on valid/required query
        parameter information.

        Args:
          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/udl/sensorplan",
            page=AsyncOffsetPage[SensorPlanListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_list_params.SensorPlanListParams,
                ),
            ),
            model=SensorPlanListResponse,
        )

    async def count(
        self,
        *,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Service operation to return the count of records satisfying the specified query
        parameters. This operation is useful to determine how many records pass a
        particular query criteria without retrieving large amounts of data. See the
        queryhelp operation (/udl/&lt;datatype&gt;/queryhelp) for more details on
        valid/required query parameter information.

        Args:
          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "text/plain", **(extra_headers or {})}
        return await self._get(
            "/udl/sensorplan/count",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_count_params.SensorPlanCountParams,
                ),
            ),
            cast_to=str,
        )

    async def get(
        self,
        id: str,
        *,
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanGetResponse:
        """
        Service operation to get a single SensorPlan by its unique ID passed as a path
        parameter.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/udl/sensorplan/{id}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_get_params.SensorPlanGetParams,
                ),
            ),
            cast_to=SensorPlanGetResponse,
        )

    async def queryhelp(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanQueryhelpResponse:
        """
        Service operation to provide detailed information on available dynamic query
        parameters for a particular data type.
        """
        return await self._get(
            "/udl/sensorplan/queryhelp",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SensorPlanQueryhelpResponse,
        )

    async def tuple(
        self,
        *,
        columns: str,
        start_time: Union[str, datetime],
        first_result: int | Omit = omit,
        max_results: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SensorPlanTupleResponse:
        """
        Service operation to dynamically query data and only return specified
        columns/fields. Requested columns are specified by the 'columns' query parameter
        and should be a comma separated list of valid fields for the specified data
        type. classificationMarking is always returned. See the queryhelp operation
        (/udl/<datatype>/queryhelp) for more details on valid/required query parameter
        information. An example URI: /udl/elset/tuple?columns=satNo,period&epoch=>now-5
        hours would return the satNo and period of elsets with an epoch greater than 5
        hours ago.

        Args:
          columns: Comma-separated list of valid field names for this data type to be returned in
              the response. Only the fields specified will be returned as well as the
              classification marking of the data, if applicable. See the ‘queryhelp’ operation
              for a complete list of possible fields.

          start_time: The start time of the plan or schedule, in ISO 8601 UTC format.
              (YYYY-MM-DDTHH:MM:SS.ssssssZ)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/udl/sensorplan/tuple",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "columns": columns,
                        "start_time": start_time,
                        "first_result": first_result,
                        "max_results": max_results,
                    },
                    sensor_plan_tuple_params.SensorPlanTupleParams,
                ),
            ),
            cast_to=SensorPlanTupleResponse,
        )

    async def unvalidated_publish(
        self,
        *,
        body: Iterable[sensor_plan_unvalidated_publish_params.Body],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """
        Service operation to take one or more sensorplan record(s) as a POST body and
        ingest into the database. This operation is intended to be used for automated
        feeds into UDL. A specific role is required to perform this service operation.
        Please contact the UDL team for assistance.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._post(
            "/filedrop/udl-sensorplan",
            body=await async_maybe_transform(body, Iterable[sensor_plan_unvalidated_publish_params.Body]),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )


class SensorPlanResourceWithRawResponse:
    def __init__(self, sensor_plan: SensorPlanResource) -> None:
        self._sensor_plan = sensor_plan

        self.create = to_raw_response_wrapper(
            sensor_plan.create,
        )
        self.update = to_raw_response_wrapper(
            sensor_plan.update,
        )
        self.list = to_raw_response_wrapper(
            sensor_plan.list,
        )
        self.count = to_raw_response_wrapper(
            sensor_plan.count,
        )
        self.get = to_raw_response_wrapper(
            sensor_plan.get,
        )
        self.queryhelp = to_raw_response_wrapper(
            sensor_plan.queryhelp,
        )
        self.tuple = to_raw_response_wrapper(
            sensor_plan.tuple,
        )
        self.unvalidated_publish = to_raw_response_wrapper(
            sensor_plan.unvalidated_publish,
        )

    @cached_property
    def history(self) -> HistoryResourceWithRawResponse:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return HistoryResourceWithRawResponse(self._sensor_plan.history)


class AsyncSensorPlanResourceWithRawResponse:
    def __init__(self, sensor_plan: AsyncSensorPlanResource) -> None:
        self._sensor_plan = sensor_plan

        self.create = async_to_raw_response_wrapper(
            sensor_plan.create,
        )
        self.update = async_to_raw_response_wrapper(
            sensor_plan.update,
        )
        self.list = async_to_raw_response_wrapper(
            sensor_plan.list,
        )
        self.count = async_to_raw_response_wrapper(
            sensor_plan.count,
        )
        self.get = async_to_raw_response_wrapper(
            sensor_plan.get,
        )
        self.queryhelp = async_to_raw_response_wrapper(
            sensor_plan.queryhelp,
        )
        self.tuple = async_to_raw_response_wrapper(
            sensor_plan.tuple,
        )
        self.unvalidated_publish = async_to_raw_response_wrapper(
            sensor_plan.unvalidated_publish,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithRawResponse:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return AsyncHistoryResourceWithRawResponse(self._sensor_plan.history)


class SensorPlanResourceWithStreamingResponse:
    def __init__(self, sensor_plan: SensorPlanResource) -> None:
        self._sensor_plan = sensor_plan

        self.create = to_streamed_response_wrapper(
            sensor_plan.create,
        )
        self.update = to_streamed_response_wrapper(
            sensor_plan.update,
        )
        self.list = to_streamed_response_wrapper(
            sensor_plan.list,
        )
        self.count = to_streamed_response_wrapper(
            sensor_plan.count,
        )
        self.get = to_streamed_response_wrapper(
            sensor_plan.get,
        )
        self.queryhelp = to_streamed_response_wrapper(
            sensor_plan.queryhelp,
        )
        self.tuple = to_streamed_response_wrapper(
            sensor_plan.tuple,
        )
        self.unvalidated_publish = to_streamed_response_wrapper(
            sensor_plan.unvalidated_publish,
        )

    @cached_property
    def history(self) -> HistoryResourceWithStreamingResponse:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return HistoryResourceWithStreamingResponse(self._sensor_plan.history)


class AsyncSensorPlanResourceWithStreamingResponse:
    def __init__(self, sensor_plan: AsyncSensorPlanResource) -> None:
        self._sensor_plan = sensor_plan

        self.create = async_to_streamed_response_wrapper(
            sensor_plan.create,
        )
        self.update = async_to_streamed_response_wrapper(
            sensor_plan.update,
        )
        self.list = async_to_streamed_response_wrapper(
            sensor_plan.list,
        )
        self.count = async_to_streamed_response_wrapper(
            sensor_plan.count,
        )
        self.get = async_to_streamed_response_wrapper(
            sensor_plan.get,
        )
        self.queryhelp = async_to_streamed_response_wrapper(
            sensor_plan.queryhelp,
        )
        self.tuple = async_to_streamed_response_wrapper(
            sensor_plan.tuple,
        )
        self.unvalidated_publish = async_to_streamed_response_wrapper(
            sensor_plan.unvalidated_publish,
        )

    @cached_property
    def history(self) -> AsyncHistoryResourceWithStreamingResponse:
        """These services provide operations for posting and querying Sensor Tasking data."""
        return AsyncHistoryResourceWithStreamingResponse(self._sensor_plan.history)
