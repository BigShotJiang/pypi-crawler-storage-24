from .dynamic_explorer import inspect_dynamic
from .static_explorer import inspect_static
from .online_file_explorer import inspect_file
from .page_type import decide_sd, is_document_url


def inspect_page(url, log_file, query, primary_key, primary_key_val, col, given_info, client):
    if is_document_url(url):
        print(f"  [Explore] {url} → document")
        return inspect_file(url, query, primary_key, primary_key_val, col, client, given_info, log_file), [], True, None, {}, True
    is_static, base_url = decide_sd(url, query, primary_key, primary_key_val, col, given_info, client, log_file)
    print(f"  [Explore] {base_url} → {'static' if is_static else 'dynamic'}")
    if is_static:
        given_info, next_level_links, proceed, source_url, path_record_level = inspect_static(base_url, query, primary_key, primary_key_val, col, client, given_info, log_file)
    else:
        given_info, next_level_links, proceed, source_url, path_record_level = inspect_dynamic(base_url, query, primary_key, primary_key_val, col, given_info, client, log_file)

    return given_info, next_level_links, proceed, source_url, path_record_level, is_static