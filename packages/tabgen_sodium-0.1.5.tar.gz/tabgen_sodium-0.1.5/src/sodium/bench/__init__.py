import json
import pathlib

import pandas as pd

_DATA = pathlib.Path(__file__).parent / "_data"


def _load_queries() -> dict:
    with open(_DATA / "queries.json", encoding="utf-8") as f:
        return json.load(f)


def list_queries() -> list:
    """Return sorted list of all query IDs in the benchmark."""
    return sorted(int(k) for k in _load_queries())


def get_query(id) -> dict:
    """Return metadata for a single benchmark query (query, primary_key, base_url, etc.)."""
    queries = _load_queries()
    key = str(id)
    if key not in queries:
        raise KeyError(f"Query id={id} not found in benchmark.")
    return queries[key]


def get_schema(id) -> pd.DataFrame:
    """Return the schema DataFrame (column names) for a benchmark query."""
    path = _DATA / "schema" / f"{id}.csv"
    if not path.exists():
        raise FileNotFoundError(f"Schema not found: {path}")
    return pd.read_csv(path)


def evaluate(id, output_csv, gt_root, out_root="eval_outputs"):
    """Evaluate agent predictions against ground truth.

    Args:
        id:         Benchmark query ID.
        output_csv: Path to the agent's output.csv.
        gt_root:    Directory containing ground-truth CSVs (e.g. gt/1.csv).
        out_root:   Directory to write evaluation outputs (default: eval_outputs/).

    Returns:
        (llm_matched, total, llm_pct, str_matched, total, str_pct)
    """
    from sodium.bench.eval.evaluation import evaluate_id

    queries_path = str(_DATA / "queries.json")
    return evaluate_id(id, output_csv, queries_path, gt_root, out_root)
