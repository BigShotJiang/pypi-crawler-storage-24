#!/usr/bin/python3


import logging
from typing import NoReturn

from slpkg.config import config_load

logger = logging.getLogger(__name__)


class Errors:  # pylint: disable=[R0903]
    """Raise an error message."""

    def __init__(self) -> None:
        logger.debug("Initializing Errors class.")
        self.prog_name = config_load.prog_name
        self.red = config_load.red
        self.endc = config_load.endc
        logger.debug("Errors class initialized with program name: %s", self.prog_name)

    def message(self, message: str, exit_status: int) -> NoReturn:
        """General method to raise an error message and exit.

        Logs the error message at a critical level before printing to console and exiting.

        Args:
            message (str): String message to display and log.
            exit_status (int): Exit status code for the application.

        Raises:
            SystemExit: Exits the application with the specified status code.
        """
        logger.critical("Application exiting with error (status %d): %s", exit_status, message)
        print(f"\n{self.prog_name}: {self.red}Error{self.endc}: {message}\n")
        raise SystemExit(exit_status)
