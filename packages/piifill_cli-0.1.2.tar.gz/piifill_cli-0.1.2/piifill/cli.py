import typer
import os
import sys
from pathlib import Path
from typing import Optional, List
from concurrent.futures import ProcessPoolExecutor, as_completed
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table

# --- Internal Imports ---
from .shared.config import settings
from .shared.ui import (
    setup_logger, print_banner, t, print_step, print_status, 
    print_error, print_success, format_detection_table, console,
    translator
)
from .engine.manager import filtration_manager, FiltrationManager
from .logic.factory import FileProcessor

# --- Initialization ---
logger = setup_logger(settings.log_file, settings.log_level)

# --- CLI Application ---
app = typer.Typer(
    help="PIIFILL: Professional Enterprise-Grade PII Sanitization CLI.",
    no_args_is_help=False,
    add_completion=False,
)

# --- Helpers ---
def version_callback(value: bool):
    if value:
        print_banner()
        console.print("[bold cyan]PIIFILL CLI Version:[/bold cyan] 0.1.2")
        console.print("[dim]Enterprise-Grade Local PII Sanitization CLI[/dim]")
        raise typer.Exit()

def _worker_process_file(fpath: Path, input_path: Path, output_dir: Path, final_name: Optional[str], mode: str):
    """Worker function for multi-core processing."""
    worker_engine = FiltrationManager()
    filename = fpath.name
    try:
        if input_path.is_dir():
            relative_path = fpath.relative_to(input_path)
            final_output_path = output_dir / relative_path
        else:
            final_output_path = output_dir / final_name
        
        final_output_path.parent.mkdir(parents=True, exist_ok=True)
        parser_instance = FileProcessor.get_parser(fpath.suffix)
        parser_instance.parse_file(fpath, final_output_path, worker_engine, mode)
        return filename, True, worker_engine.get_session_report()
    except Exception as e:
        return filename, False, str(e)

# --- Commands ---
@app.command(name="mask", help="Securely protect assets (Files/Directories)")
def mask_command(
    path: Path = typer.Argument(..., help="File or directory path to secure"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Custom output path"),
    mode: str = typer.Option("mask", "--mode", "-m", help="Sanitization strategy (mask/redact/tokenize)"),
    local: bool = typer.Option(False, "--local", "-l", help="Rapid local directory protection (scans current dir)")
):
    """Securely mask sensitive data in assets."""
    if local and path is None:
        path = Path(".")

    if path is None:
        print_error("Path is required.")
        raise typer.Exit(code=1)

    input_path = path.resolve()
    if not input_path.exists():
        print_error(t("error_path_exists", path=str(input_path)))
        raise typer.Exit(code=1)

    if input_path.is_file():
        files_to_process = [input_path]
        if output:
            if output.suffix:
                final_output_path_base = output.resolve()
                output_dir = final_output_path_base.parent
                final_name = final_output_path_base.name
            else:
                output_dir = output.resolve()
                final_name = input_path.name
        else:
            output_dir = input_path.parent / "out"
            final_name = input_path.name
    else:
        files_to_process = [p for p in input_path.rglob("*") if p.is_file() and not p.name.startswith('.')]
        output_dir = output.resolve() if output else input_path / "out"
        final_name = None

    if not files_to_process:
        print_error(t("error_no_files", path=str(input_path)))
        raise typer.Exit()

    output_dir.mkdir(parents=True, exist_ok=True)
    
    results_table = Table(title=t("results_table_title"), box=None, header_style="bold cyan")
    results_table.add_column(t("results_asset"), style="cyan")
    results_table.add_column(t("results_status"), justify="center")
    results_table.add_column(t("results_grade"), justify="center")

    if len(files_to_process) > 1:
        print_step(t("step_deploy_parallel", count=f"[bold]{os.cpu_count()}[/bold]", file_count=f"[bold]{len(files_to_process)}[/bold]"))
        with Progress(SpinnerColumn(), TextColumn(f"[cyan]{t('status_parallel')}"), BarColumn(bar_width=40, pulse_style="cyan"), TaskProgressColumn(), console=console, transient=True) as progress:
            task = progress.add_task(t("status_securing"), total=len(files_to_process))
            with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
                futures = [executor.submit(_worker_process_file, f, input_path, output_dir, final_name, mode) for f in files_to_process]
                for future in as_completed(futures):
                    fname, success, result = future.result()
                    if success:
                        results_table.add_row(fname, f"[bold green]{t('status_secured')}[/bold green]", f"[bold]{result['risk_grade']}[/bold]")
                    else:
                        results_table.add_row(fname, f"[red]{t('status_failed')}[/red]", "N/A")
                        logger.error(f"Protection Error on {fname}: {result}")
                    progress.advance(task)
    else:
        print_step(t("step_deploy_protection", count=f"[bold]{len(files_to_process)}[/bold]"))
        for fpath in files_to_process:
            filename = fpath.name
            try:
                if input_path.is_dir():
                    final_output_path = output_dir / fpath.relative_to(input_path)
                else:
                    final_output_path = output_dir / final_name
                
                final_output_path.parent.mkdir(parents=True, exist_ok=True)
                filtration_manager.reset_session()
                parser = FileProcessor.get_parser(fpath.suffix)

                with Progress(SpinnerColumn(), TextColumn(f"[cyan]{t('securing_file', name=filename)}"), BarColumn(bar_width=40, pulse_style="cyan"), TaskProgressColumn(), console=console, transient=True) as progress:
                    task_id = progress.add_task(t("sanitizing"), total=1.0)
                    parser.parse_file(fpath, final_output_path, filtration_manager, mode, progress_callback=lambda p: progress.update(task_id, completed=p))
                
                report = filtration_manager.get_session_report()
                results_table.add_row(filename, f"[bold green]{t('status_secured')}[/bold green]", f"[bold]{report['risk_grade']}[/bold]")
            except Exception as e:
                results_table.add_row(filename, f"[red]{t('status_failed')}[/red]", "N/A")
                logger.error(f"Protection Error on {filename}: {e}")

    console.print("")
    console.print(results_table)
    print_status(t("status_protection_complete", path=f"[bold cyan]{output_dir}[/bold cyan]"), "success")

@app.command(name="scan", help="Scan assets for PII without modification")
def scan_command(
    path: Path = typer.Argument(..., help="File or directory path to scan for PII"),
    recursive: bool = typer.Option(False, "--recursive", "-r", help="Scan directory recursively")
):
    """Detect PII in a file or directory"""
    if not path.exists():
        print_error(t("error_path_exists", path=str(path)))
        raise typer.Exit(code=1)

    if path.is_file():
        logger.info(f"Scanning file: {path}")
        print_step(f"Analyzing asset: [bold]{path.name}[/bold]")
        file_size = path.stat().st_size
        pii_entities = []
        filtration_manager.reset_session()
        try:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(bar_width=40, pulse_style="magenta"), TaskProgressColumn(), console=console, transient=True) as progress:
                task = progress.add_task(f"[magenta]{t('status_processing')}", total=file_size)
                with open(path, "rb") as f:
                    while True:
                        chunk = f.read(1024*1024)
                        if not chunk: break
                        try: text = chunk.decode('utf-8', errors='replace')
                        except: text = chunk.decode('latin1', errors='replace')
                        entities = filtration_manager.detect(text)
                        pii_entities.extend(entities)
                        progress.advance(task, len(chunk))
            if not pii_entities:
                print_status(t("status_no_pii"), "success")
            else:
                print_status(t("status_found_pii", count=len(pii_entities)), "warning")
                display_entities = pii_entities[:50]
                table = format_detection_table([e.model_dump() for e in display_entities])
                console.print(table)
                if len(pii_entities) > 50:
                    console.print(f"[dim]{t('status_hidden_items', count=len(pii_entities)-50)}[/dim]")
            print_status(t("status_scan_complete", name=f"[bold]{path.name}[/bold]"), "success")
        except Exception as e:
            logger.error(f"Error scanning {path}: {e}")
            print_error(t("error_scan_failed", name=path.name))
    elif path.is_dir():
        if not recursive:
            print_warning(t("warn_dir_recursive"))
            raise typer.Exit()
        files = [p for p in path.rglob("*") if p.is_file() and not p.name.startswith('.')]
        if not files:
            print_error(t("error_no_files", path=str(path)))
            raise typer.Exit()
        total_pii = 0
        print_step(t("step_deploy_batch", count=f"[bold]{len(files)}[/bold]"))
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(bar_width=40, pulse_style="cyan"), TaskProgressColumn(), console=console) as progress:
            task = progress.add_task(f"[cyan]{t('status_processing')}", total=len(files))
            for fpath in files:
                try:
                    with open(fpath, "rb") as f:
                        text = f.read().decode('utf-8', errors='replace')
                    total_pii += len(filtration_manager.detect(text))
                except: pass
                progress.advance(task)
        console.print("")
        print_status(t("status_batch_complete", pii_count=f"[bold]{total_pii}[/bold]", file_count=len(files)), "success")

@app.command(name="config", help="Manage PIIFILL configuration")
def config_command():
    """List current configurations."""
    console.print("\n[cyan]--- PIIFILL CONFIGURATION ---[/cyan]")
    console.print(f"Log Level:        [bold]{settings.log_level}[/bold]")
    console.print(f"Log File:         [bold]{settings.log_file}[/bold]")
    console.print(f"Default Mask:     [bold]{settings.default_mask_style}[/bold]")
    console.print(f"Supported Formats: [bold]{', '.join(settings.supported_extensions)}[/bold]")
    console.print("[cyan]-----------------------------[/cyan]\n")

@app.command(name="version", help="Show version information")
def version_command():
    """Show the application version."""
    console.print("[bold cyan]PIIFILL CLI Version:[/bold cyan] 0.1.2")
    console.print("[dim]Enterprise-Grade Local PII Sanitization CLI[/dim]")

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(None, "--version", "-v", callback=version_callback, is_eager=True, help="Show version info"),
    lang: str = typer.Option(settings.language, "--lang", "-L", help="Set language (en, hi, es, fr)"),
):
    """Automated Enterprise-Grade PII Sanitization Logic."""
    translator.set_language(lang)
    print_banner()
    if ctx.invoked_subcommand is None:
        console.print(f"\n[bold cyan]PIIFILL v0.1.2[/bold cyan] - {t('banner_subtitle')}")
        console.print("\n[yellow]No command specified.[/yellow] [dim]Use [bold]--help[/bold] to see all available protection commands.[/dim]")
        
        # Optionally show short help if no command
        # ctx.get_help() is also possible but might be too verbose

def entrypoint():
    app()

if __name__ == "__main__":
    app()
