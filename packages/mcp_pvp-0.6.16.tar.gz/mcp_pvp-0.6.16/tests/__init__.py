"""Tests for mcp-pvp."""
