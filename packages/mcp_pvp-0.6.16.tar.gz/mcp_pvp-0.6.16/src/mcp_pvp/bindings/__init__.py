"""HTTP binding initialization."""
