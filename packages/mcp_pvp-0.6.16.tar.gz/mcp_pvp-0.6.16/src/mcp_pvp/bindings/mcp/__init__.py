"""MCP binding initialization."""
