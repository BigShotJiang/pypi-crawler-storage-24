"""
Shared constants for the application.
"""

# pylint: disable=too-many-lines

from .i18n import _


class ServerPallette:  # pylint: disable=too-few-public-methods
    """Color for server"""

    COLOR = [
        "#33FF57",  # Green
        "#F333FF",  # Magenta
        "#3357FF",  # Blue
        "#FF8C33",  # Orange
        "#FF33A1",  # Pink
        "#F3FF33",  # Yellow
        "#33FF8C",  # Mint
        "#FF5733",  # Red-Orange
        "#33FFF3",  # Cyan
        "#A133FF",  # Purple
        "#FF3333",  # Bright Red
        "#33FFDA",  # Aqua
        "#FFB833",  # Amber
        "#8C33FF",  # Violet
        "#33A1FF",  # Sky Blue
        "#33FFB8",  # Spearmint
        "#FFD133",  # Golden Yellow
        "#33FFA5",  # Light Green
        "#C70039",  # Deep Red
        "#00B8FF",  # Electric Blue
    ]


class AppCacheTimeout:  # pylint: disable=too-few-public-methods
    """All Cache timeout value"""

    INFO_CACHE_TTL = 60
    XML_CACHE_TTL = 3600  # 1 hour
    DONT_DISPLAY_DISK_USAGE = 50


class AppInfo:  # pylint: disable=too-few-public-methods
    """Define app data"""

    name = "virtui-manager"
    namecase = "VirtUI Manager"
    version = "2.4.5"
    author = "Antoine Ginies"


class VMCardConstants:  # pylint: disable=too-few-public-methods
    """Constants for VMCard styling"""

    DEFAULT_BORDER_COLOR = "green"
    SELECTED_BORDER_COLOR = "white"
    SELECTED_BORDER_TYPE = "panel"
    DEFAULT_BORDER_TYPE = "solid"


class VmAction:  # pylint: disable=too-few-public-methods
    """Defines constants for VM action types."""

    START = "start"
    STOP = "stop"
    FORCE_OFF = "force_off"
    PAUSE = "pause"
    RESUME = "resume"
    HIBERNATE = "hibernate"
    DELETE = "delete"


class VmStatus:  # pylint: disable=too-few-public-methods
    """Defines constants for VM status filters."""

    DEFAULT = "default"
    RUNNING = "running"
    PAUSED = "paused"
    PMSUSPENDED = "pmsuspended"
    BLOCKED = "blocked"
    STOPPED = "stopped"
    SELECTED = "selected"


class ButtonLabels:  # pylint: disable=too-few-public-methods
    """Constants for button labels"""

    ADD = _("Add")
    SAVE = _("Save")
    HIBERNATE_VM = _("Hibernate VM")
    SAVE_CHANGES = _("Save Changes")
    CREATE_NETWORK = _("Create Network")
    INSTALL = _("Install")
    INFO = _("Info")
    BROWSE = _("Browse")
    START = _("Start")
    SHUTDOWN = _("Shutdown")
    FORCE_OFF = _("Force Off")
    REMOVE = _("Remove")
    PAUSE = _("Pause")
    RESUME = _("Resume")
    CONFIGURE = _("Configure")
    WEB_CONSOLE = _("Web Console")
    TEXT_CONSOLE = _("Text Console")
    CONNECT = _("Connect")
    SNAPSHOT = _("Snapshot")
    RESTORE_SNAPSHOT = _("Restore Snapshot")
    DELETE_SNAPSHOT = _("Del Snapshot")
    DELETE = _("Delete")
    EDIT = _("Edit")
    CUSTOM_URL = _("Custom URL")
    SSH_HELP = _("SSH Help")
    VIEW = _("View")
    HELP = _("Help")
    ADD_POOL = _("Add Pool")
    DELETE_POOL = _("Delete Pool")
    NEW_VOLUME = _("New Volume")
    ATTACH_VOL = _("Attach Vol")
    MOVE_VOLUME = _("Move Volume")
    DELETE_VOLUME = _("Delete Volume")
    EDIT_XML = _("Edit XML")
    EDIT_CPU_TUNE = _("Edit CPU Tune")
    EDIT_NUMA_TUNE = _("Edit NUMA Tune")
    SWITCH_TO_BIOS = _("Switch to BIOS")
    SWITCH_TO_UEFI = _("Switch to UEFI")
    SAVE_BOOT_ORDER = _("Save Boot Order")
    BOOT_UP = _("Up")
    BOOT_DOWN = _("Down")
    REMOVE_DISK = _("Remove Disk")
    DISABLE_DISK = _("Disable Disk")
    ENABLE_DISK = _("Enable Disk")
    ADD_DISK = _("Add Disk")
    ATTACH_EXISTING_DISK = _("Attach Existing Disk")
    EDIT_DISK = _("Edit Disk")
    DISK_HELP = _("Help")
    EDIT_INTERFACE = _("Edit Interface")
    ADD_INTERFACE = _("Add Interface")
    REMOVE_INTERFACE = _("Remove Interface")
    VIRTIOFS_HELP = _("Help")
    APPLY_GRAPHICS_SETTINGS = _("Apply Graphics Settings")
    APPLY_TPM_SETTINGS = _("Apply TPM Settings")
    APPLY_RNG_SETTINGS = _("Apply RNG Settings")
    ADD_PTY_CONSOLE = _("Add PTY Console")
    REMOVE_CONSOLE = _("Remove Console")
    APPLY_WATCHDOG_SETTINGS = _("Apply Watchdog Settings")
    REMOVE_WATCHDOG = _("Remove Watchdog")
    ADD_INPUT = _("Add Input")
    REMOVE_INPUT = _("Remove Input")
    ADD_USB2 = _("Add USB2")
    ADD_USB3 = _("Add USB3")
    ADD_SCSI = _("Add SCSI")
    ATTACH_ARROW = _("Attach >")
    DETACH_ARROW = _("< Detach")
    ADD_CHANNEL = _("Add Channel")
    REMOVE_CHANNEL = _("Remove Channel")
    OTHER_TABS = _("Other Tabs")
    APPLY = _("Apply")
    CLONE = _("Clone")
    MIGRATION = _("Migration")
    VIEW_XML = _("View XML")
    RENAME = _("Rename")
    SELECT_SERVER = _("[b][#FFD700]S[/][/]elect Servers")
    MANAGE_SERVERS = _("Servers [b][#FFD700]L[/][/]ist")
    SERVER_PREFERENCES = _("Server Prefs")
    FILTER_VM = _("[b][#FFD700]F[/][/]ilter VM")
    VIEW_LOG = _("Log")
    BULK_CMD = _("[b][#FFD700]B[/][/]ulk CMD")
    PATTERN_SELECT = _("[b][#FFD700]P[/][/]attern Sel")
    CONFIG = _("Config")
    PREVIOUS_PAGE = _("\\[Previous Page]")
    NEXT_PAGE = _("\\[Next Page]")
    YES = _("Yes")
    NO = _("No")
    CANCEL = _("Cancel")
    CREATE = _("Create")
    CHANGE = _("Change")
    STOP = _("Stop")
    CLOSE = _("Close")
    MOVE = _("Move")
    ATTACH = _("Attach")
    DE_ACTIVE = _("De/Active")
    AUTOSTART = _("Autostart")
    EXECUTE = _("Execute")
    DONE = _("Done")
    SEARCH_VMS = _("Search VMs")
    SELECT_MATCHING = _("Select Matching")
    REFRESH = _("Refresh")
    CLEAR_CACHES = _("Clear All Caches")
    CONFIRM = _("Confirm")
    CHECK_COMPATIBILITY = _("Check Compatibility")
    START_MIGRATION = _("Start Migration")
    CREATE_OVERLAY = _("New Overlay")
    COMMIT_DISK = _("Commit Disk")
    DISCARD_OVERLAY = _("Discard Overlay")
    SNAP_OVERLAY_HELP = _("Help")
    COMPACT_VIEW = _("Compact")
    SELECT = _("Select")
    OK = _("OK")
    LAUNCH = _("Launch")
    OPEN = _("Open")
    ACTIVATE_OR_DEACTIVATE_THE_SELECTED_NETWORK = _("Activate or Deactivate the selected netw. ..")
    ENABLE_OR_DISABLE_AUTOSTART_FOR_THE_SELECTED_NETWORK = _(
        "Enable or Disable autostart for the sele. .."
    )
    ADD_A_NEW_NETWORK = _("Add a new network.")
    EDIT_THE_SELECTED_NETWORK = _("Edit the selected network.")
    VIEW_XML_DETAILS_OF_THE_SELECTED_NETWORK = _("View XML details of the selected network. ..")
    DELETE_THE_SELECTED_NETWORK = _("Delete the selected network.")
    SHOW_NETWORK_CONFIGURATION_HELP = _("Show network configuration help.")
    ACTIVATE_OR_DEACTIVATE_THE_SELECTED_STORAGE_POOL = _(
        "Activate or Deactivate the selected stor. .."
    )
    ENABLE_OR_DISABLE_AUTOSTART_FOR_THE_SELECTED_STORAGE_POOL = _(
        "Enable or Disable autostart for the sele. .."
    )
    ADD_A_NEW_STORAGE_POOL = _("Add a new storage pool.")
    DELETE_THE_SELECTED_STORAGE_POOL = _("Delete the selected storage pool.")
    CREATE_A_NEW_VOLUME_IN_THE_SELECTED_POOL = _("Create a new volume in the selected pool. ..")
    ATTACH_AN_EXISTING_DISK_FILE_AS_A_VOLUME = _("Attach an existing disk file as a volume. ..")
    MOVE_THE_SELECTED_VOLUME_TO_ANOTHER_POOL = _("Move the selected volume to another pool. ..")
    DELETE_THE_SELECTED_VOLUME = _("Delete the selected volume.")
    VIEW_XML_DETAILS_OF_THE_SELECTED_POOL_OR_VOLUME = _(
        "View XML details of the selected pool or. .."
    )
    EDIT_XML_OF_THE_SELECTED_POOL = _("Edit XML of the selected pool.")


class BindingDescriptions:  # pylint: disable=too-few-public-methods
    """Descriptions for app bindings"""

    LOG = _("Log")
    FILTER = _("Filter")
    COMPACT_VIEW = _("CompactView")
    SERVER_PREFS = _("ServerPrefs")
    CONFIG = _("Config")
    BULK_CMD = _("BulkCMD")
    SELECT_SERVERS = _("SelServers")
    MANAGE_SERVERS = _("ServList")
    PATTERN_SELECT = _("PatternSel")
    SELECT_ALL = _("Sel/Des All")
    UNSELECT_ALL = _("Unselect All")
    PREVIOUS_PAGE = _("Previous Page")
    NEXT_PAGE = _("Next Page")
    RUNNING_VMS = _("Running VMs")
    ALL_VMS = _("All VMs")
    VIRSH_SHELL = _("Virsh")
    HOST_CAPABILITIES = _("Host Caps")
    INSTALL_VM = _("InstallVM")
    TOGGLE_STATS = _("Log Stats")
    CACHE_STATS = _("Show cache Stats")
    QUIT = _("Quit")
    HOST_DASHBOARD = _("Host Dashboard")
    TEMPLATES = _("Templates")


class TabTitles:  # pylint: disable=too-few-public-methods
    """Constants for tab titles"""

    MANAGE = _("Manage")
    OTHER = _("Other")
    STATE_MANAGEMENT = _("State Management")
    SNAP_OVER_UPDATE = _("Updating Data...")
    ACTIVE_ALLOCATION = _("Active Allocation")
    TOTAL_ALLOCATION = _("Total Allocation")
    TOTAL_TAB = _("{info}\nTotal: {snapshot_count}:")


class StatusText:  # pylint: disable=too-few-public-methods
    """Constants for status text"""

    STOPPED = _("Stopped")
    RUNNING = _("Running")
    PAUSED = _("Paused")
    PMSUSPENDED = _("Guest Suspended")
    BLOCKED = _("Blocked")
    LOADING = _("Loading")
    UNKNOWN = _("Unknown")


class StaticText:  # pylint: disable=too-few-public-methods
    """Constants for static text in modals"""

    CACHE_PERFORMANCE_STATISTICS = _("Cache Performance Statistics")
    EDITING_CONFIG_PATH = _("(Editing: {get_user_config_path})")
    CUSTOM_MIGRATION_PLAN = _("[bold]Custom Migration Plan[/bold]")
    DISK_VOLUME_NAME = _("Disk: [b]{volume_name}[/b]")
    SOURCE_POOL = _("  Source Pool: {source_pool}")
    NO_DESTINATION_POOLS = _("  No destination pools available.")
    DISK_PATH = _("Disk: [b]{disk_path}[/b]")
    ACTION_MESSAGE = _("  Action: {message}")
    FROM_POOL = _("From Pool: {source_pool_name}")
    SELECT_DESTINATION_SERVER = _("Select destination server:")
    MIGRATION_OPTIONS = _("Migration Options:")
    COMPATIBILITY_CHECK_RESULTS = _("Compatibility Check Results / Migration Log:")
    VMS_READY_FOR_MIGRATION = _("[b]VMs [green]Ready[/] for Migration[/b]")
    VMS_NOT_READY_FOR_MIGRATION = _("[b]VMs [red]Not[/] Ready for Migration[/b]")
    DELETE_ASSOCIATED_STORAGE = _("Delete associated storage")
    CREATE_NEW_DISK_IMAGE = _("Create new disk image")
    CD_ROM = _("CD-ROM")
    COPY_STORAGE_ALL = _("Copy storage all")
    UNSAFE_MIGRATION = _("Unsafe migration")
    PERSISTENT_MIGRATION = _("Persistent migration")
    COMPRESS_DATA = _("Compress data")
    TUNNELLED_MIGRATION = _("Tunnelled migration")
    CUSTOM_MIGRATION = _("Custom migration")
    ENABLE_REMOTE_WEBCONSOLE = _("Enable remote web console")
    ENABLE_DHCPV4 = _("Enable DHCPv4")
    VALIDATE_CHECKSUM = _("Validate Checksum")
    CONFIGURE_BEFORE_INSTALL = _("Configure before install")
    INSTALL_VM = _("Install VM on {uri}")
    VM_NAME = _("Virtual Machine Name")
    DISTRIBUTION = _("Distribution")
    CACHED_ISOS = _("Cached ISOs")
    GENERIC_CUSTOM_ISO = _("Generic / Custom ISO")
    FROM_STORAGE_POOL = _("From Storage Pool")
    ISO_IMAGE_REPO = _("ISO Image (Repo):")
    ISOS_DOWNLOAD_PATH = _("ISOs will be downloaded to: {iso_path}")
    CUSTOM_ISO_LOCAL_PATH = _("Custom ISO (Local Path or HTTP URL):")
    SELECT_STORAGE_POOL = _("Select Storage Pool:")
    SELECT_ISO_VOLUME = _("Select ISO Volume:")
    STORAGE_POOL = _("Storage Pool:")
    EXPERT_MODE = _("Expert Mode")
    SELECT_ISO_PROMPT = _("Select ISO...")
    SHA256_CHECKSUM_OPTIONAL_PLACEHOLDER = _("SHA256 Checksum (Optional)")
    SELECT_POOL_PROMPT = _("Select Pool...")
    SELECT_ISO_VOLUME_PROMPT = _("Select ISO Volume...")
    FETCHING_ISO_VOLUMES_FROM_TEMPLATE = _("Fetching ISO volumes from {pool_name}...")
    ERROR_FETCHING_VOLUMES = _("Error fetching volumes")
    FETCHING_ISO_LIST = _("Fetching ISO list...")
    ERROR_FETCHING_ISOS = _("Error fetching ISOs")
    VALIDATING_CHECKSUM = _("Validating Checksum...")
    CHECKSUM_VALIDATED = _("Checksum Validated")
    DOWNLOADING_ISO = _("Downloading ISO...")
    DOWNLOADING_ISO_PROGRESS = _("Downloading: {progress}% ({speed}/s)")
    UPLOADING_ISO = _("Uploading ISO...")
    UPLOADING_PROGRESS_TEMPLATE = _("Uploading: {progress}%")
    MEMORY_GB_LABEL = _(" Memory (GB)")
    DISK_SIZE_GB_LABEL = _(" Disk Size(GB)")
    DISK_FORMAT_LABEL = _(" Disk Format")
    GRAPHICS_LABEL = _(" Graphics")
    FIRMWARE_LABEL = _(" Firmware")
    DELETE_STORAGE_VOLUMES = _("Delete storage volumes and NVRAM")
    QUIESCE_GUEST = _("Quiesce guest (requires agent)")
    SELECT_INTERFACE_AND_NETWORK = _("Select interface and new network")
    ENTER_BASE_NAME = _("Enter base name for new VM(s)")
    SUFFIX_FOR_CLONE_NAMES = _("Suffix for clone names (e.g., _C)")
    NUMBER_OF_CLONES_TO_CREATE = _("Number of clones to create")
    DO_NOT_CLONE_STORAGE = _("Do Not Clone storage")
    CURRENT_NAME = _("Current name: {current_name}")
    ENTER_NEW_VM_NAME = _("Enter new VM name")
    CURRENT_TIME = _("Current time: {now}")
    ENTER_SNAPSHOT_NAME = _("Enter snapshot name")
    DESCRIPTION_OPTIONAL = _("Description (optional)")
    WEB_CONSOLE_CONFIGURATION = _("Web Console Configuration")
    REMOTE = _("Remote")
    ENTER_QEMU_CONNECTION_URI = _("Enter QEMU Connection URI:")
    ADD_NEW_SERVER = _("Add New Server")
    AUTOCONNECT_AT_STARTUP = _("Autoconnect at startup")
    EDIT_SERVER = _("Edit Server")
    SERVER_LIST_MANAGEMENT = _("Server List Management")
    SELECT_SERVERS_TO_DISPLAY = _("Select Servers to Display")
    ENTER_NEW_VCPU_COUNT = _("Enter new VCPU count")
    ENTER_NEW_MEMORY_SIZE = _("Enter new memory size (MB)")
    SELECT_MACHINE_TYPE = _("Select Machine Type")
    CPU_PINNING_FORMAT = _("Format: 0:0-3; 1:4-7")
    NUMA_MEMORY_MODE = _("NUMA Memory Mode")
    NODESET = _("Nodeset")
    ENTER_CPU_PINNING = _("Enter CPU Pinning (max vcpu: {max_vcpus})")
    SELECT_VMS_BY_PATTERN = _("Select VMs by Pattern (ctrl+u to unselect All VMS)")
    REGEX = _("Regex")
    MATCHING_VMS = _("Matching VMs:")
    FILTER_BY_NAME = _("Filter by Name")
    ALL = _("All")
    RUNNING = _("Running")
    PAUSED = _("Paused")
    PMSUSPENDED = _("Guest Suspended")
    BLOCKED = _("Blocked")
    STOPPED = _("Stopped")
    CREATE_NEW_VM = _("Create New VM")
    START_VMS = _("Start VMs")
    STOP_VMS_GRACEFUL = _("Stop VMs (Graceful Shutdown)")
    FORCE_OFF_VMS = _("Force Off VMs")
    PAUSE_VMS = _("Pause VMs")
    HIBERNATE_VMS = _("Hibernate VMs")
    DELETE_VMS = _("Delete VMs")
    EDIT_CONFIGURATION = _("Edit Configuration")
    MIGRATE_VMS = _("Migrate VMs")
    HYPERVISOR_DEFAULT = _("Hypervisor default")
    LOCALHOST_ONLY = _("Localhost only")
    ALL_INTERFACES = _("All interfaces")
    NAT_NETWORK = _("NAT Network")
    ROUTED_NETWORK = _("Routed Network")
    IPV4_NETWORK_EXAMPLE = _("e.g., 192.168.1.0/24")
    DHCP_START_EXAMPLE = _("e.g., 192.168.1.10")
    DHCP_END_EXAMPLE = _("e.g., 192.168.1.200")
    SELECT_NETWORK_AND_MODEL = _("Select Network and Model")
    USE_CUSTOM_DNS_DOMAIN = _("Use Custom DNS Domain")
    USE_NETWORK_NAME_FOR_DNS = _("Use Network Name for DNS")
    CUSTOM_DNS_DOMAIN = _("Custom DNS Domain")
    NETWORK_DETAILS = _("Network Details")
    UNDEFINE_SOURCE_VM = _("Undefine source VM")
    EDIT_DISK_TITLE = _("Edit Disk: {path}")
    MOVE_VOLUME_TITLE = _("Move Volume: {volume_name}")
    MIGRATE_VMS_TITLE = _("[{migration_type}] Migrate VMs: [b]{vm_names}[/b]")
    EMPTY_LABEL = ""
    SERVER_PREFERENCES = _("Server Preferences")
    SELECT_DISK_TO_REMOVE = _("Select Disk to Remove")
    ADD_NEW_DISK = _("Add New Disk")
    ADD_NEW_STORAGE_POOL = _("Add New Storage Pool")
    TARGET_PATH_VOLUMES = _("Target Path (for volumes)")
    TARGET_PATH_HOST = _("Target Path (on this host)")
    SOURCE_HOSTNAME = _("Source Hostname")
    SOURCE_PATH_REMOTE = _("Source Path (on remote host)")
    CREATE_NEW_STORAGE_VOLUME = _("Create New Storage Volume")
    DEVICE_TYPE = _("Device Type:")
    BUS_TYPE = _("Bus Type:")
    CACHE_MODE = _("Cache Mode:")
    DISCARD_MODE = _("Discard Mode:")
    VM_MUST_BE_STOPPED_EDIT_DISK = _("VM must be stopped to edit disk settings.")
    DESTINATION_POOL = _("Destination Pool:")
    NEW_VOLUME_NAME = _("New Volume Name:")
    ATTACH_EXISTING_DISK_AS_VOLUME = _("Attach Existing Disk as Volume")
    BOOT_ORDER = _("Boot Order")
    AVAILABLE_DEVICES = _("Available Devices")
    TYPE_LABEL = _("Type:")
    LISTEN_TYPE = _("Listen Type:")
    ADDRESS_LABEL = _("Address:")
    TPM_MODEL = _("TPM Model:")
    TPM_TYPE = _("TPM Type:")
    DEVICE_PATH_PASSTHROUGH = _("Device Path (for passthrough):")
    BACKEND_TYPE_PASSTHROUGH = _("Backend Type (for passthrough):")
    BACKEND_PATH_PASSTHROUGH = _("Backend Path (for passthrough):")
    HOST_DEVICE = _("Host device")
    WATCHDOG_MODEL = _("Watchdog Model:")
    ACTION_LABEL = _("Action:")
    AVAILABLE_HOST_USB = _("Available Host USB Devices")
    ATTACHED_TO_VM = _("Attached to VM")
    AVAILABLE_HOST_PCI = _("Available Host PCI Devices")
    VIRSH_SHELL_TITLE = _("Virsh Interactive Shell (esc to quit)")
    VIRSH_SHELL_NOTE = _(
        "Note: This shell starts a new `virsh` process, which may require re-authentication "
        "for remote connections. Using SSH keys is recommended."
    )
    INPUT_DEVICE = _("Input Device")
    ADD_CHANNEL_DEVICE = _("Add Channel Device")
    STANDARD_TARGET_NAMES = _("Standard Target Names:")
    TARGET_NAME = _("Target Name:")
    SELECTED_VMS_BULK = _("Selected VMs for Bulk Action")
    CHOOSE_ACTION = _("Choose Action:")
    PERFORMANCE = _("Performance")
    STATS_INTERVAL = _("Stats Interval (seconds)")
    LOG_FILE_PATH = _("Log File Path:")
    LOGGING_LEVEL = _("Logging Level:")
    REMOTE_VIEWER = _("Remote Viewer")
    NO_REMOTE_VIEWERS_FOUND = _("No remote viewers found (virt-viewer or virtui-remote-viewer)")
    WEBSOCKIFY_PATH = _("Websockify Path:")
    NOVNC_PATH = _("noVNC Path:")
    WEBSOCKIFY_PORT_RANGE = _("Websockify Port Range:")
    VNC_QUALITY = _("VNC Quality (0-9):")
    VNC_COMPRESSION = _("VNC Compression (0-9):")
    HOST_CAPABILITIES = _("Host Capabilities")
    CAPABILITIES_TREE_LABEL = _("Capabilities")
    SELECT_A_DIRECTORY = _("Select a Directory")
    SELECT_A_FILE = _("Select a File")
    EXPORT_READONLY_MOUNT = _("Export filesystem as readonly mount")
    WEBCONSOLE_LOCAL_RUN = _("Web console will run locally.")
    ENABLE_BOOT_MENU = _("Enable boot menu")
    WEB_CONSOLE_NOVNC = _("Web Console (novnc)")
    HOST_RESOURCE_DASHBOARD = _("Host Resource Dashboard")
    HOST_DETAILS = _("Host Details")
    VM_ALLOCATION = _("VM Allocation")
    MEMORY_USAGE = _("Memory Usage")
    ALLOCATED_VCPUS = _("Allocated VCPUs")
    ALLOCATED_MEMORY = _("Allocated Memory")
    MODEL = _("Model:")
    TOPOLOGY = _("Topology:")
    WAITING_TO_START_COLLECTION = _("Waiting to start collection...")
    COLLECTING_VM_INFO = _("Collecting VM info: {current}/{total}")
    ADD_VIRTIOFS_MOUNT = _("Add VirtIO-FS Mount")
    EDIT_VIRTIOFS_MOUNT = _("Edit VirtIO-FS")
    LATEST_SNAPSHOT = _("Latest Snapshot:")
    NO_SNAPSHOTS_CREATED = _("No Snapshots created")
    SELECT_OVERLAY_DISCARD = _("Select overlay disk to discard:")
    NO_OTHER_ACTIVE_POOLS = _("No other active pools")
    VIRTIOFS_SOURCE_PLACEHOLDER = _("Source Path (e.g., /mnt/share)")
    VIRTIOFS_TARGET_PLACEHOLDER = _("Target Path (e.g., /share)")
    CONFIGURATION_TITLE = _("{namecase} Configuration")
    STATS_INTERVAL_TOOLTIP = _(
        "Interval for updating VM Status, Statistics (CPU, Memory, I/O) in seconds."
    )
    LOG_FILE_PATH_TOOLTIP = _("Full path to the application log file")
    LOG_LEVEL_PROMPT = _("Select a logging level")
    REMOTE_VIEWER_SELECT_LABEL = _("Select Default Remote Viewer (Auto-detect: {viewer}):")
    REMOTE_VIEWER_PROMPT = _("Select a viewer")
    REMOTE_WEBCONSOLE_TOOLTIP = _(
        "Enable secure SSH and noVNC remote viewing for headless server environments"
    )
    WEBSOCKIFY_PATH_TOOLTIP = _("Path to the websockify binary")
    NOVNC_PATH_TOOLTIP = _("Path to noVNC files")
    WC_PORT_START_TOOLTIP = _("Start port for websockify")
    WC_PORT_END_TOOLTIP = _("End port for websockify")
    VNC_QUALITY_TOOLTIP = _("VNC quality setting (0-9)")
    VNC_COMPRESSION_TOOLTIP = _("VNC compression level (0-9)")
    CONNECTION_URI_PLACEHOLDER = _("qemu+ssh://user@host/system or qemu:///system")
    SERVER_NAME_PLACEHOLDER = _("Server Name")
    SERVER_URI_PLACEHOLDER = _("qemu+ssh://user@host/system")
    SERVER_NAME_COLUMN = _("Name")
    SERVER_URI_COLUMN = _("URI")
    SERVER_AUTOCONNECT_COLUMN = _("Autoconnect")
    INPUT_TYPE_PROMPT = _("Input Type")
    INPUT_BUS_PROMPT = _("Bus")
    CHANNEL_TYPE_PROMPT = _("Channel Type")
    TARGET_PRESET_PROMPT = _("Select a standard target or type below")
    TARGET_NAME_PLACEHOLDER = _("Target Name (e.g. org.qemu.guest_agent.0)")
    DISK_PATH_PLACEHOLDER = _("Path to existing disk image or ISO")
    STORAGE_POOL_PROMPT = _("Select Storage Pool")
    VOLUME_NAME_PLACEHOLDER = _("Volume Name (e.g., new-disk.qcow2)")
    DISK_SIZE_PLACEHOLDER = _("Size in GB (e.g., 10)")
    POOL_NAME_PLACEHOLDER = _("Pool Name (e.g., my_pool)")
    POOL_TYPE_DIR_LABEL = _("dir: Filesystem Directory")
    POOL_TYPE_NETFS_LABEL = _("netfs: Network Exported Directory")
    POOL_TYPE_PROMPT = _("Pool Type")
    DIR_TARGET_PATH_PLACEHOLDER = _("/var/lib/libvirt/images/>")
    EXISTING_VOLUME_NAME_PLACEHOLDER = _("Volume Name (e.g., existing_disk.qcow2)")
    DISK_IMAGE_PATH_PLACEHOLDER = _("Path to disk image")
    SELECT_A_SERVER = _("Select a server")
    SELECT_SERVER_PROMPT = _("Select server...")
    SELECT_NETWORK_PROMPT = _("Select a network")
    NO_NETWORKS_AVAILABLE_PROMPT = _("No networks available")
    MAC_ADDRESS_PLACEHOLDER = _("MAC Address (e.g., 52:54:00:xx:xx:xx)")
    EDIT_NETWORK_TITLE = _("Edit Network")
    CREATE_NEW_NETWORK_TITLE = _("Create New Network")
    NETWORK_NAME_PLACEHOLDER = _("Network Name (e.g., nat_net)")
    LOADING_LABEL = _("Loading...")
    SELECT_FORWARD_INTERFACE_PROMPT = _("Select Forward Interface")
    NO_INTERFACES_FOUND_LABEL = _("No interfaces found")
    VCPU_COUNT_EXAMPLE = _("e.g., 2")
    MEMORY_SIZE_EXAMPLE = _("e.g., 2048")
    CPU_PINNING_EXAMPLE = _("e.g., 0:0-1; 1:2-3")
    ACTIONS = _("Actions")
    NODESET_EXAMPLE = _("e.g., 0-1")
    CPU_TUNE_HELP_TITLE = _("CPU Tuning Help")
    CPU_TUNE_HELP_TEXT = _(
        """
# CPU Tune Help

## CPU Pinning (vcpupin)
Specify which physical CPUs (host CPUs) each virtual CPU (guest CPU) can run on.

## Format
`vcpu:cpuset; vcpu:cpuset; ...`

* **vcpu**: The ID of the virtual CPU.
* **cpuset**: A list or range of physical CPU IDs.

## Examples
* `0:0`: Pin vCPU 0 to physical CPU 0.
* `0:0-3`: Pin vCPU 0 to physical CPUs 0, 1, 2, and 3.
* `0:0,2`: Pin vCPU 0 to physical CPUs 0 and 2.
* `0:0-1; 1:2-3`: Pin vCPU 0 to physical CPUs 0-1, and vCPU 1 to physical CPUs 2-3.
"""
    )
    NUMA_TUNE_HELP_TITLE = _("NUMA Tuning Help")
    NUMA_TUNE_HELP_TEXT = _(
        """
# NUMA Tune Help

## Memory Modes
* **strict**: Memory allocation fails if it cannot be satisfied on the specified nodeset.
* **preferred**: Allocation is preferred on the specified nodeset but can fall back to others.
* **interleave**: Memory is allocated round-robin across the specified nodeset.

## Nodeset
Specify the NUMA nodes to use.
* Example: `0` (Node 0 only)
* Example: `0-1` (Nodes 0 and 1)
* Example: `0,2-3` (Node 0 and nodes 2 through 3)
"""
    )
    REFRESHING_HOST_STATS = _("Refreshing host stats")
    SELECT_SERVER_FOR_PREFS = _("Select a server for Preferences")
    SELECT_SERVER_FOR_VIRSH = _("Select a server for Virsh Shell")
    SELECT_SERVER_FOR_DASHBOARD = _("Select a server for Dashboard")
    VIEW_DASHBOARD = _("View Dashboard")
    SELECT_SERVER_FOR_CAPS = _("Select a server for Capabilities")
    SELECT_SERVER_FOR_INSTALL = _("Select a server for VM Installation")
    INSTALL_HERE = _("Install Here")
    SHUTTING_DOWN = _("Shutting down...")
    APP_DESCRIPTION = _("A Textual application to manage VMs.")
    CLI_HELP = _("Run in command-line interpreter mode.")
    ENABLE_3D_ACCELERATION = _("3D Acceleration")
    AUTO_PORT = _("Auto Port")
    PORT_PLACEHOLDER = _("Port (e.g., 5900)")
    ENABLE_PASSWORD = _("Enable Password")
    PASSWORD_PLACEHOLDER = _("Password")
    BACKEND_TYPE_PLACEHOLDER = _("emulator or passthrough")
    SELECT_VM = _("Select VM")

    PAUSE_THE_GUEST_FILESYSTEM_TO_ENSURE_A_CONSISTENT_BACKUP = _(
        "Pause the guest filesystem to ensure a c. .."
    )
    LEGACY_BOOT_TOOLTIP = _("Enable legacy boot mode.")
    SHOW_VM_CONFIG_BEFORE_STARTING_TOOLTIP = _(
        "Open the VM configuration dialog before starting the VM."
    )
    COPY_ALL_DISK_FILES_TOOLTIP = _("Copy all disk files to the destination server.")
    PERFORM_UNSAFE_MIGRATION_TOOLTIP = _(
        "Perform migration even if it might be unsafe (e.g., no shared storage)."
    )
    KEEP_VM_PERSISTENT_ON_DESTINATION_TOOLTIP = _(
        "Ensure the VM remains persistent on the destination server after migration."
    )
    COMPRESS_DATA_DURING_MIGRATION_TOOLTIP = _("Compress migration data to save bandwidth.")
    TUNNEL_MIGRATION_DATA_TOOLTIP = _("Tunnel migration data through the libvirt connection.")
    USE_CUSTOM_MIGRATION_WORKFLOW_TOOLTIP = _("Use a custom workflow for migration.")

    # Expert Mode and Automated Installation Tooltips
    AUTOMATION_TEMPLATE_TOOLTIP = _(
        "Choose a pre-configured installation template. Templates define software packages, users, and system settings."
    )

    # Automated Installation UI Labels
    AUTOMATED_INSTALLATION_TITLE = _("Automated Installation")
    INSTALLATION_TEMPLATE_LABEL = _("Installation Template")
    MANAGE_TEMPLATES_TITLE = _("Manage Templates")
    MANAGE_TEMPLATES_BUTTON = _("Manage Templates")
    TEMPLATE_LIST_HEADER = _("Available Templates")
    TEMPLATE_NAME_COLUMN = _("Name")
    TEMPLATE_TYPE_COLUMN = _("Type")
    TEMPLATE_DESCRIPTION_COLUMN = _("Description")
    NO_TEMPLATES_AVAILABLE = _("No templates available")
    SELECT_TEMPLATE_TO_EDIT = _("Please select a template to edit")
    SELECT_TEMPLATE_TO_VIEW = _("Please select a template to view")
    SELECT_TEMPLATE_TO_DELETE = _("Please select a template to delete")
    SELECT_TEMPLATE_TO_EXPORT = _("Please select a template to export")
    CANNOT_DELETE_BUILTIN_TEMPLATE = _("Built-in templates cannot be deleted")
    TEMPLATE_DELETED_SUCCESSFULLY = _("Template '{template_name}' deleted successfully")
    TEMPLATE_EXPORTED_TO = _("Template exported to {path}")
    TEMPLATE_IMPORTED_SUCCESSFULLY = _("Template '{template_name}' imported successfully")
    CONFIGURE_AUTOMATION_PREFILL = _("Auto-fill")
    CONFIGURE_AUTOMATION_AND_SCC_TITLE = _("Configure Automated Installation & SCC")
    CONFIGURE_AUTOMATION_AND_SCC_SUBTITLE = _(
        "Set default values for automation fields and SUSE Customer Center registration"
    )
    ROOT_PASSWORD_LABEL = _("Root Password")
    ROOT_PASSWORD_PLACEHOLDER = _("Default root password")
    USERNAME_LABEL = _("Username:")
    USERNAME_PLACEHOLDER = _("Default username")
    USER_PASSWORD_LABEL = _("User Password")
    USER_PASSWORD_PLACEHOLDER = _("Default user password")
    KEYBOARD_LAYOUT_LABEL = _("Keyboard Layout")
    LANGUAGE_LABEL = _("Language")
    SUSE_SCC_CONFIGURATION_HEADER = _("SUSE Customer Center (SCC) Configuration")
    SUSE_SCC_CONFIGURATION_SUBTITLE = _("Optional: Configure SCC registration for SUSE products")
    SCC_EMAIL_LABEL = _("SCC Email")
    SCC_REG_CODE_LABEL = _("SCC Registration Code")
    SCC_WE_REG_CODE_LABEL = _("SCC Workstation Extension Registration Code")
    SCC_HPC_REG_CODE_LABEL = _("SCC HPC Registration Code")
    SCC_HA_REG_CODE_LABEL = _("SCC HA Registration Code")
    SCC_LTSS_REG_CODE_LABEL = _("SCC LTSS Registration Code")
    SCC_LPATCHING_REG_CODE_LABEL = _("SCC Live Patching Registration Code")
    SCC_REG_CODE_PLACEHOLDER = _("Registration code from SUSE Customer Center")
    SCC_PRODUCT_ARCH_LABEL = _("SCC Product Architecture")
    # Shared language/locale constants to avoid duplication

    # Keyboard layout constants
    KEYBOARD_US_ENGLISH = _("US English")
    KEYBOARD_FRENCH = _("French")
    KEYBOARD_GERMAN = _("German")
    KEYBOARD_SPANISH = _("Spanish")
    KEYBOARD_ITALIAN = _("Italian")
    KEYBOARD_UK_ENGLISH = _("UK English")

    # Language constants
    LANGUAGE_VALUE_ENGLISH_US = _("English (US)")
    LANGUAGE_VALUE_FRENCH = _("Français")
    LANGUAGE_VALUE_GERMAN = _("Deutsch")
    LANGUAGE_VALUE_SPANISH = _("Español")
    LANGUAGE_VALUE_ITALIAN = _("Italiano")
    LANGUAGE_VALUE_ENGLISH_UK = _("English (UK)")
    TEMPLATE_NAME_TITLE = _("Template Name")
    TEMPLATE_NAME_LABEL = _("Template Name")
    TEMPLATE_NAME_PLACEHOLDER = _("Enter template name")
    TEMPLATE_OS_LABEL = _("Operating System")
    TEMPLATE_DESCRIPTION_LABEL = _("Description (optional)")
    TEMPLATE_DESCRIPTION_PLACEHOLDER = _("Enter template description")
    IMPORT_BUTTON = _("Import")
    TEMPLATE_NAME_REQUIRED = _("Template name is required")
    ROOT_PASSWORD_LABEL = _("Root Password")
    ROOT_PASSWORD_PLACEHOLDER = _("root password")
    USERNAME_LABEL = _("Username")
    USERNAME_PLACEHOLDER = _("username")
    USER_PASSWORD_LABEL = _("User Password")
    USER_PASSWORD_PLACEHOLDER = _("user password")
    HOSTNAME_LABEL = _("Hostname")
    HOSTNAME_PLACEHOLDER = _("hostname")
    LANGUAGE_LABEL = _("Language")
    LANGUAGE_TOOLTIP = _("System language for the installation")
    KEYBOARD_LABEL = _("Keyboard Layout")
    KEYBOARD_TOOLTIP = _("Keyboard layout for the system")
    USE_VIRT_INSTALL_TOOLTIP = _(
        "Use virt-install command-line tool. Uncheck to use XML-based creation."
    )
    SERIAL_CONSOLE_TOOLTIP = _("Adds console=tty0 console=ttyS0,115200 to kernel args")
    CPUS_LABEL = _("CPUs")
    NONE_OPTION = _("None")
    USE_VIRT_INSTALL_LABEL = _("Use virt-install")
    REDIRECT_CONSOLE_SERIAL_LABEL = _("Redirect console to serial (ttyS0)")
    # VM Provisioner Progress Messages
    PROVISIONING_CHECKING_ENVIRONMENT = _("Checking Environment")
    PROVISIONING_USING_EXISTING_ISO_VOLUME = _("Using existing ISO volume: {path}")
    PROVISIONING_USING_LOCAL_ISO_IMAGE = _("Using local ISO image")
    PROVISIONING_DOWNLOADING_ISO_SPEED = _("Downloading ISO: {percent}% ({speed}/s)")
    PROVISIONING_ISO_FOUND_IN_CACHE = _("ISO found in cache, skipping download")
    PROVISIONING_SETTING_UP_UEFI_FIRMWARE = _("Setting up UEFI Firmware")
    PROVISIONING_CREATING_STORAGE = _("Creating Storage")
    PROVISIONING_GENERATING_AUTOMATION_CONFIG = _("Generating automation configuration")
    PROVISIONING_DEFINING_VM = _("Defining VM")
    PROVISIONING_COMPLETE_CONFIG_MODE = _("Provisioning Complete (Configuration Mode)")
    PROVISIONING_CONFIGURING_VM_VIRT_INSTALL = _("Configuring VM (virt-install)")
    PROVISIONING_WAITING_FOR_VM = _("Waiting for VM")
    PROVISIONING_CONFIGURING_VM_XML = _("Configuring VM (XML)")
    PROVISIONING_STARTING_VM = _("Starting VM")
    PROVISIONING_COMPLETE = _("Provisioning Complete")

    # VM Type constants
    VM_TYPE_SECURE = _("Secure VM")
    VM_TYPE_COMPUTATION = _("Computation")
    VM_TYPE_DESKTOP = _("Desktop (Linux)")
    VM_TYPE_WDESKTOP = _("Windows")
    VM_TYPE_WLDESKTOP = _("Windows Legacy")
    VM_TYPE_SERVER = _("Server")

    # vmcard_dialog.py strings
    DELETE_VM_CONFIRMATION_TEMPLATE = _("Are you sure you want to delete VM '{vm_name}'?")
    CLONE_SUFFIX_PLACEHOLDER = _("e.g., -clone")
    SNAPSHOT_DESCRIPTION_PLACEHOLDER = _("snapshot description")
    WEB_CONSOLE_RUNNING_MESSAGE = _("**Web Console** is running at:")
    WESOCKIFY_SINGLE_CONNECTION_MESSAGE = _(
        "Wesockify will handle a **single WebSocket** connection and exit. "
        "So it will be possible to **connect only ONE** time. If you disconnect "
        "you need to restart a new Web Console."
    )
    RUN_WEB_CONSOLE_REMOTE_MESSAGE = _(
        "Run Web console on remote server. This will use a **LOT** of network bandwidth. "
        "It is recommended to **reduce quality** and enable **max compression**."
    )
    RUN_WEB_CONSOLE_LOCAL_MESSAGE = _("Run Web console on local machine")
    VNC_QUALITY_LABEL = _("VNC Quality (0=low, 9=high)")
    VNC_COMPRESSION_LABEL = _("VNC Compression (0=none, 9=max)")

    # base_modals.py strings
    NAME_CANNOT_BE_EMPTY = _("Name cannot be empty.")
    NAME_MUST_BE_ALPHANUMERIC = _(
        "Name must be alphanumeric and can contain underscores, but not hyphens."
    )

    # migration_modals.py strings
    SHARED_STORAGE_POOLS_HEADER = _("\n[bold]-- Shared Storage Pools --[/]")
    NO_SHARED_STORAGE_INFO = _("INFO: No common shared storage pools found between hosts.")
    SHARED_POOL_INFO_TEMPLATE = _("INFO: Shared pool '[bold]{name}[/]' (Type: {pool_type})")
    POOL_TARGET_INFO = _("  - Target: {target}")
    POOL_STATUS_INFO = _("  - Status: Source: {source_status}, Destination: {dest_status}")
    POOL_WARNING_TEMPLATE = _("  - [on yellow bold][black]WARNING[/][/]: [yellow]{warning}[/]")
    CHECKING_VM_HEADER_TEMPLATE = _("\n[on blue][bold]--- CHECKING {vm_name} ---[/][/]")
    SERVER_COMPATIBILITY_HEADER = _("[bold]-- Server Compatibility --[/]")
    SERVER_ERROR_TEMPLATE = _("[on red bold]ERROR[/]: [red]{message}[/]")
    SERVER_WARNING_TEMPLATE = _("[on yellow bold][black]WARNING[/][/]: [yellow]{message}[/]")
    SERVER_INFO_TEMPLATE = _("[bold]INFO[/]: [green]{message}[/]")
    VM_COMPATIBILITY_HEADER = _("[bold]-- VM Compatibility --[/]")
    VM_ERROR_TEMPLATE = _("[on red bold]ERROR[/]: [red]{message}[/]")
    VM_WARNING_TEMPLATE = _("[on yellow bold][black]WARNING[/][/]: [yellow]{message}[/]")
    VM_INFO_TEMPLATE = _("[bold]INFO[/]: [green]{message}[/]")
    # Virsh modals messages
    CLOSE_SHELL_BINDING = _("Close Shell")
    VIRSH_COMMAND_PLACEHOLDER = _("Enter virsh command...")
    STARTING_VIRSH_SHELL = _("Starting virsh shell...")
    CONNECTED_TO_URI = _("Connected to: {uri}\n")
    VIRSH_NOT_FOUND_ERROR = _(
        "Error: 'virsh' command not found. Please ensure libvirt-client is installed."
    )
    ERROR_STARTING_VIRSH = _("Error starting virsh: {error}")
    ERROR_READING_FROM_VIRSH = _("Error reading from virsh: {error}")
    ERROR_SENDING_COMMAND = _("Error sending command: {error}")
    VIRSH_PROCESS_NOT_RUNNING = _("Virsh process not running.")
    VIRSH_SHELL_TERMINATED = _("Virsh shell terminated.\n")

    COMPATIBILITY_CHECK_FAILED_TEMPLATE = _("\n[red]✗ Compatibility checks failed for {vm_name}[/]")
    COMPATIBILITY_CHECK_PASSED_TEMPLATE = _(
        "\\n[green]✓ Compatibility checks passed for {vm_name}[/] "
        "(with warnings if any shown above)."
    )
    FATAL_ERROR_CHECKING_TEMPLATE = _(
        "\\n[on red bold]FATAL ERROR[/]: An unexpected error occurred while checking "
        "{vm_name}: {error}"
    )
    MIGRATING_VM_HEADER_TEMPLATE = _("\n[bold]--- Migrating {vm_name} ---[/]")
    CUSTOM_MIGRATION_CONFIRMED = _("[bold]User confirmed custom migration. Executing...[/bold]")
    CUSTOM_MIGRATION_CANCELLED = _("[yellow]Custom migration cancelled by user.[/yellow]")
    CUSTOM_MIGRATION_FAILED_TEMPLATE = _(
        "[red]ERROR: Custom migration failed for {vm_name}: {error}[/red]"
    )
    LIVE_MIGRATION_FLAGS_TEMPLATE = _("[dim]Using live migration flags: {flags}[/dim]")
    OFFLINE_MIGRATION_URI3 = _(
        "[dim]Using migrateToURI3 for offline migration with storage copy.[/dim]"
    )
    OFFLINE_MIGRATION_MIGRATE = _(
        "[dim]Using migrate for offline migration without storage copy.[/dim]"
    )
    MIGRATION_SUCCESS_TEMPLATE = _("[green]✓ Successfully migrated {vm_name}.[/]")
    UNDEFINE_SUCCESS_TEMPLATE = _(
        "[green]✓ Successfully undefined {vm_name} from the source host.[/]"
    )
    UNDEFINE_FAILED_TEMPLATE = _(
        "[yellow]WARNING: Failed to undefine {vm_name} from the source host: {error}[/]"
    )
    MIGRATION_FAILED_TEMPLATE = _("[red]ERROR: Failed to migrate {vm_name}: {error}[/]")
    HOST_KEY_VERIFICATION_FAILED = _("Host key verification failed")
    HOST_KEY_HINT = _(
        "[yellow]HINT: This usually means the user running the source libvirt daemon (root?) "
        "does not have the destination host in its known_hosts file, or cannot authenticate. "
        "Try running 'sudo ssh <destination_host>' on the source server to accept "
        "the host key.[/yellow]"
    )
    MIGRATION_PROCESS_FINISHED = _("\n[bold]--- Migration process finished ---[/]")

    # server_prefs_modals.py strings
    SERVER_PREFERENCES_TITLE_TEMPLATE = _("Server Preferences ({hostname})")
    STORAGE_POOLS_LABEL = _("Storage Pools")
    NO_AUTOSTART_LABEL = _("no autostart")
    LOADING_VOLUMES = _("Loading volumes...")
    POOL_UNAVAILABLE_SUFFIX = _(" [unavailable]")
    POOL_UNAVAILABLE_LABEL = _("Pool unavailable")
    USED_BY_COLUMN = _("Used By")
    NOT_IN_USE = _("Not in use")
    IN_USE_BY_TEMPLATE = _(" (in use by {vms})")
    VOLUME_SIZE_TEMPLATE = _(" ({size} GB)")
    POOL_NOT_ACTIVE = _("Pool is not active")
    AUTOSTART_OFF = _("Autostart Off")
    AUTOSTART_ON = _("Autostart On")
    NO_VOLUMES = _("No volumes")
    MOVING_VOLUME_TEMPLATE = _("Moving {volume_name}...")

    # utils_modals.py strings
    IN_PROGRESS_TITLE = _("In Progress")
    QUICK_INFO_TITLE = _("Quick Info")


class SparklineLabels:  # pylint: disable=too-few-public-methods
    """Constants for sparkline labels"""

    DISK_RW = _("Disk R/W {read:.2f}/{write:.2f} MB/s")
    NET_RX_TX = _("Net Rx/Tx {rx:.2f}/{tx:.2f} MB/s")
    VCPU = _("{cpu} VCPU")
    MEMORY_GB = _("{mem} Gb")


class ErrorMessages:  # pylint: disable=too-few-public-methods
    """Constants for error messages"""

    R_VIEWER_NOT_FOUND = _("Remote viewer command not found. Please ensure it is installed.")
    HARD_STOP_WARNING = _("This is a hard stop, like unplugging the power cord.")
    MIGRATION_LOCALHOST_NOT_SUPPORTED = _(
        "Migration from localhost (qemu:///system) is not supported.\\n"
        "A full remote URI (e.g., qemu+ssh://user@host/system) is required."
    )
    DIFFERENT_SOURCE_HOSTS = _("Cannot migrate VMs from different source hosts at the same time.")
    MIXED_VM_STATES = _("Cannot migrate running/paused and stopped VMs at the same time.")
    WEBSOCKIFY_NOT_FOUND = _("websockify is not installed. 'Web Console' button will be disabled.")
    NOVNC_NOT_FOUND = _("novnc is not installed. 'Web Console' button will be disabled.")
    FAILED_TO_OPEN_CONNECTION = _("Failed to open connection to [b]{uri}[/b]")
    NOT_CONNECTED_TO_ANY_SERVER = _("Not connected to any server.")
    COULD_NOT_CONNECT_TO_SERVER = _("Could not connect to {uri}")
    NO_ACTION_TYPE_BULK_MODAL = _("No action type received from bulk action modal.")
    VM_NOT_FOUND_FOR_EDITING = _("Could not find any of the selected VMs for editing.")
    VMS_MUST_BE_STOPPED_FOR_BULK_EDITING = _(
        "All VMs must be stopped for bulk editing. Running VMs: {running_vms}"
    )
    COULD_NOT_LOAD_DETAILS_FOR_REFERENCE_VM = _("Could not load details for reference VM.")
    SERVER_DISCONNECTED_AUTOCONNECT_DISABLED = _(
        "Server(s) {names} disconnected and autoconnect disabled due to connection failures."
    )
    NO_ACTIVE_SERVERS = _("No active servers.")
    NO_VMS_IN_CACHE = _("No VMs found in cache. Try refreshing first.")
    NO_VMS_SELECTED = _("No VMs selected.")
    ERROR_FETCHING_VM_DATA = _("Error fetching VM data: {error}")
    ERROR_DURING_INITIAL_CACHE_LOADING = _("Error during initial cache loading: {error}")
    ERROR_ON_VM_DURING_ACTION = _("Error on VM [b]{vm_name}[/b] during '{action}': {error}")
    FATAL_ERROR_BULK_ACTION = _("A fatal error occurred during bulk action: {error}")
    VM_INFO_ERROR = _("Error getting info for VM '{vm_name}': {error}")
    VM_NOT_FOUND_BY_ID = _("Could not find VM with ID [b]{vm_id}[/b]")
    BULK_EDIT_PREP_ERROR = _("Error preparing bulk edit: {error}")
    SERVER_CONNECTION_ERROR = _("Server [b]{server_name}[/b]: {error_msg}")
    SERVER_FAILED_TO_CONNECT = _("Failed to connect to [b]{server_name}[/b]: {error_msg}")
    BULK_ACTION_FAILED_TEMPLATE = _("Bulk action [b]{action_type}[/b] failed for {count} VMs.")
    PREFERENCES_LAUNCH_ERROR = _("Error launching preferences: {error}")
    BULK_ACTION_VM_NAMES_RETRIEVAL_FAILED = _("Could not retrieve names for selected VMs.")
    VM_CLONE_FAILED_TEMPLATE = _("Failed to clone to: {vm_names}")
    NO_SUITABLE_DISKS_FOR_OVERLAY = _("No suitable disks found for overlay.")
    OVERLAY_NAME_EMPTY_AFTER_SANITIZATION = _(
        "Overlay volume name cannot be empty after sanitization."
    )
    ERROR_CREATING_OVERLAY_TEMPLATE = _("Error creating overlay: {error}")
    ERROR_PREPARING_OVERLAY_CREATION_TEMPLATE = _("Error preparing overlay creation: {error}")
    NO_OVERLAY_DISKS_FOUND = _("No overlay disks found.")
    ERROR_DISCARDING_OVERLAY_TEMPLATE = _("Error discarding overlay: {error}")
    ERROR_PREPARING_DISCARD_OVERLAY_TEMPLATE = _("Error preparing discard overlay: {error}")
    NO_DISKS_FOUND_TO_COMMIT = _("No disks found to commit.")
    ERROR_COMMITTING_DISK_TEMPLATE = _("Error committing disk: {error}")
    ERROR_PREPARING_COMMIT_TEMPLATE = _("Error preparing commit: {error}")
    INVALID_XML_TEMPLATE = _(
        "Invalid XML for '[b]{vm_name}[/b]': {error}. Your changes have been discarded."
    )
    ERROR_GETTING_XML_TEMPLATE = _("Error getting XML for VM [b]{vm_name}[/b]: {error}")
    UNEXPECTED_ERROR_OCCURRED_TEMPLATE = _("An unexpected error occurred: {error}")
    CONNECTION_INFO_NOT_AVAILABLE = _("Connection info not available for this VM.")
    REMOTE_VIEWER_FAILED_TO_START_TEMPLATE = _(
        "{viewer} failed to start for {domain_name}: {error}"
    )
    ERROR_GETTING_VM_DETAILS_TEMPLATE = _("Error getting VM details for [b]{vm_name}[/b]: {error}")
    UNEXPECTED_ERROR_CONNECTING = _("An unexpected error occurred while trying to connect.")
    ERROR_CHECKING_WEB_CONSOLE_STATUS_TEMPLATE = _(
        "Error checking web console status for [b]{vm_name}[/b]: {error}"
    )
    SNAPSHOT_ERROR_TEMPLATE = _("Snapshot error for [b]{vm_name}[/b]: {error}")
    NO_SNAPSHOTS_TO_RESTORE = _("No snapshots to restore.")
    ERROR_FETCHING_SNAPSHOTS_TEMPLATE = _("Error fetching snapshots: {error}")
    NO_SNAPSHOTS_TO_DELETE = _("No snapshots to delete.")
    ERROR_DELETING_VM_TEMPLATE = _("Error deleting VM '{vm_name}': {error}")
    VM_NAME_EMPTY_AFTER_SANITIZATION = _("VM name cannot be empty after sanitization.")
    ERROR_RENAMING_VM_TEMPLATE = _("Error renaming VM [b]{vm_name}[/b]: {error}")
    VM_NOT_FOUND_ON_ACTIVE_SERVER_TEMPLATE = _(
        "VM [b]{vm_name}[/b] with internal ID [b]{uuid}[/b] not found on any active server."
    )
    ERROR_GETTING_ID_TEMPLATE = _("Error getting ID for [b]{vm_name}[/b]: {error}")
    SELECT_AT_LEAST_TWO_SERVERS_FOR_MIGRATION = _(
        "Please select at least two servers in 'Select Servers' to enable migration."
    )
    SELECTED_VM_NOT_FOUND_ON_ACTIVE_SERVER_TEMPLATE = _(
        "Selected VM with ID [b]{uuid}[/b] not found on any active server."
    )
    ERROR_GETTING_EXISTING_VM_NAMES_TEMPLATE = _("Error getting existing VM names: {error}")
    WEBCONSOLE_VNC_ONLY = _("Web console only supports VNC graphics.")
    COULD_NOT_DETERMINE_VNC_PORT = _("Could not determine VNC port for the VM.")
    FAILED_TO_START_WEBCONSOLE_TEMPLATE = _("Failed to start web console: {error}")
    NO_FREE_WEBCONSOLE_PORT = _(
        "Could not find a free port for the web console "
        "(all ports in range used by other sessions)."
    )
    REMOTE_KEY_GENERATION_FAILED = _(
        "Remote key generation failed. Falling back to insecure ws connection."
    )
    FAILED_TO_START_REMOTE_WEBSOCKIFY_TEMPLATE = _(
        "Failed to start remote websockify for [b]{vm_name}[/b]. Check logs."
    )
    REMOTE_WEBCONSOLE_CRASHED_TEMPLATE = _(
        "Remote web console process for [b]{vm_name}[/b] failed to start or crashed. "
        "Check remote logs."
    )
    NO_FREE_LOCAL_PORT_FOR_SSH_TUNNEL = _("Could not find a free local port for SSH tunnel.")
    FAILED_TO_CREATE_SSH_TUNNEL_TEMPLATE = _("Failed to create SSH tunnel: {error}")
    SSH_COMMAND_NOT_FOUND = _("SSH command not found. Cannot create tunnel.")
    FAILED_TO_CREATE_SSH_TUNNEL_GENERIC = _("Failed to create SSH tunnel...")
    PLEASE_SELECT_ACTION = _("Please select an action.")
    ERROR_SAVING_CONFIGURATION_TEMPLATE = _("Error saving configuration: {e}")
    VALIDATION_ERROR_TEMPLATE = _("Validation error: {error}")
    INVALID_FORMAT_TEMPLATE = _("Invalid format: {error}")
    INVALID_NODESET_SYNTAX_TEMPLATE = _("Invalid nodeset syntax: {nodeset}")
    CREATE_DISK_REQUIRED_FIELDS = _(
        "Pool, Volume Name, and Size are required to create a new disk."
    )
    DISK_IMAGE_PATH_REQUIRED = _("Path to disk image is required.")
    POOL_NAME_REQUIRED = _("Pool name is required.")
    TARGET_PATH_REQUIRED_FOR_DIR = _("Target Path is required for `dir` type.")
    NETFS_FIELDS_REQUIRED = _("For `netfs`, all fields are required.")
    NAME_AND_SIZE_REQUIRED = _("Name and size are required.")
    SIZE_MUST_BE_INTEGER = _("Size must be an integer.")
    DEST_POOL_AND_NAME_REQUIRED = _("Destination pool and new name are required.")
    NAME_PATH_FORMAT_REQUIRED = _("Name, path, and format are required. Ensure a file is selected.")
    ERROR_CREATING_STORAGE_POOL_TEMPLATE = _("Error creating storage pool: {error}")
    SELECT_DESTINATION_SERVER = _("Please select a destination server.")
    RUN_COMPATIBILITY_CHECK_FIRST = _("Please run compatibility check first.")
    MIGRATION_COMPATIBILITY_ERRORS = _("Cannot start migration due to compatibility errors.")
    NETWORK_NOT_FOUND_TEMPLATE = _(
        "Network '{network}' not found. Please select an available network."
    )
    SELECT_NETWORK = _("Please select a network.")
    FORWARD_DEVICE_NOT_FOUND_TEMPLATE = _("Forward device '{device}' not found on host.")
    ERROR_GETTING_HOST_INTERFACES_TEMPLATE = _("Error getting host interfaces: {error}")
    INVALID_NETWORK_NAME_TEMPLATE = _("Invalid Network Name: {error}")
    INVALID_CUSTOM_DNS_DOMAIN_TEMPLATE = _("Invalid Custom DNS Domain: {error}")
    NETWORK_NAME_REQUIRED = _("Network Name cannot be empty.")
    DHCP_IPS_NOT_IN_NETWORK_TEMPLATE = _("DHCP IPs are not in the network {network}")
    DHCP_START_BEFORE_END = _("DHCP start IP must be before the end IP.")
    INVALID_IP_OR_NETWORK_TEMPLATE = _("Invalid IP address or network: {error}")
    DHCP_REQUIRES_IP = _("DHCP cannot be enabled without an IP network.")
    SUBNET_OVERLAPS_TEMPLATE = _("Subnet {subnet} overlaps with an existing network.")
    ERROR_CREATING_NETWORK_TEMPLATE = _("Error creating network: {error}")
    ERROR_UPDATING_NETWORK_TEMPLATE = _("Error updating network: {error}")
    VM_NAME_ALREADY_EXISTS_TEMPLATE = _(
        "A VM with the name '{vm_name}' already exists. Please choose a different name."
    )
    ERROR_CHECKING_VM_NAME_TEMPLATE = _("Error checking VM name: {error}")
    PLEASE_SELECT_VALID_STORAGE_POOL = _("Please select a valid storage pool.")
    ISO_VOLUME_NOT_FOUND_TEMPLATE = _("Selected ISO volume does not exist: {iso_url}")
    SELECT_VALID_ISO_VOLUME = _("Please select a valid ISO volume from the storage pool.")
    INVALID_EXPERT_SETTINGS = _("Invalid input for expert settings. Using defaults.")
    MEMORY_RANGE_ERROR = _("Memory must be between 1 and 8192 GB.")
    CPU_RANGE_ERROR = _("CPU count must be between 1 and 768.")
    DISK_SIZE_RANGE_ERROR = _("Disk size must be between 1 and 10000 GB.")
    STORAGE_POOL_NOT_ACTIVE_TEMPLATE = _(
        "Storage pool '{pool_name}' is not active. Please activate it first."
    )
    ERROR_ACCESSING_STORAGE_POOL_TEMPLATE = _("Error accessing storage pool '{pool_name}': {error}")
    CUSTOM_ISO_PATH_NOT_EXIST_TEMPLATE = _("Custom ISO path does not exist: {path}")
    CUSTOM_ISO_NOT_FILE_TEMPLATE = _("Custom ISO path is not a file: {path}")
    CUSTOM_ISO_DOWNLOAD_FAILED_TEMPLATE = _("Failed to download ISO from {url}: {error}")
    CUSTOM_ISO_INVALID_URL_TEMPLATE = _("Invalid URL provided: {url}")
    CHECKSUM_MISSING = _("Checksum validation enabled but no checksum provided")
    CHECKSUM_VALIDATION_FAILED = _("Checksum validation failed!")
    NO_ISO_URL_SPECIFIED = _("No ISO URL specified for provisioning")
    COULD_NOT_GET_VM_DETAILS_TEMPLATE = _("Could not get details for {vm_name}")
    FAILED_TO_START_VM_OR_VIEWER_TEMPLATE = _("Failed to start VM or viewer: {error}")
    PROVISIONING_FAILED_TEMPLATE = _("Provisioning failed: {error}")
    FAILED_TO_FETCH_ISO_VOLUMES_TEMPLATE = _(
        "Failed to fetch ISO volumes from {pool_name}: {error}"
    )
    FAILED_TO_FETCH_ISOS_TEMPLATE = _("Failed to fetch ISOs: {error}")
    VM_NAME_CANNOT_BE_EMPTY = _("VM name cannot be empty.")
    CONNECTING_TO_SERVER_TEMPLATE = _("Connecting to {uri}...")
    FAILED_TO_CONNECT_TO_SERVER_TEMPLATE = _("Failed to connect to {uri}")
    ERROR_DELETING_SERVER_TEMPLATE = _("Error deleting server '{server_name}': {error}")
    DELETE_SERVER_CONFIRMATION_TEMPLATE = _(
        "Are you sure you want to delete Server;\n'{server_name}'\nfrom list?"
    )
    NOT_CONNECTED_TO_ANY_SERVER_PREFS = _("Not connected to any server.")
    MULTIPLE_SERVERS_ACTIVE_NONE_SELECTED = _(
        "Multiple servers active but none selected for preferences."
    )
    FAILED_TO_GET_CONNECTION_PREFS_TEMPLATE = _(
        "Failed to get connection for server preferences on {uri}."
    )
    COULD_NOT_FIND_OBJECT_XML = _("Could not find object to display XML for.")
    ERROR_GETTING_XML_FOR_TYPE_TEMPLATE = _("Error getting XML for {obj_type}: {error}")
    COULD_NOT_FIND_POOL_EDIT = _("Could not find pool object to edit.")
    POOL_MUST_BE_INACTIVE_FOR_XML_EDIT = _("Pool must be inactive to edit its XML definition.")
    ERROR_GETTING_XML_FOR_POOL_TEMPLATE = _("Error getting XML for pool: {error}")
    ERROR_UPDATING_POOL_XML_TEMPLATE = _("Error updating pool XML: {error}")
    UNEXPECTED_ERROR_OCCURRED_TEMPLATE_XML = _("An unexpected error occurred: {error}")
    EDIT_POOL_XML_WARNING = _(
        "Editing a pool's XML definition is an advanced operation.\\n"
        "An invalid configuration may make its volumes inaccessible to VMs.\\n\\n"
        "Are you sure you want to proceed?"
    )
    ERROR_TOGGLE_POOL_ACTIVE_TEMPLATE = _("Error toggling pool active state: {error}")
    ERROR_TOGGLE_POOL_AUTOSTART_TEMPLATE = _("Error toggling pool autostart state: {error}")
    INVALID_OR_NON_EXISTENT_PATH_TEMPLATE = _("Invalid or non-existent path: {path}")
    ERROR_REFRESHING_POOL_TEMPLATE = _("Error refreshing pool: {error}")
    NO_POOL_FOR_DIRECTORY_CONFIRM_TEMPLATE = _(
        "No storage pool exists for the directory:\n'{directory}'.\n\nCreate a new pool named '{pool_name}'?"
    )
    ERROR_CREATING_STORAGE_POOL_FOR_DIR_TEMPLATE = _("Error creating storage pool: {error}")
    COULD_NOT_DETERMINE_SOURCE_POOL = _("Could not determine the source pool.")
    MOVE_OPERATION_FAILED_TEMPLATE = _("Move operation failed: {error}")
    ERROR_GETTING_NETWORK_XML_TEMPLATE = _("Error getting network XML: {error}")
    COULD_NOT_RETRIEVE_NETWORK_INFO_TEMPLATE = _(
        "Could not retrieve info for network '{network_name}'."
    )
    ERROR_DELETING_NETWORK_TEMPLATE = _("Error deleting network '{network_name}': {error}")
    DELETE_NETWORK_CONFIRM_TEMPLATE = _(
        "Are you sure you want to delete network:\n'{network_name}'"
    )
    NETWORK_IN_USE_WARNING_TEMPLATE = _(
        "\nThis network is currently in use by the following VMs:\n{vm_list}."
    )
    NOT_CONNECTED_TO_LIBVIRT = _("Not connected to libvirt.")
    DELETE_STORAGE_POOL_CONFIRMATION_TEMPLATE = _(
        "Are you sure you want to delete storage pool:\n' {pool_name}'\nThis will delete the pool definition but not the data on it."
    )
    VIRTIOFS_PATH_EMPTY = _("Source Path and Target Path cannot be empty.")
    SANITIZATION_ERROR_TEMPLATE = _("{error}")
    PLEASE_SELECT_INTERFACE_AND_NETWORK = _("Please select an interface and a network.")
    BASE_NAME_EMPTY = _("Base name cannot be empty.")
    INVALID_CHARS_IN_SUFFIX = _("Invalid characters in suffix: {error}")
    CLONE_COUNT_POSITIVE_INTEGER = _("Number of clones must be a positive integer.")
    SUFFIX_MANDATORY_FOR_MULTIPLE_CLONES = _("Suffix is mandatory when creating multiple clones.")
    VM_NAME_CANNOT_BE_EMPTY_RENAME = _("VM name cannot be empty.")
    SNAPSHOT_NAME_CANNOT_BE_EMPTY = _("Snapshot name cannot be empty.")
    QEMU_GUEST_AGENT_RECOMMENDATION = _(
        "QEMU Guest Agent not detected. It is recommended to pause the VM before taking a snapshot."
    )
    VM_DETAIL_COULD_NOT_LOAD_NETWORKS = _("Could not load networks: {error}")
    CANNOT_ENABLE_SECURE_BOOT_WITHOUT_UEFI = _(
        "Cannot enable secure boot without a UEFI file selected."
    )
    ERROR_UPDATING_NETWORK_TEMPLATE_SHORT = _("Error updating network: {error}")
    GRAPHICS_VM_MUST_BE_STOPPED = _("VM must be stopped to apply graphics settings.")
    RNG_VM_MUST_BE_STOPPED = _("VM must be stopped to apply RNG settings.")
    RNG_DEVICE_PATH_EMPTY = _("RNG device path cannot be empty.")
    TPM_VM_MUST_BE_STOPPED = _("VM must be stopped to apply TPM settings.")
    DEVICE_PATH_REQUIRED_FOR_PASSTHROUGH_TPM = _("Device path is required for passthrough TPM.")
    PCI_PASSTHROUGH_NOT_IMPLEMENTED = _("PCI passthrough not implemented yet.")
    ADD_CHANNEL_NO_TARGET_NAME = _("Selected channel has no target name.")
    ERROR_ADDING_CHANNEL_TEMPLATE = _("Error adding channel: {error}")
    ERROR_REMOVING_CHANNEL_TEMPLATE = _("Error removing channel: {error}")
    DISK_VM_MUST_BE_STOPPED_TO_EDIT = _("VM must be stopped to edit disk settings.")
    ERROR_ATTACHING_USB_DEVICE_TEMPLATE = _("Error attaching USB device: {error}")
    ERROR_DETACHING_USB_DEVICE_TEMPLATE = _("Error detaching USB device: {error}")
    SPICE_REMOVAL_CONFIRMATION_SINGLE = _(
        "This VM has other SPICE-related devices (e.g., channels, QXL video).\nDo you want to remove them for a clean switch to VNC?"
    )
    SPICE_REMOVAL_CONFIRMATION_BULK = _(
        "Some selected VMs have other SPICE-related devices.\nDo you want to remove them from ALL selected VMs for a clean switch to VNC?"
    )
    COULD_NOT_DETERMINE_SOURCE_POOL = _("Could not determine the source pool.")
    ERROR_SAVING_BOOT_ORDER_TEMPLATE = _("Error saving boot order: {error}")
    SANITIZED_INPUT_TOO_LONG = _("Sanitized input is too long (max 64 characters)")
    SANITIZED_DOMAIN_TOO_LONG = _("Sanitized domain name is too long (max 64 characters)")
    VCPU_EXCEEDS_MAX_TEMPLATE = _("vCPU {vcpu_int} exceeds max vCPUs ({max_vcpus})")
    INVALID_CPUSET_SYNTAX_TEMPLATE = _("Invalid cpuset syntax: {cpuset}")
    LOG_FILE_NOT_FOUND = _("Log file ({log_path}) not found.")
    ERROR_READING_LOG_FILE = _("Error reading log file: {error}")
    TERMINAL_HEIGHT_TOO_SMALL = _("Terminal height is too small ({height} lines). Please resize.")
    TERMINAL_WIDTH_TOO_SMALL = _("Terminal width is too small ({width} columns). Please resize.")
    TMUX_REQUIRED_FOR_TEMPLATE_EDITING = _(
        "Template editing requires running inside tmux. "
        "Please start virtui-manager inside a tmux session."
    )
    EDITOR_CANCELLED_OR_FAILED = _("Editor was cancelled or failed")
    FAILED_TO_SAVE_CONFIGURATION = _("Failed to save configuration")
    ERROR_SAVING_AUTOFILL_CONFIGURATION = _("Error saving auto-fill configuration")
    ERROR_OPENING_AUTOFILL_CONFIGURATION = _("Error opening auto-fill configuration")


class DialogMessages:  # pylint: disable=too-few-public-methods
    """Constants for dialog messages"""

    DELETE_SNAPSHOT_CONFIRMATION = _("Are you sure you want to delete snapshot '{name}'?")
    DELETE_VOLUME_CONFIRMATION_TEMPLATE = _("Are you sure you want to delete volume '{vol_name}'?")
    EXPERIMENTAL = _(
        "Experimental Feature! Still contains bugs, fix in progress. You have been informed"
    )
    CONFIRM_REMOVE_CHANNEL_TEMPLATE = _("Are you sure you want to remove channel '{target_name}'?")
    CONFIRM_DISCARD_CHANGES = _(
        "Are you sure you want to discard changes in '{target_disk}' and revert to its backing file? This action cannot be undone."
    )
    CONFIRM_MERGE_CHANGES = _(
        "Are you sure you want to merge changes from '{target_disk}' into its backing file?"
    )
    CONFIRM_BULK_EDIT = _(
        "This will apply configuration changes to all selected VMs based on the settings you choose.\n\nSome changes modify the VM's XML directly. All change cannot be undone.\n\nAre you sure you want to proceed?"
    )


class QuickMessages:  # pylint: disable=too-few-public-methods
    """Constants for quick messages"""

    REMOTE_VIEWER_SELECTED = _("The remote viewer {viewer} has been selected.")
    VM_DATA_LOADED = _("VM data loaded. Displaying VMs...")
    FILTER_RUNNING_VMS = _("Filter: Running VMs")
    FILTER_ALL_VMS = _("Filter: All VMs")
    ALL_VMS_UNSELECTED = _("All VMs unselected.")
    CACHING_VM_STATE = _("Caching VM state for: {vms_list}")


class WarningMessages:  # pylint: disable=too-few-public-methods
    """Constants for warning messages"""

    COMPACT_VIEW_LOCKED = _("Compact view is locked during bulk operations.")
    VMS_PER_PAGE_PERFORMANCE_WARNING = _(
        "Displaying [b]{vms_per_page}[/b] VMs per page. CPU usage may increase; 9 is recommended for optimal performance."
    )
    LIBVIRT_XML_NO_EFFECTIVE_CHANGE = _(
        "VM [b]{vm_name}[/b]: Libvirt accepted the XML but the configuration remains unchanged. Your changes may have been ignored or normalized away."
    )
    NO_REMOTE_VIEWER_SELECTED = _("No remote viewer selected. Auto-detection will be used.")
    RUNNING_NETWORK_USAGE_SCAN_WARNING = _(
        "Running network usage scan, this can freeze the UI for larger numbers of VMs."
    )
    TOO_MANY_VMS_DISK_USAGE_WARNING_TEMPLATE = _(
        "More than {count} VMs detected on this server.\nSkipping disk usage scan to prevent UI freeze."
    )
    RUNNING_DISK_USAGE_SCAN_WARNING = _(
        "Running disk usage scan, this can freeze the UI for larger numbers of VMs and disks."
    )
    VIRTIOFS_SHARED_MEM_WARNING = _(
        "! Shared Memory is Mandatory to use VirtIO-FS.\n! Enable it in Mem tab."
    )
    VM_START_OVERCOMMIT_MEMORY = _("Memory: {total} MB > {limit} MB")
    VM_START_OVERCOMMIT_VCPU = _("vCPUs: {total} > {limit}")
    VM_START_OVERCOMMIT_WARNING = _(
        "Starting VM '{vm_name}' will exceed host capacity (Active Allocation):\n{details}"
    )


class SuccessMessages:  # pylint: disable=too-few-public-methods
    """Constants for success messages"""

    CONNECTED_TO_SERVER = _("Connected to [b]{uri}[/b]")
    STATS_LOGGING_DISABLED = _("Statistics logging and monitoring disabled.")
    STATS_LOGGING_ENABLED = _("Statistics logging and monitoring enabled (every 10s).")
    CONFIG_UPDATED = _("Configuration updated.")
    VMS_SELECTED_BY_PATTERN = _("Selected {count} VMs matching pattern.")
    TERMINAL_COPY_HINT = _(
        "In some Terminal use [b]Shift[/b] key while selecting text with the mouse to copy it."
    )
    NO_SERVERS_CONFIGURED = _("No servers configured. Please add one via 'Servers List'.")
    LOG_LEVEL_CHANGED = _("Log level changed to {level}")
    BULK_ACTION_SUCCESS_TEMPLATE = _("Bulk action [b]{action_type}[/b] successful for {count} VMs.")
    SERVER_CONNECTED = _("Connected to [b]{name}[/b]")
    INPUT_SANITIZED = _("Input sanitized: '{original_input}' changed to '{sanitized_input}'")
    OVERLAY_CREATED = _("Overlay [b]{overlay_name}[/b] created and attached.")
    OVERLAY_DISCARDED = _("Overlay for [b]{target_disk}[/b] discarded and reverted to base image.")
    DISK_COMMITTED = _("Disk changes committed successfully.")
    VM_CONFIG_UPDATED = _("VM [b]{vm_name}[/b] configuration updated successfully.")
    NO_XML_CHANGES = _("No changes made to the XML configuration.")
    SNAPSHOT_CREATED = _("Snapshot [b]{snapshot_name}[/b] created successfully.")
    SNAPSHOT_RESTORED = _("Restored to snapshot [b]{snapshot_name}[/b] successfully.")
    SNAPSHOT_DELETED = _("Snapshot [b]{snapshot_name}[/b] deleted successfully.")
    VM_DELETED = _("VM '{vm_name}' deleted successfully.")
    VM_RENAMED = _("VM '{old_name}' renamed to '{new_name}' successfully.")
    VM_RENAME_CANCELLED = _("VM rename cancelled.")
    VM_RENAME_NO_CHANGE = _("New VM name is the same as the old name. No rename performed.")
    VM_CLONED = _("Successfully cloned to: {vm_names}")
    WEBCONSOLE_STOPPED = _("Web console stopped.")
    REMOTE_USER_CERT_FOUND = _("Remote user cert/key found, using secure wss connection.")
    REMOTE_SYSTEM_CERT_FOUND = _("Remote system cert/key found, using secure wss connection.")
    NO_REMOTE_CERT_FOUND_GENERATING = _(
        "No remote cert/key found. Attempting to generate in system directory..."
    )
    NO_REMOTE_CERT_CHECK_INSECURE = _(
        "Could not check for remote cert/key, using insecure ws connection."
    )
    REMOTE_CONNECTION_SSH_TUNNEL_SETUP = _("Remote connection detected. Setting up SSH tunnel...")
    LOCAL_CERT_FOUND = _("Found cert/key, using secure wss connection.")
    ALL_CACHES_CLEARED = _("All caches cleared")
    CONFIGURATION_SAVED = _("Configuration saved successfully.")
    STORAGE_POOL_CREATED_TEMPLATE = _("Storage pool '{name}' created and started.")
    NETWORK_CREATED_TEMPLATE = _("Network {name} created successfully.")
    NETWORK_UPDATED_TEMPLATE = _("Network {name} updated successfully.")
    VM_NAME_SANITIZED_TEMPLATE = _("VM name sanitized: '{original}' -> '{sanitized}'")
    VM_STARTED_TEMPLATE = _("VM '{vm_name}' started.")
    VM_SAVED_TEMPLATE = _("VM '{vm_name}' saved (hibernated).")
    REMOTE_VIEWER_STARTED_TEMPLATE = _("Remote viewer {viewer} started for {vm_name}")
    VM_DEFINED_CONFIGURE_TEMPLATE = _("VM '{vm_name}' defined. Please configure and start it.")
    VM_CREATED_SUCCESSFULLY_TEMPLATE = _("VM '{vm_name}' created successfully!")
    SERVER_DELETED_TEMPLATE = _("Server '{server_name}' deleted successfully.")
    POOL_ACTIVATION_CHANGE_TEMPLATE = _("Pool '{pool_name}' is now {status}.")
    POOL_AUTOSTART_CHANGE_TEMPLATE = _("Autostart for pool '{pool_name}' is now {status}.")
    POOL_MANAGED_BY_EXISTING_POOL_TEMPLATE = _(
        "A pool named '{pool_name}' already manages this directory.\nRefreshed pool to include the new volume."
    )
    NETWORK_ACTIVATION_CHANGE_TEMPLATE = _("Network '{net_name}' is now {status}.")
    NETWORK_AUTOSTART_CHANGE_TEMPLATE = _("Autostart for network '{net_name}' is now {status}.")
    BASE_NAME_SANITIZED_TEMPLATE = _(
        "Base name sanitized: [b]{original}[/b] changed to [b]{sanitized}[/b]"
    )
    INPUT_SANITIZED_TEMPLATE = _("Input sanitized: [b]{original}[/b] changed to [b]{sanitized}[/b]")
    BOOT_ORDER_SAVED_SUCCESSFULLY = _("Boot order saved successfully.")
    GRAPHICS_SETTINGS_APPLIED_SUCCESSFULLY = _("Graphics settings applied successfully")
    RNG_SETTINGS_APPLIED_SUCCESSFULLY = _("RNG settings applied successfully. Device: {rng_device}")
    TPM_SETTINGS_APPLIED_SUCCESSFULLY = _("TPM settings applied successfully")
    USB_DEVICE_ATTACHED_TEMPLATE = _("Attached USB device: {description}")
    USB_DEVICE_DETACHED_TEMPLATE = _("Detached USB device: {description}")
    CHANNEL_ADDED_SUCCESSFULLY = _("Channel added successfully.")
    CHANNEL_REMOVED_SUCCESSFULLY_TEMPLATE = _("Channel '{target_name}' removed successfully.")
    SPICE_DEVICES_REMOVED_SUCCESS = _("Removed associated SPICE devices")
    VM_VIDEO_MODEL_SET_SUCCESS = _("Video model set to {new_model}")
    VM_3D_ACCELERATION_SET_SUCCESS = _("3D Acceleration {state}")
    VM_SOUND_MODEL_SET_SUCCESS = _("Sound model set to {new_model}")
    VM_SECURE_BOOT_SET_SUCCESS = _("Secure Boot {state}")
    VM_SHARED_MEMORY_SET_SUCCESS = _("Shared memory {state}")
    VM_CPU_MODEL_SET_SUCCESS = _("CPU model set to {new_cpu_model}")
    VM_UEFI_FILE_SET_SUCCESS = _("UEFI file set to {uefi_file_name}")
    VM_NETWORK_INTERFACE_CHANGED_TEMPLATE = _("Interface {mac_address} switched to {new_network}")
    STORAGE_POOL_UPDATED_SUCCESSFULLY_TEMPLATE = _(
        "Storage pool '{pool_name}' updated successfully."
    )
    UPDATED_VM_CONFIGURATIONS_TEMPLATE = _("Updated VM configurations for: {vm_list}")
    NETWORK_DELETED_SUCCESSFULLY_TEMPLATE = _("Network '{network_name}' deleted successfully.")
    STORAGE_POOL_DELETED_SUCCESSFULLY_TEMPLATE = _(
        "Storage pool '{pool_name}' deleted successfully."
    )
    VOLUME_DELETED_SUCCESSFULLY_TEMPLATE = _("Volume '{volume_name}' deleted successfully.")
    VOLUME_CREATED_SUCCESSFULLY_TEMPLATE = _(
        "Volume [b]{name} {size_gb}Gb {format}[/b] created successfully."
    )
    VOLUME_MOVED_SUCCESSFULLY_TEMPLATE = _(
        "Volume '{volume_name}' moved to pool '{dest_pool_name}'."
    )
    BULK_ACTION_SUMMARY = _(
        "Bulk action '{action_type}' complete. Successful: {successful_vms}, Failed: {failed_vms}"
    )
    AUTOFILL_AND_SCC_CONFIGURATION_UPDATED = _("Auto-fill and SCC configuration updated")


class ProgressMessages:  # pylint: disable=too-few-public-methods
    """Constants for success messages"""

    CONNECTING_TO_SERVER = _("Connecting to [b]{uri}[/b]...")
    CONFIG_UPDATED_REFRESHING_VM_LIST = _("Configuration updated. Refreshing VM list...")
    LOADING_VM_DATA_FROM_REMOTE_SERVERS = _("Loading VM data from remote server(s)...")
    COMMITTING_CHANGES_FOR = _("Committing changes for {name}...")
