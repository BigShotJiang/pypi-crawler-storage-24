"""
Utils functions
"""

import logging
import os
import re
import shutil
import socket
import subprocess
from functools import lru_cache, wraps
from pathlib import Path
from typing import Callable, List, Optional, Tuple, Union
from urllib.parse import urlparse

from .constants import AppInfo


# Regex to match URIs with embedded credentials (user:password@host pattern)
# Matches patterns like: qemu+ssh://user:password@host/system
# Uses a non-greedy match for password and looks ahead for host pattern
_URI_CREDENTIAL_PATTERN = re.compile(
    r"((?:qemu|xen|lxc|vbox|vmware|hyperv|esx|vpx|libxl|bhyve|ch|vz|test)"  # libvirt drivers
    r"(?:\+[a-z]+)?"  # optional transport (+ssh, +tcp, etc.)
    r"://)"  # scheme separator
    r"([^:@/]+)"  # username
    r":(.+?)"  # password (non-greedy capture to redact)
    r"(@)"  # @ before host
    r"(?=[a-zA-Z0-9.\-]+(?:/|$|\s))",  # lookahead for hostname pattern
    re.IGNORECASE,
)


def sanitize_credentials(message: str) -> str:
    """Sanitize sensitive information from messages.

    Redacts credentials from URIs (e.g., qemu+ssh://user:password@host
    becomes qemu+ssh://user:***@host).

    Args:
        message: The message to sanitize.

    Returns:
        The sanitized message with credentials redacted.
    """
    return _URI_CREDENTIAL_PATTERN.sub(r"\1\2:***\4", message)


def sanitize_sensitive_data(message: str) -> str:
    """
    Comprehensive sanitization of sensitive information for logs, CLI output,
    error messages, and debugging output.

    This function provides enterprise-grade sanitization to prevent accidental
    exposure of passwords, SSH keys, tokens, connection credentials, and other
    sensitive data in:
    - Log messages and console output
    - Error dialogs and notifications
    - CLI command output
    - Debugging and verbose output
    - Exception messages

    Args:
        message: The message to sanitize

    Returns:
        Sanitized message with sensitive data replaced by safe placeholders
    """
    if not isinstance(message, str):
        return str(message)

    # Start with existing URI credential sanitization
    sanitized = sanitize_credentials(message)

    # 1. Redact common password patterns in various formats
    sanitized = re.sub(
        r"(?i)\b(passwd|password|pwd|pass|secret|key|token|auth|credential|cred)"
        r"\s*[=:]\s*[^,\s;'\"]+",
        r"\1=***",
        sanitized,
    )

    # 2. Redact passwords in various URI formats
    # Already covered by sanitize_credentials, but add additional patterns
    sanitized = re.sub(
        r"://([^/:@]+):([^@]+)@",  # Catch any protocol://user:pass@host
        r"://\1:***@",
        sanitized,
    )

    # 2a. Redact SSH-style user:password@host patterns (without protocol)
    sanitized = re.sub(
        r"\b([a-zA-Z_][a-zA-Z0-9_]*):([^@\s]+)@([a-zA-Z0-9.-]+)",
        r"\1:***@\3",
        sanitized,
    )

    # 3. Redact SSH private keys and certificates
    sanitized = re.sub(
        r"-----BEGIN [A-Z\s]+ PRIVATE KEY-----.*?-----END [A-Z\s]+ PRIVATE KEY-----",
        "[SSH_PRIVATE_KEY_REDACTED]",
        sanitized,
        flags=re.DOTALL,
    )

    # 4. Redact SSH command arguments that might contain sensitive data
    sanitized = re.sub(
        r"(ssh\s+[^'\"]*-o\s+[^=]*=)[^,\s;'\"]+",
        r"\1***",
        sanitized,
    )

    # 5. Redact Base64-like tokens and authentication strings (40+ characters)
    sanitized = re.sub(
        r"\b[A-Za-z0-9+/]{40,}={0,2}\b",
        "[TOKEN_REDACTED]",
        sanitized,
    )

    # 6. Redact hexadecimal strings that might be keys/hashes (32+ chars)
    sanitized = re.sub(
        r"\b[a-fA-F0-9]{32,}\b",
        "[HEX_KEY_REDACTED]",
        sanitized,
    )

    # 7. Redact JSON password fields
    sanitized = re.sub(
        r'(?i)"(passwd|password|pwd|pass|secret|key|token|auth|credential|cred)"\s*:\s*"[^"]*"',
        r'"\1":"***"',
        sanitized,
    )

    # 8. Redact XML password fields
    sanitized = re.sub(
        r"(?i)<(passwd|password|pwd|pass|secret|key|token|auth|credential|cred)>.*?</\1>",
        r"<\1>***</\1>",
        sanitized,
    )

    # 9. Redact command line password arguments
    sanitized = re.sub(
        r"(?i)(-+(?:passwd|password|pwd|pass|secret|key|token|auth|credential|cred))"
        r"[\s=][^,\s;'\"]+",
        r"\1 ***",
        sanitized,
    )

    # 10. Redact environment variable-style secrets
    sanitized = re.sub(
        r"(?i)\b[A-Z_]*(PASSWORD|SECRET|KEY|TOKEN|CRED)[A-Z_]*\s*=\s*[^,\s;'\"]+",
        r"\1=***",
        sanitized,
    )

    # 11. Redact API keys and similar patterns
    sanitized = re.sub(
        r"(?i)\b(api_key|apikey|access_token|refresh_token|bearer|authorization)"
        r"\s*[=:]\s*[^,\s;'\"]+",
        r"\1=***",
        sanitized,
    )

    # 12. Redact certificate content (public certificates can also be sensitive)
    sanitized = re.sub(
        r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----",
        "[CERTIFICATE_REDACTED]",
        sanitized,
        flags=re.DOTALL,
    )

    return sanitized


def strip_ansi_codes(text: str) -> str:
    """
    Remove ANSI escape sequences (colors, terminal control) from a string.

    Args:
        text: The string to clean

    Returns:
        Clean string without escape sequences
    """
    if not isinstance(text, str):
        return text

    # Handle CSI (Control Sequence Introducer) sequences: \x1B[...
    # This covers colors, cursor movement, etc.
    text = re.sub(r"\x1B\[[0-?]*[ -/]*[@-~]", "", text)

    # Handle OSC (Operating System Command) sequences: \x1B]...
    # These often end with \x07 (BEL) or \x1B\ (ST)
    # Using a more robust pattern for OSC
    text = re.sub(r"\x1B\].*?(?:\x07|\x1B\\)", "", text)

    # Handle other escape sequences like \x1B=, \x1B>, \x1B(B, etc.
    text = re.sub(r"\x1B[()=@-Z\\-_]|[\x80-\x9F]", "", text)

    return text


class SanitizingFilter(logging.Filter):  # pylint: disable=too-few-public-methods
    """A logging filter that sanitizes sensitive information from log messages.

    This filter redacts credentials from URIs in log messages to prevent
    clear-text logging of sensitive information.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """Filter and sanitize the log record.

        Args:
            record: The log record to filter.

        Returns:
            Always returns True (record is not filtered out), but the
            record's message is sanitized in place.
        """
        if record.args:
            # Sanitize format arguments
            sanitized_args = []
            for arg in record.args:
                if isinstance(arg, str):
                    sanitized_args.append(sanitize_sensitive_data(arg))
                else:
                    sanitized_args.append(arg)
            record.args = tuple(sanitized_args)

        # Also sanitize the message itself in case it's a pre-formatted string
        if isinstance(record.msg, str):
            record.msg = sanitize_sensitive_data(record.msg)

        return True


def is_running_under_flatpak():
    """
    Check if the application is running under Flatpak.

    Returns:
        bool: True if running under Flatpak, False otherwise
    """
    return "FLATPAK_ID" in os.environ


def find_free_port(start: int, end: int) -> int:
    """
    Find a free port in the specified range.

    Args:
        start (int): Starting port number
        end (int): Ending port number

    Returns:
        int: A free port number

    Raises:
        OSError: If no free port is found in the range
        TypeError: If inputs are not integers
        ValueError: If start > end
    """
    # Input validation
    if not isinstance(start, int) or not isinstance(end, int):
        raise TypeError("Start and end must be integers")
    if start > end:
        raise ValueError("Start port must be less than or equal to end port")

    for port in range(start, end + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(("0.0.0.0", port))
                return port
        except OSError:
            continue
    raise OSError(f"Could not find a free port in the range {start}-{end}")


def log_function_call(func) -> callable:
    """
    A decorator that logs the function call and its arguments.

    Args:
        func: The function to be decorated

    Returns:
        function: The wrapped function with logging

    Raises:
        TypeError: If func is not callable
    """
    if not callable(func):
        raise TypeError("func must be callable")

    @wraps(func)
    def wrapper(*args, **kwargs):
        logging.info("Calling %s with args: %s, kwargs: %s", func.__name__, args, kwargs)
        try:
            result = func(*args, **kwargs)
            logging.info("%s returned: %s", func.__name__, result)
            return result
        except Exception as e:
            logging.error("Exception in %s: %s", func.__name__, e)
            raise

    return wrapper


def generate_webconsole_keys_if_needed(  # pylint: disable=too-many-branches
    config_dir: Path = None, remote_host: str = None
) -> List[Tuple[str, str]]:
    """
    Checks for WebConsole TLS key and certificate and generates them if not found.
    Can generate locally or on a remote host via SSH.

    Args:
        config_dir (Path, optional): Directory to check/generate keys in.
            Defaults to ~/.config/virtui-manager for regular installs,
            or /etc/virtui-manager/keys for Flatpak.
        remote_host (str, optional): SSH host string (user@host) for remote generation.

    Returns:
        list: A list of tuples containing (level, message) for display
    """
    messages = []
    if config_dir is None:
        # In Flatpak, use system directory; otherwise use user config
        if is_running_under_flatpak():
            config_dir = Path("/etc") / AppInfo.name / "keys"
        else:
            config_dir = Path.home() / ".config" / AppInfo.name

    # If remote, we treat config_dir as a string path on the remote
    if remote_host:
        key_path = f"{config_dir}/key.pem"
        cert_path = f"{config_dir}/cert.pem"
    else:
        key_path = config_dir / "key.pem"
        cert_path = config_dir / "cert.pem"

    # Check existence
    exists = False
    if remote_host:
        try:
            subprocess.run(
                ["ssh", remote_host, f"test -f {key_path} && test -f {cert_path}"],
                check=True,
                timeout=5,
            )
            exists = True
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
            exists = False
    else:
        exists = key_path.exists() and cert_path.exists()

    if not exists:
        messages.append(
            (
                "info",
                f"WebConsole TLS key/cert not found on "
                f"{'remote' if remote_host else 'local'}. Generating...",
            )
        )

        hostname = "localhost"
        if remote_host:
            hostname = remote_host.split("@")[-1]

        gen_cmd = [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            "rsa:4096",
            "-keyout",
            str(key_path),
            "-out",
            str(cert_path),
            "-sha256",
            "-days",
            "365",
            "-nodes",
            "-subj",
            f"/CN={hostname}",
            "-addext",
            f"subjectAltName = DNS:{hostname}",
        ]

        try:
            if remote_host:
                # Ensure directory exists first
                subprocess.run(
                    ["ssh", remote_host, f"mkdir -p {config_dir}"], check=True, timeout=5
                )
                # Run openssl remotely
                # We need to quote the command for ssh
                remote_cmd = " ".join(gen_cmd)
                subprocess.run(
                    ["ssh", remote_host, remote_cmd],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            else:
                try:
                    config_dir.mkdir(parents=True, exist_ok=True)
                except PermissionError:
                    error_msg = (
                        f"Permission denied creating directory {config_dir}. "
                        f"In Flatpak, ensure /etc/virtui-manager/keys is accessible."
                    )
                    messages.append(("error", error_msg))
                    logging.error(error_msg)
                    return messages
                subprocess.run(gen_cmd, check=True, capture_output=True, text=True, timeout=30)

            messages.append(
                (
                    "info",
                    f"Successfully generated WebConsole TLS key and certificate in {config_dir} "
                    f"on {'remote' if remote_host else 'local'}.",
                )
            )

        except subprocess.TimeoutExpired:
            error_message = "Failed to generate WebConsole TLS key/cert: Operation timed out"
            messages.append(("error", error_message))
        except subprocess.CalledProcessError as e:
            error_message = (
                f"Failed to generate WebConsole TLS key/cert: "
                f"{e.stderr.strip() if e.stderr else str(e)}"
            )
            messages.append(("error", error_message))
        except FileNotFoundError:
            messages.append(("error", "openssl command not found. Please install openssl."))
        except Exception as e:
            error_message = f"Unexpected error generating WebConsole keys: {str(e)}"
            messages.append(("error", error_message))

    return messages


def is_remote_connection(uri: str) -> bool:
    """
    Determines if the connection URI is for a remote qemu+ssh host.

    Args:
        uri: The libvirt connection URI

    Returns:
        bool: True if the URI represents a remote connection, False otherwise

    Examples:
        >>> is_remote_connection("qemu:///system")
        False
        >>> is_remote_connection("qemu+ssh://user@remote.host/system")
        True
        >>> is_remote_connection("qemu+ssh://localhost/system")
        False
    """
    if not uri:
        return False
    parsed_uri = urlparse(uri)
    return (
        parsed_uri.hostname not in (None, "localhost", "127.0.0.1")
        and parsed_uri.scheme == "qemu+ssh"
    )


def check_r_viewer(configured_viewer: str = None) -> str:
    """
    Checks if r-viewer is installed.

    Args:
        configured_viewer (str, optional): The viewer configured by the user.
    Returns:
        str: return the viewer to use or None

    Raises:
        Exception: For unexpected errors during check
    """
    try:
        virtui = shutil.which("virtui-remote-viewer")
        virt = shutil.which("virt-viewer")
        if configured_viewer:
            if configured_viewer == "virtui-remote-viewer" and virtui:
                return "virtui-remote-viewer"
            if configured_viewer == "virt-viewer" and virt:
                return "virt-viewer"
            logging.warning(
                "Configured viewer %s not found. Falling back to auto-detection.", configured_viewer
            )

        if virtui is not None:
            return "virtui-remote-viewer"
        if virt is not None:
            return "virt-viewer"
    except Exception as e:
        logging.error("Unexpected error checking r-viewer: %s", e)

    logging.error("Neither 'virtui-remote-viewer' nor 'virt-viewer' is installed.")
    return None


def remote_viewer_cmd(uri: str, domain_name: str, viewer_cmd: str = None) -> list:
    """
    return the remote viewer command line
    """
    if viewer_cmd:
        check_which_one = viewer_cmd
    else:
        check_which_one = check_r_viewer()

    if check_which_one == "virt-viewer":
        command = [check_which_one, "--connect", uri, domain_name]
    else:
        command = [check_which_one, "--connect", uri, "--domain-name", domain_name]
    return command


def check_firewalld(remote_host: str = None) -> bool:
    """
    Checks if firewalld is installed.

    Args:
        remote_host (str, optional): SSH host string (user@host) for remote check.

    Returns:
        bool: True if firewalld is installed, False otherwise

    Raises:
        Exception: For unexpected errors during check
    """
    try:
        if remote_host:
            result = subprocess.run(
                ["ssh", remote_host, "which firewall-cmd"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            installed = result.returncode == 0
        else:
            installed = (
                shutil.which("firewall-cmd") is not None or shutil.which("firewalld") is not None
            )

        if not installed:
            logging.info(f"Firewall-cmd not found on {remote_host or 'local'}.")
        return installed
    except (OSError, AttributeError, subprocess.SubprocessError) as e:
        logging.error("Error checking firewalld: %s", e)
        return False


def check_novnc_path() -> bool:
    """
    Check if novnc is available.

    Returns:
        bool: True if novnc path exists, False otherwise

    Raises:
        Exception: For unexpected errors during check
    """
    try:
        return os.path.exists("/usr/share/novnc") or os.path.exists("/usr/share/webapps/novnc")
    except (OSError, AttributeError) as e:
        logging.error("Error checking novnc path: %s", e)
        return False


def check_websockify() -> bool:
    """
    Checks if websockify is installed.

    Returns:
        bool: True if websockify is installed, False otherwise

    Raises:
        Exception: For unexpected errors during check
    """
    try:
        return shutil.which("websockify") is not None
    except (OSError, AttributeError) as e:
        logging.error("Error checking websockify: %s", e)
        return False


def is_tmux_available() -> bool:
    """
    Checks if tmux command is available on the system.

    Returns:
        bool: True if tmux is installed, False otherwise
    """
    try:
        return shutil.which("tmux") is not None
    except (OSError, AttributeError) as e:
        logging.error("Error checking tmux availability: %s", e)
        return False


def is_inside_tmux() -> bool:
    """
    Checks if running inside a tmux session and tmux command is available.

    Returns:
        bool: True if inside tmux and tmux is installed, False otherwise
    """
    try:
        return os.environ.get("TMUX") is not None and is_tmux_available()
    except (OSError, AttributeError) as e:
        logging.error("Error checking tmux session: %s", e)
        return False


def check_is_firewalld_running(remote_host: str = None) -> Union[str, bool]:
    """
    Check if firewalld is running.

    Args:
        remote_host (str, optional): SSH host string (user@host) for remote check.

    Returns:
        str or bool: 'active' if running, 'inactive' if stopped, False if not installed or error

    Raises:
        Exception: For unexpected errors during check
    """
    if not check_firewalld(remote_host):
        return False

    try:
        cmd = ["systemctl", "is-active", "firewalld"]
        if remote_host:
            result = subprocess.run(
                ["ssh", remote_host, " ".join(cmd)],
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
        else:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False,
                timeout=10,
            )
        status = result.stdout.strip()
        logging.info(f"Firewalld status on {remote_host or 'local'}: {status}")
        return status
    except subprocess.TimeoutExpired:
        logging.warning(f"Timeout checking firewalld status on {remote_host or 'local'}")
        return False
    except Exception as e:
        logging.error("Error checking firewalld status: %s", e)
        return False


def run_command(
    cmd: List[str], remote_host: str = None, check: bool = True, timeout: int = 30
) -> subprocess.CompletedProcess:
    """
    Runs a command locally or remotely via SSH.

    Args:
        cmd: List of command arguments
        remote_host: Optional SSH host (user@host)
        check: If True, raises CalledProcessError if command fails
        timeout: Timeout in seconds

    Returns:
        subprocess.CompletedProcess
    """
    if remote_host:
        ssh_cmd = ["ssh", remote_host, " ".join(cmd)]
        logging.debug(f"Running remote command: {' '.join(ssh_cmd)}")
        return subprocess.run(
            ssh_cmd, capture_output=True, text=True, check=check, timeout=timeout
        )
    logging.debug(f"Running local command: {' '.join(cmd)}")
    return subprocess.run(cmd, capture_output=True, text=True, check=check, timeout=timeout)


def get_firewalld_zones(remote_host: str = None) -> List[str]:
    """
    Gets the list of available firewalld zones.

    Args:
        remote_host: Optional SSH host (user@host)

    Returns:
        List[str]: List of zone names
    """
    try:
        result = run_command(["firewall-cmd", "--get-zones"], remote_host=remote_host)
        zones = result.stdout.strip().split()
        logging.info(f"Available firewalld zones on {remote_host or 'local'}: {zones}")
        return zones
    except Exception as e:
        logging.error(f"Failed to get firewalld zones: {e}")
        return []


def get_firewalld_default_zone(remote_host: str = None) -> Optional[str]:
    """
    Gets the default firewalld zone.

    Args:
        remote_host: Optional SSH host (user@host)

    Returns:
        str: Default zone name or None if error
    """
    try:
        result = run_command(["firewall-cmd", "--get-default-zone"], remote_host=remote_host)
        zone = result.stdout.strip()
        logging.info(f"Default firewalld zone on {remote_host or 'local'}: {zone}")
        return zone
    except Exception as e:
        logging.error(f"Failed to get default firewalld zone: {e}")
        return None


def manage_firewalld_port(
    port: int, protocol: str = "tcp", action: str = "add", remote_host: str = None
) -> bool:
    """
    Adds or removes a port in firewalld, preferring 'libvirt' zone if it exists,
    otherwise falling back to the default zone.

    Args:
        port: Port number
        protocol: Protocol (tcp/udp)
        action: 'add' or 'remove'
        remote_host: Optional SSH host (user@host)

    Returns:
        bool: True if successful, False otherwise
    """
    status = check_is_firewalld_running(remote_host)
    if status != "active":
        logging.info(
            f"Firewalld is not active on {remote_host or 'local'} (status: {status}). Skipping port management."
        )
        return False

    zones = get_firewalld_zones(remote_host)
    if "libvirt" in zones:
        zone = "libvirt"
        logging.info(f"Found 'libvirt' zone on {remote_host or 'local'}. Using it.")
    else:
        zone = get_firewalld_default_zone(remote_host)
        if not zone:
            logging.warning(
                f"Could not determine default firewalld zone on {remote_host or 'local'}. Falling back to default."
            )
            zone = None

    if zone:
        zone_arg = [f"--zone={zone}"]
    else:
        zone_arg = []

    cmd = ["firewall-cmd"] + zone_arg + [f"--{action}-port={port}/{protocol}"]

    try:
        logging.info(f"Executing firewalld command on {remote_host or 'local'}: {' '.join(cmd)}")
        run_command(cmd, remote_host=remote_host)
        logging.info(
            f"Successfully {action}ed firewalld port {port}/{protocol} on {remote_host or 'local'} (zone: {zone or 'default'})"
        )
        return True
    except Exception as e:
        logging.error(f"Failed to {action} firewalld port {port} on {remote_host or 'local'}: {e}")
        return False


def get_ssh_host_from_uri(uri: str) -> Optional[str]:
    """
    Extracts the SSH host (user@host) from a libvirt URI.
    """
    if not uri or not uri.startswith("qemu+ssh://"):
        return None
    try:
        parsed_uri = urlparse(uri)
        return parsed_uri.netloc
    except Exception:
        return None


@lru_cache(maxsize=16)
def extract_server_name_from_uri(server_name: str) -> str:
    """
    Extract server name from URI for display.

    Args:
        server_name (str): The connection URI

    Returns:
        str: Extracted server name for display

    Raises:
        TypeError: If server_name is not a string
    """
    # Input validation
    if not isinstance(server_name, str):
        raise TypeError("server_name must be a string")

    if not server_name:
        return "Unknown"

    if server_name == "qemu:///system":
        return "Local"

    try:
        parsed_uri = urlparse(server_name)
        # netloc contains user:pass@host:port
        netloc = parsed_uri.netloc
        if not netloc:
            # Fallback for simple names without a scheme
            return server_name

        # Strip user info if it exists
        if "@" in netloc:
            netloc = netloc.split("@", 1)[1]

        # Strip port if it exists
        if ":" in netloc:
            netloc = netloc.split(":", 1)[0]

        return netloc if netloc else "Unknown"

    except Exception:
        # Fallback to original logic if parsing fails for any reason
        if server_name.startswith("qemu+ssh://"):
            if "@" in server_name:
                server_display = server_name.split("@")[1].split("/")[0]
            else:
                server_display = server_name.split("://")[1].split("/")[0]
        elif server_name.startswith("qemu+tcp://") or server_name.startswith("qemu+tls://"):
            server_display = server_name.split("://")[1].split("/")[0]
        else:
            server_display = server_name

        return server_display if server_display else "Unknown"


@lru_cache(maxsize=512)
def natural_sort_key(text):
    """
    Convert a string into a list for natural sorting.
    'A10' becomes ['A', 10], 'A2' becomes ['A', 2]
    This ensures A2 comes before A10.
    """

    def tryint(s):
        try:
            return int(s)
        except ValueError:
            return s.lower()

    return [tryint(c) for c in re.split("([0-9]+)", text)]


@lru_cache(maxsize=8)
def format_server_names(server_uris: tuple[str]) -> str:
    """
    Format server URIs into display names.
    Takes tuple (immutable) for caching.
    """
    names = [extract_server_name_from_uri(uri) for uri in server_uris]
    return ", ".join(sorted(set(names)))


_server_color_cache = {}
# Global variable for color indexing - used across module
_COLOR_INDEX = 0


@lru_cache(maxsize=16)
def get_server_color_cached(uri: str, palette: tuple) -> str:
    """
    Get consistent color for a server URI.
    Uses global cache to avoid instance issues.
    """
    global _COLOR_INDEX

    if uri not in _server_color_cache:
        color = palette[_COLOR_INDEX % len(palette)]
        _server_color_cache[uri] = color
        _COLOR_INDEX += 1

    return _server_color_cache[uri]


class CacheMonitor:
    """Monitor for tracking LRU cache performance."""

    def __init__(self):
        self.tracked_functions = {}

    def track(self, func: Callable) -> None:
        """Register a function for monitoring."""
        self.tracked_functions[func.__name__] = func

    def get_all_stats(self) -> dict[str, dict]:
        """Get statistics for all tracked caches."""
        stats = {}
        for name, func in self.tracked_functions.items():
            if hasattr(func, "cache_info"):
                info = func.cache_info()
                total = info.hits + info.misses
                hit_rate = (info.hits / total * 100) if total > 0 else 0.0

                stats[name] = {
                    "hits": info.hits,
                    "misses": info.misses,
                    "hit_rate": hit_rate,
                    "current_size": info.currsize,
                    "max_size": info.maxsize,
                    "efficiency": "good" if hit_rate > 70 else "poor",
                }
        return stats

    def log_stats(self) -> None:
        """Log cache statistics."""
        stats = self.get_all_stats()
        logging.info("=== Cache Statistics ===")
        for name, data in stats.items():
            logging.info(
                "%s: %.1f%% hit rate (%d hits, %d misses, %d/%d entries)",
                name,
                data["hit_rate"],
                data["hits"],
                data["misses"],
                data["current_size"],
                data["max_size"],
            )

    def clear_all_caches(self) -> None:
        """Clear all tracked caches."""
        for func in self.tracked_functions.values():
            if hasattr(func, "cache_clear"):
                func.cache_clear()
        logging.info("All caches cleared")


@lru_cache(maxsize=128)
def format_memory_display(memory_mib: int) -> str:
    """Format memory with MiB/GiB conversion."""
    mem_str = f"{memory_mib} MiB"
    if memory_mib >= 1024:
        mem_str += f" ({memory_mib / 1024:.2f} GiB)"
    return mem_str


@lru_cache(maxsize=128)
# pylint: disable=too-many-arguments,too-many-positional-arguments
def generate_tooltip_markdown(
    uuid: str,
    hypervisor: str,
    status: str,
    ip: str,
    boot: str,
    cpu: int,
    cpu_model: str,
    memory: int,
) -> str:
    """Generate tooltip markdown (pure function, cacheable)."""
    mem_display = format_memory_display(memory)
    cpu_display = f"{cpu} {cpu_model}" if cpu_model else str(cpu)

    return (
        f"`{uuid}`  \n"
        f"**Hypervisor:** {hypervisor}  \n"
        f"**Status:** {status}  \n"
        f"**IP:** {ip}  \n"
        f"**Boot:** {boot}  \n"
        f"**VCPUs:** {cpu_display}  \n"
        f"**Memory:** {mem_display}"
    )


def setup_cache_monitoring(enable: bool = True):  # pylint: disable=too-many-locals
    """Initialize or clear the cache monitor and track relevant functions."""
    cache_monitor = CacheMonitor()
    cache_monitor.tracked_functions.clear()
    if not enable:
        logging.debug("Cache monitoring disabled.")
        return None

    logging.debug("Cache monitoring enabled.")
    cache_monitor.track(format_server_names)
    cache_monitor.track(extract_server_name_from_uri)
    cache_monitor.track(get_server_color_cached)
    cache_monitor.track(natural_sort_key)
    cache_monitor.track(format_memory_display)
    cache_monitor.track(generate_tooltip_markdown)

    from .libvirt_utils import (
        _get_vm_names_from_uuids,
        get_domain_capabilities_xml,
        get_host_pci_devices,
        get_host_usb_devices,
    )

    cache_monitor.track(_get_vm_names_from_uuids)
    cache_monitor.track(get_host_pci_devices)
    cache_monitor.track(get_host_usb_devices)
    cache_monitor.track(get_domain_capabilities_xml)

    from .vm_queries import (
        _parse_domain_xml,
        get_all_vm_disk_usage,
        get_boot_info,
        get_supported_machine_types,
        get_vm_description,
        get_vm_disks,
        get_vm_disks_info,
        get_vm_network_dns_gateway_info,
    )

    cache_monitor.track(_parse_domain_xml)
    cache_monitor.track(get_vm_description)
    cache_monitor.track(get_vm_disks_info)
    cache_monitor.track(get_vm_network_dns_gateway_info)
    cache_monitor.track(get_vm_disks)
    cache_monitor.track(get_boot_info)
    cache_monitor.track(get_all_vm_disk_usage)
    cache_monitor.track(get_supported_machine_types)

    from .storage_manager import (
        find_vms_using_volume,
        get_all_storage_volumes,
        list_storage_pools,
        list_storage_volumes,
    )

    cache_monitor.track(list_storage_pools)
    cache_monitor.track(list_storage_volumes)
    cache_monitor.track(find_vms_using_volume)
    cache_monitor.track(get_all_storage_volumes)

    from .network_manager import (
        get_host_network_info,
        get_vms_using_network,
        list_networks,
    )

    cache_monitor.track(list_networks)
    cache_monitor.track(get_vms_using_network)
    cache_monitor.track(get_host_network_info)

    return cache_monitor


def setup_logging():
    """Configures the logging for the application.

    Sets up file-based logging with a sanitizing filter that redacts
    sensitive information (like credentials in URIs) from log messages.
    """
    from .config import get_log_path, load_config

    config = load_config()
    log_level_str = config.get("LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_str, logging.INFO)
    log_path = get_log_path()

    # Ensure directory exists
    log_path.parent.mkdir(parents=True, exist_ok=True)
    root_logger = logging.getLogger()

    for handler in root_logger.handlers[:]:
        if isinstance(handler, logging.StreamHandler) and not isinstance(
            handler, logging.FileHandler
        ):
            root_logger.removeHandler(handler)

    # Check if we already added a FileHandler to this path
    has_file_handler = False
    for handler in root_logger.handlers:
        if isinstance(handler, logging.FileHandler) and handler.baseFilename == str(
            log_path.absolute()
        ):
            has_file_handler = True
            break

    if not has_file_handler:
        file_handler = logging.FileHandler(log_path)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        # Add sanitizing filter to prevent clear-text logging of sensitive information
        file_handler.addFilter(SanitizingFilter())
        root_logger.addHandler(file_handler)

    root_logger.setLevel(log_level)

    if not has_file_handler:
        logging.info("--- Logging initialized ---")

    setup_cache_monitoring(enable=False)


def get_virt_install_version() -> str | None:
    """
    Checks if virt-install is available on the system and returns its version.
    Returns None if virt-install is not found or its version cannot be determined.
    """
    if shutil.which("virt-install") is None:
        return None
    try:
        result = subprocess.run(
            ["virt-install", "--version"], check=True, capture_output=True, text=True
        )
        return result.stdout.strip()
    except Exception as e:
        logging.warning(f"Could not determine virt-install version: {e}")
        return None
