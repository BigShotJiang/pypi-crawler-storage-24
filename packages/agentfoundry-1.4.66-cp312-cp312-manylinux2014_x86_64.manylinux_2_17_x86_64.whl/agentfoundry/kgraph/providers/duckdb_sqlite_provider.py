from agentfoundry.kgraph.factory import KGraphFactory
from agentfoundry.kgraph.providers.duckdb_sqlite.duck_graph import DuckSqliteGraph


if KGraphFactory.get_provider_cls("duckdb_sqlite") is None:
    KGraphFactory.register_provider("duckdb_sqlite")(DuckSqliteGraph)
