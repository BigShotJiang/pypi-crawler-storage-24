"""Knowledge-graph provider modules self-register with KGraphFactory."""

