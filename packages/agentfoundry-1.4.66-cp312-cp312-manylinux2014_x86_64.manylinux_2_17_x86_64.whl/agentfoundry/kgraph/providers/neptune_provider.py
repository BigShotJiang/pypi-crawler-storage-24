from agentfoundry.kgraph.factory import KGraphFactory
from agentfoundry.kgraph.providers.neptune_graph import NeptuneGraph


if KGraphFactory.get_provider_cls("neptune") is None:
    KGraphFactory.register_provider("neptune")(NeptuneGraph)
