# agentfoundry/optimizers/prompt_optimizer.py

__author__ = "Claude Code"
__copyright__ = "Copyright 2026"
__date__ = "2026-02-26"
__license__ = "MIT"
__version__ = "1.0"
__status__ = "Prototype"

import logging
import json
import os
import uuid
from typing import Optional

from agentfoundry.llm.llm_factory import LLMFactory
from agentfoundry.utils.config import Config

logger = logging.getLogger(__name__)

class PromptOptimizer:
    """
    Class for adaptively optimizing prompts based on task feedback.
    """

    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.meta_llm = LLMFactory.get_llm_model(config=self.config)  # Use default LLM for optimization

    def optimize_prompt(self, original_prompt: str, feedback: str, task_description: str) -> str:
        """
        Refine the original prompt using feedback from a failed task.

        Args:
            original_prompt: The original prompt used.
            feedback: Feedback or error message from the task execution.
            task_description: Description of the task.

        Returns:
            Refined prompt string.
        """
        meta_prompt = (
            f"Original prompt: {original_prompt}\n"
            f"Task: {task_description}\n"
            f"Feedback/Error: {feedback}\n\n"
            "Refine the original prompt to address the feedback and improve performance. "
            "Keep the structure similar but adjust to avoid the error. Return only the refined prompt."
        )
        try:
            result = self.meta_llm.generate(meta_prompt)
            refined = result.generations[0][0].text.strip()
            logger.info(f"Prompt optimized: {refined[:100]}...")

            # Log to prompt_history.json
            history_file = os.path.join(os.path.dirname(__file__), 'prompt_history.json')
            history_entry = {
                'original_prompt': original_prompt,
                'refined_prompt': refined,
                'task_id': str(uuid.uuid4()),
                'success_rate': 0.0  # Placeholder, update based on future metrics
            }
            with open(history_file, 'a') as f:
                json.dump(history_entry, f)
                f.write('\n')

            return refined
        except Exception as e:
            logger.error(f"Error optimizing prompt: {e}")
            return original_prompt  # Fallback to original on error