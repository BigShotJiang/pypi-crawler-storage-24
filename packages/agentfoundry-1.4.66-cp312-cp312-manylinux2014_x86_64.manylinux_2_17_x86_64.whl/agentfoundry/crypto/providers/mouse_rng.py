"""Terminal-native mouse entropy collection."""

import time
import os
import sys
import tty
import termios
import logging
from tqdm import tqdm

logger = logging.getLogger(__name__)

def collect_mouse_entropy(max_samples=500) -> bytes:
    """Collects entropy by having the user move the mouse in the terminal."""
    logger.info("Starting mouse entropy collection (max_samples=%d).", max_samples)
    mouse_data = []
    
    print("--- MOUSE ENTROPY GENERATOR ---")
    print("Move your mouse randomly (circles, zig-zags) inside this window.")
    
    pbar = tqdm(total=max_samples, desc="Collecting mouse entropy", unit="samples")
    
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    
    try:
        logger.debug("Setting terminal to cbreak mode for mouse event capture.")
        tty.setcbreak(fd)
        sys.stdout.write('\x1b[?1003h\x1b[?1006h')
        sys.stdout.flush()
        
        while len(mouse_data) < max_samples:
            ch = sys.stdin.read(1)
            if ch == '\x1b':
                seq = sys.stdin.read(2)
                if seq == '[<':
                    report = ''
                    while True:
                        c = sys.stdin.read(1)
                        report += c
                        if c in ('M', 'm'):
                            break
                    
                    timestamp = time.time_ns()
                    mouse_data.append(f"{report}{timestamp}")
                    pbar.update(1)
            elif ch == '\x03':
                logger.warning("Mouse entropy collection interrupted by user (KeyboardInterrupt).")
                raise KeyboardInterrupt
    finally:
        logger.debug("Restoring terminal settings.")
        sys.stdout.write('\x1b[?1003l\x1b[?1006l')
        sys.stdout.flush()
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        pbar.close()
        
    logger.info("Successfully collected %d samples of mouse entropy.", len(mouse_data))
    return "".join(mouse_data).encode()
