"""Kyber PQC Provider implementation using pqcrypto and PyCryptodome.

Uses the pqcrypto library (CFFI bindings to PQClean) for ML-KEM-768
key encapsulation and ML-DSA-65 digital signatures, combined with
AES-256-GCM symmetric encryption from PyCryptodome.
"""

import struct
import hashlib
import logging
from typing import Tuple

from agentfoundry.crypto.base import PQCProvider
from agentfoundry.crypto.factory import PQCFactory
from agentfoundry.crypto.providers.mouse_rng import collect_mouse_entropy

logger = logging.getLogger(__name__)

_PQCRYPTO_ERROR_MESSAGE = (
    "pqcrypto and pycryptodome are required for KyberProvider. "
    "Install with 'pip install pqcrypto pycryptodome'."
)

try:
    from pqcrypto.kem.ml_kem_768 import (
        generate_keypair as kem_generate_keypair,
        encrypt as kem_encapsulate,
        decrypt as kem_decapsulate,
    )
    from pqcrypto.sign.ml_dsa_65 import (
        generate_keypair as sig_generate_keypair,
        sign as sig_sign,
        verify as sig_verify,
    )
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes

    HAS_PQCRYPTO = True
    PQCRYPTO_IMPORT_ERROR = None
    logger.debug("Successfully imported pqcrypto (ML-KEM-768, ML-DSA-65) and PyCryptodome.")
except ImportError as e:
    HAS_PQCRYPTO = False
    PQCRYPTO_IMPORT_ERROR = e
    logger.warning("Failed to import pqcrypto or PyCryptodome: %s", e)

KEM_ALG = "ML-KEM-768"
SIG_ALG = "ML-DSA-65"


@PQCFactory.register_provider("kyber")
class KyberProvider(PQCProvider):
    def __init__(self, use_mouse_entropy=False):
        logger.info("Initializing KyberProvider (use_mouse_entropy=%s)", use_mouse_entropy)
        if not HAS_PQCRYPTO:
            logger.error(
                "Required PQC runtime dependencies are unavailable: %s",
                PQCRYPTO_IMPORT_ERROR,
            )
            if PQCRYPTO_IMPORT_ERROR:
                raise RuntimeError(
                    f"{_PQCRYPTO_ERROR_MESSAGE} {PQCRYPTO_IMPORT_ERROR}"
                ) from PQCRYPTO_IMPORT_ERROR
            raise RuntimeError(_PQCRYPTO_ERROR_MESSAGE)
        self.use_mouse_entropy = use_mouse_entropy
        logger.info("KyberProvider initialized successfully (KEM=%s, SIG=%s).", KEM_ALG, SIG_ALG)

    def _get_entropy(self) -> bytes:
        logger.debug("Generating entropy...")
        if self.use_mouse_entropy:
            logger.info("Collecting mouse entropy to mix with system entropy.")
            mouse_ent = collect_mouse_entropy()
            sys_ent = get_random_bytes(32)
            mixed = hashlib.sha256(mouse_ent + sys_ent).digest()
            logger.debug("Successfully generated mixed entropy (%d bytes).", len(mixed))
            return mixed
        logger.debug("Using standard system entropy.")
        return get_random_bytes(32)

    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """Generates ML-KEM-768 public and private keys."""
        logger.info("Generating %s keypair for KEM...", KEM_ALG)
        if self.use_mouse_entropy:
            self._get_entropy()

        try:
            public_key, secret_key = kem_generate_keypair()
            logger.info(
                "Successfully generated %s keypair (public_key=%d bytes, secret_key=%d bytes).",
                KEM_ALG, len(public_key), len(secret_key),
            )
            return public_key, secret_key
        except Exception:
            logger.exception("Failed to generate %s keypair.", KEM_ALG)
            raise

    def generate_signing_keypair(self) -> Tuple[bytes, bytes]:
        """Generates ML-DSA-65 public and private keys."""
        logger.info("Generating %s keypair for signatures...", SIG_ALG)
        if self.use_mouse_entropy:
            self._get_entropy()

        try:
            public_key, secret_key = sig_generate_keypair()
            logger.info(
                "Successfully generated %s signing keypair (public_key=%d bytes, secret_key=%d bytes).",
                SIG_ALG, len(public_key), len(secret_key),
            )
            return public_key, secret_key
        except Exception:
            logger.exception("Failed to generate %s signing keypair.", SIG_ALG)
            raise

    def encrypt(self, data: bytes, public_key: bytes) -> bytes:
        """
        Encrypts data using ML-KEM-768 KEM and AES-256-GCM.
        Returns: [4 bytes kem_ct_len] + [kem_ct] + [12 bytes nonce] + [16 bytes tag] + [aes_ct]
        """
        logger.info("Encrypting data (%d bytes) using %s + AES-256-GCM...", len(data), KEM_ALG)

        try:
            logger.debug("Encapsulating shared secret with %s...", KEM_ALG)
            kem_ciphertext, shared_secret = kem_encapsulate(public_key)
            logger.debug(
                "KEM encapsulation complete (ciphertext=%d bytes, shared_secret=%d bytes).",
                len(kem_ciphertext), len(shared_secret),
            )
        except Exception:
            logger.exception("KEM encapsulation failed during encryption.")
            raise

        try:
            logger.debug("Performing AES-256-GCM encryption with encapsulated secret...")
            aes_key = hashlib.sha256(shared_secret).digest()
            nonce = get_random_bytes(12)
            cipher = AES.new(aes_key, AES.MODE_GCM, nonce=nonce)
            encrypted_data, auth_tag = cipher.encrypt_and_digest(data)
            logger.debug(
                "AES-256-GCM encryption complete (nonce=%d bytes, tag=%d bytes, ciphertext=%d bytes).",
                len(nonce), len(auth_tag), len(encrypted_data),
            )
        except Exception:
            logger.exception("AES-256-GCM encryption failed.")
            raise

        kem_ct_len = len(kem_ciphertext)
        packed_data = struct.pack(">I", kem_ct_len) + kem_ciphertext + nonce + auth_tag + encrypted_data
        logger.info("Successfully encrypted data (payload size: %d bytes).", len(packed_data))
        return packed_data

    def decrypt(self, encrypted_data: bytes, private_key: bytes) -> bytes:
        """
        Decrypts data packed by encrypt().
        """
        logger.info("Decrypting data (%d bytes) using %s + AES-256-GCM...", len(encrypted_data), KEM_ALG)

        try:
            kem_ct_len = struct.unpack(">I", encrypted_data[:4])[0]
            offset = 4
            logger.debug("KEM ciphertext length from header: %d bytes.", kem_ct_len)

            kem_ciphertext = encrypted_data[offset:offset + kem_ct_len]
            offset += kem_ct_len

            nonce = encrypted_data[offset:offset + 12]
            offset += 12

            auth_tag = encrypted_data[offset:offset + 16]
            offset += 16

            aes_ct = encrypted_data[offset:]
            logger.debug(
                "Unpacked envelope: kem_ct=%d bytes, nonce=%d bytes, tag=%d bytes, aes_ct=%d bytes.",
                len(kem_ciphertext), len(nonce), len(auth_tag), len(aes_ct),
            )
        except Exception:
            logger.exception("Failed to unpack encrypted data envelope.")
            raise

        try:
            logger.debug("Decapsulating shared secret with %s...", KEM_ALG)
            shared_secret = kem_decapsulate(private_key, kem_ciphertext)
            logger.debug("KEM decapsulation complete (shared_secret=%d bytes).", len(shared_secret))
        except Exception:
            logger.exception("KEM decapsulation failed during decryption.")
            raise

        try:
            logger.debug("Performing AES-256-GCM decryption...")
            aes_key = hashlib.sha256(shared_secret).digest()
            cipher = AES.new(aes_key, AES.MODE_GCM, nonce=nonce)
            decrypted_data = cipher.decrypt_and_verify(aes_ct, auth_tag)
            logger.info("Successfully decrypted data (%d bytes).", len(decrypted_data))
            return decrypted_data
        except Exception:
            logger.exception("AES-256-GCM decryption/verification failed (data may be tampered or wrong key).")
            raise

    def sign(self, data: bytes, private_key: bytes) -> bytes:
        """Signs data using ML-DSA-65."""
        logger.info("Signing data (%d bytes) using %s...", len(data), SIG_ALG)
        try:
            signature = sig_sign(private_key, data)
            logger.info("Successfully signed data (signature=%d bytes).", len(signature))
            return signature
        except Exception:
            logger.exception("Signing with %s failed.", SIG_ALG)
            raise

    def verify(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """Verifies an ML-DSA-65 signature."""
        logger.info("Verifying %s signature (%d bytes) against data (%d bytes)...",
                     SIG_ALG, len(signature), len(data))
        try:
            is_valid = sig_verify(public_key, data, signature)
            if is_valid:
                logger.info("Signature verification passed.")
            else:
                logger.warning("Signature verification FAILED — data or signature may have been tampered with.")
            return is_valid
        except Exception:
            logger.exception("Signature verification raised an exception.")
            raise
