"""PQCFactory – central point to obtain Post-Quantum Cryptography providers."""

import inspect
import logging
import threading

logger = logging.getLogger(__name__)


class PQCFactory:
    """Return a PQCProvider instance from the configured provider name."""

    _REGISTRY: dict[str, type] = {}
    _CACHE: dict[str, object] = {}
    _LOCK = threading.Lock()

    @classmethod
    def register_provider(cls, name: str):
        """Decorator to register a provider class under the given name."""

        def decorator(provider_cls):
            if not isinstance(provider_cls, type):
                raise TypeError(f"Expected a class (type), got {type(provider_cls).__name__}")

            if inspect.isabstract(provider_cls):
                logger.warning("Skipping registration of abstract provider class: %s", provider_cls.__name__)
                return provider_cls

            lower = name.lower()
            if lower in cls._REGISTRY:
                logger.warning("Provider '%s' already registered; skipping duplicate", name)
                return provider_cls
            cls._REGISTRY[lower] = provider_cls
            logger.debug("Registered PQC provider '%s' -> %s", lower, provider_cls)
            return provider_cls

        return decorator

    @classmethod
    def get_provider_cls(cls, name: str):
        return cls._REGISTRY.get(name.lower())

    @classmethod
    def _lazy_import_provider(cls, name: str) -> None:
        from importlib import import_module as _import_module
        mod_name = f"agentfoundry.crypto.providers.{name.lower()}_provider"
        try:
            _import_module(mod_name)
            logger.info(f"Lazy-imported PQC provider module '{mod_name}'")
        except ModuleNotFoundError as _err:
            logger.warning(f"PQC provider module '{mod_name}' not found: {_err}")
        except Exception as _err:
            logger.warning(f"PQC provider module '{mod_name}' failed to import: {_err}", exc_info=True)

    @classmethod
    def available_providers(cls):
        return list(cls._REGISTRY.keys())

    @classmethod
    def get_provider(cls, provider: str = "kyber", **kwargs):
        """Instantiate and return a PQCProvider instance."""
        provider_name = provider.lower()
        
        provider_cls = cls.get_provider_cls(provider_name)
        if provider_cls is None:
            logger.debug(f"PQCFactory: provider={provider_name} not found; trying lazy import")
            cls._lazy_import_provider(provider_name)
            provider_cls = cls.get_provider_cls(provider_name)
            
        if provider_cls is None:
            raise ValueError(f"Unknown PQC provider '{provider_name}'. Available providers: {cls.available_providers()}")

        cache_key = provider_name
        if kwargs:
            try:
                suffix = ",".join(f"{k}={kwargs[k]}" for k in sorted(kwargs))
                cache_key = f"{provider_name}|{suffix}"
            except Exception:
                logger.debug("PQCFactory: failed to build cache key from kwargs", exc_info=True)

        if cache_key not in cls._CACHE:
            with cls._LOCK:
                if cache_key not in cls._CACHE:
                    cls._CACHE[cache_key] = provider_cls(**kwargs)

        return cls._CACHE[cache_key]

# Auto-import default providers
from importlib import import_module as _import_module
for _mod in ("agentfoundry.crypto.providers.kyber_provider",):
    try:
        _import_module(_mod)
    except ModuleNotFoundError:
        pass
    except Exception as _err:
        logger.warning(f"Optional PQC provider '{_mod}' failed to import: {_err}", exc_info=True)
