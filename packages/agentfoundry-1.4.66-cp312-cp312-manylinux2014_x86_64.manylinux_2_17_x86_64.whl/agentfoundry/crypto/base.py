"""Base interfaces for Post-Quantum Cryptography providers."""

import abc
from typing import Tuple

class PQCProvider(abc.ABC):
    """Abstract base class for PQC (Post-Quantum Cryptography) providers."""
    
    @abc.abstractmethod
    def generate_keypair(self) -> Tuple[bytes, bytes]:
        """
        Generate a new public and private keypair for KEM.
        
        Returns:
            Tuple[bytes, bytes]: A tuple containing the (public_key, private_key) as bytes.
        """
        pass

    @abc.abstractmethod
    def encrypt(self, data: bytes, public_key: bytes) -> bytes:
        """
        Encrypt data using KEM encapsulation for the given public key.
        
        Args:
            data (bytes): The plaintext data to encrypt.
            public_key (bytes): The recipient's public key.
            
        Returns:
            bytes: The encrypted payload (KEM ciphertext + symmetric encrypted data).
        """
        pass

    @abc.abstractmethod
    def decrypt(self, encrypted_data: bytes, private_key: bytes) -> bytes:
        """
        Decrypt data using KEM decapsulation with the given private key.
        
        Args:
            encrypted_data (bytes): The encrypted payload.
            private_key (bytes): The recipient's private key.
            
        Returns:
            bytes: The decrypted plaintext data.
        """
        pass

    @abc.abstractmethod
    def generate_signing_keypair(self) -> Tuple[bytes, bytes]:
        """
        Generate a new public and private keypair for Signatures.
        """
        pass

    @abc.abstractmethod
    def sign(self, data: bytes, private_key: bytes) -> bytes:
        """
        Sign data using the given private key.
        
        Args:
            data (bytes): The data to sign.
            private_key (bytes): The signer's private key.
            
        Returns:
            bytes: The signature.
        """
        pass

    @abc.abstractmethod
    def verify(self, data: bytes, signature: bytes, public_key: bytes) -> bool:
        """
        Verify a signature for the given data using the public key.
        
        Args:
            data (bytes): The signed data.
            signature (bytes): The signature to verify.
            public_key (bytes): The signer's public key.
            
        Returns:
            bool: True if the signature is valid, False otherwise.
        """
        pass
