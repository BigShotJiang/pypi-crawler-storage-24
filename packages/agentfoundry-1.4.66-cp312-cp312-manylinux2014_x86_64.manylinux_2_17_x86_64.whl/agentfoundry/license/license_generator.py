import sys
import uuid
import platform
import json
import base64
import os
from datetime import datetime, timedelta
from cryptography.fernet import Fernet

from agentfoundry.crypto.factory import PQCFactory

# Bundled wheels no longer carry the signing private key.
PRIVATE_KEY_ENV = "AGENTFOUNDRY_PRIVATE_KEY"


def get_machine_id():
    return str(uuid.getnode()) + platform.node()


def sign_license(machine_id: str, expires: str, private_key_path: str, client_pubkey_path: str, output_path: str):
    provider = PQCFactory.get_provider("kyber")

    # Generate decryption key for .so files (we generate 32 random bytes)
    decryption_key = os.urandom(32)

    # Encrypt the decryption key using the client's Kyber public key
    with open(client_pubkey_path, "rb") as f:
        client_pubkey = f.read()

    encrypted_decryption_key = provider.encrypt(decryption_key, client_pubkey)

    # Create license content
    content = {
        "machine_id": machine_id,
        "expiry": expires,
        "decryption_key": base64.b64encode(encrypted_decryption_key).decode()
    }

    # Serialize content to JSON for signing
    content_str = json.dumps(content, sort_keys=True).encode()

    # Load vendor private key (Dilithium)
    with open(private_key_path, 'rb') as f:
        private_key = f.read()

    # Sign content with Dilithium
    signature = provider.sign(content_str, private_key)

    # Create JSON license file
    license_data = {
        "content": content,
        "signature": base64.b64encode(signature).decode()
    }

    with open(output_path, "w") as f:
        json.dump(license_data, f, indent=4)


def generate_vendor_keypair(private_path="private.pem", public_path="agentfoundry.pem"):
    provider = PQCFactory.get_provider("kyber")
    public_key, private_key = provider.generate_signing_keypair()

    with open(private_path, "wb") as f:
        f.write(private_key)
    with open(public_path, "wb") as f:
        f.write(public_key)
        
    print(f"✅  Wrote vendor private key → {private_path}")
    print(f"✅  Wrote vendor public key → {public_path}")
    return private_path, public_path

def generate_client_keypair(private_path="client_private.pem", public_path="client_public.pem"):
    provider = PQCFactory.get_provider("kyber")
    public_key, private_key = provider.generate_keypair()

    with open(private_path, "wb") as f:
        f.write(private_key)
    with open(public_path, "wb") as f:
        f.write(public_key)

    print(f"✅  Wrote client private key → {private_path}")
    print(f"✅  Wrote client public key → {public_path}")
    return private_path, public_path

def validate_license(license_file: str = None, public_key_file: str = None, client_private_key_file: str = None):
    provider = PQCFactory.get_provider("kyber")

    license_file = license_file or os.path.join(os.path.dirname(__file__), '..', 'agentfoundry.lic')
    public_key_file = public_key_file or os.path.join(os.path.dirname(__file__), '..', 'agentfoundry.pem')
    
    if not os.path.exists(license_file) or not os.path.exists(public_key_file):
        print(f"License or key file not found: {license_file}, {public_key_file}")
        sys.exit(1)
        
    with open(license_file, 'r') as f:
        lic = json.load(f)
        
    content = lic.get('content') or {}
    sig = lic.get('signature')
    
    if not content or not sig:
        print(f"Invalid license format in {license_file}")
        sys.exit(1)
        
    signature = base64.b64decode(sig)
    with open(public_key_file, 'rb') as f:
        pub = f.read()

    try:
        is_valid = provider.verify(json.dumps(content, sort_keys=True).encode(), signature, pub)
        if not is_valid:
            raise Exception("Invalid signature")
    except Exception as e:
        print(f"Invalid license signature: {e}")
        sys.exit(1)

    expiry = content.get('expiry')
    try:
        exp_date = datetime.strptime(expiry, '%Y-%m-%d').date()
    except Exception:
        print(f"Invalid expiry date in license: {expiry}")
        sys.exit(1)
        
    print(f"License expiration date: {expiry}")
    if datetime.today().date() > exp_date:
        print("License has expired.")
        sys.exit(1)

    print("License signature and expiry are valid.")

    if client_private_key_file and os.path.exists(client_private_key_file):
        with open(client_private_key_file, "rb") as f:
            client_priv = f.read()
        encrypted_key = base64.b64decode(content.get("decryption_key"))
        try:
            decrypted_key = provider.decrypt(encrypted_key, client_priv)
            print("Successfully decrypted the decryption key.")
        except Exception as e:
            print(f"Failed to decrypt decryption key: {e}")
            sys.exit(1)
            
    print("License is valid.")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate or validate a signed license file for AgentFoundry using PQC.")
    parser.add_argument("--validate", action="store_true", help="Validate an existing license and print its expiration date")
    parser.add_argument("--license-file", default=None, help="Path to license file for validation")
    parser.add_argument("--public-key", default=None, help="Path to vendor public key file for validation")
    parser.add_argument("--client-private-key", default=None, help="Path to client private key for decrypting the license payload")
    
    parser.add_argument("--expires", help="Expiration date in YYYY-MM-DD format (default: 90 days from now)")
    parser.add_argument("--days", type=int, help="Number of days the license is valid (e.g. 30). Takes precedence over --expires.")
    
    parser.add_argument("--private-key", default=None, help="Path to the vendor private key used for signing")
    parser.add_argument("--client-public-key", default=None, help="Path to the client's public key for encryption")
    parser.add_argument("--output", default="agentfoundry.lic", help="Path to output license file")
    
    parser.add_argument("--gen-keys", action="store_true", help="Generate a new vendor keypair (Dilithium)")
    parser.add_argument("--gen-client-keys", action="store_true", help="Generate a new client keypair (Kyber)")
    
    parser.add_argument("--unbound", action="store_true", help="Generate a license valid on any machine (machine_id='*')")
    parser.add_argument("--machine-id", default=None, help="Override machine id instead of using the current host id")

    parser.add_argument("--vendor-public-key", default="agentfoundry/agentfoundry.pem", help="Path to write the generated vendor public key")

    args = parser.parse_args()
    
    if args.validate:
        validate_license(args.license_file, args.public_key, args.client_private_key)
        sys.exit(0)

    if args.gen_client_keys:
        generate_client_keypair()
        # If we only want to generate client keys, we can stop here unless we also want to sign.
        # But usually we generate them together in the build script.

    resolved_private_key = args.private_key or os.getenv(PRIVATE_KEY_ENV)

    if args.gen_keys:
        target_private = resolved_private_key or "private.pem"
        generate_vendor_keypair(private_path=target_private, public_path=args.vendor_public_key)
        resolved_private_key = target_private
        if not args.client_public_key:
            # If generating keys but not signing, we can exit.
            # Except if gen_client_keys was also true, we might want to continue if we use default names.
            if not os.path.exists("client_public.pem"):
                sys.exit(0)
            args.client_public_key = "client_public.pem"

    if args.days is not None:
        if args.days <= 0:
            print("❌ --days must be a positive integer.")
            sys.exit(1)
        expiration = (datetime.today() + timedelta(days=args.days)).strftime("%Y-%m-%d")
    elif args.expires:
        try:
            expiration = datetime.strptime(args.expires, "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            print("❌ Invalid --expires format. Use YYYY-MM-DD.")
            sys.exit(1)
    else:
        expiration = (datetime.today() + timedelta(days=90)).strftime("%Y-%m-%d")

    if not resolved_private_key:
        parser.error("No vendor private key provided. Use --private-key or set the %s environment variable." % PRIVATE_KEY_ENV)

    if not args.client_public_key:
        parser.error("No client public key provided for encrypting the license. Use --client-public-key.")

    if not os.path.exists(resolved_private_key):
        parser.error(f"Vendor private key not found at {resolved_private_key}.")
        
    if not os.path.exists(args.client_public_key):
        parser.error(f"Client public key not found at {args.client_public_key}.")

    machine_id = get_machine_id()
    if args.unbound:
        machine_id = "*"
    if args.machine_id:
        machine_id = args.machine_id
        
    sign_license(machine_id, expiration, resolved_private_key, args.client_public_key, args.output)
    scope = "any machine" if machine_id == "*" else machine_id
    print(f"✅ License generated for {scope}, expires {expiration}")
