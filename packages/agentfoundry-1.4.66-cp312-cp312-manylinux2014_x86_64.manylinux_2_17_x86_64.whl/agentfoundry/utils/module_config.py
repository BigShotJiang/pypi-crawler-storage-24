"""Shared module-level AgentConfig state without memory-tool import cycles."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from agentfoundry.utils.agent_config import AgentConfig

_module_config: Optional["AgentConfig"] = None


def set_module_config(config: "AgentConfig") -> None:
    """Set the process-wide AgentConfig used by runtime helpers."""
    global _module_config
    _module_config = config


def get_module_config() -> Optional["AgentConfig"]:
    """Return the process-wide AgentConfig used by runtime helpers."""
    return _module_config
