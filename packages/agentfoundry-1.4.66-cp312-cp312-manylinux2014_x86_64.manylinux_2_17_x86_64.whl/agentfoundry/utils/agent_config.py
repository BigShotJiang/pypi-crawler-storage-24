from __future__ import annotations

import logging
import os
import warnings
from pathlib import Path
from typing import Optional, Dict, Any, Union

from pydantic import BaseModel, Field, SecretStr, model_validator

# Try to import Config for backward compatibility defaults
try:
    from agentfoundry.utils.config import Config
    _HAS_LEGACY_CONFIG = True
except ImportError:
    _HAS_LEGACY_CONFIG = False

logger = logging.getLogger(__name__)


class MilvusConfig(BaseModel):
    """Milvus-specific vector store configuration."""
    uri: Optional[str] = None
    host: Optional[str] = None
    port: int = 19530
    secure: bool = False
    user: Optional[str] = None
    password: Optional[SecretStr] = None
    token: Optional[SecretStr] = None
    collection_prefix: str = "agentfoundry_"
    timeout: float = 10.0
    auto_id: bool = True
    embedding_model: str = "text-embedding-ada-002"
    fallback_dim: int = 1536


class VectorStoreConfig(BaseModel):
    """Vector store configuration supporting multiple providers."""
    provider: str = "milvus"
    collection_name: str = "agentfoundry"
    url: Optional[str] = None
    persist_dir: Optional[str] = None
    api_key: Optional[SecretStr] = None
    index_path: Optional[str] = None  # For FAISS

    # Provider-specific configs
    milvus: MilvusConfig = Field(default_factory=MilvusConfig)


class LLMConfig(BaseModel):
    """LLM provider configuration."""
    provider: str = "openai"
    model_name: str = "gpt-4o"
    api_key: Optional[SecretStr] = None
    api_base: Optional[str] = None
    temperature: Optional[float] = None
    timeout: int = 120
    # Provider-specific extras (e.g. Ollama host)
    extra_params: Dict[str, Any] = Field(default_factory=dict)


class EmbeddingConfig(BaseModel):
    """Embedding model configuration."""
    model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    dimensions: int = 384


class NeptuneConfig(BaseModel):
    """Neptune-specific knowledge-graph configuration."""
    endpoint: Optional[str] = None
    reader_endpoint: Optional[str] = None
    region: Optional[str] = None
    port: int = 8182
    use_https: bool = True
    iam_auth: bool = True
    query_language: str = "opencypher"
    timeout: float = 10.0
    use_ssh_tunnel: bool = False
    ssh_host: Optional[str] = None
    ssh_user: Optional[str] = None
    ssh_key_path: Optional[str] = None
    ssh_key_passphrase: Optional[SecretStr] = None
    use_nginx_proxy: bool = False
    nginx_proxy_host: str = "127.0.0.1"
    nginx_proxy_port: int = 8183


class AWSConfig(BaseModel):
    """AWS credentials/config used by Neptune and other AWS integrations."""

    access_key_id: Optional[str] = None
    secret_access_key: Optional[SecretStr] = None
    session_token: Optional[SecretStr] = None
    region: Optional[str] = None
    profile: Optional[str] = None


class KGraphConfig(BaseModel):
    """Knowledge-graph backend configuration."""
    backend: str = "duckdb_sqlite"
    neptune: NeptuneConfig = Field(default_factory=NeptuneConfig)


class ProjectConfig(BaseModel):
    """Default project scope values used by hosted multi-project deployments."""
    default_project_id: Optional[str] = None
    default_repo_id: Optional[str] = None
    default_bounded_context: Optional[str] = None
    default_environment: Optional[str] = None


class PartitioningConfig(BaseModel):
    """Logical partitioning settings for centralized vector/KG backends."""
    enabled: bool = True
    mode: str = "logical"
    central_vector_backend: bool = True
    central_kgraph_backend: bool = True
    vector_partition_key: str = "project_id"
    vector_namespace_template: str = "{org_id}:{project_id}"
    kgraph_partition_key: str = "project_id"
    kgraph_namespace_template: str = "{org_id}:{project_id}"


class HierarchyConfig(BaseModel):
    """Configuration for hierarchical multi-agent orchestration."""
    max_depth: int = Field(default=5, description="Maximum depth of the agent hierarchy tree.")
    parallel_limit: int = Field(default=10, description="Maximum number of sub-agents to run concurrently.")
    security_level: int = Field(
        default=1,
        description="Security enforcement level: 0=permissive (log-only), 1=enforce, 2=strict.",
    )
    parallel: bool = Field(default=True, description="Whether to run independent sub-agents concurrently.")


class ToolPolicyConfig(BaseModel):
    """Tool-governance settings for agent execution."""

    enforce_approval: bool = True
    approval_required_actions: list[str] = Field(default_factory=lambda: ["write", "build", "deploy"])
    profiles: Dict[str, "ToolPolicyProfileConfig"] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _normalize_profiles(self) -> "ToolPolicyConfig":
        normalized: Dict[str, ToolPolicyProfileConfig] = {}
        for key, value in self.profiles.items():
            name = str(key or "").strip().lower()
            if not name:
                continue
            normalized[name] = value
        self.profiles = normalized
        return self

    def resolve(self, environment: Optional[str] = None) -> "ResolvedToolPolicyConfig":
        env_key = str(environment or "").strip().lower()
        profile = self.profiles.get(env_key)
        resolved_actions = list(profile.approval_required_actions) if profile and profile.approval_required_actions else list(self.approval_required_actions)
        resolved_enforce = self.enforce_approval if profile is None or profile.enforce_approval is None else bool(profile.enforce_approval)
        return ResolvedToolPolicyConfig(
            environment=env_key or None,
            enforce_approval=resolved_enforce,
            approval_required_actions=resolved_actions or ["write", "build", "deploy"],
            profile_name=env_key or None,
        )


class ToolPolicyProfileConfig(BaseModel):
    """Environment-specific overrides for tool-governance settings."""

    enforce_approval: Optional[bool] = None
    approval_required_actions: list[str] = Field(default_factory=list)


class ResolvedToolPolicyConfig(BaseModel):
    """Effective tool-governance settings after profile resolution."""

    environment: Optional[str] = None
    enforce_approval: bool = True
    approval_required_actions: list[str] = Field(default_factory=lambda: ["write", "build", "deploy"])
    profile_name: Optional[str] = None


ToolPolicyConfig.model_rebuild()


class GitLabConfig(BaseModel):
    """GitLab API configuration for SCM integration."""

    base_url: str = "https://gitlab.com"
    api_version: str = "v4"
    username: Optional[str] = None
    token: Optional[SecretStr] = None
    default_project: Optional[str] = None


class MCPServerConfig(BaseModel):
    """Configuration for an external MCP server."""
    name: str
    command: str
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)


class AgentConfig(BaseModel):
    """
    Explicit configuration object for AgentFoundry.
    
    This is the standard way to configure AgentFoundry components. Host applications
    (like Quantify) should create an AgentConfig and pass it to AgentForge entry points.
    
    For standalone/CLI usage, use AgentConfig.from_legacy_config() to load from
    environment variables and TOML files.
    """
    # Identity & Scope
    org_id: str = "default"
    user_id: str = "default_user"
    thread_id: str = "default_thread"
    security_level: int = 0

    # Core Components
    llm: LLMConfig = Field(default_factory=LLMConfig)
    llm_formatter: Optional[LLMConfig] = Field(
        default=None,
        description="Secondary LLM config for structured-output / formatting tasks. "
                    "When None, all roles fall back to the primary 'llm' config.",
    )
    vector_store: VectorStoreConfig = Field(default_factory=VectorStoreConfig)
    kgraph: KGraphConfig = Field(default_factory=KGraphConfig)
    project: ProjectConfig = Field(default_factory=ProjectConfig)
    partitioning: PartitioningConfig = Field(default_factory=PartitioningConfig)
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    hierarchy: HierarchyConfig = Field(default_factory=HierarchyConfig)
    tool_policy: ToolPolicyConfig = Field(default_factory=ToolPolicyConfig)
    gitlab: GitLabConfig = Field(default_factory=GitLabConfig)
    aws: AWSConfig = Field(default_factory=AWSConfig)
    mcp_servers: list[MCPServerConfig] = Field(default_factory=list)
    
    # API Keys for various services (all optional)
    openai_api_key: Optional[SecretStr] = None
    xai_api_key: Optional[SecretStr] = None
    serpapi_api_key: Optional[SecretStr] = None
    google_api_key: Optional[SecretStr] = None
    hf_token: Optional[SecretStr] = None
    gemini_api_key: Optional[SecretStr] = None
    
    # Microsoft credentials (for Entra/Graph tools)
    ms_tenant_id: Optional[str] = None
    ms_client_id: Optional[str] = None
    ms_client_secret: Optional[SecretStr] = None
    
    # Paths (if using local storage)
    data_dir: Optional[Path] = None
    tools_dir: Optional[Path] = None
    cache_dir: Optional[Path] = None
    registry_db: Optional[Path] = None
    
    # Global settings
    log_level: str = "INFO"
    fail_fast: bool = Field(
        default=True,
        description="When True (default), backend init failures raise FatalInitializationError "
                    "that kills the process.  Set to False for degraded-mode startup.",
    )
    
    # Allow arbitrary extra config for plugins
    extra: Dict[str, Any] = Field(default_factory=dict)

    @staticmethod
    def _parse_action_list(raw_value: Any, default: Optional[list[str]] = None) -> list[str]:
        if isinstance(raw_value, str):
            parsed = [item.strip() for item in raw_value.split(",") if item.strip()]
            return parsed or list(default or [])
        if isinstance(raw_value, list):
            parsed = [str(item).strip() for item in raw_value if str(item).strip()]
            return parsed or list(default or [])
        return list(default or [])

    @classmethod
    def _parse_tool_policy_profiles_from_flat_dict(
        cls,
        config: Dict[str, Any],
        *,
        prefix: str = "AF_",
        dotted: bool = False,
    ) -> Dict[str, ToolPolicyProfileConfig]:
        profiles: Dict[str, Dict[str, Any]] = {}
        plain_mapping = config.get(f"{prefix}TOOL_POLICY_PROFILES") or config.get("TOOL_POLICY_PROFILES")
        if isinstance(plain_mapping, dict):
            for profile_name, profile_config in plain_mapping.items():
                if isinstance(profile_config, dict):
                    profiles[str(profile_name).strip().lower()] = dict(profile_config)
        prefix_patterns = [
            f"{prefix}TOOL_POLICY_PROFILES_",
            "TOOL_POLICY_PROFILES_",
        ]
        if dotted:
            prefix_patterns.extend(
                [
                    f"{prefix}TOOL_POLICY.PROFILES.",
                    "TOOL_POLICY.PROFILES.",
                ]
            )
        for raw_key, value in config.items():
            key = str(raw_key)
            tail = None
            for prefix_pattern in prefix_patterns:
                if key.startswith(prefix_pattern):
                    tail = key[len(prefix_pattern):]
                    break
            if tail is None:
                continue
            separator = "." if "." in tail else "_"
            parts = [part for part in tail.split(separator) if part]
            if len(parts) < 2:
                continue
            profile_name = parts[0].strip().lower()
            field_name = "_".join(part.strip().lower() for part in parts[1:] if part.strip())
            if not profile_name or not field_name:
                continue
            profiles.setdefault(profile_name, {})[field_name] = value
        resolved: Dict[str, ToolPolicyProfileConfig] = {}
        for profile_name, profile_data in profiles.items():
            resolved[profile_name] = ToolPolicyProfileConfig(
                enforce_approval=(
                    bool(profile_data["enforce_approval"])
                    if isinstance(profile_data.get("enforce_approval"), bool)
                    else (
                        str(profile_data.get("enforce_approval", "")).lower() in ("true", "1", "yes", "on")
                        if "enforce_approval" in profile_data
                        else None
                    )
                ),
                approval_required_actions=cls._parse_action_list(profile_data.get("approval_required_actions")),
            )
        return resolved

    @classmethod
    def from_dict(cls, config: Dict[str, Any], prefix: str = "AF_") -> "AgentConfig":
        """
        Create AgentConfig from a flat dictionary with prefixed keys.
        
        This is the primary factory method for host applications like Quantify
        that load configuration from secrets backends and TOML files.
        
        Args:
            config: Flat dictionary with prefixed keys (e.g., AF_OPENAI_API_KEY)
            prefix: Key prefix to strip (default: "AF_")
        
        Returns:
            AgentConfig instance
        
        Example:
            config = {
                'AF_OPENAI_API_KEY': 'sk-...',
                'AF_LLM_PROVIDER': 'openai',
                'AF_OPENAI_MODEL': 'gpt-4o',
                'AF_VECTORSTORE_PROVIDER': 'milvus',
                'AF_MILVUS_URI': 'http://localhost:19530',
            }
            af_config = AgentConfig.from_dict(config)
        """
        logger.info("AgentConfig.from_dict: building config from %d keys (prefix=%s)", len(config), prefix)

        def get(key: str, default=None):
            """Get value with or without prefix."""
            return config.get(f"{prefix}{key}") or config.get(key) or default
        
        def get_secret(key: str) -> Optional[SecretStr]:
            """Get value as SecretStr if present."""
            val = get(key)
            return SecretStr(val) if val else None
        
        # Determine LLM provider and model
        llm_provider = get("LLM_PROVIDER", "openai")
        if llm_provider == "openai":
            model_name = get("OPENAI_MODEL", "gpt-4o")
            api_key = get_secret("OPENAI_API_KEY")
            api_base = None
        elif llm_provider == "ollama":
            model_name = get("OLLAMA_MODEL", "gemma3:27b")
            api_key = None
            api_base = get("OLLAMA_HOST", "http://127.0.0.1:11434")
        elif llm_provider == "grok":
            model_name = get("GROK_MODEL", "grok-beta")
            api_key = get_secret("XAI_API_KEY")
            api_base = None
        elif llm_provider == "gemini":
            model_name = get("GEMINI_MODEL", "gemini-pro")
            api_key = get_secret("GEMINI_API_KEY") or get_secret("GOOGLE_API_KEY")
            api_base = None
        else:
            model_name = get("OPENAI_MODEL", "gpt-4o")
            api_key = get_secret("OPENAI_API_KEY")
            api_base = None
        
        # Determine formatter LLM (secondary model for structured output)
        fmt_provider = get("LLM_FORMATTER_PROVIDER")
        fmt_model = get("LLM_FORMATTER_MODEL")
        llm_formatter_cfg: Optional[LLMConfig] = None
        if fmt_provider or fmt_model:
            fmt_provider = fmt_provider or llm_provider
            if fmt_provider == "ollama":
                fmt_model = fmt_model or "gemma3:27b"
                fmt_api_key = None
                fmt_api_base = get("LLM_FORMATTER_HOST") or get("OLLAMA_HOST", "http://127.0.0.1:11434")
            elif fmt_provider == "openai":
                fmt_model = fmt_model or "gpt-4o"
                fmt_api_key = get_secret("OPENAI_API_KEY")
                fmt_api_base = None
            elif fmt_provider == "grok":
                fmt_model = fmt_model or "grok-beta"
                fmt_api_key = get_secret("XAI_API_KEY")
                fmt_api_base = None
            elif fmt_provider == "gemini":
                fmt_model = fmt_model or "gemini-pro"
                fmt_api_key = get_secret("GEMINI_API_KEY") or get_secret("GOOGLE_API_KEY")
                fmt_api_base = None
            else:
                fmt_model = fmt_model or "gpt-4o"
                fmt_api_key = get_secret("OPENAI_API_KEY")
                fmt_api_base = None
            llm_formatter_cfg = LLMConfig(
                provider=fmt_provider,
                model_name=fmt_model,
                api_key=fmt_api_key,
                api_base=fmt_api_base,
                timeout=int(get("LLM_FORMATTER_TIMEOUT", 120)),
            )

        # Build Milvus config
        milvus_config = MilvusConfig(
            uri=get("MILVUS_URI"),
            host=get("MILVUS_HOST"),
            port=int(get("MILVUS_PORT", 19530)),
            secure=str(get("MILVUS_SECURE", "false")).lower() in ("true", "1", "yes"),
            user=get("MILVUS_USER"),
            password=get_secret("MILVUS_PASSWORD"),
            token=get_secret("MILVUS_TOKEN"),
            collection_prefix=get("MILVUS_COLLECTION_PREFIX") or get("MILVUS_CONNECTION_PREFIX", "agentfoundry_"),
            timeout=float(get("MILVUS_TIMEOUT", 10.0)),
            auto_id=str(get("MILVUS_AUTO_ID", "true")).lower() in ("true", "1", "yes"),
            embedding_model=get("MILVUS_EMBEDDING_MODEL", "text-embedding-ada-002"),
            fallback_dim=int(get("MILVUS_FALLBACK_DIM", 1536)),
        )
        neptune_config = NeptuneConfig(
            endpoint=get("NEPTUNE_ENDPOINT"),
            reader_endpoint=get("NEPTUNE_READER_ENDPOINT"),
            region=get("NEPTUNE_REGION"),
            port=int(get("NEPTUNE_PORT", 8182)),
            use_https=str(get("NEPTUNE_USE_HTTPS", "true")).lower() in ("true", "1", "yes", "on"),
            iam_auth=str(get("NEPTUNE_IAM_AUTH", "true")).lower() in ("true", "1", "yes", "on"),
            query_language=get("NEPTUNE_QUERY_LANGUAGE", "opencypher"),
            timeout=float(get("NEPTUNE_TIMEOUT", 10.0)),
            use_ssh_tunnel=str(get("NEPTUNE_USE_SSH_TUNNEL", "false")).lower() in ("true", "1", "yes", "on"),
            ssh_host=get("NEPTUNE_SSH_HOST"),
            ssh_user=get("NEPTUNE_SSH_USER"),
            ssh_key_path=get("NEPTUNE_SSH_KEY_PATH"),
            ssh_key_passphrase=get_secret("NEPTUNE_SSH_KEY_PASSPHRASE"),
        )
        project_config = ProjectConfig(
            default_project_id=get("PROJECT_DEFAULT_PROJECT_ID"),
            default_repo_id=get("PROJECT_DEFAULT_REPO_ID"),
            default_bounded_context=get("PROJECT_DEFAULT_BOUNDED_CONTEXT"),
            default_environment=get("PROJECT_DEFAULT_ENVIRONMENT"),
        )
        partitioning_config = PartitioningConfig(
            enabled=str(get("PARTITIONING_ENABLED", "true")).lower() in ("true", "1", "yes", "on"),
            mode=get("PARTITIONING_MODE", "logical"),
            central_vector_backend=str(get("PARTITIONING_CENTRAL_VECTOR_BACKEND", "true")).lower() in ("true", "1", "yes", "on"),
            central_kgraph_backend=str(get("PARTITIONING_CENTRAL_KGRAPH_BACKEND", "true")).lower() in ("true", "1", "yes", "on"),
            vector_partition_key=get("PARTITIONING_VECTOR_PARTITION_KEY", "project_id"),
            vector_namespace_template=get("PARTITIONING_VECTOR_NAMESPACE_TEMPLATE", "{org_id}:{project_id}"),
            kgraph_partition_key=get("PARTITIONING_KGRAPH_PARTITION_KEY", "project_id"),
            kgraph_namespace_template=get("PARTITIONING_KGRAPH_NAMESPACE_TEMPLATE", "{org_id}:{project_id}"),
        )
        hierarchy_config = HierarchyConfig(
            max_depth=int(get("HIERARCHY_MAX_DEPTH", 5)),
            parallel_limit=int(get("HIERARCHY_PARALLEL_LIMIT", 10)),
            security_level=int(get("HIERARCHY_SECURITY_LEVEL", 1)),
            parallel=str(get("HIERARCHY_PARALLEL", "true")).lower() in ("true", "1", "yes", "on"),
        )
        approval_actions_raw = get("TOOL_POLICY_APPROVAL_REQUIRED_ACTIONS", ["write", "build", "deploy"])
        approval_required_actions = cls._parse_action_list(
            approval_actions_raw,
            default=["write", "build", "deploy"],
        )
        tool_policy_config = ToolPolicyConfig(
            enforce_approval=str(get("TOOL_POLICY_ENFORCE_APPROVAL", "true")).lower() in ("true", "1", "yes", "on"),
            approval_required_actions=approval_required_actions or ["write", "build", "deploy"],
            profiles=cls._parse_tool_policy_profiles_from_flat_dict(config, prefix=prefix),
        )
        gitlab_config = GitLabConfig(
            base_url=get("GITLAB_BASE_URL", "https://gitlab.com"),
            api_version=get("GITLAB_API_VERSION", "v4"),
            username=get("GITLAB_USERNAME"),
            token=get_secret("GITLAB_TOKEN"),
            default_project=get("GITLAB_DEFAULT_PROJECT"),
        )
        aws_config = AWSConfig(
            access_key_id=get("AWS_ACCESS_KEY_ID"),
            secret_access_key=get_secret("AWS_SECRET_ACCESS_KEY"),
            session_token=get_secret("AWS_SESSION_TOKEN"),
            region=get("AWS_REGION"),
            profile=get("AWS_PROFILE"),
        )
        
        mcp_servers = []
        mcp_list = get("MCP_SERVERS", [])
        if isinstance(mcp_list, list):
            for s in mcp_list:
                mcp_servers.append(MCPServerConfig(**s))
        
        result = cls(
            org_id=get("ORG_ID", "default"),
            user_id=get("USER_ID", "default_user"),
            thread_id=get("THREAD_ID", "default_thread"),
            security_level=int(get("SECURITY_LEVEL", 0)),
            llm=LLMConfig(
                provider=llm_provider,
                model_name=model_name,
                api_key=api_key,
                api_base=api_base,
                timeout=int(get("LLM_TIMEOUT", 120)),
            ),
            llm_formatter=llm_formatter_cfg,
            vector_store=VectorStoreConfig(
                provider=get("VECTORSTORE_PROVIDER", "milvus"),
                collection_name=get("COLLECTION_NAME", "agentfoundry"),
                url=get("MILVUS_URI"),
                persist_dir=get("FAISS_INDEX_PATH"),
                index_path=get("FAISS_INDEX_PATH"),
                milvus=milvus_config,
            ),
            kgraph=KGraphConfig(
                backend=get("KGRAPH_BACKEND", "duckdb_sqlite"),
                neptune=neptune_config,
            ),
            project=project_config,
            partitioning=partitioning_config,
            hierarchy=hierarchy_config,
            tool_policy=tool_policy_config,
            gitlab=gitlab_config,
            aws=aws_config,
            embedding=EmbeddingConfig(
                model_name=get("EMBEDDING_MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2"),
                dimensions=int(get("EMBEDDING_DIMENSIONS", 384)),
            ),
            mcp_servers=mcp_servers,
            openai_api_key=get_secret("OPENAI_API_KEY"),
            xai_api_key=get_secret("XAI_API_KEY"),
            serpapi_api_key=get_secret("SERPAPI_API_KEY"),
            google_api_key=get_secret("GOOGLE_API_KEY"),
            hf_token=get_secret("HF_TOKEN"),
            gemini_api_key=get_secret("GEMINI_API_KEY"),
            ms_tenant_id=get("MS_TENANT_ID"),
            ms_client_id=get("MS_CLIENT_ID"),
            ms_client_secret=get_secret("MS_CLIENT_SECRET"),
            data_dir=Path(get("DATA_DIR")) if get("DATA_DIR") else None,
            tools_dir=Path(get("TOOLS_DIR")) if get("TOOLS_DIR") else None,
            cache_dir=Path(get("CACHE_DIR")) if get("CACHE_DIR") else None,
            registry_db=Path(get("REGISTRY_DB")) if get("REGISTRY_DB") else None,
            log_level=get("LOG_LEVEL", "INFO"),
            fail_fast=str(get("FAIL_FAST", "true")).lower() in ("true", "1", "yes", "on"),
        )
        logger.info(
            "AgentConfig.from_dict: provider=%s model=%s vs_provider=%s org=%s fail_fast=%s",
            llm_provider, model_name,
            get("VECTORSTORE_PROVIDER", "milvus"),
            get("ORG_ID", "default"),
            get("FAIL_FAST", "true"),
        )
        return result

    @classmethod
    def from_legacy_config(cls) -> "AgentConfig":
        """
        Factory to create an AgentConfig from the existing global/env system.

        This is for backward compatibility and standalone CLI usage. Host applications
        should use from_dict() instead.
        """
        logger.info("AgentConfig.from_legacy_config: loading from environment/TOML")
        if not _HAS_LEGACY_CONFIG:
            logger.warning("Legacy Config not available; returning default AgentConfig")
            return cls()
            
        legacy = Config()
        
        def get(k, default=None):
            env_key = str(k).upper().replace(".", "_")
            env_val = os.getenv(env_key)
            if env_val not in (None, ""):
                return env_val

            cfg = getattr(legacy, "_config", {}) or {}
            current = cfg
            for part in str(k).split("."):
                if not isinstance(current, dict) or part not in current:
                    return default
                current = current[part]
            if current in (None, ""):
                return default
            return current

        # Map legacy keys to new structure
        llm_provider = get("LLM_PROVIDER", "openai")
        
        return cls(
            org_id=get("ORG_ID", "default"),
            llm=LLMConfig(
                provider=llm_provider,
                model_name=get("OPENAI_MODEL") or get("OLLAMA.MODEL") or "gpt-4o",
                api_key=SecretStr(get("OPENAI_API_KEY")) if get("OPENAI_API_KEY") else None,
                api_base=get("OLLAMA.HOST") if llm_provider == "ollama" else None,
            ),
            vector_store=VectorStoreConfig(
                provider=get("VECTORSTORE.PROVIDER", "milvus"),
                url=get("MILVUS.URI"),
                index_path=get("FAISS.INDEX_PATH"),
                milvus=MilvusConfig(
                    uri=get("MILVUS.URI"),
                    host=get("MILVUS.HOST"),
                    port=int(get("MILVUS.PORT", 19530)),
                    collection_prefix=get("MILVUS.COLLECTION_PREFIX", "agentfoundry_"),
                    timeout=float(get("MILVUS.TIMEOUT", 10.0)),
                ),
            ),
            kgraph=KGraphConfig(
                backend=get("KGRAPH.BACKEND", "duckdb_sqlite"),
                neptune=NeptuneConfig(
                    endpoint=get("NEPTUNE.ENDPOINT"),
                    reader_endpoint=get("NEPTUNE.READER_ENDPOINT"),
                    region=get("NEPTUNE.REGION"),
                    port=int(get("NEPTUNE.PORT", 8182)),
                    use_https=str(get("NEPTUNE.USE_HTTPS", "true")).lower() in ("true", "1", "yes", "on"),
                    iam_auth=str(get("NEPTUNE.IAM_AUTH", "true")).lower() in ("true", "1", "yes", "on"),
                    query_language=get("NEPTUNE.QUERY_LANGUAGE", "opencypher"),
                    timeout=float(get("NEPTUNE.TIMEOUT", 10.0)),
                    use_ssh_tunnel=str(get("NEPTUNE.USE_SSH_TUNNEL", "false")).lower() in ("true", "1", "yes", "on"),
                    ssh_host=get("NEPTUNE.SSH_HOST"),
                    ssh_user=get("NEPTUNE.SSH_USER"),
                    ssh_key_path=get("NEPTUNE.SSH_KEY_PATH"),
                    ssh_key_passphrase=SecretStr(get("NEPTUNE.SSH_KEY_PASSPHRASE")) if get("NEPTUNE.SSH_KEY_PASSPHRASE") else None,
                ),
            ),
            project=ProjectConfig(
                default_project_id=get("PROJECT.DEFAULT_PROJECT_ID"),
                default_repo_id=get("PROJECT.DEFAULT_REPO_ID"),
                default_bounded_context=get("PROJECT.DEFAULT_BOUNDED_CONTEXT"),
                default_environment=get("PROJECT.DEFAULT_ENVIRONMENT"),
            ),
            partitioning=PartitioningConfig(
                enabled=str(get("PARTITIONING.ENABLED", "true")).lower() in ("true", "1", "yes", "on"),
                mode=get("PARTITIONING.MODE", "logical"),
                central_vector_backend=str(get("PARTITIONING.CENTRAL_VECTOR_BACKEND", "true")).lower() in ("true", "1", "yes", "on"),
                central_kgraph_backend=str(get("PARTITIONING.CENTRAL_KGRAPH_BACKEND", "true")).lower() in ("true", "1", "yes", "on"),
                vector_partition_key=get("PARTITIONING.VECTOR_PARTITION_KEY", "project_id"),
                vector_namespace_template=get("PARTITIONING.VECTOR_NAMESPACE_TEMPLATE", "{org_id}:{project_id}"),
                kgraph_partition_key=get("PARTITIONING.KGRAPH_PARTITION_KEY", "project_id"),
                kgraph_namespace_template=get("PARTITIONING.KGRAPH_NAMESPACE_TEMPLATE", "{org_id}:{project_id}"),
            ),
            tool_policy=ToolPolicyConfig(
                enforce_approval=str(get("TOOL_POLICY.ENFORCE_APPROVAL", "true")).lower() in ("true", "1", "yes", "on"),
                approval_required_actions=cls._parse_action_list(
                    get("TOOL_POLICY.APPROVAL_REQUIRED_ACTIONS", ["write", "build", "deploy"]),
                    default=["write", "build", "deploy"],
                ) or ["write", "build", "deploy"],
                profiles=cls._parse_tool_policy_profiles_from_flat_dict(dict(os.environ), prefix="", dotted=True),
            ),
            gitlab=GitLabConfig(
                base_url=get("GITLAB.BASE_URL", "https://gitlab.com"),
                api_version=get("GITLAB.API_VERSION", "v4"),
                username=get("GITLAB.USERNAME"),
                token=SecretStr(get("GITLAB.TOKEN")) if get("GITLAB.TOKEN") else None,
                default_project=get("GITLAB.DEFAULT_PROJECT"),
            ),
            aws=AWSConfig(
                access_key_id=get("AWS.ACCESS_KEY_ID") or get("AWS_ACCESS_KEY_ID"),
                secret_access_key=(
                    SecretStr(get("AWS.SECRET_ACCESS_KEY") or get("AWS_SECRET_ACCESS_KEY"))
                    if (get("AWS.SECRET_ACCESS_KEY") or get("AWS_SECRET_ACCESS_KEY"))
                    else None
                ),
                session_token=(
                    SecretStr(get("AWS.SESSION_TOKEN") or get("AWS_SESSION_TOKEN"))
                    if (get("AWS.SESSION_TOKEN") or get("AWS_SESSION_TOKEN"))
                    else None
                ),
                region=get("AWS.REGION") or get("AWS_REGION"),
                profile=get("AWS.PROFILE") or get("AWS_PROFILE"),
            ),
            embedding=EmbeddingConfig(
                model_name=get("EMBEDDING.MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2"),
            ),
            mcp_servers=[MCPServerConfig(**s) for s in get("mcp_servers", [])] if isinstance(get("mcp_servers"), list) else [],
            openai_api_key=SecretStr(get("OPENAI_API_KEY")) if get("OPENAI_API_KEY") else None,
            xai_api_key=SecretStr(get("XAI_API_KEY")) if get("XAI_API_KEY") else None,
            serpapi_api_key=SecretStr(get("SERPAPI_API_KEY")) if get("SERPAPI_API_KEY") else None,
            google_api_key=SecretStr(get("GOOGLE.API_KEY")) if get("GOOGLE.API_KEY") else None,
            hf_token=SecretStr(get("HF_TOKEN")) if get("HF_TOKEN") else None,
            ms_tenant_id=get("MS.TENANT_ID"),
            ms_client_id=get("MS.CLIENT_ID"),
            ms_client_secret=SecretStr(get("MS.CLIENT_SECRET")) if get("MS.CLIENT_SECRET") else None,
            data_dir=Path(get("DATA_DIR")) if get("DATA_DIR") else None,
            tools_dir=Path(get("TOOLS_DIR")) if get("TOOLS_DIR") else None,
            cache_dir=Path(get("CACHE_DIR")) if get("CACHE_DIR") else None,
            registry_db=Path(get("REGISTRY_DB")) if get("REGISTRY_DB") else None,
            log_level=get("LOGGING.LEVEL", "INFO"),
        )

    def get_project_scope_defaults(self) -> Dict[str, Optional[str]]:
        """Return the configured default project scope values."""
        return {
            "project_id": self.project.default_project_id,
            "repo_id": self.project.default_repo_id,
            "bounded_context": self.project.default_bounded_context,
            "environment": self.project.default_environment,
        }

    def render_partition_namespace(
        self,
        kind: str,
        *,
        project_id: Optional[str] = None,
        repo_id: Optional[str] = None,
        bounded_context: Optional[str] = None,
        environment: Optional[str] = None,
    ) -> str:
        """Render a vector/KG namespace for centralized hosted backends."""
        template = (
            self.partitioning.vector_namespace_template
            if kind.lower() == "vector"
            else self.partitioning.kgraph_namespace_template
        )
        values = {
            "org_id": self.org_id,
            "project_id": project_id or self.project.default_project_id or "default_project",
            "repo_id": repo_id or self.project.default_repo_id or "",
            "bounded_context": bounded_context or self.project.default_bounded_context or "",
            "environment": environment or self.project.default_environment or "",
        }
        return template.format(**values)

    def get_api_key(self, provider: str = None) -> Optional[str]:
        """
        Get the API key for the specified or configured LLM provider.
        
        Args:
            provider: LLM provider name. If None, uses self.llm.provider.
        
        Returns:
            API key string or None
        """
        provider = provider or self.llm.provider
        
        if provider == "openai":
            key = self.llm.api_key or self.openai_api_key
        elif provider == "grok":
            key = self.llm.api_key or self.xai_api_key
        elif provider == "gemini":
            key = self.llm.api_key or self.gemini_api_key or self.google_api_key
        else:
            key = self.llm.api_key

        if key:
            return key.get_secret_value()

        # Fall back to well-known environment variables
        env_key_map = {
            "openai": "OPENAI_API_KEY",
            "grok": "XAI_API_KEY",
            "gemini": "GEMINI_API_KEY",
        }
        env_var = env_key_map.get(provider)
        if env_var:
            return os.environ.get(env_var)
        return None
    
    def get_api_key_for_config(self, llm_config: LLMConfig) -> Optional[str]:
        """Get the API key for an arbitrary LLMConfig using this AgentConfig's key store."""
        provider = llm_config.provider
        key = llm_config.api_key
        if not key:
            if provider == "openai":
                key = self.openai_api_key
            elif provider == "grok":
                key = self.xai_api_key
            elif provider == "gemini":
                key = self.gemini_api_key or self.google_api_key
        if key:
            return key.get_secret_value()

        # Fall back to well-known environment variables
        env_key_map = {
            "openai": "OPENAI_API_KEY",
            "grok": "XAI_API_KEY",
            "gemini": "GEMINI_API_KEY",
        }
        env_var = env_key_map.get(provider)
        if env_var:
            return os.environ.get(env_var)
        return None

    def get_secret(self, name: str) -> Optional[str]:
        """
        Get a secret value by name.
        
        Args:
            name: Secret name (e.g., 'serpapi_api_key', 'hf_token')
        
        Returns:
            Secret value string or None
        """
        attr = getattr(self, name, None)
        if isinstance(attr, SecretStr):
            return attr.get_secret_value()
        return attr
