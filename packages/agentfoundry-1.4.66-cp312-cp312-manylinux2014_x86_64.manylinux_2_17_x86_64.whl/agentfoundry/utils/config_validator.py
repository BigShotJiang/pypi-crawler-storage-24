"""Pre-flight configuration validation with clear, actionable error messages.

Checks AgentConfig for common misconfigurations before the orchestrator
starts. Each check returns a ``ConfigIssue`` with field, severity, message,
and a suggestion for how to fix it.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

KNOWN_LLM_PROVIDERS = {"openai", "ollama", "grok", "gemini"}
KNOWN_VS_PROVIDERS = {"milvus", "faiss"}
KNOWN_KG_BACKENDS = {"duckdb_sqlite", "neptune"}


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ConfigIssue:
    """A single validation finding."""

    field: str
    severity: Severity
    message: str
    suggestion: str = ""

    def __str__(self) -> str:
        sev = self.severity.value.upper()
        line = f"[{sev}] {self.field}: {self.message}"
        if self.suggestion:
            line += f"\n  -> {self.suggestion}"
        return line


def validate_config(config: Any) -> List[ConfigIssue]:
    """Run all validation checks against an AgentConfig instance.

    Args:
        config: An AgentConfig (or any object with matching attributes).

    Returns:
        List of ConfigIssue instances (empty = all good).
    """
    issues: List[ConfigIssue] = []

    _check_llm(config, issues)
    _check_vector_store(config, issues)
    _check_kgraph(config, issues)
    _check_paths(config, issues)
    _check_mcp_servers(config, issues)
    _check_identity(config, issues)

    return issues


def validate_and_report(config: Any) -> str:
    """Run validation and return a human-readable report.

    Returns:
        Multi-line string. Empty string if no issues found.
    """
    issues = validate_config(config)
    if not issues:
        return ""

    lines = ["AgentFoundry Configuration Report", "=" * 40]
    errors = [i for i in issues if i.severity == Severity.ERROR]
    warnings = [i for i in issues if i.severity == Severity.WARNING]
    infos = [i for i in issues if i.severity == Severity.INFO]

    if errors:
        lines.append(f"\n{len(errors)} error(s):")
        lines.extend(f"  {i}" for i in errors)
    if warnings:
        lines.append(f"\n{len(warnings)} warning(s):")
        lines.extend(f"  {i}" for i in warnings)
    if infos:
        lines.append(f"\n{len(infos)} info(s):")
        lines.extend(f"  {i}" for i in infos)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Check functions
# ---------------------------------------------------------------------------

def _get_secret_value(val: Any) -> Optional[str]:
    """Extract a string from a SecretStr or plain string."""
    if val is None:
        return None
    if hasattr(val, "get_secret_value"):
        try:
            return val.get_secret_value()
        except Exception:
            return None
    return str(val) if val else None


def _check_llm(config: Any, issues: List[ConfigIssue]) -> None:
    llm = getattr(config, "llm", None)
    if llm is None:
        issues.append(ConfigIssue(
            field="llm", severity=Severity.ERROR,
            message="LLM configuration is missing",
            suggestion="Add an 'llm' section to your configuration",
        ))
        return

    provider = getattr(llm, "provider", "")
    if provider and provider not in KNOWN_LLM_PROVIDERS:
        issues.append(ConfigIssue(
            field="llm.provider", severity=Severity.WARNING,
            message=f"Unknown LLM provider '{provider}'",
            suggestion=f"Known providers: {', '.join(sorted(KNOWN_LLM_PROVIDERS))}",
        ))

    # Check API key for providers that require one
    if provider in ("openai", "grok", "gemini"):
        key_map = {
            "openai": "openai_api_key",
            "grok": "xai_api_key",
            "gemini": "gemini_api_key",
        }
        key_attr = key_map.get(provider, "")
        key_val = _get_secret_value(getattr(config, key_attr, None))
        env_map = {
            "openai": "OPENAI_API_KEY",
            "grok": "XAI_API_KEY",
            "gemini": "GEMINI_API_KEY",
        }
        env_var = env_map.get(provider, "")
        env_val = os.getenv(env_var)

        if not key_val and not env_val:
            issues.append(ConfigIssue(
                field=f"llm ({provider})", severity=Severity.ERROR,
                message=f"API key required for provider '{provider}' but not found",
                suggestion=f"Set {env_var} environment variable or config.{key_attr}",
            ))

    model = getattr(llm, "model_name", "")
    if not model:
        issues.append(ConfigIssue(
            field="llm.model_name", severity=Severity.WARNING,
            message="No model name specified",
            suggestion="Set llm.model_name (e.g. 'gpt-4o')",
        ))


def _check_vector_store(config: Any, issues: List[ConfigIssue]) -> None:
    vs = getattr(config, "vector_store", None)
    if vs is None:
        return

    provider = getattr(vs, "provider", "")
    if provider and provider not in KNOWN_VS_PROVIDERS:
        issues.append(ConfigIssue(
            field="vector_store.provider", severity=Severity.WARNING,
            message=f"Unknown vector store provider '{provider}'",
            suggestion=f"Known providers: {', '.join(sorted(KNOWN_VS_PROVIDERS))}",
        ))

    if provider == "faiss":
        index_path = getattr(vs, "index_path", None)
        if not index_path:
            issues.append(ConfigIssue(
                field="vector_store.index_path", severity=Severity.INFO,
                message="No FAISS index path configured; using in-memory index",
                suggestion="Set vector_store.index_path for persistent FAISS storage",
            ))


def _check_kgraph(config: Any, issues: List[ConfigIssue]) -> None:
    kg = getattr(config, "kgraph", None)
    if kg is None:
        return

    backend = getattr(kg, "backend", "")
    if backend and backend not in KNOWN_KG_BACKENDS:
        issues.append(ConfigIssue(
            field="kgraph.backend", severity=Severity.WARNING,
            message=f"Unknown KGraph backend '{backend}'",
            suggestion=f"Known backends: {', '.join(sorted(KNOWN_KG_BACKENDS))}",
        ))

    if backend == "neptune":
        neptune = getattr(kg, "neptune", None)
        endpoint = getattr(neptune, "endpoint", None) if neptune else None
        if not endpoint:
            issues.append(ConfigIssue(
                field="kgraph.neptune.endpoint", severity=Severity.ERROR,
                message="Neptune endpoint is required when kgraph.backend='neptune'",
                suggestion="Set kgraph.neptune.endpoint to your Neptune cluster URL",
            ))


def _check_paths(config: Any, issues: List[ConfigIssue]) -> None:
    for attr, label in [("data_dir", "Data directory"), ("cache_dir", "Cache directory")]:
        path_val = getattr(config, attr, None)
        if not path_val:
            continue
        p = Path(str(path_val))
        if p.exists() and not p.is_dir():
            issues.append(ConfigIssue(
                field=attr, severity=Severity.ERROR,
                message=f"{label} '{path_val}' exists but is not a directory",
                suggestion=f"Remove the file or change {attr} to a valid directory path",
            ))
        elif not p.exists():
            try:
                p.mkdir(parents=True, exist_ok=True)
                p.rmdir()  # clean up the test dir
            except PermissionError:
                issues.append(ConfigIssue(
                    field=attr, severity=Severity.ERROR,
                    message=f"Cannot create {label.lower()} '{path_val}': permission denied",
                    suggestion=f"Check filesystem permissions for {path_val}",
                ))
            except Exception:
                pass  # path is creatable


def _check_mcp_servers(config: Any, issues: List[ConfigIssue]) -> None:
    servers = getattr(config, "mcp_servers", None)
    if not servers:
        return

    for i, srv in enumerate(servers):
        name = getattr(srv, "name", "") or ""
        command = getattr(srv, "command", "") or ""

        if not name:
            issues.append(ConfigIssue(
                field=f"mcp_servers[{i}].name", severity=Severity.ERROR,
                message="MCP server config missing 'name'",
                suggestion="Each MCP server must have a unique name",
            ))
        if not command:
            issues.append(ConfigIssue(
                field=f"mcp_servers[{i}].command", severity=Severity.ERROR,
                message=f"MCP server '{name or i}' missing 'command'",
                suggestion="Set the command to run the MCP server process",
            ))


def _check_identity(config: Any, issues: List[ConfigIssue]) -> None:
    org_id = getattr(config, "org_id", "")
    if not org_id or org_id == "default":
        issues.append(ConfigIssue(
            field="org_id", severity=Severity.INFO,
            message="Using default org_id; memory will be scoped to 'default'",
            suggestion="Set org_id to your organization identifier for proper multi-tenancy",
        ))
