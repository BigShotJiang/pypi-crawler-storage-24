"""Cooperative cancellation primitives for AgentFoundry.

A :class:`CancellationToken` can be passed to long-running operations.
The caller sets the token when cancellation is desired; the executing code
checks the token at strategic checkpoints and raises
:class:`RequestCancelled` to unwind.
"""

from __future__ import annotations

import logging
import threading

logger = logging.getLogger(__name__)


class RequestCancelled(Exception):
    """Raised when an operation has been cancelled."""

    def __init__(self, user_id: str = "", thread_id: str = ""):
        self.user_id = user_id
        self.thread_id = thread_id
        super().__init__(
            f"Request cancelled for user_id={user_id}, thread_id={thread_id}"
        )


class CancellationToken:
    """Thread-safe cancellation token backed by :class:`threading.Event`."""

    def __init__(self, user_id: str = "", thread_id: str = ""):
        self._event = threading.Event()
        self.user_id = user_id
        self.thread_id = thread_id

    def cancel(self) -> None:
        """Signal cancellation.  Thread-safe and idempotent."""
        logger.info(
            "Cancellation signalled for user_id=%s thread_id=%s",
            self.user_id,
            self.thread_id,
        )
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        """Check cancellation status without raising."""
        return self._event.is_set()

    def check(self) -> None:
        """Raise :class:`RequestCancelled` if cancellation has been signalled."""
        if self._event.is_set():
            raise RequestCancelled(self.user_id, self.thread_id)
