"""FAISS vector-store provider implementation.

Supports two modes:

- **Persistent** (default): loads/saves an index from disk.
- **In-memory**: creates a lightweight, non-persistent index on the fly.
  Enable by setting ``vector_store.persist_dir`` to the literal string
  ``":memory:"`` in ``AgentConfig``, or pass ``in_memory=True`` to the
  constructor.  This is useful for fast testing and dev environments where
  startup speed matters more than durability (Step 7 of
  MultiAgentCollaborationPlan).
"""

from __future__ import annotations

import logging
import os
import time
import warnings
from typing import Any, Dict, List, Optional

from agentfoundry.utils.agent_config import AgentConfig
from agentfoundry.vectorstores.base import VectorStore
from agentfoundry.vectorstores.factory import VectorStoreFactory


logger = logging.getLogger(__name__)


@VectorStoreFactory.register_provider("faiss")
class FAISSVectorStoreProvider(VectorStore):
    """Local FAISS index wrapped as a LangChain VectorStore.

    Parameters
    ----------
    config : AgentConfig, optional
        Configuration object.
    in_memory : bool
        When ``True``, create a fresh in-memory index (no disk I/O).
        Equivalent to setting ``vector_store.persist_dir = ":memory:"``.
    """

    def __init__(self, config: AgentConfig = None, *, in_memory: bool = False, **kwargs):
        super().__init__(**kwargs)

        # Handle backward compatibility
        if config is None:
            warnings.warn(
                "FAISSVectorStoreProvider() without config is deprecated. "
                "Pass AgentConfig explicitly.",
                DeprecationWarning,
                stacklevel=2,
            )
            config = AgentConfig.from_legacy_config()

        self._config = config
        self._index_path: Optional[str] = None
        self._in_memory = in_memory

        # Detect in-memory mode from config
        persist_dir = str(config.vector_store.persist_dir or "").strip()
        if persist_dir == ":memory:":
            self._in_memory = True

        # Create embeddings
        self._embedding = self._create_embedding(config)

        if self._in_memory:
            self._store = self._create_in_memory_store()
        else:
            self._store = self._load_persistent_store(config)

    def _create_embedding(self, config: AgentConfig):
        """Resolve the embedding model; fall back to a lightweight hash model."""
        model_name = config.embedding.model_name or ""

        # Try HuggingFace for sentence-transformer style models
        if "/" in model_name or model_name.startswith("sentence-transformers"):
            try:
                from langchain_huggingface import HuggingFaceEmbeddings
                return HuggingFaceEmbeddings(model_name=model_name)
            except ImportError:
                pass
            try:
                from langchain_community.embeddings import HuggingFaceEmbeddings as HFLegacy
                return HFLegacy(model_name=model_name)
            except ImportError:
                pass

        # Try OpenAI
        try:
            from langchain_openai.embeddings import OpenAIEmbeddings
            return OpenAIEmbeddings()
        except Exception:
            pass

        # Last resort: deterministic hash embeddings (no API key needed)
        from agentfoundry.vectorstores.providers.milvus_provider import _HashEmbeddings
        logger.info("FAISS: using deterministic hash embeddings (no API key needed)")
        return _HashEmbeddings(dim=config.embedding.dimensions or 384)

    def _create_in_memory_store(self):
        """Create a fresh, empty FAISS index in memory."""
        from langchain_community.vectorstores import FAISS

        t0 = time.perf_counter()
        # FAISS.from_texts with a single dummy doc is the simplest way to
        # bootstrap an empty index that can accept add_documents later.
        store = FAISS.from_texts(
            ["__init__"],
            self._embedding,
            metadatas=[{"_init": True}],
        )
        dt = int((time.perf_counter() - t0) * 1000)
        logger.info("FAISS in-memory store created in %dms", dt)
        return store

    def _load_persistent_store(self, config: AgentConfig):
        """Load a FAISS index from disk (original behaviour)."""
        from langchain_community.vectorstores import FAISS

        index_path: str = str(config.vector_store.index_path or "").strip()
        if not index_path:
            if config.data_dir:
                index_path = os.path.join(str(config.data_dir), "faiss_index")
            else:
                index_path = "./faiss_index"
        self._index_path = index_path

        if os.path.exists(index_path):
            logger.info("Loading FAISS index from %s", index_path)
            t0 = time.perf_counter()
            store = FAISS.load_local(
                index_path,
                self._embedding,
                allow_dangerous_deserialization=True,
            )
            dt = int((time.perf_counter() - t0) * 1000)
            logger.info("FAISS index loaded from %s in %dms", index_path, dt)
            return store

        logger.error("FAISS index not found at '%s'", index_path)
        raise RuntimeError(
            f"FAISS index not found at '{index_path}'. "
            "Initialize the index with real data before use, "
            "or use in_memory=True for testing."
        )

    def get_store(self, *args, **kwargs):
        logger.debug("FAISSVectorStoreProvider.get_store called")
        return self._store

    def save(self, path: Optional[str] = None) -> None:
        """Save the current index to disk.

        Args:
            path: Directory to save to.  Defaults to the configured index path.
        """
        save_path = path or self._index_path
        if save_path is None:
            logger.warning("FAISS save: no path specified and in-memory mode active; skipping")
            return
        self._store.save_local(save_path)
        logger.info("FAISS index saved to %s", save_path)

    @property
    def is_in_memory(self) -> bool:
        """Whether this provider is running in lightweight in-memory mode."""
        return self._in_memory
