"""Workflow lifecycle management for delivery wave orchestration.

Organises an :class:`ExecutionPlan` into dependency-ordered *waves* of tasks
that can execute in parallel within each wave, and provides pause / resume /
cancel / retry / replan lifecycle operations.

A :class:`WorkflowManager` is the single-threaded owner of all workflow state.
External callers interact through thread-safe lifecycle methods; the manager
stores in-memory state keyed by ``workflow_id`` so that concurrent workflows
are fully isolated.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Sequence

from agentfoundry.agents.architect import ExecutionPlan, SubTask
from agentfoundry.tracing.active import trace_span

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Status enums
# ---------------------------------------------------------------------------

class WorkflowStatus(str, Enum):
    """Top-level lifecycle state of a workflow."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class WaveTaskStatus(str, Enum):
    """Execution state of an individual task within a wave."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class WaveTask:
    """A single task within a delivery wave."""
    task_id: str
    subtask: SubTask
    status: WaveTaskStatus = WaveTaskStatus.PENDING
    result: str = ""
    error: str = ""
    attempts: int = 0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "description": self.subtask.description,
            "tool_names": self.subtask.tool_names,
            "status": self.status.value,
            "result": self.result[:200] if self.result else "",
            "error": self.error,
            "attempts": self.attempts,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


@dataclass
class Wave:
    """A group of tasks with no inter-dependencies that can run in parallel."""
    wave_index: int
    tasks: List[WaveTask] = field(default_factory=list)

    @property
    def status(self) -> WaveTaskStatus:
        statuses = {t.status for t in self.tasks}
        if statuses == {WaveTaskStatus.COMPLETED}:
            return WaveTaskStatus.COMPLETED
        if WaveTaskStatus.FAILED in statuses:
            return WaveTaskStatus.FAILED
        if WaveTaskStatus.RUNNING in statuses:
            return WaveTaskStatus.RUNNING
        if statuses == {WaveTaskStatus.SKIPPED}:
            return WaveTaskStatus.SKIPPED
        return WaveTaskStatus.PENDING

    def to_dict(self) -> Dict[str, Any]:
        return {
            "wave_index": self.wave_index,
            "status": self.status.value,
            "tasks": [t.to_dict() for t in self.tasks],
        }


@dataclass
class Workflow:
    """Full workflow state including all waves and metadata."""
    workflow_id: str
    goal: str
    status: WorkflowStatus = WorkflowStatus.PENDING
    waves: List[Wave] = field(default_factory=list)
    current_wave_index: int = 0
    config: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    original_task: str = ""
    plan: Optional[ExecutionPlan] = None
    plan_versions: List[Dict[str, Any]] = field(default_factory=list)

    def _touch(self) -> None:
        self.updated_at = time.time()

    def _snapshot_plan(self, reason: str = "") -> None:
        """Record a snapshot of the current plan for auditability."""
        version = len(self.plan_versions) + 1
        task_ids = []
        if self.plan:
            task_ids = [t.id for t in self.plan.tasks]
        self.plan_versions.append({
            "version": version,
            "timestamp": time.time(),
            "reason": reason or "initial",
            "task_ids": task_ids,
            "goal": self.goal,
            "total_tasks": len(task_ids),
        })

    def to_dict(self) -> Dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "goal": self.goal,
            "status": self.status.value,
            "current_wave_index": self.current_wave_index,
            "total_waves": len(self.waves),
            "waves": [w.to_dict() for w in self.waves],
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "plan_version_count": len(self.plan_versions),
        }


# ---------------------------------------------------------------------------
# Wave builder — topological sort of SubTasks into dependency waves
# ---------------------------------------------------------------------------

def build_waves(plan: ExecutionPlan) -> List[Wave]:
    """Partition an execution plan into dependency-ordered delivery waves.

    Tasks with no unmet dependencies land in wave 0.  Tasks whose
    dependencies are all satisfied by wave *N* land in wave *N+1*.
    """
    tasks = plan.tasks
    if not tasks:
        logger.warning("build_waves called with an empty plan; returning no waves.")
        return []

    task_map: Dict[str, SubTask] = {t.id: t for t in tasks}
    in_degree: Dict[str, int] = {t.id: 0 for t in tasks}
    dependents: Dict[str, List[str]] = defaultdict(list)

    for t in tasks:
        for dep_id in t.depends_on:
            if dep_id in task_map:
                in_degree[t.id] += 1
                dependents[dep_id].append(t.id)

    # BFS / Kahn's algorithm layered by wave
    waves: List[Wave] = []
    ready = deque(tid for tid, deg in in_degree.items() if deg == 0)
    assigned: set[str] = set()
    wave_idx = 0

    while ready:
        wave_tasks: List[WaveTask] = []
        next_ready: List[str] = []

        while ready:
            tid = ready.popleft()
            if tid in assigned:
                continue
            assigned.add(tid)
            wave_tasks.append(WaveTask(task_id=tid, subtask=task_map[tid]))

            for child in dependents.get(tid, []):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    next_ready.append(child)

        if wave_tasks:
            waves.append(Wave(wave_index=wave_idx, tasks=wave_tasks))
            logger.info(
                "Wave %d: %d task(s) — [%s]",
                wave_idx, len(wave_tasks),
                ", ".join(wt.task_id for wt in wave_tasks),
            )
            wave_idx += 1

        ready.extend(next_ready)

    # Detect cycles — any unassigned tasks have circular dependencies
    unassigned = set(task_map.keys()) - assigned
    if unassigned:
        logger.error(
            "Dependency cycle detected among tasks: %s. "
            "Placing them in a final wave to avoid deadlock.",
            sorted(unassigned),
        )
        fallback = Wave(
            wave_index=wave_idx,
            tasks=[WaveTask(task_id=tid, subtask=task_map[tid]) for tid in sorted(unassigned)],
        )
        waves.append(fallback)

    logger.info("Built %d wave(s) from %d task(s).", len(waves), len(tasks))
    return waves


# ---------------------------------------------------------------------------
# WorkflowManager
# ---------------------------------------------------------------------------

class WorkflowManager:
    """Thread-safe manager for workflow lifecycle operations.

    Each workflow is identified by a ``workflow_id`` and progresses through
    waves of tasks.  The manager exposes lifecycle methods that can be called
    from API endpoints or programmatically.

    Parameters
    ----------
    task_executor : callable, optional
        A function ``(WaveTask, config) -> str`` that runs a single task and
        returns its result.  When ``None``, tasks are marked complete with an
        empty result (useful for testing).
    plan_builder : callable, optional
        A function ``(task_description, tools_desc) -> ExecutionPlan`` used by
        :meth:`replan`.  Typically ``AgentArchitect.plan_task``.
    """

    def __init__(
        self,
        task_executor: Optional[Callable] = None,
        plan_builder: Optional[Callable] = None,
    ) -> None:
        self._workflows: Dict[str, Workflow] = {}
        self._lock = threading.Lock()
        self._task_executor = task_executor
        self._plan_builder = plan_builder
        logger.info("WorkflowManager initialised.")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_workflow(self, workflow_id: str) -> Workflow:
        wf = self._workflows.get(workflow_id)
        if wf is None:
            logger.warning("Workflow '%s' not found.", workflow_id)
            raise KeyError(f"Workflow '{workflow_id}' not found.")
        return wf

    # ------------------------------------------------------------------
    # Create
    # ------------------------------------------------------------------

    def create_workflow(
        self,
        plan: ExecutionPlan,
        config: Optional[Dict[str, Any]] = None,
        original_task: str = "",
    ) -> Workflow:
        """Build a new workflow from an execution plan."""
        workflow_id = uuid.uuid4().hex
        waves = build_waves(plan)

        wf = Workflow(
            workflow_id=workflow_id,
            goal=plan.goal,
            waves=waves,
            config=config or {},
            original_task=original_task,
            plan=plan,
        )

        wf._snapshot_plan("initial")

        with self._lock:
            self._workflows[workflow_id] = wf

        logger.info(
            "Created workflow %s: goal='%s' waves=%d tasks=%d",
            workflow_id[:12], plan.goal[:60], len(waves),
            sum(len(w.tasks) for w in waves),
        )
        return wf

    # ------------------------------------------------------------------
    # Run (execute current + subsequent waves)
    # ------------------------------------------------------------------

    def run(self, workflow_id: str) -> Workflow:
        """Execute the workflow from the current wave onward.

        Respects pause / cancel signals between waves.
        """
        wf = self._get_workflow(workflow_id)

        if wf.status == WorkflowStatus.CANCELLED:
            logger.warning("Cannot run cancelled workflow %s.", workflow_id[:12])
            raise ValueError(f"Workflow '{workflow_id}' has been cancelled.")
        if wf.status == WorkflowStatus.COMPLETED:
            logger.info("Workflow %s already completed.", workflow_id[:12])
            return wf

        wf.status = WorkflowStatus.RUNNING
        wf._touch()
        logger.info(
            "Starting workflow %s from wave %d/%d.",
            workflow_id[:12], wf.current_wave_index, len(wf.waves),
        )

        while wf.current_wave_index < len(wf.waves):
            # Check for pause / cancel before each wave
            if wf.status == WorkflowStatus.PAUSED:
                logger.info(
                    "Workflow %s paused before wave %d.",
                    workflow_id[:12], wf.current_wave_index,
                )
                return wf
            if wf.status == WorkflowStatus.CANCELLED:
                logger.info(
                    "Workflow %s cancelled before wave %d.",
                    workflow_id[:12], wf.current_wave_index,
                )
                self._skip_remaining(wf)
                return wf

            wave = wf.waves[wf.current_wave_index]
            logger.info(
                "Workflow %s executing wave %d (%d tasks).",
                workflow_id[:12], wave.wave_index, len(wave.tasks),
            )

            self._execute_wave(wf, wave)

            if wave.status == WaveTaskStatus.FAILED:
                wf.status = WorkflowStatus.FAILED
                wf._touch()
                logger.error(
                    "Workflow %s failed at wave %d.",
                    workflow_id[:12], wave.wave_index,
                )
                return wf

            wf.current_wave_index += 1
            wf._touch()

        wf.status = WorkflowStatus.COMPLETED
        wf._touch()
        logger.info("Workflow %s completed all %d waves.", workflow_id[:12], len(wf.waves))
        return wf

    def _execute_wave(self, wf: Workflow, wave: Wave) -> None:
        """Execute all pending/failed tasks in a wave."""
        with trace_span("wave", "workflow", {"wave_index": wave.wave_index, "task_count": len(wave.tasks)}) as _:
            for task in wave.tasks:
                if task.status in (WaveTaskStatus.COMPLETED, WaveTaskStatus.SKIPPED):
                    logger.debug(
                        "Skipping task %s (already %s).", task.task_id, task.status.value,
                    )
                    continue

                # Check for pause / cancel between tasks
                if wf.status == WorkflowStatus.PAUSED:
                    logger.info("Workflow %s paused during wave %d.", wf.workflow_id[:12], wave.wave_index)
                    return
                if wf.status == WorkflowStatus.CANCELLED:
                    logger.info("Workflow %s cancelled during wave %d.", wf.workflow_id[:12], wave.wave_index)
                    return

                task.status = WaveTaskStatus.RUNNING
                task.started_at = time.time()
                task.attempts += 1
                logger.info(
                    "Task %s RUNNING (attempt %d): %s",
                    task.task_id, task.attempts, task.subtask.description[:80],
                )

                with trace_span("wave_task", "workflow", {"task_id": task.task_id, "attempt": task.attempts}) as task_span:
                    try:
                        if self._task_executor:
                            task.result = self._task_executor(task, wf.config)
                        task.status = WaveTaskStatus.COMPLETED
                        task.completed_at = time.time()
                        elapsed_ms = int((task.completed_at - task.started_at) * 1000)
                        if task_span:
                            task_span.attributes["elapsed_ms"] = elapsed_ms
                            task_span.attributes["result_chars"] = len(task.result)
                        logger.info(
                            "Task %s COMPLETED in %dms (attempt %d).",
                            task.task_id, elapsed_ms, task.attempts,
                        )
                    except Exception as exc:
                        task.status = WaveTaskStatus.FAILED
                        task.error = str(exc)
                        task.completed_at = time.time()
                        elapsed_ms = int((task.completed_at - task.started_at) * 1000)
                        if task_span:
                            task_span.set_error(str(exc))
                            task_span.attributes["elapsed_ms"] = elapsed_ms
                        logger.error(
                            "Task %s FAILED in %dms (attempt %d): %s",
                            task.task_id, elapsed_ms, task.attempts, exc,
                            exc_info=True,
                        )

    def _skip_remaining(self, wf: Workflow) -> None:
        """Mark all pending tasks in current and future waves as SKIPPED."""
        skipped = 0
        for wave in wf.waves[wf.current_wave_index:]:
            for task in wave.tasks:
                if task.status in (WaveTaskStatus.PENDING, WaveTaskStatus.RUNNING):
                    task.status = WaveTaskStatus.SKIPPED
                    skipped += 1
        if skipped:
            logger.info("Skipped %d remaining task(s) in workflow %s.", skipped, wf.workflow_id[:12])

    # ------------------------------------------------------------------
    # Lifecycle: Pause
    # ------------------------------------------------------------------

    def pause(self, workflow_id: str) -> Workflow:
        """Pause a running workflow.  In-progress tasks finish; no new tasks start."""
        wf = self._get_workflow(workflow_id)
        if wf.status != WorkflowStatus.RUNNING:
            logger.warning(
                "Cannot pause workflow %s in state '%s'.",
                workflow_id[:12], wf.status.value,
            )
            raise ValueError(
                f"Cannot pause workflow in state '{wf.status.value}'. "
                f"Only RUNNING workflows can be paused."
            )
        wf.status = WorkflowStatus.PAUSED
        wf._touch()
        logger.info(
            "Workflow %s PAUSED at wave %d/%d.",
            workflow_id[:12], wf.current_wave_index, len(wf.waves),
        )
        return wf

    # ------------------------------------------------------------------
    # Lifecycle: Resume
    # ------------------------------------------------------------------

    def resume(self, workflow_id: str) -> Workflow:
        """Resume a paused workflow from where it left off."""
        wf = self._get_workflow(workflow_id)
        if wf.status != WorkflowStatus.PAUSED:
            logger.warning(
                "Cannot resume workflow %s in state '%s'.",
                workflow_id[:12], wf.status.value,
            )
            raise ValueError(
                f"Cannot resume workflow in state '{wf.status.value}'. "
                f"Only PAUSED workflows can be resumed."
            )
        logger.info(
            "Resuming workflow %s from wave %d/%d.",
            workflow_id[:12], wf.current_wave_index, len(wf.waves),
        )
        return self.run(workflow_id)

    # ------------------------------------------------------------------
    # Lifecycle: Cancel
    # ------------------------------------------------------------------

    def cancel(self, workflow_id: str) -> Workflow:
        """Cancel a workflow.  Remaining tasks are marked SKIPPED."""
        wf = self._get_workflow(workflow_id)
        terminal = {WorkflowStatus.COMPLETED, WorkflowStatus.CANCELLED}
        if wf.status in terminal:
            logger.warning(
                "Cannot cancel workflow %s in terminal state '%s'.",
                workflow_id[:12], wf.status.value,
            )
            raise ValueError(
                f"Cannot cancel workflow in state '{wf.status.value}'."
            )
        wf.status = WorkflowStatus.CANCELLED
        wf._touch()
        self._skip_remaining(wf)
        logger.info("Workflow %s CANCELLED.", workflow_id[:12])
        return wf

    # ------------------------------------------------------------------
    # Lifecycle: Retry
    # ------------------------------------------------------------------

    def retry(self, workflow_id: str, wave_index: Optional[int] = None) -> Workflow:
        """Retry failed tasks in a specific wave (default: current wave).

        Resets failed tasks back to PENDING and re-runs the workflow from
        the target wave.
        """
        wf = self._get_workflow(workflow_id)
        if wf.status not in (WorkflowStatus.FAILED, WorkflowStatus.PAUSED):
            logger.warning(
                "Cannot retry workflow %s in state '%s'.",
                workflow_id[:12], wf.status.value,
            )
            raise ValueError(
                f"Cannot retry workflow in state '{wf.status.value}'. "
                f"Only FAILED or PAUSED workflows can be retried."
            )

        target = wave_index if wave_index is not None else wf.current_wave_index
        if target < 0 or target >= len(wf.waves):
            raise ValueError(
                f"Wave index {target} out of range (0..{len(wf.waves) - 1})."
            )

        wave = wf.waves[target]
        reset_count = 0
        for task in wave.tasks:
            if task.status == WaveTaskStatus.FAILED:
                task.status = WaveTaskStatus.PENDING
                task.error = ""
                reset_count += 1

        wf.current_wave_index = target
        wf._touch()
        logger.info(
            "Retrying workflow %s: reset %d failed task(s) in wave %d.",
            workflow_id[:12], reset_count, target,
        )

        return self.run(workflow_id)

    # ------------------------------------------------------------------
    # Lifecycle: Replan
    # ------------------------------------------------------------------

    def replan(
        self,
        workflow_id: str,
        feedback: str = "",
        tools_desc: str = "",
    ) -> Workflow:
        """Regenerate the execution plan from the current state and feedback.

        Requires a ``plan_builder`` to have been provided at construction.
        Completed waves are preserved; remaining waves are replaced with a
        fresh plan.
        """
        wf = self._get_workflow(workflow_id)
        if self._plan_builder is None:
            raise RuntimeError(
                "Cannot replan: no plan_builder was provided to WorkflowManager."
            )
        if wf.status in (WorkflowStatus.COMPLETED, WorkflowStatus.CANCELLED):
            raise ValueError(
                f"Cannot replan workflow in terminal state '{wf.status.value}'."
            )

        # Gather completed results as context for replanning
        completed_context = []
        for wave in wf.waves[:wf.current_wave_index]:
            for task in wave.tasks:
                if task.status == WaveTaskStatus.COMPLETED and task.result:
                    completed_context.append(
                        f"[{task.task_id}] {task.subtask.description}: {task.result[:200]}"
                    )

        replan_task = wf.original_task or wf.goal
        if completed_context:
            replan_task += "\n\nAlready completed:\n" + "\n".join(completed_context)
        if feedback:
            replan_task += f"\n\nFeedback: {feedback}"

        logger.info(
            "Replanning workflow %s from wave %d with %d completed results and feedback=%d chars.",
            workflow_id[:12], wf.current_wave_index,
            len(completed_context), len(feedback),
        )

        try:
            new_plan = self._plan_builder(replan_task, tools_desc)
        except Exception:
            logger.exception("Replanning failed for workflow %s.", workflow_id[:12])
            raise

        new_waves = build_waves(new_plan)

        # Preserve completed waves, replace remaining
        preserved = wf.waves[:wf.current_wave_index]
        for i, nw in enumerate(new_waves):
            nw.wave_index = len(preserved) + i

        wf.waves = preserved + new_waves
        wf.plan = new_plan
        wf.goal = new_plan.goal
        wf.status = WorkflowStatus.PENDING
        wf._touch()
        wf._snapshot_plan(f"full_replan (feedback={len(feedback)} chars)")

        logger.info(
            "Replanned workflow %s: preserved %d wave(s), added %d new wave(s) (%d total tasks).",
            workflow_id[:12], len(preserved), len(new_waves),
            sum(len(w.tasks) for w in wf.waves),
        )
        return wf

    # ------------------------------------------------------------------
    # Lifecycle: Incremental Replan (delta)
    # ------------------------------------------------------------------

    def incremental_replan(
        self,
        workflow_id: str,
        feedback: str = "",
        tools_desc: str = "",
    ) -> Workflow:
        """Replan only the failed/affected subgraph, preserving completed work.

        Unlike :meth:`replan` which regenerates everything from the current wave
        onward, incremental_replan:
        1. Identifies failed tasks and their downstream dependents
        2. Builds a focused prompt describing only what needs fixing
        3. Generates replacement tasks for just the affected subgraph
        4. Splices replacements into the existing plan

        Requires a ``plan_builder`` to have been provided at construction.
        """
        from agentfoundry.agents.delta_planner import (
            compute_delta, apply_delta,
        )

        wf = self._get_workflow(workflow_id)
        if wf.status in (WorkflowStatus.COMPLETED, WorkflowStatus.CANCELLED):
            raise ValueError(
                f"Cannot replan workflow in terminal state '{wf.status.value}'."
            )
        if self._plan_builder is None:
            raise RuntimeError(
                "Cannot replan: no plan_builder was provided to WorkflowManager."
            )
        if wf.plan is None:
            raise RuntimeError("Cannot incremental_replan: workflow has no plan.")

        # Gather task states from all waves
        task_statuses: Dict[str, str] = {}
        task_results: Dict[str, str] = {}
        task_errors: Dict[str, str] = {}
        for wave in wf.waves:
            for task in wave.tasks:
                task_statuses[task.task_id] = task.status.value
                if task.result:
                    task_results[task.task_id] = task.result
                if task.error:
                    task_errors[task.task_id] = task.error

        # Compute delta
        delta = compute_delta(
            wf.plan,
            task_statuses,
            task_results,
            task_errors,
            original_task=wf.original_task or wf.goal,
            feedback=feedback,
        )

        if not delta.needs_replan:
            logger.info(
                "incremental_replan: no failed tasks found in workflow %s; nothing to replan.",
                workflow_id[:12],
            )
            return wf

        logger.info(
            "incremental_replan: workflow %s delta: failed=%d affected=%d completed=%d",
            workflow_id[:12],
            len(delta.failed_task_ids),
            len(delta.affected_task_ids),
            len(delta.completed_context),
        )

        # Generate replacement plan via plan_builder using the delta prompt
        delta_prompt = delta.to_prompt()
        try:
            replacement_plan = self._plan_builder(delta_prompt, tools_desc)
        except Exception:
            logger.exception(
                "incremental_replan: plan_builder failed for workflow %s.",
                workflow_id[:12],
            )
            raise

        # Apply delta
        merged_plan, delta_result = apply_delta(wf.plan, replacement_plan, delta)
        delta_result.version = len(wf.plan_versions) + 1

        # Rebuild waves from merged plan
        new_waves = build_waves(merged_plan)

        # Transfer status of preserved tasks from old waves
        old_task_map: Dict[str, WaveTask] = {}
        for wave in wf.waves:
            for task in wave.tasks:
                old_task_map[task.task_id] = task

        for wave in new_waves:
            for task in wave.tasks:
                old = old_task_map.get(task.task_id)
                if old and old.status == WaveTaskStatus.COMPLETED:
                    task.status = old.status
                    task.result = old.result
                    task.attempts = old.attempts
                    task.started_at = old.started_at
                    task.completed_at = old.completed_at

        wf.waves = new_waves
        wf.plan = merged_plan
        wf.status = WorkflowStatus.PENDING
        # Reset current_wave_index to first wave with non-completed tasks
        wf.current_wave_index = 0
        for i, wave in enumerate(new_waves):
            if wave.status != WaveTaskStatus.COMPLETED:
                wf.current_wave_index = i
                break
        wf._touch()
        wf._snapshot_plan(
            f"incremental_replan: removed={delta_result.tasks_removed} "
            f"added={delta_result.tasks_added} preserved={delta_result.tasks_preserved}"
        )

        logger.info(
            "incremental_replan: workflow %s merged: preserved=%d removed=%d added=%d waves=%d",
            workflow_id[:12],
            delta_result.tasks_preserved,
            delta_result.tasks_removed,
            delta_result.tasks_added,
            len(new_waves),
        )
        return wf

    # ------------------------------------------------------------------
    # Lifecycle: Rollback
    # ------------------------------------------------------------------

    def rollback_task(
        self,
        workflow_id: str,
        task_ids: List[str],
    ) -> Workflow:
        """Roll back specific tasks and their downstream dependents.

        Marks the specified tasks (and anything that depends on them)
        as PENDING, allowing them to be re-executed on the next run.
        """
        from agentfoundry.agents.delta_planner import rollback_tasks

        wf = self._get_workflow(workflow_id)
        if wf.status in (WorkflowStatus.CANCELLED,):
            raise ValueError(f"Cannot rollback tasks in cancelled workflow.")
        if wf.plan is None:
            raise RuntimeError("Cannot rollback: workflow has no plan.")

        # Compute full rollback set (targets + downstream)
        rollback_set = rollback_tasks(wf.plan, task_ids)

        reset_count = 0
        earliest_wave = len(wf.waves)
        for wave in wf.waves:
            for task in wave.tasks:
                if task.task_id in rollback_set:
                    if task.status != WaveTaskStatus.PENDING:
                        task.status = WaveTaskStatus.PENDING
                        task.result = ""
                        task.error = ""
                        task.started_at = None
                        task.completed_at = None
                        reset_count += 1
                    earliest_wave = min(earliest_wave, wave.wave_index)

        if reset_count > 0:
            wf.current_wave_index = earliest_wave
            wf.status = WorkflowStatus.PENDING
            wf._touch()
            wf._snapshot_plan(
                f"rollback: reset {reset_count} task(s) from {sorted(task_ids)}"
            )

        logger.info(
            "rollback_task: workflow %s reset %d task(s) (requested=%d downstream=%d) "
            "earliest_wave=%d",
            workflow_id[:12], reset_count, len(task_ids),
            len(rollback_set) - len(task_ids), earliest_wave,
        )
        return wf

    # ------------------------------------------------------------------
    # Query: Plan History
    # ------------------------------------------------------------------

    def get_plan_history(self, workflow_id: str) -> List[Dict[str, Any]]:
        """Return the plan version history for a workflow."""
        wf = self._get_workflow(workflow_id)
        return list(wf.plan_versions)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_status(self, workflow_id: str) -> Dict[str, Any]:
        """Return the full workflow state as a serialisable dict."""
        wf = self._get_workflow(workflow_id)
        return wf.to_dict()

    def list_workflows(self) -> List[Dict[str, Any]]:
        """Return summary info for all tracked workflows."""
        summaries = []
        for wf in self._workflows.values():
            summaries.append({
                "workflow_id": wf.workflow_id,
                "goal": wf.goal[:80],
                "status": wf.status.value,
                "current_wave_index": wf.current_wave_index,
                "total_waves": len(wf.waves),
                "created_at": wf.created_at,
            })
        return summaries
