"""Role-specific tool manifests for deterministic specialist agents."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Sequence


@dataclass(frozen=True)
class SpecialistToolManifest:
    role: str
    summary: str
    allowed_tools: tuple[str, ...]
    authority_level: str = "read_only"
    allowed_action_classes: tuple[str, ...] = ("read",)
    approval_required_actions: tuple[str, ...] = ()
    required_inputs: tuple[str, ...] = ()
    environment_requirements: tuple[str, ...] = ()
    max_recursion: int = 12

    @property
    def allow_shell(self) -> bool:
        return "shell_command" in self.allowed_tools

    @property
    def allow_write(self) -> bool:
        return False


SPECIALIST_TOOL_MANIFESTS: Dict[str, SpecialistToolManifest] = {
    "code_review": SpecialistToolManifest(
        role="code_review",
        summary="Static review of source files and snippets for defects and maintainability risks.",
        allowed_tools=("code_analysis", "code_explorer"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("python_paths_or_code_blocks",),
        environment_requirements=("repository_access",),
        max_recursion=10,
    ),
    "testing": SpecialistToolManifest(
        role="testing",
        summary="Focused automated test execution and failure summarization.",
        allowed_tools=("shell_command", "code_explorer", "system_introspection"),
        authority_level="quality_gate",
        allowed_action_classes=("read", "build"),
        approval_required_actions=("build",),
        required_inputs=("test_commands_or_test_paths",),
        environment_requirements=("test_runtime",),
        max_recursion=15,
    ),
    "debugging": SpecialistToolManifest(
        role="debugging",
        summary="Root-cause investigation using tracebacks, source inspection, and safe repro commands.",
        allowed_tools=("code_analysis", "code_explorer", "shell_command"),
        authority_level="quality_gate",
        allowed_action_classes=("read", "build"),
        approval_required_actions=("build",),
        required_inputs=("traceback_or_failure_context",),
        environment_requirements=("repository_access",),
        max_recursion=15,
    ),
    "requirements": SpecialistToolManifest(
        role="requirements",
        summary="Requirement and acceptance-criteria extraction from task text and source documents.",
        allowed_tools=("document_reader", "code_explorer", "system_introspection"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("requirement_docs_or_task_text",),
        environment_requirements=("document_access",),
    ),
    "codebase_analysis": SpecialistToolManifest(
        role="codebase_analysis",
        summary="Onboarding analysis of an existing codebase, repo topology, frameworks, and hotspots.",
        allowed_tools=("code_explorer", "code_analysis", "document_reader", "system_introspection"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("repository_paths_or_root",),
        environment_requirements=("repository_access",),
        max_recursion=14,
    ),
    "architecture": SpecialistToolManifest(
        role="architecture",
        summary="Architecture inspection using repo topology, code structure, and design signals.",
        allowed_tools=("code_explorer", "code_analysis", "system_introspection"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("module_paths_or_repo_context",),
        environment_requirements=("repository_access",),
    ),
    "backend": SpecialistToolManifest(
        role="backend",
        summary="Backend delivery analysis of APIs, services, and data-model surfaces.",
        allowed_tools=("code_analysis", "code_explorer", "system_introspection"),
        authority_level="propose_changes",
        allowed_action_classes=("read", "write", "build"),
        approval_required_actions=("write", "build"),
        required_inputs=("backend_module_paths",),
        environment_requirements=("repository_access",),
    ),
    "frontend": SpecialistToolManifest(
        role="frontend",
        summary="Frontend delivery analysis of routes, pages, components, and UX risks.",
        allowed_tools=("code_explorer", "document_reader", "system_introspection"),
        authority_level="propose_changes",
        allowed_action_classes=("read", "write", "build"),
        approval_required_actions=("write", "build"),
        required_inputs=("frontend_paths_or_design_docs",),
        environment_requirements=("repository_access",),
    ),
    "integration": SpecialistToolManifest(
        role="integration",
        summary="Integration analysis of external clients, adapters, queues, and dependency contracts.",
        allowed_tools=("code_analysis", "code_explorer", "document_reader", "system_introspection"),
        authority_level="propose_changes",
        allowed_action_classes=("read", "write", "build"),
        approval_required_actions=("write", "build"),
        required_inputs=("integration_paths_or_contract_artifacts",),
        environment_requirements=("repository_access",),
    ),
    "data_engineering": SpecialistToolManifest(
        role="data_engineering",
        summary="Data engineering analysis of schemas, migrations, ETL jobs, and data-pipeline changes.",
        allowed_tools=("code_analysis", "code_explorer", "document_reader", "system_introspection"),
        authority_level="propose_changes",
        allowed_action_classes=("read", "write", "build"),
        approval_required_actions=("write", "build"),
        required_inputs=("schema_or_migration_artifacts",),
        environment_requirements=("repository_access",),
    ),
    "contract": SpecialistToolManifest(
        role="contract",
        summary="Contract compatibility analysis for APIs, schemas, events, DTOs, and published interfaces.",
        allowed_tools=("code_analysis", "code_explorer", "document_reader", "system_introspection", "code_graph_search"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("contract_or_interface_artifacts",),
        environment_requirements=("repository_access", "code_graph"),
    ),
    "platform_operations": SpecialistToolManifest(
        role="platform_operations",
        summary="Operational analysis of deployment manifests, runtime assumptions, and rollout safeguards.",
        allowed_tools=("code_explorer", "document_reader", "system_introspection", "shell_command"),
        authority_level="release_ops",
        allowed_action_classes=("read", "build", "deploy"),
        approval_required_actions=("build", "deploy"),
        required_inputs=("deployment_or_runtime_artifacts",),
        environment_requirements=("repository_access", "runtime_or_cluster_context"),
    ),
    "release": SpecialistToolManifest(
        role="release",
        summary="Release readiness analysis for packaging, promotion, commands, and rollback preparation.",
        allowed_tools=("code_explorer", "shell_command", "system_introspection"),
        authority_level="release_ops",
        allowed_action_classes=("read", "build", "deploy"),
        approval_required_actions=("build", "deploy"),
        required_inputs=("release_artifacts_or_commands",),
        environment_requirements=("build_runtime",),
    ),
    "security_compliance": SpecialistToolManifest(
        role="security_compliance",
        summary="Security and compliance inspection of code, configuration, and transport assumptions.",
        allowed_tools=("code_analysis", "code_explorer", "system_introspection"),
        authority_level="read_only",
        allowed_action_classes=("read",),
        required_inputs=("source_or_config_paths",),
        environment_requirements=("repository_access",),
    ),
}


def get_specialist_manifest(role: str) -> SpecialistToolManifest | None:
    return SPECIALIST_TOOL_MANIFESTS.get(str(role or "").strip())


def manifest_allowed_tools(role: str) -> tuple[str, ...]:
    manifest = get_specialist_manifest(role)
    return manifest.allowed_tools if manifest else ()


def list_specialist_manifests() -> list[dict[str, object]]:
    return [
        {
            "role": manifest.role,
            "summary": manifest.summary,
            "allowed_tools": list(manifest.allowed_tools),
            "authority_level": manifest.authority_level,
            "allowed_action_classes": list(manifest.allowed_action_classes),
            "approval_required_actions": list(manifest.approval_required_actions),
            "required_inputs": list(manifest.required_inputs),
            "environment_requirements": list(manifest.environment_requirements),
            "max_recursion": manifest.max_recursion,
            "allow_shell": manifest.allow_shell,
            "allow_write": manifest.allow_write,
        }
        for manifest in SPECIALIST_TOOL_MANIFESTS.values()
    ]
