import logging
import time
from typing import List
from pydantic import BaseModel, Field
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from agentfoundry.tracing.active import trace_span

logger = logging.getLogger(__name__)

class SubTask(BaseModel):
    id: str = Field(..., description="Unique identifier for the subtask (e.g., 'task_1')")
    description: str = Field(..., description="Description of what this subtask does")
    tool_names: List[str] = Field(..., description="List of exact tool names required for this subtask")
    system_prompt: str = Field(..., description="Specialized system prompt for the agent executing this subtask")
    depends_on: List[str] = Field(default_factory=list, description="List of task IDs that must complete before this one starts")

class ExecutionPlan(BaseModel):
    goal: str = Field(..., description="The overall goal of the execution plan")
    tasks: List[SubTask] = Field(..., description="List of subtasks to execute")

class AgentArchitect:
    """
    Analyzing user requests to generate execution plans with specialized agents.
    """
    
    def __init__(self, llm):
        self.llm = llm
        self.parser = PydanticOutputParser(pydantic_object=ExecutionPlan)
        self._model_name = getattr(llm, 'model_name', getattr(llm, 'model', type(llm).__name__))
        logger.info("AgentArchitect initialized with LLM=%s", self._model_name)

    def plan_task(self, task_description: str, available_tools_desc: str) -> ExecutionPlan:
        """
        Generates a structured execution plan for the given task.
        """
        logger.info("Architect planning: task_chars=%d tools_desc_chars=%d", len(task_description), len(available_tools_desc))
        logger.debug("Architect task preview: %s", task_description[:120])
        
        system_template = """You are an expert AI Agent Architect.
Your goal is to analyze a user request and break it down into a set of efficient subtasks.
For each subtask, you must:
1. Identify the specific tools needed from the available list.
2. Write a specialized system prompt for the sub-agent that will execute this task.
3. Determine dependencies to enable parallel execution where possible.

AVAILABLE TOOLS:
{tools_desc}

GUIDELINES:
- CRITICAL: You MUST ALWAYS respond with valid JSON matching the schema below. Never respond with plain text.
- Be precise with tool names. Only use provided tools.
- Never invent tool names. Use exact names from AVAILABLE TOOLS only.
- Keep system prompts focused on the specific subtask.
- If a task depends on the output of another, list it in 'depends_on'.
- If tasks are independent, leave 'depends_on' empty to allow parallel execution.
- If the request is simple (single step), create a plan with just one task.
- For simple conversational questions that need no tools (e.g. greetings, personal questions, general knowledge), create a single task with "tool_names": [] and a system prompt instructing the agent to answer directly from context.
- If pre-fetched/injected context already contains enough information to answer, prefer a single task with "tool_names": [].

{format_instructions}
"""
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_template),
            ("human", "{task}")
        ])
        
        formatted_prompt = prompt.format_messages(
            tools_desc=available_tools_desc,
            task=task_description,
            format_instructions=self.parser.get_format_instructions()
        )
        
        t0 = time.perf_counter()
        with trace_span("architect_llm_invoke", "llm", {"model": self._model_name}) as llm_span:
            response = self.llm.invoke(formatted_prompt)
        dt = int((time.perf_counter() - t0) * 1000)
        if llm_span:
            llm_span.attributes["duration_ms"] = dt
            llm_span.attributes["response_chars"] = len(response.content or "")
            # Extract token usage if available
            usage = getattr(response, "usage_metadata", None) or {}
            if isinstance(usage, dict):
                for k in ("prompt_tokens", "completion_tokens", "total_tokens",
                           "input_tokens", "output_tokens"):
                    if k in usage:
                        llm_span.attributes[k] = usage[k]
        logger.info("Architect LLM invoke completed in %dms, response_chars=%d", dt, len(response.content or ""))
        try:
            plan = self.parser.parse(response.content)
            logger.info(
                "Architect plan: goal=%s tasks=%d tool_names=%s",
                plan.goal[:60], len(plan.tasks),
                [t.tool_names for t in plan.tasks],
            )
            return plan
        except Exception as e:
            logger.error("Failed to parse execution plan: %s", e)
            logger.debug("Raw response: %s", response.content[:500])
            raise e
