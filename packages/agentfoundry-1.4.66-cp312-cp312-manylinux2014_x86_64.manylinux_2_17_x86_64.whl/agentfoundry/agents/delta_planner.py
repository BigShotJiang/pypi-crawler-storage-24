"""Incremental (delta) replanning for workflows.

Instead of regenerating the entire plan from scratch, the delta planner:
1. Analyses the current workflow to identify failed/stale tasks
2. Computes the downstream dependency subgraph affected by failures
3. Asks the plan_builder to generate only replacement tasks for the subgraph
4. Splices replacements into the existing plan, preserving completed work

Also supports task rollback and plan version history.
"""

from __future__ import annotations

import copy
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

from agentfoundry.agents.architect import ExecutionPlan, SubTask

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Plan version history
# ---------------------------------------------------------------------------

@dataclass
class PlanVersion:
    """Snapshot of a plan at a point in time."""

    version: int
    timestamp: float = field(default_factory=time.time)
    reason: str = ""
    task_ids: List[str] = field(default_factory=list)
    goal: str = ""
    total_tasks: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "timestamp": self.timestamp,
            "reason": reason if (reason := self.reason) else "initial",
            "task_ids": self.task_ids,
            "goal": self.goal,
            "total_tasks": self.total_tasks,
        }


# ---------------------------------------------------------------------------
# Delta context — describes what needs replanning
# ---------------------------------------------------------------------------

@dataclass
class DeltaContext:
    """Captures the parts of a workflow that need attention."""

    failed_task_ids: List[str] = field(default_factory=list)
    failed_descriptions: List[str] = field(default_factory=list)
    failed_errors: List[str] = field(default_factory=list)
    affected_task_ids: List[str] = field(default_factory=list)
    completed_context: List[str] = field(default_factory=list)
    original_task: str = ""
    goal: str = ""
    feedback: str = ""

    @property
    def needs_replan(self) -> bool:
        return bool(self.failed_task_ids)

    def to_prompt(self) -> str:
        """Build the prompt for the plan_builder, scoped to the delta."""
        parts = [self.original_task or self.goal]

        if self.completed_context:
            parts.append("\n\nAlready completed successfully:")
            parts.extend(f"  - {c}" for c in self.completed_context)

        if self.failed_descriptions:
            parts.append("\n\nThe following subtasks FAILED and need replacement plans:")
            for desc, err in zip(self.failed_descriptions, self.failed_errors):
                parts.append(f"  - {desc}")
                if err:
                    parts.append(f"    Error: {err[:200]}")

        if self.affected_task_ids:
            parts.append(
                f"\n\nDownstream tasks that could not run due to failures: "
                f"{', '.join(self.affected_task_ids)}"
            )

        if self.feedback:
            parts.append(f"\n\nAdditional feedback: {self.feedback}")

        parts.append(
            "\n\nGenerate ONLY replacement tasks for the failed/affected items. "
            "Do NOT regenerate tasks that already completed."
        )
        return "\n".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "failed_task_ids": self.failed_task_ids,
            "affected_task_ids": self.affected_task_ids,
            "completed_count": len(self.completed_context),
            "needs_replan": self.needs_replan,
        }


# ---------------------------------------------------------------------------
# Delta analysis
# ---------------------------------------------------------------------------

def compute_affected_subgraph(
    tasks: List[SubTask],
    failed_ids: Set[str],
) -> Set[str]:
    """Find all tasks downstream of the failed tasks.

    A task is "affected" if any of its transitive dependencies failed.
    Uses BFS from failed nodes through the dependency graph.
    """
    # Build forward dependency map: task_id → set of tasks that depend on it
    dependents: Dict[str, List[str]] = defaultdict(list)
    task_ids = {t.id for t in tasks}
    for t in tasks:
        for dep in t.depends_on:
            if dep in task_ids:
                dependents[dep].append(t.id)

    affected: Set[str] = set()
    queue = list(failed_ids & task_ids)
    while queue:
        tid = queue.pop(0)
        for child in dependents.get(tid, []):
            if child not in affected and child not in failed_ids:
                affected.add(child)
                queue.append(child)

    return affected


def compute_delta(
    plan: ExecutionPlan,
    task_statuses: Dict[str, str],
    task_results: Dict[str, str],
    task_errors: Dict[str, str],
    original_task: str = "",
    feedback: str = "",
) -> DeltaContext:
    """Analyze a workflow's task states and compute a delta context.

    Args:
        plan: The current execution plan.
        task_statuses: {task_id: status_value} for all tasks.
        task_results: {task_id: result_text} for completed tasks.
        task_errors: {task_id: error_text} for failed tasks.
        original_task: The original user request.
        feedback: Additional feedback for replanning.

    Returns:
        DeltaContext describing what needs to be replanned.
    """
    failed_ids: Set[str] = set()
    failed_descriptions: List[str] = []
    failed_errors: List[str] = []
    completed_context: List[str] = []

    task_map = {t.id: t for t in plan.tasks}

    for tid, status in task_statuses.items():
        if status == "failed":
            failed_ids.add(tid)
            desc = task_map[tid].description if tid in task_map else tid
            failed_descriptions.append(desc)
            failed_errors.append(task_errors.get(tid, ""))
        elif status == "completed":
            desc = task_map[tid].description if tid in task_map else tid
            result = task_results.get(tid, "")
            completed_context.append(
                f"[{tid}] {desc}: {result[:200]}" if result else f"[{tid}] {desc}"
            )

    affected = compute_affected_subgraph(plan.tasks, failed_ids)

    return DeltaContext(
        failed_task_ids=sorted(failed_ids),
        failed_descriptions=failed_descriptions,
        failed_errors=failed_errors,
        affected_task_ids=sorted(affected),
        completed_context=completed_context,
        original_task=original_task,
        goal=plan.goal,
        feedback=feedback,
    )


# ---------------------------------------------------------------------------
# Delta plan application
# ---------------------------------------------------------------------------

@dataclass
class DeltaResult:
    """Result of applying a delta plan."""

    tasks_removed: int = 0
    tasks_added: int = 0
    tasks_preserved: int = 0
    version: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tasks_removed": self.tasks_removed,
            "tasks_added": self.tasks_added,
            "tasks_preserved": self.tasks_preserved,
            "version": self.version,
        }


def apply_delta(
    current_plan: ExecutionPlan,
    replacement_plan: ExecutionPlan,
    delta_context: DeltaContext,
) -> tuple[ExecutionPlan, DeltaResult]:
    """Splice replacement tasks into the current plan.

    - Tasks that completed successfully are preserved.
    - Failed tasks and their affected downstream tasks are removed.
    - Replacement tasks from the new plan are inserted.
    - Dependencies in replacement tasks that reference completed tasks
      are left intact; references to removed tasks are dropped.

    Args:
        current_plan: The existing plan.
        replacement_plan: New plan generated for the failed subgraph.
        delta_context: The delta analysis.

    Returns:
        Tuple of (merged ExecutionPlan, DeltaResult).
    """
    remove_ids = set(delta_context.failed_task_ids) | set(delta_context.affected_task_ids)

    # Preserve non-removed tasks
    preserved: List[SubTask] = []
    for task in current_plan.tasks:
        if task.id not in remove_ids:
            preserved.append(task)

    # Validate replacement task dependencies
    preserved_ids = {t.id for t in preserved}
    replacement_tasks: List[SubTask] = []
    for task in replacement_plan.tasks:
        # Clean up depends_on: keep only references to preserved or other replacement tasks
        valid_deps = [
            d for d in task.depends_on
            if d in preserved_ids or d in {t.id for t in replacement_plan.tasks}
        ]
        cleaned = task.model_copy(update={"depends_on": valid_deps})
        replacement_tasks.append(cleaned)

    merged_tasks = preserved + replacement_tasks
    merged_plan = ExecutionPlan(
        goal=current_plan.goal,
        tasks=merged_tasks,
    )

    result = DeltaResult(
        tasks_removed=len(remove_ids),
        tasks_added=len(replacement_tasks),
        tasks_preserved=len(preserved),
    )

    logger.info(
        "apply_delta: preserved=%d removed=%d added=%d total=%d",
        result.tasks_preserved, result.tasks_removed,
        result.tasks_added, len(merged_tasks),
    )

    return merged_plan, result


def rollback_tasks(
    plan: ExecutionPlan,
    task_ids: List[str],
) -> Set[str]:
    """Identify which tasks need to be reset when rolling back specific tasks.

    Rolling back a task means marking it and all its downstream dependents
    as needing re-execution.

    Args:
        plan: The current execution plan.
        task_ids: Task IDs to roll back.

    Returns:
        Set of all task IDs that need to be reset (rollback targets + downstream).
    """
    rollback_set = set(task_ids)
    affected = compute_affected_subgraph(plan.tasks, rollback_set)
    return rollback_set | affected
