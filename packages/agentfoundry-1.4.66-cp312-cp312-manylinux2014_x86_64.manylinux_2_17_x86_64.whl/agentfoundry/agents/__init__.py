"""AgentFoundry agent exports."""

from importlib import import_module
from typing import TYPE_CHECKING, Any

__all__ = [
    "HierarchicalAutoGenOrchestrator",
    "HierarchicalOrchestrator",
    "StateGraphOrchestrator",
    "RequirementsAgent",
    "CodebaseAnalysisAgent",
    "ArchitectureAgent",
    "BackendAgent",
    "DataEngineeringAgent",
    "ContractAgent",
    "FrontendAgent",
    "IntegrationAgent",
    "PlatformOperationsAgent",
    "ReleaseAgent",
    "CodeReviewAgent",
    "TestingAgent",
    "DebuggingAgent",
    "SecurityComplianceAgent",
    "HierarchyManager",
    "SecurityContext",
    "RequirementsOutputContract",
    "CodebaseAnalysisOutputContract",
    "ArchitectureOutputContract",
    "BackendOutputContract",
    "DataEngineeringOutputContract",
    "ContractAnalysisOutputContract",
    "FrontendOutputContract",
    "IntegrationOutputContract",
    "PlatformOperationsOutputContract",
    "ReleaseOutputContract",
    "SecurityComplianceOutputContract",
    "SpecialistHandoffContract",
    "render_specialist_contract",
]

if TYPE_CHECKING:  # pragma: no cover - static analyzers only
    from .autogen_hierarchical import HierarchicalAutoGenOrchestrator as _HierarchicalAutoGenOrchestrator
    from .graph_orchestrator import StateGraphOrchestrator as _StateGraphOrchestrator
    from .hierarchy import HierarchyManager as _HierarchyManager
    from .hierarchical_orchestrator import HierarchicalOrchestrator as _HierarchicalOrchestrator
    from .security_context import SecurityContext as _SecurityContext
    from .specialized_agents import ArchitectureAgent as _ArchitectureAgent
    from .specialized_agents import ArchitectureOutputContract as _ArchitectureOutputContract
    from .specialized_agents import BackendAgent as _BackendAgent
    from .specialized_agents import BackendOutputContract as _BackendOutputContract
    from .specialized_agents import CodebaseAnalysisAgent as _CodebaseAnalysisAgent
    from .specialized_agents import CodebaseAnalysisOutputContract as _CodebaseAnalysisOutputContract
    from .specialized_agents import CodeReviewAgent as _CodeReviewAgent
    from .specialized_agents import ContractAgent as _ContractAgent
    from .specialized_agents import ContractAnalysisOutputContract as _ContractAnalysisOutputContract
    from .specialized_agents import DataEngineeringAgent as _DataEngineeringAgent
    from .specialized_agents import DataEngineeringOutputContract as _DataEngineeringOutputContract
    from .specialized_agents import DebuggingAgent as _DebuggingAgent
    from .specialized_agents import FrontendAgent as _FrontendAgent
    from .specialized_agents import FrontendOutputContract as _FrontendOutputContract
    from .specialized_agents import IntegrationAgent as _IntegrationAgent
    from .specialized_agents import IntegrationOutputContract as _IntegrationOutputContract
    from .specialized_agents import PlatformOperationsAgent as _PlatformOperationsAgent
    from .specialized_agents import PlatformOperationsOutputContract as _PlatformOperationsOutputContract
    from .specialized_agents import ReleaseAgent as _ReleaseAgent
    from .specialized_agents import ReleaseOutputContract as _ReleaseOutputContract
    from .specialized_agents import RequirementsAgent as _RequirementsAgent
    from .specialized_agents import RequirementsOutputContract as _RequirementsOutputContract
    from .specialized_agents import SecurityComplianceAgent as _SecurityComplianceAgent
    from .specialized_agents import SecurityComplianceOutputContract as _SecurityComplianceOutputContract
    from .specialized_agents import SpecialistHandoffContract as _SpecialistHandoffContract
    from .specialized_agents import TestingAgent as _TestingAgent
    from .specialized_agents import render_specialist_contract as _render_specialist_contract

def __getattr__(name: str) -> Any:
    if name == "HierarchicalAutoGenOrchestrator":
        try:
            module = import_module(".autogen_hierarchical", __name__)
        except ImportError:  # pragma: no cover - surfaces during runtime config
            raise
        return module.HierarchicalAutoGenOrchestrator
    if name == "StateGraphOrchestrator":
        try:
            module = import_module(".graph_orchestrator", __name__)
        except ImportError:
            raise
        return module.StateGraphOrchestrator
    if name == "HierarchicalOrchestrator":
        module = import_module(".hierarchical_orchestrator", __name__)
        return module.HierarchicalOrchestrator
    if name == "HierarchyManager":
        module = import_module(".hierarchy", __name__)
        return module.HierarchyManager
    if name == "SecurityContext":
        module = import_module(".security_context", __name__)
        return module.SecurityContext
    if name in {
        "RequirementsAgent",
        "CodebaseAnalysisAgent",
        "ArchitectureAgent",
        "BackendAgent",
        "DataEngineeringAgent",
        "ContractAgent",
        "FrontendAgent",
        "IntegrationAgent",
        "PlatformOperationsAgent",
        "ReleaseAgent",
        "CodeReviewAgent",
        "TestingAgent",
        "DebuggingAgent",
        "SecurityComplianceAgent",
        "RequirementsOutputContract",
        "CodebaseAnalysisOutputContract",
        "ArchitectureOutputContract",
        "BackendOutputContract",
        "DataEngineeringOutputContract",
        "ContractAnalysisOutputContract",
        "FrontendOutputContract",
        "IntegrationOutputContract",
        "PlatformOperationsOutputContract",
        "ReleaseOutputContract",
        "SecurityComplianceOutputContract",
        "SpecialistHandoffContract",
        "render_specialist_contract",
    }:
        module = import_module(".specialized_agents", __name__)
        return getattr(module, name)
    raise AttributeError(name)
