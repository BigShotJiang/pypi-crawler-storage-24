"""Hierarchy management for multi-agent collaboration.

Tracks parent-child agent relationships using an in-memory tree structure
with optional persistence to the knowledge graph.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


class AgentStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class AgentNode:
    """A node in the agent hierarchy tree."""

    agent_id: str
    role: str
    parent_id: Optional[str] = None
    children: List[str] = field(default_factory=list)
    status: AgentStatus = AgentStatus.PENDING
    task: str = ""
    result: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    depth: int = 0


class HierarchyManager:
    """Manages a tree of agent nodes with optional KGraph persistence.

    The hierarchy is kept in memory for speed and optionally mirrored to the
    knowledge graph so that execution state survives restarts and is queryable
    across agents.

    Parameters
    ----------
    max_depth : int
        Maximum allowed depth of the hierarchy tree (default 5).
    kgraph : optional
        A ``KGraphBase`` instance.  When provided, hierarchy mutations are
        persisted as knowledge-graph triples.
    org_id : str
        Organisation scope used for KGraph writes.
    """

    def __init__(
        self,
        max_depth: int = 5,
        kgraph: Any = None,
        org_id: str = "default",
    ) -> None:
        self.max_depth = max_depth
        self.kgraph = kgraph
        self.org_id = org_id
        self._nodes: Dict[str, AgentNode] = {}
        self._root_ids: List[str] = []

    # ------------------------------------------------------------------
    # Tree operations
    # ------------------------------------------------------------------

    def create_root(self, role: str, task: str, metadata: Optional[Dict[str, Any]] = None) -> AgentNode:
        """Create a root-level agent node."""
        node = AgentNode(
            agent_id=uuid.uuid4().hex,
            role=role,
            task=task,
            metadata=metadata or {},
            depth=0,
        )
        self._nodes[node.agent_id] = node
        self._root_ids.append(node.agent_id)
        self._persist_node(node)
        self._persist_edge(node)
        logger.info("Created root agent node %s (role=%s)", node.agent_id[:8], role)
        return node

    def add_child(
        self,
        parent_id: str,
        role: str,
        task: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AgentNode:
        """Spawn a child agent under *parent_id*.

        Raises ``ValueError`` if the parent does not exist or adding the child
        would exceed ``max_depth``.
        """
        parent = self._nodes.get(parent_id)
        if parent is None:
            raise ValueError(f"Parent agent '{parent_id}' not found in hierarchy")

        child_depth = parent.depth + 1
        if child_depth > self.max_depth:
            raise ValueError(
                f"Cannot add child at depth {child_depth}; max_depth is {self.max_depth}"
            )

        node = AgentNode(
            agent_id=uuid.uuid4().hex,
            role=role,
            parent_id=parent_id,
            task=task,
            metadata=metadata or {},
            depth=child_depth,
        )
        parent.children.append(node.agent_id)
        self._nodes[node.agent_id] = node
        self._persist_node(node)
        self._persist_edge(node)
        logger.info(
            "Added child agent %s (role=%s) under parent %s at depth %d",
            node.agent_id[:8],
            role,
            parent_id[:8],
            child_depth,
        )
        return node

    def update_status(
        self,
        agent_id: str,
        status: AgentStatus,
        result: str = "",
    ) -> None:
        """Update the status (and optionally the result) of an agent node."""
        node = self._nodes.get(agent_id)
        if node is None:
            raise ValueError(f"Agent '{agent_id}' not found")
        node.status = status
        if result:
            node.result = result
        if status in (AgentStatus.COMPLETED, AgentStatus.FAILED):
            node.completed_at = time.time()
        self._persist_node(node)

    def get_node(self, agent_id: str) -> Optional[AgentNode]:
        return self._nodes.get(agent_id)

    def get_children(self, agent_id: str) -> List[AgentNode]:
        node = self._nodes.get(agent_id)
        if node is None:
            return []
        return [self._nodes[cid] for cid in node.children if cid in self._nodes]

    def get_subtree(self, agent_id: str) -> List[AgentNode]:
        """Return all nodes in the subtree rooted at *agent_id* (BFS)."""
        result: List[AgentNode] = []
        queue = [agent_id]
        while queue:
            current_id = queue.pop(0)
            node = self._nodes.get(current_id)
            if node is None:
                continue
            result.append(node)
            queue.extend(node.children)
        return result

    def get_roots(self) -> List[AgentNode]:
        return [self._nodes[rid] for rid in self._root_ids if rid in self._nodes]

    def all_completed(self, agent_id: str) -> bool:
        """Check whether the agent and all its descendants have completed."""
        for node in self.get_subtree(agent_id):
            if node.status not in (AgentStatus.COMPLETED, AgentStatus.FAILED):
                return False
        return True

    def aggregate_results(self, agent_id: str) -> List[str]:
        """Collect results from all completed children of *agent_id*."""
        children = self.get_children(agent_id)
        return [
            child.result
            for child in children
            if child.status == AgentStatus.COMPLETED and child.result
        ]

    def render_tree(self, agent_id: Optional[str] = None) -> str:
        """Return a human-readable rendering of the tree (or a subtree)."""
        lines: List[str] = []
        roots = [agent_id] if agent_id else self._root_ids
        for rid in roots:
            self._render_subtree(rid, lines, indent=0)
        return "\n".join(lines)

    def _render_subtree(self, node_id: str, lines: List[str], indent: int) -> None:
        node = self._nodes.get(node_id)
        if node is None:
            return
        prefix = "  " * indent
        status = node.status.value
        lines.append(f"{prefix}- [{status}] {node.role} ({node.agent_id[:8]}): {node.task[:60]}")
        for cid in node.children:
            self._render_subtree(cid, lines, indent + 1)

    # ------------------------------------------------------------------
    # KGraph persistence
    # ------------------------------------------------------------------

    def _persist_node(self, node: AgentNode) -> None:
        if self.kgraph is None:
            return
        try:
            self.kgraph.upsert_fact(
                subject=f"agent:{node.agent_id}",
                predicate="has_status",
                obj=node.status.value,
                metadata={
                    "org_id": self.org_id,
                    "role": node.role,
                    "task": node.task[:200],
                    "depth": str(node.depth),
                    "result_preview": node.result[:200] if node.result else "",
                    "graph_slice_id": f"hierarchy:{node.agent_id}",
                },
            )
        except Exception as exc:
            logger.warning("Failed to persist node %s to KGraph: %s", node.agent_id[:8], exc)

    def _persist_edge(self, node: AgentNode) -> None:
        if self.kgraph is None:
            return
        try:
            parent_subject = f"agent:{node.parent_id}" if node.parent_id else "hierarchy:root"
            self.kgraph.upsert_fact(
                subject=parent_subject,
                predicate="delegates_to",
                obj=f"agent:{node.agent_id}",
                metadata={
                    "org_id": self.org_id,
                    "child_role": node.role,
                    "graph_slice_id": f"hierarchy:{node.agent_id}",
                },
            )
        except Exception as exc:
            logger.warning("Failed to persist edge for %s to KGraph: %s", node.agent_id[:8], exc)

    def load_from_kgraph(self) -> int:
        """Re-hydrate hierarchy state from the knowledge graph.

        Returns the number of nodes loaded.
        """
        if self.kgraph is None:
            return 0
        try:
            facts = self.kgraph.fetch_by_metadata(
                org_id=self.org_id,
                filters={"graph_slice_id_prefix": "hierarchy:"},
            )
        except Exception as exc:
            logger.warning("Failed to load hierarchy from KGraph: %s", exc)
            return 0

        loaded = 0
        for fact in facts:
            subject = fact.get("subject", "")
            if subject.startswith("agent:"):
                agent_id = subject[len("agent:"):]
                if agent_id not in self._nodes:
                    meta = fact.get("metadata", {})
                    node = AgentNode(
                        agent_id=agent_id,
                        role=meta.get("role", "unknown"),
                        task=meta.get("task", ""),
                        status=AgentStatus(fact.get("object", "pending")),
                        depth=int(meta.get("depth", 0)),
                    )
                    self._nodes[agent_id] = node
                    loaded += 1
        logger.info("Loaded %d nodes from KGraph", loaded)
        return loaded
