from typing import Dict, Any, Callable, List, Optional, Type, Literal, Annotated, Sequence, TypedDict
import operator
import logging

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langgraph.graph.state import CompiledStateGraph
from langgraph.checkpoint.memory import MemorySaver

from agentfoundry.utils.agent_config import AgentConfig
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.llm.llm_factory import LLMFactory

logger = logging.getLogger(__name__)

class AgentState(TypedDict):
    """Default State Schema for the Graph Orchestrator."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    next_node: str
    metadata: Dict[str, Any]

class StateGraphOrchestrator:
    """
    A robust, graph-based Orchestrator that allows users to define complex,
    cyclical state machines for agentic workflows (e.g. Plan -> Code -> Review).
    
    It wraps LangGraph to seamlessly integrate with AgentFoundry's AgentConfig,
    LLMFactory, and ToolRegistry, abstracting away the boilerplate of node definition.
    """
    
    def __init__(
        self, 
        config: AgentConfig, 
        registry: ToolRegistry,
        state_schema: Type[Any] = AgentState
    ):
        self.config = config
        self.registry = registry
        self.llm = LLMFactory.get_llm_model(config=self.config)
        self.state_schema = state_schema
        self.graph = StateGraph(self.state_schema)
        self._compiled_app: Optional[CompiledStateGraph] = None
        self._nodes: List[str] = []
        
    def add_llm_node(
        self, 
        name: str, 
        system_prompt: str, 
        tool_names: Optional[List[str]] = None,
        structured_output_schema: Optional[Type] = None
    ):
        """
        Adds an LLM node to the state graph.
        
        Args:
            name: The unique name of the node.
            system_prompt: The prompt guiding the LLM's behavior.
            tool_names: List of tool names from the ToolRegistry to bind.
            structured_output_schema: Pydantic model for structured output (optional).
        """
        model = self.llm
        if tool_names:
            tools = self.registry.get_tools_by_names(tool_names)
            if tools:
                model = model.bind_tools(tools)
                
        if structured_output_schema:
            model = model.with_structured_output(structured_output_schema)
            
        def _node_func(state: dict):
            logger.debug(f"Executing node: {name}")
            messages = state.get("messages", [])
            # Prepend system prompt if it's the first message or not present
            if not messages or getattr(messages[0], "type", "") != "system":
                from langchain_core.messages import SystemMessage
                messages = [SystemMessage(content=system_prompt)] + list(messages)
                
            response = model.invoke(messages)
            
            # If using structured output, it might not return a BaseMessage, so wrap it
            if structured_output_schema and not isinstance(response, BaseMessage):
                # Update metadata with structured data instead of appending to messages
                metadata = state.get("metadata", {})
                metadata[f"{name}_output"] = response.dict() if hasattr(response, "dict") else response
                return {"metadata": metadata}
                
            return {"messages": [response]}
            
        self.graph.add_node(name, _node_func)
        self._nodes.append(name)
        logger.info(f"Added LLM node: {name}")

    def add_tool_node(self, name: str, tool_names: List[str]):
        """
        Adds a standard Tool execution node using LangGraph's prebuilt ToolNode.
        """
        tools = self.registry.get_tools_by_names(tool_names)
        if not tools:
            raise ValueError(f"No valid tools found for names: {tool_names}")
            
        tool_node = ToolNode(tools)
        self.graph.add_node(name, tool_node)
        self._nodes.append(name)
        logger.info(f"Added Tool node: {name} with tools: {tool_names}")

    def add_custom_node(self, name: str, func: Callable[[Any], dict]):
        """Adds a custom python function as a node."""
        self.graph.add_node(name, func)
        self._nodes.append(name)
        logger.info(f"Added custom node: {name}")

    def add_edge(self, start_node: str, end_node: str):
        """Adds a direct, unconditional edge between two nodes."""
        self.graph.add_edge(start_node, end_node)
        
    def add_conditional_edge(
        self, 
        start_node: str, 
        condition_func: Callable[[Any], str], 
        routing_dict: Dict[str, str]
    ):
        """
        Adds a conditional edge.
        
        Args:
            start_node: The node to evaluate after it finishes.
            condition_func: A function that takes the state and returns a string key.
            routing_dict: A dict mapping the returned string key to the next node name.
        """
        self.graph.add_conditional_edges(start_node, condition_func, routing_dict)
        
    def set_entry_point(self, node_name: str):
        """Sets the starting node for the graph."""
        self.graph.set_entry_point(node_name)
        
    def compile(self, checkpointer=None) -> CompiledStateGraph:
        """Compiles the state graph into an executable application."""
        checkpointer = checkpointer or MemorySaver()
        self._compiled_app = self.graph.compile(checkpointer=checkpointer)
        logger.info("Successfully compiled StateGraphOrchestrator")
        return self._compiled_app

    def invoke(self, input_state: dict, thread_id: str = "default") -> dict:
        """
        Executes the compiled graph synchronously.
        """
        if not self._compiled_app:
            self.compile()
            
        config = {"configurable": {"thread_id": thread_id}}
        return self._compiled_app.invoke(input_state, config=config)

    def stream(self, input_state: dict, thread_id: str = "default"):
        """
        Streams the execution events of the graph.
        """
        if not self._compiled_app:
            self.compile()
            
        config = {"configurable": {"thread_id": thread_id}}
        return self._compiled_app.stream(input_state, config=config)
