"""Intent classification, policy enforcement, and prompt injection detection.

Provides a semantic-level safety layer on top of the existing tool-level RBAC
(SecurityContext). While SecurityContext checks *which tools* a role may use,
IntentGuard checks *what the agent is trying to do* — catching cases where
allowed tools could be misused for unintended purposes.

All classification is keyword/pattern-based (no LLM dependency, zero latency).
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, FrozenSet, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Intent categories
# ---------------------------------------------------------------------------

class IntentCategory(str, Enum):
    """Broad categories of agent intent."""

    QUERY = "query"           # Read-only information retrieval
    ANALYZE = "analyze"       # Code/data analysis without side effects
    CREATE = "create"         # Generate new files, docs, code
    MODIFY = "modify"         # Change existing files, data, config
    DELETE = "delete"         # Remove files, data, records
    EXECUTE = "execute"       # Run commands, scripts, deployments
    ADMIN = "admin"           # System administration, user management
    EXFILTRATE = "exfiltrate" # Suspicious data extraction patterns
    INJECTION = "injection"   # Prompt injection / jailbreak attempt


class RiskLevel(str, Enum):
    """Risk assessment of a classified intent."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ---------------------------------------------------------------------------
# Classification result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class IntentClassification:
    """Result of classifying a task description."""

    category: IntentCategory
    confidence: float  # 0.0 to 1.0
    risk_level: RiskLevel
    signals: Tuple[str, ...] = ()  # keywords/patterns that triggered this classification
    details: str = ""


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class IntentPolicy:
    """Policy governing which intents are allowed for a scope.

    Defaults are permissive — all intents allowed except exfiltrate/injection.
    """

    allowed_intents: FrozenSet[IntentCategory] = frozenset({
        IntentCategory.QUERY, IntentCategory.ANALYZE,
        IntentCategory.CREATE, IntentCategory.MODIFY,
        IntentCategory.EXECUTE,
    })
    denied_intents: FrozenSet[IntentCategory] = frozenset({
        IntentCategory.EXFILTRATE, IntentCategory.INJECTION,
    })
    max_risk_level: RiskLevel = RiskLevel.HIGH
    require_approval_above: RiskLevel = RiskLevel.MEDIUM


# Presets
PERMISSIVE_POLICY = IntentPolicy(
    allowed_intents=frozenset(IntentCategory),
    denied_intents=frozenset(),
    max_risk_level=RiskLevel.CRITICAL,
    require_approval_above=RiskLevel.CRITICAL,
)

STRICT_POLICY = IntentPolicy(
    allowed_intents=frozenset({
        IntentCategory.QUERY, IntentCategory.ANALYZE,
    }),
    denied_intents=frozenset({
        IntentCategory.DELETE, IntentCategory.ADMIN,
        IntentCategory.EXFILTRATE, IntentCategory.INJECTION,
    }),
    max_risk_level=RiskLevel.MEDIUM,
    require_approval_above=RiskLevel.LOW,
)


# ---------------------------------------------------------------------------
# Guard result
# ---------------------------------------------------------------------------

@dataclass
class IntentGuardResult:
    """Outcome of an intent guard check."""

    allowed: bool
    classification: IntentClassification
    reason: str
    requires_approval: bool = False
    injection_detected: bool = False
    injection_patterns: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Keyword/pattern tables for classification
# ---------------------------------------------------------------------------

_INTENT_KEYWORDS: Dict[IntentCategory, Set[str]] = {
    IntentCategory.QUERY: {
        "search", "find", "look", "show", "list", "get", "fetch",
        "retrieve", "what", "where", "when", "who", "how", "tell",
        "explain", "describe", "summarize", "check", "verify", "read",
    },
    IntentCategory.ANALYZE: {
        "analyze", "analyse", "review", "inspect", "evaluate", "assess",
        "audit", "compare", "profile", "benchmark", "measure", "scan",
        "lint", "test", "validate", "diagnose",
    },
    IntentCategory.CREATE: {
        "create", "generate", "write", "build", "make", "add", "new",
        "implement", "develop", "produce", "compose", "draft", "init",
        "scaffold", "setup", "bootstrap",
    },
    IntentCategory.MODIFY: {
        "modify", "update", "change", "edit", "alter", "fix", "patch",
        "refactor", "rename", "replace", "transform", "migrate",
        "upgrade", "convert", "rewrite",
    },
    IntentCategory.DELETE: {
        "delete", "remove", "drop", "destroy", "purge", "clean",
        "wipe", "clear", "truncate", "erase", "uninstall",
    },
    IntentCategory.EXECUTE: {
        "run", "execute", "deploy", "launch", "start", "restart",
        "stop", "kill", "install", "publish", "release", "push",
        "apply", "trigger", "invoke", "schedule",
    },
    IntentCategory.ADMIN: {
        "admin", "administrator", "sudo", "root", "permission",
        "credential", "password", "secret", "token", "key", "grant",
        "revoke", "privilege", "role", "access", "user management",
    },
}

# Patterns indicating data exfiltration attempts
_EXFILTRATION_PATTERNS: List[re.Pattern] = [
    re.compile(r"send\s+(all|every|the)\s+\w+\s+to\s+\S+", re.I),
    re.compile(r"(upload|post|transmit|exfil)\s+.*(data|file|secret|credential|key|token)", re.I),
    re.compile(r"(copy|move|transfer)\s+.*(external|outside|remote|my\s+server)", re.I),
    re.compile(r"(email|send|forward)\s+.*\b(password|secret|api.?key|credential|private)", re.I),
    re.compile(r"curl\s+.*\|\s*.*\bpost\b", re.I),
    re.compile(r"base64.*encode.*(secret|key|password|token)", re.I),
]

# Patterns indicating prompt injection / jailbreak attempts
_INJECTION_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"ignore\s+(all\s+)?(previous|above|prior)\s+(instructions?|rules?|prompts?)", re.I),
     "ignore_previous_instructions"),
    (re.compile(r"you\s+are\s+now\s+(a|an)\s+", re.I),
     "role_override"),
    (re.compile(r"(forget|disregard|override)\s+(your|all|the)\s+(rules?|instructions?|constraints?|guidelines?)", re.I),
     "forget_rules"),
    (re.compile(r"(system|admin)\s*:\s*", re.I),
     "system_prompt_injection"),
    (re.compile(r"<\s*(system|instruction|prompt)\s*>", re.I),
     "tag_injection"),
    (re.compile(r"do\s+not\s+(follow|obey|respect)\s+(the|your|any)\s+(rules?|policy|guidelines?)", re.I),
     "policy_bypass"),
    (re.compile(r"pretend\s+(you|that)\s+(are|have|can|don)", re.I),
     "pretend_override"),
    (re.compile(r"\bDAN\b.*\b(mode|jailbreak)\b", re.I),
     "jailbreak_keyword"),
    (re.compile(r"(act|respond)\s+as\s+if\s+(you\s+)?(have\s+no|without)\s+(restrictions?|limits?|rules?)", re.I),
     "unrestricted_mode"),
]

# Risk mapping per intent category
_CATEGORY_RISK: Dict[IntentCategory, RiskLevel] = {
    IntentCategory.QUERY: RiskLevel.LOW,
    IntentCategory.ANALYZE: RiskLevel.LOW,
    IntentCategory.CREATE: RiskLevel.MEDIUM,
    IntentCategory.MODIFY: RiskLevel.MEDIUM,
    IntentCategory.DELETE: RiskLevel.HIGH,
    IntentCategory.EXECUTE: RiskLevel.HIGH,
    IntentCategory.ADMIN: RiskLevel.CRITICAL,
    IntentCategory.EXFILTRATE: RiskLevel.CRITICAL,
    IntentCategory.INJECTION: RiskLevel.CRITICAL,
}

_RISK_ORDER = {
    RiskLevel.LOW: 0,
    RiskLevel.MEDIUM: 1,
    RiskLevel.HIGH: 2,
    RiskLevel.CRITICAL: 3,
}


# ---------------------------------------------------------------------------
# Classification functions
# ---------------------------------------------------------------------------

def classify_intent(task_description: str) -> IntentClassification:
    """Classify the intent of a task description.

    Uses keyword matching and pattern detection. Returns the highest-confidence
    category. Zero LLM calls, sub-millisecond latency.

    Args:
        task_description: The user's task or query text.

    Returns:
        IntentClassification with category, confidence, risk, and signals.
    """
    if not task_description:
        return IntentClassification(
            category=IntentCategory.QUERY,
            confidence=0.0,
            risk_level=RiskLevel.LOW,
        )

    text_lower = task_description.lower()
    tokens = set(re.findall(r"[a-z][a-z0-9]*", text_lower))

    # Check for injection first (highest priority)
    injection_hits = detect_injection(task_description)
    if injection_hits:
        return IntentClassification(
            category=IntentCategory.INJECTION,
            confidence=min(0.5 + 0.15 * len(injection_hits), 1.0),
            risk_level=RiskLevel.CRITICAL,
            signals=tuple(injection_hits),
            details="Prompt injection pattern detected",
        )

    # Check for exfiltration patterns
    exfil_signals = []
    for pattern in _EXFILTRATION_PATTERNS:
        if pattern.search(task_description):
            exfil_signals.append(pattern.pattern[:40])
    if exfil_signals:
        return IntentClassification(
            category=IntentCategory.EXFILTRATE,
            confidence=min(0.6 + 0.1 * len(exfil_signals), 1.0),
            risk_level=RiskLevel.CRITICAL,
            signals=tuple(exfil_signals),
            details="Data exfiltration pattern detected",
        )

    # Score each category by keyword overlap
    scores: List[Tuple[IntentCategory, float, List[str]]] = []
    for category, keywords in _INTENT_KEYWORDS.items():
        hits = tokens & keywords
        if hits:
            score = len(hits) / max(len(tokens), 1)
            scores.append((category, score, sorted(hits)))

    if not scores:
        return IntentClassification(
            category=IntentCategory.QUERY,
            confidence=0.3,
            risk_level=RiskLevel.LOW,
            details="No strong intent signal; defaulting to query",
        )

    # Pick the highest-scoring category
    scores.sort(key=lambda x: x[1], reverse=True)
    best_cat, best_score, best_signals = scores[0]
    risk = _CATEGORY_RISK.get(best_cat, RiskLevel.LOW)

    # If multiple high-risk categories match, escalate risk
    high_risk_matches = [
        cat for cat, score, _ in scores
        if _RISK_ORDER.get(_CATEGORY_RISK.get(cat, RiskLevel.LOW), 0) >= 2
        and score > 0.1
    ]
    if len(high_risk_matches) > 1:
        risk = max(risk, RiskLevel.HIGH, key=lambda r: _RISK_ORDER[r])

    return IntentClassification(
        category=best_cat,
        confidence=min(best_score * 2.0, 1.0),  # scale up for readability
        risk_level=risk,
        signals=tuple(best_signals),
    )


def detect_injection(text: str) -> List[str]:
    """Detect prompt injection patterns in text.

    Returns a list of matched pattern names. Empty list = no injection detected.
    """
    hits: List[str] = []
    for pattern, name in _INJECTION_PATTERNS:
        if pattern.search(text):
            hits.append(name)
    return hits


def check_policy(
    classification: IntentClassification,
    policy: Optional[IntentPolicy] = None,
) -> IntentGuardResult:
    """Check whether a classified intent is allowed by the policy.

    Args:
        classification: The classified intent.
        policy: Policy to check against. Uses default if None.

    Returns:
        IntentGuardResult with allow/deny decision and reasoning.
    """
    if policy is None:
        policy = IntentPolicy()

    cat = classification.category
    risk = classification.risk_level

    # Explicitly denied
    if cat in policy.denied_intents:
        return IntentGuardResult(
            allowed=False,
            classification=classification,
            reason=f"Intent '{cat.value}' is explicitly denied by policy",
            injection_detected=cat == IntentCategory.INJECTION,
            injection_patterns=list(classification.signals) if cat == IntentCategory.INJECTION else [],
        )

    # Not in allowed set (if allowed set is non-empty)
    if policy.allowed_intents and cat not in policy.allowed_intents:
        return IntentGuardResult(
            allowed=False,
            classification=classification,
            reason=f"Intent '{cat.value}' is not in the allowed set",
        )

    # Risk level too high
    if _RISK_ORDER.get(risk, 0) > _RISK_ORDER.get(policy.max_risk_level, 2):
        return IntentGuardResult(
            allowed=False,
            classification=classification,
            reason=f"Risk level '{risk.value}' exceeds maximum '{policy.max_risk_level.value}'",
        )

    # Check if approval is needed
    requires_approval = (
        _RISK_ORDER.get(risk, 0) > _RISK_ORDER.get(policy.require_approval_above, 1)
    )

    return IntentGuardResult(
        allowed=True,
        classification=classification,
        reason="Intent allowed by policy",
        requires_approval=requires_approval,
    )


# ---------------------------------------------------------------------------
# IntentGuard — stateful wrapper for orchestrator integration
# ---------------------------------------------------------------------------

class IntentGuard:
    """Stateful intent guard for integration with the orchestrator.

    Combines intent classification, policy enforcement, and injection
    detection into a single check. Records an audit trail of all checks.

    Usage::

        guard = IntentGuard(policy=STRICT_POLICY)
        result = guard.check("delete all production databases")
        if not result.allowed:
            raise PermissionError(result.reason)
    """

    def __init__(
        self,
        policy: Optional[IntentPolicy] = None,
        enabled: bool = True,
    ) -> None:
        self.policy = policy or IntentPolicy()
        self.enabled = enabled
        self._audit: List[Dict[str, Any]] = []

    def check(
        self,
        task_description: str,
        user_id: str = "",
        org_id: str = "",
    ) -> IntentGuardResult:
        """Classify intent and check against policy.

        Args:
            task_description: The task text to analyze.
            user_id: For audit logging.
            org_id: For audit logging.

        Returns:
            IntentGuardResult with decision, classification, and reasoning.
        """
        if not self.enabled:
            return IntentGuardResult(
                allowed=True,
                classification=IntentClassification(
                    category=IntentCategory.QUERY,
                    confidence=0.0,
                    risk_level=RiskLevel.LOW,
                ),
                reason="Intent guard disabled",
            )

        classification = classify_intent(task_description)

        # Also run injection detection on the raw text
        injection_patterns = detect_injection(task_description)

        result = check_policy(classification, self.policy)

        # Override if injection detected but classification missed it
        if injection_patterns and not result.injection_detected:
            result = IntentGuardResult(
                allowed=False,
                classification=classification,
                reason=f"Prompt injection detected: {', '.join(injection_patterns)}",
                injection_detected=True,
                injection_patterns=injection_patterns,
            )

        # Audit log
        self._audit.append({
            "task_preview": task_description[:120],
            "user_id": user_id,
            "org_id": org_id,
            "category": classification.category.value,
            "risk_level": classification.risk_level.value,
            "confidence": classification.confidence,
            "allowed": result.allowed,
            "reason": result.reason,
            "requires_approval": result.requires_approval,
            "injection_detected": result.injection_detected,
        })

        if not result.allowed:
            logger.warning(
                "IntentGuard DENIED: category=%s risk=%s reason=%s user=%s preview=%.80s",
                classification.category.value,
                classification.risk_level.value,
                result.reason,
                user_id,
                task_description,
            )
        elif result.requires_approval:
            logger.info(
                "IntentGuard APPROVAL_REQUIRED: category=%s risk=%s user=%s",
                classification.category.value,
                classification.risk_level.value,
                user_id,
            )

        return result

    @property
    def audit_log(self) -> List[Dict[str, Any]]:
        """Return a copy of the audit log."""
        return list(self._audit)

    def clear_audit_log(self) -> None:
        self._audit.clear()
