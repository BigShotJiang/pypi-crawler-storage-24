"""Specialized sub-agents used by the hierarchical orchestration plan."""

from __future__ import annotations

import logging
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from agentfoundry.agents.base_agent import BaseAgent
from agentfoundry.agents.specialist_manifests import manifest_allowed_tools

logger = logging.getLogger(__name__)


PATH_PATTERN = re.compile(
    r"(?P<path>[\w./-]+\.(?:pyi|pyx|py|toml|yaml|yml|json|md|txt|jsx|tsx|ts|js|scss|css|html|sql|proto|avsc|graphql|gql|csv|ini|cfg|conf|xml|sh))(?:[:#](?P<line>\d+))?"
)
CODE_BLOCK_PATTERN = re.compile(r"```(?:\w+)?\n(?P<code>.*?)```", re.DOTALL)
COMMAND_PATTERN = re.compile(r"`(?P<cmd>(?:pytest|python(?:3)? -m pytest|python(?:3)? -m unittest|tox|nox|uv run pytest)[^`]*)`")
TRACEBACK_PATTERN = re.compile(r"(?P<exc>[A-Z][A-Za-z]+(?:Error|Exception))(?::\s*(?P<detail>[^\n]+))?")
REQUIREMENT_ID_PATTERN = re.compile(r"\b(?:REQ|NFR|FR|ADR)-?[A-Za-z0-9_.-]+\b")
NORMATIVE_LINE_PATTERN = re.compile(r"\b(must|shall|required|should|needs to)\b", re.IGNORECASE)
SECRET_PATTERN = re.compile(r"\b(api[_-]?key|client[_-]?secret|password|token|secret)\b", re.IGNORECASE)
ROUTE_PATTERN = re.compile(r"(?:@(?:app|router)\.(?:get|post|put|delete|patch)|path\s*[:=]\s*[\"'][^\"']+[\"']|<Route\b)", re.IGNORECASE)
COMPONENT_PATTERN = re.compile(r"\b(?:function|const|export\s+function)\s+([A-Z][A-Za-z0-9]+)|<([A-Z][A-Za-z0-9]+)\b")
ENDPOINT_PATTERN = re.compile(r"(https?://[^\s\"']+|/[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)+)")
INTEGRATION_PATTERN = re.compile(r"\b(webhook|queue|topic|kafka|sqs|sns|eventbridge|grpc|rest|graphql|client|adapter)\b", re.IGNORECASE)
RELEASE_COMMAND_PATTERN = re.compile(
    r"`(?P<cmd>(?:python(?:3)? -m build|make(?:\s+\w+)?|docker build[^`]*|docker compose[^`]*|kubectl [^`]*|helm [^`]*|terraform [^`]*|uv build[^`]*))`"
)
DATA_PATTERN = re.compile(r"\b(schema|migration|etl|pipeline|spark|warehouse|table|column|dataset|stream|topic|dbt)\b", re.IGNORECASE)
CONTRACT_SIGNAL_PATTERN = re.compile(r"\b(openapi|swagger|protobuf|proto|json schema|avro|graphql|contract|dto|request|response|event)\b", re.IGNORECASE)
INFRA_PATTERN = re.compile(r"\b(kubernetes|helm|terraform|docker|compose|deployment|serviceaccount|ingress|secret|configmap|container|runtime|namespace|cluster)\b", re.IGNORECASE)


@dataclass
class AgentReport:
    title: str
    summary: str
    findings: List[str] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)
    tool_activity: List[str] = field(default_factory=list)

    def render(self) -> str:
        sections = [self.title, self.summary]
        if self.findings:
            sections.append("Findings:")
            sections.extend(f"- {item}" for item in self.findings)
        if self.actions:
            sections.append("Recommended actions:")
            sections.extend(f"- {item}" for item in self.actions)
        if self.evidence:
            sections.append("Evidence:")
            sections.extend(f"- {item}" for item in self.evidence)
        if self.tool_activity:
            sections.append("Tool activity:")
            sections.extend(f"- {item}" for item in self.tool_activity)
        return "\n".join(sections)

    def to_contract(
        self,
        *,
        role: str,
        task: str,
        contract_cls: type["SpecialistOutputContract"] | None = None,
        **extra_fields: Any,
    ) -> dict[str, Any]:
        contract_type = contract_cls or SpecialistOutputContract
        contract = contract_type(
            role=role,
            task=task,
            title=self.title,
            summary=self.summary,
            findings=list(self.findings),
            actions=list(self.actions),
            proposed_actions=list(extra_fields.pop("proposed_actions", self.actions)),
            evidence=list(self.evidence),
            tool_activity=list(self.tool_activity),
            **extra_fields,
        )
        return contract.to_dict()


@dataclass
class SpecialistOutputContract:
    schema_version: str = "1.0"
    contract_type: str = "specialist_report"
    role: str = ""
    task: str = ""
    title: str = ""
    summary: str = ""
    outcome_labels: List[str] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)
    proposed_actions: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    artifacts: List[str] = field(default_factory=list)
    confidence: float = 0.5
    context_summary: Dict[str, Any] = field(default_factory=dict)
    evidence: List[str] = field(default_factory=list)
    tool_activity: List[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RequirementsOutputContract(SpecialistOutputContract):
    contract_type: str = "requirements_analysis"
    requirement_ids: List[str] = field(default_factory=list)
    candidate_requirements: List[str] = field(default_factory=list)
    source_paths: List[str] = field(default_factory=list)
    specification_gaps: List[str] = field(default_factory=list)


@dataclass
class ArchitectureOutputContract(SpecialistOutputContract):
    contract_type: str = "architecture_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    repository_tree_preview: List[str] = field(default_factory=list)
    coupling_hotspots: List[str] = field(default_factory=list)
    boundary_recommendations: List[str] = field(default_factory=list)


@dataclass
class CodebaseAnalysisOutputContract(SpecialistOutputContract):
    contract_type: str = "codebase_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    repository_tree_preview: List[str] = field(default_factory=list)
    framework_signals: List[str] = field(default_factory=list)
    extension_points: List[str] = field(default_factory=list)
    hotspot_paths: List[str] = field(default_factory=list)
    onboarding_actions: List[str] = field(default_factory=list)


@dataclass
class SecurityComplianceOutputContract(SpecialistOutputContract):
    contract_type: str = "security_compliance_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    secret_findings: List[str] = field(default_factory=list)
    transport_findings: List[str] = field(default_factory=list)
    compliance_findings: List[str] = field(default_factory=list)


@dataclass
class BackendOutputContract(SpecialistOutputContract):
    contract_type: str = "backend_implementation_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    api_surfaces: List[str] = field(default_factory=list)
    data_models: List[str] = field(default_factory=list)
    implementation_tasks: List[str] = field(default_factory=list)


@dataclass
class FrontendOutputContract(SpecialistOutputContract):
    contract_type: str = "frontend_implementation_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    route_surfaces: List[str] = field(default_factory=list)
    component_candidates: List[str] = field(default_factory=list)
    ux_risks: List[str] = field(default_factory=list)


@dataclass
class IntegrationOutputContract(SpecialistOutputContract):
    contract_type: str = "integration_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    dependency_endpoints: List[str] = field(default_factory=list)
    contract_gaps: List[str] = field(default_factory=list)
    integration_tasks: List[str] = field(default_factory=list)


@dataclass
class DataEngineeringOutputContract(SpecialistOutputContract):
    contract_type: str = "data_engineering_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    data_surfaces: List[str] = field(default_factory=list)
    schema_changes: List[str] = field(default_factory=list)
    migration_risks: List[str] = field(default_factory=list)
    data_tasks: List[str] = field(default_factory=list)


@dataclass
class ContractAnalysisOutputContract(SpecialistOutputContract):
    contract_type: str = "contract_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    contract_surfaces: List[str] = field(default_factory=list)
    compatibility_risks: List[str] = field(default_factory=list)
    impacted_consumers: List[str] = field(default_factory=list)
    validation_obligations: List[str] = field(default_factory=list)


@dataclass
class PlatformOperationsOutputContract(SpecialistOutputContract):
    contract_type: str = "platform_operations_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    environment_assumptions: List[str] = field(default_factory=list)
    infrastructure_changes: List[str] = field(default_factory=list)
    operational_risks: List[str] = field(default_factory=list)
    rollback_actions: List[str] = field(default_factory=list)


@dataclass
class SpecialistHandoffContract:
    schema_version: str = "1.0"
    contract_type: str = "specialist_handoff"
    source_agent_id: str = ""
    source_role: str = ""
    target_agent_id: str = ""
    target_role: str = ""
    task: str = ""
    required_inputs: List[str] = field(default_factory=list)
    upstream_refs: List[str] = field(default_factory=list)
    acceptance_criteria: List[str] = field(default_factory=list)
    blocking_risks: List[str] = field(default_factory=list)
    summary: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ReleaseOutputContract(SpecialistOutputContract):
    contract_type: str = "release_readiness_analysis"
    inspected_paths: List[str] = field(default_factory=list)
    candidate_commands: List[str] = field(default_factory=list)
    release_risks: List[str] = field(default_factory=list)
    rollback_actions: List[str] = field(default_factory=list)


def render_specialist_contract(contract: Dict[str, Any]) -> str:
    report = AgentReport(
        title=str(contract.get("title") or contract.get("contract_type") or "Specialist report"),
        summary=str(contract.get("summary") or ""),
        findings=[str(item) for item in contract.get("findings", []) or []],
        actions=[str(item) for item in contract.get("actions", []) or []],
        evidence=[str(item) for item in contract.get("evidence", []) or []],
        tool_activity=[str(item) for item in contract.get("tool_activity", []) or []],
    )
    return report.render()


class _RegistryBackedAgent(BaseAgent):
    """Common plumbing for deterministic specialist agents."""

    role_name = "specialist"
    system_prompt = "Resolve the assigned task using the allowed tool set."
    allowed_tool_names: Sequence[str] = ()

    @staticmethod
    def _normalize_context_summary(context: Any) -> Dict[str, Any]:
        if not isinstance(context, dict):
            return {}
        repo_roots = context.get("repo_roots") or []
        upstream_contracts = context.get("upstream_contracts") or []
        validated_reuse_refs = context.get("validated_reuse_refs") or []
        return {
            "project_id": str(context.get("project_id") or ""),
            "repo_id": str(context.get("repo_id") or ""),
            "bounded_context": str(context.get("bounded_context") or ""),
            "environment": str(context.get("environment") or ""),
            "repo_root_count": len([item for item in repo_roots if str(item)]),
            "upstream_contract_count": len(upstream_contracts) if isinstance(upstream_contracts, Sequence) else 0,
            "validated_reuse_count": len(validated_reuse_refs) if isinstance(validated_reuse_refs, Sequence) else 0,
        }

    @staticmethod
    def _estimate_confidence(
        report: AgentReport,
        *,
        dependencies: Sequence[str] | None = None,
        artifacts: Sequence[str] | None = None,
        missing_tools: Sequence[str] | None = None,
    ) -> float:
        confidence = 0.45
        if report.tool_activity:
            confidence += 0.15
        if dependencies:
            confidence += 0.15
        if artifacts:
            confidence += 0.1
        if report.evidence:
            confidence += 0.1
        if missing_tools:
            confidence -= min(0.2, 0.05 * len(list(missing_tools)))
        return max(0.1, min(0.95, round(confidence, 2)))

    def __init__(self, tool_registry: Any = None, api_info: Optional[dict] = None):
        super().__init__(api_info)
        self.tool_registry = tool_registry

    def chat(self, messages: list[dict], config: dict = None, additional: bool = False):
        last_msg = messages[-1]["content"] if messages else "No task provided."
        reply = self.run_task(last_msg, config=config)
        if additional:
            return reply, {"role": self.role_name, "allowed_tools": list(self.allowed_tool_names)}
        return reply

    def run_structured_task(self, task: str, *args, **kwargs) -> dict[str, Any]:
        kwargs["structured"] = True
        result = self.run_task(task, *args, **kwargs)
        return dict(result)

    def _get_tool(self, name: str) -> Any:
        if self.tool_registry is None or not hasattr(self.tool_registry, "get_tool"):
            return None
        return self.tool_registry.get_tool(name)

    def _invoke_tool(self, name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        tool = self._get_tool(name)
        if tool is None:
            return {"error": f"Tool '{name}' is not available."}
        try:
            if hasattr(tool, "invoke"):
                result = tool.invoke(payload)
            else:
                func = getattr(tool, "func", None)
                if callable(func):
                    result = func(**payload)
                else:
                    return {"error": f"Tool '{name}' is not invocable."}
        except Exception as exc:  # pragma: no cover - defensive boundary
            logger.warning("%s tool '%s' failed: %s", self.role_name, name, exc, exc_info=True)
            return {"error": str(exc)}
        if isinstance(result, dict):
            return result
        return {"result": result}

    def _missing_tools(self) -> List[str]:
        missing = []
        for name in self.allowed_tool_names:
            if self._get_tool(name) is None:
                missing.append(name)
        return missing

    @staticmethod
    def _dedupe(items: Iterable[str]) -> List[str]:
        seen = set()
        deduped: List[str] = []
        for item in items:
            if item and item not in seen:
                seen.add(item)
                deduped.append(item)
        return deduped

    @staticmethod
    def _extract_paths(task: str) -> List[str]:
        candidates = []
        for match in PATH_PATTERN.finditer(task):
            path = match.group("path")
            if path:
                candidates.append(path.strip(".,);:"))
        return _RegistryBackedAgent._dedupe(candidates)

    @staticmethod
    def _extract_code_blocks(task: str) -> List[str]:
        return [match.group("code").strip() for match in CODE_BLOCK_PATTERN.finditer(task)]

    @staticmethod
    def _extract_test_commands(task: str) -> List[str]:
        commands = [match.group("cmd").strip() for match in COMMAND_PATTERN.finditer(task)]
        line_commands = []
        for raw_line in task.splitlines():
            line = raw_line.strip().lstrip("$").strip()
            if re.match(r"^(pytest|python(?:3)? -m pytest|python(?:3)? -m unittest|tox|nox|uv run pytest)\b", line):
                line_commands.append(line)
        return _RegistryBackedAgent._dedupe(commands + line_commands)

    @staticmethod
    def _extract_release_commands(task: str) -> List[str]:
        commands = [match.group("cmd").strip() for match in RELEASE_COMMAND_PATTERN.finditer(task)]
        line_commands = []
        for raw_line in task.splitlines():
            line = raw_line.strip().lstrip("$").strip()
            if re.match(r"^(python(?:3)? -m build|make\b|docker build\b|docker compose\b|kubectl\b|helm\b|terraform\b|uv build\b)", line):
                line_commands.append(line)
        return _RegistryBackedAgent._dedupe(commands + line_commands)

    @staticmethod
    def _extract_traceback(task: str) -> List[str]:
        findings = []
        for match in TRACEBACK_PATTERN.finditer(task):
            exc = match.group("exc")
            detail = (match.group("detail") or "").strip()
            if detail:
                findings.append(f"{exc}: {detail}")
            else:
                findings.append(exc)
        return _RegistryBackedAgent._dedupe(findings)

    @staticmethod
    def _extract_requirement_ids(text: str) -> List[str]:
        return _RegistryBackedAgent._dedupe(match.group(0) for match in REQUIREMENT_ID_PATTERN.finditer(text))

    @staticmethod
    def _extract_normative_lines(text: str, *, limit: int = 8) -> List[str]:
        candidates: List[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip().lstrip("-*0123456789. ").strip()
            if len(line) < 12:
                continue
            if NORMATIVE_LINE_PATTERN.search(line):
                candidates.append(line)
            if len(candidates) >= limit:
                break
        return _RegistryBackedAgent._dedupe(candidates)

    @staticmethod
    def _extract_component_names(text: str, *, limit: int = 8) -> List[str]:
        names: List[str] = []
        for match in COMPONENT_PATTERN.finditer(text):
            for group in match.groups():
                if group:
                    names.append(group)
            if len(names) >= limit:
                break
        return _RegistryBackedAgent._dedupe(names[:limit])

    @staticmethod
    def _extract_route_signals(text: str, *, limit: int = 8) -> List[str]:
        findings: List[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if ROUTE_PATTERN.search(line):
                findings.append(line[:180])
            if len(findings) >= limit:
                break
        return _RegistryBackedAgent._dedupe(findings)

    @staticmethod
    def _extract_endpoints(text: str, *, limit: int = 8) -> List[str]:
        return _RegistryBackedAgent._dedupe(match.group(0) for match in ENDPOINT_PATTERN.finditer(text))[:limit]

    @staticmethod
    def _extract_integration_terms(text: str, *, limit: int = 8) -> List[str]:
        findings: List[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if INTEGRATION_PATTERN.search(line):
                findings.append(line[:180])
            if len(findings) >= limit:
                break
        return _RegistryBackedAgent._dedupe(findings)

    def _finalize_report(
        self,
        task: str,
        report: AgentReport,
        *,
        structured: bool = False,
        contract_cls: type[SpecialistOutputContract] | None = None,
        outcome_labels: Optional[List[str]] = None,
        **extra_fields: Any,
    ) -> dict[str, Any] | str:
        if structured:
            context = extra_fields.pop("context", None)
            dependencies = list(extra_fields.get("dependencies") or [])
            artifacts = list(extra_fields.get("artifacts") or [])
            missing_tools = list(extra_fields.pop("missing_tools", []) or [])
            extra_fields.setdefault("proposed_actions", list(report.actions))
            extra_fields.setdefault("risks", list(report.findings))
            extra_fields.setdefault("dependencies", dependencies)
            extra_fields.setdefault("artifacts", artifacts)
            extra_fields.setdefault(
                "confidence",
                self._estimate_confidence(
                    report,
                    dependencies=dependencies,
                    artifacts=artifacts,
                    missing_tools=missing_tools,
                ),
            )
            extra_fields.setdefault("context_summary", self._normalize_context_summary(context))
            return report.to_contract(
                role=self.role_name,
                task=task,
                contract_cls=contract_cls,
                outcome_labels=list(outcome_labels or []),
                **extra_fields,
            )
        return report.render()

    @staticmethod
    def _looks_like_environment_issue(*texts: str) -> bool:
        lowered = "\n".join(texts).lower()
        indicators = (
            "no module named",
            "modulenotfounderror",
            "importerror",
            "command not found",
            "not installed",
            "no such file or directory",
            "cannot open shared object file",
            "dependency",
            "package",
            "environment",
            "runtime",
        )
        return any(token in lowered for token in indicators)


class CodeReviewAgent(_RegistryBackedAgent):
    """Review code for syntax, lint issues, structure, and maintainability concerns."""

    role_name = "code_review"
    system_prompt = (
        "Inspect the supplied code or files, surface defects and maintainability risks, "
        "and recommend the highest-value fixes first."
    )
    allowed_tool_names = manifest_allowed_tools("code_review")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Code review report",
            summary="Completed a deterministic code review using available static-analysis tools.",
        )

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some review tools are unavailable: {', '.join(missing)}.")

        paths = [path for path in self._extract_paths(task) if Path(path).suffix in {".py", ".pyi", ".pyx"}][:3]
        code_blocks = self._extract_code_blocks(task)[:2]

        if not paths and not code_blocks:
            report.findings.append("No Python files or code blocks were provided, so the review is advisory only.")
            report.actions.append("Pass one or more Python paths or a fenced code block to enable file-level analysis.")
            return self._finalize_report(task, report, structured=structured)

        for path in paths:
            validate_result = self._invoke_tool("code_analysis", {"action": "validate", "path": path})
            report.tool_activity.append(f"code_analysis validate on {path}")
            if validate_result.get("error"):
                report.findings.append(f"{path}: validation failed to run: {validate_result['error']}")
                continue

            validation = validate_result.get("result", {})
            if not validation.get("syntax_valid", True):
                report.findings.append(f"{path}: syntax error detected: {validation.get('syntax_error', 'unknown error')}")
                report.actions.append(f"Fix the syntax error in {path} before further changes.")

            missing_metadata = validation.get("missing_metadata") or []
            if missing_metadata:
                report.findings.append(f"{path}: missing metadata fields: {', '.join(missing_metadata)}")

            docstring_warnings = validation.get("docstring_warnings") or []
            if docstring_warnings:
                report.findings.extend(f"{path}: {warning}" for warning in docstring_warnings[:5])

            lint_result = self._invoke_tool("code_analysis", {"action": "lint", "path": path, "linter": "ruff"})
            report.tool_activity.append(f"code_analysis lint on {path}")
            if lint_result.get("error"):
                report.evidence.append(f"{path}: lint skipped: {lint_result['error']}")
            else:
                issues = lint_result.get("issues") or []
                if issues:
                    preview = issues[:5]
                    report.findings.extend(f"{path}: lint issue: {issue}" for issue in preview)
                    report.actions.append(f"Resolve the reported lint issues in {path}.")
                else:
                    report.evidence.append(f"{path}: no lint issues reported by ruff.")

            parse_result = self._invoke_tool("code_analysis", {"action": "parse", "path": path})
            report.tool_activity.append(f"code_analysis parse on {path}")
            parsed = parse_result.get("result", {}) if not parse_result.get("error") else {}
            if parsed:
                functions = parsed.get("functions") or []
                classes = parsed.get("classes") or []
                report.evidence.append(
                    f"{path}: parsed {len(functions)} top-level function(s) and {len(classes)} class(es)."
                )

        for idx, code in enumerate(code_blocks, start=1):
            validate_result = self._invoke_tool("code_analysis", {"action": "validate", "code": code})
            report.tool_activity.append(f"code_analysis validate on inline snippet {idx}")
            validation = validate_result.get("result", {})
            if validate_result.get("error"):
                report.findings.append(f"Snippet {idx}: validation failed to run: {validate_result['error']}")
                continue
            if not validation.get("syntax_valid", True):
                report.findings.append(
                    f"Snippet {idx}: syntax error detected: {validation.get('syntax_error', 'unknown error')}"
                )
            docstring_warnings = validation.get("docstring_warnings") or []
            if docstring_warnings:
                report.findings.extend(f"Snippet {idx}: {warning}" for warning in docstring_warnings[:5])

        if not report.findings:
            report.findings.append("No critical issues were found in the reviewed inputs.")
        if not report.actions:
            report.actions.append("Address the listed findings, then rerun the review on the touched files.")
        outcome_labels = ["env_issue"] if self._looks_like_environment_issue(*report.findings, *report.evidence) else ["bug_fix"]
        return self._finalize_report(
            task,
            report,
            structured=structured,
            outcome_labels=outcome_labels,
            risks=list(report.findings),
            missing_tools=missing,
            context=kwargs.get("context"),
        )


class TestingAgent(_RegistryBackedAgent):
    """Run or propose focused test workflows using the repository's available test tooling."""

    role_name = "testing"
    system_prompt = (
        "Identify the smallest useful automated test run for the task, execute only safe test commands, "
        "and summarize failures in a form the parent orchestrator can act on."
    )
    allowed_tool_names = manifest_allowed_tools("testing")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Testing report",
            summary="Prepared a focused test execution plan and ran safe commands when enough context was available.",
        )

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some testing tools are unavailable: {', '.join(missing)}.")

        commands = self._extract_test_commands(task)
        paths = self._extract_paths(task)
        if not commands and paths:
            test_targets = [path for path in paths if "/test" in path or path.startswith("test_") or path.startswith("tests/")]
            if test_targets:
                commands = [f"pytest -q {' '.join(test_targets[:3])}"]

        if not commands:
            report.findings.append("No runnable test command was provided or inferred safely.")
            if paths:
                report.actions.append(f"Create or run tests covering: {', '.join(paths[:3])}.")
            else:
                report.actions.append("Provide an explicit `pytest`, `python -m pytest`, `tox`, or `nox` command.")
            return self._finalize_report(task, report, structured=structured)

        for command in commands[:2]:
            result = self._invoke_tool("shell_command", {"command": command, "timeout": 120})
            report.tool_activity.append(f"shell_command executed `{command}`")
            if result.get("error"):
                report.findings.append(f"`{command}` could not run: {result['error']}")
                continue

            returncode = int(result.get("returncode", -1))
            stdout = (result.get("stdout") or "").strip()
            stderr = (result.get("stderr") or "").strip()
            if returncode == 0:
                report.evidence.append(f"`{command}` succeeded.")
            else:
                preview = stderr or stdout or "No command output captured."
                report.findings.append(f"`{command}` failed with return code {returncode}.")
                report.evidence.append(preview[:400])
                report.actions.append(f"Investigate the failing assertions or errors from `{command}`.")

        if not report.actions:
            report.actions.append("Keep the executed test command as a regression check for the next code change.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            dependencies=commands,
            risks=list(report.findings),
            artifacts=[],
            missing_tools=missing,
            context=kwargs.get("context"),
        )


class DebuggingAgent(_RegistryBackedAgent):
    """Analyze stack traces, suspect files, and reproduction commands to narrow likely root causes."""

    role_name = "debugging"
    system_prompt = (
        "Investigate errors using traceback clues, source inspection, and safe reproduction commands, "
        "then propose the most likely root cause and next debugging step."
    )
    allowed_tool_names = manifest_allowed_tools("debugging")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Debugging report",
            summary="Investigated the supplied failure context using static inspection and safe reproduction hooks.",
        )

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some debugging tools are unavailable: {', '.join(missing)}.")

        tracebacks = self._extract_traceback(task)
        paths = self._extract_paths(task)[:3]
        commands = self._extract_test_commands(task)

        if tracebacks:
            report.findings.extend(f"Observed error signature: {entry}" for entry in tracebacks[:3])

        for path in paths:
            if Path(path).suffix in {".py", ".pyi", ".pyx"}:
                validation = self._invoke_tool("code_analysis", {"action": "validate", "path": path})
                report.tool_activity.append(f"code_analysis validate on {path}")
                if validation.get("error"):
                    report.evidence.append(f"{path}: validation unavailable: {validation['error']}")
                else:
                    result = validation.get("result", {})
                    if not result.get("syntax_valid", True):
                        report.findings.append(
                            f"{path}: syntax error likely contributes to the failure: "
                            f"{result.get('syntax_error', 'unknown error')}"
                        )
                    missing_metadata = result.get("missing_metadata") or []
                    if missing_metadata:
                        report.evidence.append(f"{path}: missing metadata fields: {', '.join(missing_metadata)}")

            read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
            report.tool_activity.append(f"code_explorer read on {path}")
            if not read_result.get("error"):
                content = read_result.get("content") or ""
                line_count = len(str(content).splitlines())
                report.evidence.append(f"{path}: inspected {line_count} line(s) of source.")

        for command in commands[:1]:
            result = self._invoke_tool("shell_command", {"command": command, "timeout": 120})
            report.tool_activity.append(f"shell_command executed `{command}`")
            if result.get("error"):
                report.findings.append(f"Reproduction command failed to start: {result['error']}")
                continue
            returncode = int(result.get("returncode", -1))
            if returncode != 0:
                preview = (result.get("stderr") or result.get("stdout") or "").strip()
                report.evidence.append(f"Reproduction output: {preview[:400]}")
            else:
                report.evidence.append(f"Reproduction command `{command}` completed successfully.")

        if not report.findings:
            report.findings.append("No explicit failure signature was provided; root-cause analysis remains provisional.")
        if not report.actions:
            if paths:
                report.actions.append(f"Add targeted logging or assertions around the logic in {paths[0]}.")
            else:
                report.actions.append("Provide a traceback, affected file path, or reproduction command for deeper analysis.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            dependencies=paths or commands,
            risks=list(report.findings),
            artifacts=paths,
            missing_tools=missing,
            context=kwargs.get("context"),
        )

class RequirementsAgent(_RegistryBackedAgent):
    """Extract and normalize requirements from task text or requirement documents."""

    role_name = "requirements"
    system_prompt = (
        "Extract explicit requirements, normalize them into actionable statements, "
        "and highlight any ambiguity or missing acceptance criteria."
    )
    allowed_tool_names = manifest_allowed_tools("requirements")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Requirements analysis report",
            summary="Extracted candidate requirements and highlighted specification gaps.",
        )

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some requirements tools are unavailable: {', '.join(missing)}.")

        paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".md", ".txt", ".pdf", ".json", ".yaml", ".yml", ".toml"}
        ][:3]
        inspected_sources: List[str] = []
        requirement_ids = self._extract_requirement_ids(task)
        normative_lines = self._extract_normative_lines(task)

        for path in paths:
            content_result = self._invoke_tool("document_reader", {"source": path})
            report.tool_activity.append(f"document_reader read {path}")
            if content_result.get("error"):
                fallback = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read {path}")
                text = str(fallback.get("content") or "")
                if fallback.get("error"):
                    report.findings.append(f"{path}: requirements source could not be opened: {fallback['error']}")
                    continue
            else:
                text = str(content_result.get("result") or content_result.get("content") or "")
            inspected_sources.append(path)
            requirement_ids.extend(self._extract_requirement_ids(text))
            normative_lines.extend(self._extract_normative_lines(text))

        requirement_ids = self._dedupe(requirement_ids)
        normative_lines = self._dedupe(normative_lines)[:8]

        if requirement_ids:
            report.evidence.append(f"Referenced requirement IDs: {', '.join(requirement_ids)}")
        if inspected_sources:
            report.evidence.append(f"Inspected sources: {', '.join(inspected_sources)}")
        if normative_lines:
            report.findings.extend(f"Candidate requirement: {line}" for line in normative_lines[:5])
        else:
            report.findings.append("No explicit normative requirement statements were detected.")

        if not requirement_ids:
            report.actions.append("Assign stable IDs to the extracted requirements for traceability.")
        report.actions.append("Add acceptance criteria for each requirement before implementation planning.")
        if len(normative_lines) < 2:
            report.actions.append("Provide a fuller requirements document or user stories to reduce ambiguity.")
        specification_gaps = [
            item for item in report.findings
            if "No explicit normative" in item
        ]
        if not requirement_ids:
            specification_gaps.append("No stable requirement IDs were found in the provided inputs.")
        if len(normative_lines) < 2:
            specification_gaps.append("Requirement coverage appears thin; additional user stories or acceptance criteria are needed.")
        risk_items = self._dedupe(specification_gaps)
        if not risk_items:
            risk_items = ["Acceptance criteria and traceability should be confirmed before implementation."]
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=RequirementsOutputContract,
            outcome_labels=[],
            dependencies=requirement_ids or inspected_sources,
            risks=risk_items,
            artifacts=inspected_sources,
            missing_tools=missing,
            requirement_ids=requirement_ids,
            candidate_requirements=normative_lines,
            source_paths=inspected_sources,
            specification_gaps=self._dedupe(specification_gaps),
            context=kwargs.get("context"),
        )


class ArchitectureAgent(_RegistryBackedAgent):
    """Summarize repository structure and likely architectural boundaries."""

    role_name = "architecture"
    system_prompt = (
        "Inspect the repository structure, infer the high-level architecture, "
        "and surface coupling or boundary risks."
    )
    allowed_tool_names = manifest_allowed_tools("architecture")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Architecture analysis report",
            summary="Inspected the repository structure and summarized likely architectural boundaries.",
        )
        coupling_hotspots: List[str] = []
        inspected_paths: List[str] = []
        tree_preview_lines: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some architecture tools are unavailable: {', '.join(missing)}.")

        paths = self._extract_paths(task)[:3]
        tree_result = self._invoke_tool("code_explorer", {"action": "tree", "path": None})
        report.tool_activity.append("code_explorer tree on project root")
        tree_text = str(tree_result.get("tree") or "")
        if tree_result.get("error"):
            report.evidence.append(f"Repository tree unavailable: {tree_result['error']}")
        elif tree_text:
            tree_preview_lines = tree_text.splitlines()[:10]
            report.evidence.append("Repository tree preview:\n" + "\n".join(tree_preview_lines))

        if not paths:
            paths = [match.get("path", "") for match in (self._invoke_tool("code_explorer", {"action": "search", "pattern": "class ", "max_results": 3}).get("matches") or [])]
            if paths:
                report.tool_activity.append("code_explorer search for class declarations")

        inspected = 0
        for path in self._dedupe(path for path in paths if path)[:3]:
            if Path(path).suffix.lower() not in {".py", ".pyi", ".pyx"}:
                continue
            inspected_paths.append(path)
            parse_result = self._invoke_tool("code_analysis", {"action": "parse", "path": path})
            report.tool_activity.append(f"code_analysis parse on {path}")
            if parse_result.get("error"):
                report.findings.append(f"{path}: architecture parsing failed: {parse_result['error']}")
                continue
            parsed = parse_result.get("result", {})
            functions = parsed.get("functions") or []
            classes = parsed.get("classes") or []
            imports = parsed.get("imports") or []
            report.evidence.append(
                f"{path}: {len(classes)} class(es), {len(functions)} function(s), {len(imports)} import(s)."
            )
            if len(imports) > 12:
                hotspot = f"{path}: high import fan-in/out suggests a coupling hotspot."
                coupling_hotspots.append(hotspot)
                report.findings.append(hotspot)
            if classes and functions:
                report.findings.append(f"{path}: mixes object and procedural logic; confirm the intended boundary.")
            inspected += 1

        if inspected == 0:
            report.findings.append("No concrete Python modules were inspected; architecture summary is high-level only.")

        report.actions.append("Confirm bounded contexts and service ownership before code generation.")
        report.actions.append("Map external interfaces and data contracts for the components in scope.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=ArchitectureOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=inspected_paths,
            risks=coupling_hotspots or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            repository_tree_preview=tree_preview_lines,
            coupling_hotspots=coupling_hotspots,
            boundary_recommendations=list(report.actions),
            context=kwargs.get("context"),
        )


class CodebaseAnalysisAgent(_RegistryBackedAgent):
    """Inspect an existing repository and summarize onboarding-critical structure and hot spots."""

    role_name = "codebase_analysis"
    system_prompt = (
        "Inspect the repository tree, key manifests, and representative source files, "
        "then summarize frameworks, extension points, and onboarding risks."
    )
    allowed_tool_names = manifest_allowed_tools("codebase_analysis")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Codebase analysis report",
            summary="Inspected repository structure and key files to support onboarding and delivery planning.",
        )
        inspected_paths: List[str] = []
        tree_preview_lines: List[str] = []
        framework_signals: List[str] = []
        extension_points: List[str] = []
        hotspot_paths: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some codebase-analysis tools are unavailable: {', '.join(missing)}.")

        tree_result = self._invoke_tool("code_explorer", {"action": "tree", "path": None})
        report.tool_activity.append("code_explorer tree on project root")
        tree_text = str(tree_result.get("tree") or "")
        if tree_result.get("error"):
            report.evidence.append(f"Repository tree unavailable: {tree_result['error']}")
        elif tree_text:
            tree_preview_lines = tree_text.splitlines()[:12]
            report.evidence.append("Repository tree preview:\n" + "\n".join(tree_preview_lines))

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".py", ".pyi", ".pyx", ".toml", ".json", ".yaml", ".yml", ".md", ".txt"}
        ]
        candidate_paths.extend(["pyproject.toml", "package.json", "README.md", "Makefile"])
        candidate_paths = self._dedupe(candidate_paths)[:6]

        framework_tokens = {
            "fastapi": "FastAPI",
            "flask": "Flask",
            "django": "Django",
            "sqlalchemy": "SQLAlchemy",
            "pydantic": "Pydantic",
            "react": "React",
            "next": "Next.js",
            "vue": "Vue",
            "celery": "Celery",
            "pytest": "pytest",
        }

        for path in candidate_paths:
            read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
            report.tool_activity.append(f"code_explorer read on {path}")
            if read_result.get("error"):
                continue
            content = str(read_result.get("content") or "")
            inspected_paths.append(path)
            lowered = content.lower()
            for token, label in framework_tokens.items():
                if token in lowered:
                    framework_signals.append(f"{path}: {label}")
            if any(marker in lowered for marker in ("todo", "fixme", "deprecated", "legacy", "monolith")):
                hotspot_paths.append(f"{path}: manual review recommended due to legacy or unfinished markers.")
            if Path(path).suffix.lower() in {".py", ".pyi", ".pyx"}:
                parse_result = self._invoke_tool("code_analysis", {"action": "parse", "path": path})
                report.tool_activity.append(f"code_analysis parse on {path}")
                if not parse_result.get("error"):
                    parsed = parse_result.get("result", {})
                    imports = parsed.get("imports") or []
                    classes = parsed.get("classes") or []
                    functions = parsed.get("functions") or []
                    if len(imports) > 10:
                        hotspot_paths.append(f"{path}: high import count suggests a coupling hotspot.")
                    for klass in classes[:4]:
                        class_name = str(klass.get("name") or "")
                        if any(token in class_name.lower() for token in ("service", "manager", "controller", "adapter")):
                            extension_points.append(f"{path}: {class_name}")
                    for func in functions[:4]:
                        func_name = str(func.get("name") or "")
                        if any(token in func_name.lower() for token in ("build", "create", "handle", "process", "sync")):
                            extension_points.append(f"{path}: {func_name}")

        framework_signals = self._dedupe(framework_signals)[:8]
        extension_points = self._dedupe(extension_points)[:8]
        hotspot_paths = self._dedupe(hotspot_paths)[:8]

        if framework_signals:
            report.findings.extend(f"Framework signal: {item}" for item in framework_signals[:4])
        else:
            report.findings.append("No framework signals were confidently identified from the inspected files.")
        if extension_points:
            report.evidence.extend(f"Extension point: {item}" for item in extension_points[:4])
        else:
            report.evidence.append("No concrete extension points were detected in the inspected files.")
        if hotspot_paths:
            report.findings.extend(hotspot_paths[:4])

        report.actions.append("Build or refresh the code graph before implementation planning for this codebase.")
        report.actions.append("Map service boundaries, contracts, and repo ownership for the identified extension points.")
        report.actions.append("Capture environment assumptions and operator runbooks during onboarding.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=CodebaseAnalysisOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=inspected_paths,
            risks=hotspot_paths or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            repository_tree_preview=tree_preview_lines,
            framework_signals=framework_signals,
            extension_points=extension_points,
            hotspot_paths=hotspot_paths,
            onboarding_actions=list(report.actions),
            context=kwargs.get("context"),
        )


class BackendAgent(_RegistryBackedAgent):
    """Inspect backend modules and outline implementation surfaces and tasks."""

    role_name = "backend"
    system_prompt = (
        "Inspect backend modules, endpoints, and data models, then summarize the implementation surfaces "
        "and the highest-value backend tasks."
    )
    allowed_tool_names = manifest_allowed_tools("backend")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Backend implementation report",
            summary="Reviewed backend source surfaces and synthesized an implementation-oriented backend plan.",
        )
        inspected_paths: List[str] = []
        api_surfaces: List[str] = []
        data_models: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some backend tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".py", ".pyi", ".pyx", ".json", ".yaml", ".yml", ".toml"}
        ][:4]
        if not candidate_paths:
            report.findings.append("No backend module paths were provided, so the backend plan is high-level only.")
            report.actions.append("Provide API, service, repository, or schema paths for targeted backend planning.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=BackendOutputContract,
                inspected_paths=[],
                api_surfaces=[],
                data_models=[],
                implementation_tasks=list(report.actions),
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix in {".py", ".pyi", ".pyx"}:
                parse_result = self._invoke_tool("code_analysis", {"action": "parse", "path": path})
                report.tool_activity.append(f"code_analysis parse on {path}")
                if not parse_result.get("error"):
                    parsed = parse_result.get("result", {})
                    classes = parsed.get("classes") or []
                    for klass in classes[:6]:
                        class_name = str(klass.get("name") or "")
                        if any(token in class_name.lower() for token in ("model", "schema", "request", "response", "dto")):
                            data_models.append(f"{path}: {class_name}")
                    functions = parsed.get("functions") or []
                    if functions:
                        report.evidence.append(f"{path}: parsed {len(functions)} function(s) and {len(classes)} class(es).")
            read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
            report.tool_activity.append(f"code_explorer read on {path}")
            if read_result.get("error"):
                report.findings.append(f"{path}: backend source could not be inspected: {read_result['error']}")
                continue
            content = str(read_result.get("content") or "")
            api_surfaces.extend(f"{path}: {item}" for item in self._extract_route_signals(content, limit=4))
            if "basemodel" in content.lower() and not any(entry.startswith(f"{path}:") for entry in data_models):
                data_models.append(f"{path}: Pydantic/BaseModel usage detected.")

        api_surfaces = self._dedupe(api_surfaces)[:6]
        data_models = self._dedupe(data_models)[:6]

        if api_surfaces:
            report.findings.extend(f"API surface: {item}" for item in api_surfaces[:4])
        else:
            report.findings.append("No explicit backend route/controller surfaces were detected in the inspected files.")
        if data_models:
            report.evidence.extend(f"Data model surface: {item}" for item in data_models[:4])
        else:
            report.evidence.append("No explicit DTO/model classes were detected in the inspected backend files.")

        report.actions.append("Confirm request/response contracts for each backend surface before code generation.")
        report.actions.append("Map persistence boundaries and transaction ownership for the inspected backend modules.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=BackendOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=inspected_paths,
            risks=list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            api_surfaces=api_surfaces,
            data_models=data_models,
            implementation_tasks=list(report.actions),
            context=kwargs.get("context"),
        )


class FrontendAgent(_RegistryBackedAgent):
    """Inspect frontend modules and summarize UI routes, components, and UX risks."""

    role_name = "frontend"
    system_prompt = (
        "Inspect frontend files, route surfaces, and component structures, then summarize the implementation plan "
        "and UX risks."
    )
    allowed_tool_names = manifest_allowed_tools("frontend")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Frontend implementation report",
            summary="Reviewed frontend surfaces and identified route/component work needed for delivery.",
        )
        inspected_paths: List[str] = []
        route_surfaces: List[str] = []
        component_candidates: List[str] = []
        ux_risks: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some frontend tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".js", ".jsx", ".ts", ".tsx", ".css", ".scss", ".html", ".md"}
        ][:4]
        if not candidate_paths:
            report.findings.append("No frontend paths were provided, so the frontend plan is advisory only.")
            report.actions.append("Provide route, page, component, or design-doc paths for targeted frontend analysis.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=FrontendOutputContract,
                inspected_paths=[],
                route_surfaces=[],
                component_candidates=[],
                ux_risks=[],
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix == ".md":
                read_result = self._invoke_tool("document_reader", {"source": path})
                report.tool_activity.append(f"document_reader read {path}")
                content = str(read_result.get("result") or read_result.get("content") or "")
            else:
                read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read on {path}")
                if read_result.get("error"):
                    report.findings.append(f"{path}: frontend source could not be inspected: {read_result['error']}")
                    continue
                content = str(read_result.get("content") or "")
            route_surfaces.extend(f"{path}: {item}" for item in self._extract_route_signals(content, limit=4))
            component_candidates.extend(f"{path}: {item}" for item in self._extract_component_names(content, limit=6))
            lowered = content.lower()
            if "todo" in lowered or "placeholder" in lowered or "mock" in lowered:
                ux_risks.append(f"{path}: placeholder or mock UI content detected.")
            if "<form" in lowered and "required" not in lowered and "zod" not in lowered and "yup" not in lowered:
                ux_risks.append(f"{path}: form surface may be missing explicit validation.")

        route_surfaces = self._dedupe(route_surfaces)[:6]
        component_candidates = self._dedupe(component_candidates)[:8]
        ux_risks = self._dedupe(ux_risks)[:6]

        if route_surfaces:
            report.findings.extend(f"Route surface: {item}" for item in route_surfaces[:4])
        else:
            report.findings.append("No explicit route surfaces were detected in the inspected frontend files.")
        if component_candidates:
            report.evidence.extend(f"Component candidate: {item}" for item in component_candidates[:4])
        if ux_risks:
            report.findings.extend(ux_risks[:4])

        report.actions.append("Confirm screen flows, form validation, and loading/error states before UI generation.")
        report.actions.append("Define reusable component boundaries for the inspected frontend surfaces.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=FrontendOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=inspected_paths,
            risks=ux_risks or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            route_surfaces=route_surfaces,
            component_candidates=component_candidates,
            ux_risks=ux_risks,
            context=kwargs.get("context"),
        )


class IntegrationAgent(_RegistryBackedAgent):
    """Inspect service boundaries and external contracts to summarize integration work."""

    role_name = "integration"
    system_prompt = (
        "Inspect interface definitions, adapters, and config files, then summarize downstream dependencies, "
        "contract gaps, and integration tasks."
    )
    allowed_tool_names = manifest_allowed_tools("integration")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Integration analysis report",
            summary="Reviewed integration surfaces and identified dependency and contract risks.",
        )
        inspected_paths: List[str] = []
        dependency_endpoints: List[str] = []
        contract_gaps: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some integration tools are unavailable: {', '.join(missing)}.")

        candidate_paths = self._extract_paths(task)[:4]
        if not candidate_paths:
            report.findings.append("No integration-relevant files were provided, so the analysis is high-level only.")
            report.actions.append("Provide client, adapter, config, or contract files for targeted integration analysis.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=IntegrationOutputContract,
                inspected_paths=[],
                dependency_endpoints=[],
                contract_gaps=[],
                integration_tasks=list(report.actions),
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix in {".md", ".txt"}:
                read_result = self._invoke_tool("document_reader", {"source": path})
                report.tool_activity.append(f"document_reader read {path}")
                content = str(read_result.get("result") or read_result.get("content") or "")
            else:
                read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read on {path}")
                if read_result.get("error"):
                    report.findings.append(f"{path}: integration artifact could not be inspected: {read_result['error']}")
                    continue
                content = str(read_result.get("content") or "")

            dependency_endpoints.extend(f"{path}: {item}" for item in self._extract_endpoints(content, limit=6))
            dependency_endpoints.extend(f"{path}: {item}" for item in self._extract_integration_terms(content, limit=4))

            lowered = content.lower()
            if any(token in lowered for token in ("client", "adapter", "webhook", "queue", "topic", "endpoint")):
                if "timeout" not in lowered:
                    contract_gaps.append(f"{path}: integration surface does not mention timeout handling.")
                if "retry" not in lowered:
                    contract_gaps.append(f"{path}: integration surface does not mention retry strategy.")
                if "auth" not in lowered and "token" not in lowered and "apikey" not in lowered:
                    contract_gaps.append(f"{path}: integration surface does not mention authentication requirements.")

        dependency_endpoints = self._dedupe(dependency_endpoints)[:8]
        contract_gaps = self._dedupe(contract_gaps)[:6]

        if dependency_endpoints:
            report.findings.extend(f"Dependency surface: {item}" for item in dependency_endpoints[:4])
        else:
            report.findings.append("No explicit external dependency surfaces were detected in the inspected artifacts.")
        if contract_gaps:
            report.findings.extend(contract_gaps[:4])
        else:
            report.evidence.append("No obvious timeout/retry/auth gaps were detected in the inspected integration surfaces.")

        report.actions.append("Define explicit timeout, retry, and auth expectations for each downstream dependency.")
        report.actions.append("Pin request/response or event contracts before implementation waves begin.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=IntegrationOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=dependency_endpoints,
            risks=contract_gaps or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            dependency_endpoints=dependency_endpoints,
            contract_gaps=contract_gaps,
            integration_tasks=list(report.actions),
            context=kwargs.get("context"),
        )


class DataEngineeringAgent(_RegistryBackedAgent):
    """Inspect schema, migration, and data-pipeline artifacts for enterprise delivery work."""

    role_name = "data_engineering"
    system_prompt = (
        "Inspect schema, migration, ETL, and data-pipeline artifacts, then summarize data surfaces, "
        "migration risks, and the next implementation steps."
    )
    allowed_tool_names = manifest_allowed_tools("data_engineering")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Data engineering analysis report",
            summary="Reviewed data surfaces and identified migration and compatibility risks.",
        )
        inspected_paths: List[str] = []
        data_surfaces: List[str] = []
        schema_changes: List[str] = []
        migration_risks: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some data-engineering tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".py", ".sql", ".yaml", ".yml", ".json", ".toml", ".md", ".txt", ".csv"}
        ][:5]
        if not candidate_paths:
            report.findings.append("No schema, migration, or pipeline artifacts were provided for analysis.")
            report.actions.append("Provide migration, schema, ETL, or warehouse paths for targeted data analysis.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=DataEngineeringOutputContract,
                inspected_paths=[],
                data_surfaces=[],
                schema_changes=[],
                migration_risks=[],
                data_tasks=list(report.actions),
                missing_tools=missing,
                context=kwargs.get("context"),
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix in {".md", ".txt"}:
                read_result = self._invoke_tool("document_reader", {"source": path})
                report.tool_activity.append(f"document_reader read {path}")
                content = str(read_result.get("result") or read_result.get("content") or "")
            else:
                read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read on {path}")
                if read_result.get("error"):
                    report.findings.append(f"{path}: data artifact could not be inspected: {read_result['error']}")
                    continue
                content = str(read_result.get("content") or "")
            lowered = content.lower()

            for raw_line in content.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                if DATA_PATTERN.search(line):
                    data_surfaces.append(f"{path}: {line[:180]}")
                if any(token in lowered for token in ("alter table", "create table", "drop table", "rename column", "add column", "migration")):
                    if any(token in line.lower() for token in ("alter table", "create table", "drop table", "rename column", "add column", "migration")):
                        schema_changes.append(f"{path}: {line[:180]}")
                if len(data_surfaces) >= 10 and len(schema_changes) >= 8:
                    break

            if suffix in {".py", ".pyi", ".pyx"}:
                parse_result = self._invoke_tool("code_analysis", {"action": "parse", "path": path})
                report.tool_activity.append(f"code_analysis parse on {path}")
                if not parse_result.get("error"):
                    parsed = parse_result.get("result", {})
                    for klass in parsed.get("classes") or []:
                        class_name = str(klass.get("name") or "")
                        if any(token in class_name.lower() for token in ("schema", "model", "record", "dataset")):
                            data_surfaces.append(f"{path}: {class_name}")

            if any(token in lowered for token in ("drop table", "delete from", "truncate", "backfill", "repartition")):
                migration_risks.append(f"{path}: destructive or large-scale data operation detected.")
            if "rollback" not in lowered and any(token in lowered for token in ("migration", "alter table", "backfill")):
                migration_risks.append(f"{path}: migration or backfill logic does not mention rollback handling.")

        data_surfaces = self._dedupe(data_surfaces)[:8]
        schema_changes = self._dedupe(schema_changes)[:8]
        migration_risks = self._dedupe(migration_risks)[:8]

        if data_surfaces:
            report.findings.extend(f"Data surface: {item}" for item in data_surfaces[:4])
        else:
            report.findings.append("No clear data surfaces were detected in the inspected artifacts.")
        if schema_changes:
            report.evidence.extend(f"Schema change: {item}" for item in schema_changes[:4])
        if migration_risks:
            report.findings.extend(migration_risks[:4])

        report.actions.append("Confirm migration ordering, rollback safety, and downstream data dependencies before execution.")
        report.actions.append("Define validation queries or reconciliation checks for the affected datasets.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=DataEngineeringOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=data_surfaces or inspected_paths,
            risks=migration_risks or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            data_surfaces=data_surfaces,
            schema_changes=schema_changes,
            migration_risks=migration_risks,
            data_tasks=list(report.actions),
            context=kwargs.get("context"),
        )


class ContractAgent(_RegistryBackedAgent):
    """Inspect interface definitions and compatibility surfaces for APIs, events, and DTOs."""

    role_name = "contract"
    system_prompt = (
        "Inspect API, schema, and event contracts, then summarize compatibility risks, impacted consumers, "
        "and validation obligations."
    )
    allowed_tool_names = manifest_allowed_tools("contract")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Contract analysis report",
            summary="Reviewed interface and schema surfaces to identify compatibility and validation requirements.",
        )
        inspected_paths: List[str] = []
        contract_surfaces: List[str] = []
        compatibility_risks: List[str] = []
        impacted_consumers: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some contract-analysis tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".py", ".json", ".yaml", ".yml", ".proto", ".graphql", ".gql", ".avsc", ".md", ".txt"}
        ][:5]
        if not candidate_paths:
            report.findings.append("No contract or interface artifacts were provided for analysis.")
            report.actions.append("Provide API spec, DTO, event, or schema files for targeted contract analysis.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=ContractAnalysisOutputContract,
                inspected_paths=[],
                contract_surfaces=[],
                compatibility_risks=[],
                impacted_consumers=[],
                validation_obligations=list(report.actions),
                missing_tools=missing,
                context=kwargs.get("context"),
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix in {".md", ".txt"}:
                read_result = self._invoke_tool("document_reader", {"source": path})
                report.tool_activity.append(f"document_reader read {path}")
                content = str(read_result.get("result") or read_result.get("content") or "")
            else:
                read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read on {path}")
                if read_result.get("error"):
                    report.findings.append(f"{path}: contract artifact could not be inspected: {read_result['error']}")
                    continue
                content = str(read_result.get("content") or "")
            lowered = content.lower()

            for raw_line in content.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                if CONTRACT_SIGNAL_PATTERN.search(line):
                    contract_surfaces.append(f"{path}: {line[:180]}")
                if any(token in line.lower() for token in ("breaking", "deprecated", "required", "removed", "renamed")):
                    compatibility_risks.append(f"{path}: {line[:180]}")
                if any(token in line.lower() for token in ("consumer", "client", "subscriber", "provider")):
                    impacted_consumers.append(f"{path}: {line[:180]}")
                if len(contract_surfaces) >= 10:
                    break

            if "required" in lowered and "optional" not in lowered:
                compatibility_risks.append(f"{path}: required-field changes may break downstream consumers.")
            if "deprecated" in lowered:
                impacted_consumers.append(f"{path}: deprecation markers indicate consumer coordination is needed.")

        contract_surfaces = self._dedupe(contract_surfaces)[:8]
        compatibility_risks = self._dedupe(compatibility_risks)[:8]
        impacted_consumers = self._dedupe(impacted_consumers)[:8]

        if contract_surfaces:
            report.findings.extend(f"Contract surface: {item}" for item in contract_surfaces[:4])
        else:
            report.findings.append("No clear contract surfaces were detected in the inspected artifacts.")
        if compatibility_risks:
            report.findings.extend(compatibility_risks[:4])
        if impacted_consumers:
            report.evidence.extend(f"Impacted consumer: {item}" for item in impacted_consumers[:4])

        report.actions.append("Define compatibility guarantees and test obligations before changing published contracts.")
        report.actions.append("Coordinate consumer/provider rollout sequencing for any required or breaking changes.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=ContractAnalysisOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=contract_surfaces or inspected_paths,
            risks=compatibility_risks or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            contract_surfaces=contract_surfaces,
            compatibility_risks=compatibility_risks,
            impacted_consumers=impacted_consumers,
            validation_obligations=list(report.actions),
            context=kwargs.get("context"),
        )


class PlatformOperationsAgent(_RegistryBackedAgent):
    """Inspect deployment and runtime artifacts to summarize operational assumptions and rollout risks."""

    role_name = "platform_operations"
    system_prompt = (
        "Inspect infrastructure and runtime artifacts, then summarize environment assumptions, operational risks, "
        "and rollback or readiness actions."
    )
    allowed_tool_names = manifest_allowed_tools("platform_operations")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Platform operations report",
            summary="Reviewed runtime and deployment artifacts to identify operational assumptions and risks.",
        )
        inspected_paths: List[str] = []
        environment_assumptions: List[str] = []
        infrastructure_changes: List[str] = []
        operational_risks: List[str] = []
        rollback_actions: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some platform-operations tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".yaml", ".yml", ".json", ".toml", ".md", ".txt", ".sh", ".cfg", ".conf", ".ini"}
        ][:5]
        commands = self._extract_release_commands(task)[:2]

        if not candidate_paths and not commands:
            report.findings.append("No deployment manifests, runtime config, or rollout commands were provided.")
            report.actions.append("Provide deployment manifests, infra config, or approved runtime commands for analysis.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=PlatformOperationsOutputContract,
                inspected_paths=[],
                environment_assumptions=[],
                infrastructure_changes=[],
                operational_risks=[],
                rollback_actions=[],
                missing_tools=missing,
                context=kwargs.get("context"),
            )

        for path in candidate_paths:
            inspected_paths.append(path)
            if Path(path).suffix.lower() in {".md", ".txt"}:
                read_result = self._invoke_tool("document_reader", {"source": path})
                report.tool_activity.append(f"document_reader read {path}")
                content = str(read_result.get("result") or read_result.get("content") or "")
            else:
                read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
                report.tool_activity.append(f"code_explorer read on {path}")
                if read_result.get("error"):
                    report.findings.append(f"{path}: runtime artifact could not be inspected: {read_result['error']}")
                    continue
                content = str(read_result.get("content") or "")
            lowered = content.lower()

            for raw_line in content.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                if INFRA_PATTERN.search(line):
                    infrastructure_changes.append(f"{path}: {line[:180]}")
                if any(token in line.lower() for token in ("env", "secret", "configmap", "namespace", "replicas", "resources", "cpu", "memory")):
                    environment_assumptions.append(f"{path}: {line[:180]}")
                if any(token in line.lower() for token in ("rollback", "revert", "restore", "fallback")):
                    rollback_actions.append(f"{path}: {line[:180]}")
                if len(infrastructure_changes) >= 10:
                    break

            if "readiness" not in lowered and "liveness" not in lowered and any(token in lowered for token in ("deployment", "container", "service")):
                operational_risks.append(f"{path}: readiness/liveness or equivalent health checks are not obvious.")
            if "secret" in lowered and "external" not in lowered and "vault" not in lowered:
                operational_risks.append(f"{path}: secret handling may rely on inline platform configuration.")
            if "rollback" not in lowered and any(token in lowered for token in ("deployment", "migration", "cutover")):
                rollback_actions.append(f"{path}: define rollback ownership and execution steps before rollout.")

        for command in commands:
            result = self._invoke_tool("shell_command", {"command": command, "timeout": 60})
            report.tool_activity.append(f"shell_command executed `{command}`")
            if result.get("error"):
                operational_risks.append(f"`{command}` could not run under current policy: {result['error']}")
                continue
            if int(result.get("returncode", -1)) != 0:
                operational_risks.append(f"`{command}` failed during operational validation.")

        environment_assumptions = self._dedupe(environment_assumptions)[:8]
        infrastructure_changes = self._dedupe(infrastructure_changes)[:8]
        operational_risks = self._dedupe(operational_risks)[:8]
        rollback_actions = self._dedupe(rollback_actions)[:8]

        if infrastructure_changes:
            report.findings.extend(f"Infrastructure signal: {item}" for item in infrastructure_changes[:4])
        else:
            report.findings.append("No clear infrastructure or runtime changes were detected in the inspected artifacts.")
        if environment_assumptions:
            report.evidence.extend(f"Environment assumption: {item}" for item in environment_assumptions[:4])
        if operational_risks:
            report.findings.extend(operational_risks[:4])

        report.actions.append("Confirm runtime prerequisites, health checks, and rollback ownership before deployment.")
        report.actions.append("Capture operator-visible environment assumptions in a runbook or release artifact.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=PlatformOperationsOutputContract,
            outcome_labels=["runbook"],
            dependencies=infrastructure_changes or inspected_paths or commands,
            risks=operational_risks or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            environment_assumptions=environment_assumptions,
            infrastructure_changes=infrastructure_changes,
            operational_risks=operational_risks,
            rollback_actions=rollback_actions,
            context=kwargs.get("context"),
        )


class ReleaseAgent(_RegistryBackedAgent):
    """Inspect release artifacts and commands to summarize release readiness and rollback needs."""

    role_name = "release"
    system_prompt = (
        "Inspect release manifests, packaging metadata, and release commands, then summarize release readiness, "
        "risks, and rollback steps."
    )
    allowed_tool_names = manifest_allowed_tools("release")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Release readiness report",
            summary="Reviewed release inputs and synthesized a release-readiness and rollback plan.",
        )
        inspected_paths: List[str] = []
        release_risks: List[str] = []
        rollback_actions: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some release tools are unavailable: {', '.join(missing)}.")

        candidate_paths = [
            path for path in self._extract_paths(task)
            if Path(path).suffix.lower() in {".toml", ".yaml", ".yml", ".json", ".md", ".txt"}
        ][:4]
        commands = self._extract_release_commands(task)[:3]

        for path in candidate_paths:
            inspected_paths.append(path)
            read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
            report.tool_activity.append(f"code_explorer read on {path}")
            if read_result.get("error"):
                report.findings.append(f"{path}: release artifact could not be inspected: {read_result['error']}")
                continue
            content = str(read_result.get("content") or "")
            lowered = content.lower()
            if "version" not in lowered:
                release_risks.append(f"{path}: release metadata does not mention a version identifier.")
            if "rollback" not in lowered and "revert" not in lowered:
                release_risks.append(f"{path}: rollback guidance is missing from the inspected release artifact.")
            if "migration" in lowered and "rollback" not in lowered:
                rollback_actions.append(f"{path}: define rollback steps for schema/data migrations before release.")

        for command in commands:
            result = self._invoke_tool("shell_command", {"command": command, "timeout": 120})
            report.tool_activity.append(f"shell_command executed `{command}`")
            if result.get("error"):
                release_risks.append(f"`{command}` could not run under current tool policy: {result['error']}")
                continue
            returncode = int(result.get("returncode", -1))
            if returncode == 0:
                report.evidence.append(f"`{command}` completed successfully.")
            else:
                release_risks.append(f"`{command}` failed with return code {returncode}.")
                stderr = str(result.get("stderr") or result.get("stdout") or "")
                if stderr:
                    report.evidence.append(stderr[:400])

        if not commands:
            report.findings.append("No explicit release commands were supplied for readiness validation.")

        release_risks = self._dedupe(release_risks)[:6]
        rollback_actions = self._dedupe(rollback_actions)[:6]

        if release_risks:
            report.findings.extend(release_risks[:4])
        report.actions.append("Confirm release promotion criteria, artifact versioning, and rollback ownership.")
        report.actions.append("Run the approved build/release commands in a controlled environment before cutover.")
        if not rollback_actions:
            rollback_actions.append("Prepare an operator-readable rollback procedure for code, config, and schema changes.")
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=ReleaseOutputContract,
            outcome_labels=["runbook"],
            dependencies=commands or inspected_paths,
            risks=release_risks or list(report.findings),
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            candidate_commands=commands,
            release_risks=release_risks,
            rollback_actions=rollback_actions,
            context=kwargs.get("context"),
        )


class SecurityComplianceAgent(_RegistryBackedAgent):
    """Inspect code and documents for obvious security and compliance risks."""

    role_name = "security_compliance"
    system_prompt = (
        "Look for hardcoded secrets, insecure transport, and missing security controls, "
        "then recommend the highest-priority remediation steps."
    )
    allowed_tool_names = manifest_allowed_tools("security_compliance")

    def run_task(self, task: str, *args, **kwargs) -> dict[str, Any] | str:
        structured = bool(kwargs.get("structured", False))
        report = AgentReport(
            title="Security and compliance report",
            summary="Scanned the supplied inputs for obvious security and compliance risks.",
        )
        inspected_paths: List[str] = []
        secret_findings: List[str] = []
        transport_findings: List[str] = []

        missing = self._missing_tools()
        if missing:
            report.findings.append(f"Some security tools are unavailable: {', '.join(missing)}.")

        paths = self._extract_paths(task)[:4]
        if not paths:
            report.findings.append("No file paths were provided, so the security review is advisory only.")
            report.actions.append("Provide paths to source files, config files, or policy documents for targeted review.")
            return self._finalize_report(
                task,
                report,
                structured=structured,
                contract_cls=SecurityComplianceOutputContract,
                inspected_paths=[],
                secret_findings=[],
                transport_findings=[],
                compliance_findings=list(report.findings),
            )

        for path in paths:
            inspected_paths.append(path)
            suffix = Path(path).suffix.lower()
            if suffix in {".py", ".pyi", ".pyx"}:
                validation = self._invoke_tool("code_analysis", {"action": "validate", "path": path})
                report.tool_activity.append(f"code_analysis validate on {path}")
                if validation.get("error"):
                    report.evidence.append(f"{path}: static validation unavailable: {validation['error']}")
                else:
                    result = validation.get("result", {})
                    if not result.get("syntax_valid", True):
                        report.findings.append(f"{path}: syntax issues may hide security defects.")
                    for warning in result.get("docstring_warnings") or []:
                        if "security" in warning.lower():
                            report.findings.append(f"{path}: {warning}")

            read_result = self._invoke_tool("code_explorer", {"action": "read", "path": path})
            report.tool_activity.append(f"code_explorer read on {path}")
            if read_result.get("error"):
                report.findings.append(f"{path}: unable to inspect file contents: {read_result['error']}")
                continue

            content = str(read_result.get("content") or "")
            lowered = content.lower()
            if SECRET_PATTERN.search(content):
                finding = f"{path}: potential hardcoded secret material detected."
                secret_findings.append(finding)
                report.findings.append(finding)
            if "http://" in lowered and "localhost" not in lowered and "127.0.0.1" not in lowered:
                finding = f"{path}: insecure HTTP endpoint detected; prefer TLS."
                transport_findings.append(finding)
                report.findings.append(finding)
            if "verify=false" in lowered or "ssl=false" in lowered:
                finding = f"{path}: disabled TLS verification detected."
                transport_findings.append(finding)
                report.findings.append(finding)
            if "allow_origins=['*']".replace(" ", "") in lowered.replace(" ", "") or "access-control-allow-origin: *" in lowered:
                report.findings.append(f"{path}: wildcard cross-origin policy detected.")

        if not report.findings:
            report.findings.append("No obvious hardcoded secrets or insecure transport patterns were found in the inspected files.")
        report.actions.append("Move any secrets to managed configuration and validate transport security on external endpoints.")
        report.actions.append("Add security regression checks before release for the touched modules.")
        compliance_findings = [
            item for item in report.findings
            if item not in secret_findings and item not in transport_findings
        ]
        return self._finalize_report(
            task,
            report,
            structured=structured,
            contract_cls=SecurityComplianceOutputContract,
            outcome_labels=["reusable_pattern"],
            dependencies=inspected_paths,
            risks=secret_findings + transport_findings + compliance_findings,
            artifacts=inspected_paths,
            missing_tools=missing,
            inspected_paths=inspected_paths,
            secret_findings=secret_findings,
            transport_findings=transport_findings,
            compliance_findings=compliance_findings,
            context=kwargs.get("context"),
        )


__all__ = [
    "AgentReport",
    "ArchitectureAgent",
    "ArchitectureOutputContract",
    "BackendAgent",
    "BackendOutputContract",
    "CodebaseAnalysisAgent",
    "CodebaseAnalysisOutputContract",
    "CodeReviewAgent",
    "ContractAgent",
    "ContractAnalysisOutputContract",
    "DataEngineeringAgent",
    "DataEngineeringOutputContract",
    "DebuggingAgent",
    "FrontendAgent",
    "FrontendOutputContract",
    "IntegrationAgent",
    "IntegrationOutputContract",
    "PlatformOperationsAgent",
    "PlatformOperationsOutputContract",
    "ReleaseAgent",
    "ReleaseOutputContract",
    "RequirementsAgent",
    "RequirementsOutputContract",
    "SpecialistHandoffContract",
    "render_specialist_contract",
    "SecurityComplianceAgent",
    "SecurityComplianceOutputContract",
    "SpecialistOutputContract",
    "TestingAgent",
]
