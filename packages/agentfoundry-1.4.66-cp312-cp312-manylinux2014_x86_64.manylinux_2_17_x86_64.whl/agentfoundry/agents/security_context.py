"""Security context for hierarchical agent execution.

Provides role-based access control for sub-agents, restricting which tools
each agent role is allowed to invoke.  Supports audit logging of tool access.

Implements Step 5 of MultiAgentCollaborationPlan.md.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Optional, Set

from agentfoundry.agents.specialist_manifests import SPECIALIST_TOOL_MANIFESTS

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ApprovalContext:
    """Approvals granted for a delivery/action execution window."""

    approved_tool_names: FrozenSet[str] = frozenset()
    approved_action_classes: FrozenSet[str] = frozenset()
    approver: str = ""
    reason: str = ""

    def approves(self, tool_name: str, action_class: str) -> bool:
        return tool_name in self.approved_tool_names or action_class in self.approved_action_classes


@dataclass(frozen=True)
class RolePolicy:
    """Defines what a given agent role is allowed to do.

    Attributes
    ----------
    role : str
        Name of the agent role (e.g. ``"code_review"``).
    allowed_tools : frozenset[str]
        Tool names the role may invoke.  An empty set means *no* tools.
    allow_shell : bool
        Whether the role may execute shell commands.
    allow_write : bool
        Whether the role may write/modify files.
    max_recursion : int
        Maximum number of tool-call round-trips for this role.
    """

    role: str
    allowed_tools: FrozenSet[str] = frozenset()
    authority_level: str = "read_only"
    allowed_action_classes: FrozenSet[str] = frozenset({"read"})
    approval_required_actions: FrozenSet[str] = frozenset()
    allow_shell: bool = False
    allow_write: bool = False
    max_recursion: int = 20


def _default_specialist_policies() -> Dict[str, RolePolicy]:
    policies: Dict[str, RolePolicy] = {}
    for manifest in SPECIALIST_TOOL_MANIFESTS.values():
        policies[manifest.role] = RolePolicy(
            role=manifest.role,
            allowed_tools=frozenset(manifest.allowed_tools),
            authority_level=manifest.authority_level,
            allowed_action_classes=frozenset(manifest.allowed_action_classes),
            approval_required_actions=frozenset(manifest.approval_required_actions),
            allow_shell=manifest.allow_shell,
            allow_write=manifest.allow_write,
            max_recursion=manifest.max_recursion,
        )
    return policies


# Sensible defaults for the shipped specialist agents.
DEFAULT_POLICIES: Dict[str, RolePolicy] = {
    **_default_specialist_policies(),
    "general": RolePolicy(
        role="general",
        allowed_tools=frozenset(),  # empty = all tools allowed
        authority_level="orchestrate",
        allowed_action_classes=frozenset({"read", "memory_write", "write", "build", "deploy"}),
        approval_required_actions=frozenset({"write", "build", "deploy"}),
        allow_shell=True,
        allow_write=True,
        max_recursion=20,
    ),
    "orchestrator": RolePolicy(
        role="orchestrator",
        allowed_tools=frozenset(),
        authority_level="orchestrate",
        allowed_action_classes=frozenset({"read", "memory_write", "write", "build", "deploy"}),
        approval_required_actions=frozenset({"write", "build", "deploy"}),
        allow_shell=True,
        allow_write=True,
        max_recursion=40,
    ),
}


@dataclass
class AuditEntry:
    """A single audit-log record for a tool access attempt."""

    timestamp: float
    agent_id: str
    role: str
    tool_name: str
    allowed: bool
    detail: str = ""


class SecurityContext:
    """Enforces role-based access control and records an audit trail.

    Parameters
    ----------
    policies : dict, optional
        Mapping of role name → ``RolePolicy``.  Falls back to
        ``DEFAULT_POLICIES`` for roles not explicitly provided.
    security_level : int
        Global security level.  0 = permissive (log-only), 1 = enforce,
        2 = strict (deny unknown roles).
    """

    def __init__(
        self,
        policies: Optional[Dict[str, RolePolicy]] = None,
        security_level: int = 1,
        approval_required_actions: Optional[Set[str]] = None,
        enforce_approval: bool = True,
        approval_context: Optional[ApprovalContext] = None,
    ) -> None:
        self._policies: Dict[str, RolePolicy] = dict(DEFAULT_POLICIES)
        if policies:
            self._policies.update(policies)
        self.security_level = security_level
        self.approval_required_actions: Set[str] = set(approval_required_actions or {"write", "build", "deploy"})
        self.enforce_approval = enforce_approval
        self._approval_context = approval_context or ApprovalContext()
        self._audit_log: List[AuditEntry] = []

    # ------------------------------------------------------------------
    # Policy management
    # ------------------------------------------------------------------

    def set_policy(self, policy: RolePolicy) -> None:
        self._policies[policy.role] = policy

    def get_policy(self, role: str) -> Optional[RolePolicy]:
        return self._policies.get(role)

    def set_approval_context(self, approval_context: Optional[ApprovalContext]) -> None:
        self._approval_context = approval_context or ApprovalContext()

    @property
    def approval_context(self) -> ApprovalContext:
        return self._approval_context

    def configure_approval_policy(
        self,
        *,
        approval_required_actions: Optional[Set[str]] = None,
        enforce_approval: Optional[bool] = None,
    ) -> None:
        if approval_required_actions is not None:
            self.approval_required_actions = set(approval_required_actions)
        if enforce_approval is not None:
            self.enforce_approval = bool(enforce_approval)

    # ------------------------------------------------------------------
    # Access control
    # ------------------------------------------------------------------

    def check_tool_access(
        self,
        agent_id: str,
        role: str,
        tool_name: str,
        *,
        tool_policy: Optional[Any] = None,
    ) -> bool:
        """Return ``True`` if *role* is allowed to invoke *tool_name*.

        Side-effect: appends an ``AuditEntry`` regardless of outcome.
        """
        policy = self._policies.get(role)

        if policy is None:
            # Unknown role
            if self.security_level >= 2:
                self._record(agent_id, role, tool_name, allowed=False, detail="unknown role (strict)")
                return False
            # Permissive / enforce: allow with warning
            logger.warning("No policy for role '%s'; defaulting to allow", role)
            self._record(agent_id, role, tool_name, allowed=True, detail="no policy, default allow")
            return True

        # Empty allowed_tools = unrestricted
        if policy.allowed_tools and tool_name not in policy.allowed_tools:
            if self.security_level == 0:
                logger.warning(
                    "Tool '%s' not in allowed set for role '%s' (permissive mode)",
                    tool_name,
                    role,
                )
                self._record(agent_id, role, tool_name, allowed=True, detail="denied by policy, allowed by permissive mode")
                return True
            self._record(agent_id, role, tool_name, allowed=False, detail="tool not in allowed set")
            return False

        action_class = str(getattr(tool_policy, "action_class", "read") or "read")
        if policy.allowed_action_classes and action_class not in policy.allowed_action_classes:
            if self.security_level == 0:
                self._record(
                    agent_id,
                    role,
                    tool_name,
                    allowed=True,
                    detail=f"action_class={action_class} exceeds role authority, allowed by permissive mode",
                )
                return True
            self._record(
                agent_id,
                role,
                tool_name,
                allowed=False,
                detail=f"action_class={action_class} not permitted for authority_level={policy.authority_level}",
            )
            return False

        required_actions = set(self.approval_required_actions)
        required_actions.update(policy.approval_required_actions)
        if self.enforce_approval and action_class in required_actions:
            if not self._approval_context.approves(tool_name, action_class):
                if self.security_level == 0:
                    self._record(
                        agent_id,
                        role,
                        tool_name,
                        allowed=True,
                        detail=f"approval required for action_class={action_class}, allowed by permissive mode",
                    )
                    return True
                self._record(
                    agent_id,
                    role,
                    tool_name,
                    allowed=False,
                    detail=f"approval required for action_class={action_class}",
                )
                return False

        self._record(agent_id, role, tool_name, allowed=True)
        return True

    def describe_role_policy(self, role: str) -> Dict[str, Any]:
        policy = self._policies.get(role)
        if policy is None:
            return {
                "role": role,
                "authority_level": "unknown",
                "allowed_tools": [],
                "allowed_action_classes": [],
                "approval_required_actions": [],
                "allow_shell": False,
                "allow_write": False,
                "max_recursion": 20,
            }
        return {
            "role": policy.role,
            "authority_level": policy.authority_level,
            "allowed_tools": sorted(policy.allowed_tools),
            "allowed_action_classes": sorted(policy.allowed_action_classes),
            "approval_required_actions": sorted(set(self.approval_required_actions).union(policy.approval_required_actions)),
            "allow_shell": policy.allow_shell,
            "allow_write": policy.allow_write,
            "max_recursion": policy.max_recursion,
        }

    def check_shell_access(self, agent_id: str, role: str) -> bool:
        """Return ``True`` if *role* may execute shell commands."""
        policy = self._policies.get(role)
        if policy is None:
            allowed = self.security_level < 2
            self._record(agent_id, role, "shell_command", allowed=allowed, detail="shell check, no policy")
            return allowed
        if not policy.allow_shell:
            if self.security_level == 0:
                self._record(agent_id, role, "shell_command", allowed=True, detail="shell denied by policy, allowed by permissive mode")
                return True
            self._record(agent_id, role, "shell_command", allowed=False, detail="shell not allowed for role")
            return False
        self._record(agent_id, role, "shell_command", allowed=True)
        return True

    def get_max_recursion(self, role: str) -> int:
        policy = self._policies.get(role)
        return policy.max_recursion if policy else 20

    # ------------------------------------------------------------------
    # Audit trail
    # ------------------------------------------------------------------

    @property
    def audit_log(self) -> List[AuditEntry]:
        return list(self._audit_log)

    def clear_audit_log(self) -> None:
        self._audit_log.clear()

    def _record(
        self,
        agent_id: str,
        role: str,
        tool_name: str,
        allowed: bool,
        detail: str = "",
    ) -> None:
        entry = AuditEntry(
            timestamp=time.time(),
            agent_id=agent_id,
            role=role,
            tool_name=tool_name,
            allowed=allowed,
            detail=detail,
        )
        self._audit_log.append(entry)
        if not allowed:
            logger.info(
                "SECURITY: denied %s (role=%s) access to tool '%s': %s",
                agent_id[:8],
                role,
                tool_name,
                detail,
            )

    def filter_tools(
        self,
        role: str,
        tool_names: List[str],
        *,
        agent_id: str = "policy_filter",
        tool_policies: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        """Return only the tool names that *role* is allowed to use."""
        allowed: List[str] = []
        for name in tool_names:
            policy = tool_policies.get(name) if tool_policies else None
            if self.check_tool_access(agent_id, role, name, tool_policy=policy):
                allowed.append(name)
        return allowed
