"""Hierarchical orchestrator for multi-agent collaboration.

Extends the flat Orchestrator with tree-structured agent swarms, task
decomposition, delegation to specialised sub-agents, and result aggregation.
Integrates with the knowledge graph for hierarchy persistence.

Implements Steps 3 & 4 of MultiAgentCollaborationPlan.md.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, Sequence

from langchain.agents import create_agent as _langchain_create_agent  # type: ignore
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.checkpoint.memory import MemorySaver

from agentfoundry.agents.base_agent import BaseAgent
from agentfoundry.agents.hierarchy import AgentNode, AgentStatus, HierarchyManager
from agentfoundry.agents.security_context import SecurityContext
from agentfoundry.agents.specialized_agents import (
    ArchitectureAgent,
    BackendAgent,
    CodebaseAnalysisAgent,
    CodeReviewAgent,
    ContractAgent,
    DataEngineeringAgent,
    DebuggingAgent,
    FrontendAgent,
    IntegrationAgent,
    PlatformOperationsAgent,
    ReleaseAgent,
    RequirementsAgent,
    SecurityComplianceAgent,
    SpecialistHandoffContract,
    TestingAgent,
    _RegistryBackedAgent,
    render_specialist_contract,
)
from agentfoundry.agents.specialist_manifests import get_specialist_manifest
from agentfoundry.llm.llm_factory import LLMFactory
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.utils.agent_config import AgentConfig

logger = logging.getLogger(__name__)


def create_agent(*, model, tools=None, prompt: str | None = None, **kwargs):
    if prompt is not None and "system_prompt" not in kwargs:
        kwargs["system_prompt"] = prompt
    return _langchain_create_agent(model=model, tools=tools, **kwargs)

# ── task decomposition prompt ──────────────────────────────────────────
_DECOMPOSITION_PROMPT = """\
You are a task decomposition engine.  Given a complex task, break it into
independent subtasks that can be assigned to specialist agents.

Available specialist roles:
- requirements: extract requirements, constraints, and acceptance criteria
- codebase_analysis: inspect an existing repository for topology, frameworks, extension points, and onboarding risks
- architecture: inspect repository structure and architectural boundaries
- backend: inspect backend modules, APIs, services, and data-model implementation work
- frontend: inspect UI routes, components, and frontend delivery risks
- integration: inspect service contracts, adapters, and external dependency boundaries
- data_engineering: inspect schema, migration, ETL, and data-pipeline work
- contract: inspect API, event, DTO, and schema contracts for compatibility risks
- platform_operations: inspect deployment, runtime, and operational rollout assumptions
- release: inspect release readiness, manifests, commands, and rollback needs
- code_review: static analysis, linting, style, maintainability
- testing: running test suites, proposing test commands
- debugging: traceback analysis, root-cause investigation
- security_compliance: inspect code and config for security/compliance risks
- general: anything that doesn't fit the above

Respond with a JSON array of objects.  Each object must have:
  "role": one of the roles above
  "task": a concise description of what this sub-agent should do

Example:
[
  {"role": "requirements", "task": "Extract the core requirements from docs/requirements.md"},
  {"role": "codebase_analysis", "task": "Inspect the existing repo structure and identify onboarding hot spots"},
  {"role": "architecture", "task": "Summarize the service boundaries in the payments repo"},
  {"role": "backend", "task": "Inspect the API and service implementation surfaces in services/orders.py"},
  {"role": "frontend", "task": "Inspect the checkout routes and components in web/src/routes/checkout.tsx"},
  {"role": "integration", "task": "Review partner adapter and webhook contracts in integrations/stripe.py"},
  {"role": "data_engineering", "task": "Inspect migrations and ETL jobs for schema and pipeline risks"},
  {"role": "contract", "task": "Review openapi/orders.yaml and DTO changes for compatibility risks"},
  {"role": "platform_operations", "task": "Inspect deployment manifests and runtime assumptions in deploy/prod.yaml"},
  {"role": "release", "task": "Validate the release manifest and build commands for the next deployment"},
  {"role": "code_review", "task": "Lint and validate app/models.py"},
  {"role": "testing", "task": "Run pytest -q tests/test_models.py"},
  {"role": "debugging", "task": "Investigate ImportError in worker.py:42"},
  {"role": "security_compliance", "task": "Inspect auth.py and config files for hardcoded secrets"}
]

Respond ONLY with the JSON array.
"""

# ── aggregation prompt ─────────────────────────────────────────────────
_AGGREGATION_PROMPT = """\
You are a result aggregator.  You received sub-results from specialist agents
that were each working on part of a larger task.

Original task: {original_task}

Sub-results:
{sub_results}

Synthesize the sub-results into a single, coherent response that addresses the
original task.  Highlight the most important findings and recommended actions.
"""

# Map role names to specialist agent classes
_ROLE_AGENT_MAP: Dict[str, type] = {
    "requirements": RequirementsAgent,
    "codebase_analysis": CodebaseAnalysisAgent,
    "architecture": ArchitectureAgent,
    "backend": BackendAgent,
    "frontend": FrontendAgent,
    "integration": IntegrationAgent,
    "data_engineering": DataEngineeringAgent,
    "contract": ContractAgent,
    "platform_operations": PlatformOperationsAgent,
    "release": ReleaseAgent,
    "code_review": CodeReviewAgent,
    "testing": TestingAgent,
    "debugging": DebuggingAgent,
    "security_compliance": SecurityComplianceAgent,
}

_HANDOFF_ROLE_ORDER: tuple[str, ...] = (
    "requirements",
    "codebase_analysis",
    "architecture",
    "contract",
    "backend",
    "frontend",
    "integration",
    "data_engineering",
    "code_review",
    "testing",
    "debugging",
    "security_compliance",
    "platform_operations",
    "release",
)


class HierarchicalOrchestrator(BaseAgent):
    """Orchestrator that decomposes tasks into a hierarchy of sub-agents.

    Parameters
    ----------
    tool_registry : ToolRegistry
        Registry containing available tools for sub-agents.
    config : AgentConfig
        Configuration for LLM, KGraph, etc.
    max_depth : int
        Maximum hierarchy depth (default 3).
    parallel : bool
        Whether to run independent sub-agents concurrently (default True).
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        config: AgentConfig,
        *,
        max_depth: int = None,
        parallel: bool = None,
        llm: Any = None,
        security_context: Optional[SecurityContext] = None,
    ) -> None:
        super().__init__()
        self.registry = tool_registry
        self.config = config

        # Resolve hierarchy config (explicit args take precedence over config)
        hier_cfg = getattr(config, "hierarchy", None)
        self.parallel = parallel if parallel is not None else (getattr(hier_cfg, "parallel", True))
        resolved_max_depth = max_depth if max_depth is not None else (getattr(hier_cfg, "max_depth", 5))

        # Security context
        security_level = getattr(hier_cfg, "security_level", 1) if hier_cfg else 1
        tool_policy_cfg = getattr(config, "tool_policy", None)
        self.security = security_context or SecurityContext(
            security_level=security_level,
            approval_required_actions=set(getattr(tool_policy_cfg, "approval_required_actions", ["write", "build", "deploy"])),
            enforce_approval=bool(getattr(tool_policy_cfg, "enforce_approval", True)),
        )

        # LLM for decomposition / aggregation
        self.llm = llm or LLMFactory.get_llm_model(config=self.config)

        # Resolve KGraph (best-effort; None is acceptable)
        kgraph = None
        try:
            from agentfoundry.kgraph.factory import KGraphFactory
            kgraph = KGraphFactory.get_instance().get_kgraph({"AGENT_CONFIG": self.config})
        except Exception as exc:
            logger.warning("KGraph unavailable for hierarchy persistence: %s", exc)

        self.hierarchy = HierarchyManager(
            max_depth=resolved_max_depth,
            kgraph=kgraph,
            org_id=config.org_id,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_task(self, task: str, *args, **kwargs) -> str:
        """Decompose *task*, delegate to sub-agents, aggregate results."""
        config = kwargs.get("config") or {
            "configurable": {"user_id": "default", "thread_id": "default"}
        }
        t0 = time.perf_counter()

        # 1. Create root node
        root = self.hierarchy.create_root(role="orchestrator", task=task)
        self.hierarchy.update_status(root.agent_id, AgentStatus.RUNNING)

        # 2. Decompose task into subtasks
        subtasks = self._decompose_task(task)
        if not subtasks:
            # Fallback: run as a single general task
            subtasks = [{"role": "general", "task": task}]

        # 3. Spawn child nodes
        child_nodes: List[AgentNode] = []
        for st in subtasks:
            try:
                child = self.hierarchy.add_child(
                    parent_id=root.agent_id,
                    role=st["role"],
                    task=st["task"],
                )
                child_nodes.append(child)
            except ValueError as exc:
                logger.warning("Could not add child: %s", exc)

        # 4. Execute sub-agents
        if self.parallel and len(child_nodes) > 1:
            self._execute_parallel(child_nodes, config)
        else:
            self._execute_sequential(child_nodes, config)

        # 5. Aggregate results
        results = self.hierarchy.aggregate_results(root.agent_id)
        if not results:
            # Include failed results too for context
            children = self.hierarchy.get_children(root.agent_id)
            results = [c.result for c in children if c.result]

        aggregated = self._aggregate_results(task, results, config)

        # 6. Update root status
        self.hierarchy.update_status(root.agent_id, AgentStatus.COMPLETED, result=aggregated)

        elapsed = int((time.perf_counter() - t0) * 1000)
        logger.info(
            "HierarchicalOrchestrator completed in %dms (%d subtasks, tree:\n%s)",
            elapsed,
            len(child_nodes),
            self.hierarchy.render_tree(root.agent_id),
        )
        return aggregated

    def chat(self, messages: list[dict], config: dict = None, additional: bool = False):
        last_msg = messages[-1]["content"] if messages else ""
        result = self.run_task(last_msg, config=config)
        if additional:
            root = self.hierarchy.get_roots()[-1] if self.hierarchy.get_roots() else None
            return result, self._build_additional_payload(root.agent_id if root else None)
        return result

    # ------------------------------------------------------------------
    # Task decomposition
    # ------------------------------------------------------------------

    def _decompose_task(self, task: str) -> List[Dict[str, str]]:
        """Use the LLM to break *task* into subtasks for specialist roles."""
        import json

        try:
            response = self.llm.invoke([
                SystemMessage(content=_DECOMPOSITION_PROMPT),
                HumanMessage(content=task),
            ])
            content = response.content if hasattr(response, "content") else str(response)

            # Extract JSON from response (handle markdown fences)
            text = content.strip()
            if text.startswith("```"):
                lines = text.splitlines()
                text = "\n".join(
                    line for line in lines
                    if not line.strip().startswith("```")
                )

            subtasks = json.loads(text)
            if not isinstance(subtasks, list):
                logger.warning("Decomposition did not return a list; falling back")
                return []

            # Validate structure
            valid = []
            for st in subtasks:
                if isinstance(st, dict) and "role" in st and "task" in st:
                    valid.append({"role": st["role"], "task": st["task"]})
            return valid

        except Exception as exc:
            logger.warning("Task decomposition failed: %s; falling back to single task", exc)
            return []

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def _execute_agent(self, node: AgentNode, config: dict) -> None:
        """Run a single sub-agent for *node* and update its status."""
        self.hierarchy.update_status(node.agent_id, AgentStatus.RUNNING)
        try:
            result, contract = self._run_specialist(node.agent_id, node.role, node.task, config)
            if contract:
                node.metadata["output_contract"] = contract
            self.hierarchy.update_status(node.agent_id, AgentStatus.COMPLETED, result=result)
        except Exception as exc:
            logger.error("Agent %s (role=%s) failed: %s", node.agent_id[:8], node.role, exc)
            self.hierarchy.update_status(
                node.agent_id, AgentStatus.FAILED, result=f"Error: {exc}"
            )

    def _execute_sequential(self, nodes: List[AgentNode], config: dict) -> None:
        for node in nodes:
            self._execute_agent(node, config)

    def _execute_parallel(self, nodes: List[AgentNode], config: dict) -> None:
        """Run sub-agents concurrently using asyncio."""

        async def _run_all():
            loop = asyncio.get_event_loop()
            tasks = [
                loop.run_in_executor(None, self._execute_agent, node, config)
                for node in nodes
            ]
            await asyncio.gather(*tasks, return_exceptions=True)

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Already inside an async context; fall back to sequential
                logger.info("Event loop already running; executing sub-agents sequentially")
                self._execute_sequential(nodes, config)
            else:
                loop.run_until_complete(_run_all())
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(_run_all())
            finally:
                loop.close()

    def _run_specialist(self, agent_id: str, role: str, task: str, config: dict) -> tuple[str, Optional[Dict[str, Any]]]:
        """Instantiate and run a specialist agent for the given *role*.

        Security checks are applied: the agent is only given tools that its
        role policy permits.
        """
        agent_cls = _ROLE_AGENT_MAP.get(role)
        if agent_cls is not None:
            candidate_agent = agent_cls(tool_registry=self.registry)
            get_tool_policy = getattr(self.registry, "get_tool_policy", None)
            allowed_tool_names = self.security.filter_tools(
                role,
                list(candidate_agent.allowed_tool_names),
                agent_id=agent_id,
                tool_policies={
                    name: get_tool_policy(name) if callable(get_tool_policy) else None
                    for name in candidate_agent.allowed_tool_names
                },
            )
            scoped_registry_factory = getattr(self.registry, "scoped_registry", None)
            scoped_registry = (
                scoped_registry_factory(allowed_tool_names)
                if callable(scoped_registry_factory)
                else self.registry
            )
            agent = agent_cls(tool_registry=scoped_registry)
            contract = agent.run_structured_task(task)
            return render_specialist_contract(contract), contract

        # General role: use an LLM-backed agent with security-filtered tools
        all_tool_names: List[str] = []
        tools = []
        if hasattr(self.registry, "as_langchain_tools"):
            tools = list(self.registry.as_langchain_tools())
            all_tool_names = [getattr(t, "name", "") for t in tools]

        get_tool_policy = getattr(self.registry, "get_tool_policy", None)
        allowed_names = set(
            self.security.filter_tools(
                role,
                all_tool_names,
                agent_id=agent_id,
                tool_policies={
                    name: get_tool_policy(name) if callable(get_tool_policy) else None
                    for name in all_tool_names
                },
            )
        )
        filtered_tools = [t for t in tools if getattr(t, "name", "") in allowed_names] if allowed_names != set(all_tool_names) else tools

        agent = create_agent(
            model=self.llm,
            tools=filtered_tools,
            prompt=(
                "You are a general-purpose assistant. Complete the assigned task "
                "using the available tools. Be concise and actionable."
            ),
            checkpointer=None,
            name=f"general_{role}",
        )
        response = agent.invoke(
            {"messages": [HumanMessage(content=task)]},
            config=config,
        )
        msgs = response.get("messages", [])
        if msgs:
            content = msgs[-1].content
            return content if isinstance(content, str) else str(content), None
        return "", None

    def _build_additional_payload(self, root_agent_id: Optional[str]) -> Dict[str, Any]:
        if not root_agent_id:
            return {"hierarchy": self.hierarchy.render_tree(), "nodes": [], "handoffs": []}
        nodes = self.hierarchy.get_subtree(root_agent_id)
        nodes_payload: List[Dict[str, Any]] = []
        for node in nodes:
            nodes_payload.append(
                {
                    "agent_id": node.agent_id,
                    "role": node.role,
                    "parent_id": node.parent_id,
                    "status": node.status.value,
                    "task": node.task,
                    "result": node.result,
                    "metadata": dict(node.metadata),
                    "depth": node.depth,
                }
            )
        return {
            "hierarchy": self.hierarchy.render_tree(root_agent_id),
            "root_agent_id": root_agent_id,
            "nodes": nodes_payload,
            "handoffs": self._build_handoff_payloads(root_agent_id, nodes),
        }

    @staticmethod
    def _role_sort_key(role: str) -> tuple[int, str]:
        try:
            return (_HANDOFF_ROLE_ORDER.index(role), role)
        except ValueError:
            return (len(_HANDOFF_ROLE_ORDER), role)

    def _build_handoff_payloads(self, root_agent_id: str, nodes: Sequence[AgentNode]) -> List[Dict[str, Any]]:
        root_children = [node for node in nodes if node.parent_id == root_agent_id]
        ordered_children = sorted(root_children, key=lambda node: self._role_sort_key(node.role))
        handoffs: List[Dict[str, Any]] = []
        for index, source_node in enumerate(ordered_children[:-1]):
            target_node = ordered_children[index + 1]
            source_contract = source_node.metadata.get("output_contract")
            if not isinstance(source_contract, dict):
                continue
            target_manifest = get_specialist_manifest(target_node.role)
            proposed_actions = [str(item) for item in source_contract.get("proposed_actions", []) or [] if str(item)]
            findings = [str(item) for item in source_contract.get("findings", []) or [] if str(item)]
            summary = str(source_contract.get("summary") or "")
            acceptance_criteria = proposed_actions[:3] or findings[:2] or ([summary] if summary else [])
            blocking_risks = [str(item) for item in source_contract.get("risks", []) or [] if str(item)] or findings[:3]
            handoff = SpecialistHandoffContract(
                source_agent_id=source_node.agent_id,
                source_role=source_node.role,
                target_agent_id=target_node.agent_id,
                target_role=target_node.role,
                task=target_node.task,
                required_inputs=list(target_manifest.required_inputs) if target_manifest else [],
                upstream_refs=[
                    f"agentrun:{source_node.agent_id}",
                    f"contract:{source_node.agent_id}:{source_contract.get('contract_type') or 'specialist_report'}",
                ],
                acceptance_criteria=acceptance_criteria,
                blocking_risks=blocking_risks[:4],
                summary=(
                    f"Handoff {source_node.role} -> {target_node.role}: "
                    f"{summary[:180] or target_node.task[:180]}"
                ),
            )
            handoffs.append(handoff.to_dict())
        return handoffs

    # ------------------------------------------------------------------
    # Aggregation
    # ------------------------------------------------------------------

    def _aggregate_results(self, original_task: str, results: List[str], config: dict) -> str:
        """Use the LLM to synthesize sub-results into a single response."""
        if not results:
            return "No results were produced by the sub-agents."

        if len(results) == 1:
            return results[0]

        sub_results_text = "\n\n---\n\n".join(
            f"Sub-result {i + 1}:\n{r}" for i, r in enumerate(results)
        )
        prompt = _AGGREGATION_PROMPT.format(
            original_task=original_task,
            sub_results=sub_results_text,
        )
        try:
            response = self.llm.invoke([
                SystemMessage(content=prompt),
                HumanMessage(content="Please aggregate the above sub-results."),
            ])
            content = response.content if hasattr(response, "content") else str(response)
            return content
        except Exception as exc:
            logger.warning("Aggregation LLM call failed: %s; returning concatenated results", exc)
            return sub_results_text
