"""Shell command execution tool for coding agents.

Generalized subprocess execution following python_code_executer.py patterns.
Returns structured output with stdout, stderr, and returncode.
Command allowlist/blocklist configurable.
"""

import logging
import shlex
import subprocess
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)

# Configurable allow/block lists
_BLOCKED_COMMANDS: List[str] = ["rm -rf /", "mkfs", "dd if=", ":(){", "fork bomb"]
_ALLOWED_COMMANDS: Optional[List[str]] = None  # None means all allowed
_DEFAULT_TIMEOUT: int = 60
_DEFAULT_CWD: Optional[str] = None


class ShellCommandInput(BaseModel):
    command: str = Field(..., description="Shell command to execute.")
    timeout: Optional[int] = Field(None, description="Timeout in seconds (default: 60).")
    cwd: Optional[str] = Field(None, description="Working directory for the command.")


def _is_command_allowed(command: str) -> bool:
    """Check command against allow/block lists."""
    cmd_lower = command.lower().strip()
    for blocked in _BLOCKED_COMMANDS:
        if blocked.lower() in cmd_lower:
            return False
    if _ALLOWED_COMMANDS is not None:
        cmd_base = shlex.split(command)[0] if command.strip() else ""
        if cmd_base not in _ALLOWED_COMMANDS:
            return False
    return True


def shell_command(
    command: str,
    timeout: Optional[int] = None,
    cwd: Optional[str] = None,
) -> Dict[str, object]:
    """
    Execute a shell command and return structured output.

    Returns a dict with 'stdout', 'stderr', and 'returncode'.
    Commands are checked against a configurable blocklist for safety.
    """
    logger.info("shell_command: %s", command[:200])

    if not command.strip():
        return {"error": "Empty command."}

    if not _is_command_allowed(command):
        return {"error": f"Command blocked by security policy: {command}"}

    effective_timeout = timeout or _DEFAULT_TIMEOUT
    effective_cwd = cwd or _DEFAULT_CWD

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=effective_timeout,
            cwd=effective_cwd,
        )
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after {effective_timeout}s.", "returncode": -1}
    except Exception as ex:
        logger.error("shell_command error: %s", ex, exc_info=True)
        return {"error": str(ex), "returncode": -1}


shell_command_tool = StructuredTool.from_function(
    func=shell_command,
    name="shell_command",
    description=shell_command.__doc__,
    args_schema=ShellCommandInput,
)
