"""Diff and patch tool for coding agents.

Provides diff generation (via difflib), patch application, and
search/replace editing — the most reliable edit pattern for LLM agents.
"""

import difflib
import logging
from pathlib import Path
from typing import Dict, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)


class DiffPatchInput(BaseModel):
    action: str = Field(
        ...,
        description="Action: 'generate_diff', 'apply_patch', or 'apply_edit'.",
    )
    path: Optional[str] = Field(None, description="File path relative to project root.")
    original: Optional[str] = Field(None, description="Original text for 'generate_diff'.")
    modified: Optional[str] = Field(None, description="Modified text for 'generate_diff'.")
    patch: Optional[str] = Field(None, description="Unified diff patch text for 'apply_patch'.")
    search: Optional[str] = Field(None, description="Text to find for 'apply_edit'.")
    replace: Optional[str] = Field(None, description="Replacement text for 'apply_edit'.")


def _get_root() -> Path:
    return Path.cwd()


def diff_patch(
    action: str,
    path: Optional[str] = None,
    original: Optional[str] = None,
    modified: Optional[str] = None,
    patch: Optional[str] = None,
    search: Optional[str] = None,
    replace: Optional[str] = None,
) -> Dict[str, object]:
    """
    Generate diffs, apply patches, or perform search/replace edits.

    Actions:
      - generate_diff: Generate a unified diff between 'original' and 'modified' text,
        or between a file's current content and 'modified'.
      - apply_patch: Apply a unified diff patch to a file.
      - apply_edit: Search and replace text in a file (most reliable LLM edit pattern).
    """
    logger.info("diff_patch: action=%s path=%s", action, path)
    root = _get_root()

    try:
        if action == "generate_diff":
            if path:
                fp = (root / path).resolve()
                if not fp.is_file():
                    return {"error": f"File not found: {path}"}
                orig_lines = fp.read_text(errors="ignore").splitlines(keepends=True)
                label_a = path
            elif original is not None:
                orig_lines = original.splitlines(keepends=True)
                label_a = "original"
            else:
                return {"error": "Provide 'path' or 'original' text for generate_diff."}

            if modified is None:
                return {"error": "Missing 'modified' text for generate_diff."}
            mod_lines = modified.splitlines(keepends=True)
            label_b = "modified"

            diff = difflib.unified_diff(orig_lines, mod_lines, fromfile=label_a, tofile=label_b)
            diff_text = "".join(diff)
            return {"diff": diff_text, "has_changes": bool(diff_text.strip())}

        if action == "apply_patch":
            if not path:
                return {"error": "Missing 'path' for apply_patch."}
            if not patch:
                return {"error": "Missing 'patch' text for apply_patch."}
            fp = (root / path).resolve()
            if not fp.is_file():
                return {"error": f"File not found: {path}"}

            original_lines = fp.read_text(errors="ignore").splitlines(keepends=True)
            patched_lines = _apply_unified_patch(original_lines, patch)
            if patched_lines is None:
                return {"error": "Failed to apply patch — context mismatch."}
            fp.write_text("".join(patched_lines))
            return {"status": "ok", "path": path}

        if action == "apply_edit":
            if not path:
                return {"error": "Missing 'path' for apply_edit."}
            if search is None:
                return {"error": "Missing 'search' text for apply_edit."}
            if replace is None:
                return {"error": "Missing 'replace' text for apply_edit."}
            fp = (root / path).resolve()
            if not fp.is_file():
                return {"error": f"File not found: {path}"}

            content = fp.read_text(errors="ignore")
            count = content.count(search)
            if count == 0:
                return {"error": "Search text not found.", "path": path}
            updated = content.replace(search, replace)
            fp.write_text(updated)
            return {"status": "ok", "replacements": count, "path": path}

        return {"error": f"Unknown action: {action}"}
    except Exception as ex:
        logger.error("diff_patch error: %s", ex, exc_info=True)
        return {"error": str(ex)}


def _apply_unified_patch(original_lines: list, patch_text: str) -> Optional[list]:
    """Apply a unified diff patch to a list of lines. Returns None on failure."""
    result = list(original_lines)
    offset = 0

    for line in patch_text.splitlines(keepends=True):
        line_stripped = line.rstrip("\n\r")
        if line_stripped.startswith("@@"):
            import re
            m = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line_stripped)
            if m:
                orig_start = int(m.group(1)) - 1 + offset
                current_pos = orig_start
            continue
        if line_stripped.startswith("---") or line_stripped.startswith("+++"):
            continue
        if not line_stripped:
            continue

        if line_stripped.startswith("-"):
            if 0 <= current_pos < len(result):
                result.pop(current_pos)
                offset -= 1
            else:
                return None
        elif line_stripped.startswith("+"):
            content = line_stripped[1:] + "\n"
            result.insert(current_pos, content)
            current_pos += 1
            offset += 1
        elif line_stripped.startswith(" "):
            current_pos += 1

    return result


diff_patch_tool = StructuredTool.from_function(
    func=diff_patch,
    name="diff_patch",
    description=diff_patch.__doc__,
    args_schema=DiffPatchInput,
)
