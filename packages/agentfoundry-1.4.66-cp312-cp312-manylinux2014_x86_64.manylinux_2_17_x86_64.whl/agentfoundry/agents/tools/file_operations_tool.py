"""File operations tool for coding agents.

Extends the read-only code_explorer_tool with mutation capabilities:
write, read, append, edit (search/replace), delete, move, copy, mkdir.
All paths are resolved relative to a project root with traversal protection.
"""

import logging
import shutil
from pathlib import Path
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)

# Default project root; can be overridden via sandbox integration
_PROJECT_ROOT: Optional[Path] = None


def _get_project_root() -> Path:
    return _PROJECT_ROOT or Path.cwd()


def _resolve_safe(path_str: str) -> Path:
    """Resolve *path_str* relative to project root, blocking traversal."""
    root = _get_project_root()
    resolved = (root / path_str).resolve()
    if not str(resolved).startswith(str(root.resolve())):
        raise PermissionError(f"Path traversal blocked: {path_str}")
    return resolved


class FileOperationsInput(BaseModel):
    action: str = Field(
        ...,
        description=(
            "Action to perform: 'write', 'read', 'append', 'edit', "
            "'delete', 'move', 'copy', or 'mkdir'."
        ),
    )
    path: Optional[str] = Field(None, description="Target file/directory path relative to project root.")
    content: Optional[str] = Field(None, description="Content for write/append actions.")
    search: Optional[str] = Field(None, description="Text to find for 'edit' (search/replace) action.")
    replace: Optional[str] = Field(None, description="Replacement text for 'edit' action.")
    destination: Optional[str] = Field(None, description="Destination path for 'move' or 'copy' actions.")
    create_parents: Optional[bool] = Field(True, description="Create parent directories if they don't exist.")


def file_operations(
    action: str,
    path: Optional[str] = None,
    content: Optional[str] = None,
    search: Optional[str] = None,
    replace: Optional[str] = None,
    destination: Optional[str] = None,
    create_parents: bool = True,
) -> Dict[str, object]:
    """
    Perform file system operations for coding tasks.

    Actions:
      - write: Write content to a file (creates or overwrites).
      - read: Read the content of a file.
      - append: Append content to an existing file.
      - edit: Search and replace text within a file.
      - delete: Delete a file or empty directory.
      - move: Move/rename a file or directory.
      - copy: Copy a file or directory.
      - mkdir: Create a directory (and parents).
    """
    logger.info("file_operations: action=%s path=%s", action, path)
    try:
        if action == "write":
            if not path:
                return {"error": "Missing 'path' for write action."}
            if content is None:
                return {"error": "Missing 'content' for write action."}
            fp = _resolve_safe(path)
            if create_parents:
                fp.parent.mkdir(parents=True, exist_ok=True)
            fp.write_text(content)
            return {"status": "ok", "path": str(fp.relative_to(_get_project_root())), "bytes_written": len(content)}

        if action == "read":
            if not path:
                return {"error": "Missing 'path' for read action."}
            fp = _resolve_safe(path)
            if not fp.exists() or not fp.is_file():
                return {"error": f"File not found: {path}"}
            text = fp.read_text(errors="ignore")
            return {"content": text}

        if action == "append":
            if not path:
                return {"error": "Missing 'path' for append action."}
            if content is None:
                return {"error": "Missing 'content' for append action."}
            fp = _resolve_safe(path)
            if not fp.exists():
                return {"error": f"File not found: {path}"}
            with fp.open("a") as f:
                f.write(content)
            return {"status": "ok", "path": str(fp.relative_to(_get_project_root())), "bytes_appended": len(content)}

        if action == "edit":
            if not path:
                return {"error": "Missing 'path' for edit action."}
            if search is None:
                return {"error": "Missing 'search' for edit action."}
            if replace is None:
                return {"error": "Missing 'replace' for edit action."}
            fp = _resolve_safe(path)
            if not fp.exists() or not fp.is_file():
                return {"error": f"File not found: {path}"}
            original = fp.read_text(errors="ignore")
            count = original.count(search)
            if count == 0:
                return {"error": "Search text not found in file.", "path": path}
            updated = original.replace(search, replace)
            fp.write_text(updated)
            return {"status": "ok", "replacements": count, "path": str(fp.relative_to(_get_project_root()))}

        if action == "delete":
            if not path:
                return {"error": "Missing 'path' for delete action."}
            fp = _resolve_safe(path)
            if not fp.exists():
                return {"error": f"Path not found: {path}"}
            if fp.is_file():
                fp.unlink()
            elif fp.is_dir():
                shutil.rmtree(fp)
            return {"status": "ok", "deleted": str(fp.relative_to(_get_project_root()))}

        if action == "move":
            if not path or not destination:
                return {"error": "Missing 'path' or 'destination' for move action."}
            src = _resolve_safe(path)
            dst = _resolve_safe(destination)
            if not src.exists():
                return {"error": f"Source not found: {path}"}
            if create_parents:
                dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
            return {"status": "ok", "from": path, "to": destination}

        if action == "copy":
            if not path or not destination:
                return {"error": "Missing 'path' or 'destination' for copy action."}
            src = _resolve_safe(path)
            dst = _resolve_safe(destination)
            if not src.exists():
                return {"error": f"Source not found: {path}"}
            if create_parents:
                dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                shutil.copytree(str(src), str(dst))
            else:
                shutil.copy2(str(src), str(dst))
            return {"status": "ok", "from": path, "to": destination}

        if action == "mkdir":
            if not path:
                return {"error": "Missing 'path' for mkdir action."}
            fp = _resolve_safe(path)
            fp.mkdir(parents=create_parents, exist_ok=True)
            return {"status": "ok", "path": str(fp.relative_to(_get_project_root()))}

        return {"error": f"Unknown action: {action}"}
    except PermissionError as e:
        return {"error": str(e)}
    except Exception as ex:
        logger.error("file_operations error: %s", ex, exc_info=True)
        return {"error": str(ex)}


file_operations_tool = StructuredTool.from_function(
    func=file_operations,
    name="file_operations",
    description=file_operations.__doc__,
    args_schema=FileOperationsInput,
)
