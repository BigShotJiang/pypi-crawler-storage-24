"""Code analysis tool for coding agents.

Wraps CodeParser and CodeValidator from agentfoundry.code_gen as a
StructuredTool. Actions: parse, validate, lint, dependencies.
"""

import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)


class CodeAnalysisInput(BaseModel):
    action: str = Field(
        ...,
        description="Action: 'parse', 'validate', 'lint', or 'dependencies'.",
    )
    path: Optional[str] = Field(None, description="File path relative to project root.")
    code: Optional[str] = Field(None, description="Source code string (alternative to path).")
    linter: Optional[str] = Field(
        default="ruff",
        description="Linter to use for 'lint' action: 'ruff' or 'flake8'.",
    )


def code_analysis(
    action: str,
    path: Optional[str] = None,
    code: Optional[str] = None,
    linter: str = "ruff",
) -> Dict[str, object]:
    """
    Analyze Python source code for structure, validation, linting, or dependencies.

    Actions:
      - parse: Parse code into structured metadata (imports, functions, classes).
      - validate: Validate syntax, metadata, and docstrings.
      - lint: Run a linter (ruff or flake8) on a file.
      - dependencies: Extract all import statements from code.
    """
    logger.info("code_analysis: action=%s path=%s", action, path)

    try:
        source = _get_source(path, code)
        if isinstance(source, dict):
            return source  # error dict

        if action == "parse":
            from agentfoundry.code_gen.code_parser import CodeParser
            parser = CodeParser(source)
            return {"result": parser.parse()}

        if action == "validate":
            from agentfoundry.code_gen.code_validator import CodeValidator
            validator = CodeValidator(source)
            return {"result": validator.validate()}

        if action == "lint":
            if not path:
                return {"error": "Lint requires a file 'path'."}
            root = Path.cwd()
            fp = (root / path).resolve()
            if not fp.is_file():
                return {"error": f"File not found: {path}"}

            if linter == "ruff":
                cmd = ["ruff", "check", str(fp)]
            elif linter == "flake8":
                cmd = ["flake8", str(fp)]
            else:
                return {"error": f"Unsupported linter: {linter}"}

            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                issues = [line for line in result.stdout.strip().splitlines() if line.strip()]
                return {
                    "issues": issues,
                    "issue_count": len(issues),
                    "returncode": result.returncode,
                }
            except FileNotFoundError:
                return {"error": f"Linter '{linter}' not installed or not on PATH."}

        if action == "dependencies":
            from agentfoundry.code_gen.code_parser import CodeParser
            parser = CodeParser(source)
            imports = parser.get_imports()
            return {"imports": imports}

        return {"error": f"Unknown action: {action}"}

    except SyntaxError as e:
        return {"error": f"Syntax error in code: {e}"}
    except Exception as ex:
        logger.error("code_analysis error: %s", ex, exc_info=True)
        return {"error": str(ex)}


def _get_source(path: Optional[str], code: Optional[str]) -> str | Dict:
    """Get source code from path or direct string."""
    if code:
        return code
    if path:
        root = Path.cwd()
        fp = (root / path).resolve()
        if not fp.is_file():
            return {"error": f"File not found: {path}"}
        return fp.read_text(errors="ignore")
    return {"error": "Provide 'path' or 'code'."}


code_analysis_tool = StructuredTool.from_function(
    func=code_analysis,
    name="code_analysis",
    description=code_analysis.__doc__,
    args_schema=CodeAnalysisInput,
)
