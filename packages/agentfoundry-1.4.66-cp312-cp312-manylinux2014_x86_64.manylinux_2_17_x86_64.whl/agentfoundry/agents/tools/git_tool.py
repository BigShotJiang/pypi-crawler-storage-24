"""Git operations tool for coding agents.

Provides structured git operations: status, diff, log, add, commit,
branch, checkout, push, pull, init, clone.
Uses subprocess.run(["git", ...]) with structured output parsing.
"""

import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

logger = logging.getLogger(__name__)

_DEFAULT_CWD: Optional[str] = None
_DEFAULT_TIMEOUT: int = 60


class GitInput(BaseModel):
    action: str = Field(
        ...,
        description=(
            "Git action: 'status', 'diff', 'log', 'add', 'commit', "
            "'branch', 'checkout', 'push', 'pull', 'init', 'clone'."
        ),
    )
    args: Optional[List[str]] = Field(
        default=None,
        description="Additional arguments (e.g., file paths for 'add', branch name for 'checkout').",
    )
    message: Optional[str] = Field(None, description="Commit message for 'commit' action.")
    cwd: Optional[str] = Field(None, description="Working directory for git commands.")


def _run_git(args: List[str], cwd: Optional[str] = None, timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, object]:
    """Run a git command and return structured output."""
    effective_cwd = cwd or _DEFAULT_CWD
    cmd = ["git"] + args
    logger.debug("Running: %s", " ".join(cmd))
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=effective_cwd,
        )
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"error": f"Git command timed out after {timeout}s.", "returncode": -1}
    except FileNotFoundError:
        return {"error": "Git is not installed or not on PATH.", "returncode": -1}
    except Exception as ex:
        return {"error": str(ex), "returncode": -1}


def _parse_status(stdout: str) -> List[Dict[str, str]]:
    """Parse git status --porcelain output."""
    files = []
    for line in stdout.strip().splitlines():
        if len(line) >= 4:
            status = line[:2].strip()
            filepath = line[3:].strip()
            files.append({"status": status, "path": filepath})
    return files


def _parse_log(stdout: str) -> List[Dict[str, str]]:
    """Parse git log --oneline output."""
    commits = []
    for line in stdout.strip().splitlines():
        parts = line.split(" ", 1)
        if len(parts) == 2:
            commits.append({"hash": parts[0], "message": parts[1]})
    return commits


def git_operations(
    action: str,
    args: Optional[List[str]] = None,
    message: Optional[str] = None,
    cwd: Optional[str] = None,
) -> Dict[str, object]:
    """
    Perform git operations for version control.

    Actions:
      - status: Show working tree status (parsed).
      - diff: Show changes (optionally pass file paths in args).
      - log: Show commit history (parsed, default last 20).
      - add: Stage files (pass paths in args, or ['.'] for all).
      - commit: Commit staged changes (requires 'message').
      - branch: List branches, or create one (pass name in args).
      - checkout: Switch branches or restore files (pass target in args).
      - push: Push to remote (optionally pass remote/branch in args).
      - pull: Pull from remote.
      - init: Initialize a new repository.
      - clone: Clone a repository (pass URL in args).
    """
    logger.info("git_operations: action=%s args=%s", action, args)
    extra_args = args or []

    if action == "status":
        result = _run_git(["status", "--porcelain"] + extra_args, cwd=cwd)
        if result.get("returncode") == 0:
            result["files"] = _parse_status(result["stdout"])
        return result

    if action == "diff":
        return _run_git(["diff"] + extra_args, cwd=cwd)

    if action == "log":
        n = "20"
        log_args = ["log", "--oneline", f"-{n}"] + extra_args
        result = _run_git(log_args, cwd=cwd)
        if result.get("returncode") == 0:
            result["commits"] = _parse_log(result["stdout"])
        return result

    if action == "add":
        if not extra_args:
            return {"error": "Missing file paths for 'add' action. Use ['.'] for all."}
        return _run_git(["add"] + extra_args, cwd=cwd)

    if action == "commit":
        if not message:
            return {"error": "Missing 'message' for commit action."}
        return _run_git(["commit", "-m", message] + extra_args, cwd=cwd)

    if action == "branch":
        if extra_args:
            return _run_git(["branch"] + extra_args, cwd=cwd)
        result = _run_git(["branch", "--list"], cwd=cwd)
        if result.get("returncode") == 0:
            branches = [b.strip().lstrip("* ") for b in result["stdout"].strip().splitlines() if b.strip()]
            result["branches"] = branches
        return result

    if action == "checkout":
        if not extra_args:
            return {"error": "Missing branch/path for 'checkout' action."}
        return _run_git(["checkout"] + extra_args, cwd=cwd)

    if action == "push":
        return _run_git(["push"] + extra_args, cwd=cwd)

    if action == "pull":
        return _run_git(["pull"] + extra_args, cwd=cwd)

    if action == "init":
        return _run_git(["init"] + extra_args, cwd=cwd)

    if action == "clone":
        if not extra_args:
            return {"error": "Missing repository URL for 'clone' action."}
        return _run_git(["clone"] + extra_args, cwd=cwd)

    return {"error": f"Unknown git action: {action}"}


git_tool = StructuredTool.from_function(
    func=git_operations,
    name="git_operations",
    description=git_operations.__doc__,
    args_schema=GitInput,
)
