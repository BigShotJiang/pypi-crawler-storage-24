"""GitLab API tools for repository and merge-request integration.

Read operations use `gitlab_read_api`. Merge-request creation uses
`gitlab_merge_request_api` so write access can be governed separately.
"""

from __future__ import annotations

import base64
import json
import logging
from typing import Any, Dict, Optional
from urllib import error, parse, request

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from agentfoundry.utils.agent_config import AgentConfig

logger = logging.getLogger(__name__)


def _get_gitlab_config() -> Any:
    return AgentConfig.from_legacy_config().gitlab


def _normalize_api_base(base_url: str, api_version: str) -> str:
    normalized = (base_url or "https://gitlab.com").rstrip("/")
    suffix = f"/api/{api_version.strip('/')}"
    if normalized.endswith(suffix):
        return normalized
    if "/api/" in normalized:
        return normalized
    return f"{normalized}{suffix}"


def _resolve_project(project: Optional[str]) -> str:
    resolved = (project or _get_gitlab_config().default_project or "").strip()
    if not resolved:
        raise ValueError("Provide 'project' or set AF_GITLAB_DEFAULT_PROJECT.")
    return resolved


def _request_json(
    *,
    method: str,
    path: str,
    query: Optional[dict[str, Any]] = None,
    payload: Optional[dict[str, Any]] = None,
    base_url: Optional[str] = None,
    api_version: Optional[str] = None,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    cfg = _get_gitlab_config()
    api_base = _normalize_api_base(base_url or cfg.base_url, api_version or cfg.api_version)
    url = f"{api_base}{path}"
    if query:
        params = {key: value for key, value in query.items() if value not in (None, "", [])}
        if params:
            url = f"{url}?{parse.urlencode(params, doseq=True)}"

    headers = {"Accept": "application/json"}
    resolved_token = token or (cfg.token.get_secret_value() if cfg.token else None)
    if resolved_token:
        headers["PRIVATE-TOKEN"] = resolved_token

    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = request.Request(url=url, data=data, headers=headers, method=method.upper())
    try:
        with request.urlopen(req, timeout=30) as response:
            raw = response.read().decode("utf-8")
            parsed = json.loads(raw) if raw else {}
            return {
                "status_code": getattr(response, "status", 200),
                "data": parsed,
            }
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"message": body}
        return {
            "error": parsed.get("message") or body or str(exc),
            "status_code": exc.code,
            "data": parsed,
        }
    except Exception as exc:  # pragma: no cover - defensive boundary
        return {"error": str(exc), "status_code": -1}


class GitLabReadInput(BaseModel):
    action: str = Field(
        ...,
        description=(
            "GitLab read action: 'current_user', 'list_projects', 'get_project', "
            "'list_merge_requests', 'get_merge_request', 'list_issues', 'get_issue', "
            "'list_repository_tree', or 'get_file'."
        ),
    )
    project: Optional[str] = Field(None, description="Project path or numeric ID. Falls back to AF_GITLAB_DEFAULT_PROJECT.")
    merge_request_iid: Optional[int] = Field(None, description="Merge request IID for 'get_merge_request'.")
    search: Optional[str] = Field(None, description="Search string for 'list_projects'.")
    state: Optional[str] = Field("opened", description="State filter for merge requests or issues.")
    file_path: Optional[str] = Field(None, description="Repository file path for 'get_file'.")
    ref: Optional[str] = Field("HEAD", description="Git ref/branch/tag for file or tree reads.")
    path: Optional[str] = Field(None, description="Repository path for 'list_repository_tree'.")
    recursive: bool = Field(False, description="Whether repository-tree listing should recurse.")
    per_page: int = Field(20, description="Page size for list actions.")
    membership: bool = Field(True, description="Whether project listing should be limited to memberships.")
    base_url: Optional[str] = Field(None, description="Override GitLab base URL.")
    api_version: Optional[str] = Field(None, description="Override GitLab API version.")
    token: Optional[str] = Field(None, description="GitLab personal access token override.")


def gitlab_read_api(
    action: str,
    project: Optional[str] = None,
    merge_request_iid: Optional[int] = None,
    search: Optional[str] = None,
    state: Optional[str] = "opened",
    file_path: Optional[str] = None,
    ref: Optional[str] = "HEAD",
    path: Optional[str] = None,
    recursive: bool = False,
    per_page: int = 20,
    membership: bool = True,
    base_url: Optional[str] = None,
    api_version: Optional[str] = None,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    """Read GitLab projects, merge requests, issues, repository trees, and files."""
    logger.info("gitlab_read_api: action=%s project=%s", action, project)

    if action == "current_user":
        return _request_json(method="GET", path="/user", base_url=base_url, api_version=api_version, token=token)

    if action == "list_projects":
        return _request_json(
            method="GET",
            path="/projects",
            query={"membership": str(bool(membership)).lower(), "search": search, "per_page": per_page},
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    try:
        resolved_project = _resolve_project(project)
    except ValueError as exc:
        return {"error": str(exc), "status_code": 400}
    project_key = parse.quote_plus(resolved_project)

    if action == "get_project":
        return _request_json(method="GET", path=f"/projects/{project_key}", base_url=base_url, api_version=api_version, token=token)

    if action == "list_merge_requests":
        return _request_json(
            method="GET",
            path=f"/projects/{project_key}/merge_requests",
            query={"state": state, "per_page": per_page},
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    if action == "get_merge_request":
        if merge_request_iid is None:
            return {"error": "Provide 'merge_request_iid' for get_merge_request.", "status_code": 400}
        return _request_json(
            method="GET",
            path=f"/projects/{project_key}/merge_requests/{merge_request_iid}",
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    if action == "list_issues":
        return _request_json(
            method="GET",
            path=f"/projects/{project_key}/issues",
            query={"state": state, "per_page": per_page},
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    if action == "get_issue":
        if merge_request_iid is None:
            return {"error": "Provide 'merge_request_iid' as the issue IID for get_issue.", "status_code": 400}
        return _request_json(
            method="GET",
            path=f"/projects/{project_key}/issues/{merge_request_iid}",
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    if action == "list_repository_tree":
        return _request_json(
            method="GET",
            path=f"/projects/{project_key}/repository/tree",
            query={"path": path, "ref": ref, "recursive": str(bool(recursive)).lower(), "per_page": per_page},
            base_url=base_url,
            api_version=api_version,
            token=token,
        )

    if action == "get_file":
        if not file_path:
            return {"error": "Provide 'file_path' for get_file.", "status_code": 400}
        file_key = parse.quote_plus(file_path)
        result = _request_json(
            method="GET",
            path=f"/projects/{project_key}/repository/files/{file_key}",
            query={"ref": ref},
            base_url=base_url,
            api_version=api_version,
            token=token,
        )
        data = result.get("data")
        if isinstance(data, dict) and data.get("content") and data.get("encoding") == "base64":
            try:
                decoded = base64.b64decode(str(data["content"])).decode("utf-8")
                data["decoded_content"] = decoded
            except Exception as exc:  # pragma: no cover - defensive
                result["decode_error"] = str(exc)
        return result

    return {"error": f"Unknown GitLab read action: {action}", "status_code": 400}


class GitLabMergeRequestInput(BaseModel):
    project: Optional[str] = Field(None, description="Project path or numeric ID. Falls back to AF_GITLAB_DEFAULT_PROJECT.")
    source_branch: str = Field(..., description="Source branch for the merge request.")
    target_branch: str = Field(..., description="Target branch for the merge request.")
    title: str = Field(..., description="Merge request title.")
    description: Optional[str] = Field(None, description="Optional merge request description.")
    draft: bool = Field(False, description="Whether the merge request should be created as a draft.")
    remove_source_branch: bool = Field(False, description="Whether GitLab should remove the source branch on merge.")
    squash: bool = Field(False, description="Whether GitLab should squash commits on merge.")
    base_url: Optional[str] = Field(None, description="Override GitLab base URL.")
    api_version: Optional[str] = Field(None, description="Override GitLab API version.")
    token: Optional[str] = Field(None, description="GitLab personal access token override.")


def gitlab_merge_request_api(
    source_branch: str,
    target_branch: str,
    title: str,
    project: Optional[str] = None,
    description: Optional[str] = None,
    draft: bool = False,
    remove_source_branch: bool = False,
    squash: bool = False,
    base_url: Optional[str] = None,
    api_version: Optional[str] = None,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a GitLab merge request using a personal access token."""
    logger.info("gitlab_merge_request_api: project=%s source=%s target=%s", project, source_branch, target_branch)
    cfg = _get_gitlab_config()
    resolved_token = token or (cfg.token.get_secret_value() if cfg.token else None)
    if not resolved_token:
        return {"error": "GitLab token is required. Set AF_GITLAB_TOKEN or pass token explicitly.", "status_code": 401}

    try:
        resolved_project = _resolve_project(project)
    except ValueError as exc:
        return {"error": str(exc), "status_code": 400}
    payload = {
        "source_branch": source_branch,
        "target_branch": target_branch,
        "title": f"Draft: {title}" if draft and not title.startswith("Draft:") else title,
        "description": description or "",
        "remove_source_branch": bool(remove_source_branch),
        "squash": bool(squash),
    }
    return _request_json(
        method="POST",
        path=f"/projects/{parse.quote_plus(resolved_project)}/merge_requests",
        payload=payload,
        base_url=base_url,
        api_version=api_version,
        token=resolved_token,
    )


class GitLabIssueWriteInput(BaseModel):
    action: str = Field(
        ...,
        description="GitLab issue write action: 'assign_issue', 'create_note', or 'update_issue_state'.",
    )
    project: Optional[str] = Field(None, description="Project path or numeric ID. Falls back to AF_GITLAB_DEFAULT_PROJECT.")
    issue_iid: int = Field(..., description="Issue IID within the GitLab project.")
    assignee_username: Optional[str] = Field(None, description="Username to assign for 'assign_issue'.")
    note_body: Optional[str] = Field(None, description="Issue note body for 'create_note'.")
    state_event: Optional[str] = Field(None, description="State event such as 'close' or 'reopen' for 'update_issue_state'.")
    base_url: Optional[str] = Field(None, description="Override GitLab base URL.")
    api_version: Optional[str] = Field(None, description="Override GitLab API version.")
    token: Optional[str] = Field(None, description="GitLab personal access token override.")


def _resolve_gitlab_user_id(username: str, *, base_url: Optional[str], api_version: Optional[str], token: Optional[str]) -> Dict[str, Any]:
    result = _request_json(
        method="GET",
        path="/users",
        query={"username": username},
        base_url=base_url,
        api_version=api_version,
        token=token,
    )
    data = result.get("data")
    if isinstance(data, list):
        for user in data:
            if str(user.get("username") or "") == username:
                return {"user_id": user.get("id")}
        if data:
            return {"user_id": data[0].get("id")}
    return {"error": f"GitLab user '{username}' not found.", "status_code": 404}


def gitlab_issue_write_api(
    action: str,
    issue_iid: int,
    project: Optional[str] = None,
    assignee_username: Optional[str] = None,
    note_body: Optional[str] = None,
    state_event: Optional[str] = None,
    base_url: Optional[str] = None,
    api_version: Optional[str] = None,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    """Assign GitLab issues, add notes, or update issue state using a personal access token."""
    logger.info("gitlab_issue_write_api: action=%s project=%s issue_iid=%s", action, project, issue_iid)
    cfg = _get_gitlab_config()
    resolved_token = token or (cfg.token.get_secret_value() if cfg.token else None)
    if not resolved_token:
        return {"error": "GitLab token is required. Set AF_GITLAB_TOKEN or pass token explicitly.", "status_code": 401}
    try:
        resolved_project = _resolve_project(project)
    except ValueError as exc:
        return {"error": str(exc), "status_code": 400}
    project_key = parse.quote_plus(resolved_project)

    if action == "assign_issue":
        if not assignee_username:
            return {"error": "Provide 'assignee_username' for assign_issue.", "status_code": 400}
        user_result = _resolve_gitlab_user_id(
            assignee_username,
            base_url=base_url,
            api_version=api_version,
            token=resolved_token,
        )
        if user_result.get("error"):
            return user_result
        return _request_json(
            method="PUT",
            path=f"/projects/{project_key}/issues/{issue_iid}",
            payload={"assignee_ids": [user_result["user_id"]]},
            base_url=base_url,
            api_version=api_version,
            token=resolved_token,
        )

    if action == "create_note":
        if not note_body:
            return {"error": "Provide 'note_body' for create_note.", "status_code": 400}
        return _request_json(
            method="POST",
            path=f"/projects/{project_key}/issues/{issue_iid}/notes",
            payload={"body": note_body},
            base_url=base_url,
            api_version=api_version,
            token=resolved_token,
        )

    if action == "update_issue_state":
        if not state_event:
            return {"error": "Provide 'state_event' for update_issue_state.", "status_code": 400}
        return _request_json(
            method="PUT",
            path=f"/projects/{project_key}/issues/{issue_iid}",
            payload={"state_event": state_event},
            base_url=base_url,
            api_version=api_version,
            token=resolved_token,
        )

    return {"error": f"Unknown GitLab issue write action: {action}", "status_code": 400}


gitlab_read_tool = StructuredTool.from_function(
    func=gitlab_read_api,
    name="gitlab_read_api",
    description=gitlab_read_api.__doc__,
    args_schema=GitLabReadInput,
)


gitlab_merge_request_tool = StructuredTool.from_function(
    func=gitlab_merge_request_api,
    name="gitlab_merge_request_api",
    description=gitlab_merge_request_api.__doc__,
    args_schema=GitLabMergeRequestInput,
)


gitlab_issue_write_tool = StructuredTool.from_function(
    func=gitlab_issue_write_api,
    name="gitlab_issue_write_api",
    description=gitlab_issue_write_api.__doc__,
    args_schema=GitLabIssueWriteInput,
)
