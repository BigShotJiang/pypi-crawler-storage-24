"""Proactive contradiction detection across existing KGraph facts.

Scans facts within an org scope, clusters by (subject, predicate),
checks pairwise similarity, and produces a "fact health" report with
contradiction density per topic.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agentfoundry.agents.memory.contradictions import (
    Contradiction,
    Fact,
    find_contradictions,
    text_similarity,
)

logger = logging.getLogger(__name__)


@dataclass
class FactCluster:
    """A group of facts sharing the same (subject, predicate)."""

    subject: str
    predicate: str
    facts: List[Fact] = field(default_factory=list)
    contradictions: List[Contradiction] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.facts)

    @property
    def contradiction_count(self) -> int:
        return len(self.contradictions)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subject": self.subject,
            "predicate": self.predicate,
            "fact_count": self.count,
            "contradiction_count": self.contradiction_count,
            "facts": [
                {"object": f.object, "fact_id": f.fact_id[:12]}
                for f in self.facts
            ],
            "contradictions": [
                {
                    "existing_obj": c.existing_obj,
                    "new_obj": c.new_obj,
                    "similarity": round(c.similarity, 3),
                    "fact_id": c.fact_id[:12],
                }
                for c in self.contradictions
            ],
        }


@dataclass
class FactHealthReport:
    """Summary of fact health within a scope."""

    org_id: str
    total_facts: int
    total_clusters: int
    clusters_with_contradictions: int
    total_contradictions: int
    contradiction_density: float  # contradictions / total_facts
    clusters: List[FactCluster] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "org_id": self.org_id,
            "total_facts": self.total_facts,
            "total_clusters": self.total_clusters,
            "clusters_with_contradictions": self.clusters_with_contradictions,
            "total_contradictions": self.total_contradictions,
            "contradiction_density": round(self.contradiction_density, 4),
            "problem_clusters": [
                c.to_dict() for c in self.clusters if c.contradiction_count > 0
            ],
        }


def scan_facts(
    kgraph: Any,
    org_id: str,
    user_id: str = "",
    threshold: float = 0.0,
    max_facts: int = 500,
) -> FactHealthReport:
    """Scan KGraph facts and produce a health report.

    Args:
        kgraph: A KGraph instance with search() or fetch_by_metadata().
        org_id: Organization ID to scope the scan.
        user_id: Optional user ID filter.
        threshold: Similarity threshold for contradiction detection.
            Default 0.0 flags all same-(subject, predicate) pairs with
            different objects.
        max_facts: Maximum number of facts to retrieve.

    Returns:
        FactHealthReport summarizing the health of the fact store.
    """
    # Fetch facts from KGraph
    facts = _fetch_facts(kgraph, org_id, user_id, max_facts)
    if not facts:
        return FactHealthReport(
            org_id=org_id,
            total_facts=0,
            total_clusters=0,
            clusters_with_contradictions=0,
            total_contradictions=0,
            contradiction_density=0.0,
        )

    # Cluster by (subject, predicate)
    clusters = _cluster_facts(facts)

    # Check pairwise contradictions within each cluster
    total_contradictions = 0
    clusters_with_issues = 0

    for cluster in clusters:
        if cluster.count < 2:
            continue
        # Check each fact against all others in the cluster
        seen_pairs: set = set()
        for i, fact in enumerate(cluster.facts):
            others = cluster.facts[:i] + cluster.facts[i + 1:]
            new_contradictions = find_contradictions(fact, others, threshold=threshold)
            for c in new_contradictions:
                # Deduplicate by (fact_id, existing_obj, new_obj)
                pair_key = tuple(sorted([c.existing_obj, c.new_obj]))
                if pair_key not in seen_pairs:
                    seen_pairs.add(pair_key)
                    cluster.contradictions.append(c)

        if cluster.contradictions:
            clusters_with_issues += 1
            total_contradictions += len(cluster.contradictions)

    density = total_contradictions / len(facts) if facts else 0.0

    report = FactHealthReport(
        org_id=org_id,
        total_facts=len(facts),
        total_clusters=len(clusters),
        clusters_with_contradictions=clusters_with_issues,
        total_contradictions=total_contradictions,
        contradiction_density=density,
        clusters=clusters,
    )

    logger.info(
        "FactHealth scan: org=%s facts=%d clusters=%d contradictions=%d density=%.3f",
        org_id, len(facts), len(clusters), total_contradictions, density,
    )

    return report


def _fetch_facts(kgraph: Any, org_id: str, user_id: str, max_facts: int) -> List[Fact]:
    """Fetch facts from KGraph using available methods."""
    facts: List[Fact] = []

    # Try fetch_by_metadata first (most efficient for bulk retrieval)
    if hasattr(kgraph, "fetch_by_metadata"):
        try:
            filters: Dict[str, str] = {}
            if user_id:
                filters["user_id"] = user_id
            results = kgraph.fetch_by_metadata(org_id=org_id, filters=filters)
            for r in results[:max_facts]:
                if isinstance(r, dict):
                    facts.append(Fact(
                        subject=r.get("subject", ""),
                        predicate=r.get("predicate", ""),
                        object=r.get("object", ""),
                        fact_id=r.get("fact_id", r.get("id", "")),
                        metadata=r.get("metadata", {}),
                    ))
            return facts
        except Exception:
            logger.debug("fact_health: fetch_by_metadata failed, falling back to search")

    # Fallback: broad search
    try:
        results = kgraph.search("*", user_id=user_id, org_id=org_id, k=max_facts)
        for r in results:
            if isinstance(r, dict):
                facts.append(Fact(
                    subject=r.get("subject", ""),
                    predicate=r.get("predicate", ""),
                    object=r.get("object", ""),
                    fact_id=r.get("fact_id", r.get("id", "")),
                    metadata=r.get("metadata", {}),
                ))
    except Exception as e:
        logger.warning("fact_health: search failed: %s", e)

    return facts


def _cluster_facts(facts: List[Fact]) -> List[FactCluster]:
    """Group facts by normalized (subject, predicate)."""
    groups: Dict[tuple, FactCluster] = {}
    for fact in facts:
        key = (fact.subject.lower().strip(), fact.predicate.lower().strip())
        if key not in groups:
            groups[key] = FactCluster(subject=fact.subject, predicate=fact.predicate)
        groups[key].facts.append(fact)
    return list(groups.values())
