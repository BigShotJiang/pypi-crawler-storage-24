"""Abstract base class for memory management layers."""

from __future__ import annotations

import hashlib
import logging
import pathlib
from abc import ABC
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from langchain_core.documents import Document

from agentfoundry.vectorstores.factory import VectorStoreFactory
from agentfoundry.kgraph.factory import KGraphFactory
from agentfoundry.cache.caching_layer import CachingVectorProvider, CachingKGraph
from agentfoundry.agents.memory.constants import SYSTEM_USER_ID
from agentfoundry.agents.memory.types import DecayConfig
from agentfoundry.tracing.active import trace_span

logger = logging.getLogger(__name__)


class BaseMemory(ABC):
    """Base class for memory layers providing common storage and hashing logic."""

    def __init__(self, root_path: pathlib.Path, hash_prefix: str | None = None):
        """Initialize the base memory.
        
        Args:
            root_path: Directory where this memory scope stores data (mostly for KGraph/DuckDB).
            hash_prefix: Prefix used for deterministic ID generation (e.g. org_id or user_id).
                         If None, only the text is hashed.
        """
        self._root = root_path
        self._root.mkdir(parents=True, exist_ok=True)
        self.hash_prefix = hash_prefix

        from agentfoundry.agents.tools.memory_tools import get_module_config

        module_cfg = get_module_config()

        # Vector store provider (cached wrapper)
        # Note: VectorStoreFactory returns a singleton provider. Scoping is handled via metadata/filters.
        if module_cfg is not None:
            provider = VectorStoreFactory.get_provider(config=module_cfg)
        else:
            provider = VectorStoreFactory.get_provider()
        self.vs_provider = CachingVectorProvider(provider)

        # KGraph provider (cached wrapper)
        # Note: KGraph factory returns a provider often tied to the DATA_DIR.
        graph_override = {"DATA_DIR": str(self._root)}
        if module_cfg is not None:
            graph_override["AGENT_CONFIG"] = module_cfg
        self._kg = CachingKGraph(KGraphFactory.get_instance().get_kgraph(graph_override))
        
        logger.debug(f"BaseMemory initialized at {self._root} with prefix {hash_prefix}")

    def _det_id(self, text: str) -> str:
        """Generate a deterministic ID based on text and the configured prefix."""
        if self.hash_prefix:
            content = f"{self.hash_prefix}|{text}"
        else:
            content = text
        return hashlib.sha256(content.encode()).hexdigest()

    def _get_base_metadata(self) -> Dict[str, Any]:
        """Return base metadata to be attached to every document/fact.
        
        Override this in subclasses to add scope-specific fields (user_id, org_id, etc.).
        """
        return {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "accessed_at": datetime.now(timezone.utc).isoformat(),
            "access_count": 0,
        }

    # ------------------------------------------------------------------
    # Semantic layer (Vector Store)
    # ------------------------------------------------------------------
    def add_semantic_item(self, text: str, metadata: Dict[str, Any] | None = None, **kwargs) -> str:
        """Add a document to the vector store."""
        doc_id = self._det_id(text)
        base_meta = self._get_base_metadata()
        full_meta = {**(metadata or {}), **base_meta}

        with trace_span("add_semantic_item", "memory", {"scope": self.__class__.__name__}) as mem_span:
            try:
                # Create Document
                doc = Document(page_content=text, metadata=full_meta, id=doc_id)

                # Helper for subclasses to inject specific args into vs_provider.add_documents
                # e.g., org_id for partitioning
                self._add_to_vectorstore([doc], [doc_id], **kwargs)

                logger.debug(f"{self.__class__.__name__} semantic item added id={doc_id}")
                if mem_span:
                    mem_span.attributes["doc_id"] = doc_id[:12]
                    mem_span.attributes["text_len"] = len(text)
            except ValueError:
                logger.debug(f"{self.__class__.__name__} semantic item duplicate ignored id={doc_id}")
            except Exception as e:
                logger.error(f"Error adding semantic item in {self.__class__.__name__}: {e}", exc_info=True)
                raise e

        return doc_id

    def _add_to_vectorstore(self, docs: List[Document], ids: List[str], **kwargs):
        """Internal method to push to vector store. Can be overridden for complex logic."""
        self.vs_provider.add_documents(docs, ids=ids, allow_update=False, **kwargs)

    def semantic_search(self, query: str, k: int = 10, filter: Dict[str, Any] | None = None, **kwargs) -> List[str]:
        """Search the vector store."""
        docs = self.vs_provider.similarity_search(query, k=k, filter=filter, **kwargs)
        logger.debug(f"{self.__class__.__name__} search '{query}' hits={len(docs)}")
        return [d.page_content for d in docs]

    def scored_search(
        self,
        query: str,
        k: int = 10,
        filter: Dict[str, Any] | None = None,
        decay_config: DecayConfig | None = None,
        **kwargs,
    ) -> List[str]:
        """Search with decay-based relevance scoring.

        Over-fetches candidates via similarity_search_with_score, applies
        decay reranking, and returns the top k results. Existing
        semantic_search is unaffected.
        """
        from agentfoundry.agents.memory.decay import rerank_with_decay

        with trace_span("scored_search", "memory", {"scope": self.__class__.__name__, "k": k}) as ss_span:
            # Over-fetch to give reranking enough candidates
            raw = self.vs_provider.similarity_search_with_score(
                query, k=k * 2, filter=filter, **kwargs
            )
            reranked = rerank_with_decay(raw, config=decay_config)
            results = reranked[:k]
            if ss_span:
                ss_span.attributes["candidates"] = len(raw)
                ss_span.attributes["returned"] = len(results)
        logger.debug(
            "%s scored_search '%s' candidates=%d returned=%d",
            self.__class__.__name__, query, len(raw), len(results),
        )
        return [doc.page_content for doc, score in results]

    # ------------------------------------------------------------------
    # KGraph layer
    # ------------------------------------------------------------------
    def upsert_fact(self, subject: str, predicate: str, obj: str) -> str:
        """Insert a fact into the knowledge graph."""
        meta = self._get_base_metadata()
        with trace_span("upsert_fact", "memory", {"scope": self.__class__.__name__, "subject": subject[:60]}) as _:
            fid = self._kg.upsert_fact(subject, predicate, obj, meta)
        logger.debug(f"{self.__class__.__name__} fact upsert id={fid}")
        return fid

    def fact_search(self, query: str, k: int = 10, **kwargs):
        """Search the knowledge graph."""
        # Subclasses should provide user_id/org_id in kwargs if required by underlying KGraph
        return self._kg.search(query, k=k, **kwargs)

    def compact(
        self,
        config: Any = None,
        summarizer: Any = None,
        max_docs: int = 200,
        **kwargs,
    ) -> Dict[str, Any]:
        """Run memory compaction: cluster similar docs and replace with summaries.

        Args:
            config: CompactionConfig instance (uses defaults if None).
            summarizer: Optional callable(texts, max_len) -> summary_text.
            max_docs: Maximum docs to retrieve for compaction.
            **kwargs: Passed to similarity_search_with_score (e.g. filter, org_id).

        Returns:
            CompactionResult as a dict.
        """
        from agentfoundry.agents.memory.compaction import compact as _compact, CompactionConfig

        if config is None:
            config = CompactionConfig()

        with trace_span("compact", "memory", {"scope": self.__class__.__name__, "max_docs": max_docs}) as c_span:
            # Retrieve candidate documents
            raw = self.vs_provider.similarity_search_with_score(
                "*", k=max_docs, **kwargs
            )
            result, clusters, replacements = _compact(raw, config=config, summarizer=summarizer)

            if not config.dry_run and replacements:
                for new_doc, removal_info in replacements:
                    # Delete originals
                    removed_ids = removal_info.get("removed_ids", [])
                    if removed_ids:
                        try:
                            self.vs_provider.delete(removed_ids, **kwargs)
                        except Exception as e:
                            logger.warning("compact: failed to delete originals: %s", e)

                    # Insert summary document
                    try:
                        doc_id = self._det_id(new_doc.page_content)
                        new_doc.id = doc_id
                        new_doc.metadata["__doc_id__"] = doc_id
                        self._add_to_vectorstore([new_doc], [doc_id], **kwargs)
                    except Exception as e:
                        logger.warning("compact: failed to insert summary: %s", e)

            if c_span:
                c_span.attributes.update(result.to_dict())

        logger.info(
            "%s compact: removed=%d created=%d chars_saved=%d",
            self.__class__.__name__, result.docs_removed,
            result.docs_created, result.chars_saved,
        )
        return result.to_dict()

    def summary(self, k: int = 5) -> Dict[str, Any]:
        """Default summary implementation."""
        return {
            "docs": self.semantic_search("*", k=k),
            "facts": self.fact_search("*", k=k)
        }
