"""Async batched metadata updater for access tracking.

Records `accessed_at` and `access_count` updates in a non-blocking way,
flushing batches to the underlying store on a background thread.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set

from langchain_core.documents import Document

logger = logging.getLogger(__name__)


class AccessTracker:
    """Non-blocking access tracker that batches metadata updates.

    Wired as an optional attribute on CachingVectorProvider. When present,
    similarity_search_with_score calls record_access after returning results.

    Local FAISS shadow metadata is updated in-process (no I/O).
    Remote updates are best-effort (log warning on failure, don't crash).
    """

    def __init__(
        self,
        caching_provider: Any = None,
        flush_interval_s: float = 2.0,
    ) -> None:
        self._provider = caching_provider
        self._queue: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._cv = threading.Condition(self._lock)
        self._stop = False
        self._flush_interval = flush_interval_s

        self._thread = threading.Thread(
            target=self._run, name="AccessTracker", daemon=True
        )
        self._thread.start()
        logger.debug("AccessTracker initialized (flush_interval=%.1fs)", flush_interval_s)

    def record_access(self, docs: List[Document]) -> None:
        """Enqueue access records for the given documents. Non-blocking."""
        now = datetime.now(timezone.utc).isoformat()
        entries = []
        for doc in docs:
            doc_id = getattr(doc, "id", None) or (doc.metadata or {}).get("__doc_id__")
            if doc_id:
                entries.append({"doc_id": doc_id, "accessed_at": now, "doc": doc})
        if not entries:
            return
        with self._cv:
            self._queue.extend(entries)
            self._cv.notify()

    def _run(self) -> None:
        """Background loop that flushes access updates."""
        while True:
            with self._cv:
                if not self._queue and not self._stop:
                    self._cv.wait(timeout=self._flush_interval)
                batch = self._queue[:]
                self._queue.clear()
                stop = self._stop

            if batch:
                self._flush(batch)
            if stop:
                break

    def _flush(self, batch: List[Dict[str, Any]]) -> None:
        """Apply access metadata updates."""
        # Deduplicate by doc_id (keep latest)
        by_id: Dict[str, Dict[str, Any]] = {}
        for entry in batch:
            by_id[entry["doc_id"]] = entry

        for doc_id, entry in by_id.items():
            doc: Document = entry["doc"]
            meta = doc.metadata or {}

            # Update in-process metadata (local shadow)
            old_count = meta.get("access_count", 0) or 0
            meta["access_count"] = old_count + 1
            meta["accessed_at"] = entry["accessed_at"]
            doc.metadata = meta

            # Update local shadow docs in CachingVectorProvider
            if self._provider is not None:
                self._update_local_shadow(doc_id, meta)

        logger.debug("AccessTracker: flushed %d access updates", len(by_id))

    def _update_local_shadow(self, doc_id: str, meta: Dict[str, Any]) -> None:
        """Update metadata on matching local shadow docs (no I/O)."""
        try:
            provider = self._provider
            if not hasattr(provider, "_local") or not hasattr(provider, "_lock"):
                return
            with provider._lock:
                for ld in provider._local:
                    if ld.id == doc_id:
                        ld.doc.metadata = dict(ld.doc.metadata or {})
                        ld.doc.metadata["access_count"] = meta.get("access_count", 0)
                        ld.doc.metadata["accessed_at"] = meta.get("accessed_at")
                        break
        except Exception as e:
            logger.warning("AccessTracker: failed to update local shadow: %s", e)

    def stop(self) -> None:
        """Signal the background thread to stop and flush remaining items."""
        with self._cv:
            self._stop = True
            self._cv.notify_all()
        self._thread.join(timeout=5.0)
        logger.debug("AccessTracker stopped")
