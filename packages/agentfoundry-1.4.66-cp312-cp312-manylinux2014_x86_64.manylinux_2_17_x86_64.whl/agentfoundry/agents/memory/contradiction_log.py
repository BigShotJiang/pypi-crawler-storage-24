"""Persistent contradiction log backed by DuckDB.

Records all detected contradictions with timestamps, resolution policy,
and agent context. Queryable for auditing and fact health monitoring.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ContradictionLog:
    """Lightweight DuckDB-backed log for contradiction events.

    Thread-safe. One instance per cache directory.
    """

    _INSTANCES: Dict[str, "ContradictionLog"] = {}
    _LOCK = threading.Lock()

    def __new__(cls, cache_dir: str = "./data/cache"):
        with cls._LOCK:
            inst = cls._INSTANCES.get(cache_dir)
            if inst is None:
                inst = super().__new__(cls)
                cls._INSTANCES[cache_dir] = inst
                inst._initialized = False
            return inst

    def __init__(self, cache_dir: str = "./data/cache") -> None:
        if self._initialized:
            return
        import duckdb

        db_dir = os.path.join(cache_dir, "kg")
        os.makedirs(db_dir, exist_ok=True)
        self._db_path = os.path.join(db_dir, "contradiction_log.duckdb")
        self._conn = duckdb.connect(self._db_path)
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS contradiction_log (
                id BIGINT PRIMARY KEY,
                detected_at TEXT,
                subject TEXT,
                predicate TEXT,
                existing_obj TEXT,
                new_obj TEXT,
                existing_fact_id TEXT,
                similarity DOUBLE,
                policy TEXT,
                resolution TEXT,
                org_id TEXT,
                user_id TEXT,
                metadata TEXT
            )
            """
        )
        self._lock = threading.Lock()
        self._initialized = True
        logger.debug("ContradictionLog initialized at %s", self._db_path)

    def record(
        self,
        subject: str,
        predicate: str,
        existing_obj: str,
        new_obj: str,
        existing_fact_id: str,
        similarity: float,
        policy: str,
        resolution: str,
        org_id: str = "",
        user_id: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Record a contradiction event. Returns the row ID."""
        row_id = int(time.time() * 1e6)
        now = datetime.now(timezone.utc).isoformat()
        meta_json = json.dumps(metadata or {})
        with self._lock:
            self._conn.execute(
                """INSERT INTO contradiction_log
                   (id, detected_at, subject, predicate, existing_obj, new_obj,
                    existing_fact_id, similarity, policy, resolution,
                    org_id, user_id, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                [
                    row_id, now, subject, predicate, existing_obj, new_obj,
                    existing_fact_id, similarity, policy, resolution,
                    org_id, user_id, meta_json,
                ],
            )
        logger.debug(
            "ContradictionLog: recorded id=%d subject=%s predicate=%s policy=%s",
            row_id, subject[:40], predicate[:40], policy,
        )
        return row_id

    def search(
        self,
        subject: Optional[str] = None,
        predicate: Optional[str] = None,
        org_id: Optional[str] = None,
        policy: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Query the contradiction log with optional filters.

        Returns list of dicts, most recent first.
        """
        conditions: List[str] = []
        params: List[Any] = []
        if subject:
            conditions.append("subject = ?")
            params.append(subject)
        if predicate:
            conditions.append("predicate = ?")
            params.append(predicate)
        if org_id:
            conditions.append("org_id = ?")
            params.append(org_id)
        if policy:
            conditions.append("policy = ?")
            params.append(policy)

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = f"SELECT * FROM contradiction_log {where} ORDER BY id DESC LIMIT ?"
        params.append(limit)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()

        columns = [
            "id", "detected_at", "subject", "predicate", "existing_obj",
            "new_obj", "existing_fact_id", "similarity", "policy",
            "resolution", "org_id", "user_id", "metadata",
        ]
        results = []
        for row in rows:
            d = dict(zip(columns, row))
            try:
                d["metadata"] = json.loads(d["metadata"]) if d["metadata"] else {}
            except (json.JSONDecodeError, TypeError):
                d["metadata"] = {}
            results.append(d)
        return results

    def count(self, org_id: Optional[str] = None) -> int:
        """Return the total number of contradiction events."""
        if org_id:
            with self._lock:
                row = self._conn.execute(
                    "SELECT COUNT(*) FROM contradiction_log WHERE org_id = ?", [org_id]
                ).fetchone()
        else:
            with self._lock:
                row = self._conn.execute("SELECT COUNT(*) FROM contradiction_log").fetchone()
        return row[0] if row else 0
