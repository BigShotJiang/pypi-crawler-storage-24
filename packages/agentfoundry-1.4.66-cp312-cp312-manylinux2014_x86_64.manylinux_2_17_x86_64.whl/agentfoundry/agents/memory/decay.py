"""Pure-function scoring module for memory decay and relevance ranking.

Provides time-based decay, access frequency boosting, and reranking of
similarity search results. All functions are stateless and easy to test.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from langchain_core.documents import Document

from agentfoundry.agents.memory.types import DecayConfig

# Default config values
_DEFAULTS: DecayConfig = {
    "half_life_days": 30.0,
    "similarity_weight": 0.7,
    "recency_weight": 0.2,
    "frequency_weight": 0.1,
    "min_score": 0.0,
    "access_boost_cap": 50,
}


def _get(config: Optional[DecayConfig], key: str) -> Any:
    """Get a config value with fallback to defaults."""
    if config and key in config:
        return config[key]  # type: ignore[literal-required]
    return _DEFAULTS[key]  # type: ignore[literal-required]


def compute_relevance_score(
    similarity: float,
    created_at: Optional[str],
    accessed_at: Optional[str],
    access_count: Optional[int],
    config: Optional[DecayConfig] = None,
    now: Optional[datetime] = None,
) -> float:
    """Compute a weighted relevance score combining similarity, recency, and frequency.

    Args:
        similarity: Raw similarity score from vector search (typically 0.0-1.0).
        created_at: ISO8601 timestamp of document creation.
        accessed_at: ISO8601 timestamp of last access (falls back to created_at).
        access_count: Number of times this document has been retrieved.
        config: Decay configuration overrides.
        now: Current time (defaults to utcnow).

    Returns:
        Weighted relevance score.
    """
    if now is None:
        now = datetime.now(timezone.utc)

    half_life = float(_get(config, "half_life_days"))
    sim_w = float(_get(config, "similarity_weight"))
    rec_w = float(_get(config, "recency_weight"))
    freq_w = float(_get(config, "frequency_weight"))
    cap = int(_get(config, "access_boost_cap"))

    # Normalize weights to sum to 1.0
    total_w = sim_w + rec_w + freq_w
    if total_w > 0:
        sim_w /= total_w
        rec_w /= total_w
        freq_w /= total_w

    # Recency factor: exponential decay based on age
    ref_time = _parse_iso(accessed_at) or _parse_iso(created_at)
    if ref_time is not None:
        age_days = max(0.0, (now - ref_time).total_seconds() / 86400.0)
    else:
        age_days = 0.0  # no timestamp → treat as fresh
    recency_factor = 0.5 ** (age_days / half_life) if half_life > 0 else 0.0

    # Frequency factor
    count = max(0, access_count or 0)
    frequency_factor = min(count, cap) / cap if cap > 0 else 0.0

    return (sim_w * similarity) + (rec_w * recency_factor) + (freq_w * frequency_factor)


def rerank_with_decay(
    docs_with_scores: List[Tuple[Document, float]],
    config: Optional[DecayConfig] = None,
    now: Optional[datetime] = None,
) -> List[Tuple[Document, float]]:
    """Rerank documents by combining similarity scores with decay and frequency.

    Args:
        docs_with_scores: List of (Document, similarity_score) tuples from vector search.
        config: Decay configuration overrides.
        now: Current time (defaults to utcnow).

    Returns:
        Reranked list of (Document, relevance_score) tuples, sorted descending.
    """
    if now is None:
        now = datetime.now(timezone.utc)

    min_score = float(_get(config, "min_score"))
    scored: List[Tuple[Document, float]] = []

    for doc, similarity in docs_with_scores:
        meta = doc.metadata or {}
        relevance = compute_relevance_score(
            similarity=similarity,
            created_at=meta.get("created_at"),
            accessed_at=meta.get("accessed_at"),
            access_count=meta.get("access_count"),
            config=config,
            now=now,
        )

        # Decay-exempt documents never rank below their raw similarity
        if meta.get("decay_exempt"):
            relevance = max(similarity, relevance)

        if relevance >= min_score:
            scored.append((doc, relevance))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored


def _parse_iso(ts: Optional[str]) -> Optional[datetime]:
    """Parse an ISO8601 timestamp string, returning None on failure."""
    if not ts:
        return None
    try:
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None
