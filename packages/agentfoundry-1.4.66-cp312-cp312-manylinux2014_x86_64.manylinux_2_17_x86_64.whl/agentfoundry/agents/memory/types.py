"""Common type definitions for the memory system."""

from __future__ import annotations

from typing import TypedDict, Optional, Any, Union, List

class MemoryMetadata(TypedDict, total=False):
    """Standard metadata fields for memory items."""
    user_id: str
    org_id: str
    scope: str
    role_level: int
    created_at: str
    thread_id: Optional[str]
    # Allow other arbitrary fields
    source: Optional[str]
    doc_id: Optional[str]
    # Decay and access tracking fields
    accessed_at: Optional[str]    # ISO8601, last retrieval time
    access_count: Optional[int]   # retrieval counter
    decay_exempt: Optional[bool]  # pinned memories skip decay
    # Contradiction provenance
    supersedes_fact_id: Optional[str]  # ID of the fact this one replaces


class DecayConfig(TypedDict, total=False):
    """Configuration for memory decay and relevance scoring."""
    half_life_days: float       # default 30.0
    similarity_weight: float    # default 0.7
    recency_weight: float       # default 0.2
    frequency_weight: float     # default 0.1
    min_score: float            # default 0.0
    access_boost_cap: int       # default 50

class SearchFilter(TypedDict, total=False):
    """Standard search filter fields."""
    user_id: str
    org_id: str
    thread_id: str
    scope: str
    # Complex filters often used by vector stores
    id: Union[str, dict]
    role_level: Union[int, dict]
    # Allow recursive structure for $and, $or queries
    # Use alternative syntax for keys with special characters
SearchFilter.__annotations__["$and"] = List[dict]
SearchFilter.__annotations__["$or"] = List[dict]
