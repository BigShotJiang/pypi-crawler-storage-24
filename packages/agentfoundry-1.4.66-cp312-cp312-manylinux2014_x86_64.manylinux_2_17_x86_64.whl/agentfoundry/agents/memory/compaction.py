"""Memory compaction pipeline.

Clusters semantically similar documents within a memory scope, summarizes
each cluster into a single document, and replaces the originals. This
reduces memory size while preserving information density.

The compaction pipeline is:
1. Retrieve all documents in scope
2. Cluster by text similarity (greedy, threshold-based)
3. For each cluster with 2+ documents: summarize → single replacement doc
4. Delete originals, insert summary
5. Preserve decay_exempt and highest access_count from cluster members

Compaction is opt-in and non-destructive until the final swap step.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from difflib import SequenceMatcher
from typing import Any, Callable, Dict, List, Optional, Tuple

from langchain_core.documents import Document

logger = logging.getLogger(__name__)


@dataclass
class CompactionConfig:
    """Configuration for memory compaction."""

    similarity_threshold: float = 0.75  # min similarity to cluster together
    min_cluster_size: int = 2  # clusters smaller than this are left alone
    max_summary_len: int = 500  # max chars for summary text
    preserve_recent_hours: float = 24.0  # don't compact docs newer than this
    dry_run: bool = False  # if True, plan but don't execute


@dataclass
class CompactionCluster:
    """A group of similar documents to be merged."""

    docs: List[Document] = field(default_factory=list)
    doc_ids: List[str] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.docs)

    @property
    def texts(self) -> List[str]:
        return [d.page_content for d in self.docs]

    @property
    def total_chars(self) -> int:
        return sum(len(t) for t in self.texts)

    def best_metadata(self) -> Dict[str, Any]:
        """Merge metadata from cluster members, preserving important fields."""
        if not self.docs:
            return {}
        # Start with first doc's metadata
        merged = dict(self.docs[0].metadata or {})
        max_access = merged.get("access_count", 0) or 0
        is_exempt = merged.get("decay_exempt", False)

        for doc in self.docs[1:]:
            meta = doc.metadata or {}
            ac = meta.get("access_count", 0) or 0
            if ac > max_access:
                max_access = ac
            if meta.get("decay_exempt"):
                is_exempt = True

        merged["access_count"] = max_access
        if is_exempt:
            merged["decay_exempt"] = True
        merged["compacted_from"] = len(self.docs)
        merged["compacted_at"] = datetime.now(timezone.utc).isoformat()
        merged["created_at"] = datetime.now(timezone.utc).isoformat()
        merged["accessed_at"] = datetime.now(timezone.utc).isoformat()
        return merged


@dataclass
class CompactionResult:
    """Summary of a compaction run."""

    total_docs: int = 0
    clusters_found: int = 0
    clusters_compacted: int = 0
    docs_removed: int = 0
    docs_created: int = 0
    chars_before: int = 0
    chars_after: int = 0
    dry_run: bool = False

    @property
    def chars_saved(self) -> int:
        return self.chars_before - self.chars_after

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_docs": self.total_docs,
            "clusters_found": self.clusters_found,
            "clusters_compacted": self.clusters_compacted,
            "docs_removed": self.docs_removed,
            "docs_created": self.docs_created,
            "chars_before": self.chars_before,
            "chars_after": self.chars_after,
            "chars_saved": self.chars_saved,
            "dry_run": self.dry_run,
        }


def text_similarity(a: str, b: str) -> float:
    """Fast text similarity using SequenceMatcher."""
    if not a or not b:
        return 0.0
    # Use normalized lower for comparison
    na = " ".join(a.lower().split())
    nb = " ".join(b.lower().split())
    if na == nb:
        return 1.0
    return SequenceMatcher(None, na, nb).ratio()


def cluster_documents(
    docs: List[Document],
    threshold: float = 0.75,
) -> List[CompactionCluster]:
    """Cluster documents by text similarity using greedy assignment.

    Each document is assigned to the first cluster whose centroid
    (first document) it matches above the threshold. Documents that
    don't match any existing cluster start a new one.

    Args:
        docs: List of documents to cluster.
        threshold: Minimum similarity to join an existing cluster.

    Returns:
        List of CompactionCluster instances.
    """
    clusters: List[CompactionCluster] = []

    for doc in docs:
        doc_id = getattr(doc, "id", None) or (doc.metadata or {}).get("__doc_id__", "")
        text = doc.page_content

        assigned = False
        for cluster in clusters:
            # Compare against the cluster's first document (centroid)
            sim = text_similarity(text, cluster.docs[0].page_content)
            if sim >= threshold:
                cluster.docs.append(doc)
                cluster.doc_ids.append(doc_id)
                assigned = True
                break

        if not assigned:
            clusters.append(CompactionCluster(
                docs=[doc], doc_ids=[doc_id],
            ))

    return clusters


def default_summarizer(texts: List[str], max_len: int = 500) -> str:
    """Simple concatenation-based summarizer (no LLM dependency).

    For production use, replace with an LLM-backed summarizer via the
    `summarizer` parameter of `compact()`.
    """
    combined = " | ".join(t.strip() for t in texts if t.strip())
    if len(combined) <= max_len:
        return combined
    # Truncate with ellipsis
    return combined[:max_len - 3] + "..."


def compact(
    docs_with_scores: List[Tuple[Document, float]],
    config: Optional[CompactionConfig] = None,
    summarizer: Optional[Callable[[List[str], int], str]] = None,
) -> Tuple[CompactionResult, List[CompactionCluster], List[Tuple[Document, Dict[str, Any]]]]:
    """Plan and optionally execute memory compaction.

    This is a pure function that takes documents and returns what should
    be done. The caller (BaseMemory.compact) handles actual vector store
    mutations.

    Args:
        docs_with_scores: List of (Document, score) from similarity_search_with_score.
        config: Compaction configuration.
        summarizer: Function(texts, max_len) -> summary_text.
            Defaults to simple concatenation.

    Returns:
        Tuple of (CompactionResult, clusters, replacements).
        - clusters: all clusters found
        - replacements: List of (new_doc, old_metadata) for clusters that
          were compacted. Only populated if not dry_run.
    """
    if config is None:
        config = CompactionConfig()
    if summarizer is None:
        summarizer = default_summarizer

    docs = [doc for doc, _ in docs_with_scores]
    result = CompactionResult(
        total_docs=len(docs),
        dry_run=config.dry_run,
    )

    if not docs:
        return result, [], []

    # Filter out recently created docs
    now = datetime.now(timezone.utc)
    eligible: List[Document] = []
    for doc in docs:
        meta = doc.metadata or {}
        created = meta.get("created_at")
        if created and config.preserve_recent_hours > 0:
            try:
                dt = datetime.fromisoformat(created)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                age_hours = (now - dt).total_seconds() / 3600.0
                if age_hours < config.preserve_recent_hours:
                    continue  # too recent, skip
            except (ValueError, TypeError):
                pass
        eligible.append(doc)

    # Cluster eligible documents
    clusters = cluster_documents(eligible, threshold=config.similarity_threshold)
    result.clusters_found = len(clusters)

    # Build replacement documents for clusters that meet min size
    replacements: List[Tuple[Document, Dict[str, Any]]] = []
    for cluster in clusters:
        if cluster.count < config.min_cluster_size:
            continue

        result.clusters_compacted += 1
        result.docs_removed += cluster.count
        result.chars_before += cluster.total_chars

        # Summarize
        summary_text = summarizer(cluster.texts, config.max_summary_len)
        result.chars_after += len(summary_text)
        result.docs_created += 1

        # Build replacement document
        merged_meta = cluster.best_metadata()
        new_doc = Document(page_content=summary_text, metadata=merged_meta)

        replacements.append((new_doc, {"removed_ids": cluster.doc_ids}))

    logger.info(
        "compaction: total=%d eligible=%d clusters=%d compacted=%d "
        "removed=%d created=%d chars_saved=%d dry_run=%s",
        result.total_docs, len(eligible), result.clusters_found,
        result.clusters_compacted, result.docs_removed, result.docs_created,
        result.chars_saved, result.dry_run,
    )

    return result, clusters, replacements
