"""Contradiction detection for knowledge graph facts.

Pure-function module that identifies when a new fact contradicts an existing
one (same subject+predicate, different object). Detection is non-blocking —
callers decide how to handle conflicts (log, reject, overwrite).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from difflib import SequenceMatcher
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Contradiction:
    """A detected conflict between a new fact and an existing one."""

    fact_id: str
    subject: str
    predicate: str
    existing_obj: str
    new_obj: str
    similarity: float  # how similar the objects are (high = same topic, different value)
    created_at: Optional[str] = None


@dataclass
class Fact:
    """Lightweight representation of a KGraph triple with metadata."""

    subject: str
    predicate: str
    object: str
    fact_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


def normalize_text(text: str) -> str:
    """Normalize text for comparison: lowercase, strip, collapse whitespace."""
    return " ".join(text.lower().split())


def text_similarity(a: str, b: str) -> float:
    """Compute similarity between two strings using SequenceMatcher.

    Returns a float in [0.0, 1.0]. This is a fast, dependency-free
    approximation. For production use with large fact stores, callers
    can substitute embedding-based cosine similarity.
    """
    if not a or not b:
        return 0.0
    na, nb = normalize_text(a), normalize_text(b)
    if na == nb:
        return 1.0
    return SequenceMatcher(None, na, nb).ratio()


def find_contradictions(
    new_fact: Fact,
    existing_facts: List[Fact],
    threshold: float = 0.85,
) -> List[Contradiction]:
    """Detect contradictions between a new fact and existing facts.

    A contradiction is when two facts share the same (subject, predicate)
    but have different objects that are topically similar (above threshold).
    This catches cases like:
      - ("Alice", "prefers_theme", "dark-mode") vs ("Alice", "prefers_theme", "light-mode")
      - ("server-1", "status", "healthy") vs ("server-1", "status", "degraded")

    Exact duplicates (same object) are NOT contradictions.

    Args:
        new_fact: The fact being written.
        existing_facts: Facts already in the knowledge graph.
        threshold: Minimum similarity between objects to flag a contradiction.
            Higher values are stricter (fewer false positives).
            Set to 0.0 to flag all same-(subject,predicate) pairs with different objects.

    Returns:
        List of Contradiction instances, sorted by similarity descending.
    """
    new_subj = normalize_text(new_fact.subject)
    new_pred = normalize_text(new_fact.predicate)
    new_obj_norm = normalize_text(new_fact.object)

    contradictions: List[Contradiction] = []

    for existing in existing_facts:
        # Must share subject and predicate
        if normalize_text(existing.subject) != new_subj:
            continue
        if normalize_text(existing.predicate) != new_pred:
            continue

        existing_obj_norm = normalize_text(existing.object)

        # Exact same object is not a contradiction
        if existing_obj_norm == new_obj_norm:
            continue

        sim = text_similarity(existing.object, new_fact.object)
        if sim >= threshold:
            contradictions.append(
                Contradiction(
                    fact_id=existing.fact_id,
                    subject=existing.subject,
                    predicate=existing.predicate,
                    existing_obj=existing.object,
                    new_obj=new_fact.object,
                    similarity=sim,
                    created_at=existing.metadata.get("created_at"),
                )
            )

    contradictions.sort(key=lambda c: c.similarity, reverse=True)
    return contradictions


def check_and_flag(
    kgraph: Any,
    new_subject: str,
    new_predicate: str,
    new_obj: str,
    metadata: Dict[str, Any],
    threshold: float = 0.85,
) -> List[Contradiction]:
    """Query the KGraph and check for contradictions before a write.

    Convenience wrapper that fetches existing facts for the subject and
    runs find_contradictions. Does NOT block writes — the caller decides
    what to do with the returned contradictions.

    Args:
        kgraph: A KGraph instance with a search() method.
        new_subject: Subject of the fact being written.
        new_predicate: Predicate of the fact being written.
        new_obj: Object of the fact being written.
        metadata: Metadata for the new fact (used for user_id/org_id in search).
        threshold: Contradiction similarity threshold.

    Returns:
        List of Contradiction instances (empty if none found).
    """
    user_id = metadata.get("user_id", "")
    org_id = metadata.get("org_id", "")

    # Search for facts related to this subject
    try:
        results = kgraph.search(
            new_subject, user_id=user_id, org_id=org_id, k=20
        )
    except Exception as e:
        logger.warning("contradiction check: search failed: %s", e)
        return []

    # Convert search results to Fact objects
    existing: List[Fact] = []
    for r in results:
        if isinstance(r, dict):
            existing.append(
                Fact(
                    subject=r.get("subject", ""),
                    predicate=r.get("predicate", ""),
                    object=r.get("object", ""),
                    fact_id=r.get("fact_id", r.get("id", "")),
                    metadata=r.get("metadata", {}),
                )
            )

    new_fact = Fact(
        subject=new_subject,
        predicate=new_predicate,
        object=new_obj,
        metadata=metadata,
    )

    contradictions = find_contradictions(new_fact, existing, threshold=threshold)

    if contradictions:
        logger.warning(
            "contradiction check: %d contradiction(s) found for (%s, %s, %s): %s",
            len(contradictions),
            new_subject,
            new_predicate,
            new_obj[:60],
            [(c.fact_id[:8], c.existing_obj[:40]) for c in contradictions],
        )

    return contradictions


# ---------------------------------------------------------------------------
# Conflict resolution
# ---------------------------------------------------------------------------


class ConflictPolicy(str, Enum):
    """How to handle a detected contradiction."""

    LOG_ONLY = "log_only"       # Log the contradiction, proceed with write
    REJECT = "reject"           # Block the write, raise ConflictRejected
    SUPERSEDE = "supersede"     # Write new fact with supersedes_fact_id, soft-delete old
    ASK_USER = "ask_user"       # Return contradictions for caller to present to user


class ConflictRejected(Exception):
    """Raised when a write is rejected due to a contradiction under REJECT policy."""

    def __init__(self, contradictions: List[Contradiction]) -> None:
        self.contradictions = contradictions
        subjects = ", ".join(c.existing_obj[:40] for c in contradictions[:3])
        super().__init__(f"Fact write rejected: conflicts with existing value(s): {subjects}")


@dataclass
class ConflictResolution:
    """Result of applying a conflict policy to a set of contradictions."""

    policy: ConflictPolicy
    contradictions: List[Contradiction]
    action_taken: str  # human-readable description
    superseded_ids: List[str] = field(default_factory=list)
    proceed: bool = True  # whether the write should continue


def resolve_contradiction(
    contradictions: List[Contradiction],
    policy: ConflictPolicy,
    metadata: Optional[Dict[str, Any]] = None,
    kgraph: Any = None,
) -> ConflictResolution:
    """Apply a conflict policy to a set of contradictions.

    Args:
        contradictions: List of detected contradictions.
        policy: The policy to apply.
        metadata: Metadata dict for the new fact (modified in-place for SUPERSEDE).
        kgraph: KGraph instance (needed for SUPERSEDE to soft-delete old facts).

    Returns:
        ConflictResolution describing the outcome.

    Raises:
        ConflictRejected: If policy is REJECT and contradictions exist.
    """
    if not contradictions:
        return ConflictResolution(
            policy=policy, contradictions=[], action_taken="no_conflict", proceed=True
        )

    if policy == ConflictPolicy.LOG_ONLY:
        logger.warning(
            "ConflictPolicy.LOG_ONLY: %d contradiction(s) logged, proceeding with write",
            len(contradictions),
        )
        return ConflictResolution(
            policy=policy,
            contradictions=contradictions,
            action_taken="logged",
            proceed=True,
        )

    if policy == ConflictPolicy.REJECT:
        logger.warning(
            "ConflictPolicy.REJECT: blocking write due to %d contradiction(s)",
            len(contradictions),
        )
        raise ConflictRejected(contradictions)

    if policy == ConflictPolicy.SUPERSEDE:
        superseded = []
        for c in contradictions:
            if c.fact_id:
                superseded.append(c.fact_id)
                # Attempt soft-delete of old fact via KGraph
                if kgraph is not None:
                    try:
                        if hasattr(kgraph, "delete"):
                            kgraph.delete(ids=[c.fact_id])
                        elif hasattr(kgraph, "purge_expired"):
                            # Some KGraph implementations lack delete;
                            # log a warning but don't crash
                            logger.debug(
                                "resolve_contradiction: KGraph lacks delete(); "
                                "old fact %s not removed", c.fact_id[:12],
                            )
                    except Exception as e:
                        logger.warning(
                            "resolve_contradiction: failed to delete old fact %s: %s",
                            c.fact_id[:12], e,
                        )
        # Tag the new fact's metadata with provenance
        if metadata is not None and superseded:
            metadata["supersedes_fact_id"] = superseded[0] if len(superseded) == 1 else superseded

        logger.info(
            "ConflictPolicy.SUPERSEDE: superseding %d old fact(s): %s",
            len(superseded), [fid[:12] for fid in superseded],
        )
        return ConflictResolution(
            policy=policy,
            contradictions=contradictions,
            action_taken="superseded",
            superseded_ids=superseded,
            proceed=True,
        )

    if policy == ConflictPolicy.ASK_USER:
        logger.info(
            "ConflictPolicy.ASK_USER: %d contradiction(s) returned for user decision",
            len(contradictions),
        )
        return ConflictResolution(
            policy=policy,
            contradictions=contradictions,
            action_taken="awaiting_user",
            proceed=False,
        )
