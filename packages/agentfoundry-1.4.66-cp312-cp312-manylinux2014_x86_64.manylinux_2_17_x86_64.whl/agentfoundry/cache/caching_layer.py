from __future__ import annotations

import atexit
import hashlib
import json
import logging
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, cast

import duckdb  # type: ignore
import numpy as _np
from langchain_core.documents import Document

from agentfoundry.agents.memory.types import MemoryMetadata, SearchFilter

# Import module-level config getter from memory_tools
try:
    from agentfoundry.agents.tools.memory_tools import get_module_config
except ImportError:
    get_module_config = lambda: None  # noqa: E731

logger = logging.getLogger(__name__)


def _get_cache_dir() -> str:
    """Get cache directory from module config or default."""
    cfg = get_module_config()
    if cfg and cfg.cache_dir:
        return str(cfg.cache_dir)
    return "./data/cache"


def _get_faiss_index_path() -> Optional[str]:
    """Get FAISS index path from module config."""
    cfg = get_module_config()
    if cfg and cfg.vector_store.index_path:
        return str(cfg.vector_store.index_path)
    return None


def _use_hash_embeddings() -> bool:
    flag = os.getenv("AF_DISABLE_OPENAI_EMBEDDINGS", "0").lower() in ("1", "true", "yes", "on")
    has_key = bool(os.getenv("OPENAI_API_KEY") or os.getenv("AF_OPENAI_API_KEY"))
    return flag or not has_key


class _HashEmbeddings:
    """Deterministic fallback embeddings for local shadow index."""

    def __init__(self, dim: int = 128) -> None:
        self.dim = int(dim)

    def _vec(self, text: str) -> _np.ndarray:
        import itertools

        digest = hashlib.sha256((text or "").encode("utf-8")).digest()
        vals = [((byte / 255.0) - 0.5) for byte in itertools.islice(itertools.cycle(digest), self.dim)]
        return _np.array(vals, dtype=_np.float32)

    def embed_query(self, text: str) -> list[float]:
        return self._vec(text).tolist()

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [self._vec(t).tolist() for t in texts]


# -------------------------------------------------------------
# Small TTL LRU cache for read-through query memoization
# -------------------------------------------------------------
class _LRU:
    def __init__(self, cap: int = 256, ttl_s: int = 30) -> None:
        self.cap = cap
        self.ttl = ttl_s
        self._d: Dict[Any, Tuple[float, Any]] = {}
        self._order: List[Any] = []
        self._lock = threading.Lock()
        logger.debug(f"_LRU initialized with cap={cap}, ttl_s={ttl_s}")

    def get(self, k: Any):
        now = time.time()
        with self._lock:
            v = self._d.get(k)
            if not v:
                logger.debug("_LRU.get: miss (key not present)")
                return None
            ts, data = v
            if now - ts > self.ttl:
                logger.debug("_LRU.get: expired entry; deleting and returning miss")
                self._delete(k)
                return None
            # bump recency
            try:
                self._order.remove(k)
            except ValueError:
                pass
            self._order.append(k)
            logger.debug("_LRU.get: hit (recency updated)")
            return data

    def set(self, k: Any, v: Any):
        with self._lock:
            if k in self._d:
                try:
                    self._order.remove(k)
                except ValueError:
                    pass
            elif len(self._order) >= self.cap:
                ev = self._order.pop(0)
                self._d.pop(ev, None)
                logger.debug(f"_LRU.set: capacity reached; evicted oldest key={ev!r}")
            self._d[k] = (time.time(), v)
            self._order.append(k)
            logger.debug(f"_LRU.set: stored key; size={len(self._order)}/{self.cap}")

    def invalidate_prefix(self, prefix: Tuple[Any, ...]) -> None:
        with self._lock:
            keys = [k for k in self._d.keys() if isinstance(k, tuple) and k[: len(prefix)] == prefix]
            for k in keys:
                self._delete(k)
            logger.debug(f"_LRU.invalidate_prefix: removed={len(keys)} for prefix={prefix!r}")

    def _delete(self, k: Any) -> None:
        self._d.pop(k, None)
        try:
            self._order.remove(k)
        except ValueError:
            pass

    def invalidate_if(self, predicate) -> int:
        """Invalidate any cached entries whose key satisfies predicate(key).

        Returns the number of entries removed.
        """
        removed = 0
        with self._lock:
            keys = list(self._d.keys())
            for k in keys:
                try:
                    if predicate(k):
                        self._delete(k)
                        removed += 1
                except Exception as e:  # noqa
                    # Be conservative – do not remove if predicate errors
                    logger.debug(f"_LRU.invalidate_if: predicate raised {e!r} for key={k!r}")
                    pass
        if removed:
            logger.debug(f"_LRU.invalidate_if: removed={removed} entries")
        return removed


# -------------------------------------------------------------
# Background batch flusher helper
# -------------------------------------------------------------
class _FlushThread(threading.Thread):
    def __init__(self, name: str, fn_flush_batch, interval_s: float, batch_size: int) -> None:
        super().__init__(name=name, daemon=True)
        self.fn = fn_flush_batch
        self.interval_s = interval_s
        self.batch_size = batch_size
        self._q: List[Any] = []
        self._cv = threading.Condition()
        self._stop = False
        logger.info(
            f"{self.name}: initialized flusher with interval_s={interval_s}, batch_size={batch_size}"
        )

    def enqueue(self, item: Any) -> None:
        with self._cv:
            self._q.append(item)
            self._cv.notify()
        if logger.isEnabledFor(logging.DEBUG):
            try:
                preview = item if isinstance(item, (str, int)) else type(item).__name__
                logger.debug(f"{self.name}: enqueued item={preview!r}; q_len={len(self._q)}")
            except Exception:
                logger.debug(f"{self.name}: enqueued item; q_len={len(self._q)}")

    def run(self) -> None:  # pragma: no cover (threads are hard to deterministically test)
        pending: List[Any] = []
        last = 0.0
        while True:
            with self._cv:
                if not self._q and not self._stop:
                    self._cv.wait(timeout=self.interval_s)
                q, self._q = self._q, []
                stop = self._stop
            pending.extend(q)
            now = time.time()
            if pending and (len(pending) >= self.batch_size or now - last >= self.interval_s or stop):
                try:
                    batch = pending[:]
                    logger.debug(f"{self.name}: flushing batch size={len(batch)} stop={stop}")
                    self.fn(batch)
                    pending.clear()
                    last = now
                except Exception as e:  # noqa
                    logger.error(f"{self.name}: flush error: {e}", exc_info=True)
                    # backoff on error
                    time.sleep(min(30.0, self.interval_s * 2.0))
            if stop:
                if pending:
                    logger.debug(f"{self.name}: stopping with {len(pending)} pending items (dropping)")
                break

    def stop(self) -> None:
        with self._cv:
            self._stop = True
            self._cv.notify_all()
        logger.info(f"{self.name}: stop requested")


# -------------------------------------------------------------
# Caching Vector Provider (write-behind + read-through)
# -------------------------------------------------------------
@dataclass
class _LocalDoc:
    id: str
    emb: _np.ndarray
    doc: Document


class CachingVectorProvider:
    """Write-behind wrapper around a VectorStore provider.

    - add_documents: stages docs into a small local in-memory index (read-your-writes),
      enqueues a background flush to the remote provider, and returns immediately.
    - similarity_search: tries query cache, then searches local index, then
      falls back to the remote provider, merging unique results.
    """

    _emb = None  # shared embedding model across instances
    # Singleton map: one wrapper per remote provider identity
    _INSTANCES: dict[int, "CachingVectorProvider"] = {}
    _LOCK = threading.Lock()

    def __new__(cls, remote_provider, *, cache_dir: Optional[str] = None):  # type: ignore[override]
        key = id(remote_provider)
        with cls._LOCK:
            inst = cls._INSTANCES.get(key)
            if inst is None:
                inst = super().__new__(cls)
                cls._INSTANCES[key] = inst
                # mark as not yet initialised
                setattr(inst, "_initialized", False)
        return inst

    def __init__(self, remote_provider, *, cache_dir: Optional[str] = None) -> None:
        # Prevent duplicate initialisation when singleton is reused
        if getattr(self, "_initialized", False):
            return
        from langchain_openai.embeddings import OpenAIEmbeddings  # lazy import

        self.remote = remote_provider
        if hasattr(self.remote, 'verify_connectivity'):
            self.remote.verify_connectivity()
        base = cache_dir or _get_cache_dir()
        self.cache_dir = os.path.join(base, "vs")
        os.makedirs(self.cache_dir, exist_ok=True)
        logger.info(
            f"CachingVectorProvider init: cache_dir={self.cache_dir}, remote_provider={type(remote_provider).__name__}"
        )

        # local shadow index
        if CachingVectorProvider._emb is None:
            if _use_hash_embeddings():
                CachingVectorProvider._emb = _HashEmbeddings()
                logger.debug("CachingVectorProvider: using hash embeddings for local shadow index")
            else:
                try:
                    CachingVectorProvider._emb = OpenAIEmbeddings()
                    logger.debug("CachingVectorProvider: OpenAIEmbeddings loaded for local shadow index")
                except Exception as e:  # noqa
                    CachingVectorProvider._emb = _HashEmbeddings()
                    logger.warning(f"CachingVectorProvider: falling back to hash embeddings: {e}")
        self.emb = CachingVectorProvider._emb
        self._local_enabled = os.getenv("AF_CACHE_VS_LOCAL_DISABLE", "0").lower() not in ("1", "true", "yes", "on")
        self._local_cap = int(os.getenv("AF_CACHE_VS_LOCAL_CAP", "1000"))
        try:
            self._local_max_chars = int(os.getenv("AF_CACHE_VS_LOCAL_MAX_CHARS", "0") or "0")
        except Exception:
            self._local_max_chars = 0
        self._local: List[_LocalDoc] = []
        self._lock = threading.Lock()
        # Optional ANN backend for local shadow index
        self._ann_backend = os.getenv("AF_CACHE_VS_LOCAL_INDEX", "linear").lower().strip()
        self._faiss = None
        self._ann_index = None
        self._ann_ids: List[str] = []
        if self._ann_backend == "faiss":
            try:
                import faiss  # type: ignore

                self._faiss = faiss
                logger.debug("CachingVectorProvider: FAISS enabled for local shadow index")
            except Exception as e:  # noqa
                logger.warning(f"CachingVectorProvider: FAISS unavailable ({e}); falling back to linear search")
                self._ann_backend = "linear"
        # map recent doc_id -> (org_id, user_id, role_level)
        self._doc_index: Dict[str, Tuple[str, str, int]] = {}
        logger.debug(
            f"CachingVectorProvider config: local_cap={self._local_cap}, qcache_cap={os.getenv('AF_CACHE_Q_CAP','256')}, qcache_ttl={os.getenv('AF_CACHE_Q_TTL','30')}"
        )

        # small read cache
        self._qcache = _LRU(
            cap=int(os.getenv("AF_CACHE_Q_CAP", "256")),
            ttl_s=int(os.getenv("AF_CACHE_Q_TTL", "30")),
        )

        # background flusher
        self._flusher = _FlushThread(
            name="VSFlush",
            fn_flush_batch=self._flush_docs,
            interval_s=float(os.getenv("AF_CACHE_FLUSH_S", "0.75")),
            batch_size=int(os.getenv("AF_CACHE_BATCH", "64")),
        )
        self._flusher.start()
        atexit.register(self._flusher.stop)
        logger.info("CachingVectorProvider: background flusher started for vector store")
        self._initialized = True

    # ----------------- public API -----------------
    def add_documents(
        self,
        documents: List[Document],
        ids: Optional[List[str]] = None,
        allow_update: bool = True,
        **kwargs,
    ):
        logger.info(
            f"add_documents: count={len(documents)}, ids_provided={bool(ids)}, allow_update={allow_update}, extra_keys={list(kwargs.keys())}"
        )
        out_ids: List[str] = []
        local_only = bool(kwargs.pop("local_only", False))
        for i, d in enumerate(documents):
            did = (ids[i] if ids else getattr(d, "id", None)) or self._det_id(
                d.page_content, getattr(d, "metadata", None)
            )
            # ensure metadata dict exists
            d.metadata = dict(getattr(d, "metadata", {}) or {})
            d.metadata.setdefault("__doc_id__", did)
            out_ids.append(did)
            # immediate local visibility of embeddings available
            self._stage_local(did, d)
            # invalidate cache for queries that could now see this doc
            scope = self._scope_key(d.metadata)
            removed = self._invalidate_for_new_doc(scope, int(d.metadata.get("role_level", 0)))
            # track doc scope for targeted invalidation on delete
            try:
                self._doc_index[did] = (scope[0], scope[1], int(scope[2] or 0))
            except Exception:
                logger.debug(
                    "add_documents: failed to index doc scope for delete invalidation",
                    exc_info=True,
                )
                pass
            # If local embeddings are unavailable, perform a synchronous
            # write-through to the remote provider so callers immediately see
            # their writes during tests and minimal environments.
            if self.emb is None:
                try:
                    if not local_only:
                        self.remote.add_documents([d], ids=[did], allow_update=bool(allow_update), **kwargs)
                        # Persist FAISS index to disk if available
                        try:
                            store = self.remote.get_store()
                            path = _get_faiss_index_path()
                            if hasattr(store, "save_local") and path:
                                store.save_local(path)
                                logger.debug("add_documents: persisted FAISS index to %s", path)
                        except Exception:  # noqa
                            logger.debug("add_documents: FAISS persist skipped (not available)")
                    logger.debug(f"add_documents: synchronously flushed doc_id={did!r} to remote")
                except Exception:
                    logger.error("add_documents: synchronous remote add failed", exc_info=True)
            else:
                if not local_only:
                    # enqueue for remote flush
                    # include passthrough kwargs for remote provider flush
                    self._flusher.enqueue(("add", d, did, bool(allow_update), dict(kwargs)))
                    logger.debug(
                        f"add_documents: staged doc_id={did!r}, scope={scope}, cache_invalidated={removed}"
                    )
        logger.info(f"add_documents: staged={len(out_ids)} docs; returning ids")
        return out_ids

    def similarity_search_with_score(self, query: str, k: int = 5, **kwargs) -> List[Tuple[Document, float]]:
        """Search and return documents with their similarity scores.

        Returns:
            List of (Document, score) tuples sorted by score descending.
        """
        logger.debug(
            "similarity_search_with_score: query_len=%d, k=%d, kwargs_keys=%s",
            len(query), k, list(kwargs.keys()),
        )
        scope = self._scope_from_kwargs(kwargs)
        filter_dict = kwargs.get("filter") or kwargs.get("where")

        merged: List[Tuple[Document, float]] = []
        seen: set[str] = set()

        # 1) local scored search
        local_hits = self._local_search_with_score(query, k, scope, filter_dict)
        for doc, score in local_hits:
            did = getattr(doc, "id", None) or doc.metadata.get("__doc_id__") or self._det_id(
                doc.page_content, doc.metadata
            )
            if did not in seen:
                seen.add(did)
                merged.append((doc, score))

        # 2) remote scored search
        try:
            remote_fn = getattr(self.remote, "similarity_search_with_score", None)
            if remote_fn is not None:
                remote_results = remote_fn(query, k=k, **kwargs)
            else:
                # Fallback: remote only supports similarity_search, assign score=1.0
                remote_docs = self.remote.similarity_search(query, k=k, **kwargs)
                remote_results = [(d, 1.0) for d in remote_docs]
        except Exception:
            logger.warning(
                "similarity_search_with_score: remote provider failed; continuing with local",
                exc_info=True,
            )
            remote_results = []
        for doc, score in remote_results:
            did = getattr(doc, "id", None) or doc.metadata.get("__doc_id__") or self._det_id(
                doc.page_content, doc.metadata
            )
            if did not in seen:
                seen.add(did)
                merged.append((doc, score))

        # Sort by score descending, truncate
        merged.sort(key=lambda x: x[1], reverse=True)
        merged = merged[:k]

        # Record access if tracker is wired
        access_tracker = getattr(self, "access_tracker", None)
        if access_tracker is not None:
            try:
                access_tracker.record_access([doc for doc, _ in merged])
            except Exception:
                logger.debug("similarity_search_with_score: access tracking failed", exc_info=True)

        return merged

    def _local_search_with_score(
        self,
        query: str,
        k: int,
        scope: Tuple[str, str, str],
        filt: Optional[Dict[str, Any]],
    ) -> List[Tuple[Document, float]]:
        """Local shadow search returning (Document, cosine_similarity) tuples."""
        if self.emb is None:
            return []
        try:
            qv = _np.array(self.emb.embed_query(query), dtype=_np.float32)
        except Exception:
            return []
        with self._lock:
            if not self._local:
                return []
            # Linear cosine similarity (always use linear for scored search)
            mat = _np.stack([ld.emb for ld in self._local])
            norms = _np.linalg.norm(mat, axis=1) * _np.linalg.norm(qv) + 1e-9
            sims = (mat @ qv) / norms
            idxs = _np.argsort(-sims)[: max(1, min(int(k) * 3, len(self._local)))]
            hits: List[Tuple[Document, float]] = []
            for i in idxs:
                ld = self._local[int(i)]
                meta = ld.doc.metadata or {}
                if self._in_scope(meta, scope) and self._filter_matches(meta, filt):
                    hits.append((ld.doc, float(sims[int(i)])))
                if len(hits) >= k:
                    break
            return hits

    def similarity_search(self, query: str, k: int = 5, **kwargs):
        logger.debug(f"similarity_search: query_len={len(query)}, k={k}, kwargs_keys={list(kwargs.keys())}")
        try:
            logger.info(
                "similarity_search: scope org=%s user=%s role=%s provider=%s where=%s",
                kwargs.get("org_id"), kwargs.get("user_id"), kwargs.get("caller_role_level"),
                type(self.remote).__name__, kwargs.get("filter") or kwargs.get("where")
            )
        except Exception:
            pass
        scope = self._scope_from_kwargs(kwargs)
        filter_dict = kwargs.get("filter") or kwargs.get("where")
        filter_key = ""
        if filter_dict:
            try:
                filter_key = json.dumps(filter_dict, sort_keys=True, separators=(",", ":"))
            except Exception:
                filter_key = str(filter_dict)
        ck = (*scope, query, int(k), filter_key)
        cached = self._qcache.get(ck)
        if cached is not None:
            logger.debug(
                f"similarity_search: cache HIT for scope={scope} query_hash={hashlib.sha256(query.encode()).hexdigest()[:8]} k={k}; returning {len(cached)} docs"
            )
            return cached

        merged: List[Document] = []
        seen: set[str] = set()

        # 1) local (best-effort)
        local_hits = self._local_search(query, k, scope, filter_dict)
        logger.debug(f"similarity_search: local_hits={len(local_hits)}")
        for d in local_hits:
            did = getattr(d, "id", None) or d.metadata.get("__doc_id__") or self._det_id(
                d.page_content, d.metadata
            )
            if did not in seen:
                seen.add(did)
                merged.append(d)

        # 2) remote
        try:
            remote_docs = self.remote.similarity_search(query, k=k, **kwargs)
            try:
                logger.info("similarity_search: remote provider returned %d docs", len(remote_docs))
            except Exception:
                pass
        except Exception:
            logger.warning(
                "similarity_search: remote provider failed; continuing with local hits",
                exc_info=True,
            )
            remote_docs = []
        for d in remote_docs:
            did = getattr(d, "id", None) or d.metadata.get("__doc_id__") or self._det_id(
                d.page_content, d.metadata
            )
            if did not in seen:
                seen.add(did)
                merged.append(d)

        merged = merged[:k]
        self._qcache.set(ck, merged)
        logger.debug(
            f"similarity_search: merged_results={len(merged)}; cache SET for scope={scope} query_hash={hashlib.sha256(query.encode()).hexdigest()[:8]}"
        )
        return merged

    def delete(self, *args, **kwargs):  # passthrough with local invalidation
        logger.info("delete: invoked; attempting local invalidation then delegating to remote")
        ids = []
        if args:
            # try the first positional as ids list (langchain convention)
            ids = args[0] if isinstance(args[0], list) else []
        if not ids:
            ids = kwargs.get("ids", []) or []
        # remove from local shadow and invalidate related cache keys
        if ids:
            with self._lock:
                self._local = [ld for ld in self._local if ld.id not in ids]
            logger.debug(f"delete: removed {len(ids)} docs from local shadow index")
            for did in ids:
                meta = self._doc_index.pop(did, None)
                if meta:
                    org, user, role = meta
                    removed = self._invalidate_for_new_doc((org, user, str(role)), role)
                    logger.debug(
                        f"delete: invalidated {removed} cache entries for doc_id={did!r} scope={(org,user,role)}"
                    )
        else:
            logger.debug("delete: no ids provided for local invalidation")
        return getattr(self.remote, "delete")(*args, **kwargs)

    # ----------------- helpers -----------------
    @staticmethod
    def _det_id(text: str, meta: MemoryMetadata | Dict[str, Any] | None) -> str:
        h = hashlib.sha256()
        h.update((text or "").encode())
        if meta:
            try:
                h.update(json.dumps(meta, sort_keys=True).encode())
            except Exception:  # noqa
                h.update(str(meta).encode())
        return h.hexdigest()

    @staticmethod
    def _scope_key(meta: MemoryMetadata | Dict[str, Any]) -> Tuple[str, str, str]:
        return (
            str(meta.get("org_id", "")),
            str(meta.get("user_id", "")),
            str(meta.get("role_level", "")),
        )

    @staticmethod
    def _scope_from_kwargs(kwargs: MemoryMetadata | Dict[str, Any]) -> Tuple[str, str, str]:
        return (
            str(kwargs.get("org_id", "")),
            str(kwargs.get("user_id", "")),
            str(kwargs.get("caller_role_level", "")),
        )

    @staticmethod
    def _in_scope(meta: MemoryMetadata | Dict[str, Any], scope: Tuple[str, str, str]) -> bool:
        org, user, role = scope
        if org and str(meta.get("org_id", "")) != org:
            return False
        if user and str(meta.get("user_id", "")) != user:
            return False
        if role:
            try:
                return int(meta.get("role_level", 0)) <= int(role)
            except Exception:  # noqa
                return False
        return True

    @staticmethod
    def _filter_matches(meta: Dict[str, Any], filt: SearchFilter | Dict[str, Any] | None) -> bool:
        if not filt:
            return True
        if "$and" in filt:
            return all(CachingVectorProvider._filter_matches(meta, f) for f in filt.get("$and", []) if f)
        if "$or" in filt:
            return any(CachingVectorProvider._filter_matches(meta, f) for f in filt.get("$or", []) if f)
        if "$not" in filt:
            return not CachingVectorProvider._filter_matches(meta, filt.get("$not"))

        for key, expected in filt.items():
            if key in {"$and", "$or", "$not"}:
                continue
            actual = meta.get(key)
            if isinstance(expected, dict):
                for op, value in expected.items():
                    if op == "$in":
                        if str(actual) not in {str(v) for v in value}:
                            return False
                    elif op == "$eq":
                        if str(actual) != str(value):
                            return False
                    elif op == "$ne":
                        if str(actual) == str(value):
                            return False
                    elif op == "$contains":
                        if str(value) not in str(actual):
                            return False
                    elif op in ("$lt", "$lte", "$gt", "$gte"):
                        try:
                            a = float(actual) if actual is not None else float("inf")
                            v = float(value)
                            if op == "$lt" and not (a < v):
                                return False
                            elif op == "$lte" and not (a <= v):
                                return False
                            elif op == "$gt" and not (a > v):
                                return False
                            elif op == "$gte" and not (a >= v):
                                return False
                        except (TypeError, ValueError):
                            return False
                    else:
                        return False
            else:
                if str(actual) != str(expected):
                    return False
        return True

    def _stage_local(self, doc_id: str, doc: Document) -> None:
        if not self._local_enabled or self._local_cap <= 0:
            logger.debug("_stage_local: local shadow index disabled")
            return
        if self.emb is None:
            logger.debug("_stage_local: embeddings unavailable; skipping local shadow index")
            return  # no local embeddings available; skip the shadow index
        if self._local_max_chars and len(doc.page_content or "") > self._local_max_chars:
            logger.debug("_stage_local: skipped large doc (len=%s > max=%s)", len(doc.page_content or ""), self._local_max_chars)
            return
        try:
            vec = _np.array(self.emb.embed_query(doc.page_content), dtype=_np.float32)
        except Exception:  # noqa
            logger.warning("_stage_local: embedding failed; doc not staged locally", exc_info=True)
            return
        with self._lock:
            self._local.append(_LocalDoc(id=doc_id, emb=vec, doc=doc))
            # trim to cap
            if len(self._local) > self._local_cap:
                self._local = self._local[-self._local_cap:]
                self._rebuild_ann_index()
            else:
                self._ann_add(doc_id, vec)
        logger.debug(
            f"_stage_local: staged doc_id={doc_id!r}; local_size={len(self._local)}/{self._local_cap}"
        )

    def _local_search(
        self,
        query: str,
        k: int,
        scope: Tuple[str, str, str],
        filt: SearchFilter | Dict[str, Any] | None,
    ) -> List[Document]:
        if self.emb is None:
            logger.debug("_local_search: embeddings unavailable; returning empty")
            return []
        try:
            qv = _np.array(self.emb.embed_query(query), dtype=_np.float32)
        except Exception as e:  # noqa
            logger.warning(f"_local_search: query embedding failed: {e}", exc_info=True)
            return []
        with self._lock:
            if not self._local:
                logger.debug("_local_search: no local docs available")
                return []
            hits: List[Document] = []
            # Use ANN index when available
            if self._ann_enabled() and self._ann_index is not None and getattr(self._ann_index, "ntotal", 0) > 0:
                cand_n = max(10, int(k) * (10 if (filt or scope) else 3))
                cand_n = min(len(self._local), cand_n)
                qv_norm = self._norm_vec(qv).astype(_np.float32).reshape(1, -1)
                try:
                    _dists, idxs = self._ann_index.search(qv_norm, cand_n)
                    idx_list = [int(i) for i in idxs[0].tolist() if int(i) >= 0]
                except Exception:
                    idx_list = []
                for i in idx_list:
                    if i >= len(self._local):
                        continue
                    ld = self._local[i]
                    meta = ld.doc.metadata or {}
                    if self._in_scope(meta, scope) and self._filter_matches(meta, filt):
                        hits.append(ld.doc)
                    if len(hits) >= k:
                        break
                logger.debug(
                    f"_local_search: ann_candidates={len(idx_list)}, hits={len(hits)} for scope={scope}"
                )
                return hits

            # Fallback: linear cosine similarity
            mat = _np.stack([ld.emb for ld in self._local])
            denom = (_np.linalg.norm(mat, axis=1) * _np.linalg.norm(qv) + 1e-9)  # noqa
            sims = (mat @ qv) / denom
            idxs = _np.argsort(-sims)[: max(1, min(int(k), 10))]
            for i in idxs:
                ld = self._local[int(i)]
                meta = ld.doc.metadata or {}
                if self._in_scope(meta, scope) and self._filter_matches(meta, filt):
                    hits.append(ld.doc)
            logger.debug(
                f"_local_search: evaluated={len(self._local)}, candidate_idxs={len(idxs)}, hits={len(hits)} for scope={scope}"
            )
            return hits

    def _flush_docs(self, batch: List[Tuple[str, Document, str, bool, MemoryMetadata | Dict[str, Any]]]) -> None:
        adds = [b for b in batch if b and b[0] == "add"]
        if not adds:
            logger.debug("_flush_docs: nothing to flush")
            return
        docs = [b[1] for b in adds]
        ids = [b[2] for b in adds]
        allow_update = any(b[3] for b in adds)
        # Merge passthrough kwargs if consistent across the batch; otherwise drop conflicting keys
        merged_kwargs: Dict[str, Any] = {}
        if adds:
            key_candidates = set().union(*[set((b[4] or {}).keys()) for b in adds])
            for key in key_candidates:
                values = { (b[4] or {}).get(key) for b in adds }
                if len(values) == 1:
                    merged_kwargs[key] = values.pop()
                else:
                    logger.debug(f"_flush_docs: dropping conflicting kwarg '{key}' across batch")
        try:
            # Delegate to provider; base class filters kwargs appropriately
            if merged_kwargs:
                logger.debug(f"_flush_docs: forwarding kwargs to remote: {merged_kwargs}")
            self.remote.add_documents(docs, ids=ids, allow_update=allow_update, **merged_kwargs)
        except Exception as e:
            msg = str(e)
            # Gracefully ignore duplicate-id errors from stores like FAISS
            if isinstance(e, ValueError) and "already exist" in msg:
                logger.info(
                    f"_flush_docs: skipped {len(ids)} duplicate ids during remote add (existing ids)"
                )
            else:
                logger.error(
                    f"_flush_docs: remote add_documents failed for {len(ids)} docs (allow_update={allow_update}, kwargs_keys={list(merged_kwargs.keys())})",
                    exc_info=True,
                )
            # best-effort; keep the local cache warm and retry on the next wave
            pass
        else:
            logger.info(f"_flush_docs: flushed {len(ids)} docs to remote provider")
            # Persist FAISS index to disk if the store supports it
            try:
                store = self.remote.get_store()
                path = _get_faiss_index_path()
                if hasattr(store, "save_local") and path:
                    store.save_local(path)
                    logger.debug("_flush_docs: persisted FAISS index to %s", path)
            except Exception:  # noqa
                logger.debug("_flush_docs: FAISS persist skipped (not available)")

    # ----------------- advanced invalidation -----------------
    def _invalidate_for_new_doc(self, scope: Tuple[str, str, str], doc_role: int) -> int:
        """Invalidate cached queries that could include the new/updated doc.

        Strategy:
        - Match org_id and user_id exactly (empty string matches only empty).
        - Invalidate any cached entry with caller_role_level >= doc.role_level.
        """
        org, user, _ = scope

        def pred(key: Any) -> bool:
            if not isinstance(key, tuple) or len(key) < 5:
                return False
            k_org, k_user, k_role = str(key[0]), str(key[1]), int(str(key[2] or 0))
            if k_org != str(org):
                return False
            if k_user != str(user):
                return False
            return k_role >= int(doc_role)
        removed = self._qcache.invalidate_if(pred)
        logger.debug(
            f"cache invalidation: scope={scope}, doc_role={doc_role}, removed={removed}"
        )
        return removed

    # ----------------- ANN helpers -----------------
    def _ann_enabled(self) -> bool:
        return self._ann_backend == "faiss" and self._faiss is not None

    @staticmethod
    def _norm_vec(vec: _np.ndarray) -> _np.ndarray:
        denom = _np.linalg.norm(vec)
        if denom == 0:
            return vec
        return vec / denom

    def _ensure_ann_index(self, dim: int) -> None:
        if not self._ann_enabled():
            return
        if self._ann_index is None:
            self._ann_index = self._faiss.IndexFlatIP(int(dim))

    def _ann_add(self, doc_id: str, vec: _np.ndarray) -> None:
        if not self._ann_enabled():
            return
        self._ensure_ann_index(len(vec))
        if self._ann_index is None:
            return
        nvec = self._norm_vec(vec).astype(_np.float32).reshape(1, -1)
        self._ann_index.add(nvec)
        self._ann_ids.append(doc_id)

    def _rebuild_ann_index(self) -> None:
        if not self._ann_enabled():
            return
        if not self._local:
            self._ann_index = None
            self._ann_ids = []
            return
        dim = int(self._local[0].emb.shape[0])
        self._ann_index = self._faiss.IndexFlatIP(dim)
        self._ann_ids = []
        vecs = []
        for ld in self._local:
            self._ann_ids.append(ld.id)
            vecs.append(self._norm_vec(ld.emb).astype(_np.float32))
        mat = _np.stack(vecs) if vecs else _np.zeros((0, dim), dtype=_np.float32)
        if mat.size:
            self._ann_index.add(mat)


# -------------------------------------------------------------
# Caching KGraph (write-behind with durable outbox)
# -------------------------------------------------------------
class CachingKGraph:
    _INSTANCES: dict[int, "CachingKGraph"] = {}
    _LOCK = threading.Lock()

    def __new__(cls, remote, *, cache_dir: Optional[str] = None):  # type: ignore[override]
        key = id(remote)
        with cls._LOCK:
            inst = cls._INSTANCES.get(key)
            if inst is None:
                inst = super().__new__(cls)
                cls._INSTANCES[key] = inst
                setattr(inst, "_initialized", False)
        return inst
    def __init__(self, remote, *, cache_dir: Optional[str] = None) -> None:
        if getattr(self, "_initialized", False):
            return
        from agentfoundry.utils.exceptions import InitializationError

        self.remote = remote
        if hasattr(self.remote, 'conn'):
            try:
                self.remote.conn.execute("SELECT 1").fetchone()
            except Exception as exc:
                raise InitializationError(
                    "CachingKGraph",
                    f"Remote KGraph unreachable: {exc}",
                    cause=exc,
                ) from exc
        base = cache_dir or _get_cache_dir()
        self.cache_dir = os.path.join(base, "kg")
        os.makedirs(self.cache_dir, exist_ok=True)
        logger.info(
            f"CachingKGraph init: cache_dir={self.cache_dir}, remote_provider={type(remote).__name__}"
        )

        self._db = duckdb.connect(os.path.join(self.cache_dir, "outbox.duckdb"))
        self._db_lock = threading.Lock()
        self._max_flush_tries = int(os.getenv("AF_CACHE_MAX_TRIES", "10"))
        self._db.execute(
            """
            CREATE TABLE IF NOT EXISTS outbox (
                id BIGINT PRIMARY KEY,
                subject TEXT,
                predicate TEXT,
                object TEXT,
                meta TEXT,
                tries INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT now()
            )
            """
        )

        self._flusher = _FlushThread(
            name="KGFlush",
            fn_flush_batch=self._flush_ids,
            interval_s=float(os.getenv("AF_CACHE_FLUSH_S", "0.75")),
            batch_size=int(os.getenv("AF_CACHE_BATCH", "128")),
        )
        self._flusher.start()
        atexit.register(self._flusher.stop)
        # Optional contradiction checker — wired by callers who want detection.
        # Set to True to enable, or set to a ConflictPolicy value.
        self.contradiction_checker = None
        # Conflict policy: controls what happens when contradictions are found.
        # Imported lazily to avoid circular imports.
        self.conflict_policy = None  # Default: LOG_ONLY when checker is enabled
        # Optional contradiction log — wired by callers who want auditing.
        self.contradiction_log = None

        logger.info("CachingKGraph: background flusher started for KG outbox")
        self._initialized = True

    def upsert_fact(self, subject: str, predicate: str, obj: str, meta: MemoryMetadata | Dict[str, Any]):
        # Run contradiction check if a checker is wired (non-blocking, best-effort)
        if self.contradiction_checker is not None:
            try:
                from agentfoundry.agents.memory.contradictions import (
                    check_and_flag, resolve_contradiction,
                    ConflictPolicy, ConflictRejected,
                )
                contradictions = check_and_flag(
                    self.remote, subject, predicate, obj, meta or {}
                )
                if contradictions:
                    policy = self.conflict_policy or ConflictPolicy.LOG_ONLY
                    resolution = resolve_contradiction(
                        contradictions, policy,
                        metadata=meta if isinstance(meta, dict) else None,
                        kgraph=self.remote,
                    )
                    # Log to contradiction index if available
                    if self.contradiction_log is not None:
                        for c in contradictions:
                            try:
                                self.contradiction_log.record(
                                    subject=c.subject,
                                    predicate=c.predicate,
                                    existing_obj=c.existing_obj,
                                    new_obj=c.new_obj,
                                    existing_fact_id=c.fact_id,
                                    similarity=c.similarity,
                                    policy=policy.value,
                                    resolution=resolution.action_taken,
                                    org_id=(meta or {}).get("org_id", ""),
                                    user_id=(meta or {}).get("user_id", ""),
                                )
                            except Exception:
                                logger.debug("CachingKGraph: contradiction log write failed", exc_info=True)
                    if not resolution.proceed:
                        logger.info(
                            "CachingKGraph: write blocked by policy %s for (%s, %s)",
                            policy.value, subject, predicate,
                        )
                        return ""  # Return empty ID — write was blocked
            except Exception as exc:
                # ConflictRejected should propagate
                if exc.__class__.__name__ == "ConflictRejected":
                    raise
                logger.debug("CachingKGraph: contradiction check failed", exc_info=True)

        # Persist intent to durable outbox, then enqueue id for async flush
        rid = int(time.time() * 1e6)
        with self._db_lock:
            self._db.execute(
                "INSERT INTO outbox (id, subject, predicate, object, meta) VALUES (?,?,?,?,?)",
                [rid, subject, predicate, obj, json.dumps(meta)],
            )
        self._flusher.enqueue(rid)
        # return deterministic id so repeated calls are idempotent for clients
        h = hashlib.sha256()
        h.update(f"{subject}|{predicate}|{obj}|{json.dumps(meta, sort_keys=True)}".encode())
        fact_id = h.hexdigest()
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(
                f"upsert_fact: rid={rid}, subject={subject!r}, predicate={predicate!r}, object_len={len(obj)}, meta_keys={list((meta or {}).keys())}, fact_id={fact_id[:10]}"
            )
        return fact_id

    # optional helpers mirroring provider
    def search(self, q: str, *, user_id: str, org_id: str, k: int = 5):  # pragma: no cover
        return self.remote.search(q, user_id=user_id, org_id=org_id, k=k)

    def get_neighbours(self, *args, **kwargs):  # pragma: no cover
        return getattr(self.remote, "get_neighbours")(*args, **kwargs)

    def purge_expired(self, *args, **kwargs):  # pragma: no cover
        return getattr(self.remote, "purge_expired")(*args, **kwargs)

    # flusher
    def _flush_ids(self, ids: List[int]) -> None:
        if not ids:
            logger.debug("_flush_ids: nothing to flush")
            return
        uniq = sorted(set(ids))
        qmarks = ",".join(["?"] * len(uniq))
        with self._db_lock:
            rows = self._db.execute(
                f"SELECT id, subject, predicate, object, meta, tries FROM outbox WHERE id IN ({qmarks})",
                uniq,
            ).fetchall()
        logger.debug(f"_flush_ids: attempting to flush {len(rows)} rows from outbox")
        for rid, s, p, o, meta_json, tries in rows:
            try:
                self.remote.upsert_fact(s, p, o, json.loads(meta_json))
                with self._db_lock:
                    self._db.execute("DELETE FROM outbox WHERE id=?", [rid])
                logger.info(f"_flush_ids: flushed rid={rid}")
            except Exception as e:  # noqa
                new_tries = int(tries) + 1
                if new_tries >= self._max_flush_tries:
                    logger.error(
                        "_flush_ids: rid=%d exceeded max retries (%d), moving to dead letter",
                        rid, self._max_flush_tries,
                    )
                    with self._db_lock:
                        self._db.execute("DELETE FROM outbox WHERE id=?", [rid])
                else:
                    logger.warning(f"_flush_ids: failure for rid={rid} (try {new_tries}): {e}")
                    with self._db_lock:
                        self._db.execute("UPDATE outbox SET tries=? WHERE id=?", [new_tries, rid])
