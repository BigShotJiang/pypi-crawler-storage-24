"""Cache package for AgentFoundry."""
