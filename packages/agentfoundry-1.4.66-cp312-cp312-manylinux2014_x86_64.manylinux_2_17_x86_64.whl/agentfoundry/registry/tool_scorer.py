"""Adaptive tool relevance scoring for query-aware tool selection.

Scores each registered tool against a user query using keyword overlap,
domain affinity, and usage history. Returns a ranked, filtered tool list
so the architect sees only the most relevant tools.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

logger = logging.getLogger(__name__)

# ---- Stop words filtered from query tokenization --------------------------
_STOP_WORDS: Set[str] = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "about", "between",
    "through", "after", "before", "during", "and", "or", "but", "not",
    "if", "then", "so", "that", "this", "it", "i", "me", "my", "we",
    "you", "your", "he", "she", "they", "them", "what", "which", "who",
    "how", "when", "where", "why", "please", "help", "want", "need",
    "like", "just", "also", "some", "all", "any", "each", "every",
}

# ---- Domain keyword clusters for affinity scoring -------------------------
_DOMAIN_KEYWORDS: Dict[str, Set[str]] = {
    "memory": {
        "remember", "recall", "memory", "store", "save", "search",
        "forget", "context", "history", "past", "previous", "thread",
        "user", "preference", "profile", "fact", "knowledge",
    },
    "code": {
        "code", "python", "function", "class", "bug", "fix", "refactor",
        "test", "debug", "compile", "build", "lint", "analyze", "review",
        "commit", "git", "diff", "patch", "file", "module", "import",
        "error", "exception", "stack", "trace", "script", "run",
    },
    "data": {
        "data", "csv", "json", "database", "sql", "query", "table",
        "column", "row", "pandas", "dataframe", "excel", "schema",
        "aggregate", "filter", "sort", "group", "join", "sqlite",
    },
    "web": {
        "web", "http", "api", "rest", "url", "fetch", "request",
        "response", "endpoint", "scrape", "search", "google", "browse",
        "download", "upload", "webhook", "html", "page",
    },
    "file": {
        "file", "read", "write", "create", "delete", "move", "copy",
        "rename", "directory", "folder", "path", "zip", "unzip",
        "extract", "pdf", "document", "upload",
    },
    "devops": {
        "deploy", "release", "shell", "command", "terminal", "aws",
        "cloud", "container", "docker", "kubernetes", "ci", "cd",
        "pipeline", "infrastructure", "server", "ssh", "log",
    },
    "gitlab": {
        "gitlab", "merge", "request", "issue", "pipeline", "branch",
        "repository", "repo", "mr", "ci",
    },
}

# ---- Tool → domain mapping (inferred from tool name patterns) -------------
_TOOL_DOMAIN_HINTS: Dict[str, str] = {
    "save_thread_memory": "memory", "search_thread_memory": "memory",
    "delete_thread_memory": "memory", "save_user_memory": "memory",
    "search_user_memory": "memory", "delete_user_memory": "memory",
    "save_org_memory": "memory", "search_org_memory": "memory",
    "delete_org_memory": "memory", "save_global_memory": "memory",
    "search_global_memory": "memory", "delete_global_memory": "memory",
    "save_recall_memory": "memory", "search_recall_memories": "memory",
    "delete_recall_memory": "memory", "summarize_any_memory": "memory",
    "code_analysis": "code", "code_explorer": "code",
    "python_code_runner": "code", "python_file_writer": "code",
    "python_tool_creator": "code", "diff_patch": "code",
    "test_runner": "code", "git_operations": "code",
    "pandas_explorer": "data", "summarize_csv": "data",
    "sqlite_query": "data",
    "http_request_tool": "web", "rest_api_tool": "web",
    "web_search_tool": "web", "webpage_scraper": "web",
    "google_search_tool": "web",
    "file_operations": "file", "document_reader": "file",
    "pdf_creator": "file", "pdf_editor": "file", "pdf_file_creator": "file",
    "unzip_file": "file", "unzip_tool": "file",
    "shell_command": "devops", "awscli_executor": "devops",
    "system_introspection": "devops",
    "gitlab_read_api": "gitlab", "gitlab_issue_write_api": "gitlab",
    "gitlab_merge_request_api": "gitlab",
}

# Tools that should always be included regardless of relevance score
_MANDATORY_TOOLS: Set[str] = {
    "search_thread_memory", "search_user_memory",
}


def _tokenize(text: str) -> Set[str]:
    """Extract lowercase keyword tokens from text, filtering stop words.

    Splits on whitespace, punctuation, and underscores so that tool names
    like "search_user_memory" produce {"search", "user", "memory"}.
    """
    # Split on non-alphanumeric characters (including underscores)
    raw = re.findall(r"[a-z][a-z0-9]*", text.lower())
    return set(raw) - _STOP_WORDS


def _infer_domain(tool_name: str) -> str:
    """Infer a tool's domain from name hints or name tokens."""
    if tool_name in _TOOL_DOMAIN_HINTS:
        return _TOOL_DOMAIN_HINTS[tool_name]
    name_tokens = set(tool_name.lower().replace("_", " ").split())
    best_domain = "general"
    best_overlap = 0
    for domain, keywords in _DOMAIN_KEYWORDS.items():
        overlap = len(name_tokens & keywords)
        if overlap > best_overlap:
            best_overlap = overlap
            best_domain = domain
    return best_domain


def _detect_query_domains(query_tokens: Set[str]) -> Set[str]:
    """Detect which domains the query is related to."""
    domains: Set[str] = set()
    for domain, keywords in _DOMAIN_KEYWORDS.items():
        if query_tokens & keywords:
            domains.add(domain)
    return domains


@dataclass
class ToolScore:
    """Relevance score breakdown for a single tool."""
    name: str
    total: float
    keyword_score: float = 0.0
    domain_score: float = 0.0
    usage_score: float = 0.0
    mandatory: bool = False


def score_tools(
    query: str,
    tools: Sequence[Any],
    tracker: Optional[Any] = None,
    keyword_weight: float = 0.5,
    domain_weight: float = 0.3,
    usage_weight: float = 0.2,
) -> List[ToolScore]:
    """Score each tool's relevance to the given query.

    Args:
        query: The user's task description.
        tools: List of tool objects with `name` and `description` attributes.
        tracker: Optional ToolUsageTracker for historical signal.
        keyword_weight: Weight for keyword overlap score.
        domain_weight: Weight for domain affinity score.
        usage_weight: Weight for usage history score.

    Returns:
        List of ToolScore sorted by total descending.
    """
    query_tokens = _tokenize(query)
    query_domains = _detect_query_domains(query_tokens)

    scores: List[ToolScore] = []

    for tool in tools:
        name = getattr(tool, "name", str(tool))
        desc = getattr(tool, "description", "") or ""

        # 1. Keyword overlap
        tool_tokens = _tokenize(f"{name} {desc}")
        overlap = len(query_tokens & tool_tokens)
        max_possible = max(len(query_tokens), 1)
        keyword_score = min(overlap / max_possible, 1.0)

        # 2. Domain affinity
        tool_domain = _infer_domain(name)
        if query_domains and tool_domain in query_domains:
            domain_score = 1.0
        elif tool_domain == "general":
            domain_score = 0.3  # general tools get a mild base score
        else:
            domain_score = 0.0

        # 3. Usage history
        usage_score = 0.0
        if tracker is not None:
            sr = tracker.success_rate(name)
            if sr is not None:
                usage_score = sr  # 0.0 to 1.0

        total = (
            keyword_weight * keyword_score
            + domain_weight * domain_score
            + usage_weight * usage_score
        )

        is_mandatory = name in _MANDATORY_TOOLS
        if is_mandatory:
            total = max(total, 1.0)  # mandatory tools always rank at top

        scores.append(ToolScore(
            name=name,
            total=total,
            keyword_score=keyword_score,
            domain_score=domain_score,
            usage_score=usage_score,
            mandatory=is_mandatory,
        ))

    scores.sort(key=lambda s: s.total, reverse=True)
    return scores


def select_tools(
    query: str,
    tools: Sequence[Any],
    tracker: Optional[Any] = None,
    max_tools: int = 20,
    min_score: float = 0.05,
) -> List[Any]:
    """Select the most relevant tools for a query.

    Args:
        query: The user's task description.
        tools: Full list of available tool objects.
        tracker: Optional ToolUsageTracker.
        max_tools: Maximum number of tools to return.
        min_score: Minimum relevance score to include.

    Returns:
        Filtered and ranked list of tool objects.
    """
    if not tools or not query:
        return list(tools)

    scores = score_tools(query, tools, tracker=tracker)

    # Build name→tool lookup
    tool_map = {getattr(t, "name", str(t)): t for t in tools}

    selected: List[Any] = []
    selected_names: Set[str] = set()

    for ts in scores:
        if len(selected) >= max_tools and not ts.mandatory:
            break
        if ts.total < min_score and not ts.mandatory:
            continue
        tool = tool_map.get(ts.name)
        if tool and ts.name not in selected_names:
            selected.append(tool)
            selected_names.add(ts.name)

    logger.info(
        "select_tools: query_len=%d total=%d selected=%d max=%d",
        len(query), len(tools), len(selected), max_tools,
    )

    return selected
