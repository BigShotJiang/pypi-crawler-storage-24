import asyncio
import logging
from typing import List, Dict, Any, Optional

from langchain_core.tools import Tool, StructuredTool
from pydantic import BaseModel, create_model, Field

try:
    from mcp.client.stdio import stdio_client, StdioServerParameters
    from mcp.client.session import ClientSession
    HAS_MCP = True
except ImportError:
    HAS_MCP = False
    stdio_client = None
    StdioServerParameters = Any
    ClientSession = Any

logger = logging.getLogger(__name__)

def _schema_to_pydantic_model(name: str, schema: dict) -> type[BaseModel]:
    fields = {}
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    for key, val in properties.items():
        t = Any
        val_type = val.get("type")
        if val_type == "string": t = str
        elif val_type == "integer": t = int
        elif val_type == "number": t = float
        elif val_type == "boolean": t = bool
        elif val_type == "array": t = list
        elif val_type == "object": t = dict
        
        default = ... if key in required else None
        fields[key] = (t, Field(default=default, description=val.get("description", "")))
        
    return create_model(name, **fields)

class MCPToolAdapter:
    """Adapts an MCP server's tools into LangChain tools."""

    def __init__(self, server_name: str, server_params: StdioServerParameters = None):
        self.server_name = server_name
        self.server_params = server_params
        self._tools: List[Tool] = []
        self._session: Optional[ClientSession] = None
        self._stdio_context = None
        
        if not HAS_MCP:
            raise RuntimeError("mcp package is required. Run 'pip install mcp'")

    async def connect(self):
        """Connects to the MCP server and fetches available tools."""
        if self.server_params:
            self._stdio_context = stdio_client(self.server_params)
            read_stream, write_stream = await self._stdio_context.__aenter__()
        else:
            raise ValueError("Must provide server_params")
            
        self._session = ClientSession(read_stream, write_stream)
        await self._session.__aenter__()
        await self._session.initialize()

    async def fetch_tools(self) -> List[Tool]:
        if not self._session:
            await self.connect()

        mcp_tools_response = await self._session.list_tools()
        tools = []
        
        for mcp_tool in mcp_tools_response.tools:
            tool = self._create_langchain_tool(mcp_tool)
            tools.append(tool)
            
        self._tools = tools
        return tools

    def _create_langchain_tool(self, mcp_tool: Any) -> StructuredTool:
        """Create a LangChain StructuredTool from an MCP Tool."""
        tool_name = f"{self.server_name}_{mcp_tool.name}"
        
        args_schema = _schema_to_pydantic_model(f"{tool_name}_schema", mcp_tool.inputSchema)
        
        async def _run_mcp_tool(**kwargs) -> str:
            if not self._session:
                await self.connect()
            try:
                result = await self._session.call_tool(mcp_tool.name, arguments=kwargs)
                # Content is typically a list of text/image blocks.
                text_content = []
                if result.content:
                    for block in result.content:
                        if getattr(block, "type", "") == "text":
                            text_content.append(block.text)
                        elif isinstance(block, dict) and block.get("type") == "text":
                            text_content.append(block.get("text", ""))
                        else:
                            text_content.append(str(block))
                return "\n".join(text_content)
            except Exception as e:
                logger.error(f"Error calling MCP tool {tool_name}: {e}")
                return f"Error: {e}"

        def _run_mcp_tool_sync(**kwargs) -> str:
            import asyncio
            import threading
            
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
            if loop.is_running():
                result = [None]
                error = [None]
                
                def _thread_run():
                    new_loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(new_loop)
                    try:
                        result[0] = new_loop.run_until_complete(_run_mcp_tool(**kwargs))
                    except Exception as e:
                        error[0] = e
                    finally:
                        new_loop.close()
                
                t = threading.Thread(target=_thread_run)
                t.start()
                t.join()
                
                if error[0]:
                    return f"Error: {error[0]}"
                return result[0]
            else:
                return loop.run_until_complete(_run_mcp_tool(**kwargs))

        return StructuredTool(
            name=tool_name,
            description=mcp_tool.description or "No description provided",
            func=_run_mcp_tool_sync,
            coroutine=_run_mcp_tool,
            args_schema=args_schema
        )

    async def close(self):
        """Closes the MCP connection."""
        if self._session:
            await self._session.__aexit__(None, None, None)
            self._session = None
        if self._stdio_context:
            await self._stdio_context.__aexit__(None, None, None)
            self._stdio_context = None
