"""Tool usage tracking for adaptive tool selection.

Records tool invocation outcomes (success/failure) in a fixed-size ring
buffer. Provides rolling success rates and co-occurrence data to inform
the ToolRelevanceScorer.

No persistence — the tracker resets on process restart, which is
intentional: usage patterns should reflect the current session, not
stale history.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


@dataclass
class ToolInvocation:
    """A single tool invocation record."""
    tool_name: str
    success: bool
    timestamp: float = field(default_factory=time.time)
    task_id: str = ""
    cooccurring_tools: tuple = ()  # other tools used in same task


class ToolUsageTracker:
    """In-memory tracker for tool invocation outcomes.

    Thread-safe. Uses a fixed-size ring buffer per tool to bound memory.
    """

    def __init__(self, max_per_tool: int = 100) -> None:
        self._max = max_per_tool
        self._history: Dict[str, Deque[ToolInvocation]] = defaultdict(
            lambda: deque(maxlen=max_per_tool)
        )
        # Task → set of tool names used together
        self._task_tools: Dict[str, Set[str]] = defaultdict(set)
        self._lock = threading.Lock()

    def record(
        self,
        tool_name: str,
        success: bool,
        task_id: str = "",
        cooccurring_tools: Optional[List[str]] = None,
    ) -> None:
        """Record a tool invocation outcome.

        Args:
            tool_name: Name of the tool invoked.
            success: Whether the invocation succeeded.
            task_id: Optional task ID for co-occurrence tracking.
            cooccurring_tools: Other tools used in the same task.
        """
        inv = ToolInvocation(
            tool_name=tool_name,
            success=success,
            task_id=task_id,
            cooccurring_tools=tuple(cooccurring_tools or []),
        )
        with self._lock:
            self._history[tool_name].append(inv)
            if task_id:
                self._task_tools[task_id].add(tool_name)

    def success_rate(self, tool_name: str) -> Optional[float]:
        """Rolling success rate for a tool, or None if never used.

        Returns a float in [0.0, 1.0].
        """
        with self._lock:
            history = self._history.get(tool_name)
            if not history:
                return None
            successes = sum(1 for inv in history if inv.success)
            return successes / len(history)

    def invocation_count(self, tool_name: str) -> int:
        """Number of recorded invocations for a tool."""
        with self._lock:
            history = self._history.get(tool_name)
            return len(history) if history else 0

    def cooccurrence(self, tool_name: str) -> List[str]:
        """Tools that frequently co-occur with the given tool.

        Returns tool names sorted by co-occurrence frequency descending.
        """
        with self._lock:
            counts: Dict[str, int] = defaultdict(int)
            for inv in self._history.get(tool_name, []):
                for co in inv.cooccurring_tools:
                    if co != tool_name:
                        counts[co] += 1
            # Also check task-level co-occurrence
            for task_id, tools in self._task_tools.items():
                if tool_name in tools:
                    for co in tools:
                        if co != tool_name:
                            counts[co] += 1

        if not counts:
            return []
        return sorted(counts.keys(), key=lambda k: counts[k], reverse=True)

    def recently_successful(self, window_s: float = 300.0) -> List[str]:
        """Tools that succeeded within the last `window_s` seconds.

        Useful for recency-boosting in the scorer.
        """
        cutoff = time.time() - window_s
        result: List[str] = []
        with self._lock:
            for tool_name, history in self._history.items():
                for inv in reversed(history):
                    if inv.timestamp < cutoff:
                        break
                    if inv.success:
                        result.append(tool_name)
                        break
        return result

    def summary(self) -> Dict[str, Dict[str, object]]:
        """Return a summary of all tracked tools."""
        with self._lock:
            return {
                name: {
                    "count": len(history),
                    "success_rate": (
                        sum(1 for i in history if i.success) / len(history)
                        if history else 0.0
                    ),
                }
                for name, history in self._history.items()
            }

    def clear(self) -> None:
        """Reset all tracking data."""
        with self._lock:
            self._history.clear()
            self._task_tools.clear()
