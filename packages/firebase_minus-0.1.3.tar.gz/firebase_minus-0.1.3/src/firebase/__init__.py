import urllib.request, requests
import json
import ssl
import threading
import time, json
from google.oauth2 import service_account
import google.auth.transport.requests


class FireBase:
    def __init__(self, url, secret_keyDB, conf):
        self.base_url = url
        self.secret_key = secret_keyDB
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.running = False
        self.conf = conf
        with open(conf, "r") as f:
            self.project_id = json.load(f)["project_id"]

    def _get_access_token(self):
            self.credentials = service_account.Credentials.from_service_account_file(
                self.conf,
                scopes=['https://www.googleapis.com/auth/firebase.messaging']
                )
            
            auth_request = google.auth.transport.requests.Request()
            self.credentials.refresh(auth_request)
            
            return self.credentials.token
        
    def listen(self, path, callback):
        """Запускает прослушивание изменений"""
        self.running = True
        thread = threading.Thread(target=self._listen_thread, args=(path, callback))
        thread.daemon = True
        thread.start()
        return thread
    
    def _listen_thread(self, path, callback):
        """Поток для long polling"""
        url = f"{self.base_url}/{path}.json?auth={self.secret_key}"
        last_data = None
        
        while self.running:
            try:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, context=self.ssl_context) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    
                    # Если данные изменились
                    if data != last_data:
                        callback(data)
                        last_data = data
                    
                    # Небольшая задержка между запросами
                    time.sleep(1)
                    
            except Exception as e:
                print(f"Ошибка прослушивания: {e}")
                time.sleep(5)  # Пауза перед повторной попыткой

    def _firebase_request(self, method, path, data=None):
        """Универсальная функция для работы с Firebase"""
        url = f"{self.base_url}/{path}.json?auth={self.secret_key}"
    
    # Создаем запрос
        req = urllib.request.Request(url, method=method)
    
    # Добавляем заголовки - важно указать UTF-8
        req.add_header('Content-Type', 'application/json; charset=utf-8')
    
    # Если есть данные для отправки
        if data:
            # Явно указываем ensure_ascii=False для сохранения русских букв
            json_str = json.dumps(data, ensure_ascii=False)
            data_bytes = json_str.encode('utf-8')
            req.data = data_bytes
    
        try:
        # Отправляем запрос
            with urllib.request.urlopen(req, context=self.ssl_context) as response:
                response_data = response.read().decode('utf-8')
                return json.loads(response_data) if response_data else None
        except urllib.error.HTTPError as e:
            return None
        except Exception as e:
            return None

    def delete_data(self, path):
        """Удаление данных"""
        return self.firebase_request('DELETE', path)
    
    def write_data(self, path, data):
        """Запись данных (полная замена)"""
        return self.firebase_request('PUT', path, data)
    
    def stop(self):
        self.running = False
    
    def send_push(self, device_token, title, message):
        """Максимально простая функция отправки"""
    
        access_token = self._get_access_token()
        if not access_token:
            return False
        

        
        url = f"https://fcm.googleapis.com/v1/projects/{self.project_id}/messages:send"
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {access_token}',
        }
        
        payload = {
            "message": {
                "token": device_token,
                "notification": {
                    "title": title,
                    "body": message
                },
                "android": {
                    "priority": "high"
                }
            }
        }

        response = requests.post(url, headers=headers, json=payload, timeout=30)
        if response.status_code == 200:
                return True
        else:
                return False
                

# Использование real-time

# Запуск