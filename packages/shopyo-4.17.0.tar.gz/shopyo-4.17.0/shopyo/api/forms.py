from flask import flash

from shopyo.api.html import notify_warning


def flash_errors(form):
    """
    Auto flash errors from WKHtml forms
    Reqwires base module or similar notification
    mechanism

    Parameters
    ----------
    form: WKHtml form

    Returns
    -------
    None
    """
    for field, errors in form.errors.items():
        for error in errors:
            error_msg = "Error in the {} field - {}".format(
                getattr(form, field).label.text,
                error,
            )
            flash(notify_warning(error_msg))
