import numpy as np
from .base import BaseLocalPlanner


class APF(BaseLocalPlanner):
    def __init__(self, map_data, start, end, k_attr=5.0, k_rep=100.0, rep_range=3.0, step_size=0.5, max_iter=1000):
        super().__init__(map_data, start, end, name='APF')
        self.k_attr = k_attr            # 吸引力系数
        self.k_rep = k_rep              # 斥力系数
        self.rep_range = rep_range      # 斥力有效距离
        self.step_size = step_size      # 每步移动长度
        self.max_iter = max_iter

        self.trajectory = [self.start.copy()]
        self.rows, self.cols = self.map_size
        self.obstacles = np.array(np.transpose(np.where(self.map_data == 1))).astype(float)

    def calc_attractive_force(self, pos):
        return self.k_attr * (self.end - pos)

    def calc_repulsive_force(self, pos):
        force = np.zeros(2)
        for obs in self.obstacles:
            diff = pos - obs
            dist = np.linalg.norm(diff)
            if dist <= 0.1:
                dist = 0.1  # 防止除0
            if dist <= self.rep_range:
                rep = self.k_rep * (1.0 / dist - 1.0 / self.rep_range) / (dist ** 3) * diff
                force += rep
        return force

    def run(self):
        pos = self.start.copy()
        for i in range(self.max_iter):
            attr = self.calc_attractive_force(pos)
            rep = self.calc_repulsive_force(pos)
            total_force = attr + rep

            if np.linalg.norm(total_force) < 1e-3:
                # 陷入局部极小值，尝试随机扰动
                total_force += np.random.uniform(-1, 1, size=2) * 0.5

            direction = total_force / np.linalg.norm(total_force)
            next_pos = pos + self.step_size * direction

            if self.is_collision(next_pos):
                print("Path blocked by obstacle.")
                break

            self.trajectory.append(next_pos.copy())
            pos = next_pos

            if np.linalg.norm(pos - self.end) < self.step_size:
                print("Goal reached.")
                self.trajectory.append(self.end.copy())
                self.trajectory_len = self.calc_total_length(self.trajectory)
                break
        return self.trajectory

    def is_collision(self, pos):
        x, y = int(round(pos[0])), int(round(pos[1]))
        if 0 <= x < self.rows and 0 <= y < self.cols:
            return self.map_data[x, y] == 1
        return True  # 越界也当作障碍物




