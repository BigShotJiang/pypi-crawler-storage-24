import numpy as np
from math import sqrt, pi, cos, sin
from .base import BaseLocalPlanner

class RobotState:
    def __init__(self, x=0.0, y=0.0, yaw=0.0, v=0.0, omega=0.0):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v
        self.omega = omega

    def update(self, v, omega, dt):
        self.x += v * cos(self.yaw) * dt
        self.y += v * sin(self.yaw) * dt
        self.yaw += omega * dt
        self.v = v
        self.omega = omega

    def to_array(self):
        return np.array([self.x, self.y])


class Config:
    """
    Configuration parameters for the Dynamic Window Approach (DWA) local planner.

    Attributes:
        max_speed (float): Maximum forward speed of the robot (m/s).
        min_speed (float): Minimum speed of the robot (m/s), can be negative for reverse motion.
        max_yaw_rate (float): Maximum yaw rate (rad/s).
        max_accel (float): Maximum acceleration (m/s^2).
        max_delta_yaw (float): Maximum change in yaw per time step (rad/s).
        v_reso (float): Resolution of speed sampling (m/s).
        yaw_rate_reso (float): Resolution of yaw rate sampling (rad/s).
        dt (float): Time interval for trajectory prediction (s).
        predict_time (float): Prediction horizon for trajectory generation (s).
        to_goal_cost_gain (float): Weight for the cost of heading towards the goal.
        speed_cost_gain (float): Weight for the cost of robot speed.
        obstacle_cost_gain (float): Weight for the cost of obstacle avoidance.
        robot_radius (float): Radius of the robot (m) for collision checking.
    """
    def __init__(self):
        self.max_speed = 1.0
        self.min_speed = -0.2
        self.max_yaw_rate = 45.0 * pi / 180.0
        self.max_accel = 0.5
        self.max_delta_yaw = 60.0 * pi / 180.0
        self.v_reso = 0.1
        self.yaw_rate_reso = 5.0 * pi / 180.0
        self.dt = 0.1
        self.predict_time = 3.0
        self.to_goal_cost_gain = 1.0
        self.speed_cost_gain = 0.1
        self.obstacle_cost_gain = 0.8
        self.robot_radius = 0.5


class ObstacleMap:
    def __init__(self, grid):
        self.grid = grid
        self.ox, self.oy = np.where(self.grid == 1)
        self.obstacles = np.vstack((self.ox, self.oy)).T

    def is_collision(self, x, y, robot_radius):
        for ox, oy in self.obstacles:
            d = sqrt((ox - x) ** 2 + (oy - y) ** 2)
            if d <= robot_radius:
                return True
        return False


class DWA(BaseLocalPlanner):
    def __init__(self, map_data: np.ndarray, start=None, end=None, config=None):
        super().__init__(map_data, start, end)
        self.config = Config() if config is None else config
        self.obmap = ObstacleMap(self.map_data)
        init_yaw = np.arctan2(end[1] - start[1], end[0] - start[0])
        self.state = RobotState(start[0], start[1], init_yaw)
        self.best_way_data = [[self.state.x, self.state.y]]
        self.best_way_len = 0.0

    def run(self, max_iter=2000):
        for _ in range(max_iter):
            u, predicted_traj = self.dwa_control()
            self.state.update(u[0], u[1], self.config.dt)

            last_point = self.best_way_data[-1]
            current_point = [self.state.x, self.state.y]
            segment_len = sqrt((current_point[0] - last_point[0]) ** 2 + (current_point[1] - last_point[1]) ** 2)
            self.best_way_len += segment_len
            self.best_way_data.append(current_point)

            if sqrt((self.state.x - self.end[0]) ** 2 + (self.state.y - self.end[1]) ** 2) <= self.config.robot_radius:
                break
        else:
            print("DWA: Reached maximum iterations without finding a path to the goal.")

    def dwa_control(self):
        best_u = [0.0, 0.0]
        min_cost = float("inf")
        best_traj = []
        v_range = np.arange(self.config.min_speed, self.config.max_speed, self.config.v_reso)
        yaw_range = np.arange(-self.config.max_yaw_rate, self.config.max_yaw_rate, self.config.yaw_rate_reso)

        for v in v_range:
            for omega in yaw_range:
                traj = self.calc_trajectory(v, omega)
                to_goal_cost = self.config.to_goal_cost_gain * self.calc_to_goal_cost(traj)
                speed_cost = self.config.speed_cost_gain * (self.config.max_speed - v)
                ob_cost = self.config.obstacle_cost_gain * self.calc_obstacle_cost(traj)
                final_cost = to_goal_cost + speed_cost + ob_cost
                if final_cost < min_cost:
                    min_cost = final_cost
                    best_u = [v, omega]
                    best_traj = traj
        return best_u, best_traj

    def calc_trajectory(self, v, omega):
        traj = [[self.state.x, self.state.y]]
        time = 0.0
        new_state = RobotState(self.state.x, self.state.y, self.state.yaw, self.state.v, self.state.omega)
        while time <= self.config.predict_time:
            new_state.update(v, omega, self.config.dt)
            traj.append([new_state.x, new_state.y])
            time += self.config.dt
        return traj

    def calc_obstacle_cost(self, traj):
        min_dist = float("inf")
        for x, y in traj:
            for ox, oy in self.obmap.obstacles:
                dist = sqrt((ox - x) ** 2 + (oy - y) ** 2)
                if dist < min_dist:
                    min_dist = dist
                if dist <= self.config.robot_radius:
                    return float("inf")
        return 1.0 / min_dist

    def calc_to_goal_cost(self, traj):
        dx = self.end[0] - traj[-1][0]
        dy = self.end[1] - traj[-1][1]
        distance = sqrt(dx ** 2 + dy ** 2)
        heading = np.arctan2(dy, dx)
        traj_yaw = np.arctan2(traj[-1][1] - traj[0][1], traj[-1][0] - traj[0][0])
        angle_diff = abs(heading - traj_yaw)
        return distance + angle_diff * 0.5



