from abc import ABC, abstractmethod
import numpy as np
from lddya.core.base import BasePlanningProblem

class BaseLocalPlanner(BasePlanningProblem):
    """
    局部规划算法基类（非RL范式）

    特点：
    - 一键运行
    - 输入完整问题描述
    - 输出局部轨迹
    """

    def __init__(self, map_data, start=None, end=None):
        super().__init__(map_data, start, end)

        self.trajectory = []
        self.trajectory_len = np.inf

    @abstractmethod
    def run(self):
        """
        执行局部规划，生成一段可执行轨迹，并存入类属性 self.trajectory
        """
        raise NotImplementedError
    
    def calc_total_length(self, way):
        """
            计算路径总长度，使用numpy矢量化计算
            Params:
                way: 路径点列表，形如 [(y1,x1),(y2,x2),...]
            Returns:
                total_length: 路径总长度（float）
        """
        way = np.asarray(way)
        diffs = way[1:] - way[:-1]          # 相邻点差分
        step_lengths = np.linalg.norm(diffs, axis=1)
        return step_lengths.sum()
