from abc import ABC, abstractmethod
import numpy as np
from lddya.core.base import BasePlanningProblem


class BaseTraditionalPlanner(BasePlanningProblem, ABC):
    """
    传统全局规划算法：
    - A*
    - Dijkstra
    - Dynamic Programming
    """

    def __init__(self, map_data, start=None, end=None):
        super().__init__(map_data, start, end)

        self.best_way_data = []
        self.best_way_len = np.inf
        

    @abstractmethod
    def run(self):
        """
        执行规划
        """
        raise NotImplementedError
