from lddya.algorithms.globals.traditional.base import BaseTraditionalPlanner
import numpy as np
import heapq


class AStar(BaseTraditionalPlanner):
    def __init__(self, map_data, start=None, end=None):
        super().__init__(map_data,start,end)
        self.start = tuple(self.start)
        self.end = tuple(self.end)
        self.distance_matrix = np.array([1, 1, 1, 1, 2**0.5, 2**0.5, 2**0.5, 2**0.5])
        self.directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]
    def heuristic(self, a, b):
        return np.linalg.norm(np.array(a)-b)

    def run(self):
        open_set = []
        heapq.heappush(open_set, (0, self.start))
        came_from = {}
        g_score = {self.start: 0}
        f_score = {self.start: self.heuristic(self.start, self.end)}

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == self.end:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(self.start)
                path.reverse()
                self.best_way_len = g_score[self.end]
                self.best_way_data = path
                return path, g_score[self.end]

            for index, direction in enumerate(self.directions):
                neighbor = (current[0] + direction[0], current[1] + direction[1])
                if 0 <= neighbor[0] < self.map_size and 0 <= neighbor[1] < self.map_size and self.map_data[neighbor[0]][neighbor[1]] == 0:
                    tentative_g_score = g_score[current] + self.distance_matrix[index]
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, self.end)
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        return None, None
