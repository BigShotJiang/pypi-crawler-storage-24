
import numpy as np


class Env():
    def __init__(self,map_data,start_pos,end_pos) -> None:
        '''
            Function:
            ----------
            根据地图数据以及问题的起点终点信息，生成相匹配的环境类。

            Params:
            -------
            start_pos : 1*2-np.array --> 问题的起点位置(y,x)
            end_pos   : 1*2-np.array --> 问题的终点位置(y,x)

            Return:
            -------
            class Env
        '''
        self.map_data_backup = map_data              # 保留地图信息的原件
        self.map_data = self.map_data_backup.copy()  # 用以进行路径规划任务的地图信息的复制件。(为记录路径痕迹这一功能进行服务)
        self.map_size = self.map_data.shape[0]       # 地图尺寸
        self.start_pos = start_pos.copy()            # 起点    
        self.end_pos = end_pos.copy()                # 终点
        


    def actResponse(self,now_pos,action): 
        '''
            Function:
            ----------
            根据当前位置以及行动指令，返回新位置以及状态码。

            Params:
            -------
            now_pos : 1*2-list --> 当前位置(y,x)
            action : int --> 行动指令,“上”(y++)对应“0”，顺时针递增到7

            Return:
            -------
            status : int ---> 0为正常移动，1为碰撞，2为成功找到终点。(放弃该值，因为该值特征在reward中可以得到体现)
            new_pos : 1*2-list  --> 移动后的位置，当且仅当state=0时，有值返回(需要被接收后处理)
            reward : int --> 每一步行动所获得的回报
        '''
        pos_change_mat = np.array([  # 位置更新矩阵
            [1,0],
            [1,1],
            [0,1],
            [-1,1],
            [-1,0],
            [-1,-1],
            [0,-1],
            [1,-1]
        ])
        new_pos = now_pos + pos_change_mat[action]
        is_out_of_bounds = np.any((new_pos < 0) | (new_pos > (self.map_size-1)))   # 这里特地保留越界状态，防止后面有用，否则，clip直接裁剪就行。
        if is_out_of_bounds:
            status = 1          #越界视为碰撞障碍物
        else:
            if self.map_data[new_pos[0],new_pos[1]] == 1:
                status = 1     # 碰撞障碍物
            elif self.map_data[new_pos[0],new_pos[1]] == 2:
                status = 2
            elif self.map_data[new_pos[0],new_pos[1]] == 3:
                status = 3     # 走过重复的路径节点，高惩罚
            else:
                status = 0     # 正常移动
                self.map_data[new_pos[0],new_pos[1]] = 3  # 标记走过的路径
        reward_list = [0,-1,1,0]  #  第0位为正常移动，第1位为碰撞，第2位为成功找到终点  
        return new_pos,reward_list[status]
    
    def resetMapData(self):
        '''
            Function:
            ----------
            重置self.map_data数据。即清除所记录的路径痕迹。

            Params:
            -------
            None

            Return:
            -------
            None
        '''
        self.map_data = self.map_data_backup.copy()
        self.map_data[self.start_pos[0],self.start_pos[1]] = 3   # 起点位置设为经过状态
        self.map_data[self.end_pos[0],self.end_pos[1]] = 2       # 终点位置标记一下
        
        

        

class Q_Learning():
    def __init__(self,map_data,alpha= 0.1,epsilon = 0.5,max_iter = 3000,start = None,end = None,max_move_num = 500,name ='ql') -> None:
        #参数承接
        self.name = name
        self.success_count = 0            #成功找到终点的次数
        self.map_data = map_data          # 地图数据
        self.map_size = map_data.shape[0] # 地图尺寸
        self.alpha = alpha                #
        self.epsilon = epsilon            # epasilon-greedy 策略要用
        self.epsilon_min = 0.05           # 预防算法绝对贪婪
        self.max_iter = max_iter          #最大迭代次数
        self.max_move_num = max_move_num  #寻路时最大的路径长度
        #起点终点
        self.start_pos = np.array(start) if start is not None else np.array([0,0])                        #起点
        self.end_pos = np.array(end) if end is not None else np.array([self.map_size-1,self.map_size-1,]) #终点
        #马尔科夫决策链五要素
        self.action_space = np.array([0,1,2,3,4,5,6,7]) #动作空间 ，'0'对应'上'，顺时针递增
        self.Q_table = np.zeros([self.map_size,self.map_size,len(self.action_space)])  #3维Q表,索引格式[y,x,act_index]
        self.Q_table[end[0],end[1]] = 0
        self.sigma_zhi = 0.9             #折扣因子(直线方向)
        self.sigma_xie = 0.85            #折扣因子(斜线方向)
        self.generation_way_len = []     #每轮路径长度
        self.generation_reward = []      #每轮累计回报值
        self.generation_step = []        #每轮行动次数
        self.generation_esp = []         #每轮eps
        self.generation_path_length = [] #每轮路径长度
        self.best_way_iteration = 0      #最优路径最小迭代次数
        self.best_way_data = []          #最优路径
        self.best_way_len = 9999         #最优路径长度
        # 生成环境
        self.env = Env(map_data=map_data,start_pos=start,end_pos=end)

    def finallyLookingForThePath(self):
        '''
        Function
        --------
        根据当前的Q值表，用贪婪策略测试，看看能否找到终点，若找到，则保存在way_data_best中，否则，抛出异常。
        '''
        now_pos = self.start_pos.copy()
        self.best_way_data.append(now_pos.copy())
        result = True
        self.env.resetMapData()
        while True:
            A =  self.Q_table[now_pos[0],now_pos[1]]
            act = self.Q_table[now_pos[0],now_pos[1]].argmax()
            new_pos,r = self.env.actResponse(now_pos=now_pos,action=act)
            now_pos = new_pos
            self.best_way_data.append(now_pos.copy())
            if r == -1:
                raise Exception('无法找到终点！')
            elif r == 1:
                self.best_way_len = self.calcWayLength(self.best_way_data)
                break
                
    def greedy(self,now_pos):
        '''
            Function
            --------
            根据当前的状态s，通过greedy策略返回一个行动(编码形式0、1、2...)

            Params
            ------
            now_pos : 1*2-np.array --> 某个状态

            Return
            -------
            act  : int --> 行动的编号
        '''
        act = self.Q_table[now_pos[0],now_pos[1]].argmax()
        return act

    def e_greedy(self,now_pos):
        '''
            Function
            --------
            根据当前的状态s，通过e-greedy策略返回一个行动(编码形式0、1、2...)

            Params
            ------
            s   : 1*2-np.array --> 某个状态

            Return
            -------
            a   : int --> 行动的编号
        '''
        
        pos_change_mat = np.array([  # 位置更新矩阵
            [1,0],
            [1,1],
            [0,1],
            [-1,1],
            [-1,0],
            [-1,-1],
            [0,-1],
            [1,-1]
        ])
        if np.random.rand()<self.epsilon:  #epsilon的概率通过贪婪策略进行选择
            if self.Q_table[now_pos[0],now_pos[1]].max() != 0:  # 如果当前状态的Q值全为0，则随机选择一个可行的动作
                act = self.Q_table[now_pos[0],now_pos[1]].argmax()
            else:
                nei_pos = now_pos + pos_change_mat
                is_out_of_bounds = np.any((nei_pos < 0) | (nei_pos > (self.map_size-1)),axis=1)
                nei_pos = nei_pos[~is_out_of_bounds]  # 剔除越界的节点
                allow_action = self.action_space[~is_out_of_bounds]  # 剔除越界的动作
                free_pos = self.map_data[nei_pos[:,0],nei_pos[:,1]] == 0  # 剔除障碍物的节点
                allow_action = allow_action[free_pos]  # 计算当前状态的所有可行动作
                nei_pos = nei_pos[free_pos]  # 计算当前状态的所有可行节点
                #allow_action = self.action_space[self.Q_table[now_pos[0],now_pos[1]]!=-1]
                dis = np.linalg.norm(nei_pos-self.end_pos,axis=1)  # 计算当前状态的所有可行动作到终点的距离
                if dis.min() == 0:
                    act = allow_action[dis.argmin()]
                else:
                    dis = (1/dis)  # 反转距离
                    dis = dis/np.sum(dis)  # 归一化处理
                    #act = np.random.choice(allow_action,p=dis)
                    act = allow_action[dis.argmax()]
        else:
            nei_pos = now_pos + pos_change_mat
            is_out_of_bounds = np.any((nei_pos < 0) | (nei_pos > (self.map_size-1)),axis=1)
            nei_pos = nei_pos[~is_out_of_bounds]  # 剔除越界的节点
            allow_action = self.action_space[~is_out_of_bounds]  # 剔除越界的动作
            free_pos = self.map_data[nei_pos[:,0],nei_pos[:,1]] == 0  # 剔除障碍物的节点
            allow_action = allow_action[free_pos]  # 计算当前状态的所有可行动作
            #allow_action = self.action_space[self.Q_table[now_pos[0],now_pos[1]]!=-1]
            act = np.random.choice(allow_action)
        return act  
      


    def run(self):
        dont_find_end = True
        self.success_count = 0
        for iteration in range(self.max_iter):
            self.x = False
            self.epsilon = (iteration/self.max_iter)   # epsilon随迭代进行而线性减小
            now_pos = self.start_pos.copy()            # 设置当前位置为起点
            way_data = [now_pos.copy()]                # 路径节点记录器(为了方便使用，元素类型选用list类型)
            reward_accumulated = 0                     # 每轮的累计奖励值
            self.env.resetMapData()                    # 重置路径痕迹
            current_path_length = 0
            for move_iter in range(self.max_move_num): #开始当代的寻路任务循环
                act = self.e_greedy(now_pos)                    # 选择act
                new_pos,r = self.env.actResponse(now_pos,act)   # 评估
                reward_accumulated += r
                # if r == -1:                            # 如果新位置出界或者碰撞障碍物，则相应的act直接赋值-1，并退出当前轮次的寻路
                #     self.Q_table[now_pos[0],now_pos[1],act] = -1
                #     break
                sigma = self.sigma_zhi if act%2==0 else self.sigma_xie   # 根据移动的方向选择折扣因子
                self.Q_table[now_pos[0],now_pos[1],act] += self.alpha*(r+sigma*np.max(self.Q_table[new_pos[0],new_pos[1]])-self.Q_table[now_pos[0],now_pos[1],act])  # 更新Q表
                now_pos = new_pos                      # 更新当前位置
                way_data.append(now_pos.copy())        # 记录路径节点，为后面的当代路径长度提供数据
                if (now_pos == self.end_pos).all():    # 如果找到终点，则退出当前轮次。另外，第一次报告一下，可以衡量算法性能。
                    self.success_count +=1
                    if dont_find_end:
                        #print('在第'+str(iteration)+'代首次找到终点！')
                        dont_find_end = False
                    self.x = True
                    break
            self.generation_reward.append(reward_accumulated)             #记录当代所得路径的累计奖励
            self.generation_step.append(move_iter)                        #记录当代所得路径的移动次数
            self.generation_way_len.append(self.calcWayLength(way_data))  #记录当代所得路径的长度
            self.generation_esp.append(self.epsilon)                      #记录当代所得路径的epsilon，主要为后面的epsilon改进提供基础
        else:
            self.finallyLookingForThePath() #训练结束后自动按照贪婪算法搜索终点
    
    def calcWayLength(self,way_data):
        '''
            Function
            --------
            计算路径长度。

            Params
            ------
            way_data : n-list  ->路径数据

            Return
            ------
            length  : float -> 路径长度
        '''
        way_data = np.array(way_data)
        length = np.linalg.norm(way_data[1:]-way_data[:-1],axis=1).sum()
        return length





        




        
        