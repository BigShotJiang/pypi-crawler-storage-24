from abc import ABC, abstractmethod
import numpy as np
from lddya.core.base import BasePlanningProblem


class BaseHeuristicPlanner(BasePlanningProblem, ABC):
    """
    群体 / 启发式全局规划算法，如：
    - ACO
    - GA
    - PSO
    """

    def __init__(self, map_data, start=None, end=None, max_iter=100, population_size=50):
        # 问题定义
        super().__init__(map_data, start, end)
        # 启发式算法参数
        self.max_iter = max_iter
        self.population_size = population_size
        self.best_way_data = []
        self.best_way_len = np.inf
        # 代际统计信息
        self.generation_best = []
        self.generation_aver = []

    @abstractmethod
    def run(self):
        """
        执行多代搜索，返回最优路径
        """
        raise NotImplementedError
    
    def calc_total_length(self, way):
        """
            计算路径总长度，使用numpy矢量化计算
            Params:
                way: 路径点列表，形如 [(y1,x1),(y2,x2),...]
            Returns:
                total_length: 路径总长度（float）
        """
        way = np.asarray(way)
        diffs = way[1:] - way[:-1]          # 相邻点差分
        step_lengths = np.linalg.norm(diffs, axis=1)
        return step_lengths.sum()
