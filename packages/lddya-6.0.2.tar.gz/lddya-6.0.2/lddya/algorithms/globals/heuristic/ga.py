from lddya.algorithms.globals.heuristic.base import BaseHeuristicPlanner
import numpy as np

class GAPlanner(BaseHeuristicPlanner):
    def __init__(self, map_data,start=None,end=None,population_size=50, max_iter = 100, cross_pro=0.95, mut_pro=0.15):
        '''
            Function
            --------
            初始化一个基本GA用于解决路径规划。

            Params
            ------
            map_data     : n*n-np.array  -> 尺寸为n*n的地图数据。\n
            start        : 2-np.arraty   -> 起点坐标，默认为None。\n
            end          : 2-np.arraty   -> 终点坐标，默认为None。\n 
            population   : int -> 种群大小，默认为50。\n
            max_iter     : int -> 最大迭代次数，默认为50。\n
            cross_pro    : float -> 交叉概率，默认0.95。\n
            mut_pro      : float -> 变异概率，默认0.15。\n

            Return
            ------
            返回一个用于解决路径规划的GA实例。
            
        '''
        super().__init__(
            map_data=map_data,
            start=start,
            end=end,
            max_iter=max_iter,
            population_size=population_size)
        self.cross_pro = cross_pro
        self.mut_pro = mut_pro
        self.chroms_list = []  # 初代染色体信息库, 初始化由外部提供
        self.child_list = []    #子代染色体信息库
        self.temporary = []   #临时变量，用来保存ACO生成的初代路径
        self.initPopulation() # 初始化种群

    def initPopulation(self):
        try_count = 0
        while True:
            try_count += 1   # 尝试次数
            if try_count > 10*self.population_size:
                input(f'初始种群成功率不高于{(try_count/self.population_size)*100}%，建议重新调整程序。按确认键继续生成:')
            temp_way_data = []
            temp_way_data.append(self.start.tolist())  # 起点
            success = False   # 标志是否成功
            while True:
                # 计算邻接可行动位置
                allow_grid = np.array([
                    [1, 0], [1, 1], [0, 1], [-1, 1],
                    [-1, 0], [-1, -1], [0, -1], [1, -1]
                ]) + temp_way_data[-1]  # 计算邻接点

                # 过滤掉超出边界的点
                valid_mask = np.logical_and(allow_grid < self.map_size, allow_grid >= 0).all(axis=1)
                allow_grid = allow_grid[valid_mask]
                # 过滤掉不可通行的点
                walkable_mask = self.map_data[allow_grid[:, 0], allow_grid[:, 1]] == 0
                allow_grid = allow_grid[walkable_mask]
                # 若没有可选动作，返回 -1
                if allow_grid.shape[0] == 0:
                    success = False
                    break

                # 计算距离，并获取最小距离的索引
                distance = np.linalg.norm(allow_grid - self.end, axis=1)
                min_idx = np.argmin(distance)

                # 若某个邻居点已经是终点，则直接返回该动作
                if distance[min_idx] == 0:
                    temp_way_data.append(allow_grid[min_idx].tolist())
                    success = True
                    break
                # 计算概率 p
                distance_weight = 1 / distance
                p = (distance_weight**10)
                p /= np.sum(p)  # 归一化概率
                # 移动
                index  =np.random.choice(range(len(allow_grid)), p=p)
                temp_way_data.append(allow_grid[index].tolist())
            if success:
                self.chroms_list.append(temp_way_data)  # 将路径添加到染色体列表中
            if len(self.chroms_list) == self.population_size:
                break
    
    def run(self,show_process = False):
        '''
            Function
            --------
            函数运行主流程
        '''
        for i in range(self.max_iter):
            # Step 1：执行种群选择
            self.child_list = self.selection()
            self.evalution()
            # Step 2: 交叉 
            self.cross()
            # Step 3: 变异
            self.mutation()
            # Step 4: 子代并入父代中
            self.chroms_list = self.child_list.copy()
            if show_process:
                print('第',i,'代:')
                print('平均长度:',self.generation_aver[-1],'最短:',self.generation_best[-1])
    
    def selection(self):
        '''
            Function:
            ---------
                选择算子。选择法则为竞标赛选择法。即每次随机选择3个个体出来竞争，最优秀的那个个体的染色体信息继承到下一代。
            
            Params:
            --------
                None

            Return:
            -------
                child_1:    list-list
                    子代的染色体信息
        '''
        chroms_1 = self.chroms_list.copy()
        child_1 = []
        for i in range(self.population_size):
            a_1 = []    # 3个选手
            b_1 = []    # 3个选手的成绩
            for j in range(3):
                a_1.append(np.random.randint(0,len(chroms_1)))
            for j in a_1:
                b_1.append(self.calc_total_lenght(chroms_1[j]))
            c_1 = b_1.index(min(b_1))  # 最好的是第几个
            child_1.append(chroms_1[a_1[c_1]])  #最好者进入下一代
        return child_1


    def evalution(self):
        '''
            Function
            --------
            对child_list中的染色体进行评估
        '''
        e = []
        for i in self.child_list:
            e.append(self.eval_fun(i))
        self.generation_aver.append(sum(e)/len(e))
        self.generation_best.append(min(e))
        if min(e)<=self.best_way_len:
            self.best_way_len = min(e)
            k = e.index(min(e))
            self.best_way_data = self.child_list[k].copy()

    def cross(self):
        '''
            Function
            --------
            交叉算子
        '''
        child_1 = []   # 参与交叉的个体
        for i in self.child_list:  #依据交叉概率挑选个体
            if np.random.random()<self.cross_pro:
                child_1.append(i)
        if len(child_1)%2 != 0:    #如果不是双数
            child_1.append(child_1[np.random.randint(0,len(child_1))])  #随机复制一个个体
        for i_1 in range(0,len(child_1),2):
            child_2 = child_1[i_1]       #交叉的第一个个体
            child_3 = child_1[i_1+1]     #交叉的第二个个体
            sames = []     #两条路径中，相同的节点的各自所在位置，放这里，留待后面交叉
            for k,i in enumerate(child_2[1:-1]):          # 找相同节点(除起点与终点)
                if i in child_3:
                    sames.append([k+1,child_3.index(i)])   # [index in child_2, index in child_3  ]
            if len(sames) != 0:
                a_1 = np.random.randint(0,len(sames))
                cut_1 = sames[a_1][0]
                cut_2 = sames[a_1][1]
                child_1[i_1] = child_2[:cut_1]+child_3[cut_2:]            #新的覆盖原染色体信息
                child_1[i_1+1] = child_3[:cut_2]+child_2[cut_1:]
        for i in child_1:                     #交叉后的染色体个体加入子代群集中
            self.child_list.append(i)

    def mutation(self):        
        '''
            Function
            --------
            变异算子
        '''
        child_1 = []   # 参与变异的个体
        for i in self.child_list:  #依据变异概率挑选个体
            if np.random.random()<self.mut_pro:
                child_1.append(i)
        for i in range(0,len(child_1)):
            child_2 = np.array(child_1[i])
            index = np.random.randint(low=1,high=len(child_2)-1)    #随机选择一个中间节点
            point_a,point_b,point_c = child_2[index-1:index+1+1]
            v1 = point_b-point_a
            v2 = point_c-point_b
            dot_product = np.dot(v1, v2)  #计算这两个向量的内积
            if dot_product <0 :          #如果两个向量之间的夹角为锐角，则必产生冗余
                del child_1[i][index]    #删除被选中的节点
            elif dot_product == 0:       #如果两个向量之间的夹角为直角，则需要进一步判断
                if 0 in v1:               #如果第一个向量是水平或者垂直的,则必存在冗余
                    del child_1[i][index]    #删除被选中的节点
                elif self.map_data[(point_a[0]+point_c[0])//2,(point_a[1]+point_c[1])//2]==0:                     #如果第一个向量是对角的,且point_a与point_b之间的节点为可通行，则可优化
                    child_1[i][index]  = [(point_a[0]+point_c[0])//2,(point_a[1]+point_c[1])//2]  #修改被选中的节点为中间节点

        for i in child_1:                     #交叉后的染色体个体加入子代群集中
            self.child_list.append(i)
