import numpy as np
import matplotlib.pyplot as plt


class IterationGraph:
    def __init__(self, data_list, style_dict_list=None, point_interval=1, figsize=(8, 5)) -> None:
        """
        Function
        --------
        绘制迭代图。

        Params
        -------
        data_list        : 迭代数据列表，列表中的每个元素为一维数组或列表。
        style_dict_list  : 线条样式列表，每个元素皆为字典，支持 plot 原生参数，
                           如 color、linestyle、marker、label、linewidth 等。
        point_interval   : 点间隔，默认 1。
        figsize          : 图像大小，默认 (8, 5)。

        Return
        ------
        None
        """
        if not isinstance(data_list, (list, tuple)) or len(data_list) == 0:
            raise ValueError("data_list 必须是非空列表或元组。")

        self.fig, self.ax = plt.subplots(figsize=figsize)

        self.data_list = [np.asarray(data, dtype=float) for data in data_list]
        self.style_dict_list = style_dict_list if style_dict_list is not None else []
        self.point_interval = max(1, int(point_interval))

        self._has_label = False

        self._plot_all_curves()

    def _plot_all_curves(self):
        """内部方法：绘制所有曲线"""
        for i, data in enumerate(self.data_list):
            x_values = np.arange(len(data))

            style = self.style_dict_list[i] if i < len(self.style_dict_list) else {}

            self.ax.plot(
                x_values[::self.point_interval],
                data[::self.point_interval],
                **style
            )

            if 'label' in style:
                self._has_label = True

        if self._has_label:
            self.ax.legend()

    def set_title(self, title=''):
        """设置标题"""
        self.ax.set_title(title)

    def set_x_axis(self, label='x', start=None, major=1, offset=0):
        """
        Function
        --------
        设置 x 轴标签和刻度。

        Params
        -------
        label   : x轴标签，默认 'x'
        start   : x轴刻度起始位置，默认 None，表示不手动设置
        major   : 主刻度间隔
        offset  : 标签偏移量

        Return
        ------
        None
        """
        self.ax.set_xlabel(label)

        if start is not None:
            max_len = max(len(d) for d in self.data_list)
            ticks = np.arange(start, max_len, major)
            labels = ticks + offset
            self.ax.set_xticks(ticks)
            self.ax.set_xticklabels(labels)

    def set_y_axis(self, label='y', start=None, major=1, offset=0):
        """
        Function
        --------
        设置 y 轴标签和刻度。

        Params
        -------
        label   : y轴标签，默认 'y'
        start   : y轴刻度起始值，默认 None，表示不手动设置
        major   : 主刻度间隔
        offset  : 标签偏移量

        Return
        ------
        None
        """
        self.ax.set_ylabel(label)

        if start is not None:
            all_data = np.concatenate(self.data_list)
            y_max = np.max(all_data)
            ticks = np.arange(start, y_max + major, major)
            labels = ticks + offset
            self.ax.set_yticks(ticks)
            self.ax.set_yticklabels(labels)

    def set_xlim(self, left=None, right=None):
        """设置 x 轴显示范围"""
        self.ax.set_xlim(left, right)

    def set_ylim(self, bottom=None, top=None):
        """设置 y 轴显示范围"""
        self.ax.set_ylim(bottom, top)

    def set_grid(self, visible=True, alpha=0.3, linestyle='--'):
        """设置网格"""
        self.ax.grid(visible, alpha=alpha, linestyle=linestyle)

    def set_legend(self, **kwargs):
        """手动设置图例"""
        self.ax.legend(**kwargs)

    def smooth_data(self, window_size=5, inplace=True, redraw=True):
        """
        Function
        --------
        对所有曲线进行滑动平均平滑。

        Params
        -------
        window_size : 平滑窗口大小，必须 >= 1
        inplace     : 是否替换原始数据
        redraw      : 是否重绘图像

        Return
        ------
        smoothed_data_list
        """
        if window_size < 1:
            raise ValueError("window_size 必须 >= 1")

        smoothed_data_list = []
        kernel = np.ones(window_size) / window_size

        for data in self.data_list:
            if len(data) < window_size:
                smoothed = data.copy()
            else:
                smoothed = np.convolve(data, kernel, mode='same')
            smoothed_data_list.append(smoothed)

        if inplace:
            self.data_list = smoothed_data_list
            if redraw:
                self.redraw()

        return smoothed_data_list

    def redraw(self):
        """清空并重绘"""
        self.ax.clear()
        self._has_label = False
        self._plot_all_curves()

    def show(self):
        plt.show()

    def save(self, figname='figure.png', dpi=300, bbox_inches='tight'):
        """
        保存图像
        常用于论文：png / pdf / svg
        """
        self.fig.savefig(figname, dpi=dpi, bbox_inches=bbox_inches)


class PlotStyleGenerator:
    def __init__(self):
        self.styles = [
            {"color": "red",         "linestyle": "-",  "marker": "o", "linewidth": 1.8},
            {"color": "black",       "linestyle": "-",  "marker": "<", "linewidth": 1.8},
            {"color": "magenta",     "linestyle": "-",  "marker": ".", "linewidth": 1.8},
            {"color": "blue",        "linestyle": "-",  "marker": "d", "linewidth": 1.8},
            {"color": "olive",       "linestyle": "-",  "marker": "*", "linewidth": 1.8},
            {"color": "teal",        "linestyle": "-",  "marker": ">", "linewidth": 1.8},
            {"color": "saddlebrown", "linestyle": "-",  "marker": "s", "linewidth": 1.8},
            {"color": "lime",        "linestyle": "-",  "marker": "p", "linewidth": 1.8},
            {"color": "gray",        "linestyle": "-",  "marker": "h", "linewidth": 1.8},
            {"color": "deeppink",    "linestyle": "-",  "marker": "^", "linewidth": 1.8},
            {"color": "cyan",        "linestyle": "-",  "marker": "v", "linewidth": 1.8},
            {"color": "turquoise",   "linestyle": "--", "marker": ">", "linewidth": 1.8},
            {"color": "darkviolet",  "linestyle": "--", "marker": "v", "linewidth": 1.8},
            {"color": "peru",        "linestyle": "--", "marker": ">", "linewidth": 1.8},
            {"color": "tomato",      "linestyle": "--", "marker": "s", "linewidth": 1.8},
            {"color": "maroon",      "linestyle": "--", "marker": "^", "linewidth": 1.8},
        ]

    def get_styles(self, n=None, shuffle=True, labels=None):
        """
        返回前 n 个 plot() 兼容样式组合。

        Params
        -------
        n       : 返回样式数量
        shuffle : 是否打乱
        labels  : 可选标签列表，会自动写入每个 style 的 label

        Return
        ------
        list[dict]
        """
        styles = [s.copy() for s in self.styles]

        if shuffle:
            np.random.shuffle(styles)

        if n is None or n > len(styles):
            n = len(styles)

        styles = styles[:n]

        if labels is not None:
            for i in range(min(n, len(labels))):
                styles[i]["label"] = labels[i]

        return styles