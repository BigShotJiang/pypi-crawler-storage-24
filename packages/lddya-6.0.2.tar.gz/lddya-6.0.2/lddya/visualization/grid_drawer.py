import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as pat

class ShanGeTu():
    def __init__(self,map_data,x_label = '',y_label = '',x_major=1, y_major=1,obs_color = "k",edge_color = 'k') -> None:
        self.map_size = np.array([*map_data.shape])  # 获取地图的尺寸
        default_size = np.array([7, 7])  # 默认图形大小
        self.fig = plt.figure(figsize=default_size*(self.map_size[::-1]/max(self.map_size[::-1])))
        self.ax1 = self.fig.add_subplot(1,1,1)
        self.ax1.set_xbound(0,len(map_data))
        self.ax1.set_ybound(0,len(map_data))
        rect_pat = []
        for ki,i in enumerate(map_data):
            for kj,j in enumerate(i):
                if j == 1:
                    rect_pat.append(pat.Rectangle((kj,ki),1,1,color = obs_color))
                else:
                    rect_pat.append(pat.Rectangle((kj,ki),1,1,fill = False,edgecolor =edge_color,linewidth = 1))
        for i in rect_pat:
            self.ax1.add_patch(i)
        self.ax1.set_xlabel(x_label)
        self.ax1.set_ylabel(y_label)
        # 显示刻度标签
        self.ax1.set_xticks(np.array([1] + list(np.arange(x_major, map_data.shape[1] + 1, x_major)))-0.5)
        self.ax1.set_yticks(np.array([1] + list(np.arange(y_major, map_data.shape[0] + 1, y_major)))-0.5)
        # 显示刻度标签，从 1 开始，后续为指定间隔的倍数
        self.ax1.set_xticklabels([1] + list(np.arange(x_major, map_data.shape[1] + 1, x_major)))
        self.ax1.set_yticklabels([1] + list(np.arange(y_major, map_data.shape[0] + 1, y_major)))
        self.show_legend = False



    def draw_way(self, way_data, style_dict = {}):
        """
        绘制路径，接受所有 plt.plot 支持的参数，通过字典解包方式传入。

        Parameters
        ----------
        way_data : list or np.ndarray
            路径点坐标，格式为[y, x]。
        style_dict : dict
            所有 plt.plot 支持的参数，例如 color、linestyle、marker、label、linewidth 等。
        """
        way_data = np.array(way_data)

        if 'label' in style_dict:
            self.show_legend = True

        self.ax1.plot(
            way_data[:, 1] + 0.5,
            way_data[:, 0] + 0.5,
            **style_dict
        )
    
    

    def add_obstacles(self, positions, color):
        """
        添加自定义障碍物，可指定颜色和图例名称。

        Parameters:
        -----------
        positions: List of [y, x] 坐标
        color: 填充颜色
        label: 图例文字（可选）
        """
        for pos in positions:
            y, x = pos
            self.ax1.add_patch(pat.Rectangle((x, y), 1, 1, color=color)) 
 
    def show(self):
        if self.show_legend:
            self.ax1.legend()
        plt.show()
    
    def save(self,filename = 'figure.jpg'):
        if self.show_legend:
            self.ax1.legend()
        plt.savefig(filename)
   