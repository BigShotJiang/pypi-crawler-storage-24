from abc import ABC, abstractmethod
import numpy as np


class BasePlanningProblem(ABC):
    """
    路径规划问题的最小抽象：
    - 定义环境（map）
    - 定义起点 / 终点
    不包含任何算法行为
    """

    def __init__(self, map_data, start=None, end=None):
        self.map_data = np.array(map_data).copy()
        self.map_size = self.map_data.shape[0]      # 地图大小
        

        self.start = (
            np.array(start) if start is not None
            else np.array([0, 0])                                        # 任务起点, 默认左上角
        )
        self.end = (
            np.array(end) if end is not None
            else np.array([self.map_size - 1, self.map_size - 1])    # 任务终点, 默认右下角
        )


    @abstractmethod
    def run(self):
        """
        算法运行
        """
        raise NotImplementedError
