from .cobre import *

__doc__ = cobre.__doc__
if hasattr(cobre, "__all__"):
    __all__ = cobre.__all__