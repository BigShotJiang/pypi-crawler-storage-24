"""
Scénarios de test automatisés pour ErrorShield
"""

import requests
import time
import json
from typing import Dict, List, Any

class ErrorShieldTester:
    """Testeur automatique pour ErrorShield"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.dashboard_url = "http://localhost:3001"
        self.test_results = []
    
    def run_all_tests(self):
        """Exécute tous les scénarios de test"""
        print("🧪 Démarrage des tests automatisés ErrorShield")
        print("=" * 50)
        
        # Test de connectivité
        if not self.test_connectivity():
            print("❌ Serveur non disponible - démarrez l'application d'abord")
            return False
        
        # Scénarios de test
        scenarios = [
            self.test_ecommerce_flow,
            self.test_api_errors,
            self.test_database_errors,
            self.test_system_errors,
            self.test_security_errors,
            self.test_monitoring_errors,
            self.test_basic_errors,
            self.test_dashboard_connectivity
        ]
        
        for scenario in scenarios:
            try:
                print(f"\n🎯 Exécution: {scenario.__name__}")
                result = scenario()
                self.test_results.append({
                    'scenario': scenario.__name__,
                    'status': 'PASS' if result else 'FAIL',
                    'timestamp': time.time()
                })
                print(f"{'✅' if result else '❌'} {scenario.__name__}")
            except Exception as e:
                print(f"❌ {scenario.__name__}: {str(e)}")
                self.test_results.append({
                    'scenario': scenario.__name__,
                    'status': 'ERROR',
                    'error': str(e),
                    'timestamp': time.time()
                })
        
        self.print_summary()
        return True
    
    def test_connectivity(self) -> bool:
        """Test la connectivité avec l'application"""
        try:
            response = requests.get(f"{self.base_url}/", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def test_ecommerce_flow(self) -> bool:
        """Test du flux e-commerce"""
        try:
            # Ajouter au panier
            data = {'product': 'laptop', 'quantity': '2'}
            response = requests.post(f"{self.base_url}/cart/add", data=data)
            
            # Finaliser commande (devrait fonctionner)
            response = requests.get(f"{self.base_url}/cart/checkout")
            
            # Erreur de paiement (devrait générer une erreur)
            try:
                response = requests.get(f"{self.base_url}/cart/error")
                return False  # Ne devrait pas arriver ici
            except requests.exceptions.RequestException:
                return True  # Erreur attendue
            
        except Exception:
            return True  # Erreur attendue pour certains tests
    
    def test_api_errors(self) -> bool:
        """Test des erreurs API"""
        try:
            # Test API users (GET)
            response = requests.get(f"{self.base_url}/api/users")
            
            # Test API users (POST) - devrait échouer
            try:
                response = requests.post(f"{self.base_url}/api/users", json={})
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test erreur API 500
            try:
                response = requests.get(f"{self.base_url}/api/error")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test erreur validation
            try:
                response = requests.get(f"{self.base_url}/api/validation")
                return False
            except requests.exceptions.RequestException:
                pass
            
            return True
            
        except Exception:
            return True
    
    def test_database_errors(self) -> bool:
        """Test des erreurs de base de données"""
        try:
            # Test requête simple
            data = {'query_type': 'select'}
            response = requests.post(f"{self.base_url}/database/query", data=data)
            
            # Test timeout
            try:
                response = requests.get(f"{self.base_url}/database/timeout")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test erreur connexion
            try:
                response = requests.get(f"{self.base_url}/database/connection")
                return False
            except requests.exceptions.RequestException:
                pass
            
            return True
            
        except Exception:
            return True
    
    def test_system_errors(self) -> bool:
        """Test des erreurs système"""
        try:
            # Test traitement normal
            data = {'size': '50'}
            response = requests.post(f"{self.base_url}/system/process", data=data)
            
            # Test erreur mémoire
            try:
                response = requests.get(f"{self.base_url}/system/memory")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test erreur fichier
            try:
                response = requests.get(f"{self.base_url}/system/file")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test erreur permission
            try:
                response = requests.get(f"{self.base_url}/system/permission")
                return False
            except requests.exceptions.RequestException:
                pass
            
            return True
            
        except Exception:
            return True
    
    def test_security_errors(self) -> bool:
        """Test des erreurs de sécurité"""
        try:
            # Test login avec données sensibles
            data = {
                'email': 'test@example.com',
                'password': 'secret123',
                'card': '1234-5678-9012-3456'
            }
            try:
                response = requests.post(f"{self.base_url}/security/login", data=data)
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test simulation fuite
            try:
                response = requests.get(f"{self.base_url}/security/breach")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test nettoyage
            try:
                response = requests.get(f"{self.base_url}/security/sanitize")
                return False
            except requests.exceptions.RequestException:
                pass
            
            return True
            
        except Exception:
            return True
    
    def test_monitoring_errors(self) -> bool:
        """Test des erreurs de monitoring"""
        try:
            # Test métriques normales
            data = {'cpu': '30', 'memory': '256'}
            response = requests.post(f"{self.base_url}/monitoring/metrics", data=data)
            
            # Test alerte
            try:
                response = requests.get(f"{self.base_url}/monitoring/alert")
                return False
            except requests.exceptions.RequestException:
                pass
            
            # Test health check
            response = requests.get(f"{self.base_url}/monitoring/health")
            
            return True
            
        except Exception:
            return True
    
    def test_basic_errors(self) -> bool:
        """Test des erreurs de base"""
        error_endpoints = [
            '/error/value',
            '/error/type', 
            '/error/key',
            '/error/index',
            '/error/memory',
            '/error/timeout',
            '/error/custom',
            '/error/cascade'
        ]
        
        for endpoint in error_endpoints:
            try:
                response = requests.get(f"{self.base_url}{endpoint}")
                # Si on arrive ici, l'erreur n'a pas été levée
                return False
            except requests.exceptions.RequestException:
                # Erreur attendue
                continue
        
        return True
    
    def test_dashboard_connectivity(self) -> bool:
        """Test la connectivité du dashboard"""
        try:
            response = requests.get(f"{self.dashboard_url}/", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def print_summary(self):
        """Affiche le résumé des tests"""
        print("\n" + "=" * 50)
        print("📊 RÉSUMÉ DES TESTS")
        print("=" * 50)
        
        passed = sum(1 for r in self.test_results if r['status'] == 'PASS')
        failed = sum(1 for r in self.test_results if r['status'] == 'FAIL')
        errors = sum(1 for r in self.test_results if r['status'] == 'ERROR')
        total = len(self.test_results)
        
        print(f"✅ Réussis: {passed}/{total}")
        print(f"❌ Échoués: {failed}/{total}")
        print(f"⚠️  Erreurs: {errors}/{total}")
        
        if failed > 0 or errors > 0:
            print("\n📋 Détails:")
            for result in self.test_results:
                if result['status'] != 'PASS':
                    status_icon = "❌" if result['status'] == 'FAIL' else "⚠️"
                    print(f"  {status_icon} {result['scenario']}")
                    if 'error' in result:
                        print(f"    Erreur: {result['error']}")
        
        print(f"\n🎯 Taux de réussite: {(passed/total)*100:.1f}%")
        
        if passed == total:
            print("🎉 Tous les tests passés avec succès!")
        elif passed >= total * 0.8:
            print("👍 La plupart des tests sont passés")
        else:
            print("⚠️  Certains tests ont échoué - vérifiez l'application")

def main():
    """Fonction principale"""
    tester = ErrorShieldTester()
    tester.run_all_tests()

if __name__ == '__main__':
    main()
