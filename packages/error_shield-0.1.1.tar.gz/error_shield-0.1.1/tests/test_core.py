"""
Tests for ErrorShield core functionality
"""

import pytest
import os
from unittest.mock import Mock, patch
from error_shield import ErrorShield, ErrorShieldConfig
from error_shield.core import ErrorContext


class TestErrorShieldConfig:
    """Test ErrorShieldConfig class"""
    
    def test_default_config(self):
        """Test default configuration values"""
        config = ErrorShieldConfig()
        
        assert config.mode == 'auto'
        assert config.error_context_size == 10
        assert config.enable_local_dashboard is True
        assert config.dashboard_port == 3001
        assert 'password' in config.sanitize_fields
        assert 'token' in config.sanitize_fields
    
    def test_production_detection(self):
        """Test automatic production environment detection"""
        # Test development
        with patch.dict(os.environ, {'FLASK_ENV': 'development'}):
            config = ErrorShieldConfig(mode='auto')
            assert config.is_production is False
        
        # Test production
        with patch.dict(os.environ, {'FLASK_ENV': 'production'}):
            config = ErrorShieldConfig(mode='auto')
            assert config.is_production is True
    
    def test_force_modes(self):
        """Test force production/development modes"""
        # Force production
        config = ErrorShieldConfig(mode='force_prod')
        assert config.is_production is True
        
        # Force development
        config = ErrorShieldConfig(mode='force_dev')
        assert config.is_production is False
    
    def test_invalid_mode(self):
        """Test invalid mode raises error"""
        with pytest.raises(ValueError):
            ErrorShieldConfig(mode='invalid')
    
    def test_from_dict(self):
        """Test creating config from dictionary"""
        config_dict = {
            'mode': 'force_prod',
            'error_context_size': 20,
            'dashboard_port': 4000
        }
        
        config = ErrorShieldConfig.from_dict(config_dict)
        assert config.mode == 'force_prod'
        assert config.error_context_size == 20
        assert config.dashboard_port == 4000


class TestErrorShield:
    """Test ErrorShield main class"""
    
    def test_initialization_without_app(self):
        """Test initialization without Flask app"""
        config = ErrorShieldConfig()
        shield = ErrorShield(config=config)
        
        assert shield.config == config
        assert shield.app is None
        assert shield._error_history == []
        assert shield._current_context is None
    
    def test_error_context_creation(self):
        """Test error context creation"""
        config = ErrorShieldConfig()
        shield = ErrorShield(config=config)
        
        exception = ValueError("Test error")
        context = shield._create_error_context(exception)
        
        assert isinstance(context, ErrorContext)
        assert context.error['type'] == 'ValueError'
        assert context.error['message'] == 'Test error'
        assert 'traceback' in context.error
        assert context.error_id is not None
        assert context.timestamp is not None
    
    def test_data_sanitization(self):
        """Test data sanitization"""
        config = ErrorShieldConfig(sanitize_fields=['password', 'secret'])
        shield = ErrorShield(config=config)
        
        data = {
            'username': 'john',
            'password': 'secret123',
            'nested': {
                'secret_key': 'abc123',
                'public_key': 'def456'
            }
        }
        
        sanitized = shield._sanitize_data(data)
        
        assert sanitized['username'] == 'john'
        assert sanitized['password'] == '[REDACTED]'
        assert sanitized['nested']['secret_key'] == '[REDACTED]'
        assert sanitized['nested']['public_key'] == 'def456'
    
    def test_error_history_management(self):
        """Test error history management"""
        config = ErrorShieldConfig(error_context_size=3)
        shield = ErrorShield(config=config)
        
        # Add errors
        for i in range(5):
            exception = ValueError(f"Error {i}")
            context = shield._create_error_context(exception)
            shield._error_history.append(context)
        
        # Should only keep last 3 errors
        assert len(shield._error_history) == 3
        assert shield._error_history[-1].error['message'] == 'Error 4'
    
    def test_get_error_history(self):
        """Test getting error history"""
        config = ErrorShieldConfig()
        shield = ErrorShield(config=config)
        
        exception = ValueError("Test error")
        context = shield._create_error_context(exception)
        shield._error_history.append(context)
        
        history = shield.get_error_history()
        assert len(history) == 1
        assert history[0].error['message'] == 'Test error'
        
        # Should return a copy
        history.clear()
        assert len(shield._error_history) == 1


class TestErrorContext:
    """Test ErrorContext class"""
    
    def test_error_context_creation(self):
        """Test ErrorContext creation"""
        error_data = {
            'type': 'ValueError',
            'message': 'Test error',
            'traceback': 'Traceback...'
        }
        
        context = ErrorContext(
            error_id='test-123',
            timestamp=None,  # Will be set in test
            environment='development',
            error=error_data
        )
        
        assert context.error_id == 'test-123'
        assert context.environment == 'development'
        assert context.error == error_data
        assert context.request is None
        assert context.user is None


@pytest.fixture
def mock_flask_app():
    """Mock Flask app for testing"""
    app = Mock()
    app.errorhandler = Mock()
    app.before_request = Mock()
    app.after_request = Mock()
    return app


class TestFlaskIntegration:
    """Test Flask integration"""
    
    def test_init_with_app(self, mock_flask_app):
        """Test initialization with Flask app"""
        config = ErrorShieldConfig()
        shield = ErrorShield(mock_flask_app, config=config)
        
        assert shield.app == mock_flask_app
        assert hasattr(mock_flask_app, 'error_shield_config')
        assert hasattr(mock_flask_app, 'error_shield')
    
    @patch('error_shield.core.ErrorShield._init_plugins')
    @patch('error_shield.core.ErrorShield._setup_error_handlers')
    @patch('error_shield.core.ErrorShield._start_dashboard')
    def test_init_app_calls(self, mock_dashboard, mock_handlers, mock_plugins, mock_flask_app):
        """Test that init_app calls all necessary methods"""
        config = ErrorShieldConfig(enable_local_dashboard=False)
        shield = ErrorShield(config=config)
        shield.init_app(mock_flask_app)
        
        mock_plugins.assert_called_once()
        mock_handlers.assert_called_once()
        mock_dashboard.assert_called_once()


if __name__ == '__main__':
    pytest.main([__file__])
