"""
Core ErrorShield functionality
"""

import os
import uuid
import traceback
import threading
from datetime import datetime
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from .config import ErrorShieldConfig
from contextlib import contextmanager
from functools import wraps


@dataclass
class ErrorContext:
    """Context information for an error"""
    error_id: str
    timestamp: datetime
    environment: str
    error: Dict[str, Any]
    request: Optional[Dict[str, Any]] = None
    user: Optional[Dict[str, Any]] = None
    system: Optional[Dict[str, Any]] = None
    business_context: Optional[Dict[str, Any]] = None
    additional_context: Optional[Dict[str, Any]] = None


class ErrorShield:
    """Main ErrorShield class"""
    
    def __init__(self, app=None, config: Optional[ErrorShieldConfig] = None):
        self.config = config or ErrorShieldConfig()
        self.app = app
        self._error_history: List[ErrorContext] = []
        self._current_context: Optional[ErrorContext] = None
        self._plugins = []
        self._lock = threading.Lock()
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize ErrorShield with a Flask app"""
        self.app = app
        
        # Store config in app
        app.error_shield_config = self.config
        app.error_shield = self
        
        # Initialize plugins
        self._init_plugins()
        
        # Setup error handlers
        self._setup_error_handlers()
        
        # Start dashboard if enabled
        if self.config.enable_local_dashboard and not self.config.is_production:
            self._start_dashboard()
    
    def _init_plugins(self):
        """Initialize configured plugins"""
        for plugin_name in self.config.plugins:
            try:
                # Import plugin
                if plugin_name == 'database':
                    from .plugins.database import DatabasePlugin, set_database_plugin
                    plugin = DatabasePlugin(self.config.plugins_config.get('database', {}))
                    set_database_plugin(plugin)  # Set global instance
                elif plugin_name == 'memory':
                    from .plugins.memory import MemoryPlugin
                    plugin = MemoryPlugin(self.config.plugins_config.get('memory', {}))
                elif plugin_name == 'business':
                    from .plugins.business import BusinessPlugin
                    plugin = BusinessPlugin(self.config.plugins_config.get('business', {}))
                else:
                    continue
                
                # Initialize plugin
                plugin.on_startup()
                self._plugins.append(plugin)
                
            except ImportError:
                # Plugin not available, skip
                continue
            except Exception as e:
                # Plugin initialization failed, but don't break the main app
                print(f"Warning: Failed to initialize plugin {plugin_name}: {e}")
    
    def _setup_error_handlers(self):
        """Setup error handlers for the app"""
        if hasattr(self.app, 'errorhandler'):
            @self.app.errorhandler(Exception)
            def handle_exception(e):
                return self._handle_error(e)
    
    def _handle_error(self, exception):
        """Handle an exception and return appropriate response"""
        # Create error context
        context = self._create_error_context(exception)
        
        # Store current context
        with self._lock:
            self._current_context = context
            self._error_history.append(context)
            
            # Limit history size
            if len(self._error_history) > self.config.error_context_size:
                self._error_history.pop(0)
        
        # Run plugins
        for plugin in self._plugins:
            try:
                plugin.after_capture(exception, context)
            except Exception:
                pass  # Don't let plugin errors break error handling
        
        # Generate response
        if self.config.is_production:
            return self._render_production_error(context)
        else:
            return self._render_development_error(context)
    
    def _create_error_context(self, exception) -> ErrorContext:
        """Create error context from exception"""
        error_id = str(uuid.uuid4())
        
        error_data = {
            'type': type(exception).__name__,
            'message': str(exception),
            'traceback': traceback.format_exc(),
            'local_vars': getattr(exception, '__dict__', {})
        }
        
        # Sanitize sensitive data
        error_data = self._sanitize_data(error_data)
        
        context = ErrorContext(
            error_id=error_id,
            timestamp=datetime.utcnow(),
            environment='production' if self.config.is_production else 'development',
            error=error_data
        )
        
        # Add request context if available
        if hasattr(self.app, 'request_context'):
            try:
                from flask import request
                context.request = {
                    'method': request.method,
                    'path': request.path,
                    'query_params': dict(request.args),
                    'headers': dict(request.headers),
                    'body': request.get_data(as_text=True) if request.get_data() else None
                }
            except Exception:
                pass
        
        return context
    
    def _sanitize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize sensitive data from error context"""
        if not isinstance(data, dict):
            return data
        
        sanitized = {}
        for key, value in data.items():
            # Check if key matches any sanitize field
            if any(field in key.lower() for field in self.config.sanitize_fields):
                sanitized[key] = '[REDACTED]'
            elif isinstance(value, dict):
                sanitized[key] = self._sanitize_data(value)
            elif isinstance(value, list):
                sanitized[key] = [self._sanitize_data(item) if isinstance(item, dict) else item for item in value]
            else:
                sanitized[key] = value
        
        return sanitized
    
    def _render_production_error(self, context: ErrorContext):
        """Render production error page"""
        from flask import render_template_string, make_response
        
        template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Something went wrong</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
                       display: flex; align-items: center; justify-content: center; min-height: 100vh; 
                       margin: 0; background: #f8fafc; }
                .container { text-align: center; padding: 2rem; }
                .icon { font-size: 4rem; color: #ef4444; margin-bottom: 1rem; }
                h1 { color: #1f2937; margin-bottom: 0.5rem; }
                p { color: #6b7280; margin-bottom: 2rem; }
                .btn { background: #3b82f6; color: white; padding: 0.75rem 1.5rem; 
                       text-decoration: none; border-radius: 0.5rem; display: inline-block; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">⚠️</div>
                <h1>Something went wrong</h1>
                <p>We've been notified about this issue and are working on it.</p>
                <p>Error ID: {{ error_id }}</p>
                <a href="/" class="btn">Go back home</a>
            </div>
        </body>
        </html>
        """
        
        response = make_response(render_template_string(template, error_id=context.error_id))
        response.status_code = 500
        return response
    
    def _render_development_error(self, context: ErrorContext):
        """Render development error page"""
        from flask import render_template_string, make_response
        
        template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Development Error - {{ error.type }}</title>
            <style>
                body { font-family: 'Monaco', 'Menlo', monospace; margin: 0; background: #1e1e1e; color: #d4d4d4; }
                .header { background: #252526; padding: 1rem; border-bottom: 1px solid #333; }
                .tabs { display: flex; background: #2d2d2d; }
                .tab { padding: 0.75rem 1.5rem; cursor: pointer; border-right: 1px solid #333; }
                .tab.active { background: #1e1e1e; }
                .content { padding: 1rem; }
                .tab-content { display: none; }
                .tab-content.active { display: block; }
                .error-type { color: #f48771; font-weight: bold; }
                .error-message { color: #cccccc; margin: 0.5rem 0; }
                .traceback { background: #2d2d2d; padding: 1rem; border-radius: 0.25rem; overflow-x: auto; }
                .error-id { color: #4ec9b0; font-size: 0.9rem; }
                pre { margin: 0; white-space: pre-wrap; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🛡️ ErrorShield - Development Error</h1>
                <div class="error-id">Error ID: {{ error_id }}</div>
            </div>
            
            <div class="tabs">
                <div class="tab active" onclick="showTab('overview')">Overview</div>
                <div class="tab" onclick="showTab('traceback')">Traceback</div>
                <div class="tab" onclick="showTab('request')">Request</div>
                <div class="tab" onclick="showTab('context')">Context</div>
            </div>
            
            <div class="content">
                <div id="overview" class="tab-content active">
                    <h2 class="error-type">{{ error.type }}</h2>
                    <p class="error-message">{{ error.message }}</p>
                    <p><strong>Time:</strong> {{ timestamp }}</p>
                    <p><strong>Environment:</strong> {{ environment }}</p>
                </div>
                
                <div id="traceback" class="tab-content">
                    <div class="traceback">
                        <pre>{{ error.traceback }}</pre>
                    </div>
                </div>
                
                <div id="request" class="tab-content">
                    {% if request %}
                    <h3>Request Details</h3>
                    <p><strong>Method:</strong> {{ request.method }}</p>
                    <p><strong>Path:</strong> {{ request.path }}</p>
                    <p><strong>Query Params:</strong></p>
                    <pre>{{ request.query_params | tojson(indent=2) }}</pre>
                    {% else %}
                    <p>No request context available</p>
                    {% endif %}
                </div>
                
                <div id="context" class="tab-content">
                    <h3>Local Variables</h3>
                    <pre>{{ error.local_vars | tojson(indent=2) }}</pre>
                </div>
            </div>
            
            <script>
                function showTab(tabName) {
                    // Hide all tabs
                    document.querySelectorAll('.tab-content').forEach(content => {
                        content.classList.remove('active');
                    });
                    document.querySelectorAll('.tab').forEach(tab => {
                        tab.classList.remove('active');
                    });
                    
                    // Show selected tab
                    document.getElementById(tabName).classList.add('active');
                    event.target.classList.add('active');
                }
            </script>
        </body>
        </html>
        """
        
        response = make_response(render_template_string(
            template, 
            error_id=context.error_id,
            error=context.error,
            timestamp=context.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC'),
            environment=context.environment,
            request=context.request
        ))
        response.status_code = 500
        return response
    
    def _start_dashboard(self):
        """Start the local development dashboard"""
        if not self.config.enable_local_dashboard or self.config.is_production:
            return
        
        try:
            from .dashboard.server import DashboardServer
            self.dashboard = DashboardServer(self, self.config.dashboard_port)
            self.dashboard.start()
        except ImportError:
            # Dashboard dependencies not available
            pass
        except Exception as e:
            # Failed to start dashboard, but don't break the main app
            print(f"Warning: Failed to start ErrorShield dashboard: {e}")
    
    def get_current_context(self) -> Optional[ErrorContext]:
        """Get the current error context"""
        return self._current_context
    
    def get_error_history(self) -> List[ErrorContext]:
        """Get the error history"""
        return self._error_history.copy()


# Global context for manual error capture
_current_error_context = None


def capture_error(exception: Exception, additional_context: Optional[Dict[str, Any]] = None):
    """Manually capture an error"""
    global _current_error_context
    
    # Get the current ErrorShield instance if available
    from flask import current_app
    if hasattr(current_app, 'error_shield'):
        error_shield = current_app.error_shield
        context = error_shield._create_error_context(exception)
        
        if additional_context:
            context.additional_context = additional_context
        
        with error_shield._lock:
            error_shield._current_context = context
            error_shield._error_history.append(context)
            
            if len(error_shield._error_history) > error_shield.config.error_context_size:
                error_shield._error_history.pop(0)
        
        _current_error_context = context
    else:
        # Fallback context creation
        _current_error_context = ErrorContext(
            error_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow(),
            environment='unknown',
            error={
                'type': type(exception).__name__,
                'message': str(exception),
                'traceback': traceback.format_exc()
            },
            additional_context=additional_context
        )


def current_error_context() -> Optional[ErrorContext]:
    """Get the current error context"""
    return _current_error_context


def set_business_context(context: Dict[str, Any]):
    """Set business context for the current request"""
    from flask import g
    if not hasattr(g, 'error_shield_business_context'):
        g.error_shield_business_context = {}
    g.error_shield_business_context.update(context)
