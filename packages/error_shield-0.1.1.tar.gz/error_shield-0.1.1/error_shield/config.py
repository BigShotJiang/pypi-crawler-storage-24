"""
Configuration management for ErrorShield
"""

import os
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field


@dataclass
class ErrorShieldConfig:
    """Configuration for ErrorShield with validation and defaults"""
    
    # Core settings
    mode: str = 'auto'  # 'auto', 'force_prod', 'force_dev'
    is_production: bool = field(init=False)  # Computed from mode
    
    # UI settings
    ui_template: Optional[str] = None
    error_context_size: int = 10
    enable_local_dashboard: bool = True
    dashboard_port: int = 3001
    
    # UI customization
    ui_config: Dict[str, Any] = field(default_factory=lambda: {
        'company_name': 'ErrorShield',
        'logo_url': None,
        'primary_color': '#4facfe',
        'support_email': None,
        'documentation_url': None
    })
    
    # Security settings
    sanitize_fields: List[str] = field(default_factory=lambda: [
        'password', 'token', 'credit_card', 'ssn', 'email', 
        'secret', 'authorization', 'api_key', 'private_key'
    ])
    security: Dict[str, Any] = field(default_factory=lambda: {
        'mask_ip': True,
        'rate_limit': {
            'max_errors_per_minute': 100,
            'ban_time_minutes': 5,
        }
    })
    
    # Plugin system
    plugins: List[str] = field(default_factory=list)
    plugins_config: Dict[str, Any] = field(default_factory=dict)
    
    # Notifications
    notifications: Dict[str, Any] = field(default_factory=dict)
    
    # Dashboard settings
    dashboard: Dict[str, Any] = field(default_factory=lambda: {
        'enabled': True,
        'port': 3001,
        'password': None,
        'retention_days': 7,
    })
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        # Auto-detect environment if mode is 'auto'
        if self.mode == 'auto':
            env = os.getenv('ENV', os.getenv('FLASK_ENV', os.getenv('NODE_ENV', 'development')))
            self.is_production = env.lower() == 'production'
        else:
            self.is_production = self.mode == 'force_prod'
        
        # Validate settings
        self._validate()
        
        # Apply environment overrides
        self._apply_env_overrides()
    
    def _validate(self):
        """Validate configuration settings"""
        if self.mode not in ['auto', 'force_prod', 'force_dev']:
            raise ValueError(f"Invalid mode: {self.mode}. Must be 'auto', 'force_prod', or 'force_dev'")
        
        if self.error_context_size < 1:
            raise ValueError("error_context_size must be at least 1")
        
        if self.dashboard_port < 1 or self.dashboard_port > 65535:
            raise ValueError("dashboard_port must be between 1 and 65535")
        
        if not isinstance(self.sanitize_fields, list):
            raise ValueError("sanitize_fields must be a list")
    
    def _apply_env_overrides(self):
        """Apply environment variable overrides"""
        # Dashboard settings
        if 'ERRORSHIELD_DASHBOARD_PORT' in os.environ:
            self.dashboard_port = int(os.environ['ERRORSHIELD_DASHBOARD_PORT'])
        
        if 'ERRORSHIELD_DASHBOARD_ENABLED' in os.environ:
            self.enable_local_dashboard = os.environ['ERRORSHIELD_DASHBOARD_ENABLED'].lower() == 'true'
        
        # UI settings
        if 'ERRORSHIELD_COMPANY_NAME' in os.environ:
            self.ui_config['company_name'] = os.environ['ERRORSHIELD_COMPANY_NAME']
        
        if 'ERRORSHIELD_PRIMARY_COLOR' in os.environ:
            self.ui_config['primary_color'] = os.environ['ERRORSHIELD_PRIMARY_COLOR']
        
        # Security settings
        if 'ERRORSHIELD_MASK_IP' in os.environ:
            self.security['mask_ip'] = os.environ['ERRORSHIELD_MASK_IP'].lower() == 'true'
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'ErrorShieldConfig':
        """Create configuration from dictionary"""
        return cls(**config_dict)
    
    @classmethod
    def from_env(cls) -> 'ErrorShieldConfig':
        """Create configuration from environment variables"""
        config = cls()
        
        # Apply all environment variable overrides
        config._apply_env_overrides()
        
        return config
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        result = {}
        for key, value in self.__dict__.items():
            if not key.startswith('_'):
                result[key] = value
        return result
    
    def update(self, **kwargs):
        """Update configuration with new values"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                raise ValueError(f"Unknown configuration key: {key}")
        
        # Re-validate after update
        self._validate()
        self._apply_env_overrides()
    
    def get_plugin_config(self, plugin_name: str) -> Dict[str, Any]:
        """Get configuration for a specific plugin"""
        return self.plugins_config.get(plugin_name, {})
    
    def set_plugin_config(self, plugin_name: str, config: Dict[str, Any]):
        """Set configuration for a specific plugin"""
        self.plugins_config[plugin_name] = config
    
    def is_plugin_enabled(self, plugin_name: str) -> bool:
        """Check if a plugin is enabled"""
        return plugin_name in self.plugins
    
    def enable_plugin(self, plugin_name: str, config: Optional[Dict[str, Any]] = None):
        """Enable a plugin"""
        if plugin_name not in self.plugins:
            self.plugins.append(plugin_name)
        
        if config:
            self.set_plugin_config(plugin_name, config)
    
    def disable_plugin(self, plugin_name: str):
        """Disable a plugin"""
        if plugin_name in self.plugins:
            self.plugins.remove(plugin_name)
        
        if plugin_name in self.plugins_config:
            del self.plugins_config[plugin_name]


class ConfigManager:
    """Configuration manager for ErrorShield"""
    
    def __init__(self, config: Optional[ErrorShieldConfig] = None):
        self.config = config or ErrorShieldConfig()
        self._config_sources = []
    
    def add_config_source(self, source: Dict[str, Any]):
        """Add a configuration source (will be applied in order)"""
        self._config_sources.append(source)
        self._rebuild_config()
    
    def _rebuild_config(self):
        """Rebuild configuration from all sources"""
        # Start with defaults
        config_dict = {}
        
        # Apply sources in order
        for source in self._config_sources:
            config_dict.update(source)
        
        # Create new config
        self.config = ErrorShieldConfig.from_dict(config_dict)
    
    def load_from_file(self, file_path: str):
        """Load configuration from file"""
        import json
        import yaml
        
        try:
            with open(file_path, 'r') as f:
                if file_path.endswith('.json'):
                    config_data = json.load(f)
                elif file_path.endswith(('.yml', '.yaml')):
                    config_data = yaml.safe_load(f)
                else:
                    raise ValueError(f"Unsupported config file format: {file_path}")
            
            self.add_config_source(config_data)
        except FileNotFoundError:
            raise FileNotFoundError(f"Configuration file not found: {file_path}")
        except Exception as e:
            raise ValueError(f"Failed to load configuration from {file_path}: {e}")
    
    def load_from_env(self, prefix: str = 'ERRORSHIELD_'):
        """Load configuration from environment variables with prefix"""
        env_config = {}
        
        for key, value in os.environ.items():
            if key.startswith(prefix):
                config_key = key[len(prefix):].lower()
                
                # Try to parse as JSON, fallback to string
                try:
                    env_config[config_key] = json.loads(value)
                except (json.JSONDecodeError, ValueError):
                    env_config[config_key] = value
        
        if env_config:
            self.add_config_source(env_config)
    
    def get_config(self) -> ErrorShieldConfig:
        """Get the current configuration"""
        return self.config
    
    def update_config(self, **kwargs):
        """Update the current configuration"""
        self.config.update(**kwargs)
