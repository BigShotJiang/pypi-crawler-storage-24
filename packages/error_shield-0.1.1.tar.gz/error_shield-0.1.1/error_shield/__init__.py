"""
ErrorShield - Intelligent error handling for Python web applications

Features:
- Adaptive error UI for dev/production
- Local error dashboard
- Plugin system
- Automatic PII scrubbing
- Framework agnostic
"""

__version__ = "0.1.0"
__author__ = "ErrorShield Team"

from .core import ErrorShield, ErrorShieldConfig
from .utils import capture_error, current_error_context, set_business_context

__all__ = [
    "ErrorShield",
    "ErrorShieldConfig",
    "capture_error",
    "current_error_context",
    "set_business_context",
]
