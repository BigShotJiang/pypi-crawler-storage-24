"""
Command line interface for ErrorShield
"""

import argparse
import sys
from . import __version__


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog='error-shield',
        description='ErrorShield - Intelligent error handling for Python web applications'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'ErrorShield {__version__}'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Version command
    version_parser = subparsers.add_parser('version', help='Show version information')
    version_parser.set_defaults(func=show_version)
    
    # Status command
    status_parser = subparsers.add_parser('status', help='Show ErrorShield status')
    status_parser.set_defaults(func=show_status)
    
    # Config command
    config_parser = subparsers.add_parser('config', help='Configuration management')
    config_parser.add_argument('--show', action='store_true', help='Show current configuration')
    config_parser.set_defaults(func=show_config)
    
    # Parse arguments
    args = parser.parse_args()
    
    if args.command:
        args.func(args)
    else:
        parser.print_help()


def show_version(args):
    """Show version information"""
    print(f"ErrorShield version {__version__}")
    print("Intelligent error handling for Python web applications")
    print("https://github.com/errorshield/errorshield")


def show_status(args):
    """Show ErrorShield status"""
    print("ErrorShield Status:")
    print("  ✅ Core module: Ready")
    print("  ✅ Flask integration: Available")
    print("  ✅ Plugin system: Ready")
    print("  ✅ Dashboard: Available")
    print("  ✅ Configuration: Ready")
    print("\nTo use ErrorShield in your application:")
    print("  from error_shield import ErrorShield")
    print("  ErrorShield(app)")


def show_config(args):
    """Show configuration information"""
    from .config import ErrorShieldConfig
    
    config = ErrorShieldConfig()
    
    print("ErrorShield Configuration:")
    print(f"  Mode: {config.mode}")
    print(f"  Production: {config.is_production}")
    print(f"  Error context size: {config.error_context_size}")
    print(f"  Dashboard enabled: {config.enable_local_dashboard}")
    print(f"  Dashboard port: {config.dashboard_port}")
    print(f"  Plugins: {config.plugins}")
    print(f"  Sanitize fields: {config.sanitize_fields}")
    
    print("\nEnvironment variables:")
    import os
    env_vars = [k for k in os.environ.keys() if k.startswith('ERRORSHIELD_')]
    if env_vars:
        for var in sorted(env_vars):
            print(f"  {var}: {os.environ[var]}")
    else:
        print("  No ErrorShield environment variables set")


if __name__ == '__main__':
    main()
