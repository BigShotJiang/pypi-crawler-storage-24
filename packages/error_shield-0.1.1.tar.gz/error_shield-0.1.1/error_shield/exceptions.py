"""
Custom exceptions for ErrorShield
"""


class ErrorShieldError(Exception):
    """Base exception for all ErrorShield errors"""
    
    def __init__(self, message: str, error_code: str = None, context: dict = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.context = context or {}
    
    def __str__(self):
        if self.error_code:
            return f"[{self.error_code}] {self.message}"
        return self.message


class ConfigurationError(ErrorShieldError):
    """Raised when there's an error in ErrorShield configuration"""
    
    def __init__(self, message: str, config_key: str = None, **kwargs):
        super().__init__(message, error_code="CONFIG_ERROR", **kwargs)
        self.config_key = config_key


class PluginError(ErrorShieldError):
    """Raised when there's an error with a plugin"""
    
    def __init__(self, message: str, plugin_name: str = None, **kwargs):
        super().__init__(message, error_code="PLUGIN_ERROR", **kwargs)
        self.plugin_name = plugin_name


class DashboardError(ErrorShieldError):
    """Raised when there's an error with the dashboard"""
    
    def __init__(self, message: str, **kwargs):
        super().__init__(message, error_code="DASHBOARD_ERROR", **kwargs)


class SanitizationError(ErrorShieldError):
    """Raised when there's an error during data sanitization"""
    
    def __init__(self, message: str, data_type: str = None, **kwargs):
        super().__init__(message, error_code="SANITIZATION_ERROR", **kwargs)
        self.data_type = data_type


class TemplateError(ErrorShieldError):
    """Raised when there's an error with UI templates"""
    
    def __init__(self, message: str, template_name: str = None, **kwargs):
        super().__init__(message, error_code="TEMPLATE_ERROR", **kwargs)
        self.template_name = template_name


class ContextError(ErrorShieldError):
    """Raised when there's an error with error context"""
    
    def __init__(self, message: str, context_id: str = None, **kwargs):
        super().__init__(message, error_code="CONTEXT_ERROR", **kwargs)
        self.context_id = context_id


class RateLimitError(ErrorShieldError):
    """Raised when rate limiting is triggered"""
    
    def __init__(self, message: str = "Rate limit exceeded", limit: int = None, window: int = None, **kwargs):
        super().__init__(message, error_code="RATE_LIMIT_ERROR", **kwargs)
        self.limit = limit
        self.window = window


class ValidationError(ErrorShieldError):
    """Raised when data validation fails"""
    
    def __init__(self, message: str, field: str = None, value: any = None, **kwargs):
        super().__init__(message, error_code="VALIDATION_ERROR", **kwargs)
        self.field = field
        self.value = value


class NotificationError(ErrorShieldError):
    """Raised when notification sending fails"""
    
    def __init__(self, message: str, notification_type: str = None, recipient: str = None, **kwargs):
        super().__init__(message, error_code="NOTIFICATION_ERROR", **kwargs)
        self.notification_type = notification_type
        self.recipient = recipient


class IntegrationError(ErrorShieldError):
    """Raised when external integration fails"""
    
    def __init__(self, message: str, service: str = None, **kwargs):
        super().__init__(message, error_code="INTEGRATION_ERROR", **kwargs)
        self.service = service


# Warning exceptions (don't stop execution but should be logged)
class ErrorShieldWarning(Warning):
    """Base warning for ErrorShield"""
    pass


class ConfigurationWarning(ErrorShieldWarning):
    """Warning about configuration issues"""
    pass


class PluginWarning(ErrorShieldWarning):
    """Warning about plugin issues"""
    pass


class DeprecationWarning(ErrorShieldWarning):
    """Warning about deprecated features"""
    pass


# Utility function to create standardized error responses
def create_error_response(
    error_type: str,
    message: str,
    error_code: str = None,
    context: dict = None,
    **kwargs
) -> ErrorShieldError:
    """Factory function to create standardized error responses"""
    
    error_classes = {
        'configuration': ConfigurationError,
        'plugin': PluginError,
        'dashboard': DashboardError,
        'sanitization': SanitizationError,
        'template': TemplateError,
        'context': ContextError,
        'rate_limit': RateLimitError,
        'validation': ValidationError,
        'notification': NotificationError,
        'integration': IntegrationError,
    }
    
    error_class = error_classes.get(error_type.lower(), ErrorShieldError)
    return error_class(message, error_code=error_code, context=context, **kwargs)


# Decorator for error handling
def handle_error_shield_errors(default_return=None, log_errors=True):
    """Decorator to handle ErrorShield errors gracefully"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except ErrorShieldError as e:
                if log_errors:
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.error(f"ErrorShield error in {func.__name__}: {e}")
                
                if default_return is not None:
                    return default_return
                raise
            except Exception as e:
                if log_errors:
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.error(f"Unexpected error in {func.__name__}: {e}")
                
                if default_return is not None:
                    return default_return
                raise
        return wrapper
    return decorator
