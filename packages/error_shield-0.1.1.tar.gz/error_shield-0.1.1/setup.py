"""
Setup script for ErrorShield
"""

from setuptools import setup, find_packages
import os

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
def read_requirements():
    requirements = []
    if os.path.exists('requirements.txt'):
        with open('requirements.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('-'):
                    # Only include core dependencies, not dev dependencies
                    if any(pkg in line for pkg in ['Flask', 'psutil', 'PyYAML']):
                        requirements.append(line)
    return requirements

setup(
    name="error-shield",
    version="0.1.0",
    author="ErrorShield Team",
    author_email="team@errorshield.dev",
    description="Intelligent error handling for Python web applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/errorshield/errorshield",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
        "Topic :: System :: Monitoring",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dashboard": ["Flask>=2.0.0"],
        "memory": ["psutil>=5.8.0"],
        "config": ["PyYAML>=6.0"],
        "full": [
            "Flask>=2.0.0",
            "psutil>=5.8.0",
            "PyYAML>=6.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
            "sphinx>=5.0.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "error-shield=error_shield.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "error_shield": [
            "ui/templates/*.html",
            "ui/static/css/*.css",
            "ui/static/js/*.js",
            "dashboard/templates/*.html",
        ],
    },
    keywords=[
        "error handling",
        "debugging",
        "monitoring",
        "logging",
        "flask",
        "web development",
        "error tracking",
        "production",
        "development",
    ],
    project_urls={
        "Bug Reports": "https://github.com/errorshield/errorshield/issues",
        "Source": "https://github.com/errorshield/errorshield",
        "Documentation": "https://docs.errorshield.dev",
    },
)
