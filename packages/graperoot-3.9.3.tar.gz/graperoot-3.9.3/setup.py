"""Cython build configuration for graperoot.

Compiles core .py modules to native C extensions when Cython and a C compiler
are available. Falls back to pure Python automatically — no compiler required.
"""
import os
import sys
from setuptools import setup

COMPILED_MODULES = [
    "graph_builder",
    "dg",
    "context_packer",
    "dgc_claude",
]

# Try to build Cython extensions; gracefully degrade to pure Python if
# Cython or a C compiler is not available (common on Linux without build-essential,
# macOS without Xcode CLT, or Windows without MSVC).
extensions = []
try:
    from Cython.Build import cythonize
    from setuptools import Extension
    from setuptools.command.build_ext import build_ext as _build_ext

    _modules = [
        Extension(
            name=f"graperoot.{m}",
            sources=[f"src/graperoot/{m}.py"],
        )
        for m in COMPILED_MODULES
    ]

    class build_ext(_build_ext):
        """After building, remove .py and .c files from build dir (keep only .so/.pyd)."""
        def run(self):
            super().run()
            import glob
            pkg_dir = os.path.join(self.build_lib, "graperoot")
            if not os.path.isdir(pkg_dir):
                return
            for name in COMPILED_MODULES:
                # Only strip .py if the compiled extension was actually built
                compiled = (
                    glob.glob(os.path.join(pkg_dir, f"{name}*.pyd")) +
                    glob.glob(os.path.join(pkg_dir, f"{name}*.so"))
                )
                if compiled:
                    for ext in (".py", ".c"):
                        f = os.path.join(pkg_dir, f"{name}{ext}")
                        if os.path.exists(f):
                            os.remove(f)

        def build_extensions(self):
            try:
                super().build_extensions()
            except Exception:
                # Compiler not available — skip extension build, pure Python will be used
                pass

    extensions = cythonize(
        _modules,
        compiler_directives={
            "language_level": "3",
            "embedsignature": False,
            "emit_code_comments": False,
        },
        nthreads=0,
    )
    cmdclass = {"build_ext": build_ext}
except Exception:
    # Cython not installed or failed to import — pure Python install
    cmdclass = {}

setup(
    ext_modules=extensions,
    cmdclass=cmdclass,
)
