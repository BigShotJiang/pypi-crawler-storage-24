#!/Users/krishnakant/.dual-graph/venv/bin/python3
"""DGC pre-injection wrapper — runs graph retrieval BEFORE Claude starts.

Takes a user query, packs context from the dual-graph, then launches
`claude -p` with the packed context prepended.  Claude runs with ZERO
MCP tools — only native Read/Grep/Bash.

Usage:
    dgc-claude "Explain the auth flow"
    dgc-claude --budget 4000 --max-files 10 "Design a loyalty system"
    dgc-claude --json "Find the bug in orders"
    dgc-claude --project-root /path/to/project "query"
    dgc-claude --dry-run "query"
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# Ensure bin/ is on sys.path so sibling modules are importable.
_BIN_DIR = Path(__file__).resolve().parent
if str(_BIN_DIR) not in sys.path:
    sys.path.insert(0, str(_BIN_DIR))

from graperoot.context_packer import estimate_tokens, pack, load_summaries
from graperoot.dg import load_graph, retrieve, classify_intent
from graperoot.graph_builder import scan


def _ensure_graph(project_root: Path) -> dict:
    """Load the graph, building it automatically if it doesn't exist yet."""
    from graperoot.dg import GRAPH_JSON, DATA_DIR

    if GRAPH_JSON.exists():
        return load_graph()

    print(f"[dgc] No graph found — scanning {project_root} ...", file=sys.stderr)
    t0 = time.time()
    g = scan(project_root)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    import json
    GRAPH_JSON.write_text(json.dumps(g, indent=2), encoding="utf-8")
    elapsed = time.time() - t0
    print(
        f"[dgc] Graph built in {elapsed:.1f}s: "
        f"{g.get('node_count', '?')} nodes, {g.get('edge_count', '?')} edges",
        file=sys.stderr,
    )
    return g


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="dgc-claude",
        description="Pre-injection wrapper: graph retrieval → packed context → claude -p",
    )
    p.add_argument(
        "query",
        nargs="*",
        help="The user's question (all positional args joined with spaces)",
    )
    p.add_argument(
        "--project-root", "-r",
        default=".",
        help="Project root directory (default: current dir)",
    )
    p.add_argument(
        "--budget", "-b",
        type=int,
        default=5000,
        help="Token budget for the context pack (default: 5000)",
    )
    p.add_argument(
        "--max-files",
        type=int,
        default=8,
        help="Max files included in context (default: 8)",
    )
    p.add_argument(
        "--model", "-m",
        default="claude-sonnet-4-6",
        help="Claude model to use (default: claude-sonnet-4-6)",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Add --output-format json (for benchmarks)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the packed context and exit (don't launch Claude)",
    )
    p.add_argument(
        "--no-permissions",
        action="store_true",
        help="Add --dangerously-skip-permissions (for benchmarks)",
    )
    p.add_argument(
        "--no-session",
        action="store_true",
        help="Add --no-session-persistence (for benchmarks)",
    )
    p.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print pack timing and token estimate to stderr",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    query = " ".join(args.query).strip()

    if not query:
        print("Usage: dgc-claude [OPTIONS] \"your question here\"", file=sys.stderr)
        print("Run dgc-claude --help for full options.", file=sys.stderr)
        return 1

    root = Path(args.project_root).resolve()
    if not root.is_dir():
        print(f"[dgc] Error: project root does not exist: {root}", file=sys.stderr)
        return 1

    # ── Step 1: Build / load graph ────────────────────────────────────────
    try:
        graph = _ensure_graph(root)
    except Exception as exc:
        print(f"[dgc] Error loading graph: {exc}", file=sys.stderr)
        return 1

    # ── Step 2: Retrieve + pack context ───────────────────────────────────
    t0 = time.time()
    result = retrieve(graph, query, top_files=args.max_files, top_edges=40)
    summaries = load_summaries(root)
    context = pack(
        retrieve_result=result,
        summaries=summaries,
        graph=graph,
        project_root=root,
        token_budget=args.budget,
        max_files=args.max_files,
    )
    pack_time = time.time() - t0

    if args.verbose:
        tokens_est = estimate_tokens(context)
        print(
            f"[dgc] Context packed in {pack_time:.2f}s (~{tokens_est} tokens)",
            file=sys.stderr,
        )

    if args.dry_run:
        print(context)
        return 0

    # ── Step 3: Verify claude binary exists ────────────────────────────────
    claude_bin = shutil.which("claude")
    if claude_bin is None:
        print(
            "[dgc] Error: 'claude' binary not found in PATH.\n"
            "Install Claude Code CLI: https://docs.anthropic.com/en/docs/claude-code",
            file=sys.stderr,
        )
        return 1

    # ── Step 4: Build full prompt and launch ──────────────────────────────
    full_prompt = (
        f"{context}\n\n---\n\n"
        f"User question: {query}\n\n"
        f"Instructions: Answer thoroughly using the pre-loaded context above. "
        f"Include relevant code snippets in your response when they help explain the answer. "
        f"Reference specific file paths and line numbers. Do not edit any files."
    )

    cmd = ["claude", "-p", full_prompt, "--model", args.model]
    if args.json:
        cmd.extend(["--output-format", "json"])
    if args.no_permissions:
        cmd.append("--dangerously-skip-permissions")
    if args.no_session:
        cmd.append("--no-session-persistence")

    # Remove env vars that could cause nested-session issues.
    env = os.environ.copy()
    env.pop("CLAUDECODE", None)
    env.pop("CLAUDE_CODE_SESSION", None)

    if args.verbose:
        print(f"[dgc] Launching: claude -p ... --model {args.model}", file=sys.stderr)

    # Replace current process with claude.
    os.execvpe("claude", cmd, env)

    # execvpe never returns on success; if we get here something went wrong.
    return 1  # pragma: no cover


if __name__ == "__main__":
    raise SystemExit(main())
