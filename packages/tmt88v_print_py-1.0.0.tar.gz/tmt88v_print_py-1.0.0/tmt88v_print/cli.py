"""
CLI entry point: tmt88v-print-py <image> [options]
"""

import os
import sys
import time
from pathlib import Path

from .core import image_to_escpos
from .dither import DitherAlgo

DEVICE_WRITE_CHUNK = 1024
DEVICE_WRITE_DELAY = 0.018  # 18 ms; uniform delay, no extra pause at strip boundaries


def write_to_device_in_chunks(device: str, data: bytes) -> None:
    with open(device, "wb") as f:
        offset = 0
        while offset < len(data):
            chunk = data[offset : offset + DEVICE_WRITE_CHUNK]
            f.write(chunk)
            offset += len(chunk)
            if offset < len(data):
                time.sleep(DEVICE_WRITE_DELAY)

DITHER_VALUES: tuple[DitherAlgo, ...] = ("none", "floyd-steinberg", "ordered", "atkinson")
FIT_VALUES = ("inside", "fill", "stretch")


def main() -> None:
    argv = [a for a in sys.argv[1:] if a != ""]
    args = [a for a in argv if not a.startswith("--")]
    device = os.environ.get("PRINTER_DEVICE", "/dev/usb/lp2")
    chunk_height = 400
    output_path: str | None = None
    width = 512
    fit: str = "inside"
    dither: DitherAlgo = "none"
    threshold = 128

    i = 0
    while i < len(argv):
        if argv[i] == "--device" and i + 1 < len(argv):
            device = argv[i + 1]
            i += 2
            continue
        if argv[i] == "--chunk" and i + 1 < len(argv):
            chunk_height = int(argv[i + 1], 10)
            i += 2
            continue
        if argv[i] == "--output" and i + 1 < len(argv):
            output_path = argv[i + 1]
            i += 2
            continue
        if argv[i] == "--width" and i + 1 < len(argv):
            width = int(argv[i + 1], 10)
            i += 2
            continue
        if argv[i] == "--fit" and i + 1 < len(argv):
            v = argv[i + 1].lower()
            if v in FIT_VALUES:
                fit = v
            i += 2
            continue
        if argv[i] == "--dither" and i + 1 < len(argv):
            v = argv[i + 1].lower().replace("–", "-").replace("—", "-")
            if v in DITHER_VALUES:
                dither = v
            i += 2
            continue
        if argv[i] == "--threshold" and i + 1 < len(argv):
            threshold = int(argv[i + 1], 10)
            i += 2
            continue
        i += 1

    if not args:
        print(
            "Usage: tmt88v-print-py <image> [--device PATH] [--chunk N] [--output FILE] [--width N] [--fit inside|fill|stretch] [--dither none|floyd-steinberg|ordered|atkinson] [--threshold N]",
            file=sys.stderr,
        )
        sys.exit(1)

    image_path = Path(args[0]).resolve()
    if not image_path.is_file():
        print("File not found:", image_path, file=sys.stderr)
        sys.exit(1)

    try:
        escpos = image_to_escpos(
            str(image_path),
            chunk_height=chunk_height,
            width=width,
            fit=fit,
            dither=dither,
            threshold=threshold,
        )
        if output_path:
            Path(output_path).write_bytes(escpos)
            print("Wrote ESC/POS to", output_path, "(" + str(len(escpos)), "bytes)", file=sys.stderr)
        else:
            write_to_device_in_chunks(device, escpos)
            print("Sent to", device, file=sys.stderr)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
