"""
ESC/POS raster generation for TM-T88V: resize, binarize (dither or threshold), chunk, encode.
"""

import struct
from pathlib import Path
from typing import Literal

from PIL import Image, ImageOps

from .dither import DitherAlgo, to_1bit

PRINT_WIDTH = 512  # TM-T88V: 72mm printable = 512 dots

FitMode = Literal["inside", "fill", "stretch"]


def _load_image(image: str | Path | Image.Image) -> Image.Image:
    if isinstance(image, Image.Image):
        return image.convert("L")
    return Image.open(image).convert("L")


def _resize(im: Image.Image, width: int, fit: FitMode, height: int | None) -> Image.Image:
    w, h = im.size
    if fit == "inside":
        new_h = height if height is not None else round(h * width / w)
        return im.resize((width, new_h), Image.Resampling.LANCZOS)
    if fit == "fill":
        new_h = height if height is not None else round(h * width / w)
        return ImageOps.fit(im, (width, new_h), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
    # stretch
    new_h = height if height is not None else round(h * width / w)
    return im.resize((width, new_h), Image.Resampling.LANCZOS)


def image_to_escpos(
    image: str | Path | Image.Image,
    *,
    chunk_height: int = 0,
    width: int = PRINT_WIDTH,
    fit: FitMode = "inside",
    height: int | None = None,
    dither: DitherAlgo = "none",
    threshold: int = 128,
) -> bytes:
    """
    Convert image to ESC/POS raster bytes (GS v 0).
    """
    im = _load_image(image)
    im = _resize(im, width, fit, height)
    w, h = im.size

    arr = list(im.getdata())
    lo, hi = min(arr), max(arr)
    if hi > lo:
        span = hi - lo
        arr = [round(255 * (x - lo) / span) for x in arr]
    # Invert so that with raster XOR we get correct image (TM-T88V prints full with this stream)
    arr = [255 - x for x in arr]

    bits = to_1bit(arr, w, h, dither, threshold)
    # Pack to bytes MSB first; thermal: 1 = burn, so bit value 1 stays 1
    width_bytes = (w + 7) // 8
    pad_w = width_bytes * 8
    out = bytearray()
    for y in range(h):
        for byte_x in range(width_bytes):
            b = 0
            for i in range(8):
                x = byte_x * 8 + i
                if x < w and bits[y * w + x]:
                    b |= 128 >> i
            out.append(b)

    # XOR raster: stream that worked without EIO; combined with pre-invert gives correct image
    for i in range(len(out)):
        out[i] ^= 0xFF

    # Invert for thermal (we stored 1=black; PIL/ESC-POS often expect 1=print)
    # Our dither outputs 1 = burn (black). ESC/POS raster: 1 = dot. So we're good; no invert.
    # Actually in original png_to_escpos we did invert. So printer expects 0 = burn? Check: we had
    # im = PIL.ImageOps.invert(im.convert("L")).convert("1") so we inverted. So 0 in original
    # image (white) -> 255 after stretch -> 0 after threshold -> then we inverted to 1? No:
    # original was "soglia: nero sotto 128, bianco sopra (termica: invertiamo dopo)". So black
    # in image -> 0 after threshold -> invert -> 1. So for thermal, 1 = burn. Our to_1bit returns
    # 1 for black (v < threshold). So we don't invert the bits; we send 1 = black. Same as TS.
    # (TS: v = stretched >= 128 ? 0 : 1 so 1 = black. Good.)

    result = bytearray()
    result.extend(b"\x1b\x40")  # init

    if chunk_height and h > chunk_height:
        y = 0
        while y < h:
            strip_h = min(chunk_height, h - y)
            result.extend(b"\x1d\x76\x30\x00")
            result.extend(struct.pack("<H", width_bytes))
            result.extend(struct.pack("<H", strip_h))
            start = y * width_bytes
            result.extend(out[start : start + strip_h * width_bytes])
            y += strip_h
    else:
        result.extend(b"\x1d\x76\x30\x00")
        result.extend(struct.pack("<H", width_bytes))
        result.extend(struct.pack("<H", h))
        result.extend(out)

    # ESC d 5 = feed 5 lines so last printed line passes cutter, then partial cut
    result.extend(b"\x1b\x64\x05\x1d\x56\x00")
    return bytes(result)


def print_image(
    image_path: str | Path,
    *,
    device: str | None = None,
    chunk_height: int = 400,
    width: int = PRINT_WIDTH,
    fit: FitMode = "inside",
    height: int | None = None,
    dither: DitherAlgo = "none",
    threshold: int = 128,
) -> None:
    """
    Generate ESC/POS and write to device in small chunks with uniform delay (no strip-boundary pause).
    """
    import os
    import time
    dev = device or os.environ.get("PRINTER_DEVICE", "/dev/usb/lp2")
    data = image_to_escpos(
        image_path,
        chunk_height=chunk_height,
        width=width,
        fit=fit,
        height=height,
        dither=dither,
        threshold=threshold,
    )
    chunk_size = 1024
    delay_s = 0.018
    with open(dev, "wb") as f:
        offset = 0
        while offset < len(data):
            chunk = data[offset : offset + chunk_size]
            f.write(chunk)
            offset += len(chunk)
            if offset < len(data):
                time.sleep(delay_s)
