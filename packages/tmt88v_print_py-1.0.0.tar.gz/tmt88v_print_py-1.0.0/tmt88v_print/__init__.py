"""
tmt88v-print-py – Print images to Epson TM-T88V (80mm, 512 dots) via ESC/POS.
No CUPS/lp: sends directly to device (e.g. /dev/usb/lp2).
"""

from .core import (
    PRINT_WIDTH,
    image_to_escpos,
    print_image,
)
from .dither import DitherAlgo

__all__ = [
    "PRINT_WIDTH",
    "image_to_escpos",
    "print_image",
    "DitherAlgo",
]
