"""
1-bit dithering: none (threshold), Floyd–Steinberg, ordered (Bayer), Atkinson.
"""

from typing import Literal

DitherAlgo = Literal["none", "floyd-steinberg", "ordered", "atkinson"]

# Bayer 4x4
_BAYER_4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
]


def to_1bit(gray_data: list[int], width: int, height: int, algo: DitherAlgo, threshold: int) -> list[int]:
    """Convert grayscale 0–255 to 0/1 (thermal: 1 = burn)."""
    out = [0] * (width * height)
    if algo == "none":
        for i, v in enumerate(gray_data):
            out[i] = 0 if v >= threshold else 1
        return out
    if algo == "ordered":
        for y in range(height):
            for x in range(width):
                bayer_val = (_BAYER_4[y % 4][x % 4] / 16) * 255
                out[y * width + x] = 0 if gray_data[y * width + x] > bayer_val else 1
        return out
    # Mutable float copy for error diffusion
    f = [float(v) for v in gray_data]
    if algo == "floyd-steinberg":
        for y in range(height):
            for x in range(width):
                i = y * width + x
                old = f[i]
                v = 255 if old >= 128 else 0
                out[i] = 0 if v == 255 else 1
                err = old - v
                if x + 1 < width:
                    f[i + 1] += (7 / 16) * err
                if y + 1 < height:
                    if x > 0:
                        f[i + width - 1] += (3 / 16) * err
                    f[i + width] += (5 / 16) * err
                    if x + 1 < width:
                        f[i + width + 1] += (1 / 16) * err
        return out
    if algo == "atkinson":
        for y in range(height):
            for x in range(width):
                i = y * width + x
                old = f[i]
                v = 255 if old >= 128 else 0
                out[i] = 0 if v == 255 else 1
                err = (old - v) / 8
                if x + 1 < width:
                    f[i + 1] += err
                if x + 2 < width:
                    f[i + 2] += err
                if y + 1 < height:
                    if x > 0:
                        f[i + width - 1] += err
                    f[i + width] += err
                    if x + 1 < width:
                        f[i + width + 1] += err
                if y + 2 < height:
                    f[i + 2 * width] += err
        return out
    return out
