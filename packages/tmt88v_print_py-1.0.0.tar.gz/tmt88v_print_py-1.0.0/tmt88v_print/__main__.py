"""Allow running the package with python -m tmt88v_print."""
from .cli import main

if __name__ == "__main__":
    main()
