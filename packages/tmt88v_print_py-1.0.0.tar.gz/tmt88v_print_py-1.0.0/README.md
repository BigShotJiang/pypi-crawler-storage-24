# tmt88v-print-py

![Epson TM-T88V](printer.png)

Print images to **Epson TM-T88V** thermal printer (80 mm) via ESC/POS. Sends data **directly to the device** (e.g. `/dev/usb/lp2`), no CUPS/lp.

- Resolution: 512 dots (72 mm printable width), configurable.
- Resize: `width`, `fit` (inside | fill | stretch), optional `height`.
- Binarization: threshold (default) or dither: `none`, `floyd-steinberg`, `ordered`, `atkinson`.
- Chunked printing for tall images (default 400 px strips).

## Install

```bash
pip install tmt88v-print-py
```

## CLI

```bash
# Print to default device (/dev/usb/lp2)
tmt88v-print-py image.png

# Custom device
tmt88v-print-py image.png --device /dev/usb/lp0

# Save ESC/POS to file
tmt88v-print-py image.png --output out.bin

# Width 384 (58 mm), Floyd–Steinberg dither
tmt88v-print-py photo.jpg --width 384 --dither floyd-steinberg

# Options: --chunk, --width, --fit, --dither, --threshold
```

Use `sudo` if needed: `sudo tmt88v-print-py image.png`

## Local testing (no printer)

Generate a sample image and write ESC/POS to a file:

```bash
pip install -e .
python examples/generate_sample.py
tmt88v-print-py examples/sample.png --output examples/out.bin
```

See [examples/README.md](examples/README.md) for more options and API usage.

## API

```python
from tmt88v_print import image_to_escpos, print_image

# Get ESC/POS bytes
data = image_to_escpos("image.png", chunk_height=400, width=512, dither="none")
with open("/dev/usb/lp2", "wb") as f:
    f.write(data)

# Or print directly
print_image("image.png", device="/dev/usb/lp2", chunk_height=400)
```

## Author

**Pietro Leoni** – [GitHub](https://github.com/piLeoni) · pietro.leoni@gmail.com

## License

MIT – see [LICENSE](LICENSE).
