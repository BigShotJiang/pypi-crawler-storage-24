# clawlink

Reserved by the [ClawNexus](https://github.com/SilverstreamsAI/ClawNexus) project.

ClawNexus is an identity registry for AI agents. Install via npm:

```bash
npm install -g clawnexus
```
