"""Encounter converter: C-CDA Encounter Activity to FHIR Encounter resource."""

from __future__ import annotations

import logging

from ccda_to_fhir.ccda.models.datatypes import CD, CE, IVL_TS, TS
from ccda_to_fhir.ccda.models.encounter import Encounter as CCDAEncounter
from ccda_to_fhir.ccda.models.observation import EntryRelationship
from ccda_to_fhir.constants import (
    CPT_CODE_SYSTEM,
    DISCHARGE_DISPOSITION_TO_FHIR,
    ENCOUNTER_STATUS_TO_FHIR,
    PARTICIPATION_FUNCTION_CODE_MAP,
    V3_ACT_CODE_SYSTEM,
    V3_ACTCODE_DISPLAY_NAMES,
    FHIRCodes,
    FHIRSystems,
    TemplateIds,
    map_cpt_to_actcode,
)
from ccda_to_fhir.types import (
    DiagnosisRole,
    FHIRCodeableConcept,
    FHIRResourceDict,
    JSONObject,
    ReasonResult,
)

from .author_references import format_person_display
from .base import BaseConverter

logger = logging.getLogger(__name__)


class EncounterConverter(BaseConverter[CCDAEncounter]):
    """Convert C-CDA Encounter Activity to FHIR Encounter resource.

    This converter handles the mapping from C-CDA Encounter Activity
    to a FHIR R4B Encounter resource, including status, class, type, and period.

    Reference: https://build.fhir.org/ig/HL7/CDA-ccda/StructureDefinition-EncounterActivity.html
    """

    def __init__(self, code_system_mapper=None, reference_registry=None):
        """Initialize the encounter converter.

        Args:
            code_system_mapper: Optional code system mapper
            reference_registry: Optional reference registry for tracking converted resources
        """
        super().__init__(code_system_mapper, reference_registry)
        # Track resources created during conversion that need to be added to bundle
        self._pending_practitioners: list[FHIRResourceDict] = []
        self._pending_locations: list[FHIRResourceDict] = []

    def convert(self, ccda_model: CCDAEncounter, section=None) -> FHIRResourceDict:
        """Convert a C-CDA Encounter Activity to a FHIR Encounter resource.

        Args:
            ccda_model: The C-CDA Encounter Activity
            section: The C-CDA Section containing this encounter (for narrative)

        Returns:
            FHIR Encounter resource as a dictionary

        Raises:
            ValueError: If the encounter lacks required data
        """
        encounter = ccda_model  # Alias for readability
        fhir_encounter: JSONObject = {
            "resourceType": FHIRCodes.ResourceTypes.ENCOUNTER,
        }

        # Generate ID from encounter identifier (skip nullFlavor entries)
        # Find first valid identifier
        root = None
        extension = None
        if encounter.id:
            for id_elem in encounter.id:
                if not id_elem.null_flavor and (id_elem.root or id_elem.extension):
                    root = id_elem.root
                    extension = id_elem.extension
                    break

        # Generate fallback context if no valid identifiers
        fallback_context = ""
        if root is None and extension is None:
            # Create deterministic context from encounter properties
            context_parts = []
            if encounter.code and encounter.code.code:
                context_parts.append(encounter.code.code)
            if encounter.effective_time:
                # Use low value if available for determinism
                if isinstance(encounter.effective_time, IVL_TS) and encounter.effective_time.low:
                    context_parts.append(str(encounter.effective_time.low.value or ""))
                elif isinstance(encounter.effective_time, TS) and encounter.effective_time.value:
                    context_parts.append(str(encounter.effective_time.value))
            if encounter.status_code and encounter.status_code.code:
                context_parts.append(encounter.status_code.code)
            fallback_context = "-".join(filter(None, context_parts))

        # Always generate an ID (with fallback if needed)
        fhir_encounter["id"] = self.generate_resource_id(
            root=root,
            extension=extension,
            resource_type="encounter",
            fallback_context=fallback_context,
        )

        # Identifiers (skip nullFlavor entries)
        if encounter.id:
            fhir_encounter["identifier"] = [
                self.create_identifier(id_elem.root, id_elem.extension)
                for id_elem in encounter.id
                if not id_elem.null_flavor and id_elem.root
            ]

        # Status - Map from statusCode, with moodCode as fallback
        fhir_encounter["status"] = self._extract_status(encounter)

        # Class - Map from code if V3 ActCode, otherwise default to ambulatory
        fhir_encounter["class"] = self._extract_class(encounter)

        # Subject (patient reference)
        # Patient reference (from recordTarget in document header)
        if not self.reference_registry:
            raise ValueError(
                "reference_registry is required. Cannot create Encounter without patient reference."
            )
        fhir_encounter["subject"] = self.reference_registry.get_patient_reference().to_dict()

        # Type - Convert encounter code to type (if not used for class)
        encounter_type = self._extract_type(encounter)
        if encounter_type:
            fhir_encounter["type"] = [encounter_type.to_dict()]

        # Participant - Extract performers and their roles
        participants = self._extract_participants(encounter)
        if participants:
            fhir_encounter["participant"] = participants

        # Period - Convert effective time to period
        if encounter.effective_time:
            period = self._convert_period(encounter.effective_time)
            if period:
                fhir_encounter["period"] = period

        # Reason codes and references - Extract from indication entry relationships
        reasons = self._extract_reasons(encounter.entry_relationship)
        if reasons.codes:
            fhir_encounter["reasonCode"] = [c.to_dict() for c in reasons.codes]
        if reasons.references:
            fhir_encounter["reasonReference"] = [r.to_dict() for r in reasons.references]

        # Diagnosis - Extract from encounter diagnosis entry relationships
        diagnoses = self._extract_diagnoses(encounter.entry_relationship)
        if diagnoses:
            # Apply intelligent diagnosis role detection based on encounter context
            self._apply_diagnosis_roles(diagnoses, encounter)
            fhir_encounter["diagnosis"] = diagnoses

        # Location - Extract from location participants
        locations = self._extract_locations(encounter)
        if locations:
            fhir_encounter["location"] = locations

        # Hospitalization (discharge disposition)
        hospitalization = self._extract_hospitalization(encounter)
        if hospitalization:
            fhir_encounter["hospitalization"] = hospitalization

        # Narrative (from entry text reference, per C-CDA on FHIR IG)
        narrative = self._generate_narrative(entry=encounter, section=section)
        if narrative:
            fhir_encounter["text"] = narrative

        return fhir_encounter

    def _generate_encounter_id(self, root: str | None, extension: str | None) -> str:
        """Generate a FHIR Encounter ID from C-CDA identifiers.

        Uses base class generate_resource_id with fallback to synthetic ID.

        Args:
            root: The OID or UUID root
            extension: The extension value

        Returns:
            A FHIR-compliant ID string
        """
        return self.generate_resource_id(
            root=root,
            extension=extension,
            resource_type="encounter",
            fallback_context="",
        )

    def _extract_status(self, encounter: CCDAEncounter) -> str:
        """Extract FHIR status from C-CDA encounter.

        Maps from statusCode first, then falls back to moodCode.

        Args:
            encounter: The C-CDA encounter

        Returns:
            FHIR encounter status code
        """
        # First try statusCode - only use if code is in mapping
        if encounter.status_code and encounter.status_code.code:
            status_code = encounter.status_code.code.lower()
            if status_code in ENCOUNTER_STATUS_TO_FHIR:
                return ENCOUNTER_STATUS_TO_FHIR[status_code]

        # Fallback to moodCode
        if encounter.mood_code:
            mood_code = encounter.mood_code.upper()
            if mood_code == "INT":
                return FHIRCodes.EncounterStatus.PLANNED
            elif mood_code == "EVN":
                return FHIRCodes.EncounterStatus.FINISHED

        # Default to finished for documented encounters
        return FHIRCodes.EncounterStatus.FINISHED

    def _extract_class(self, encounter: CCDAEncounter) -> JSONObject:
        """Extract FHIR class from C-CDA encounter code.

        If the encounter code is from V3 ActCode system, use it for class.
        If translations contain V3 ActCode, prefer that over CPT mapping.
        If the encounter code is a CPT code with no V3 translation, map to V3 ActCode per C-CDA on FHIR IG.
        Otherwise, default to ambulatory.

        Args:
            encounter: The C-CDA encounter

        Returns:
            FHIR Coding object for encounter class
        """
        if encounter.code and encounter.code.code:
            # Check if code is from V3 ActCode system
            if encounter.code.code_system == V3_ACT_CODE_SYSTEM:
                # Use standard display name from mapping if available, otherwise fall back to C-CDA display
                standard_display = V3_ACTCODE_DISPLAY_NAMES.get(encounter.code.code)
                display = standard_display if standard_display else encounter.code.display_name

                return {
                    "system": FHIRSystems.V3_ACT_CODE,
                    "code": encounter.code.code,
                    "display": display,
                }

            # Check translations for V3 ActCode FIRST (before CPT mapping)
            # Per C-CDA on FHIR IG, explicit V3 ActCode translations should be preferred
            if encounter.code.translation:
                for trans in encounter.code.translation:
                    trans_system = None
                    trans_code = None
                    trans_display = None

                    if isinstance(trans, dict):
                        trans_system = trans.get("code_system")
                        trans_code = trans.get("code")
                        trans_display = trans.get("display_name")
                    else:
                        trans_system = trans.code_system
                        trans_code = trans.code
                        trans_display = trans.display_name

                    if trans_system == V3_ACT_CODE_SYSTEM and trans_code:
                        # Use standard display name from mapping if available
                        standard_display = V3_ACTCODE_DISPLAY_NAMES.get(trans_code)
                        display = standard_display if standard_display else trans_display

                        return {
                            "system": FHIRSystems.V3_ACT_CODE,
                            "code": trans_code,
                            "display": display,
                        }

            # Check if code is CPT and map to V3 ActCode
            # Only applies if no V3 ActCode translation was found above
            # Reference: docs/mapping/08-encounter.md lines 77-86
            if encounter.code.code_system == CPT_CODE_SYSTEM:
                mapped_actcode = map_cpt_to_actcode(encounter.code.code)
                if mapped_actcode:
                    # Use standard display name from mapping
                    display = V3_ACTCODE_DISPLAY_NAMES.get(mapped_actcode)
                    return {
                        "system": FHIRSystems.V3_ACT_CODE,
                        "code": mapped_actcode,
                        "display": display,
                    }

        # Default to ambulatory
        return {
            "system": FHIRSystems.V3_ACT_CODE,
            "code": FHIRCodes.EncounterClass.AMBULATORY,
        }

    def _extract_type(self, encounter: CCDAEncounter) -> FHIRCodeableConcept | None:
        """Extract FHIR type from C-CDA encounter code.

        If the encounter code is NOT from V3 ActCode (since that's used for class),
        convert it to type.

        Args:
            encounter: The C-CDA encounter

        Returns:
            FHIR CodeableConcept for encounter type, or None
        """
        if not encounter.code or not encounter.code.code:
            return None

        # If code is from V3 ActCode, don't use it for type (it's used for class)
        if encounter.code.code_system == V3_ACT_CODE_SYSTEM:
            return None

        return self._convert_code(encounter.code)

    def _convert_code(self, code: CD) -> FHIRCodeableConcept | None:
        """Convert C-CDA encounter code to FHIR CodeableConcept model.

        Args:
            code: The C-CDA encounter code

        Returns:
            FHIRCodeableConcept or None
        """
        return self.convert_code_to_codeable_concept(code)

    def _convert_period(self, effective_time) -> JSONObject | None:
        """Convert C-CDA effectiveTime to FHIR Period.

        Args:
            effective_time: The C-CDA effectiveTime (can be IVL_TS or simple value)

        Returns:
            FHIR Period or None
        """
        if isinstance(effective_time, str):
            # Simple datetime value - use as start
            converted = self.convert_date(effective_time)
            if converted:
                return {"start": converted}

        period: JSONObject = {}

        # Handle IVL_TS
        if isinstance(effective_time, IVL_TS):
            # Check for point-in-time (IVL_TS with direct value attribute)
            if effective_time.value:
                converted = self.convert_date(effective_time.value)
                if converted:
                    return {"start": converted}

            # Handle period with low/high
            if effective_time.low:
                low_value = effective_time.low.value if effective_time.low.value else None
                if low_value:
                    converted_low = self.convert_date(str(low_value))
                    if converted_low:
                        period["start"] = converted_low

            if effective_time.high:
                high_value = effective_time.high.value if effective_time.high.value else None
                if high_value:
                    converted_high = self.convert_date(str(high_value))
                    if converted_high:
                        period["end"] = converted_high

            return period if period else None

        # Handle single value (TS type)
        if isinstance(effective_time, TS) and effective_time.value:
            converted = self.convert_date(effective_time.value)
            if converted:
                period["start"] = converted

        return period if period else None

    def _extract_participants(self, encounter: CCDAEncounter) -> list[JSONObject]:
        """Extract FHIR participants from C-CDA performers and create related resources.

        Creates Practitioner resources inline for participants that don't already exist
        in the reference registry. Follows the pattern used for Device creation.

        Args:
            encounter: The C-CDA encounter

        Returns:
            List of FHIR participant objects
        """
        from ccda_to_fhir.converters.practitioner import PractitionerConverter

        participants = []

        if not encounter.performer:
            return participants

        for performer in encounter.performer:
            participant: JSONObject = {}

            # Extract participant type from functionCode
            # Map C-CDA ParticipationFunction codes to FHIR ParticipationType codes
            # Reference: docs/mapping/08-encounter.md lines 217-223
            # Reference: docs/mapping/09-participations.md lines 217-232
            if performer.function_code:
                function_code = performer.function_code.code

                # Map known function codes (PCP→PPRF, ATTPHYS→ATND, ANEST→SPRF, etc.)
                mapped_code = (
                    PARTICIPATION_FUNCTION_CODE_MAP.get(
                        function_code,
                        function_code,  # Pass through if not in map
                    )
                    if function_code
                    else "PART"
                )  # Default to PART if no code

                type_coding = {
                    "system": FHIRSystems.V3_PARTICIPATION_TYPE,
                    "code": mapped_code,
                    "display": performer.function_code.display_name,
                }
                participant["type"] = [{"coding": [type_coding]}]
            else:
                # Default to PART (participant) if no function code specified
                participant["type"] = [
                    {
                        "coding": [
                            {
                                "system": FHIRSystems.V3_PARTICIPATION_TYPE,
                                "code": "PART",
                                "display": "participant",
                            }
                        ]
                    }
                ]

            # Extract individual reference from assignedEntity
            # Create Practitioner resource if it doesn't already exist
            # Prefer NPI (2.16.840.1.113883.4.6) over other identifiers for consistency
            # Only process if participant represents a person (has assigned_person)
            # Per C-CDA: assignedEntity can be just an organization without a person
            if performer.assigned_entity and performer.assigned_entity.assigned_person:
                assigned_entity = performer.assigned_entity

                # Generate practitioner ID from NPI or other identifiers
                # Prefer NPI for consistency
                if assigned_entity.id:
                    npi_id = None
                    first_id = None

                    for id_elem in assigned_entity.id:
                        if id_elem.root:
                            if not first_id:
                                first_id = id_elem
                            # Prefer NPI identifier
                            if id_elem.root == "2.16.840.1.113883.4.6":
                                npi_id = id_elem
                                break

                    # Use NPI if available, otherwise use first identifier
                    selected_id = npi_id if npi_id else first_id
                    if selected_id:
                        practitioner_id = self._generate_practitioner_id(
                            selected_id.root, selected_id.extension
                        )

                        # Check if resource already exists in reference registry
                        if self.reference_registry and not self.reference_registry.has_resource(
                            "Practitioner", practitioner_id
                        ):
                            # Create Practitioner resource
                            pract_converter = PractitionerConverter(
                                code_system_mapper=self.code_system_mapper
                            )
                            practitioner = pract_converter.convert(assigned_entity)
                            practitioner["id"] = practitioner_id

                            # Store for later addition to bundle
                            self._pending_practitioners.append(practitioner)

                            # Register with reference registry
                            if self.reference_registry:
                                self.reference_registry.register_resource(practitioner)

                        # Add reference to participant with display
                        individual_ref: JSONObject = {"reference": f"urn:uuid:{practitioner_id}"}
                        display = format_person_display(assigned_entity.assigned_person)
                        if display:
                            individual_ref["display"] = display
                        participant["individual"] = individual_ref

            if participant:
                participants.append(participant)

        return participants

    def _extract_locations(self, encounter: CCDAEncounter) -> list[JSONObject]:
        """Extract FHIR locations from C-CDA location participants and create related resources.

        Creates Location resources inline for locations that don't already exist
        in the reference registry. Follows the pattern used for Device creation.

        Args:
            encounter: The C-CDA encounter

        Returns:
            List of FHIR location objects
        """
        from ccda_to_fhir.converters.location import LocationConverter

        locations = []

        if not encounter.participant:
            return locations

        for participant in encounter.participant:
            # Look for location participants (typeCode="LOC")
            if participant.type_code == "LOC":
                location: JSONObject = {}

                # Extract location reference and display
                if participant.participant_role:
                    role = participant.participant_role

                    # Extract location name from playingEntity (needed for synthetic ID)
                    display = None
                    if role.playing_entity:
                        entity = role.playing_entity
                        if entity.name:
                            if isinstance(entity.name, str):
                                display = entity.name
                            elif isinstance(entity.name, list) and len(entity.name) > 0:
                                # Handle list of ON objects
                                first_name = entity.name[0]
                                if first_name.value:
                                    display = first_name.value
                            elif entity.name.value:
                                display = entity.name.value

                    # Extract address data (needed for synthetic ID)
                    address_for_id = None
                    if role.addr:
                        addr_raw = role.addr[0] if isinstance(role.addr, list) else role.addr
                        # Build simple address dict for ID generation
                        address_for_id = {}
                        if addr_raw.city:
                            address_for_id["city"] = addr_raw.city
                        if addr_raw.state:
                            address_for_id["state"] = addr_raw.state
                        if addr_raw.street_address_line:
                            # street_address_line is a list, use first element
                            address_for_id["line"] = (
                                [addr_raw.street_address_line[0]]
                                if addr_raw.street_address_line
                                else []
                            )

                    # Generate location ID from role ID, or create synthetic ID if missing
                    location_id = None
                    if role.id:
                        for id_elem in role.id:
                            if id_elem.root:
                                location_id = self._generate_location_id(
                                    id_elem.root, id_elem.extension
                                )
                                break

                    # Generate synthetic ID if no explicit ID
                    if not location_id and display:
                        location_id = self._generate_synthetic_location_id(display, address_for_id)

                    # Create location reference if we have a valid ID
                    if location_id:
                        # Check if resource already exists in reference registry
                        if self.reference_registry and not self.reference_registry.has_resource(
                            "Location", location_id
                        ):
                            # Create Location resource
                            loc_converter = LocationConverter(
                                code_system_mapper=self.code_system_mapper
                            )
                            location_resource = loc_converter.convert(role)
                            location_resource["id"] = location_id

                            # Store for later addition to bundle
                            self._pending_locations.append(location_resource)

                            # Register with reference registry
                            if self.reference_registry:
                                self.reference_registry.register_resource(location_resource)

                        # Add reference to encounter location
                        location["location"] = {"reference": f"urn:uuid:{location_id}"}
                        if display:
                            location["location"]["display"] = display

                        # Extract period from participant time
                        period = None
                        if participant.time:
                            period = self._convert_period(participant.time)
                            if period:
                                location["period"] = period

                        # Determine status based on participant time and encounter status
                        location["status"] = self._determine_location_status(
                            participant, period, encounter
                        )

                        if location:
                            locations.append(location)

        return locations

    def _determine_location_status(
        self, participant, period: JSONObject | None, encounter: CCDAEncounter
    ) -> str:
        """Determine FHIR location status from C-CDA participant time and encounter context.

        The location status indicates the patient's presence at the location:
        - completed: Patient was at location during the period (has end time)
        - active: Patient is/was at location (no end time, or ongoing)
        - planned: Patient is planned to be at location
        - reserved: Location is held empty (rarely used in C-CDA)

        Determination logic:
        1. If participant.time has both start and end → "completed"
        2. If participant.time has only start (no end) → "active"
        3. If no participant.time, derive from encounter status:
           - encounter "finished" → "completed"
           - encounter "in-progress" → "active"
           - encounter "planned" → "planned"
           - encounter "cancelled" → "completed" (was assigned)

        Reference: http://hl7.org/fhir/R4/valueset-encounter-location-status.html

        Args:
            participant: The C-CDA participant with typeCode="LOC"
            period: The converted FHIR period from participant.time (if any)
            encounter: The C-CDA encounter providing context

        Returns:
            FHIR EncounterLocationStatus code
        """
        # If participant has time information, use it to determine status
        if period:
            # If period has both start and end, location assignment is completed
            if "end" in period:
                return "completed"
            # If period has only start (no end), location is active
            elif "start" in period:
                return "active"

        # Fall back to encounter status
        encounter_status = self._extract_status(encounter)

        # Map encounter status to location status
        if encounter_status == FHIRCodes.EncounterStatus.FINISHED:
            return "completed"
        elif encounter_status == FHIRCodes.EncounterStatus.IN_PROGRESS:
            return "active"
        elif encounter_status == FHIRCodes.EncounterStatus.PLANNED:
            return "planned"
        elif encounter_status == FHIRCodes.EncounterStatus.CANCELLED:
            # Location was assigned but encounter cancelled
            return "completed"
        else:
            # Default to completed for documented encounters
            return "completed"

    def _determine_admit_source(self, encounter: CCDAEncounter) -> JSONObject | None:
        """Determine FHIR admission source from C-CDA encounter characteristics.

        C-CDA does not explicitly encode admission source, but it can be intelligently
        inferred from encounter characteristics:

        1. Emergency encounter class (EMER) → "emd" (from emergency department)
           Rationale: Emergency encounters originate from the hospital's ED

        2. priorityCode = "EM" (Emergency) → "emd" (from emergency department)
           Rationale: Emergency priority indicates admission via ED

        3. Inpatient encounters (IMP, ACUTE, NONAC) → "other"
           Rationale: General hospital admission without specific source

        4. Outpatient/Ambulatory encounters → No admission source
           Rationale: Admission source only applies to inpatient admissions

        Reference: http://terminology.hl7.org/CodeSystem/admit-source

        Args:
            encounter: The C-CDA encounter

        Returns:
            FHIR CodeableConcept for admission source, or None
        """
        # Extract encounter class from code or translation
        encounter_class = None
        if encounter.code and encounter.code.code:
            if encounter.code.code_system == V3_ACT_CODE_SYSTEM:
                encounter_class = encounter.code.code
            elif encounter.code.translation:
                for trans in encounter.code.translation:
                    trans_system = None
                    trans_code = None

                    if isinstance(trans, dict):
                        trans_system = trans.get("code_system")
                        trans_code = trans.get("code")
                    else:
                        trans_system = trans.code_system
                        trans_code = trans.code

                    if trans_system == V3_ACT_CODE_SYSTEM and trans_code:
                        encounter_class = trans_code
                        break

        # 1. Emergency encounter class → from emergency department
        if encounter_class == "EMER":
            return {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/admit-source",
                        "code": "emd",
                        "display": "From accident/emergency department",
                    }
                ]
            }

        # 2. Emergency priority code → from emergency department
        if encounter.priority_code and encounter.priority_code.code == "EM":
            return {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/admit-source",
                        "code": "emd",
                        "display": "From accident/emergency department",
                    }
                ]
            }

        # 3. Inpatient encounters → other (general admission)
        # Only assign "other" for inpatient encounters, not outpatient
        if encounter_class in ["IMP", "ACUTE", "NONAC"]:
            return {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/admit-source",
                        "code": "other",
                        "display": "Other",
                    }
                ]
            }

        # 4. Outpatient/Ambulatory → No admission source
        # Don't assign admission source for non-inpatient encounters
        return None

    def _extract_hospitalization(self, encounter: CCDAEncounter) -> JSONObject | None:
        """Extract FHIR hospitalization from C-CDA encounter.

        Extracts:
        - admitSource: Intelligently inferred from encounter characteristics
        - dischargeDisposition: Mapped from sdtc:dischargeDispositionCode

        Args:
            encounter: The C-CDA encounter

        Returns:
            FHIR hospitalization object or None
        """
        hospitalization: JSONObject = {}

        # Extract admission source (intelligently inferred)
        admit_source = self._determine_admit_source(encounter)
        if admit_source:
            hospitalization["admitSource"] = admit_source

        # Extract discharge disposition
        if encounter.sdtc_discharge_disposition_code:
            disposition = encounter.sdtc_discharge_disposition_code
            if disposition.code:
                # Map discharge disposition code to FHIR
                fhir_code = DISCHARGE_DISPOSITION_TO_FHIR.get(disposition.code)
                if not fhir_code:
                    # Use original code if not in mapping
                    fhir_code = disposition.code

                hospitalization["dischargeDisposition"] = {
                    "coding": [
                        {
                            "system": "http://terminology.hl7.org/CodeSystem/discharge-disposition",
                            "code": fhir_code,
                            "display": disposition.display_name
                            if disposition.display_name
                            else None,
                        }
                    ]
                }

        return hospitalization if hospitalization else None

    def _extract_diagnoses(
        self, entry_relationships: list[EntryRelationship] | None
    ) -> list[JSONObject]:
        """Extract FHIR diagnoses from encounter diagnosis entry relationships.

        Creates condition references with intelligent diagnosis role detection.

        Args:
            entry_relationships: List of entry relationships

        Returns:
            List of FHIR diagnosis objects with condition references and use codes
        """
        diagnoses = []

        if not entry_relationships:
            return diagnoses

        for entry_rel in entry_relationships:
            # Look for Encounter Diagnosis act (template 2.16.840.1.113883.10.20.22.4.80)
            if entry_rel.act and entry_rel.act.template_id:
                for template in entry_rel.act.template_id:
                    if template.root == TemplateIds.ENCOUNTER_DIAGNOSIS:
                        # Extract diagnosis from nested observation
                        if entry_rel.act.entry_relationship:
                            for nested_entry in entry_rel.act.entry_relationship:
                                if nested_entry.observation:
                                    obs = nested_entry.observation

                                    # Generate condition ID from observation ID
                                    # Must match ID generation in ConditionConverter
                                    if obs.id and len(obs.id) > 0:
                                        first_id = obs.id[0]
                                        condition_id = self._generate_condition_id(
                                            first_id.root, first_id.extension
                                        )
                                    else:
                                        # Fallback: Generate deterministic ID from observation content
                                        # Must use same method as ConditionConverter for consistency
                                        from ccda_to_fhir.converters.condition import (
                                            generate_id_from_observation_content,
                                        )

                                        condition_id = generate_id_from_observation_content(obs)

                                    condition_ref: JSONObject = {
                                        "reference": f"urn:uuid:{condition_id}"
                                    }

                                    # Add display from observation value (diagnosis code)
                                    if (
                                        obs.value
                                        and isinstance(obs.value, (CD, CE))
                                        and obs.value.display_name
                                    ):
                                        condition_ref["display"] = obs.value.display_name

                                    diagnosis: JSONObject = {"condition": condition_ref}

                                    # Add diagnosis use/role - will be set by _determine_diagnosis_role
                                    # when the encounter context is available
                                    diagnosis["use"] = {
                                        "coding": [
                                            {
                                                "system": "http://terminology.hl7.org/CodeSystem/diagnosis-role",
                                                "code": "billing",
                                                "display": "Billing",
                                            }
                                        ]
                                    }

                                    diagnoses.append(diagnosis)
                        break

        return diagnoses

    def _apply_diagnosis_roles(self, diagnoses: list[JSONObject], encounter: CCDAEncounter) -> None:
        """Apply intelligent diagnosis role detection to diagnoses based on encounter context.

        Updates diagnosis.use codes in place based on encounter characteristics:
        - Encounters with discharge disposition → DD (discharge diagnosis)
        - Inpatient encounters (IMP/ACUTE) without discharge → AD (admission diagnosis)
        - Emergency encounters (EMER) → AD (admission diagnosis)
        - All other encounters → billing (general documentation/billing)

        Args:
            diagnoses: List of diagnosis objects to update (modified in place)
            encounter: The C-CDA encounter providing context
        """
        if not diagnoses:
            return

        # Determine the appropriate diagnosis role based on encounter context
        diagnosis_role = self._determine_diagnosis_role(encounter)

        # Apply the determined role to all diagnoses in this encounter
        for diagnosis in diagnoses:
            if "use" in diagnosis and "coding" in diagnosis["use"]:
                diagnosis["use"]["coding"][0]["code"] = diagnosis_role.code
                diagnosis["use"]["coding"][0]["display"] = diagnosis_role.display

    def _determine_diagnosis_role(self, encounter: CCDAEncounter) -> DiagnosisRole:
        """Determine the appropriate diagnosis role based on encounter context.

        C-CDA Encounter Diagnosis Act does not explicitly encode diagnosis roles
        (admission, discharge, billing, etc.). This method infers the role from
        encounter characteristics:

        1. Discharge disposition present → Discharge diagnosis (DD)
           Rationale: If discharge info exists, diagnosis is documented at discharge

        2. Inpatient encounter (IMP/ACUTE) → Admission diagnosis (AD)
           Rationale: Inpatient encounters typically document admission diagnoses

        3. Emergency encounter (EMER) → Admission diagnosis (AD)
           Rationale: Emergency diagnoses are documented at presentation/admission

        4. All other cases → Billing diagnosis (billing)
           Rationale: Most encounters document diagnoses for billing/general purposes

        Reference: http://terminology.hl7.org/CodeSystem/diagnosis-role

        Args:
            encounter: The C-CDA encounter

        Returns:
            DiagnosisRole with code and display for the diagnosis role
        """
        # Check for discharge disposition - indicates discharge diagnosis
        if (
            encounter.sdtc_discharge_disposition_code
            and encounter.sdtc_discharge_disposition_code.code
        ):
            return DiagnosisRole(code="DD", display="Discharge diagnosis")

        # Check encounter class for inpatient or emergency
        if encounter.code and encounter.code.code:
            encounter_class = None

            # Extract class from code or translation
            if encounter.code.code_system == V3_ACT_CODE_SYSTEM:
                encounter_class = encounter.code.code
            elif encounter.code.translation:
                for trans in encounter.code.translation:
                    trans_system = None
                    trans_code = None

                    if isinstance(trans, dict):
                        trans_system = trans.get("code_system")
                        trans_code = trans.get("code")
                    else:
                        trans_system = trans.code_system
                        trans_code = trans.code

                    if trans_system == V3_ACT_CODE_SYSTEM and trans_code:
                        encounter_class = trans_code
                        break

            # Inpatient and emergency encounters → admission diagnosis
            if encounter_class in ["IMP", "ACUTE", "NONAC", "EMER"]:
                return DiagnosisRole(code="AD", display="Admission diagnosis")

        # Default to billing diagnosis for all other encounters
        # This is the most general-purpose role for outpatient, ambulatory, etc.
        return DiagnosisRole(code="billing", display="Billing")

    def _extract_reasons(self, entry_relationships: list[EntryRelationship] | None) -> ReasonResult:
        """Extract FHIR reason codes and references from C-CDA entry relationships.

        Delegates to base class method for consistent handling across converters.

        Args:
            entry_relationships: List of entry relationships

        Returns:
            ReasonResult with codes and references lists
        """
        return self.extract_reasons_from_entry_relationships(
            entry_relationships,
            problem_template_id=TemplateIds.PROBLEM_OBSERVATION,
        )

    def _generate_synthetic_location_id(self, name: str, address: JSONObject | None) -> str:
        """Generate synthetic FHIR Location ID from name and address.

        Used when C-CDA location participant has no explicit ID element.
        Creates a deterministic UUID v4 based on location characteristics.

        Args:
            name: Location name
            address: FHIR address object (if available)

        Returns:
            Generated synthetic Location ID (UUID v4)
        """
        from ccda_to_fhir.id_generator import generate_id_from_identifiers

        # Build a unique string from available identifying information
        id_parts = [name]

        if address:
            if "city" in address:
                id_parts.append(address["city"])
            if "state" in address:
                id_parts.append(address["state"])
            if "line" in address and address["line"]:
                # Use first line
                id_parts.append(address["line"][0])

        # Create deterministic UUID v4 from combined location info
        combined = "|".join(id_parts)
        return generate_id_from_identifiers("Location", combined, None)

    def _generate_condition_id_from_observation(self, observation) -> str:
        """Generate a Condition resource ID from a Problem Observation.

        Overrides base class to provide fallback behavior: if no ID is found,
        generates a deterministic ID from observation content instead of returning None.
        This ensures Encounter.diagnosis references are always resolvable.

        Args:
            observation: Problem Observation with ID

        Returns:
            Condition resource ID string (never None)
        """
        # Try the base implementation first
        condition_id = super()._generate_condition_id_from_observation(observation)
        if condition_id:
            return condition_id

        # Fallback: Generate deterministic ID from observation content
        # Must use same method as ConditionConverter for consistency
        from ccda_to_fhir.converters.condition import generate_id_from_observation_content

        return generate_id_from_observation_content(observation)

    # Note: _generate_condition_id is inherited from BaseConverter

    def extract_diagnosis_observations(self, encounter: CCDAEncounter) -> list:
        """Extract diagnosis observations from Encounter Diagnosis Acts.

        These observations should be converted to Condition resources with
        category="encounter-diagnosis" to match the Encounter.diagnosis references.

        Args:
            encounter: The C-CDA Encounter Activity

        Returns:
            List of diagnosis observations to convert to Condition resources
        """
        observations = []

        if not encounter.entry_relationship:
            return observations

        for entry_rel in encounter.entry_relationship:
            # Look for Encounter Diagnosis act (template 2.16.840.1.113883.10.20.22.4.80)
            if entry_rel.act and entry_rel.act.template_id:
                for template in entry_rel.act.template_id:
                    if template.root == TemplateIds.ENCOUNTER_DIAGNOSIS:
                        # Extract diagnosis from nested observation
                        if entry_rel.act.entry_relationship:
                            for nested_entry in entry_rel.act.entry_relationship:
                                if nested_entry.observation:
                                    observations.append(nested_entry.observation)
                        break

        return observations

    def get_pending_resources(self) -> list[FHIRResourceDict]:
        """Get resources created during conversion that need to be added to bundle.

        Returns Practitioner and Location resources that were created inline
        during participant/location extraction, then clears the pending lists
        for the next conversion.

        Returns:
            List of FHIR resources (Practitioner and Location) to add to bundle
        """
        resources = []
        resources.extend(self._pending_practitioners)
        resources.extend(self._pending_locations)

        # Clear for next conversion
        self._pending_practitioners = []
        self._pending_locations = []

        return resources
