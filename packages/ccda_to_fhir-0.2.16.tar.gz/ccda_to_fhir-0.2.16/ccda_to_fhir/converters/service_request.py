"""ServiceRequest converter: C-CDA Planned Procedure/Act to FHIR ServiceRequest resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ccda_to_fhir.ccda.models.act import Act as CCDAAct
from ccda_to_fhir.ccda.models.datatypes import CD, IVL_TS, TS
from ccda_to_fhir.ccda.models.procedure import Procedure as CCDAProcedure
from ccda_to_fhir.constants import (
    SERVICE_REQUEST_MOOD_TO_INTENT,
    SERVICE_REQUEST_PRIORITY_TO_FHIR,
    SERVICE_REQUEST_STATUS_TO_FHIR,
    FHIRCodes,
    TemplateIds,
)
from ccda_to_fhir.types import (
    FHIRCodeableConcept,
    FHIRReference,
    FHIRResourceDict,
    JSONObject,
    ReasonResult,
)

from .base import BaseConverter

if TYPE_CHECKING:
    from ccda_to_fhir.ccda.models.entry_relationship import EntryRelationship
    from ccda_to_fhir.ccda.models.performer import Performer


class ServiceRequestConverter(BaseConverter[CCDAProcedure | CCDAAct]):
    """Convert C-CDA Planned Procedure/Act to FHIR ServiceRequest resource.

    This converter handles the mapping from C-CDA Planned Procedure and Planned Act
    templates to FHIR R4B ServiceRequest resources.

    Supports:
    - Planned Procedure (V2): 2.16.840.1.113883.10.20.22.4.41
    - Planned Act (V2): 2.16.840.1.113883.10.20.22.4.39

    **CRITICAL**: Only converts procedures/acts with moodCode in {INT, RQO, PRP, ARQ, PRMS}.
    Procedures with moodCode=EVN (Event) or moodCode=GOL (Goal) must use
    Procedure or Goal converters instead.

    Reference: docs/mapping/18-service-request.md
    """

    def convert(self, ccda_model: CCDAProcedure | CCDAAct, section=None) -> FHIRResourceDict:
        """Convert a C-CDA Planned Procedure/Act to a FHIR ServiceRequest resource.

        Args:
            ccda_model: The C-CDA Planned Procedure or Planned Act element
            section: The C-CDA Section containing this procedure (for narrative)

        Returns:
            FHIR ServiceRequest resource as a dictionary

        Raises:
            ValueError: If the procedure lacks required data or has invalid moodCode
        """
        procedure = ccda_model  # Alias for readability
        # Validate moodCode - CRITICAL for distinguishing ServiceRequest from Procedure/Goal
        if not procedure.mood_code:
            raise ValueError("Planned Procedure/Act must have a moodCode attribute")

        mood_code = procedure.mood_code.upper()
        valid_mood_codes = {"INT", "RQO", "PRP", "ARQ", "PRMS"}

        if mood_code not in valid_mood_codes:
            if mood_code == "EVN":
                raise ValueError(
                    "moodCode=EVN indicates completed procedure; use Procedure converter instead"
                )
            elif mood_code == "GOL":
                raise ValueError("moodCode=GOL indicates goal; use Goal converter instead")
            else:
                raise ValueError(
                    f"Invalid moodCode '{mood_code}' for ServiceRequest; "
                    f"expected one of {valid_mood_codes}"
                )

        # Validate required code element
        if not procedure.code:
            raise ValueError("Planned Procedure/Act must have a code")

        has_valid_code = procedure.code.code and not procedure.code.null_flavor

        if not has_valid_code:
            raise ValueError("Planned Procedure/Act code must have a valid code value")

        # Build FHIR ServiceRequest resource
        fhir_service_request: JSONObject = {
            "resourceType": FHIRCodes.ResourceTypes.SERVICE_REQUEST,
        }

        # Add US Core profile
        fhir_service_request["meta"] = {
            "profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-servicerequest"]
        }

        # Generate ID from procedure identifier
        if procedure.id and len(procedure.id) > 0:
            first_id = procedure.id[0]
            fhir_service_request["id"] = self._generate_service_request_id(
                first_id.root, first_id.extension
            )

        # Identifiers
        if procedure.id:
            fhir_service_request["identifier"] = [
                self.create_identifier(id_elem.root, id_elem.extension)
                for id_elem in procedure.id
                if id_elem.root
            ]

        # Status (required) - map from statusCode
        status = self._map_status(procedure.status_code)
        fhir_service_request["status"] = status

        # Intent (required) - map from moodCode
        intent = self._map_intent(mood_code)
        fhir_service_request["intent"] = intent

        # Category (must support) - infer from code system
        category = self._infer_category(procedure.code)
        if category:
            fhir_service_request["category"] = [category]

        # Code (required)
        code = self._convert_code(procedure.code)
        if code:
            fhir_service_request["code"] = code.to_dict()

        # Subject (required) - patient reference
        if not self.reference_registry:
            raise ValueError(
                "reference_registry is required. "
                "Cannot create ServiceRequest without patient reference."
            )
        fhir_service_request["subject"] = self.reference_registry.get_patient_reference().to_dict()

        # Encounter (must support)
        if self.reference_registry:
            encounter_ref = self.reference_registry.get_encounter_reference()
            if encounter_ref:
                fhir_service_request["encounter"] = encounter_ref.to_dict()

        # Occurrence[x] (must support) - from effectiveTime
        if procedure.effective_time:
            occurrence = self._convert_occurrence(procedure.effective_time)
            if occurrence:
                if isinstance(occurrence, dict) and ("start" in occurrence or "end" in occurrence):
                    fhir_service_request["occurrencePeriod"] = occurrence
                else:
                    fhir_service_request["occurrenceDateTime"] = occurrence

        # AuthoredOn (must support) - from author/time
        if procedure.author:
            authored_on = self._extract_authored_on(procedure.author)
            if authored_on:
                fhir_service_request["authoredOn"] = authored_on

        # Requester (must support) - from author/assignedAuthor
        if procedure.author:
            requester = self._extract_requester(procedure.author)
            if requester:
                fhir_service_request["requester"] = requester.to_dict()

        # Performer - from performer/assignedEntity
        if procedure.performer:
            performers = self.extract_performer_references(procedure.performer)
            if performers:
                fhir_service_request["performer"] = [p.to_dict() for p in performers]

        # PerformerType - from performer/functionCode
        if procedure.performer:
            performer_type = self._extract_performer_type(procedure.performer)
            if performer_type:
                fhir_service_request["performerType"] = performer_type.to_dict()

        # Priority - from priorityCode (both CCDAProcedure and CCDAAct have this)
        if procedure.priority_code:
            priority = self._map_priority(procedure.priority_code)
            if priority:
                fhir_service_request["priority"] = priority

        # Body site - from targetSiteCode (only CCDAProcedure has this)
        if isinstance(procedure, CCDAProcedure) and procedure.target_site_code:
            body_sites: list[JSONObject] = []
            for site_code in procedure.target_site_code:
                if site_code.code:
                    body_site = self._convert_code(site_code)
                    if body_site:
                        body_sites.append(body_site.to_dict())
            if body_sites:
                fhir_service_request["bodySite"] = body_sites

        # Reason codes and references - from entryRelationship
        if procedure.entry_relationship:
            reasons = self._extract_reasons(procedure.entry_relationship)
            if reasons.codes:
                fhir_service_request["reasonCode"] = [c.to_dict() for c in reasons.codes]
            if reasons.references:
                fhir_service_request["reasonReference"] = [r.to_dict() for r in reasons.references]

        # Patient instruction - from entryRelationship with Instruction template
        if procedure.entry_relationship:
            patient_instruction = self._extract_patient_instruction(procedure.entry_relationship)
            if patient_instruction:
                fhir_service_request["patientInstruction"] = patient_instruction

        # Notes
        notes = self._extract_notes(procedure)
        if notes:
            fhir_service_request["note"] = notes

        # Narrative
        narrative = self._generate_narrative(entry=procedure, section=section)
        if narrative:
            fhir_service_request["text"] = narrative

        return fhir_service_request

    def _generate_service_request_id(self, root: str | None, extension: str | None) -> str:
        """Generate a FHIR ServiceRequest ID from C-CDA identifiers.

        Uses centralized ID generation for consistent UUID caching and handling.

        Args:
            root: The OID or UUID root
            extension: The extension value

        Returns:
            Generated UUID string
        """
        from ccda_to_fhir.id_generator import generate_id_from_identifiers

        return generate_id_from_identifiers("ServiceRequest", root, extension)

    def _map_status(self, status_code) -> str:
        """Map C-CDA status code to FHIR ServiceRequest status.

        Handles nullFlavor per C-CDA on FHIR IG ConceptMap CF-NullFlavorDataAbsentReason.

        Args:
            status_code: The C-CDA status code

        Returns:
            FHIR ServiceRequest status code
        """
        # Check for nullFlavor - per C-CDA on FHIR IG
        if status_code and status_code.null_flavor:
            null_flavor_upper = status_code.null_flavor.upper()
            if null_flavor_upper == "UNK":
                return FHIRCodes.ServiceRequestStatus.UNKNOWN
            # For planned procedures, other nullFlavors default to active
            return FHIRCodes.ServiceRequestStatus.ACTIVE

        return self.map_status_code(
            status_code,
            SERVICE_REQUEST_STATUS_TO_FHIR,
            FHIRCodes.ServiceRequestStatus.ACTIVE,
        )

    def _map_intent(self, mood_code: str) -> str:
        """Map C-CDA moodCode to FHIR ServiceRequest intent.

        Args:
            mood_code: The C-CDA moodCode (already validated)

        Returns:
            FHIR ServiceRequest intent code
        """
        return SERVICE_REQUEST_MOOD_TO_INTENT.get(mood_code, FHIRCodes.ServiceRequestIntent.PLAN)

    def _map_priority(self, priority_code) -> str | None:
        """Map C-CDA priorityCode to FHIR ServiceRequest priority.

        Args:
            priority_code: The C-CDA priorityCode

        Returns:
            FHIR ServiceRequest priority code or None
        """
        if not priority_code or not priority_code.code:
            return None

        ccda_priority = priority_code.code.upper()
        return SERVICE_REQUEST_PRIORITY_TO_FHIR.get(ccda_priority)

    def _infer_category(self, code: CD) -> JSONObject | None:
        """Infer ServiceRequest category from procedure code.

        Args:
            code: The C-CDA procedure code

        Returns:
            FHIR CodeableConcept for category or None
        """
        if not code or not code.code_system:
            return None

        # Infer category based on code system and code ranges
        code_system = code.code_system
        code_value = code.code

        # LOINC codes - typically lab procedures
        if code_system == "2.16.840.1.113883.6.1":
            return {
                "coding": [
                    {
                        "system": "http://snomed.info/sct",
                        "code": "108252007",
                        "display": "Laboratory procedure",
                    }
                ]
            }

        # CPT codes
        if code_system == "2.16.840.1.113883.6.12" and code_value:
            try:
                cpt_code = int(code_value)
                # Radiology range: 70000-79999
                if 70000 <= cpt_code <= 79999:
                    return {
                        "coding": [
                            {
                                "system": "http://snomed.info/sct",
                                "code": "363679005",
                                "display": "Imaging",
                            }
                        ]
                    }
                # Surgery range: 10000-69999
                elif 10000 <= cpt_code <= 69999:
                    return {
                        "coding": [
                            {
                                "system": "http://snomed.info/sct",
                                "code": "387713003",
                                "display": "Surgical procedure",
                            }
                        ]
                    }
            except ValueError:
                pass

        # SNOMED CT codes - check for specific procedure types
        if code_system == "2.16.840.1.113883.6.96" and code_value:
            # Counseling
            if code_value == "409063005":
                return {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "409063005",
                            "display": "Counselling",
                        }
                    ]
                }
            # Education
            if code_value == "409073007":
                return {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "409073007",
                            "display": "Education",
                        }
                    ]
                }

        # Default category: Diagnostic procedure
        return {
            "coding": [
                {
                    "system": "http://snomed.info/sct",
                    "code": "103693007",
                    "display": "Diagnostic procedure",
                }
            ]
        }

    def _convert_code(self, code: CD) -> FHIRCodeableConcept | None:
        """Convert C-CDA code to FHIR CodeableConcept model.

        Args:
            code: The C-CDA code

        Returns:
            FHIRCodeableConcept or None
        """
        return self.convert_code_to_codeable_concept(code)

    def _convert_occurrence(self, effective_time: IVL_TS | TS | str) -> JSONObject | str | None:
        """Convert C-CDA effectiveTime to FHIR occurrence[x].

        Args:
            effective_time: The C-CDA effectiveTime

        Returns:
            FHIR occurrenceDateTime (string) or occurrencePeriod (dict), or None
        """
        if isinstance(effective_time, str):
            return self.convert_date(effective_time)

        if isinstance(effective_time, IVL_TS):
            # Check for point-in-time (IVL_TS with direct value attribute)
            if effective_time.value:
                return self.convert_date(effective_time.value)

            # Handle period (low/high)
            period: JSONObject = {}

            if effective_time.low:
                low_value = effective_time.low.value
                if low_value:
                    converted_low = self.convert_date(str(low_value))
                    if converted_low:
                        period["start"] = converted_low

            if effective_time.high:
                high_value = effective_time.high.value
                if high_value:
                    converted_high = self.convert_date(str(high_value))
                    if converted_high:
                        period["end"] = converted_high

            return period if period else None

        # Handle single value (TS type)
        if isinstance(effective_time, TS) and effective_time.value:
            return self.convert_date(effective_time.value)

        return None

    def _extract_authored_on(self, authors: list) -> str | None:
        """Extract authoredOn from C-CDA authors.

        Uses the latest author timestamp.

        Args:
            authors: List of C-CDA author elements

        Returns:
            FHIR dateTime string or None
        """
        if not authors or len(authors) == 0:
            return None

        # Get latest author by timestamp
        authors_with_time = [a for a in authors if a.time and a.time.value]

        if not authors_with_time:
            return None

        latest_author = max(authors_with_time, key=lambda a: a.time.value)
        return self.convert_date(latest_author.time.value)

    def _extract_requester(self, authors: list) -> FHIRReference | None:
        """Extract requester reference from C-CDA authors.

        Uses the latest author.

        Args:
            authors: List of C-CDA author elements

        Returns:
            FHIRReference or None
        """
        if not authors or len(authors) == 0:
            return None

        authors_with_time = [a for a in authors if a.time and a.time.value]

        if not authors_with_time:
            return None

        latest_author = max(authors_with_time, key=lambda a: a.time.value)

        if latest_author.assigned_author:
            assigned_author = latest_author.assigned_author

            if assigned_author.assigned_person:
                if assigned_author.id:
                    for id_elem in assigned_author.id:
                        if id_elem.root:
                            pract_id = self._generate_practitioner_id(
                                id_elem.root, id_elem.extension
                            )
                            from ccda_to_fhir.converters.author_references import (
                                format_person_display,
                            )

                            display = format_person_display(assigned_author.assigned_person)
                            return FHIRReference(reference=f"urn:uuid:{pract_id}", display=display)

        return None

    def _extract_performer_type(self, performers: list[Performer]) -> FHIRCodeableConcept | None:
        """Extract performerType from C-CDA performer functionCode.

        Args:
            performers: List of C-CDA performer elements

        Returns:
            FHIRCodeableConcept or None
        """
        for performer in performers:
            if performer.function_code:
                return self._convert_code(performer.function_code)

        return None

    def _extract_reasons(self, entry_relationships: list[EntryRelationship]) -> ReasonResult:
        """Extract reason codes and references from entryRelationships.

        Delegates to base class method for consistent handling across converters.

        Args:
            entry_relationships: List of C-CDA entry relationship elements

        Returns:
            ReasonResult with codes and references lists
        """
        return self.extract_reasons_from_entry_relationships(
            entry_relationships,
            problem_template_id=TemplateIds.PROBLEM_OBSERVATION,
        )

    # Note: _generate_condition_id and _generate_condition_id_from_observation
    # are inherited from BaseConverter

    def _extract_patient_instruction(self, entry_relationships: list) -> str | None:
        """Extract patient instruction from entryRelationships.

        Args:
            entry_relationships: List of C-CDA entry relationship elements

        Returns:
            Patient instruction text or None
        """
        for entry_rel in entry_relationships:
            # Look for Instruction acts with typeCode="SUBJ" and inversionInd="true"
            if (entry_rel.type_code == "SUBJ" and entry_rel.inversion_ind) and entry_rel.act:
                act = entry_rel.act

                # Check if this is an Instruction template
                is_instruction = False
                if act.template_id:
                    for template in act.template_id:
                        if template.root == TemplateIds.INSTRUCTION_ACT:
                            is_instruction = True
                            break

                if is_instruction and act.text:
                    if isinstance(act.text, str):
                        return act.text
                    elif act.text.value:
                        return act.text.value

        return None

    def _extract_notes(self, procedure) -> list[JSONObject]:
        """Extract notes from procedure.

        Args:
            procedure: The C-CDA procedure element

        Returns:
            List of FHIR Annotation objects
        """
        # ServiceRequest only extracts from text, not from comment activities
        return self.extract_notes_from_element(procedure, include_comments=False)
