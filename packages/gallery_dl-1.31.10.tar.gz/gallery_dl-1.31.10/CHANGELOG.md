## 1.31.9 - 2026-03-08
### Extractors
#### Fixes
- [twitter] fix `AttributeError: '_update_variables_search_maxid'` ([#9203](https://github.com/mikf/gallery-dl/issues/9203))
