import django
from django.conf import settings

if not settings.configured:
    settings.configure(
        SECRET_KEY='test',
        INSTALLED_APPS=['django.contrib.contenttypes', 'django_base_models'],
        DATABASES={'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': ':memory:'}},
        DEFAULT_AUTO_FIELD='django.db.models.BigAutoField',
        USE_TZ=True,
    )
    django.setup()

from django.test import TestCase
from django_base_models import CreatedBaseModel, SlugBasedModel
from django_base_models.utils import generate_slug, cyrillic_slugify


class UtilsTest(TestCase):
    def test_generate_slug(self):
        slug = generate_slug('Hello World')
        self.assertEqual(slug, 'hello-world')

    def test_cyrillic_slugify(self):
        slug = cyrillic_slugify('Привет Мир')
        self.assertEqual(slug, 'privet-mir')

    def test_empty_slug(self):
        slug = generate_slug('')
        self.assertEqual(len(slug), 8)