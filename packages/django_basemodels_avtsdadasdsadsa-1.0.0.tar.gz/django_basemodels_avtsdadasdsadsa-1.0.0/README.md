# Django Base Models

Base models for Django with created_at, updated_at, and slug fields.

## Installation

```bash
pip install django-base-models