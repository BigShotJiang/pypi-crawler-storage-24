from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='django-basemodels-avtsdadasdsadsa',
    version='1.0.0',
    author='Abdulvohid',
    author_email='nadirovabdulvohid3@gmail.com',  # Real email
    description='Base models for Django with created_at, updated_at, and slug fields',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/abdulvohid/django-base-models',
    project_urls={
        'Bug Tracker': 'https://github.com/abdulvohid/django-base-models/issues',
        'Source Code': 'https://github.com/abdulvohid/django-base-models',
    },
    packages=find_packages(exclude=['tests*']),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 3.2',
        'Framework :: Django :: 4.0',
        'Framework :: Django :: 4.1',
        'Framework :: Django :: 4.2',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    license='MIT',
    python_requires='>=3.8',
    install_requires=[
        'Django>=3.2',
    ],
    keywords='django models base slug created updated timestamp',
    include_package_data=True,
    zip_safe=False,
)