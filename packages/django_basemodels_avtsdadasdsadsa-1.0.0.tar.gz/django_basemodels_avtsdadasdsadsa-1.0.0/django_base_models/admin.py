"""
Admin mixins for django-base-models
"""

from django.contrib import admin


class CreatedBaseModelAdmin(admin.ModelAdmin):
    """
    CreatedBaseModel uchun admin mixin.

    Usage:
        @admin.register(MyModel)
        class MyModelAdmin(CreatedBaseModelAdmin):
            list_display = ['title'] + CreatedBaseModelAdmin.list_display
    """
    list_display = ["created_at", "updated_at"]
    list_filter = ["created_at", "updated_at"]
    readonly_fields = ["created_at", "updated_at"]
    date_hierarchy = "created_at"
    ordering = ["-created_at"]


class SlugBasedModelAdmin(CreatedBaseModelAdmin):
    """
    SlugBasedModel uchun admin mixin.

    Usage:
        @admin.register(Article)
        class ArticleAdmin(SlugBasedModelAdmin):
            list_display = ['title'] + SlugBasedModelAdmin.list_display
    """
    list_display = ["slug"] + CreatedBaseModelAdmin.list_display
    prepopulated_fields = {}  # Override qiling: {"slug": ("title",)}
    search_fields = ["slug"]


class FullFeaturedModelAdmin(SlugBasedModelAdmin):
    """
    FullFeaturedModel uchun admin mixin.
    """
    list_display = ["is_active", "is_deleted"] + SlugBasedModelAdmin.list_display
    list_filter = ["is_active", "is_deleted"] + list(SlugBasedModelAdmin.list_filter)
    list_editable = ["is_active"]
    actions = ["soft_delete_selected", "restore_selected", "activate", "deactivate"]

    @admin.action(description="Tanlangan ob'ektlarni o'chirish (soft delete)")
    def soft_delete_selected(self, request, queryset):
        for obj in queryset:
            obj.soft_delete()
        self.message_user(request, f"{queryset.count()} ta ob'ekt o'chirildi.")

    @admin.action(description="Tanlangan ob'ektlarni tiklash")
    def restore_selected(self, request, queryset):
        for obj in queryset:
            obj.restore()
        self.message_user(request, f"{queryset.count()} ta ob'ekt tiklandi.")

    @admin.action(description="Faollashtirish")
    def activate(self, request, queryset):
        queryset.update(is_active=True)

    @admin.action(description="O'chirish (deactivate)")
    def deactivate(self, request, queryset):
        queryset.update(is_active=False)