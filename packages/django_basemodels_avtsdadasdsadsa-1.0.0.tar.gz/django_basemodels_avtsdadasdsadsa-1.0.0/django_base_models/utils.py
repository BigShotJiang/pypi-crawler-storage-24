from django.utils.text import slugify
import uuid
import re


def generate_slug(text, max_length=255):
    slug = slugify(text)
    if not slug:
        slug = str(uuid.uuid4())[:8]
    return slug[:max_length]


def generate_unique_slug(model_class, text, slug_field='slug', max_length=255):
    base_slug = generate_slug(text, max_length)
    slug = base_slug
    counter = 1
    while model_class.objects.filter(**{slug_field: slug}).exists():
        suffix = f'-{counter}'
        slug = f'{base_slug[:max_length - len(suffix)]}{suffix}'
        counter += 1
    return slug


def transliterate(text):
    mapping = {
        'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
        'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
        'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
        'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'shch',
        'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya',
        'ў': 'o', 'қ': 'q', 'ғ': 'g', 'ҳ': 'h',
    }
    result = ''
    for char in text.lower():
        result += mapping.get(char, char)
    return result


def cyrillic_slugify(text, max_length=255):
    text = transliterate(text)
    return generate_slug(text, max_length)