from django.db import models
from .mixins import CreatedMixin, UpdatedMixin, SlugMixin
from .fields import AutoSlugField


class CreatedBaseModel(CreatedMixin, UpdatedMixin):
    class Meta:
        abstract = True
        ordering = ['-created_at']


class SlugBasedModel(CreatedMixin, UpdatedMixin, SlugMixin):
    slug_source_field = 'name'

    class Meta:
        abstract = True
        ordering = ['-created_at']


class FullBaseModel(CreatedMixin, UpdatedMixin):
    slug = AutoSlugField(populate_from='name', unique=True, max_length=255)
    is_active = models.BooleanField(default=True, db_index=True)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        abstract = True
        ordering = ['order', '-created_at']

    @classmethod
    def active(cls):
        return cls.objects.filter(is_active=True)


class UUIDBaseModel(CreatedMixin, UpdatedMixin):
    import uuid as uuid_lib
    id = models.UUIDField(primary_key=True, default=uuid_lib.uuid4, editable=False)

    class Meta:
        abstract = True
        ordering = ['-created_at']


class SoftDeleteMixin(models.Model):
    is_deleted = models.BooleanField(default=False, db_index=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

    def soft_delete(self):
        from django.utils import timezone
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save(update_fields=['is_deleted', 'deleted_at'])

    def restore(self):
        self.is_deleted = False
        self.deleted_at = None
        self.save(update_fields=['is_deleted', 'deleted_at'])