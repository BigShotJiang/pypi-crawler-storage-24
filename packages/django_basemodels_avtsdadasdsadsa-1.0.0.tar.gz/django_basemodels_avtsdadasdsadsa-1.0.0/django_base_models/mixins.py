from django.db import models
from django.utils import timezone


class CreatedMixin(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        abstract = True


class UpdatedMixin(models.Model):
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SlugMixin(models.Model):
    slug = models.SlugField(max_length=255, unique=True, blank=True, db_index=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = self._generate_slug()
        super().save(*args, **kwargs)

    def _generate_slug(self):
        from django.utils.text import slugify
        import uuid
        source_field = getattr(self, 'slug_source_field', None)
        if source_field and hasattr(self, source_field):
            base_slug = slugify(getattr(self, source_field))
        else:
            base_slug = str(uuid.uuid4())[:8]
        if not base_slug:
            base_slug = str(uuid.uuid4())[:8]
        slug = base_slug
        counter = 1
        model_class = self.__class__
        while model_class.objects.filter(slug=slug).exclude(pk=self.pk).exists():
            slug = f'{base_slug}-{counter}'
            counter += 1
        return slug


class IsActiveMixin(models.Model):
    is_active = models.BooleanField(default=True, db_index=True)

    class Meta:
        abstract = True


class OrderMixin(models.Model):
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        abstract = True
        ordering = ['order']