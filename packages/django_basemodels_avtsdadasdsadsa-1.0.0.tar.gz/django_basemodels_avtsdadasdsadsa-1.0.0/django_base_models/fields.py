from django.db import models
from django.utils.text import slugify
import uuid


class AutoSlugField(models.SlugField):
    def __init__(self, populate_from=None, unique=True, max_length=255, *args, **kwargs):
        self.populate_from = populate_from
        kwargs['unique'] = unique
        kwargs['max_length'] = max_length
        kwargs['blank'] = True
        super().__init__(*args, **kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if self.populate_from:
            kwargs['populate_from'] = self.populate_from
        return name, path, args, kwargs

    def pre_save(self, model_instance, add):
        value = getattr(model_instance, self.attname)
        if not value and self.populate_from:
            source = getattr(model_instance, self.populate_from, None)
            if source:
                value = self.generate_unique_slug(model_instance, source)
                setattr(model_instance, self.attname, value)
        if not value:
            value = self.generate_unique_slug(model_instance, str(uuid.uuid4())[:8])
            setattr(model_instance, self.attname, value)
        return value

    def generate_unique_slug(self, instance, source):
        slug = slugify(source)
        if not slug:
            slug = str(uuid.uuid4())[:8]
        model_class = instance.__class__
        unique_slug = slug[:self.max_length]
        counter = 1
        while model_class.objects.filter(**{self.attname: unique_slug}).exclude(pk=instance.pk).exists():
            suffix = f'-{counter}'
            unique_slug = f'{slug[:self.max_length - len(suffix)]}{suffix}'
            counter += 1
        return unique_slug