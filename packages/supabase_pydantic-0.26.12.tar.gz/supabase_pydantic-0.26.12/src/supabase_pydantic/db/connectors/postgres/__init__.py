"""PostgreSQL connector module."""
