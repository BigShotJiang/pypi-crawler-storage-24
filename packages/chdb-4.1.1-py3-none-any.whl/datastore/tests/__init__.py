"""
DataStore test suite
"""

