"""Crawdad SDK exceptions."""

from __future__ import annotations


class CrawdadError(Exception):
    """Base exception for all Crawdad API errors."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"[{status_code}] {message}")


class AuthenticationError(CrawdadError):
    """Raised on 401 Unauthorized responses."""

    def __init__(self, message: str = "missing or invalid API key") -> None:
        super().__init__(401, message)


class NotFoundError(CrawdadError):
    """Raised on 404 Not Found responses."""

    def __init__(self, message: str = "resource not found") -> None:
        super().__init__(404, message)


class RateLimitError(CrawdadError):
    """Raised on 429 Too Many Requests responses."""

    def __init__(self, message: str = "rate limit exceeded") -> None:
        super().__init__(429, message)
