"""PolicyGate — pre-built security policies for every OpenClaw tool type."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from ..client import CrawdadClient

# ── Sensitive paths that require approval ─────────────────────────────

_SENSITIVE_PATHS = [
    re.compile(r"^~?/?\.(ssh|gnupg|aws|config|kube)(/|$)"),
    re.compile(r"^~?/?\.env(\.|$)"),
    re.compile(r"/etc/(passwd|shadow|sudoers|hosts)$"),
    re.compile(r"/etc/ssh/"),
    re.compile(r"^~?/?\.crawdad\.env$"),
    re.compile(r"^~?/?\.git/config$"),
    re.compile(r"^~?/?\.npmrc$"),
    re.compile(r"^~?/?\.pypirc$"),
    re.compile(r"^~?/?\.docker/config\.json$"),
    re.compile(r"^~?/?\.netrc$"),
    re.compile(r"/id_rsa|/id_ed25519|/id_ecdsa"),
]

# ── Known-good API endpoint patterns ─────────────────────────────────

_DEFAULT_API_ALLOWLIST = [
    re.compile(r"^https?://localhost[:/]"),
    re.compile(r"^https?://127\.0\.0\.1[:/]"),
    re.compile(r"^https?://api\.openai\.com/"),
    re.compile(r"^https?://api\.anthropic\.com/"),
    re.compile(r"^https?://.*\.googleapis\.com/"),
    re.compile(r"^https?://api\.github\.com/"),
]

_DEFAULT_API_BLOCKLIST = [
    re.compile(r"^https?://.*\.(onion|i2p)(/|$)"),
    re.compile(r"^https?://pastebin\.com/"),
    re.compile(r"^https?://transfer\.sh/"),
    re.compile(r"^https?://0x0\.st/"),
    re.compile(r"^https?://webhook\.site/"),
    re.compile(r"^https?://requestbin\."),
]

# ── URL allowlist for browser navigation ──────────────────────────────

_BROWSER_BLOCKLIST = [
    re.compile(r"^https?://.*\.(onion|i2p)(/|$)"),
    re.compile(r"^javascript:", re.IGNORECASE),
    re.compile(r"^data:", re.IGNORECASE),
    re.compile(r"^file:", re.IGNORECASE),
]


class PolicyGate:
    """Pre-built security policies for every OpenClaw tool type.

    Each policy returns a decision dict with:
    - decision: "Permit", "Deny", or "Escalate"
    - reason: Human-readable explanation
    - risk_level: "low", "medium", "high", or "critical"
    - risk_level_score: Numeric score 0-100

    Supported tool types:
    - shell_exec: High risk, requires policy approval
    - browser_navigate: Check URL against blocklist
    - browser_click / browser_fill: Medium risk
    - file_read: Check path against allowed directories
    - file_write: High risk for sensitive paths
    - email_send: Scan content for PII
    - api_call: Check destination against known-good endpoints
    - git_push / git_commit: Medium risk

    Args:
        client: Optional CrawdadClient for PII scanning in email policies.
        allowed_directories: List of allowed base directories for file_read.
        api_allowlist: Additional regex patterns for allowed API endpoints.
        api_blocklist: Additional regex patterns for blocked API endpoints.
    """

    def __init__(
        self,
        client: Optional[CrawdadClient] = None,
        *,
        allowed_directories: Optional[List[str]] = None,
        api_allowlist: Optional[List[re.Pattern]] = None,  # type: ignore[type-arg]
        api_blocklist: Optional[List[re.Pattern]] = None,  # type: ignore[type-arg]
    ) -> None:
        self._client = client
        self._allowed_dirs = allowed_directories or ["/tmp", "/data", "."]
        self._api_allowlist = _DEFAULT_API_ALLOWLIST + (api_allowlist or [])
        self._api_blocklist = _DEFAULT_API_BLOCKLIST + (api_blocklist or [])

    def evaluate(self, action: str, resource: str, **context: Any) -> Dict[str, Any]:
        """Evaluate an action against the appropriate policy.

        Args:
            action: The tool/action type (e.g. "shell_exec", "file_read").
            resource: The target resource (path, URL, command, etc.).
            **context: Additional context for the evaluation.

        Returns:
            Policy decision dict.
        """
        handler = self._policies.get(action)
        if handler is not None:
            return handler(self, resource, **context)
        # Unknown action — escalate by default
        return _decision(
            "Escalate",
            f"Unknown action type: {action}",
            "medium",
            50,
        )

    # ── Individual policies ───────────────────────────────────────────

    def _policy_shell_exec(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """shell_exec: High risk. Always requires explicit approval."""
        # Block dangerous commands
        dangerous = ["rm -rf", "mkfs", "dd if=", "> /dev/", "chmod 777", ":(){ :|:& };:"]
        for d in dangerous:
            if d in resource:
                return _decision("Deny", f"Dangerous command detected: {d}", "critical", 100)
        return _decision(
            "Escalate",
            "shell_exec requires explicit approval",
            "high",
            80,
        )

    def _policy_browser_navigate(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """browser_navigate: Check URL against blocklist."""
        for pattern in _BROWSER_BLOCKLIST:
            if pattern.search(resource):
                return _decision("Deny", f"Blocked URL pattern: {pattern.pattern}", "high", 85)
        return _decision("Permit", "URL not in blocklist", "low", 10)

    def _policy_browser_click(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """browser_click: Medium risk."""
        return _decision("Permit", "Browser click permitted", "medium", 30)

    def _policy_browser_fill(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """browser_fill: Medium risk — could expose data."""
        return _decision(
            "Escalate",
            "browser_fill may expose sensitive data",
            "medium",
            40,
        )

    def _policy_file_read(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """file_read: Check against allowed directories and sensitive paths."""
        # Block reading sensitive paths
        for pattern in _SENSITIVE_PATHS:
            if pattern.search(resource):
                return _decision("Deny", f"Reading sensitive path: {resource}", "high", 80)
        return _decision("Permit", "file_read permitted", "low", 10)

    def _policy_file_write(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """file_write: High risk for sensitive paths, requires approval."""
        for pattern in _SENSITIVE_PATHS:
            if pattern.search(resource):
                return _decision("Deny", f"Writing to sensitive path: {resource}", "critical", 95)
        return _decision("Escalate", "file_write requires approval", "high", 60)

    def _policy_email_send(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """email_send: Scan content for PII before sending."""
        if self._client is not None:
            pii = self._client.scan_pii(resource)
            if pii.get("count", 0) > 0:
                cats = pii.get("categories_found", [])
                return _decision(
                    "Deny",
                    f"PII detected in email content: {', '.join(cats)}",
                    "high",
                    85,
                )
        return _decision("Escalate", "email_send requires review", "medium", 50)

    def _policy_api_call(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """api_call: Check destination against known-good endpoints."""
        for pattern in self._api_blocklist:
            if pattern.search(resource):
                return _decision("Deny", f"Blocked API destination: {resource}", "critical", 95)
        for pattern in self._api_allowlist:
            if pattern.search(resource):
                return _decision("Permit", "API endpoint in allowlist", "low", 5)
        return _decision(
            "Escalate",
            f"Unknown API endpoint: {resource}",
            "medium",
            50,
        )

    def _policy_git_push(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """git_push: Medium risk — code leaving the system."""
        return _decision("Escalate", "git_push requires review", "medium", 45)

    def _policy_git_commit(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """git_commit: Low-medium risk."""
        return _decision("Permit", "git_commit permitted", "low", 15)

    def _policy_calendar_access(self, resource: str, **ctx: Any) -> Dict[str, Any]:
        """calendar: Low risk for reads, medium for writes."""
        if "write" in resource.lower() or "create" in resource.lower():
            return _decision("Escalate", "Calendar write requires review", "medium", 35)
        return _decision("Permit", "Calendar read permitted", "low", 10)

    # ── Policy dispatch table ─────────────────────────────────────────

    _policies: Dict[str, Any] = {
        "shell_exec": _policy_shell_exec,
        "exec": _policy_shell_exec,
        "browser_navigate": _policy_browser_navigate,
        "browser_click": _policy_browser_click,
        "browser_fill": _policy_browser_fill,
        "file_read": _policy_file_read,
        "file_write": _policy_file_write,
        "email_send": _policy_email_send,
        "api_call": _policy_api_call,
        "git_push": _policy_git_push,
        "git_commit": _policy_git_commit,
        "calendar": _policy_calendar_access,
    }


def _decision(decision: str, reason: str, risk_level: str, score: int) -> Dict[str, Any]:
    """Build a policy decision dict."""
    return {
        "decision": decision,
        "reason": reason,
        "risk_level": risk_level,
        "risk_level_score": score,
    }
