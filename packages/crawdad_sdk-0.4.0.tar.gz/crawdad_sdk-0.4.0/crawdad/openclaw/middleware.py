"""CrawdadMiddleware — intercepts OpenClaw agent traffic through Crawdad's security pillars."""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar

from ..client import CrawdadClient
from .credentials import CredentialDetector
from .policy import PolicyGate

F = TypeVar("F", bound=Callable[..., Any])


class CrawdadMiddleware:
    """Security middleware that intercepts OpenClaw agent traffic.

    Intercepts:
    - Inbound messages before they reach the agent loop
    - Outbound content before it leaves the agent
    - Tool execution requests through the policy engine
    - Hook/heartbeat payloads through the firewall

    Args:
        base_url: Crawdad server URL.
        api_key: Crawdad API key.
        auto_block_malicious: Automatically block Malicious verdicts.
        pii_scan_outbound: Scan outbound content for PII.
        credential_scan: Scan for leaked credentials.
        timeout: HTTP timeout in seconds.
        transport: Optional httpx transport (for testing).
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        auto_block_malicious: bool = True,
        pii_scan_outbound: bool = True,
        credential_scan: bool = True,
        timeout: float = 30.0,
        transport: Any = None,
    ) -> None:
        kwargs: Dict[str, Any] = {"timeout": timeout}
        if transport is not None:
            kwargs["transport"] = transport
        self._client = CrawdadClient(base_url, api_key, **kwargs)
        self._auto_block = auto_block_malicious
        self._pii_scan = pii_scan_outbound
        self._credential_scan = credential_scan
        self._credential_detector = CredentialDetector()
        self._policy_gate = PolicyGate(self._client)

    @property
    def client(self) -> CrawdadClient:
        """Access the underlying CrawdadClient."""
        return self._client

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "CrawdadMiddleware":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Inbound scanning ──────────────────────────────────────────────

    def scan_inbound(self, message: str, *, direction: str = "inbound") -> Dict[str, Any]:
        """Scan an inbound message through the firewall before it reaches the agent.

        Returns:
            Dict with keys: blocked (bool), verdict, threat_score, patterns_detected, reason
        """
        analysis = self._client.analyze(message, direction=direction)
        verdict = analysis.get("verdict", "Clean")
        blocked = self._auto_block and verdict == "Malicious"
        reason = ""
        if blocked:
            patterns = analysis.get("patterns_detected", [])
            reason = f"Malicious content detected: {', '.join(patterns)}" if patterns else "Malicious content detected"
        return {
            "blocked": blocked,
            "verdict": verdict,
            "threat_score": analysis.get("threat_score", 0),
            "patterns_detected": analysis.get("patterns_detected", []),
            "confidence": analysis.get("confidence", 0.0),
            "reason": reason,
            "raw": analysis,
        }

    # ── Outbound scanning ─────────────────────────────────────────────

    def scan_outbound(self, content: str) -> Dict[str, Any]:
        """Scan outbound content for PII and credentials before it leaves the agent.

        Returns:
            Dict with keys: pii_found (bool), credentials_found (bool),
            redacted (str), detections, credential_detections
        """
        result: Dict[str, Any] = {
            "pii_found": False,
            "credentials_found": False,
            "redacted": content,
            "detections": [],
            "credential_detections": [],
            "blocked": False,
            "reason": "",
        }

        # PII scan
        if self._pii_scan:
            pii = self._client.scan_pii(content)
            if pii.get("count", 0) > 0:
                result["pii_found"] = True
                result["detections"] = pii.get("detections", [])
                # Redact PII
                transformed = self._client.transform(content, mode="redact")
                result["redacted"] = transformed.get("transformed_text", content)

        # Credential scan
        if self._credential_scan:
            creds = self._credential_detector.scan_content(content)
            if creds:
                result["credentials_found"] = True
                result["credential_detections"] = creds
                result["blocked"] = True
                result["reason"] = f"Credentials detected: {', '.join(c['type'] for c in creds)}"

        # Output guard
        guard = self._client.guard(content, trust_level="Medium")
        if not guard.get("action_allowed", True):
            result["blocked"] = True
            result["reason"] = result["reason"] or f"Output guard blocked: {', '.join(guard.get('flags', []))}"

        return result

    # ── Action authorization ──────────────────────────────────────────

    def authorize_action(
        self,
        agent_id: str,
        action: str,
        resource: str,
        *,
        context: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Evaluate a tool execution request through the policy engine.

        First checks the local PolicyGate for OpenClaw-specific tool rules,
        then evaluates through the Crawdad policy engine.

        Returns:
            Dict with keys: decision (Permit/Deny/Escalate), risk_score, reason,
            policy_check (local policy result)
        """
        # Local policy check first
        local_result = self._policy_gate.evaluate(action, resource)

        # If local policy denies, short-circuit
        if local_result["decision"] == "Deny":
            return {
                "decision": "Deny",
                "risk_score": local_result.get("risk_level_score", 100),
                "reason": local_result["reason"],
                "policy_check": local_result,
                "raw": None,
            }

        # Server-side policy evaluation
        server_result = self._client.evaluate(
            agent_id, action, resource, context=context
        )

        decision = server_result.get("decision", "Deny")
        # If local policy escalates, override server permit
        if local_result["decision"] == "Escalate" and decision == "Permit":
            decision = "Escalate"

        return {
            "decision": decision,
            "risk_score": server_result.get("risk_score", 0),
            "reason": server_result.get("reason", ""),
            "policy_check": local_result,
            "raw": server_result,
        }

    # ── Hook/heartbeat scanning ───────────────────────────────────────

    def scan_hook(self, payload: str) -> Dict[str, Any]:
        """Scan a hook or heartbeat payload through the firewall.

        Returns:
            Same format as scan_inbound.
        """
        return self.scan_inbound(payload, direction="inbound")

    # ── Decorators ────────────────────────────────────────────────────

    def firewall_scan(self, func: F) -> F:
        """Decorator that scans the first string argument through the firewall.

        Raises ValueError if the content is blocked.
        """
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Find the first string argument
            text = None
            for arg in args:
                if isinstance(arg, str):
                    text = arg
                    break
            if text is None:
                for v in kwargs.values():
                    if isinstance(v, str):
                        text = v
                        break
            if text is not None:
                result = self.scan_inbound(text)
                if result["blocked"]:
                    raise ValueError(f"Blocked by Crawdad firewall: {result['reason']}")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]

    def policy_check(self, agent_id: str, action: str) -> Callable[[F], F]:
        """Decorator factory that checks policy before executing.

        Usage:
            @middleware.policy_check(agent_id, "file_read")
            def read_file(path):
                ...

        Raises ValueError if the action is denied.
        """
        def decorator(func: F) -> F:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                # Use first string arg as resource
                resource = ""
                for arg in args:
                    if isinstance(arg, str):
                        resource = arg
                        break
                result = self.authorize_action(agent_id, action, resource)
                if result["decision"] == "Deny":
                    raise ValueError(f"Blocked by Crawdad policy: {result['reason']}")
                return func(*args, **kwargs)
            return wrapper  # type: ignore[return-value]
        return decorator

    def pii_scan(self, func: F) -> F:
        """Decorator that scans the return value for PII.

        Replaces the return value with the redacted version if PII is found.
        """
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            result = func(*args, **kwargs)
            if isinstance(result, str):
                scan = self.scan_outbound(result)
                if scan["pii_found"] or scan["credentials_found"]:
                    return scan["redacted"]
            return result
        return wrapper  # type: ignore[return-value]
