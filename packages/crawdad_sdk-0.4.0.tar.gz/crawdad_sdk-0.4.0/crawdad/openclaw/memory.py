"""MemoryGuard — wraps OpenClaw's SOUL.md and MEMORY.md with Crawdad memory integrity."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Dict, Optional

from ..client import CrawdadClient


def _file_hash(path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


class MemoryGuard:
    """Protects OpenClaw's SOUL.md and MEMORY.md with Crawdad's memory integrity.

    Wraps file writes with firewall scanning, stores content in Crawdad's
    Merkle-chained memory, and detects tampering.

    Args:
        client: A configured CrawdadClient instance.
    """

    def __init__(self, client: CrawdadClient) -> None:
        self._client = client
        self._known_hashes: Dict[str, str] = {}

    def write_memory(
        self,
        agent_id: str,
        content: str,
        file_path: str,
        *,
        source: str = "OpenClaw",
        reason: str = "memory update",
    ) -> Dict[str, Any]:
        """Write content to both Crawdad memory and a local markdown file.

        1. Scans content through the firewall.
        2. Writes to Crawdad's Merkle-chained memory.
        3. Updates the local markdown file.
        4. Records the file hash for tamper detection.

        Args:
            agent_id: Crawdad agent ID.
            content: Content to write.
            file_path: Path to the local markdown file (MEMORY.md or SOUL.md).
            source: Source identifier for the memory entry.
            reason: Reason for the write.

        Returns:
            Dict with entry_id, chain_hash, firewall_verdict, and file_hash.
        """
        # Step 1: Scan content through firewall
        firewall = self._client.analyze(content)
        verdict = firewall.get("verdict", "Clean")

        if verdict == "Malicious":
            return {
                "blocked": True,
                "reason": f"Content blocked by firewall: {', '.join(firewall.get('patterns_detected', []))}",
                "firewall_verdict": verdict,
                "entry_id": None,
                "chain_hash": None,
                "file_hash": None,
            }

        # Step 2: Write to Crawdad memory
        mem = self._client.write(agent_id, content, source, "openclaw-guard", reason)

        # Step 3: Update local file
        p = Path(file_path)
        if p.exists():
            existing = p.read_text()
            new_content = existing + "\n" + content
        else:
            new_content = content
        p.write_text(new_content)

        # Step 4: Record file hash
        file_hash = _file_hash(p)
        self._known_hashes[file_path] = file_hash

        return {
            "blocked": False,
            "entry_id": mem.get("entry_id"),
            "chain_hash": mem.get("chain_hash"),
            "firewall_verdict": verdict,
            "file_hash": file_hash,
        }

    def verify_integrity(self, agent_id: str) -> Dict[str, Any]:
        """Verify the Merkle chain integrity for an agent's memory.

        Args:
            agent_id: Crawdad agent ID.

        Returns:
            Dict with chain_valid, entry_count, and agent_id.
        """
        return self._client.verify(agent_id)

    def detect_tampering(self, file_path: str) -> Dict[str, Any]:
        """Check if a file has been tampered with since the last known good state.

        Args:
            file_path: Path to the file to check.

        Returns:
            Dict with tampered (bool), current_hash, known_hash, and file_path.
        """
        p = Path(file_path)
        if not p.exists():
            return {
                "tampered": True,
                "reason": "file does not exist",
                "current_hash": None,
                "known_hash": self._known_hashes.get(file_path),
                "file_path": file_path,
            }

        current_hash = _file_hash(p)
        known_hash = self._known_hashes.get(file_path)

        if known_hash is None:
            # First check — record the hash
            self._known_hashes[file_path] = current_hash
            return {
                "tampered": False,
                "reason": "first verification — hash recorded",
                "current_hash": current_hash,
                "known_hash": None,
                "file_path": file_path,
            }

        tampered = current_hash != known_hash
        return {
            "tampered": tampered,
            "reason": "hash mismatch — file was modified" if tampered else "hash matches",
            "current_hash": current_hash,
            "known_hash": known_hash,
            "file_path": file_path,
        }

    def protect_soul(self, soul_md_path: str) -> Dict[str, Any]:
        """Set up integrity monitoring for a SOUL.md file.

        Records the current file hash as the known good state.

        Args:
            soul_md_path: Path to the SOUL.md file.

        Returns:
            Dict with file_path, hash, and protected status.
        """
        p = Path(soul_md_path)
        if not p.exists():
            return {
                "protected": False,
                "reason": "file does not exist",
                "file_path": soul_md_path,
                "hash": None,
            }

        h = _file_hash(p)
        self._known_hashes[soul_md_path] = h
        return {
            "protected": True,
            "reason": "hash recorded — monitoring active",
            "file_path": soul_md_path,
            "hash": h,
        }

    def restore_soul(self, agent_id: str, soul_md_path: str) -> Dict[str, Any]:
        """Restore SOUL.md from the last verified good memory state.

        Reads the memory chain from Crawdad and reconstructs the file
        from the most recent memory entries.

        Args:
            agent_id: Crawdad agent ID.
            soul_md_path: Path to the SOUL.md file to restore.

        Returns:
            Dict with restored (bool), entry_count, and file_hash.
        """
        # Read memory chain
        chain = self._client.read(agent_id)
        entries = chain.get("entries", [])

        if not entries:
            return {
                "restored": False,
                "reason": "no memory entries found for this agent",
                "entry_count": 0,
                "file_hash": None,
            }

        # Reconstruct content from memory entries
        content_parts = []
        for entry in entries:
            c = entry.get("content", "")
            if c:
                content_parts.append(c)

        restored_content = "\n".join(content_parts)

        # Write to file
        p = Path(soul_md_path)
        p.write_text(restored_content)

        # Update known hash
        file_hash = _file_hash(p)
        self._known_hashes[soul_md_path] = file_hash

        return {
            "restored": True,
            "reason": f"restored from {len(entries)} memory entries",
            "entry_count": len(entries),
            "file_hash": file_hash,
        }
