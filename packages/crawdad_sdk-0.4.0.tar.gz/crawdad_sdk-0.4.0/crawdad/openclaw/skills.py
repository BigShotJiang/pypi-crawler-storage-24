"""SkillScanner — parse, hash, and security-scan OpenClaw SKILL.md files."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Patterns that indicate malicious intent ───────────────────────────

_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?(prior|previous|above)", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+", re.IGNORECASE),
    re.compile(r"system\s*prompt", re.IGNORECASE),
    re.compile(r"reveal\s+(your|the)\s+(system|secret|hidden)", re.IGNORECASE),
    re.compile(r"override\s+(all\s+)?safety", re.IGNORECASE),
    re.compile(r"jailbreak", re.IGNORECASE),
    re.compile(r"do\s+anything\s+now", re.IGNORECASE),
    re.compile(r"act\s+as\s+(if\s+you\s+are|a)\s+", re.IGNORECASE),
    re.compile(r"pretend\s+(you\s+are|to\s+be)\s+", re.IGNORECASE),
]

_EXFILTRATION_PATTERNS = [
    re.compile(r"curl\s+(-[a-zA-Z]\s+)*https?://", re.IGNORECASE),
    re.compile(r"wget\s+https?://", re.IGNORECASE),
    re.compile(r"fetch\s*\(\s*['\"]https?://", re.IGNORECASE),
    re.compile(r"requests?\.(get|post|put)\s*\(", re.IGNORECASE),
    re.compile(r"httpx?\.(get|post|put)\s*\(", re.IGNORECASE),
    re.compile(r"urllib\.request", re.IGNORECASE),
    re.compile(r"base64\.(b64encode|encode)", re.IGNORECASE),
    re.compile(r"\.encode\s*\(\s*['\"]base64", re.IGNORECASE),
    re.compile(r"subprocess\.(run|call|Popen)", re.IGNORECASE),
    re.compile(r"os\.system\s*\(", re.IGNORECASE),
    re.compile(r"exec\s*\(", re.IGNORECASE),
    re.compile(r"eval\s*\(", re.IGNORECASE),
]

_SUSPICIOUS_CAPABILITIES = [
    "shell_exec",
    "network_access",
    "file_write",
    "system_admin",
    "credential_access",
    "process_control",
]


class AttestationResult:
    """Result of scanning an OpenClaw skill for security issues.

    Attributes:
        status: "safe", "suspicious", or "malicious".
        reasons: List of reasons for the status.
        skill_name: Name of the skill.
        skill_version: Version of the skill.
        file_hashes: Dict mapping file paths to their SHA-256 hashes.
        declared_capabilities: List of capabilities declared by the skill.
        injection_patterns: List of injection patterns found.
        exfiltration_patterns: List of exfiltration patterns found.
    """

    def __init__(
        self,
        status: str,
        reasons: List[str],
        *,
        skill_name: str = "",
        skill_version: str = "",
        file_hashes: Optional[Dict[str, str]] = None,
        declared_capabilities: Optional[List[str]] = None,
        injection_patterns: Optional[List[str]] = None,
        exfiltration_patterns: Optional[List[str]] = None,
    ) -> None:
        self.status = status
        self.reasons = reasons
        self.skill_name = skill_name
        self.skill_version = skill_version
        self.file_hashes = file_hashes or {}
        self.declared_capabilities = declared_capabilities or []
        self.injection_patterns = injection_patterns or []
        self.exfiltration_patterns = exfiltration_patterns or []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "reasons": self.reasons,
            "skill_name": self.skill_name,
            "skill_version": self.skill_version,
            "file_hashes": self.file_hashes,
            "declared_capabilities": self.declared_capabilities,
            "injection_patterns": self.injection_patterns,
            "exfiltration_patterns": self.exfiltration_patterns,
        }


def _parse_skill_md(content: str) -> Dict[str, Any]:
    """Parse a SKILL.md file with YAML frontmatter.

    Returns a dict with parsed frontmatter fields and the body content.
    """
    result: Dict[str, Any] = {"_body": "", "_raw_frontmatter": ""}

    # Check for YAML frontmatter delimiters
    if not content.startswith("---"):
        return {"_body": content, "_raw_frontmatter": "", "_parse_error": "no frontmatter"}

    parts = content.split("---", 2)
    if len(parts) < 3:
        return {"_body": content, "_raw_frontmatter": "", "_parse_error": "malformed frontmatter"}

    frontmatter = parts[1].strip()
    body = parts[2].strip()
    result["_raw_frontmatter"] = frontmatter
    result["_body"] = body

    # Simple YAML-like parsing (avoid external dependency)
    current_key = ""
    current_list: Optional[List[str]] = None
    for line in frontmatter.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        # List item
        if stripped.startswith("- "):
            if current_list is not None:
                current_list.append(stripped[2:].strip())
            continue

        # Key-value pair
        if ":" in stripped:
            if current_list is not None and current_key:
                result[current_key] = current_list
                current_list = None

            key, _, value = stripped.partition(":")
            key = key.strip()
            value = value.strip()

            if not value:
                # Could be a list or multi-line value
                current_key = key
                current_list = []
            elif value == ">":
                # Multi-line scalar — collect following indented lines
                current_key = key
                current_list = None
                result[key] = ""
            else:
                result[key] = value.strip('"').strip("'")
                current_key = key
                current_list = None

    # Flush last list
    if current_list is not None and current_key:
        result[current_key] = current_list

    return result


def _hash_file(path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    data = path.read_bytes()
    h.update(data)
    return h.hexdigest()


def _hash_content(content: str) -> str:
    """Compute SHA-256 hash of a string."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class SkillScanner:
    """Scans OpenClaw skills for security issues.

    Parses SKILL.md files, hashes all skill files, and scans content
    for injection patterns, exfiltration attempts, and suspicious capabilities.
    """

    def scan_skill(self, skill_directory: str) -> AttestationResult:
        """Scan a local OpenClaw skill directory.

        Args:
            skill_directory: Path to the skill directory containing SKILL.md.

        Returns:
            AttestationResult with status, reasons, and file hashes.
        """
        skill_dir = Path(skill_directory)
        reasons: List[str] = []
        injection_found: List[str] = []
        exfiltration_found: List[str] = []

        # Check SKILL.md exists
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            return AttestationResult(
                "malicious",
                ["SKILL.md not found — cannot verify skill identity"],
                skill_name="unknown",
            )

        # Parse SKILL.md
        content = skill_md.read_text()
        metadata = _parse_skill_md(content)
        skill_name = metadata.get("name", "unknown")
        skill_version = metadata.get("version", "unknown")

        if "_parse_error" in metadata:
            reasons.append(f"SKILL.md parse error: {metadata['_parse_error']}")

        # Extract declared capabilities
        declared_caps: List[str] = []
        perms = metadata.get("permissions", [])
        if isinstance(perms, list):
            declared_caps.extend(perms)
        caps = metadata.get("capabilities", [])
        if isinstance(caps, list):
            declared_caps.extend(caps)

        # Check for suspicious capabilities
        for cap in declared_caps:
            if cap in _SUSPICIOUS_CAPABILITIES:
                reasons.append(f"Suspicious capability requested: {cap}")

        # Hash all files in the directory
        file_hashes: Dict[str, str] = {}
        all_content = ""
        for fpath in sorted(skill_dir.rglob("*")):
            if fpath.is_file():
                rel = str(fpath.relative_to(skill_dir))
                file_hashes[rel] = _hash_file(fpath)
                try:
                    text = fpath.read_text(errors="ignore")
                    all_content += text + "\n"
                except Exception:
                    pass

        # Scan all content for injection patterns
        for pattern in _INJECTION_PATTERNS:
            matches = pattern.findall(all_content)
            if matches:
                injection_found.append(pattern.pattern)

        # Scan all content for exfiltration patterns
        for pattern in _EXFILTRATION_PATTERNS:
            matches = pattern.findall(all_content)
            if matches:
                exfiltration_found.append(pattern.pattern)

        # Determine status
        if injection_found or exfiltration_found:
            status = "malicious"
            if injection_found:
                reasons.append(f"Injection patterns detected: {len(injection_found)} pattern(s)")
            if exfiltration_found:
                reasons.append(f"Exfiltration patterns detected: {len(exfiltration_found)} pattern(s)")
        elif reasons:
            status = "suspicious"
        else:
            status = "safe"
            reasons.append("No security issues found")

        return AttestationResult(
            status,
            reasons,
            skill_name=skill_name,
            skill_version=skill_version,
            file_hashes=file_hashes,
            declared_capabilities=declared_caps,
            injection_patterns=injection_found,
            exfiltration_patterns=exfiltration_found,
        )

    def scan_skill_content(self, name: str, content: str) -> AttestationResult:
        """Scan skill content provided as a string (e.g. from ClawHub).

        Args:
            name: Skill name.
            content: Full content of the skill (SKILL.md + code combined).

        Returns:
            AttestationResult with status and reasons.
        """
        reasons: List[str] = []
        injection_found: List[str] = []
        exfiltration_found: List[str] = []

        # Parse if it looks like SKILL.md
        metadata: Dict[str, Any] = {}
        if content.startswith("---"):
            metadata = _parse_skill_md(content)

        skill_name = metadata.get("name", name)
        skill_version = metadata.get("version", "unknown")

        # Extract capabilities
        declared_caps: List[str] = []
        for key in ("permissions", "capabilities"):
            val = metadata.get(key, [])
            if isinstance(val, list):
                declared_caps.extend(val)

        for cap in declared_caps:
            if cap in _SUSPICIOUS_CAPABILITIES:
                reasons.append(f"Suspicious capability requested: {cap}")

        # Scan for injection patterns
        for pattern in _INJECTION_PATTERNS:
            if pattern.search(content):
                injection_found.append(pattern.pattern)

        # Scan for exfiltration patterns
        for pattern in _EXFILTRATION_PATTERNS:
            if pattern.search(content):
                exfiltration_found.append(pattern.pattern)

        # Hash the content
        content_hash = _hash_content(content)
        file_hashes = {"content": content_hash}

        # Determine status
        if injection_found or exfiltration_found:
            status = "malicious"
            if injection_found:
                reasons.append(f"Injection patterns detected: {len(injection_found)} pattern(s)")
            if exfiltration_found:
                reasons.append(f"Exfiltration patterns detected: {len(exfiltration_found)} pattern(s)")
        elif reasons:
            status = "suspicious"
        else:
            status = "safe"
            reasons.append("No security issues found")

        return AttestationResult(
            status,
            reasons,
            skill_name=skill_name,
            skill_version=skill_version,
            file_hashes=file_hashes,
            declared_capabilities=declared_caps,
            injection_patterns=injection_found,
            exfiltration_patterns=exfiltration_found,
        )

    def parse_skill_md(self, content: str) -> Dict[str, Any]:
        """Parse a SKILL.md file and return the metadata.

        Public wrapper around the internal parser.
        """
        return _parse_skill_md(content)
