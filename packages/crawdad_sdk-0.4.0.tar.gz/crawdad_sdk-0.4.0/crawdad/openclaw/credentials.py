"""CredentialDetector — detects leaked API keys, SSH keys, wallet mnemonics, and more."""

from __future__ import annotations

import re
from typing import Any, Dict, List


# ── Credential patterns ───────────────────────────────────────────────

_PATTERNS: List[Dict[str, Any]] = [
    # API Keys
    {
        "type": "openai_api_key",
        "label": "OpenAI API Key",
        "pattern": re.compile(r"sk-[A-Za-z0-9]{20,}T3BlbkFJ[A-Za-z0-9]{20,}"),
    },
    {
        "type": "openai_api_key_new",
        "label": "OpenAI API Key (new format)",
        "pattern": re.compile(r"sk-proj-[A-Za-z0-9_-]{40,}"),
    },
    {
        "type": "anthropic_api_key",
        "label": "Anthropic API Key",
        "pattern": re.compile(r"sk-ant-[A-Za-z0-9_-]{40,}"),
    },
    {
        "type": "google_api_key",
        "label": "Google API Key",
        "pattern": re.compile(r"AIza[A-Za-z0-9_-]{35}"),
    },
    {
        "type": "github_token",
        "label": "GitHub Token",
        "pattern": re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),
    },
    {
        "type": "github_fine_grained_token",
        "label": "GitHub Fine-Grained Token",
        "pattern": re.compile(r"github_pat_[A-Za-z0-9_]{22,}"),
    },
    # AWS
    {
        "type": "aws_access_key",
        "label": "AWS Access Key ID",
        "pattern": re.compile(r"AKIA[0-9A-Z]{16}"),
    },
    {
        "type": "aws_secret_key",
        "label": "AWS Secret Access Key",
        "pattern": re.compile(r"(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])"),
        "requires_context": re.compile(r"(?i)(aws|secret|access_key|credential)"),
    },
    # SSH Keys
    {
        "type": "ssh_private_key",
        "label": "SSH Private Key",
        "pattern": re.compile(r"-----BEGIN (RSA |EC |ED25519 |DSA |OPENSSH )?PRIVATE KEY-----"),
    },
    # PGP Keys
    {
        "type": "pgp_private_key",
        "label": "PGP Private Key",
        "pattern": re.compile(r"-----BEGIN PGP PRIVATE KEY BLOCK-----"),
    },
    # Crypto Wallets
    {
        "type": "crypto_mnemonic",
        "label": "Cryptocurrency Wallet Mnemonic",
        "pattern": re.compile(
            r"\b(abandon|ability|able|about|above|absent|absorb|abstract|absurd|abuse|access|accident|"
            r"account|accuse|achieve|acid|acoustic|acquire|across|action|actor|actress|actual|adapt|"
            r"add|addict|address|adjust|admit|adult|advance|advice|aerobic|affair|afford|afraid|"
            r"again|age|agent|agree|ahead|aim|air|airport|aisle|alarm|album|alcohol|alert|alien|"
            r"all|alley|allow|almost|alone|alpha|already|also|alter|always|amateur|amazing|among|"
            r"amount|amused|analyst|anchor|ancient|anger|angle|angry|animal|ankle|announce|annual|"
            r"another|answer|antenna|antique|anxiety|any|apart|apology|appear|apple|approve|april|"
            r"arch|arctic|area|arena|argue|arm|armed|armor|army|around|arrange|arrest|arrive|arrow|"
            r"art|artefact|artist|artwork|ask|aspect|assault|asset|assist|assume|asthma|athlete|atom|"
            r"attack|attend|attitude|attract|auction|audit|august|aunt|author|auto|autumn|average|"
            r"avocado|avoid|awake|aware|awesome|awful|awkward|axis)"
            r"(\s+(abandon|ability|able|about|above|absent|absorb|abstract|absurd|abuse|access|accident|"
            r"account|accuse|achieve|acid|acoustic|acquire|across|action|actor|actress|actual|adapt|"
            r"add|addict|address|adjust|admit|adult|advance|advice|aerobic|affair|afford|afraid|"
            r"again|age|agent|agree|ahead|aim|air|airport|aisle|alarm|album|alcohol|alert|alien|"
            r"all|alley|allow|almost|alone|alpha|already|also|alter|always|amateur|amazing|among|"
            r"amount|amused|analyst|anchor|ancient|anger|angle|angry|animal|ankle|announce|annual|"
            r"another|answer|antenna|antique|anxiety|any|apart|apology|appear|apple|approve|april|"
            r"arch|arctic|area|arena|argue|arm|armed|armor|army|around|arrange|arrest|arrive|arrow|"
            r"art|artefact|artist|artwork|ask|aspect|assault|asset|assist|assume|asthma|athlete|atom|"
            r"attack|attend|attitude|attract|auction|audit|august|aunt|author|auto|autumn|average|"
            r"avocado|avoid|awake|aware|awesome|awful|awkward|axis)){11,23}\b"
        ),
    },
    {
        "type": "ethereum_private_key",
        "label": "Ethereum Private Key",
        "pattern": re.compile(r"0x[0-9a-fA-F]{64}"),
    },
    # Database connection strings
    {
        "type": "database_url",
        "label": "Database Connection String",
        "pattern": re.compile(
            r"(postgres(ql)?|mysql|mongodb(\+srv)?|redis|mssql)://[^\s'\"]{10,}"
        ),
    },
    # Stripe
    {
        "type": "stripe_secret_key",
        "label": "Stripe Secret Key",
        "pattern": re.compile(r"sk_(test|live)_[A-Za-z0-9]{24,}"),
    },
    # Slack
    {
        "type": "slack_token",
        "label": "Slack Token",
        "pattern": re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}"),
    },
    # Twilio
    {
        "type": "twilio_api_key",
        "label": "Twilio API Key",
        "pattern": re.compile(r"SK[0-9a-fA-F]{32}"),
    },
    # SendGrid
    {
        "type": "sendgrid_api_key",
        "label": "SendGrid API Key",
        "pattern": re.compile(r"SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}"),
    },
    # Generic secret patterns
    {
        "type": "generic_secret",
        "label": "Generic Secret/Token",
        "pattern": re.compile(
            r"(?i)(api[_-]?key|api[_-]?secret|auth[_-]?token|secret[_-]?key|access[_-]?token|"
            r"private[_-]?key|client[_-]?secret)\s*[:=]\s*['\"]?([A-Za-z0-9_/+=-]{20,})['\"]?"
        ),
    },
]


class CredentialDetector:
    """Detects leaked credentials in text content.

    Scans for:
    - API keys: OpenAI, Anthropic, Google, AWS, GitHub, Stripe, Slack, Twilio, SendGrid
    - SSH private keys, PGP private keys
    - Cryptocurrency wallet mnemonics and Ethereum private keys
    - Database connection strings (Postgres, MySQL, MongoDB, Redis, MSSQL)
    - Generic secret/token assignment patterns
    """

    def __init__(self, *, extra_patterns: Optional[List[Dict[str, Any]]] = None) -> None:
        self._patterns = list(_PATTERNS)
        if extra_patterns:
            self._patterns.extend(extra_patterns)

    def scan_content(self, text: str) -> List[Dict[str, Any]]:
        """Scan text for credential patterns.

        Args:
            text: The text to scan.

        Returns:
            List of dicts, each with:
            - type: credential type identifier
            - label: human-readable label
            - start: start position in text
            - end: end position in text
            - matched_text: the matched text (partially redacted)
        """
        detections: List[Dict[str, Any]] = []

        for spec in self._patterns:
            pattern = spec["pattern"]
            requires_context = spec.get("requires_context")

            # If the pattern requires context (e.g. AWS secret key needs "aws" nearby),
            # check for context first
            if requires_context and not requires_context.search(text):
                continue

            for match in pattern.finditer(text):
                matched = match.group(0)
                # Redact middle portion for safety
                if len(matched) > 12:
                    redacted = matched[:6] + "..." + matched[-4:]
                elif len(matched) > 6:
                    redacted = matched[:3] + "..." + matched[-2:]
                else:
                    redacted = matched[:2] + "..."

                detections.append({
                    "type": spec["type"],
                    "label": spec["label"],
                    "start": match.start(),
                    "end": match.end(),
                    "matched_text": redacted,
                })

        return detections

    def has_credentials(self, text: str) -> bool:
        """Quick check: does the text contain any credentials?"""
        return len(self.scan_content(text)) > 0
