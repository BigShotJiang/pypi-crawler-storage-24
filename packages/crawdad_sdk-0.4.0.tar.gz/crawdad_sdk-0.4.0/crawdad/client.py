"""Crawdad Python SDK client."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .exceptions import AuthenticationError, CrawdadError, NotFoundError, RateLimitError


def _raise_for_status(response: httpx.Response) -> None:
    """Raise a typed CrawdadError for non-2xx responses."""
    if response.is_success:
        return
    try:
        body = response.json()
        message = body.get("error", response.text)
    except Exception:
        message = response.text
    code = response.status_code
    if code == 401:
        raise AuthenticationError(message)
    if code == 404:
        raise NotFoundError(message)
    if code == 429:
        raise RateLimitError(message)
    raise CrawdadError(code, message)


class CrawdadClient:
    """Client for the Crawdad API.

    Args:
        base_url: Base URL of the Crawdad server (e.g. ``http://localhost:3000``).
        api_key: Value for the ``X-API-Key`` header.
        timeout: Request timeout in seconds. Defaults to ``30.0``.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        timeout: float = 30.0,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        kwargs: Dict[str, Any] = {
            "base_url": base_url.rstrip("/"),
            "headers": {"X-API-Key": api_key},
            "timeout": timeout,
        }
        if transport is not None:
            kwargs["transport"] = transport
        self._http = httpx.Client(**kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> "CrawdadClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── helpers ──────────────────────────────────────────────────────────

    def _get(self, path: str, **params: Any) -> Any:
        resp = self._http.get(path, params={k: v for k, v in params.items() if v is not None})
        _raise_for_status(resp)
        return resp.json()

    def _post(self, path: str, json: Any = None) -> Any:
        resp = self._http.post(path, json=json)
        _raise_for_status(resp)
        return resp.json()

    def _put(self, path: str, json: Any = None) -> Any:
        resp = self._http.put(path, json=json)
        _raise_for_status(resp)
        return resp.json()

    def _delete(self, path: str) -> Any:
        resp = self._http.delete(path)
        _raise_for_status(resp)
        return resp.json()

    # ── Identity ─────────────────────────────────────────────────────────

    def register_agent(self, display_name: str) -> Dict[str, Any]:
        """Register a new agent."""
        return self._post("/agents", json={"display_name": display_name})

    def get_agent(self, agent_id: str) -> Dict[str, Any]:
        """Get agent identity by ID."""
        return self._get(f"/agents/{agent_id}")

    def list_agents(self) -> List[Dict[str, Any]]:
        """List all registered agents."""
        return self._get("/agents")

    def revoke_agent(self, agent_id: str) -> Dict[str, Any]:
        """Revoke agent credentials (kill level 2)."""
        return self._post(f"/agents/{agent_id}/revoke")

    def emergency_halt(self) -> Dict[str, Any]:
        """Network-wide emergency halt (kill level 3)."""
        return self._post("/emergency/halt")

    # ── Policy ───────────────────────────────────────────────────────────

    def evaluate(
        self,
        agent_id: str,
        action: str,
        resource: str,
        *,
        context: Optional[Dict[str, str]] = None,
        behavioral_deviation: int = 0,
    ) -> Dict[str, Any]:
        """Evaluate an agent action against policy rules."""
        body: Dict[str, Any] = {
            "agent_id": agent_id,
            "action": action,
            "resource": resource,
            "behavioral_deviation": behavioral_deviation,
        }
        if context is not None:
            body["context"] = context
        return self._post("/policy/evaluate", json=body)

    def add_rule(self, rule_type: str, condition: str, action: str) -> Dict[str, Any]:
        """Add a policy rule."""
        return self._post(
            "/policy/rules",
            json={"rule_type": rule_type, "condition": condition, "action": action},
        )

    def list_rules(self, *, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """List policy rules."""
        return self._get("/policy/rules", limit=limit, offset=offset)

    def delete_rule(self, rule_id: str) -> Dict[str, Any]:
        """Delete a policy rule."""
        return self._delete(f"/policy/rules/{rule_id}")

    def get_baseline(self, agent_id: str) -> Dict[str, Any]:
        """Get behavioral baseline for an agent."""
        return self._get(f"/policy/baseline/{agent_id}")

    # ── Memory ───────────────────────────────────────────────────────────

    def write(
        self,
        agent_id: str,
        content: str,
        source: str,
        writer: str,
        reason: str,
    ) -> Dict[str, Any]:
        """Write an entry to agent memory."""
        return self._post(
            f"/memory/{agent_id}/write",
            json={"content": content, "source": source, "writer": writer, "reason": reason},
        )

    def read(self, agent_id: str) -> Dict[str, Any]:
        """Read the full memory chain for an agent."""
        return self._get(f"/memory/{agent_id}")

    def verify(self, agent_id: str) -> Dict[str, Any]:
        """Verify memory chain integrity."""
        return self._post(f"/memory/{agent_id}/verify")

    def rollback(self, agent_id: str, mode: Dict[str, Any]) -> Dict[str, Any]:
        """Rollback memory entries."""
        return self._post(f"/memory/{agent_id}/rollback", json=mode)

    def compact(
        self,
        agent_id: str,
        entry_ids: List[str],
        summary_content: str,
        summary_source: str,
    ) -> Dict[str, Any]:
        """Compact memory entries into a summary."""
        return self._post(
            f"/memory/{agent_id}/compact",
            json={
                "entry_ids": entry_ids,
                "summary_content": summary_content,
                "summary_source": summary_source,
            },
        )

    def get_seals(self, agent_id: str) -> Dict[str, Any]:
        """List compaction seals for an agent."""
        return self._get(f"/memory/{agent_id}/seals")

    # ── Skills ───────────────────────────────────────────────────────────

    def register_skill(
        self,
        name: str,
        version: str,
        author: str,
        description: str,
        content: str,
        capabilities_requested: List[str],
    ) -> Dict[str, Any]:
        """Register a skill manifest."""
        return self._post(
            "/skills/register",
            json={
                "name": name,
                "version": version,
                "author": author,
                "description": description,
                "content": content,
                "capabilities_requested": capabilities_requested,
            },
        )

    def list_skills(self, *, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """List all registered skills."""
        return self._get("/skills", limit=limit, offset=offset)

    def get_skill(self, skill_id: str) -> Dict[str, Any]:
        """Get skill manifest by ID."""
        return self._get(f"/skills/{skill_id}")

    def attest(self, skill_id: str) -> Dict[str, Any]:
        """Run attestation scanner on a skill."""
        return self._post(f"/skills/{skill_id}/attest")

    def check_capability(self, skill_id: str, agent_id: str) -> Dict[str, Any]:
        """Check if an agent can use a skill."""
        return self._post(f"/skills/{skill_id}/check", json={"agent_id": agent_id})

    def report_outcome(self, skill_id: str, outcome: str) -> Dict[str, Any]:
        """Report a skill invocation outcome (Success, Failure, Blocked)."""
        return self._post(f"/skills/{skill_id}/report-outcome", json={"outcome": outcome})

    def get_runtime(self, skill_id: str) -> Dict[str, Any]:
        """Get skill runtime profile."""
        return self._get(f"/skills/{skill_id}/runtime")

    def generate_sbom(
        self, skill_id: str, dependencies: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Generate SBOM for a skill."""
        return self._post(f"/skills/{skill_id}/sbom", json={"dependencies": dependencies})

    def get_sbom(self, skill_id: str) -> Dict[str, Any]:
        """Get stored SBOM for a skill."""
        return self._get(f"/skills/{skill_id}/sbom")

    def check_sbom(
        self,
        sbom: Dict[str, Any],
        known_vulnerabilities: List[Dict[str, Any]],
        *,
        license_policy: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Check SBOM against vulnerability database."""
        body: Dict[str, Any] = {"sbom": sbom, "known_vulnerabilities": known_vulnerabilities}
        if license_policy is not None:
            body["license_policy"] = license_policy
        return self._post("/skills/sbom/check", json=body)

    # ── Comms ────────────────────────────────────────────────────────────

    def send_message(self, from_agent: str, to_agent: str, content: str) -> Dict[str, Any]:
        """Send an inter-agent message."""
        return self._post(
            "/comms/send",
            json={"from_agent": from_agent, "to_agent": to_agent, "content": content},
        )

    def scan_message(self, content: str) -> Dict[str, Any]:
        """Pre-scan message content for threats."""
        return self._post("/comms/scan", json={"content": content})

    def delegate(
        self, from_agent: str, to_agent: str, scopes: List[str]
    ) -> Dict[str, Any]:
        """Create a delegation between agents."""
        return self._post(
            "/comms/delegate",
            json={"from_agent": from_agent, "to_agent": to_agent, "scopes": scopes},
        )

    def list_delegations(
        self, agent_id: str, *, limit: int = 50, offset: int = 0
    ) -> Dict[str, Any]:
        """List delegations for an agent."""
        return self._get(f"/comms/delegations/{agent_id}", limit=limit, offset=offset)

    def check_collusion(self, agent_a: str, agent_b: str) -> Dict[str, Any]:
        """Check for collusion between two agents."""
        return self._post(
            "/comms/check-collusion", json={"agent_a": agent_a, "agent_b": agent_b}
        )

    def isolate_agent(self, agent_id: str, level: str) -> Dict[str, Any]:
        """Isolate an agent (Soft, Hard, or Quarantine)."""
        return self._post(f"/comms/isolate/{agent_id}", json={"level": level})

    def release_agent(self, agent_id: str) -> Dict[str, Any]:
        """Release an agent from isolation."""
        return self._post(f"/comms/release/{agent_id}")

    def cascade_health(self, agent_id: str) -> Dict[str, Any]:
        """Get cascade breaker health for an agent."""
        return self._get(f"/comms/cascade/{agent_id}")

    def list_quarantined(self) -> Dict[str, Any]:
        """List all quarantined agents."""
        return self._get("/comms/quarantine")

    def validate_chain(self, chain: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Validate a delegation chain."""
        return self._post("/delegation/validate", json={"chain": chain})

    # ── Privacy ──────────────────────────────────────────────────────────

    def scan_pii(self, text: str) -> Dict[str, Any]:
        """Scan text for PII."""
        return self._post("/privacy/scan", json={"text": text})

    def transform(
        self, text: str, mode: str, *, key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Transform PII in text (redact, pseudonymize, tokenize, summarize)."""
        body: Dict[str, Any] = {"text": text, "mode": mode}
        if key is not None:
            body["key"] = key
        return self._post("/privacy/transform", json=body)

    def get_consent(self, agent_id: str) -> Dict[str, Any]:
        """Get consent records for an agent."""
        return self._get(f"/privacy/consent/{agent_id}")

    def update_consent(self, agent_id: str, consents: Dict[str, bool]) -> Dict[str, Any]:
        """Update consent for an agent."""
        return self._put(f"/privacy/consent/{agent_id}", json={"consents": consents})

    def submit_dsar(self, operation: str, subject_query: str) -> Dict[str, Any]:
        """Submit a Data Subject Access Request."""
        return self._post(
            "/privacy/dsar", json={"operation": operation, "subject_query": subject_query}
        )

    def list_jurisdictions(self) -> List[Dict[str, Any]]:
        """List all supported jurisdictions."""
        return self._get("/privacy/jurisdictions")

    def get_jurisdiction(self, country_code: str) -> Dict[str, Any]:
        """Get jurisdiction profile by country code."""
        return self._get(f"/privacy/jurisdiction/{country_code}")

    def compliance_check(
        self,
        country_code: str,
        operations: List[str],
        *,
        has_consent: bool = False,
    ) -> Dict[str, Any]:
        """Check data operation compliance against a jurisdiction."""
        return self._post(
            "/privacy/compliance-check",
            json={
                "country_code": country_code,
                "operations": operations,
                "has_consent": has_consent,
            },
        )

    def generate_report(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        stats: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Generate a compliance report."""
        return self._post(
            "/privacy/report/generate",
            json={
                "country_code": country_code,
                "period_start": period_start,
                "period_end": period_end,
                "stats": stats,
            },
        )

    def get_report(self, report_id: str) -> Dict[str, Any]:
        """Retrieve a compliance report by ID."""
        return self._get(f"/privacy/report/{report_id}")

    def private_query(
        self,
        count: int,
        config: Dict[str, Any],
        *,
        total_budget_epsilon: Optional[float] = None,
        queries_already_made: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Execute a differentially-private query."""
        body: Dict[str, Any] = {"count": count, "config": config}
        if total_budget_epsilon is not None:
            body["total_budget_epsilon"] = total_budget_epsilon
        if queries_already_made is not None:
            body["queries_already_made"] = queries_already_made
        return self._post("/privacy/query/private", json=body)

    # ── Firewall ─────────────────────────────────────────────────────────

    def analyze(
        self, input_text: str, *, direction: str = "inbound"
    ) -> Dict[str, Any]:
        """Analyze text for prompt injection and threats."""
        return self._post(
            "/firewall/analyze", json={"input": input_text, "direction": direction}
        )

    def stats(self) -> Dict[str, Any]:
        """Get firewall statistics."""
        return self._get("/firewall/stats")

    def guard(
        self,
        action_text: str,
        trust_level: str,
        *,
        input_context: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Evaluate a proposed agent action (output guard)."""
        body: Dict[str, Any] = {"action_text": action_text, "trust_level": trust_level}
        if input_context is not None:
            body["input_context"] = input_context
        return self._post("/firewall/guard", json=body)

    def density(self, text: str, session_id: str) -> Dict[str, Any]:
        """Score instruction density of text."""
        return self._post(
            "/firewall/density", json={"text": text, "session_id": session_id}
        )

    # ── Tokens ───────────────────────────────────────────────────────────

    def issue_token(
        self,
        agent_id: str,
        purpose: str,
        allowed_actions: List[str],
        allowed_resources: List[str],
        *,
        ttl_seconds: int = 3600,
        max_uses: int = 10,
    ) -> Dict[str, Any]:
        """Issue a scoped token for an agent."""
        return self._post(
            f"/agents/{agent_id}/tokens",
            json={
                "purpose": purpose,
                "allowed_actions": allowed_actions,
                "allowed_resources": allowed_resources,
                "ttl_seconds": ttl_seconds,
                "max_uses": max_uses,
            },
        )

    def list_tokens(self, agent_id: str) -> List[Dict[str, Any]]:
        """List tokens for an agent."""
        return self._get(f"/agents/{agent_id}/tokens")

    def validate_token(self, token_id: str, action: str, resource: str) -> Dict[str, Any]:
        """Validate a token against an action and resource."""
        return self._post(
            f"/tokens/{token_id}/validate", json={"action": action, "resource": resource}
        )

    def revoke_token(self, token_id: str) -> Dict[str, Any]:
        """Revoke a token."""
        return self._delete(f"/tokens/{token_id}")

    # ── Provenance ───────────────────────────────────────────────────────

    def get_provenance(self, data_id: str) -> Dict[str, Any]:
        """Trace data provenance."""
        return self._get(f"/provenance/{data_id}")

    def verify_provenance(self, tag: Dict[str, Any]) -> Dict[str, Any]:
        """Verify a provenance tag."""
        return self._post("/provenance/verify", json={"tag": tag})

    # ── System ───────────────────────────────────────────────────────────

    def health(self) -> Dict[str, Any]:
        """Health check (no auth required)."""
        resp = self._http.get("/health")
        _raise_for_status(resp)
        return resp.json()

    def metrics(self) -> Dict[str, Any]:
        """Server metrics (no auth required)."""
        resp = self._http.get("/metrics")
        _raise_for_status(resp)
        return resp.json()

    # ── OpenClaw convenience methods ──────────────────────────────────

    def scan_openclaw_skill(self, skill_directory: str) -> Any:
        """Scan an OpenClaw skill directory for security issues.

        Convenience wrapper around ``SkillScanner.scan_skill()``.

        Args:
            skill_directory: Path to the skill directory containing SKILL.md.

        Returns:
            AttestationResult from the SkillScanner.
        """
        from .openclaw.skills import SkillScanner
        scanner = SkillScanner()
        return scanner.scan_skill(skill_directory)

    def protect_openclaw_memory(self, soul_md_path: str) -> Dict[str, Any]:
        """Set up integrity monitoring for an OpenClaw SOUL.md file.

        Convenience wrapper around ``MemoryGuard.protect_soul()``.

        Args:
            soul_md_path: Path to the SOUL.md file.

        Returns:
            Protection result dict.
        """
        from .openclaw.memory import MemoryGuard
        guard = MemoryGuard(self)
        return guard.protect_soul(soul_md_path)

    def create_openclaw_middleware(self, agent_name: str = "openclaw-agent") -> Any:
        """Create a configured CrawdadMiddleware for OpenClaw.

        Uses this client's base_url and API key.

        Args:
            agent_name: Display name for the agent.

        Returns:
            Configured CrawdadMiddleware instance.
        """
        from .openclaw.middleware import CrawdadMiddleware
        base_url = str(self._http.base_url).rstrip("/")
        api_key = self._http.headers.get("X-API-Key", "")
        return CrawdadMiddleware(base_url, api_key)
