"""Crawdad Admin SDK client."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .exceptions import AuthenticationError, CrawdadError, NotFoundError, RateLimitError


def _raise_for_status(response: httpx.Response) -> None:
    """Raise a typed CrawdadError for non-2xx responses."""
    if response.is_success:
        return
    try:
        body = response.json()
        message = body.get("error", response.text)
    except Exception:
        message = response.text
    code = response.status_code
    if code == 401:
        raise AuthenticationError(message)
    if code == 404:
        raise NotFoundError(message)
    if code == 429:
        raise RateLimitError(message)
    raise CrawdadError(code, message)


class AdminClient:
    """Admin client for Crawdad tenant management.

    Args:
        base_url: Base URL of the Crawdad server.
        admin_key: Value for the ``X-Admin-Key`` header.
        timeout: Request timeout in seconds. Defaults to ``30.0``.
    """

    def __init__(
        self,
        base_url: str,
        admin_key: str,
        *,
        timeout: float = 30.0,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        kwargs: Dict[str, Any] = {
            "base_url": base_url.rstrip("/"),
            "headers": {"X-Admin-Key": admin_key},
            "timeout": timeout,
        }
        if transport is not None:
            kwargs["transport"] = transport
        self._http = httpx.Client(**kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> "AdminClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── helpers ──────────────────────────────────────────────────────────

    def _get(self, path: str, **params: Any) -> Any:
        resp = self._http.get(path, params={k: v for k, v in params.items() if v is not None})
        _raise_for_status(resp)
        return resp.json()

    def _post(self, path: str, json: Any = None) -> Any:
        resp = self._http.post(path, json=json)
        _raise_for_status(resp)
        return resp.json()

    # ── Tenant management ────────────────────────────────────────────────

    def create_tenant(self, name: str, *, plan: str = "free") -> Dict[str, Any]:
        """Create a new tenant."""
        return self._post("/admin/tenants", json={"name": name, "plan": plan})

    def list_tenants(self) -> List[Dict[str, Any]]:
        """List all tenants."""
        return self._get("/admin/tenants")

    def get_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """Get tenant details."""
        return self._get(f"/admin/tenants/{tenant_id}")

    def suspend_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """Suspend a tenant."""
        return self._post(f"/admin/tenants/{tenant_id}/suspend")

    def generate_key(self, tenant_id: str) -> Dict[str, Any]:
        """Generate a new API key for a tenant."""
        return self._post(f"/admin/tenants/{tenant_id}/keys")
