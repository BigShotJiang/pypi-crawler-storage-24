"""Pydantic models for Crawdad API request and response types."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Identity ────────────────────────────────────────────────────────────


class Agent(BaseModel):
    agent_id: str
    display_name: str
    did: Optional[str] = None
    did_document: Optional[Dict[str, Any]] = None
    public_key: Optional[str] = None
    trust_level: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None


class HaltResponse(BaseModel):
    status: str
    kill_level: int
    agents_affected: int


# ── Tokens ──────────────────────────────────────────────────────────────


class ScopedToken(BaseModel):
    token_id: str
    agent_id: str
    purpose: Optional[str] = None
    allowed_actions: List[str] = Field(default_factory=list)
    allowed_resources: List[str] = Field(default_factory=list)
    expires_at: Optional[datetime] = None
    max_uses: Optional[int] = None
    uses_remaining: Optional[int] = None
    revoked: Optional[bool] = None


class TokenValidation(BaseModel):
    valid: bool
    token_id: Optional[str] = None
    reason: Optional[str] = None


# ── Policy ──────────────────────────────────────────────────────────────


class PolicyRule(BaseModel):
    rule_id: str
    rule_type: str
    condition: str
    action: str


class EvaluationResult(BaseModel):
    agent_id: str
    decision: str
    risk_score: Optional[int] = None
    reason: Optional[str] = None
    matching_rules: List[Dict[str, Any]] = Field(default_factory=list)
    risk_breakdown: Optional[Dict[str, Any]] = None


class BehavioralProfile(BaseModel):
    agent_id: str
    action_counts: Dict[str, int] = Field(default_factory=dict)
    resource_counts: Dict[str, int] = Field(default_factory=dict)
    risk_scores: List[int] = Field(default_factory=list)
    anomaly_flags: List[str] = Field(default_factory=list)


# ── Memory ──────────────────────────────────────────────────────────────


class MemoryEntry(BaseModel):
    entry_id: str
    agent_id: Optional[str] = None
    content: Optional[str] = None
    source: Optional[str] = None
    timestamp: Optional[datetime] = None
    provenance: Optional[Dict[str, Any]] = None
    signature: Optional[str] = None
    chain_hash: Optional[str] = None
    prev_hash: Optional[str] = None


class MemoryWriteResponse(BaseModel):
    entry_id: str
    chain_hash: Optional[str] = None
    anomaly: Optional[Dict[str, Any]] = None


class MemoryVerifyResponse(BaseModel):
    agent_id: str
    chain_valid: bool
    entry_count: int


class RollbackResult(BaseModel):
    entries_removed: int
    entries_remaining: int
    chain_resealed: bool


class CompactionSeal(BaseModel):
    seal_id: str
    source_entry_ids: List[str] = Field(default_factory=list)
    source_hashes: List[str] = Field(default_factory=list)
    compaction_timestamp: Optional[datetime] = None
    resulting_summary_id: Optional[str] = None
    composite_provenance_score: Optional[float] = None
    seal_hash: Optional[str] = None


# ── Skills ──────────────────────────────────────────────────────────────


class SkillManifest(BaseModel):
    skill_id: str
    name: str
    version: Optional[str] = None
    author: Optional[str] = None
    description: Optional[str] = None
    sha256_hash: Optional[str] = None
    capabilities_requested: List[str] = Field(default_factory=list)
    attestation_status: Optional[str] = None


class ScanResult(BaseModel):
    risk_score: int
    hash_valid: bool
    injection_patterns: List[str] = Field(default_factory=list)
    capability_risk: Optional[str] = None
    recommended_status: Optional[str] = None


class SkillRuntimeProfile(BaseModel):
    skill_id: str
    invocation_count: Optional[int] = None
    success_count: Optional[int] = None
    failure_count: Optional[int] = None
    blocked_count: Optional[int] = None
    success_rate: Optional[float] = None
    last_invoked: Optional[datetime] = None
    behavioral_flags: List[str] = Field(default_factory=list)


class SbomEntry(BaseModel):
    name: str
    version: str
    license: Optional[str] = None
    purl: Optional[str] = None
    hashes: List[str] = Field(default_factory=list)


class SbomReport(BaseModel):
    skill_id: Optional[str] = None
    format: Optional[str] = None
    components: List[SbomEntry] = Field(default_factory=list)
    total_dependencies: Optional[int] = None
    known_vulnerable: List[Dict[str, Any]] = Field(default_factory=list)
    license_issues: List[Dict[str, Any]] = Field(default_factory=list)
    generated_at: Optional[datetime] = None


# ── Comms ───────────────────────────────────────────────────────────────


class MessageEnvelope(BaseModel):
    message_id: str
    from_agent: str
    to_agent: str
    content: Optional[str] = None
    timestamp: Optional[datetime] = None
    signed_hash: Optional[str] = None
    delegation_chain: List[str] = Field(default_factory=list)


class MessageFilterVerdict(BaseModel):
    threat_score: int
    recommendation: str
    pii_detected: List[str] = Field(default_factory=list)
    injection_detected: Optional[bool] = None


class Delegation(BaseModel):
    delegation_id: str
    from_agent: str
    to_agent: str
    scopes: List[str] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    chain: List[str] = Field(default_factory=list)


class ChainValidation(BaseModel):
    valid: bool
    depth: Optional[int] = None
    findings: List[str] = Field(default_factory=list)


class CollusionReport(BaseModel):
    agent_a: str
    agent_b: str
    collusion_score: float
    findings: List[Dict[str, Any]] = Field(default_factory=list)


class IsolationRecord(BaseModel):
    agent_id: str
    level: str
    isolated_at: Optional[datetime] = None


class CascadeHealth(BaseModel):
    agent_id: str
    fan_out: Optional[int] = None
    error_rate: Optional[float] = None
    status: Optional[str] = None


# ── Provenance ──────────────────────────────────────────────────────────


class ProvenanceTag(BaseModel):
    tag_id: str
    origin_agent: Optional[str] = None
    origin_entry_id: Optional[str] = None
    content_hash: Optional[str] = None
    initial_trust: Optional[float] = None
    trust_score: Optional[float] = None
    classification: Optional[str] = None
    chain: List[Dict[str, Any]] = Field(default_factory=list)
    tag_hash: Optional[str] = None


class LineageReport(BaseModel):
    tag_id: str
    hops: Optional[int] = None
    trust_degradation: Optional[float] = None
    chain_length: Optional[int] = None
    is_laundered: Optional[bool] = None
    valid_hash: Optional[bool] = None


# ── Privacy ─────────────────────────────────────────────────────────────


class PiiDetection(BaseModel):
    category: str
    confidence: float
    start: int
    end: int
    matched_text: Optional[str] = None


class PiiScanResponse(BaseModel):
    detections: List[PiiDetection] = Field(default_factory=list)
    categories_found: List[str] = Field(default_factory=list)
    count: int


class TransformResult(BaseModel):
    original_length: Optional[int] = None
    transformed_text: str
    transformations_applied: Optional[int] = None
    mode: Optional[str] = None
    token_map: Optional[Dict[str, str]] = None


class ConsentRecord(BaseModel):
    agent_id: str
    consents: Dict[str, bool] = Field(default_factory=dict)
    updated_at: Optional[datetime] = None


class DsarReport(BaseModel):
    operation: str
    subject_query: str
    entries_found: Optional[int] = None
    located_entries: List[Dict[str, Any]] = Field(default_factory=list)
    exported_data: List[Dict[str, Any]] = Field(default_factory=list)
    entries_deleted: Optional[int] = None


class JurisdictionProfile(BaseModel):
    jurisdiction: str
    name: Optional[str] = None
    applicable_law: Optional[str] = None
    requires_consent_before_processing: Optional[bool] = None
    right_to_erasure: Optional[bool] = None
    right_to_portability: Optional[bool] = None
    data_localization_required: Optional[bool] = None
    breach_notification_hours: Optional[int] = None
    minimum_age_for_consent: Optional[int] = None
    cross_border_transfer_restrictions: Optional[bool] = None
    dpa_authority: Optional[str] = None


class ComplianceReport(BaseModel):
    jurisdiction: Optional[str] = None
    operations_requiring_consent: List[str] = Field(default_factory=list)
    restricted_operations: List[Dict[str, Any]] = Field(default_factory=list)
    required_notifications: List[str] = Field(default_factory=list)
    compliant: Optional[bool] = None


class FullComplianceReport(BaseModel):
    report_id: str
    jurisdiction: Optional[str] = None
    generated_at: Optional[datetime] = None
    period_start: Optional[datetime] = None
    period_end: Optional[datetime] = None
    total_data_subjects: Optional[int] = None
    consent_coverage: Optional[float] = None
    dsar_requests: Optional[int] = None
    dsar_completed: Optional[int] = None
    dsar_avg_completion_hours: Optional[float] = None
    pii_detections: Optional[int] = None
    pii_transformations: Optional[int] = None
    breach_incidents: Optional[int] = None
    data_retention_compliance: Optional[bool] = None
    cross_border_transfers: Optional[int] = None
    compliant: Optional[bool] = None
    findings: List[Dict[str, Any]] = Field(default_factory=list)


class PrivateQueryResponse(BaseModel):
    original_value: Optional[float] = None
    noisy_value: float
    epsilon_used: Optional[float] = None
    mechanism: Optional[str] = None
    budget_remaining: Optional[float] = None
    budget_exhausted: Optional[bool] = None


# ── Firewall ────────────────────────────────────────────────────────────


class InputAnalysis(BaseModel):
    threat_score: int
    verdict: str
    patterns_detected: List[str] = Field(default_factory=list)
    deobfuscated: Optional[str] = None
    confidence: Optional[float] = None


class FirewallStats(BaseModel):
    total_analyzed: int
    total_blocked: int
    total_suspicious: int
    average_threat_score: Optional[float] = None


class OutputVerdict(BaseModel):
    action_allowed: bool
    risk_score: Optional[int] = None
    flags: List[str] = Field(default_factory=list)
    recommendation: Optional[str] = None


class DensityVerdict(BaseModel):
    density_score: float
    verdict: Optional[str] = None
    session_trend: Optional[str] = None


# ── System ──────────────────────────────────────────────────────────────


class HealthResponse(BaseModel):
    status: str


class MetricsResponse(BaseModel):
    uptime_seconds: int
    total_requests: int
    agents_registered: int
    audit_entries_count: int
    active_emergency_halt: bool
    memory_usage_bytes: int
