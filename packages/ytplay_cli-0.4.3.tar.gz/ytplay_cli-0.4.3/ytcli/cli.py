import argparse
import os
import subprocess

from ytcli.search import search_youtube
from ytcli.player import play_video, play_audio, download_video, open_in_browser
from ytcli.ui import select_video
from ytcli.utils import format_duration, format_views
from ytcli.config import load_config
from ytcli.deps import check_dependencies
from ytcli import __version__

HISTORY_FILE = os.path.expanduser("~/.local/share/yt-cli/history")

def save_history(query):
    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
    with open(HISTORY_FILE, "a") as f:
        f.write(query + "\n")

def show_history():
    if not os.path.exists(HISTORY_FILE):
        print("No history yet.")
        return
    with open(HISTORY_FILE) as f:
        print(f.read())

def fzf_menu(options, prompt):
    fzf = subprocess.Popen(
        [
            "fzf",
            "--height=40%",
            "--layout=reverse",
            "--border",
            "--prompt", prompt
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True
    )
    stdout, _ = fzf.communicate("\n".join(options))
    return stdout.strip()

def choose_action():
    actions = [
        "Play Video",
        "Play Audio Only",
        "Download Video",
        "Open in Browser"
    ]
    return fzf_menu(actions, "Action > ")

def choose_quality():
    qualities = [
        "1080",
        "720",
        "480",
        "best"
    ]
    return fzf_menu(qualities, "Quality > ")

def choose_speed():
    speeds = [
        "1",
        "1.25",
        "1.5",
        "2"
    ]
    return fzf_menu(speeds, "Speed > ")

def main():
    # 1. First-Run Auto-Installer checks
    check_dependencies()

    parser = argparse.ArgumentParser(
        description="YouTube CLI player"
    )

    parser.add_argument("query", nargs="*")
    parser.add_argument("--audio", action="store_true")
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--play", type=int)
    parser.add_argument("--history", action="store_true")
    parser.add_argument("--version", action="store_true")

    args = parser.parse_args()

    if args.version:
        print("yt-cli version", __version__)
        return

    if args.history:
        show_history()
        return

    if not args.query:
        parser.print_help()
        return

    query = " ".join(args.query)
    save_history(query)
    config = load_config()

    print("[*] Searching YouTube...")
    videos = search_youtube(query)

    if not videos:
        print("[-] No results found.")
        return

    lines = []

    # 2. Format data for the instant UI preview
    for v in videos:
        # Sanitize text to avoid breaking our awk delimiter in ui.py
        title = v.get("title", "Unknown").replace("|", "-")
        channel = v.get("channel", "Unknown").replace("|", "-")
        duration = format_duration(v.get("duration"))
        views = format_views(v.get("view_count"))
        vid = v.get("id")

        # Format the upload date (yt-dlp usually returns YYYYMMDD here)
        raw_date = v.get("upload_date", "Unknown")
        if raw_date and raw_date != "Unknown" and len(raw_date) == 8:
            date_fmt = f"{raw_date[:4]}-{raw_date[4:6]}-{raw_date[6:]}"
        else:
            date_fmt = "Unknown"

        # Combine everything into one string separated by ' | '
        lines.append(
            f"{title} | {channel} | {duration} | {views} | {date_fmt} | {vid}"
        )

    selection = select_video(lines)

    if not selection:
        return

    # 3. Retrieve the selected video based on the exact string matched
    index = lines.index(selection)
    video = videos[index]
    video_id = video["id"]

    # ACTION MENU
    action = choose_action()

    if not action:
        return

    if action == "Play Audio Only":
        play_audio(video_id)
        return

    if action == "Download Video":
        download_video(video_id)
        return

    if action == "Open in Browser":
        # Uses our new robust cross-platform browser function!
        open_in_browser(video_id)
        return

    # QUALITY MENU (Fall back to config defaults if user hits escape)
    quality = choose_quality()
    if not quality:
        quality = config.get("default_quality", "720")

    # SPEED MENU (Fall back to config defaults if user hits escape)
    speed = choose_speed()
    if not speed:
        speed = config.get("default_speed", "1")

    # 4. Stream the video
    play_video(video_id, quality, speed)

if __name__ == "__main__":
    main()
