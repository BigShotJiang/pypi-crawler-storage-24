import os
import platform
import shutil
import subprocess
import webbrowser

# Termux hard-coded binary paths (reliable even when PATH is incomplete)
TERMUX_PREFIX = "/data/data/com.termux/files/usr"
TERMUX_BINS = {
    "mpv": f"{TERMUX_PREFIX}/bin/mpv",
}

def _which_termux_aware(tool):
    """
    Like shutil.which() but also checks the Termux prefix directly.
    Termux sometimes doesn't export its full PATH to child processes,
    causing shutil.which() to return None for installed tools.
    """
    termux_path = TERMUX_BINS.get(tool)
    if termux_path and os.path.isfile(termux_path) and os.access(termux_path, os.X_OK):
        return termux_path
    return shutil.which(tool)


def get_os_type():
    """Detects the specific OS environment, including subsystems like WSL and Termux."""
    system = platform.system().lower()
    release = platform.release().lower()

    if "linux" in system and "com.termux" in os.environ.get("PREFIX", ""):
        return "android"

    if "linux" in system and ("microsoft" in release or "wsl" in release):
        return "wsl"

    if system == "windows":
        return "windows"
    if system == "darwin":
        return "macos"

    return "linux"


def _get_termux_vo():
    """
    Returns the best mpv --vo (video output) driver available on this
    Termux installation, in order of preference:

      1. gpu        — hardware-accelerated OpenGL ES via termux-x11 or
                      a Wayland compositor (best quality, requires a
                      display server to be running)
      2. drm        — Direct Rendering Manager, works without X/Wayland
                      but needs /dev/dri access (common on rooted devices
                      or devices with termux-x11's DRM bridge)
      3. sdl         — SDL2 fallback, needs 'pkg install sdl2' and a
                      display server
      4. <empty>    — let mpv auto-detect; on most stock Termux installs
                      this falls back to audio-only because there is no
                      display, so we return None and warn the user instead
                      of silently playing audio.

    We detect availability by checking whether the needed shared libs /
    device nodes exist rather than trying to spawn mpv, which keeps
    startup fast.
    """
    # gpu / OpenGL ES — needs EGL + a compositor socket or /dev/dri
    if (os.path.exists("/dev/dri/renderD128") or
            os.environ.get("DISPLAY") or
            os.environ.get("WAYLAND_DISPLAY")):
        return "gpu"

    # DRM direct — /dev/dri present but no compositor
    if os.path.exists("/dev/dri"):
        return "drm"

    # SDL2 shared lib present and a display env var set
    sdl2 = f"{TERMUX_PREFIX}/lib/libSDL2.so"
    if os.path.exists(sdl2) and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        return "sdl"

    # Nothing suitable found
    return None


def open_in_browser(video_id):
    """Robustly opens a video and catches errors if no browser/app exists."""
    url = f"https://youtube.com/watch?v={video_id}"
    os_type = get_os_type()
    error_msg = f"\n[-] Error: No web browser or compatible app found.\n[*] Manual Link: {url}\n"

    try:
        if os_type == "android":
            result = subprocess.run(["termux-open", url], capture_output=True, text=True)
            if result.returncode != 0:
                print(error_msg)
        elif os_type == "wsl":
            subprocess.run(["cmd.exe", "/c", "start", "", url], capture_output=True, text=True)
        else:
            success = webbrowser.open(url)
            if not success:
                print(error_msg)
    except Exception:
        print(error_msg)


def play_video(video_id, quality="720", speed="1"):
    """
    Plays video using mpv for ALL platforms.

    On Termux, auto-detects the best available video output driver.
    If no display server is present, informs the user clearly instead
    of silently falling back to audio-only or opening the browser.
    """
    url = f"https://youtube.com/watch?v={video_id}"
    os_type = get_os_type()
    mpv_bin = _which_termux_aware("mpv")

    if mpv_bin is None and os_type != "android":
        print("[!] mpv player not found. Falling back to browser...")
        open_in_browser(video_id)
        return

    if quality == "best":
        fmt = "bestvideo+bestaudio/best"
    elif quality == "worst":
        fmt = "worstvideo+worstaudio/worst"
    else:
        fmt = f"bestvideo[height<={quality}]+bestaudio/best"

    cmd = [
        mpv_bin,
        "--ytdl-format=" + fmt,
        "--speed=" + speed,
        "--cache=yes",
        "--demuxer-max-bytes=1000M",
        "--demuxer-readahead-secs=300",
    ]

    # On Termux, delegate entirely to Android mpv natively
    if os_type == "android":
        print("[*] Resolving stream URL for Android mpv...")
        try:
             # Force yt-dlp to return a single pre-merged video+audio format (b or best)
             # If we use bestvideo+bestaudio, yt-dlp -g prints TWO URLs, and am start -d only takes one.
             if quality == "best":
                 fmt = "b"
             else:
                 fmt = f"b[height<={quality}]/b"
                 
             result = subprocess.run(
                 ["yt-dlp", "-f", fmt, "-g", url], 
                 capture_output=True, text=True, check=True
             )
             stream_url = result.stdout.strip().split('\n')[0] # Get the first URL
        except Exception as e:
             print(f"[-] Failed to extract direct stream URL: {e}")
             stream_url = url # fallback to raw url if it fails

        print(f"[*] Opening native Android mpv app...")
        subprocess.run([
            "am", "start", "--user", "0", 
            "-a", "android.intent.action.VIEW", 
            "-d", stream_url, 
            "-n", "is.xyz.mpv/.MPVActivity"
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return

    try:
        print(f"[*] Starting playback (Quality: {quality}p, Speed: {speed}x)...")
        subprocess.run(cmd + [url])
    except KeyboardInterrupt:
        print("\n[*] Playback stopped by user.")


def play_audio(video_id):
    """Plays audio-only using mpv with high-buffer caching."""
    url = f"https://youtube.com/watch?v={video_id}"
    os_type = get_os_type()
    mpv_bin = _which_termux_aware("mpv")

    if mpv_bin is None and os_type != "android":
        print("[!] mpv player not found. Falling back to browser...")
        open_in_browser(video_id)
        return

    if os_type == "android":
        print("[*] Resolving audio stream URL for Android mpv...")
        try:
             # get best audio only
             result = subprocess.run(
                 ["yt-dlp", "-f", "bestaudio", "-g", url], 
                 capture_output=True, text=True, check=True
             )
             stream_url = result.stdout.strip().split('\n')[0]
        except Exception as e:
             print(f"[-] Failed to extract direct audio URL: {e}")
             stream_url = url

        print(f"[*] Opening native Android mpv app...")
        subprocess.run([
            "am", "start", "--user", "0", 
            "-a", "android.intent.action.VIEW", 
            "-d", stream_url, 
            "-n", "is.xyz.mpv/.MPVActivity"
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return

    try:
        print("[*] Starting audio playback...")
        subprocess.run([
            mpv_bin,
            "--force-window=no",
            "--no-video",
            "--cache=yes",
            "--demuxer-max-bytes=500M",
            "--demuxer-readahead-secs=600",
            url
        ])
    except KeyboardInterrupt:
        print("\n[*] Audio playback stopped.")


def download_video(video_id):
    """Downloads video via yt-dlp."""
    url = f"https://youtube.com/watch?v={video_id}"
    try:
        print("[*] Starting download...")
        subprocess.run(["yt-dlp", url])
        print("\n[+] Download complete!")
    except KeyboardInterrupt:
        print("\n[*] Download cancelled.")
