import os
import platform
import shutil
import subprocess
import sys

# Termux hard-coded binary paths (reliable even when PATH is incomplete)
TERMUX_PREFIX = "/data/data/com.termux/files/usr"
TERMUX_BINS = {
    "mpv": f"{TERMUX_PREFIX}/bin/mpv",
    "fzf": f"{TERMUX_PREFIX}/bin/fzf",
}

def _which_termux_aware(tool):
    """
    Like shutil.which() but also checks the Termux prefix directly.
    Termux sometimes doesn't export its full PATH to child processes,
    causing shutil.which() to return None for installed tools.
    """
    # 1. Check the known Termux binary path first
    termux_path = TERMUX_BINS.get(tool)
    if termux_path and os.path.isfile(termux_path) and os.access(termux_path, os.X_OK):
        return termux_path

    # 2. Fall back to normal PATH search
    return shutil.which(tool)


def detect_environment():
    """Detects the OS and the best available package manager."""
    system = platform.system().lower()

    # Android / Termux check
    if "linux" in system and "com.termux" in os.environ.get("PREFIX", ""):
        return "android", "pkg"

    if system == "windows":
        for mgr in ["winget", "choco", "scoop"]:
            if shutil.which(mgr): return "windows", mgr
        return "windows", None

    if system == "darwin":
        if shutil.which("brew"): return "macos", "brew"
        return "macos", None

    if "linux" in system:
        for mgr in ["apt", "dnf", "pacman"]:
            if shutil.which(mgr): return "linux", mgr
        return "linux", None

    return "unknown", None


def install_dependency(pkg, os_type, manager):
    """Executes the correct install command based on the OS and package manager."""
    print(f"\n[*] ytplay-cli needs '{pkg}'. Attempting auto-install via {manager}...")

    try:
        if manager == "winget":
            subprocess.run(["winget", "install", "-e", "--id", pkg], check=True)
        elif manager == "choco":
            subprocess.run(["choco", "install", "-y", pkg], check=True)
        elif manager == "brew":
            subprocess.run(["brew", "install", pkg], check=True)
        elif manager == "pkg":
            subprocess.run(["pkg", "install", "-y", pkg], check=True)
        elif manager == "apt":
            subprocess.run(["sudo", "apt", "install", "-y", pkg], check=True)
        elif manager == "dnf":
            subprocess.run(["sudo", "dnf", "install", "-y", pkg], check=True)
        elif manager == "pacman":
            subprocess.run(["sudo", "pacman", "-S", "--noconfirm", pkg], check=True)

        print(f"[+] Successfully installed {pkg}!")
        return True
    except subprocess.CalledProcessError:
        print(f"[-] Failed to automatically install {pkg}. Please install it manually.")
        return False


def check_dependencies():
    """Checks for required tools and auto-installs them on first run."""
    # yt-dlp is handled by pip via pyproject.toml. jq is removed to fix UI lag.
    required_tools = ["fzf", "mpv"]

    # Use Termux-aware detection so tools found in the Termux prefix are
    # not incorrectly reported as missing when PATH is incomplete.
    missing_tools = [t for t in required_tools if _which_termux_aware(t) is None]

    if missing_tools:
        os_type, manager = detect_environment()

        if not manager:
            print(f"\n[-] Missing dependencies: {', '.join(missing_tools)}")
            print("[-] No supported package manager found. Please install them manually.")
            sys.exit(1)

        # Setup Termux X11 repository first if we need to install on Android
        if manager == "pkg":
            print("\n--- ytplay-cli First-Run Setup (Termux) ---")
            install_dependency("x11-repo", os_type, manager)
            # Add Termux X11 package required for video
            missing_tools.append("termux-x11-nightly")
        else:
            print("\n--- ytplay-cli First-Run Setup ---")

        for tool in missing_tools:
            install_name = "junegunn.fzf" if (manager == "winget" and tool == "fzf") else tool
            install_name = "mpv.net" if (manager == "winget" and tool == "mpv") else install_name
            install_dependency(install_name, os_type, manager)
        print("-----------------------------------\n")
