import subprocess

def select_video(lines):
    # This script runs instantly on the local string fzf is highlighting
    preview_script = r'''
line={}
title=$(echo "$line" | awk -F' \\| ' '{print $1}')
channel=$(echo "$line" | awk -F' \\| ' '{print $2}')
duration=$(echo "$line" | awk -F' \\| ' '{print $3}')
views=$(echo "$line" | awk -F' \\| ' '{print $4}')
date=$(echo "$line" | awk -F' \\| ' '{print $5}')
vid=$(echo "$line" | awk -F' \\| ' '{print $6}')

# Use ANSI escape codes for beautiful coloring
echo -e "\033[1;34mTitle:\033[0m $title"
echo ""
echo -e "\033[1;32mChannel:\033[0m $channel"
echo -e "\033[1;36mViews:\033[0m $views"
echo -e "\033[1;33mDuration:\033[0m $duration"
echo -e "\033[1;35mUpload Date:\033[0m $date"
echo -e "\033[1;30mVideo ID:\033[0m $vid"
'''

    fzf = subprocess.Popen(
        [
            "fzf",
            "--height=90%",
            "--layout=reverse",
            "--border",
            "--prompt=YouTube > ",
            "--preview",
            preview_script,
            "--preview-window=right:50%:wrap" # wrap ensures long titles don't get cut off
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True
    )

    stdout, _ = fzf.communicate("\n".join(lines))

    return stdout.strip()
