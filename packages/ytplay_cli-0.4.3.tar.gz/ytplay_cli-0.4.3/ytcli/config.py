import os
import json

CONFIG_DIR = os.path.expanduser("~/.config/yt-cli")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

DEFAULT_CONFIG = {
    "default_quality": "720",
    "default_speed": "1"
}


def load_config():

    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)

    if not os.path.exists(CONFIG_FILE):

        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)

        return DEFAULT_CONFIG

    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except Exception:
        return DEFAULT_CONFIG
