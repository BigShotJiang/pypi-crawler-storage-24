def format_duration(seconds):
    """
    Convert seconds to YouTube-like format:
    HH:MM:SS or MM:SS
    """

    if seconds is None:
        return "??:??"

    seconds = int(seconds)

    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{sec:02d}"

    return f"{minutes}:{sec:02d}"


def format_views(v):
    """
    Convert views to readable format
    """

    if not v:
        return "0"

    if v >= 1_000_000:
        return f"{v/1_000_000:.1f}M"

    if v >= 1_000:
        return f"{v/1_000:.1f}K"

    return str(v)
