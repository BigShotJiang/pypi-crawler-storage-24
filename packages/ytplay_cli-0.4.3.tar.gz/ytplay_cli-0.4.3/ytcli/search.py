import yt_dlp

RESULT_LIMIT = 30


def search_youtube(query):

    ydl_opts = {
        "quiet": True,
        "extract_flat": "in_playlist",
        "skip_download": True
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(
            f"ytsearch{RESULT_LIMIT}:{query}",
            download=False
        )

    return info.get("entries", [])
