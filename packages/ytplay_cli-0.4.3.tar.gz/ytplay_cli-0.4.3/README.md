# ytplay-cli 📺🚀

[![PyPI version](https://img.shields.io/pypi/v/ytplay-cli.svg)](https://pypi.org/project/ytplay-cli/)
[![Python versions](https://img.shields.io/pypi/pyversions/ytplay-cli.svg)](https://pypi.org/project/ytplay-cli/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Search, preview, stream, and download YouTube videos directly from your terminal. 

`ytplay-cli` is a blazing-fast, cross-platform command-line tool that combines the power of `yt-dlp`, `fzf`, and `mpv` to deliver a seamless, ad-free YouTube experience without ever leaving your console.

---

## ✨ What's New in Version 0.4.1
The entire core engine has been rebuilt for speed, stability, and broad compatibility:
* **Zero-Lag UI:** Search results and metadata previews are now 100% instantaneous. We completely removed the `jq` dependency and redundant network calls.
* **Smart Auto-Installer:** On the first run, the tool detects your OS and gracefully attempts to install missing system requirements (`mpv`, `fzf`) via your native package manager.
* **Android (Termux) & WSL Support:** Video streams now intelligently route to your native Android apps (via `termux-open`) or your host Windows browser from inside WSL. Audio-only mode runs natively anywhere!
* **Bulletproof Pause/Resume:** `mpv` now uses aggressive background RAM caching. Pause a video for hours, and it will resume instantly without crashing or dropping the connection.

---

## 🚀 Features

* **Search:** Find videos instantly right from the command line.
* **Interactive UI:** Navigate results with a beautiful, fuzzy-searchable interface powered by **fzf**.
* **Instant Previews:** View channel name, duration, upload date, and view counts before selecting a video.
* **Stream Video & Audio:** Play media directly using the ultra-lightweight **mpv** player.
* **Download:** Save videos locally via **yt-dlp**.
* **Customization:** Select preferred video quality and playback speed.
* **History:** Keeps a persistent log of your recent searches.

---

## 📦 Installation & Setup

### 1. Install the Python Package
The easiest and recommended way to install `ytplay-cli` is via **pipx**, which safely installs Python CLI applications globally in isolated environments.

```bash
# Install pipx if you don't have it
python3 -m pip install --user pipx
python3 -m pipx ensurepath

# Install ytplay-cli
pipx install ytplay-cli
```
*(Alternatively, you can use standard `pip install ytplay-cli`)*

### 2. Auto-Installing System Tools (fzf & mpv)
`ytplay-cli` requires `fzf` (for the interactive menu) and `mpv` (for streaming media). 

**⚡ New in v0.4.1:** When you run the `yt` command for the very first time, the application will attempt to automatically install these dependencies for you based on your operating system!

If the auto-installer is blocked by your system permissions, you can easily install them manually using your OS package manager:

* **🐧 Linux (Debian / Ubuntu):** `sudo apt install fzf mpv`
* **🍎 macOS:** `brew install fzf mpv`
* **🪟 Windows (Winget):** `winget install junegunn.fzf` and `winget install mpv.net`
* **📱 Android (Termux):** `pkg install fzf mpv` *(Note: Termux cannot render graphical video players. ytplay-cli will stream "Audio-Only" natively, and seamlessly route "Video" to your native Android apps like YouTube or VLC).*

---

## 🎮 Usage

Running the tool exposes the global `yt` command. Simply type `yt` followed by your search query:

```bash
yt "machine learning crash course"
```

### Keyboard Controls

**In the Search Menu (`fzf`):**
* `Up / Down Arrow`: Browse through search results.
* `Enter`: Select the highlighted video.
* `ESC` or `Ctrl+C`: Exit the search menu.

**During Playback (`mpv`):**
* `Spacebar`: Pause / Resume playback.
* `Right / Left Arrow`: Seek forward / backward by 5 seconds.
* `Up / Down Arrow`: Increase / Decrease volume.
* `q`: Quit the player and return to the terminal.

### Additional Commands
```bash
# View your past search history
yt --history

# Check the current version
yt --version

# View help menu
yt --help
```

---

## ⚙️ Configuration

`ytplay-cli` automatically generates a configuration file on your first run. You can edit this file to skip the interactive prompts for quality and speed.

**Config Location:** `~/.config/yt-cli/config.json`

```json
{
  "default_quality": "720",
  "default_speed": "1"
}
```

---

## 🛠️ Built With
* [Python 3](https://www.python.org/) - The core language.
* [yt-dlp](https://github.com/yt-dlp/yt-dlp) - YouTube metadata and stream extraction.
* [fzf](https://github.com/junegunn/fzf) - Command-line fuzzy finder.
* [mpv](https://mpv.io/) - Free, open-source media player.

---

## 🤝 Contributing
Contributions, issues, and feature requests are welcome! 
Feel free to check the [issues page](https://github.com/naveen07-c/yt-cli/issues). 

If you like this project, please consider giving it a ⭐ on GitHub!
