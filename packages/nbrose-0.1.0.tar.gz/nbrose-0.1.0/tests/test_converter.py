"""
tests/test_converter.py
~~~~~~~~~~~~~~~~~~~~~~~
Basic tests for nbrose converter.
"""

import json
import tempfile
from pathlib import Path

import pytest

from nbrose import convert
from nbrose.converter import (
    highlight_python,
    markdown_to_html,
    build_toc,
)


# ── Fixtures ──────────────────────────────────────────────────────────────
def make_notebook(cells: list) -> dict:
    return {
        "nbformat": 4,
        "nbformat_minor": 5,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            }
        },
        "cells": cells,
    }


def write_notebook(nb: dict, path: Path) -> None:
    path.write_text(json.dumps(nb), encoding="utf-8")


# ── highlight_python ──────────────────────────────────────────────────────
def test_highlight_keyword():
    result = highlight_python("def foo():")
    assert '<span class="kw">def</span>' in result


def test_highlight_string():
    result = highlight_python('"hello"')
    assert '<span class="st">' in result


def test_highlight_comment():
    result = highlight_python("# a comment")
    assert '<span class="cm">' in result


def test_highlight_builtin():
    result = highlight_python("print(x)")
    assert '<span class="bi">print</span>' in result


# ── markdown_to_html ──────────────────────────────────────────────────────
def test_markdown_heading():
    html = markdown_to_html("# Hello World")
    assert "<h1" in html
    assert "Hello World" in html


def test_markdown_bold():
    html = markdown_to_html("**bold text**")
    assert "<strong>bold text</strong>" in html


def test_markdown_code_inline():
    html = markdown_to_html("`code`")
    assert "<code>code</code>" in html


def test_markdown_list():
    html = markdown_to_html("- item one\n- item two")
    assert "<ul>" in html
    assert "<li>" in html


# ── build_toc ─────────────────────────────────────────────────────────────
def test_toc_built_from_headings():
    cells = [
        {"cell_type": "markdown", "source": ["# Introduction"]},
        {"cell_type": "markdown", "source": ["## Methods"]},
        {"cell_type": "code",     "source": ["x = 1"], "outputs": [], "execution_count": 1},
    ]
    toc = build_toc(cells)
    assert "Introduction" in toc
    assert "Methods" in toc


def test_toc_empty_when_no_headings():
    cells = [
        {"cell_type": "code", "source": ["x = 1"], "outputs": [], "execution_count": 1},
    ]
    toc = build_toc(cells)
    assert toc == ""


# ── convert ───────────────────────────────────────────────────────────────
def test_convert_basic():
    nb = make_notebook([
        {"cell_type": "markdown", "source": ["# Test Notebook\n\nHello world."]},
        {
            "cell_type": "code",
            "source": ["print('hello')"],
            "execution_count": 1,
            "outputs": [
                {"output_type": "stream", "name": "stdout", "text": ["hello\n"]}
            ],
        },
    ])
    with tempfile.TemporaryDirectory() as tmp:
        nb_path = Path(tmp) / "test.ipynb"
        out_path = Path(tmp) / "test.html"
        write_notebook(nb, nb_path)

        result = convert(nb_path, out_path)

        assert result == out_path
        assert out_path.exists()
        content = out_path.read_text()
        assert "Test Notebook" in content
        assert "hello" in content
        assert "rose-pine" in content.lower() or "#191724" in content


def test_convert_default_output_path():
    nb = make_notebook([
        {"cell_type": "markdown", "source": ["# Hello"]},
    ])
    with tempfile.TemporaryDirectory() as tmp:
        nb_path = Path(tmp) / "mynotebook.ipynb"
        write_notebook(nb, nb_path)

        result = convert(nb_path)

        assert result == nb_path.with_suffix(".html")
        assert result.exists()


def test_convert_custom_title():
    nb = make_notebook([])
    with tempfile.TemporaryDirectory() as tmp:
        nb_path = Path(tmp) / "test.ipynb"
        write_notebook(nb, nb_path)

        result = convert(nb_path, title="Custom Title")
        content = result.read_text()
        assert "Custom Title" in content


def test_convert_file_not_found():
    with pytest.raises(FileNotFoundError):
        convert("nonexistent.ipynb")


def test_convert_wrong_extension():
    with pytest.raises(ValueError):
        convert("notebook.txt")
