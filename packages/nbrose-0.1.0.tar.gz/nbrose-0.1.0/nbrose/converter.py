"""
nbrose.converter
~~~~~~~~~~~~~~~~
Core .ipynb → styled HTML converter with Rosé Pine theme.
"""

from __future__ import annotations

import json
import re
import html as html_module
from pathlib import Path
from typing import Optional


# ── Rosé Pine palette ──────────────────────────────────────────────────────
ROSE_PINE_CSS = """
:root {
  --base:        #191724;
  --surface:     #1f1d2e;
  --overlay:     #26233a;
  --muted:       #6e6a86;
  --subtle:      #908caa;
  --text:        #e0def4;
  --love:        #eb6f92;
  --gold:        #f6c177;
  --rose:        #ebbcba;
  --pine:        #31748f;
  --foam:        #9ccfd8;
  --iris:        #c4a7e7;
  --hl-low:      #21202e;
  --hl-med:      #403d52;
  --hl-high:     #524f67;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: "Source Code Pro", "Fira Code", "Cascadia Code", monospace;
  background: var(--base);
  color: var(--text);
  line-height: 1.7;
  display: flex;
  min-height: 100vh;
}

/* ── TOC sidebar ── */
#toc {
  position: fixed;
  top: 0; left: 0;
  width: 260px;
  height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--hl-med);
  overflow-y: auto;
  padding: 24px 0;
  z-index: 100;
  transition: transform 0.3s;
}

#toc h2 {
  font-size: 0.7rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--muted);
  padding: 0 20px 12px;
  border-bottom: 1px solid var(--hl-med);
  margin-bottom: 12px;
}

#toc ul { list-style: none; }

#toc li a {
  display: block;
  padding: 6px 20px;
  color: var(--subtle);
  text-decoration: none;
  font-size: 0.78rem;
  border-left: 2px solid transparent;
  transition: all 0.2s;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

#toc li a:hover,
#toc li a.active {
  color: var(--iris);
  border-left-color: var(--iris);
  background: var(--hl-low);
}

#toc li.h3 a { padding-left: 36px; font-size: 0.73rem; }
#toc li.h4 a { padding-left: 52px; font-size: 0.7rem; }

/* ── Main content ── */
#main {
  margin-left: 260px;
  flex: 1;
  max-width: 960px;
  padding: 48px 40px 80px;
}

/* ── Notebook header ── */
.nb-header {
  margin-bottom: 48px;
  padding-bottom: 24px;
  border-bottom: 1px solid var(--hl-med);
}

.nb-title {
  font-size: 2rem;
  font-weight: 700;
  color: var(--iris);
  margin-bottom: 8px;
}

.nb-meta {
  font-size: 0.75rem;
  color: var(--muted);
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.nb-meta span { display: flex; align-items: center; gap: 6px; }

/* ── Cells ── */
.cell { margin-bottom: 28px; }

/* ── Markdown cells ── */
.cell-markdown { padding: 4px 0; }

.cell-markdown h1,
.cell-markdown h2,
.cell-markdown h3,
.cell-markdown h4,
.cell-markdown h5,
.cell-markdown h6 {
  color: var(--iris);
  margin: 1.6em 0 0.6em;
  font-weight: 700;
  scroll-margin-top: 24px;
}

.cell-markdown h1 { font-size: 1.8rem; border-bottom: 2px solid var(--pine); padding-bottom: 8px; }
.cell-markdown h2 { font-size: 1.4rem; border-bottom: 1px solid var(--hl-med); padding-bottom: 6px; }
.cell-markdown h3 { font-size: 1.15rem; color: var(--foam); }
.cell-markdown h4 { font-size: 1rem; color: var(--gold); }

.cell-markdown p  { color: var(--subtle); margin-bottom: 0.9em; }
.cell-markdown a  { color: var(--pine); text-decoration: underline; }
.cell-markdown a:hover { color: var(--foam); }
.cell-markdown strong { color: var(--gold); font-weight: 700; }
.cell-markdown em     { color: var(--rose); font-style: italic; }

.cell-markdown ul,
.cell-markdown ol {
  margin: 0.6em 0 0.9em 1.6em;
  color: var(--subtle);
}
.cell-markdown li { margin-bottom: 0.3em; }

.cell-markdown blockquote {
  border-left: 3px solid var(--pine);
  padding: 8px 16px;
  margin: 1em 0;
  background: var(--hl-low);
  border-radius: 0 6px 6px 0;
  color: var(--muted);
  font-style: italic;
}

.cell-markdown code {
  background: var(--overlay);
  color: var(--foam);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.88em;
}

.cell-markdown pre {
  background: var(--overlay);
  padding: 16px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 1em 0;
  border: 1px solid var(--hl-med);
}

.cell-markdown pre code { background: none; padding: 0; font-size: 0.85rem; }

.cell-markdown table { width: 100%; border-collapse: collapse; margin: 1em 0; font-size: 0.85rem; }
.cell-markdown th { background: var(--overlay); color: var(--iris); padding: 8px 12px; text-align: left; border: 1px solid var(--hl-med); }
.cell-markdown td { padding: 7px 12px; border: 1px solid var(--hl-low); color: var(--subtle); }
.cell-markdown tr:hover td { background: var(--hl-low); }

/* ── Code cells ── */
.cell-code {
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid var(--hl-med);
  background: var(--surface);
}

.code-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 14px;
  background: var(--overlay);
  border-bottom: 1px solid var(--hl-med);
}

.code-prompt { font-size: 0.68rem; color: var(--muted); letter-spacing: 0.06em; }
.code-lang   { font-size: 0.65rem; color: var(--pine); letter-spacing: 0.08em; text-transform: uppercase; }

.code-source {
  padding: 16px;
  overflow-x: auto;
  background: var(--surface);
}
.code-source pre { margin: 0; font-size: 0.84rem; line-height: 1.6; white-space: pre; }

/* ── Outputs ── */
.cell-output {
  background: var(--hl-low);
  border-top: 1px solid var(--hl-med);
  padding: 14px 16px;
  font-size: 0.83rem;
  color: var(--subtle);
  overflow-x: auto;
}
.cell-output pre { margin: 0; white-space: pre-wrap; word-break: break-word; }
.output-error { color: var(--love); }

.output-image {
  padding: 16px;
  text-align: center;
  background: var(--hl-low);
  border-top: 1px solid var(--hl-med);
}
.output-image img { max-width: 100%; border-radius: 6px; }

.output-html {
  padding: 14px 16px;
  background: var(--hl-low);
  border-top: 1px solid var(--hl-med);
  overflow-x: auto;
  color: var(--subtle);
  font-size: 0.83rem;
}
.output-html table { border-collapse: collapse; font-size: 0.82rem; width: 100%; }
.output-html th { background: var(--overlay); color: var(--iris); padding: 6px 10px; text-align: left; border: 1px solid var(--hl-med); }
.output-html td { padding: 5px 10px; border: 1px solid var(--hl-low); color: var(--subtle); }

/* ── Syntax highlight classes ── */
.kw  { color: #c4a7e7; }
.bi  { color: #eb6f92; }
.st  { color: #f6c177; }
.cm  { color: #6e6a86; font-style: italic; }
.nm  { color: #9ccfd8; }
.fn  { color: #ebbcba; }
.op  { color: #908caa; }
.dc  { color: #31748f; }
.cl  { color: #9ccfd8; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--surface); }
::-webkit-scrollbar-thumb { background: var(--hl-high); border-radius: 3px; }

/* ── Responsive ── */
@media (max-width: 768px) {
  #toc { transform: translateX(-260px); }
  #toc.open { transform: translateX(0); }
  #main { margin-left: 0; padding: 24px 20px 60px; }
  .nb-title { font-size: 1.5rem; }
  #toc-toggle {
    display: flex !important;
    position: fixed;
    bottom: 20px; right: 20px;
    width: 44px; height: 44px;
    background: var(--iris);
    color: var(--base);
    border: none;
    border-radius: 50%;
    font-size: 1.2rem;
    cursor: pointer;
    align-items: center;
    justify-content: center;
    z-index: 200;
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
  }
}

#toc-toggle { display: none; }
"""


# ── Python syntax highlighter ──────────────────────────────────────────────
# Strategy: tokenise raw source into segments, escape each segment,
# then wrap with span tags. This avoids double-processing HTML entities.

KEYWORDS = frozenset({
    "False","None","True","and","as","assert","async","await",
    "break","class","continue","def","del","elif","else","except",
    "finally","for","from","global","if","import","in","is",
    "lambda","nonlocal","not","or","pass","raise","return","try",
    "while","with","yield",
})

BUILTINS = frozenset({
    "abs","all","any","bin","bool","bytes","callable","chr",
    "dict","dir","divmod","enumerate","eval","exec","filter",
    "float","format","frozenset","getattr","globals","hasattr",
    "hash","help","hex","id","input","int","isinstance",
    "issubclass","iter","len","list","locals","map","max",
    "min","next","object","oct","open","ord","pow","print",
    "property","range","repr","reversed","round","set","setattr",
    "slice","sorted","staticmethod","str","sum","super","tuple",
    "type","vars","zip",
})

# Token types
_T_COMMENT = "cm"
_T_STRING3  = "st"
_T_STRING1  = "st"
_T_NUMBER   = "nm"
_T_DECORATOR= "dc"
_T_WORD     = "word"   # resolve kw/bi/fn later
_T_OTHER    = None


def _tokenise(code: str):
    """Yield (token_class, raw_text) pairs from raw Python source."""
    i = 0
    n = len(code)
    while i < n:
        # comment
        if code[i] == "#":
            end = code.find("\n", i)
            end = end if end != -1 else n
            yield (_T_COMMENT, code[i:end])
            i = end
            continue
        # triple-quoted string
        for q in ('"""', "'''"):
            if code[i:i+3] == q:
                end = code.find(q, i+3)
                end = (end + 3) if end != -1 else n
                yield (_T_STRING3, code[i:end])
                i = end
                break
        else:
            # single-quoted string (with optional prefix)
            m = re.match(r'[fFbBrRuU]{0,2}(["\'])(?:(?!\1)(?:\\.|[^\\]))*\1', code[i:])
            if m:
                yield (_T_STRING1, m.group(0))
                i += m.end()
                continue
            # decorator
            if code[i] == "@":
                m2 = re.match(r'@[\w.]+', code[i:])
                if m2:
                    yield (_T_DECORATOR, m2.group(0))
                    i += m2.end()
                    continue
            # number
            m3 = re.match(r'\b(\d+\.?\d*(?:[eE][+-]?\d+)?[jJ]?|0[xXoObB][\da-fA-F_]+)\b', code[i:])
            if m3:
                yield (_T_NUMBER, m3.group(0))
                i += m3.end()
                continue
            # identifier / keyword
            m4 = re.match(r'[A-Za-z_]\w*', code[i:])
            if m4:
                yield (_T_WORD, m4.group(0))
                i += m4.end()
                continue
            # anything else — one char at a time
            yield (_T_OTHER, code[i])
            i += 1


def highlight_python(code: str) -> str:
    """Tokenise raw Python source → HTML with Rosé Pine span classes."""
    parts = []
    tokens = list(_tokenise(code))
    # peek-ahead to detect function names: word followed by '('
    for idx, (ttype, text) in enumerate(tokens):
        escaped = html_module.escape(text)
        if ttype is None:
            parts.append(escaped)
        elif ttype == _T_WORD:
            if text in KEYWORDS:
                parts.append(f'<span class="kw">{escaped}</span>')
            elif text in BUILTINS:
                parts.append(f'<span class="bi">{escaped}</span>')
            else:
                # check next non-space token
                j = idx + 1
                while j < len(tokens) and tokens[j][0] is None and tokens[j][1] in (" ", "\t"):
                    j += 1
                if j < len(tokens) and tokens[j][1] == "(":
                    parts.append(f'<span class="fn">{escaped}</span>')
                else:
                    parts.append(escaped)
        else:
            parts.append(f'<span class="{ttype}">{escaped}</span>')
    return "".join(parts)


# ── Markdown → HTML ────────────────────────────────────────────────────────
def markdown_to_html(text: str) -> str:
    lines = text.split("\n")
    out: list[str] = []
    in_ul = in_ol = in_code = False
    code_buf: list[str] = []
    code_lang = ""

    def close_list():
        nonlocal in_ul, in_ol
        if in_ul:  out.append("</ul>");  in_ul = False
        if in_ol:  out.append("</ol>");  in_ol = False

    def inline(s: str) -> str:
        s = html_module.escape(s)
        s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
        s = re.sub(r'\*(.+?)\*',     r'<em>\1</em>', s)
        s = re.sub(r'`([^`]+)`',     r'<code>\1</code>', s)
        s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', s)
        return s

    i = 0
    while i < len(lines):
        line = lines[i]

        if line.startswith("```"):
            if not in_code:
                close_list()
                in_code = True
                code_lang = line[3:].strip() or "python"
                code_buf = []
            else:
                in_code = False
                raw = "\n".join(code_buf)
                if code_lang.lower() in ("python", "py", ""):
                    body = highlight_python(raw)
                else:
                    body = html_module.escape(raw)
                out.append(f'<pre><code class="language-{code_lang}">{body}</code></pre>')
                code_buf = []
            i += 1; continue

        if in_code:
            code_buf.append(line); i += 1; continue

        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            close_list()
            level = len(m.group(1))
            content = inline(m.group(2))
            slug = re.sub(r'[^a-z0-9-]', '', m.group(2).lower().replace(' ', '-'))
            out.append(f'<h{level} id="{slug}">{content}</h{level}>')
            i += 1; continue

        if line.startswith("> "):
            close_list()
            out.append(f'<blockquote><p>{inline(line[2:])}</p></blockquote>')
            i += 1; continue

        if re.match(r'^[-*+]\s', line):
            if not in_ul: close_list(); out.append("<ul>"); in_ul = True
            out.append(f'<li>{inline(line[2:].strip())}</li>')
            i += 1; continue

        if re.match(r'^\d+\.\s', line):
            if not in_ol: close_list(); out.append("<ol>"); in_ol = True
            out.append(f'<li>{inline(re.sub(r"^\d+\.\s", "", line).strip())}</li>')
            i += 1; continue

        if re.match(r'^[-*_]{3,}$', line.strip()):
            close_list(); out.append("<hr>"); i += 1; continue

        if not line.strip():
            close_list(); out.append(""); i += 1; continue

        close_list()
        out.append(f'<p>{inline(line)}</p>')
        i += 1

    close_list()
    return "\n".join(out)


# ── Cell renderers ─────────────────────────────────────────────────────────
def render_markdown_cell(cell: dict) -> str:
    source = "".join(cell.get("source", []))
    return f'<div class="cell cell-markdown">{markdown_to_html(source)}</div>\n'


def render_output(output: dict) -> str:
    otype = output.get("output_type", "")

    if otype == "stream":
        text = "".join(output.get("text", []))
        cls = "output-error" if output.get("name") == "stderr" else ""
        return f'<div class="cell-output {cls}"><pre>{html_module.escape(text)}</pre></div>'

    if otype in ("execute_result", "display_data"):
        data = output.get("data", {})
        for mime in ("image/png", "image/jpeg", "image/svg+xml"):
            if mime in data:
                img = "".join(data[mime]) if isinstance(data[mime], list) else data[mime]
                if mime == "image/svg+xml":
                    return f'<div class="output-image">{img}</div>'
                return f'<div class="output-image"><img src="data:{mime};base64,{img}" alt="output"/></div>'
        if "text/html" in data:
            return f'<div class="output-html">{"".join(data["text/html"])}</div>'
        if "text/plain" in data:
            return f'<div class="cell-output"><pre>{html_module.escape("".join(data["text/plain"]))}</pre></div>'

    if otype == "error":
        tb = re.sub(r'\x1b\[[0-9;]*m', '', "\n".join(output.get("traceback", [])))
        return f'<div class="cell-output output-error"><pre>{html_module.escape(tb)}</pre></div>'

    return ""


def render_code_cell(cell: dict, index: int, kernel: str) -> str:
    source = "".join(cell.get("source", []))
    exec_count = cell.get("execution_count") or " "

    if kernel.lower() in ("python", "python3", "python 3"):
        highlighted = highlight_python(source)
    else:
        highlighted = html_module.escape(source)

    parts = [
        '<div class="cell cell-code">',
        '  <div class="code-header">',
        f'    <span class="code-prompt">In [{exec_count}]</span>',
        f'    <span class="code-lang">{html_module.escape(kernel)}</span>',
        '  </div>',
        f'  <div class="code-source"><pre>{highlighted}</pre></div>',
    ]
    for out in cell.get("outputs", []):
        parts.append(render_output(out))
    parts.append("</div>")
    return "\n".join(parts) + "\n"


# ── TOC ────────────────────────────────────────────────────────────────────
def build_toc(cells: list) -> str:
    items = []
    for cell in cells:
        if cell.get("cell_type") != "markdown":
            continue
        for line in "".join(cell.get("source", [])).split("\n"):
            m = re.match(r'^(#{1,4})\s+(.*)', line)
            if m:
                level = len(m.group(1))
                title = re.sub(r'[*_`]', '', m.group(2)).strip()
                slug  = re.sub(r'[^a-z0-9-]', '', title.lower().replace(' ', '-'))
                css   = f"h{level}" if level > 1 else ""
                items.append(f'<li class="{css}"><a href="#{slug}">{html_module.escape(title)}</a></li>')
    if not items:
        return ""
    return '<nav id="toc"><h2>Contents</h2><ul>' + "\n".join(items) + "</ul></nav>"


# ── HTML template ──────────────────────────────────────────────────────────
HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{title}</title>
<link href="https://fonts.googleapis.com/css2?family=Source+Code+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<style>
{css}
</style>
</head>
<body>

{toc}

<div id="main">
  <div class="nb-header">
    <div class="nb-title">{title}</div>
    <div class="nb-meta">
      <span>🐍 {kernel}</span>
      <span>📓 {cell_count} cells</span>
      <span>🔢 {code_count} code &middot; 📝 {md_count} markdown</span>
    </div>
  </div>

{cells_html}
</div>

<button id="toc-toggle" onclick="document.getElementById('toc').classList.toggle('open')">☰</button>

<script>
const headings = document.querySelectorAll('h1[id],h2[id],h3[id],h4[id]');
const tocLinks = document.querySelectorAll('#toc a');
const observer = new IntersectionObserver(entries => {{
  entries.forEach(entry => {{
    if (entry.isIntersecting) {{
      tocLinks.forEach(a => a.classList.remove('active'));
      const active = document.querySelector('#toc a[href="#' + entry.target.id + '"]');
      if (active) active.classList.add('active');
    }}
  }});
}}, {{ rootMargin: '-10% 0px -80% 0px' }});
headings.forEach(h => observer.observe(h));
</script>
</body>
</html>
"""


# ── Public API ─────────────────────────────────────────────────────────────
def convert(
    input_path: "str | Path",
    output_path: "Optional[str | Path]" = None,
    title: "Optional[str]" = None,
) -> Path:
    """
    Convert a Jupyter notebook (.ipynb) to a styled HTML file.

    Parameters
    ----------
    input_path  : path to the .ipynb file
    output_path : destination .html path (default: same dir, same stem)
    title       : custom page title (default: notebook filename stem)

    Returns
    -------
    Path to the generated HTML file.

    Example
    -------
    >>> from nbrose import convert
    >>> convert("analysis.ipynb")
    PosixPath('analysis.html')
    """
    input_path = Path(input_path)

    if input_path.suffix.lower() != ".ipynb":
        raise ValueError(f"Expected a .ipynb file, got: {input_path}")

    if not input_path.exists():
        raise FileNotFoundError(f"Notebook not found: {input_path}")

    if output_path is None:
        output_path = input_path.with_suffix(".html")
    output_path = Path(output_path)

    nb = json.loads(input_path.read_text(encoding="utf-8"))
    kernel = nb.get("metadata", {}).get("kernelspec", {}).get("display_name", "Python 3")
    cells  = nb.get("cells", [])

    page_title = title or input_path.stem.replace("-", " ").replace("_", " ").title()
    cell_count = len(cells)
    code_count = sum(1 for c in cells if c.get("cell_type") == "code")
    md_count   = sum(1 for c in cells if c.get("cell_type") == "markdown")

    toc_html   = build_toc(cells)
    cells_html = "".join(
        render_markdown_cell(c) if c.get("cell_type") == "markdown"
        else render_code_cell(c, i, kernel) if c.get("cell_type") == "code"
        else ""
        for i, c in enumerate(cells)
    )

    html = HTML_TEMPLATE.format(
        title=html_module.escape(page_title),
        kernel=html_module.escape(kernel),
        cell_count=cell_count,
        code_count=code_count,
        md_count=md_count,
        css=ROSE_PINE_CSS,
        toc=toc_html,
        cells_html=cells_html,
    )

    output_path.write_text(html, encoding="utf-8")
    return output_path
