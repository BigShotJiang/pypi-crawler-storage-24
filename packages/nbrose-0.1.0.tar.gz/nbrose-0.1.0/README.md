# nbrose 🌸

> Convert Jupyter notebooks to beautiful HTML with the **Rosé Pine** dark theme.

[![PyPI version](https://img.shields.io/pypi/v/nbrose.svg)](https://pypi.org/project/nbrose/)
[![Python](https://img.shields.io/pypi/pyversions/nbrose.svg)](https://pypi.org/project/nbrose/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## Features

- 🎨 **Rosé Pine dark theme** — warm, muted tones easy on the eyes
- 🌳 **Table of contents sidebar** — auto-generated from headings, highlights on scroll
- 🔦 **Syntax highlighting** — Python keywords, builtins, strings, comments, decorators
- 📊 **Rich output support** — images, DataFrames, plain text, errors, tracebacks
- 📝 **Markdown rendering** — headings, lists, blockquotes, tables, inline code
- 🚀 **Zero dependencies** — pure Python stdlib, no nbconvert required
- ⚡ **CLI + Python API**

---

## Installation

```bash
pip install nbrose
```

---

## Usage

### CLI

```bash
# Basic conversion — outputs analysis.html
nbrose analysis.ipynb

# Custom output path
nbrose analysis.ipynb -o report.html

# Custom page title
nbrose analysis.ipynb --title "Sales Analysis 2024"

# Check version
nbrose --version
```

### Python API

```python
from nbrose import convert

# Basic — writes analysis.html next to the notebook
convert("analysis.ipynb")

# Custom output path
convert("analysis.ipynb", "report.html")

# Custom title
convert("analysis.ipynb", title="Sales Analysis 2024")

# Full control
from pathlib import Path
out = convert(
    input_path=Path("notebooks/analysis.ipynb"),
    output_path=Path("dist/report.html"),
    title="My Analysis",
)
print(f"Written to {out}")
```

---

## Output Structure

The generated HTML includes:

| Section | Description |
|---------|-------------|
| **Sticky TOC sidebar** | Auto-built from `#`, `##`, `###`, `####` headings |
| **Notebook header** | Title, kernel name, cell counts |
| **Markdown cells** | Full Markdown → HTML with Rosé Pine typography |
| **Code cells** | Syntax-highlighted source + all output types |
| **Outputs** | Text, images (base64), HTML tables, errors |

---

## Rosé Pine Palette

| Role | Color |
|------|-------|
| Background | `#191724` |
| Surface | `#1f1d2e` |
| Text | `#e0def4` |
| Keywords | `#c4a7e7` (iris) |
| Strings | `#f6c177` (gold) |
| Functions | `#ebbcba` (rose) |
| Comments | `#6e6a86` (muted) |
| Numbers | `#9ccfd8` (foam) |
| Builtins | `#eb6f92` (love) |

---

## Requirements

- Python 3.8+
- No external dependencies

---

## License

MIT © [Jahid Hasan](https://github.com/msjahid)
