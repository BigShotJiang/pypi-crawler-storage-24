# ScraperCity Python SDK

B2B lead generation for AI agents and Python developers. 20+ tools including Apollo scraping, Google Maps, email finder/validator, mobile lookup, skip trace, ecommerce store data, and more.

## Install

```bash
pip install scrapercity
```

## Quick Start

```python
from scrapercity import ScraperCity

sc = ScraperCity("your-api-key")

# Check balance
print(sc.wallet())

# Scrape Google Maps
result = sc.scrape_maps("plumbers", "Denver, CO", limit=200)
print(result["runId"])

# Query lead database (requires $649/mo plan)
leads = sc.query_leads(title="CEO", state="California", limit=50)
```

## LangChain / LangGraph

```python
from scrapercity import langchain_tools
from langgraph.prebuilt import create_react_agent

tools = langchain_tools(api_key="your-key")
agent = create_react_agent(llm, tools)
result = agent.invoke({"messages": [{"role": "user", "content": "Find 50 CEOs in New York"}]})
```

## OpenAI Agents SDK

```python
from agents import Agent
from scrapercity.openai_tools import get_tools, init

init("your-api-key")
agent = Agent(name="Lead Gen Agent", tools=get_tools())
```

## OpenAI Function Calling

```python
from scrapercity.openai_tools import get_function_definitions, handle_tool_call, init

init("your-api-key")
tools = get_function_definitions()

response = client.chat.completions.create(
    model="gpt-4o",
    messages=messages,
    tools=tools
)

# Handle the tool call
for call in response.choices[0].message.tool_calls:
    result = handle_tool_call(call.function.name, json.loads(call.function.arguments))
```

## Available Methods

| Method | Description | Cost |
|--------|-------------|------|
| `scrape_apollo(url, count)` | B2B contacts from Apollo.io | $0.0039/lead |
| `scrape_maps(query, location)` | Google Maps businesses | $0.01/place |
| `validate_emails(emails)` | Email deliverability check | $0.0036/email |
| `find_emails(contacts)` | Email from name + company | $0.05/contact |
| `find_mobiles(inputs)` | Phone from LinkedIn/email | $0.25/input |
| `find_people(**params)` | Skip trace by name/email/phone | $0.02/result |
| `scrape_store_leads(**params)` | Shopify/WooCommerce stores | $0.0039/lead |
| `scrape_builtwith(technology)` | Sites using a technology | $4.99/search |
| `search_criminal_records(name)` | Background check | $1.00 if found |
| `query_leads(**params)` | 4M+ B2B database (instant) | Included ($649 plan) |
| `scrape_yelp(**params)` | Yelp business listings | varies |
| `scrape_angi(keyword, zips)` | Angi service providers | varies |
| `scrape_zillow_agents(location)` | Zillow real estate agents | varies |
| `scrape_airbnb(**params)` | Airbnb host emails | varies |
| `scrape_youtube_email(channels)` | YouTube channel emails | varies |

## Authentication

```bash
export SCRAPERCITY_API_KEY="your-key"
```

Or pass directly: `ScraperCity(api_key="your-key")`

Get your API key at [scrapercity.com](https://scrapercity.com)

## License

MIT
