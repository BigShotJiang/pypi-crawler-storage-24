"""LangChain tool wrappers for ScraperCity.

Usage with LangChain:
    from scrapercity import langchain_tools
    tools = langchain_tools()
    # Use with any LangChain agent

Usage with LangGraph:
    from scrapercity import langchain_tools
    from langgraph.prebuilt import create_react_agent
    tools = langchain_tools()
    agent = create_react_agent(llm, tools)
"""
import json
from typing import Optional

from scrapercity.client import ScraperCity


def get_tools(api_key: Optional[str] = None) -> list:
    """Return a list of LangChain tools for ScraperCity.

    Args:
        api_key: ScraperCity API key. Falls back to SCRAPERCITY_API_KEY env var.

    Returns:
        List of LangChain tools ready to use with any agent.
    """
    try:
        from langchain_core.tools import tool as langchain_tool
    except ImportError:
        raise ImportError("Install langchain-core: pip install scrapercity[langchain]")

    sc = ScraperCity(api_key)

    @langchain_tool
    def check_wallet() -> str:
        """Check ScraperCity account balance, plan, and billing info. Call this FIRST to verify credits."""
        return json.dumps(sc.wallet(), indent=2)

    @langchain_tool
    def list_runs(hours: int = 24, limit: int = 20) -> str:
        """List recent ScraperCity scraper runs with status, lead counts, and costs."""
        return json.dumps(sc.runs(hours, limit), indent=2)

    @langchain_tool
    def scrape_apollo(url: str, count: int = 1000) -> str:
        """Scrape B2B contacts from Apollo.io using a search URL. Delivery takes up to 4 days."""
        return json.dumps(sc.scrape_apollo(url, count), indent=2)

    @langchain_tool
    def scrape_maps(query: str, location: str, limit: int = 500) -> str:
        """Scrape businesses from Google Maps. Returns names, addresses, phones, emails, ratings."""
        return json.dumps(sc.scrape_maps(query, location, limit), indent=2)

    @langchain_tool
    def validate_emails(emails: list[str]) -> str:
        """Validate email addresses. Returns deliverability status, catch-all detection, MX records."""
        return json.dumps(sc.validate_emails(emails), indent=2)

    @langchain_tool
    def find_emails(contacts: list[dict]) -> str:
        """Find business email addresses from name + company. Each contact needs name AND company/domain."""
        return json.dumps(sc.find_emails(contacts), indent=2)

    @langchain_tool
    def find_mobiles(inputs: list[str]) -> str:
        """Find mobile phone numbers from LinkedIn URLs or work emails."""
        return json.dumps(sc.find_mobiles(inputs), indent=2)

    @langchain_tool
    def find_people(name: list[str] = None, email: list[str] = None, phone_number: list[str] = None) -> str:
        """Skip trace / people finder. Look up personal info by name, email, or phone."""
        params = {}
        if name:
            params["name"] = name
        if email:
            params["email"] = email
        if phone_number:
            params["phone_number"] = phone_number
        return json.dumps(sc.find_people(**params), indent=2)

    @langchain_tool
    def scrape_store_leads(platform: str = "shopify", country_code: str = "", total_leads: int = 1000) -> str:
        """Get ecommerce store data (Shopify, WooCommerce, etc). Instant results from cached database."""
        return json.dumps(sc.scrape_store_leads(platform=platform, countryCode=country_code, totalLeads=total_leads), indent=2)

    @langchain_tool
    def query_lead_database(title: str = "", industry: str = "", state: str = "", city: str = "", limit: int = 50) -> str:
        """Query 4M+ B2B contacts instantly by title, industry, and location. Requires $649/mo plan."""
        return json.dumps(sc.query_leads(title=title, industry=industry, state=state, city=city, limit=limit), indent=2)

    @langchain_tool
    def check_run_status(run_id: str) -> str:
        """Check status of a scraper run. Returns RUNNING/SUCCEEDED/FAILED and download URL when done."""
        return json.dumps(sc.status(run_id), indent=2)

    @langchain_tool
    def download_results(run_id: str, output_path: str = "") -> str:
        """Download CSV results of a completed scraper run."""
        return json.dumps(sc.download(run_id, output_path or None), indent=2)

    @langchain_tool
    def cancel_run(run_id: str) -> str:
        """Cancel a running scraper job."""
        return json.dumps(sc.cancel(run_id), indent=2)

    return [
        check_wallet,
        list_runs,
        scrape_apollo,
        scrape_maps,
        validate_emails,
        find_emails,
        find_mobiles,
        find_people,
        scrape_store_leads,
        query_lead_database,
        check_run_status,
        download_results,
        cancel_run,
    ]
