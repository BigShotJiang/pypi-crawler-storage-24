"""ScraperCity API client."""
import os
import json
import time
from pathlib import Path
from typing import Any, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode

BASE_URL = "https://app.scrapercity.com"


class ScraperCity:
    """ScraperCity API client for B2B lead generation.

    Usage:
        from scrapercity import ScraperCity
        sc = ScraperCity("your-api-key")
        result = sc.wallet()
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("SCRAPERCITY_API_KEY") or self._load_rc()
        if not self.api_key:
            raise ValueError(
                "No API key. Pass api_key= or set SCRAPERCITY_API_KEY env var. "
                "Get yours at scrapercity.com"
            )

    def _load_rc(self) -> Optional[str]:
        rc = Path.home() / ".scrapercityrc"
        if rc.exists():
            data = json.loads(rc.read_text())
            return data.get("apiKey")
        return None

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = path if path.startswith("http") else f"{BASE_URL}{path}"
        data = json.dumps(body).encode() if body and method != "GET" else None
        req = Request(url, data=data, method=method)
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "scrapercity-python/1.0")
        try:
            with urlopen(req) as resp:
                return json.loads(resp.read())
        except HTTPError as e:
            text = e.read().decode()
            try:
                err = json.loads(text)
            except Exception:
                err = {"raw": text}
            raise RuntimeError(err.get("error", err.get("message", f"HTTP {e.code}"))) from e

    def _get(self, path: str) -> dict:
        return self._request("GET", path)

    def _post(self, path: str, body: dict) -> dict:
        return self._request("POST", path, body)

    # ── Wallet & Runs ──────────────────────────────────────────
    def wallet(self) -> dict:
        """Check account balance, plan, and billing info."""
        return self._get("/api/v1/wallet")

    def runs(self, hours: int = 24, limit: int = 50) -> dict:
        """List recent scraper runs."""
        return self._get(f"/api/v1/runs?hours={hours}&limit={limit}")

    # ── Status / Download / Cancel ─────────────────────────────
    def status(self, run_id: str) -> dict:
        """Check status of a scraper run."""
        return self._get(f"/api/v1/scrape/status/{run_id}")

    def cancel(self, run_id: str) -> dict:
        """Cancel a running scraper job."""
        return self._post(f"/api/v1/scrape/cancel/{run_id}", {})

    def download(self, run_id: str, output_path: Optional[str] = None) -> dict:
        """Download CSV results of a completed run."""
        url = f"{BASE_URL}/api/downloads/{run_id}"
        req = Request(url)
        req.add_header("Authorization", f"Bearer {self.api_key}")
        with urlopen(req) as resp:
            data = resp.read()
        out = output_path or f"{run_id}.csv"
        Path(out).write_bytes(data)
        return {"path": out, "bytes": len(data)}

    # ── Apollo ─────────────────────────────────────────────────
    def scrape_apollo(self, url: str, count: int = 1000, file_name: str = "") -> dict:
        """Scrape B2B contacts from Apollo.io using a search URL."""
        return self._post("/api/v1/scrape/apollo", {"url": url, "count": count, "fileName": file_name})

    def scrape_apollo_filters(self, **filters) -> dict:
        """Scrape Apollo.io using filter parameters."""
        return self._post("/api/v1/scrape/apollo-filters", filters)

    # ── Maps ───────────────────────────────────────────────────
    def scrape_maps(self, query: str, location: str, limit: int = 500) -> dict:
        """Scrape businesses from Google Maps."""
        q = [query] if isinstance(query, str) else query
        return self._post("/api/v1/scrape/maps", {
            "searchStringsArray": q,
            "locationQuery": location,
            "maxCrawledPlacesPerSearch": limit
        })

    # ── Email Validator ────────────────────────────────────────
    def validate_emails(self, emails: list[str]) -> dict:
        """Validate email addresses for deliverability."""
        return self._post("/api/v1/scrape/email-validator", {"emails": emails})

    # ── Email Finder ───────────────────────────────────────────
    def find_emails(self, contacts: list[dict], validate: bool = False, mobiles: bool = False) -> dict:
        """Find business email addresses from name + company."""
        return self._post("/api/v1/scrape/email-finder", {
            "contacts": contacts,
            "autoValidateEmails": validate,
            "autoFindMobiles": mobiles
        })

    # ── Mobile Finder ──────────────────────────────────────────
    def find_mobiles(self, inputs: list[str]) -> dict:
        """Find mobile numbers from LinkedIn URLs or work emails."""
        return self._post("/api/v1/scrape/mobile-finder", {"inputs": inputs})

    # ── People Finder / Skip Trace ─────────────────────────────
    def find_people(self, **params) -> dict:
        """Skip trace - look up personal info by name, email, phone, or address."""
        return self._post("/api/v1/scrape/people-finder", params)

    # ── Store Leads (Ecommerce) ────────────────────────────────
    def scrape_store_leads(self, **params) -> dict:
        """Get ecommerce store data (Shopify, WooCommerce, etc)."""
        return self._post("/api/v1/scrape/store-leads", params)

    # ── BuiltWith ──────────────────────────────────────────────
    def scrape_builtwith(self, technology: str, file_name: str = "") -> dict:
        """Find websites using a specific technology."""
        return self._post("/api/v1/scrape/builtwith", {"technology": technology, "fileName": file_name})

    # ── Criminal Records ───────────────────────────────────────
    def search_criminal_records(self, name: str, state: str = "", dob: str = "") -> dict:
        """Search criminal records by name."""
        return self._post("/api/v1/scrape/criminal-records", {"name": name, "state": state, "dob": dob})

    # ── Airbnb ─────────────────────────────────────────────────
    def scrape_airbnb(self, **params) -> dict:
        """Scrape Airbnb host emails by city or listing URL."""
        return self._post("/api/v1/scrape/airbnb-email", params)

    # ── YouTube Email ──────────────────────────────────────────
    def scrape_youtube_email(self, channels: list[str]) -> dict:
        """Find business emails for YouTube channels."""
        return self._post("/api/v1/scrape/youtube-email", {"channels": channels})

    # ── Website Finder ─────────────────────────────────────────
    def scrape_website_finder(self, domains: list[str], job_title: str = "") -> dict:
        """Find contact info from website domains."""
        return self._post("/api/v1/scrape/website-finder", {"domains": domains, "jobTitle": job_title})

    # ── Yelp ───────────────────────────────────────────────────
    def scrape_yelp(self, **params) -> dict:
        """Scrape business listings from Yelp."""
        return self._post("/api/v1/scrape/yelp-scraper", params)

    # ── Angi ───────────────────────────────────────────────────
    def scrape_angi(self, keyword: str, zip_codes: list[str] = None, max_items: int = 100) -> dict:
        """Scrape from Angi (Angie's List)."""
        return self._post("/api/v1/scrape/angi-angies-list-scraper", {
            "keyword": keyword, "zipCodes": zip_codes or [], "maxItems": max_items
        })

    # ── Zillow Agents ──────────────────────────────────────────
    def scrape_zillow_agents(self, location: str, **opts) -> dict:
        """Scrape real estate agents from Zillow."""
        return self._post("/api/v1/scrape/zillow-agents", {"location": location, **opts})

    # ── BizBuySell ─────────────────────────────────────────────
    def scrape_bizbuysell(self, start_urls: list[str], max_items: int = 100) -> dict:
        """Scrape business-for-sale listings."""
        return self._post("/api/v1/scrape/bizbuysell-scraper", {"startUrls": start_urls, "maxItems": max_items})

    # ── Crexi ──────────────────────────────────────────────────
    def scrape_crexi(self, start_urls: list[str]) -> dict:
        """Scrape commercial real estate from Crexi."""
        return self._post("/api/v1/scrape/crexi-scraper", {"startUrls": start_urls})

    # ── Property Lookup ────────────────────────────────────────
    def scrape_property_lookup(self, addresses: list[str], include_owner: bool = False) -> dict:
        """Look up property data by address."""
        return self._post("/api/v1/scrape/property-lookup", {
            "addresses": addresses, "includeOwnerContact": include_owner
        })

    # ── Lead Database ($649 plan) ──────────────────────────────
    def query_leads(self, **params) -> dict:
        """Query 4M+ B2B contacts instantly."""
        qs = urlencode({k: v for k, v in params.items() if v}, doseq=True)
        return self._get(f"/api/v1/database/leads?{qs}")

    def query_local_businesses(self, **params) -> dict:
        """Query local business database."""
        qs = urlencode({k: v for k, v in params.items() if v}, doseq=True)
        return self._get(f"/api/v1/database/local-businesses?{qs}")

    def query_ecommerce(self, **params) -> dict:
        """Query ecommerce store database."""
        qs = urlencode({k: v for k, v in params.items() if v}, doseq=True)
        return self._get(f"/api/v1/database/ecommerce?{qs}")

    # ── Poll ───────────────────────────────────────────────────
    def poll_until_done(self, run_id: str, interval: int = 15, timeout: int = 3600) -> dict:
        """Poll a run until it completes. Returns final status."""
        start = time.time()
        while time.time() - start < timeout:
            s = self.status(run_id)
            if s.get("status") == "SUCCEEDED":
                return s
            if s.get("status") in ("FAILED", "CANCELLED"):
                raise RuntimeError(f"Run {run_id} ended: {s.get('status')} - {s.get('statusMessage', '')}")
            time.sleep(interval)
        raise TimeoutError(f"Timed out after {timeout}s waiting for {run_id}")
