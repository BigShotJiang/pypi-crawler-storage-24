"""ScraperCity - B2B lead generation for AI agents and Python developers."""
from scrapercity.client import ScraperCity

__version__ = "1.0.0"
__all__ = ["ScraperCity", "langchain_tools"]


def langchain_tools(api_key=None):
    """Lazy import to avoid requiring langchain-core for basic usage."""
    from scrapercity.langchain_tools import get_tools
    return get_tools(api_key)
