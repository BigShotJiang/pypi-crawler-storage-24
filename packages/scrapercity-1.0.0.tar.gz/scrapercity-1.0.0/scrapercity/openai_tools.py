"""OpenAI Agents SDK tool definitions for ScraperCity.

Usage with OpenAI Agents SDK:
    from scrapercity.openai_tools import get_tools
    from agents import Agent

    tools = get_tools()
    agent = Agent(name="Lead Gen Agent", tools=tools)

Usage with OpenAI function calling:
    from scrapercity.openai_tools import get_function_definitions, handle_tool_call
    functions = get_function_definitions()
    # Pass to chat.completions.create(tools=functions)
    # Then: result = handle_tool_call(function_name, arguments)
"""
import json
from typing import Optional

from scrapercity.client import ScraperCity

_client: Optional[ScraperCity] = None


def _get_client() -> ScraperCity:
    global _client
    if _client is None:
        _client = ScraperCity()
    return _client


def init(api_key: Optional[str] = None):
    """Initialize the ScraperCity client. Call before using tools."""
    global _client
    _client = ScraperCity(api_key)


# ── Tool handler functions ─────────────────────────────────────

def _check_wallet(**kwargs) -> str:
    return json.dumps(_get_client().wallet(), indent=2)

def _list_runs(hours: int = 24, limit: int = 20, **kwargs) -> str:
    return json.dumps(_get_client().runs(hours, limit), indent=2)

def _scrape_apollo(url: str, count: int = 1000, **kwargs) -> str:
    return json.dumps(_get_client().scrape_apollo(url, count), indent=2)

def _scrape_maps(query: str, location: str, limit: int = 500, **kwargs) -> str:
    return json.dumps(_get_client().scrape_maps(query, location, limit), indent=2)

def _validate_emails(emails: list, **kwargs) -> str:
    return json.dumps(_get_client().validate_emails(emails), indent=2)

def _find_emails(contacts: list, **kwargs) -> str:
    return json.dumps(_get_client().find_emails(contacts), indent=2)

def _find_mobiles(inputs: list, **kwargs) -> str:
    return json.dumps(_get_client().find_mobiles(inputs), indent=2)

def _find_people(**params) -> str:
    return json.dumps(_get_client().find_people(**params), indent=2)

def _scrape_store_leads(platform: str = "shopify", country_code: str = "", total_leads: int = 1000, **kwargs) -> str:
    return json.dumps(_get_client().scrape_store_leads(platform=platform, countryCode=country_code, totalLeads=total_leads), indent=2)

def _query_lead_database(title: str = "", industry: str = "", state: str = "", city: str = "", limit: int = 50, **kwargs) -> str:
    return json.dumps(_get_client().query_leads(title=title, industry=industry, state=state, city=city, limit=limit), indent=2)

def _check_run_status(run_id: str, **kwargs) -> str:
    return json.dumps(_get_client().status(run_id), indent=2)

def _download_results(run_id: str, output_path: str = "", **kwargs) -> str:
    return json.dumps(_get_client().download(run_id, output_path or None), indent=2)

def _cancel_run(run_id: str, **kwargs) -> str:
    return json.dumps(_get_client().cancel(run_id), indent=2)


_HANDLERS = {
    "check_wallet": _check_wallet,
    "list_runs": _list_runs,
    "scrape_apollo": _scrape_apollo,
    "scrape_maps": _scrape_maps,
    "validate_emails": _validate_emails,
    "find_emails": _find_emails,
    "find_mobiles": _find_mobiles,
    "find_people": _find_people,
    "scrape_store_leads": _scrape_store_leads,
    "query_lead_database": _query_lead_database,
    "check_run_status": _check_run_status,
    "download_results": _download_results,
    "cancel_run": _cancel_run,
}


def handle_tool_call(function_name: str, arguments: dict) -> str:
    """Handle a tool call from OpenAI function calling.

    Args:
        function_name: The function name from the model's tool call.
        arguments: The parsed arguments dict.

    Returns:
        JSON string result.
    """
    handler = _HANDLERS.get(function_name)
    if not handler:
        return json.dumps({"error": f"Unknown function: {function_name}"})
    return handler(**arguments)


def get_function_definitions() -> list[dict]:
    """Return OpenAI function calling tool definitions.

    Use with: openai.chat.completions.create(tools=get_function_definitions())
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "check_wallet",
                "description": "Check ScraperCity account balance, plan, and billing info. Call FIRST to verify credits.",
                "parameters": {"type": "object", "properties": {}}
            }
        },
        {
            "type": "function",
            "function": {
                "name": "list_runs",
                "description": "List recent scraper runs with status, lead counts, and costs.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "hours": {"type": "integer", "description": "Hours back to look (default 24)", "default": 24},
                        "limit": {"type": "integer", "description": "Max runs to return (default 20)", "default": 20}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "scrape_apollo",
                "description": "Scrape B2B contacts from Apollo.io using a search URL. Delivery takes up to 4 days.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "Full Apollo.io search URL"},
                        "count": {"type": "integer", "description": "Number of leads (min 500, max 50000)", "default": 1000}
                    },
                    "required": ["url"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "scrape_maps",
                "description": "Scrape businesses from Google Maps with phones, emails, ratings.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search keyword e.g. 'plumbers'"},
                        "location": {"type": "string", "description": "City/area e.g. 'Denver, CO'"},
                        "limit": {"type": "integer", "description": "Max places (default 500)", "default": 500}
                    },
                    "required": ["query", "location"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "validate_emails",
                "description": "Validate email deliverability, catch-all detection, MX records.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "emails": {"type": "array", "items": {"type": "string"}, "description": "Emails to validate"}
                    },
                    "required": ["emails"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "find_emails",
                "description": "Find business email addresses from name + company.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "contacts": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "first_name": {"type": "string"},
                                    "last_name": {"type": "string"},
                                    "domain": {"type": "string"},
                                    "company_name": {"type": "string"}
                                }
                            },
                            "description": "Contacts to find emails for"
                        }
                    },
                    "required": ["contacts"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "find_mobiles",
                "description": "Find mobile phone numbers from LinkedIn URLs or work emails.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "inputs": {"type": "array", "items": {"type": "string"}, "description": "LinkedIn URLs or work emails"}
                    },
                    "required": ["inputs"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "find_people",
                "description": "Skip trace / people finder. Look up by name, email, phone, or address.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "array", "items": {"type": "string"}, "description": "Full names"},
                        "email": {"type": "array", "items": {"type": "string"}, "description": "Emails"},
                        "phone_number": {"type": "array", "items": {"type": "string"}, "description": "Phone numbers"}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "scrape_store_leads",
                "description": "Get ecommerce store data (Shopify, WooCommerce, etc). Instant results.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "platform": {"type": "string", "description": "e.g. shopify, woocommerce", "default": "shopify"},
                        "country_code": {"type": "string", "description": "e.g. US, GB"},
                        "total_leads": {"type": "integer", "description": "Number of leads", "default": 1000}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "query_lead_database",
                "description": "Query 4M+ B2B contacts instantly by title, industry, location. Requires $649/mo plan.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Job title filter"},
                        "industry": {"type": "string", "description": "Company industry"},
                        "state": {"type": "string", "description": "Person state"},
                        "city": {"type": "string", "description": "Person city"},
                        "limit": {"type": "integer", "description": "Results per page (max 100)", "default": 50}
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "check_run_status",
                "description": "Check status of a scraper run. Returns RUNNING/SUCCEEDED/FAILED.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "run_id": {"type": "string", "description": "The run ID"}
                    },
                    "required": ["run_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "download_results",
                "description": "Download CSV results of a completed run.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "run_id": {"type": "string", "description": "The run ID"},
                        "output_path": {"type": "string", "description": "File path to save CSV"}
                    },
                    "required": ["run_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "cancel_run",
                "description": "Cancel a running scraper job.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "run_id": {"type": "string", "description": "The run ID to cancel"}
                    },
                    "required": ["run_id"]
                }
            }
        }
    ]


def get_tools():
    """Return tools compatible with OpenAI Agents SDK.

    Usage:
        from agents import Agent
        from scrapercity.openai_tools import get_tools, init

        init("your-api-key")
        agent = Agent(name="Lead Gen", tools=get_tools())
    """
    try:
        from agents import FunctionTool
    except ImportError:
        raise ImportError("Install openai-agents: pip install openai-agents")

    tools = []
    for defn in get_function_definitions():
        fn = defn["function"]
        handler = _HANDLERS[fn["name"]]
        tools.append(FunctionTool(
            name=fn["name"],
            description=fn["description"],
            params_json_schema=fn["parameters"],
            on_invoke_tool=lambda ctx, args, h=handler: h(**json.loads(args))
        ))
    return tools
