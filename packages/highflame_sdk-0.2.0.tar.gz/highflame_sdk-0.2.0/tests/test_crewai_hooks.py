"""Tests for HighflameCrewHooks (highflame/integrations/crewai.py).

crewai.hooks is injected as a mock module so it need not be installed.
"""

from __future__ import annotations

import json
import sys
import types
from types import SimpleNamespace

import httpx
import pytest
import respx

# ---------------------------------------------------------------------------
# Inject mock crewai.hooks before importing the integration
# ---------------------------------------------------------------------------

# Module-level tracking registry — reset by autouse fixture per test.
_registry: dict[str, list] = {
    "before_llm": [],
    "after_llm": [],
    "before_tool": [],
    "after_tool": [],
}


def _mock_register_before_llm_call_hook(fn):
    _registry["before_llm"].append(fn)


def _mock_register_after_llm_call_hook(fn):
    _registry["after_llm"].append(fn)


def _mock_register_before_tool_call_hook(fn):
    _registry["before_tool"].append(fn)


def _mock_register_after_tool_call_hook(fn):
    _registry["after_tool"].append(fn)


def _mock_unregister_before_llm_call_hook(fn):
    try:
        _registry["before_llm"].remove(fn)
    except ValueError:
        pass


def _mock_unregister_after_llm_call_hook(fn):
    try:
        _registry["after_llm"].remove(fn)
    except ValueError:
        pass


def _mock_unregister_before_tool_call_hook(fn):
    try:
        _registry["before_tool"].remove(fn)
    except ValueError:
        pass


def _mock_unregister_after_tool_call_hook(fn):
    try:
        _registry["after_tool"].remove(fn)
    except ValueError:
        pass


_mock_hooks_mod = types.ModuleType("crewai.hooks")
_mock_hooks_mod.register_before_llm_call_hook = _mock_register_before_llm_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.register_after_llm_call_hook = _mock_register_after_llm_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.register_before_tool_call_hook = _mock_register_before_tool_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.register_after_tool_call_hook = _mock_register_after_tool_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.unregister_before_llm_call_hook = _mock_unregister_before_llm_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.unregister_after_llm_call_hook = _mock_unregister_after_llm_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.unregister_before_tool_call_hook = _mock_unregister_before_tool_call_hook  # type: ignore[attr-defined]
_mock_hooks_mod.unregister_after_tool_call_hook = _mock_unregister_after_tool_call_hook  # type: ignore[attr-defined]

# Build minimal crewai package hierarchy
_mock_crewai = types.ModuleType("crewai")
sys.modules.setdefault("crewai", _mock_crewai)
sys.modules["crewai.hooks"] = _mock_hooks_mod

# Now import — crewai stubs are in place
from highflame import BlockedError, Highflame  # noqa: E402
from highflame.integrations.crewai import (  # noqa: E402
    HighflameCrewHooks,
    _extract_last_user_message,
    _resolve_session_id,
)

BASE_URL = "http://guard.test"
API_KEY = "test-key"

_ALLOW_BODY = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_BODY = {
    "decision": "deny",
    "policy_reason": "policy violation",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard"],
    "detectors": [],
    "context": {},
}


def _client() -> Highflame:
    return Highflame(base_url=BASE_URL, api_key=API_KEY, max_retries=0)


def _hooks(**kwargs) -> HighflameCrewHooks:
    return HighflameCrewHooks(_client(), **kwargs)


def _guard_route(router: respx.MockRouter, body: dict) -> respx.Route:
    return router.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=body))


@pytest.fixture(autouse=True)
def _reset_registry():
    """Reset the mock hook registry before each test."""
    for key in _registry:
        _registry[key].clear()
    yield
    for key in _registry:
        _registry[key].clear()


# ===========================================================================
# 1. Helper unit tests — _extract_last_user_message
# ===========================================================================


class TestExtractLastUserMessage:
    def test_single_user_dict(self):
        messages = [{"role": "user", "content": "hello"}]
        assert _extract_last_user_message(messages) == "hello"

    def test_returns_last_of_multiple_user_msgs(self):
        messages = [
            {"role": "user", "content": "first"},
            {"role": "assistant", "content": "response"},
            {"role": "user", "content": "second"},
        ]
        assert _extract_last_user_message(messages) == "second"

    def test_no_user_message_returns_none(self):
        messages = [{"role": "assistant", "content": "only ai"}]
        assert _extract_last_user_message(messages) is None

    def test_empty_list_returns_none(self):
        assert _extract_last_user_message([]) is None

    def test_role_human_variant(self):
        messages = [{"role": "human", "content": "from human"}]
        assert _extract_last_user_message(messages) == "from human"

    def test_object_with_attrs(self):
        msg = SimpleNamespace(role="user", content="object content")
        assert _extract_last_user_message([msg]) == "object content"

    def test_mixed_roles_returns_last_user(self):
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "user msg"},
            {"role": "assistant", "content": "ai msg"},
        ]
        assert _extract_last_user_message(messages) == "user msg"


# ===========================================================================
# 2. Helper unit tests — _resolve_session_id
# ===========================================================================


class TestResolveSessionId:
    def test_static_id_wins(self):
        context = SimpleNamespace(crew=SimpleNamespace(id="crew_99"))
        assert _resolve_session_id(context, "static_session") == "static_session"

    def test_falls_back_to_crew_id(self):
        context = SimpleNamespace(crew=SimpleNamespace(id="crew_42"))
        assert _resolve_session_id(context, None) == "crew_42"

    def test_none_when_neither(self):
        context = SimpleNamespace()
        assert _resolve_session_id(context, None) is None

    def test_crew_id_coerced_to_str(self):
        context = SimpleNamespace(crew=SimpleNamespace(id=12345))
        assert _resolve_session_id(context, None) == "12345"

    def test_crew_missing_id_attr_returns_none(self):
        context = SimpleNamespace(crew=SimpleNamespace())
        assert _resolve_session_id(context, None) is None


# ===========================================================================
# 3. Instantiation
# ===========================================================================


class TestInstantiation:
    def test_default_mode_is_enforce(self):
        h = _hooks()
        assert h._mode == "enforce"

    def test_custom_mode_preserved(self):
        h = _hooks(mode="monitor")
        assert h._mode == "monitor"

    def test_import_error_without_crewai(self, monkeypatch):
        import highflame.integrations.crewai as mod

        monkeypatch.setattr(mod, "_CREWAI_AVAILABLE", False)
        with pytest.raises(ImportError, match="crewai"):
            HighflameCrewHooks(_client())


# ===========================================================================
# 4. register() / unregister()
# ===========================================================================


class TestRegisterUnregister:
    def test_register_adds_all_four_hooks(self):
        h = _hooks()
        h.register()
        assert h._before_llm_call in _registry["before_llm"]
        assert h._after_llm_call in _registry["after_llm"]
        assert h._before_tool_call in _registry["before_tool"]
        assert h._after_tool_call in _registry["after_tool"]

    def test_unregister_removes_all_four_hooks(self):
        h = _hooks()
        h.register()
        h.unregister()
        assert h._before_llm_call not in _registry["before_llm"]
        assert h._after_llm_call not in _registry["after_llm"]
        assert h._before_tool_call not in _registry["before_tool"]
        assert h._after_tool_call not in _registry["after_tool"]

    def test_context_manager_hooks_present_inside(self):
        h = _hooks()
        with h:
            assert h._before_llm_call in _registry["before_llm"]
            assert h._after_llm_call in _registry["after_llm"]
            assert h._before_tool_call in _registry["before_tool"]
            assert h._after_tool_call in _registry["after_tool"]

    def test_context_manager_hooks_absent_after(self):
        h = _hooks()
        with h:
            pass
        assert h._before_llm_call not in _registry["before_llm"]
        assert h._after_llm_call not in _registry["after_llm"]
        assert h._before_tool_call not in _registry["before_tool"]
        assert h._after_tool_call not in _registry["after_tool"]


# ===========================================================================
# 5. _before_llm_call — allow
# ===========================================================================


class TestBeforeLlmCallAllow:
    @respx.mock
    def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            messages=[{"role": "user", "content": "hello world"}],
            crew=SimpleNamespace(id=None),
        )
        h._before_llm_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "hello world"
        assert sent["content_type"] == "prompt"
        assert sent["action"] == "process_prompt"

    @respx.mock
    def test_mode_forwarded(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(mode="monitor")
        context = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            crew=SimpleNamespace(id=None),
        )
        h._before_llm_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["mode"] == "monitor"

    @respx.mock
    def test_session_id_from_crew(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            crew=SimpleNamespace(id="crew_abc"),
        )
        h._before_llm_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("session_id") == "crew_abc"

    @respx.mock
    def test_static_session_id_passed_through(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(session_id="static_sess")
        context = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            crew=SimpleNamespace(id="crew_abc"),
        )
        h._before_llm_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("session_id") == "static_sess"

    @respx.mock
    def test_skips_guard_when_no_user_message(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            messages=[{"role": "assistant", "content": "only ai"}],
            crew=SimpleNamespace(id=None),
        )
        h._before_llm_call(context)

        assert len(route.calls) == 0

    @respx.mock
    def test_skips_guard_when_messages_empty(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(messages=[], crew=SimpleNamespace(id=None))
        h._before_llm_call(context)

        assert len(route.calls) == 0


# ===========================================================================
# 6. _before_llm_call — deny
# ===========================================================================


class TestBeforeLlmCallDeny:
    @respx.mock
    def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        context = SimpleNamespace(
            messages=[{"role": "user", "content": "bad input"}],
            crew=SimpleNamespace(id=None),
        )
        with pytest.raises(BlockedError) as exc_info:
            h._before_llm_call(context)

        assert exc_info.value.response.decision == "deny"


# ===========================================================================
# 7. _after_llm_call — allow
# ===========================================================================


class TestAfterLlmCallAllow:
    @respx.mock
    def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(response="model output", crew=SimpleNamespace(id=None))
        h._after_llm_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "model output"
        assert sent["content_type"] == "response"
        assert sent["action"] == "process_prompt"

    @respx.mock
    def test_skips_when_response_is_none(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(response=None, crew=SimpleNamespace(id=None))
        h._after_llm_call(context)

        assert len(route.calls) == 0

    @respx.mock
    def test_skips_when_response_is_empty_string(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(response="", crew=SimpleNamespace(id=None))
        h._after_llm_call(context)

        assert len(route.calls) == 0


# ===========================================================================
# 8. _after_llm_call — deny
# ===========================================================================


class TestAfterLlmCallDeny:
    @respx.mock
    def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        context = SimpleNamespace(response="toxic output", crew=SimpleNamespace(id=None))
        with pytest.raises(BlockedError):
            h._after_llm_call(context)


# ===========================================================================
# 9. _before_tool_call — allow
# ===========================================================================


class TestBeforeToolCallAllow:
    @respx.mock
    def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            tool_name="search",
            tool_input={"q": "test"},
            crew=SimpleNamespace(id=None),
        )
        h._before_tool_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content_type"] == "tool_call"
        assert sent["action"] == "call_tool"
        assert "search" in sent["content"]

    @respx.mock
    def test_tool_input_forwarded(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            tool_name="shell",
            tool_input={"cmd": "ls"},
            crew=SimpleNamespace(id=None),
        )
        h._before_tool_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("tool", {}).get("arguments") == {"cmd": "ls"}

    @respx.mock
    def test_none_tool_input_handled(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(
            tool_name="ping",
            tool_input=None,
            crew=SimpleNamespace(id=None),
        )
        h._before_tool_call(context)

        # Should not raise — None tool_input handled gracefully
        assert len(route.calls) == 1

    @respx.mock
    def test_mode_forwarded(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(mode="alert")
        context = SimpleNamespace(
            tool_name="lookup",
            tool_input=None,
            crew=SimpleNamespace(id=None),
        )
        h._before_tool_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["mode"] == "alert"


# ===========================================================================
# 10. _before_tool_call — deny
# ===========================================================================


class TestBeforeToolCallDeny:
    @respx.mock
    def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        context = SimpleNamespace(
            tool_name="dangerous",
            tool_input={"x": 1},
            crew=SimpleNamespace(id=None),
        )
        with pytest.raises(BlockedError):
            h._before_tool_call(context)


# ===========================================================================
# 11. _after_tool_call — allow
# ===========================================================================


class TestAfterToolCallAllow:
    @respx.mock
    def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(tool_result="file contents", crew=SimpleNamespace(id=None))
        h._after_tool_call(context)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "file contents"
        assert sent["content_type"] == "response"
        assert sent["action"] == "call_tool"

    @respx.mock
    def test_skips_when_tool_result_is_none(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(tool_result=None, crew=SimpleNamespace(id=None))
        h._after_tool_call(context)

        assert len(route.calls) == 0

    @respx.mock
    def test_skips_when_tool_result_is_empty_string(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        context = SimpleNamespace(tool_result="", crew=SimpleNamespace(id=None))
        h._after_tool_call(context)

        assert len(route.calls) == 0


# ===========================================================================
# 12. _after_tool_call — deny
# ===========================================================================


class TestAfterToolCallDeny:
    @respx.mock
    def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        context = SimpleNamespace(tool_result="sensitive data", crew=SimpleNamespace(id=None))
        with pytest.raises(BlockedError):
            h._after_tool_call(context)
