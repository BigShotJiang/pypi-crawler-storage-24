"""Tests for HighflameStrandsHooks (highflame/integrations/strands.py).

strands.hooks is injected as a mock module so it need not be installed.
"""

from __future__ import annotations

import json
import sys
import types
from types import SimpleNamespace

import httpx
import pytest
import respx

# ---------------------------------------------------------------------------
# Inject mock strands.hooks before importing the integration
# ---------------------------------------------------------------------------

# Module-level tracking registry — keyed by mock event class, reset per test.
_registry: dict[type, list] = {}


class MockBeforeInvocationEvent:
    pass


class MockAfterModelCallEvent:
    pass


class MockBeforeToolCallEvent:
    pass


class MockAfterToolCallEvent:
    pass


class MockHookRegistry:
    def add_callback(self, event_cls, fn):
        _registry.setdefault(event_cls, []).append(fn)


class MockHookProvider:
    """Minimal stub that HighflameStrandsHooks inherits from."""

    def register_hooks(self, registry):
        pass


_mock_hooks_mod = types.ModuleType("strands.hooks")
_mock_hooks_mod.HookProvider = MockHookProvider  # type: ignore[attr-defined]
_mock_hooks_mod.HookRegistry = MockHookRegistry  # type: ignore[attr-defined]
_mock_hooks_mod.BeforeInvocationEvent = MockBeforeInvocationEvent  # type: ignore[attr-defined]
_mock_hooks_mod.AfterModelCallEvent = MockAfterModelCallEvent  # type: ignore[attr-defined]
_mock_hooks_mod.BeforeToolCallEvent = MockBeforeToolCallEvent  # type: ignore[attr-defined]
_mock_hooks_mod.AfterToolCallEvent = MockAfterToolCallEvent  # type: ignore[attr-defined]

# Build minimal strands package hierarchy in sys.modules
_mock_strands = types.ModuleType("strands")
sys.modules.setdefault("strands", _mock_strands)
sys.modules["strands.hooks"] = _mock_hooks_mod

# Now import — strands stubs are in place
from highflame import BlockedError, Highflame  # noqa: E402
from highflame.integrations.strands import (  # noqa: E402
    HighflameStrandsHooks,
    _extract_last_user_message,
    _extract_model_response,
    _extract_text_from_content,
    _extract_tool_result_content,
    _resolve_session_id,
)

BASE_URL = "http://guard.test"
API_KEY = "test-key"

_ALLOW_BODY = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_BODY = {
    "decision": "deny",
    "policy_reason": "policy violation",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard"],
    "detectors": [],
    "context": {},
}


def _client() -> Highflame:
    return Highflame(base_url=BASE_URL, api_key=API_KEY, max_retries=0)


def _hooks(**kwargs) -> HighflameStrandsHooks:
    return HighflameStrandsHooks(_client(), **kwargs)


def _guard_route(router: respx.MockRouter, body: dict) -> respx.Route:
    return router.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=body))


@pytest.fixture(autouse=True)
def _reset_registry():
    """Reset the mock hook registry before each test."""
    _registry.clear()
    yield
    _registry.clear()


# ===========================================================================
# 1. Helper unit tests — _extract_text_from_content
# ===========================================================================


class TestExtractTextFromContent:
    def test_plain_str(self):
        assert _extract_text_from_content("hello") == "hello"

    def test_list_of_text_dicts(self):
        blocks = [{"type": "text", "text": "foo"}, {"type": "text", "text": "bar"}]
        assert _extract_text_from_content(blocks) == "foo\nbar"

    def test_list_mixed_types_non_text_ignored(self):
        blocks = [{"type": "image", "source": "..."}, {"type": "text", "text": "caption"}]
        assert _extract_text_from_content(blocks) == "caption"

    def test_object_style_blocks(self):
        block = SimpleNamespace(type="text", text="from object")
        assert _extract_text_from_content([block]) == "from object"

    def test_none_returns_none(self):
        assert _extract_text_from_content(None) is None

    def test_empty_list_returns_none(self):
        assert _extract_text_from_content([]) is None

    def test_empty_string_returns_none(self):
        assert _extract_text_from_content("") is None


# ===========================================================================
# 2. Helper unit tests — _extract_last_user_message
# ===========================================================================


class TestExtractLastUserMessage:
    def test_role_user_dict(self):
        messages = [{"role": "user", "content": "hello"}]
        assert _extract_last_user_message(messages) == "hello"

    def test_returns_last_of_multiple_user_msgs(self):
        messages = [
            {"role": "user", "content": "first"},
            {"role": "assistant", "content": "response"},
            {"role": "user", "content": "second"},
        ]
        assert _extract_last_user_message(messages) == "second"

    def test_no_user_message_returns_none(self):
        messages = [{"role": "assistant", "content": "only ai"}]
        assert _extract_last_user_message(messages) is None

    def test_role_human_variant(self):
        messages = [{"role": "human", "content": "from human"}]
        assert _extract_last_user_message(messages) == "from human"

    def test_object_with_attrs(self):
        msg = SimpleNamespace(role="user", content="object content")
        assert _extract_last_user_message([msg]) == "object content"

    def test_skips_system_and_assistant(self):
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "user msg"},
            {"role": "assistant", "content": "ai msg"},
        ]
        assert _extract_last_user_message(messages) == "user msg"

    def test_empty_list_returns_none(self):
        assert _extract_last_user_message([]) is None

    def test_content_as_text_block_list(self):
        messages = [{"role": "user", "content": [{"type": "text", "text": "text block"}]}]
        assert _extract_last_user_message(messages) == "text block"


# ===========================================================================
# 3. Helper unit tests — _extract_model_response
# ===========================================================================


class TestExtractModelResponse:
    def test_dict_message_with_text_content_list(self):
        stop_response = SimpleNamespace(
            message={"content": [{"type": "text", "text": "model output"}]}
        )
        assert _extract_model_response(stop_response) == "model output"

    def test_plain_str_content(self):
        stop_response = SimpleNamespace(message={"content": "plain text"})
        assert _extract_model_response(stop_response) == "plain text"

    def test_none_returns_none(self):
        assert _extract_model_response(None) is None

    def test_none_message_returns_none(self):
        stop_response = SimpleNamespace(message=None)
        assert _extract_model_response(stop_response) is None

    def test_object_message(self):
        msg = SimpleNamespace(content="object message")
        stop_response = SimpleNamespace(message=msg)
        assert _extract_model_response(stop_response) == "object message"


# ===========================================================================
# 4. Helper unit tests — _extract_tool_result_content
# ===========================================================================


class TestExtractToolResultContent:
    def test_dict_with_content_list(self):
        result = {"content": [{"type": "text", "text": "file contents"}]}
        assert _extract_tool_result_content(result) == "file contents"

    def test_plain_str_fallback(self):
        assert _extract_tool_result_content("raw result") == "raw result"

    def test_none_returns_none(self):
        assert _extract_tool_result_content(None) is None

    def test_empty_str_returns_none(self):
        assert _extract_tool_result_content("") is None

    def test_object_with_content_attr(self):
        result = SimpleNamespace(content="output text")
        assert _extract_tool_result_content(result) == "output text"


# ===========================================================================
# 5. Helper unit tests — _resolve_session_id
# ===========================================================================


class TestResolveSessionId:
    def test_static_wins(self):
        assert _resolve_session_id({"session_id": "from_state"}, "session_id", "static") == "static"

    def test_key_from_invocation_state(self):
        assert _resolve_session_id({"session_id": "from_state"}, "session_id", None) == "from_state"

    def test_both_absent_returns_none(self):
        assert _resolve_session_id({}, "session_id", None) is None

    def test_custom_key(self):
        assert _resolve_session_id({"my_sess": "s42"}, "my_sess", None) == "s42"

    def test_value_coerced_to_str(self):
        assert _resolve_session_id({"session_id": 999}, "session_id", None) == "999"


# ===========================================================================
# 6. Instantiation
# ===========================================================================


class TestInstantiation:
    def test_default_mode_is_enforce(self):
        h = _hooks()
        assert h._mode == "enforce"

    def test_custom_mode_preserved(self):
        h = _hooks(mode="monitor")
        assert h._mode == "monitor"

    def test_custom_session_id_key_preserved(self):
        h = _hooks(session_id_key="my_session")
        assert h._session_id_key == "my_session"

    def test_import_error_without_strands(self, monkeypatch):
        import highflame.integrations.strands as mod

        monkeypatch.setattr(mod, "_STRANDS_AVAILABLE", False)
        with pytest.raises(ImportError, match="strands"):
            HighflameStrandsHooks(_client())


# ===========================================================================
# 7. register_hooks()
# ===========================================================================


class TestRegisterHooks:
    def test_all_four_hooks_registered(self):
        h = _hooks()
        reg = MockHookRegistry()
        h.register_hooks(reg)
        assert h._before_invocation in _registry[MockBeforeInvocationEvent]
        assert h._after_model_call in _registry[MockAfterModelCallEvent]
        assert h._before_tool_call in _registry[MockBeforeToolCallEvent]
        assert h._after_tool_call in _registry[MockAfterToolCallEvent]


# ===========================================================================
# 8. _before_invocation — allow
# ===========================================================================


class TestBeforeInvocationAllow:
    @respx.mock
    async def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            messages=[{"role": "user", "content": "hello world"}],
            invocation_state={},
        )
        await h._before_invocation(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "hello world"
        assert sent["content_type"] == "prompt"
        assert sent["action"] == "process_prompt"

    @respx.mock
    async def test_mode_forwarded(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(mode="monitor")
        event = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            invocation_state={},
        )
        await h._before_invocation(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["mode"] == "monitor"

    @respx.mock
    async def test_session_id_from_invocation_state(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            invocation_state={"session_id": "sess_abc"},
        )
        await h._before_invocation(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("session_id") == "sess_abc"

    @respx.mock
    async def test_static_session_id_wins(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(session_id="static_sess")
        event = SimpleNamespace(
            messages=[{"role": "user", "content": "hi"}],
            invocation_state={"session_id": "from_state"},
        )
        await h._before_invocation(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("session_id") == "static_sess"

    @respx.mock
    async def test_skips_when_messages_empty(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(messages=[], invocation_state={})
        await h._before_invocation(event)

        assert len(route.calls) == 0

    @respx.mock
    async def test_skips_when_no_user_message(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            messages=[{"role": "assistant", "content": "only ai"}],
            invocation_state={},
        )
        await h._before_invocation(event)

        assert len(route.calls) == 0

    @respx.mock
    async def test_skips_when_messages_is_none(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(messages=None, invocation_state={})
        await h._before_invocation(event)

        assert len(route.calls) == 0


# ===========================================================================
# 9. _before_invocation — deny
# ===========================================================================


class TestBeforeInvocationDeny:
    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        event = SimpleNamespace(
            messages=[{"role": "user", "content": "bad input"}],
            invocation_state={},
        )
        with pytest.raises(BlockedError) as exc_info:
            await h._before_invocation(event)

        assert exc_info.value.response.decision == "deny"


# ===========================================================================
# 10. _after_model_call — allow
# ===========================================================================


class TestAfterModelCallAllow:
    @respx.mock
    async def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            stop_response=SimpleNamespace(
                message={"content": [{"type": "text", "text": "model output"}]}
            ),
            invocation_state={},
        )
        await h._after_model_call(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "model output"
        assert sent["content_type"] == "response"
        assert sent["action"] == "process_prompt"

    @respx.mock
    async def test_skips_when_stop_response_is_none(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(stop_response=None, invocation_state={})
        await h._after_model_call(event)

        assert len(route.calls) == 0

    @respx.mock
    async def test_skips_when_content_is_empty(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            stop_response=SimpleNamespace(message={"content": []}),
            invocation_state={},
        )
        await h._after_model_call(event)

        assert len(route.calls) == 0


# ===========================================================================
# 11. _after_model_call — deny
# ===========================================================================


class TestAfterModelCallDeny:
    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        event = SimpleNamespace(
            stop_response=SimpleNamespace(message={"content": "bad output"}),
            invocation_state={},
        )
        with pytest.raises(BlockedError):
            await h._after_model_call(event)


# ===========================================================================
# 12. _before_tool_call — allow
# ===========================================================================


class TestBeforeToolCallAllow:
    @respx.mock
    async def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_use={"name": "search", "input": {"q": "test"}},
            invocation_state={},
        )
        await h._before_tool_call(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content_type"] == "tool_call"
        assert sent["action"] == "call_tool"
        assert "search" in sent["content"]

    @respx.mock
    async def test_tool_input_forwarded_as_arguments(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_use={"name": "shell", "input": {"cmd": "ls"}},
            invocation_state={},
        )
        await h._before_tool_call(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("tool", {}).get("arguments") == {"cmd": "ls"}

    @respx.mock
    async def test_none_input_handled(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_use={"name": "ping", "input": None},
            invocation_state={},
        )
        await h._before_tool_call(event)

        assert len(route.calls) == 1

    @respx.mock
    async def test_mode_forwarded(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks(mode="alert")
        event = SimpleNamespace(
            tool_use={"name": "lookup", "input": None},
            invocation_state={},
        )
        await h._before_tool_call(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["mode"] == "alert"


# ===========================================================================
# 13. _before_tool_call — deny
# ===========================================================================


class TestBeforeToolCallDeny:
    @respx.mock
    async def test_cancel_tool_set_to_reason(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_use={"name": "dangerous", "input": {"x": 1}},
            invocation_state={},
            cancel_tool=None,
        )
        with pytest.raises(BlockedError):
            await h._before_tool_call(event)

        assert event.cancel_tool == "policy violation"

    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_use={"name": "dangerous", "input": {"x": 1}},
            invocation_state={},
            cancel_tool=None,
        )
        with pytest.raises(BlockedError):
            await h._before_tool_call(event)


# ===========================================================================
# 14. _after_tool_call — allow
# ===========================================================================


class TestAfterToolCallAllow:
    @respx.mock
    async def test_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_result={"content": [{"type": "text", "text": "file contents"}]},
            invocation_state={},
        )
        await h._after_tool_call(event)

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "file contents"
        assert sent["content_type"] == "response"
        assert sent["action"] == "call_tool"

    @respx.mock
    async def test_skips_when_result_is_none(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(tool_result=None, invocation_state={})
        await h._after_tool_call(event)

        assert len(route.calls) == 0

    @respx.mock
    async def test_skips_when_result_is_empty(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        h = _hooks()
        event = SimpleNamespace(tool_result="", invocation_state={})
        await h._after_tool_call(event)

        assert len(route.calls) == 0


# ===========================================================================
# 15. _after_tool_call — deny
# ===========================================================================


class TestAfterToolCallDeny:
    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        h = _hooks()
        event = SimpleNamespace(
            tool_result="sensitive data",
            invocation_state={},
        )
        with pytest.raises(BlockedError):
            await h._after_tool_call(event)
