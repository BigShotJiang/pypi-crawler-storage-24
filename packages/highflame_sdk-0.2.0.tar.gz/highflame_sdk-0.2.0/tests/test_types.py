"""Serialisation round-trip tests for Pydantic models."""

import pytest

from highflame import (
    FileContext,
    GuardRequest,
    GuardResponse,
    MCPContext,
    ModelContext,
    ToolContext,
)

# ---------------------------------------------------------------------------
# GuardRequest serialisation
# ---------------------------------------------------------------------------


def test_guard_request_minimal():
    """Minimal required fields serialise correctly."""
    req = GuardRequest(
        content="hello",
        content_type="prompt",
        action="process_prompt",
    )
    data = req.model_dump(exclude_none=True, by_alias=True)
    assert data["content"] == "hello"
    assert data["content_type"] == "prompt"
    assert data["action"] == "process_prompt"
    # mode and product default to None → excluded by exclude_none
    assert "mode" not in data
    assert "product" not in data


def test_guard_request_with_tool():
    """ToolContext nested model serialises and round-trips."""
    req = GuardRequest(
        content="shell ls",
        content_type="tool_call",
        action="call_tool",
        tool=ToolContext(name="shell", arguments={"cmd": "ls"}, is_builtin=True),
    )
    payload = req.model_dump(exclude_none=True, by_alias=True)
    assert payload["tool"]["name"] == "shell"
    assert payload["tool"]["arguments"] == {"cmd": "ls"}
    assert payload["tool"]["is_builtin"] is True


def test_guard_request_with_all_contexts():
    """All optional context fields serialise without error."""
    req = GuardRequest(
        content="read /etc/passwd",
        content_type="file",
        action="read_file",
        tool=ToolContext(name="read_file", is_builtin=False),
        model=ModelContext(provider="openai", model="gpt-4o", tokens_used=100),
        file=FileContext(path="/etc/passwd", operation="read"),
        mcp=MCPContext(server_name="fs", verified=False),
        session_id="sess_abc",
        metadata={"user": "alice"},
        contexts=["RAG chunk 1"],
        mode="monitor",
        early_exit=True,
        explain=True,
    )
    data = req.model_dump(exclude_none=True, by_alias=True)
    assert data["session_id"] == "sess_abc"
    assert data["mode"] == "monitor"
    assert data["file"]["path"] == "/etc/passwd"
    assert data["mcp"]["server_name"] == "fs"
    assert data["model"]["provider"] == "openai"
    assert data["contexts"] == ["RAG chunk 1"]


# ---------------------------------------------------------------------------
# GuardResponse deserialisation
# ---------------------------------------------------------------------------

_ALLOW_RESPONSE = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 12,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_RESPONSE = {
    "decision": "deny",
    "actual_decision": "deny",
    "alerted": False,
    "policy_reason": "secrets detected",
    "audit_id": "aud_1",
    "request_id": "req_1",
    "timestamp": "2024-01-01T00:00:01Z",
    "latency_ms": 8,
    "eval_latency_ms": 1,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard", "slow"],
    "detectors": [
        {
            "name": "secrets",
            "tier": "fast",
            "latency_ms": 2,
            "context": {"contains_secrets": True},
            "status": "healthy",
        }
    ],
    "context": {"contains_secrets": True},
    "projected_context": {"contains_secrets": True},
    "determining_policies": [
        {
            "rule_id": "r1",
            "policy_id": "p1",
            "policy_name": "block_secrets",
            "effect": "forbid",
            "mode": "enforce",
            "annotations": {},
        }
    ],
    "root_causes": [
        {
            "summary": "Secrets detected in prompt",
            "detector": "secrets",
            "labels": {"tier": "fast"},
            "triggering_context": {"contains_secrets": True},
            "evidence": {"secret_types": ["api_key"]},
            "triggered_policies": ["p1"],
        }
    ],
    "session_delta": {
        "turn_count": 2,
        "cumulative_risk": 85.5,
        "tokens_used_delta": 150,
        "new_action": "process_prompt",
    },
}


def test_guard_response_allow():
    resp = GuardResponse.model_validate(_ALLOW_RESPONSE)
    assert resp.decision == "allow"
    assert resp.allowed is True
    assert resp.denied is False
    assert resp.latency_ms == 12
    assert resp.tiers_evaluated == ["fast"]


def test_guard_response_deny():
    resp = GuardResponse.model_validate(_DENY_RESPONSE)
    assert resp.decision == "deny"
    assert resp.denied is True
    assert resp.policy_reason == "secrets detected"
    assert resp.audit_id == "aud_1"
    assert resp.tiers_skipped == ["standard", "slow"]

    # Detectors
    assert len(resp.detectors) == 1
    det = resp.detectors[0]
    assert det.name == "secrets"
    assert det.status == "healthy"
    assert det.context["contains_secrets"] is True

    # Determining policies
    assert len(resp.determining_policies) == 1
    pol = resp.determining_policies[0]
    assert pol.policy_name == "block_secrets"
    assert pol.effect == "forbid"

    # Root causes
    assert len(resp.root_causes) == 1
    rc = resp.root_causes[0]
    assert rc.detector == "secrets"
    assert rc.evidence["secret_types"] == ["api_key"]

    # Session delta
    assert resp.session_delta is not None
    assert resp.session_delta.turn_count == 2
    assert resp.session_delta.cumulative_risk == pytest.approx(85.5)


def test_guard_response_alert_mode():
    """alerted flag and actual_decision parse correctly."""
    data = {
        **_ALLOW_RESPONSE,
        "alerted": True,
        "actual_decision": "deny",
        "mode_overridden": True,
        "effective_mode": "alert",
    }
    resp = GuardResponse.model_validate(data)
    assert resp.alerted is True
    assert resp.allowed is True  # decision is still allow
    assert resp.actual_decision == "deny"
    assert resp.mode_overridden is True
    assert resp.effective_mode == "alert"


def test_guard_response_json_round_trip():
    """JSON serialise → deserialise produces identical model."""
    resp = GuardResponse.model_validate(_DENY_RESPONSE)
    serialised = resp.model_dump_json()
    resp2 = GuardResponse.model_validate_json(serialised)
    assert resp2.decision == resp.decision
    assert resp2.policy_reason == resp.policy_reason
    assert resp2.session_delta is not None
    assert resp2.session_delta.turn_count == resp.session_delta.turn_count
