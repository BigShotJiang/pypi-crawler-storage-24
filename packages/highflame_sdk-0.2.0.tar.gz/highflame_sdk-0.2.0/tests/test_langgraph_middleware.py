"""Tests for HighflameMiddleware (highflame/integrations/langgraph.py).

langchain is injected as a mock module so it need not be installed.
"""

from __future__ import annotations

import json
import sys
import types
from types import SimpleNamespace

import httpx
import pytest
import respx

# ---------------------------------------------------------------------------
# Inject mock langchain.agents.middleware before importing the integration
# ---------------------------------------------------------------------------

_mock_middleware_mod = types.ModuleType("langchain.agents.middleware")


class _AgentMiddleware:
    """Minimal stub that HighflameMiddleware inherits from."""


_AgentState = dict

_mock_middleware_mod.AgentMiddleware = _AgentMiddleware  # type: ignore[attr-defined]
_mock_middleware_mod.AgentState = _AgentState  # type: ignore[attr-defined]

# Build minimal langchain package hierarchy in sys.modules
_mock_langchain = types.ModuleType("langchain")
_mock_agents = types.ModuleType("langchain.agents")
sys.modules.setdefault("langchain", _mock_langchain)
sys.modules.setdefault("langchain.agents", _mock_agents)
sys.modules["langchain.agents.middleware"] = _mock_middleware_mod

# Now import — langchain stubs are in place
from highflame import BlockedError, Highflame  # noqa: E402
from highflame.integrations.langgraph import (  # noqa: E402
    HighflameMiddleware,
    _extract_text_from_content,
    _get_last_ai_message,
    _get_last_human_message,
    _resolve_session_id,
)

BASE_URL = "http://guard.test"
API_KEY = "test-key"

_ALLOW_BODY = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_BODY = {
    "decision": "deny",
    "policy_reason": "policy violation",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard"],
    "detectors": [],
    "context": {},
}


def _client() -> Highflame:
    return Highflame(base_url=BASE_URL, api_key=API_KEY, max_retries=0)


def _middleware(**kwargs) -> HighflameMiddleware:
    return HighflameMiddleware(_client(), **kwargs)


def _guard_route(router: respx.MockRouter, body: dict) -> respx.Route:
    return router.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=body))


def _make_msg(type_: str, content: str | list) -> SimpleNamespace:
    return SimpleNamespace(type=type_, content=content)


def _make_state(*messages) -> dict:
    return {"messages": list(messages)}


def _make_runtime(thread_id: str | None = None) -> SimpleNamespace:
    return SimpleNamespace(thread_id=thread_id)


# ===========================================================================
# 1. Helper unit tests
# ===========================================================================


class TestExtractTextFromContent:
    def test_plain_str(self):
        assert _extract_text_from_content("hello") == "hello"

    def test_list_of_text_dicts(self):
        blocks = [{"type": "text", "text": "foo"}, {"type": "text", "text": "bar"}]
        assert _extract_text_from_content(blocks) == "foo\nbar"

    def test_list_mixed_types(self):
        blocks = [{"type": "image_url", "url": "..."}, {"type": "text", "text": "caption"}]
        assert _extract_text_from_content(blocks) == "caption"

    def test_list_with_objects(self):
        block = SimpleNamespace(type="text", text="from object")
        assert _extract_text_from_content([block]) == "from object"

    def test_empty_list(self):
        assert _extract_text_from_content([]) == ""


class TestGetLastHumanMessage:
    def test_returns_last_human(self):
        state = _make_state(
            _make_msg("human", "first"),
            _make_msg("ai", "response"),
            _make_msg("human", "second"),
        )
        assert _get_last_human_message(state) == "second"

    def test_no_human_returns_none(self):
        state = _make_state(_make_msg("ai", "only ai"))
        assert _get_last_human_message(state) is None

    def test_empty_messages(self):
        assert _get_last_human_message({"messages": []}) is None


class TestGetLastAiMessage:
    def test_returns_last_ai(self):
        state = _make_state(
            _make_msg("human", "question"),
            _make_msg("ai", "first answer"),
            _make_msg("ai", "revised answer"),
        )
        assert _get_last_ai_message(state) == "revised answer"

    def test_no_ai_returns_none(self):
        state = _make_state(_make_msg("human", "only human"))
        assert _get_last_ai_message(state) is None


class TestResolveSessionId:
    def test_state_key_takes_priority(self):
        state = {"session": "s_from_state"}
        runtime = _make_runtime("t_from_runtime")
        assert _resolve_session_id(state, runtime, "session") == "s_from_state"

    def test_falls_back_to_thread_id(self):
        state = {"session": None}
        runtime = _make_runtime("thread_42")
        assert _resolve_session_id(state, runtime, "session") == "thread_42"

    def test_no_key_uses_thread_id(self):
        state = {}
        runtime = _make_runtime("t99")
        assert _resolve_session_id(state, runtime, None) == "t99"

    def test_none_when_nothing(self):
        assert _resolve_session_id({}, _make_runtime(), None) is None

    def test_missing_key_falls_back(self):
        state = {}
        runtime = _make_runtime("fallback_thread")
        assert _resolve_session_id(state, runtime, "missing_key") == "fallback_thread"


# ===========================================================================
# 2. Instantiation
# ===========================================================================


class TestInstantiation:
    def test_default_mode(self):
        mw = _middleware()
        assert mw._mode == "enforce"

    def test_custom_mode(self):
        mw = _middleware(mode="monitor")
        assert mw._mode == "monitor"

    def test_import_error_without_langchain(self, monkeypatch):
        import highflame.integrations.langgraph as mod

        monkeypatch.setattr(mod, "_LANGGRAPH_AVAILABLE", False)
        with pytest.raises(ImportError, match="langchain"):
            HighflameMiddleware(_client())


# ===========================================================================
# 3. before_model — allow
# ===========================================================================


class TestBeforeModelAllow:
    @respx.mock
    async def test_sends_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "hello world"))
        await mw.before_model(state, _make_runtime())

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "hello world"
        assert sent["content_type"] == "prompt"
        assert sent["action"] == "process_prompt"

    @respx.mock
    async def test_sends_mode(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware(mode="monitor")
        state = _make_state(_make_msg("human", "hi"))
        await mw.before_model(state, _make_runtime())

        sent = json.loads(route.calls.last.request.content)
        assert sent["mode"] == "monitor"

    @respx.mock
    async def test_sends_session_id_from_runtime(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "hi"))
        await mw.before_model(state, _make_runtime("thread_99"))

        sent = json.loads(route.calls.last.request.content)
        assert sent.get("session_id") == "thread_99"

    @respx.mock
    async def test_no_human_msg_skips_guard(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("ai", "only ai"))
        await mw.before_model(state, _make_runtime())

        assert len(route.calls) == 0

    @respx.mock
    async def test_sets_current_session_id(self):
        _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "hi"))
        await mw.before_model(state, _make_runtime("sess_abc"))

        assert mw._current_session_id == "sess_abc"


# ===========================================================================
# 4. before_model — deny
# ===========================================================================


class TestBeforeModelDeny:
    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "bad input"))
        with pytest.raises(BlockedError):
            await mw.before_model(state, _make_runtime())

    @respx.mock
    async def test_error_has_response(self):
        _guard_route(respx.mock, _DENY_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "bad input"))
        with pytest.raises(BlockedError) as exc_info:
            await mw.before_model(state, _make_runtime())

        assert exc_info.value.response.decision == "deny"
        assert exc_info.value.response.policy_reason == "policy violation"


# ===========================================================================
# 5. after_model — allow
# ===========================================================================


class TestAfterModelAllow:
    @respx.mock
    async def test_sends_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("ai", "model output"))
        await mw.after_model(state, _make_runtime())

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "model output"
        assert sent["content_type"] == "response"
        assert sent["action"] == "process_prompt"

    @respx.mock
    async def test_no_ai_msg_skips_guard(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("human", "only human"))
        await mw.after_model(state, _make_runtime())

        assert len(route.calls) == 0


# ===========================================================================
# 6. after_model — deny
# ===========================================================================


class TestAfterModelDeny:
    @respx.mock
    async def test_raises_blocked_error(self):
        _guard_route(respx.mock, _DENY_BODY)
        mw = _middleware()
        state = _make_state(_make_msg("ai", "toxic output"))
        with pytest.raises(BlockedError):
            await mw.after_model(state, _make_runtime())


# ===========================================================================
# 7. wrap_tool_call — allow (two guard calls)
# ===========================================================================


class TestWrapToolCallAllow:
    @respx.mock
    async def test_two_guard_calls_and_handler_called(self):
        called = []
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            called.append(True)
            return "tool result"

        mw = _middleware()
        request = SimpleNamespace(tool_name="search", arguments={"q": "test"})
        result = await mw.wrap_tool_call(request, handler)

        assert result == "tool result"
        assert called == [True]
        assert len(route.calls) == 2

    @respx.mock
    async def test_pre_guard_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "ok"

        mw = _middleware()
        request = SimpleNamespace(tool_name="shell", arguments={"cmd": "ls"})
        await mw.wrap_tool_call(request, handler)

        pre_body = json.loads(route.calls[0].request.content)
        assert pre_body["content_type"] == "tool_call"
        assert pre_body["action"] == "call_tool"

    @respx.mock
    async def test_post_guard_correct_body(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "file contents"

        mw = _middleware()
        request = SimpleNamespace(tool_name="read_file", arguments=None)
        await mw.wrap_tool_call(request, handler)

        post_body = json.loads(route.calls[1].request.content)
        assert post_body["content"] == "file contents"
        assert post_body["content_type"] == "response"
        assert post_body["action"] == "call_tool"

    @respx.mock
    async def test_tool_name_from_name_attr(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "result"

        mw = _middleware()
        # No tool_name attr, falls back to name
        request = SimpleNamespace(name="my_tool", arguments=None)
        await mw.wrap_tool_call(request, handler)

        pre_body = json.loads(route.calls[0].request.content)
        assert "my_tool" in pre_body["content"]

    @respx.mock
    async def test_tool_name_fallback_unknown(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "result"

        mw = _middleware()
        # Neither tool_name nor name
        request = SimpleNamespace(arguments=None)
        await mw.wrap_tool_call(request, handler)

        pre_body = json.loads(route.calls[0].request.content)
        assert "unknown" in pre_body["content"]

    @respx.mock
    async def test_none_arguments(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "ok"

        mw = _middleware()
        request = SimpleNamespace(tool_name="ping", arguments=None)
        await mw.wrap_tool_call(request, handler)

        # Should not raise — None arguments are handled gracefully
        assert len(route.calls) == 2


# ===========================================================================
# 8. wrap_tool_call — pre-deny (handler NOT called)
# ===========================================================================


class TestWrapToolCallPreDeny:
    @respx.mock
    async def test_handler_not_called_on_pre_deny(self):
        _guard_route(respx.mock, _DENY_BODY)
        called = []

        async def handler(req):
            called.append(True)
            return "should not reach"

        mw = _middleware()
        request = SimpleNamespace(tool_name="dangerous", arguments={"x": 1})
        with pytest.raises(BlockedError):
            await mw.wrap_tool_call(request, handler)

        assert called == [], "handler must NOT be called when pre-guard denies"


# ===========================================================================
# 9. wrap_tool_call — post-deny (handler DID run, result blocked)
# ===========================================================================


class TestWrapToolCallPostDeny:
    @respx.mock
    async def test_handler_ran_but_result_blocked(self):
        called = []
        call_count = 0

        def side_effect(request):
            nonlocal call_count
            call_count += 1
            # Allow on first call (pre-guard), deny on second (post-guard)
            if call_count == 1:
                return httpx.Response(200, json=_ALLOW_BODY)
            return httpx.Response(200, json=_DENY_BODY)

        respx.mock.post(f"{BASE_URL}/v1/guard").mock(side_effect=side_effect)

        async def handler(req):
            called.append(True)
            return "sensitive result"

        mw = _middleware()
        request = SimpleNamespace(tool_name="fetch", arguments=None)
        with pytest.raises(BlockedError):
            await mw.wrap_tool_call(request, handler)

        assert called == [True], "handler MUST run before post-guard blocks"


# ===========================================================================
# 10. wrap_model_call — passthrough
# ===========================================================================


class TestWrapModelCall:
    @respx.mock
    async def test_no_guards_called_handler_result_returned(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)

        async def handler(req):
            return "model response"

        mw = _middleware()
        result = await mw.wrap_model_call(SimpleNamespace(), handler)

        assert result == "model response"
        assert len(route.calls) == 0, "wrap_model_call must not call any guard endpoints"


# ===========================================================================
# 11. List content — multimodal messages
# ===========================================================================


class TestListContent:
    @respx.mock
    async def test_multimodal_human_message_extracted(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()
        blocks = [
            {"type": "image_url", "url": "http://example.com/img.png"},
            {"type": "text", "text": "describe this image"},
        ]
        state = _make_state(_make_msg("human", blocks))
        await mw.before_model(state, _make_runtime())

        sent = json.loads(route.calls.last.request.content)
        assert sent["content"] == "describe this image"


# ===========================================================================
# 12. Session ID propagation
# ===========================================================================


class TestSessionIdPropagation:
    @respx.mock
    async def test_before_model_sets_session_id_used_by_wrap_tool_call(self):
        route = _guard_route(respx.mock, _ALLOW_BODY)
        mw = _middleware()

        # Step 1: before_model sets _current_session_id
        state = _make_state(_make_msg("human", "hello"))
        await mw.before_model(state, _make_runtime("session_xyz"))
        assert mw._current_session_id == "session_xyz"

        # Step 2: wrap_tool_call uses _current_session_id
        async def handler(req):
            return "tool result"

        request = SimpleNamespace(tool_name="lookup", arguments=None)
        await mw.wrap_tool_call(request, handler)

        # All three calls: before_model guard + pre-tool guard + post-tool guard
        assert len(route.calls) == 3
        pre_tool_body = json.loads(route.calls[1].request.content)
        assert pre_tool_body.get("session_id") == "session_xyz"
        post_tool_body = json.loads(route.calls[2].request.content)
        assert post_tool_body.get("session_id") == "session_xyz"
