"""Generated types from spec/shield-v1.yaml — DO NOT EDIT.

Regenerate: python codegen/generate.py --spec spec/shield-v1.yaml
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict


class _Base(BaseModel):
    model_config = ConfigDict(populate_by_name=True)


# =============================================================================
# Enums
# =============================================================================

ContentType = Literal["prompt", "response", "tool_call", "file"]
"""Type of content being evaluated."""

Decision = Literal["allow", "deny"]
"""Guard evaluation decision."""

Mode = Literal["enforce", "monitor", "alert"]
"""enforce: block on deny. monitor: allow + log. alert: allow + signal."""


# =============================================================================
# Models
# =============================================================================


class AgentIdentityTrace(_Base):
    """Authenticated agent identity from token claims."""

    # Agent identifier.
    agent_id: str
    # Type of agent (e.g. claude, cursor, custom).
    agent_type: str
    # Trust level (verified, unverified, etc.).
    trust_level: str
    # Agent framework (e.g. Python SDK, Node SDK).
    framework: str = ""
    # Publisher/organization.
    publisher: str = ""
    # Authentication method: api_key or jwt.
    auth_method: str


class ContextKeySpec(_Base):
    """Specification of a context key emitted by a detector."""

    # Context key name (e.g. injection_score).
    key: str
    # Cedar type: long, bool, string, or set.
    type: str
    # Human-readable description.
    description: str
    # Value range (e.g. 0-100).
    range: str = ""


class EntityDebug(_Base):
    """Entity in the Cedar evaluation context."""

    # Entity type.
    type: str
    # Entity ID.
    id: str
    # Parent entity UIDs.
    parents: list[str] = []


class TenantDebug(_Base):
    """Resolved tenant identity."""

    account_id: str
    project_id: str
    application_id: str


class DebugInfo(_Base):
    """Cedar evaluation debug info (when debug=true)."""

    # Product namespace.
    product: str
    # Cedar namespace (e.g. Guardrails).
    namespace: str
    # Principal entity type.
    principal_type: str
    # Principal entity ID.
    principal_id: str
    # Cedar action.
    action: str
    # Resource entity type.
    resource_type: str
    # Resource entity ID.
    resource_id: str
    # Entity hierarchy.
    entities: list[EntityDebug]
    # Number of loaded policies.
    loaded_policy_count: int
    tenant: TenantDebug


class PolicySummary(_Base):
    """Summary of a loaded Cedar policy."""

    # Database UUID.
    policy_id: str
    # Human-readable name.
    policy_name: str
    # Policy mode: enforce, monitor, or alert.
    mode: str
    # Policy domain category.
    category: str = ""
    # Cedar @id annotations from this policy.
    rule_ids: list[str]


class DebugPoliciesResponse(_Base):
    """Response from GET /v1/debug/policies."""

    # Product namespace inspected.
    product: str
    # Whether the evaluator has loaded policies.
    has_policies: bool
    # Number of distinct DB policies loaded.
    policy_count: int
    # Loaded policies with metadata.
    policies: list[PolicySummary]


class FileContext(_Base):
    """File operation context."""

    # File path.
    path: str
    # File operation: read, write, delete, append, etc.
    operation: str
    # File size in bytes.
    size: int = 0
    # File MIME type.
    mime_type: str = ""


class MCPContext(_Base):
    """MCP server interaction context."""

    # MCP server name.
    server_name: str
    # MCP server URL.
    server_url: str = ""
    # Transport protocol: sse, stdio, http.
    transport: str = ""
    # Whether the server passed trust/signature verification.
    verified: bool = False
    # Advertised MCP capabilities from server manifest.
    capabilities: list[str] = []


class ModelContext(_Base):
    """LLM model context (provider, temperature, token usage)."""

    # LLM provider (e.g. openai, anthropic).
    provider: str = ""
    # Model name (e.g. gpt-4, claude-3).
    model: str = ""
    # Temperature setting.
    temperature: float = 0.0
    # Tokens consumed so far in the session.
    tokens_used: int = 0
    # Max token limit for the session.
    max_tokens: int = 0


class ToolContext(_Base):
    """Tool call context for agentic evaluation."""

    # Tool name.
    name: str
    # Whether the tool is built-in to the LLM or externally registered.
    is_builtin: bool
    # Tool arguments as a JSON object.
    arguments: dict[str, Any] = {}
    # MCP server ID (for externally-registered tools).
    server_id: str = ""
    # Tool description from MCP manifest, for tool-poisoning analysis.
    description: str = ""


class DetectRequest(_Base):
    """Request body for POST /v1/detect. Detection only, no policy evaluation."""

    # Content to analyze.
    content: str
    content_type: ContentType
    # Specific detectors to run. Empty runs all enabled detectors.
    detectors: list[str] = []
    # Caller-provided metadata passed through to detectors.
    metadata: dict[str, Any] = {}
    # Reference material for context-aware detection.
    contexts: list[str] = []
    # Session ID for cross-turn state tracking.
    session_id: str = ""
    tool: ToolContext | None = None
    model: ModelContext | None = None
    file: FileContext | None = None
    mcp: MCPContext | None = None


class DetectorResult(_Base):
    """Result from a single detector execution."""

    # Detector name (e.g. injection, secrets, toxicity).
    name: str
    # Detector tier: fast, standard, or slow.
    tier: str
    # Detector execution latency in milliseconds.
    latency_ms: int
    # Emitted context attributes (e.g. injection_score, contains_secrets).
    context: dict[str, Any]
    # Detector status: healthy, degraded, error, or timeout.
    status: str
    # Error message (when status is error or timeout).
    error: str = ""


class DetectResponse(_Base):
    """Response from POST /v1/detect."""

    # Per-detector results.
    detectors: list[DetectorResult]
    # Merged context from all detectors.
    context: dict[str, Any]
    # Total detection latency in milliseconds.
    latency_ms: int
    # Detector tiers that ran.
    tiers_evaluated: list[str]


class DetectorInfo(_Base):
    """Metadata about an available detector."""

    # Detector name.
    name: str
    # Detector version.
    version: str
    # Detector tier: fast, standard, or slow.
    tier: str
    # Keys this detector may emit.
    context_keys: list[ContextKeySpec]
    # Detector status: healthy, degraded, or disabled.
    status: str
    # Human-readable display name.
    display_name: str = ""
    # What the detector detects.
    description: str = ""
    # Detection category (e.g. Security, Content Safety).
    category: str = ""
    # Whether the detector accepts configuration.
    configurable: bool = False
    # Configuration schema type (if configurable).
    config_type: str = ""
    # Tags for filtering.
    tags: list[str] = []
    # Typical latency estimate.
    latency: str = ""


class DetectorPlanEntry(_Base):
    """Entry in the detector optimization plan."""

    # Detector name.
    name: str
    # Detector tier.
    tier: str
    # Why included/excluded: policy_required, always_run, not_required.
    reason: str
    # Full scoped config (dry run only).
    config: dict[str, Any] = {}


class DeterminingPolicy(_Base):
    """A Cedar policy that contributed to the guard decision."""

    # Cedar @id annotation (e.g. secrets-block-prompts).
    rule_id: str
    # Database UUID (for dashboard linking).
    policy_id: str = ""
    # Human-readable policy name.
    policy_name: str = ""
    # Cedar effect: permit or forbid.
    effect: str = ""
    # Policy mode: enforce, monitor, or alert.
    mode: str = ""
    # Policy domain (e.g. secrets, pii, injection).
    category: str = ""
    # From Cedar @severity annotation.
    severity: str = ""
    # From Cedar @tags annotation.
    tags: list[str] = []
    # Custom Cedar annotations.
    annotations: dict[str, str] = {}


class GuardRequest(_Base):
    """Request body for POST /v1/guard."""

    # Content to evaluate (prompt text, tool call arguments, file content, etc.).
    content: str
    content_type: ContentType
    # Cedar action (e.g. process_prompt, call_tool, read_file, write_file).
    action: str
    # Specific detectors to run. Empty runs all enabled detectors.
    detectors: list[str] = []
    mode: Mode | None = None
    # Enable early exit on deny after each tier (skips slower tiers).
    early_exit: bool = False
    # Include structured policy explanation showing why each determining policy matched.
    explain: bool = False
    # Caller-provided metadata passed through to detectors.
    metadata: dict[str, Any] = {}
    # Reference material for context-aware detection (hallucination, groundedness).
    contexts: list[str] = []
    # Session ID for cross-turn state tracking.
    session_id: str = ""
    tool: ToolContext | None = None
    model: ModelContext | None = None
    file: FileContext | None = None
    mcp: MCPContext | None = None
    # When true, only run detectors whose outputs are referenced by active policies.
    optimize: bool = False
    # When true and optimize is true, return the optimization plan without executing.
    dry_run: bool = False
    # Include debug_info showing exact Cedar evaluation inputs.
    debug: bool = False


class OptimizationReport(_Base):
    """Detector optimization plan (when optimize=true)."""

    # Context keys required by active policies.
    required_context_keys: list[str]
    # Detectors required by policies.
    required_detectors: list[DetectorPlanEntry]
    # Detectors skipped (not required by policies).
    skipped_detectors: list[DetectorPlanEntry]
    # Policies matching this action/product scope.
    active_policies: list[str]
    # Why this optimization plan was chosen.
    reason: str
    # True if fell back to running all detectors.
    fallback_to_all: bool


class RootCause(_Base):
    """Root cause analysis for a triggered detection."""

    # Human-readable summary of the root cause.
    summary: str
    # Detector that triggered.
    detector: str
    # Key-value pairs explaining the threat.
    labels: dict[str, str] = {}
    # Context values that caused the trigger.
    triggering_context: dict[str, Any]
    # Supporting evidence.
    evidence: dict[str, Any] = {}
    # Policy IDs triggered by this root cause.
    triggered_policies: list[str]


class SessionDelta(_Base):
    """Session state changes after evaluation."""

    # Updated turn count.
    turn_count: int
    # Updated cumulative risk score (0-100).
    cumulative_risk: float
    # Tokens used in this turn.
    tokens_used_delta: int = 0
    # Action performed in this turn.
    new_action: str = ""


class GuardResponse(_Base):
    """Response from POST /v1/guard."""

    decision: Decision
    # Cedar decision before mode override.
    actual_decision: str = ""
    # True if decision was changed by per-policy mode.
    mode_overridden: bool = False
    # Strictest mode among determining policies.
    effective_mode: str = ""
    # True when alert-mode policy fired.
    alerted: bool = False
    # Human-readable policy decision reasoning.
    policy_reason: str = ""
    # Mode override explanation (monitor/alert).
    mode_reason: str = ""
    # Cedar diagnostic errors (rare).
    eval_errors: str = ""
    # Unique audit trail ID.
    audit_id: str = ""
    # Request trace ID.
    request_id: str = ""
    # Response timestamp (RFC 3339).
    timestamp: str
    # Policies that determined the decision.
    determining_policies: list[DeterminingPolicy] = []
    # Per-detector results.
    detectors: list[DetectorResult]
    # Merged detector context.
    context: dict[str, Any]
    # Total evaluation latency in milliseconds.
    latency_ms: int
    # Cedar evaluation latency in milliseconds.
    eval_latency_ms: int = 0
    # Detector tiers that ran (fast, standard, slow).
    tiers_evaluated: list[str]
    # Detector tiers skipped due to early exit.
    tiers_skipped: list[str] = []
    session_delta: SessionDelta | None = None
    agent_identity: AgentIdentityTrace | None = None
    # Structured policy explanation (when explain=true).
    explanation: dict[str, Any] = {}
    # Root cause analysis for triggered detections.
    root_causes: list[RootCause] = []
    # Cedar-normalized context (when debug=true).
    projected_context: dict[str, Any] = {}
    optimization: OptimizationReport | None = None
    debug_info: DebugInfo | None = None

    @property
    def allowed(self) -> bool:
        """True if the guard decision is 'allow'."""
        return self.decision == "allow"

    @property
    def denied(self) -> bool:
        """True if the guard decision is 'deny'."""
        return self.decision == "deny"


class HealthResponse(_Base):
    """Response from GET /v1/health."""

    # Overall health status.
    status: Literal["healthy", "degraded"]
    # Per-detector health status.
    detectors: dict[str, str] = {}
    # Cedar evaluator status.
    evaluator: Literal["ready", "no_policies"] = ""


class ListDetectorsResponse(_Base):
    """Response from GET /v1/detectors."""

    # Available detectors.
    detectors: list[DetectorInfo]
    # Total number of registered detectors.
    count: int


class ProblemDetails(_Base):
    """RFC 9457 Problem Details error format."""

    # HTTP status code.
    status: int
    # Short error title.
    title: str
    # Detailed error message.
    detail: str = ""


class StreamEvent(_Base):
    """A Server-Sent Event from the guard stream."""

    # Event type: detector_result (per-detector), decision (final), or error.
    type: Literal["detector_result", "decision", "error"]
    # Event payload (DetectorResult for detector_result, GuardResponse for decision).
    data: dict[str, Any]


class TokenResponse(_Base):
    """Response from the token exchange endpoint (used by SDK auth)."""

    # RS256 JWT token.
    access_token: str
    # Token type (always Bearer).
    token_type: str = ""
    # Token lifetime in seconds.
    expires_in: int
    # Account ID from token claims.
    account_id: str = ""
    # Gateway ID from token claims.
    gateway_id: str = ""
    # Project ID from token claims.
    project_id: str = ""
