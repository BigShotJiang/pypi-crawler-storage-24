"""Token exchange for service key → JWT authentication."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from dataclasses import dataclass

import httpx

from ._types_gen import TokenResponse
from .errors import APIConnectionError, APIError, AuthenticationError

logger = logging.getLogger("highflame")

_TOKEN_REFRESH_BUFFER = 60  # Refresh this many seconds before expiry.


@dataclass
class CachedToken:
    access_token: str
    expires_at: float  # time.time() + expires_in - buffer
    account_id: str
    project_id: str
    gateway_id: str


def _raise_for_problem(response: httpx.Response) -> None:
    """Parse RFC 9457 Problem Details and raise APIError."""
    if response.is_success:
        return
    try:
        body = response.json()
        title = body.get("title", response.reason_phrase or "Error")
        detail = body.get("detail", "")
    except Exception:
        title = response.reason_phrase or "Error"
        detail = response.text

    if response.status_code == 401:
        raise AuthenticationError(detail)
    raise APIError(status=response.status_code, title=title, detail=detail)


class TokenManager:
    """Thread-safe and async-safe token cache with automatic refresh."""

    def __init__(self, api_key: str, token_url: str, timeout: float) -> None:
        self._api_key = api_key
        self._token_url = token_url
        self._timeout = timeout
        self._cached: CachedToken | None = None
        self._lock = threading.Lock()
        self._async_lock: asyncio.Lock | None = None
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    @property
    def _http_sync(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client()
        return self._sync_client

    @property
    def _http_async(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient()
        return self._async_client

    def _exchange(self) -> CachedToken:
        """Exchange service key for JWT (sync)."""
        logger.debug("Exchanging service key for JWT at %s", self._token_url)
        try:
            resp = self._http_sync.post(
                self._token_url,
                json={"grant_type": "api_key", "api_key": self._api_key},
                timeout=self._timeout,
            )
        except httpx.TimeoutException as exc:
            raise APIConnectionError(f"Token exchange timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise APIConnectionError(f"Token exchange failed: {exc}") from exc
        _raise_for_problem(resp)
        tok = TokenResponse.model_validate(resp.json())
        cached = CachedToken(
            access_token=tok.access_token,
            expires_at=time.time() + tok.expires_in - _TOKEN_REFRESH_BUFFER,
            account_id=tok.account_id,
            project_id=tok.project_id,
            gateway_id=tok.gateway_id,
        )
        logger.debug(
            "Token exchanged, account=%s project=%s expires_in=%ds",
            cached.account_id,
            cached.project_id,
            tok.expires_in,
        )
        return cached

    async def _aexchange(self) -> CachedToken:
        """Exchange service key for JWT (async)."""
        logger.debug("Exchanging service key for JWT (async) at %s", self._token_url)
        try:
            resp = await self._http_async.post(
                self._token_url,
                json={"grant_type": "api_key", "api_key": self._api_key},
                timeout=self._timeout,
            )
        except httpx.TimeoutException as exc:
            raise APIConnectionError(f"Token exchange timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise APIConnectionError(f"Token exchange failed: {exc}") from exc
        _raise_for_problem(resp)
        tok = TokenResponse.model_validate(resp.json())
        cached = CachedToken(
            access_token=tok.access_token,
            expires_at=time.time() + tok.expires_in - _TOKEN_REFRESH_BUFFER,
            account_id=tok.account_id,
            project_id=tok.project_id,
            gateway_id=tok.gateway_id,
        )
        logger.debug(
            "Token exchanged (async), account=%s project=%s expires_in=%ds",
            cached.account_id,
            cached.project_id,
            tok.expires_in,
        )
        return cached

    def get_token(self) -> CachedToken:
        """Return a valid token, refreshing if needed (sync, thread-safe)."""
        with self._lock:
            if self._cached is None or time.time() >= self._cached.expires_at:
                self._cached = self._exchange()
            return self._cached

    async def aget_token(self) -> CachedToken:
        """Return a valid token, refreshing if needed (async, coroutine-safe)."""
        with self._lock:
            if self._cached is not None and time.time() < self._cached.expires_at:
                return self._cached
            if self._async_lock is None:
                self._async_lock = asyncio.Lock()

        async with self._async_lock:
            with self._lock:
                if self._cached is not None and time.time() < self._cached.expires_at:
                    return self._cached

            new_token = await self._aexchange()

            with self._lock:
                self._cached = new_token
                return self._cached

    def close(self) -> None:
        if self._sync_client:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client:
            await self._async_client.aclose()
