"""
Highflame Python SDK.

Quick start::

    from highflame import Highflame

    client = Highflame(api_key="hf_sk_...")
    resp = client.guard.evaluate_prompt("Hello world")
    print(resp.decision)  # "allow" or "deny"
"""

from importlib.metadata import version as _pkg_version

from ._types_gen import (
    AgentIdentityTrace,
    # Enums
    ContentType,
    ContextKeySpec,
    DebugInfo,
    DebugPoliciesResponse,
    Decision,
    # Info types
    DetectorInfo,
    DetectorResult,
    DetectRequest,
    DetectResponse,
    DeterminingPolicy,
    FileContext,
    # Request types
    GuardRequest,
    # Response types
    GuardResponse,
    HealthResponse,
    ListDetectorsResponse,
    MCPContext,
    Mode,
    ModelContext,
    OptimizationReport,
    PolicySummary,
    ProblemDetails,
    RootCause,
    SessionDelta,
    StreamEvent,
    TokenResponse,
    ToolContext,
)
from .client import Highflame
from .errors import (
    APIConnectionError,
    APIError,
    AuthenticationError,
    BlockedError,
    HighflameError,
    RateLimitError,
)
from .shield import Shield

try:
    __version__ = _pkg_version("highflame")
except Exception:
    __version__ = "0.0.0"

__all__ = [
    # Version
    "__version__",
    # Client
    "Highflame",
    # Decorator facade
    "Shield",
    # Errors
    "HighflameError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    "APIConnectionError",
    "BlockedError",
    # Enums
    "ContentType",
    "Decision",
    "Mode",
    # Request types
    "GuardRequest",
    "DetectRequest",
    "ToolContext",
    "ModelContext",
    "FileContext",
    "MCPContext",
    # Response types
    "GuardResponse",
    "DetectResponse",
    "DetectorResult",
    "DeterminingPolicy",
    "SessionDelta",
    "AgentIdentityTrace",
    "RootCause",
    "OptimizationReport",
    "DebugInfo",
    "StreamEvent",
    # Info types
    "DetectorInfo",
    "ContextKeySpec",
    "ListDetectorsResponse",
    "HealthResponse",
    "DebugPoliciesResponse",
    "PolicySummary",
    "TokenResponse",
    "ProblemDetails",
]
