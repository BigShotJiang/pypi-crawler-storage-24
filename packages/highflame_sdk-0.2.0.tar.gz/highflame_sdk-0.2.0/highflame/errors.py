"""Error hierarchy for the Highflame SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._types_gen import GuardResponse


class HighflameError(Exception):
    """Base class for all SDK errors."""


class APIError(HighflameError):
    """HTTP error from the API (RFC 9457 Problem Details)."""

    def __init__(self, status: int, title: str, detail: str) -> None:
        self.status = status
        self.title = title
        self.detail = detail
        super().__init__(f"[{status}] {title}: {detail}")


class AuthenticationError(APIError):
    """401 Unauthorized — invalid or expired credentials."""

    def __init__(self, detail: str = "Invalid or expired credentials") -> None:
        super().__init__(status=401, title="Unauthorized", detail=detail)


class RateLimitError(APIError):
    """429 Too Many Requests — rate limit exceeded."""

    def __init__(self, detail: str = "Rate limit exceeded") -> None:
        super().__init__(status=429, title="Too Many Requests", detail=detail)


class APIConnectionError(HighflameError):
    """Connection or timeout failure communicating with the API."""


class BlockedError(HighflameError):
    """Raised by Shield decorators when the guard decision is 'deny'."""

    def __init__(self, response: GuardResponse) -> None:
        self.response = response
        super().__init__(f"Blocked by guard: {response.policy_reason or response.decision}")
