"""Highflame SDK client with resource-based API.

Usage::

    from highflame import Highflame

    client = Highflame(api_key="hf_sk_...")

    # Guard
    resp = client.guard.evaluate_prompt("Hello world")
    resp = client.guard.evaluate_tool_call("shell", {"cmd": "ls"})

    # Detect (no policy evaluation)
    resp = client.detect.run(content="...", content_type="prompt")

    # Detectors
    detectors = client.detectors.list()

    # Debug
    policies = client.debug.policies()

    # Streaming
    for event in client.guard.stream(request):
        print(event.type, event.data)
"""

from __future__ import annotations

from typing import Any

import httpx

from ._http import HTTPTransport
from .resources import DebugResource, DetectorsResource, DetectResource, GuardResource

_SAAS_BASE_URL = "https://shield.api.highflame.ai"
_SAAS_TOKEN_URL = "https://studio.api.highflame.ai/api/cli-auth/token"


class Highflame:
    """Highflame SDK client.

    Supports both sync and async usage. For sync, call methods directly.
    For async, use the ``a``-prefixed variants on each resource::

        # Sync
        resp = client.guard.evaluate_prompt("hello")

        # Async
        resp = await client.guard.aevaluate_prompt("hello")

    Service Key Flow
    ~~~~~~~~~~~~~~~~
    Keys that start with ``hf_sk`` are automatically exchanged for a
    short-lived RS256 JWT. The JWT is cached and auto-refreshed.

    Direct JWT Flow
    ~~~~~~~~~~~~~~~
    Any other ``api_key`` value is sent as ``Authorization: Bearer <api_key>``.

    Custom Headers
    ~~~~~~~~~~~~~~
    Pass ``default_headers`` to inject extra headers into every request.
    Useful for custom routing or identity headers::

        client = Highflame(
            api_key="hf_sk_...",
            default_headers={"X-Custom-Routing": "my-service"},
        )
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _SAAS_BASE_URL,
        token_url: str = _SAAS_TOKEN_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
        account_id: str | None = None,
        project_id: str | None = None,
        default_headers: dict[str, str] | None = None,
        httpx_client: httpx.Client | None = None,
        async_httpx_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_url = base_url
        self._transport = HTTPTransport(
            base_url=base_url,
            api_key=api_key,
            token_url=token_url,
            timeout=timeout,
            max_retries=max_retries,
            account_id=account_id,
            project_id=project_id,
            default_headers=default_headers,
            httpx_client=httpx_client,
            async_httpx_client=async_httpx_client,
        )
        self._guard = GuardResource(self._transport)
        self._detect = DetectResource(self._transport)
        self._detectors = DetectorsResource(self._transport)
        self._debug = DebugResource(self._transport)

    @property
    def guard(self) -> GuardResource:
        """Guard resource: evaluate content against policies."""
        return self._guard

    @property
    def detect(self) -> DetectResource:
        """Detect resource: run detectors without policy evaluation."""
        return self._detect

    @property
    def detectors(self) -> DetectorsResource:
        """Detectors resource: list available detectors."""
        return self._detectors

    @property
    def debug(self) -> DebugResource:
        """Debug resource: inspect loaded policies."""
        return self._debug

    # ------------------------------------------------------------------
    # Context managers
    # ------------------------------------------------------------------

    def __enter__(self) -> Highflame:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    async def __aenter__(self) -> Highflame:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    def close(self) -> None:
        """Close underlying HTTP clients."""
        self._transport.close()

    async def aclose(self) -> None:
        """Async: close underlying HTTP clients."""
        await self._transport.aclose()

    def __repr__(self) -> str:
        return f"Highflame(base_url={self._base_url!r})"
