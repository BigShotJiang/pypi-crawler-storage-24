"""Shield facade — decorator-based guardrails for functions and coroutines.

Usage::

    from highflame import Highflame, Shield, BlockedError

    client = Highflame(api_key="hf_sk_xxx")
    shield = Shield(client)

    @shield.prompt
    def chat(message: str) -> str:
        return llm.complete(message)

    @shield.tool
    async def run_shell(cmd: str) -> str:
        ...
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable

from ._types_gen import GuardRequest, GuardResponse, Mode, ToolContext
from .client import Highflame
from .errors import BlockedError


def _first_str_param(fn: Callable[..., Any]) -> str:
    """Return the name of the first str-annotated (or unannotated) parameter."""
    sig = inspect.signature(fn)
    for name, param in sig.parameters.items():
        if param.annotation in (str, "str", inspect.Parameter.empty):
            return name
    raise TypeError(
        f"shield: {fn.__name__} has no str parameter to guard. "
        "Use content_arg= to specify one explicitly."
    )


def _extract_content(
    fn: Callable[..., Any], arg_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]
) -> str:
    """Bind call args and return the named str argument."""
    bound = inspect.signature(fn).bind(*args, **kwargs)
    bound.apply_defaults()
    val = bound.arguments.get(arg_name)
    if not isinstance(val, str):
        raise TypeError(f"shield: '{arg_name}' must be str, got {type(val).__name__}")
    return val


def _bind_all_args(
    fn: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]
) -> dict[str, Any]:
    """Return all bound arguments as a dict (for ToolContext.arguments)."""
    bound = inspect.signature(fn).bind(*args, **kwargs)
    bound.apply_defaults()
    return dict(bound.arguments)


def _raise_if_blocked(response: GuardResponse) -> None:
    if response.denied:
        raise BlockedError(response)


class Shield:
    """Decorator facade over :class:`Highflame`.

    Attach guard checks to functions::

        shield = Shield(client)

        @shield.prompt
        def chat(msg: str) -> str: ...

        @shield.tool
        def shell(cmd: str) -> str: ...

        @shield.toolresponse
        def fetch(url: str) -> str: ...

        @shield.modelresponse
        def generate(prompt: str) -> str: ...

        @shield(content_type="file", action="write_file", content_arg="content")
        def write(path: str, content: str) -> None: ...
    """

    def __init__(self, client: Highflame) -> None:
        self._client = client

    def prompt(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        content_arg: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a prompt input before the function runs."""

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            arg_name = content_arg or _first_str_param(f)

            if inspect.iscoroutinefunction(f):

                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    content = _extract_content(f, arg_name, args, kwargs)
                    _raise_if_blocked(
                        await self._client.guard.aevaluate_prompt(
                            content, mode=mode, session_id=session_id
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                content = _extract_content(f, arg_name, args, kwargs)
                _raise_if_blocked(
                    self._client.guard.evaluate_prompt(content, mode=mode, session_id=session_id)
                )
                return f(*args, **kwargs)

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    def tool(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        tool_name: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a tool call before the function runs."""

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            name = tool_name or f.__name__

            if inspect.iscoroutinefunction(f):

                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    bound_args = _bind_all_args(f, args, kwargs)
                    _raise_if_blocked(
                        await self._client.guard.aevaluate_tool_call(
                            name, arguments=bound_args, mode=mode, session_id=session_id
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                bound_args = _bind_all_args(f, args, kwargs)
                _raise_if_blocked(
                    self._client.guard.evaluate_tool_call(
                        name, arguments=bound_args, mode=mode, session_id=session_id
                    )
                )
                return f(*args, **kwargs)

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    def toolresponse(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        tool_name: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a tool's return value after the function runs."""

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            name = tool_name or f.__name__

            if inspect.iscoroutinefunction(f):

                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    result = await f(*args, **kwargs)
                    _raise_if_blocked(
                        await self._client.guard.aevaluate(
                            GuardRequest(
                                content=result if isinstance(result, str) else str(result),
                                content_type="response",
                                action="call_tool",
                                mode=mode,
                                session_id=session_id or "",
                                tool=ToolContext(name=name, is_builtin=False),
                            )
                        )
                    )
                    return result

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = f(*args, **kwargs)
                _raise_if_blocked(
                    self._client.guard.evaluate(
                        GuardRequest(
                            content=result if isinstance(result, str) else str(result),
                            content_type="response",
                            action="call_tool",
                            mode=mode,
                            session_id=session_id or "",
                            tool=ToolContext(name=name, is_builtin=False),
                        )
                    )
                )
                return result

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    def modelresponse(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
    ) -> Any:
        """Guard a model response before returning to the caller."""

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            if inspect.iscoroutinefunction(f):

                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    result = await f(*args, **kwargs)
                    _raise_if_blocked(
                        await self._client.guard.aevaluate(
                            GuardRequest(
                                content=result if isinstance(result, str) else str(result),
                                content_type="response",
                                action="process_prompt",
                                mode=mode,
                                session_id=session_id or "",
                            )
                        )
                    )
                    return result

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = f(*args, **kwargs)
                _raise_if_blocked(
                    self._client.guard.evaluate(
                        GuardRequest(
                            content=result if isinstance(result, str) else str(result),
                            content_type="response",
                            action="process_prompt",
                            mode=mode,
                            session_id=session_id or "",
                        )
                    )
                )
                return result

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    def __call__(
        self,
        fn: None = None,
        *,
        content_type: str,
        action: str,
        content_arg: str | None = None,
        mode: Mode = "enforce",
        session_id: str | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Generic decorator with fully configurable content type and action."""
        if fn is not None:
            raise TypeError(
                "shield() requires keyword arguments: "
                "@shield(content_type=..., action=...) not @shield"
            )

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            arg_name = content_arg or _first_str_param(f)

            if inspect.iscoroutinefunction(f):

                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    content = _extract_content(f, arg_name, args, kwargs)
                    _raise_if_blocked(
                        await self._client.guard.aevaluate(
                            GuardRequest(
                                content=content,
                                content_type=content_type,  # type: ignore[arg-type]
                                action=action,
                                mode=mode,
                                session_id=session_id or "",
                            )
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                content = _extract_content(f, arg_name, args, kwargs)
                _raise_if_blocked(
                    self._client.guard.evaluate(
                        GuardRequest(
                            content=content,
                            content_type=content_type,  # type: ignore[arg-type]
                            action=action,
                            mode=mode,
                            session_id=session_id or "",
                        )
                    )
                )
                return f(*args, **kwargs)

            return sync_wrapper

        return decorator
