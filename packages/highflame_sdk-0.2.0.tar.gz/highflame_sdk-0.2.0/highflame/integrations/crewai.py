"""CrewAI execution-hooks integration for highflame.

Usage::

    from highflame.integrations.crewai import HighflameCrewHooks

    hooks = HighflameCrewHooks(client, mode="enforce")
    hooks.register()

    # or as a context manager:
    with HighflameCrewHooks(client) as hooks:
        crew.kickoff()
"""

from __future__ import annotations

from typing import Any

try:
    from crewai.hooks import (
        register_after_llm_call_hook,
        register_after_tool_call_hook,
        register_before_llm_call_hook,
        register_before_tool_call_hook,
        unregister_after_llm_call_hook,
        unregister_after_tool_call_hook,
        unregister_before_llm_call_hook,
        unregister_before_tool_call_hook,
    )

    _CREWAI_AVAILABLE = True
except ImportError:
    _CREWAI_AVAILABLE = False

    def register_before_llm_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def register_after_llm_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def register_before_tool_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def register_after_tool_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def unregister_before_llm_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def unregister_after_llm_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def unregister_before_tool_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass

    def unregister_after_tool_call_hook(fn: Any) -> None:  # type: ignore[misc]
        pass


from .._types_gen import GuardRequest, Mode
from ..client import Highflame
from ..shield import _raise_if_blocked


def _extract_last_user_message(messages: list) -> str | None:
    """Return the content of the last user/human message in an OpenAI-style message list.

    Supports both dict messages (``{"role": "user", "content": "..."}``) and
    objects with ``role``/``content`` attributes.
    """
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
        else:
            role = getattr(msg, "role", "") or ""
        if role in ("user", "human"):
            if isinstance(msg, dict):
                return msg.get("content")
            return getattr(msg, "content", None)
    return None


def _resolve_session_id(context: Any, static_id: str | None) -> str | None:
    """Resolve a session ID from static config or the crew context.

    Priority: ``static_id`` → ``str(context.crew.id)`` → ``None``.
    """
    if static_id is not None:
        return static_id
    try:
        crew_id = context.crew.id
        if crew_id is not None:
            return str(crew_id)
    except AttributeError:
        pass
    return None


class HighflameCrewHooks:
    """CrewAI execution-hooks integration that routes guardrail checks through Highflame.

    Registers four synchronous hooks with the CrewAI hooks registry:

    - ``before_llm_call``  — guards the last user message before the LLM is called
    - ``after_llm_call``   — guards the LLM response after it is produced
    - ``before_tool_call`` — guards a tool call before it executes
    - ``after_tool_call``  — guards a tool result after the tool returns

    On deny, each hook raises :class:`~highflame.errors.BlockedError`.

    Can be used as a context manager::

        with HighflameCrewHooks(client, mode="enforce") as hooks:
            crew.kickoff()
    """

    def __init__(
        self,
        client: Highflame,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
    ) -> None:
        if not _CREWAI_AVAILABLE:
            raise ImportError(
                "crewai is required for HighflameCrewHooks. "
                "Install it with: pip install 'highflame[crewai]'"
            )
        self._client = client
        self._mode = mode
        self._session_id = session_id

    # ------------------------------------------------------------------
    # Hook implementations
    # ------------------------------------------------------------------

    def _before_llm_call(self, context: Any) -> None:
        """Guard the last user message before the LLM is called."""
        messages = getattr(context, "messages", None) or []
        text = _extract_last_user_message(messages)
        if not text:
            return
        session_id = _resolve_session_id(context, self._session_id)
        _raise_if_blocked(
            self._client.guard.evaluate_prompt(text, mode=self._mode, session_id=session_id)
        )

    def _after_llm_call(self, context: Any) -> None:
        """Guard the LLM response after it is produced."""
        response = getattr(context, "response", None)
        if not response:
            return
        session_id = _resolve_session_id(context, self._session_id)
        _raise_if_blocked(
            self._client.guard.evaluate(
                GuardRequest(
                    content=response,
                    content_type="response",
                    action="process_prompt",
                    mode=self._mode,
                    session_id=session_id or "",
                )
            )
        )

    def _before_tool_call(self, context: Any) -> None:
        """Guard a tool call before it executes."""
        tool_name = getattr(context, "tool_name", None) or "unknown"
        tool_input = getattr(context, "tool_input", None)
        session_id = _resolve_session_id(context, self._session_id)
        _raise_if_blocked(
            self._client.guard.evaluate_tool_call(
                tool_name,
                tool_input if isinstance(tool_input, dict) else None,
                mode=self._mode,
                session_id=session_id,
            )
        )

    def _after_tool_call(self, context: Any) -> None:
        """Guard a tool result after the tool returns."""
        tool_result = getattr(context, "tool_result", None)
        if not tool_result:
            return
        session_id = _resolve_session_id(context, self._session_id)
        _raise_if_blocked(
            self._client.guard.evaluate(
                GuardRequest(
                    content=tool_result,
                    content_type="response",
                    action="call_tool",
                    mode=self._mode,
                    session_id=session_id or "",
                )
            )
        )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self) -> None:
        """Register all four hooks with the CrewAI hooks registry."""
        register_before_llm_call_hook(self._before_llm_call)
        register_after_llm_call_hook(self._after_llm_call)
        register_before_tool_call_hook(self._before_tool_call)
        register_after_tool_call_hook(self._after_tool_call)

    def unregister(self) -> None:
        """Unregister all four hooks from the CrewAI hooks registry."""
        unregister_before_llm_call_hook(self._before_llm_call)
        unregister_after_llm_call_hook(self._after_llm_call)
        unregister_before_tool_call_hook(self._before_tool_call)
        unregister_after_tool_call_hook(self._after_tool_call)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> HighflameCrewHooks:
        self.register()
        return self

    def __exit__(self, *args: Any) -> None:
        self.unregister()
