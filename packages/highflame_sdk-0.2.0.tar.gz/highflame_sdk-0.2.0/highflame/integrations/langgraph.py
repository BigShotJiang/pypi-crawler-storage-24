"""LangGraph AgentMiddleware integration for highflame.

Usage::

    from highflame.integrations.langgraph import HighflameMiddleware

    middleware = HighflameMiddleware(client, mode="enforce")
"""

from __future__ import annotations

from typing import Any

try:
    from langchain.agents.middleware import AgentMiddleware, AgentState

    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _LANGGRAPH_AVAILABLE = False
    AgentMiddleware = object  # type: ignore[assignment,misc]
    AgentState = dict  # type: ignore[assignment]

from .._types_gen import GuardRequest, Mode
from ..client import Highflame
from ..shield import _raise_if_blocked


def _extract_text_from_content(content: str | list) -> str:
    """Extract text from plain str or list-of-content-block (multimodal) format."""
    if isinstance(content, str):
        return content
    parts = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
        elif getattr(block, "type", None) == "text":
            parts.append(getattr(block, "text", ""))
    return "\n".join(parts)


def _resolve_session_id(state: Any, runtime: Any, key: str | None) -> str | None:
    """Resolve session ID: state[key] → LangGraph config thread_id → runtime.thread_id → None."""
    if key is not None:
        try:
            val = state.get(key) if hasattr(state, "get") else state[key]
            if val:
                return str(val)
        except (KeyError, TypeError):
            pass
    # Try LangGraph context variable (set during agent.ainvoke via config).
    # langchain_core >= 0.3 exposes var_child_runnable_config directly.
    try:
        from langchain_core.runnables.config import (
            var_child_runnable_config,  # type: ignore[import]
        )

        cfg = var_child_runnable_config.get()
        if cfg is not None:
            thread_id = cfg.get("configurable", {}).get("thread_id")
            if thread_id:
                return str(thread_id)
    except (ImportError, AttributeError, KeyError):
        pass
    # Fallback: runtime attribute (backward compat / testing)
    thread_id = getattr(runtime, "thread_id", None)
    if thread_id:
        return str(thread_id)
    return None


def _get_last_human_message(state: Any) -> str | None:
    """Return text of the last human message in state['messages'], or None."""
    messages = state.get("messages", []) if hasattr(state, "get") else []
    for msg in reversed(messages):
        if getattr(msg, "type", None) == "human":
            return _extract_text_from_content(getattr(msg, "content", ""))
    return None


def _get_last_ai_message(state: Any) -> str | None:
    """Return text of the last AI message in state['messages'], or None."""
    messages = state.get("messages", []) if hasattr(state, "get") else []
    for msg in reversed(messages):
        if getattr(msg, "type", None) == "ai":
            return _extract_text_from_content(getattr(msg, "content", ""))
    return None


class HighflameMiddleware(AgentMiddleware):  # type: ignore[misc]
    """LangGraph AgentMiddleware that routes guardrail checks through Highflame.

    Hooks::

        before_model  — guards the last human message before the LLM is called
        after_model   — guards the last AI response after the LLM responds
        wrap_tool_call — guards tool call (pre) and its result (post)
        wrap_model_call — pass-through, no guarding

    On deny, each hook raises :class:`~highflame.errors.BlockedError`.
    """

    def __init__(
        self,
        client: Highflame,
        *,
        mode: Mode = "enforce",
        session_id_key: str | None = None,
    ) -> None:
        if not _LANGGRAPH_AVAILABLE:
            raise ImportError(
                "langchain is required for HighflameMiddleware. "
                "Install it with: pip install 'highflame[langgraph]'"
            )
        self._client = client
        self._mode = mode
        self._session_id_key = session_id_key
        self._current_session_id: str | None = None

    async def before_model(self, state: Any, runtime: Any) -> None:
        """Guard the last human message before the model is called."""
        text = _get_last_human_message(state)
        if text is None:
            return
        session_id = _resolve_session_id(state, runtime, self._session_id_key)
        self._current_session_id = session_id
        _raise_if_blocked(
            await self._client.guard.aevaluate_prompt(text, mode=self._mode, session_id=session_id)
        )

    async def after_model(self, state: Any, runtime: Any) -> None:
        """Guard the last AI message after the model responds."""
        text = _get_last_ai_message(state)
        if text is None:
            return
        session_id = _resolve_session_id(state, runtime, self._session_id_key)
        _raise_if_blocked(
            await self._client.guard.aevaluate(
                GuardRequest(
                    content=text,
                    content_type="response",
                    action="process_prompt",
                    mode=self._mode,
                    session_id=session_id or "",
                )
            )
        )

    async def wrap_tool_call(self, request: Any, handler: Any) -> Any:
        """Guard a tool call pre-execution and its result post-execution."""
        # Real LangGraph ToolCallRequest: request.tool_call = {"name": ..., "args": ...}
        tool_call_dict = getattr(request, "tool_call", None)
        if isinstance(tool_call_dict, dict):
            tool_name = tool_call_dict.get("name") or "unknown"
            arguments = tool_call_dict.get("args")
        else:
            # Backward compat: SimpleNamespace(tool_name=..., arguments=...)
            tool_name = (
                getattr(request, "tool_name", None) or getattr(request, "name", None) or "unknown"
            )
            arguments = getattr(request, "arguments", None)

        # Pre-execution guard — handler NOT called on deny
        _raise_if_blocked(
            await self._client.guard.aevaluate_tool_call(
                tool_name,
                arguments,
                mode=self._mode,
                session_id=self._current_session_id,
            )
        )

        result = await handler(request)

        # Extract content: ToolMessage has .content; plain strings fall back to str()
        result_content = getattr(result, "content", None)
        if result_content is None:
            result_content = str(result) if result is not None else ""
        elif not isinstance(result_content, str):
            result_content = _extract_text_from_content(result_content) or ""

        # Post-execution guard — handler already ran, block the return value on deny
        _raise_if_blocked(
            await self._client.guard.aevaluate(
                GuardRequest(
                    content=result_content,
                    content_type="response",
                    action="call_tool",
                    mode=self._mode,
                    session_id=self._current_session_id or "",
                )
            )
        )

        return result

    async def wrap_model_call(self, request: Any, handler: Any) -> Any:
        """Pass through model calls without guarding."""
        return await handler(request)

    # Aliases called by the real LangGraph async middleware framework
    abefore_model = before_model
    aafter_model = after_model
    awrap_tool_call = wrap_tool_call
    awrap_model_call = wrap_model_call
