"""AWS Strands Agents HookProvider integration for highflame.

Usage::

    from highflame.integrations.strands import HighflameStrandsHooks

    hooks = HighflameStrandsHooks(client, mode="enforce")
    agent = Agent(hooks=[hooks])
"""

from __future__ import annotations

from typing import Any

try:
    from strands.hooks import (
        AfterModelCallEvent,
        AfterToolCallEvent,
        BeforeInvocationEvent,
        BeforeToolCallEvent,
        HookProvider,
        HookRegistry,
    )

    _STRANDS_AVAILABLE = True
except ImportError:
    _STRANDS_AVAILABLE = False
    HookProvider = object  # type: ignore[assignment,misc]
    HookRegistry = object  # type: ignore[assignment]
    BeforeInvocationEvent = object  # type: ignore[assignment]
    AfterModelCallEvent = object  # type: ignore[assignment]
    BeforeToolCallEvent = object  # type: ignore[assignment]
    AfterToolCallEvent = object  # type: ignore[assignment]

from .._types_gen import GuardRequest, Mode
from ..client import Highflame
from ..shield import _raise_if_blocked


def _extract_text_from_content(content: Any) -> str | None:
    """Extract text from plain str, list of content blocks, or object-style blocks.

    Returns ``None`` (not empty string) when nothing is extractable.
    """
    if content is None:
        return None
    if isinstance(content, str):
        return content if content else None
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                # Handle both generic {"type":"text","text":"..."} and
                # Bedrock native {"text":"..."} (no "type" key) formats.
                if block.get("type", "text") == "text" and "text" in block:
                    parts.append(block.get("text", ""))
            elif getattr(block, "type", None) == "text":
                parts.append(getattr(block, "text", ""))
        return "\n".join(parts) if parts else None
    return None


def _extract_last_user_message(messages: list) -> str | None:
    """Return text of the last user/human message in a Bedrock-style message list, or None.

    Supports both dict messages (``{"role": "user", "content": ...}``) and
    objects with ``role``/``content`` attributes.  Content may be a plain
    string or a list of content blocks.
    """
    if not messages:
        return None
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            if role in ("user", "human"):
                return _extract_text_from_content(msg.get("content"))
        else:
            role = getattr(msg, "role", "") or ""
            if role in ("user", "human"):
                return _extract_text_from_content(getattr(msg, "content", None))
    return None


def _extract_model_response(stop_response: Any) -> str | None:
    """Extract text from a Strands stop_response object.

    Reads ``stop_response.message`` (dict or object), then delegates to
    ``_extract_text_from_content`` on the message's ``content`` field.
    """
    if stop_response is None:
        return None
    message = getattr(stop_response, "message", None)
    if message is None:
        return None
    if isinstance(message, dict):
        content = message.get("content")
    else:
        content = getattr(message, "content", None)
    return _extract_text_from_content(content)


def _extract_tool_result_content(result: Any) -> str | None:
    """Extract text from a Strands tool result.

    Tries ``result["content"]`` or ``result.content`` and delegates to
    ``_extract_text_from_content``.  Falls back to the result itself when
    it is a non-empty plain string.
    """
    if result is None:
        return None
    if isinstance(result, str):
        return result if result else None
    content: Any = None
    if hasattr(result, "get"):
        content = result.get("content")
    else:
        content = getattr(result, "content", None)
    if content is not None:
        return _extract_text_from_content(content)
    return None


def _resolve_session_id(invocation_state: dict, key: str, static_id: str | None) -> str | None:
    """Resolve a session ID.

    Priority: ``static_id`` → ``invocation_state[key]`` → ``None``.
    """
    if static_id is not None:
        return static_id
    if invocation_state:
        val = invocation_state.get(key)
        if val is not None:
            return str(val)
    return None


class HighflameStrandsHooks(HookProvider):  # type: ignore[misc]
    """AWS Strands Agents HookProvider that routes guardrail checks through Highflame.

    Registers four async hooks with the Strands hook registry:

    - ``BeforeInvocationEvent``  — guards the last user message before the agent loop starts
    - ``AfterModelCallEvent``    — guards the model response after the LLM responds
    - ``BeforeToolCallEvent``    — guards a tool call before it executes
    - ``AfterToolCallEvent``     — guards a tool result after the tool returns

    On deny, each hook raises :class:`~highflame.errors.BlockedError`.
    For ``BeforeToolCallEvent``, ``event.cancel_tool`` is also set to the deny reason
    before raising, following the idiomatic Strands cancellation signal.

    Usage::

        hooks = HighflameStrandsHooks(client, mode="enforce")
        agent = Agent(hooks=[hooks])
    """

    def __init__(
        self,
        client: Highflame,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
        session_id_key: str = "session_id",
    ) -> None:
        if not _STRANDS_AVAILABLE:
            raise ImportError(
                "strands-agents is required for HighflameStrandsHooks. "
                "Install it with: pip install 'highflame[strands]'"
            )
        self._client = client
        self._mode = mode
        self._session_id = session_id
        self._session_id_key = session_id_key

    # ------------------------------------------------------------------
    # Hook implementations
    # ------------------------------------------------------------------

    async def _before_invocation(self, event: Any) -> None:
        """Guard the last user message before the agent loop starts."""
        messages = getattr(event, "messages", None) or []
        text = _extract_last_user_message(messages)
        if not text:
            return
        invocation_state = getattr(event, "invocation_state", {}) or {}
        session_id = _resolve_session_id(invocation_state, self._session_id_key, self._session_id)
        _raise_if_blocked(
            await self._client.guard.aevaluate_prompt(text, mode=self._mode, session_id=session_id)
        )

    async def _after_model_call(self, event: Any) -> None:
        """Guard the model response after the LLM responds."""
        stop_response = getattr(event, "stop_response", None)
        if stop_response is None:
            return
        text = _extract_model_response(stop_response)
        if not text:
            return
        invocation_state = getattr(event, "invocation_state", {}) or {}
        session_id = _resolve_session_id(invocation_state, self._session_id_key, self._session_id)
        _raise_if_blocked(
            await self._client.guard.aevaluate(
                GuardRequest(
                    content=text,
                    content_type="response",
                    action="process_prompt",
                    mode=self._mode,
                    session_id=session_id or "",
                )
            )
        )

    async def _before_tool_call(self, event: Any) -> None:
        """Guard a tool call before it executes.

        On deny, sets ``event.cancel_tool`` to the deny reason (idiomatic Strands
        cancellation signal) and then raises ``BlockedError``.
        """
        tool_use = getattr(event, "tool_use", {}) or {}
        if isinstance(tool_use, dict):
            tool_name = tool_use.get("name") or "unknown"
            tool_input = tool_use.get("input")
        else:
            tool_name = getattr(tool_use, "name", None) or "unknown"
            tool_input = getattr(tool_use, "input", None)
        invocation_state = getattr(event, "invocation_state", {}) or {}
        session_id = _resolve_session_id(invocation_state, self._session_id_key, self._session_id)
        resp = await self._client.guard.aevaluate_tool_call(
            tool_name,
            tool_input if isinstance(tool_input, dict) else None,
            mode=self._mode,
            session_id=session_id,
        )
        if resp.denied:
            event.cancel_tool = resp.policy_reason or "Blocked by Highflame Shield"
        _raise_if_blocked(resp)

    async def _after_tool_call(self, event: Any) -> None:
        """Guard a tool result after the tool returns."""
        # Real Strands SDK: event.result (ToolResult TypedDict)
        # Backward compat (tests / older code): event.tool_result
        tool_result = getattr(event, "result", None)
        if tool_result is None:
            tool_result = getattr(event, "tool_result", None)
        text = _extract_tool_result_content(tool_result)
        if not text:
            return
        invocation_state = getattr(event, "invocation_state", {}) or {}
        session_id = _resolve_session_id(invocation_state, self._session_id_key, self._session_id)
        _raise_if_blocked(
            await self._client.guard.aevaluate(
                GuardRequest(
                    content=text,
                    content_type="response",
                    action="call_tool",
                    mode=self._mode,
                    session_id=session_id or "",
                )
            )
        )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_hooks(self, registry: Any) -> None:
        """Register all four async hooks with the Strands hook registry."""
        registry.add_callback(BeforeInvocationEvent, self._before_invocation)
        registry.add_callback(AfterModelCallEvent, self._after_model_call)
        registry.add_callback(BeforeToolCallEvent, self._before_tool_call)
        registry.add_callback(AfterToolCallEvent, self._after_tool_call)
