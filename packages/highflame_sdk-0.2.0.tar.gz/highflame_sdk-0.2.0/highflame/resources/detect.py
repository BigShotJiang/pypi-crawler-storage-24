"""Detect resource: POST /v1/detect — detection only, no policy evaluation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._types_gen import DetectRequest, DetectResponse

if TYPE_CHECKING:
    from .._http import HTTPTransport


class DetectResource:
    """Run detectors without policy evaluation.

    Usage::

        resp = client.detect.run(content="...", content_type="prompt")
        resp = client.detect.run(DetectRequest(...))
    """

    def __init__(self, transport: HTTPTransport) -> None:
        self._transport = transport

    def run(
        self,
        request: DetectRequest | None = None,
        *,
        content: str | None = None,
        content_type: str | None = None,
        detectors: list[str] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> DetectResponse:
        """Run detection (POST /v1/detect)."""
        if request is None:
            if content is None or content_type is None:
                raise ValueError("content and content_type are required")
            request = DetectRequest(
                content=content,
                content_type=content_type,  # type: ignore[arg-type]
                detectors=detectors or [],
                **kwargs,
            )
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        response = self._transport.request("POST", "/v1/detect", body, timeout=timeout)
        return DetectResponse.model_validate(response.json())

    async def arun(
        self,
        request: DetectRequest | None = None,
        *,
        content: str | None = None,
        content_type: str | None = None,
        detectors: list[str] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> DetectResponse:
        """Async: run detection."""
        if request is None:
            if content is None or content_type is None:
                raise ValueError("content and content_type are required")
            request = DetectRequest(
                content=content,
                content_type=content_type,  # type: ignore[arg-type]
                detectors=detectors or [],
                **kwargs,
            )
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        response = await self._transport.arequest("POST", "/v1/detect", body, timeout=timeout)
        return DetectResponse.model_validate(response.json())
