"""Detectors resource: GET /v1/detectors."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._types_gen import ListDetectorsResponse

if TYPE_CHECKING:
    from .._http import HTTPTransport


class DetectorsResource:
    """List available detectors.

    Usage::

        resp = client.detectors.list()
        for d in resp.detectors:
            print(d.name, d.tier, d.status)
    """

    def __init__(self, transport: HTTPTransport) -> None:
        self._transport = transport

    def list(self, *, timeout: float | None = None) -> ListDetectorsResponse:
        """List available detectors (GET /v1/detectors)."""
        response = self._transport.request("GET", "/v1/detectors", timeout=timeout)
        return ListDetectorsResponse.model_validate(response.json())

    async def alist(self, *, timeout: float | None = None) -> ListDetectorsResponse:
        """Async: list available detectors."""
        response = await self._transport.arequest("GET", "/v1/detectors", timeout=timeout)
        return ListDetectorsResponse.model_validate(response.json())
