"""Debug resource: GET /v1/debug/policies."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._types_gen import DebugPoliciesResponse

if TYPE_CHECKING:
    from .._http import HTTPTransport


class DebugResource:
    """Inspect loaded policies and other debug information.

    Usage::

        policies = client.debug.policies()
    """

    def __init__(self, transport: HTTPTransport) -> None:
        self._transport = transport

    def policies(
        self, *, product: str = "guardrails", timeout: float | None = None
    ) -> DebugPoliciesResponse:
        """Inspect loaded policies (GET /v1/debug/policies)."""
        response = self._transport.request(
            "GET", f"/v1/debug/policies?product={product}", timeout=timeout
        )
        return DebugPoliciesResponse.model_validate(response.json())

    async def apolicies(
        self, *, product: str = "guardrails", timeout: float | None = None
    ) -> DebugPoliciesResponse:
        """Async: inspect loaded policies."""
        response = await self._transport.arequest(
            "GET", f"/v1/debug/policies?product={product}", timeout=timeout
        )
        return DebugPoliciesResponse.model_validate(response.json())
