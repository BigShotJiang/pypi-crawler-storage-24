"""Guard resource: POST /v1/guard and POST /v1/guard/stream."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any

from .._types_gen import (
    GuardRequest,
    GuardResponse,
    Mode,
    StreamEvent,
    ToolContext,
)
from ..errors import APIConnectionError

if TYPE_CHECKING:
    from .._http import HTTPTransport

try:
    from httpx_sse import aconnect_sse, connect_sse
except ImportError:
    aconnect_sse = None  # type: ignore[assignment,misc]
    connect_sse = None  # type: ignore[assignment,misc]


class GuardResource:
    """Evaluate content against guard policies.

    Usage::

        resp = client.guard.evaluate(content="...", content_type="prompt", action="process_prompt")
        resp = client.guard.evaluate_prompt("hello")
        resp = client.guard.evaluate_tool_call("shell", {"command": "ls"})
    """

    def __init__(self, transport: HTTPTransport) -> None:
        self._transport = transport

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    def evaluate(
        self,
        request: GuardRequest | None = None,
        *,
        content: str | None = None,
        content_type: str | None = None,
        action: str | None = None,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> GuardResponse:
        """Evaluate content against guard policies (POST /v1/guard).

        Either pass a ``GuardRequest`` object, or provide fields as kwargs.
        """
        if request is None:
            if content is None or content_type is None or action is None:
                raise ValueError("content, content_type, and action are required")
            request = GuardRequest(
                content=content,
                content_type=content_type,  # type: ignore[arg-type]
                action=action,
                mode=mode,
                session_id=session_id or "",
                **kwargs,
            )
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        response = self._transport.request("POST", "/v1/guard", body, timeout=timeout)
        return GuardResponse.model_validate(response.json())

    def evaluate_prompt(
        self,
        content: str,
        *,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> GuardResponse:
        """Shorthand: evaluate a user prompt."""
        return self.evaluate(
            GuardRequest(
                content=content,
                content_type="prompt",
                action="process_prompt",
                mode=mode,
                session_id=session_id or "",
            ),
            timeout=timeout,
        )

    def evaluate_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> GuardResponse:
        """Shorthand: evaluate a tool call."""
        return self.evaluate(
            GuardRequest(
                content=f"Tool call: {tool_name}",
                content_type="tool_call",
                action="call_tool",
                mode=mode,
                session_id=session_id or "",
                tool=ToolContext(name=tool_name, is_builtin=False, arguments=arguments or {}),
            ),
            timeout=timeout,
        )

    def stream(
        self, request: GuardRequest, *, timeout: float | None = None
    ) -> Iterator[StreamEvent]:
        """Stream guard evaluation results (POST /v1/guard/stream)."""
        if connect_sse is None:
            raise ImportError("httpx-sse is required for streaming. Install: pip install httpx-sse")
        headers = self._transport._get_headers()
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        try:
            with connect_sse(
                self._transport._sync_client,
                "POST",
                "/v1/guard/stream",
                content=json.dumps(body),
                headers=headers,
                timeout=timeout or self._transport._timeout,
            ) as event_source:
                for sse in event_source.iter_sse():
                    if not sse.data:
                        continue
                    try:
                        payload = json.loads(sse.data)
                    except json.JSONDecodeError:
                        continue
                    yield StreamEvent(
                        type=sse.event or "detector_result",
                        data=payload,
                    )
        except Exception as exc:
            if "timeout" in str(exc).lower():
                raise APIConnectionError(f"Stream timed out: {exc}") from exc
            raise APIConnectionError(f"Stream failed: {exc}") from exc

    # ------------------------------------------------------------------
    # Async
    # ------------------------------------------------------------------

    async def aevaluate(
        self,
        request: GuardRequest | None = None,
        *,
        content: str | None = None,
        content_type: str | None = None,
        action: str | None = None,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> GuardResponse:
        """Async: evaluate content against guard policies."""
        if request is None:
            if content is None or content_type is None or action is None:
                raise ValueError("content, content_type, and action are required")
            request = GuardRequest(
                content=content,
                content_type=content_type,  # type: ignore[arg-type]
                action=action,
                mode=mode,
                session_id=session_id or "",
                **kwargs,
            )
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        response = await self._transport.arequest("POST", "/v1/guard", body, timeout=timeout)
        return GuardResponse.model_validate(response.json())

    async def aevaluate_prompt(
        self,
        content: str,
        *,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> GuardResponse:
        """Async shorthand: evaluate a user prompt."""
        return await self.aevaluate(
            GuardRequest(
                content=content,
                content_type="prompt",
                action="process_prompt",
                mode=mode,
                session_id=session_id or "",
            ),
            timeout=timeout,
        )

    async def aevaluate_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        mode: Mode | None = None,
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> GuardResponse:
        """Async shorthand: evaluate a tool call."""
        return await self.aevaluate(
            GuardRequest(
                content=f"Tool call: {tool_name}",
                content_type="tool_call",
                action="call_tool",
                mode=mode,
                session_id=session_id or "",
                tool=ToolContext(name=tool_name, is_builtin=False, arguments=arguments or {}),
            ),
            timeout=timeout,
        )

    async def astream(
        self, request: GuardRequest, *, timeout: float | None = None
    ) -> AsyncIterator[StreamEvent]:
        """Async: stream guard evaluation results."""
        if aconnect_sse is None:
            raise ImportError("httpx-sse is required for streaming. Install: pip install httpx-sse")
        headers = await self._transport._aget_headers()
        body = request.model_dump(exclude_none=True, exclude_defaults=True, by_alias=True)
        try:
            async with aconnect_sse(
                self._transport._async_client,
                "POST",
                "/v1/guard/stream",
                content=json.dumps(body),
                headers=headers,
                timeout=timeout or self._transport._timeout,
            ) as event_source:
                async for sse in event_source.aiter_sse():
                    if not sse.data:
                        continue
                    try:
                        payload = json.loads(sse.data)
                    except json.JSONDecodeError:
                        continue
                    yield StreamEvent(
                        type=sse.event or "detector_result",
                        data=payload,
                    )
        except Exception as exc:
            if "timeout" in str(exc).lower():
                raise APIConnectionError(f"Stream timed out: {exc}") from exc
            raise APIConnectionError(f"Stream failed: {exc}") from exc
