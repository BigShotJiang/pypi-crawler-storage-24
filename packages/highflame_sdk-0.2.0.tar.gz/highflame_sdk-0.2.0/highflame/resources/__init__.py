"""Resource classes for the Highflame SDK."""

from .debug import DebugResource
from .detect import DetectResource
from .detectors import DetectorsResource
from .guard import GuardResource

__all__ = [
    "GuardResource",
    "DetectResource",
    "DetectorsResource",
    "DebugResource",
]
