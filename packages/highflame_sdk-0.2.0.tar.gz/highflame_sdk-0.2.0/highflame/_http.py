"""Base HTTP transport with retry, auth header injection, and error mapping."""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Any

import httpx

from ._auth import TokenManager
from .errors import (
    APIConnectionError,
    APIError,
    AuthenticationError,
    RateLimitError,
)

logger = logging.getLogger("highflame")

_DEFAULT_TIMEOUT = 30.0
_DEFAULT_MAX_RETRIES = 2
_RETRY_STATUS_CODES = {429, 500, 502, 503, 504}
_LOG_BODY_MAX = 1024  # Truncate request/response bodies in debug logs.


def _user_agent() -> str:
    from importlib.metadata import version as _pkg_version

    try:
        v = _pkg_version("highflame")
    except Exception:
        v = "0.0.0"
    return f"highflame-python/{v}"


_USER_AGENT = _user_agent()


def _truncate(text: str, max_len: int = _LOG_BODY_MAX) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"... ({len(text)} chars)"


def _raise_for_status(response: httpx.Response) -> None:
    """Map HTTP errors to SDK error classes."""
    if response.is_success:
        return
    try:
        body = response.json()
        title = body.get("title", response.reason_phrase or "Error")
        detail = body.get("detail", "")
    except Exception:
        title = response.reason_phrase or "Error"
        detail = response.text

    if response.status_code == 401:
        raise AuthenticationError(detail)
    if response.status_code == 429:
        raise RateLimitError(detail)
    raise APIError(status=response.status_code, title=title, detail=detail)


def _retry_delay(attempt: int) -> float:
    """Exponential backoff with jitter: base of 1s, 2s, 4s, … plus ±25% jitter."""
    import random

    base = 2.0**attempt
    jitter = base * 0.25 * (2.0 * random.random() - 1.0)  # ±25%
    return max(0.0, base + jitter)


class HTTPTransport:
    """HTTP transport layer with retry logic and auth header injection.

    Supports both service-key (automatic token exchange) and direct JWT modes.

    You can pass pre-configured ``httpx.Client`` / ``httpx.AsyncClient``
    instances for custom proxy, certificate, or connection-pool settings.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        token_url: str | None,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        account_id: str | None = None,
        project_id: str | None = None,
        default_headers: dict[str, str] | None = None,
        httpx_client: httpx.Client | None = None,
        async_httpx_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._override_account_id = account_id
        self._override_project_id = project_id
        self._default_headers: dict[str, str] = dict(default_headers) if default_headers else {}

        # Auth: either token manager (service key) or static headers (direct JWT).
        self._token_mgr: TokenManager | None = None
        if token_url and api_key.startswith("hf_sk"):
            self._token_mgr = TokenManager(api_key, token_url, timeout)

        self._static_headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
            **self._default_headers,
        }
        if not self._token_mgr:
            self._static_headers["Authorization"] = f"Bearer {api_key}"
        if account_id:
            self._static_headers["X-Account-ID"] = account_id
        if project_id:
            self._static_headers["X-Project-ID"] = project_id

        # HTTP clients — user-provided or lazily created.
        self.__sync_client: httpx.Client | None = httpx_client
        self.__async_client: httpx.AsyncClient | None = async_httpx_client
        self._owns_sync_client = httpx_client is None
        self._owns_async_client = async_httpx_client is None

    @property
    def _sync_client(self) -> httpx.Client:
        if self.__sync_client is None:
            self.__sync_client = httpx.Client(base_url=self._base_url)
        return self.__sync_client

    @property
    def _async_client(self) -> httpx.AsyncClient:
        if self.__async_client is None:
            self.__async_client = httpx.AsyncClient(base_url=self._base_url)
        return self.__async_client

    def _get_headers(self) -> dict[str, str]:
        """Build request headers with auth (sync)."""
        if not self._token_mgr:
            return self._static_headers
        token = self._token_mgr.get_token()
        headers: dict[str, str] = {
            "Authorization": f"Bearer {token.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
            **self._default_headers,
        }
        acct = self._override_account_id or token.account_id
        proj = self._override_project_id or token.project_id
        if acct:
            headers["X-Account-ID"] = acct
        if proj:
            headers["X-Project-ID"] = proj
        return headers

    async def _aget_headers(self) -> dict[str, str]:
        """Build request headers with auth (async)."""
        if not self._token_mgr:
            return self._static_headers
        token = await self._token_mgr.aget_token()
        headers: dict[str, str] = {
            "Authorization": f"Bearer {token.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
            **self._default_headers,
        }
        acct = self._override_account_id or token.account_id
        proj = self._override_project_id or token.project_id
        if acct:
            headers["X-Account-ID"] = acct
        if proj:
            headers["X-Project-ID"] = proj
        return headers

    def request(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Make an HTTP request with retries (sync)."""
        effective_timeout = timeout if timeout is not None else self._timeout
        last_exc: Exception = APIConnectionError("Request failed after all retries.")
        idempotency_key: str | None = None
        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                if idempotency_key is None:
                    idempotency_key = str(uuid.uuid4())
                delay = _retry_delay(attempt - 1)
                logger.debug(
                    "Retrying %s %s (attempt %d/%d) after %.1fs",
                    method,
                    path,
                    attempt + 1,
                    self._max_retries + 1,
                    delay,
                )
                time.sleep(delay)
            headers = self._get_headers()
            if idempotency_key:
                headers["X-Idempotency-Key"] = idempotency_key
            content = json.dumps(body) if body is not None else None
            try:
                logger.debug("%s %s", method, path)
                if content:
                    logger.debug("Request body: %s", _truncate(content))
                response = self._sync_client.request(
                    method,
                    path,
                    content=content,
                    headers=headers,
                    timeout=effective_timeout,
                )
            except httpx.TimeoutException as exc:
                logger.debug("Request timed out: %s %s", method, path)
                last_exc = APIConnectionError(f"Request timed out: {exc}")
                continue
            except httpx.ConnectError as exc:
                raise APIConnectionError(f"Connection failed: {exc}") from exc

            logger.debug("%s %s → %d", method, path, response.status_code)
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("Response body: %s", _truncate(response.text))

            if response.status_code not in _RETRY_STATUS_CODES:
                _raise_for_status(response)
                return response

            last_exc = APIError(
                status=response.status_code,
                title=response.reason_phrase or "Server Error",
                detail=response.text,
            )
        raise last_exc

    async def arequest(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Make an HTTP request with retries (async)."""
        effective_timeout = timeout if timeout is not None else self._timeout
        last_exc: Exception = APIConnectionError("Request failed after all retries.")
        idempotency_key: str | None = None
        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                if idempotency_key is None:
                    idempotency_key = str(uuid.uuid4())
                delay = _retry_delay(attempt - 1)
                logger.debug(
                    "Retrying %s %s (attempt %d/%d) after %.1fs",
                    method,
                    path,
                    attempt + 1,
                    self._max_retries + 1,
                    delay,
                )
                await asyncio.sleep(delay)
            headers = await self._aget_headers()
            if idempotency_key:
                headers["X-Idempotency-Key"] = idempotency_key
            content = json.dumps(body) if body is not None else None
            try:
                logger.debug("%s %s", method, path)
                if content:
                    logger.debug("Request body: %s", _truncate(content))
                response = await self._async_client.request(
                    method,
                    path,
                    content=content,
                    headers=headers,
                    timeout=effective_timeout,
                )
            except httpx.TimeoutException as exc:
                logger.debug("Request timed out: %s %s", method, path)
                last_exc = APIConnectionError(f"Request timed out: {exc}")
                continue
            except httpx.ConnectError as exc:
                raise APIConnectionError(f"Connection failed: {exc}") from exc

            logger.debug("%s %s → %d", method, path, response.status_code)
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("Response body: %s", _truncate(response.text))

            if response.status_code not in _RETRY_STATUS_CODES:
                _raise_for_status(response)
                return response

            last_exc = APIError(
                status=response.status_code,
                title=response.reason_phrase or "Server Error",
                detail=response.text,
            )
        raise last_exc

    def close(self) -> None:
        if self.__sync_client and self._owns_sync_client:
            self.__sync_client.close()
        if self._token_mgr:
            self._token_mgr.close()

    async def aclose(self) -> None:
        if self.__async_client and self._owns_async_client:
            await self.__async_client.aclose()
        if self._token_mgr:
            await self._token_mgr.aclose()
