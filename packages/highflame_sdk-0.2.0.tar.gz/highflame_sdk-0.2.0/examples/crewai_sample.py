#!/usr/bin/env python3
"""
CrewAI + Highflame Shield — integration sample
===============================================

Shows how to add Highflame Shield guardrails to a CrewAI crew
with HighflameCrewHooks used as a context manager.

The LLM is mocked via litellm.mock_response — no LLM API key required.
Requires a running Shield service; set SHIELD_URL / SHIELD_API_KEY
or run `highflame dev` to start a local instance.

Requirements
------------
    pip install 'highflame[crewai]' crewai litellm

Usage
-----
    cd python
    SHIELD_URL=http://localhost:8080 python examples/crewai_sample.py
"""

from __future__ import annotations

import os
import sys

import litellm
from crewai import LLM, Agent, Crew, Task
from crewai.tools import tool as crewai_tool

from highflame import APIConnectionError, BlockedError, Highflame
from highflame.integrations.crewai import HighflameCrewHooks

SHIELD_URL = os.environ.get("SHIELD_URL", "http://localhost:8080")
API_KEY = os.environ.get("SHIELD_API_KEY", "demo-key")

_tty = sys.stdout.isatty()
GREEN = "\033[32m" if _tty else ""
RED = "\033[31m" if _tty else ""
BLUE = "\033[34m" if _tty else ""
RESET = "\033[0m" if _tty else ""


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@crewai_tool("Revenue Lookup")
def lookup_revenue(quarter: str) -> str:
    """Look up revenue figures for a given quarter."""
    return f"Q{quarter} revenue: $4.2M, up 12% year-over-year."


# ---------------------------------------------------------------------------
# Demo scenarios
# ---------------------------------------------------------------------------


def demo_allowed() -> None:
    """Normal crew run — Shield evaluates each LLM call and allows through."""
    print("── 1. Normal crew run ────────────────────────────────────────")

    litellm.mock_response = "Revenue grew 12% year-over-year to $4.2M."

    # Two lines to add Shield to any CrewAI crew:
    client = Highflame(base_url=SHIELD_URL, api_key=API_KEY, max_retries=0)

    llm = LLM(model="gpt-4o-mini", api_key="fake-key")
    agent = Agent(
        role="Financial Analyst",
        goal="Analyse revenue data and produce a concise summary",
        backstory="Expert in interpreting financial results.",
        llm=llm,
        verbose=False,
    )
    task = Task(
        description="Summarise last quarter's revenue in one sentence.",
        expected_output="One-sentence revenue summary.",
        agent=agent,
    )
    crew = Crew(agents=[agent], tasks=[task], verbose=False)

    try:
        with HighflameCrewHooks(client, mode="enforce", session_id="demo-crew-001"):
            result = crew.kickoff()
        print(f"  {GREEN}✓{RESET}  crew result: {str(result).strip()[:80]!r}")
    except BlockedError as e:
        print(f"  {RED}✗{RESET}  Shield blocked: {e.response.reason}")
    except APIConnectionError:
        print(f"  {BLUE}!{RESET}  Shield not reachable — start a local instance or set SHIELD_URL")
    finally:
        litellm.mock_response = None


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    print(f"\n{BLUE}·{RESET}  CrewAI + Highflame Shield — integration demo")
    print(f"{BLUE}·{RESET}  Shield endpoint: {SHIELD_URL}\n")
    demo_allowed()
    print()


if __name__ == "__main__":
    main()
