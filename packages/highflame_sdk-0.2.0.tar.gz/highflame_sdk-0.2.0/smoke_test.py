#!/usr/bin/env python3
"""
smoke_test.py — Auth smoke test for the highflame Python SDK.

Verifies:
  1. Direct JWT auth      → GET /v1/detectors, POST /v1/guard,
                            GET /v1/debug/policies
  2. Service-key flow     → POST token exchange, JWT used as Bearer,
                            token cached across calls, async aevaluate()

Environment variables:

  HIGHFLAME_API_KEY  An hf_sk_xxx service key for the token-exchange tests.
                     This is the primary credential for most callers.

  HIGHFLAME_JWT      A raw JWT for direct-auth tests (optional).
                     Use this only when testing the raw-bearer path.

  SHIELD_BASE_URL    Override the Shield guard service base URL.
                     Defaults to the Highflame SaaS endpoint.
                     Example: https://shield.api-dev.highflame.dev

  SHIELD_TOKEN_URL   Override the token exchange endpoint URL.
                     Defaults to the Highflame SaaS endpoint.
                     Example: https://studio.api-dev.highflame.dev/api/cli-auth/token

Usage (from sdk/python/ with venv active):

  # Service key (uses SaaS endpoints by default):
  HIGHFLAME_API_KEY=hf_sk_xxx     python smoke_test.py

  # Override endpoints (e.g. for dev environment):
  SHIELD_BASE_URL=https://shield.api-dev.highflame.dev \
  SHIELD_TOKEN_URL=https://studio.api-dev.highflame.dev/api/cli-auth/token \
  HIGHFLAME_API_KEY=hf_sk_xxx     python smoke_test.py

  # Both flows:
  SHIELD_BASE_URL=https://shield.api-dev.highflame.dev \
  SHIELD_TOKEN_URL=https://studio.api-dev.highflame.dev/api/cli-auth/token \
  HIGHFLAME_JWT=<jwt>             \
  HIGHFLAME_API_KEY=hf_sk_xxx     python smoke_test.py

Exit codes:
  0 — all checks passed
  1 — one or more checks failed
"""

import os
import sys

try:
    from highflame import (
        APIConnectionError,
        APIError,
        GuardRequest,
        Highflame,
    )
except ImportError:
    print("ERROR: highflame not installed.")
    print("       Run: pip install -e .")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

BASE_URL = os.environ.get("SHIELD_BASE_URL", "https://shield.api-dev.highflame.dev")
TOKEN_URL = os.environ.get(
    "SHIELD_TOKEN_URL",
    "https://studio.api-dev.highflame.dev/api/cli-auth/token",
)
API_KEY = os.environ.get("HIGHFLAME_API_KEY", "")  # hf_sk_xxx service key
JWT = os.environ.get("HIGHFLAME_JWT", "")  # raw JWT for direct-auth tests

# ANSI colours (suppressed when not a TTY)
_tty = sys.stdout.isatty()
GREEN = "\033[32m" if _tty else ""
RED = "\033[31m" if _tty else ""
BLUE = "\033[34m" if _tty else ""
YELLOW = "\033[33m" if _tty else ""
RESET = "\033[0m" if _tty else ""

PASS = f"{GREEN}✓{RESET}"
FAIL = f"{RED}✗{RESET}"
INFO = f"{BLUE}·{RESET}"
WARN = f"{YELLOW}!{RESET}"
SKIP = f"{YELLOW}–{RESET}"

# The test request used for all guard calls.
_TEST_REQUEST = GuardRequest(
    content="What is the capital of France?",
    content_type="prompt",
    action="process_prompt",
)

_results: list[tuple[str, bool]] = []


def _run(label: str, fn) -> bool:
    """Execute fn(), record and print pass/fail."""
    try:
        fn()
        print(f"  {PASS}  {label}")
        _results.append((label, True))
        return True
    except APIError as e:
        print(f"  {FAIL}  {label}")
        print(f"         APIError [{e.status}] {e.title}: {e.detail}")
        _results.append((label, False))
        return False
    except APIConnectionError as e:
        print(f"  {FAIL}  {label}")
        print(f"         ConnectionError: {e}")
        _results.append((label, False))
        return False
    except AssertionError as e:
        print(f"  {FAIL}  {label}")
        print(f"         Assertion failed: {e}")
        _results.append((label, False))
        return False
    except Exception as e:
        print(f"  {FAIL}  {label}")
        print(f"         Unexpected error ({type(e).__name__}): {e}")
        _results.append((label, False))
        return False


# ---------------------------------------------------------------------------
# Pre-flight: validate URL and keys
# ---------------------------------------------------------------------------

print(f"\n{INFO}  Base URL  : {BASE_URL or '(SaaS default)'}")
print(f"{INFO}  Token URL : {TOKEN_URL or '(SaaS default)'}")
print()

if not API_KEY and not JWT:
    print(f"{FAIL}  Neither HIGHFLAME_API_KEY nor HIGHFLAME_JWT is set — cannot run any checks.")
    sys.exit(1)

# URL overrides applied to all clients.
_overrides = {k: v for k, v in {"base_url": BASE_URL, "token_url": TOKEN_URL}.items() if v}


# ---------------------------------------------------------------------------
# 1. Direct JWT flow
# ---------------------------------------------------------------------------

_jwt_is_service_key = JWT.startswith("hf_sk")

if not JWT:
    print(f"{SKIP}  Direct JWT tests skipped (HIGHFLAME_JWT not set)")
elif _jwt_is_service_key:
    print(
        f"{SKIP}  Direct JWT tests skipped (HIGHFLAME_JWT looks like a service key"
        " — set it to a raw JWT for direct-auth tests)"
    )
else:
    print(f"── 1. Direct JWT flow {'─' * 34}")

    direct = Highflame(api_key=JWT, max_retries=0, **_overrides)

    def _check_list_detectors():
        result = direct.detectors.list()
        print(f"         {result.count} detector(s) registered")
        assert result.count >= 0, "negative detector count"

    def _check_guard_direct():
        resp = direct.guard.evaluate(_TEST_REQUEST)
        print(f"         decision={resp.decision!r}  latency_ms={resp.latency_ms}")
        assert resp.decision in (
            "allow",
            "deny",
        ), f"unexpected decision: {resp.decision!r}"

    def _check_debug_policies():
        result = direct.debug.policies()
        print(f"         {len(result.policies) if result.policies else 0} policy/ies loaded")

    _run("GET  /v1/detectors", _check_list_detectors)
    _run("POST /v1/guard  (raw JWT)", _check_guard_direct)
    _run("GET  /v1/debug/policies", _check_debug_policies)


# ---------------------------------------------------------------------------
# 2. Service-key flow
# ---------------------------------------------------------------------------

if not API_KEY:
    print(f"\n{SKIP}  Service-key tests skipped (HIGHFLAME_API_KEY not set)")
else:
    print(f"\n── 2. Service-key flow {'─' * 35}")

    sk = Highflame(api_key=API_KEY, max_retries=0, **_overrides)

    def _check_exchange():
        # _get_headers() on the transport triggers the token exchange on first call.
        headers = sk._transport._get_headers()
        tok = sk._transport._token_mgr._cached
        assert tok is not None, "no token cached after _get_headers()"

        bearer = headers.get("Authorization", "")
        assert bearer.startswith("Bearer "), "Authorization header missing"

        jwt = bearer[len("Bearer ") :]
        assert jwt != API_KEY, (
            "Authorization header still carries the raw service key — exchange did not occur"
        )
        assert jwt.startswith("eyJ"), (
            f"Token does not look like a JWT (expected 'eyJ...'): {jwt[:30]!r}"
        )

        print(f"         account_id={tok.account_id!r}  project_id={tok.project_id!r}")
        print(f"         JWT prefix : {jwt[:40]}…")

    def _check_guard_jwt():
        resp = sk.guard.evaluate(_TEST_REQUEST)
        print(f"         decision={resp.decision!r}  latency_ms={resp.latency_ms}")
        assert resp.decision in (
            "allow",
            "deny",
        ), f"unexpected decision: {resp.decision!r}"

    def _check_token_cached():
        tok_before = sk._transport._token_mgr._cached
        sk.guard.evaluate(_TEST_REQUEST)
        tok_after = sk._transport._token_mgr._cached
        assert tok_before is tok_after, (
            "Token object was replaced — unexpected re-exchange on second call"
        )
        print("         Same token reused across both guard.evaluate() calls")

    def _check_async_exchange():
        import asyncio

        async def _inner():
            async with Highflame(api_key=API_KEY, max_retries=0, **_overrides) as ask:
                headers = await ask._transport._aget_headers()
                tok = ask._transport._token_mgr._cached
                assert tok is not None, "no token cached after _aget_headers()"
                jwt = headers.get("Authorization", "")[len("Bearer ") :]
                assert jwt != API_KEY, "async exchange did not replace the raw key"
                assert jwt.startswith("eyJ"), "async token is not a JWT"
                resp = await ask.guard.aevaluate(_TEST_REQUEST)
                assert resp.decision in ("allow", "deny")
                print(f"         async decision={resp.decision!r}  latency_ms={resp.latency_ms}")

        asyncio.run(_inner())

    _run("POST token exchange", _check_exchange)
    _run("POST /v1/guard  (JWT auth)", _check_guard_jwt)
    _run("Token cached across calls", _check_token_cached)
    _run("Async exchange + aevaluate()", _check_async_exchange)


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

passed = sum(1 for _, ok in _results if ok)
total = len(_results)

print(f"\n{'─' * 57}")
if total == 0:
    print(f"{WARN}  No checks ran — verify your environment variables.")
    sys.exit(1)
elif passed == total:
    print(f"{PASS}  All {total} checks passed")
    sys.exit(0)
else:
    print(f"{FAIL}  {passed}/{total} checks passed")
    for label, ok in _results:
        mark = PASS if ok else FAIL
        print(f"       {mark}  {label}")
    sys.exit(1)
