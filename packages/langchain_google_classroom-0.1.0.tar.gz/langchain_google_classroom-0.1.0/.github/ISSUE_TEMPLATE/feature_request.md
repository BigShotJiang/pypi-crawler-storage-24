---
name: Feature Request
about: Suggest a new feature
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Description
A clear description of the feature you'd like.

## Use Case
Why this feature would be useful. What problem does it solve?

## Proposed API
```python
# How you'd expect to use this feature
```
