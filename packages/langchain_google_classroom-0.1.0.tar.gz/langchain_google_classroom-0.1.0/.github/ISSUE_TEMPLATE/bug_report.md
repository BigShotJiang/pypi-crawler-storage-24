---
name: Bug Report
about: Report a bug in langchain-google-classroom
title: "[BUG] "
labels: bug
assignees: ""
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. ...
2. ...

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened. Include error traceback if applicable.

## Environment
- Python version:
- langchain-google-classroom version:
- OS:
