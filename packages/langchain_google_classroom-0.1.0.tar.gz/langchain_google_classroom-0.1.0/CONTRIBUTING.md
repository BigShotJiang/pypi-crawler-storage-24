# Contributing to langchain-google-classroom

Thank you for your interest in contributing! This guide will help you get started.

## Development Setup

```bash
# Clone the repository
git clone https://github.com/ayanokojix21/langchain-google-classroom.git
cd langchain-google-classroom

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# Install in development mode
pip install -e ".[dev]"
```

## Running Tests

```bash
# Run all unit tests
pytest tests/unit/ -v

# Run a specific test file
pytest tests/unit/test_parsers.py -v

# Run with coverage
pytest tests/unit/ --cov=langchain_google_classroom --cov-report=term-missing
```

## Linting

```bash
# Check for lint errors
ruff check langchain_google_classroom/ tests/

# Auto-fix issues
ruff check langchain_google_classroom/ tests/ --fix
```

## Code Style

This project follows LangChain coding conventions:

- **Type annotations** on all functions and methods
- **Docstrings** in Google/NumPy style on all public functions
- **`from __future__ import annotations`** at the top of every module
- **`guard_import`** for optional dependencies (pypdf, python-docx)
- **`BaseBlobParser` + `Blob`** interface for all file parsers
- **`BaseLoader.lazy_load()`** as the main entry point

## Adding a New Parser

1. Create `langchain_google_classroom/parsers/your_parser.py`
2. Implement `BaseBlobParser.lazy_parse(blob)` → `Iterator[Document]`
3. Add the MIME type mapping in `parsers/__init__.py`
4. Add tests in `tests/unit/test_parsers.py`
5. Run `pytest` and `ruff check`

## Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Make your changes with tests
4. Run `pytest tests/unit/ -v` and `ruff check`
5. Commit with a descriptive message
6. Push and open a Pull Request

## Reporting Issues

Use [GitHub Issues](https://github.com/ayanokojix21/langchain-google-classroom/issues) with:

- **Bug reports**: Include Python version, error traceback, and steps to reproduce
- **Feature requests**: Describe the use case and proposed API
