import os
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import List, Mapping

from pandas import Series, DataFrame
from sqlalchemy.orm.session import Session
from werkzeug.datastructures import FileStorage
from werkzeug.exceptions import BadRequest, InternalServerError

from cidc_api.models.dataset import Dataset, Stages
from ..config.logging import get_logger
from ..config.settings import GOOGLE_CLINICAL_DATA_BUCKET
from ..models import (
    PreprocessedFiles,
    TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER,
    DownloadableFiles,
    with_default_session,
)
from ..shared.auth import get_current_user
from ..shared.gcloud_client import upload_file_to_gcs, move_gcs_file
from ..telemetry import trace_

logger = get_logger(__name__)

MASTER_APPENDIX_A_VERSION_PREFIX = "Master Appendix A Version:"


@trace_()
def set_current_file(
    file: FileStorage,
    file_category: str,
    gcs_folder: str,
    session: Session,
    uploader_email: str,
    job_id: int = None,
    append_timestamp: bool = None,
) -> PreprocessedFiles:
    """
    Archives any existing 'current' files for the given category and job,
    then uploads the new file as the latest 'current' version.
    """
    latest_version = PreprocessedFiles.archive_current_files(file_category, job_id=job_id, session=session)
    latest_file = create_file(
        file, gcs_folder, file_category, session, uploader_email, job_id, latest_version + 1, append_timestamp
    )
    return latest_file


@trace_()
def create_file(
    file: FileStorage,
    gcs_folder: str,
    file_category: str,
    session: Session,
    uploader_email: str,
    job_id: int = None,
    version: int = None,
    append_timestamp: bool = None,
) -> PreprocessedFiles:
    """Upload file to GCS and create corresponding metadata record in the database."""
    status = "pending" if gcs_folder.endswith("pending/") else "current"
    # only need timestamp for current/versioned files, if not specified otherwise
    append_timestamp = append_timestamp if append_timestamp is not None else (status == "current")
    # create file in GCS
    gcs_file_path = upload_file_to_gcs(file, GOOGLE_CLINICAL_DATA_BUCKET, gcs_folder, append_timestamp=append_timestamp)
    # create corresponding record in db
    file = PreprocessedFiles.create(
        file_name=file.filename,
        object_url=gcs_file_path,
        file_category=file_category,
        uploader_email=uploader_email,
        status=status,
        job_id=job_id,
        version=version,
        session=session,
    )
    return file


def validate_file_extension(filename: str, allowed_extensions: list[str]):
    if not filename or not any(filename.lower().endswith(ext) for ext in allowed_extensions):
        raise BadRequest(f"Invalid file type. Must be one of: {allowed_extensions}")


def format_common_preprocessed_file_response(file: PreprocessedFiles):
    """Format a common response for a single PreprocessedFiles record."""
    return {
        "file_name": file.file_name,
        "gcs_uri": f"gs://{GOOGLE_CLINICAL_DATA_BUCKET}/{file.object_url}",
        "status": file.status,
        "file_category": file.file_category,
        "uploader_email": file.uploader_email,
        "date": file._created.isoformat(),
    }


def version_pending_file(pending_file: PreprocessedFiles):
    """Transitions an existing pending file to be a current versioned file."""
    original_filename = pending_file.file_name
    pending_gcs_path = pending_file.object_url
    try:
        versioned_gcs_folder = strip_filename_and_pending_folder(pending_gcs_path)
        new_gcs_path = move_gcs_file(GOOGLE_CLINICAL_DATA_BUCKET, pending_gcs_path, versioned_gcs_folder)
    except Exception as e:
        logger.error(str(e))
        raise InternalServerError(str(e))
    # Move any 'current' file(s) to 'archived' status
    latest_version = PreprocessedFiles.archive_current_files(pending_file.file_category, pending_file.job_id)
    # Insert new current/versioned DB record
    PreprocessedFiles.create(
        file_name=original_filename,
        object_url=new_gcs_path,
        file_category=pending_file.file_category,
        uploader_email=get_current_user().email,
        status="current",
        job_id=pending_file.job_id,
        version=latest_version + 1,
    )
    # Delete pending record
    pending_file.delete()
    return new_gcs_path


def strip_filename_and_pending_folder(path_str):
    """Returns the file path above the 'pending' folder to be used for versioned files."""
    path = Path(path_str)
    if path.parent.name != "pending":
        raise ValueError("Expected 'pending' folder above file")
    return str(path.parent.parent)


def get_row_at_condition(df: DataFrame, condition):
    condition_met_index = df[condition].index[0]
    row_at_condition_series = df.iloc[condition_met_index]

    return row_at_condition_series


def get_column(header_row_series: Series, header_name: str, use_raw_header_val: bool = False):
    for idx, raw_header in enumerate(header_row_series):
        if str(raw_header).lower() == header_name.lower():
            return raw_header if use_raw_header_val else header_row_series.index[idx]
    return None


def get_column_from_appendix_a(appendix_a_df: DataFrame, header_name: str):
    category_column = appendix_a_df.columns[0]
    aa_header_condition = appendix_a_df[category_column] == TRIAL_APPENDIX_A_CELL_THAT_ENDS_THE_HEADER
    header_row_series = get_row_at_condition(appendix_a_df, aa_header_condition)
    return get_column(header_row_series, header_name)


def get_column_from_first_row(df: DataFrame, header_name: str):
    use_raw_header_val = False
    if df.columns.inferred_type == "integer":
        # If columns are integers (i.e. file was read without headers), treat the first row as header values.
        header_row_series = df.iloc[0]
    else:
        # Otherwise columns already are headers
        header_row_series = Series(df.columns)
        use_raw_header_val = True

    return get_column(header_row_series, header_name, use_raw_header_val=use_raw_header_val)


def generate_clinical_data_files(files: List[DownloadableFiles], write_dir: str):
    """
    Generates clinical data CSVs based on a list of DownloadableFiles objects.

    Files are grouped by trial/version to load each dataset only once,
    then writes the requested clinical data to timestamped CSV files.
    """
    is_admin_user = get_current_user().is_admin()
    # Group the files by (trial_id, trial_version) and collect the requested data categories and object_urls for each group.
    trials_to_process = defaultdict(dict)
    for file in files:
        trial_id = file.trial_id
        # Get required metadata from JSON metadata.
        trial_version = file.additional_metadata.get("trial_version")
        data_category = file.additional_metadata.get("data_category")
        if trial_id and trial_version and data_category:
            key = (trial_id, trial_version)
            trials_to_process[key][data_category] = file.object_url
        else:
            logger.error(f"Skipping file ID '{file.id}' due to missing expected metadata.")

    # Iterate through each unique (trial_id, version) group and generate the requested files.
    for (trial_id, version), requested_files_map in trials_to_process.items():
        process_trial_to_csv(trial_id, version, requested_files_map, is_admin_user, write_dir)


@with_default_session
def process_trial_to_csv(
    trial_id: str, version: str, requested_files_map: dict, is_admin_user: bool, write_dir: str, session
):
    """Loads a clinical dataset and generates all requested CSV files for a single trial/version."""
    logger.info(f"Loading dataset for Trial: {trial_id}, Version: {version}")
    clinical_db_dataset = Dataset(trial_id, version, Stages.STAGE2)
    clinical_db_dataset.load(session)
    clinical_model_dataset = clinical_db_dataset.to_dataset()
    part_id_index = clinical_db_dataset.build_index_for("participant_id")
    timestamp = datetime.now().isoformat(timespec="seconds").replace(":", "-")

    # Iterate through the categories requested for this specific dataset.
    for data_category, filename in requested_files_map.items():
        clinical_models = clinical_model_dataset.get(data_category)
        if not clinical_models:
            logger.error(f"No clinical data found for category '{data_category}' in trial '{trial_id}'.")
            continue

        # Add timestamp to output filename.
        file_base, file_extension = os.path.splitext(filename.replace("/", "_"))
        output_filename = os.path.join(write_dir, f"{file_base}_{timestamp}{file_extension}")

        excluded_columns = {f"{data_category}_id", "trial_id", "version", "participant_id", "native_participant_id"}
        records_for_df = []

        # Build records/rows for CSV file.
        for clinical_model in clinical_models:
            record = clinical_model.model_dump()
            if record.get("participant_id"):
                handle_cimac_part_id(record, data_category, part_id_index)
                # TODO Implement filter for assay matching cimac_part_id (CIDC-4020)
                if not record.get("cimac_part_id") and not is_admin_user:
                    # Don't include records that don't have a CIMAC Participant ID (for non-admin users).
                    continue

            # Remove any keys in excluded_columns from the dict to ensure not included in csv.
            record = {key: value for key, value in record.items() if key not in excluded_columns}
            records_for_df.append(record)

        if records_for_df:
            # Write the data to CSV
            df = DataFrame(records_for_df)
            df.to_csv(output_filename, index=False)


def handle_cimac_part_id(record: dict, data_category: str, part_id_index: Mapping):
    """Looks up and assigns the 'cimac_part_id' to a record (if exists)."""
    if data_category == "participant":
        # cimac_participant_id is already on participant records, just rename to cimac_part_id
        record["cimac_part_id"] = record.pop("cimac_participant_id")
    else:
        # Look for and add CIMAC Participant ID from correlated part_id_index
        participant_details = part_id_index.get(record["participant_id"])
        if participant_details:
            record["cimac_part_id"] = getattr(participant_details.get("participant")[0], "cimac_participant_id", None)
        else:
            logger.warning(f"Could not find participant_id {record["participant_id"]} in index")
            record["cimac_part_id"] = None
