from __future__ import annotations
from typing import List
from datetime import datetime

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from cidc_api.models.db.stage2.base_orm import BaseORM
from cidc_api.models.types import AssayType, TrialOrganization, TrialFundingAgency, AgeGroup, PrimaryPurposeType


class TrialORM(BaseORM):
    __tablename__ = "trial"
    __repr_attrs__ = ["trial_id", "version"]
    __data_category__ = "trial"

    trial_id: Mapped[str] = mapped_column(primary_key=True)
    version: Mapped[str] = mapped_column(primary_key=True)

    primary_endpoint: Mapped[str | None]
    master_aa_version: Mapped[int | None]
    age_group: Mapped[List[AgeGroup]] = mapped_column(JSON, nullable=True)
    study_population: Mapped[str | None]
    nct_id: Mapped[str | None]
    nci_id: Mapped[str | None]
    trial_name: Mapped[str | None]
    trial_type: Mapped[str | None]
    trial_description: Mapped[str | None]
    trial_organization: Mapped[TrialOrganization | None]
    grant_or_affiliated_network: Mapped[TrialFundingAgency | None]
    biobank_institution_id: Mapped[int | None]
    justification: Mapped[str | None]
    dates_of_conduct_start: Mapped[datetime]
    dates_of_conduct_end: Mapped[datetime | None]
    schema_file_id: Mapped[int | None]
    biomarker_plan: Mapped[str | None]
    data_sharing_plan: Mapped[str | None]
    expected_assays: Mapped[List[AssayType]] = mapped_column(JSON, nullable=True)
    primary_purpose_type: Mapped[PrimaryPurposeType]
    dbgap_study_accession: Mapped[str | None]

    additional_treatments: Mapped[List[AdditionalTreatmentORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    adverse_events: Mapped[List[AdverseEventORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    administrative_people: Mapped[List[AdministrativePersonORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    administrative_role_assignments: Mapped[List[AdministrativeRoleAssignmentORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    arms: Mapped[List[ArmORM]] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    baseline_clinical_assessments: Mapped[List[BaselineClinicalAssessmentORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    biobank: Mapped[InstitutionORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    cohorts: Mapped[List[CohortORM]] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    comorbidities: Mapped[ComorbidityORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    contacts: Mapped[ContactORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    consent_groups: Mapped[List[ConsentGroupORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    custom_data: Mapped[List[CustomDataORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    demographics: Mapped[DemographicORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    diseases: Mapped[DiseaseORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    exposures: Mapped[ExposureORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    files: Mapped[List[FileORM]] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    gvhd_diagnosis_acutes: Mapped[GVHDDiagnosisAcuteORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    gvhd_diagnosis_chronics: Mapped[GVHDDiagnosisChronicORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    gvhd_organ_acutes: Mapped[GVHDOrganAcuteORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    gvhd_organ_chronics: Mapped[GVHDOrganChronicORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    medical_histories: Mapped[MedicalHistoryORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    other_clinical_endpoints: Mapped[List[OtherClinicalEndpointORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    other_malignancies: Mapped[OtherMalignancyORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    participants: Mapped[List[ParticipantORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    prior_treatments: Mapped[PriorTreatmentORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    publications: Mapped[List[PublicationORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    radiotherapy_doses: Mapped[RadiotherapyDoseORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    responses: Mapped[ResponseORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    response_by_systems: Mapped[ResponseBySystemORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    schema: Mapped[FileORM | None] = relationship(back_populates="trial", viewonly=True)
    shipments: Mapped[List[ShipmentORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    shipment_specimens: Mapped[List[ShipmentSpecimenORM]] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    specimens: Mapped[SpecimenORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    stem_cell_transplants: Mapped[StemCellTransplantORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    surgeries: Mapped[SurgeryORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
    therapy_agent_doses: Mapped[TherapyAgentDoseORM] = relationship(
        back_populates="trial", cascade="all, delete", passive_deletes=True
    )
    treatments: Mapped[TreatmentORM] = relationship(back_populates="trial", cascade="all, delete", passive_deletes=True)
