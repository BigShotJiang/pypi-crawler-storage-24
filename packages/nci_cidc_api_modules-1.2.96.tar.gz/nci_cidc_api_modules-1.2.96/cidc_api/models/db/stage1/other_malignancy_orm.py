from __future__ import annotations

from pydantic import NonPositiveInt
from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.icdo3 import MorphologicalCode, MorphologicalTerm
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.code_systems.uberon import UberonAnatomicalTerm
from cidc_api.models.types import MalignancyStatus


class OtherMalignancyORM(BaseORM):
    __tablename__ = "other_malignancy"
    __repr_attrs__ = ["other_malignancy_id", "other_malignancy_primary_disease_site"]
    __data_category__ = "other_malignancy"
    __exclude_during_promotion__ = ["other_malignancy_id", "participant_id", "medical_history_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    other_malignancy_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))
    medical_history_id: Mapped[int] = mapped_column(
        ForeignKey("stage1.medical_history.medical_history_id", ondelete="CASCADE")
    )

    native_participant_id: Mapped[str]
    other_malignancy_primary_disease_site: Mapped[UberonAnatomicalTerm]
    other_malignancy_morphological_code: Mapped[MorphologicalCode | None]
    other_malignancy_morphological_term: Mapped[MorphologicalTerm | None]
    other_malignancy_description: Mapped[str | None]
    other_malignancy_days_since_diagnosis: Mapped[NonPositiveInt | None]
    other_malignancy_status: Mapped[MalignancyStatus | None]

    trial: Mapped[TrialORM] = relationship(back_populates="other_malignancies", cascade="all, delete")
    medical_history: Mapped[MedicalHistoryORM] = relationship(
        back_populates="other_malignancies", cascade="all, delete"
    )
    participant: Mapped[ParticipantORM] = relationship(back_populates="other_malignancies", cascade="all, delete")
