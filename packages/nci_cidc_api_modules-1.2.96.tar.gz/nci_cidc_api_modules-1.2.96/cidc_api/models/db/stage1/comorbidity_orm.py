from __future__ import annotations

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.icd10cm import ComorbidityCode, ComorbidityTerm
from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM


class ComorbidityORM(BaseORM):
    __tablename__ = "comorbidity"
    __repr_attrs__ = ["comorbidity_id", "comorbidity_term"]
    __data_category__ = "comorbidity"
    __exclude_during_promotion__ = ["comorbidity_id", "medical_history_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    comorbidity_id: Mapped[int] = mapped_column(primary_key=True)
    medical_history_id: Mapped[int] = mapped_column(
        ForeignKey("stage1.medical_history.medical_history_id", ondelete="CASCADE")
    )
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    comorbidity_code: Mapped[ComorbidityCode | None]
    comorbidity_term: Mapped[ComorbidityTerm | None]
    comorbidity_other: Mapped[str | None]

    trial: Mapped[TrialORM] = relationship(back_populates="comorbidities", cascade="all, delete")
    medical_history: Mapped[MedicalHistoryORM] = relationship(back_populates="comorbidities", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="comorbidities", cascade="all, delete")
