from __future__ import annotations
from typing import List

from pydantic import NonNegativeInt
from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM


class ConsentGroupORM(BaseORM):
    __tablename__ = "consent_group"
    __repr_attrs__ = ["consent_group_id", "consent_group_name"]
    __data_category__ = "consent_group"
    __exclude_during_promotion__ = ["consent_group_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    consent_group_id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    native_participant_id: Mapped[str]
    consent_group_short_name: Mapped[str]
    consent_group_name: Mapped[str]
    consent_group_number: Mapped[NonNegativeInt]

    trial: Mapped[TrialORM] = relationship(back_populates="consent_groups", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(
        back_populates="consent_group", foreign_keys=[participant_id], cascade="all, delete"
    )
