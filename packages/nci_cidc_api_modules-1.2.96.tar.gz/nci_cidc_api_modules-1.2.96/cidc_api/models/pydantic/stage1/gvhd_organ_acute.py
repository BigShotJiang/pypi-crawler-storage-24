from typing import get_args

from cidc_api.code_systems.other import (
    Organ,
    OrganAcuteStage,
    _OrganAcuteStageMagic,
    _OrganAcuteStageModifiedGlucksberg,
)
from cidc_api.models.errors import ValueLocError
from cidc_api.models.pydantic.base import Base, forced_validator, forced_validators
from cidc_api.models.types import PreOrPostEnrollment


@forced_validators
class GVHDOrganAcute(Base):
    __data_category__ = "gvhd_organ_acute"
    __cardinality__ = "many"

    # The unique internal identifier for the GVHD Organ Acute Record
    gvhd_organ_acute_id: int | None = None

    # The unique internal identifier for the associated GVHD Diagnosis Acute record
    gvhd_diagnosis_acute_id: int | None = None

    # The unique internal identifier of the associated participant
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # An organ affected by acute GVHD for which the stage is assessed as part of the overall acute GVHD evaluation.
    organ: Organ

    # The severity level of an individual organ’s involvement in acute GVHD, usually scored from 0 (none) to 4 (severe).
    acute_stage: OrganAcuteStage

    # Indicator for whether the acute GVHD diagnosis was made before or after trial enrollment.
    pre_or_post_enrollment: PreOrPostEnrollment

    @forced_validator
    @classmethod
    def validate_acute_stage(cls, data, info) -> None:
        acute_assessment_system = data.get("acute_assessment_system", None)
        acute_stage = data.get("acute_stage", None)

        msg = f"'{acute_stage}' is not applicable to '{acute_assessment_system}'"
        if acute_assessment_system == "MAGIC" and acute_stage not in get_args(_OrganAcuteStageMagic):
            raise ValueLocError(msg, loc="acute_stage")
        elif acute_assessment_system == "Modified Glucksberg" and acute_stage not in get_args(
            _OrganAcuteStageModifiedGlucksberg
        ):
            raise ValueLocError(msg, loc="acute_stage")
