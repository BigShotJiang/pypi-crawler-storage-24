from cidc_api.code_systems.icd10cm import ComorbidityCode, ComorbidityTerm, validate_code_term_match
from cidc_api.models.errors import ValueLocError
from cidc_api.models.pydantic.base import Base, forced_validator, forced_validators


@forced_validators
class Comorbidity(Base):
    __data_category__ = "comorbidity"
    __cardinality__ = "many"

    # The unique internal identifier for the comorbidity record
    comorbidity_id: int | None = None

    # The unique internal identifier for the associated MedicalHistory record
    medical_history_id: int | None = None

    # The unique internal identifier of the associated participant
    participant_id: int | None = None

    # The unique external identifier assigned by the trial that identifies the participant
    native_participant_id: str

    # The diagnosis, in humans, as captured in the tenth version of the
    # International Classification of Disease (ICD-10-CM, the disease code subset of ICD-10).
    comorbidity_code: ComorbidityCode | None = None

    # The words from the tenth version of the International Classification of Disease (ICD-10-CM,
    # the disease subset of ICD-10) used to identify the diagnosis in humans.
    comorbidity_term: ComorbidityTerm | None = None

    # A descriptive string that names or briefly describes the comorbidity.
    comorbidity_other: str | None = None

    @forced_validator
    @classmethod
    def validate_code_or_term_or_other_cr(cls, data, info) -> None:
        comorbidity_term = data.get("comorbidity_term", None)
        comorbidity_other = data.get("comorbidity_other", None)
        comorbidity_code = data.get("comorbidity_code", None)

        if not comorbidity_code and not comorbidity_term and not comorbidity_other:
            raise ValueLocError(
                'Please provide at least one of "comorbidity_code", "comorbidity_term" or "comorbidity_other".',
                loc="comorbidity_code,comorbidity_term,comorbidity_other",
            )

    @forced_validator
    @classmethod
    def validate_comorbidity_code_term_match(cls, data, info) -> None:
        code = data.get("comorbidity_code")
        term = data.get("comorbidity_term")

        if code is None or term is None:
            return

        try:
            validate_code_term_match(code, term)
        except ValueError as e:
            raise ValueLocError(str(e), loc="comorbidity_term") from e
