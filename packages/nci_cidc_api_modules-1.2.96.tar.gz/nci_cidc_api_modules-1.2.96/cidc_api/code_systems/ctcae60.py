from typing import Annotated, Literal

from pydantic import AfterValidator

from cidc_api.code_systems.sqlite_store import get_conn as _conn


def is_valid_code(v: str) -> str:
    if _conn().execute("SELECT 1 FROM ctcae60 WHERE code = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid CTCAE 6.0 code")

    return v


def is_valid_term(v: str) -> str:
    if _conn().execute("SELECT 1 FROM ctcae60 WHERE term = ?", (v,)).fetchone() is None:
        raise ValueError(f"'{v}' is not a valid CTCAE 6.0 term")

    return v


def validate_code_term_match(code: str, term: str) -> None:
    row = _conn().execute("SELECT term FROM ctcae60 WHERE code = ?", (code,)).fetchone()

    # row is None when the code doesn't exist — already rejected by is_valid_code
    if row is not None and row[0] != term:
        raise ValueError(f"code '{code}' does not match term '{term}'")


# Determines if the CTCAE term is one of the "Other, specify" types of terms
# for which we include additional data about the AE.
def is_other_term(v) -> bool:
    if isinstance(v, str):
        return "Other, specify" in v

    return False


SeverityGradeSystem = Literal["CTCAE"]
SeverityGradeSystemVersion = Literal["5.0", "6.0"]
SeverityGrade = Literal["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5"]

EventCode = Annotated[str, AfterValidator(is_valid_code)]
EventTerm = Annotated[str, AfterValidator(is_valid_term)]

SystemOrganClass = Literal[
    "Blood and lymphatic system disorders",
    "Cardiac disorders",
    "Congenital, familial and genetic disorders",
    "Ear and labyrinth disorders",
    "Endocrine disorders",
    "Eye disorders",
    "Gastrointestinal disorders",
    "General disorders and administration site conditions",
    "Hepatobiliary disorders",
    "Immune system disorders",
    "Infections and infestations",
    "Injury, poisoning and procedural complications",
    "Investigations",
    "Metabolism and nutrition disorders",
    "Musculoskeletal and connective tissue disorders",
    "Neoplasms benign, malignant and unspecified (incl cysts and polyps)",
    "Nervous system disorders",
    "Pregnancy, puerperium and perinatal conditions",
    "Psychiatric disorders",
    "Renal and urinary disorders",
    "Reproductive system and breast disorders",
    "Respiratory, thoracic and mediastinal disorders",
    "Skin and subcutaneous tissue disorders",
    "Social circumstances",
    "Surgical and medical procedures",
    "Vascular disorders",
]
