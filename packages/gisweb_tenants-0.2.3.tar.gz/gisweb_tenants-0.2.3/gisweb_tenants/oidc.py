from .models import TenantConfig, OidcBffConfig, OidcSharedSettings

def resolve_oidc_config(
    tenant_cfg: TenantConfig,
    shared: OidcSharedSettings,
) -> OidcBffConfig:
    
    if not tenant_cfg.oidc:
        raise ValueError(
            f"bff_oidc mancante per tenant '{tenant_cfg.tenant}'"
        )

    realm = tenant_cfg.oidc.realm
    issuer = f"{shared.base_url.rstrip('/')}/{realm}"

    tenant_public = tenant_cfg.oidc.public_base_url
    public = (tenant_public or shared.public_base_url).rstrip("/")
    
    return OidcBffConfig(
        realm=realm,
        issuer=issuer,
        authorization_endpoint=f"{issuer}/protocol/openid-connect/auth",
        token_endpoint=f"{issuer}/protocol/openid-connect/token",
        revocation_endpoint=f"{issuer}/protocol/openid-connect/revoke",
        end_session_endpoint=f"{issuer}/protocol/openid-connect/logout",
        jwks_uri=f"{issuer}/protocol/openid-connect/certs",
        client_id=shared.client_id,
        redirect_uri=f"{public}/",
        post_logout_redirect_uri=f"{public}/",
        scope=shared.scope,
        token_endpoint_auth_method=shared.auth_method,
    )