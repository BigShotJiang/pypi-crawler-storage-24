"""
DfGUI v2.0 – современная и простая GUI-библиотека на основе tkinter/ttk.
Поддерживает темы, продвинутые виджеты, автоматическое DPI-масштабирование.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser, font
import ctypes
import sys

# ========== Глобальные переменные ==========
_current_window = None  # для автоматического родителя

# ========== Настройка DPI ==========
def DPI(scale_factor=None):
    """Настраивает масштабирование под DPI экрана."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
        if scale_factor is None:
            hwnd = ctypes.windll.user32.GetDesktopWindow()
            dpi = ctypes.windll.user32.GetDpiForWindow(hwnd)
            scale_factor = dpi / 96.0
    except:
        scale_factor = scale_factor or 1.0
    root = tk.Tk()
    root.tk.call('tk', 'scaling', scale_factor)
    root.destroy()
    return scale_factor

# ========== Базовый класс для всех виджетов ==========
class Widget:
    def __init__(self, parent=None, **kwargs):
        global _current_window
        if parent is None:
            parent = _current_window
        self.parent = parent
        self.widget = None
        self._create_widget(**kwargs)

    def _create_widget(self, **kwargs):
        # Должен быть переопределён в подклассах
        pass

    def pack(self, **kwargs):
        if self.widget:
            self.widget.pack(**kwargs)
        return self

    def grid(self, **kwargs):
        if self.widget:
            self.widget.grid(**kwargs)
        return self

    def place(self, **kwargs):
        if self.widget:
            self.widget.place(**kwargs)
        return self

    def configure(self, **kwargs):
        if self.widget:
            self.widget.configure(**kwargs)
        return self

    def bind(self, event, callback):
        if self.widget:
            self.widget.bind(event, callback)
        return self

    def destroy(self):
        if self.widget:
            self.widget.destroy()

# ========== Виджеты ==========
class Window(Widget):
    """Главное окно приложения."""
    def __init__(self, title="DfGUI App", width=800, height=600, resizable=(True, True)):
        global _current_window
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry(f"{width}x{height}")
        self.root.resizable(*resizable)
        self._current_layout = 'pack'  # pack, grid, place
        _current_window = self
        self.children = []
        self.menubar = None
        self.statusbar = None
        self.toolbar = None

    def _create_widget(self, **kwargs):
        pass  # для совместимости

    def add(self, widget, **pack_options):
        """Добавляет виджет с упаковкой pack."""
        widget.pack(**pack_options)
        self.children.append(widget)
        return widget

    def grid_add(self, widget, **grid_options):
        """Добавляет виджет с сеткой."""
        widget.grid(**grid_options)
        self.children.append(widget)
        return widget

    def place_add(self, widget, **place_options):
        """Добавляет виджет с абсолютным позиционированием."""
        widget.place(**place_options)
        self.children.append(widget)
        return widget

    def set_layout(self, layout):
        self._current_layout = layout

    def center(self):
        """Центрирует окно на экране."""
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() - self.root.winfo_width()) // 2
        y = (self.root.winfo_screenheight() - self.root.winfo_height()) // 2
        self.root.geometry(f"+{x}+{y}")

    def fullscreen(self, enable=True):
        self.root.attributes('-fullscreen', enable)

    def run(self):
        self.root.mainloop()

    def close(self):
        self.root.quit()

    # ========== Меню ==========
    def create_menubar(self):
        self.menubar = tk.Menu(self.root)
        self.root.config(menu=self.menubar)
        return Menu(self.menubar)

    def create_statusbar(self, text=""):
        self.statusbar = ttk.Label(self.root, text=text, relief=tk.SUNKEN, anchor=tk.W)
        self.statusbar.pack(side=tk.BOTTOM, fill=tk.X)
        return self.statusbar

    def create_toolbar(self):
        self.toolbar = ttk.Frame(self.root)
        self.toolbar.pack(side=tk.TOP, fill=tk.X)
        return self.toolbar

class Label(Widget):
    def _create_widget(self, text="", font=("Segoe UI", 10), fg="black", bg=None, **kwargs):
        self.widget = ttk.Label(self.parent.root, text=text, font=font, foreground=fg, background=bg, **kwargs)

class Button(Widget):
    def _create_widget(self, text="", command=None, style=None, **kwargs):
        self.widget = ttk.Button(self.parent.root, text=text, command=command, style=style, **kwargs)

class Entry(Widget):
    def _create_widget(self, width=30, font=("Segoe UI", 10), show=None, **kwargs):
        self.widget = ttk.Entry(self.parent.root, width=width, font=font, show=show, **kwargs)

    def get(self):
        return self.widget.get()

    def set(self, value):
        self.widget.delete(0, tk.END)
        self.widget.insert(0, value)

class Checkbox(Widget):
    def _create_widget(self, text="", variable=None, **kwargs):
        if variable is None:
            variable = tk.BooleanVar()
        self.widget = ttk.Checkbutton(self.parent.root, text=text, variable=variable, **kwargs)

class Radio(Widget):
    def _create_widget(self, text="", variable=None, value=0, **kwargs):
        self.widget = ttk.Radiobutton(self.parent.root, text=text, variable=variable, value=value, **kwargs)

class Combobox(Widget):
    def _create_widget(self, values=[], width=20, **kwargs):
        self.widget = ttk.Combobox(self.parent.root, values=values, width=width, **kwargs)
        self.widget.set(values[0] if values else "")

    def get(self):
        return self.widget.get()

    def set(self, value):
        self.widget.set(value)

class Spinbox(Widget):
    def _create_widget(self, from_=0, to=100, width=10, **kwargs):
        self.widget = ttk.Spinbox(self.parent.root, from_=from_, to=to, width=width, **kwargs)

    def get(self):
        return self.widget.get()

class Listbox(Widget):
    def _create_widget(self, height=5, width=30, **kwargs):
        self.widget = tk.Listbox(self.parent.root, height=height, width=width, **kwargs)

    def insert(self, index, *items):
        for item in items:
            self.widget.insert(index, item)

    def get_selected(self):
        sel = self.widget.curselection()
        if sel:
            return self.widget.get(sel[0])
        return None

class Treeview(Widget):
    def _create_widget(self, columns=[], show="headings", height=10, **kwargs):
        self.widget = ttk.Treeview(self.parent.root, columns=columns, show=show, height=height, **kwargs)
        for col in columns:
            self.widget.heading(col, text=col)

    def insert(self, parent="", index="end", values=[]):
        return self.widget.insert(parent, index, values=values)

    def clear(self):
        for item in self.widget.get_children():
            self.widget.delete(item)

class Progressbar(Widget):
    def _create_widget(self, orient=tk.HORIZONTAL, length=200, mode='determinate', **kwargs):
        self.widget = ttk.Progressbar(self.parent.root, orient=orient, length=length, mode=mode, **kwargs)

    def start(self, interval=10):
        self.widget.start(interval)

    def stop(self):
        self.widget.stop()

    def step(self, amount=1):
        self.widget.step(amount)

class Slider(Widget):
    def _create_widget(self, from_=0, to=100, orient=tk.HORIZONTAL, command=None, **kwargs):
        self.widget = ttk.Scale(self.parent.root, from_=from_, to=to, orient=orient, command=command, **kwargs)

    def get(self):
        return self.widget.get()

    def set(self, value):
        self.widget.set(value)

class TextArea(Widget):
    def _create_widget(self, height=10, width=50, wrap=tk.WORD, **kwargs):
        self.widget = tk.Text(self.parent.root, height=height, width=width, wrap=wrap, **kwargs)

    def insert(self, text):
        self.widget.insert(tk.END, text)

    def get(self):
        return self.widget.get(1.0, tk.END)

    def clear(self):
        self.widget.delete(1.0, tk.END)

class ScrolledText(TextArea):
    def _create_widget(self, height=10, width=50, wrap=tk.WORD, **kwargs):
        import tkinter.scrolledtext as st
        self.widget = st.ScrolledText(self.parent.root, height=height, width=width, wrap=wrap, **kwargs)

class Canvas(Widget):
    def _create_widget(self, width=200, height=200, bg="white", **kwargs):
        self.widget = tk.Canvas(self.parent.root, width=width, height=height, bg=bg, **kwargs)

    def create_rectangle(self, *args, **kwargs):
        return self.widget.create_rectangle(*args, **kwargs)

    def create_oval(self, *args, **kwargs):
        return self.widget.create_oval(*args, **kwargs)

    def create_line(self, *args, **kwargs):
        return self.widget.create_line(*args, **kwargs)

    def create_text(self, *args, **kwargs):
        return self.widget.create_text(*args, **kwargs)

    def delete(self, item):
        self.widget.delete(item)

class Frame(Widget):
    def _create_widget(self, relief=tk.FLAT, borderwidth=0, **kwargs):
        self.widget = ttk.Frame(self.parent.root, relief=relief, borderwidth=borderwidth, **kwargs)
        self.children = []

    def add(self, widget, **pack_options):
        widget.pack(**pack_options)
        self.children.append(widget)
        return widget

    def grid_add(self, widget, **grid_options):
        widget.grid(**grid_options)
        self.children.append(widget)
        return widget

class Notebook(Widget):
    def _create_widget(self, **kwargs):
        self.widget = ttk.Notebook(self.parent.root, **kwargs)
        self.tabs = []

    def add_tab(self, title, frame):
        self.widget.add(frame.widget, text=title)
        self.tabs.append(frame)

class Menu(Widget):
    def _create_widget(self, parent_menu=None, tearoff=0, **kwargs):
        self.widget = tk.Menu(parent_menu, tearoff=tearoff, **kwargs)

    def add_command(self, label, command, **kwargs):
        self.widget.add_command(label=label, command=command, **kwargs)

    def add_cascade(self, label, menu, **kwargs):
        self.widget.add_cascade(label=label, menu=menu.widget, **kwargs)

    def add_separator(self):
        self.widget.add_separator()

class Tab(Frame):
    """Просто алиас для Frame, чтобы использовать в Notebook"""
    pass

# ========== Диалоги ==========
def message_box(title, message, type="info"):
    if type == "info":
        messagebox.showinfo(title, message)
    elif type == "warning":
        messagebox.showwarning(title, message)
    elif type == "error":
        messagebox.showerror(title, message)
    elif type == "yesno":
        return messagebox.askyesno(title, message)
    elif type == "okcancel":
        return messagebox.askokcancel(title, message)
    elif type == "retrycancel":
        return messagebox.askretrycancel(title, message)
    return None

def open_file(title="Выберите файл", filetypes=[("All files", "*.*")]):
    return filedialog.askopenfilename(title=title, filetypes=filetypes)

def save_file(title="Сохранить файл", filetypes=[("All files", "*.*")]):
    return filedialog.asksaveasfilename(title=title, filetypes=filetypes)

def select_folder(title="Выберите папку"):
    return filedialog.askdirectory(title=title)

def choose_color(title="Выберите цвет"):
    return colorchooser.askcolor(title=title)[1]

def choose_font():
    return font.asksaveasfilename()  # font.askfont() – возвращает словарь

# ========== Темы ==========
_themes = {
    "light": {
        "bg": "#f0f0f0",
        "fg": "#000000",
        "select_bg": "#0078d7",
        "select_fg": "white",
    },
    "dark": {
        "bg": "#2d2d2d",
        "fg": "#ffffff",
        "select_bg": "#1a73e8",
        "select_fg": "white",
    }
}

def set_theme(theme_name):
    """Применяет тему ко всем будущим окнам (ttk style)."""
    style = ttk.Style()
    style.theme_use('clam')
    colors = _themes.get(theme_name, _themes["light"])
    style.configure('.', background=colors['bg'], foreground=colors['fg'])
    style.configure('TLabel', background=colors['bg'], foreground=colors['fg'])
    style.configure('TButton', background=colors['bg'], foreground=colors['fg'])
    style.map('TButton', background=[('active', colors['select_bg'])])
    style.configure('TEntry', fieldbackground=colors['bg'], foreground=colors['fg'])
    style.configure('TCombobox', fieldbackground=colors['bg'], foreground=colors['fg'])
    style.configure('TSpinbox', fieldbackground=colors['bg'], foreground=colors['fg'])
    style.configure('TFrame', background=colors['bg'])
    style.configure('TNotebook', background=colors['bg'])
    style.configure('TNotebook.Tab', background=colors['bg'], foreground=colors['fg'])
    style.map('TNotebook.Tab', background=[('selected', colors['select_bg'])])
    style.configure('TProgressbar', troughcolor=colors['bg'], background=colors['select_bg'])
    style.configure('TScale', background=colors['bg'], troughcolor=colors['select_bg'])
    style.configure('Treeview', background=colors['bg'], foreground=colors['fg'], fieldbackground=colors['bg'])
    style.configure('Treeview.Heading', background=colors['bg'], foreground=colors['fg'])

# ========== Горячие клавиши ==========
def bind_shortcut(window, key, callback):
    window.root.bind_all(f"<{key}>", lambda e: callback())

# ========== Утилиты ==========
def run_app(window):
    window.run()

# ========== Экспорт ==========
__all__ = [
    'DPI',
    'Window',
    'Label',
    'Button',
    'Entry',
    'Checkbox',
    'Radio',
    'Combobox',
    'Spinbox',
    'Listbox',
    'Treeview',
    'Progressbar',
    'Slider',
    'TextArea',
    'ScrolledText',
    'Canvas',
    'Frame',
    'Notebook',
    'Tab',
    'Menu',
    'message_box',
    'open_file',
    'save_file',
    'select_folder',
    'choose_color',
    'choose_font',
    'set_theme',
    'bind_shortcut',
    'run_app'
]