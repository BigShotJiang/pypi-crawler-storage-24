# materializer - SQL compute delegation via query interception
# https://github.com/damiandelmas/materializer
"""
Materializer intercepts pseudo-functions in SQL queries, dispatches
computation to external engines, materializes results as temp tables,
and rewrites the query before handing it back to SQLite.
"""

__version__ = "0.1.0"
