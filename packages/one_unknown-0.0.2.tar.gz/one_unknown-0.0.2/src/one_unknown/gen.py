def add(a, b):
    return a + b


def multiply(a, b):
    return a * b


def greet(name):
    return f"Hello {name}, welcome to my PyPI package!"