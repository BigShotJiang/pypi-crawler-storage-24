# chatbot/entrypoints/aws_lambda.py
"""
AWS Lambda handler for pdf-autofillr-chatbot.

Lambda handler string:
    chatbot.entrypoints.aws_lambda.handler

Config is read from config.ini (bundled in deployment package) then
environment variables set on the Lambda function (which override config.ini).

Expected event format:
    {
        "user_id":    "investor_123",
        "session_id": "session_abc",
        "message":    "my name is John Smith",
        "pdf_path":   "s3://your-bucket/blank_form.pdf"   # optional override
    }
"""
from __future__ import annotations

import json
import logging
import os

from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger(__name__)

# Client is module-level — persists across warm Lambda invocations
_client = None
_validated = False


def _init_client():
    global _client, _validated

    from chatbot.config.settings import Settings
    from chatbot.config.validator import validate_for_entrypoint

    settings = Settings(validate=False)

    if not _validated:
        validate_for_entrypoint("lambda", settings)
        _validated = True

    from chatbot import chatbotClient, LocalStorage, S3Storage, FormConfig

    if settings.storage_type == "s3":
        storage = S3Storage(
            output_bucket=settings.s3_output_bucket,
            config_bucket=settings.s3_config_bucket,
            region=settings.s3_region,
        )
        form_config = FormConfig.from_storage(storage)
    else:
        # local in Lambda — /tmp is ephemeral, but allowed
        storage = LocalStorage(
            data_path=settings.data_path if settings.data_path != "./chatbot_data"
                       else "/tmp/chatbot_data",
            config_path=settings.config_path,
        )
        form_config = FormConfig.from_directory(settings.config_path)

    pdf_filler = None
    if settings.pdf_filler_enabled:
        if settings.pdf_filler_provider == "mapper":
            from chatbot.pdf.mapper_filler import MapperPDFFiller
            pdf_filler = MapperPDFFiller(
                mapper_api_url=settings.mapper_api_url,
                mapper_api_key=settings.mapper_api_key,
            )
        elif settings.pdf_filler_provider == "managed":
            from chatbot_managed.filler import chatbotManagedPDFFiller
            pdf_filler = chatbotManagedPDFFiller(
                auth0_domain=os.environ["AUTH0_DOMAIN"],
                auth0_client_id=os.environ["AUTH0_CLIENT_ID"],
                auth0_client_secret=os.environ["AUTH0_CLIENT_SECRET"],
                auth0_audience=os.environ["AUTH0_AUDIENCE"],
                pdf_lambda_url=os.environ["FILL_PDF_LAMBDA_URL"],
                pdf_api_key=os.environ["PDF_API_KEY"],
                backend_url=os.getenv("BACKEND_URL", ""),
                auth_token=os.getenv("AUTH_TOKEN", ""),
            )

    _client = chatbotClient(
        openai_api_key=settings.openai_api_key,
        storage=storage,
        form_config=form_config,
        pdf_filler=pdf_filler,
        settings=settings,
    )


def handler(event, context):
    global _client
    try:
        if _client is None:
            _init_client()

        user_id    = event["user_id"]
        session_id = event["session_id"]
        message    = event.get("message", "")

        from chatbot.config.settings import Settings
        s = Settings(validate=False)
        pdf_path = event.get("pdf_path") or s.pdf_path

        if pdf_path:
            _client.create_session(user_id, session_id, pdf_path=pdf_path)

        response, complete, data = _client.send_message(user_id, session_id, message)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "user_id": user_id,
                "session_id": session_id,
                "response": response,
                "session_complete": complete,
                "filled_data": data if complete else None,
            }),
        }

    except KeyError as e:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Missing required field: {e}"}),
        }
    except Exception as e:
        logger.exception("Lambda handler error")
        # Reset client on error so cold-start reinitialises on next invocation
        _client = None
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
        }