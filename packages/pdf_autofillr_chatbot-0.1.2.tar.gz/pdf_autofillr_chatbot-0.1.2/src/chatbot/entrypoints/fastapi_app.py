# chatbot/entrypoints/fastapi_app.py
"""
FastAPI app for pdf-autofillr-chatbot.

Standalone:
    chatbot-server

Mount in your existing app:
    from chatbot.entrypoints.fastapi_app import app as chatbot_app
    main_app.mount("/onboarding", chatbot_app)

All config is read from config.ini + .env — no env var wrangling needed here.
"""
from __future__ import annotations

import logging
from typing import Optional

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from chatbot import chatbotClient, LocalStorage, S3Storage, FormConfig
from chatbot.config.settings import Settings
from chatbot.limits import RateLimitExceeded

logger = logging.getLogger(__name__)

app = FastAPI(
    title="pdf-autofillr-chatbot API",
    description="Conversational investor onboarding — collects data and fills PDF forms.",
    version="0.1.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Client singleton ──────────────────────────────────────────────────────────

_client: Optional[chatbotClient] = None
_settings: Optional[Settings] = None


def _get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings(validate=False)
    return _settings


def _build_pdf_filler(s: Settings):
    if not s.pdf_filler_enabled:
        return None

    if s.pdf_filler_provider == "mapper":
        from chatbot.pdf.mapper_filler import MapperPDFFiller
        return MapperPDFFiller(
            mapper_api_url=s.mapper_api_url,
            mapper_api_key=s.mapper_api_key,
        )

    if s.pdf_filler_provider == "managed":
        try:
            from chatbot_managed.filler import chatbotManagedPDFFiller
        except ImportError:
            raise ImportError(
                "pdf_filler.provider = managed requires the chatbot-managed package."
            )
        import os
        return chatbotManagedPDFFiller(
            auth0_domain=os.environ["AUTH0_DOMAIN"],
            auth0_client_id=os.environ["AUTH0_CLIENT_ID"],
            auth0_client_secret=os.environ["AUTH0_CLIENT_SECRET"],
            auth0_audience=os.environ["AUTH0_AUDIENCE"],
            pdf_lambda_url=os.environ["FILL_PDF_LAMBDA_URL"],
            pdf_api_key=os.environ["PDF_API_KEY"],
            backend_url=os.getenv("BACKEND_URL", ""),
            auth_token=os.getenv("AUTH_TOKEN", ""),
        )

    # custom: return None — files stored, user handles filling
    return None


def get_client() -> chatbotClient:
    global _client
    if _client is None:
        s = _get_settings()

        if s.storage_type == "s3":
            storage = S3Storage(
                output_bucket=s.s3_output_bucket,
                config_bucket=s.s3_config_bucket,
                region=s.s3_region,
            )
            form_config = FormConfig.from_storage(storage)
        else:
            storage = LocalStorage(
                data_path=s.data_path,
                config_path=s.config_path,
            )
            form_config = FormConfig.from_directory(s.config_path)

        _client = chatbotClient(
            openai_api_key=s.openai_api_key,
            storage=storage,
            form_config=form_config,
            pdf_filler=_build_pdf_filler(s),
            settings=s,
        )
    return _client


# ── Startup validation ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup_validation():
    from chatbot.config.validator import validate_for_entrypoint
    s = _get_settings()
    validate_for_entrypoint("server", s)   # raises SystemExit on error


# ── Models ────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    user_id: str
    session_id: str
    message: str = ""
    pdf_path: Optional[str] = None   # optional per-request override of config pdf_path


class ChatResponse(BaseModel):
    user_id: str
    session_id: str
    response: str
    session_complete: bool
    filled_data: Optional[dict] = None


class SessionDataResponse(BaseModel):
    user_id: str
    session_id: str
    data: Optional[dict]


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    s = _get_settings()
    return {
        "name": "pdf-autofillr-chatbot",
        "version": "0.1.0",
        "docs": "/docs",
        "mode": s.mode,
        "storage": s.storage_type,
        "pdf_filler": s.pdf_filler_provider if s.pdf_filler_enabled else "disabled",
    }


@app.post("/chatbot/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    try:
        client = get_client()
        s = _get_settings()
        pdf_path = req.pdf_path or s.pdf_path
        if pdf_path:
            client.create_session(req.user_id, req.session_id, pdf_path=pdf_path)
        response, complete, data = client.send_message(req.user_id, req.session_id, req.message)
        return ChatResponse(
            user_id=req.user_id,
            session_id=req.session_id,
            response=response,
            session_complete=complete,
            filled_data=data if complete else None,
        )
    except RateLimitExceeded as e:
        raise HTTPException(status_code=429, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("Error in /chatbot/chat")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/chatbot/session/{user_id}/{session_id}", response_model=SessionDataResponse)
def get_session(user_id: str, session_id: str):
    data = get_client().get_session_data(user_id, session_id)
    if data is None:
        raise HTTPException(status_code=404, detail="Session not found or not complete yet.")
    return SessionDataResponse(user_id=user_id, session_id=session_id, data=data)


@app.get("/chatbot/session/{user_id}/{session_id}/fill-report")
def get_fill_report(user_id: str, session_id: str, format: str = "json"):
    client = get_client()
    if format == "text":
        text = client.get_fill_report_text(user_id, session_id)
        if text is None:
            raise HTTPException(status_code=404, detail="Fill report not found.")
        return {"user_id": user_id, "session_id": session_id, "report": text}
    report = client.get_fill_report(user_id, session_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Fill report not found.")
    return {"user_id": user_id, "session_id": session_id, "report": report}


@app.delete("/chatbot/session/{user_id}/{session_id}")
def delete_session(user_id: str, session_id: str):
    get_client().delete_session(user_id, session_id)
    return {"deleted": True, "user_id": user_id, "session_id": session_id}


@app.get("/health")
def health():
    s = _get_settings()
    return {
        "status": "ok",
        "version": "0.1.0",
        "storage": s.storage_type,
        "pdf_filler": s.pdf_filler_provider if s.pdf_filler_enabled else "disabled",
        "telemetry": s.telemetry_mode if s.telemetry_enabled else "disabled",
    }


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(status_code=500, content={"error": str(exc)})