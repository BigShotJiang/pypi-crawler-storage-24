# chatbot/config/settings.py
"""
SDK runtime settings.

Priority (highest wins):
    1. Actual environment variables (shell exports, Lambda env, Docker -e)
    2. .env file (loaded by python-dotenv before Settings is constructed)
    3. config.ini (read here — base layer for local development)
    4. Hard-coded defaults

This means production deployments (Lambda, Docker) can ignore config.ini
entirely and just pass env vars — existing behaviour unchanged.
"""
from __future__ import annotations

import configparser
import os
import warnings
from pathlib import Path


def _find_config_ini() -> Path | None:
    """Walk up from cwd looking for config.ini."""
    candidate = Path.cwd() / "config.ini"
    if candidate.exists():
        return candidate
    # also check one level up (useful when running from src/ subdirectory)
    candidate2 = Path.cwd().parent / "config.ini"
    if candidate2.exists():
        return candidate2
    return None


class Settings:
    """
    SDK runtime settings.

    Reads config.ini (if present) as the base layer.
    Environment variables (including .env) always override config.ini.

    Pass ``config_ini_path`` to point at a specific config.ini location.
    Pass ``validate=False`` to skip startup checks (useful in tests).
    """

    def __init__(
        self,
        validate: bool = True,
        config_ini_path: str | None = None,
    ):
        # ── Load config.ini ────────────────────────────────────────────
        ini = configparser.ConfigParser()
        ini_path = Path(config_ini_path) if config_ini_path else _find_config_ini()
        if ini_path and ini_path.exists():
            ini.read(ini_path)

        def _get(section: str, key: str, env_var: str, default: str = "") -> str:
            """env var > config.ini > default"""
            env_val = os.getenv(env_var)
            if env_val is not None:
                return env_val
            try:
                return ini.get(section, key)
            except (configparser.NoSectionError, configparser.NoOptionError):
                return default

        def _getbool(section: str, key: str, env_var: str, default: bool = False) -> bool:
            raw = _get(section, key, env_var, str(default))
            return raw.strip().lower() in ("true", "1", "yes")

        def _getint(section: str, key: str, env_var: str, default: int = 0) -> int:
            try:
                return int(_get(section, key, env_var, str(default)))
            except (ValueError, TypeError):
                return default

        # ── [core] ─────────────────────────────────────────────────────
        self.mode: str         = _get("core", "mode",    "chatbot_MODE",    "server")
        self.storage_type: str = _get("core", "storage", "chatbot_STORAGE", "local")
        self.edit_mode: bool   = _getbool("core", "edit_mode", "chatbot_EDIT_MODE", False)

        # ── [storage_local] ────────────────────────────────────────────
        self.data_path: str   = _get("storage_local", "data_path",   "chatbot_DATA_PATH",   "./chatbot_data")
        self.config_path: str = _get("storage_local", "config_path", "chatbot_CONFIG_PATH", "./configs")

        # ── [storage_s3] ───────────────────────────────────────────────
        self.s3_output_bucket: str = _get("storage_s3", "output_bucket", "AWS_OUTPUT_BUCKET", "")
        self.s3_config_bucket: str = _get("storage_s3", "config_bucket", "AWS_CONFIG_BUCKET", "")
        self.s3_region: str        = _get("storage_s3", "region",        "AWS_REGION",        "us-east-1")

        # ── [pdf_filler] ───────────────────────────────────────────────
        self.pdf_filler_enabled: bool = _getbool("pdf_filler", "enabled",  "chatbot_PDF_FILLER_ENABLED", False)
        self.pdf_filler_provider: str = _get("pdf_filler",     "provider", "chatbot_PDF_FILLER",         "mapper")
        self.pdf_path: str            = _get("pdf_filler",     "pdf_path", "chatbot_PDF_PATH",           "")

        # Legacy single env var support: chatbot_PDF_FILLER=none means disabled
        _legacy_filler = os.getenv("chatbot_PDF_FILLER", "").lower()
        if _legacy_filler == "none":
            self.pdf_filler_enabled = False
        elif _legacy_filler in ("mapper", "managed", "custom"):
            self.pdf_filler_enabled = True
            self.pdf_filler_provider = _legacy_filler

        # Convenience alias used by existing code
        @property
        def pdf_filler_mode(self) -> str:
            if not self.pdf_filler_enabled:
                return "none"
            return self.pdf_filler_provider

        self.pdf_filler_mode = "none" if not self.pdf_filler_enabled else self.pdf_filler_provider

        # ── [mapper] ───────────────────────────────────────────────────
        self.mapper_api_url: str = _get("mapper", "api_url",     "MAPPER_API_URL",    "http://localhost:8000")
        self.mapper_url_prefix: str = _get("mapper", "url_prefix", "MAPPER_URL_PREFIX", "/mapper")
        self.mapper_api_key: str = os.getenv("MAPPER_API_KEY", "")

        # ── [telemetry] ────────────────────────────────────────────────
        # managed pdf_filler forces managed telemetry
        _tel_mode_default = "managed" if self.pdf_filler_provider == "managed" else "local"
        self.telemetry_mode: str = _get("telemetry", "mode", "chatbot_TELEMETRY_MODE", _tel_mode_default)

        # telemetry is considered enabled if mode is set to managed (managed implies it)
        _tel_env = os.getenv("chatbot_TELEMETRY", "").lower()
        if _tel_env:
            self.telemetry_enabled: bool = _tel_env in ("true", "1", "yes")
        else:
            # managed provider always enables telemetry automatically
            self.telemetry_enabled = self.pdf_filler_provider == "managed"

        self.telemetry_endpoint: str = os.getenv("TELEMETRY_ENDPOINT", "")
        self.sdk_api_key: str        = os.getenv("chatbot_SDK_API_KEY", "")

        # ── [server] ───────────────────────────────────────────────────
        self.server_port: int  = _getint("server", "port",    "PORT",    8001)
        self.server_host: str  = _get("server",    "host",    "HOST",    "0.0.0.0")
        self.server_workers: int = _getint("server", "workers", "WEB_CONCURRENCY", 1)

        # ── Misc / legacy ──────────────────────────────────────────────
        self.openai_api_key: str  = os.getenv("OPENAI_API_KEY", "")
        self.debug_logging: bool  = _getbool("", "", "chatbot_DEBUG_LOGGING", False)
        self.log_level: str       = os.getenv("chatbot_LOG_LEVEL", "INFO")
        self.pdf_poll_interval: int = _getint("", "", "chatbot_PDF_POLL_INTERVAL", 10)
        self.pdf_poll_timeout: int  = _getint("", "", "chatbot_PDF_POLL_TIMEOUT",  150)
        self.pdf_max_retries: int   = _getint("", "", "chatbot_PDF_MAX_RETRIES",   3)
        self.rate_limit_enabled: bool = _getbool("", "", "chatbot_RATE_LIMIT_ENABLED", False)
        # Bot identity — used by init_handler and other handlers
        self.bot_name: str = os.getenv(
            "chatbot_BOT_NAME", "Bot"
        )
        self.greeting: str = os.getenv(
            "chatbot_GREETING",
            "Hi! I am here to help you fill out your investment documents.",
        )

        if validate:
            self._validate()

    # ──────────────────────────────────────────────────────────────────
    # Validation
    # ──────────────────────────────────────────────────────────────────

    def _validate(self) -> None:
        errors: list[str] = []
        warns: list[str] = []

        # Always required
        if not self.openai_api_key:
            errors.append(
                "OPENAI_API_KEY is not set.\n"
                "  Add it to your .env file:  OPENAI_API_KEY=sk-..."
            )

        # S3 storage
        if self.storage_type == "s3":
            missing = []
            if not self.s3_output_bucket:
                missing.append("storage_s3.output_bucket (or AWS_OUTPUT_BUCKET env var)")
            if not self.s3_config_bucket:
                missing.append("storage_s3.config_bucket (or AWS_CONFIG_BUCKET env var)")
            has_creds = (
                os.getenv("AWS_ACCESS_KEY_ID")
                or os.getenv("AWS_PROFILE")
                or os.getenv("AWS_ROLE_ARN")
                or os.getenv("AWS_EXECUTION_ENV")
                or os.getenv("AWS_LAMBDA_FUNCTION_NAME")
            )
            if not has_creds:
                missing.append(
                    "AWS credentials — set AWS_ACCESS_KEY_ID+AWS_SECRET_ACCESS_KEY, "
                    "AWS_PROFILE, or use an IAM role"
                )
            if missing:
                errors.append(
                    "core.storage = s3 but the following are missing:\n"
                    + "\n".join(f"  - {v}" for v in missing)
                )

        # PDF filler
        if self.pdf_filler_enabled:
            if not self.pdf_path:
                errors.append(
                    "pdf_filler.enabled = true but pdf_filler.pdf_path is not set.\n"
                    "  Set the path to the blank PDF:\n"
                    "    Local: pdf_path = ./data/input/blank_form.pdf\n"
                    "    S3:    pdf_path = s3://your-bucket/blank_form.pdf"
                )

            if self.pdf_filler_provider == "mapper":
                if not self.mapper_api_url:
                    warns.append(
                        "pdf_filler.provider = mapper but mapper.api_url is not set.\n"
                        "  Defaulting to http://localhost:8000"
                    )
                if not self.mapper_api_key:
                    warns.append(
                        "MAPPER_API_KEY is not set — mapper calls will have no auth header.\n"
                        "  Set it in .env if your mapper server requires authentication."
                    )

            elif self.pdf_filler_provider == "managed":
                required = [
                    "AUTH0_DOMAIN", "AUTH0_CLIENT_ID", "AUTH0_CLIENT_SECRET",
                    "AUTH0_AUDIENCE", "FILL_PDF_LAMBDA_URL", "PDF_API_KEY",
                ]
                missing = [v for v in required if not os.getenv(v)]
                if missing:
                    errors.append(
                        "pdf_filler.provider = managed but these .env keys are missing:\n"
                        + "\n".join(f"  - {v}" for v in missing)
                    )

        # Telemetry
        if self.telemetry_enabled:
            if self.telemetry_mode == "local" and not self.telemetry_endpoint:
                warns.append(
                    "telemetry.mode = local but TELEMETRY_ENDPOINT is not set in .env.\n"
                    "  Events will be queued but never sent."
                )
            if self.telemetry_mode == "managed":
                if self.pdf_filler_provider != "managed":
                    errors.append(
                        "telemetry.mode = managed requires pdf_filler.provider = managed."
                    )
                if not self.sdk_api_key:
                    errors.append(
                        "telemetry.mode = managed but chatbot_SDK_API_KEY is not set in .env."
                    )

        for w in warns:
            warnings.warn(f"[chatbot-sdk] {w}", stacklevel=3)

        if errors:
            raise EnvironmentError(
                "\n\n[chatbot-sdk] Configuration errors — fix and restart:\n\n"
                + "\n\n".join(f"  ✗ {e}" for e in errors)
                + "\n\n  Run `chatbot-setup` to reconfigure interactively.\n"
                + "  See config.ini and .env.example for all options.\n"
            )