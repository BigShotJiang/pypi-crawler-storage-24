
# auto-generated; do not edit

commits = {
    "ROCm/xla": "b61fa4053afd43f0a40880b7046382540f698af6",
    "ROCm/rocm-jax": "6bce63f7b844c26faa75087a9be5d2482f45e51a",
    "jax": "58cb6e556c996bf0361bca9e64890a551e513280",
}
