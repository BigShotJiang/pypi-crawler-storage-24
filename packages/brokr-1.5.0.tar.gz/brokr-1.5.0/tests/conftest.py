"""Shared test fixtures for brokr tests."""

from unittest.mock import patch

import pytest
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


# Use fast KDF params in tests (n=2^14 instead of 2^17) to keep suite under 30s.
# Production uses n=2^17 for brute-force resistance.
# Tests marked @pytest.mark.real_kdf skip this (e.g. subprocess tests that spawn
# a real brokr process which uses the production KDF).
@pytest.fixture(autouse=True)
def _fast_kdf(request, monkeypatch):
    if "real_kdf" in request.keywords:
        return

    def fast_derive_key(passphrase, salt):
        kdf = Scrypt(salt=salt, length=32, n=2**14, r=8, p=1)
        return kdf.derive(passphrase.encode("utf-8"))

    monkeypatch.setattr("brokr.store.derive_key", fast_derive_key)
