# Releasing brokr

## One-time setup

Preferred path: PyPI Trusted Publisher via GitHub Actions.

Create pending publishers in PyPI and optionally TestPyPI:

- owner: `Virtuous6`
- repo: `brokr`
- workflow: `publish.yml`
- environment: `pypi` for PyPI, `testpypi` for TestPyPI

Do this before the first tagged release.

If Trusted Publisher setup is not ready, fallback is API token upload:

```bash
.venv/bin/python -m pip install '.[release]'
.venv/bin/python -m build
.venv/bin/python -m twine check dist/*
.venv/bin/python -m twine upload dist/*
```

## TestPyPI smoke

```bash
gh workflow run publish.yml -f target=testpypi
gh run watch
```

Then install from TestPyPI:

```bash
python -m pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  brokr
```

## PyPI release

1. bump version in `pyproject.toml`
2. commit + push
3. tag release: `git tag v<version> && git push origin v<version>`
4. watch run: `gh run watch`
5. verify install: `python -m pip install --upgrade brokr`
