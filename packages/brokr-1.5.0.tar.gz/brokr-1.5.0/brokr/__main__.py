"""Allow running brokr as ``python -m brokr``."""

from brokr.cli import app

app()
