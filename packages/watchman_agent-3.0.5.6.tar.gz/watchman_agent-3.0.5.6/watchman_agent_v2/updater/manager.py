"""
manager.py
──────────
Orchestrateur principal de la mise à jour.
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import click

from watchman_agent_v2.updater.checker   import start_background_check, get_check_result
from watchman_agent_v2.updater.classifier import UPDATE_LABELS
from watchman_agent_v2.updater.state     import (
    set_state, UPDATING, IDLE,
    wait_for_idle, InstanceLock,
)
from watchman_agent_v2.updater.rollback  import (
    create_snapshot, run_health_check, rollback
)

PACKAGE_NAME      = "watchman-agent"
IDLE_WAIT_TIMEOUT = 120
PENDING_FILE_PATH = Path.home() / ".watchman" / "update_pending.json"
UPDATE_LOG        = Path.home() / ".watchman" / "update.log"


# ─────────────────────────────────────────────────────────────
#  VERSION
# ─────────────────────────────────────────────────────────────

def _get_current_version() -> Optional[str]:
    """
    Lit la version via pip show.
    Fonctionne en mode normal ET en mode -e (editable).
    """
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", PACKAGE_NAME],
            capture_output=True, text=True,
        )
        for line in result.stdout.splitlines():
            if line.startswith("Version:"):
                return line.split(":", 1)[1].strip()
        return None
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────
#  MODE EDITABLE
# ─────────────────────────────────────────────────────────────

def _get_editable_path() -> Optional[str]:
    """
    Retourne le chemin du projet si installé en mode -e, sinon None.
    """
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "-f", PACKAGE_NAME],
            capture_output=True, text=True,
        )
        for line in result.stdout.splitlines():
            if line.startswith("Editable project location:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return None


# ─────────────────────────────────────────────────────────────
#  APPLY — process détaché (résout WinError 32)
# ─────────────────────────────────────────────────────────────

def _apply_update(target_version: str, editable_path: Optional[str] = None) -> bool:
    """
    Lance la mise à jour dans un process détaché qui s'exécute
    APRÈS la fermeture du process actuel.

    Windows interdit de remplacer un .exe en cours d'exécution.
    Ce process enfant attend que le parent se ferme, puis applique
    la mise à jour et écrit le résultat dans update.log.
    """
    UPDATE_LOG.parent.mkdir(parents=True, exist_ok=True)

    # Commande pip principale
    pip_cmd = (
        f'[sys.executable, "-m", "pip", "install", '
        f'"{PACKAGE_NAME}=={target_version}", "--quiet"]'
    )

    # Si mode editable : réinstaller -e après la mise à jour PyPI
    editable_restore = ""
    if editable_path:
        editable_restore = f"""
# Restaurer le mode développement
r2 = subprocess.run(
    [sys.executable, "-m", "pip", "install", "-e", r"{editable_path}", "--quiet"],
    capture_output=True, text=True,
)
log_lines.append("editable restore: " + ("ok" if r2.returncode == 0 else r2.stderr.strip()))
"""

    script = f"""
import subprocess, sys, time, os

parent_pid = {os.getpid()}
log_path   = r"{str(UPDATE_LOG)}"
log_lines  = []

# Attendre que le process parent soit fermé
try:
    import psutil
    proc = psutil.Process(parent_pid)
    proc.wait(timeout=20)
    log_lines.append("parent closed via psutil")
except Exception:
    time.sleep(4)
    log_lines.append("parent wait via sleep")

# Appliquer la mise à jour
r1 = subprocess.run(
    {pip_cmd},
    capture_output=True, text=True,
)
log_lines.append("pip returncode: " + str(r1.returncode))
if r1.stderr:
    log_lines.append("pip stderr: " + r1.stderr.strip())
{editable_restore}
# Écrire le log
with open(log_path, "w", encoding="utf-8") as f:
    f.write("\\n".join(log_lines))

# Nettoyer ce script temporaire
try:
    os.unlink(__file__)
except Exception:
    pass
"""

    try:
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        )
        tmp.write(script)
        tmp.close()

        if sys.platform == "win32":
            subprocess.Popen(
                [sys.executable, tmp.name],
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                close_fds=True,
            )
        else:
            subprocess.Popen(
                [sys.executable, tmp.name],
                start_new_session=True,
                close_fds=True,
            )
        return True

    except Exception as e:
        click.echo(f"  Impossible de lancer le process de mise à jour : {e}")
        return False


# ─────────────────────────────────────────────────────────────
#  PENDING
# ─────────────────────────────────────────────────────────────

def _save_pending(update_info: dict) -> None:
    PENDING_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    update_info["saved_at"] = datetime.now().isoformat()
    PENDING_FILE_PATH.write_text(json.dumps(update_info, indent=2))


def _load_pending() -> Optional[dict]:
    try:
        if PENDING_FILE_PATH.exists():
            return json.loads(PENDING_FILE_PATH.read_text())
    except Exception:
        pass
    return None


def _clear_pending() -> None:
    try:
        PENDING_FILE_PATH.unlink(missing_ok=True)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────
#  CORE : snapshot → apply → health check → rollback
# ─────────────────────────────────────────────────────────────

def _safe_apply(current_version: str, latest_version: str, silent: bool = False) -> bool:
    """
    Séquence complète :
      1. Snapshot de la version actuelle
      2. Application via process détaché
      3. Health check
      4. Rollback automatique si health check échoue
    """
    editable_path = _get_editable_path()

    # ── 1. Snapshot ──────────────────────────────────────────
    if not silent:
        click.echo(f" Création du snapshot v{current_version}...")

    snapshot = create_snapshot(current_version)
    if not snapshot:
        if not silent:
            click.echo("   Snapshot impossible, mise à jour annulée par précaution.")
        return False

    set_state(UPDATING, f"Mise à jour vers {latest_version}")

    # ── 2. Apply ─────────────────────────────────────────────
    if not silent:
        click.echo(f"   Application de la mise à jour vers {latest_version}...")
        click.echo(f"   Logs disponibles dans : {UPDATE_LOG}")

    success = _apply_update(latest_version, editable_path)

    set_state(IDLE)

    if not success:
        if not silent:
            click.echo("  Impossible de lancer la mise à jour.")
        return False

    # ── 3. Message final ─────────────────────────────────────
    if not silent:
        click.echo(f"  Mise à jour {latest_version} lancée.")
        click.echo(f"  Relancez watchman-agent dans quelques secondes.")

    return True


# ─────────────────────────────────────────────────────────────
#  STRATÉGIES PAR TYPE
# ─────────────────────────────────────────────────────────────

def _handle_critical(current: str, latest: str) -> None:
    click.echo(f"\nMISE À JOUR CRITIQUE détectée : {current} → {latest}")
    click.echo("   Cette version corrige une faille de sécurité.")
    click.echo("   En attente d'un état idle de l'agent...")

    idle = wait_for_idle(timeout=IDLE_WAIT_TIMEOUT)
    if not idle:
        click.echo("   Timeout : l'agent est occupé, mise à jour forcée dans 10s...")
        time.sleep(10)

    lock = InstanceLock()
    with lock() as acquired:
        if not acquired:
            click.echo("   Une autre instance effectue déjà une mise à jour. Abandon.")
            return
        _safe_apply(current, latest, silent=False)

    sys.exit(0)


def _handle_patch(current: str, latest: str) -> None:
    idle = wait_for_idle(timeout=IDLE_WAIT_TIMEOUT)
    if not idle:
        return

    lock = InstanceLock()
    with lock() as acquired:
        if not acquired:
            return
        _safe_apply(current, latest, silent=True)


def _handle_minor(current: str, latest: str) -> None:
    click.echo(f"\nNouvelle version disponible : {latest}  (actuelle : {current})")
    click.echo(f"   Contient de nouvelles fonctionnalités.")
    click.echo(f"   Lancez 'watchman-agent update' pour mettre à jour.")


def _handle_major(current: str, latest: str) -> None:
    click.echo(f"\nMise à jour MAJEURE disponible : {latest}  (actuelle : {current})")
    click.echo("   Cette version peut contenir des changements incompatibles.")

    pending = _load_pending()
    if pending and pending.get("latest") == latest:
        if click.confirm("   Une mise à jour MAJOR est en attente. Appliquer maintenant ?", default=False):
            _clear_pending()
            lock = InstanceLock()
            with lock() as acquired:
                if not acquired:
                    click.echo(" Une autre instance met à jour. Abandon.")
                    return
                click.echo("  Attente d'un état idle...")
                wait_for_idle(timeout=IDLE_WAIT_TIMEOUT)
                _safe_apply(current, latest)
        else:
            click.echo("  Mise à jour reportée au prochain run.")
    else:
        if click.confirm("   Confirmer la mise à jour MAJOR ?", default=False):
            _save_pending({"current": current, "latest": latest, "type": "major"})
            click.echo("  Mise à jour planifiée pour le prochain run idle.")
        else:
            click.echo("  Mise à jour MAJOR ignorée.")


# ─────────────────────────────────────────────────────────────
#  POINT D'ENTRÉE
# ─────────────────────────────────────────────────────────────

def run_update_flow() -> None:
    current = _get_current_version()
    if not current:
        click.echo("Package non trouvé via pip (mode développement détecté).")
        return

    click.echo(f"   Version actuelle : {current}")

    pending = _load_pending()
    if pending and pending.get("type") == "major":
        _handle_major(pending["current"], pending["latest"])
        return

    start_background_check(current)
    click.echo("   Connexion à PyPI...")

    result = get_check_result(timeout=5.0)
    if not result:
        click.echo("  Impossible de joindre PyPI. Vérifiez votre connexion.")
        return

    update_type = result.get("update_type", "none")
    latest      = result.get("latest", current)
    is_critical = result.get("is_critical", False)

    if update_type == "none":
        click.echo(f"  Watchman Agent est à jour (v{current}).")
        return

    label = UPDATE_LABELS.get(update_type, update_type)
    click.echo(f"\n Watchman Update — {label}")

    if is_critical:
        _handle_critical(current, latest)
        return

    dispatch = {
        "patch": _handle_patch,
        "minor": _handle_minor,
        "major": _handle_major,
    }

    handler = dispatch.get(update_type)
    if handler:
        handler(current, latest)