"""
checker.py
──────────
Vérifie la dernière version disponible sur PyPI de manière
non-bloquante (thread daemon). Le résultat est mis en cache
dans un fichier local pour éviter de spammer PyPI.
"""

import json
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import requests

PACKAGE_NAME = "watchman-agent"
CACHE_FILE = Path.home() / ".watchman" / "version_cache.json"
CACHE_TTL_MINUTES = 60          # Vérifier PyPI au maximum 1x/heure
PYPI_TIMEOUT_SECONDS = 5


# ─────────────────────────────────────────────────────────────
#  Cache local
# ─────────────────────────────────────────────────────────────

def _read_cache(current_version: str) -> Optional[dict]:
    try:
        if CACHE_FILE.exists():
            data = json.loads(CACHE_FILE.read_text())
            cached_at = datetime.fromisoformat(data["cached_at"])

            # ← Invalider si la version actuelle a changé depuis le cache
            if data.get("current_version") != current_version:
                return None

            if datetime.now() - cached_at < timedelta(minutes=CACHE_TTL_MINUTES):
                return data
    except Exception:
        pass
    return None


def _write_cache(current_version: str, latest: str, update_type: str, is_critical: bool) -> None:
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps({
            "current_version": current_version,   # ← ajouté
            "latest":          latest,
            "update_type":     update_type,
            "is_critical":     is_critical,
            "cached_at":       datetime.now().isoformat(),
        }))
    except Exception:
        pass
# ─────────────────────────────────────────────────────────────
#  Appel PyPI
# ─────────────────────────────────────────────────────────────

def _fetch_pypi_info() -> Optional[dict]:
    """
    Retourne les métadonnées PyPI du package.
    Retourne None en cas d'erreur réseau.
    """
    try:
        resp = requests.get(
            f"https://pypi.org/pypi/{PACKAGE_NAME}/json",
            timeout=PYPI_TIMEOUT_SECONDS,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception:
        return None


def _is_critical_release(pypi_info: dict, latest_version: str) -> bool:
    """
    Détecte si la release est critique en cherchant des mots-clés
    dans les release notes / description PyPI.
    """
    keywords = ["security", "critical", "cve", "vulnerability", "urgent", "hotfix"]
    try:
        description = pypi_info.get("info", {}).get("description", "").lower()
        releases = pypi_info.get("releases", {})
        release_notes = str(releases.get(latest_version, "")).lower()
        combined = description + release_notes
        return any(kw in combined for kw in keywords)
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
#  Interface publique
# ─────────────────────────────────────────────────────────────

# Résultat partagé entre le thread et le processus principal
_result: dict = {}
_lock = threading.Lock()


def _background_check(current_version: str) -> None:
    from watchman_agent_v2.updater.classifier import classify

    cached = _read_cache(current_version)   # ← passer current_version
    if cached:
        with _lock:
            _result.update(cached)
        return

    info = _fetch_pypi_info()
    if not info:
        return

    latest      = info["info"]["version"]
    update_type = classify(current_version, latest)
    is_critical = _is_critical_release(info, latest)

    _write_cache(current_version, latest, update_type, is_critical)  # ← passer current_version

    with _lock:
        _result.update({
            "current_version": current_version,
            "latest":          latest,
            "update_type":     update_type,
            "is_critical":     is_critical,
        })

def start_background_check(current_version: str) -> threading.Thread:
    """
    Lance la vérification PyPI en arrière-plan.
    Retourne le thread pour permettre un join() optionnel.
    """
    t = threading.Thread(
        target=_background_check,
        args=(current_version,),
        daemon=True,
        name="watchman-update-checker",
    )
    t.start()
    return t


def get_check_result(timeout: float = 3.0) -> dict:
    """
    Attend le résultat du check (max `timeout` secondes).
    Retourne un dict vide si aucun résultat disponible.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        with _lock:
            if _result:
                return dict(_result)
        time.sleep(0.1)
    return {}