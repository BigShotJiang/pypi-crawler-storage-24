"""
state.py
────────
Gère deux mécanismes critiques :

1. IDLE STATE — L'agent signale s'il est en train de traiter quelque chose.
   Une mise à jour ne s'applique que quand l'état est IDLE.

2. INSTANCE LOCK — Empêche plusieurs instances de se mettre à jour
   en même temps (cas multi-process / multi-cron).
   Compatible Windows et Unix.
"""

import json
import os
import sys
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

from filelock import Timeout, FileLock

# ─── Chemins ────────────────────────────────────────────────
WATCHMAN_DIR     = Path.home() / ".watchman"
STATE_FILE       = WATCHMAN_DIR / "agent_state.json"
LOCK_FILE        = WATCHMAN_DIR / "update.lock"
IDLE_TIMEOUT_SEC = 300

# ─── États possibles ────────────────────────────────────────
IDLE     = "idle"
BUSY     = "busy"
UPDATING = "updating"

# ─── Détection plateforme ───────────────────────────────────
_IS_WINDOWS = sys.platform == "win32"


# ─────────────────────────────────────────────────────────────
#  STATE FILE
# ─────────────────────────────────────────────────────────────

def _ensure_dir() -> None:
    WATCHMAN_DIR.mkdir(parents=True, exist_ok=True)


def set_state(status: str, context: str = "") -> None:
    _ensure_dir()
    STATE_FILE.write_text(json.dumps({
        "status":     status,
        "context":    context,
        "pid":        os.getpid(),
        "updated_at": datetime.now().isoformat(),
    }))


def get_state() -> dict:
    try:
        if not STATE_FILE.exists():
            return {"status": IDLE}

        data = json.loads(STATE_FILE.read_text())
        updated_at = datetime.fromisoformat(data["updated_at"])
        age = (datetime.now() - updated_at).total_seconds()

        if age > IDLE_TIMEOUT_SEC:
            return {"status": IDLE, "stale": True}

        return data
    except Exception:
        return {"status": IDLE}


def is_idle() -> bool:
    return get_state().get("status") == IDLE


def wait_for_idle(timeout: float = 60.0, poll: float = 2.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_idle():
            return True
        time.sleep(poll)
    return False


@contextmanager
def busy_context(context: str = ""):
    set_state(BUSY, context)
    try:
        yield
    finally:
        set_state(IDLE)


# ─────────────────────────────────────────────────────────────
#  INSTANCE LOCK — cross-platform (Windows + Unix)
# ─────────────────────────────────────────────────────────────



class InstanceLock:
    """
    Verrou fichier cross-platform via filelock.
    Fonctionne sur Windows, Linux, macOS.
    """

    def __init__(self):
        _ensure_dir()
        self._lock = FileLock(str(LOCK_FILE))

    def acquire(self) -> bool:
        try:
            self._lock.acquire(timeout=0)   # non-bloquant
            return True
        except Timeout:
            return False

    def release(self) -> None:
        try:
            self._lock.release()
        except Exception:
            pass

    @contextmanager
    def __call__(self):
        acquired = self.acquire()
        try:
            yield acquired
        finally:
            if acquired:
                self.release()