"""
classifier.py
─────────────
Classifie le type de mise à jour en comparant deux versions SemVer.
"""

from packaging.version import Version


UpdateType = str   # "none" | "patch" | "minor" | "major"


def classify(current: str, latest: str) -> UpdateType:
    """
    Compare current et latest et retourne le type de mise à jour.

    Exemples :
        classify("1.2.3", "1.2.4") → "patch"
        classify("1.2.3", "1.3.0") → "minor"
        classify("1.2.3", "2.0.0") → "major"
        classify("1.2.3", "1.2.3") → "none"
    """
    try:
        c = Version(current)
        l = Version(latest)

        if l <= c:
            return "none"
        if l.major > c.major:
            return "major"
        if l.minor > c.minor:
            return "minor"
        return "patch"

    except Exception:
        return "none"


# Priorité numérique utile pour comparaisons
PRIORITY = {
    "none":  0,
    "patch": 1,
    "minor": 2,
    "major": 3,
}

UPDATE_LABELS = {
    "none":  "À jour",
    "patch": "Bugfix / Patch",
    "minor": "Nouvelle fonctionnalité",
    "major": "Changement majeur",
}