"""
rollback.py
───────────
Rollback toujours depuis PyPI — source de vérité unique.

Avant chaque mise à jour :
  1. Freeze l'environnement complet (pip freeze → requirements.txt)
  2. Mémorise la version actuelle
  3. Applique la mise à jour depuis PyPI
  4. Health check
  5. Si échec → pip install <version_précédente> depuis PyPI + restore freeze
"""

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import click

WATCHMAN_DIR   = Path.home() / ".watchman"
SNAPSHOT_DIR   = WATCHMAN_DIR / "snapshots"
SNAPSHOT_META  = WATCHMAN_DIR / "snapshot_meta.json"
PACKAGE_NAME   = "watchman-agent"
MAX_SNAPSHOTS  = 3
HEALTH_TIMEOUT = 15


# ─────────────────────────────────────────────────────────────
#  SNAPSHOT — freeze complet + version PyPI
# ─────────────────────────────────────────────────────────────

def create_snapshot(current_version: str) -> bool:
    """
    Sauvegarde :
      - La version actuelle (pour pip install lors du rollback)
      - Le freeze complet de l'environnement (pour restaurer les dépendances)

    Retourne True si le snapshot est créé avec succès.
    """
    try:
        SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        version_dir = SNAPSHOT_DIR / current_version
        version_dir.mkdir(exist_ok=True)

        # ① Vérifier que cette version existe bien sur PyPI avant de snapshotter
        check = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", PACKAGE_NAME],
            capture_output=True, text=True,
        )
        if current_version not in check.stdout:
            click.echo(f"   v{current_version} introuvable sur PyPI — snapshot ignoré.")
            return False

        # ② Freeze complet de l'environnement
        freeze_result = subprocess.run(
            [sys.executable, "-m", "pip", "freeze"],
            capture_output=True, text=True,
        )
        if freeze_result.returncode != 0:
            return False

        freeze_file = version_dir / "requirements_freeze.txt"
        freeze_file.write_text(freeze_result.stdout)

        # ③ Sauvegarder les métadonnées
        _update_snapshot_meta(current_version, str(freeze_file))
        _cleanup_old_snapshots()

        return True

    except Exception as e:
        click.echo(f"    Snapshot échoué : {e}")
        return False


# ─────────────────────────────────────────────────────────────
#  MÉTADONNÉES
# ─────────────────────────────────────────────────────────────

def _update_snapshot_meta(version: str, freeze_path: str) -> None:
    try:
        meta = _read_snapshot_meta()
        # Éviter les doublons
        meta["snapshots"] = [s for s in meta["snapshots"] if s["version"] != version]
        meta["snapshots"].insert(0, {
            "version":    version,
            "freeze":     freeze_path,
            "created_at": datetime.now().isoformat(),
        })
        SNAPSHOT_META.write_text(json.dumps(meta, indent=2))
    except Exception:
        pass


def _read_snapshot_meta() -> dict:
    try:
        if SNAPSHOT_META.exists():
            return json.loads(SNAPSHOT_META.read_text())
    except Exception:
        pass
    return {"snapshots": []}


def _cleanup_old_snapshots() -> None:
    try:
        meta = _read_snapshot_meta()
        to_keep   = meta["snapshots"][:MAX_SNAPSHOTS]
        to_delete = meta["snapshots"][MAX_SNAPSHOTS:]

        for snap in to_delete:
            p = Path(snap["freeze"]).parent
            if p.exists():
                import shutil
                shutil.rmtree(p, ignore_errors=True)

        meta["snapshots"] = to_keep
        SNAPSHOT_META.write_text(json.dumps(meta, indent=2))
    except Exception:
        pass


def get_last_snapshot() -> Optional[dict]:
    meta = _read_snapshot_meta()
    snaps = meta.get("snapshots", [])
    return snaps[0] if snaps else None


# ─────────────────────────────────────────────────────────────
#  COMPATIBILITÉ — dry-run avant d'appliquer
# ─────────────────────────────────────────────────────────────

def is_version_compatible(target_version: str) -> bool:
    """
    Simule l'installation depuis PyPI sans rien changer.
    Retourne True si la version est installable.
    """
    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "pip", "install",
                f"{PACKAGE_NAME}=={target_version}",
                "--dry-run",
                "--quiet",
            ],
            capture_output=True, text=True,
        )
        return result.returncode == 0
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
#  HEALTH CHECK
# ─────────────────────────────────────────────────────────────

def run_health_check() -> bool:
    """
    Vérifie que :
      1. Le package s'importe sans erreur
      2. La commande --help répond correctement
    """
    try:
        module_name = PACKAGE_NAME.replace("-", "_")

        # Test 1 : import
        r1 = subprocess.run(
            [sys.executable, "-c", f"import {module_name}"],
            capture_output=True,
            timeout=HEALTH_TIMEOUT,
        )
        if r1.returncode != 0:
            return False

        # Test 2 : CLI --help
        r2 = subprocess.run(
            [PACKAGE_NAME, "--help"],
            capture_output=True,
            timeout=HEALTH_TIMEOUT,
        )
        return r2.returncode == 0

    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
#  ROLLBACK — toujours depuis PyPI
# ─────────────────────────────────────────────────────────────

def rollback() -> bool:
    """
    Restaure la version précédente depuis PyPI.

    Séquence :
      1. Lire le snapshot (version + freeze)
      2. Vérifier compatibilité PyPI
      3. pip install <version> depuis PyPI
      4. Restaurer le freeze complet des dépendances
    """
    snap = get_last_snapshot()
    if not snap:
        click.echo("  Aucun snapshot disponible pour le rollback.")
        return False

    target_version = snap["version"]
    freeze_file    = Path(snap["freeze"])

    click.echo(f"   Vérification de v{target_version} sur PyPI...")
    if not is_version_compatible(target_version):
        click.echo(f"  v{target_version} incompatible ou introuvable sur PyPI.")
        return False

    # ① Réinstaller la version depuis PyPI
    click.echo(f"  Réinstallation de v{target_version} depuis PyPI...")
    r1 = subprocess.run(
        [
            sys.executable, "-m", "pip", "install",
            f"{PACKAGE_NAME}=={target_version}",
            "--force-reinstall",
            "--quiet",
        ],
        capture_output=True, text=True,
    )

    if r1.returncode != 0:
        click.echo(f"   pip install échoué : {r1.stderr.strip()}")
        return False

    # ② Restaurer le freeze complet (dépendances)
    if freeze_file.exists():
        click.echo("  Restauration des dépendances...")
        r2 = subprocess.run(
            [
                sys.executable, "-m", "pip", "install",
                "-r", str(freeze_file),
                "--quiet",
            ],
            capture_output=True, text=True,
        )
        if r2.returncode != 0:
            click.echo(f"   Dépendances partiellement restaurées : {r2.stderr.strip()}")
            # Non bloquant — le package principal est restauré

    click.echo(f"  Rollback vers v{target_version} terminé.")
    return True