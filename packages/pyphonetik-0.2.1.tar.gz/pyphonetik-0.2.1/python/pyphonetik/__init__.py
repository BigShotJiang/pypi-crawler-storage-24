"""Python bindings for the phonetik phonetic analysis engine."""

from pyphonetik._core import Engine

__all__ = ["Engine"]
__version__ = "0.2.1"
