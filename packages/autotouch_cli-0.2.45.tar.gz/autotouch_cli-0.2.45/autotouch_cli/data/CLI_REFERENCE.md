# Autotouch CLI Reference

Generated from the installed parser for `autotouch-cli` `0.2.45`.

## Output Modes

- `json`: exactly one JSON document per invocation.
- `ndjson`: one JSON object per line for streaming/progress-oriented commands.
- `human`: interactive text for people.

## Commands

### `auth`

#### `autotouch auth`

Auth helpers

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `check, bootstrap, login, set-key, show, whoami, clear, schema`
- Example:
  - `autotouch auth [-h]
                      {check,bootstrap,login,set-key,show,whoami,clear,schema} ...`

#### `autotouch auth bootstrap`

Register an account/org and return a developer key

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth bootstrap [-h] [--first-name FIRST_NAME]
                                [--last-name LAST_NAME] [--email EMAIL]
                                [--password PASSWORD]
                                [--organization-name ORGANIZATION_NAME]
                                [--key-name KEY_NAME]
                                [--expires-at EXPIRES_AT]
                                [--scopes-json SCOPES_JSON]
                                [--scopes-file SCOPES_FILE]
                                [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--save-key]
                                [--base-url BASE_URL] [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--first-name`: First name
  - `--last-name`: Last name
  - `--email`: User email
  - `--password`: Password
  - `--organization-name`: Organization name
  - `--key-name`: Developer key label (default: Agent bootstrap key)
  - `--expires-at`: Optional developer key expiry ISO timestamp
  - `--scopes-json`: Optional JSON array of scopes
  - `--scopes-file`: Optional JSON file with scopes array
  - `--data-json`: Explicit agent bootstrap payload JSON
  - `--data-file`: Path to agent bootstrap payload JSON file
  - `--save-key` (default=False): Persist the returned apiKey and bootstrap a saved JWT session
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch auth check`

Validate token against /api/capabilities

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth check [-h] [--base-url BASE_URL] [--token TOKEN]
                            [--use-x-api-key] [--timeout TIMEOUT]
                            [--output {json,ndjson,human}] [--compact]
                            [--select SELECT | --json-pointer JSON_POINTER]
                            [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch auth clear`

Clear stored auth config

- Auth: `none`
- Stability: `stable`
- Destructive: `yes`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth clear [-h] [--all] [--clear-base-url]
                            [--output {json,ndjson,human}] [--compact]
                            [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--all` (default=False): Clear all config keys
  - `--clear-base-url` (default=False): Also clear stored base_url
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch auth login`

Authenticate with email/password and persist a JWT session

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth login [-h] [--email EMAIL] [--password PASSWORD]
                            [--data-json DATA_JSON] [--data-file DATA_FILE]
                            [--no-save-session] [--base-url BASE_URL]
                            [--timeout TIMEOUT] [--output {json,ndjson,human}]
                            [--compact] [--select SELECT |
                            --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--email`: User email
  - `--password`: Password (prompted if omitted in a TTY)
  - `--data-json`: Explicit auth login payload JSON
  - `--data-file`: Path to auth login payload JSON file
  - `--no-save-session` (default=True): Do not persist the returned access token
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch auth schema`

Print auth payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth schema [-h] [--type {all,bootstrap,login}]
                             [--out-file OUT_FILE]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,bootstrap,login; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch auth set-key`

Persist API key/base URL to user config

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth set-key [-h] [--api-key API_KEY] [--base-url BASE_URL]
                              [--overwrite] [--output {json,ndjson,human}]
                              [--compact] [--select SELECT |
                              --json-pointer JSON_POINTER]`
- Options:
  - `--api-key`: Developer API key to store (defaults from env if omitted)
  - `--base-url`: Default API base URL (default: https://app.autotouch.ai)
  - `--overwrite` (default=False): Replace existing stored API key
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch auth show`

Show current auth config

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth show [-h] [--output {json,ndjson,human}] [--compact]
                           [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch auth whoami`

Show the current saved user session identity

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch auth whoami [-h] [--token TOKEN] [--base-url BASE_URL]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--token`: Explicit JWT session token
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `blacklist`

#### `autotouch blacklist`

Organization blacklist operations (admin)

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, add, remove, import, check, filter`
- Example:
  - `autotouch blacklist [-h] {list,add,remove,import,check,filter} ...`

#### `autotouch blacklist add`

Add a blacklist entry

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--type, --value`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist add [-h] --type {email,domain} --value VALUE
                               [--reason REASON] [--notes NOTES]
                               [--base-url BASE_URL] [--token TOKEN]
                               [--use-x-api-key] [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--type` (required; choices=email,domain): Entry type
  - `--value` (required): Email or domain value
  - `--reason` (default=): Optional reason
  - `--notes` (default=): Optional notes
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch blacklist check`

Check whether emails are blacklisted

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist check [-h] [--email EMAIL]
                                 [--emails-json EMAILS_JSON]
                                 [--emails-file EMAILS_FILE]
                                 [--emails-column EMAILS_COLUMN]
                                 [--chunk-size CHUNK_SIZE] [--summary-only]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--email`: Email value (repeatable; comma-separated also supported)
  - `--emails-json`: JSON array or object with emails[]
  - `--emails-file`: Path to .txt/.csv/.json email list
  - `--emails-column` (default=email): CSV column for emails (default: email)
  - `--chunk-size` (default=1000): Request chunk size (max 1000, default: 1000)
  - `--summary-only` (default=False): Omit per-email results
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch blacklist filter`

Filter blacklisted emails from a list

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist filter [-h] [--email EMAIL]
                                  [--emails-json EMAILS_JSON]
                                  [--emails-file EMAILS_FILE]
                                  [--emails-column EMAILS_COLUMN]
                                  [--chunk-size CHUNK_SIZE] [--summary-only]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--email`: Email value (repeatable; comma-separated also supported)
  - `--emails-json`: JSON array or object with emails[]
  - `--emails-file`: Path to .txt/.csv/.json email list
  - `--emails-column` (default=email): CSV column for emails (default: email)
  - `--chunk-size` (default=10000): Request chunk size (max 10000, default: 10000)
  - `--summary-only` (default=False): Omit full clean/blocked lists
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch blacklist import`

Import blacklist entries from CSV/TXT

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--file`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist import [-h] --file FILE [--base-url BASE_URL]
                                  [--token TOKEN] [--use-x-api-key]
                                  [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--file` (required): Path to CSV/TXT file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch blacklist list`

List blacklist entries

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist list [-h] [--type-filter {all,email,domain}]
                                [--search SEARCH] [--page PAGE]
                                [--limit LIMIT] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--type-filter` (choices=all,email,domain; default=all)
  - `--search`: Filter by value/reason/notes
  - `--page` (default=1): Page number (default: 1)
  - `--limit` (default=100): Entries per page (default: 100)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch blacklist remove`

Remove a blacklist entry by id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--entry-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch blacklist remove [-h] --entry-id ENTRY_ID
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--entry-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `capabilities`

#### `autotouch capabilities`

Get machine-readable API capabilities

- Auth: `optional`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch capabilities [-h] [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `cells`

#### `autotouch cells`

Cell operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `get, patch, schema`
- Example:
  - `autotouch cells [-h] {get,patch,schema} ...`

#### `autotouch cells get`

Get one cell with value/status/metadata

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--row-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch cells get [-h] --row-id ROW_ID --column-id COLUMN_ID
                           [--base-url BASE_URL] [--token TOKEN]
                           [--use-x-api-key] [--timeout TIMEOUT]
                           [--output {json,ndjson,human}] [--compact]
                           [--select SELECT | --json-pointer JSON_POINTER]
                           [--verbose]`
- Options:
  - `--row-id` (required)
  - `--column-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch cells patch`

Patch cells in batch

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch cells patch [-h] --table-id TABLE_ID
                             [--updates-json UPDATES_JSON]
                             [--updates-file UPDATES_FILE] [--detect-types]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--table-id` (required)
  - `--updates-json`: JSON list or {updates:[...]} object
  - `--updates-file`: Path to JSON file with updates payload
  - `--detect-types` (default=False): Set detect_types=true query flag
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch cells schema`

Print cell payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch cells schema [-h] [--type {all,patch_updates}]
                              [--out-file OUT_FILE]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,patch_updates; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `cli-manifest`

#### `autotouch cli-manifest`

Print the machine-readable CLI command manifest

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch cli-manifest [-h] [--source {live,bundled}]
                              [--out-file OUT_FILE]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--source` (choices=live,bundled; default=live): Manifest source
  - `--out-file`: Write manifest JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `cli-reference`

#### `autotouch cli-reference`

Print the generated CLI reference

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch cli-reference [-h] [--source {live,bundled}]
                               [--out-file OUT_FILE]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--source` (choices=live,bundled; default=live): Reference source
  - `--out-file`: Write reference markdown to file
  - `--output` (choices=json,ndjson,human; default=human): Output mode
  - `--compact` (default=False): Print compact JSON when using JSON output
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `columns`

#### `autotouch columns`

Column operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, create, update, delete, projections, test-http-request, run, stop, run-next, estimate, recipe`
- Example:
  - `autotouch columns [-h]
                         {list,create,update,delete,projections,test-http-request,run,stop,run-next,estimate,recipe} ...`

#### `autotouch columns create`

Create a column

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns create [-h] --table-id TABLE_ID
                                [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--data-json`: ColumnCreate payload JSON
  - `--data-file`: ColumnCreate payload file path
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns delete`

Delete a column and all of its cells

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns delete [-h] --table-id TABLE_ID --column-id COLUMN_ID
                                [--yes] [--base-url BASE_URL] [--token TOKEN]
                                [--use-x-api-key] [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--yes` (default=False): Required confirmation flag for destructive delete
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns estimate`

Estimate a column run

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns estimate [-h] --table-id TABLE_ID
                                  --column-id COLUMN_ID
                                  [--scope {all,subset,row,firstN,filtered}]
                                  [--row-id ROW_ID] [--row-ids [ROW_IDS ...]]
                                  [--first-n FIRST_N] [--unprocessed-only]
                                  [--filters-json FILTERS_JSON]
                                  [--filters-file FILTERS_FILE]
                                  [--data-json DATA_JSON]
                                  [--data-file DATA_FILE]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--scope` (choices=all,subset,row,firstN,filtered; default=all): Run scope: row=one explicit ID, subset=explicit many IDs, filtered=current filters, firstN=first N rows, all=entire table
  - `--row-id`: Single row ID for scope=row
  - `--row-ids`: Row IDs for subset scope (or a single row when scope=row)
  - `--first-n`: First N rows (for scope=firstN). Use with --unprocessed-only to process the next rows without reruns
  - `--unprocessed-only` (default=False): Only process rows without values (recommended with scope=firstN)
  - `--filters-json`: JSON object for scope=filtered
  - `--filters-file`: Path to JSON file for scope=filtered
  - `--data-json`: Explicit RunRequest payload JSON (overrides scope flags)
  - `--data-file`: Path to RunRequest payload JSON file (overrides scope flags)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns list`

List table columns

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns list [-h] --table-id TABLE_ID [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--table-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns projections`

Create JSON projection columns

Create JSON-split projection columns from a JSON source column.
Use this command for flattening enrichment JSON output into readable columns.
Do not use `autotouch columns create` with `kind: "projection"` and empty `config`.

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns projections [-h] --table-id TABLE_ID
                                     [--data-json DATA_JSON]
                                     [--data-file DATA_FILE]
                                     [--base-url BASE_URL] [--token TOKEN]
                                     [--use-x-api-key] [--timeout TIMEOUT]
                                     [--output {json,ndjson,human}]
                                     [--compact] [--select SELECT |
                                     --json-pointer JSON_POINTER] [--verbose]`
- Notes:

```text
CreateProjectionsRequest payload example:

{
  "items": [
    {
      "key": "company_name",
      "label": "Company Name",
      "sourceColumnId": "<JSON_COLUMN_ID>",
      "path": "company_name",
      "dataType": "text"
    }
  ]
}

Each item must include `key`, `label`, `sourceColumnId`, and `path`.
```
- Options:
  - `--table-id` (required)
  - `--data-json`: CreateProjectionsRequest payload JSON
  - `--data-file`: CreateProjectionsRequest payload file path
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns recipe`

Print copy-ready ColumnCreate payload templates

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns recipe [-h]
                                [--type {all,formatter,llm_enrichment,email_finder,phone_finder,lead_finder,add_to_crm,sync_to_table,add_to_sequence,http_request}]
                                [--out-file OUT_FILE]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,formatter,llm_enrichment,email_finder,phone_finder,lead_finder,add_to_crm,sync_to_table,add_to_sequence,http_request; default=all)
  - `--out-file`: Write template JSON to file (single type writes payload only)
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch columns run`

Run a column

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns run [-h] --table-id TABLE_ID --column-id COLUMN_ID
                             [--scope {all,subset,row,firstN,filtered}]
                             [--row-id ROW_ID] [--row-ids [ROW_IDS ...]]
                             [--first-n FIRST_N] [--unprocessed-only]
                             [--filters-json FILTERS_JSON]
                             [--filters-file FILTERS_FILE]
                             [--data-json DATA_JSON] [--data-file DATA_FILE]
                             [--show-estimate] [--dry-run]
                             [--max-credits MAX_CREDITS] [--allow-unknown-max]
                             [--wait] [--quiet-wait]
                             [--poll-interval POLL_INTERVAL]
                             [--wait-timeout WAIT_TIMEOUT] [--fail-on-error]
                             [--fail-on-partial] [--base-url BASE_URL]
                             [--token TOKEN] [--use-x-api-key]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--scope` (choices=all,subset,row,firstN,filtered; default=all): Run scope: row=one explicit ID, subset=explicit many IDs, filtered=current filters, firstN=first N rows, all=entire table
  - `--row-id`: Single row ID for scope=row
  - `--row-ids`: Row IDs for subset scope (or a single row when scope=row)
  - `--first-n`: First N rows (for scope=firstN). Use with --unprocessed-only to process the next rows without reruns
  - `--unprocessed-only` (default=False): Only process rows without values (recommended with scope=firstN)
  - `--filters-json`: JSON object for scope=filtered
  - `--filters-file`: Path to JSON file for scope=filtered
  - `--data-json`: Explicit RunRequest payload JSON (overrides scope flags)
  - `--data-file`: Path to RunRequest payload JSON file (overrides scope flags)
  - `--show-estimate` (default=False): Include estimate response in output
  - `--dry-run` (default=False): Only estimate; do not execute run
  - `--max-credits`: Block run when estimate exceeds this value
  - `--allow-unknown-max` (default=False): Allow run when estimated_credits_max is null (max-credits guard uses min estimate)
  - `--wait` (default=False): Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}
  - `--quiet-wait` (default=False): Suppress per-poll output in --wait mode
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero when final status is error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero when final status is partial
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns run-next`

Run exactly N selected rows using subset scope

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id, --count`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns run-next [-h] --table-id TABLE_ID
                                  --column-id COLUMN_ID --count COUNT
                                  [--filters-json FILTERS_JSON]
                                  [--filters-file FILTERS_FILE]
                                  [--page-size PAGE_SIZE]
                                  [--include-processed] [--fail-if-empty]
                                  [--show-estimate] [--dry-run]
                                  [--max-credits MAX_CREDITS]
                                  [--allow-unknown-max] [--wait]
                                  [--quiet-wait]
                                  [--poll-interval POLL_INTERVAL]
                                  [--wait-timeout WAIT_TIMEOUT]
                                  [--fail-on-error] [--fail-on-partial]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--count` (required): Exact number of rows to queue
  - `--filters-json`: Optional JSON object to select from filtered rows
  - `--filters-file`: Optional JSON file to select from filtered rows
  - `--page-size` (default=200): Rows page size while selecting candidates (max 1000)
  - `--include-processed` (default=True): Include rows that already have output in candidate selection
  - `--fail-if-empty` (default=False): Exit non-zero when no eligible rows are selected
  - `--show-estimate` (default=False): Include estimate response in output
  - `--dry-run` (default=False): Only estimate; do not execute run
  - `--max-credits`: Block run when estimate exceeds this value
  - `--allow-unknown-max` (default=False): Allow run when estimated_credits_max is null (max-credits guard uses min estimate)
  - `--wait` (default=False): Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}
  - `--quiet-wait` (default=False): Suppress per-poll output in --wait mode
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero when final status is error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero when final status is partial
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns stop`

Stop a running column (cancel active job dispatch)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns stop [-h] --table-id TABLE_ID --column-id COLUMN_ID
                              [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns test-http-request`

Preview an HTTP Request column against the first table row

Resolve and execute one HTTP request using the first row in the table.
This preview does not write cells.
Pass either a full http_request column payload or a direct request config object.

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns test-http-request --table-id <TABLE_ID> --data-file column.json`
- Notes:

```text
Recommended flow:

autotouch columns recipe --type http_request --out-file column.json
autotouch columns test-http-request --table-id <TABLE_ID> --data-file column.json
autotouch columns create --table-id <TABLE_ID> --data-file column.json

Template syntax:
- {{column_key}} -> row value from the first table row
- {{secrets.name}} -> workspace secret or active org integration credential by provider slug
```
- Options:
  - `--table-id` (required)
  - `--data-json`: HTTP request column payload JSON or direct preview payload JSON
  - `--data-file`: HTTP request column payload file path or direct preview payload file path
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch columns update`

Update a column

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch columns update [-h] --table-id TABLE_ID --column-id COLUMN_ID
                                [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--data-json`: ColumnUpdate payload JSON
  - `--data-file`: ColumnUpdate payload file path
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `context`

#### `autotouch context`

Resolved requester context used by enrichment/runtime

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `resolved`
- Example:
  - `autotouch context [-h] {resolved} ...`

#### `autotouch context resolved`

Show effective requester context after org/personal overrides

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch context resolved [-h] [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `jobs`

#### `autotouch jobs`

Bulk job operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `get, list, watch`
- Example:
  - `autotouch jobs [-h] {get,list,watch} ...`

#### `autotouch jobs get`

Get bulk job details

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--job-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch jobs get [-h] --job-id JOB_ID [--base-url BASE_URL]
                          [--token TOKEN] [--use-x-api-key]
                          [--timeout TIMEOUT] [--output {json,ndjson,human}]
                          [--compact] [--select SELECT |
                          --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--job-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch jobs list`

List recent bulk jobs (recover latest job_id)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch jobs list [-h] [--table-id TABLE_ID] [--column-id COLUMN_ID]
                           [--status STATUS] [--provider PROVIDER]
                           [--limit LIMIT] [--base-url BASE_URL]
                           [--token TOKEN] [--use-x-api-key]
                           [--timeout TIMEOUT] [--output {json,ndjson,human}]
                           [--compact] [--select SELECT |
                           --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id`: Filter by table id
  - `--column-id`: Filter by column id
  - `--status`: Filter by status (or comma-separated statuses)
  - `--provider`: Filter by provider
  - `--limit` (default=20): Max jobs to return (1-100)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch jobs watch`

Poll bulk job status until terminal (or once)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--job-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch jobs watch [-h] --job-id JOB_ID [--once]
                            [--interval INTERVAL]
                            [--wait-timeout WAIT_TIMEOUT] [--fail-on-error]
                            [--fail-on-partial] [--base-url BASE_URL]
                            [--token TOKEN] [--use-x-api-key]
                            [--timeout TIMEOUT] [--output {json,ndjson,human}]
                            [--compact] [--select SELECT |
                            --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--job-id` (required)
  - `--once` (default=False): Fetch once and exit
  - `--interval` (default=2): Polling interval seconds
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero on error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero on partial
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `leads`

#### `autotouch leads`

Lead query + mutation operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `recipe, get, create, update, upsert-contact-channels, update-status, reassign-owner, query, count, stats, research, filters-metadata, research-tables`
- Example:
  - `autotouch leads [-h]
                       {recipe,get,create,update,upsert-contact-channels,upsert-contacts,update-status,reassign-owner,query,count,stats,research,filters-metadata,research-tables} ...`

#### `autotouch leads count`

Count leads matching a query payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads count [-h] [--data-json DATA_JSON]
                             [--data-file DATA_FILE]
                             [--filter-json FILTER_JSON]
                             [--filter-file FILTER_FILE]
                             [--sort-json SORT_JSON] [--sort-file SORT_FILE]
                             [--search SEARCH] [--limit LIMIT]
                             [--cursor CURSOR] [--scope {org,user}]
                             [--source-table-id SOURCE_TABLE_ID]
                             [--source-table-scope {company,lead}]
                             [--related-tables-mode {linked,direct,none}]
                             [--include-research-data]
                             [--include-placeholder-leads]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--data-json`: Explicit leads query payload JSON
  - `--data-file`: Path to leads query payload JSON file
  - `--filter-json`: Filter descriptor JSON object
  - `--filter-file`: Path to filter descriptor JSON file
  - `--sort-json`: Sort spec JSON object/array
  - `--sort-file`: Path to sort spec JSON file
  - `--search`: Free-text lead search
  - `--limit`: Pagination limit
  - `--cursor`: Pagination cursor
  - `--scope` (choices=org,user): Lead scope
  - `--source-table-id`: Research table id used for scope/research context
  - `--source-table-scope` (choices=company,lead): Research scope resolution mode
  - `--related-tables-mode` (choices=linked,direct,none): How related_tables should be populated
  - `--include-research-data` (default=False): Inline research_data when --source-table-id is provided
  - `--include-placeholder-leads` (default=False): Include placeholder/incomplete lead records
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads create`

Create a lead from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads create [-h] [--data-json DATA_JSON]
                              [--data-file DATA_FILE] [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--data-json`: Lead create payload JSON
  - `--data-file`: Path to lead create payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads filters-metadata`

List filterable lead fields and research columns

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads filters-metadata [-h] [--base-url BASE_URL]
                                        [--token TOKEN] [--use-x-api-key]
                                        [--timeout TIMEOUT]
                                        [--output {json,ndjson,human}]
                                        [--compact] [--select SELECT |
                                        --json-pointer JSON_POINTER]
                                        [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads get`

Get one lead by id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--lead-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads get [-h] --lead-id LEAD_ID [--base-url BASE_URL]
                           [--token TOKEN] [--use-x-api-key]
                           [--timeout TIMEOUT] [--output {json,ndjson,human}]
                           [--compact] [--select SELECT |
                           --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--lead-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads query`

Query/filter leads with descriptor payloads

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads query [-h] [--data-json DATA_JSON]
                             [--data-file DATA_FILE]
                             [--filter-json FILTER_JSON]
                             [--filter-file FILTER_FILE]
                             [--sort-json SORT_JSON] [--sort-file SORT_FILE]
                             [--search SEARCH] [--limit LIMIT]
                             [--cursor CURSOR] [--scope {org,user}]
                             [--source-table-id SOURCE_TABLE_ID]
                             [--source-table-scope {company,lead}]
                             [--related-tables-mode {linked,direct,none}]
                             [--include-research-data]
                             [--include-placeholder-leads]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--data-json`: Explicit leads query payload JSON
  - `--data-file`: Path to leads query payload JSON file
  - `--filter-json`: Filter descriptor JSON object
  - `--filter-file`: Path to filter descriptor JSON file
  - `--sort-json`: Sort spec JSON object/array
  - `--sort-file`: Path to sort spec JSON file
  - `--search`: Free-text lead search
  - `--limit`: Pagination limit
  - `--cursor`: Pagination cursor
  - `--scope` (choices=org,user): Lead scope
  - `--source-table-id`: Research table id used for scope/research context
  - `--source-table-scope` (choices=company,lead): Research scope resolution mode
  - `--related-tables-mode` (choices=linked,direct,none): How related_tables should be populated
  - `--include-research-data` (default=False): Inline research_data when --source-table-id is provided
  - `--include-placeholder-leads` (default=False): Include placeholder/incomplete lead records
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads reassign-owner`

Bulk reassign lead owner by ids or descriptor selection

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads reassign-owner [-h] [--data-json DATA_JSON]
                                      [--data-file DATA_FILE]
                                      [--lead-id LEAD_ID]
                                      [--lead-ids-json LEAD_IDS_JSON]
                                      [--lead-ids-file LEAD_IDS_FILE]
                                      [--lead-ids-column LEAD_IDS_COLUMN]
                                      [--filter-json FILTER_JSON]
                                      [--filter-file FILTER_FILE]
                                      [--sort-json SORT_JSON]
                                      [--sort-file SORT_FILE]
                                      [--search SEARCH] [--limit LIMIT]
                                      [--scope {org,user}]
                                      [--source-table-id SOURCE_TABLE_ID]
                                      [--source-table-scope {company,lead}]
                                      [--user-id USER_ID]
                                      [--base-url BASE_URL] [--token TOKEN]
                                      [--use-x-api-key] [--timeout TIMEOUT]
                                      [--output {json,ndjson,human}]
                                      [--compact] [--select SELECT |
                                      --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Explicit bulk lead action payload JSON
  - `--data-file`: Path to bulk lead action payload JSON file
  - `--lead-id`: Lead id (repeatable; comma-separated also supported)
  - `--lead-ids-json`: JSON array or object with lead_ids[]
  - `--lead-ids-file`: Path to JSON/TXT/CSV file with lead_ids[]
  - `--lead-ids-column` (default=lead_id): CSV column for lead ids (default: lead_id)
  - `--filter-json`: Filter descriptor JSON object
  - `--filter-file`: Path to filter descriptor JSON file
  - `--sort-json`: Sort spec JSON object/array
  - `--sort-file`: Path to sort spec JSON file
  - `--search`: Free-text lead search
  - `--limit`: Optional descriptor selection limit
  - `--scope` (choices=org,user): Lead scope
  - `--source-table-id`: Optional research table id for descriptor selection
  - `--source-table-scope` (choices=company,lead): Optional research scope resolution mode
  - `--user-id`: Target owner user id
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads recipe`

Print lead payload recipes for create/update/query/research/bulk selection

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads recipe [-h]
                              [--type {all,create,update,contact_upsert,query,research,selection}]
                              [--out-file OUT_FILE] [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--type` (choices=all,create,update,contact_upsert,query,research,selection; default=all)
  - `--out-file`: Optional path to save the selected payload JSON
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads research`

Fetch research row data for specific lead ids

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads research [-h] [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--lead-id LEAD_ID]
                                [--lead-ids-json LEAD_IDS_JSON]
                                [--lead-ids-file LEAD_IDS_FILE]
                                [--source-table-id SOURCE_TABLE_ID]
                                [--field-id FIELD_ID]
                                [--field-ids-json FIELD_IDS_JSON]
                                [--field-ids-file FIELD_IDS_FILE]
                                [--base-url BASE_URL] [--token TOKEN]
                                [--use-x-api-key] [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Explicit leads research payload JSON
  - `--data-file`: Path to leads research payload JSON file
  - `--lead-id`: Lead id (repeatable; comma-separated also supported)
  - `--lead-ids-json`: JSON array or object with lead_ids[]
  - `--lead-ids-file`: Path to JSON file with lead_ids[]
  - `--source-table-id`: Research table id
  - `--field-id`: Research field/column id to include (repeatable; comma-separated also supported)
  - `--field-ids-json`: JSON array or object with field_ids[]
  - `--field-ids-file`: Path to JSON file with field_ids[]
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads research-tables`

List research tables available for lead lookups

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads research-tables [-h] [--base-url BASE_URL]
                                       [--token TOKEN] [--use-x-api-key]
                                       [--timeout TIMEOUT]
                                       [--output {json,ndjson,human}]
                                       [--compact] [--select SELECT |
                                       --json-pointer JSON_POINTER]
                                       [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads stats`

Aggregate stats for leads matching a query payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads stats [-h] [--data-json DATA_JSON]
                             [--data-file DATA_FILE]
                             [--filter-json FILTER_JSON]
                             [--filter-file FILTER_FILE]
                             [--sort-json SORT_JSON] [--sort-file SORT_FILE]
                             [--search SEARCH] [--limit LIMIT]
                             [--cursor CURSOR] [--scope {org,user}]
                             [--source-table-id SOURCE_TABLE_ID]
                             [--source-table-scope {company,lead}]
                             [--related-tables-mode {linked,direct,none}]
                             [--include-research-data]
                             [--include-placeholder-leads]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--data-json`: Explicit leads query payload JSON
  - `--data-file`: Path to leads query payload JSON file
  - `--filter-json`: Filter descriptor JSON object
  - `--filter-file`: Path to filter descriptor JSON file
  - `--sort-json`: Sort spec JSON object/array
  - `--sort-file`: Path to sort spec JSON file
  - `--search`: Free-text lead search
  - `--limit`: Pagination limit
  - `--cursor`: Pagination cursor
  - `--scope` (choices=org,user): Lead scope
  - `--source-table-id`: Research table id used for scope/research context
  - `--source-table-scope` (choices=company,lead): Research scope resolution mode
  - `--related-tables-mode` (choices=linked,direct,none): How related_tables should be populated
  - `--include-research-data` (default=False): Inline research_data when --source-table-id is provided
  - `--include-placeholder-leads` (default=False): Include placeholder/incomplete lead records
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads update`

Update one lead with a partial JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--lead-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads update [-h] --lead-id LEAD_ID [--data-json DATA_JSON]
                              [--data-file DATA_FILE] [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--lead-id` (required)
  - `--data-json`: Lead update payload JSON
  - `--data-file`: Path to lead update payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads update-status`

Bulk update lead status by ids or descriptor selection

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads update-status [-h] [--data-json DATA_JSON]
                                     [--data-file DATA_FILE]
                                     [--lead-id LEAD_ID]
                                     [--lead-ids-json LEAD_IDS_JSON]
                                     [--lead-ids-file LEAD_IDS_FILE]
                                     [--lead-ids-column LEAD_IDS_COLUMN]
                                     [--filter-json FILTER_JSON]
                                     [--filter-file FILTER_FILE]
                                     [--sort-json SORT_JSON]
                                     [--sort-file SORT_FILE] [--search SEARCH]
                                     [--limit LIMIT] [--scope {org,user}]
                                     [--source-table-id SOURCE_TABLE_ID]
                                     [--source-table-scope {company,lead}]
                                     [--status STATUS] [--base-url BASE_URL]
                                     [--token TOKEN] [--use-x-api-key]
                                     [--timeout TIMEOUT]
                                     [--output {json,ndjson,human}]
                                     [--compact] [--select SELECT |
                                     --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Explicit bulk lead action payload JSON
  - `--data-file`: Path to bulk lead action payload JSON file
  - `--lead-id`: Lead id (repeatable; comma-separated also supported)
  - `--lead-ids-json`: JSON array or object with lead_ids[]
  - `--lead-ids-file`: Path to JSON/TXT/CSV file with lead_ids[]
  - `--lead-ids-column` (default=lead_id): CSV column for lead ids (default: lead_id)
  - `--filter-json`: Filter descriptor JSON object
  - `--filter-file`: Path to filter descriptor JSON file
  - `--sort-json`: Sort spec JSON object/array
  - `--sort-file`: Path to sort spec JSON file
  - `--search`: Free-text lead search
  - `--limit`: Optional descriptor selection limit
  - `--scope` (choices=org,user): Lead scope
  - `--source-table-id`: Optional research table id for descriptor selection
  - `--source-table-scope` (choices=company,lead): Optional research scope resolution mode
  - `--status`: Lead status to apply
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch leads upsert-contact-channels`

Merge emails/phones into a lead without replacing the full arrays

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Aliases: `upsert-contacts`
- Required flags: `--lead-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch leads upsert-contact-channels [-h] --lead-id LEAD_ID
                                               [--data-json DATA_JSON]
                                               [--data-file DATA_FILE]
                                               [--base-url BASE_URL]
                                               [--token TOKEN]
                                               [--use-x-api-key]
                                               [--timeout TIMEOUT]
                                               [--output {json,ndjson,human}]
                                               [--compact] [--select SELECT |
                                               --json-pointer JSON_POINTER]
                                               [--verbose]`
- Options:
  - `--lead-id` (required)
  - `--data-json`: Contact upsert payload JSON
  - `--data-file`: Path to contact upsert payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `linkedin`

#### `autotouch linkedin`

LinkedIn list-building operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `recipe, status, limits, search, search-params, posts, post, comments, reactions`
- Example:
  - `autotouch linkedin [-h]
                          {recipe,status,limits,search,search-params,posts,post,comments,reactions} ...`

#### `autotouch linkedin comments`

List comments on a LinkedIn post

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--post-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin comments [-h] --post-id POST_ID [--cursor CURSOR]
                                   [--limit LIMIT] [--base-url BASE_URL]
                                   [--token TOKEN] [--use-x-api-key]
                                   [--timeout TIMEOUT]
                                   [--output {json,ndjson,human}] [--compact]
                                   [--select SELECT |
                                   --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--post-id` (required): LinkedIn post ID
  - `--cursor`: Pagination cursor from previous response
  - `--limit` (default=100): Results per page, 1-100 (default: 100)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin limits`

View LinkedIn send limits and usage

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin limits [-h] [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin post`

Get full details for a single LinkedIn post

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--post-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin post [-h] --post-id POST_ID [--base-url BASE_URL]
                               [--token TOKEN] [--use-x-api-key]
                               [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--post-id` (required): LinkedIn post ID
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin posts`

List LinkedIn posts for a user

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--identifier`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin posts [-h] --identifier IDENTIFIER [--cursor CURSOR]
                                [--limit LIMIT] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--identifier` (required): LinkedIn profile URL, public ID, or URN
  - `--cursor`: Pagination cursor from previous response
  - `--limit` (default=25): Results per page, 1-100 (default: 25)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin reactions`

List reactions on a LinkedIn post

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--post-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin reactions [-h] --post-id POST_ID [--cursor CURSOR]
                                    [--limit LIMIT] [--base-url BASE_URL]
                                    [--token TOKEN] [--use-x-api-key]
                                    [--timeout TIMEOUT]
                                    [--output {json,ndjson,human}] [--compact]
                                    [--select SELECT |
                                    --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--post-id` (required): LinkedIn post ID
  - `--cursor`: Pagination cursor from previous response
  - `--limit` (default=100): Results per page, 1-100 (default: 100)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin recipe`

Print LinkedIn payload recipes for search and list-building

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin recipe [-h]
                                 [--type {all,search,search_url,search_params,posts,comments,reactions}]
                                 [--out-file OUT_FILE] [--base-url BASE_URL]
                                 [--token TOKEN] [--use-x-api-key]
                                 [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--type` (choices=all,search,search_url,search_params,posts,comments,reactions; default=all)
  - `--out-file`: Optional path to save the selected payload JSON
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin search`

Search LinkedIn for people, companies, jobs, or posts

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin search [-h] [--data-json DATA_JSON]
                                 [--data-file DATA_FILE] [--url URL]
                                 [--category {people,companies,jobs,posts}]
                                 [--keywords KEYWORDS]
                                 [--linkedin-api {classic,sales_navigator}]
                                 [--cursor CURSOR] [--limit LIMIT]
                                 [--extra-params-json EXTRA_PARAMS_JSON]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Explicit search payload JSON (overrides individual flags)
  - `--data-file`: Path to search payload JSON file
  - `--url`: Full LinkedIn/Sales Navigator search URL (overrides keyword filters)
  - `--category` (choices=people,companies,jobs,posts; default=people): Search category (default: people)
  - `--keywords`: Free-text keyword search
  - `--linkedin-api` (choices=classic,sales_navigator; default=classic): API mode (default: classic)
  - `--cursor`: Pagination cursor from previous response
  - `--limit` (default=25): Results per page, 1-250 (default: 25)
  - `--extra-params-json`: JSON object with additional search filters (location IDs, industry, etc.)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin search-params`

Resolve names to LinkedIn parameter IDs for search filters

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--type`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin search-params [-h] --type TYPE [--keywords KEYWORDS]
                                        [--limit LIMIT] [--base-url BASE_URL]
                                        [--token TOKEN] [--use-x-api-key]
                                        [--timeout TIMEOUT]
                                        [--output {json,ndjson,human}]
                                        [--compact] [--select SELECT |
                                        --json-pointer JSON_POINTER]
                                        [--verbose]`
- Options:
  - `--type` (required): Parameter type: location, industry, company, school, title, language, etc.
  - `--keywords` (default=): Search text to match
  - `--limit` (default=25): Max results, 1-250 (default: 25)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch linkedin status`

Check LinkedIn connection status

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch linkedin status [-h] [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `onboarding`

#### `autotouch onboarding`

Onboarding helpers

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `submit-domain, schema`
- Example:
  - `autotouch onboarding [-h] {submit-domain,schema} ...`

#### `autotouch onboarding schema`

Print onboarding payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch onboarding schema [-h] [--type {all,submit_domain}]
                                   [--out-file OUT_FILE]
                                   [--output {json,ndjson,human}] [--compact]
                                   [--select SELECT |
                                   --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,submit_domain; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch onboarding submit-domain`

Analyze company website and seed org context

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch onboarding submit-domain [-h] [--website WEBSITE]
                                          [--domain DOMAIN]
                                          [--data-json DATA_JSON]
                                          [--data-file DATA_FILE]
                                          [--base-url BASE_URL]
                                          [--token TOKEN] [--use-x-api-key]
                                          [--timeout TIMEOUT]
                                          [--output {json,ndjson,human}]
                                          [--compact] [--select SELECT |
                                          --json-pointer JSON_POINTER]
                                          [--verbose]`
- Options:
  - `--website`: Company website/domain
  - `--domain`: Alias for --website
  - `--data-json`: Explicit submit-domain payload JSON
  - `--data-file`: Path to submit-domain payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `org-context`

#### `autotouch org-context`

Organization value prop / ICP context

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `get, set, schema`
- Example:
  - `autotouch org-context [-h] {get,set,schema} ...`

#### `autotouch org-context get`

Fetch organization context

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch org-context get [-h] [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch org-context schema`

Print org-context payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch org-context schema [-h] [--type {all,set}]
                                    [--out-file OUT_FILE]
                                    [--output {json,ndjson,human}] [--compact]
                                    [--select SELECT |
                                    --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,set; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch org-context set`

Save organization context

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch org-context set [-h] [--source SOURCE]
                                 [--value-proposition VALUE_PROPOSITION]
                                 [--ideal-title IDEAL_TITLE]
                                 [--buyer-persona BUYER_PERSONA]
                                 [--user-persona USER_PERSONA]
                                 [--voice-profile VOICE_PROFILE]
                                 [--case-study-url CASE_STUDY_URL]
                                 [--data-json DATA_JSON]
                                 [--data-file DATA_FILE] [--base-url BASE_URL]
                                 [--token TOKEN] [--use-x-api-key]
                                 [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--source` (default=cli): Context source label (default: cli)
  - `--value-proposition`: Organization value proposition
  - `--ideal-title`: Ideal title (repeatable; comma-separated also supported)
  - `--buyer-persona`: Buyer persona / ICP buyer
  - `--user-persona`: User persona / ICP users
  - `--voice-profile`: Voice profile guidance
  - `--case-study-url`: Case-study URL (repeatable)
  - `--data-json`: Explicit org context payload JSON
  - `--data-file`: Path to org context payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `personal-context`

#### `autotouch personal-context`

Personal sender / rep context

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `get, set, schema`
- Example:
  - `autotouch personal-context [-h] {get,set,schema} ...`

#### `autotouch personal-context get`

Fetch personal context

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch personal-context get [-h] [--base-url BASE_URL]
                                      [--token TOKEN] [--use-x-api-key]
                                      [--timeout TIMEOUT]
                                      [--output {json,ndjson,human}]
                                      [--compact] [--select SELECT |
                                      --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch personal-context schema`

Print personal-context payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch personal-context schema [-h] [--type {all,set}]
                                         [--out-file OUT_FILE]
                                         [--output {json,ndjson,human}]
                                         [--compact] [--select SELECT |
                                         --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,set; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch personal-context set`

Save personal context

- Auth: `user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch personal-context set [-h] [--title TITLE]
                                      [--linkedin-url LINKEDIN_URL]
                                      [--territory TERRITORY]
                                      [--use-personal-value-proposition]
                                      [--personal-value-proposition PERSONAL_VALUE_PROPOSITION]
                                      [--voice-profile VOICE_PROFILE]
                                      [--use-personal-voice-profile]
                                      [--data-json DATA_JSON]
                                      [--data-file DATA_FILE]
                                      [--base-url BASE_URL] [--token TOKEN]
                                      [--use-x-api-key] [--timeout TIMEOUT]
                                      [--output {json,ndjson,human}]
                                      [--compact] [--select SELECT |
                                      --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--title`: User title
  - `--linkedin-url`: User LinkedIn URL
  - `--territory`: Territory or region (repeatable)
  - `--use-personal-value-proposition` (default=False): Prefer the personal value proposition over org default
  - `--personal-value-proposition`: Personal value proposition
  - `--voice-profile`: Personal voice profile guidance
  - `--use-personal-voice-profile` (default=False): Prefer the personal voice profile over org default
  - `--data-json`: Explicit personal context payload JSON
  - `--data-file`: Path to personal context payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `prompts`

#### `autotouch prompts`

Manage saved prompt templates for LLM enrichment columns

List, create, update, and delete prompt templates used by LLM enrichment columns. Templates can be scoped to a single user (private) or shared with the team.

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, get, create, update, delete, schema`
- Example:
  - `autotouch prompts list`
  - `autotouch prompts list --mode agent`
  - `autotouch prompts get --id <TEMPLATE_ID>`
  - `autotouch prompts create --data-file prompt.json`
  - `autotouch prompts delete --id <TEMPLATE_ID> --yes`
- Notes:

```text
Developer API keys need prompts:read / prompts:write scopes (or *) for these endpoints.
```

#### `autotouch prompts create`

Create a new prompt template

Create a new prompt template. Requires a JSON payload with name, content, type, and mode.

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts create [-h] [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Inline JSON payload
  - `--data-file`: Path to JSON payload file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch prompts delete`

Delete a prompt template

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts delete [-h] --id ID [--yes] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--id` (required): Prompt template ID
  - `--yes` (default=False): Confirm deletion
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch prompts get`

Get a single prompt template by ID

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts get [-h] --id ID [--base-url BASE_URL]
                             [--token TOKEN] [--use-x-api-key]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--id` (required): Prompt template ID
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch prompts list`

List prompt templates

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts list [-h] [--mode {basic,agent}]
                              [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--mode` (choices=basic,agent): Filter by mode
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch prompts schema`

Print prompt template payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts schema [-h] [--type {all,create,update}]
                                [--out-file OUT_FILE]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,create,update; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch prompts update`

Update an existing prompt template

Partially update a prompt template. Only include the fields you want to change.

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch prompts update [-h] --id ID [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--id` (required): Prompt template ID
  - `--data-json`: Inline JSON payload
  - `--data-file`: Path to JSON payload file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `rows`

#### `autotouch rows`

Row operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, get, add, import-csv, schema, import-status, import-verify, import-rollback, delete`
- Example:
  - `autotouch rows [-h]
                      {list,get,add,import-csv,schema,import-status,import-verify,import-rollback,delete} ...`

#### `autotouch rows add`

Add rows (blank count or records payload)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows add [-h] --table-id TABLE_ID [--count COUNT]
                          [--records-json RECORDS_JSON]
                          [--records-file RECORDS_FILE] [--detect-types]
                          [--base-url BASE_URL] [--token TOKEN]
                          [--use-x-api-key] [--timeout TIMEOUT]
                          [--output {json,ndjson,human}] [--compact]
                          [--select SELECT | --json-pointer JSON_POINTER]
                          [--verbose]`
- Options:
  - `--table-id` (required)
  - `--count` (default=1): Blank rows to create (ignored if records provided)
  - `--records-json`: Object, list, or {records:[...]} payload
  - `--records-file`: Path to JSON file containing records payload
  - `--detect-types` (default=False): Enable detect_types when patching record values
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows delete`

Delete a single row

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--table-id, --row-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows delete [-h] --table-id TABLE_ID --row-id ROW_ID
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--table-id` (required)
  - `--row-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows get`

Get one flattened row by id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --row-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows get [-h] --table-id TABLE_ID --row-id ROW_ID
                          [--base-url BASE_URL] [--token TOKEN]
                          [--use-x-api-key] [--timeout TIMEOUT]
                          [--output {json,ndjson,human}] [--compact]
                          [--select SELECT | --json-pointer JSON_POINTER]
                          [--verbose]`
- Options:
  - `--table-id` (required)
  - `--row-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows import-csv`

Import CSV rows by creating rows + patching cells

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --file`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows import-csv [-h] --table-id TABLE_ID
                                 [--confirm-table-id CONFIRM_TABLE_ID]
                                 --file FILE [--transport {optimized,direct}]
                                 [--dry-run] [--validate-only]
                                 [--sample-size SAMPLE_SIZE]
                                 [--checkpoint-file CHECKPOINT_FILE]
                                 [--allow-reimport]
                                 [--expected-rows EXPECTED_ROWS]
                                 [--require-columns REQUIRE_COLUMNS]
                                 [--duplicate-key DUPLICATE_KEY]
                                 [--require-non-empty REQUIRE_NON_EMPTY]
                                 [--delimiter DELIMITER] [--encoding ENCODING]
                                 [--limit LIMIT] [--no-trim-headers]
                                 [--trim-values] [--no-empty-as-null]
                                 [--no-skip-empty-rows] [--detect-types]
                                 [--origin ORIGIN]
                                 [--field-mappings-json FIELD_MAPPINGS_JSON]
                                 [--field-mappings-file FIELD_MAPPINGS_FILE]
                                 [--no-check-company-blacklist]
                                 [--check-email-blacklist] [--sync] [--wait]
                                 [--poll-interval POLL_INTERVAL]
                                 [--wait-timeout WAIT_TIMEOUT]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--confirm-table-id`: Safety check: must match --table-id or command exits
  - `--file` (required): CSV file path
  - `--transport` (choices=optimized,direct; default=optimized): Import transport: optimized uses /import-optimized (recommended); direct uses row/cell API loop
  - `--dry-run` (default=False): Parse CSV and print summary without creating rows
  - `--validate-only` (default=False): Server-side CSV parse/shape validation only (no writes)
  - `--sample-size` (default=5): Sample rows returned by --validate-only (0-20, default: 5)
  - `--checkpoint-file`: Optional JSON checkpoint file (guards duplicate imports unless --allow-reimport)
  - `--allow-reimport` (default=False): Ignore checkpoint guard and import again
  - `--expected-rows`: Assert row count equals this value
  - `--require-columns`: Assert required column keys exist (comma-separated; repeatable)
  - `--duplicate-key`: Assert no duplicates on this identity key (comma-separated; repeatable)
  - `--require-non-empty`: Assert non-empty ratio by key (key:ratio, comma-separated; repeatable)
  - `--delimiter` (default=,): CSV delimiter (default: ,)
  - `--encoding` (default=utf-8): File encoding (default: utf-8)
  - `--limit`: Optional max records to import
  - `--no-trim-headers` (default=True): Do not trim header whitespace
  - `--trim-values` (default=False): Trim cell string values
  - `--no-empty-as-null` (default=True): Preserve empty strings instead of null
  - `--no-skip-empty-rows` (default=True): Keep fully empty rows
  - `--detect-types` (default=False): Enable detect_types while patching
  - `--origin` (default=csv): Column origin tag for optimized import
  - `--field-mappings-json`: Field mappings JSON object for optimized import
  - `--field-mappings-file`: Field mappings JSON file for optimized import
  - `--no-check-company-blacklist` (default=True): Disable company blacklist filtering for optimized import
  - `--check-email-blacklist` (default=False): Enable email blacklist filtering for optimized import
  - `--sync` (default=True): Use synchronous /import-optimized processing instead of background task mode
  - `--wait` (default=False): Wait for async optimized import to complete
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows import-rollback`

Rollback rows created by import task_id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows import-rollback [-h] --table-id TABLE_ID
                                      --task-id TASK_ID [--dry-run]
                                      [--base-url BASE_URL] [--token TOKEN]
                                      [--use-x-api-key] [--timeout TIMEOUT]
                                      [--output {json,ndjson,human}]
                                      [--compact] [--select SELECT |
                                      --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--task-id` (required)
  - `--dry-run` (default=False): Preview rollback scope without deleting rows
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows import-status`

Get or watch async CSV import status

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows import-status [-h] --table-id TABLE_ID --task-id TASK_ID
                                    [--wait] [--poll-interval POLL_INTERVAL]
                                    [--wait-timeout WAIT_TIMEOUT]
                                    [--base-url BASE_URL] [--token TOKEN]
                                    [--use-x-api-key] [--timeout TIMEOUT]
                                    [--output {json,ndjson,human}] [--compact]
                                    [--select SELECT |
                                    --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--task-id` (required)
  - `--wait` (default=False): Poll until completed/failed
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows import-verify`

Verify imported rows for task_id assertions

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows import-verify [-h] --table-id TABLE_ID --task-id TASK_ID
                                    [--expected-rows EXPECTED_ROWS]
                                    [--require-columns REQUIRE_COLUMNS]
                                    [--duplicate-key DUPLICATE_KEY]
                                    [--require-non-empty REQUIRE_NON_EMPTY]
                                    [--base-url BASE_URL] [--token TOKEN]
                                    [--use-x-api-key] [--timeout TIMEOUT]
                                    [--output {json,ndjson,human}] [--compact]
                                    [--select SELECT |
                                    --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--task-id` (required)
  - `--expected-rows`: Assert imported row count equals this value
  - `--require-columns`: Assert required column keys exist (comma-separated; repeatable)
  - `--duplicate-key`: Assert no duplicates on this identity key (comma-separated; repeatable)
  - `--require-non-empty`: Assert non-empty ratio by key (key:ratio, comma-separated; repeatable)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows list`

List table rows with optional filters/sort

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows list [-h] --table-id TABLE_ID
                           [--filters-json FILTERS_JSON]
                           [--filters-file FILTERS_FILE]
                           [--sort-json SORT_JSON] [--sort-file SORT_FILE]
                           [--page-size PAGE_SIZE] [--cursor CURSOR]
                           [--base-url BASE_URL] [--token TOKEN]
                           [--use-x-api-key] [--timeout TIMEOUT]
                           [--output {json,ndjson,human}] [--compact]
                           [--select SELECT | --json-pointer JSON_POINTER]
                           [--verbose]`
- Options:
  - `--table-id` (required)
  - `--filters-json`: Optional JSON object for server-side filters
  - `--filters-file`: Optional JSON file for server-side filters
  - `--sort-json`: Optional JSON object for server-side sort
  - `--sort-file`: Optional JSON file for server-side sort
  - `--page-size` (default=50): Rows per page (1-1000, default 50)
  - `--cursor`: Pagination cursor from a previous rows list response
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch rows schema`

Print row payload schemas for add/import helpers

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch rows schema [-h]
                             [--type {all,add_records,import_field_mappings}]
                             [--out-file OUT_FILE]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,add_records,import_field_mappings; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `run`

#### `autotouch run`

Alias for: columns run

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch run [-h] --table-id TABLE_ID --column-id COLUMN_ID
                     [--scope {all,subset,row,firstN,filtered}]
                     [--row-id ROW_ID] [--row-ids [ROW_IDS ...]]
                     [--first-n FIRST_N] [--unprocessed-only]
                     [--filters-json FILTERS_JSON]
                     [--filters-file FILTERS_FILE] [--data-json DATA_JSON]
                     [--data-file DATA_FILE] [--show-estimate] [--dry-run]
                     [--max-credits MAX_CREDITS] [--allow-unknown-max]
                     [--wait] [--quiet-wait] [--poll-interval POLL_INTERVAL]
                     [--wait-timeout WAIT_TIMEOUT] [--fail-on-error]
                     [--fail-on-partial] [--base-url BASE_URL] [--token TOKEN]
                     [--use-x-api-key] [--timeout TIMEOUT]
                     [--output {json,ndjson,human}] [--compact]
                     [--select SELECT | --json-pointer JSON_POINTER]
                     [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--scope` (choices=all,subset,row,firstN,filtered; default=all): Run scope: row=one explicit ID, subset=explicit many IDs, filtered=current filters, firstN=first N rows, all=entire table
  - `--row-id`: Single row ID for scope=row
  - `--row-ids`: Row IDs for subset scope (or a single row when scope=row)
  - `--first-n`: First N rows (for scope=firstN). Use with --unprocessed-only to process the next rows without reruns
  - `--unprocessed-only` (default=False): Only process rows without values (recommended with scope=firstN)
  - `--filters-json`: JSON object for scope=filtered
  - `--filters-file`: Path to JSON file for scope=filtered
  - `--data-json`: Explicit RunRequest payload JSON (overrides scope flags)
  - `--data-file`: Path to RunRequest payload JSON file (overrides scope flags)
  - `--show-estimate` (default=False): Include estimate response in output
  - `--dry-run` (default=False): Only estimate; do not execute run
  - `--max-credits`: Block run when estimate exceeds this value
  - `--allow-unknown-max` (default=False): Allow run when estimated_credits_max is null (max-credits guard uses min estimate)
  - `--wait` (default=False): Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}
  - `--quiet-wait` (default=False): Suppress per-poll output in --wait mode
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero when final status is error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero when final status is partial
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `run-next`

#### `autotouch run-next`

Alias for: columns run-next

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id, --column-id, --count`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch run-next [-h] --table-id TABLE_ID --column-id COLUMN_ID
                          --count COUNT [--filters-json FILTERS_JSON]
                          [--filters-file FILTERS_FILE]
                          [--page-size PAGE_SIZE] [--include-processed]
                          [--fail-if-empty] [--show-estimate] [--dry-run]
                          [--max-credits MAX_CREDITS] [--allow-unknown-max]
                          [--wait] [--quiet-wait]
                          [--poll-interval POLL_INTERVAL]
                          [--wait-timeout WAIT_TIMEOUT] [--fail-on-error]
                          [--fail-on-partial] [--base-url BASE_URL]
                          [--token TOKEN] [--use-x-api-key]
                          [--timeout TIMEOUT] [--output {json,ndjson,human}]
                          [--compact] [--select SELECT |
                          --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--count` (required): Exact number of rows to queue
  - `--filters-json`: Optional JSON object to select from filtered rows
  - `--filters-file`: Optional JSON file to select from filtered rows
  - `--page-size` (default=200): Rows page size while selecting candidates (max 1000)
  - `--include-processed` (default=True): Include rows that already have output in candidate selection
  - `--fail-if-empty` (default=False): Exit non-zero when no eligible rows are selected
  - `--show-estimate` (default=False): Include estimate response in output
  - `--dry-run` (default=False): Only estimate; do not execute run
  - `--max-credits`: Block run when estimate exceeds this value
  - `--allow-unknown-max` (default=False): Allow run when estimated_credits_max is null (max-credits guard uses min estimate)
  - `--wait` (default=False): Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}
  - `--quiet-wait` (default=False): Suppress per-poll output in --wait mode
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero when final status is error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero when final status is partial
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `schema`

#### `autotouch schema`

Print shared descriptor schemas used across commands

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch schema [-h]
                        [--type {all,filter_descriptor,sort_spec,run_request,selection_descriptor}]
                        [--out-file OUT_FILE] [--output {json,ndjson,human}]
                        [--compact] [--select SELECT |
                        --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,filter_descriptor,sort_spec,run_request,selection_descriptor; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `search`

#### `autotouch search`

Provider-hidden search and list-building operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `recipe, companies, people, similar-companies, news, local-businesses, reviews, filings`
- Example:
  - `autotouch search [-h]
                        {recipe,companies,people,similar-companies,news,local-businesses,reviews,filings} ...`

#### `autotouch search companies`

Find companies with provider-hidden neural search

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search companies [-h] [--query QUERY] [--limit LIMIT]
                                  [--data-json DATA_JSON]
                                  [--data-file DATA_FILE]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--query`: Free-text company query
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search filings`

Research public company filings

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search filings [-h] [--company-name COMPANY_NAME]
                                [--filing-type FILING_TYPE]
                                [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--company-name`: Public company name
  - `--filing-type`: Filing type (repeatable; comma-separated also supported)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search local-businesses`

Search local businesses

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search local-businesses [-h] [--query QUERY] [--limit LIMIT]
                                         [--country COUNTRY]
                                         [--language LANGUAGE] [--page PAGE]
                                         [--data-json DATA_JSON]
                                         [--data-file DATA_FILE]
                                         [--base-url BASE_URL] [--token TOKEN]
                                         [--use-x-api-key] [--timeout TIMEOUT]
                                         [--output {json,ndjson,human}]
                                         [--compact] [--select SELECT |
                                         --json-pointer JSON_POINTER]
                                         [--verbose]`
- Options:
  - `--query`: Local business query
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--country` (default=us): Country code (default: us)
  - `--language` (default=en): Language code (default: en)
  - `--page` (default=1): Page number (default: 1)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search news`

Search recent news

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search news [-h] [--query QUERY] [--days-back DAYS_BACK]
                             [--limit LIMIT] [--data-json DATA_JSON]
                             [--data-file DATA_FILE] [--base-url BASE_URL]
                             [--token TOKEN] [--use-x-api-key]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--query`: News query
  - `--days-back` (default=7): Lookback window in days (default: 7)
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search people`

Find people with provider-hidden neural search

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search people [-h] [--query QUERY] [--company COMPANY]
                               [--location LOCATION] [--skill SKILL]
                               [--limit LIMIT] [--data-json DATA_JSON]
                               [--data-file DATA_FILE] [--base-url BASE_URL]
                               [--token TOKEN] [--use-x-api-key]
                               [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--query`: Free-text role/persona query
  - `--company`: Optional company name
  - `--location`: Optional location
  - `--skill`: Optional skill (repeatable; comma-separated also supported)
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search recipe`

Print search payload recipes

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search recipe [-h]
                               [--type {all,companies,people,similar_companies,news,local_businesses,reviews,filings}]
                               [--out-file OUT_FILE] [--base-url BASE_URL]
                               [--token TOKEN] [--use-x-api-key]
                               [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--type` (choices=all,companies,people,similar_companies,news,local_businesses,reviews,filings; default=all)
  - `--out-file`: Optional path to save the selected payload JSON
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search reviews`

Fetch reviews for a known listing

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search reviews [-h] [--cid CID] [--place-id PLACE_ID]
                                [--fid FID] [--sort-by SORT_BY]
                                [--limit LIMIT] [--country COUNTRY]
                                [--language LANGUAGE]
                                [--next-page-token NEXT_PAGE_TOKEN]
                                [--page PAGE] [--data-json DATA_JSON]
                                [--data-file DATA_FILE] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--cid`: Listing CID
  - `--place-id`: Listing place_id
  - `--fid`: Listing fid
  - `--sort-by` (default=newest): Sort order (default: newest)
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--country` (default=us): Country code (default: us)
  - `--language` (default=en): Language code (default: en)
  - `--next-page-token`: Pagination token
  - `--page` (default=1): Page number (default: 1)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch search similar-companies`

Find companies similar to a seed company

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch search similar-companies [-h] [--company-name COMPANY_NAME]
                                          [--limit LIMIT]
                                          [--data-json DATA_JSON]
                                          [--data-file DATA_FILE]
                                          [--base-url BASE_URL]
                                          [--token TOKEN] [--use-x-api-key]
                                          [--timeout TIMEOUT]
                                          [--output {json,ndjson,human}]
                                          [--compact] [--select SELECT |
                                          --json-pointer JSON_POINTER]
                                          [--verbose]`
- Options:
  - `--company-name`: Seed company name
  - `--limit` (default=25): Max results, 1-100 (default: 25)
  - `--data-json`: Explicit request payload JSON
  - `--data-file`: Path to request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `sequences`

#### `autotouch sequences`

Sequence management and enrollment

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, get, stats, delivery-status, recipe, create, update, delete, clone, status, activate, pause, archive, enroll, pause-enrollment`
- Example:
  - `autotouch sequences [-h]
                           {list,get,stats,delivery-status,recipe,create,update,delete,clone,status,activate,pause,archive,enroll,pause-enrollment} ...`

#### `autotouch sequences activate`

Activate a sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences activate [-h] --sequence-id SEQUENCE_ID
                                    [--actor-user-id ACTOR_USER_ID]
                                    [--base-url BASE_URL] [--token TOKEN]
                                    [--use-x-api-key] [--timeout TIMEOUT]
                                    [--output {json,ndjson,human}] [--compact]
                                    [--select SELECT |
                                    --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences archive`

Archive a sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences archive [-h] --sequence-id SEQUENCE_ID
                                   [--actor-user-id ACTOR_USER_ID]
                                   [--base-url BASE_URL] [--token TOKEN]
                                   [--use-x-api-key] [--timeout TIMEOUT]
                                   [--output {json,ndjson,human}] [--compact]
                                   [--select SELECT |
                                   --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences clone`

Clone a sequence into a new DRAFT

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences clone [-h] --sequence-id SEQUENCE_ID
                                 [--actor-user-id ACTOR_USER_ID]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences create`

Create a sequence from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences create [-h] [--data-json DATA_JSON]
                                  [--data-file DATA_FILE]
                                  [--actor-user-id ACTOR_USER_ID]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: Sequence create payload JSON
  - `--data-file`: Sequence create payload file path
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences delete`

Delete a DRAFT or ARCHIVED sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences delete [-h] --sequence-id SEQUENCE_ID [--yes]
                                  [--actor-user-id ACTOR_USER_ID]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--yes` (default=False): Required confirmation flag for destructive delete
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences delivery-status`

Check sequence email delivery readiness

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences delivery-status [-h] [--base-url BASE_URL]
                                           [--token TOKEN] [--use-x-api-key]
                                           [--timeout TIMEOUT]
                                           [--output {json,ndjson,human}]
                                           [--compact] [--select SELECT |
                                           --json-pointer JSON_POINTER]
                                           [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences enroll`

Enroll leads into a sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences enroll [-h] --sequence-id SEQUENCE_ID
                                  [--data-json DATA_JSON]
                                  [--data-file DATA_FILE] [--lead-id LEAD_ID]
                                  [--lead-ids-json LEAD_IDS_JSON]
                                  [--lead-ids-file LEAD_IDS_FILE]
                                  [--lead-ids-column LEAD_IDS_COLUMN]
                                  [--start-date START_DATE]
                                  [--research-context-json RESEARCH_CONTEXT_JSON]
                                  [--research-context-file RESEARCH_CONTEXT_FILE]
                                  [--variable-map-json VARIABLE_MAP_JSON]
                                  [--variable-map-file VARIABLE_MAP_FILE]
                                  [--variable-overrides-json VARIABLE_OVERRIDES_JSON]
                                  [--variable-overrides-file VARIABLE_OVERRIDES_FILE]
                                  [--assigned-to-user-id ASSIGNED_TO_USER_ID]
                                  [--update-lead-owner] [--review-only]
                                  [--wait] [--quiet-wait]
                                  [--poll-interval POLL_INTERVAL]
                                  [--wait-timeout WAIT_TIMEOUT]
                                  [--fail-on-error] [--fail-on-partial]
                                  [--actor-user-id ACTOR_USER_ID]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--data-json`: Full enroll payload JSON
  - `--data-file`: Full enroll payload JSON file
  - `--lead-id`: Lead id to enroll (repeatable; comma-separated also supported)
  - `--lead-ids-json`: JSON array or object with leadIds[]
  - `--lead-ids-file`: Path to JSON/TXT/CSV file with lead ids
  - `--lead-ids-column` (default=lead_id): CSV column for lead ids (default: lead_id)
  - `--start-date`: Optional startDate ISO timestamp
  - `--research-context-json`: researchContext JSON
  - `--research-context-file`: researchContext JSON file
  - `--variable-map-json`: variableMap JSON
  - `--variable-map-file`: variableMap JSON file
  - `--variable-overrides-json`: variableOverrides JSON
  - `--variable-overrides-file`: variableOverrides JSON file
  - `--assigned-to-user-id`: Optional explicit assignee user id
  - `--update-lead-owner` (default=False): Also update Lead.user_id to the assignee
  - `--review-only` (default=False): Create paused review-only enrollments
  - `--wait` (default=False): Wait for enrollment bulk job terminal status
  - `--quiet-wait` (default=False): Suppress per-poll output in --wait mode
  - `--poll-interval` (default=2): Polling interval seconds for --wait
  - `--wait-timeout` (default=0): Max seconds to wait (0 = no timeout)
  - `--fail-on-error` (default=False): Exit non-zero when final status is error/cancelled
  - `--fail-on-partial` (default=False): Exit non-zero when final status is partial
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences get`

Get one sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences get [-h] --sequence-id SEQUENCE_ID
                               [--base-url BASE_URL] [--token TOKEN]
                               [--use-x-api-key] [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences list`

List sequences

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences list [-h] [--status STATUS]
                                [--source-table-id SOURCE_TABLE_ID]
                                [--include-stats] [--limit LIMIT]
                                [--offset OFFSET] [--base-url BASE_URL]
                                [--token TOKEN] [--use-x-api-key]
                                [--timeout TIMEOUT]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--status`: Filter by status (DRAFT/ACTIVE/PAUSED/ARCHIVED)
  - `--source-table-id`: Filter by source table id
  - `--include-stats` (default=False): Include live enrollment stats per sequence
  - `--limit` (default=50): Max sequences to return (1-100)
  - `--offset` (default=0): Pagination offset
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences pause`

Pause a sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences pause [-h] --sequence-id SEQUENCE_ID
                                 [--actor-user-id ACTOR_USER_ID]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences pause-enrollment`

Pause one lead's enrollment in a sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id, --lead-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences pause-enrollment [-h] --sequence-id SEQUENCE_ID
                                            --lead-id LEAD_ID
                                            [--actor-user-id ACTOR_USER_ID]
                                            [--base-url BASE_URL]
                                            [--token TOKEN] [--use-x-api-key]
                                            [--timeout TIMEOUT]
                                            [--output {json,ndjson,human}]
                                            [--compact] [--select SELECT |
                                            --json-pointer JSON_POINTER]
                                            [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--lead-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences recipe`

Print copy-ready sequence payload templates

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences recipe [-h]
                                  [--type {all,create,bulk_automated,enroll}]
                                  [--out-file OUT_FILE]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,create,bulk_automated,enroll; default=all)
  - `--out-file`: Write template JSON to file (single type writes payload only)
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch sequences stats`

Get live stats for one sequence

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences stats [-h] --sequence-id SEQUENCE_ID
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences status`

Set sequence status

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id, --status`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences status [-h] --sequence-id SEQUENCE_ID
                                  --status {ACTIVE,PAUSED,ARCHIVED}
                                  [--actor-user-id ACTOR_USER_ID]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--status` (required; choices=ACTIVE,PAUSED,ARCHIVED)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch sequences update`

Update a sequence from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--sequence-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sequences update [-h] --sequence-id SEQUENCE_ID
                                  [--data-json DATA_JSON]
                                  [--data-file DATA_FILE]
                                  [--actor-user-id ACTOR_USER_ID]
                                  [--base-url BASE_URL] [--token TOKEN]
                                  [--use-x-api-key] [--timeout TIMEOUT]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--sequence-id` (required)
  - `--data-json`: Sequence update payload JSON
  - `--data-file`: Sequence update payload file path
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `setup`

#### `autotouch setup`

First-run setup with key validation

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch setup [-h] [--api-key API_KEY] [--base-url BASE_URL]
                       [--overwrite] [--use-x-api-key] [--timeout TIMEOUT]
                       [--output {json,ndjson,human}] [--compact]
                       [--select SELECT | --json-pointer JSON_POINTER]
                       [--verbose] [--no-banner]`
- Options:
  - `--api-key`: Developer API key (stk_...)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--overwrite` (default=False): Replace existing stored API key
  - `--use-x-api-key` (default=False): Validate using X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=human): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr
  - `--no-banner` (default=False): Skip banner in human mode

### `sop`

#### `autotouch sop`

Print credit-safe execution SOP + default filtered run payload

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch sop [-h] [--out-file OUT_FILE] [--output {json,ndjson,human}]
                     [--compact] [--select SELECT |
                     --json-pointer JSON_POINTER]`
- Options:
  - `--out-file`: Write SOP JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `status`

#### `autotouch status`

Show pending/done/error counts for a table/column (requires pymongo + MONGODB_URI)

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Availability: `optional_dependency`
- Optional Python modules: `pymongo`
- Required env/config: `MONGODB_URI`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch status [-h] --table-id TABLE_ID --column-id COLUMN_ID
                        [--mongo-uri MONGO_URI] [--db-name DB_NAME]
                        [--output {json,ndjson,human}] [--compact]
                        [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--mongo-uri`: Override MONGODB_URI
  - `--db-name`: Override MONGODB_DB_NAME
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `tables`

#### `autotouch tables`

Table operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, create, schema`
- Example:
  - `autotouch tables [-h] {list,create,schema} ...`

#### `autotouch tables create`

Create a table

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tables create [-h] [--name NAME]
                               [--metadata-json METADATA_JSON]
                               [--metadata-file METADATA_FILE]
                               [--data-json DATA_JSON] [--data-file DATA_FILE]
                               [--base-url BASE_URL] [--token TOKEN]
                               [--use-x-api-key] [--timeout TIMEOUT]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]
                               [--verbose]`
- Options:
  - `--name`: Table name (when not using --data-json/--data-file)
  - `--metadata-json`: Optional table metadata JSON object
  - `--metadata-file`: Optional file with table metadata JSON
  - `--data-json`: Explicit table create payload JSON
  - `--data-file`: Path to table create payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tables list`

List tables

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tables list [-h] [--view-mode VIEW_MODE]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--view-mode`: Optional view mode filter
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tables schema`

Print table payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tables schema [-h] [--type {all,create}]
                               [--out-file OUT_FILE]
                               [--output {json,ndjson,human}] [--compact]
                               [--select SELECT | --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,create; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `tasks`

#### `autotouch tasks`

Task queue operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `recipe, query, count, assignee-counts, get, stats, create, update, delete, bulk-update, bulk-delete, draft, schedule-email`
- Example:
  - `autotouch tasks [-h]
                       {recipe,query,count,assignee-counts,get,stats,create,update,delete,bulk-update,bulk-delete,draft,schedule-email,email-schedule} ...`

#### `autotouch tasks assignee-counts`

Aggregate assignee counts for a TaskQueryRequest payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks assignee-counts [-h] [--data-json DATA_JSON]
                                       [--data-file DATA_FILE]
                                       [--base-url BASE_URL] [--token TOKEN]
                                       [--use-x-api-key] [--timeout TIMEOUT]
                                       [--output {json,ndjson,human}]
                                       [--compact] [--select SELECT |
                                       --json-pointer JSON_POINTER]
                                       [--verbose]`
- Options:
  - `--data-json`: TaskQueryRequest payload JSON
  - `--data-file`: Path to TaskQueryRequest payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks bulk-delete`

Bulk delete tasks from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks bulk-delete [-h] [--data-json DATA_JSON]
                                   [--data-file DATA_FILE]
                                   [--actor-user-id ACTOR_USER_ID]
                                   [--base-url BASE_URL] [--token TOKEN]
                                   [--use-x-api-key] [--timeout TIMEOUT]
                                   [--output {json,ndjson,human}] [--compact]
                                   [--select SELECT |
                                   --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: BulkTaskDeleteRequest payload JSON
  - `--data-file`: Path to BulkTaskDeleteRequest payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks bulk-update`

Bulk update tasks from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks bulk-update [-h] [--data-json DATA_JSON]
                                   [--data-file DATA_FILE]
                                   [--actor-user-id ACTOR_USER_ID]
                                   [--base-url BASE_URL] [--token TOKEN]
                                   [--use-x-api-key] [--timeout TIMEOUT]
                                   [--output {json,ndjson,human}] [--compact]
                                   [--select SELECT |
                                   --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--data-json`: BulkTaskUpdateRequest payload JSON
  - `--data-file`: Path to BulkTaskUpdateRequest payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks count`

Count tasks matching a TaskQueryRequest payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks count [-h] [--data-json DATA_JSON]
                             [--data-file DATA_FILE] [--base-url BASE_URL]
                             [--token TOKEN] [--use-x-api-key]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--data-json`: TaskQueryRequest payload JSON
  - `--data-file`: Path to TaskQueryRequest payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks create`

Create tasks from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks create [-h] [--data-json DATA_JSON]
                              [--data-file DATA_FILE]
                              [--actor-user-id ACTOR_USER_ID]
                              [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--data-json`: TaskQueueCreate payload JSON
  - `--data-file`: Path to TaskQueueCreate payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks delete`

Delete one task (soft delete to skipped)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks delete [-h] --task-id TASK_ID
                              [--actor-user-id ACTOR_USER_ID]
                              [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--task-id` (required)
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks draft`

Generate an AI draft for one task

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks draft [-h] --task-id TASK_ID [--force]
                             [--data-json DATA_JSON] [--data-file DATA_FILE]
                             [--actor-user-id ACTOR_USER_ID]
                             [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--task-id` (required)
  - `--force` (default=False): Force re-draft even if content already exists
  - `--data-json`: Optional TaskDraftRequest payload JSON
  - `--data-file`: Optional TaskDraftRequest payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks get`

Get one task by id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks get [-h] --task-id TASK_ID [--base-url BASE_URL]
                           [--token TOKEN] [--use-x-api-key]
                           [--timeout TIMEOUT] [--output {json,ndjson,human}]
                           [--compact] [--select SELECT |
                           --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--task-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks query`

Query tasks with a TaskQueryRequest payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks query [-h] [--data-json DATA_JSON]
                             [--data-file DATA_FILE] [--base-url BASE_URL]
                             [--token TOKEN] [--use-x-api-key]
                             [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--data-json`: TaskQueryRequest payload JSON
  - `--data-file`: Path to TaskQueryRequest payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks recipe`

Print task payload recipes

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks recipe [-h]
                              [--type {all,query,create,update,bulk_update,bulk_delete,draft,schedule_email}]
                              [--out-file OUT_FILE] [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--type` (choices=all,query,create,update,bulk_update,bulk_delete,draft,schedule_email; default=all)
  - `--out-file`: Optional path to save the selected payload JSON
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks schedule-email`

Schedule or send an email task from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Aliases: `email-schedule`
- Required flags: `--task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks schedule-email [-h] --task-id TASK_ID
                                      [--data-json DATA_JSON]
                                      [--data-file DATA_FILE]
                                      [--actor-user-id ACTOR_USER_ID]
                                      [--base-url BASE_URL] [--token TOKEN]
                                      [--use-x-api-key] [--timeout TIMEOUT]
                                      [--output {json,ndjson,human}]
                                      [--compact] [--select SELECT |
                                      --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--task-id` (required)
  - `--data-json`: TaskEmailScheduleRequest payload JSON
  - `--data-file`: Path to TaskEmailScheduleRequest payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks stats`

Get task summary stats

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks stats [-h] [--base-url BASE_URL] [--token TOKEN]
                             [--use-x-api-key] [--timeout TIMEOUT]
                             [--output {json,ndjson,human}] [--compact]
                             [--select SELECT | --json-pointer JSON_POINTER]
                             [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch tasks update`

Update one task from a JSON payload

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--task-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch tasks update [-h] --task-id TASK_ID [--data-json DATA_JSON]
                              [--data-file DATA_FILE]
                              [--actor-user-id ACTOR_USER_ID]
                              [--base-url BASE_URL] [--token TOKEN]
                              [--use-x-api-key] [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--task-id` (required)
  - `--data-json`: TaskQueueUpdate payload JSON
  - `--data-file`: Path to TaskQueueUpdate payload JSON file
  - `--actor-user-id`: Optional actor override; must resolve to an active user in the same organization
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `watch`

#### `autotouch watch`

Watch status periodically (requires pymongo + MONGODB_URI)

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Availability: `optional_dependency`
- Optional Python modules: `pymongo`
- Required env/config: `MONGODB_URI`
- Required flags: `--table-id, --column-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch watch [-h] --table-id TABLE_ID --column-id COLUMN_ID
                       [--interval INTERVAL] [--once] [--mongo-uri MONGO_URI]
                       [--db-name DB_NAME] [--output {json,ndjson,human}]
                       [--compact] [--select SELECT |
                       --json-pointer JSON_POINTER]`
- Options:
  - `--table-id` (required)
  - `--column-id` (required)
  - `--interval` (default=5)
  - `--once` (default=False): Fetch one snapshot and exit
  - `--mongo-uri`: Override MONGODB_URI
  - `--db-name`: Override MONGODB_DB_NAME
  - `--output` (choices=json,ndjson,human; default=human): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `webhooks`

#### `autotouch webhooks`

Table webhook operations

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `recipe, get, rotate, ingest, subscriptions, deliveries`
- Example:
  - `autotouch webhooks [-h]
                          {recipe,get,rotate,ingest,subscriptions,deliveries} ...`

#### `autotouch webhooks deliveries`

Inspect webhook delivery outcomes

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, attempts`
- Example:
  - `autotouch webhooks deliveries [-h] {list,attempts} ...`

#### `autotouch webhooks deliveries attempts`

List delivery attempts for one delivery id

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--delivery-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks deliveries attempts [-h] --delivery-id DELIVERY_ID
                                              [--limit LIMIT]
                                              [--base-url BASE_URL]
                                              [--token TOKEN]
                                              [--use-x-api-key]
                                              [--timeout TIMEOUT]
                                              [--output {json,ndjson,human}]
                                              [--compact] [--select SELECT |
                                              --json-pointer JSON_POINTER]
                                              [--verbose]`
- Options:
  - `--delivery-id` (required)
  - `--limit` (default=100): Max attempts to return (1-500)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks deliveries list`

List webhook deliveries

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks deliveries list [-h]
                                          [--subscription-id SUBSCRIPTION_ID]
                                          [--status STATUS]
                                          [--event-type EVENT_TYPE]
                                          [--limit LIMIT]
                                          [--base-url BASE_URL]
                                          [--token TOKEN] [--use-x-api-key]
                                          [--timeout TIMEOUT]
                                          [--output {json,ndjson,human}]
                                          [--compact] [--select SELECT |
                                          --json-pointer JSON_POINTER]
                                          [--verbose]`
- Options:
  - `--subscription-id`: Filter by subscription id
  - `--status`: Filter by status (queued/retry_scheduled/succeeded/failed)
  - `--event-type`: Filter by event type
  - `--limit` (default=100): Max deliveries to return (1-500)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks get`

Get webhook config for a table

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks get [-h] --table-id TABLE_ID [--base-url BASE_URL]
                              [--token TOKEN] [--use-x-api-key]
                              [--timeout TIMEOUT]
                              [--output {json,ndjson,human}] [--compact]
                              [--select SELECT | --json-pointer JSON_POINTER]
                              [--verbose]`
- Options:
  - `--table-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks ingest`

Ingest records using table webhook token

- Auth: `webhook_token`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks ingest [-h] --table-id TABLE_ID
                                 [--webhook-token WEBHOOK_TOKEN]
                                 [--records-json RECORDS_JSON]
                                 [--records-file RECORDS_FILE]
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--webhook-token`: x-autotouch-token (or AUTOTOUCH_WEBHOOK_TOKEN)
  - `--records-json`: Object, list, or {records:[...]} payload JSON
  - `--records-file`: Path to JSON file containing records payload
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks recipe`

Print webhook payload recipes

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks recipe [-h]
                                 [--type {all,ingest,subscription_create,subscription_update,subscription_test}]
                                 [--out-file OUT_FILE] [--base-url BASE_URL]
                                 [--token TOKEN] [--use-x-api-key]
                                 [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--type` (choices=all,ingest,subscription_create,subscription_update,subscription_test; default=all)
  - `--out-file`: Optional path to save the selected payload JSON
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks rotate`

Create/rotate webhook token for a table

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--table-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks rotate [-h] --table-id TABLE_ID
                                 [--base-url BASE_URL] [--token TOKEN]
                                 [--use-x-api-key] [--timeout TIMEOUT]
                                 [--output {json,ndjson,human}] [--compact]
                                 [--select SELECT |
                                 --json-pointer JSON_POINTER] [--verbose]`
- Options:
  - `--table-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions`

Manage outbound webhook subscriptions

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, create, get, update, delete, pause, resume, rotate-secret, test`
- Example:
  - `autotouch webhooks subscriptions [-h]
                                        {list,create,get,update,delete,pause,resume,rotate-secret,test} ...`

#### `autotouch webhooks subscriptions create`

Create a webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions create [-h] [--url URL]
                                               [--events [EVENTS ...]]
                                               [--paused]
                                               [--filters-json FILTERS_JSON]
                                               [--filters-file FILTERS_FILE]
                                               [--metadata-json METADATA_JSON]
                                               [--metadata-file METADATA_FILE]
                                               [--retry-policy-json RETRY_POLICY_JSON]
                                               [--retry-policy-file RETRY_POLICY_FILE]
                                               [--data-json DATA_JSON]
                                               [--data-file DATA_FILE]
                                               [--base-url BASE_URL]
                                               [--token TOKEN]
                                               [--use-x-api-key]
                                               [--timeout TIMEOUT]
                                               [--output {json,ndjson,human}]
                                               [--compact] [--select SELECT |
                                               --json-pointer JSON_POINTER]
                                               [--verbose]`
- Options:
  - `--url`: Webhook endpoint URL
  - `--events`: Event names or families (for example bulk_job.*)
  - `--paused` (default=False): Create subscription as paused/disabled
  - `--filters-json`: Optional filters JSON
  - `--filters-file`: Optional filters JSON file
  - `--metadata-json`: Optional metadata JSON
  - `--metadata-file`: Optional metadata JSON file
  - `--retry-policy-json`: Optional retryPolicy JSON
  - `--retry-policy-file`: Optional retryPolicy JSON file
  - `--data-json`: Full request payload JSON
  - `--data-file`: Full request payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions delete`

Delete a webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions delete [-h]
                                               --subscription-id SUBSCRIPTION_ID
                                               [--base-url BASE_URL]
                                               [--token TOKEN]
                                               [--use-x-api-key]
                                               [--timeout TIMEOUT]
                                               [--output {json,ndjson,human}]
                                               [--compact] [--select SELECT |
                                               --json-pointer JSON_POINTER]
                                               [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions get`

Get a webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions get [-h]
                                            --subscription-id SUBSCRIPTION_ID
                                            [--base-url BASE_URL]
                                            [--token TOKEN] [--use-x-api-key]
                                            [--timeout TIMEOUT]
                                            [--output {json,ndjson,human}]
                                            [--compact] [--select SELECT |
                                            --json-pointer JSON_POINTER]
                                            [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions list`

List webhook subscriptions

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions list [-h] [--include-disabled]
                                             [--limit LIMIT]
                                             [--base-url BASE_URL]
                                             [--token TOKEN] [--use-x-api-key]
                                             [--timeout TIMEOUT]
                                             [--output {json,ndjson,human}]
                                             [--compact] [--select SELECT |
                                             --json-pointer JSON_POINTER]
                                             [--verbose]`
- Options:
  - `--include-disabled` (default=False): Include paused/disabled subscriptions
  - `--limit` (default=100): Max subscriptions to return (1-500)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions pause`

Pause a webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions pause [-h]
                                              --subscription-id SUBSCRIPTION_ID
                                              [--base-url BASE_URL]
                                              [--token TOKEN]
                                              [--use-x-api-key]
                                              [--timeout TIMEOUT]
                                              [--output {json,ndjson,human}]
                                              [--compact] [--select SELECT |
                                              --json-pointer JSON_POINTER]
                                              [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions resume`

Resume a paused webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions resume [-h]
                                               --subscription-id SUBSCRIPTION_ID
                                               [--base-url BASE_URL]
                                               [--token TOKEN]
                                               [--use-x-api-key]
                                               [--timeout TIMEOUT]
                                               [--output {json,ndjson,human}]
                                               [--compact] [--select SELECT |
                                               --json-pointer JSON_POINTER]
                                               [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions rotate-secret`

Rotate webhook subscription signing secret

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions rotate-secret [-h]
                                                      --subscription-id SUBSCRIPTION_ID
                                                      [--base-url BASE_URL]
                                                      [--token TOKEN]
                                                      [--use-x-api-key]
                                                      [--timeout TIMEOUT]
                                                      [--output {json,ndjson,human}]
                                                      [--compact]
                                                      [--select SELECT |
                                                      --json-pointer JSON_POINTER]
                                                      [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions test`

Fire a test event for a subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions test [-h]
                                             --subscription-id SUBSCRIPTION_ID
                                             [--event-type EVENT_TYPE]
                                             [--data-json DATA_JSON]
                                             [--data-file DATA_FILE]
                                             [--base-url BASE_URL]
                                             [--token TOKEN] [--use-x-api-key]
                                             [--timeout TIMEOUT]
                                             [--output {json,ndjson,human}]
                                             [--compact] [--select SELECT |
                                             --json-pointer JSON_POINTER]
                                             [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--event-type`: Optional event type (for example lead.created)
  - `--data-json`: Optional test payload JSON
  - `--data-file`: Optional test payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch webhooks subscriptions update`

Update a webhook subscription

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--subscription-id`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch webhooks subscriptions update [-h]
                                               --subscription-id SUBSCRIPTION_ID
                                               [--data-json DATA_JSON]
                                               [--data-file DATA_FILE]
                                               [--base-url BASE_URL]
                                               [--token TOKEN]
                                               [--use-x-api-key]
                                               [--timeout TIMEOUT]
                                               [--output {json,ndjson,human}]
                                               [--compact] [--select SELECT |
                                               --json-pointer JSON_POINTER]
                                               [--verbose]`
- Options:
  - `--subscription-id` (required)
  - `--data-json`: Patch payload JSON
  - `--data-file`: Patch payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

### `workflows`

#### `autotouch workflows`

Common multi-step workflow blueprints

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, recipe`
- Example:
  - `autotouch workflows [-h] {list,recipe} ...`

#### `autotouch workflows list`

List common workflow blueprints

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workflows list [-h] [--out-file OUT_FILE]
                                [--output {json,ndjson,human}] [--compact]
                                [--select SELECT |
                                --json-pointer JSON_POINTER]`
- Options:
  - `--out-file`: Save JSON payload to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch workflows recipe`

Emit one workflow blueprint payload

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Required flags: `--type`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workflows recipe [-h]
                                  --type {lead_finder_to_sequence,llm_items_to_contacts_then_sequence}
                                  [--out-file OUT_FILE]
                                  [--output {json,ndjson,human}] [--compact]
                                  [--select SELECT |
                                  --json-pointer JSON_POINTER]`
- Options:
  - `--type` (required; choices=lead_finder_to_sequence,llm_items_to_contacts_then_sequence): Workflow blueprint type
  - `--out-file`: Save raw workflow payload to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

### `workspace-secrets`

#### `autotouch workspace-secrets`

Manage reusable org-scoped secrets for HTTP request columns

Manage reusable org-scoped secrets used by {{secrets.name}} templates in HTTP request columns and other templated features.

- Auth: `varies_by_subcommand`
- Stability: `stable`
- Destructive: `no`
- Subcommands: `list, set, delete, schema`
- Example:
  - `autotouch workspace-secrets set --name clearbit --value "$CLEARBIT_API_KEY"`
  - `autotouch workspace-secrets list`
  - `autotouch workspace-secrets delete --name clearbit --yes`
- Notes:

```text
Developer API keys need secrets:read / secrets:write scopes (or *) for these endpoints.
Workspace secrets are optional; HTTP request columns can still use literal headers/body values.
```

#### `autotouch workspace-secrets delete`

Delete a workspace secret

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `yes`
- Required flags: `--name`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workspace-secrets delete [-h] --name NAME [--yes]
                                          [--base-url BASE_URL]
                                          [--token TOKEN] [--use-x-api-key]
                                          [--timeout TIMEOUT]
                                          [--output {json,ndjson,human}]
                                          [--compact] [--select SELECT |
                                          --json-pointer JSON_POINTER]
                                          [--verbose]`
- Options:
  - `--name` (required): Secret/provider slug to delete
  - `--yes` (default=False): Confirm deletion
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch workspace-secrets list`

List workspace secrets (masked values)

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workspace-secrets list [-h] [--base-url BASE_URL]
                                        [--token TOKEN] [--use-x-api-key]
                                        [--timeout TIMEOUT]
                                        [--output {json,ndjson,human}]
                                        [--compact] [--select SELECT |
                                        --json-pointer JSON_POINTER]
                                        [--verbose]`
- Options:
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr

#### `autotouch workspace-secrets schema`

Print workspace-secrets payload schemas

- Auth: `none`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workspace-secrets schema [-h] [--type {all,set}]
                                          [--out-file OUT_FILE]
                                          [--output {json,ndjson,human}]
                                          [--compact] [--select SELECT |
                                          --json-pointer JSON_POINTER]`
- Options:
  - `--type` (choices=all,set; default=all)
  - `--out-file`: Write schema JSON to file
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)

#### `autotouch workspace-secrets set`

Create or update a workspace secret

Create or update a workspace secret used by {{secrets.name}} template references.

- Auth: `developer_key_or_user_session`
- Stability: `stable`
- Destructive: `no`
- Output modes: `json, ndjson, human`
- Example:
  - `autotouch workspace-secrets set [-h] [--name NAME] [--value VALUE]
                                       [--data-json DATA_JSON]
                                       [--data-file DATA_FILE]
                                       [--base-url BASE_URL] [--token TOKEN]
                                       [--use-x-api-key] [--timeout TIMEOUT]
                                       [--output {json,ndjson,human}]
                                       [--compact] [--select SELECT |
                                       --json-pointer JSON_POINTER]
                                       [--verbose]`
- Options:
  - `--name`: Secret/provider slug, for example clearbit
  - `--value`: Secret value (for example an API key or bearer token)
  - `--data-json`: Explicit workspace secret payload JSON
  - `--data-file`: Path to workspace secret payload JSON file
  - `--base-url` (default=https://app.autotouch.ai): API base URL (default: https://app.autotouch.ai)
  - `--token`: Developer API key / JWT token
  - `--use-x-api-key` (default=False): Send token via X-API-Key header
  - `--timeout` (default=30): HTTP timeout in seconds
  - `--output` (choices=json,ndjson,human; default=json): Output mode
  - `--compact` (default=False): Print compact JSON
  - `--select`: Extract a dotted field path from the final result (for example: id or items.0.id)
  - `--json-pointer`: Extract a JSON pointer from the final result (for example: /id)
  - `--verbose` (default=False): Print request metadata to stderr
