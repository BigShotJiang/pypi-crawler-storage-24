"""Rust-first GENSHI STT client wrappers."""

from __future__ import annotations

from pathlib import Path
from typing import Union
import asyncio
import json

import numpy as np

from genshi_stt.audio import decode_audio_input_to_pcm16, get_pcm16_duration_seconds
from genshi_stt.engine import DEFAULT_LOCAL_MODEL_DTYPE
from genshi_stt.transcriber import RealtimeSession, TranscriptionResult


_NATIVE_CLIENT_CLS = None

try:
    from genshi_stt_native import RustGenshiSttClient as _RUST_NATIVE_CLIENT  # type: ignore

    _NATIVE_CLIENT_CLS = _RUST_NATIVE_CLIENT
except Exception:
    _NATIVE_CLIENT_CLS = None


class GenshiSTTClient:
    """High-accuracy transcription client powered by Rust native SDK core."""

    _DEFAULT_LANGUAGE = "ja-JP"

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.genshi.ai",
        *,
        timeout: float = 120.0,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        if _NATIVE_CLIENT_CLS is None:
            raise RuntimeError(
                "genshi_stt_native is required. "
                "Install a wheel that includes the Rust native module."
            )
        self._native = _NATIVE_CLIENT_CLS(api_key, self.base_url, timeout)

    async def transcribe(
        self,
        input_data: Union[str, bytes, np.ndarray, Path],
        *,
        domain: str = "general",
        language: str = _DEFAULT_LANGUAGE,
        secure: bool | None = None,
        processing_tier: str | None = None,
        dictionary_ids: list[str] | None = None,
        dictionaries: list[dict] | None = None,
        audio_duration_seconds: float | None = None,
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> TranscriptionResult:
        """Transcribe audio and return the final text."""
        del local_model_dir
        if local_model_dtype != DEFAULT_LOCAL_MODEL_DTYPE:
            raise ValueError(f"only dtype={DEFAULT_LOCAL_MODEL_DTYPE!r} is supported")

        pcm16 = decode_audio_input_to_pcm16(input_data)
        resolved_processing_tier = _resolve_processing_tier(secure=secure, processing_tier=processing_tier)
        normalized_dictionary_ids = _normalize_dictionary_ids(dictionary_ids)
        normalized_dictionaries = _normalize_dictionaries(dictionaries)
        _assert_supported_processing_profile(
            domain=domain,
            processing_tier=resolved_processing_tier,
            dictionary_ids=normalized_dictionary_ids,
            dictionaries=normalized_dictionaries,
        )
        payload = await _run_blocking(
            self._native.transcribe_audio_sync,
            pcm16,
            domain,
            language,
            audio_duration_seconds or get_pcm16_duration_seconds(pcm16),
            resolved_processing_tier,
            normalized_dictionary_ids,
            json.dumps(normalized_dictionaries) if normalized_dictionaries else None,
        )
        return _result_from_payload(json.loads(payload))

    def realtime(
        self,
        *,
        domain: str = "general",
        language: str = _DEFAULT_LANGUAGE,
        secure: bool | None = None,
        processing_tier: str | None = None,
        dictionary_ids: list[str] | None = None,
        dictionaries: list[dict] | None = None,
        context_window_size: int = 5,
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> RealtimeSession:
        """Create a realtime transcription session."""
        del local_model_dir
        if local_model_dtype != DEFAULT_LOCAL_MODEL_DTYPE:
            raise ValueError(f"only dtype={DEFAULT_LOCAL_MODEL_DTYPE!r} is supported")

        resolved_processing_tier = _resolve_processing_tier(secure=secure, processing_tier=processing_tier)
        normalized_dictionary_ids = _normalize_dictionary_ids(dictionary_ids)
        normalized_dictionaries = _normalize_dictionaries(dictionaries)
        _assert_supported_processing_profile(
            domain=domain,
            processing_tier=resolved_processing_tier,
            dictionary_ids=normalized_dictionary_ids,
            dictionaries=normalized_dictionaries,
        )

        native_session = self._native.realtime(
            domain,
            language,
            max(1, context_window_size),
            resolved_processing_tier,
            normalized_dictionary_ids,
            json.dumps(normalized_dictionaries) if normalized_dictionaries else None,
        )
        return RealtimeSession(native_session=native_session)

    def stream(
        self,
        *,
        domain: str = "general",
        language: str = _DEFAULT_LANGUAGE,
        secure: bool | None = None,
        processing_tier: str | None = None,
        dictionary_ids: list[str] | None = None,
        dictionaries: list[dict] | None = None,
        context_window_size: int = 5,
        local_model_dir: str | None = None,
        local_model_dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    ) -> RealtimeSession:
        return self.realtime(
            domain=domain,
            language=language,
            secure=secure,
            processing_tier=processing_tier,
            dictionary_ids=dictionary_ids,
            dictionaries=dictionaries,
            context_window_size=context_window_size,
            local_model_dir=local_model_dir,
            local_model_dtype=local_model_dtype,
        )

    async def close(self) -> None:
        await _run_blocking(self._native.close)

    async def __aenter__(self) -> "GenshiSTTClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()


async def _run_blocking(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: func(*args))


def _result_from_payload(payload: dict) -> TranscriptionResult:
    text = str(payload.get("text", "")).strip()
    raw_text = str(payload.get("raw_text", ""))
    return TranscriptionResult(
        text=text or raw_text.strip() or "",
        raw_text=raw_text,
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
    )


def _resolve_processing_tier(*, secure: bool | None, processing_tier: str | None) -> str | None:
    if processing_tier:
        normalized = processing_tier.strip().lower()
        if normalized not in {"standard", "secure"}:
            raise ValueError("processing_tier must be 'standard' or 'secure'")
        if secure is not None and normalized != ("secure" if secure else "standard"):
            raise ValueError("secure and processing_tier must not conflict")
        return normalized
    if secure is None:
        return None
    return "secure" if secure else "standard"


def _normalize_dictionary_ids(dictionary_ids: list[str] | None) -> list[str] | None:
    if not dictionary_ids:
        return None
    normalized = []
    for raw_value in dictionary_ids:
        value = str(raw_value).strip()
        if value and value not in normalized:
            normalized.append(value)
    return normalized or None


def _normalize_dictionaries(dictionaries: list[dict] | None) -> list[dict] | None:
    if not dictionaries:
        return None
    normalized = []
    for raw_dictionary in dictionaries:
        normalized.append(
            {
                "id": str(raw_dictionary.get("id", "")).strip() or None,
                "name": str(raw_dictionary["name"]).strip(),
                "industry": str(raw_dictionary.get("industry", "")).strip().lower() or None,
                "terms": [
                    {
                        "term": str(term["term"]).strip(),
                        "reading": str(term.get("reading", "")).strip() or None,
                        "aliases": [
                            str(alias).strip()
                            for alias in term.get("aliases", [])
                            if str(alias).strip()
                        ],
                        "description": str(term.get("description", "")).strip() or None,
                    }
                    for term in raw_dictionary.get("terms", [])
                    if str(term.get("term", "")).strip()
                ],
            }
        )
    return normalized or None


def _assert_supported_processing_profile(
    *,
    domain: str,
    processing_tier: str | None,
    dictionary_ids: list[str] | None,
    dictionaries: list[dict] | None,
) -> None:
    if processing_tier == "secure" and domain.strip().lower() == "general" and not dictionaries:
        raise ValueError("secure transcription requires an industry domain or a custom dictionary")
    if dictionary_ids and not dictionaries:
        raise ValueError("dictionary_ids currently require inline dictionaries")
