# Changelog

## 1.0.2 (2026-03-17)

Compatibility release for the production API domain split.

### Changes

- Switched SDK default API origin to `https://api.genshi.ai`
- Prepared Cloudflare compatibility routing so legacy `https://works.genshi.ai/v1/*` traffic can be forwarded during migration
- Intended production runtime configuration now keeps one Fly machine warm to reduce first-request latency

## 1.0.1 (2026-03-12)

Metadata-only maintenance release.

### Changes

- Clarified public package metadata for closed-source distribution
- Removed misleading public `repository` links from npm package metadata
- Added public `Releases` and `Changelog` links to PyPI package metadata
- Added landing-page README and changelog to the public release repository

## 1.0.0 (2026-03-06)

Initial production release.

### Features
- Batch transcription via `client.transcribe(audio)` (Python / Node.js / Browser)
- Realtime streaming via `client.stream()` / `client.realtime()` with push-based audio input
- Built-in Silero VAD for voice activity detection
- Encrypted on-device STT model (fp16 ONNX) with Rust native runtime
- Platform-specific native extensions: macOS ARM64, Linux x64, Windows x64
- Browser SDK (`@genshiai/stt-web`) with ONNX Runtime Web + Transformers.js
- Domain-specific transcription support (medical, general)

### Packages
- `genshiai-stt` (PyPI) — Python SDK
- `genshiai-stt-native` (PyPI) — Python native extension (platform wheels)
- `@genshiai/stt` (npm) — Node.js SDK
- `@genshiai/stt-native-{platform}` (npm) — Node.js native addons
- `@genshiai/stt-web` (npm) — Browser SDK
