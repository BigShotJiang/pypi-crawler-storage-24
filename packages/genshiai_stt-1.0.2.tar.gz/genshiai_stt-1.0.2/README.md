# GENSHI Works STT SDK

High-accuracy domain-specific speech-to-text SDK. Supports batch transcription and realtime streaming with built-in VAD and on-device STT inference.

## Installation

### Python

```bash
pip install genshiai-stt

# With native runtime (recommended for production):
pip install genshiai-stt[native]
```

### Node.js

```bash
npm install @genshiai/stt
```

The correct native addon for your platform is installed automatically via optional dependencies.

### Browser

```bash
npm install @genshiai/stt-web
```

## Quick Start

### Python

```python
import asyncio

from genshi_stt import GenshiSTTClient

async def main() -> None:
    async with GenshiSTTClient(api_key="gw-...") as client:
        with open("recording.wav", "rb") as f:
            result = await client.transcribe(f.read())
        print(result.text)

        async with client.stream(
            domain="medical",
            secure=True,
            dictionary_ids=["dict_hospital"],
            dictionaries=[
                {
                    "id": "dict_hospital",
                    "name": "院内用語",
                    "industry": "medical",
                    "terms": [{"term": "GENSHI AI", "reading": "げんしえーあい"}],
                }
            ],
        ) as session:
            events = await session.push(audio_chunk)  # PCM16 bytes
            print(events[0].text if events else "")
            final = await session.finalize()
            print(final.text)

asyncio.run(main())
```

### Node.js / TypeScript

```typescript
import { GenshiSTTClient } from '@genshiai/stt';

const client = new GenshiSTTClient({ apiKey: 'gw-...' });

// Batch transcription
const result = await client.transcribe(audioBuffer);
console.log(result.text);

// Realtime streaming
const session = client.stream({
  domain: 'medical',
  secure: true,
  dictionaryIds: ['dict_hospital'],
  dictionaries: [
    {
      id: 'dict_hospital',
      name: '院内用語',
      industry: 'medical',
      terms: [{ term: 'GENSHI AI', reading: 'げんしえーあい' }],
    },
  ],
});
const events = await session.push(pcm16Chunk);
console.log(events[0]?.text);
const final = await session.finalize();
console.log(final.text);
```

### Browser

```typescript
import { GenshiSTTClient, createMicStream } from '@genshiai/stt-web';

const client = new GenshiSTTClient({ apiKey: 'gw-...' });
await client.init();

const session = client.stream({
  domain: 'medical',
  secure: true,
  dictionaryIds: ['dict_hospital'],
  dictionaries: [
    {
      id: 'dict_hospital',
      name: '院内用語',
      industry: 'medical',
      terms: [{ term: 'GENSHI AI', reading: 'げんしえーあい' }],
    },
  ],
});

const mic = await createMicStream();
mic.onAudio(async (chunk) => {
  const events = await session.push(chunk);
  console.log(events[0]?.text);
});

// When done:
const result = await session.finalize();
console.log(result.text);
```

Prefer `await session.finalize()` when you need the final corrected text.
`await session.close()` now performs a best-effort finalize for cleanup.
Use `session.abort()` only for intentional force-abort without billing finalize.

`secure=True` / `secure: true` requests the Secure tier. Secure requests require an industry domain such as `medical`, or inline custom dictionaries.

## Response

```json
{
  "text": "今日は天気がいい",
  "raw_text": "きょうわ天気がいい",
  "processing_time_ms": 142
}
```

## Supported Platforms

| Platform | Python | Node.js |
|----------|--------|---------|
| macOS ARM64 (Apple Silicon) | genshiai-stt-native | @genshiai/stt-native-darwin-arm64 |
| Linux x64 | genshiai-stt-native | @genshiai/stt-native-linux-x64 |
| Windows x64 | genshiai-stt-native | @genshiai/stt-native-windows-x64 |
| Browser | — | @genshiai/stt-web |

## Requirements

- Python >= 3.10 / Node.js >= 20
- Valid GENSHI Works API key
- `ffmpeg` (Node.js batch decode only)

Browser SDK note:

- `await client.init()` is required before `transcribe()` or `realtime()`
- the npm package includes JSON metadata, and secured ONNX assets are fetched via `POST /v1/activate`

## Documentation

Full documentation: https://docs.genshi.ai/stt

## License

Proprietary. Copyright (c) 2026 GENSHI Works Inc. All rights reserved. See [LICENSE](./LICENSE).
