# pyannotators_acronyms

[![license](https://img.shields.io/github/license/oterrier/pyannotators_acronyms)](https://github.com/oterrier/pyannotators_acronyms/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyannotators_acronyms/workflows/tests/badge.svg)](https://github.com/oterrier/pyannotators_acronyms/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyannotators_acronyms)](https://codecov.io/gh/oterrier/pyannotators_acronyms)
[![docs](https://img.shields.io/readthedocs/pyannotators_acronyms)](https://pyannotators_acronyms.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyannotators_acronyms)](https://pypi.org/project/pyannotators_acronyms/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyannotators_acronyms)](https://pypi.org/project/pyannotators_acronyms/)

Annotator based on Facebook's Acronyms

## Installation

You can simply `pip install pyannotators_acronyms`.

## Developing

### Pre-requisites

You will need to install `uv` (for building and managing the package):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyannotators_acronyms
```

Install dependencies:

```
uv sync --extra test
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
