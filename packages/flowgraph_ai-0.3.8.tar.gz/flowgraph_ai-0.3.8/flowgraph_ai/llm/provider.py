"""
LLM Provider abstraction layer.

Supported providers:
  claude      — Anthropic Claude (langchain-anthropic)
  ollama      — Local Ollama (langchain-ollama)
  openai      — OpenAI ChatGPT (langchain-openai)
  openrouter  — OpenRouter (OpenAI-compatible API via langchain-openai)
  lmstudio    — LM Studio local server (OpenAI-compatible API via langchain-openai)

Any node can request provider and parameter overrides via:
  llm_provider: "openai"     # override provider
  llm_params:                # override any LLM parameter
    temperature: 0.2
    max_tokens: 512
    top_p: 0.9
    model: "gpt-4o"          # per-node model override (within same provider)

config.yaml example:
  llm:
    provider: "openai"
    openai_model: "gpt-4o-mini"
    openai_api_key: "sk-..."          # or set OPENAI_API_KEY env var
    temperature: 0.7
    max_tokens: 1024
    top_p: 1.0
    streaming: false

    openrouter_model: "openai/gpt-4o-mini"
    openrouter_api_key: "sk-or-..."   # or set OPENROUTER_API_KEY env var

    lmstudio_model: "local-model"
    lmstudio_base_url: "http://localhost:1234/v1"
"""

import logging
import os
from typing import Any

logger = logging.getLogger("flowgraph.llm.provider")


def _extract_llm_params(llm_config: dict, overrides: dict | None = None) -> dict[str, Any]:
    """Extract LLM instantiation params from config + per-node overrides.

    Priority: node-level overrides > global config > defaults.
    """
    overrides = overrides or {}
    params: dict[str, Any] = {}

    # Temperature
    temp = overrides.get("temperature", llm_config.get("temperature", 0.7))
    if temp is not None:
        params["temperature"] = float(temp)

    # Max tokens
    max_tokens = overrides.get("max_tokens", llm_config.get("max_tokens"))
    if max_tokens is not None:
        params["max_tokens"] = int(max_tokens)

    # Top-p
    top_p = overrides.get("top_p", llm_config.get("top_p"))
    if top_p is not None:
        params["top_p"] = float(top_p)

    # Streaming
    streaming = overrides.get("streaming", llm_config.get("streaming"))
    if streaming is not None:
        params["streaming"] = bool(streaming)

    # Timeout
    timeout = overrides.get("timeout", llm_config.get("timeout"))
    if timeout is not None:
        params["timeout"] = int(timeout)

    return params


def get_llm(
    config: dict,
    provider_override: str | None = None,
    param_overrides: dict | None = None,
    callbacks: list | None = None,
):
    """Create and return an LLM client instance.

    Args:
        config:           Full config dict from config.yaml.
        provider_override: If set, use this provider instead of the global default.
        param_overrides:  Dict of LLM parameter overrides (temperature, max_tokens, etc.).
        callbacks:        Optional list of LangChain callbacks (e.g., Langfuse handlers).
        metadata:         Optional dict of metadata to bind to the LLM config.

    Returns:
        A LangChain-compatible chat model instance.
    """
    llm_config = config.get("llm", {})
    provider = (provider_override or llm_config.get("provider", "ollama")).lower()
    params = _extract_llm_params(llm_config, overrides=param_overrides)

    temperature = params.pop("temperature", 0.7)
    max_tokens = params.pop("max_tokens", None)
    top_p = params.pop("top_p", None)
    streaming = params.pop("streaming", False)
    timeout = params.pop("timeout", None)

    # Model override at node level
    model_override = (param_overrides or {}).get("model")

    if provider == "claude":
        from langchain_anthropic import ChatAnthropic

        model = model_override or llm_config.get("claude_model", "claude-sonnet-4-20250514")
        kwargs: dict[str, Any] = {"model": model, "temperature": temperature}
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if top_p is not None:
            kwargs["top_p"] = top_p
        if timeout is not None:
            kwargs["timeout"] = timeout
        logger.info(
            "[LLM] provider=claude  model=%s  temperature=%s  max_tokens=%s",
            model,
            temperature,
            max_tokens,
        )
        llm = ChatAnthropic(**kwargs)
        if callbacks:
            llm = llm.with_config(callbacks=callbacks)
        return llm

    elif provider == "openai":
        from langchain_openai import ChatOpenAI

        model = model_override or llm_config.get("openai_model", "gpt-4o-mini")
        api_key = llm_config.get("openai_api_key") or os.environ.get("OPENAI_API_KEY") or "not-set"
        kwargs = {
            "model": model,
            "temperature": temperature,
            "api_key": api_key,
            "streaming": streaming,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if top_p is not None:
            kwargs["model_kwargs"] = {"top_p": top_p}
        if timeout is not None:
            kwargs["request_timeout"] = timeout
        logger.info(
            "[LLM] provider=openai  model=%s  temperature=%s  max_tokens=%s",
            model,
            temperature,
            max_tokens,
        )
        llm = ChatOpenAI(**kwargs)
        if callbacks:
            llm = llm.with_config(callbacks=callbacks)
        return llm

    elif provider == "openrouter":
        from langchain_openai import ChatOpenAI

        model = model_override or llm_config.get("openrouter_model", "openai/gpt-4o-mini")
        api_key = (
            llm_config.get("openrouter_api_key")
            or os.environ.get("OPENROUTER_API_KEY")
            or "not-set"
        )
        base_url = llm_config.get("openrouter_base_url", "https://openrouter.ai/api/v1")
        kwargs = {
            "model": model,
            "temperature": temperature,
            "api_key": api_key,
            "base_url": base_url,
            "streaming": streaming,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        logger.info("[LLM] provider=openrouter  model=%s  base_url=%s", model, base_url)
        llm = ChatOpenAI(**kwargs)
        if callbacks:
            llm = llm.with_config(callbacks=callbacks)
        return llm

    elif provider == "lmstudio":
        from langchain_openai import ChatOpenAI

        model = model_override or llm_config.get("lmstudio_model", "local-model")
        base_url = llm_config.get("lmstudio_base_url", "http://localhost:1234/v1")
        kwargs = {
            "model": model,
            "temperature": temperature,
            "api_key": "lmstudio",
            "base_url": base_url,
        }
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        logger.info("[LLM] provider=lmstudio  model=%s  base_url=%s", model, base_url)
        llm = ChatOpenAI(**kwargs)
        if callbacks:
            llm = llm.with_config(callbacks=callbacks)
        return llm

    else:  # ollama (default)
        from langchain_ollama import ChatOllama

        model = model_override or llm_config.get("ollama_model", "llama3")
        base_url = llm_config.get("ollama_base_url", "http://localhost:11434")
        kwargs = {"model": model, "base_url": base_url, "temperature": temperature}
        if top_p is not None:
            kwargs["top_p"] = top_p
        logger.info("[LLM] provider=ollama  model=%s  base_url=%s", model, base_url)
        llm = ChatOllama(**kwargs)
        if callbacks:
            llm = llm.with_config(callbacks=callbacks)
        return llm


def get_node_llm(node_config: dict, default_llm, config: dict, callbacks: list | None = None):
    """Get the LLM for a specific node, respecting per-node overrides.

    Reads:
      node_config['llm_provider'] — optional provider override
      node_config['llm_params']   — optional dict of parameter overrides:
                                    temperature, max_tokens, top_p, streaming, timeout, model
    """
    provider_override = node_config.get("llm_provider")
    param_overrides = node_config.get("llm_params")

    if provider_override or param_overrides:
        logger.info(
            "[NODE_LLM] override  provider=%s  params=%s",
            provider_override or "(same)",
            param_overrides or {},
        )
        return get_llm(
            config,
            provider_override=provider_override,
            param_overrides=param_overrides,
            callbacks=callbacks,
        )

    if callbacks:
        return default_llm.with_config(callbacks=callbacks)
    return default_llm
