"""
Embedding manager for RAG-based intent classification.

Reads training examples from YAML or Markdown files, generates embeddings
using the configured embedding model, and stores them in PostgreSQL
with pgvector for similarity search.

Training data formats:

YAML (intent_training.yaml):
  - intent: order_tracking
    examples:
      - "where is my order"
      - "track my package"
      - "delivery status"
  - intent: greeting
    examples:
      - "hello"
      - "hi there"

Markdown (intent_training.md):
  ## order_tracking
  - where is my order
  - track my package
  - delivery status

  ## greeting
  - hello
  - hi there
"""

import logging
import os
import re
import time

import yaml

logger = logging.getLogger("flowgraph.rag.embeddings")


def parse_training_data(source_path: str) -> list[dict]:
    """Parse intent training data from YAML or Markdown file.

    Returns a list of dicts: [{"intent": "...", "text": "..."}, ...]
    Each example becomes one embedding record.
    """
    if not os.path.exists(source_path):
        raise FileNotFoundError(f"Training data file not found: {source_path}")

    ext = os.path.splitext(source_path)[1].lower()
    if ext in (".yaml", ".yml"):
        return _parse_yaml(source_path)
    elif ext in (".md", ".markdown"):
        return _parse_markdown(source_path)
    else:
        raise ValueError(f"Unsupported training data format: {ext}  (use .yaml or .md)")


def _parse_yaml(path: str) -> list[dict]:
    """Parse YAML training data."""
    with open(path) as f:
        data = yaml.safe_load(f) or []

    records = []
    for entry in data:
        intent = entry.get("intent", "").strip()
        if not intent:
            continue
        examples = entry.get("examples", [])
        for ex in examples:
            text = str(ex).strip()
            if text:
                records.append({"intent": intent, "text": text})

    logger.info(
        "[PARSE] source=%s  format=yaml  intents=%d  examples=%d", path, len(data), len(records)
    )
    return records


def _parse_markdown(path: str) -> list[dict]:
    """Parse Markdown training data.

    Expected format: ## intent_name followed by bullet list.
    """
    with open(path) as f:
        content = f.read()

    records = []
    current_intent = None
    intent_count = 0

    for line in content.splitlines():
        line = line.strip()
        # Detect intent header: ## intent_name
        header_match = re.match(r"^##\s+(.+)$", line)
        if header_match:
            current_intent = header_match.group(1).strip().lower().replace(" ", "_")
            intent_count += 1
            continue
        # Detect example: - example text
        if current_intent and line.startswith("- "):
            text = line[2:].strip().strip('"').strip("'")
            if text:
                records.append({"intent": current_intent, "text": text})

    logger.info(
        "[PARSE] source=%s  format=md  intents=%d  examples=%d", path, intent_count, len(records)
    )
    return records


def create_embeddings(
    source_path: str,
    config: dict,
    recreate: bool = False,
) -> dict:
    """Generate embeddings from training data and store in pgvector.

    Args:
        source_path: Path to YAML or MD training data file.
        config: App config dict (reads intent.rag and checkpoint sections).
        recreate: If True, drop existing embeddings before creating.

    Returns:
        Summary dict: {"intent_count": int, "example_count": int, "elapsed_ms": float}
    """
    t0 = time.perf_counter()

    # 1. Parse source data
    records = parse_training_data(source_path)
    if not records:
        raise ValueError(f"No training examples found in {source_path}")

    # 2. Get config
    rag_cfg = config.get("intent", {}).get("rag", {})
    embedding_model = rag_cfg.get("embedding_model", "text-embedding-3-small")
    collection = rag_cfg.get("collection", "intent_embeddings")

    # 3. Get PostgreSQL connection string
    conn_str = _get_pg_connection(config)

    # 4. Create embedding function
    embeddings = _get_embedding_function(embedding_model, config)

    # 5. Ensure pgvector extension exists
    _ensure_pgvector(conn_str)

    # 6. Optional: drop existing collection
    if recreate:
        _drop_collection(conn_str, collection)
        logger.info("[EMBEDDINGS] dropped existing collection=%s", collection)

    # 7. Create embeddings and store
    texts = [r["text"] for r in records]
    metadatas = [{"intent": r["intent"], "text": r["text"]} for r in records]

    from langchain_community.vectorstores import PGVector

    PGVector.from_texts(
        texts=texts,
        embedding=embeddings,
        metadatas=metadatas,
        collection_name=collection,
        connection_string=conn_str,
        pre_delete_collection=recreate,
    )

    intents = set(r["intent"] for r in records)
    elapsed_ms = (time.perf_counter() - t0) * 1000

    summary = {
        "intent_count": len(intents),
        "example_count": len(records),
        "collection": collection,
        "embedding_model": embedding_model,
        "elapsed_ms": round(elapsed_ms),
        "intents": sorted(intents),
    }

    logger.info(
        "[EMBEDDINGS] created  intents=%d  examples=%d  collection=%s  model=%s  elapsed=%.0fms",
        len(intents),
        len(records),
        collection,
        embedding_model,
        elapsed_ms,
    )
    return summary


def get_embedding_count(config: dict) -> dict:
    """Get statistics about current embeddings."""
    rag_cfg = config.get("intent", {}).get("rag", {})
    collection = rag_cfg.get("collection", "intent_embeddings")
    conn_str = _get_pg_connection(config)

    try:
        import psycopg

        with psycopg.connect(conn_str) as conn:
            with conn.cursor() as cur:
                # Check if table exists
                cur.execute(
                    "SELECT EXISTS (SELECT 1 FROM information_schema.tables "
                    "WHERE table_name = 'langchain_pg_embedding')"
                )
                exists = cur.fetchone()[0]
                if not exists:
                    return {"collection": collection, "count": 0, "exists": False}

                cur.execute(
                    "SELECT COUNT(*), COUNT(DISTINCT cmetadata->>'intent') "
                    "FROM langchain_pg_embedding e "
                    "JOIN langchain_pg_collection c ON e.collection_id = c.uuid "
                    "WHERE c.name = %s",
                    (collection,),
                )
                row = cur.fetchone()
                return {
                    "collection": collection,
                    "count": row[0],
                    "intent_count": row[1],
                    "exists": True,
                }
    except Exception as e:
        logger.warning("[EMBEDDINGS] stats query failed: %s", e)
        return {"collection": collection, "count": 0, "exists": False, "error": str(e)}


def _get_pg_connection(config: dict) -> str:
    """Get PostgreSQL connection string from config."""
    # First check env var
    conn_str = os.getenv("FLOWGRAPH_RAG_DB_URL", "")
    if conn_str:
        return conn_str

    # Fall back to checkpoint connection string
    conn_str = config.get("checkpoint", {}).get("connection_string", "")
    if conn_str and conn_str.startswith(("postgresql://", "postgres://")):
        return conn_str

    # Default to stack postgres
    return "postgresql://postgres:flowgraph@localhost:5433/postgres"


def _get_embedding_function(model_name: str, config: dict):
    """Create an embedding function based on the LLM provider config."""
    llm_cfg = config.get("llm", {})
    provider = llm_cfg.get("provider", "openai").lower()

    if provider == "openai" or model_name.startswith("text-embedding"):
        from langchain_openai import OpenAIEmbeddings

        return OpenAIEmbeddings(model=model_name)
    elif provider == "ollama":
        from langchain_ollama import OllamaEmbeddings

        embed_model = model_name if model_name != "text-embedding-3-small" else "nomic-embed-text"
        base_url = llm_cfg.get("base_url", "http://localhost:11434")
        return OllamaEmbeddings(model=embed_model, base_url=base_url)
    else:
        # Default to OpenAI embeddings
        from langchain_openai import OpenAIEmbeddings

        return OpenAIEmbeddings(model=model_name)


def _ensure_pgvector(conn_str: str) -> None:
    """Ensure pgvector extension is installed in PostgreSQL."""
    try:
        import psycopg

        with psycopg.connect(conn_str, autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
                logger.debug("[PGVECTOR] extension ensured")
    except Exception as e:
        raise RuntimeError(
            f"Failed to enable pgvector extension: {e}\n"
            "  Fix: Install pgvector in your PostgreSQL server.\n"
            "  Docker: Use postgres:16-alpine + install vector extension.\n"
            "  brew: brew install pgvector"
        ) from e


def _drop_collection(conn_str: str, collection_name: str) -> None:
    """Drop an existing embedding collection."""
    try:
        import psycopg

        with psycopg.connect(conn_str) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM langchain_pg_embedding e "
                    "USING langchain_pg_collection c "
                    "WHERE e.collection_id = c.uuid AND c.name = %s",
                    (collection_name,),
                )
                cur.execute(
                    "DELETE FROM langchain_pg_collection WHERE name = %s", (collection_name,)
                )
                conn.commit()
    except Exception as e:
        logger.warning("[EMBEDDINGS] drop collection failed (may not exist): %s", e)
