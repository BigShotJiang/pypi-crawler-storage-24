"""
RAG-based intent classifier using pgvector similarity search.

Given a user message, this module:
1. Generates an embedding for the message
2. Queries pgvector for the top-k most similar training examples
3. Aggregates intent votes from the top matches
4. Returns the best intent + confidence score

If confidence is below the configured threshold, returns None
so the caller can fall back to LLM-based classification.

config.yaml:
  intent:
    rag:
      enabled: true
      confidence_threshold: 0.7
      top_k: 5
      embedding_model: "text-embedding-3-small"
      collection: "intent_embeddings"
      fallback_to_llm: true
"""

import logging
import time
from collections import Counter

logger = logging.getLogger("flowgraph.rag.classifier")

try:
    from langfuse.decorators import langfuse_context as _lf_ctx
    from langfuse.decorators import observe

    _LANGFUSE_AVAILABLE = True
except ImportError:
    _LANGFUSE_AVAILABLE = False

    def observe(*a, **kw):
        return lambda fn: fn

    _lf_ctx = None


@observe(name="classify:rag", as_type="span")
def classify_with_rag(
    user_message: str,
    config: dict,
    available_workflows: list[str] | None = None,
) -> tuple[str | None, float, list[dict]]:
    """Classify user intent using RAG vector similarity search.

    Args:
        user_message: The user's message text.
        config: Full app config dict.
        available_workflows: Optional list to filter results (only return
                             intents that match available workflow names).

    Returns:
        Tuple of (intent_name, confidence, top_matches).
        - intent_name is None if confidence < threshold.
        - confidence is 0.0–1.0.
        - top_matches is list of {"intent": str, "text": str, "score": float}.
    """
    rag_cfg = config.get("intent", {}).get("rag", {})
    top_k = rag_cfg.get("top_k", 5)
    threshold = rag_cfg.get("confidence_threshold", 0.7)
    collection = rag_cfg.get("collection", "intent_embeddings")
    embedding_model = rag_cfg.get("embedding_model", "text-embedding-3-small")

    t0 = time.perf_counter()

    try:
        from flowgraph_ai.intent_rag.embeddings import _get_embedding_function, _get_pg_connection

        conn_str = _get_pg_connection(config)
        embeddings = _get_embedding_function(embedding_model, config)

        from langchain_community.vectorstores import PGVector

        store = PGVector(
            collection_name=collection,
            connection_string=conn_str,
            embedding_function=embeddings,
        )

        # Perform similarity search with scores
        results = store.similarity_search_with_score(user_message, k=top_k)

        elapsed_ms = (time.perf_counter() - t0) * 1000

        if not results:
            logger.info(
                "[RAG_CLASSIFY] no results  message=%r  elapsed=%.0fms",
                user_message[:50],
                elapsed_ms,
            )
            _update_langfuse(user_message, None, 0.0, [], elapsed_ms, "no_results")
            return None, 0.0, []

        # Convert results to structured format
        # PGVector returns (Document, distance) where lower distance = more similar
        # Convert distance to similarity: score = 1 / (1 + distance)
        top_matches = []
        for doc, distance in results:
            similarity = 1.0 / (1.0 + distance)
            intent = doc.metadata.get("intent", "unknown")
            top_matches.append(
                {
                    "intent": intent,
                    "text": doc.metadata.get("text", doc.page_content[:100]),
                    "score": round(similarity, 4),
                    "distance": round(distance, 4),
                }
            )

        # Filter to only available workflows if provided
        if available_workflows:
            top_matches = [m for m in top_matches if m["intent"] in available_workflows]

        if not top_matches:
            logger.info(
                "[RAG_CLASSIFY] no matches in available workflows  available=%s  elapsed=%.0fms",
                available_workflows,
                elapsed_ms,
            )
            _update_langfuse(user_message, None, 0.0, top_matches, elapsed_ms, "no_workflow_match")
            return None, 0.0, []

        # Vote: aggregate by intent, weighted by score
        intent_scores: Counter = Counter()
        for match in top_matches:
            intent_scores[match["intent"]] += match["score"]

        # Best intent is the one with highest aggregate score
        best_intent, total_score = intent_scores.most_common(1)[0]
        # Normalize confidence by number of matches for that intent
        match_count = sum(1 for m in top_matches if m["intent"] == best_intent)
        confidence = total_score / max(match_count, 1)

        # Clamp to 0-1 range
        confidence = min(1.0, max(0.0, confidence))

        logger.info(
            "[RAG_CLASSIFY] result=%s  confidence=%.3f  threshold=%.2f  "
            "top_k=%d  matches=%d  elapsed=%.0fms  message=%r",
            best_intent,
            confidence,
            threshold,
            top_k,
            len(top_matches),
            elapsed_ms,
            user_message[:50],
        )

        # Check threshold
        if confidence < threshold:
            logger.info(
                "[RAG_CLASSIFY] below_threshold  intent=%s  confidence=%.3f < %.2f",
                best_intent,
                confidence,
                threshold,
            )
            _update_langfuse(
                user_message, best_intent, confidence, top_matches, elapsed_ms, "below_threshold"
            )
            return None, confidence, top_matches

        _update_langfuse(user_message, best_intent, confidence, top_matches, elapsed_ms, "accepted")
        return best_intent, confidence, top_matches

    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.error(
            "[RAG_CLASSIFY] error=%s  elapsed=%.0fms  message=%r",
            e,
            elapsed_ms,
            user_message[:50],
        )
        _update_langfuse(user_message, None, 0.0, [], elapsed_ms, f"error: {e}")
        return None, 0.0, []


def _update_langfuse(
    message: str,
    intent: str | None,
    confidence: float,
    matches: list,
    elapsed_ms: float,
    status: str,
) -> None:
    """Update Langfuse observation with RAG classification details."""
    if not _LANGFUSE_AVAILABLE or not _lf_ctx:
        return
    try:
        _lf_ctx.update_current_observation(
            input={"user_message": message[:200]},
            output={
                "classified_as": intent,
                "confidence": round(confidence, 4),
                "status": status,
                "top_matches": matches[:5],
            },
            metadata={
                "elapsed_ms": round(elapsed_ms),
                "method": "rag",
                "match_count": len(matches),
            },
        )
    except Exception:
        pass
