"""
Redis-backed cache with in-memory fallback.

Provides a unified caching interface used by:
- Intent classification (avoid repeated LLM calls for same message)
- Language detection (avoid repeated LLM calls for same text)
- Guardrails prompts (cache sanitized responses)

If Redis is unavailable or not configured, falls back transparently to
an in-memory LRU dict so the framework runs without external deps.

Config (config.yaml):
  cache:
    enabled: true
    redis_url: "redis://:flowgraphredis@localhost:6379/0"
    ttl_seconds: 3600
    prefix: "fg:"

Environment variable override:
  FLOWGRAPH_REDIS_URL=redis://:flowgraphredis@localhost:6379/0
"""

import hashlib
import logging
import os
import time
from collections import OrderedDict

logger = logging.getLogger("flowgraph.cache")

# Singleton instance
_instance: "FlowGraphCache | None" = None


class FlowGraphCache:
    """Unified cache with Redis backend and in-memory fallback.

    Usage:
        cache = get_cache(config)
        cache.set("intent", "hello world", "greeting", ttl=3600)
        result = cache.get("intent", "hello world")  # → "greeting"
    """

    def __init__(self, config: dict) -> None:
        cache_cfg = config.get("cache", {})
        self._enabled = cache_cfg.get("enabled", False)
        self._prefix = cache_cfg.get("prefix", "fg:")
        self._default_ttl = cache_cfg.get("ttl_seconds", 3600)
        self._redis = None
        self._memory: OrderedDict[str, tuple[str, float]] = OrderedDict()  # key → (value, expiry)
        self._max_memory = 1000  # max in-memory entries

        if not self._enabled:
            logger.debug("[CACHE] disabled in config")
            return

        redis_url = os.getenv("FLOWGRAPH_REDIS_URL") or cache_cfg.get("redis_url", "")
        if not redis_url:
            logger.info("[CACHE] no redis_url configured — using in-memory fallback")
            self._enabled = True  # still enabled, just in-memory
            return

        try:
            import redis as redis_lib

            t0 = time.perf_counter()
            self._redis = redis_lib.from_url(
                redis_url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            # Test connectivity
            self._redis.ping()
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.info(
                "[CACHE] Redis connected  url=%s  elapsed=%.0fms",
                _redact_url(redis_url),
                elapsed_ms,
            )
        except ImportError:
            logger.info(
                "[CACHE] redis package not installed — using in-memory fallback.\n"
                "  Fix: uv add 'flowgraph-ai[cache]'  OR  uv add redis"
            )
            self._redis = None
        except Exception as e:
            logger.warning(
                "[CACHE] Redis connection failed: %s — using in-memory fallback.\n"
                "  Fix: flowgraph stack up  (starts Redis on port 6379)",
                e,
            )
            self._redis = None

    @property
    def is_redis(self) -> bool:
        """True if Redis is active, False if using in-memory fallback."""
        return self._redis is not None

    @property
    def backend(self) -> str:
        """Return the active backend name."""
        if not self._enabled:
            return "disabled"
        return "redis" if self._redis else "memory"

    def _make_key(self, namespace: str, raw_key: str) -> str:
        """Create a stable cache key from namespace + raw key."""
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()[:16]
        return f"{self._prefix}{namespace}:{key_hash}"

    def get(self, namespace: str, raw_key: str) -> str | None:
        """Get a cached value. Returns None on miss or if disabled."""
        if not self._enabled:
            return None

        key = self._make_key(namespace, raw_key)

        if self._redis:
            try:
                val = self._redis.get(key)
                if val is not None:
                    logger.debug("[CACHE_HIT] backend=redis  key=%s", key)
                    return val
                return None
            except Exception as e:
                logger.warning("[CACHE_GET_FAIL] redis error=%s  key=%s", e, key)
                return None
        else:
            # In-memory fallback
            entry = self._memory.get(key)
            if entry is None:
                return None
            value, expiry = entry
            if expiry and time.time() > expiry:
                self._memory.pop(key, None)
                return None
            logger.debug("[CACHE_HIT] backend=memory  key=%s", key)
            self._memory.move_to_end(key)
            return value

    def set(self, namespace: str, raw_key: str, value: str, ttl: int | None = None) -> None:
        """Store a value in cache."""
        if not self._enabled:
            return

        key = self._make_key(namespace, raw_key)
        ttl = ttl or self._default_ttl

        if self._redis:
            try:
                self._redis.setex(key, ttl, value)
                logger.debug("[CACHE_SET] backend=redis  key=%s  ttl=%d", key, ttl)
            except Exception as e:
                logger.warning("[CACHE_SET_FAIL] redis error=%s  key=%s", e, key)
        else:
            # In-memory fallback with LRU eviction
            if len(self._memory) >= self._max_memory:
                # Evict oldest 20%
                evict_count = self._max_memory // 5
                for _ in range(evict_count):
                    self._memory.popitem(last=False)
                logger.debug(
                    "[CACHE_EVICT] removed=%d  remaining=%d", evict_count, len(self._memory)
                )

            expiry = time.time() + ttl if ttl else 0
            self._memory[key] = (value, expiry)
            logger.debug(
                "[CACHE_SET] backend=memory  key=%s  ttl=%d  size=%d", key, ttl, len(self._memory)
            )

    def delete(self, namespace: str, raw_key: str) -> None:
        """Delete a specific cached value."""
        if not self._enabled:
            return

        key = self._make_key(namespace, raw_key)

        if self._redis:
            try:
                self._redis.delete(key)
            except Exception:
                pass
        else:
            self._memory.pop(key, None)

    def clear(self, namespace: str | None = None) -> int:
        """Clear cached values. If namespace given, clear only that namespace.

        Returns count of cleared keys.
        """
        if not self._enabled:
            return 0

        if self._redis:
            try:
                pattern = f"{self._prefix}{namespace}:*" if namespace else f"{self._prefix}*"
                keys = list(self._redis.scan_iter(match=pattern, count=100))
                if keys:
                    self._redis.delete(*keys)
                logger.info(
                    "[CACHE_CLEAR] backend=redis  namespace=%s  cleared=%d",
                    namespace or "*",
                    len(keys),
                )
                return len(keys)
            except Exception as e:
                logger.warning("[CACHE_CLEAR_FAIL] error=%s", e)
                return 0
        else:
            if namespace:
                prefix = f"{self._prefix}{namespace}:"
                keys = [k for k in self._memory if k.startswith(prefix)]
                for k in keys:
                    self._memory.pop(k, None)
                logger.info(
                    "[CACHE_CLEAR] backend=memory  namespace=%s  cleared=%d", namespace, len(keys)
                )
                return len(keys)
            else:
                count = len(self._memory)
                self._memory.clear()
                logger.info("[CACHE_CLEAR] backend=memory  namespace=*  cleared=%d", count)
                return count

    def stats(self) -> dict:
        """Return cache statistics."""
        info: dict = {
            "enabled": self._enabled,
            "backend": self.backend,
            "prefix": self._prefix,
            "default_ttl": self._default_ttl,
        }
        if self._redis:
            try:
                redis_info = self._redis.info("memory")
                info["redis_memory_used"] = redis_info.get("used_memory_human", "?")
                info["redis_keys"] = self._redis.dbsize()
            except Exception:
                info["redis_status"] = "error"
        else:
            info["memory_entries"] = len(self._memory)
            info["memory_max"] = self._max_memory
        return info


def get_cache(config: dict) -> FlowGraphCache:
    """Get or create the singleton cache instance."""
    global _instance
    if _instance is None:
        _instance = FlowGraphCache(config)
    return _instance


def reset() -> None:
    """Reset cache singleton (for testing)."""
    global _instance
    _instance = None


def _redact_url(url: str) -> str:
    """Hide password from Redis URL for logging."""
    import re

    return re.sub(r"(?<=:).+?(?=@)", "****", url)
