"""
Configuration loader for FlowGraph-AI.

Loads config.yaml from the project's working directory (or a custom path)
and merges any .env values into the environment before returning.

Usage::

    from flowgraph_ai.config import load_config

    config = load_config()           # auto-discovers config.yaml in cwd
    config = load_config("/path/to/config.yaml")

Returns an empty dict if no config file is found (framework uses built-in defaults).
"""

import logging
import os

import yaml
from dotenv import load_dotenv

logger = logging.getLogger("flowgraph.config")


def load_config(config_path: str | None = None) -> dict:
    """Load configuration from config.yaml and .env file.

    Search order for config.yaml:
      1. ``config_path`` argument (explicit path)
      2. ``<cwd>/config.yaml``
      3. ``<package_dir>/../config.yaml``

    Env vars in .env always take lower precedence than vars already in the
    process environment (``load_dotenv`` does not overwrite existing vars).

    Args:
        config_path: Explicit path to config.yaml.  Auto-discovered if None.

    Returns:
        Parsed config dict, or ``{}`` if no config file is found.
    """
    # ── Load .env ─────────────────────────────────────────────────────────────
    env_path = os.path.join(os.getcwd(), ".env")
    if not os.path.exists(env_path):
        env_path = os.path.join(os.path.dirname(__file__), "..", ".env")

    if os.path.exists(env_path):
        load_dotenv(env_path)
        logger.debug("[CONFIG] Loaded .env from %s", env_path)
    else:
        logger.debug("[CONFIG] No .env file found (searched cwd and package dir)")

    # ── Resolve config.yaml path ──────────────────────────────────────────────
    if config_path is None:
        config_path = os.path.join(os.getcwd(), "config.yaml")
        if not os.path.exists(config_path):
            config_path = os.path.join(os.path.dirname(__file__), "..", "config.yaml")

    # ── Load YAML ─────────────────────────────────────────────────────────────
    try:
        with open(config_path) as f:
            cfg = yaml.safe_load(f) or {}

        # Warn on common missing keys that many features depend on
        if "llm" not in cfg:
            logger.warning(
                "[CONFIG] No 'llm' section in %s — framework will use Ollama defaults. "
                "Set llm.provider and model in config.yaml for production.",
                config_path,
            )
        if "checkpoint" not in cfg:
            logger.debug(
                "[CONFIG] No 'checkpoint' section — using in-memory checkpointer "
                "(sessions reset on restart). Add checkpoint.connection_string for persistence."
            )

        logger.info("[CONFIG] Loaded config from %s", config_path)
        return cfg

    except FileNotFoundError:
        logger.warning(
            "[CONFIG] No config.yaml found at %s — using framework defaults. "
            "Run 'flowgraph init <project>' to create a new project.",
            config_path,
        )
        return {}
    except yaml.YAMLError as exc:
        logger.error("[CONFIG] Failed to parse %s: %s", config_path, exc)
        raise
