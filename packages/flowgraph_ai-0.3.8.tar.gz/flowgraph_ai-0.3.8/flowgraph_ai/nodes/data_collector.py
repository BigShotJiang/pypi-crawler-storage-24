"""
DataCollector Node — V3.

Collects one or more pieces of information from the user via LangGraph interrupt().

────────────────────────────────────────────────────────────────────────────
SINGLE-FIELD MODE
────────────────────────────────────────────────────────────────────────────
YAML:
  collect_sr:
    type: data_collector
    role: "You are a helpful service desk assistant."
    initial_message: "Please provide your SR number (e.g., SR-12345)"
    field: sr_number
    description: "Service Request number in format SR-XXXXX"
    max_retry: 3
    next: check_billing          # On successful extraction + validation
    on_max_retry: error_response # After max retries (optional, defaults to END)
    allow_intent_escape: false   # Optional — let user ask off-topic questions
    humanize: true               # Optional — humanize bot messages via LLM (default: false)
    guardrails:                  # Optional — per-node guardrails override
      enabled: true
      tone: "warm and friendly"
    validation:
      method: "validations.sr.check_sr_format"
    tools:                       # Optional — tools the LLM can call during extraction
      - method: "actions.my_module.my_tool"
        name: "my_tool"
        description: "What this tool does and when to use it"

PRE-EXTRACTION:
  If the user's opening message already contains the field value, it is
  extracted immediately without asking. If validation fails, the node falls
  back to the normal interrupt loop.

Extraction format: LLM returns "next_node:extracted_value"
  e.g. "check_billing:SR-12345"
  e.g. "EXTRACTION_FAILED:none"

────────────────────────────────────────────────────────────────────────────
MULTI-FIELD MODE
────────────────────────────────────────────────────────────────────────────
YAML:
  collect_contact:
    type: data_collector
    role: "You are a helpful assistant."
    initial_message: "Please provide your full name and email."
    max_retry: 3
    next: process_contact
    on_max_retry: error_response
    humanize: true               # Optional — humanize bot messages via LLM (default: false)
    fields:
      - field: customer_name
        description: "Customer's full name"
      - field: customer_email
        description: "Email address"
        validation:
          method: regex
          pattern: "^[\\w.-]+@[\\w.-]+\\.\\w+$"
    tools:
      - method: "actions.lookup.find_customer"
        name: "find_customer"
        description: "Look up customer details by name"

Multi-field: LLM returns JSON {"customer_name": "Alice", "customer_email": "a@b.com"}
State is updated with all extracted fields. Routes to `next` on completion.

PRE-EXTRACTION:
  If the user's opening message already contains some or all field values,
  those are extracted immediately. The node only asks for the remaining
  missing fields (or nothing if all were found in the first message).

────────────────────────────────────────────────────────────────────────────
TOOLS SUPPORT
────────────────────────────────────────────────────────────────────────────
When `tools:` is defined, the LLM can call them during extraction/response.
Use this when the field value must be fetched from an external source, or
when answering a user question requires live data (e.g. CPU temperature,
stock prices, DB lookups).

Tool functions must accept keyword arguments matching their Pydantic schema.
They can return any value that can be converted to str.

────────────────────────────────────────────────────────────────────────────
HALLUCINATION DETECTION
────────────────────────────────────────────────────────────────────────────
After every successful extraction, the node checks whether the extracted
value is grounded in the user's message, tool results, or session state.

  hallucination_check: true   # Optional — enable/disable grounding check (default: true)

When a hallucinated value is detected:
  1. If the LLM suggests a correction, it is used automatically.
  2. Otherwise, strict re-extraction is attempted from the evidence.
  3. If both fail, the user is re-asked (counts as a retry attempt).

────────────────────────────────────────────────────────────────────────────
MESSAGE PIPELINE (every outgoing bot message)
────────────────────────────────────────────────────────────────────────────
  raw_message → [humanizer LLM] → [guardrails LLM] → user
  Both steps can be disabled per-node or globally in config.yaml.
"""

import importlib
import logging
import time

from langgraph.types import interrupt
from pydantic import Field, create_model

from flowgraph_ai.core.history import format_history, history_updates
from flowgraph_ai.core.language import detect_language, language_instruction
from flowgraph_ai.engine.guardrails import (
    apply_guardrails,
    humanize_and_guard,
    merge_guardrails_config,
)
from flowgraph_ai.engine.json_repair import try_parse_json
from flowgraph_ai.engine.template import render
from flowgraph_ai.llm.provider import get_node_llm
from flowgraph_ai.validators.registry import run_validation

logger = logging.getLogger("flowgraph.nodes.data_collector")

_EXTRACTION_FAILED = "EXTRACTION_FAILED"


# ─────────────────────────────────────────────────────────────────────────────
# Node rollback — redirect to a sibling node if user's input is off-topic
# ─────────────────────────────────────────────────────────────────────────────


def _check_node_redirect(
    llm,
    user_input: str,
    current_node_name: str,
    current_node_desc: str,
    sibling_nodes: list[dict],
    language: str = "",
    custom_prompt: str | None = None,
) -> str | None:
    """
    Check if the user's input is better handled by a sibling data_collector node.

    Returns the sibling node_name to redirect to, or None if the current node
    is the right one to handle this input.

    Only called when `allow_node_rollback: true` (or enabled: true) is set on
    the current node.

    Args:
        custom_prompt: Optional YAML-defined prompt override. Supports
            {current_node}, {current_desc}, {user_input}, {candidates}
            placeholders that will be filled automatically.
    """
    # Build candidate list (sibling nodes that are data_collectors with a description)
    candidates = [
        n
        for n in sibling_nodes
        if n.get("name") != current_node_name
        and n.get("type") == "data_collector"
        and (n.get("description") or n.get("field") or n.get("fields"))
    ]
    if not candidates:
        return None

    def _node_desc(n: dict) -> str:
        if n.get("description"):
            return n["description"]
        if n.get("field"):
            return n.get("field", "")
        fields = n.get("fields", [])
        return ", ".join(f.get("description", f.get("field", "")) for f in fields)

    candidate_lines = "\n".join(f"- {n['name']}: {_node_desc(n)}" for n in candidates)
    candidate_names_str = ", ".join(n["name"] for n in candidates)

    if custom_prompt:
        # Allow YAML author to fully customize routing logic with placeholders
        prompt = custom_prompt.format(
            current_node=current_node_name,
            current_desc=current_node_desc,
            user_input=user_input,
            candidates=candidate_lines,
            candidate_names=candidate_names_str,
            language=language or "auto",
        )
    else:
        prompt = (
            f"You are routing user input to the correct data collection step.\n\n"
            f"Current step: '{current_node_name}' — collects: {current_node_desc}\n\n"
            f'User said: "{user_input}"\n\n'
            f"Other available steps:\n{candidate_lines}\n\n"
            f"Decide: is the user's input best handled by the CURRENT step, "
            f"or should it redirect to one of the other steps?\n"
            f"Rules:\n"
            f"- If the user is providing information for the CURRENT step, respond: current\n"
            f"- If the user is clearly asking about or providing information for a DIFFERENT step, "
            f"respond with ONLY that step name (e.g., 'collect_address')\n"
            f"- If unsure, respond: current\n"
            f"Respond with a single word only."
        )

    try:
        result = llm.invoke(prompt).content.strip().lower().rstrip(".")
    except Exception as e:
        logger.warning("[NODE_REDIRECT_CHECK] error=%s  defaulting=current", e)
        return None

    if result == "current" or result == current_node_name.lower():
        return None

    # Validate it's a real sibling
    candidate_names = {n["name"].lower(): n["name"] for n in candidates}
    if result in candidate_names:
        return candidate_names[result]

    logger.debug(
        "[NODE_REDIRECT_CHECK] llm_returned=%r  not_a_valid_sibling  defaulting=current", result
    )
    return None


def build_node(
    node_def: dict,
    default_llm,
    app_config: dict | None = None,
    workflow_guardrails: dict | None = None,
    callbacks: list | None = None,
    sibling_nodes: list[dict] | None = None,
):
    """Return a LangGraph-compatible node function for a data_collector node.

    Args:
        node_def:            The node configuration dict from workflow YAML.
        default_llm:         The LangChain LLM instance.
        app_config:          The full app config dict (from config.yaml).
        workflow_guardrails: Optional workflow-level guardrails config.
        callbacks:           Optional list of LangChain callbacks.
        sibling_nodes:       All other node defs in this workflow — used for
                             node rollback (allow_node_rollback: true).
    """
    is_multi = "fields" in node_def

    # Pre-compute guardrails config (merged from all levels)
    node_guardrails = node_def.get("guardrails")
    guardrails_cfg = merge_guardrails_config(app_config, workflow_guardrails, node_guardrails)

    # Humanize setting: opt-in (default False)
    humanize_cfg = node_def.get("humanize", False)

    humanize_enabled = False
    humanize_prompt = None

    if isinstance(humanize_cfg, bool):
        humanize_enabled = humanize_cfg
    elif isinstance(humanize_cfg, dict):
        humanize_enabled = humanize_cfg.get("enabled", False)
        humanize_prompt = humanize_cfg.get("custom_prompt")

    # Rollback config: support bool or dict {enabled, custom_prompt}
    # e.g.  allow_node_rollback: true
    # or    allow_node_rollback:
    #         enabled: true
    #         custom_prompt: "Route {user_input} — current: {current_node}, options: {candidates}"
    rollback_cfg = node_def.get("allow_node_rollback", False)
    if isinstance(rollback_cfg, bool):
        allow_rollback = rollback_cfg
        rollback_custom_prompt: str | None = None
    elif isinstance(rollback_cfg, dict):
        allow_rollback = bool(rollback_cfg.get("enabled", False))
        rollback_custom_prompt = rollback_cfg.get("custom_prompt") or None
    else:
        allow_rollback = False
        rollback_custom_prompt = None
    rollback_siblings = sibling_nodes or []

    # Load tools declared in YAML (optional)
    tools = _load_dc_tools(node_def.get("tools", []))

    def node_fn(state: dict) -> dict:
        llm = get_node_llm(node_def, default_llm, app_config, callbacks=callbacks)
        language = state.get("user_language", "English") or "English"

        node_name = node_def.get("name", "?")

        def polish(msg: str) -> str:
            """Humanize and/or apply guardrails to any outgoing bot message."""
            if not msg or not msg.strip():
                return msg
            t0 = time.perf_counter()
            result = msg
            if humanize_enabled and guardrails_cfg.get("enabled", True):
                result = humanize_and_guard(result, llm, language, guardrails_cfg, humanize_prompt)
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.debug(
                    "[POLISH] node=%s  mode=humanize+guardrails  elapsed=%.0fms  chars=%d→%d",
                    node_name,
                    elapsed_ms,
                    len(msg),
                    len(result),
                )
            elif humanize_enabled:
                result = _humanize_message(result, llm, language, humanize_prompt)
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.debug(
                    "[POLISH] node=%s  mode=humanize_only  elapsed=%.0fms  chars=%d→%d",
                    node_name,
                    elapsed_ms,
                    len(msg),
                    len(result),
                )
            elif guardrails_cfg.get("enabled", True):
                result = apply_guardrails(result, llm, language, guardrails_cfg)
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.info(
                    "[POLISH] node=%s  mode=guardrails_only  elapsed=%.0fms  chars=%d→%d",
                    node_name,
                    elapsed_ms,
                    len(msg),
                    len(result),
                )
            return result

        if is_multi:
            return _multi_field(
                state,
                node_def,
                llm,
                polish,
                tools=tools,
                allow_rollback=allow_rollback,
                rollback_siblings=rollback_siblings,
                rollback_custom_prompt=rollback_custom_prompt,
            )
        else:
            return _single_field(
                state,
                node_def,
                llm,
                polish,
                tools=tools,
                allow_rollback=allow_rollback,
                rollback_siblings=rollback_siblings,
                rollback_custom_prompt=rollback_custom_prompt,
            )

    return node_fn


# ─────────────────────────────────────────────────────────────────────────────
# Single-field implementation
# ─────────────────────────────────────────────────────────────────────────────


def _single_field(
    state: dict,
    node_def: dict,
    llm,
    polish,
    tools: list | None = None,
    allow_rollback: bool = False,
    rollback_siblings: list[dict] | None = None,
    rollback_custom_prompt: str | None = None,
) -> dict:
    field = node_def["field"]
    description = node_def.get("description", field)
    max_retry = node_def.get("max_retry", 3)
    validation_config = node_def.get("validation", {})
    allow_escape_cfg = node_def.get("allow_intent_escape", False)
    allow_escape = (
        allow_escape_cfg.get("enabled", False)
        if isinstance(allow_escape_cfg, dict)
        else bool(allow_escape_cfg)
    )
    escape_prompt = (
        allow_escape_cfg.get("custom_prompt") if isinstance(allow_escape_cfg, dict) else None
    )
    next_node = node_def.get("next", "END")
    tools = tools or []

    node_name = node_def.get("name", "?")

    # Skip if already collected
    if state.get(field) and str(state[field]).strip():
        logger.info("[FIELD_SKIP] node=%s  field=%s  reason=already_in_state", node_name, field)
        return {}

    language = state.get("user_language", "")
    history = state.get("messages", [])

    # ── PRE-EXTRACTION: try to get the field from the user's opening message ──
    user_message = state.get("user_message", "")
    if user_message:
        pre_result = _try_pre_extract_single(
            llm, user_message, description, next_node, language, tools, state
        )
        if pre_result is not None:
            value, node = pre_result
            is_valid = True
            if validation_config:
                is_valid, _ = run_validation(value, validation_config)
            if is_valid:
                lang_updates = {}
                if not language:
                    lang = detect_language(user_message, llm)
                    if lang:
                        lang_updates["user_language"] = lang
                logger.info(
                    "[PRE_EXTRACT] node=%s  field=%s  value=%r  source=user_message",
                    node_name,
                    field,
                    value,
                )
                return {field: value, "_dc_next_node": node, **lang_updates}

    # ── Build initial question ────────────────────────────────────────────────
    if node_def.get("initial_message"):
        raw_question = render(node_def["initial_message"], state)
    else:
        raw_question = _generate_question(llm, description, state, language)
    question = polish(raw_question)

    updates: dict = {}

    for attempt in range(max_retry):
        # ── Ask user (LangGraph interrupt) ───────────────────────────────────
        logger.info(
            "[INTERRUPT] node=%s  question_chars=%d  attempt=%d/%d",
            node_name,
            len(question),
            attempt + 1,
            max_retry,
        )
        user_input = str(interrupt({"question": question, "field": field})).strip()

        # ── Node rollback: redirect if user's input fits a sibling node better ──────
        if allow_rollback and rollback_siblings:
            redirect_target = _check_node_redirect(
                llm,
                user_input,
                node_name,
                description,
                rollback_siblings,
                language,
                custom_prompt=rollback_custom_prompt,
            )
            if redirect_target:
                logger.info(
                    "[NODE_ROLLBACK] node=%s  redirect_to=%s  user_input=%r",
                    node_name,
                    redirect_target,
                    user_input[:80],
                )
                hist = history_updates(question, user_input)
                updates["messages"] = updates.get("messages", []) + hist.get("messages", [])
                updates["_dc_next_node"] = redirect_target
                return updates

        # ── Language detection (first turn only) ─────────────────────────────
        if attempt == 0 and not language:
            t_lang = time.perf_counter()
            language = detect_language(user_input, llm)
            elapsed_lang_ms = (time.perf_counter() - t_lang) * 1000
            if language:
                updates["user_language"] = language
                logger.info(
                    "[LANG_DETECT] detected=%s  elapsed=%.0fms",
                    language,
                    elapsed_lang_ms,
                )

        # ── History tracking ─────────────────────────────────────────────────
        hist = history_updates(question, user_input)
        updates["messages"] = updates.get("messages", []) + hist.get("messages", [])

        # ── Intent escape: answer off-topic questions inline ─────────────────
        if allow_escape:
            if _is_off_topic(llm, user_input, description, language, custom_prompt=escape_prompt):
                logger.info(
                    "[OFF_TOPIC] user_input=%r  answering_and_continuing",
                    user_input[:80],
                )
                off_topic_answer = _answer_off_topic(llm, user_input, state, language, tools)
                re_ask = render(node_def.get("initial_message", ""), state) or _generate_question(
                    llm, description, state, language
                )
                question = polish(f"{off_topic_answer}\n\n{re_ask}")
                continue

        # ── Resolve tools (if any) before extraction ─────────────────────────
        tool_context = _resolve_with_tools(llm, user_input, tools, state) if tools else ""

        # ── LLM extraction: returns "next_node:value" format ─────────────────
        t_extract = time.perf_counter()
        raw = _extract_single(
            llm,
            user_input,
            description,
            next_node,
            state,
            language,
            history,
            tool_context=tool_context,
        )
        elapsed_extract_ms = (time.perf_counter() - t_extract) * 1000
        logger.debug("[RAW_LLM] response=%r", raw)
        parsed_node, extracted = _parse_extraction(raw, next_node)

        if parsed_node == _EXTRACTION_FAILED or not extracted or extracted == "none":
            logger.info(
                "[RETRY] field=%s  attempt=%d/%d  reason=extraction_failed",
                field,
                attempt + 1,
                max_retry,
            )
            logger.info(
                "[EXTRACT] node=%s  attempt=%d  elapsed=%.0fms  result=failed",
                node_name,
                attempt + 1,
                elapsed_extract_ms,
            )
            question = polish(
                _generate_retry_question(
                    llm, description, state, language, reason="could not extract the value"
                )
            )
            continue

        logger.info(
            "[EXTRACT] node=%s  attempt=%d  elapsed=%.0fms  result=success",
            node_name,
            attempt + 1,
            elapsed_extract_ms,
        )

        # ── Validation ───────────────────────────────────────────────────────
        if validation_config:
            is_valid, error_msg = run_validation(extracted, validation_config)
            if not is_valid:
                logger.info(
                    "[RETRY] field=%s  attempt=%d/%d  reason=validation_failed  error=%s",
                    field,
                    attempt + 1,
                    max_retry,
                    error_msg,
                )
                question = polish(
                    _generate_retry_question(llm, description, state, language, reason=error_msg)
                )
                continue

        # ── Hallucination grounding check ────────────────────────────────────
        grounding_enabled = node_def.get("hallucination_check", True)
        if grounding_enabled:
            from flowgraph_ai.engine.hallucination import attempt_autofix, check_grounding

            grounding = check_grounding(
                llm,
                extracted,
                description,
                user_input,
                tool_context=tool_context,
                session_context=state,
                language=language,
            )
            if not grounding.is_grounded:
                logger.warning(
                    "[HALLUCINATION] node=%s  field=%s  value=%r  reason=%s  attempt=%d",
                    node_name,
                    field,
                    extracted,
                    grounding.reason,
                    attempt + 1,
                )
                # Try auto-correction first
                if grounding.corrected_value:
                    extracted = grounding.corrected_value
                    logger.info("[AUTOFIX] Used LLM-suggested correction: %r", extracted)
                else:
                    fixed = attempt_autofix(
                        llm, description, user_input, tool_context=tool_context, language=language
                    )
                    if fixed:
                        extracted = fixed
                        logger.info(
                            "[AUTOFIX] Deterministic re-extraction succeeded: %r", extracted
                        )
                    else:
                        question = polish(
                            _generate_retry_question(
                                llm,
                                description,
                                state,
                                language,
                                reason="could not verify the value — please provide it explicitly",
                            )
                        )
                        continue

        # ── Success ──────────────────────────────────────────────────────────
        updates[field] = extracted
        updates["_dc_next_node"] = parsed_node
        logger.info(
            "[FIELD_COLLECTED] field=%s  value=%s  attempt=%d  elapsed=%.0fms",
            field,
            extracted,
            attempt + 1,
            elapsed_extract_ms,
        )
        return updates

    # ── Max retry exceeded ────────────────────────────────────────────────────
    logger.warning(
        "[MAX_RETRY] node=%s  field=%s  max=%d  routing_to=%s",
        node_name,
        field,
        max_retry,
        node_def.get("on_max_retry", "END"),
    )
    updates["_dc_failed"] = True
    updates["_dc_node"] = node_def["name"]
    return updates


# ─────────────────────────────────────────────────────────────────────────────
# Multi-field implementation
# ─────────────────────────────────────────────────────────────────────────────


def _multi_field(
    state: dict,
    node_def: dict,
    llm,
    polish,
    tools: list | None = None,
    allow_rollback: bool = False,
    rollback_siblings: list[dict] | None = None,
    rollback_custom_prompt: str | None = None,
) -> dict:
    fields_config = node_def["fields"]
    max_retry = node_def.get("max_retry", 3)
    allow_escape_cfg = node_def.get("allow_intent_escape", False)
    allow_escape = (
        allow_escape_cfg.get("enabled", False)
        if isinstance(allow_escape_cfg, dict)
        else bool(allow_escape_cfg)
    )
    escape_prompt = (
        allow_escape_cfg.get("custom_prompt") if isinstance(allow_escape_cfg, dict) else None
    )
    tools = tools or []

    node_name = node_def.get("name", "?")

    # Skip if all fields already in state
    if all(state.get(f["field"]) and str(state[f["field"]]).strip() for f in fields_config):
        logger.info("[FIELD_SKIP] node=%s  reason=all_fields_in_state", node_name)
        return {}

    language = state.get("user_language", "")
    field_descriptions = ", ".join(f.get("description", f["field"]) for f in fields_config)

    updates: dict = {}
    collected: dict = {}

    # ── PRE-EXTRACTION: try to get fields from the user's opening message ─────
    user_message = state.get("user_message", "")
    fields_to_extract = fields_config

    if user_message:
        role = node_def.get("role", "You are a helpful assistant.")
        pre_extracted = _extract_multi(
            llm,
            user_message,
            fields_to_extract,
            role,
            language,
            initial_message=user_message,
            tools=tools,
        )
        # Validate pre-extracted fields
        for f in fields_config:
            fname = f["field"]
            val = pre_extracted.get(fname)
            if val and f.get("validation"):
                is_valid, _ = run_validation(val, f["validation"])
                if not is_valid:
                    pre_extracted.pop(fname, None)
        collected.update(pre_extracted)
        updates.update(pre_extracted)

        # Apply defaults for fields not found in pre-extraction
        for f in fields_config:
            fname = f["field"]
            if "default" in f and not collected.get(fname) and not state.get(fname):
                updates[fname] = f["default"]
                collected[fname] = f["default"]

        missing_fields = [
            f
            for f in fields_config
            if updates.get(f["field"]) is None
            and state.get(f["field"]) is None
            and "default" not in f
        ]

        if not missing_fields:
            # All fields extracted from the user's opening message — no need to ask
            lang_updates = {}
            if not language:
                lang = detect_language(user_message, llm)
                if lang:
                    lang_updates["user_language"] = lang
            logger.info(
                "[PRE_EXTRACT] node=%s  all_%d_fields_from_user_message",
                node_name,
                len(fields_config),
            )
            return {**updates, **lang_updates}

        # Some fields still missing — narrow scope and adjust question
        fields_to_extract = missing_fields
        missing_descs = [f.get("description", f["field"]) for f in missing_fields]
        if pre_extracted:
            logger.info(
                "[PRE_EXTRACT] node=%s  partial=%d_found  still_need=%s",
                node_name,
                len(pre_extracted),
                ", ".join(f["field"] for f in missing_fields),
            )
        raw_question = _generate_question(llm, ", ".join(missing_descs), state, language)
    else:
        if node_def.get("initial_message"):
            raw_question = render(node_def["initial_message"], state)
        else:
            raw_question = f"Please provide the following: {field_descriptions}."

    question = polish(raw_question)

    for attempt in range(max_retry):
        # ── Ask user ─────────────────────────────────────────────────────────
        field_label = ", ".join(f["field"] for f in fields_to_extract)
        logger.info(
            "[INTERRUPT] node=%s  question_chars=%d  attempt=%d/%d  extracting=%s",
            node_name,
            len(question),
            attempt + 1,
            max_retry,
            field_label,
        )
        user_input = str(interrupt({"question": question, "field": field_label})).strip()

        # ── Node rollback: redirect if user's input fits a sibling node better ──────
        if allow_rollback and rollback_siblings:
            rollback_desc = field_descriptions  # what this multi-field node collects
            redirect_target = _check_node_redirect(
                llm,
                user_input,
                node_name,
                rollback_desc,
                rollback_siblings,
                language,
                custom_prompt=rollback_custom_prompt,
            )
            if redirect_target:
                logger.info(
                    "[NODE_ROLLBACK] node=%s  redirect_to=%s  user_input=%r",
                    node_name,
                    redirect_target,
                    user_input[:80],
                )
                hist = history_updates(question, user_input)
                updates["messages"] = updates.get("messages", []) + hist.get("messages", [])
                updates["_dc_next_node"] = redirect_target
                return updates

        # ── Language detection ────────────────────────────────────────────────
        if attempt == 0 and not language:
            t_lang = time.perf_counter()
            language = detect_language(user_input, llm)
            elapsed_lang_ms = (time.perf_counter() - t_lang) * 1000
            if language:
                updates["user_language"] = language
                logger.info(
                    "[LANG_DETECT] detected=%s  elapsed=%.0fms",
                    language,
                    elapsed_lang_ms,
                )

        # ── History ──────────────────────────────────────────────────────────
        hist = history_updates(question, user_input)
        updates["messages"] = updates.get("messages", []) + hist.get("messages", [])

        # ── Intent escape: answer off-topic questions inline ─────────────────
        if allow_escape and _is_off_topic(
            llm, user_input, field_descriptions, language, custom_prompt=escape_prompt
        ):
            off_topic_answer = _answer_off_topic(llm, user_input, state, language, tools)
            re_ask = render(node_def.get("initial_message", ""), state) or _generate_question(
                llm, field_descriptions, state, language
            )
            question = polish(f"{off_topic_answer}\n\n{re_ask}")
            continue

        # ── Resolve tools (if any) before extraction ─────────────────────────
        tool_context = _resolve_with_tools(llm, user_input, tools, state) if tools else ""

        # ── JSON extraction (structured output, only missing fields) ─────────
        role = node_def.get("role", "You are a helpful assistant.")
        extracted = _extract_multi(
            llm,
            user_input,
            fields_to_extract,
            role,
            language,
            initial_message=state.get("user_message", ""),
            tool_context=tool_context,
            tools=tools,
        )
        collected.update(extracted)

        # ── Validate each extracted field ─────────────────────────────────────
        validation_errors = []
        for f in fields_config:
            fname = f["field"]
            val = collected.get(fname)
            if val and f.get("validation"):
                is_valid, error_msg = run_validation(val, f["validation"])
                if not is_valid:
                    validation_errors.append(f"{f.get('description', fname)}: {error_msg}")
                    collected.pop(fname, None)

        # ── Apply field defaults for unextracted optional fields ─────────────
        for f in fields_config:
            fname = f["field"]
            if (
                "default" in f
                and not collected.get(fname)
                and not updates.get(fname)
                and not state.get(fname)
            ):
                updates[fname] = f["default"]
                collected[fname] = f["default"]
                logger.debug("Field '%s' not extracted — using default: '%s'", fname, f["default"])

        updates.update(collected)

        # ── Hallucination grounding check for newly extracted fields ──────────
        grounding_enabled = node_def.get("hallucination_check", True)
        if grounding_enabled:
            from flowgraph_ai.engine.hallucination import check_grounding

            for f in fields_to_extract:
                fname = f["field"]
                val = collected.get(fname) or updates.get(fname)
                if not val:
                    continue
                grounding = check_grounding(
                    llm,
                    str(val),
                    f.get("description", fname),
                    user_input,
                    tool_context=tool_context,
                    session_context=state,
                    language=language,
                )
                if not grounding.is_grounded:
                    logger.warning(
                        "[HALLUCINATION] node=%s  field=%s  value=%r  reason=%s",
                        node_name,
                        fname,
                        val,
                        grounding.reason,
                    )
                    if grounding.corrected_value:
                        collected[fname] = grounding.corrected_value
                        updates[fname] = grounding.corrected_value
                    else:
                        collected.pop(fname, None)
                        updates.pop(fname, None)

        # ── Check completion ──────────────────────────────────────────────────
        missing_fields = [
            f
            for f in fields_config
            if updates.get(f["field"]) is None
            and state.get(f["field"]) is None
            and "default" not in f
        ]
        missing = [f.get("description", f["field"]) for f in missing_fields]

        if not missing:
            logger.info(
                "[FIELD_COLLECTED] node=%s  collected=%d_fields",
                node_name,
                len(fields_config),
            )
            return updates

        # ── Narrow extraction scope: only ask LLM for still-missing fields ───
        fields_to_extract = missing_fields

        # ── Build retry question ──────────────────────────────────────────────
        if validation_errors:
            question = polish(
                _generate_retry_question(
                    llm,
                    description=", ".join(f.get("description", f["field"]) for f in fields_config),
                    state=state,
                    language=language,
                    reason="; ".join(validation_errors),
                )
            )
        else:
            question = polish(
                _generate_retry_question(
                    llm,
                    description=", ".join(missing),
                    state=state,
                    language=language,
                    reason=f"still need: {', '.join(missing)}",
                )
            )

    # ── Max retry exceeded ────────────────────────────────────────────────────
    logger.warning(
        "[MAX_RETRY] node=%s  fields=%s  max=%d  routing_to=%s",
        node_name,
        ", ".join(f["field"] for f in fields_config),
        max_retry,
        node_def.get("on_max_retry", "END"),
    )
    updates["_dc_failed"] = True
    updates["_dc_node"] = node_def["name"]
    return updates


# ─────────────────────────────────────────────────────────────────────────────
# Tools support
# ─────────────────────────────────────────────────────────────────────────────


def _load_dc_tools(tools_config: list) -> list:
    """Load tool functions from the YAML tools config list.

    Each entry must have:
      method: "module.path.function_name"
      name: "tool_name"
      description: "What the tool does and when to call it"

    Returns a list of LangChain StructuredTool objects.
    """
    if not tools_config:
        return []
    try:
        from langchain_core.tools import StructuredTool
    except ImportError:
        logger.warning("langchain_core not available — tools will be disabled")
        return []

    tools = []
    for t_cfg in tools_config:
        method_path = t_cfg.get("method", "")
        if not method_path or "." not in method_path:
            logger.error("[TOOL_LOAD] Invalid method path: %r", method_path)
            continue
        module_path, func_name = method_path.rsplit(".", 1)
        try:
            try:
                module = importlib.import_module(module_path)
            except ModuleNotFoundError:
                if module_path.startswith("actions.") or module_path.startswith("validations."):
                    module = importlib.import_module(f"flowgraph_ai.{module_path}")
                else:
                    raise
            func = getattr(module, func_name)
            tool_name = t_cfg.get("name", func_name)
            tool_desc = t_cfg.get("description", getattr(func, "__doc__", "") or "")
            lc_tool = StructuredTool.from_function(
                func=func,
                name=tool_name,
                description=tool_desc,
            )
            tools.append(lc_tool)
            logger.info("[TOOL_LOAD] loaded=%s  from=%s", tool_name, method_path)
        except Exception as e:
            logger.error("[TOOL_LOAD] Failed to load %r: %s", method_path, e)
    return tools


def _resolve_with_tools(llm, user_input: str, tools: list, state: dict) -> str:
    """Run tool calls needed for the given user input and return context string.

    The LLM decides which tools (if any) to call based on the user's message.
    All tool results are concatenated and returned as a context string to be
    injected into the extraction prompt.

    Returns an empty string when no tools are called.
    """
    if not tools:
        return ""

    try:
        from langchain_core.messages import HumanMessage, ToolMessage
    except ImportError:
        return ""

    tool_map = {t.name: t for t in tools}

    tool_llm = llm.bind_tools(tools)
    tool_names = ", ".join(t.name for t in tools)

    prompt = (
        f'The user said: "{user_input}"\n\n'
        f"Available tools: {tool_names}\n\n"
        f"If any tool is needed to answer or get context for this message, call it now.\n"
        f"If no tool is needed, say exactly: NO_TOOLS_NEEDED"
    )
    messages = [HumanMessage(content=prompt)]
    context_parts = []

    for _ in range(4):  # max 4 tool call rounds
        try:
            response = tool_llm.invoke(messages)
        except Exception as e:
            logger.warning("[TOOL_RESOLVE] LLM call failed: %s", e)
            break

        tool_calls = getattr(response, "tool_calls", []) or []
        if not tool_calls:
            break  # No tool calls — done

        messages.append(response)
        for tc in tool_calls:
            tool_name = tc.get("name", "")
            tool_args = tc.get("args", {})
            tool_id = tc.get("id", tool_name)
            if tool_name in tool_map:
                try:
                    result = tool_map[tool_name].invoke(tool_args)
                    result_str = str(result)
                    context_parts.append(f"{tool_name}: {result_str}")
                    messages.append(ToolMessage(content=result_str, tool_call_id=tool_id))
                    logger.info("[TOOL_CALL] tool=%s  result_chars=%d", tool_name, len(result_str))
                except Exception as e:
                    err_str = f"Error: {e}"
                    messages.append(ToolMessage(content=err_str, tool_call_id=tool_id))
                    logger.warning("[TOOL_CALL] tool=%s  error=%s", tool_name, e)

    return "\n".join(context_parts)


# ─────────────────────────────────────────────────────────────────────────────
# LLM helpers
# ─────────────────────────────────────────────────────────────────────────────


def _try_pre_extract_single(
    llm,
    user_message: str,
    description: str,
    success_node: str,
    language: str,
    tools: list,
    state: dict,
) -> tuple | None:
    """Try to extract a single field value from the user's opening message.

    Returns (value, node_name) if successful, None if not found.
    Does NOT interrupt — used only for pre-extraction before asking.
    """
    # Resolve tools if needed
    tool_context = _resolve_with_tools(llm, user_message, tools, state) if tools else ""
    tool_section = f"\nTool results:\n{tool_context}\n" if tool_context else ""

    lang_instr = language_instruction(language)
    prompt = (
        f"Extract {description} from the user's message below.{tool_section}\n"
        f'User message: "{user_message}"\n\n'
        f"If you can clearly extract the value, respond EXACTLY as:\n"
        f"  {success_node}:<extracted_value>\n\n"
        f"If the value is NOT clearly present in the message or tool results, respond EXACTLY as:\n"
        f"  {_EXTRACTION_FAILED}:none\n\n"
        f"{lang_instr}\n"
        f"Return ONLY the formatted response, nothing else."
    )
    try:
        raw = llm.invoke(prompt).content.strip()
        node, val = _parse_extraction(raw, success_node)
        if node != _EXTRACTION_FAILED and val and val != "none":
            return val, node
        return None
    except Exception as e:
        logger.debug("[PRE_EXTRACT_FAIL] error=%s", e)
        return None


def _extract_single(
    llm,
    user_input: str,
    description: str,
    success_node: str,
    state: dict,
    language: str,
    history: list,
    tool_context: str = "",
) -> str:
    """Prompt LLM to extract a single field. Returns 'node:value' or 'EXTRACTION_FAILED:none'."""
    lang_instr = language_instruction(language)
    history_text = format_history(history, max_turns=3) if history else ""
    history_section = (
        f"\nRecent conversation:\n{history_text}\n"
        if history_text and history_text != "(no conversation history)"
        else ""
    )

    initial_msg = state.get("user_message", "")
    initial_section = (
        f'\nUser\'s opening message (may contain useful context):\n"{initial_msg}"\n'
        if initial_msg
        else ""
    )

    tool_section = f"\nContext from tool calls:\n{tool_context}\n" if tool_context else ""

    prompt = (
        f"Extract {description} from the user's message.\n"
        f"{initial_section}"
        f"{history_section}"
        f"{tool_section}"
        f'User said: "{user_input}"\n\n'
        f"NOTE: If the user refers to something they already stated (e.g. 'I already told you', "
        f"'already mentioned', 'as I said'), look for the value in the conversation history "
        f"or opening message above.\n\n"
        f"If tool context is available above, use it as additional data when extracting.\n\n"
        f"If you successfully extract the value, respond EXACTLY as:\n"
        f"  {success_node}:<extracted_value>\n\n"
        f"If you cannot extract the value, respond EXACTLY as:\n"
        f"  {_EXTRACTION_FAILED}:none\n\n"
        f"{lang_instr}\n"
        f"Return ONLY the formatted response, nothing else."
    )
    logger.debug("[PROMPT_EXTRACT] prompt_chars=%d\n%s", len(prompt), prompt)
    result = llm.invoke(prompt).content.strip()
    logger.debug("[RAW_LLM] response=%r", result)
    return result


def _parse_extraction(raw: str, default_next: str) -> tuple[str, str]:
    """Parse 'node:value' format. Returns (node_name, value)."""
    if ":" in raw:
        parts = raw.split(":", 1)
        node = parts[0].strip()
        value = parts[1].strip()
        return node, value
    return _EXTRACTION_FAILED, "none"


def _extract_multi(
    llm,
    user_input: str,
    fields_config: list,
    role: str,
    language: str,
    initial_message: str = "",
    tool_context: str = "",
    tools: list | None = None,
) -> dict:
    """Use Pydantic structured output to extract multiple fields at once.

    Args:
        llm:             LLM instance.
        user_input:      The user's current reply.
        fields_config:   List of field configs to extract (may be a subset on retries).
        role:            System role string from the node YAML.
        language:        Detected language for the response.
        initial_message: The user's very first message (workflow entry).
        tool_context:    Tool call results to inject as additional context.
        tools:           Optional list of LangChain tools (resolved before calling this).
    """
    field_defs = {}
    for f in fields_config:
        fname = f["field"]
        desc = f.get("description", fname)
        field_defs[fname] = (str | None, Field(default=None, description=desc))

    dynamic_model_class = create_model("ExtractedFields", **field_defs)
    structured_llm = llm.with_structured_output(dynamic_model_class)

    lang_instr = language_instruction(language)
    field_list = "\n".join(
        f"- {f['field']}: {f.get('description', f['field'])}" for f in fields_config
    )

    initial_section = (
        f'\nUser\'s opening message (may contain useful context):\n"{initial_message}"\n'
        if initial_message
        else ""
    )

    tool_section = f"\nContext from tool calls:\n{tool_context}\n" if tool_context else ""

    prompt = (
        f"{role}\n\n"
        f"Extract the following from the user's message:\n{field_list}\n{initial_section}{tool_section}\n"
        f'User said: "{user_input}"\n\n'
        f"NOTE: If the user says 'same date', 'same as above', or refers to a previously "
        f"given value, infer the value from the opening message or context.\n\n"
        f"If tool context is available above, use it as additional data when extracting.\n\n"
        f"Set each field to null if not found. {lang_instr}\n\n"
        f"CRITICAL RULES:\n"
        f"1. Extract ONLY the raw value itself. For example, if user says 'My order is ORD-123', extract ONLY 'ORD-123'. Do NOT include words like 'My order is'.\n"
        f"2. Return ONLY a valid JSON object. Do NOT include markdown blocks. Do NOT output pretext or explanations."
    )
    try:
        result = structured_llm.invoke(prompt)
        return {k: v for k, v in result.model_dump().items() if v is not None}
    except Exception as e:
        # Structured output (Pydantic) failed — fall back to raw LLM call + JSON repair
        logger.error("Structured extraction failed: %s. Attempting JSON repair.", e)
        raw = llm.invoke(prompt).content
        parsed = try_parse_json(raw)
        return parsed if isinstance(parsed, dict) else {}


def _humanize_message(text: str, llm, language: str, custom_prompt: str | None = None) -> str:
    """Pass any outgoing bot message through an LLM to ensure it sounds natural and human."""
    lang_instr = language_instruction(language)

    if custom_prompt:
        prompt = (
            f"{custom_prompt.strip()}\n\n"
            f"Keep all the core information exactly the same. Do not add new information.\n"
            f"{lang_instr}\n\n"
            f"CRITICAL: Return ONLY the message text. No quotes, no labels, no explanations.\n\n"
            f"Message:\n{text}"
        )
    else:
        prompt = (
            f"You are a warm, human-sounding customer support agent.\n"
            f"Review this message and ensure it sounds natural and conversational — "
            f"not robotic or like a form.\n"
            f"Keep all the information exactly the same. Do not add new information.\n"
            f"If it already sounds natural, return it unchanged.\n"
            f"{lang_instr}\n\n"
            f"CRITICAL: Return ONLY the message text. No quotes, no labels, no explanations.\n\n"
            f"Message:\n{text}"
        )

    try:
        result = llm.invoke(prompt).content.strip().strip('"').strip("'")
        if result:
            logger.debug("Humanizer: %d chars → %d chars", len(text), len(result))
            return result
        return text
    except Exception as e:
        logger.warning("Humanizer LLM call failed: %s. Using original message.", e)
        return text


def _generate_question(llm, description: str, state: dict, language: str) -> str:
    """Use LLM to generate a natural question for the required field."""
    lang_instr = language_instruction(language)
    prompt = (
        f"Generate a short, friendly question to ask the user for: {description}.\n"
        f"{lang_instr}\n"
        f"Return ONLY the question text — no quotes, no labels."
    )
    return llm.invoke(prompt).content.strip().strip('"').strip("'")


def _generate_retry_question(llm, description: str, state: dict, language: str, reason: str) -> str:
    """Generate a polite retry question explaining why the previous answer failed."""
    lang_instr = language_instruction(language)
    prompt = (
        f"The user's previous answer was not valid for: {description}.\n"
        f"Reason: {reason}\n"
        f"Generate a short, polite message explaining the issue and re-asking for: {description}.\n"
        f"{lang_instr}\n"
        f"Return ONLY the message text itself — no quotes, no labels, no explanations."
    )
    return llm.invoke(prompt).content.strip().strip('"').strip("'")


def _is_off_topic(
    llm, user_input: str, expected_description: str, language: str, custom_prompt: str | None = None
) -> bool:
    """Check if the user's reply is off-topic (not answering the expected question)."""
    if custom_prompt:
        prompt = (
            f"{custom_prompt}\n\n"
            f"We need to collect: {expected_description}.\n"
            f'The user said: "{user_input}"\n\n'
            f"Respond ONLY with: ON_TOPIC or OFF_TOPIC"
        )
    else:
        prompt = (
            f"We need the user to provide: {expected_description}.\n"
            f'The user said: "{user_input}"\n\n'
            f"QUESTION: Is the user's message actually providing the requested information,\n"
            f"or are they asking a NEW question about something else entirely?\n\n"
            f"Examples:\n"
            f"- If we need 'order ID' and user says 'ORD-12345' → ON_TOPIC (providing data)\n"
            f"- If we need 'order ID' and user says 'Do you ship to Canada?' → OFF_TOPIC (asking new question)\n"
            f"- If we need 'email' and user says 'my email is john@test.com' → ON_TOPIC\n"
            f"- If we need 'email' and user says 'What payment methods do you accept?' → OFF_TOPIC\n\n"
            f"Respond ONLY with: ON_TOPIC or OFF_TOPIC"
        )
    try:
        result = llm.invoke(prompt).content.strip().upper()
        return "OFF_TOPIC" in result
    except Exception:
        return False


def _answer_off_topic(
    llm, user_input: str, state: dict, language: str, tools: list | None = None
) -> str:
    """Answer the user's off-topic question briefly, using tools if available."""
    lang_instr = language_instruction(language)
    history = state.get("messages", [])
    history_text = format_history(history, max_turns=3)
    tools = tools or []

    # Resolve tools for the off-topic question if tools are available
    tool_context = _resolve_with_tools(llm, user_input, tools, state) if tools else ""
    tool_section = f"\nRelevant information from tools:\n{tool_context}\n" if tool_context else ""

    prompt = (
        f"The user asked an off-topic question during a conversation.\n"
        f"Context:\n{history_text}\n"
        f"{tool_section}\n"
        f'User asked: "{user_input}"\n\n'
        f"Answer this question briefly and helpfully. {lang_instr}\n"
        f"Return ONLY the answer."
    )
    try:
        return llm.invoke(prompt).content.strip()
    except Exception:
        return "I'm not sure about that, but let me continue with your original request."


# ─────────────────────────────────────────────────────────────────────────────
# Router — called by graph_builder as a conditional edge function
# ─────────────────────────────────────────────────────────────────────────────


def make_router(node_def: dict, all_node_names: set):
    """Return a LangGraph conditional edge function for a data_collector node."""
    is_multi = "fields" in node_def
    next_node = node_def.get("next", "END")
    on_max_retry = node_def.get("on_max_retry", "END")

    if is_multi:
        fields_config = node_def["fields"]

        def multi_router(state: dict) -> str:
            if state.get("_dc_failed") and state.get("_dc_node") == node_def["name"]:
                return on_max_retry if on_max_retry in all_node_names else "__end__"
            all_collected = all(state.get(f["field"]) is not None for f in fields_config)
            if all_collected:
                return next_node if next_node in all_node_names else "__end__"
            return "__end__"

        return multi_router

    else:
        field = node_def["field"]

        def single_router(state: dict) -> str:
            if state.get("_dc_failed") and state.get("_dc_node") == node_def["name"]:
                return on_max_retry if on_max_retry in all_node_names else "__end__"
            if state.get(field):
                extracted_next = state.get("_dc_next_node", "")
                if extracted_next and extracted_next in all_node_names:
                    return extracted_next
                return next_node if next_node in all_node_names else "__end__"
            return "__end__"

        return single_router
