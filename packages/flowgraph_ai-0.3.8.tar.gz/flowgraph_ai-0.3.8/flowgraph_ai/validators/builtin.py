"""Built-in validators for the FlowGraph-AI framework.

Each validator is a callable with signature::

    def validate_<name>(value: str, config: dict) -> tuple[bool, str]:
        ...

Returns a 2-tuple: ``(is_valid: bool, error_message: str)``.
When valid, ``error_message`` is an empty string.

BUILTIN_VALIDATORS maps method names (used in YAML) to their functions.

YAML usage::

    validation:
      method: regex
      pattern: "^SR-\\d{5}$"
      error_message: "Must be SR-XXXXX format"

Custom validators can be registered via :mod:`flowgraph_ai.validators.registry`.
"""

import logging
import re

logger = logging.getLogger("flowgraph.validators.builtin")


def validate_regex(value: str, config: dict) -> tuple[bool, str]:
    """Validate value matches a regex pattern.

    YAML::

        validation:
          method: regex
          pattern: "^SR-\\d{5}$"
          error_message: "Must be in format SR-XXXXX"
    """
    pattern = config.get("pattern", ".*")
    if re.match(pattern, value):
        logger.debug("[VALIDATOR] regex PASS  pattern=%r  value=%r", pattern, value[:50])
        return True, ""
    msg = config.get("error_message", f"Value must match pattern: {pattern}")
    logger.debug("[VALIDATOR] regex FAIL  pattern=%r  value=%r  msg=%r", pattern, value[:50], msg)
    return False, msg


def validate_length(value: str, config: dict) -> tuple[bool, str]:
    """Validate string length is within bounds.

    YAML::

        validation:
          method: length
          min: 3
          max: 10
    """
    min_len = config.get("min", 0)
    max_len = config.get("max", float("inf"))
    if min_len <= len(value) <= max_len:
        logger.debug(
            "[VALIDATOR] length PASS  len=%d  range=[%s, %s]", len(value), min_len, max_len
        )
        return True, ""
    msg = config.get("error_message", f"Length must be between {min_len} and {max_len}")
    logger.debug("[VALIDATOR] length FAIL  len=%d  range=[%s, %s]", len(value), min_len, max_len)
    return False, msg


def validate_numeric(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is a number, optionally within range.

    YAML::

        validation:
          method: numeric
          min: 1
          max: 100
    """
    try:
        num = float(value)
    except ValueError:
        msg = config.get("error_message", "Must be a valid number")
        logger.debug("[VALIDATOR] numeric FAIL — not a number  value=%r", value[:50])
        return False, msg

    min_val = config.get("min", float("-inf"))
    max_val = config.get("max", float("inf"))
    if min_val <= num <= max_val:
        logger.debug("[VALIDATOR] numeric PASS  num=%s  range=[%s, %s]", num, min_val, max_val)
        return True, ""
    msg = config.get("error_message", f"Must be between {min_val} and {max_val}")
    logger.debug("[VALIDATOR] numeric FAIL  num=%s  range=[%s, %s]", num, min_val, max_val)
    return False, msg


def validate_one_of(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is one of the allowed options (case-insensitive).

    YAML::

        validation:
          method: one_of
          options: ["high", "medium", "low"]
    """
    options = config.get("options", [])
    if value.lower() in [o.lower() for o in options]:
        logger.debug("[VALIDATOR] one_of PASS  value=%r  options=%s", value, options)
        return True, ""
    msg = config.get("error_message", f"Must be one of: {', '.join(options)}")
    logger.debug("[VALIDATOR] one_of FAIL  value=%r  options=%s", value, options)
    return False, msg


def validate_not_empty(value: str, config: dict) -> tuple[bool, str]:
    """Validate value is not blank/whitespace.

    YAML::

        validation:
          method: not_empty
    """
    if value.strip():
        logger.debug("[VALIDATOR] not_empty PASS")
        return True, ""
    msg = config.get("error_message", "This field cannot be empty")
    logger.debug("[VALIDATOR] not_empty FAIL — blank input")
    return False, msg


# ── Registry ──────────────────────────────────────────────────────────────────

BUILTIN_VALIDATORS: dict[str, callable] = {
    "regex": validate_regex,
    "length": validate_length,
    "numeric": validate_numeric,
    "one_of": validate_one_of,
    "not_empty": validate_not_empty,
}
