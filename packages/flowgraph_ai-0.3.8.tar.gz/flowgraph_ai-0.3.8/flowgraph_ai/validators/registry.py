"""
Validation Registry.

Resolves validator by name:
  - Built-in: 'regex', 'length', 'numeric', 'one_of', 'not_empty'
  - Dynamic import: 'validations.sr.check_sr_format'
"""

import importlib
import logging
import time

from flowgraph_ai.validators.builtin import BUILTIN_VALIDATORS

logger = logging.getLogger("flowgraph.validators.registry")


def run_validation(value: str, validation_config: dict) -> tuple[bool, str]:
    """Run a validation method from config.

    Args:
        value: The value to validate.
        validation_config: Dict with at least a 'method' key.

    Returns:
        (is_valid, error_message) tuple.
    """
    if not validation_config:
        return True, ""

    method_name = validation_config.get("method", "not_empty")
    t0 = time.perf_counter()

    # Dynamic import for custom validators (e.g., 'validations.sr.check_sr_format')
    if "." in method_name:
        try:
            module_name, func_name = method_name.rsplit(".", 1)
            try:
                module = importlib.import_module(module_name)
            except ModuleNotFoundError:
                if module_name.startswith("validations.") or module_name.startswith("actions."):
                    module = importlib.import_module(f"flowgraph_ai.{module_name}")
                else:
                    raise
            validator_func = getattr(module, func_name)
            is_valid, error_msg = validator_func(value, validation_config)
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.info(
                "[VALIDATE] method=%s  value=%r  valid=%s  elapsed=%.0fms%s",
                method_name,
                value[:50] if value else "",
                is_valid,
                elapsed_ms,
                f"  error={error_msg}" if not is_valid else "",
            )
            return is_valid, error_msg
        except Exception as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.error(
                "[VALIDATE_FAIL] method=%s  error=%s  elapsed=%.0fms",
                method_name,
                e,
                elapsed_ms,
            )
            return False, f"Internal validation error: {e}"

    # Built-in registry lookup
    validator = BUILTIN_VALIDATORS.get(method_name)
    if validator is None:
        logger.warning(
            "[VALIDATE_UNKNOWN] method=%r  not_in_builtins=%s  skipping",
            method_name,
            list(BUILTIN_VALIDATORS.keys()),
        )
        return True, ""

    is_valid, error_msg = validator(value, validation_config)
    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.info(
        "[VALIDATE] method=%s  value=%r  valid=%s  elapsed=%.1fms%s",
        method_name,
        value[:50] if value else "",
        is_valid,
        elapsed_ms,
        f"  error={error_msg}" if not is_valid else "",
    )
    return is_valid, error_msg
