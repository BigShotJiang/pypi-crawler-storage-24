"""
Hallucination detection and auto-fix for DataCollector extracted values.

After the LLM extracts a field value from user input, this module:
1. Validates the extracted value is actually present in user message / tool results / session state
2. If suspicious → retries with correction prompt
3. Records retry reason in logs, tracker, and Langfuse spans
4. Fails gracefully after max_hallucination_retries

Langfuse observability:
  - check_grounding() creates a Langfuse span with input evidence, verdict, confidence
  - attempt_autofix() creates a span showing strict re-extraction results

Usage:
    from flowgraph_ai.engine.hallucination import check_grounding, GroundingResult

    result = check_grounding(llm, extracted_value, field_description, user_input, context)
    if not result.is_grounded:
        # retry or flag
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass

logger = logging.getLogger("flowgraph.engine.hallucination")

# ── Langfuse decorators (optional — graceful no-op if not installed) ──────────
try:
    from langfuse.decorators import langfuse_context as _lf_ctx
    from langfuse.decorators import observe as _lf_observe

    _LANGFUSE_AVAILABLE = True
except ImportError:
    _LANGFUSE_AVAILABLE = False
    _lf_observe = lambda *a, **kw: lambda fn: fn  # noqa: E731
    _lf_ctx = None


@dataclass
class GroundingResult:
    """Result of a hallucination grounding check."""

    is_grounded: bool
    confidence: float  # 0.0 – 1.0
    reason: str  # Human-readable explanation
    corrected_value: str | None = None  # Auto-corrected value if available
    method: str = "llm"  # "llm" | "regex" | "deterministic"


@_lf_observe(name="hallucination:check_grounding", as_type="span")
def check_grounding(
    llm,
    extracted_value: str,
    field_description: str,
    user_input: str,
    tool_context: str = "",
    session_context: dict | None = None,
    language: str = "",
) -> GroundingResult:
    """Check whether an extracted value is grounded in the available evidence.

    Steps:
    1. Fast deterministic check — is the value a literal substring of the evidence?
    2. LLM grounding check — ask the LLM if the value is supported by the evidence.
    3. Return GroundingResult with is_grounded, confidence, reason, and optional correction.
    """
    t0 = time.perf_counter()

    if not extracted_value or not extracted_value.strip():
        return GroundingResult(is_grounded=False, confidence=0.0, reason="Empty extracted value")

    logger.info(
        "[GROUNDING_START] field=%s  value=%r  user_input_chars=%d  has_tool_ctx=%s",
        field_description[:50],
        extracted_value[:100],
        len(user_input),
        bool(tool_context),
    )

    # Update Langfuse span input
    if _LANGFUSE_AVAILABLE and _lf_ctx:
        try:
            _lf_ctx.update_current_observation(
                input={
                    "extracted_value": extracted_value[:200],
                    "field_description": field_description,
                    "user_input_preview": user_input[:200],
                    "has_tool_context": bool(tool_context),
                    "has_session_context": bool(session_context),
                },
            )
        except Exception:
            pass

    # Build evidence string from all available context
    evidence_parts = [f'User said: "{user_input}"']
    if tool_context:
        evidence_parts.append(f"Tool results:\n{tool_context}")
    if session_context:
        relevant = {
            k: v
            for k, v in session_context.items()
            if v and not k.startswith("_") and k not in ("messages", "output", "error")
        }
        if relevant:
            evidence_parts.append(f"Prior session data: {relevant}")
    evidence = "\n\n".join(evidence_parts)

    # ── Step 1: Fast deterministic check ─────────────────────────────────────
    deterministic_result = _deterministic_check(extracted_value, user_input, tool_context)
    if deterministic_result is not None:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "[GROUNDING_DONE] method=deterministic  is_grounded=%s  confidence=%.2f  "
            "elapsed=%.0fms  reason=%s",
            deterministic_result.is_grounded,
            deterministic_result.confidence,
            elapsed_ms,
            deterministic_result.reason[:80],
        )
        _update_langfuse_grounding(deterministic_result, elapsed_ms)
        return deterministic_result

    # ── Step 2: LLM grounding check ───────────────────────────────────────────
    result = _llm_grounding_check(llm, extracted_value, field_description, evidence, language)
    elapsed_ms = (time.perf_counter() - t0) * 1000

    logger.info(
        "[GROUNDING_DONE] method=llm  is_grounded=%s  confidence=%.2f  "
        "elapsed=%.0fms  corrected=%s  reason=%s",
        result.is_grounded,
        result.confidence,
        elapsed_ms,
        result.corrected_value[:50] if result.corrected_value else "none",
        result.reason[:80],
    )
    _update_langfuse_grounding(result, elapsed_ms)
    return result


def _update_langfuse_grounding(result: GroundingResult, elapsed_ms: float) -> None:
    """Update the current Langfuse span with grounding result metadata."""
    if not _LANGFUSE_AVAILABLE or _lf_ctx is None:
        return
    try:
        _lf_ctx.update_current_observation(
            output={
                "is_grounded": result.is_grounded,
                "confidence": result.confidence,
                "reason": result.reason,
                "corrected_value": result.corrected_value,
                "method": result.method,
            },
            metadata={
                "elapsed_ms": round(elapsed_ms),
                "is_grounded": result.is_grounded,
                "confidence": result.confidence,
                "method": result.method,
                "has_correction": result.corrected_value is not None,
            },
            level="WARNING" if not result.is_grounded else "DEFAULT",
        )
    except Exception:
        pass


def _deterministic_check(
    extracted_value: str, user_input: str, tool_context: str
) -> GroundingResult | None:
    """Fast non-LLM check. Returns a result if clearly grounded or clearly absent.

    Returns None if uncertain (falls through to LLM check).
    """
    val = extracted_value.strip().lower()
    combined_evidence = (user_input + " " + tool_context).lower()

    # Direct substring match → clearly grounded
    if val in combined_evidence:
        return GroundingResult(
            is_grounded=True,
            confidence=0.98,
            reason="Value found verbatim in evidence",
            method="deterministic",
        )

    # Check for common hallucination patterns (values that look invented)
    hallucination_patterns = [
        r"\b(john doe|jane doe|test\d+|example\.com|foo|bar|baz|placeholder|dummy|fake)\b",
        r"\b(12345678|00000000|xxxxxx|aaaaaa)\b",
    ]
    for pattern in hallucination_patterns:
        if re.search(pattern, val, re.IGNORECASE):
            logger.warning(
                "[HALLUCINATION_PATTERN] Detected suspicious pattern in value: %r  pattern=%s",
                extracted_value,
                pattern,
            )
            return GroundingResult(
                is_grounded=False,
                confidence=0.9,
                reason=f"Value matches suspicious hallucination pattern: {pattern}",
                method="deterministic",
            )

    return None  # Uncertain — let LLM decide


def _llm_grounding_check(
    llm,
    extracted_value: str,
    field_description: str,
    evidence: str,
    language: str = "",
) -> GroundingResult:
    """Ask the LLM whether the extracted value is supported by the evidence."""
    prompt = (
        f"You are a fact-checker validating an AI extraction result.\n\n"
        f"Field being extracted: {field_description}\n"
        f'Extracted value: "{extracted_value}"\n\n'
        f"Evidence available:\n{evidence}\n\n"
        f"Question: Is the extracted value actually present in or clearly derivable from the evidence above?\n\n"
        f"Rules:\n"
        f"- Answer GROUNDED if the value appears verbatim or can be clearly inferred from the evidence.\n"
        f"- Answer HALLUCINATED if the value does NOT appear in the evidence and cannot be inferred.\n"
        f"- If hallucinated, suggest the correct value from the evidence (or 'NONE' if not found).\n\n"
        f"Respond in EXACTLY this format (3 lines):\n"
        f"VERDICT: GROUNDED or HALLUCINATED\n"
        f"CONFIDENCE: 0.0-1.0\n"
        f"CORRECTION: <correct value from evidence, or NONE if not found>\n"
    )

    t0 = time.perf_counter()
    try:
        raw = llm.invoke(prompt).content.strip()
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.debug(
            "[GROUNDING_LLM] elapsed=%.0fms  response=%r",
            elapsed_ms,
            raw[:200],
        )
        return _parse_grounding_response(raw, extracted_value)
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.warning(
            "[GROUNDING_LLM_FAIL] error=%s  elapsed=%.0fms  assuming=grounded",
            e,
            elapsed_ms,
        )
        # Fail open — assume grounded if we can't check
        return GroundingResult(
            is_grounded=True,
            confidence=0.5,
            reason=f"Grounding check failed (LLM error: {e}), assuming grounded",
            method="llm",
        )


def _parse_grounding_response(raw: str, original_value: str) -> GroundingResult:
    """Parse the 3-line LLM grounding response."""
    lines = [line.strip() for line in raw.strip().splitlines() if line.strip()]
    verdict = "GROUNDED"
    confidence = 0.8
    correction = None

    for line in lines:
        upper = line.upper()
        if upper.startswith("VERDICT:"):
            verdict = "HALLUCINATED" if "HALLUCINATED" in upper else "GROUNDED"
        elif upper.startswith("CONFIDENCE:"):
            try:
                confidence = float(line.split(":", 1)[1].strip())
                confidence = max(0.0, min(1.0, confidence))
            except (ValueError, IndexError):
                confidence = 0.7
        elif upper.startswith("CORRECTION:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() not in ("NONE", "N/A", ""):
                correction = val

    is_grounded = verdict == "GROUNDED"
    reason = f"LLM verdict: {verdict} (confidence={confidence:.2f})"
    if not is_grounded and correction:
        reason += f" → suggested correction: {correction!r}"

    return GroundingResult(
        is_grounded=is_grounded,
        confidence=confidence,
        reason=reason,
        corrected_value=correction if not is_grounded else None,
        method="llm",
    )


@_lf_observe(name="hallucination:autofix", as_type="span")
def attempt_autofix(
    llm,
    field_description: str,
    user_input: str,
    tool_context: str = "",
    language: str = "",
) -> str | None:
    """Attempt to deterministically re-extract a field value from evidence.

    Used after hallucination detection fails — tries a stricter extraction prompt.
    Returns the corrected value string, or None if extraction fails.
    """
    t0 = time.perf_counter()
    evidence = user_input
    if tool_context:
        evidence += f"\n\nAdditional context:\n{tool_context}"

    logger.info(
        "[AUTOFIX_START] field=%s  evidence_chars=%d",
        field_description[:50],
        len(evidence),
    )

    if _LANGFUSE_AVAILABLE and _lf_ctx:
        try:
            _lf_ctx.update_current_observation(
                input={
                    "field_description": field_description,
                    "evidence_preview": evidence[:300],
                    "language": language,
                },
            )
        except Exception:
            pass

    from flowgraph_ai.core.language import language_instruction

    lang_instr = language_instruction(language)

    prompt = (
        f"STRICT EXTRACTION MODE.\n\n"
        f"Extract ONLY what is explicitly stated in the evidence for: {field_description}\n\n"
        f"Evidence:\n{evidence}\n\n"
        f"Rules:\n"
        f"- Only extract values that appear VERBATIM or are UNAMBIGUOUSLY clear.\n"
        f"- Do NOT infer, guess, or hallucinate.\n"
        f"- If the value is not present, respond with exactly: NOT_FOUND\n\n"
        f"{lang_instr}\n"
        f"Return ONLY the extracted value (or NOT_FOUND)."
    )
    try:
        result = llm.invoke(prompt).content.strip()
        elapsed_ms = (time.perf_counter() - t0) * 1000

        if result and result.upper() != "NOT_FOUND" and result != "none":
            logger.info(
                "[AUTOFIX_SUCCESS] field=%s  corrected_value=%r  elapsed=%.0fms",
                field_description[:50],
                result[:100],
                elapsed_ms,
            )
            if _LANGFUSE_AVAILABLE and _lf_ctx:
                try:
                    _lf_ctx.update_current_observation(
                        output={"corrected_value": result[:200], "success": True},
                        metadata={"elapsed_ms": round(elapsed_ms), "success": True},
                    )
                except Exception:
                    pass
            return result

        logger.info(
            "[AUTOFIX_NOT_FOUND] field=%s  elapsed=%.0fms",
            field_description[:50],
            elapsed_ms,
        )
        if _LANGFUSE_AVAILABLE and _lf_ctx:
            try:
                _lf_ctx.update_current_observation(
                    output={"success": False, "reason": "NOT_FOUND"},
                    metadata={"elapsed_ms": round(elapsed_ms), "success": False},
                )
            except Exception:
                pass
        return None
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.warning(
            "[AUTOFIX_FAIL] field=%s  error=%s  elapsed=%.0fms",
            field_description[:50],
            e,
            elapsed_ms,
        )
        return None
