"""
JSON Repair & Guardrails.

When an LLM returns malformed JSON:
  1. Try json.loads() directly.
  2. Try extracting a JSON block from the text (```json ... ``` or bare {...}).
  3. Send a repair prompt to the LLM and retry (configurable retries).
"""

import json
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

_JSON_BLOCK = re.compile(r"```(?:json)?\s*([\s\S]*?)```", re.IGNORECASE)
_BARE_OBJECT = re.compile(r"(\{[\s\S]*\})", re.DOTALL)
_BARE_ARRAY = re.compile(r"(\[[\s\S]*\])", re.DOTALL)


def try_parse_json(text: str) -> Any | None:
    """Try to parse JSON from text. Returns parsed object or None."""
    text = text.strip()

    # 1. Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # 2. Extract from code block
    block_match = _JSON_BLOCK.search(text)
    if block_match:
        try:
            return json.loads(block_match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # 3. Extract bare object
    for pattern in (_BARE_OBJECT, _BARE_ARRAY):
        match = pattern.search(text)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass

    return None


def repair_json(text: str, llm, max_retries: int = 2) -> Any | None:
    """Attempt to parse JSON from text, repairing via LLM if needed.

    Args:
        text: Raw LLM output that should contain JSON.
        llm: LangChain LLM instance for repair prompts.
        max_retries: Number of LLM repair attempts.

    Returns:
        Parsed Python object, or None if all attempts fail.
    """
    result = try_parse_json(text)
    if result is not None:
        return result

    logger.warning("JSON parse failed. Attempting LLM repair (up to %d retries).", max_retries)

    current_text = text
    for attempt in range(1, max_retries + 1):
        repair_prompt = (
            "The following text should be valid JSON but is malformed.\n"
            "Return ONLY the corrected JSON with no explanation or markdown:\n\n"
            f"{current_text}"
        )
        try:
            repaired = llm.invoke(repair_prompt).content.strip()
            result = try_parse_json(repaired)
            if result is not None:
                logger.info("JSON repaired on attempt %d.", attempt)
                return result
            current_text = repaired
        except Exception as e:
            logger.error("JSON repair LLM call failed on attempt %d: %s", attempt, e)

    logger.error("JSON repair exhausted all retries. Returning None.")
    return None
