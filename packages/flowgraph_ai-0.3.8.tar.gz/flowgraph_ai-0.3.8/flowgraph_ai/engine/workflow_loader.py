"""
Workflow Loader — V3.

Loads and validates YAML workflow definitions.

V3 supports only 3 node types: data_collector, custom_action, response.

YAML format (dict-style nodes):
  workflow: my_workflow
  description: "What this handles — used by intent classifier"
  start_node: first_node
  state:
    my_field: str           # Simple type string
  nodes:
    node_name:
      type: data_collector | custom_action | response
      ...

Standard state fields auto-injected (no need to declare):
  messages, user_language, output, error, user_message
"""

import logging
import os
import time

import yaml

logger = logging.getLogger("flowgraph.engine.workflow_loader")


def _get_workflows_dir() -> str:
    cwd_dir = os.path.join(os.getcwd(), "workflows")
    if os.path.isdir(cwd_dir):
        return cwd_dir
    return os.path.join(os.path.dirname(__file__), "..", "..", "workflows")


_WORKFLOWS_DIR = _get_workflows_dir()

_VALID_NODE_TYPES = {"data_collector", "custom_action", "response"}

_STANDARD_STATE = {
    "user_message": "str",  # Initial user message (generic)
    "user_language": "str",  # Detected language
    "output": "str",  # Final output to user
    "error": "str",  # Error message
    "messages": "list",  # Full conversation history
    # Internal DataCollector routing signals
    "_dc_next_node": "str",
    "_dc_failed": "bool",
    "_dc_node": "str",
}


class WorkflowLoader:
    def __init__(
        self, workflows_dir: str | None = None, fallback_workflow: str = "greeting"
    ) -> None:
        self._dir = workflows_dir or _WORKFLOWS_DIR
        self._fallback = fallback_workflow
        logger.info(
            "[LOADER_INIT] workflows_dir=%s  fallback=%s",
            self._dir,
            self._fallback,
        )

    def load(self, workflow_name: str) -> dict:
        """Load and normalize a workflow by name."""
        t0 = time.perf_counter()
        path = os.path.join(self._dir, f"{workflow_name}.yaml")
        if not os.path.exists(path):
            logger.warning(
                "[WORKFLOW_FALLBACK] workflow=%r  not_found  using=%s  path=%s",
                workflow_name,
                self._fallback,
                path,
            )
            path = os.path.join(self._dir, f"{self._fallback}.yaml")
        else:
            logger.debug("[WORKFLOW_LOAD] workflow=%s  path=%s", workflow_name, path)

        with open(path) as f:
            raw = yaml.safe_load(f)

        config = self._normalize(raw, workflow_name)
        elapsed_ms = (time.perf_counter() - t0) * 1000

        # Log detailed node summary
        node_types = {}
        for n in config["nodes"]:
            t = n.get("type", "?")
            node_types[t] = node_types.get(t, 0) + 1
        type_summary = ", ".join(f"{t}={c}" for t, c in sorted(node_types.items()))

        logger.info(
            "[WORKFLOW_LOADED] workflow=%s  nodes=%d  types=[%s]  start=%s  "
            "state_fields=%d  has_guardrails=%s  elapsed=%.0fms",
            config["workflow"],
            len(config["nodes"]),
            type_summary,
            config.get("start_node"),
            len(config["state"]),
            bool(config.get("guardrails")),
            elapsed_ms,
        )
        return config

    def load_metadata(self, workflow_name: str) -> dict:
        """Load only name + description (fast, for intent classifier)."""
        path = os.path.join(self._dir, f"{workflow_name}.yaml")
        if not os.path.exists(path):
            logger.debug("[METADATA_MISS] workflow=%s  not_found", workflow_name)
            return {"workflow": workflow_name, "description": workflow_name}
        with open(path) as f:
            raw = yaml.safe_load(f) or {}
        desc = raw.get("description", workflow_name.replace("_", " "))
        logger.debug(
            "[METADATA_LOAD] workflow=%s  description=%r",
            workflow_name,
            desc[:60],
        )
        return {
            "workflow": raw.get("workflow", workflow_name),
            "description": desc,
        }

    def _normalize(self, raw: dict, workflow_name: str) -> dict:
        """Normalize YAML to canonical internal format."""
        name = raw.get("workflow", workflow_name)
        description = raw.get("description", name.replace("_", " "))
        initial_input_field = raw.get("initial_input_field", "user_message")

        # Merge standard + user-defined state schema
        user_state = raw.get("state", {})
        state_schema = {**_STANDARD_STATE, **user_state}
        if initial_input_field not in state_schema:
            state_schema[initial_input_field] = "str"

        # Nodes: dict format (V3 primary)
        raw_nodes = raw.get("nodes", {})
        if isinstance(raw_nodes, dict):
            nodes = []
            for node_name, node_def in raw_nodes.items():
                nd = dict(node_def)
                nd["name"] = node_name
                nodes.append(nd)
        elif isinstance(raw_nodes, list):
            nodes = raw_nodes  # backward compat
        else:
            nodes = []

        start_node = raw.get("start_node") or (nodes[0]["name"] if nodes else None)

        config = {
            "workflow": name,
            "description": description,
            "initial_input_field": initial_input_field,
            "start_node": start_node,
            "state": state_schema,
            "nodes": nodes,
            "guardrails": raw.get("guardrails"),  # workflow-level guardrails override (optional)
        }
        self._validate(config)
        return config

    def _validate(self, config: dict) -> None:
        if not config.get("nodes"):
            raise ValueError(f"Workflow '{config['workflow']}' has no nodes defined.")
        for node in config["nodes"]:
            if "name" not in node:
                raise ValueError(f"Node missing 'name': {node}")
            if "type" not in node:
                raise ValueError(f"Node '{node['name']}' missing 'type'.")
            if node["type"] not in _VALID_NODE_TYPES:
                raise ValueError(
                    f"Node '{node['name']}' has unknown type '{node['type']}'. "
                    f"Valid: {_VALID_NODE_TYPES}"
                )
        node_names = {n["name"] for n in config["nodes"]}
        start = config.get("start_node")
        if start and start not in node_names:
            raise ValueError(
                f"Workflow '{config['workflow']}' start_node '{start}' not in nodes {node_names}."
            )

    def list_workflows(self) -> list[str]:
        if not os.path.isdir(self._dir):
            logger.warning("[WORKFLOW_LIST] dir_not_found  path=%s", self._dir)
            return []
        workflows = [f[:-5] for f in os.listdir(self._dir) if f.endswith(".yaml")]
        logger.debug("[WORKFLOW_LIST] found=%d  names=%s", len(workflows), workflows)
        return workflows
