"""
FlowGraph-AI — Interactive CLI (V3).

Flow per conversation turn:
  1. User types a message.
  2. Intent classifier maps it to a workflow.
  3. GraphBuilder compiles the workflow.
  4. Graph runs with LangGraph interrupt/resume (SqliteSaver checkpoints).
  5. CLI handles WAITING_INPUT (interrupt) ↔ COMPLETED cycle.
  6. Same thread_id resumes the conversation from where it left off.
"""

import logging
import uuid

from langgraph.types import Command

from flowgraph_ai.config import load_config
from flowgraph_ai.engine.graph_builder import GraphBuilder
from flowgraph_ai.engine.workflow_loader import WorkflowLoader
from flowgraph_ai.intent import classify_intent
from flowgraph_ai.llm.provider import get_llm
from flowgraph_ai.storage.checkpointer import get_checkpointer

logger = logging.getLogger("flowgraph.main")


def _generate_follow_up(
    llm, completed_output: str, conversation_history: list, user_message: str, workflow_name: str
) -> str:
    """Answer a follow-up question after a workflow has completed.

    Returns the response text, or "__NEW_WORKFLOW__:<name>" if the LLM decides
    the user's message is a completely new request that should start fresh.
    """
    from flowgraph_ai.core.history import format_history

    history_text = format_history(conversation_history or [], max_turns=6)

    prompt = (
        f"A '{workflow_name}' conversation just completed.\n\n"
        f"Previous conversation:\n{history_text}\n\n"
        f"Bot's final response was:\n{completed_output}\n\n"
        f'User\'s follow-up: "{user_message}"\n\n'
        f"Decision:\n"
        f"1. If this is a follow-up related to the completed topic (concern, more info, "
        f"escalation, timeline question, complaint), answer it helpfully in context.\n"
        f"2. If this is CLEARLY a brand-new unrelated request, respond exactly with:\n"
        f"   __NEW_WORKFLOW__:\n\n"
        f"Return ONLY the response text or __NEW_WORKFLOW__: — nothing else."
    )
    try:
        result = llm.invoke(prompt).content.strip()
        return result or "I'm here if you have more questions."
    except Exception as e:
        logger.warning("[FOLLOW_UP] LLM call failed: %s", e)
        return "I'm here if you have more questions."


def run_graph(compiled_graph, initial_input: dict, thread_id: str) -> dict:
    """Invoke a compiled graph and handle all interrupt/resume cycles.

    Returns the final state values when the graph reaches END.
    """
    run_cfg = {"configurable": {"thread_id": thread_id}}

    # First invocation
    compiled_graph.invoke(initial_input, run_cfg)

    while True:
        state = compiled_graph.get_state(run_cfg)
        if not state.next:
            return state.values

        # Handle interrupts (waiting for user input)
        for task in state.tasks:
            if hasattr(task, "interrupts") and task.interrupts:
                for intr in task.interrupts:
                    interrupt_data = intr.value
                    question = interrupt_data.get("question", "Your input:")
                    user_reply = input(f"Bot: {question}\nYou: ").strip()
                    if not user_reply:
                        continue
                    compiled_graph.invoke(Command(resume=user_reply), run_cfg)


def main() -> None:
    config = load_config()
    from flowgraph_ai.core.logging_setup import configure_logging

    configure_logging(config)
    llm = get_llm(config)
    checkpointer = get_checkpointer(config)
    loader = WorkflowLoader(
        fallback_workflow=config.get("intent", {}).get("fallback_workflow", "greeting")
    )
    builder = GraphBuilder(default_llm=llm, app_config=config)

    # Cache compiled graphs by workflow name (re-use across conversations)
    graph_cache: dict = {}

    provider = config["llm"]["provider"]
    model_key = f"{provider}_model"
    model_name = config["llm"].get(model_key, "default")
    app_name = config.get("app", {}).get("name", "FlowGraph-AI")

    print("=" * 55)
    print(f"  {app_name} (V3 — LangGraph powered)")
    print(f"  Provider : {provider}")
    print(f"  Model    : {model_name}")
    print("=" * 55)
    print("Type a message to chat. Type 'quit' or 'exit' to stop.\n")

    thread_id = None
    intent = None

    while True:
        try:
            user_text = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_text:
            continue
        if user_text.lower() in ("quit", "exit"):
            print("Goodbye!")
            break

        try:
            # ── 1. Classify intent if we don't have an active workflow ────────────────────────────────────────────
            if not thread_id:
                # new conversation
                intent = classify_intent(user_text, llm, config=config)
                print(f"  Intent: {intent}")
                thread_id = str(uuid.uuid4())
                workflow_name = intent
            else:
                workflow_name = intent

            # ── 2. Build (or retrieve cached) graph ───────────────────────────
            if workflow_name not in graph_cache:
                workflow_config = loader.load(workflow_name)
                graph_cache[workflow_name] = (
                    builder.build(workflow_config, checkpointer=checkpointer),
                    workflow_config,
                )
            compiled, wf_config = graph_cache[workflow_name]

            # ── 3. Seed initial state or Resume ─────────────────────────────────────────
            current_state = compiled.get_state({"configurable": {"thread_id": thread_id}})

            if not current_state.next and current_state.values:
                # Workflow was already finished. Handle as a follow-up question in context,
                # or start a new conversation if it's clearly a different topic.
                values = current_state.values
                completed_output = values.get("output") or values.get("error") or ""
                conversation_history = values.get("messages") or []

                follow_up_answer = _generate_follow_up(
                    llm, completed_output, conversation_history, user_text, workflow_name
                )

                # Check if the follow-up handler signals a new workflow is needed
                if follow_up_answer.startswith("__NEW_WORKFLOW__:"):
                    new_intent = follow_up_answer.split(":", 1)[1].strip()
                    intent = (
                        new_intent if new_intent else classify_intent(user_text, llm, config=config)
                    )
                    print(f"  [New Workflow] Intent: {intent}")
                    thread_id = str(uuid.uuid4())
                    workflow_name = intent

                    if workflow_name not in graph_cache:
                        workflow_config = loader.load(workflow_name)
                        graph_cache[workflow_name] = (
                            builder.build(workflow_config, checkpointer=checkpointer),
                            workflow_config,
                        )
                    compiled, wf_config = graph_cache[workflow_name]
                    initial_field = wf_config.get("initial_input_field", "user_message")
                    input_data = {"user_message": user_text, initial_field: user_text}
                else:
                    # Answer the follow-up in place — no new graph run needed
                    print(f"\nBot: {follow_up_answer}\n")
                    continue
            elif not current_state.values:
                # completely new thread
                initial_field = wf_config.get("initial_input_field", "user_message")
                input_data = {"user_message": user_text, initial_field: user_text}
            else:
                # Resuming existing
                input_data = Command(resume=user_text)

            # ── 5. Run graph (handles interrupts internally) ──────────────────
            final_state = run_graph(compiled, input_data, thread_id)

            # ── 6. Show result ────────────────────────────────────────────────
            if final_state.get("error"):
                print(f"\nBot: Error — {final_state['error']}\n")
            elif final_state.get("output"):
                print(f"\nBot: {final_state['output']}\n")
            else:
                print("\nBot: (conversation completed)\n")

        except Exception as e:
            logger.error("Error: %s", e, exc_info=True)
            print(f"\n  Error: {e}\n")


if __name__ == "__main__":
    main()
