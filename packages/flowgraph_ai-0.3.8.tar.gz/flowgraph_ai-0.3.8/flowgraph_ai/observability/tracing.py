"""
OpenTelemetry tracing for FlowGraph-AI → Jaeger.

Exports distributed traces via OTLP (gRPC on port 4327, HTTP fallback on 4328).

Every API request gets a root workflow span; nodes appear as nested child spans.
Correlation IDs link spans to task-tracker cards and Langfuse traces.

Span hierarchy:
  workflow.<name>                        ← root span per API request
    node.<name> (data_collector)         ← per node execution
      dc.pre_extract                     ← pre-extraction attempt
      dc.interrupt                       ← waiting for user input
      dc.extract                         ← LLM extraction call
      dc.validate                        ← field validation
      dc.hallucination_check             ← grounding check
      dc.retry                           ← retry attempt
      tool.<name>                        ← tool call
    node.<name> (custom_action)
    node.<name> (response)
    follow_up                            ← post-END follow-up

Setup:
  flowgraph stack up   (starts Jaeger container)
  Set observability.tracing.enabled: true in config.yaml
  Jaeger UI: http://localhost:16686

config.yaml:
  observability:
    tracing:
      enabled: true
      endpoint: http://localhost:4327    # Jaeger OTLP gRPC
      service_name: flowgraph-ai

Environment variable overrides:
  OTEL_EXPORTER_OTLP_ENDPOINT

Correlation IDs:
  All spans include:
    - correlation_id: ties span to task-tracker card
    - session_id: LangGraph thread_id
    - workflow.name
  Follow the correlation_id from the API response → task board → Jaeger → Langfuse.
"""

import logging
import os
import uuid
from collections.abc import Generator
from contextlib import contextmanager

logger = logging.getLogger(__name__)

_tracer = None
_initialized = False


def setup_tracing(config: dict) -> None:
    """Initialize the OpenTelemetry tracer provider.

    Must be called once at application startup (in FastAPI lifespan or CLI start).
    """
    global _tracer, _initialized
    if _initialized:
        return

    tracing_cfg = config.get("observability", {}).get("tracing", {})
    if not tracing_cfg.get("enabled", False):
        _initialized = True
        logger.debug("OTel tracing disabled.")
        return

    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT") or tracing_cfg.get(
        "endpoint", "http://localhost:4327"
    )
    service_name = tracing_cfg.get("service_name", "flowgraph-ai")

    # Silence ALL OTel export-related loggers at CRITICAL level so they never
    # flood the console when Jaeger or Langfuse is not running.  Covers:
    #  • Our Jaeger OTLP exporter (grpc / http)
    #  • Langfuse SDK's own internal OTel exporter → Langfuse server
    import logging as _logging

    for _noisy in (
        "opentelemetry.exporter.otlp.proto.grpc.exporter",
        "opentelemetry.exporter.otlp.proto.http.trace_exporter",
        "opentelemetry.exporter.otlp.proto.http._log_exporter",
        "opentelemetry.sdk.trace.export",
        "opentelemetry",
    ):
        _logging.getLogger(_noisy).setLevel(_logging.CRITICAL)

    try:
        # ── Pre-flight: is the OTLP endpoint reachable? ───────────────────────
        import socket as _socket
        from urllib.parse import urlparse as _urlparse

        from opentelemetry import trace
        from opentelemetry.sdk.resources import SERVICE_NAME, Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        _parsed = _urlparse(endpoint)
        _host = _parsed.hostname or "localhost"
        _port = _parsed.port or 4327
        _reachable = False
        try:
            with _socket.create_connection((_host, _port), timeout=1):
                _reachable = True
        except OSError:
            pass

        if not _reachable:
            logger.warning(
                "[OTel] Jaeger not reachable at %s — tracing skipped until stack is up.\n"
                "  Fix: colima start && flowgraph stack up",
                endpoint,
            )
            _initialized = True
            return

        resource = Resource.create({SERVICE_NAME: service_name})
        provider = TracerProvider(resource=resource)

        # Try gRPC exporter first (native Jaeger OTLP port)
        try:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

            exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)
            logger.info("OTel tracing → Jaeger gRPC  %s", endpoint)
        except ImportError:
            logger.warning(
                "[OTel] grpc exporter not found, falling back to HTTP.\n"
                "  Fix: uv add opentelemetry-exporter-otlp-proto-grpc"
            )
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

            http_endpoint = endpoint.replace(":4327", ":4328")
            exporter = OTLPSpanExporter(endpoint=f"{http_endpoint}/v1/traces")
            logger.info("OTel tracing → Jaeger HTTP  %s/v1/traces", http_endpoint)

        processor = BatchSpanProcessor(
            exporter,
            max_export_batch_size=512,
            export_timeout_millis=5_000,
            schedule_delay_millis=5_000,
        )
        provider.add_span_processor(processor)
        trace.set_tracer_provider(provider)
        _tracer = trace.get_tracer(service_name)
        logger.info(
            "OpenTelemetry tracing initialized  service=%s  endpoint=%s",
            service_name,
            endpoint,
        )

    except ImportError as e:
        logger.error(
            "[OTel] Required packages not installed: %s\n"
            "  Fix: uv add opentelemetry-sdk opentelemetry-exporter-otlp-proto-grpc",
            e,
        )
    except Exception as e:
        logger.warning("[OTel] Unexpected error during tracing setup: %s", e)

    _initialized = True


def get_tracer():
    """Return the active tracer, or None if tracing is disabled/unavailable."""
    return _tracer


def reset() -> None:
    """Reset tracer state (used in tests)."""
    global _tracer, _initialized
    _tracer = None
    _initialized = False


def new_correlation_id() -> str:
    """Generate a new correlation ID for linking spans, tasks, and Langfuse traces."""
    return uuid.uuid4().hex


def get_current_trace_id() -> str | None:
    """Return the hex trace ID of the current span, or None if not tracing."""
    try:
        from opentelemetry import trace as otel_trace

        span = otel_trace.get_current_span()
        ctx = span.get_span_context()
        if ctx and ctx.is_valid:
            return format(ctx.trace_id, "032x")
    except Exception:
        pass
    return None


@contextmanager
def workflow_span(
    workflow_name: str,
    session_id: str = "",
    correlation_id: str = "",
    **attributes: str,
) -> Generator:
    """Context manager for a top-level workflow execution span.

    Usage:
        with workflow_span("order_tracking", session_id=thread_id, correlation_id=cid) as span:
            if span:
                span.set_attribute("user.message.length", str(len(message)))
            compiled.invoke(...)
    """
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"workflow.{workflow_name}",
        kind=SpanKind.SERVER,
    ) as span:
        span.set_attribute("workflow.name", workflow_name)
        span.set_attribute("session.id", session_id)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        for k, v in attributes.items():
            span.set_attribute(k.replace("_", "."), str(v))
        # user.id is set via **attributes (e.g. user_id="alice@example.com")
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def node_span(
    node_name: str,
    node_type: str,
    session_id: str = "",
    correlation_id: str = "",
    **attributes: str,
) -> Generator:
    """Context manager for a single node execution span (child of workflow span).

    Usage:
        with node_span("collect_order_info", "data_collector", session_id=sid) as span:
            ...
    """
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"node.{node_name}",
        kind=SpanKind.INTERNAL,
    ) as span:
        span.set_attribute("node.name", node_name)
        span.set_attribute("node.type", node_type)
        if session_id:
            span.set_attribute("session.id", session_id)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        for k, v in attributes.items():
            span.set_attribute(k.replace("_", "."), str(v))
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def tool_span(tool_name: str, node_name: str = "", correlation_id: str = "") -> Generator:
    """Context manager for a tool call span."""
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"tool.{tool_name}",
        kind=SpanKind.CLIENT,
    ) as span:
        span.set_attribute("tool.name", tool_name)
        if node_name:
            span.set_attribute("node.name", node_name)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def extraction_span(field: str, node_name: str = "", attempt: int = 1) -> Generator:
    """Context manager for a field extraction span inside a data_collector node."""
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"dc.extract.{field}",
        kind=SpanKind.INTERNAL,
    ) as span:
        span.set_attribute("dc.field", field)
        span.set_attribute("dc.attempt", str(attempt))
        if node_name:
            span.set_attribute("node.name", node_name)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def hallucination_span(field: str, node_name: str = "") -> Generator:
    """Context manager for a hallucination grounding check span."""
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"dc.hallucination_check.{field}",
        kind=SpanKind.INTERNAL,
    ) as span:
        span.set_attribute("dc.field", field)
        if node_name:
            span.set_attribute("node.name", node_name)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def follow_up_span(workflow_name: str, session_id: str = "", correlation_id: str = "") -> Generator:
    """Context manager for a post-END follow-up span."""
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"follow_up.{workflow_name}",
        kind=SpanKind.INTERNAL,
    ) as span:
        span.set_attribute("workflow.name", workflow_name)
        span.set_attribute("span.type", "follow_up")
        if session_id:
            span.set_attribute("session.id", session_id)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def api_call_span(
    method: str,
    url: str,
    node_name: str = "",
    correlation_id: str = "",
) -> Generator:
    """Context manager for an external HTTP API call span inside a custom_action.

    Usage:
        with api_call_span("POST", "https://api.example.com/orders", node_name=node_name) as span:
            if span:
                span.set_attribute("request.body_size", str(len(body)))
            response = requests.post(url, ...)
            if span:
                span.set_attribute("http.response.status_code", str(response.status_code))
    """
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"http.{method.upper()}",
        kind=SpanKind.CLIENT,
    ) as span:
        span.set_attribute("http.method", method.upper())
        span.set_attribute("http.url", url)
        if node_name:
            span.set_attribute("node.name", node_name)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


@contextmanager
def custom_action_span(
    node_name: str,
    method_path: str,
    session_id: str = "",
    correlation_id: str = "",
) -> Generator:
    """Context manager for a custom_action node execution span.

    Captures method_path, result, routing decision and error in Jaeger.
    """
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    from opentelemetry.trace import SpanKind, Status, StatusCode

    with tracer.start_as_current_span(
        f"custom_action.{node_name}",
        kind=SpanKind.INTERNAL,
    ) as span:
        span.set_attribute("node.name", node_name)
        span.set_attribute("node.type", "custom_action")
        span.set_attribute("action.method", method_path)
        if session_id:
            span.set_attribute("session.id", session_id)
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)
        try:
            yield span
        except Exception as exc:
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            span.record_exception(exc)
            raise


def is_enabled(config: dict) -> bool:
    """Return True if OTel tracing is enabled in config."""
    return config.get("observability", {}).get("tracing", {}).get("enabled", False)
