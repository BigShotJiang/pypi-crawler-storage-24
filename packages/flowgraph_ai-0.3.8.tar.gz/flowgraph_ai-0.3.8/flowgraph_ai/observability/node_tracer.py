"""
Node-level Langfuse tracing for FlowGraph-AI.

Wraps each LangGraph node function with a Langfuse span that captures:
- Node input state (relevant fields)
- Node output state delta (what changed)
- Execution timing (wall-clock ms)
- LLM call results (via the callback handler already on the LLM)
- Routing decision (next node)
- Field extraction details (for data_collector nodes)

Uses langfuse.decorators.observe so spans are properly nested under the
parent workflow trace established by propagate_attributes().

Usage (in graph_builder.py):
    from flowgraph_ai.observability.node_tracer import wrap_node
    fn = wrap_node(fn, node_name=name, node_type=node_type, workflow=wf_name)
"""

import functools
import logging
import time
from collections.abc import Callable

logger = logging.getLogger("flowgraph.observability.node_tracer")

# Fields that are too noisy or large to include in traces
_SKIP_FIELDS = {"messages"}

# Fields that hold sensitive data — truncated in traces
_TRUNCATE_FIELDS = {"user_message", "output", "error"}
_TRUNCATE_LEN = 500


def _sanitize_state(state: dict) -> dict:
    """Produce a clean snapshot of state suitable for Langfuse."""
    result = {}
    for k, v in state.items():
        if k in _SKIP_FIELDS:
            continue
        if k.startswith("_"):
            # Internal control fields — still useful, keep them
            result[k] = v
            continue
        if isinstance(v, str) and k in _TRUNCATE_FIELDS:
            result[k] = v[:_TRUNCATE_LEN] + ("…" if len(v) > _TRUNCATE_LEN else "")
        elif isinstance(v, list):
            result[k] = f"[{len(v)} items]"
        else:
            result[k] = v
    return result


def _state_delta(before: dict, after: dict) -> dict:
    """Return only the fields that changed between before and after."""
    delta = {}
    all_keys = set(before) | set(after)
    for k in all_keys:
        v_before = before.get(k)
        v_after = after.get(k)
        if v_before != v_after:
            delta[k] = {"before": v_before, "after": v_after}
    return delta


def wrap_node(
    fn: Callable,
    node_name: str,
    node_type: str,
    workflow: str,
) -> Callable:
    """
    Wrap a LangGraph node function with Langfuse tracing.

    Each call to the wrapped node creates a Langfuse span showing:
    - Input state snapshot
    - Output state delta (what changed)
    - Execution timing (wall-clock ms)
    - Routing info (_dc_next_node, _dc_failed)
    - Field extraction metrics (for data_collector nodes)
    - Node type classification tags

    Falls back to calling fn() unmodified if Langfuse is unavailable.
    """
    try:
        from langfuse.decorators import langfuse_context, observe
    except ImportError:
        # Langfuse not available — return node unchanged
        return fn

    # custom_action nodes are self-instrumented with their own @observe + Jaeger span
    if node_type == "custom_action":
        return fn

    @observe(name=f"{workflow}/{node_name}", as_type="span")
    @functools.wraps(fn)
    def traced_fn(state: dict) -> dict:
        t0 = time.perf_counter()
        input_snapshot = _sanitize_state(state)

        # Count populated vs empty fields for data quality metrics
        populated_fields = sum(
            1
            for k, v in input_snapshot.items()
            if v is not None and v != "" and not k.startswith("_")
        )

        # Annotate the span with node metadata and input
        try:
            langfuse_context.update_current_observation(
                name=node_name,
                input=input_snapshot,
                metadata={
                    "node_type": node_type,
                    "workflow": workflow,
                    "node": node_name,
                    "populated_fields": populated_fields,
                    "user_language": state.get("user_language", "unknown"),
                },
            )
        except Exception:
            pass

        logger.debug(
            "[NODE_ENTER] workflow=%s  node=%s  type=%s  populated_fields=%d",
            workflow,
            node_name,
            node_type,
            populated_fields,
        )

        # Run the actual node
        output = fn(state)

        elapsed_ms = (time.perf_counter() - t0) * 1000

        # Compute what changed
        if isinstance(output, dict):
            delta = _state_delta(input_snapshot, _sanitize_state(output))
            # Determine routing decision
            routing_info = {}
            if "_dc_next_node" in output:
                routing_info["next_node"] = output["_dc_next_node"]
            if "_dc_failed" in output:
                routing_info["failed"] = output["_dc_failed"]
            if "_dc_node" in output:
                routing_info["failed_at"] = output["_dc_node"]

            summary_output = {
                "state_delta": delta,
                "routing": routing_info or "→ END",
            }
            if "output" in output and output.get("output"):
                summary_output["output_preview"] = str(output["output"])[:_TRUNCATE_LEN]
            if "error" in output and output.get("error"):
                summary_output["error"] = str(output["error"])[:_TRUNCATE_LEN]

            # Collect extracted field values for data_collector nodes
            extracted_fields = {}
            if node_type == "data_collector":
                for k, v in output.items():
                    if not k.startswith("_") and k not in ("messages", "output", "error"):
                        extracted_fields[k] = str(v)[:200] if v else None

            try:
                langfuse_context.update_current_observation(
                    output=summary_output,
                    metadata={
                        "node_type": node_type,
                        "workflow": workflow,
                        "node": node_name,
                        "routing": routing_info or "END",
                        "fields_changed": list(delta.keys()),
                        "elapsed_ms": round(elapsed_ms),
                        "extracted_fields": extracted_fields or None,
                        "is_failed": bool(output.get("_dc_failed")),
                    },
                    level="WARNING" if output.get("_dc_failed") else "DEFAULT",
                )
            except Exception:
                pass

            logger.info(
                "[NODE_EXIT] workflow=%s  node=%s  type=%s  elapsed=%.0fms  "
                "fields_changed=%d  routing=%s",
                workflow,
                node_name,
                node_type,
                elapsed_ms,
                len(delta),
                routing_info.get("next_node", "END"),
            )
        else:
            try:
                langfuse_context.update_current_observation(
                    output=str(output),
                    metadata={"elapsed_ms": round(elapsed_ms)},
                )
            except Exception:
                pass
            logger.info(
                "[NODE_EXIT] workflow=%s  node=%s  type=%s  elapsed=%.0fms  output_type=%s",
                workflow,
                node_name,
                node_type,
                elapsed_ms,
                type(output).__name__,
            )

        return output

    return traced_fn
