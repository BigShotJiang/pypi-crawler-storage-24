"""Task tracker — in-memory store with optional SQLite persistence."""

from __future__ import annotations

import logging
import sqlite3
import threading
from collections.abc import Callable

from flowgraph_ai.tracking.models import Task, TaskEvent, TaskStatus

logger = logging.getLogger("flowgraph.tracking")

_SUBSCRIBERS: list[Callable[[Task], None]] = []
_LOCK = threading.Lock()
_TASKS: dict[str, Task] = {}
_DB_PATH: str | None = None
_DB_CONN: sqlite3.Connection | None = None


def setup_tracker(db_path: str | None = None) -> None:
    """Initialize the task tracker. Call once at app startup."""
    global _DB_PATH, _DB_CONN
    _DB_PATH = db_path
    if db_path and db_path != ":memory:":
        _DB_CONN = sqlite3.connect(db_path, check_same_thread=False)
        _DB_CONN.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY,
                session_id TEXT,
                workflow_name TEXT,
                correlation_id TEXT,
                data TEXT,
                updated_at TEXT
            )
        """)
        _DB_CONN.execute("CREATE INDEX IF NOT EXISTS idx_session ON tasks(session_id)")
        _DB_CONN.commit()
        logger.info("[TRACKER] SQLite store initialized at %s", db_path)
    elif db_path == ":memory:":
        _DB_CONN = sqlite3.connect(":memory:", check_same_thread=False)
        _DB_CONN.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY,
                session_id TEXT,
                workflow_name TEXT,
                correlation_id TEXT,
                data TEXT,
                updated_at TEXT
            )
        """)
        _DB_CONN.execute("CREATE INDEX IF NOT EXISTS idx_session ON tasks(session_id)")
        _DB_CONN.commit()
        logger.info("[TRACKER] In-memory SQLite store initialized")
    else:
        logger.info("[TRACKER] In-memory store only (no persistence)")


def subscribe(callback: Callable[[Task], None]) -> None:
    """Register a callback to be called on every task update."""
    _SUBSCRIBERS.append(callback)


def unsubscribe(callback: Callable[[Task], None]) -> None:
    """Unregister a previously registered callback."""
    if callback in _SUBSCRIBERS:
        _SUBSCRIBERS.remove(callback)


def create_task(
    session_id: str,
    workflow_name: str,
    user_request: str,
    correlation_id: str | None = None,
    trace_id: str | None = None,
) -> Task:
    """Create and store a new task. Returns the Task."""
    title = user_request[:80] + "..." if len(user_request) > 80 else user_request
    task = Task(
        session_id=session_id,
        workflow_name=workflow_name,
        user_request=user_request,
        title=title,
        trace_id=trace_id,
    )
    if correlation_id:
        task.correlation_id = correlation_id
    task.add_event("task_created", f"Task created for workflow '{workflow_name}'")

    with _LOCK:
        _TASKS[task.task_id] = task
        _persist(task)

    _notify(task)
    logger.info(
        "[TRACKER] Task created: %s  session=%s  workflow=%s",
        task.task_id,
        session_id,
        workflow_name,
    )
    return task


def get_task(task_id: str) -> Task | None:
    """Get a task by ID."""
    return _TASKS.get(task_id)


def get_task_by_session(session_id: str) -> Task | None:
    """Get the most recent task for a session."""
    with _LOCK:
        matching = [t for t in _TASKS.values() if t.session_id == session_id]
    if not matching:
        return None
    return max(matching, key=lambda t: t.created_at)


def update_task_status(
    task_id: str,
    status: TaskStatus,
    node: str | None = None,
    node_type: str | None = None,
    description: str | None = None,
    metadata: dict | None = None,
) -> Task | None:
    """Update task status and add a timeline event."""
    task = _TASKS.get(task_id)
    if not task:
        logger.warning("[TRACKER] update_task_status: task not found: %s", task_id)
        return None

    task.update_status(status, node=node, node_type=node_type)
    if description:
        task.add_event("status_change", description, metadata=metadata)

    with _LOCK:
        _persist(task)

    _notify(task)
    logger.info("[TRACKER] Task %s → %s  node=%s", task_id, status.value, node)
    return task


def add_task_event(
    task_id: str, event_type: str, description: str, metadata: dict | None = None
) -> TaskEvent | None:
    """Add an event to a task's timeline."""
    task = _TASKS.get(task_id)
    if not task:
        return None
    event = task.add_event(event_type, description, metadata=metadata)
    with _LOCK:
        _persist(task)
    _notify(task)
    return event


def record_tool_call(task_id: str, tool_name: str) -> None:
    """Record a tool call on a task."""
    task = _TASKS.get(task_id)
    if not task:
        return
    if tool_name not in task.tool_calls:
        task.tool_calls.append(tool_name)
    task.add_event("tool_call", f"Tool called: {tool_name}", {"tool": tool_name})
    with _LOCK:
        _persist(task)
    _notify(task)


def record_retry(task_id: str, reason: str) -> None:
    """Record a retry attempt on a task."""
    task = _TASKS.get(task_id)
    if not task:
        return
    task.retry_count += 1
    task.update_status(TaskStatus.RETRY_RECOVERY)
    task.add_event(
        "retry",
        f"Retry #{task.retry_count}: {reason}",
        {"reason": reason, "count": task.retry_count},
    )
    with _LOCK:
        _persist(task)
    _notify(task)


def complete_task(task_id: str, result_summary: str | None = None) -> Task | None:
    """Mark a task as completed."""
    task = _TASKS.get(task_id)
    if not task:
        return None
    task.result_summary = result_summary
    task.update_status(TaskStatus.COMPLETED)
    task.add_event(
        "task_completed", "Task completed successfully", {"result": result_summary or ""}
    )
    with _LOCK:
        _persist(task)
    _notify(task)
    return task


def fail_task(task_id: str, error_message: str) -> Task | None:
    """Mark a task as failed."""
    task = _TASKS.get(task_id)
    if not task:
        return None
    task.error_message = error_message
    task.update_status(TaskStatus.FAILED)
    task.add_event("task_failed", f"Task failed: {error_message}", {"error": error_message})
    with _LOCK:
        _persist(task)
    _notify(task)
    return task


def list_tasks(
    limit: int = 100, workflow_name: str | None = None, status: TaskStatus | None = None
) -> list[Task]:
    """List tasks, most recent first."""
    with _LOCK:
        tasks = list(_TASKS.values())
    if workflow_name:
        tasks = [t for t in tasks if t.workflow_name == workflow_name]
    if status:
        tasks = [t for t in tasks if t.status == status]
    tasks.sort(key=lambda t: t.created_at, reverse=True)
    return tasks[:limit]


def clear_tasks() -> None:
    """Clear all in-memory tasks (useful for testing)."""
    with _LOCK:
        _TASKS.clear()


def _persist(task: Task) -> None:
    """Persist task to SQLite if configured."""
    if _DB_CONN is None:
        return
    try:
        data = task.model_dump_json()
        _DB_CONN.execute(
            """INSERT OR REPLACE INTO tasks (task_id, session_id, workflow_name, correlation_id, data, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                task.task_id,
                task.session_id,
                task.workflow_name,
                task.correlation_id,
                data,
                task.updated_at.isoformat(),
            ),
        )
        _DB_CONN.commit()
    except Exception as e:
        logger.warning("[TRACKER] SQLite persist failed: %s", e)


def _notify(task: Task) -> None:
    """Notify all subscribers of a task update."""
    for callback in list(_SUBSCRIBERS):
        try:
            callback(task)
        except Exception as e:
            logger.warning("[TRACKER] Subscriber callback failed: %s", e)
