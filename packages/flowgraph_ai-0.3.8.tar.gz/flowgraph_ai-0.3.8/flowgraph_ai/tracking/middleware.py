"""Tracking middleware — integrates task tracker into framework events.

Usage:
  from flowgraph_ai.tracking.middleware import TaskContext

  with TaskContext(session_id, workflow_name, user_request) as ctx:
      ctx.node_enter("collect_order", "data_collector")
      # ... run node ...
      ctx.node_exit("collect_order", success=True)
"""

from __future__ import annotations

import logging

from flowgraph_ai.tracking import tracker
from flowgraph_ai.tracking.models import Task, TaskStatus

logger = logging.getLogger("flowgraph.tracking.middleware")


class TaskContext:
    """Context manager that manages a Task's lifecycle through a workflow."""

    def __init__(
        self,
        session_id: str,
        workflow_name: str,
        user_request: str,
        correlation_id: str | None = None,
        trace_id: str | None = None,
    ) -> None:
        self.session_id = session_id
        self.workflow_name = workflow_name
        self.user_request = user_request
        self.correlation_id = correlation_id
        self.trace_id = trace_id
        self.task: Task | None = None

    def __enter__(self) -> TaskContext:
        self.task = tracker.create_task(
            session_id=self.session_id,
            workflow_name=self.workflow_name,
            user_request=self.user_request,
            correlation_id=self.correlation_id,
            trace_id=self.trace_id,
        )
        tracker.update_task_status(
            self.task.task_id,
            TaskStatus.IN_PROGRESS,
            description=f"Workflow '{self.workflow_name}' started",
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if not self.task:
            return
        if exc_type is not None:
            tracker.fail_task(self.task.task_id, str(exc_val))
        # Don't auto-complete here — let the caller decide when done

    @property
    def task_id(self) -> str | None:
        return self.task.task_id if self.task else None

    def node_enter(self, node_name: str, node_type: str) -> None:
        """Called when a node begins execution."""
        if not self.task:
            return
        status = (
            TaskStatus.WAITING_INPUT if node_type == "data_collector" else TaskStatus.IN_PROGRESS
        )
        tracker.update_task_status(
            self.task.task_id,
            status,
            node=node_name,
            node_type=node_type,
            description=f"Entering node: {node_name} ({node_type})",
            metadata={"node": node_name, "node_type": node_type},
        )

    def node_exit(self, node_name: str, success: bool = True) -> None:
        """Called when a node finishes execution."""
        if not self.task:
            return
        desc = f"Node '{node_name}' {'completed' if success else 'failed'}"
        tracker.add_task_event(
            self.task.task_id, "node_exit", desc, {"node": node_name, "success": success}
        )

    def waiting_for_input(self, field: str, question: str) -> None:
        """Called when the bot is waiting for user input."""
        if not self.task:
            return
        tracker.update_task_status(
            self.task.task_id,
            TaskStatus.WAITING_INPUT,
            description=f"Waiting for input: {field}",
            metadata={"field": field, "question": question[:200]},
        )

    def tool_running(self, tool_name: str) -> None:
        """Called when a tool is being invoked."""
        if not self.task:
            return
        tracker.update_task_status(
            self.task.task_id,
            TaskStatus.TOOL_RUNNING,
            description=f"Running tool: {tool_name}",
        )
        tracker.record_tool_call(self.task.task_id, tool_name)

    def retry(self, reason: str) -> None:
        """Called on extraction retry or hallucination recovery."""
        if not self.task:
            return
        tracker.record_retry(self.task.task_id, reason)

    def complete(self, result_summary: str | None = None) -> None:
        """Called when the workflow completes successfully."""
        if not self.task:
            return
        tracker.complete_task(self.task.task_id, result_summary=result_summary)

    def fail(self, error: str) -> None:
        """Called when the workflow fails."""
        if not self.task:
            return
        tracker.fail_task(self.task.task_id, error)
