"""
Conversation History Helpers.

Every workflow has a ``messages`` list in state (auto-injected by the framework).
Each entry is a dict::

    {
        "role":      "assistant" | "user",
        "content":   str,
        "timestamp": ISO-8601 UTC string,
        "id":        8-char hex string (for deduplication),
    }

Conversation history can be injected into YAML prompts via ``{state.messages}``
which renders as a human-readable dialogue string.

Usage::

    from flowgraph_ai.core.history import make_message, format_history, history_updates

Public API
----------
- :func:`make_message`      — create a single message dict
- :func:`format_history`    — format history list as readable string for LLM context
- :func:`history_updates`   — build a LangGraph state-update dict that appends messages
"""

import logging
import uuid
from datetime import UTC, datetime

logger = logging.getLogger("flowgraph.core.history")


def make_message(role: str, content: str) -> dict:
    """Create a single message entry for the conversation history.

    Args:
        role:    ``"assistant"`` or ``"user"``.
        content: Message text.

    Returns:
        A dict suitable for appending to ``state["messages"]``.
    """
    msg = {
        "role": role,
        "content": content,
        "timestamp": datetime.now(UTC).isoformat(),
        "id": uuid.uuid4().hex[:8],
    }
    logger.debug("[HISTORY] make_message  role=%s  chars=%d  id=%s", role, len(content), msg["id"])
    return msg


def format_history(messages: list, max_turns: int = 10) -> str:
    """Format conversation history as a readable string for LLM injection.

    Args:
        messages:  List of message dicts from ``state["messages"]``.
        max_turns: Maximum number of recent turns to include (each turn = 2 messages).

    Returns:
        Formatted string like::

            User: hello
            Bot: Hi! How can I help?
            User: check my SR
    """
    if not messages:
        logger.debug("[HISTORY] format_history — empty history")
        return "(no conversation history)"

    recent = messages[-max_turns * 2 :]  # Each turn = 2 messages (user + assistant)
    lines = []
    for msg in recent:
        role_label = "User" if msg.get("role") == "user" else "Bot"
        lines.append(f"{role_label}: {msg.get('content', '')}")

    logger.debug(
        "[HISTORY] format_history  total_msgs=%d  shown=%d  max_turns=%d",
        len(messages),
        len(recent),
        max_turns,
    )
    return "\n".join(lines)


def history_updates(assistant_question: str, user_reply: str) -> dict:
    """Build a LangGraph state-update dict that appends assistant + user messages.

    Designed to be returned directly from a node function::

        return {**other_updates, **history_updates(question, reply)}

    Args:
        assistant_question: The question/message the bot asked (can be empty string).
        user_reply:         The user's response (can be empty string).

    Returns:
        ``{"messages": [...]}`` with 0–2 entries, or ``{}`` if both inputs are empty.
    """
    msgs = []
    if assistant_question:
        msgs.append(make_message("assistant", assistant_question))
    if user_reply:
        msgs.append(make_message("user", user_reply))

    if msgs:
        logger.debug("[HISTORY] history_updates  appending %d message(s)", len(msgs))
    return {"messages": msgs} if msgs else {}
