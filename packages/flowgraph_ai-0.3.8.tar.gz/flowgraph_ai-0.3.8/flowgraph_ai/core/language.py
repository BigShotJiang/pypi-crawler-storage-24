"""
Language Detection.

Detects the language of user input and stores it in state["user_language"].
All subsequent LLM prompts include a language instruction so the bot
always responds in the user's language.

Performance:
  - Redis-backed cache (with in-memory fallback) avoids repeated LLM calls.
  - Short / alphanumeric strings are assumed English without LLM.
"""

import logging
import time

logger = logging.getLogger("flowgraph.core.language")


def detect_language(text: str, llm, config: dict | None = None) -> str:
    """Detect the language of the text.

    Args:
        text: User input text.
        llm: LangChain LLM instance.
        config: Optional app config for Redis cache integration.

    Returns:
        Language name in English (e.g., "English", "Spanish", "Tamil").
    """
    if not text or not text.strip():
        logger.debug("[LANG_DETECT] empty_input → default=English")
        return "English"

    # If the text is extremely short or just alphanumeric/symbols, assume English
    stripped = text.strip()
    if len(stripped) < 5 or stripped.replace("-", "").replace("_", "").isalnum():
        logger.debug("[LANG_DETECT] short_or_alnum  len=%d → default=English", len(stripped))
        return "English"

    # Use first 100 chars for detection (speed + cost)
    sample = stripped[:100]

    # ── Check cache ───────────────────────────────────────────────────────────
    cached = _cache_get(sample, config)
    if cached:
        logger.debug("[LANG_DETECT] cache_hit  sample=%r → %s", sample[:30], cached)
        return cached

    t0 = time.perf_counter()
    try:
        prompt = (
            f"Detect the language of this text and respond with ONLY the language name in English.\n"
            f'Text: "{sample}"\n'
            f"Examples of valid responses: English, Spanish, French, Tamil, Hindi, Arabic, German, Portuguese, Chinese, Japanese\n"
            f"Respond with ONLY the language name, nothing else."
        )
        result = llm.invoke(prompt).content.strip()
        elapsed_ms = (time.perf_counter() - t0) * 1000

        # Sanitize — keep only the first word if LLM returns more
        language = result.split()[0] if result else "English"

        _cache_set(sample, language, config)
        logger.info(
            "[LANG_DETECT] detected=%s  elapsed=%.0fms  sample=%r",
            language,
            elapsed_ms,
            sample[:30],
        )
        return language
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.warning(
            "[LANG_DETECT_FAIL] error=%s  elapsed=%.0fms → default=English", e, elapsed_ms
        )
        return "English"


def language_instruction(language: str) -> str:
    """Return a language instruction string to append to LLM prompts."""
    if not language or language.lower() == "english":
        return ""
    return f"IMPORTANT: Always respond in {language}."


# ── Cache helpers (Redis-backed with graceful fallback) ───────────────────────

_FALLBACK_CACHE: dict[str, str] = {}  # in-memory fallback if no Redis/config
_FALLBACK_MAX = 500


def _cache_get(sample: str, config: dict | None) -> str | None:
    """Get cached language detection result."""
    if config:
        try:
            from flowgraph_ai.cache.cache import get_cache

            return get_cache(config).get("lang", sample)
        except Exception:
            pass
    # In-memory fallback
    return _FALLBACK_CACHE.get(sample)


def _cache_set(sample: str, language: str, config: dict | None) -> None:
    """Cache a language detection result."""
    if config:
        try:
            from flowgraph_ai.cache.cache import get_cache

            get_cache(config).set("lang", sample, language, ttl=7200)  # 2h TTL
            return
        except Exception:
            pass
    # In-memory fallback with eviction
    if len(_FALLBACK_CACHE) >= _FALLBACK_MAX:
        keys = list(_FALLBACK_CACHE.keys())[: _FALLBACK_MAX // 5]
        for k in keys:
            _FALLBACK_CACHE.pop(k, None)
    _FALLBACK_CACHE[sample] = language
