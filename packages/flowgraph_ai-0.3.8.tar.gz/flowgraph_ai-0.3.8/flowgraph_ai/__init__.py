"""
FlowGraph-AI — YAML-driven AI workflow engine powered by LangGraph.

Build conversational multi-step AI applications without boilerplate.

Quickstart
----------
Install::

    pip install flowgraph-ai

Run your first workflow::

    flowgraph init my_project
    cd my_project
    flowgraph serve

Public API
----------
- :func:`flowgraph_ai.config.load_config` — load config.yaml
- :class:`flowgraph_ai.engine.workflow_builder.workflow` — fluent Python builder
- :func:`flowgraph_ai.llm.provider.get_llm` — create LLM instance
- :func:`flowgraph_ai.engine.workflow_loader.WorkflowLoader` — load YAML workflows
- :func:`flowgraph_ai.storage.checkpointer.get_checkpointer` — persistence layer

See https://flowgraphai.sridharhomelab.in for full documentation.
"""

__version__ = "0.3.7"
__author__ = "Simpletools India"
__email__ = "support@simpletools.in"
__license__ = "MIT"

# Re-export the most commonly used public API symbols for ergonomic imports:
#   from flowgraph_ai import load_config, workflow, get_llm
from flowgraph_ai.config import load_config
from flowgraph_ai.engine.workflow_builder import workflow
from flowgraph_ai.llm.provider import get_llm

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "__license__",
    "load_config",
    "workflow",
    "get_llm",
]
