"""
Intent Classifier — V4.

Maps a user message to a workflow name by one of two methods:
1. **RAG** — vector similarity search against developer-supplied training
   examples (pgvector).  Fast, zero LLM cost, deterministic.
2. **LLM** — prompt-based classification reading workflow YAML descriptions.
   Works out of the box, no extra setup needed.

If RAG is enabled and returns a high-confidence match, the LLM is never called.
If RAG confidence is below threshold, falls back to LLM automatically.

Config (config.yaml):
  intent:
    fallback_workflow: "greeting"
    rag:
      enabled: false              # toggle via `flowgraph rag enable`
      confidence_threshold: 0.7   # 0.0–1.0
      top_k: 5
      fallback_to_llm: true       # fall back to LLM if RAG confidence low
"""

import logging
import time

from flowgraph_ai.engine.workflow_loader import WorkflowLoader

logger = logging.getLogger("flowgraph.intent")

try:
    from langfuse.decorators import langfuse_context as _lf_ctx
    from langfuse.decorators import observe

    _LANGFUSE_AVAILABLE = True
except ImportError:
    _LANGFUSE_AVAILABLE = False

    def observe(*a, **kw):
        return lambda fn: fn  # no-op decorator

    _lf_ctx = None


@observe(name="classify:intent", as_type="span")
def classify_intent(
    user_message: str,
    llm,
    config: dict | None = None,
    workflows_dir: str | None = None,
    loader: "WorkflowLoader | None" = None,
    callbacks: list | None = None,
) -> str:
    """Classify user message into a workflow name.

    Tries RAG first (if enabled), then falls back to LLM classification.

    Args:
        user_message: Raw user text.
        llm: LangChain LLM instance.
        config: Full app config (for fallback_workflow + rag settings).
        workflows_dir: Optional custom path to workflows directory.
        loader: Optional pre-built WorkflowLoader instance.
        callbacks: Optional LangChain callbacks (e.g. Langfuse handler).

    Returns:
        Workflow name matching a .yaml file in the workflows directory.
    """
    config = config or {}
    intent_cfg = config.get("intent", {})
    fallback = intent_cfg.get("fallback_workflow", "greeting")

    if loader is None:
        loader = WorkflowLoader(workflows_dir, fallback_workflow=fallback)
    available = loader.list_workflows()

    if not available:
        logger.warning("[CLASSIFY_FALLBACK] reason=no_workflows  using=%s", fallback)
        return fallback

    # ── Check cache first ─────────────────────────────────────────────────────
    cache_key = f"{user_message}::{','.join(sorted(available))}"
    cached_result = _cache_get("intent", cache_key, config)
    if cached_result and cached_result in available:
        logger.info(
            "[CLASSIFY_CACHED] result=%s  message=%r",
            cached_result,
            user_message[:50],
        )
        if _LANGFUSE_AVAILABLE and _lf_ctx:
            try:
                _lf_ctx.update_current_observation(
                    input={"user_message": user_message[:200]},
                    output={"classified_as": cached_result, "method": "cache"},
                    metadata={"cache_hit": True},
                )
            except Exception:
                pass
        return cached_result

    # ── Try RAG classification ────────────────────────────────────────────────
    rag_cfg = intent_cfg.get("rag", {})
    if rag_cfg.get("enabled", False):
        rag_result = _try_rag(user_message, config, available, rag_cfg)
        if rag_result is not None:
            _cache_set("intent", cache_key, rag_result, config)
            return rag_result

        # If RAG failed and fallback_to_llm is False, use fallback
        if not rag_cfg.get("fallback_to_llm", True):
            logger.info(
                "[CLASSIFY_RAG_ONLY] RAG below threshold, no LLM fallback  using=%s", fallback
            )
            return fallback

        logger.info("[CLASSIFY_RAG_FALLBACK] RAG below threshold, falling back to LLM")

    # ── LLM classification (original path) ────────────────────────────────────
    result = _classify_with_llm(user_message, llm, available, intent_cfg, fallback, callbacks)
    _cache_set("intent", cache_key, result, config)
    return result


def _try_rag(
    user_message: str,
    config: dict,
    available_workflows: list[str],
    rag_cfg: dict,
) -> str | None:
    """Attempt RAG classification. Returns workflow name or None."""
    try:
        from flowgraph_ai.intent_rag.rag_classifier import classify_with_rag

        intent, confidence, matches = classify_with_rag(user_message, config, available_workflows)
        if intent is not None:
            logger.info(
                "[CLASSIFY_RAG] result=%s  confidence=%.3f  matches=%d",
                intent,
                confidence,
                len(matches),
            )
            return intent
        return None
    except ImportError:
        logger.warning(
            "[CLASSIFY_RAG] RAG dependencies not installed.\n"
            "  Fix: uv add 'flowgraph-ai[rag]'  OR  uv add pgvector langchain-community"
        )
        return None
    except Exception as e:
        logger.warning("[CLASSIFY_RAG] error=%s — falling back to LLM", e)
        return None


def _classify_with_llm(
    user_message: str,
    llm,
    available: list[str],
    intent_cfg: dict,
    fallback: str,
    callbacks: list | None,
) -> str:
    """Original LLM-based classification."""
    loader = WorkflowLoader()

    # Read descriptions from each workflow's YAML
    descriptions = {}
    for name in available:
        meta = loader.load_metadata(name)
        descriptions[name] = meta.get("description", name.replace("_", " "))

    descriptions_text = "\n".join(
        f"- {name}: {desc}" for name, desc in sorted(descriptions.items())
    )

    custom_prompt = intent_cfg.get("custom_prompt")

    if custom_prompt:
        prompt = (
            f"{custom_prompt}\n\n"
            f'User message: "{user_message}"\n\n'
            f"Available workflows:\n{descriptions_text}\n\n"
        )
    else:
        prompt = (
            f"Classify the intent of this user message into the best matching workflow.\n\n"
            f'User message: "{user_message}"\n\n'
            f"Available workflows:\n{descriptions_text}\n\n"
            f"Rules:\n"
            f"1. Carefully analyze the user's core intent. For example, 'track my order' or 'where is my package' belongs to order tracking, not a general FAQ.\n"
            f"2. Choose the single best matching workflow name from the list above.\n"
            f"3. Respond with ONLY the workflow name (e.g., 'greeting'), nothing else.\n"
            f"4. ONLY use '{fallback}' if the user is asking about a general topic entirely uncovered by the other explicit workflows."
        )

    logger.debug(
        "[CLASSIFY_START] message=%r  workflows=%d  prompt_chars=%d",
        user_message[:60],
        len(available),
        len(prompt),
    )
    logger.debug("[CLASSIFY_PROMPT]\n%s", prompt)

    # Attach Langfuse callbacks so this LLM call is visible in traces
    traced_llm = llm.with_config(callbacks=callbacks) if callbacks else llm

    t0 = time.perf_counter()
    try:
        response = traced_llm.invoke(prompt).content.strip().lower().rstrip(".")
        elapsed_ms = (time.perf_counter() - t0) * 1000
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.error(
            "[CLASSIFY_FAIL] error=%s  elapsed=%.0fms  using=%s\n"
            "  Fix: Check LLM provider is running (flowgraph llm test).",
            e,
            elapsed_ms,
            fallback,
        )
        return fallback

    if response not in available:
        logger.warning(
            "[CLASSIFY_FALLBACK] llm_returned=%r  not_in_workflows=%s  using=%s  elapsed=%.0fms",
            response,
            available,
            fallback,
            elapsed_ms,
        )
        if _LANGFUSE_AVAILABLE and _lf_ctx:
            try:
                _lf_ctx.update_current_observation(
                    input={"user_message": user_message[:200], "available_workflows": available},
                    output={"classified_as": fallback, "llm_returned": response, "fallback": True},
                    metadata={
                        "elapsed_ms": round(elapsed_ms),
                        "fallback_reason": "llm_returned_unknown",
                        "method": "llm",
                    },
                )
            except Exception:
                pass
        return fallback

    logger.info(
        "[CLASSIFY_DONE] method=llm  result=%s  elapsed=%.0fms  message=%r",
        response,
        elapsed_ms,
        user_message[:50],
    )
    if _LANGFUSE_AVAILABLE and _lf_ctx:
        try:
            _lf_ctx.update_current_observation(
                input={"user_message": user_message[:200], "available_workflows": available},
                output={"classified_as": response, "fallback": False},
                metadata={
                    "elapsed_ms": round(elapsed_ms),
                    "workflows_count": len(available),
                    "method": "llm",
                },
            )
        except Exception:
            pass
    return response


# ── Cache helpers ─────────────────────────────────────────────────────────────


def _cache_get(namespace: str, key: str, config: dict) -> str | None:
    """Try to get a cached value, gracefully returning None on any error."""
    try:
        from flowgraph_ai.cache.cache import get_cache

        return get_cache(config).get(namespace, key)
    except Exception:
        return None


def _cache_set(namespace: str, key: str, value: str, config: dict) -> None:
    """Try to cache a value, silently failing on any error."""
    try:
        from flowgraph_ai.cache.cache import get_cache

        get_cache(config).set(namespace, key, value)
    except Exception:
        pass
