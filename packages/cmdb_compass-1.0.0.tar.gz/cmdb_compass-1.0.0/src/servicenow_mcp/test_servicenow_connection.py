"""
Test ServiceNow Connection Tool

Verify connectivity to the ServiceNow instance.
Audit-level tool for connection verification (free).
"""

import sys
from typing import Any, Dict

from servicenow_mcp.servicenow import ServiceNowClient


async def test_servicenow_connection(app_context: Any) -> str:
    """
    Test connection to ServiceNow instance.

    This tool verifies connectivity to the ServiceNow instance and returns
    information about the authenticated user.

    Args:
        app_context: The app context object containing the servicenow client

    Returns:
        Formatted string with connection status and user information
    """
    try:
        connection_info = await app_context.servicenow.test_connection()
        user_info = connection_info.get("user", {})

        result = "**ServiceNow Connection Status**\n\n"
        result += "**Status:** ✅ Connected\n"
        result += f"**Instance:** {app_context.servicenow.instance_url}\n"
        result += f"**User Name:** {user_info.get('name', 'Unknown')}\n"
        result += f"**User ID:** {user_info.get('user_name', 'Unknown')}\n"
        result += f"**Email:** {user_info.get('email', 'Unknown')}\n"

        return result

    except Exception as e:
        print(f"[ERROR] test_servicenow_connection failed: {e}", file=sys.stderr)
        return f"**ServiceNow Connection Status**\n\n**Status:** ❌ Failed\n**Error:** {str(e)}"
