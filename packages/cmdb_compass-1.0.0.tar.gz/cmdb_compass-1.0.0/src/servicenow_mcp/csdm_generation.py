"""
CSDM rule generation via Retrieval-Augmented Generation.

This module builds a lightweight LangGraph pipeline that retrieves guidance from
local CSDM reference notes and asks an LLM to emit compliance rules in the schema
used by the CMDB compliance tool.
"""

from __future__ import annotations

import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple, TypedDict

try:
    from dotenv import load_dotenv  # type: ignore[import]
except ImportError:  # pragma: no cover - optional dependency
    load_dotenv = None  # type: ignore[assignment]


class RuleGenerationError(RuntimeError):
    """Raised when the LLM output cannot be parsed into a rule."""


_CANONICAL_NAME_FIELDS: Dict[str, str] = {
    "cmdb_ci_business_process": "name",
    "cmdb_model": "model_id",
    "cmdb_group": "name",
}


def _import_rag_dependencies() -> Dict[str, Any]:
    """Import langchain/langgraph dependencies lazily to avoid hard failures at import time."""

    try:
        try:
            from langchain_text_splitters import RecursiveCharacterTextSplitter  # type: ignore[import]
        except ImportError:
            from langchain.text_splitter import RecursiveCharacterTextSplitter  # type: ignore[import]

        from langchain_community.vectorstores import FAISS

        try:
            from langchain_core.prompts import ChatPromptTemplate
        except ImportError:
            from langchain.prompts import ChatPromptTemplate  # type: ignore[import]

        from langchain_openai import ChatOpenAI, OpenAIEmbeddings
        from langgraph.graph import END, StateGraph
    except ImportError as exc:  # pragma: no cover - guarded import
        raise ImportError(
            "LangChain / LangGraph dependencies are required for dynamic CSDM rule generation. "
            "Install the project with the new dependencies (pip install .) or set "
            "CSDM_DYNAMIC_RULES=0 to disable dynamic generation."
        ) from exc

    return {
        "RecursiveCharacterTextSplitter": RecursiveCharacterTextSplitter,
        "FAISS": FAISS,
        "ChatPromptTemplate": ChatPromptTemplate,
        "ChatOpenAI": ChatOpenAI,
        "OpenAIEmbeddings": OpenAIEmbeddings,
        "StateGraph": StateGraph,
        "END": END,
    }


class RuleState(TypedDict, total=False):
    question: str
    context: str
    response: str
    variables: Mapping[str, str]
    domain: str
    table: str
    display_name: str


def _extract_json_blob(text: str) -> str:
    """Extract the first JSON object from a string."""
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not match:
        raise RuleGenerationError("LLM response did not contain JSON.")
    return match.group(0)


def _load_targets(path: Path) -> Dict[str, List[Dict[str, str]]]:
    """Load domain -> targets mapping."""
    if not path.exists():
        raise FileNotFoundError(f"CSDM targets file not found at {path}")
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
        if not isinstance(data, dict):
            raise ValueError("CSDM targets file must be a JSON object.")
    return {str(domain): list(entries) for domain, entries in data.items()}


def _normalize_rule_payload(
    payload: Dict[str, Any],
    *,
    variables: Mapping[str, str],
) -> Dict[str, Any]:
    """Coerce the LLM payload into the rule schema expected by the compliance tool."""

    normalized: Dict[str, Any] = dict(payload)

    def _coerce_str(value: Any) -> Optional[str]:
        if isinstance(value, str):
            stripped = value.strip()
            if stripped:
                return stripped
        return None

    # Normalise the primary identifiers
    table_aliases = (
        "table",
        "table_name",
        "target_table",
        "cmdb_table",
        "sys_class_name",
    )
    table_value = None
    for alias in table_aliases:
        table_value = _coerce_str(normalized.get(alias))
        if table_value:
            normalized["table"] = table_value
            break
    if not table_value:
        normalized["table"] = variables["table"]

    normalized["domain"] = _coerce_str(normalized.get("domain")) or variables["domain"]

    display_aliases = ("display_name", "name", "title")
    display_value = None
    for alias in display_aliases:
        display_value = _coerce_str(normalized.get(alias))
        if display_value:
            normalized["display_name"] = display_value
            break
    if not display_value:
        normalized["display_name"] = variables["display_name"]

    normalized["query"] = _coerce_str(normalized.get("query")) or ""
    name_field_candidate = _coerce_str(normalized.get("name_field"))
    canonical_name_field = _CANONICAL_NAME_FIELDS.get(variables["table"], "name")
    if not name_field_candidate or not re.fullmatch(r"[A-Za-z0-9_]+", name_field_candidate):
        normalized["name_field"] = canonical_name_field
    else:
        normalized["name_field"] = name_field_candidate

    try:
        limit_value = int(normalized.get("limit", 100))
        normalized["limit"] = max(limit_value, 1)
    except (TypeError, ValueError):
        normalized["limit"] = 100

    def _coerce_fields(value: Any) -> List[str]:
        if isinstance(value, str):
            parts = re.split(r"[,\n]+", value)
            return [part.strip() for part in parts if part and part.strip()]

        if isinstance(value, (list, tuple, set)):
            fields: List[str] = []
            for item in value:
                if isinstance(item, str):
                    entry = item.strip()
                    if entry:
                        fields.append(entry)
                elif isinstance(item, Mapping):
                    candidates = (
                        item.get("name"),
                        item.get("field"),
                        item.get("id"),
                    )
                    for candidate in candidates:
                        coerced = _coerce_str(candidate)
                        if coerced:
                            fields.append(coerced)
                            break
            return fields

        return []

    normalized["required_fields"] = _coerce_fields(normalized.get("required_fields", []))

    def _coerce_relationships(value: Any) -> List[Dict[str, Any]]:
        relationships: List[Dict[str, Any]] = []
        if isinstance(value, Mapping):
            value = [value]
        if isinstance(value, list):
            for item in value:
                if not isinstance(item, Mapping):
                    continue
                relationship: Dict[str, Any] = dict(item)
                relationship["name"] = _coerce_str(relationship.get("name")) or "Relationship"
                relationship["query_template"] = (
                    _coerce_str(relationship.get("query_template")) or ""
                )
                try:
                    relationship["min_count"] = max(int(relationship.get("min_count", 0)), 0)
                except (TypeError, ValueError):
                    relationship["min_count"] = 0
                relationship["description"] = _coerce_str(relationship.get("description")) or ""
                relationships.append(relationship)
        return relationships

    normalized["relationships"] = _coerce_relationships(normalized.get("relationships", []))

    return normalized


def _load_baseline_rules(path: Path) -> Dict[str, Dict[str, Any]]:
    """Load the curated CSDM rule notes to reinforce LLM output."""
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        return {}

    normalised: Dict[str, Dict[str, Any]] = {}
    for domain, tables in data.items():
        if not isinstance(tables, dict):
            continue
        normalised[str(domain)] = {}
        for table, rule in tables.items():
            if isinstance(rule, dict):
                normalised[str(domain)][str(table)] = rule
    return normalised


def _merge_with_baseline(
    rule: Dict[str, Any],
    *,
    baseline: Optional[Mapping[str, Any]],
    canonical_name_field: str,
) -> Dict[str, Any]:
    """Reinforce LLM output with curated baseline notes."""
    result = dict(rule)

    if not baseline:
        result["required_fields"] = sorted(dict.fromkeys(result.get("required_fields", [])))
        result["relationships"] = list(result.get("relationships", []))
        return result

    label = baseline.get("label")
    if isinstance(label, str) and label.strip():
        result["display_name"] = label.strip()

    # Merge required fields
    baseline_fields = baseline.get("fields")
    required_fields: Iterable[str] = result.get("required_fields", [])
    merged_fields: Dict[str, None] = {str(field): None for field in required_fields if isinstance(field, str)}

    if isinstance(baseline_fields, Mapping):
        for field_name in baseline_fields.keys():
            merged_fields[str(field_name)] = None

    # Clean sentinel/default placeholders
    cleaned_fields = [
        field for field in merged_fields.keys() if field and field.lower() not in {"", "tbd", "n/a"}
    ]
    result["required_fields"] = sorted(cleaned_fields)

    # Canonicalise name field
    current_name_field = str(result.get("name_field", "")).strip()
    if not re.fullmatch(r"[A-Za-z0-9_]+", current_name_field):
        result["name_field"] = canonical_name_field

    # Infuse relationship guidance
    relationships: List[Dict[str, Any]] = []
    existing_names: Dict[str, Dict[str, Any]] = {}
    for entry in result.get("relationships", []):
        if isinstance(entry, Mapping):
            clone = dict(entry)
            name = str(clone.get("name", "")).strip()
            if not name:
                name = str(clone.get("description", "")).strip() or "Relationship"
            clone["name"] = name
            clone["query_template"] = str(clone.get("query_template", "") or "").strip()
            try:
                clone["min_count"] = max(int(clone.get("min_count", 0)), 0)
            except (TypeError, ValueError):
                clone["min_count"] = 0
            clone["description"] = str(clone.get("description", "") or "").strip()
            relationships.append(clone)
            existing_names[name.lower()] = clone

    baseline_relationships = baseline.get("relationships")
    if isinstance(baseline_relationships, Mapping):
        for rel_key, rel_meta in baseline_relationships.items():
            if not isinstance(rel_meta, Mapping):
                continue
            rel_name = str(rel_meta.get("direction") or rel_meta.get("name") or rel_key).strip()
            if not rel_name:
                rel_name = str(rel_key).replace("_", " ").title()
            if rel_name.lower() in existing_names:
                continue
            relationships.append(
                {
                    "name": rel_name,
                    "query_template": "",
                    "min_count": 0,
                    "description": str(rel_meta.get("description", "") or "").strip(),
                }
            )
    result["relationships"] = relationships
    return result


@dataclass
class GenerationConfig:
    """Configuration for the rule generator."""

    knowledge_path: Path
    targets_path: Path
    cache_path: Path
    baseline_rules_path: Path
    model: str = os.environ.get("CSDM_RULE_MODEL", "gpt-4o-mini")
    embedding_model: str = os.environ.get("CSDM_EMBED_MODEL", "text-embedding-3-small")
    k: int = int(os.environ.get("CSDM_RETRIEVAL_K", "4"))


class CSDMRuleGenerator:
    """Generate CSDM rule definitions using a RAG pipeline."""

    def __init__(self, config: GenerationConfig | None = None) -> None:
        deps = _import_rag_dependencies()
        self._text_splitter = deps["RecursiveCharacterTextSplitter"]
        self._vector_store_cls = deps["FAISS"]
        self._chat_prompt_cls = deps["ChatPromptTemplate"]
        self._chat_model_cls = deps["ChatOpenAI"]
        self._embedding_cls = deps["OpenAIEmbeddings"]
        self._state_graph_cls = deps["StateGraph"]
        self._graph_end = deps["END"]

        base_path = Path(__file__).resolve().parent.parent.parent

        if load_dotenv:
            # Ensure .env values are available when running standalone scripts.
            env_loaded = load_dotenv(dotenv_path=base_path / ".env", override=False)
            if env_loaded:
                print(f"[CSDM] Loaded environment from {base_path / '.env'}", file=sys.stderr)
            else:
                print(f"[CSDM] No .env loaded from {base_path / '.env'}", file=sys.stderr)

        default_config = GenerationConfig(
            knowledge_path=base_path / "data" / "csdm" / "reference.md",
            targets_path=base_path / "data" / "csdm" / "targets.json",
            cache_path=base_path / ".cache" / "csdm_rules_cache.json",
            baseline_rules_path=base_path / "data" / "csdm_rules.json",
        )
        self.config = config or default_config

        if not os.getenv("OPENAI_API_KEY"):
            raise EnvironmentError(
                "OPENAI_API_KEY must be set to enable dynamic CSDM rule generation."
            )

        self._cache: Dict[str, Dict[str, Any]] = {}
        self._load_cache()
        self._targets = _load_targets(self.config.targets_path)
        self._baseline_rules = _load_baseline_rules(self.config.baseline_rules_path)

        self._llm = self._chat_model_cls(
            model=self.config.model,
            temperature=0.0,
        )
        embedder = self._embedding_cls(model=self.config.embedding_model)
        documents = self._load_documents(self.config.knowledge_path)
        self._vector_store = self._vector_store_cls.from_documents(documents, embedder)
        self._retriever = self._vector_store.as_retriever(search_kwargs={"k": self.config.k})

        self._prompt = self._chat_prompt_cls.from_template(
            """
You are a ServiceNow CMDB compliance architect. Use the provided context to create
a rule definition for table "{table}" in the "{domain}" domain of CSDM 5.0.

Respond with JSON matching this schema:
{{
  "domain": "{domain}",
  "display_name": "{display_name}",
  "table": "{table}",
  "query": "encoded_query_or_empty_string",
  "name_field": "primary display field",
  "limit": 100,
  "required_fields": ["field_one", "field_two"],
  "relationships": [
    {{
      "name": "Relationship label",
      "query_template": "cmdb_rel_ci encoded query using {{sys_id}} placeholder",
      "min_count": 1,
      "description": "Why this relationship matters"
    }}
  ]
}}

Rules:
- Use the context to identify required attributes and relationships.
- If the context does not specify an encoded query, return an empty string.
- If relationship information is unclear, set "query_template" to "" and "min_count" to 0.
- Make sure "required_fields" is a flat list of field names only.
- Make sure "relationships" is a list (possibly empty) with the described structure.
- The JSON MUST include the "table" property with the exact value "{table}".
- Only reference field names and relationships that are explicitly present in the context; do not invent placeholders.
- If you cannot identify a specific primary display field, set "name_field" to "name".
- Return ONLY the JSON object with no extra commentary.

Context:
{context}
"""
        )

        self._graph = self._build_graph()

    def _load_cache(self) -> None:
        cache_path = self.config.cache_path
        if cache_path.exists():
            try:
                with cache_path.open("r", encoding="utf-8") as handle:
                    data = json.load(handle)
                    if isinstance(data, dict):
                        self._cache = data
            except json.JSONDecodeError:
                # Corrupted cache; ignore and rebuild
                self._cache = {}
        else:
            cache_path.parent.mkdir(parents=True, exist_ok=True)

    def _save_cache(self) -> None:
        with self.config.cache_path.open("w", encoding="utf-8") as handle:
            json.dump(self._cache, handle, indent=2, sort_keys=True)

    def _load_documents(self, path: Path) -> List[Any]:
        if not path.exists():
            raise FileNotFoundError(f"CSDM reference file not found at {path}")
        content = path.read_text(encoding="utf-8")
        splitter = self._text_splitter(chunk_size=1200, chunk_overlap=200)
        return splitter.create_documents([content])

    def _build_graph(self):
        graph = self._state_graph_cls(RuleState)

        def retrieve(state: RuleState) -> RuleState:
            question = state["question"]
            try:
                docs = self._retriever.get_relevant_documents(question)  # older API
            except AttributeError:
                docs = self._retriever.invoke(question)  # newer runnable API
            state["context"] = "\n\n".join(doc.page_content for doc in docs)
            return state

        def synthesize(state: RuleState) -> RuleState:
            context = state.get("context", "")
            raw_variables = state.get("variables", {})
            variables: Dict[str, str] = {}
            if isinstance(raw_variables, Mapping):
                variables = {str(key): str(value) for key, value in raw_variables.items() if value is not None}

            table_value = variables.get("table") or state.get("table") or ""
            domain_value = variables.get("domain") or state.get("domain") or ""
            display_name_value = (
                variables.get("display_name")
                or state.get("display_name")
                or (str(table_value).replace("_", " ").title() if table_value else "")
            )

            messages = self._prompt.format_messages(
                context=context,
                domain=str(domain_value),
                table=str(table_value),
                display_name=str(display_name_value),
            )
            response = self._llm.invoke(messages)
            if hasattr(response, "content"):
                state["response"] = response.content  # type: ignore[index]
            else:
                state["response"] = str(response)
            return state

        graph.add_node("retrieve", retrieve)
        graph.add_node("synthesize", synthesize)
        graph.set_entry_point("retrieve")
        graph.add_edge("retrieve", "synthesize")
        graph.add_edge("synthesize", self._graph_end)
        return graph.compile()

    @property
    def domains(self) -> List[str]:
        return list(self._targets.keys())

    def tables_for_domain(self, domain: str) -> List[Dict[str, str]]:
        return self._targets.get(domain, [])

    def generate_rule(
        self,
        domain: str,
        table: str,
        display_name: Optional[str] = None,
        *,
        use_cache: bool = True,
    ) -> Dict[str, Any]:
        """Generate or retrieve a rule for the specified table."""
        cache_key = f"{domain}:{table}"
        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        variables = {
            "domain": domain,
            "table": table,
            "display_name": display_name or table.replace("_", " ").title(),
        }
        state: RuleState = {
            "question": (
                f"Summarise CSDM compliance requirements for table {table} in the {domain} domain. "
                "List mandatory fields and recommended relationships."
            ),
            "variables": variables,
            "domain": domain,
            "table": table,
            "display_name": variables["display_name"],
        }
        final_state = self._graph.invoke(state)
        raw_response = final_state.get("response", "")

        print(
            f"[CSDM RAW RESPONSE] domain={domain} table={table}\n{raw_response}\n",
            file=sys.stderr,
        )

        try:
            json_blob = _extract_json_blob(raw_response)
            parsed = json.loads(json_blob)
        except json.JSONDecodeError as exc:
            print(
                f"⚠️  LLM response parsing failed for {domain}:{table}. Raw response:\n{raw_response}",
                file=sys.stderr,
            )
            raise RuleGenerationError(f"Failed to parse LLM response for {table}") from exc

        if isinstance(parsed, list):
            if parsed:
                first = parsed[0]
                if isinstance(first, dict):
                    parsed = first
                else:
                    print(
                        f"⚠️  LLM response for {domain}:{table} returned a list without dict elements: {parsed}",
                        file=sys.stderr,
                    )
                    raise RuleGenerationError("List response missing dict entries.")
            else:
                print(
                    f"⚠️  LLM response for {domain}:{table} returned an empty list.",
                    file=sys.stderr,
                )
                raise RuleGenerationError("Empty list response.")
        elif not isinstance(parsed, dict):
            print(
                f"⚠️  LLM response for {domain}:{table} is not a JSON object: {parsed}",
                file=sys.stderr,
            )
            raise RuleGenerationError("Non-object JSON response.")

        normalized = _normalize_rule_payload(parsed, variables=variables)

        final_table = normalized.get("table")
        if not isinstance(final_table, str) or not final_table.strip():
            print(
                f"⚠️  Normalised rule is missing 'table' for {domain}:{table}. Raw JSON: {json_blob}",
                file=sys.stderr,
            )
            raise RuleGenerationError("Rule payload missing table definition.")

        canonical_name_field = _CANONICAL_NAME_FIELDS.get(table, normalized.get("name_field", "name"))
        baseline_rule = self._baseline_rules.get(domain, {}).get(table) if isinstance(self._baseline_rules, dict) else None
        enriched = _merge_with_baseline(
            normalized,
            baseline=baseline_rule,
            canonical_name_field=canonical_name_field,
        )

        self._cache[cache_key] = enriched
        self._save_cache()
        return enriched

    def generate_rules_for_domain(self, domain: str, *, use_cache: bool = True) -> List[Dict[str, Any]]:
        rules: List[Dict[str, Any]] = []
        for target in self.tables_for_domain(domain):
            table = target.get("table")
            if not table:
                continue
            rule = self.generate_rule(
                domain=domain,
                table=table,
                display_name=target.get("display_name"),
                use_cache=use_cache,
            )
            rules.append(rule)
        return rules

    def generate_rules(
        self,
        targets: Mapping[str, List[Mapping[str, str]]],
        *,
        use_cache: bool = True,
    ) -> Dict[str, Dict[str, Any]]:
        result: Dict[str, Dict[str, Any]] = {}
        for domain, entries in targets.items():
            for entry in entries:
                if not isinstance(entry, Mapping):
                    continue
                table = entry.get("table")
                if not table:
                    continue
                try:
                    rule = self.generate_rule(
                        domain=domain,
                        table=table,
                        display_name=entry.get("display_name"),
                        use_cache=use_cache,
                    )
                except Exception as exc:  # pragma: no cover - robustness for individual failures
                    print(
                        f"⚠️  Failed to generate CSDM rule for {domain}:{table}: {exc}",
                        file=sys.stderr,
                    )
                    continue
                result[f"{domain}:{table}"] = rule
        return result


__all__ = ["CSDMRuleGenerator", "GenerationConfig", "RuleGenerationError"]
