"""Executable entrypoint for `python -m servicenow_mcp`."""

import base64
import hashlib
import os
import secrets
import sys
import time
from urllib.parse import urlencode, parse_qs, urlparse

# Load environment variables from .env file BEFORE anything else
try:
    from dotenv import load_dotenv
    # Load .env from the project root directory
    load_dotenv(override=False)
except ImportError:
    pass

# Initialize Sentry early for error tracking
from .sentry_init import init_sentry

init_sentry()

# In-memory store for OAuth sessions (use Redis/KV in production)
OAUTH_SESSIONS: dict[str, dict] = {}
AUTH_CODES: dict[str, dict] = {}

# Licensing layer URL
LICENSING_URL = os.getenv("LICENSING_URL", "https://nexecute-licensing-production.nexecute.workers.dev")


def main() -> None:
    """Run the server with the configured transport (stdio or HTTP)."""
    transport = os.getenv("MCP_TRANSPORT", "stdio")

    if transport == "http":
        # HTTP transport for remote deployment (Fly.io, etc.)
        import uvicorn
        from starlette.requests import Request
        from starlette.responses import JSONResponse, RedirectResponse
        from .server import mcp

        port = int(os.getenv("PORT", 8000))
        base_url = os.getenv("BASE_URL", f"http://localhost:{port}")
        print(f"🌐 Starting ServiceNow MCP Server with HTTP transport on port {port}...", file=sys.stderr)

        app = mcp.streamable_http_app()

        async def health(_: Request) -> JSONResponse:
            """Health check endpoint for load balancer."""
            return JSONResponse({"status": "ok"})

        async def oauth_metadata(_: Request) -> JSONResponse:
            """OAuth 2.0 Authorization Server Metadata (RFC 8414)."""
            return JSONResponse({
                "issuer": base_url,
                "authorization_endpoint": f"{base_url}/authorize",
                "token_endpoint": f"{base_url}/token",
                "registration_endpoint": f"{base_url}/register",
                "response_types_supported": ["code"],
                "grant_types_supported": ["authorization_code"],
                "code_challenge_methods_supported": ["S256"],
                "token_endpoint_auth_methods_supported": ["none"],
            })

        async def oauth_protected_resource(_: Request) -> JSONResponse:
            """OAuth 2.0 Protected Resource Metadata (RFC 9728)."""
            return JSONResponse({
                "resource": base_url,
                "authorization_servers": [base_url],
                "bearer_methods_supported": ["header"],
            })

        async def register(request: Request) -> JSONResponse:
            """Dynamic Client Registration (RFC 7591)."""
            # Claude sends client metadata, we return a client_id
            # Since we use our own auth, just acknowledge and return a placeholder
            body = await request.json()
            client_id = secrets.token_urlsafe(16)
            
            return JSONResponse({
                "client_id": client_id,
                "client_id_issued_at": int(time.time()),
                "grant_types": ["authorization_code"],
                "response_types": ["code"],
                "redirect_uris": body.get("redirect_uris", []),
                "token_endpoint_auth_method": "none",
            }, status_code=201)

        async def authorize(request: Request) -> RedirectResponse:
            """
            OAuth 2.0 Authorization endpoint.
            Redirects to licensing layer's Google OAuth, then back to Claude.
            """
            params = dict(request.query_params)
            
            # Extract OAuth params from Claude Desktop
            client_id = params.get("client_id", "")
            redirect_uri = params.get("redirect_uri", "")
            code_challenge = params.get("code_challenge", "")
            code_challenge_method = params.get("code_challenge_method", "S256")
            state = params.get("state", "")
            scope = params.get("scope", "")
            
            # Generate session ID to track this OAuth flow
            session_id = secrets.token_urlsafe(32)
            
            # Store session data for callback
            OAUTH_SESSIONS[session_id] = {
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "code_challenge": code_challenge,
                "code_challenge_method": code_challenge_method,
                "state": state,
                "scope": scope,
                "created_at": time.time(),
            }
            
            # Redirect to licensing layer's Google OAuth
            # The licensing layer will redirect back to our /oauth/callback
            oauth_params = {
                "mcp_session": session_id,
                "mcp_callback": f"{base_url}/oauth/callback",
            }
            
            auth_url = f"{LICENSING_URL}/auth/google?{urlencode(oauth_params)}"
            print(f"🔐 OAuth authorize: redirecting to {auth_url}", file=sys.stderr)
            
            return RedirectResponse(url=auth_url, status_code=302)

        async def oauth_callback(request: Request) -> RedirectResponse:
            """
            OAuth callback from licensing layer.
            Receives JWT token, creates auth code, redirects to Claude.
            """
            params = dict(request.query_params)
            
            # Get the JWT token from licensing layer
            token = params.get("token", "")
            session_id = params.get("mcp_session", "")
            error = params.get("error", "")
            
            if error:
                print(f"❌ OAuth error: {error}", file=sys.stderr)
                return RedirectResponse(url=f"https://claude.ai/error?error={error}", status_code=302)
            
            # Retrieve session data
            session = OAUTH_SESSIONS.pop(session_id, None)
            if not session:
                print(f"❌ OAuth session not found: {session_id}", file=sys.stderr)
                return RedirectResponse(url="https://claude.ai/error?error=session_expired", status_code=302)
            
            # Generate authorization code
            auth_code = secrets.token_urlsafe(32)
            
            # Store auth code with token and PKCE data
            AUTH_CODES[auth_code] = {
                "token": token,
                "code_challenge": session["code_challenge"],
                "code_challenge_method": session["code_challenge_method"],
                "client_id": session["client_id"],
                "redirect_uri": session["redirect_uri"],
                "created_at": time.time(),
            }
            
            # Redirect to Claude's callback with auth code
            callback_params = {
                "code": auth_code,
                "state": session["state"],
            }
            
            callback_url = f"{session['redirect_uri']}?{urlencode(callback_params)}"
            print(f"✅ OAuth callback: redirecting to Claude with auth code", file=sys.stderr)
            
            return RedirectResponse(url=callback_url, status_code=302)

        async def token(request: Request) -> JSONResponse:
            """
            OAuth 2.0 Token endpoint.
            Exchanges authorization code for access token (JWT).
            """
            # Parse form data or JSON body
            content_type = request.headers.get("content-type", "")
            
            if "application/x-www-form-urlencoded" in content_type:
                form = await request.form()
                params = dict(form)
            elif "application/json" in content_type:
                params = await request.json()
            else:
                body = await request.body()
                params = dict(parse_qs(body.decode()))
                params = {k: v[0] if isinstance(v, list) else v for k, v in params.items()}
            
            grant_type = params.get("grant_type", "")
            code = params.get("code", "")
            code_verifier = params.get("code_verifier", "")
            client_id = params.get("client_id", "")
            redirect_uri = params.get("redirect_uri", "")
            
            # Retrieve and remove auth code data
            code_data = AUTH_CODES.pop(code, None)
            
            if not code_data:
                print(f"❌ Token exchange: invalid code", file=sys.stderr)
                return JSONResponse(
                    {"error": "invalid_grant", "error_description": "Invalid authorization code"},
                    status_code=400
                )
            
            # Check code expiration (5 minutes)
            if time.time() - code_data["created_at"] > 300:
                print(f"❌ Token exchange: code expired", file=sys.stderr)
                return JSONResponse(
                    {"error": "invalid_grant", "error_description": "Authorization code expired"},
                    status_code=400
                )
            
            # Verify PKCE code_verifier
            if code_data["code_challenge_method"] == "S256":
                # SHA256 hash of code_verifier, base64url encoded
                verifier_hash = hashlib.sha256(code_verifier.encode()).digest()
                computed_challenge = base64.urlsafe_b64encode(verifier_hash).rstrip(b"=").decode()
                
                if computed_challenge != code_data["code_challenge"]:
                    print(f"❌ Token exchange: PKCE verification failed", file=sys.stderr)
                    return JSONResponse(
                        {"error": "invalid_grant", "error_description": "PKCE verification failed"},
                        status_code=400
                    )
            
            # Return the JWT token from licensing layer
            print(f"✅ Token exchange: returning access token", file=sys.stderr)
            
            return JSONResponse({
                "access_token": code_data["token"],
                "token_type": "Bearer",
                "expires_in": 604800,  # 7 days
                "scope": "claudeai",
            })

        # Add routes
        app.add_route("/health", health, methods=["GET"])
        app.add_route("/.well-known/oauth-authorization-server", oauth_metadata, methods=["GET"])
        app.add_route("/.well-known/oauth-protected-resource", oauth_protected_resource, methods=["GET"])
        app.add_route("/register", register, methods=["POST"])
        app.add_route("/authorize", authorize, methods=["GET"])
        app.add_route("/oauth/callback", oauth_callback, methods=["GET"])
        app.add_route("/token", token, methods=["POST"])

        uvicorn.run(
            app,
            host="0.0.0.0",
            port=port,
            log_level="info",
        )
    else:
        # stdio transport for local Claude Desktop
        from .server import main as server_main

        server_main()


if __name__ == "__main__":
    main()
