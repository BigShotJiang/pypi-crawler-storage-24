"""
ServiceNow REST API Client

This module provides an async client for interacting with ServiceNow REST APIs.
"""

import os
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple
import httpx


class ServiceNowClient:
    """
    Async client for ServiceNow REST API interactions.

    Handles authentication, HTTP requests, and provides methods for common
    ServiceNow operations including CRUD operations on tables.
    """

    def __init__(
        self,
        instance_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        access_token: Optional[str] = None,
    ):
        """
        Initialize the ServiceNow client.

        Supports two authentication modes:
        - OAuth Bearer: provide access_token (or set SERVICENOW_ACCESS_TOKEN env var)
        - Basic Auth:   provide username + password (or set SERVICENOW_USERNAME /
                        SERVICENOW_PASSWORD env vars)

        OAuth takes precedence when both are supplied.

        Args:
            instance_url: ServiceNow instance URL (e.g., https://dev12345.service-now.com)
                         If not provided, reads from SERVICENOW_INSTANCE_URL env var
            username: ServiceNow username. If not provided, reads from SERVICENOW_USERNAME env var
            password: ServiceNow password. If not provided, reads from SERVICENOW_PASSWORD env var
            access_token: OAuth Bearer access token. If not provided, reads from
                         SERVICENOW_ACCESS_TOKEN env var

        Raises:
            ValueError: If required credentials are not provided
        """
        self.instance_url = (instance_url or os.getenv("SERVICENOW_INSTANCE_URL", "")).rstrip("/")
        resolved_access_token = access_token or os.getenv("SERVICENOW_ACCESS_TOKEN", "")

        if resolved_access_token:
            # OAuth Bearer auth — no username/password needed
            self.username = ""
            self.password = ""

            if not self.instance_url:
                raise ValueError(
                    "ServiceNow instance URL must be provided either as an argument or "
                    "via the SERVICENOW_INSTANCE_URL environment variable"
                )

            self.client = httpx.AsyncClient(
                headers={
                    "Authorization": f"Bearer {resolved_access_token}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                timeout=30.0,
            )
        else:
            # Basic Auth
            self.username = username or os.getenv("SERVICENOW_USERNAME", "")
            self.password = password or os.getenv("SERVICENOW_PASSWORD", "")

            if not all([self.instance_url, self.username, self.password]):
                raise ValueError(
                    "ServiceNow credentials must be provided either as arguments or "
                    "via environment variables: SERVICENOW_INSTANCE_URL, "
                    "SERVICENOW_USERNAME, SERVICENOW_PASSWORD"
                )

            self.client = httpx.AsyncClient(
                auth=(self.username, self.password),
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                timeout=30.0,
            )

        self.base_url = f"{self.instance_url}/api/now"

    async def close(self) -> None:
        """Close the HTTP client and clean up resources."""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def test_connection(self) -> Dict[str, Any]:
        """
        Test the connection to ServiceNow and return authenticated user info.

        Returns:
            Dict containing authenticated user information

        Raises:
            httpx.HTTPStatusError: If the connection fails
        """
        url = f"{self.base_url}/table/sys_user"
        # In OAuth mode self.username is empty; query the current user generically
        query = f"user_name={self.username}" if self.username else "active=true"
        params = {
            "sysparm_query": query,
            "sysparm_limit": 1,
            "sysparm_display_value": "true",
        }

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        # Check if we got HTML (hibernating instance) instead of JSON
        content_type = response.headers.get('content-type', '')
        if 'text/html' in content_type:
            raise ValueError(
                "ServiceNow Personal Developer Instance (PDI) is hibernating. "
                "Please wake it up by visiting the instance URL in your browser, "
                "or run: python3 wake_instance.py"
            )

        data = response.json()
        return {
            "success": True,
            "instance_url": self.instance_url,
            "user": data.get("result", [{}])[0] if data.get("result") else {},
        }

    async def get_table_records(
        self,
        table: str,
        sysparm_query: Optional[str] = None,
        sysparm_fields: Optional[str] = None,
        sysparm_limit: int = 10,
        sysparm_offset: int = 0,
        sysparm_display_value: str = "true",
        **additional_params,
    ) -> Dict[str, Any]:
        """
        Get records from a ServiceNow table.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            sysparm_query: Encoded query string for filtering (e.g., 'active=true^priority=1')
            sysparm_fields: Comma-separated list of fields to return
            sysparm_limit: Maximum number of records to return (default: 10)
            sysparm_offset: Starting record index for pagination (default: 0)
            sysparm_display_value: Return display values ('true', 'false', 'all')
            **additional_params: Additional query parameters

        Returns:
            Dict containing the API response with 'result' key containing records

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        url = f"{self.base_url}/table/{table}"

        params = {
            "sysparm_limit": sysparm_limit,
            "sysparm_offset": sysparm_offset,
            "sysparm_display_value": sysparm_display_value,
        }

        if sysparm_query:
            params["sysparm_query"] = sysparm_query
        if sysparm_fields:
            params["sysparm_fields"] = sysparm_fields

        # Add any additional parameters
        params.update(additional_params)

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        return response.json()

    async def count_records(
        self,
        table: str,
        sysparm_query: Optional[str] = None,
    ) -> Tuple[int, Dict[str, Any]]:
        """
        Return the record count for a table using sysparm_count semantics.

        Args:
            table: Table name to query.
            sysparm_query: Encoded query string for filtering.

        Returns:
            Tuple of (count, response_json). Response JSON is provided so callers can
            inspect the payload if needed for logging.
        """
        url = f"{self.base_url}/table/{table}"
        params = {
            "sysparm_count": "true",
            "sysparm_limit": 1,
            "sysparm_offset": 0,
            "sysparm_display_value": "false",
        }
        if sysparm_query:
            params["sysparm_query"] = sysparm_query

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        # sysparm_count returns X-Total-Count header when successful.
        header_value = response.headers.get("X-Total-Count")
        if header_value is not None:
            try:
                return int(header_value), response.json()
            except ValueError:
                pass

        # Fall back to parsing the payload if the header is unavailable.
        payload = response.json()
        fallback_count = payload.get("count") or payload.get("total")
        try:
            return int(fallback_count or 0), payload
        except (TypeError, ValueError):
            return 0, payload

    async def paginate(
        self,
        table: str,
        *,
        sysparm_query: Optional[str] = None,
        sysparm_fields: Optional[str] = None,
        page_size: int = 1000,
        sysparm_display_value: str = "true",
    ) -> AsyncIterator[List[Dict[str, Any]]]:
        """
        Paginate through records from a ServiceNow table.

        Yields pages of records instead of loading the full result set into
        memory.  Stops when a page returns fewer records than page_size
        (indicating end of dataset) or when the page is empty.

        Args:
            table: Table name (e.g., 'cmdb_rel_ci')
            sysparm_query: Encoded query string for filtering
            sysparm_fields: Comma-separated list of fields to return
            page_size: Records per page (default: 1000)
            sysparm_display_value: Return display values ('true', 'false', 'all')

        Yields:
            List of record dicts for each page
        """
        offset = 0
        while True:
            response = await self.get_table_records(
                table=table,
                sysparm_query=sysparm_query,
                sysparm_fields=sysparm_fields,
                sysparm_limit=page_size,
                sysparm_offset=offset,
                sysparm_display_value=sysparm_display_value,
            )
            records = response.get("result", [])
            if not records:
                break
            yield records
            if len(records) < page_size:
                break
            offset += page_size

    async def get_record_by_id(
        self,
        table: str,
        sys_id: str,
        sysparm_fields: Optional[str] = None,
        sysparm_display_value: str = "true",
    ) -> Dict[str, Any]:
        """
        Get a specific record by its sys_id.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            sys_id: The sys_id of the record
            sysparm_fields: Comma-separated list of fields to return
            sysparm_display_value: Return display values ('true', 'false', 'all')

        Returns:
            Dict containing the API response with 'result' key containing the record

        Raises:
            httpx.HTTPStatusError: If the API request fails or record not found
        """
        url = f"{self.base_url}/table/{table}/{sys_id}"

        params = {
            "sysparm_display_value": sysparm_display_value,
        }

        if sysparm_fields:
            params["sysparm_fields"] = sysparm_fields

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        return response.json()

    async def get_record_by_number(
        self,
        table: str,
        number: str,
        sysparm_fields: Optional[str] = None,
        sysparm_display_value: str = "true",
    ) -> Dict[str, Any]:
        """
        Get a record by its number field (e.g., INC0010001, CHG0030002).

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            number: The record number (e.g., 'INC0010001')
            sysparm_fields: Comma-separated list of fields to return
            sysparm_display_value: Return display values ('true', 'false', 'all')

        Returns:
            Dict containing the API response with 'result' key containing matching records

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        return await self.get_table_records(
            table=table,
            sysparm_query=f"number={number}",
            sysparm_fields=sysparm_fields,
            sysparm_limit=1,
            sysparm_display_value=sysparm_display_value,
        )

    async def create_record(
        self,
        table: str,
        data: Dict[str, Any],
        sysparm_display_value: str = "true",
        sysparm_fields: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new record in a ServiceNow table.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            data: Dictionary containing field names and values for the new record
            sysparm_display_value: Return display values ('true', 'false', 'all')
            sysparm_fields: Comma-separated list of fields to return

        Returns:
            Dict containing the API response with 'result' key containing the created record

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        url = f"{self.base_url}/table/{table}"

        params = {
            "sysparm_display_value": sysparm_display_value,
        }

        if sysparm_fields:
            params["sysparm_fields"] = sysparm_fields

        response = await self.client.post(url, json=data, params=params)
        response.raise_for_status()

        result = response.json()
        # Wrap response to include status for tool compatibility
        return {"status": "success", "result": result.get("result", result)}

    async def update_record(
        self,
        table: str,
        sys_id: str,
        data: Dict[str, Any],
        sysparm_display_value: str = "true",
        sysparm_fields: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing record in a ServiceNow table.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            sys_id: The sys_id of the record to update
            data: Dictionary containing field names and values to update
            sysparm_display_value: Return display values ('true', 'false', 'all')
            sysparm_fields: Comma-separated list of fields to return

        Returns:
            Dict containing the API response with 'result' key containing the updated record

        Raises:
            httpx.HTTPStatusError: If the API request fails or record not found
        """
        url = f"{self.base_url}/table/{table}/{sys_id}"

        params = {
            "sysparm_display_value": sysparm_display_value,
        }

        if sysparm_fields:
            params["sysparm_fields"] = sysparm_fields

        response = await self.client.patch(url, json=data, params=params)
        response.raise_for_status()

        result = response.json()
        # Wrap response to include status for tool compatibility
        return {"status": "success", "result": result.get("result", result)}

    async def delete_record(
        self,
        table: str,
        sys_id: str,
    ) -> None:
        """
        Delete a record from a ServiceNow table.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            sys_id: The sys_id of the record to delete

        Raises:
            httpx.HTTPStatusError: If the API request fails or record not found
        """
        url = f"{self.base_url}/table/{table}/{sys_id}"

        response = await self.client.delete(url)
        response.raise_for_status()

    async def query_table(
        self,
        table: str,
        query: str = "",
        limit: int = 10,
        fields: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query a ServiceNow table and return list of records.

        This is a convenience wrapper around get_table_records that returns
        just the list of records for simpler usage.

        Args:
            table: Table name (e.g., 'incident', 'change_request')
            query: Encoded query string for filtering
            limit: Maximum number of records to return
            fields: Comma-separated list of fields to return

        Returns:
            List of record dictionaries

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        response = await self.get_table_records(
            table=table,
            sysparm_query=query if query else None,
            sysparm_limit=limit,
            sysparm_fields=fields,
        )
        return response.get("result", [])

    async def get_table_schema(
        self,
        table: str,
    ) -> Dict[str, Any]:
        """
        Get schema/field definitions for a ServiceNow table.

        Args:
            table: Table name (e.g., 'incident', 'change_request')

        Returns:
            Dict containing the table schema information

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        # Get table dictionary entry
        url = f"{self.base_url}/table/sys_db_object"
        params = {
            "sysparm_query": f"name={table}",
            "sysparm_limit": 1,
            "sysparm_display_value": "true",
        }

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        table_info = response.json()

        # Get field definitions
        url = f"{self.base_url}/table/sys_dictionary"
        params = {
            "sysparm_query": f"name={table}^active=true",
            "sysparm_fields": "element,column_label,internal_type,max_length,mandatory,read_only,reference",
            "sysparm_display_value": "true",
        }

        response = await self.client.get(url, params=params)
        response.raise_for_status()

        fields_info = response.json()

        return {
            "table": table_info.get("result", [{}])[0] if table_info.get("result") else {},
            "fields": fields_info.get("result", []),
        }
