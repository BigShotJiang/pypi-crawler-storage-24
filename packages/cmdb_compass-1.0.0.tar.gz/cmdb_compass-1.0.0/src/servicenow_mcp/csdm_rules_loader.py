"""
CSDM 5.0 Rules Loader and Validator

This module loads CSDM 5.0 rules from csdm_rules.json and provides utilities
for tools to reference CSDM requirements BEFORE executing operations.

Tools must check CSDM rules first to ensure compliance-driven decision making.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

try:  # Python 3.9+
    from importlib import resources
except ImportError:  # pragma: no cover - Python <3.9
    import importlib_resources as resources  # type: ignore[no-redef]


class CSDMRulesLoader:
    """Load and provide access to CSDM 5.0 rules."""

    def __init__(self):
        """Initialize CSDM rules loader and load rules from file."""
        self.rules = {}
        self.ci_class_map = {}  # Map CI class to domain
        self._load_rules()

    def _load_rules(self) -> None:
        """Load CSDM rules from local data directory or bundled package assets."""
        candidate_paths = []

        env_dir = os.getenv("SERVICENOW_MCP_DATA_DIR")
        if env_dir:
            candidate_paths.append(Path(env_dir).expanduser() / "csdm_rules.json")

        package_root = Path(__file__).resolve().parent.parent.parent
        candidate_paths.append(package_root / "data" / "csdm_rules.json")
        candidate_paths.append(Path.cwd() / "data" / "csdm_rules.json")

        for rules_path in candidate_paths:
            if rules_path.exists():
                try:
                    with rules_path.open("r", encoding="utf-8") as f:
                        self.rules = json.load(f)
                    print(f"[INFO] Loaded CSDM rules from {rules_path}", file=sys.stderr)
                    self._build_ci_class_map()
                    return
                except json.JSONDecodeError as e:
                    print(f"[ERROR] Failed to parse CSDM rules JSON at {rules_path}: {e}", file=sys.stderr)
                    self.rules = {}
                    return

        # Fallback to bundled resource (installed package data)
        try:
            with resources.files("servicenow_mcp.data").joinpath("csdm_rules.json").open("r", encoding="utf-8") as f:
                self.rules = json.load(f)
            print("[INFO] Loaded CSDM rules from package resources", file=sys.stderr)
            self._build_ci_class_map()
        except (FileNotFoundError, ModuleNotFoundError, AttributeError, json.JSONDecodeError) as exc:
            print(
                "[WARNING] CSDM rules file missing. "
                "Set SERVICENOW_MCP_DATA_DIR to a directory containing csdm_rules.json.",
                file=sys.stderr,
            )
            print(f"[WARNING] Loader fallback failed: {exc}", file=sys.stderr)
            self.rules = {}

    def _build_ci_class_map(self) -> None:
        """Build mapping of CI class -> domain for quick lookup."""
        for domain, ci_classes in self.rules.items():
            if isinstance(ci_classes, dict):
                for ci_class in ci_classes.keys():
                    if not ci_class.startswith("_"):  # Skip metadata keys
                        self.ci_class_map[ci_class] = domain

    def get_ci_class_requirements(self, ci_class: str) -> Optional[Dict[str, Any]]:
        """
        Get all requirements for a CI class from CSDM rules.

        Args:
            ci_class: The CI class (e.g., 'cmdb_ci_server', 'cmdb_ci_database')

        Returns:
            Dict with fields, relationships, and requirements, or None if not found
        """
        domain = self.ci_class_map.get(ci_class)
        if not domain:
            return None

        return self.rules.get(domain, {}).get(ci_class)

    def get_required_fields(self, ci_class: str) -> Set[str]:
        """
        Get set of required fields for a CI class.

        Args:
            ci_class: The CI class

        Returns:
            Set of field names marked as required
        """
        requirements = self.get_ci_class_requirements(ci_class)
        if not requirements or "fields" not in requirements:
            return set()

        required = set()
        for field_name, field_def in requirements["fields"].items():
            if isinstance(field_def, dict):
                requirement_text = field_def.get("requirement", "").lower()
                # Check for explicit requirement keywords
                if any(
                    keyword in requirement_text
                    for keyword in ["required", "must be", "should be"]
                ):
                    required.add(field_name)

        return required

    def get_optional_fields(self, ci_class: str) -> Set[str]:
        """Get set of optional fields for a CI class."""
        requirements = self.get_ci_class_requirements(ci_class)
        if not requirements or "fields" not in requirements:
            return set()

        return set(requirements["fields"].keys()) - self.get_required_fields(ci_class)

    def is_valid_ci_class(self, ci_class: str) -> bool:
        """
        Check if a CI class is valid and defined in CSDM 5.0 rules.

        Args:
            ci_class: The CI class name (e.g., 'cmdb_ci_server', 'cmdb_ci_database')

        Returns:
            True if the CI class is defined in CSDM rules, False otherwise
        """
        return ci_class in self.ci_class_map

    def get_all_ci_classes(self) -> List[str]:
        """
        Get all CI classes defined in CSDM rules.

        Returns:
            List of all CI class names
        """
        return list(self.ci_class_map.keys())

    def get_relationship_rules(self, ci_class: str) -> Optional[Dict[str, Any]]:
        """
        Get relationship mapping rules for a CI class.

        Args:
            ci_class: The CI class

        Returns:
            Dict of relationships with type, direction, cardinality, requirements
        """
        requirements = self.get_ci_class_requirements(ci_class)
        if not requirements:
            return None

        return requirements.get("relationships", {})

    def get_valid_relationship_types(self, include_servicenow_types: bool = False, client=None) -> Set[str]:
        """
        Get all valid relationship types from CSDM rules.

        Args:
            include_servicenow_types: If True and client provided, fetch live types from ServiceNow
            client: ServiceNowClient instance for fetching live relationship types

        Returns:
            Set of valid relationship type strings
        """
        valid_types = set()

        for domain_rules in self.rules.values():
            if isinstance(domain_rules, dict):
                for ci_class_rules in domain_rules.values():
                    if isinstance(ci_class_rules, dict):
                        relationships = ci_class_rules.get("relationships", {})
                        for rel_info in relationships.values():
                            if isinstance(rel_info, dict):
                                rel_type = rel_info.get("type")
                                if rel_type:
                                    valid_types.add(rel_type)

        # Add common CSDM relationship types if not found
        common_types = {
            "hosted_on",
            "deployed_on",
            "depends_on",
            "used_by",
            "connects_to",
            "contains",
            "managed_by",
            "runs_on",
            "supports",
            "references",
            "enables",
            "serves",
        }
        valid_types.update(common_types)

        return valid_types

    async def get_servicenow_relationship_types(self, client) -> Dict[str, Any]:
        """
        Fetch relationship types directly from ServiceNow instance.

        This queries the cmdb_rel_type table to get all available relationship types,
        providing a complete and up-to-date list from the live instance.

        Args:
            client: ServiceNowClient instance

        Returns:
            Dict with:
            - relationship_types: List of dicts with sys_id, name, parent_descriptor, child_descriptor
            - count: Total number of relationship types
            - type_names: Set of relationship type names (parent descriptors)
        """
        try:
            # Query cmdb_rel_type table for all relationship types
            response = await client.get_table_records(
                table="cmdb_rel_type",
                sysparm_fields="sys_id,name,parent_descriptor,child_descriptor",
                sysparm_limit=1000,  # Should cover all relationship types
            )

            rel_types = response.get("result", [])

            # Extract parent_descriptor names (these are the relationship type names)
            type_names = set()
            for rel_type in rel_types:
                parent_desc = rel_type.get("parent_descriptor", "")
                # Handle dict response from ServiceNow API (when sysparm_display_value is used)
                if isinstance(parent_desc, dict):
                    parent_desc = parent_desc.get("display_value") or parent_desc.get("value") or ""
                if parent_desc and isinstance(parent_desc, str):
                    type_names.add(parent_desc)

            return {
                "relationship_types": rel_types,
                "count": len(rel_types),
                "type_names": type_names,
            }

        except Exception as e:
            print(f"[WARNING] Failed to fetch ServiceNow relationship types: {e}", file=sys.stderr)
            return {
                "relationship_types": [],
                "count": 0,
                "type_names": set(),
            }

    async def get_all_valid_relationship_types(self, client=None) -> Set[str]:
        """
        Get comprehensive set of relationship types from both CSDM rules and ServiceNow.

        This is the recommended method for getting relationship types as it combines:
        - CSDM 5.0 rules (static, curated)
        - Live ServiceNow instance types (dynamic, complete)
        - Common fallback types (safety net)

        Args:
            client: Optional ServiceNowClient instance for fetching live types

        Returns:
            Set of all valid relationship type names
        """
        # Start with CSDM rule types
        all_types = self.get_valid_relationship_types()

        # Fetch and merge ServiceNow types if client provided
        if client:
            servicenow_data = await self.get_servicenow_relationship_types(client)
            servicenow_types = servicenow_data.get("type_names", set())

            if servicenow_types:
                print(f"[INFO] Merged {len(servicenow_types)} relationship types from ServiceNow instance", file=sys.stderr)
                all_types.update(servicenow_types)

        return all_types

    def normalize_relationship_type(self, rel_type: str) -> str:
        """
        Normalize relationship type to CSDM format (lowercase with underscores).

        Args:
            rel_type: Relationship type in any format (e.g., "Deployed on", "deployed_on")

        Returns:
            Normalized CSDM format (e.g., "deployed_on")
        """
        return rel_type.lower().replace(" ", "_")

    def convert_csdm_to_servicenow_descriptor(self, csdm_type: str) -> Dict[str, str]:
        """
        Convert CSDM relationship type to ServiceNow parent/child descriptors.

        Uses CSDM 5.0 standard mappings. CSDM uses lowercase_underscore (e.g., 'deployed_on'),
        ServiceNow uses Title Case with spaces (e.g., 'Deployed on').

        Args:
            csdm_type: CSDM relationship type (e.g., 'deployed_on', 'runs_on')

        Returns:
            Dict with parent_descriptor, child_descriptor, and name
        """
        # Normalize to CSDM format
        normalized = self.normalize_relationship_type(csdm_type)

        # CSDM 5.0 standard relationship type mappings
        # Source: ServiceNow CSDM documentation
        mappings = {
            "deployed_on": ("Deployed on", "Hosts Deployment"),
            "depends_on": ("Depends on", "Used by"),
            "runs_on": ("Runs on", "Runs"),
            "hosted_on": ("Hosted on", "Hosts"),
            "contains": ("Contains", "Contained by"),
            "connects_to": ("Connects to", "Connected by"),
            "consumes": ("Consumes", "Consumed by"),
            "provides": ("Provides", "Provided by"),
            "manages": ("Manages", "Managed by"),
            "managed_by": ("Managed by", "Manages"),
            "uses": ("Uses", "Used by"),
            "used_by": ("Used by", "Uses"),
            "supports": ("Supports", "Supported by"),
            "references": ("References", "Referenced by"),
            "enables": ("Enables", "Enabled by"),
            "serves": ("Serves", "Served by"),
            "contributes_to": ("Contributes to", "Receives contribution from"),
            "deploys_to": ("Deploys to", "Deployment target for"),
        }

        if normalized in mappings:
            parent_desc, child_desc = mappings[normalized]
        else:
            # Generate from type name if not in standard mappings
            parent_desc = csdm_type.replace("_", " ").title()
            # Generate inverse descriptor
            if parent_desc.endswith("s"):
                child_desc = f"{parent_desc[:-1]}ed by"
            else:
                child_desc = f"{parent_desc}d by"

        return {
            "parent_descriptor": parent_desc,
            "child_descriptor": child_desc,
            "name": f"{parent_desc}::{child_desc}",
        }

    async def create_missing_csdm_relationship_type(
        self, client, rel_type_name: str, dry_run: bool = False
    ) -> Optional[str]:
        """
        Auto-create a missing CSDM relationship type in ServiceNow.

        This ensures CSDM compliance by creating relationship types that are
        defined in CSDM rules but missing from the ServiceNow instance.

        Args:
            client: ServiceNowClient instance
            rel_type_name: Relationship type name (e.g., 'Deployed on', 'deployed_on')
            dry_run: If True, only simulate creation without making changes

        Returns:
            sys_id of created/found relationship type, or None if creation failed
        """
        try:
            # Normalize and get descriptors
            normalized = self.normalize_relationship_type(rel_type_name)
            descriptors = self.convert_csdm_to_servicenow_descriptor(normalized)

            if dry_run:
                print(
                    f"[DRY-RUN] Would create CSDM relationship type: {descriptors['name']}",
                    file=sys.stderr
                )
                return f"DRYRUN_{normalized}"

            print(
                f"[INFO] Auto-creating CSDM relationship type: {descriptors['name']}",
                file=sys.stderr
            )

            # Create the relationship type in cmdb_rel_type table
            response = await client.create_record(
                table="cmdb_rel_type",
                data={
                    "name": descriptors["name"],
                    "parent_descriptor": descriptors["parent_descriptor"],
                    "child_descriptor": descriptors["child_descriptor"],
                },
                sysparm_display_value="false",
                sysparm_fields="sys_id,name,parent_descriptor,child_descriptor",
            )

            result = response.get("result", {})
            sys_id = result.get("sys_id")

            if sys_id:
                print(
                    f"[SUCCESS] Created CSDM relationship type '{descriptors['name']}' (sys_id: {sys_id})",
                    file=sys.stderr
                )
                return sys_id
            else:
                print(
                    f"[ERROR] Failed to create relationship type '{descriptors['name']}': No sys_id returned",
                    file=sys.stderr
                )
                return None

        except Exception as e:
            print(
                f"[ERROR] Failed to create CSDM relationship type '{rel_type_name}': {str(e)}",
                file=sys.stderr
            )
            return None

    def get_ci_classes_by_domain(self, domain: str) -> List[str]:
        """
        Get all CI classes for a specific domain.

        Args:
            domain: The domain name (e.g., 'Foundation', 'Design', 'Operate', 'Manage')

        Returns:
            List of CI class names in the domain
        """
        domain_lower = domain.lower()
        # The rules dictionary has domain keys, need to match case-insensitively
        for key, value in self.rules.items():
            if key.lower() == domain_lower and isinstance(value, dict):
                # Filter out metadata keys (starting with _) and return CI class names
                return [k for k in value.keys() if not k.startswith("_")]
        return []

    def get_duplicate_detection_fields(self, ci_class: str) -> List[str]:
        """
        Get recommended fields for duplicate detection for a CI class.

        Based on CSDM rules, different CI classes use different fields for ID.
        For example, servers use (serial_number, hostname), computers use (serial_number, asset_tag).

        Args:
            ci_class: The CI class

        Returns:
            List of fields to check for duplicates, in priority order
        """
        # Field priority by CI class based on CSDM best practices
        field_priority = {
            # Computers: serial number is primary identifier
            "cmdb_ci_computer": [
                "serial_number",
                "asset_tag",
                "mac_address",
                "host_name",
                "ip_address",
            ],
            # Servers: hostname + serial number
            "cmdb_ci_server": [
                "host_name",
                "ip_address",
                "serial_number",
                "mac_address",
            ],
            # Databases: name + hostname
            "cmdb_ci_database": [
                "name",
                "host_name",
                "ip_address",
            ],
            # Network devices: IP or MAC
            "cmdb_ci_network_device": [
                "ip_address",
                "mac_address",
                "name",
            ],
            # Applications: name + environment
            "cmdb_ci_appl": [
                "name",
                "environment",
                "version",
            ],
            # Services: name
            "cmdb_ci_service": [
                "name",
                "environment",
            ],
        }

        return field_priority.get(ci_class, ["serial_number", "asset_tag", "name"])

    def get_staleness_threshold(self, ci_class: str) -> Optional[int]:
        """
        Get recommended staleness threshold (in days) for a CI class.

        Based on CSDM, different CI types have different refresh requirements.

        Args:
            ci_class: The CI class

        Returns:
            Number of days before CI is considered stale, or None if not defined
        """
        # Staleness thresholds by CI class (in days)
        thresholds = {
            "cmdb_ci_server": 60,  # Servers: 60 days
            "cmdb_ci_computer": 90,  # Computers: 90 days (less frequent discovery)
            "cmdb_ci_database": 60,  # Databases: 60 days (critical)
            "cmdb_ci_network_device": 60,  # Network: 60 days
            "cmdb_ci_appl": 90,  # Applications: 90 days
            "cmdb_ci_service": 180,  # Services: 180 days (less frequently updated)
        }

        return thresholds.get(ci_class)

    def validate_against_csdm(
        self, ci_class: str, ci_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Validate a CI record against CSDM requirements.

        Args:
            ci_class: The CI class
            ci_data: The CI record data

        Returns:
            Dict with validation results including missing_required, extra_fields, etc.
        """
        requirements = self.get_ci_class_requirements(ci_class)
        if not requirements:
            return {"status": "unknown", "ci_class": ci_class, "message": "No CSDM rules found"}

        required_fields = self.get_required_fields(ci_class)
        missing = required_fields - set(ci_data.keys())
        missing_with_values = {
            f for f in required_fields if not ci_data.get(f)
        }

        return {
            "ci_class": ci_class,
            "status": "compliant" if not missing_with_values else "non_compliant",
            "required_fields": list(required_fields),
            "missing_required_fields": list(missing_with_values),
            "optional_fields": list(self.get_optional_fields(ci_class)),
            "compliance_score": round(
                (len(required_fields) - len(missing_with_values))
                / max(len(required_fields), 1)
                * 100,
                1,
            ),
        }

    def print_rules_summary(self) -> None:
        """Print summary of loaded CSDM rules for debugging."""
        print("\n" + "=" * 60, file=sys.stderr)
        print("CSDM Rules Summary", file=sys.stderr)
        print("=" * 60, file=sys.stderr)

        for domain, ci_classes in self.rules.items():
            if isinstance(ci_classes, dict):
                class_count = len(
                    [c for c in ci_classes.keys() if not c.startswith("_")]
                )
                print(f"\n📚 Domain: {domain} ({class_count} CI classes)", file=sys.stderr)

                for ci_class in list(ci_classes.keys())[:3]:  # Show first 3
                    if not ci_class.startswith("_"):
                        print(f"   - {ci_class}", file=sys.stderr)
                if class_count > 3:
                    print(f"   ... and {class_count - 3} more", file=sys.stderr)

        print("\n" + "=" * 60, file=sys.stderr)


# Global instance - load once
_csdm_loader: Optional[CSDMRulesLoader] = None


def get_csdm_rules() -> CSDMRulesLoader:
    """Get or create the global CSDM rules loader instance."""
    global _csdm_loader
    if _csdm_loader is None:
        _csdm_loader = CSDMRulesLoader()
    return _csdm_loader
