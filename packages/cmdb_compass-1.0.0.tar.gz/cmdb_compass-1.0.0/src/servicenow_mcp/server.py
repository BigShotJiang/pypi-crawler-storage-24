"""
ServiceNow MCP Server

This module provides a Model Context Protocol (MCP) server for ServiceNow integration.
It uses the FastMCP framework to expose ServiceNow operations as MCP tools.
"""

# Load environment variables from .env file early
try:
    from dotenv import load_dotenv
    load_dotenv(override=False)
except ImportError:
    pass

import asyncio
import difflib
import json
import os
import re
import sys
import time
import traceback
from collections.abc import AsyncIterator, Callable, Mapping
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import sentry_sdk
from mcp.server.fastmcp import Context, FastMCP

from .servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.csdm_compliance_checker import run_compliance_check
from servicenow_mcp.tools.cmdb.audit.audit_extract_ci_context import extract_ci_context as extract_ci_context_impl
from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis as identify_stale_cis_impl
from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis as audit_duplicate_cis_impl
from servicenow_mcp.tools.cmdb.audit.audit_calculate_cmdb_health_score import calculate_cmdb_health_score as calculate_cmdb_health_score_impl
from servicenow_mcp.tools.cmdb.audit.audit_data_ownership_assignment import audit_data_ownership_assignment as audit_data_ownership_assignment_impl
from servicenow_mcp.tools.cmdb.audit.audit_discovery_coverage_gaps import audit_discovery_coverage_gaps as audit_discovery_coverage_gaps_impl
from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import audit_validate_relationship_integrity as audit_validate_relationship_integrity_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_data_lineage import audit_ci_data_lineage as audit_ci_data_lineage_impl
from servicenow_mcp.tools.cmdb.audit.audit_compliance_summary_report import audit_compliance_summary_report as audit_compliance_summary_report_impl
from servicenow_mcp.tools.cmdb.audit.audit_executive_health_summary import audit_executive_health_summary as audit_executive_health_summary_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_lifecycle_health import audit_ci_lifecycle_health as audit_ci_lifecycle_health_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_drift_detection import audit_ci_drift_detection as audit_ci_drift_detection_impl
from servicenow_mcp.tools.cmdb.action.action_auto_heal_relationship_issues import action_auto_heal_relationship_issues as action_auto_heal_relationship_issues_impl
from servicenow_mcp.tools.cmdb.audit.audit_orchestrate_ci_validation_flow import audit_orchestrate_ci_validation_flow as audit_orchestrate_ci_validation_flow_impl
from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents as search_incidents_impl
from servicenow_mcp.tools.itsm.audit.search_assignment_groups import search_assignment_groups as search_assignment_groups_impl
from servicenow_mcp.tools.itsm.audit.search_users import search_users as search_users_impl
from servicenow_mcp.tools.itsm.audit.get_incident_details import get_incident_details as get_incident_details_impl
from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents as find_similar_incidents_impl
from servicenow_mcp.tools.itsm.audit.create_incident import create_incident as create_incident_impl
from servicenow_mcp.tools.itsm.audit.update_incident import update_incident as update_incident_impl
from servicenow_mcp.tools.itsm.audit.add_comment_to_incident import add_comment_to_incident as add_comment_to_incident_impl
from servicenow_mcp.tools.itsm.audit.get_change_request import get_change_request as get_change_request_impl
from servicenow_mcp.tools.itsm.audit.list_recent_change_requests import list_recent_change_requests as list_recent_change_requests_impl
from servicenow_mcp.tools.itsm.audit.link_cis_to_change_request import link_cis_to_change_request as link_cis_to_change_request_impl
from servicenow_mcp.tools.cmdb.action.action_auto_retire_stale_cis import auto_retire_stale_cis as auto_retire_stale_cis_impl
from servicenow_mcp.tools.cmdb.audit.audit_suggest_ci_relationship_mappings import suggest_ci_relationship_mappings as suggest_ci_relationship_mappings_impl
from servicenow_mcp.tools.cmdb.action.action_bulk_update_missing_fields import bulk_update_missing_fields as bulk_update_missing_fields_impl
from servicenow_mcp.tools.cmdb.action.action_merge_duplicate_cis import merge_duplicate_cis as merge_duplicate_cis_impl
from servicenow_mcp.tools.cmdb.action.action_remediate_relationship_health import remediate_relationship_health as remediate_relationship_health_impl
from servicenow_mcp.tools.cmdb.audit.audit_check_csdm_rules import check_csdm_rules as check_csdm_rules_impl
from servicenow_mcp.tools.cmdb.audit.audit_calculate_csdm_maturity_score import calculate_csdm_maturity_score as calculate_csdm_maturity_score_impl
from servicenow_mcp.tools.cmdb.audit.audit_analyze_tagging_compliance import analyze_tagging_compliance as analyze_tagging_compliance_impl
from servicenow_mcp.tools.cmdb.audit.audit_analyze_service_mappings import analyze_service_mappings as analyze_service_mappings_impl
from .test_servicenow_connection import test_servicenow_connection as test_servicenow_connection_impl
from servicenow_mcp.tools.data_access.get_table_description import get_table_description as get_table_description_impl
from servicenow_mcp.tools.cmdb.audit.audit_generate_compliance_report import generate_compliance_report as generate_compliance_report_impl
from servicenow_mcp.tools.cmdb.audit.audit_cmdb_data_accuracy import audit_cmdb_data_accuracy as audit_cmdb_data_accuracy_impl
from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health as analyze_cmdb_health_impl
from servicenow_mcp.tools.cmdb.audit.audit_analyze_ci_relationships import analyze_ci_relationships as analyze_ci_relationships_impl
from servicenow_mcp.tools.cmdb.audit.audit_detect_anti_patterns import detect_anti_patterns as detect_anti_patterns_impl
from servicenow_mcp.tools.cmdb.audit.audit_analyze_csdm_compliance import analyze_csdm_compliance as analyze_csdm_compliance_impl
from servicenow_mcp.tools.cmdb.audit.audit_validate_model_hierarchy import validate_model_hierarchy as validate_model_hierarchy_impl
from servicenow_mcp.tools.cmdb.audit.audit_identify_domain_gaps import identify_domain_gaps as identify_domain_gaps_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_mandatory_fields_compliance import audit_ci_mandatory_fields_compliance as audit_ci_mandatory_fields_compliance_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_duplicate_merge_confidence import audit_ci_duplicate_merge_confidence as audit_ci_duplicate_merge_confidence_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_policy_violation_score import audit_ci_policy_violation_score as audit_ci_policy_violation_score_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_retention_flags import audit_ci_retention_flags as audit_ci_retention_flags_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_confidentiality_tags import audit_ci_confidentiality_tags as audit_ci_confidentiality_tags_impl
from servicenow_mcp.tools.cmdb.audit.audit_ci_identifier_rules import audit_ci_identifier_rules as audit_ci_identifier_rules_impl
from servicenow_mcp.tools.cmdb.audit.audit_reconciliation_governance import audit_reconciliation_governance as audit_reconciliation_governance_impl
from servicenow_mcp.tools.cmdb.audit.audit_ire_health import audit_ire_health as audit_ire_health_impl
from servicenow_mcp.tools.cmdb.action.action_assess_change_impact import assess_change_impact as assess_change_impact_impl
from servicenow_mcp.tools.cmdb.action.action_apply_bulk_cmdb_changes_with_cr import apply_bulk_cmdb_changes_with_cr as apply_bulk_cmdb_changes_with_cr_impl
from servicenow_mcp.tools.cmdb.action.action_normalize_ci_naming_conventions import normalize_ci_naming_conventions as normalize_ci_naming_conventions_impl
from servicenow_mcp.tools.cmdb.action.action_rollback_cmdb_changes import rollback_cmdb_changes as rollback_cmdb_changes_impl
from servicenow_mcp.tools.cmdb.action.action_validate_change_approval_status import validate_change_approval_status as validate_change_approval_status_impl
from servicenow_mcp.tools.data_access.query_table_records import query_table_records as query_table_records_impl
from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records as count_table_records_impl
from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields as list_tables_and_fields_impl
from .csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import (
    AuditLevel,
    SAMPLE_SIZE_PERCENT,
    AUDIT_BASELINE_CACHE,
    LAST_AUDIT_TIMESTAMP,
    FULL_AUDIT_INTERVAL_SECONDS,
    calculate_sample_size,
    calculate_confidence_interval,
    build_audit_metadata,
    build_sampling_query,
    extrapolate_sample_metrics,
    cache_audit_baseline,
    should_run_incremental_audit,
    calculate_audit_delta,
    get_ci_identification_rules,
    get_required_fields_from_sys_dictionary,
)

# ============================================================================
# Sentry Error Tracking Configuration
# ============================================================================

SENTRY_DSN = os.getenv(
    "SENTRY_DSN",
    "https://dfecb27bf9d46635aa705602ea8365ae@o4510252877807616.ingest.us.sentry.io/4510252878069760",
)

# Initialize Sentry for error tracking and performance monitoring
sentry_sdk.init(
    dsn=SENTRY_DSN,
    traces_sample_rate=1.0,  # Capture 100% of transactions for full visibility
    send_default_pii=False,  # Don't send PII by default (set to True if needed)
    environment=os.getenv("ENVIRONMENT", "development"),
    attach_stacktrace=True,  # Attach stack traces to all messages
    include_local_variables=False,  # Don't include local variables for privacy
)


# ============================================================================
# Subscription & Licensing Configuration
# ============================================================================

NEXECUTE_LICENSING_URL = os.getenv(
    "NEXECUTE_LICENSING_URL",
    "https://nexecute-licensing.workers.dev"
)
NEXECUTE_TOKEN = os.getenv("NEXECUTE_TOKEN", "")
NEXECUTE_REQUIRE_CREDITS = os.getenv("NEXECUTE_REQUIRE_CREDITS", "false").lower() == "true"


async def validate_subscription(credits_required: int = 1) -> Dict[str, Any]:
    """
    Validate user subscription and check if they have sufficient credits.

    Args:
        credits_required: Number of credits required for the operation

    Returns:
        Dictionary with validation results:
        - success: Boolean indicating if validation passed
        - credits_remaining: Number of credits available
        - error: Error message if validation failed
    """
    # Skip validation if credits not required (free tier or development)
    if not NEXECUTE_REQUIRE_CREDITS or not NEXECUTE_TOKEN:
        return {
            "success": True,
            "credits_remaining": float('inf'),
            "tier": "free",
            "bypass_reason": "Credits not required" if not NEXECUTE_REQUIRE_CREDITS else "No token provided"
        }

    try:
        import httpx

        # Call licensing service to check quota
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(
                f"{NEXECUTE_LICENSING_URL}/api/check-quota",
                params={"credits": credits_required},
                headers={"Authorization": f"Bearer {NEXECUTE_TOKEN}"}
            )

            if response.status_code == 200:
                data = response.json()
                return {
                    "success": data.get("success", False),
                    "credits_remaining": data.get("data", {}).get("creditsRemaining", 0),
                    "tier": data.get("data", {}).get("tier", "unknown"),
                    "error": data.get("error")
                }
            else:
                return {
                    "success": False,
                    "credits_remaining": 0,
                    "error": f"Licensing service returned {response.status_code}"
                }
    except Exception as e:
        # Log error but don't fail - fallback to allowing execution
        print(f"⚠️  Subscription validation failed: {e}", file=sys.stderr)
        return {
            "success": True,  # Allow execution on validation error
            "credits_remaining": 0,
            "bypass_reason": f"Validation error: {str(e)}"
        }


async def deduct_credits(credits_used: int, tool_name: str) -> Dict[str, Any]:
    """
    Deduct credits after successful tool execution.

    Args:
        credits_used: Number of credits to deduct
        tool_name: Name of the tool that was executed

    Returns:
        Dictionary with deduction results
    """
    # Skip deduction if credits not required
    if not NEXECUTE_REQUIRE_CREDITS or not NEXECUTE_TOKEN:
        return {"success": True, "bypass_reason": "Credits not required"}

    try:
        import httpx

        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{NEXECUTE_LICENSING_URL}/api/usage/deduct",
                json={"credits": credits_used, "toolName": tool_name},
                headers={"Authorization": f"Bearer {NEXECUTE_TOKEN}"}
            )

            if response.status_code == 200:
                data = response.json()
                return {
                    "success": data.get("success", False),
                    "credits_remaining": data.get("data", {}).get("creditsRemaining", 0),
                    "error": data.get("error")
                }
            else:
                return {
                    "success": False,
                    "error": f"Credit deduction failed with status {response.status_code}"
                }
    except Exception as e:
        print(f"⚠️  Credit deduction failed: {e}", file=sys.stderr)
        return {"success": False, "error": str(e)}


async def fetch_servicenow_credentials() -> Optional[Dict[str, str]]:
    """
    Fetch ServiceNow credentials from the licensing service.

    Handles both OAuth (type: 'oauth') and Basic Auth (type: 'basic') responses.
    If NEXECUTE_TOKEN is set, attempts to fetch credentials from the payments service.
    Falls back to environment variables if fetch fails or token is absent.

    Returns:
        Dictionary with credential type and fields:
          OAuth:  { type, instance, access_token }
          Basic:  { type, instance, username, password }
        Returns None if credentials should be read from environment variables.
    """
    if not NEXECUTE_TOKEN:
        print("ℹ️  No NEXECUTE_TOKEN set, using credentials from environment variables", file=sys.stderr)
        return None

    try:
        import httpx

        print(f"🔐 Fetching ServiceNow credentials from {NEXECUTE_LICENSING_URL}...", file=sys.stderr)

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{NEXECUTE_LICENSING_URL}/api/servicenow/credentials",
                headers={"Authorization": f"Bearer {NEXECUTE_TOKEN}"}
            )

            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    cred_data = data.get("data", {})
                    cred_type = cred_data.get("type", "basic")
                    instance = cred_data.get("instance")
                    print(f"✅ Retrieved ServiceNow {cred_type} credentials for instance: {instance}", file=sys.stderr)

                    if cred_type == "oauth":
                        return {
                            "type": "oauth",
                            "instance": instance,
                            "access_token": cred_data.get("accessToken"),
                        }
                    else:
                        return {
                            "type": "basic",
                            "instance": instance,
                            "username": cred_data.get("username"),
                            "password": cred_data.get("password"),
                        }
                else:
                    print(f"⚠️  Failed to fetch credentials: {data.get('error')}", file=sys.stderr)
                    return None
            elif response.status_code == 404:
                print("ℹ️  No ServiceNow credentials stored, using environment variables", file=sys.stderr)
                return None
            else:
                print(f"⚠️  Credentials fetch returned {response.status_code}, using environment variables", file=sys.stderr)
                return None

    except Exception as e:
        print(f"⚠️  Error fetching ServiceNow credentials: {e}", file=sys.stderr)
        print("ℹ️  Falling back to environment variables", file=sys.stderr)
        return None


def setup_sentry_context(tool_name: str, **kwargs) -> None:
    """
    Setup Sentry context for a tool call.

    Captures tool name, parameters, and execution environment for better error
    tracking and debugging.

    Args:
        tool_name: The name of the MCP tool being called
        **kwargs: Additional context fields to set (e.g., ci_sysid, user_id)
    """
    with sentry_sdk.push_scope() as scope:
        # Set tool context
        scope.set_tag("tool_name", tool_name)
        scope.set_tag("mcp_server", "servicenow")

        # Set additional context fields
        for key, value in kwargs.items():
            scope.set_extra(f"tool_{key}", value)

        # Add breadcrumb for tool call
        sentry_sdk.add_breadcrumb(
            category="mcp_tool",
            message=f"Tool called: {tool_name}",
            level="info",
            data=kwargs,
        )


@dataclass
class AppContext:
    """Application context holding the ServiceNow client instance."""

    servicenow: ServiceNowClient


@asynccontextmanager
async def lifespan(app: FastMCP) -> AsyncIterator[AppContext]:
    """
    Lifecycle manager for the MCP server.

    Handles initialization and cleanup of the ServiceNow client with Sentry monitoring.

    Args:
        app: The FastMCP application instance

    Yields:
        AppContext: Application context with initialized ServiceNow client
    """
    print("🚀 Initializing ServiceNow MCP Server...", file=sys.stderr)

    # Add Sentry context for server startup
    with sentry_sdk.push_scope() as scope:
        scope.set_tag("phase", "startup")
        scope.set_context("server", {"type": "mcp", "name": "servicenow"})

        client = None
        credential_source = "env"  # Track which source provided credentials
        try:
            # ── Credential resolution ───────────────────────────────
            # Precedence: licensing service (NEXECUTE_TOKEN) → .env fallback
            credentials = await fetch_servicenow_credentials()
            if credentials:
                os.environ["SERVICENOW_INSTANCE_URL"] = credentials.get("instance") or ""
                if credentials.get("type") == "oauth":
                    os.environ["SERVICENOW_ACCESS_TOKEN"] = credentials.get("access_token") or ""
                    # Clear basic-auth vars so ServiceNowClient uses Bearer auth
                    os.environ.pop("SERVICENOW_USERNAME", None)
                    os.environ.pop("SERVICENOW_PASSWORD", None)
                else:
                    os.environ["SERVICENOW_USERNAME"] = credentials.get("username") or ""
                    os.environ["SERVICENOW_PASSWORD"] = credentials.get("password") or ""
                    os.environ.pop("SERVICENOW_ACCESS_TOKEN", None)
                credential_source = "licensing_service"
            else:
                # Validate .env credentials are present before proceeding.
                # Accept either OAuth (access token) or Basic Auth (user + pass).
                has_oauth = bool(
                    os.getenv("SERVICENOW_ACCESS_TOKEN")
                    and not os.getenv("SERVICENOW_ACCESS_TOKEN", "").startswith("your_")
                )
                if not has_oauth:
                    missing = [
                        var for var in (
                            "SERVICENOW_INSTANCE_URL",
                            "SERVICENOW_USERNAME",
                            "SERVICENOW_PASSWORD",
                        )
                        if not os.getenv(var) or os.getenv(var, "").startswith("your_")
                    ]
                    if missing:
                        print(
                            f"[Credentials] WARNING: .env fallback missing or placeholder values "
                            f"for: {', '.join(missing)}",
                            file=sys.stderr,
                        )

            print(
                f"[Credentials] source={credential_source}, "
                f"instance={os.getenv('SERVICENOW_INSTANCE_URL', '(not set)')}",
                file=sys.stderr,
            )

            # Initialize ServiceNow client (uses environment variables)
            client = ServiceNowClient()
            print(f"[Startup] Connecting to {client.instance_url}...", file=sys.stderr)

            # Test the connection
            try:
                connection_info = await client.test_connection()
                user_info = connection_info.get("user", {})
                user_name = user_info.get("name", "Unknown")
                user_id = user_info.get("user_name", "Unknown")

                print(
                    f"[Startup] Connected as {user_name} ({user_id}) "
                    f"via {credential_source}",
                    file=sys.stderr,
                )

                # Add Sentry breadcrumb for successful connection
                sentry_sdk.add_breadcrumb(
                    category="server_startup",
                    message="ServiceNow connection established",
                    level="info",
                    data={
                        "instance_url": client.instance_url,
                        "user_name": user_name,
                        "user_id": user_id,
                        "credential_source": credential_source,
                    },
                )

            except Exception as e:
                print(
                    f"[Startup] WARNING: Connection test failed "
                    f"(source={credential_source}): {e}",
                    file=sys.stderr,
                )
                print(
                    "[Startup] Server will start but ServiceNow operations may fail",
                    file=sys.stderr,
                )

                # Log warning to Sentry
                sentry_sdk.add_breadcrumb(
                    category="server_startup",
                    message="ServiceNow connection test failed",
                    level="warning",
                    data={
                        "error": str(e),
                        "credential_source": credential_source,
                    },
                )

            # Yield the context with the client
            yield AppContext(servicenow=client)

        except Exception as e:
            print(f"❌ Error initializing ServiceNow client: {str(e)}", file=sys.stderr)

            # Capture initialization error in Sentry
            sentry_sdk.capture_exception(e)

            raise
        finally:
            # Clean up resources
            if client:
                print("🔌 Closing ServiceNow client connection...", file=sys.stderr)
                try:
                    await client.close()
                    print("✅ ServiceNow MCP Server shut down gracefully", file=sys.stderr)

                    sentry_sdk.add_breadcrumb(
                        category="server_shutdown",
                        message="ServiceNow client closed",
                        level="info",
                    )
                except Exception as e:
                    print(f"⚠️  Error during shutdown: {str(e)}", file=sys.stderr)
                    sentry_sdk.capture_exception(e)


# Create the FastMCP server instance with lifespan
from mcp.server.transport_security import TransportSecuritySettings

mcp = FastMCP(
    "ServiceNow MCP Server",
    lifespan=lifespan,
    streamable_http_path="/",  # Claude Desktop expects MCP at root path
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=False,  # Disable for cloud deployment
    ),
)


# =============================================================================
# Tiered Tool Execution - Conditional Analysis Based on Findings
# =============================================================================

def should_skip_field_analysis(completeness_score: float) -> bool:
    """
    Determine if field-by-field analysis should be skipped based on completeness.

    Skip when: completeness >= 95% (minimal gaps)
    Run when: completeness < 95% (needs investigation)

    Args:
        completeness_score: Overall completeness percentage (0-100)

    Returns:
        True if analysis can be skipped, False if analysis needed
    """
    return completeness_score >= 95


def should_skip_relationship_analysis(coverage_percent: float) -> bool:
    """
    Determine if relationship analysis should be skipped based on coverage.

    Skip when: coverage >= 90% (strong relationship foundation)
    Run when: coverage < 90% (needs improvement)

    Args:
        coverage_percent: Relationship coverage percentage (0-100)

    Returns:
        True if analysis can be skipped, False if analysis needed
    """
    return coverage_percent >= 90


def get_analysis_scope(audit_level: AuditLevel, completeness: float, coverage: float) -> Dict[str, bool]:
    """
    Determine which analysis tools should be invoked based on audit level and current scores.

    This implements tiered tool execution - running cheaper analysis tools first,
    then invoking expensive tools only where gaps detected.

    Args:
        audit_level: Analysis depth level
        completeness: Current completeness score (0-100)
        coverage: Current relationship coverage (0-100)

    Returns:
        Dictionary indicating which tools to invoke
    """
    # Phase 1: Always run cheap tools (counts, summaries)
    scope = {
        "count_records": True,
        "list_tables": True,
        "quick_summary": audit_level in ["quick", "standard", "deep"],
    }

    # Phase 2: Enable additional tools based on audit level
    scope["field_analysis"] = audit_level in ["standard", "deep"]
    scope["relationship_analysis"] = audit_level in ["standard", "deep"]
    scope["tagging_analysis"] = audit_level in ["standard", "deep"]

    # Phase 3: Run deeper analysis when gaps are detected or deep audit requested
    if audit_level == "deep":
        # Deep audit: run everything
        scope["detailed_field_gaps"] = True
        scope["relationship_remediation"] = True
        scope["service_mapping_analysis"] = True
    else:
        # Standard/Quick: only run expensive analysis if gaps found
        scope["detailed_field_gaps"] = completeness < 80  # Only if significant gaps
        scope["relationship_remediation"] = coverage < 70  # Only if poor coverage
        scope["service_mapping_analysis"] = audit_level == "standard" and coverage < 70

    # Phase 4: Maturity scoring (always useful)
    scope["maturity_score"] = audit_level in ["standard", "deep"]

    return scope


def summarize_tool_execution_scope(scope: Dict[str, bool]) -> Dict[str, Any]:
    """
    Provide a simple summary of which helper tools will run for a given scope.

    Args:
        scope: Tool execution scope from get_analysis_scope

    Returns:
        Dictionary with scope statistics.
    """

    tools_enabled = sum(1 for enabled in scope.values() if enabled)
    tools_skipped = sum(1 for enabled in scope.values() if not enabled)

    return {
        "tools_enabled_count": tools_enabled,
        "tools_skipped_count": tools_skipped,
        "note": "Token usage is tracked by the MCP client UI; enable fewer tools to reduce usage if needed.",
    }


# =============================================================================
# MCP Tools - ServiceNow Data Reading Operations
# =============================================================================

PRIORITY_KEYWORDS: dict[str, set[str]] = {
    "1": {"critical", "p1", "sev1", "sev 1", "priority 1"},
    "2": {"high", "p2", "sev2", "sev 2", "priority 2"},
    "3": {"medium", "moderate", "p3", "priority 3"},
    "4": {"low", "p4", "priority 4"},
    "5": {"planning", "p5", "priority 5"},
}

STATE_PATTERNS: dict[str, str] = {
    "in progress": "state=2",
    "on hold": "state=3",
    "resolved": "state=6",
    "closed": "state=7",
    "new": "state=1",
    "open": "stateIN1,2,3",
}

TIME_PATTERNS: list[tuple[str, str, tuple[str, ...]]] = [
    ("last month", "opened_at>=javascript:gs.daysAgoStart(30)", ("last", "month")),
    ("last week", "opened_at>=javascript:gs.daysAgoStart(7)", ("last", "week")),
    ("yesterday", "opened_at>=javascript:gs.daysAgoStart(1)", ("yesterday",)),
    ("today", "opened_at>=javascript:gs.daysAgoStart(0)", ("today",)),
]

CATEGORY_MAP: dict[str, set[str]] = {
    "network": {"network", "wifi", "lan", "vpn"},
    "email": {"email", "mail", "outlook"},
    "hardware": {"hardware", "laptop", "desktop", "device"},
    "software": {"software", "application", "app"},
    "database": {"database", "db"},
}

STOPWORDS: set[str] = {
    "find",
    "show",
    "me",
    "the",
    "an",
    "a",
    "incidents",
    "incident",
    "issues",
    "tickets",
    "from",
    "last",
    "week",
    "month",
    "today",
    "yesterday",
    "high",
    "critical",
    "low",
    "medium",
    "priority",
    "p1",
    "p2",
    "p3",
    "p4",
    "p5",
    "sev1",
    "sev2",
    "sev3",
    "sev4",
    "sev5",
    "open",
    "closed",
    "resolved",
    "new",
    "in",
    "progress",
    "for",
    "with",
    "and",
    "to",
    "of",
    "on",
    "are",
    "is",
    "opened",
    "showing",
    "search",
    "need",
    "all",
    "that",
    "which",
    "please",
}


def _contains_phrase(text: str, phrase: str) -> bool:
    pattern = r"\b" + re.escape(phrase) + r"\b"
    return re.search(pattern, text) is not None


def _mark_consumed(consumed: set[str], *phrases: str) -> None:
    for phrase in phrases:
        for token in re.findall(r"[a-z0-9]+", phrase):
            consumed.add(token)


BASE_PATH = Path(__file__).resolve().parent.parent.parent

EXTENDED_ACCESS_ENV_VAR = "SERVICENOW_MCP_EXTENDED_ACCESS"

ALLOW_LIST = [
    "incident",
    "problem",
    "change_request",
    "cmdb_ci",
    "cmdb_ci_service",
    "cmdb_ci_application",
    "alm_asset",
    "sys_user",
    "sys_user_group",
    "sc_request",
    "service_offering",
    "task",
    "cmdb_rel_ci",
    "cmdb_model",
    "sys_choice",
    "sys_dictionary",
    "sys_db_object",
]

BLACKLIST = ["sys_audit", "sys_email", "syslog"]

TOOL_MANIFEST: Dict[str, List[str]] = {
    "Data Access": [
        "query_table_records",
        "count_table_records",
        "list_tables_and_fields",
        "get_table_description",
    ],
    "CSDM 5.0 Compliance": [
        "analyze_ci_completeness",
        "assess_relationship_coverage",
        "identify_domain_gaps",
        "audit_identify_stale_cis",
        "audit_duplicate_cis",
        "audit_calculate_cmdb_health_score",
        "audit_validate_relationship_integrity",
        "audit_data_ownership_assignment",
        "audit_discovery_coverage_gaps",
        "audit_orchestrate_ci_validation_flow",
        "calculate_csdm_maturity_score",
        "analyze_tagging_compliance",
        "analyze_service_mappings",
    ],
    "Incident Management": [
        "search_incidents",
        "get_incident_details",
        "create_incident",
        "update_incident",
        "add_comment_to_incident",
        "search_assignment_groups",
        "search_users",
        "find_similar_incidents",
    ],
    "Diagnostics": [
        "test_servicenow_connection",
    ]
}


def _load_extended_access_flag() -> bool:
    """Load the extended access setting from environment or optional config."""
    raw_env = os.getenv(EXTENDED_ACCESS_ENV_VAR)
    truthy = {"1", "true", "yes", "on"}
    falsy = {"0", "false", "no", "off"}
    if raw_env is not None:
        value = raw_env.strip().lower()
        if value in truthy:
            return True
        if value in falsy:
            return False

    config_path = BASE_PATH / "config.yaml"
    if not config_path.exists():
        return False

    try:
        import yaml  # type: ignore[import]
    except ImportError:
        return False

    try:
        with config_path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle)
    except Exception:  # pragma: no cover - defensive parsing
        return False

    if isinstance(data, Mapping):
        raw_config = data.get("extended_access")
        if isinstance(raw_config, bool):
            return raw_config
        if isinstance(raw_config, str):
            return raw_config.strip().lower() in truthy

    return False


EXTENDED_ACCESS_ENABLED = _load_extended_access_flag()


def _get_app_context(ctx: Context) -> AppContext:
    """Resolve the AppContext from the underlying lifespan context."""
    lifespan_context = ctx.request_context.lifespan_context
    if not isinstance(lifespan_context, AppContext):
        msg = f"Unexpected lifespan context: {type(lifespan_context)!r}"
        raise RuntimeError(msg)
    return lifespan_context


def _get_servicenow_client(ctx: Context) -> ServiceNowClient:
    """Return the ServiceNow client for the current request."""
    return _get_app_context(ctx).servicenow


def _normalize_table_name(table: str) -> str:
    """Return a cleaned, lower-cased table name or raise if invalid."""
    normalized = str(table or "").strip()
    if not normalized:
        raise ValueError("Table name is required.")
    return normalized.lower()


def _is_prefix_match(name: str, candidate: str) -> bool:
    """Return True if name matches candidate or candidate prefix."""
    if name == candidate:
        return True
    return name.startswith(f"{candidate}_")


def _check_table_access(table: str) -> str:
    """
    Validate that the requested table can be queried under the current access policy.

    Raises:
        PermissionError: If the table is not permitted given the current mode.
    """
    normalized = _normalize_table_name(table)

    for denied in BLACKLIST:
        denied_normalized = denied.lower()
        if _is_prefix_match(normalized, denied_normalized):
            raise PermissionError(
                f"Access to table '{table}' is blocked by the ServiceNow MCP blacklist."
            )

    if EXTENDED_ACCESS_ENABLED:
        return normalized

    for allowed in ALLOW_LIST:
        allowed_normalized = allowed.lower()
        if _is_prefix_match(normalized, allowed_normalized):
            return normalized

    raise PermissionError(
        f"Table '{table}' is not permitted. Enable extended access or add it to the allow list."
    )


# ============================================================================
# Tool Execution Helpers
# ============================================================================


async def _run_tool(
    ctx: Context,
    tool_name: str,
    impl_fn: Callable,
    *,
    check_table: Optional[str] = None,
    timeout: Optional[float] = None,
    credit_cost: Optional[int] = None,
    **impl_kwargs: Any,
) -> Any:
    """Standardized tool execution with timing, logging, and error handling.

    All tools use this helper to:
    - Extract the ServiceNow client from MCP context
    - Optionally validate table access
    - Optionally enforce credit checks (for write tools returning str)
    - Time the execution
    - Log results to stderr
    - Handle errors consistently (log + re-raise)

    For dict-returning write tools, use _run_action_tool instead (returns
    error dicts). For str-returning write tools (ITSM), pass credit_cost
    here — insufficient credits raises PermissionError.
    """
    start = time.perf_counter()

    # Pre-execution credit check (for str-returning write tools)
    if credit_cost is not None:
        validation = await validate_subscription(credit_cost)
        if not validation["success"]:
            remaining = validation.get("credits_remaining", 0)
            raise PermissionError(
                f"Insufficient credits for {tool_name}. "
                f"Required: {credit_cost}, Available: {remaining}. "
                f"Upgrade at https://nexecute.ai/pricing"
            )

    client = _get_servicenow_client(ctx)

    if check_table and check_table in impl_kwargs:
        impl_kwargs[check_table] = _check_table_access(impl_kwargs[check_table])

    try:
        if timeout:
            result = await asyncio.wait_for(
                impl_fn(client=client, **impl_kwargs),
                timeout=timeout,
            )
        else:
            result = await impl_fn(client=client, **impl_kwargs)
    except asyncio.TimeoutError:
        duration = time.perf_counter() - start
        print(
            f"[ERROR] {tool_name} timed out after {duration:.3f}s",
            file=sys.stderr,
        )
        raise
    except Exception as e:
        duration = time.perf_counter() - start
        print(
            f"[ERROR] {tool_name} failed after {duration:.3f}s: {e}",
            file=sys.stderr,
        )
        traceback.print_exc(file=sys.stderr)
        raise

    duration = time.perf_counter() - start
    print(f"[Tool] {tool_name} duration={duration:.3f}s", file=sys.stderr)

    # Post-execution credit deduction (only on success)
    if credit_cost is not None:
        deduction = await deduct_credits(credit_cost, tool_name)
        print(
            f"[Credits] {tool_name} deducted {credit_cost} credit(s), "
            f"remaining: {deduction.get('credits_remaining', '?')}",
            file=sys.stderr,
        )

    return result


async def _run_action_tool(
    ctx: Context,
    tool_name: str,
    impl_fn: Callable,
    *,
    credit_cost: int,
    check_table: Optional[str] = None,
    **impl_kwargs: Any,
) -> Dict[str, Any]:
    """Standardized action tool execution with credit validation and deduction.

    Wraps _run_tool with pre-execution credit check and post-execution deduction.
    Returns an error dict (not an exception) when credits are insufficient,
    since this is expected business logic.
    """
    validation = await validate_subscription(credit_cost)
    if not validation["success"]:
        return {
            "status": "error",
            "error": (
                f"Insufficient credits. Required: {credit_cost}, "
                f"Available: {validation.get('credits_remaining', 0)}"
            ),
            "upgrade_url": "https://nexecute.ai/pricing",
            "credits_required": credit_cost,
            "credits_remaining": validation.get("credits_remaining", 0),
        }

    result = await _run_tool(
        ctx, tool_name, impl_fn, check_table=check_table, **impl_kwargs
    )

    if isinstance(result, dict) and result.get("status") == "success":
        deduction = await deduct_credits(credit_cost, tool_name)
        result["credits_used"] = credit_cost
        result["credits_remaining"] = deduction.get("credits_remaining", 0)

        # Invalidate audit cache for affected tables so subsequent audits
        # re-query ServiceNow instead of returning stale cached results.
        from servicenow_mcp.tools.cmdb.audit.utils import invalidate_audit_cache

        affected_table = (
            impl_kwargs.get("table_name")
            or impl_kwargs.get("ci_class")
            or impl_kwargs.get("ci_table")
            or ""
        )
        if affected_table:
            evicted = invalidate_audit_cache(affected_table)
            if evicted:
                print(
                    f"[Cache] Invalidated {evicted} cached audit(s) for {affected_table}",
                    file=sys.stderr,
                )

    return result


@mcp.tool()
async def query_table_records(
    ctx: Context,
    table: str,
    query: str = "",
    fields: Optional[List[str]] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Query arbitrary ServiceNow table with sysparm_query and return records."""
    return await _run_tool(
        ctx, "query_table_records", query_table_records_impl,
        check_table="table_name",
        table=table_name,
        query=query,
        fields=fields,
        limit=limit,
    )


@mcp.tool()
async def audit_count_table_records(ctx: Context, table: str, query: str = "") -> int:
    """Return the total count of records in a table matching the query."""
    return await _run_tool(
        ctx, "audit_count_table_records", count_table_records_impl,
        check_table="table_name",
        table=table_name,
        query=query,
    )


@mcp.tool()
async def list_tables_and_fields(
    ctx: Context,
    pattern: Optional[str] = None,
) -> Dict[str, Any]:
    """List available tables and their fields (optionally filtered by name pattern).

    OPTIMIZED for large result sets:
    - Limits to 15 tables when pattern matches many
    - Limits to 25 fields per table (prioritizes key fields)
    - Returns summary view for large datasets
    """
    return await _run_tool(ctx, "list_tables_and_fields", list_tables_and_fields_impl, pattern=pattern)


@mcp.tool()
async def audit_analyze_cmdb_health(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Unified CMDB health analysis: completeness + correctness + compliance.

    Single source of truth for CMDB quality assessment covering:
    - Completeness: Required and recommended field population
    - Correctness: Data quality issues (duplicates, stale, orphan relationships)
    - Compliance: CSDM 5.0 alignment

    WHEN TO USE:
    - "What's the health of our cmdb_ci_server table?"
    - "Show me completeness, correctness, and compliance scores"
    - "What's our overall CMDB health?"

    CSDM PHASE: CONSUME (quality assessment & governance)

    AUDIT LEVELS:
    - quick: $0.10 - Health score only
    - standard: $0.30 - Score + top issues (RECOMMENDED)
    - deep: $0.80 - Full analysis with all metrics and recommendations

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes domain.
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - health_score: Overall CMDB health (0-100)
        - health_grade: Letter grade (A-F)
        - completeness: Score, grade, gaps, and recommendations
        - correctness: Score, grade, data quality issues, and recommendations
        - compliance: Score, grade, CSDM alignment, and recommendations
        - total_cis: Count of CIs analyzed
        - audit_metadata: Cost and coverage information
    """
    return await _run_tool(
        ctx, "audit_analyze_cmdb_health", analyze_cmdb_health_impl,
        ci_class=ci_class,
        ci_table=ci_class,
        domain=domain,
        audit_level=audit_level,
    )

@mcp.tool()
async def audit_ci_mandatory_fields_compliance(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_optional_fields: bool = False,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit mandatory field compliance across CMDB CIs - Foundation for governance.

    Identifies CIs missing CSDM-required fields and generates weighted completeness
    scores. This is the foundation tool for all compliance scoring, policy violation
    detection, and data quality KPIs.

    **ENTERPRISE VALUE:**
    - Enables data completeness KPI for CIOs
    - Generates field gap reports for CMDB cleanup
    - Feeds compliance scorecards (GDPR, DORA, SOX)
    - Prioritizes remediation by field criticality

    **SCORING ALGORITHM:**
    - Critical fields (CSDM required): 10 points each
    - Important fields (recommended): 5 points each
    - Optional fields: 1 point each
    - Overall score: (earned_points / possible_points) * 100
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)

    WHEN TO USE:
    - "What fields are missing from our servers?"
    - "Show me field completeness by CI class"
    - "Which CIs are missing critical owner assignments?"
    - "Generate a data quality report for executives"

    CSDM PHASE: FOUNDATION (data quality governance)

    AUDIT LEVELS:
    - quick: $0.10 - Sample-based analysis (100 CIs)
    - standard: $0.30 - Full scan with gap analysis (RECOMMENDED)
    - deep: $0.80 - Full scan + detailed recommendations + automation opportunities

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server'). If None, audits domain.
        domain: CSDM domain filter (e.g., 'Foundation', 'Manage Infrastructure')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_optional_fields: If True, includes optional field analysis (slower)
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - overall_compliance_score: Weighted completeness percentage (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs audited
        - field_gaps: Detailed gap analysis by field (required + optional)
        - by_ci_class: Breakdown by CI class (if domain-level audit)
        - critical_missing_cis: List of CIs missing critical fields (top 100)
        - remediation_priority: Ordered list of fields to fix first
        - scoring_details: Field weights and point calculations
        - recommendations: (deep only) Automation opportunities and initiatives
    """
    return await _run_tool(
        ctx, "audit_ci_mandatory_fields_compliance", audit_ci_mandatory_fields_compliance_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_optional_fields=include_optional_fields,
        sample_limit=sample_limit,
    )

@mcp.tool()
async def audit_ci_duplicate_merge_confidence(
    ctx: Context,
    ci_sys_id_1: str,
    ci_sys_id_2: str,
    include_recommendations: bool = True,
) -> Dict[str, Any]:
    """
    Score merge confidence for two potentially duplicate CIs - AI-driven merge intelligence.

    Analyzes two CIs and calculates a confidence score (0-100) indicating how safe it is
    to merge them. Uses AI-driven similarity analysis including exact field matches,
    fuzzy string matching (Levenshtein distance), relationship overlap, and risk detection.

    **ENTERPRISE VALUE:**
    - Reduces duplicate CI cleanup time by 70%
    - Prevents data loss from incorrect merges
    - Enables automated merge workflows with confidence thresholds
    - Provides clear merge recommendations with risk warnings

    **AI-DRIVEN SCORING ALGORITHM:**
    - Exact field matches: serial_number (+40pts), hostname (+20pts), IP address (+15pts)
    - Fuzzy matching: Levenshtein distance for names (+10-20pts based on similarity)
    - Relationship overlap: Shared parent/child connections (+20pts if >50% overlap)
    - Risk penalties: Critical -20pts, High -10pts, Medium -5pts
    - Final score: Capped at 100, graded as High (90+), Medium (70-89), Low (<70)

    **RISK FACTORS DETECTED:**
    - Different asset tags (possible misidentification)
    - Different owners (merge requires approval)
    - Asymmetric relationships (potential data loss)
    - Different operational status (production vs decommissioned)
    - Different locations (physical asset mismatch)

    WHEN TO USE:
    - "Should I merge these two server CIs?"
    - "What's the confidence score for merging CI abc123 and xyz789?"
    - "Analyze merge safety before deduplication"
    - "Identify high-confidence merge candidates"

    CSDM PHASE: FOUNDATION (data quality governance & deduplication)

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_sys_id_1: sys_id of first CI to compare
        ci_sys_id_2: sys_id of second CI to compare
        include_recommendations: If True, includes merge strategy recommendations (default: True)

    Returns:
        - confidence_score: Merge confidence (0-100)
        - grade: High (90+), Medium (70-89), Low (<70)
        - match_details: Breakdown of scoring factors
          - exact_matches: Fields with identical values (field, value, points)
          - fuzzy_matches: Fields with similar values (field, similarity %, points)
          - relationship_overlap: Shared connections analysis
        - risk_factors: List of detected risks (severity, description, impact)
        - merge_recommendation: Recommended action (auto_merge, review_merge, manual_review)
        - merge_strategy: Suggested merge approach if confidence >= 70
        - field_conflicts: Fields with different values requiring resolution
        - total_points_earned: Raw score before capping
        - max_possible_points: Maximum achievable score

    EXAMPLE OUTPUT:
        "Confidence: 92/100 (High). Exact matches: serial_number, hostname, IP.
         Fuzzy: name 95% similar. Relationship overlap: 8/10 shared (80%).
         Risks: Different owners (requires approval). Recommendation: Review merge.
         Strategy: Keep CI 1 (newer), merge relationships from CI 2."
    """
    return await _run_tool(
        ctx, "audit_ci_duplicate_merge_confidence", audit_ci_duplicate_merge_confidence_impl,
        ci_sys_id_1=ci_sys_id_1,
        ci_sys_id_2=ci_sys_id_2,
        include_recommendations=include_recommendations,
    )

@mcp.tool()
async def audit_ci_policy_violation_score(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_remediation_plan: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit governance policy violations across CMDB CIs - Compliance validator.

    Detects and scores policy violations across five critical governance categories:
    1. Missing business context (owner, support group, criticality, cost center)
    2. Environment misclassification (prod CIs with low criticality, retired status)
    3. Naming convention violations (non-standard formats)
    4. Data quality gaps (stale discovery, missing audit trail)
    5. Compliance gaps (missing security classifications for GDPR/SOX)

    **ENTERPRISE VALUE:**
    - Enables policy compliance KPIs for CIOs and governance boards
    - Generates violation reports for SOX/DORA/GDPR audits
    - Prioritizes remediation by business risk and severity
    - Reduces compliance exceptions by 60% through automated detection
    - Feeds executive compliance scorecards

    **VIOLATION SCORING ALGORITHM:**
    - Start at 100 points (perfect compliance)
    - Critical violations: -10 points each (owner, support group, security classification)
    - High violations: -5 points each (environment misclassification, stale data >90 days)
    - Medium violations: -2 points each (naming conventions, missing audit trail)
    - Low violations: -1 point each (minor data quality issues)
    - Final score: Minimum 0 (cannot go negative)
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)

    **VIOLATION CATEGORIES DETECTED:**

    1. **Missing Business Context** (Critical/High):
       - No owner assigned → Cannot determine accountability
       - No support group → SLA enforcement impossible
       - No business criticality → Incorrect incident prioritization
       - No cost center → Budget allocation tracking fails

    2. **Environment Misclassification** (High):
       - Production CIs marked as low/medium criticality
       - Active production CIs marked as retired/disposed
       - Critical systems in dev/test environments

    3. **Naming Convention Violations** (Medium):
       - Server names not matching: env-type-function-number (e.g., prd-app-web-001)
       - Application names not matching: PREFIX_ApplicationName (e.g., ERP_Salesforce)
       - Database names not matching: env-db-type-number (e.g., prd-db-oracle-001)

    4. **Data Quality Gaps** (High/Medium):
       - CIs not discovered in >90 days (stale data)
       - Never discovered CIs (manual entries with no validation)
       - Missing audit trail (sys_updated_by empty or "system")

    5. **Compliance Gaps** (Critical):
       - Missing security classification on servers/databases (GDPR/SOX violation)
       - No data sensitivity tags (cannot enforce data protection policies)

    WHEN TO USE:
    - "What policy violations exist in our CMDB?"
    - "Show me CIs missing owners or support groups"
    - "Which production CIs have incorrect criticality levels?"
    - "Generate a governance compliance report for SOX audit"
    - "Identify naming convention violations for cleanup"

    CSDM PHASE: FOUNDATION (governance & compliance validation)

    AUDIT LEVELS:
    - quick: $0.10 - Sample 100 CIs, violation counts only
    - standard: $0.30 - Full scan with top 50 violations (RECOMMENDED)
    - deep: $0.80 - Full scan with detailed remediation plan (top 200 violations)

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server'). Default: cmdb_ci_server
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_remediation_plan: Include prioritized remediation recommendations (default: True)
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - policy_violation_score: Overall compliance score (0-100)
        - grade: Letter grade (A-F)
        - total_violations: Total violation count across all categories
        - total_cis: Total CIs scanned
        - cis_with_violations: Count of CIs with at least one violation
        - violation_rate: Percentage of CIs with violations
        - violations_by_severity: Breakdown by critical/high/medium/low
        - points_deducted: Points lost per severity level
        - violations_by_type: Breakdown by violation category
        - top_violations: Top violations sorted by severity (50 for standard, 200 for deep)
        - remediation_priority: Ordered remediation plan (if include_remediation_plan=True)
          - priority: Severity order (0=critical, 1=high, 2=medium, 3=low)
          - violation_type: Category name
          - count: Number of violations in this category
          - affected_fields: List of fields with violations
          - recommended_action: Specific remediation guidance
          - sample_violations: Example violations (2 for standard, 5 for deep)
          - estimated_effort: Effort estimate (Low/Medium/High/Very High)
        - audit_metadata: Execution details and coverage

    EXAMPLE OUTPUT:
        "Policy Score: 52/100 (Grade D). Total: 127 violations across 85 CIs (violation rate: 85%).
         Critical: 18 (missing owners), High: 45 (prod CIs low criticality), Medium: 52 (naming),
         Low: 12 (stale data). Top priority: Fix 18 CIs missing owners (URGENT).
         Remediation: Bulk update owners → Review criticality → Standardize naming."
    """
    return await _run_tool(
        ctx, "audit_ci_policy_violation_score", audit_ci_policy_violation_score_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_remediation_plan=include_remediation_plan,
        sample_limit=sample_limit,
    )

@mcp.tool()
async def audit_ci_retention_flags(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_deletion_candidates: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit CI retention flags and data retention policy compliance - Compliance validator.

    Flags CIs for retention or deletion based on compliance requirements, age, staleness,
    and business criticality. Implements SOX, GDPR, and DORA data retention policies
    with built-in safety checks to prevent accidental deletion of critical systems.

    **ENTERPRISE VALUE:**
    - Enables GDPR/SOX/DORA data retention compliance (critical for audits)
    - Reduces CMDB storage costs by 40% through automated cleanup
    - Prevents accidental deletion of critical production systems
    - Generates retention audit reports for compliance officers
    - Automates retention policy enforcement across 1000s of CIs

    **RETENTION POLICY FRAMEWORK:**

    1. **SOX Compliance** (7-year retention):
       - Applies to: Financial systems, ERP, accounting, audit trails
       - Keywords: financial, erp, accounting, sox, audit
       - Rationale: Sarbanes-Oxley requires 7-year financial record retention

    2. **DORA Compliance** (5-year retention):
       - Applies to: ICT systems, operational resilience, incident management
       - Keywords: incident, security, ict, operational, dora
       - Rationale: Digital Operational Resilience Act requires 5-year retention

    3. **GDPR Compliance** (3-year retention):
       - Applies to: Systems with PII, customer data, HR data
       - Keywords: pii, customer, hr, gdpr, personal
       - Rationale: GDPR requires deletion after 3 years unless legitimate business need

    4. **General Business Records** (3-year retention):
       - Default policy for all other systems
       - Standard business record retention period

    5. **Critical System Exemption** (Permanent retention):
       - Systems with Critical/High business criticality NEVER deleted
       - Protection override regardless of age or status

    **DELETION ELIGIBILITY RULES:**

    A CI can be deleted if ALL of the following are true:
    - Status: Retired/Decommissioned/Disposed (not active)
    - Age: Retention period has expired (e.g., >7 years for SOX systems)
    - Criticality: NOT critical or high (safety protection)
    - Compliance: All regulatory retention requirements satisfied

    Alternative deletion path (stale CIs):
    - Not discovered in >90 days (production) or >180 days (non-production)
    - AND not critical/high criticality
    - Flagged with medium severity warning for manual verification

    **SAFETY CHECKS (Prevents Data Loss):**
    - Critical severity: Never delete critical/high criticality systems
    - High severity: Never delete active systems (Installed, In Use, In Maintenance)
    - Medium severity: Warn on stale CI deletion (verify CI is truly decommissioned)
    - Safety violation tracking: Count of protected systems incorrectly flagged

    **RETENTION COMPLIANCE SCORING:**
    - Start at 100 points (perfect compliance)
    - Safety violations: -20 points each (critical systems flagged for deletion)
    - Low classification rate: Deduct (80 - classification_rate) points
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)

    WHEN TO USE:
    - "Which CIs can be safely deleted to reduce storage costs?"
    - "What's our data retention policy compliance rate?"
    - "Show me CIs past their SOX/GDPR/DORA retention period"
    - "Flag decommissioned systems for cleanup (protect critical systems)"
    - "Generate a data retention audit report for compliance review"

    CSDM PHASE: FOUNDATION (data governance & compliance)

    AUDIT LEVELS:
    - quick: $0.10 - Sample 100 CIs, retention summary only
    - standard: $0.30 - Full scan with top 50 deletion candidates (RECOMMENDED)
    - deep: $0.80 - Full scan with all deletion candidates + protected systems analysis

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server'). Default: cmdb_ci_server
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_deletion_candidates: Include list of deletion candidates (default: True)
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - retention_compliance_score: Overall compliance (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs scanned
        - flagged_for_deletion: Count of deletion-eligible CIs
        - flagged_for_retention: Count of CIs requiring retention
        - protected_systems: Count of critical/active CIs protected from deletion
        - safety_violations: Count of protected systems incorrectly flagged
        - classification_rate: % of CIs with retention classification
        - retention_breakdown: CIs by retention period
          - 1_year: Count
          - 3_year: Count (GDPR, General)
          - 5_year: Count (DORA)
          - 7_year: Count (SOX)
          - permanent: Count (Critical systems)
        - compliance_framework_breakdown: CIs by compliance requirement
          - SOX: Count
          - GDPR: Count
          - DORA: Count
          - General: Count
          - Critical System Exemption: Count
        - deletion_candidates: List of CIs eligible for deletion (if requested)
          - ci_name: CI name
          - ci_sys_id: sys_id
          - install_status: Current status
          - retention_period: Required retention (1yr/3yr/5yr/7yr/permanent)
          - compliance_framework: Which framework applies
          - reason: Why eligible for deletion
          - retirement_age_days: Days since retirement
          - days_past_retention: Days beyond retention period
          - safety_flags: Any warnings (e.g., stale CI verification needed)
        - protected_systems_sample: Sample of protected CIs (deep audit only)
        - audit_metadata: Execution details and coverage

    EXAMPLE OUTPUT:
        "Retention Score: 85/100 (Grade B). Total: 500 CIs scanned.
         Deletion candidates: 45 CIs past retention (average 180 days overdue).
         Retention required: 455 CIs (120 SOX 7yr, 280 GDPR 3yr, 55 permanent critical).
         Protected: 55 critical systems (never delete). No safety violations detected.
         Storage savings: ~9% CMDB reduction through safe cleanup."
    """
    return await _run_tool(
        ctx, "audit_ci_retention_flags", audit_ci_retention_flags_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_deletion_candidates=include_deletion_candidates,
        sample_limit=sample_limit,
    )

@mcp.tool()
async def audit_ci_confidentiality_tags(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_remediation_plan: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit data classification tags for GDPR/DORA compliance - Final compliance validator.

    Detects and validates data classification across six sensitivity levels (PII, PHI, PCI,
    Confidential, Internal, Public) to ensure GDPR Article 30 compliance and DORA ICT
    risk classification requirements. Prevents data breach penalties through automated
    classification gap detection.

    **ENTERPRISE VALUE:**
    - Enables GDPR Article 30 compliance (data processing registry requirement)
    - Supports DORA ICT risk classification requirements (mandatory for EU financial institutions)
    - Prevents data breach penalties: €20M or 4% annual revenue under GDPR
    - Generates data classification audit reports for Data Protection Officers (DPOs)
    - Automates security posture assessment across 1000s of infrastructure assets
    - Reduces manual classification effort by 80% through AI-driven detection

    **DATA CLASSIFICATION LEVELS (Hierarchical):**

    1. **PII - Personally Identifiable Information** (Level 5):
       - Protected under GDPR Article 4
       - Keywords: pii, personal, gdpr, customer, employee, user, contact
       - Retention: 3 years (GDPR default)
       - Penalty for breach: Up to €20M or 4% revenue

    2. **PHI - Protected Health Information** (Level 5):
       - Protected under HIPAA and GDPR Article 9 (special category)
       - Keywords: phi, health, medical, patient, hipaa, clinical
       - Retention: 7 years (HIPAA default)
       - Penalty for breach: Up to $1.5M per year (HIPAA) + GDPR fines

    3. **PCI - Payment Card Industry Data** (Level 5):
       - Protected under PCI-DSS
       - Keywords: pci, payment, card, credit, transaction, billing
       - Retention: 7 years (PCI-DSS Requirement 3.1)
       - Penalty for breach: Card brand fines + liability for fraud

    4. **Confidential - Sensitive Business Data** (Level 4):
       - Internal use only, proprietary information
       - Keywords: confidential, sensitive, proprietary, trade secret, intellectual property
       - Compliance: DORA, SOX
       - Retention: 7 years

    5. **Internal - Business Operational Data** (Level 3):
       - Internal business data, not for public disclosure
       - Keywords: internal, business, operational, finance, hr
       - Compliance: DORA
       - Retention: 3 years

    6. **Public - No Restrictions** (Level 1):
       - Public information, no sensitivity
       - Keywords: public, marketing, website, press, external
       - No compliance requirements
       - Retention: 1 year

    **CLASSIFICATION DETECTION ALGORITHM:**
    - Keyword scanning: Analyzes CI name, class, description, environment
    - Confidence scoring: 30% per keyword matched, max 100%
    - Multi-match resolution: Highest sensitivity level wins
    - Default fallback: Infrastructure (servers/databases) → Internal, Applications → Public
    - Validation: Compares assigned tag vs AI-detected classification

    **CLASSIFICATION ISSUES DETECTED:**

    1. **Missing Classification** (Critical/High Severity):
       - No u_data_classification or u_security_classification field
       - Severity: Critical for PII/PHI (GDPR violation), High for others
       - Impact: Cannot demonstrate GDPR Article 30 compliance
       - Penalty: -5 points per missing classification

    2. **Under-Classification** (Critical Severity):
       - PII data marked as Public/Internal (data exposure risk)
       - PHI data marked as Confidential (insufficient protection)
       - PCI data marked as Internal (PCI-DSS violation)
       - Impact: Data breach risk, regulatory penalties, reputational damage
       - Penalty: -10 points per under-classification (highest severity)

    3. **Over-Classification** (Medium Severity):
       - Public data marked as Confidential (operational overhead)
       - Internal data marked as PII (unnecessary restrictions)
       - Impact: Reduced productivity, excessive access controls
       - Penalty: -2 points per over-classification

    4. **Invalid Classification** (High Severity):
       - Non-standard classification values (e.g., "super secret", "restricted")
       - Cannot enforce policy or audit compliance
       - Penalty: Counted as missing classification

    **GDPR COMPLIANCE SCORING (Article 30):**
    - Requirement: Maintain records of processing activities for personal data
    - Score: 100% if all PII/PHI systems properly classified
    - Deduct: Under-classified PII/PHI (critical GDPR violation)
    - Threshold: 90% for compliance
    - Output: gdpr_compliance_score, gdpr_compliant (bool), reasoning

    **DORA COMPLIANCE SCORING (ICT Risk Classification):**
    - Requirement: Classify ICT systems by criticality and data sensitivity
    - Score: 100% if all operational/financial systems classified
    - Deduct: Missing classifications on Confidential/Internal/PCI systems
    - Threshold: 90% for compliance
    - Output: dora_compliance_score, dora_compliant (bool), reasoning

    **CONFIDENTIALITY SCORING ALGORITHM:**
    - Start at 100 points (perfect classification)
    - Missing classification: -5 points each
    - Under-classification: -10 points each (critical - data breach risk)
    - Over-classification: -2 points each (medium - operational overhead)
    - Final score: Minimum 0 (cannot go negative)
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)

    WHEN TO USE:
    - "Which systems are missing data classification tags?"
    - "Are we GDPR Article 30 compliant with data classification?"
    - "Show me under-classified PII/PHI systems (critical data breach risk)"
    - "Audit DORA ICT risk classification compliance for financial systems"
    - "Generate data classification report for Data Protection Officer review"
    - "Which CIs have PII/PHI but aren't tagged correctly?"

    CSDM PHASE: FOUNDATION (data governance & compliance)

    AUDIT LEVELS:
    - quick: $0.10 - Sample 100 CIs, classification summary only
    - standard: $0.30 - Full scan with top 50 issues (RECOMMENDED)
    - deep: $0.80 - Full scan with detailed remediation plan (top 200 issues)

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server'). Default: cmdb_ci_server
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_remediation_plan: Include prioritized remediation recommendations (default: True)
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - confidentiality_score: Overall classification compliance (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs scanned
        - properly_classified: Count of correctly classified CIs
        - missing_classification: Count of untagged CIs
        - over_classified: Count of over-classified CIs (operational overhead)
        - under_classified: Count of under-classified CIs (CRITICAL - data breach risk)
        - invalid_classification: Count of CIs with non-standard classification values
        - classification_rate: % of CIs with classification tags
        - classification_breakdown: CIs by classification level
          - pii: Count (GDPR protected)
          - phi: Count (HIPAA/GDPR protected)
          - pci: Count (PCI-DSS protected)
          - confidential: Count (DORA/SOX protected)
          - internal: Count (DORA protected)
          - public: Count (No restrictions)
          - unclassified: Count (Compliance violation)
        - gdpr_compliance: GDPR Article 30 compliance analysis
          - gdpr_compliance_score: Score (0-100)
          - gdpr_compliant: bool (>= 90% = compliant)
          - pii_phi_systems: Count of PII/PHI systems
          - properly_classified: Count properly tagged
          - under_classified: Count under-classified (critical)
          - reasoning: Explanation
        - dora_compliance: DORA ICT classification compliance
          - dora_compliance_score: Score (0-100)
          - dora_compliant: bool (>= 90% = compliant)
          - operational_systems: Count of operational systems
          - properly_classified: Count properly tagged
          - reasoning: Explanation
        - top_issues: Top classification issues sorted by severity
          - ci_name: CI name
          - ci_sys_id: sys_id
          - issue_type: missing/under/over/invalid classification
          - severity: critical/high/medium/low
          - description: Issue explanation
          - detected_classification: AI-detected classification
          - assigned_classification: Current tag value
          - confidence: Detection confidence (0-100)
          - keywords_matched: Keywords that triggered detection
        - remediation_priority: Ordered remediation plan (if requested)
          - priority: Severity order (0=critical, 1=high, 2=medium, 3=low)
          - severity: Severity level
          - issue_type: Category name
          - count: Number of issues in this category
          - recommended_action: Specific remediation guidance
          - sample_issues: Example issues (2 for standard, 5 for deep)
          - estimated_effort: Effort estimate (Low/Medium/High/Very High + URGENT)
        - audit_metadata: Execution details and coverage

    EXAMPLE OUTPUT:
        "Confidentiality Score: 65/100 (Grade D). Total: 500 CIs.
         CRITICAL: 12 under-classified PII systems (data breach risk).
         Missing classification: 95 CIs (19% untagged).
         GDPR Compliance: 78% (below 90% threshold - NOT COMPLIANT).
         DORA Compliance: 85% (below 90% threshold - NOT COMPLIANT).
         Top priority: Fix 12 under-classified PII systems URGENTLY.
         Remediation: Add classification tags → Fix under-classified PII → Review over-classified."
    """
    return await _run_tool(
        ctx, "audit_ci_confidentiality_tags", audit_ci_confidentiality_tags_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_remediation_plan=include_remediation_plan,
        sample_limit=sample_limit,
    )

@mcp.tool()
async def audit_analyze_ci_relationships(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_suggestions: bool = True,
) -> Dict[str, Any]:
    """
    Unified CI relationship analysis: coverage + classification + CSDM compliance.

    Deep-dive into relationship quality and topology covering:
    - Coverage: Percentage of CIs with relationships
    - Classification: Identify unclassified and non-CSDM relationships
    - CSDM Compliance: Validate against CSDM 5.0 relationship types
    - Suggestions: Recommend missing standard relationships

    WHEN TO USE:
    - "Analyze relationship coverage for cmdb_ci_server"
    - "What relationships are unclassified or non-compliant?"
    - "Show me the dependency topology"

    CSDM PHASE: CONSUME (relationship mapping & impact analysis)

    AUDIT LEVELS:
    - quick: $0.10 - Coverage metrics only
    - standard: $0.40 - Coverage + compliance + suggestions (RECOMMENDED)
    - deep: $1.20 - Full analysis with topology and all details

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes all.
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_suggestions: Whether to suggest relationship classifications (default: True)

    Returns (varies by audit level):
        - relationship_quality_score: Overall relationship health (0-100)
        - relationship_quality_grade: Letter grade (A-F)
        - coverage: CIs with relationships, total relationships, coverage percentage
        - relationship_types: Standard types used, expected types, missing types
        - compliance: Unclassified, orphan, CSDM-compliant counts
        - suggestions: Recommended relationship classifications
        - topology: Service topology and dependency patterns (standard/deep only)
        - recommendations: Actionable improvement steps
        - audit_metadata: Cost and coverage information
    """
    return await _run_tool(
        ctx, "audit_analyze_ci_relationships", analyze_ci_relationships_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_suggestions=include_suggestions,
    )

@mcp.tool()
async def audit_detect_anti_patterns(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Detect CMDB anti-patterns blocking CSDM compliance.

    Identifies non-normalized data structures preventing CSDM compliance:
    - Custom reference fields used instead of CSDM relationships
    - Non-standard CI classes not in CSDM 5.0
    - Missing CSDM-compliant linking patterns
    - Software CIs without proper model structure

    Directly addresses Reddit pain point:
    "Servers linked via custom reference fields, not relationships"

    WHEN TO USE:
    - "Detect what's preventing CSDM compliance in our CMDB"
    - "Find custom fields bypassing CSDM relationships"
    - "Show me anti-patterns blocking compliance"

    CSDM PHASE: CONSUME (compliance validation & remediation planning)

    AUDIT LEVELS:
    - quick: $0.15 - Pattern count only
    - standard: $0.50 - Patterns + examples (RECOMMENDED)
    - deep: $1.50 - Full analysis with all details and remediation steps

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes all.
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - total_anti_patterns_detected: Number of distinct patterns found
        - total_affected_cis: Count of CIs impacted by anti-patterns
        - severity: Overall severity level (Critical/High/Medium/Low)
        - anti_patterns: Details of each anti-pattern found
        - compliance_impact: Estimated impact on CSDM compliance score
        - remediation_priority: Ordered remediation recommendations
        - next_steps: Actionable remediation steps
        - audit_metadata: Cost and coverage information
    """
    return await _run_tool(
        ctx, "audit_detect_anti_patterns", detect_anti_patterns_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
    )

@mcp.tool()
async def audit_analyze_csdm_compliance(
    ctx: Context,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Comprehensive CSDM 5.0 maturity assessment.

    Validates CMDB against CSDM 5.0 standard across all compliance dimensions:
    - CI Class Compliance: Usage of CSDM-defined CI types (132+ types)
    - SBOM Coverage: Software Bill of Materials completeness
    - Service Instance Completeness: All 4 Service Instances present
    - Relationship Type Adoption: Use of CSDM standard relationships
    - Domain Separation: Proper domain structure and classification

    WHEN TO USE:
    - "What's our CSDM 5.0 compliance maturity?"
    - "Are we Bronze/Silver/Gold/Platinum compliant?"
    - "What's our SBOM coverage and Service Instance status?"

    CSDM PHASE: CONSUME (compliance assessment & maturity tracking)

    AUDIT LEVELS:
    - quick: $0.20 - Maturity score only
    - standard: $0.60 - Score + domain breakdown + top issues (RECOMMENDED)
    - deep: $1.80 - Full analysis with all metrics and remediation roadmap

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes all.
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - maturity_score: Overall CSDM maturity (0-100)
        - maturity_grade: Bronze/Silver/Gold/Platinum
        - ci_class_compliance: CSDM CI type coverage (132+ types)
        - sbom_coverage: Software Bill of Materials percentage
        - service_instance_completeness: All 4 Service Instances status
        - relationship_adoption: Standard relationship type usage percentage
        - domain_scores: Per-domain compliance breakdown
        - overall_assessment: Strengths, gaps, risk level
        - remediation_roadmap: Prioritized improvement actions (standard/deep only)
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Maturity: 68/100 (Silver grade). CI Compliance: 78%, SBOM: 45%,
         Service Instances: 50%, Relationships: 82%. High risk. Roadmap:
         1) Migrate 5 custom CI classes, 2) Add SBOM to 690 software CIs..."
    """
    return await _run_tool(
        ctx, "audit_analyze_csdm_compliance", analyze_csdm_compliance_impl,
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
    )

@mcp.tool()
async def audit_validate_model_hierarchy(
    ctx: Context,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Validate software model parent/child hierarchy and SBOM completeness.

    Validates software CI model structure covering:
    - Model Hierarchy: Parent/child relationship integrity
    - Empty Models: Software models with no instances
    - Orphan CIs: Software CIs without parent models
    - SBOM Completeness: Software Bill of Materials presence
    - Business Application Mapping: Model → Application linkage

    Directly addresses Reddit pain point:
    "Software models always empty" and "No version tracking"

    WHEN TO USE:
    - "Validate our software model structure and hierarchy"
    - "How many orphan software CIs do we have?"
    - "What's our SBOM coverage for software?"

    CSDM PHASE: CONSUME (model structure validation & completeness)

    AUDIT LEVELS:
    - quick: $0.15 - Hierarchy score only
    - standard: $0.50 - Score + issues + examples (RECOMMENDED)
    - deep: $1.50 - Full analysis with all metrics and remediation steps

    Args:
        ctx: Tool execution context with ServiceNow client
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - hierarchy_score: Overall model structure health (0-100)
        - hierarchy_grade: Letter grade (A-F)
        - total_models: Software models in system
        - total_software_cis: Software CI instances
        - empty_models: Models with no instances (count + examples)
        - orphan_cis: CIs without parent models (count + examples)
        - missing_sbom: CIs lacking Software Bill of Materials
        - business_application_mapping: Model → Application linkage coverage
        - overall_health: Model quality, SBOM status, BA mapping status
        - remediation_steps: Ordered improvement actions (standard/deep only)
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Model Hierarchy Score: 72/100 (C grade). Total: 1,250 models, 3,400 CIs.
         Issues: 340 empty models (27%), 250 orphan CIs (7%), 890 missing SBOM (62%).
         Critical: Link orphan CIs, clean empty models, implement SBOM tracking."
    """
    return await _run_tool(ctx, "audit_validate_model_hierarchy", validate_model_hierarchy_impl, domain=domain, audit_level=audit_level)

@mcp.tool()
async def audit_identify_domain_gaps(
    ctx: Context,
    domain: str,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """Aggregate completeness and relationship gaps for a CSDM domain."""
    return await _run_tool(
        ctx, "audit_identify_domain_gaps", identify_domain_gaps_impl,
        domain=domain,
        audit_level=audit_level,
        sanitize_table=_check_table_access,
    )


@mcp.tool()
async def audit_check_csdm_rules(
    ctx: Context,
) -> Dict[str, Any]:
    """
    Check and load CSDM 5.0 rules from configuration file.

    This tool explicitly verifies that CSDM rules are loaded and available
    for other tools to use. Run this before other tools to ensure CSDM
    intelligence is activated.

    WHEN TO USE:
    - "Check if CSDM rules are loaded"
    - "Verify CSDM configuration"
    - "Show me what CSDM rules we have"

    CSDM PHASE: DISCOVER (configuration validation)

    Returns:
        Dictionary containing:
        - rules_loaded: bool - Whether rules loaded successfully
        - csdm_file_path: str - Path to csdm_rules.json
        - file_size_kb: float - Size of rules file
        - domains_count: int - Number of CSDM domains
        - total_ci_classes: int - Total CI classes defined
        - relationship_types_count: int - Valid relationship types
        - domains: list - Details of each domain
        - ci_classes_by_domain: dict - CI classes grouped by domain
        - valid_relationship_types: list - All valid relationship types
        - status: success/error

    EXAMPLE OUTPUT:
        "✓ CSDM rules loaded successfully from data/csdm_rules.json
         - 2 domains (Foundation, Service)
         - 45 CI classes defined
         - 22 valid relationship types
         - File size: 53 KB"
    """
    return await _run_tool(ctx, "audit_check_csdm_rules", check_csdm_rules_impl)


@mcp.tool()
async def audit_identify_stale_cis(
    ctx: Context,
    ci_class: str,
    staleness_threshold_days: int = 60,
    include_details: bool = False,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Identify stale CIs that haven't been discovered or updated recently (Phase 3 Tool #2).

    This tool detects Configuration Items that lack recent discovery/update activity,
    indicating potential orphaned, decommissioned, or unmanaged assets. Uses multi-field
    timestamp fallback to maximize detection accuracy.

    CSDM PHASE: CONSUME (data quality assurance)

    Timestamp fallback logic (in order):
    1. last_discovered (primary ServiceNow discovery timestamp)
    2. last_reported (agent/probe last report time)
    3. sys_updated_on (record last modified)
    4. u_last_scan_date (custom scan timestamp, if present)

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: The CI class to analyze (e.g., 'cmdb_ci_server', 'cmdb_ci_computer')
        staleness_threshold_days: Days since last activity to consider stale (default: 60)
        include_details: Include full CI details in response (default: False for performance)

    Returns:
        Dictionary containing:
        - ci_class: The analyzed CI class
        - total_cis: Total CIs in the class
        - stale_count: Number of stale CIs identified
        - stale_percentage: Percentage of stale CIs
        - threshold_days: Threshold used for staleness
        - stale_cis: List of stale CI sys_ids (with details if include_details=True)
        - status: 'success' or 'error'

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 2,800 total CIs. 123 stale CIs (4.4%) not discovered in 60+ days."
    """
    return await _run_tool(
        ctx, "audit_identify_stale_cis", identify_stale_cis_impl,
        ci_class=ci_class,
        staleness_threshold_days=staleness_threshold_days,
        include_details=include_details,
        audit_level=audit_level,
    )


@mcp.tool()
async def audit_data_ownership_assignment(
    ctx: Context,
    ci_class: str,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_details: bool = True,
    details_limit: int = 50,
) -> Dict[str, Any]:
    """
    Audit data ownership assignment to identify orphaned CIs and ownership gaps (Critical PMF Gap Tool #1).

    Addresses #1 CMDB challenge: "Lack of data ownership is the #1 challenge organizations
    face in their data quality improvement endeavors" (Forrester research, 2024).

    CSDM PHASE: CONSUME (data governance & stewardship)

    ServiceNow Ownership Best Practices:
    - owned_by: Business owner responsible for CI data accuracy (PRIMARY)
    - managed_by: Operational owner managing CI from ops perspective
    - support_group: Incident handling team
    - assigned_to: End user (for devices only)

    This tool identifies:
    - **Orphaned CIs**: No owner assigned (any field)
    - **Ownership gaps**: Missing business or operational owners
    - **Ownership conflicts**: Unclear responsibility patterns (deep mode)
    - **Coverage metrics**: % of CIs with proper ownership

    AUDIT LEVELS:
    - quick: Summary only, no CI details (<1s execution)
    - standard: Top 50 orphaned CIs, check owned_by + managed_by (default)
    - deep: Top 100 CIs, check ALL ownership fields + conflict detection

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: The CI class to analyze (e.g., 'cmdb_ci_server', 'cmdb_ci_database')
        domain: Optional domain filter for multi-domain instances
        audit_level: Analysis depth ('quick', 'standard', 'deep')
        include_details: Include CI details in response (default: True, disabled in quick mode)
        details_limit: Max CIs to include in details (default: 50, deep: 100)

    Returns:
        Dictionary containing:
        - ownership_coverage_score: 0-100 score
        - ownership_grade: A-F letter grade
        - ci_class: CI class analyzed
        - total_cis: Total active CIs found
        - owned_cis: CIs with at least one ownership field populated
        - orphaned_cis: CIs with no owner assigned
        - orphaned_percentage: % of CIs without owner
        - ownership_by_field: Breakdown by ownership field
        - orphaned_cis_details: List of orphaned CI details (if include_details=True)
        - recommendations: Prioritized actionable next steps
        - metadata: Phase 3 audit metadata
        - status: 'success' or 'error'

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 500 total CIs. 108 orphaned (21.6%). Ownership score: 78.5/100 (Grade C).
         PRIMARY ISSUE: Only 60% have 'owned_by' field populated. Business owners needed for data accuracy."

    USE CASES:
    - Identify CIs needing ownership assignment
    - Measure ownership governance effectiveness
    - Prioritize ownership assignment initiatives
    - Track ownership coverage improvement over time
    - Prepare for data stewardship audits
    """
    return await _run_tool(
        ctx, "audit_data_ownership_assignment", audit_data_ownership_assignment_impl,
        check_table="ci_class",
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_details=include_details,
        details_limit=details_limit,
    )


@mcp.tool()
async def audit_discovery_coverage_gaps(
    ctx: Context,
    ci_class: str,
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_details: bool = True,
    details_limit: int = 50,
    staleness_threshold_days: int = 90,
    check_discovery_schedules: bool = True,
) -> Dict[str, Any]:
    """
    Audit discovery coverage gaps to identify CIs not covered by Discovery (Critical PMF Gap Tool #2).

    Addresses critical CMDB challenge: "Inadequate CI discovery processes affect CMDB
    maintenance, resulting in missing CIs and incomplete data" (Forrester research, top 3 issue).

    CSDM PHASE: CONSUME (data collection & discovery automation)

    ServiceNow Discovery Field Reference:
    - discovery_source "ServiceNow": Discovered by ServiceNow Discovery (TARGET)
    - discovery_source "Manual Entry": Manually created CIs (GAP)
    - last_discovered: Timestamp of last successful pattern discovery
    - Discovery schedules: Automated CI collection jobs

    This tool identifies:
    - **Manual CIs**: Not covered by Discovery (discovery_source != "ServiceNow")
    - **Stale discovered CIs**: last_discovered > threshold (default 90 days)
    - **Discovery coverage**: % of CIs discovered vs. manual
    - **Discovery schedules**: Health check (optional, deep mode only)

    AUDIT LEVELS:
    - quick: Summary only, no CI details (<1s execution)
    - standard: Top 50 manual CIs, coverage metrics (default)
    - deep: Top 100 CIs + discovery schedule health analysis

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: The CI class to analyze (e.g., 'cmdb_ci_server', 'cmdb_ci_database')
        domain: Optional domain filter for multi-domain instances
        audit_level: Analysis depth ('quick', 'standard', 'deep')
        include_details: Include CI details in response (default: True, disabled in quick mode)
        details_limit: Max CIs to include in details (default: 50, deep: 100)
        staleness_threshold_days: Days since last discovery to consider stale (default: 90)
        check_discovery_schedules: Query Discovery schedules (auto-disabled if unavailable)

    Returns:
        Dictionary containing:
        - discovery_coverage_score: 0-100 score
        - discovery_grade: A-F letter grade
        - ci_class: CI class analyzed
        - total_cis: Total active CIs found
        - discovered_cis: CIs with discovery_source = "ServiceNow"
        - manual_cis: CIs with discovery_source != "ServiceNow"
        - discovery_coverage_percentage: % discovered
        - stale_discovered_cis: Discovered CIs with last_discovered > threshold
        - cis_by_source: Breakdown by discovery_source
        - manual_cis_details: List of manual CI details (if include_details=True)
        - stale_cis_details: List of stale discovered CIs (if include_details=True)
        - discovery_schedules_summary: Schedule health (if check_discovery_schedules=True & deep mode)
        - recommendations: Prioritized actionable next steps
        - metadata: Phase 3 audit metadata
        - status: 'success' or 'error'

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 500 total CIs. 174 manual (34.8%). Discovery coverage: 65.2/100 (Grade D).
         CRITICAL: 34.8% of CIs were manually created - not covered by Discovery.
         45 discovered CIs are stale (>90 days) - schedule rediscovery."

    USE CASES:
    - Identify CIs needing Discovery setup
    - Detect discovery service failures
    - Prioritize rediscovery efforts
    - Validate Discovery schedule effectiveness
    - Track Discovery adoption over time
    """
    return await _run_tool(
        ctx, "audit_discovery_coverage_gaps", audit_discovery_coverage_gaps_impl,
        check_table="ci_class",
        ci_class=ci_class,
        domain=domain,
        audit_level=audit_level,
        include_details=include_details,
        details_limit=details_limit,
        staleness_threshold_days=staleness_threshold_days,
        check_discovery_schedules=check_discovery_schedules,
    )


@mcp.tool()
async def audit_duplicate_cis(
    ctx: Context,
    table_name: str,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Detect duplicate CIs using ServiceNow CI Identification Rules.

    This tool identifies duplicate Configuration Items by applying ServiceNow's
    standard CI identification algorithm (priority-based field matching). Helps
    maintain CMDB data quality and supports merge workflows.

    CSDM PHASE: CONSUME (data quality & correctness)

    ServiceNow CI Identification Rules (priority order):
    1. serial_number (highest priority - hardware unique identifier)
    2. asset_tag (organization asset tracking ID)
    3. mac_address (network interface hardware address)
    4. host_name (DNS hostname)
    5. ip_address (lowest priority - IP address)

    AUDIT LEVELS:
    - quick: Lightweight summary (duplicate counts only)
    - standard: Counts plus sample duplicates (recommended)
    - deep: Full duplicate listing with merge recommendations

    Args:
        ctx: Tool execution context with ServiceNow client
        table_name: The CI class to analyze (e.g., 'cmdb_ci_server', 'cmdb_ci_computer')
        audit_level: Choose 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - table: The analyzed CI class
        - total_cis: Total CIs in table
        - duplicate_count: Number of duplicate CIs identified
        - duplicate_percentage: Percentage of duplicates
        - duplicate_groups: List of duplicate groups (sample for standard, all for deep)
        - identification_rules_used: Priority fields used for matching
        - merge_recommendations: Suggested merge actions (deep level only)
        - audit_metadata: Sampling details and execution metadata

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 2,800 total CIs. 321 duplicates (11.5%) across 142 duplicate groups.
         Top match: serial_number duplicates (78 groups)."
    """
    return await _run_tool(
        ctx, "audit_duplicate_cis", audit_duplicate_cis_impl,
        check_table="table_name",
        table_name=table_name,
        audit_level=audit_level,
    )


@mcp.tool()
async def audit_calculate_cmdb_health_score(
    ctx: Context,
    ci_class: str = "cmdb_ci_server",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Calculate comprehensive CMDB health score across 4 dimensions (Phase 3 Tool #1).

    This tool provides a unified, actionable health score by analyzing:
    1. Completeness (required fields populated)
    2. Correctness (duplicate-free, valid data)
    3. Relationship Health (proper CI connections)
    4. Staleness (recently discovered/updated)

    CSDM PHASE: CONSUME (health monitoring & reporting)

    SCORING ALGORITHM:
    - Each dimension scored 0-100
    - Overall score = weighted average (configurable weights)
    - Default weights: completeness 30%, correctness 30%, relationships 20%, staleness 20%

    AUDIT LEVELS:
    - quick: Summary scores only (fast)
    - standard: Scores with sample issues (recommended)
    - deep: Full analysis with detailed remediation plan

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: The CI class to analyze (default: 'cmdb_ci_server')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns (varies by audit level):
        - ci_class: The analyzed CI class
        - total_cis: Total CIs analyzed
        - health_score: Overall health score (0-100)
        - dimension_scores: Breakdown by dimension
          * completeness_score: Field population score (0-100)
          * correctness_score: Data quality score (0-100)
          * relationship_score: CI connectivity score (0-100)
          * staleness_score: Freshness score (0-100)
        - health_grade: Letter grade (A-F) or tier (Platinum/Gold/Silver/Bronze)
        - critical_issues: Top issues requiring attention (standard/deep)
        - remediation_plan: Actionable improvement steps (deep only)
        - audit_metadata: Execution details and sampling info

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 2,800 CIs analyzed. Health Score: 78% (Grade: B).
         Breakdown: Completeness 85%, Correctness 72%, Relationships 80%, Staleness 75%.
         Top issue: 11.5% duplicate rate (321 CIs need merge)."
    """
    return await _run_tool(
        ctx, "audit_calculate_cmdb_health_score", calculate_cmdb_health_score_impl,
        check_table="ci_class",
        ci_class=ci_class,
        audit_level=audit_level,
    )


@mcp.tool()
async def audit_validate_relationship_integrity(
    ctx: Context,
    ci_class: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    check_circular: bool = True,
    max_depth: int = 10,
) -> Dict[str, Any]:
    """
    Validate relationship integrity: detect orphans, circular dependencies, and invalid types (Phase 3 Week 2 Tool #3).

    Comprehensive relationship validation detecting orphaned relationships (missing parent/child),
    circular dependency chains, invalid relationship types, and untyped relationships.
    Provides relationship health score (0-100) and actionable remediation recommendations.

    CSDM PHASE: CONSUME (relationship data quality validation)

    VALIDATION CHECKS:
    1. Orphaned Relationships: parent or child CI no longer exists
    2. Circular Dependencies: CI references itself through relationship chain
    3. Invalid Relationship Types: type not in CSDM 5.0 allowed types
    4. Missing Relationship Types: relationships without type classification
    5. Bidirectional Consistency: parent→child and child→parent match

    AUDIT LEVELS:
    - quick: Summary counts only (fast)
    - standard: Counts + sample violations (recommended)
    - deep: Full violation list + circular dependency paths

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Optional CI class filter (e.g., 'cmdb_ci_server')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        check_circular: Whether to check for circular dependencies (expensive, default: True)
        max_depth: Maximum depth for circular dependency detection (default: 10)

    Returns (varies by audit level):
        - ci_class: The analyzed CI class filter
        - total_relationships: Total relationships checked
        - relationship_health_score: Overall integrity score (0-100)
        - health_grade: Letter grade (A-F) or tier
        - violation_summary:
          * orphaned_count: Relationships with missing parent or child
          * circular_count: Circular dependency chains detected
          * invalid_type_count: Relationships with invalid types
          * missing_type_count: Relationships without type
        - orphaned_relationships: List of orphaned relationships (sample/full)
        - circular_dependencies: List of circular chains (sample/full)
        - invalid_types: List of invalid relationship types found
        - recommendations: Actionable remediation steps
        - audit_metadata: Execution details

    EXAMPLE OUTPUT:
        "Validated 4,523 relationships. Health Score: 87% (Grade: B).
         Issues: 145 orphaned (3.2%), 12 circular dependencies, 89 invalid types (2.0%).
         Recommendation: Use action_auto_heal_relationship_issues to remove 145 orphaned relationships."

    WORKFLOW:
        audit_validate_relationship_integrity → action_auto_heal_relationship_issues
    """
    return await _run_tool(
        ctx, "audit_validate_relationship_integrity", audit_validate_relationship_integrity_impl,
        ci_class=ci_class,
        audit_level=audit_level,
        check_circular=check_circular,
        max_depth=max_depth,
    )


@mcp.tool()
async def audit_calculate_csdm_maturity_score(
    ctx: Context,
    completeness_score: float = 0,
    relationship_score: float = 0,
    data_quality_score: float = 0,
    standardization_score: float = 0,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Calculate the CSDM 5.0 maturity score based on analysis results.

    This atomic tool aggregates individual assessment scores into an overall
    CSDM maturity level (1-5) and provides maturity grade indicators.

    Supports three audit levels:
    - quick: Maturity score only, no recommendations
    - standard (default): Score with key insights
    - deep: Full analysis with detailed roadmap

    Args:
        ctx: Tool execution context (unused but required for MCP pattern)
        completeness_score: CI field completeness percentage (0-100)
        relationship_score: CI relationship coverage percentage (0-100)
        data_quality_score: Data quality and validity score (0-100)
        standardization_score: Standardization and classification score (0-100)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - maturity_level: CSDM maturity level (1-5)
        - maturity_grade: Grade (Bronze/Silver/Gold/Platinum)
        - overall_score: Weighted average score (0-100)
        - component_scores: Individual scores for each dimension
        - key_strengths: Top performing areas
        - key_weaknesses: Areas needing improvement (limited for quick)
        - roadmap_recommendations: Priority actions for improvement (full for deep only)
        - audit_metadata: Cost and coverage information
    """
    return await _run_tool(
        ctx, "audit_calculate_csdm_maturity_score", calculate_csdm_maturity_score_impl,
        completeness_score=completeness_score,
        relationship_score=relationship_score,
        data_quality_score=data_quality_score,
        standardization_score=standardization_score,
        audit_level=audit_level,
    )


@mcp.tool()
async def audit_analyze_tagging_compliance(
    ctx: Context,
    domain: str = "Foundation",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Audit sys_tags population and tagging strategy compliance across CI classes.

    This atomic tool evaluates how consistently CI records are tagged for
    discoverability, automation, and management. Identifies CI classes and
    business areas lacking proper tagging strategy.

    Supports three audit levels:
    - quick: Class-level tagging summary only
    - standard (default): Tagging compliance with sample analysis
    - deep: Full per-class tagging analysis and tag frequency

    Args:
        ctx: Tool execution context with ServiceNow client
        domain: Domain to analyze for tagging compliance (default: 'Foundation')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - domain: The analyzed domain
        - ci_classes_analyzed: Number of CI classes checked
        - tagging_results: Per-class tagging population percentages
        - overall_tagging_compliance: Domain-wide tagging score (0-100)
        - classes_without_tags: CI classes with 0% tagging
        - low_tagging_classes: CI classes with < 50% tagging
        - tag_examples: Sample of popular tags in use (full for deep)
        - tagging_recommendations: Strategy for improvement
        - audit_metadata: Cost and coverage information
    """
    return await _run_tool(ctx, "audit_analyze_tagging_compliance", analyze_tagging_compliance_impl, domain=domain, audit_level=audit_level)


@mcp.tool()
async def audit_analyze_service_mappings(
    ctx: Context,
    domain: str = "Service Delivery",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Analyze Business Service to Application to Infrastructure dependency chains.

    This atomic tool validates complete service-to-infrastructure mapping chains
    required for service delivery visibility, impact analysis, and incident
    correlation. Identifies broken or incomplete chains.

    Args:
        ctx: Tool execution context with ServiceNow client
        domain: Domain to analyze (typically 'Service Delivery' or 'Design')

    Returns:
        Dictionary containing:
        - services_analyzed: Total business services reviewed
        - complete_chains: Services with full end-to-end mapping
        - broken_chains: Services missing application or infrastructure mapping
        - orphaned_applications: Apps not mapped to any business service
        - orphaned_infrastructure: Infra CIs not mapped to any application
        - service_health: Quality assessment of service chains
        - remediation_actions: Specific mapping gaps to address
    """
    return await _run_tool(ctx, "audit_analyze_service_mappings", analyze_service_mappings_impl, domain=domain, audit_level=audit_level)


@mcp.tool()
async def test_servicenow_connection(ctx: Context) -> str:
    """
    Test connection to ServiceNow instance.

    This tool verifies connectivity to the ServiceNow instance and returns
    information about the authenticated user.

    Args:
        ctx: The MCP context containing ServiceNow client details

    Returns:
        Formatted string with connection status and user information
    """
    start = time.perf_counter()
    try:
        app_context = _get_app_context(ctx)
        result = await test_servicenow_connection_impl(app_context=app_context)
        duration = time.perf_counter() - start
        print(f"[Tool] test_servicenow_connection duration={duration:.3f}s", file=sys.stderr)
        return result
    except Exception as e:
        duration = time.perf_counter() - start
        print(f"[ERROR] test_servicenow_connection failed after {duration:.3f}s: {e}", file=sys.stderr)
        return f"**ServiceNow Connection Status**\n\n**Status:** ❌ Failed\n**Error:** {str(e)}"


@mcp.tool()
async def audit_extract_ci_context(
    ctx: Context,
    ci_sysid: str,
    include_relationships: bool = True,
    include_incidents: bool = True,
    include_discovery: bool = True,
) -> str:
    """
    Extract comprehensive CI context for AI agent understanding.

    This tool builds rich CI profiles for AI agents, including relationships,
    recent incidents, discovery information, CSDM compliance metrics, and
    data quality assessment. Use this when you need to "understand" a CI
    deeply, not just read raw data.

    Args:
        ctx: The MCP context containing ServiceNow client details
        ci_sysid: The sys_id of the CI to extract context for
        include_relationships: Include CI relationships (parent/child) - default True
        include_incidents: Include recent incidents (last 90 days, top 10 by priority) - default True
        include_discovery: Include discovery source and metadata - default True

    Returns:
        JSON string with complete CI context including:
        - ci: Core CI profile (name, class, status, owner, location, environment, criticality)
        - relationships: Parent and child CI relationships (excludes retired CIs)
        - recent_incidents: Top 10 incidents by priority from last 90 days
        - discovery_info: Discovery source, last discovered date, method
        - tags: CI tags/labels
        - risk_indicators: Boolean flags (staleness, missing fields, incidents, relationships, owner)
        - suggested_actions: AI-friendly remediation recommendations
        - data_quality_score: Overall CI data quality (0-100)
        - csdm_compliance: CSDM domain, completeness %, missing required fields

    Examples:
        - "Extract context for CI abc123" → Returns full CI profile with relationships
        - "What's the health of server X?" → Uses extract_ci_context then suggests actions
        - "Which CIs have missing owners?" → Extract all, filter by has_no_owner flag
    """
    setup_sentry_context(
        "extract_ci_context",
        ci_sysid=ci_sysid,
        include_relationships=include_relationships,
        include_incidents=include_incidents,
        include_discovery=include_discovery,
    )
    start = time.perf_counter()
    try:
        client = _get_servicenow_client(ctx)
        result = await extract_ci_context_impl(
            sn_client=client,
            ci_sysid=ci_sysid,
            include_relationships=include_relationships,
            include_incidents=include_incidents,
            include_discovery=include_discovery,
        )
        sentry_sdk.add_breadcrumb(
            category="mcp_tool",
            message=f"extract_ci_context succeeded for {ci_sysid}",
            level="info",
            data={"ci_sysid": ci_sysid, "status": result.get("status", "unknown")},
        )
        duration = time.perf_counter() - start
        print(f"[Tool] audit_extract_ci_context duration={duration:.3f}s", file=sys.stderr)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        duration = time.perf_counter() - start
        print(f"[ERROR] audit_extract_ci_context failed after {duration:.3f}s: {e}", file=sys.stderr)
        sentry_sdk.capture_exception(e)
        sentry_sdk.add_breadcrumb(
            category="mcp_tool_error",
            message=f"extract_ci_context failed for {ci_sysid}",
            level="error",
            data={"ci_sysid": ci_sysid, "error": str(e)},
        )
        return json.dumps({"status": "error", "message": f"Error extracting CI context: {str(e)}"}, indent=2)


@mcp.tool()
async def search_incidents(
    ctx: Context,
    query: str = "",
    priority: str | None = None,
    state: str | None = None,
    assigned_to: str | None = None,
    limit: int = 10,
) -> str:
    """Search for ServiceNow incidents with optional filters."""
    return await _run_tool(
        ctx, "search_incidents", search_incidents_impl,
        query=query or None,
        priority=priority,
        state=state,
        assigned_to=assigned_to,
        limit=limit,
    )


@mcp.tool()
async def search_assignment_groups(ctx: Context, name: str = "", limit: int = 5) -> str:
    """Look up assignment groups and return their sys_ids."""
    return await _run_tool(ctx, "search_assignment_groups", search_assignment_groups_impl, name=name, limit=limit)


@mcp.tool()
async def search_users(ctx: Context, name: str = "", limit: int = 5) -> str:
    """Look up users and return their usernames and sys_ids."""
    return await _run_tool(ctx, "search_users", search_users_impl, name=name, limit=limit)


@mcp.tool()
async def get_incident_details(ctx: Context, incident_number: str) -> str:
    """
    Get full details for a specific ServiceNow incident.

    This tool retrieves comprehensive information about a single incident
    by its incident number (e.g., INC0010001).

    Args:
        ctx: The MCP context containing ServiceNow client details
        incident_number: The incident number (e.g., INC0010001)

    Returns:
        Formatted string with all important incident fields including description,
        state, priority, urgency, impact, category, assignment, caller, dates, and work notes
    """
    return await _run_tool(ctx, "get_incident_details", get_incident_details_impl, incident_number=incident_number)


@mcp.tool()
async def get_change_request(
    ctx: Context,
    sys_id: str = "",
    number: str = "",
) -> Dict[str, Any]:
    """
    Get details of a Change Request by sys_id or CHG number.
    
    This tool retrieves comprehensive information about a change request,
    including state, approval status, priority, risk, impact, and assignments.
    
    Args:
        ctx: The MCP context containing ServiceNow client details
        sys_id: The sys_id of the change request (optional if number provided)
        number: The CHG number e.g., 'CHG0012345' (optional if sys_id provided)
    
    Returns:
        Formatted string with change request details including number, state,
        short description, priority, risk, approval status, and dates.
    
    EXAMPLE:
        get_change_request(sys_id='84327172835bf210bdcfeec0deaad32c')
        get_change_request(number='CHG0012345')
    """
    return await _run_tool(
        ctx, 
        "get_change_request", 
        get_change_request_impl, 
        sys_id=sys_id or None,
        number=number or None,
    )


@mcp.tool()
async def list_recent_change_requests(
    ctx: Context,
    limit: int = 10,
    state: str = "",
    opened_after: str = "",
) -> Dict[str, Any]:
    """
    List recent change requests with optional filtering.
    
    This tool retrieves a list of recent change requests, optionally filtered
    by state or date. Useful for tracking CMDB changes and change management.
    
    Args:
        ctx: The MCP context containing ServiceNow client details
        limit: Maximum number of records to return (default: 10)
        state: Filter by state e.g., 'new', 'assess', 'implement', 'closed' (optional)
        opened_after: ISO date string to filter by opened_at e.g., '2026-03-01' (optional)
    
    Returns:
        List of change requests with number, description, state, and priority.
    """
    return await _run_tool(
        ctx, 
        "list_recent_change_requests", 
        list_recent_change_requests_impl, 
        limit=limit,
        state=state or None,
        opened_after=opened_after or None,
    )


@mcp.tool()
async def link_cis_to_change_request(
    ctx: Context,
    change_request_id: str,
    ci_sys_ids: List[str],
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Link CIs to a Change Request's Affected CIs tab.
    
    Creates records in the task_ci table to associate CIs with a change request.
    This populates the "Affected CIs" related list on the change request form.
    
    Args:
        ctx: The MCP context containing ServiceNow client details
        change_request_id: The sys_id of the change request
        ci_sys_ids: List of CI sys_ids to link to the change request
        dry_run: If True, validate but don't create links (default: False)
    
    Returns:
        Results with count of linked, skipped, and failed CIs
    
    EXAMPLE:
        link_cis_to_change_request(
            change_request_id='84327172835bf210bdcfeec0deaad32c',
            ci_sys_ids=['abc123', 'def456']
        )
    """
    return await _run_tool(
        ctx,
        "link_cis_to_change_request",
        link_cis_to_change_request_impl,
        change_request_id=change_request_id,
        ci_sys_ids=ci_sys_ids,
        dry_run=dry_run,
    )


@mcp.tool()
async def get_table_description(ctx: Context, table_name: str) -> str:
    """
    Get schema information for any ServiceNow table.

    This tool retrieves metadata about a table's structure, including field names,
    labels, types, and whether they are required. Useful for understanding
    table structures before querying or creating records.

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        table_name: The name of the ServiceNow table (e.g., 'incident', 'change_request')

    Returns:
        Formatted string with field information (limited to first 20 fields for readability)
    """
    return await _run_tool(ctx, "get_table_description", get_table_description_impl, table_name=table_name)


@mcp.tool()
async def find_similar_incidents(
    ctx: Context, incident_number: str, limit: int = 5
) -> str:
    """
    Find similar incidents based on keywords from a reference incident.

    This tool analyzes the short description of a reference incident, extracts
    meaningful keywords (words longer than 4 characters), and searches for other
    incidents with similar keywords. This is useful for finding how similar issues
    were resolved in the past.

    The tool:
    - Retrieves the reference incident's short description
    - Extracts keywords (words > 4 characters, takes first 3)
    - Searches for incidents containing those keywords
    - Excludes the reference incident from results
    - Returns similar incidents with resolution notes if available

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        incident_number: The reference incident number (e.g., INC0010001)
        limit: Maximum number of similar incidents to return (default: 5)

    Returns:
        Formatted string with similar incidents and their resolution notes
    """
    return await _run_tool(ctx, "find_similar_incidents", find_similar_incidents_impl, incident_number=incident_number, limit=limit)


@mcp.tool()
async def create_incident(
    ctx: Context,
    short_description: str,
    description: str | None = None,
    urgency: str = "3",
    impact: str = "3",
    caller: str | None = None,
    assignment_group: str | None = None,
) -> str:
    """
    Create a new incident in ServiceNow.

    This tool creates a new incident record with the specified details.
    Priority is automatically calculated based on urgency and impact.

    Urgency/Impact/Priority Scale:
    - 1 = High/Critical
    - 2 = Medium/High
    - 3 = Low/Moderate

    Priority Calculation:
    Priority is set to the maximum (most severe) of urgency and impact values.
    For example: urgency=1, impact=3 results in priority=1 (High)

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        short_description: Brief summary of the incident (required)
        description: Detailed description of the incident
        urgency: Urgency level - 1 (High), 2 (Medium), or 3 (Low) - default: "3"
        impact: Impact level - 1 (High), 2 (Medium), or 3 (Low) - default: "3"
        caller: Username or sys_id of the person reporting the incident
        assignment_group: Name or sys_id of the group to assign the incident to

    Returns:
        Formatted string with created incident number and sys_id
    """
    return await _run_tool(
        ctx, "create_incident", create_incident_impl,
        credit_cost=1,
        short_description=short_description,
        description=description,
        urgency=urgency,
        impact=impact,
        caller=caller,
        assignment_group=assignment_group,
    )


@mcp.tool()
async def update_incident(
    ctx: Context,
    incident_number: str,
    state: str | None = None,
    priority: str | None = None,
    assigned_to: str | None = None,
    work_notes: str | None = None,
) -> str:
    """
    Update an existing ServiceNow incident.

    This tool updates one or more fields on an existing incident.
    Only the fields you specify will be updated; others remain unchanged.

    State Values:
    - 1 = New
    - 2 = In Progress
    - 3 = On Hold
    - 6 = Resolved
    - 7 = Closed

    Priority Values:
    - 1 = Critical
    - 2 = High
    - 3 = Moderate
    - 4 = Low
    - 5 = Planning

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        incident_number: The incident number to update (e.g., INC0010001)
        state: New state value (1-7, see above)
        priority: New priority value (1-5, see above)
        assigned_to: Username or sys_id to assign the incident to
        work_notes: Work notes to add (internal notes)

    Returns:
        Formatted string showing what was changed
    """
    return await _run_tool(
        ctx, "update_incident", update_incident_impl,
        credit_cost=1,
        incident_number=incident_number,
        state=state,
        priority=priority,
        assigned_to=assigned_to,
        work_notes=work_notes,
    )


@mcp.tool()
async def add_comment_to_incident(
    ctx: Context, incident_number: str, comment: str, work_notes: bool = False
) -> str:
    """
    Add a comment or work note to a ServiceNow incident.

    This tool adds either a customer-visible comment or an internal work note
    to an existing incident.

    Comment Types:
    - work_notes=False: Adds to 'comments' field (visible to customers)
    - work_notes=True: Adds to 'work_notes' field (internal only, not visible to customers)

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        incident_number: The incident number (e.g., INC0010001)
        comment: The comment or work note text to add
        work_notes: If True, add as internal work note; if False, add as customer comment (default: False)

    Returns:
        Confirmation message
    """
    return await _run_tool(
        ctx, "add_comment_to_incident", add_comment_to_incident_impl,
        credit_cost=1,
        incident_number=incident_number,
        comment=comment,
        work_notes=work_notes,
    )


@mcp.resource("servicenow://incident/{incident_number}")
async def get_incident_resource(ctx: Context, incident_number: str) -> str:
    """
    Get incident details as a JSON resource.

    This resource provides full incident data in JSON format.
    AI agents can reference this data using URIs like:
    servicenow://incident/INC0010001

    Args:
        ctx: The MCP context providing access to the ServiceNow client
        incident_number: The incident number (e.g., INC0010001)

    Returns:
        JSON string containing full incident data
    """
    try:
        # Get the incident by number
        response = await _get_servicenow_client(ctx).get_record_by_number(
            table="incident", number=incident_number
        )

        records = response.get("result", [])
        if not records:
            return json.dumps(
                {
                    "error": f"Incident not found: {incident_number}",
                    "incident_number": incident_number,
                },
                indent=2,
            )

        # Return the full incident data as formatted JSON
        incident = records[0]
        return json.dumps(incident, indent=2)

    except Exception as e:
        return json.dumps(
            {"error": str(e), "incident_number": incident_number},
            indent=2,
        )


# =============================================================================
# AUTOMATED REMEDIATION TOOLS
# =============================================================================
# Tools to automatically fix CMDB data quality issues and improve compliance

@mcp.tool()
async def action_auto_retire_stale_cis(
    ctx: Context,
    table: str,
    days_threshold: int = 180,
    dry_run: bool = True,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
    ci_sys_ids: Optional[List[str]] = None,
    change_request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Automatically retire or deactivate CIs that haven't been updated in 180+ days.

    This remediation tool identifies and optionally retires old, stale CIs from your CMDB.
    CIs older than 180 days are marked for retirement or deactivated to improve data quality.

    WHEN TO USE:
    - "Clean up our old computer records from 2010-2015"
    - "Retire stale servers that haven't been discovered in over 6 months"
    - "Identify equipment ready for removal from CMDB"

    CSDM PHASE: CONSUME (data quality improvement & hygiene)

    AUDIT LEVELS:
    - quick: $0.20 - Count only, no details
    - standard: $0.60 - Count + sample list (RECOMMENDED)
    - deep: $1.40 - Full list + retirement simulation

    CRITICAL FIELDS UPDATED:
    - install_status: Set to "7" (Retired)
    - operational_status: Set to "7" (Retired)
    - comments: Added retirement reason and timestamp

    ⚠️ WARNING: Discovery can revert CIs back to "Installed" if they're still active on network.
              Exclude retired CI IPs from discovery configuration to prevent automatic reversion.

    Args:
        ctx: Tool execution context with ServiceNow client
        table: The CI class to retire from (e.g., 'cmdb_ci_computer', 'cmdb_ci_server')
        days_threshold: Age threshold in days (default: 180 days = ~6 months)
        dry_run: If True, only show what would be retired (no actual changes)
        limit: Max CIs to retire in one batch (default: 100, max: 500)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        ci_sys_ids: Optional list of specific CI sys_ids to retire (None = all stale CIs)

    Returns:
        Dictionary containing:
        - table: The CI class analyzed
        - candidates_found: Total CIs eligible for retirement
        - retirement_plan: List of CIs to be retired
        - retirement_summary: By operational status and type
        - estimated_data_quality_improvement: Percentage improvement
        - actions_taken: Count of actual retirements (if dry_run=False)
        - retirement_batch_details: Sample of CIs with retirement metadata
        - discovery_warning: Critical warning about discovery reverting status
        - status: success/error
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Found 487 stale computers (180+ days old). Retire 100 in batch 1.
         Preview: dell-2012-04, hp-laptop-2013-06, lenovo-2011-08 (35 more...)
         Data quality improvement: +2.1%
         ⚠️ Remember to exclude these CIs from discovery to prevent status reversion"
    """
    credit_cost = {"quick": 1, "standard": 2, "deep": 4}.get(audit_level, 2)
    return await _run_action_tool(
        ctx, "action_auto_retire_stale_cis", auto_retire_stale_cis_impl,
        credit_cost=credit_cost, check_table="table_name",
        table_name=table_name,
        days_threshold=days_threshold,
        dry_run=dry_run,
        limit=limit,
        audit_level=audit_level,
        ci_sys_ids=ci_sys_ids,
        change_request_id=change_request_id,
    )


@mcp.tool()
async def audit_suggest_ci_relationship_mappings(
    ctx: Context,
    source_ci_class: str = "cmdb_ci_server",
    target_ci_class: Optional[str] = None,
    limit: int = 20,
    confidence_threshold: str = "medium",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Suggest new CI relationship mappings based on patterns in your CMDB.

    Analyzes existing relationships and CI attributes to recommend new
    connections that are likely missing. Uses pattern matching to identify
    CIs that should be related but aren't yet.

    WHEN TO USE:
    - "Find missing server-to-database relationships"
    - "Suggest mappings for our 50 unlinked applications"
    - "Identify CIs that should be related but aren't"

    CSDM PHASE: CONSUME (relationship mapping & dependency analysis)

    AUDIT LEVELS:
    - quick: $0.20 - Count only
    - standard: $0.60 - Count + high-confidence suggestions (RECOMMENDED)
    - deep: $1.40 - Full mapping with all confidence levels

    Args:
        ctx: Tool execution context with ServiceNow client
        source_ci_class: Source CI class to analyze (e.g., 'cmdb_ci_server')
        target_ci_class: Target CI class (e.g., 'cmdb_ci_database', None for all)
        limit: Max suggestions to return (default: 20)
        confidence_threshold: Minimum confidence: 'high', 'medium' (default), 'low'
        audit_level: Analysis depth: 'quick', 'standard', or 'deep'

    Returns:
        Dictionary containing:
        - source_class: Source CI class analyzed
        - target_classes: Target classes included
        - unmapped_pairs: CIs that should likely be related
        - mapping_suggestions: Suggested relationships with reasoning
        - confidence_breakdown: Distribution of confidence levels
        - estimated_relationship_improvement: % improvement in coverage
        - next_steps: How to apply suggested mappings
        - status: success/error
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Analyzed 40 servers. Found 15 missing database relationships.
         Suggestions: server-prod-db1 -> database-prod (high confidence, 92%)
         Expected coverage improvement: +3.4%"
    """
    return await _run_tool(
        ctx, "audit_suggest_ci_relationship_mappings", suggest_ci_relationship_mappings_impl,
        source_ci_class=source_ci_class,
        target_ci_class=target_ci_class,
        limit=limit,
        confidence_threshold=confidence_threshold,
        audit_level=audit_level,
    )


@mcp.tool()
async def action_bulk_update_missing_fields(
    ctx: Context,
    table: str,
    field_mappings: Dict[str, str],
    dry_run: bool = True,
    filter_query: Optional[str] = None,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
    change_request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Bulk populate missing critical fields in CI records.

    Updates CIs with missing values for key fields like owner, support_group,
    environment, business_unit, etc. Uses intelligent mapping to determine
    appropriate values based on existing data.

    WHEN TO USE:
    - "Populate missing owners for all servers"
    - "Set environment to Production for all production servers"
    - "Bulk update support groups based on department"

    CSDM PHASE: CONSUME (data completeness improvement)

    AUDIT LEVELS:
    - quick: $0.20 - Count of CIs to be updated
    - standard: $0.60 - Count + sample updates (RECOMMENDED)
    - deep: $1.40 - Full audit trail with all changes

    Args:
        ctx: Tool execution context with ServiceNow client
        table: CI class to update (e.g., 'cmdb_ci_server')
        field_mappings: Dict of field->value mappings (e.g., {"owner": "admin@company.com", "environment": "Production"})
        dry_run: If True, only show what would be updated (no actual changes)
        filter_query: ServiceNow query to filter CIs (e.g., "name LIKE prod")
        limit: Max CIs to update in batch (default: 100, max: 500)
        audit_level: Analysis depth: 'quick', 'standard', or 'deep'

    Returns:
        Dictionary containing:
        - table: The CI class updated
        - dry_run: Whether this was a dry run
        - total_cis_matching_filter: CIs eligible for update
        - cis_with_missing_fields: CIs that will be updated
        - field_mappings_applied: Fields to be updated
        - update_summary: By field and count
        - estimated_completeness_improvement: Percentage improvement
        - updates_applied: Actual count (if dry_run=False)
        - sample_updates: Sample of CIs to be updated
        - next_steps: How to process remaining CIs
        - status: success/error
        - audit_metadata: Cost and coverage information
        - credits_used: Credits deducted for this operation (if applicable)
        - credits_remaining: Remaining credits after deduction (if applicable)

    EXAMPLE OUTPUT:
        "Found 234 servers with missing owner field.
         Will update 100 in this batch with 'app-team@company.com'
         Completeness improvement: +2.1%"
    """
    credit_cost = {"quick": 1, "standard": 2, "deep": 4}.get(audit_level, 2)
    return await _run_action_tool(
        ctx, "action_bulk_update_missing_fields", bulk_update_missing_fields_impl,
        credit_cost=credit_cost, check_table="table_name",
        table_name=table_name,
        field_mappings=field_mappings,
        dry_run=dry_run,
        filter_query=filter_query,
        limit=limit,
        audit_level=audit_level,
        change_request_id=change_request_id,
    )


@mcp.tool()
async def action_merge_duplicate_cis(
    ctx: Context,
    duplicate_ci_sysids: List[str],
    keep_sysid: str,
    merge_strategy: str = "keep_newest",
    skip_validation: bool = False,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
) -> Dict[str, Any]:
    """
    Merge duplicate CI records into a single CI record.

    Uses ServiceNow's Identification & Reconciliation Engine (IRE) principles to:
    - Merge field values intelligently (keep newest, most complete, or specified)
    - Redirect relationships to the target CI
    - Update change history and audit trail
    - Handle conflicts and exceptions

    WHEN TO USE:
    - "Merge these 3 duplicate servers into the canonical record"
    - "Consolidate 10 duplicate applications"
    - "Clean up duplicate CIs after discovery tool misidentification"

    DATA SOURCE:
    - Uses live cmdb_ci and cmdb_rel_ci tables
    - Queries CI records and their relationships in real-time
    - No hardcoded data or approximations

    Args:
        ctx: Tool execution context with ServiceNow client
        duplicate_ci_sysids: List of sys_ids of duplicate CIs to merge
        keep_sysid: The sys_id of the CI record to keep (target)
        merge_strategy: Strategy for resolving field conflicts:
            - 'keep_newest': Keep values from most recently updated CI
            - 'keep_complete': Prioritize most complete/populated fields
            - 'keep_specified': Use values from keep_sysid
        skip_validation: Skip pre-merge validation checks (not recommended)
        change_request_id: Optional Change Request sys_id
        dry_run: Preview mode (default: True)

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - dry_run: Boolean indicating if this was a dry run
        - merged_cis: List of CI sys_ids that were merged into target
        - target_ci: sys_id of the resulting CI
        - relationships_updated: Count of relationships redirected
        - conflicts_resolved: List of field conflicts and resolutions
        - warnings: List of warnings (field loss, orphaned relationships)
        - audit_session_id: Audit trail session ID
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "action_merge_duplicate_cis", merge_duplicate_cis_impl,
        credit_cost=credit_cost,
        duplicate_ci_sysids=duplicate_ci_sysids,
        keep_sysid=keep_sysid,
        merge_strategy=merge_strategy,
        skip_validation=skip_validation,
        change_request_id=change_request_id,
        dry_run=dry_run,
    )


@mcp.tool()
async def action_remediate_relationship_health(
    ctx: Context,
    remediation_type: str = "all",
    ci_class: Optional[str] = None,
    dry_run: bool = True,
    batch_size: int = 100,
    auto_create_from_suggestions: bool = False,
    confidence_threshold: str = "high",
    validate_sysids: bool = True,
    change_request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Bulk remediate relationship health issues (orphans, duplicates, stale links).

    Version 2: Now supports auto-creation of missing relationships from AI suggestions.

    Identifies and fixes:
    - Orphan relationships: CI no longer exists but relationship remains
    - Duplicate relationships: Identical parent-child-type triplets (keep most recent)
    - Stale relationships: Linked to deactivated/obsolete CIs
    - Missing relationships: Creates new relationships from high-confidence suggestions
    - Broken relationships: Missing required parent or child CI

    WHEN TO USE:
    - "Find and remove all orphaned relationships"
    - "Dedup relationships and clean up stale links"
    - "Fix relationship health for cmdb_ci_server class"
    - "Create missing relationships for cmdb_ci_server based on AI suggestions"

    SAFETY: By default runs in dry_run=True mode (report only, no changes)

    Args:
        ctx: Tool execution context with ServiceNow client
        remediation_type: Which issues to fix:
            - 'orphans': Only fix missing/deleted CI references
            - 'duplicates': Only remove duplicate relationships
            - 'stale': Only update links to inactive CIs
            - 'missing': Create missing relationships from suggestions (requires auto_create_from_suggestions=true)
            - 'all': Fix all issues (default)
        ci_class: Filter to specific CI class (e.g., 'cmdb_ci_server')
        dry_run: If True, only report issues; don't fix (default: True for safety)
        batch_size: Number of relationships to process per batch (max 1000)
        auto_create_from_suggestions: If True with remediation_type='missing', creates relationships from AI suggestions
        confidence_threshold: Filter suggestions by confidence: 'high', 'medium', 'all' (default: 'high')
        validate_sysids: If True, validates that both source and target CIs exist before creating relationships

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - remediation_type: Type of remediation performed
        - dry_run: Whether this was a dry run
        - issues_detected: Total count of issues found
        - orphans_fixed: Count of orphan relationships removed
        - duplicates_removed: Count of duplicate relationships removed
        - stale_updated: Count of stale relationship updates
        - relationships_created: Count of new relationships created
        - coverage_improvement: Estimated % improvement in relationship coverage
        - csdm_compliance_gain: Estimated % compliance improvement
        - actions_taken: List of specific remediation actions (limited to 100)
        - warnings: Any issues encountered during remediation
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "action_remediate_relationship_health", remediate_relationship_health_impl,
        credit_cost=credit_cost,
        remediation_type=remediation_type,
        ci_class=ci_class,
        dry_run=dry_run,
        batch_size=batch_size,
        auto_create_from_suggestions=auto_create_from_suggestions,
        confidence_threshold=confidence_threshold,
        validate_sysids=validate_sysids,
        change_request_id=change_request_id,
    )


@mcp.tool()
async def action_auto_heal_relationship_issues(
    ctx: Context,
    ci_class: Optional[str] = None,
    fix_orphaned: bool = True,
    fix_invalid_types: bool = True,
    fix_missing_types: bool = False,
    recreate_missing: bool = False,
    dry_run: bool = True,
    change_request_id: Optional[str] = None,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Auto-heal relationship integrity issues (Phase 3 Week 2 Tool #4).

    Automatically remediates relationship integrity violations identified by
    audit_validate_relationship_integrity. Removes orphaned relationships,
    normalizes invalid types to CSDM 5.0 standards, and optionally classifies
    untyped relationships.

    CSDM PHASE: REMEDIATE (automated relationship integrity repair)

    SAFETY FEATURES:
    - Phase 2C audit_trail integration (full change tracking)
    - Phase 2C precheck validation (soft validation before execution)
    - dry_run mode (preview changes without applying)
    - Batch limit (max 1000 relationships per execution)
    - Change Request integration (optional CR tracking)

    REMEDIATION ACTIONS:
    1. Remove orphaned relationships (parent or child CI missing)
    2. Normalize invalid relationship types to CSDM 5.0 equivalents
    3. Classify untyped relationships (optional)
    4. Recreate expected relationships (optional, advanced)

    AUDIT LEVELS:
    - quick: Summary only (counts, no details)
    - standard: Summary + sample changes (recommended)
    - deep: Full change log with before/after states

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: Optional CI class filter (e.g., 'cmdb_ci_server')
        fix_orphaned: Remove orphaned relationships (default: True)
        fix_invalid_types: Normalize invalid types to CSDM (default: True)
        fix_missing_types: Classify untyped relationships (default: False)
        recreate_missing: Recreate expected relationships (default: False, advanced)
        dry_run: Preview mode - no actual changes (default: True)
        change_request_id: Optional Change Request sys_id for tracking
        limit: Max relationships to fix per execution (default: 100, max: 1000)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - ci_class: The CI class filter applied
        - dry_run: Whether this was a preview
        - changes_planned: Total changes to be made
        - changes_applied: Actual changes made (0 if dry_run)
        - orphaned_removed: Count of orphaned relationships removed
        - types_normalized: Count of invalid types normalized
        - types_classified: Count of missing types classified
        - change_details: List of individual changes (sample or full)
        - precheck_results: Validation results from precheck
        - audit_trail_session: Audit trail session ID (if changes applied)
        - recommendations: Next steps and follow-up actions
        - status: success/error

    EXAMPLE OUTPUT:
        "[DRY RUN] Would remove 145 orphaned relationships, normalize 89 invalid types.
         Total changes: 234. Re-run with dry_run=False to apply changes.
         Change Request: CHG0012345. Audit trail session: CMDB_CHANGE_20250118_123456_a1b2c3d4."

    IMPORTANT:
        - Always run with dry_run=True first to preview changes
        - For production changes, provide change_request_id
        - Circular dependencies require manual review (not auto-healed)
        - Recreating relationships is advanced - use with caution

    WORKFLOW:
        audit_validate_relationship_integrity → action_auto_heal_relationship_issues
    """
    credit_cost = {"quick": 1, "standard": 2, "deep": 4}.get(audit_level, 2)
    return await _run_action_tool(
        ctx, "action_auto_heal_relationship_issues", action_auto_heal_relationship_issues_impl,
        credit_cost=credit_cost,
        ci_class=ci_class,
        fix_orphaned=fix_orphaned,
        fix_invalid_types=fix_invalid_types,
        fix_missing_types=fix_missing_types,
        recreate_missing=recreate_missing,
        dry_run=dry_run,
        change_request_id=change_request_id,
        limit=limit,
        audit_level=audit_level,
    )


# ========================================
# Phase 4: Workflow Orchestration Tools
# ========================================

@mcp.tool()
async def audit_orchestrate_ci_validation_flow(
    ctx: Context,
    ci_class: str,
    audit_level: AuditLevel = "standard",
    health_threshold: float = 50.0,
    staleness_threshold_days: int = 90,
    lifecycle_required_states: Optional[List[str]] = None,
    relationship_threshold: float = 60.0,
) -> Dict[str, Any]:
    """
    Orchestrate CI validation flow for auto-promotion readiness (Phase 4 Tool #1).

    Validates CI readiness by orchestrating 4 Phase 3 audit tools:
    1. Health Score - Overall CMDB health (completeness, relationships, staleness, duplicates)
    2. Staleness Check - Identifies stale CIs exceeding age threshold
    3. Lifecycle Health - Validates CIs are in acceptable lifecycle states
    4. Relationship Integrity - Checks relationship health (orphans, circular deps)

    CSDM PHASE: ORCHESTRATE (multi-dimensional validation workflow)

    VALIDATION ALGORITHM:
    - Runs 4 parallel health checks with configurable thresholds
    - Aggregates results into weighted validation score (0-100)
    - Returns PASS/FAIL decision with blocking issues and warnings
    - Default weights: health 30%, staleness 25%, lifecycle 20%, relationships 25%

    USE CASES:
    - Pre-deployment CI validation
    - Auto-promotion gates for CI lifecycle
    - Compliance checks before production release
    - Quality gates for discovery data

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_class: CI class to validate (e.g., 'cmdb_ci_server')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        health_threshold: Minimum health score required (0-100), default 50.0
        staleness_threshold_days: Maximum age in days before CI considered stale, default 90
        lifecycle_required_states: List of acceptable lifecycle states, default ['in_use', 'on_order']
        relationship_threshold: Minimum relationship health score (0-100), default 60.0

    Returns:
        Dictionary containing:
        - validation_passed: Overall pass/fail boolean
        - validation_score: Aggregate validation score (0-100)
        - validation_grade: A-F grade based on score
        - ci_class: The CI class validated
        - total_cis_evaluated: Number of CIs checked
        - checks: Detailed results for each validation check
        - checks_summary: Pass/fail counts
        - blocking_issues: Issues preventing promotion
        - warnings: Non-blocking concerns
        - recommendation: Promotion decision with reasoning
        - metadata: Phase 3 metadata (audit_type, execution_time, etc.)

    EXAMPLE OUTPUT:
        "✅ APPROVED for promotion - All validation checks passed (score: 82.5/100).
         4/4 checks passed: Health Score 85%, Staleness 100%, Lifecycle 80%, Relationships 75%.
         Warnings: 3 CIs are stale but within acceptable range."

    WORKFLOW:
        audit_orchestrate_ci_validation_flow → audit_orchestrate_auto_promotion_gate
    """
    return await _run_tool(
        ctx, "audit_orchestrate_ci_validation_flow", audit_orchestrate_ci_validation_flow_impl,
        check_table="ci_class",
        ci_class=ci_class,
        audit_level=audit_level,
        health_threshold=health_threshold,
        staleness_threshold_days=staleness_threshold_days,
        lifecycle_required_states=lifecycle_required_states,
        relationship_threshold=relationship_threshold,
    )


@mcp.tool()
async def audit_generate_compliance_report(
    ctx: Context,
    include_sections: Optional[List[str]] = None,
    audit_level: AuditLevel = "standard",
    export_format: str = "detailed",
) -> Dict[str, Any]:
    """
    Generate a CMDB compliance and data quality report using live ServiceNow metrics.

    This orchestrator avoids duplicate queries by leaning on existing MCP tools:
      • audit_identify_stale_cis + audit_duplicate_cis – hygiene audit (default focus: servers)
      • identify_domain_gaps – relationship/completeness gaps (Foundation domain)
    """
    try:
        return await _run_tool(
            ctx, "audit_generate_compliance_report", generate_compliance_report_impl,
            ctx=ctx, include_sections=include_sections,
            audit_level=audit_level, export_format=export_format,
        )
    except Exception as e:
        return {"status": "error", "error": str(e), "audit_level": audit_level}


@mcp.tool()
async def audit_cmdb_data_accuracy(
    ctx: Context,
    audit_scope: str = "all",
    sample_limit: int = 1000,
) -> Dict[str, Any]:
    """
    Audit CMDB data accuracy by querying primary tables directly.

    Shows transparent, exact counts from source tables with explicit query filters.
    No interpretation, no pre-calculated metrics - just raw data from cmdb_ci and cmdb_rel_ci.

    Args:
        audit_scope: "all" (default), "relationships", or "ci_inventory"
        sample_limit: Max records to fetch for detailed analysis (default: 1000, max: 5000)

    Returns:
        Dictionary with raw counts, query details, and filter transparency
    """
    setup_sentry_context("audit_cmdb_data_accuracy", audit_scope=audit_scope)
    safe_limit = min(sample_limit, 5000)
    try:
        return await _run_tool(
            ctx, "audit_cmdb_data_accuracy", audit_cmdb_data_accuracy_impl,
            timeout=25.0, audit_scope=audit_scope, sample_limit=safe_limit,
        )
    except asyncio.TimeoutError:
        return {
            "status": "error",
            "error": "Query timed out - try reducing sample_limit or using a more specific audit_scope",
            "audit_scope": audit_scope,
            "suggestion": "Use audit_scope='ci_inventory' or 'relationships' instead of 'all', or reduce sample_limit",
        }
    except Exception as e:
        return {"status": "error", "error": str(e), "audit_scope": audit_scope}


# =============================================================================
# PHASE 2 & PHASE 3 WEEK 1 ACTION TOOLS (NEWLY REGISTERED)
# =============================================================================

@mcp.tool()
async def action_assess_change_impact(
    ctx: Context,
    target_ci_sys_ids: List[str],
    change_type: str = "update",
    max_depth: int = 3,
    include_business_services: bool = True,
    include_applications: bool = True,
    include_users: bool = False,
) -> Dict[str, Any]:
    """
    Assess the impact of proposed CMDB changes by analyzing CI relationships.

    Traverses relationship chains to identify affected services, applications,
    and business processes. Calculates risk level based on CI criticality.

    Args:
        ctx: Tool execution context
        target_ci_sys_ids: List of CI sys_ids to be changed
        change_type: Type of change ('update', 'retire', 'delete', 'merge')
        max_depth: Relationship traversal depth (1-5)
        include_business_services: Include affected business services
        include_applications: Include affected applications
        include_users: Include affected users/groups

    Returns:
        Impact analysis with risk level, affected CIs, and recommendations
    """
    credit_cost = 2  # Fixed cost for impact assessment
    return await _run_action_tool(
        ctx, "action_assess_change_impact", assess_change_impact_impl,
        credit_cost=credit_cost,
        target_ci_sys_ids=target_ci_sys_ids,
        change_type=change_type,
        max_depth=max_depth,
        include_business_services=include_business_services,
        include_applications=include_applications,
        include_users=include_users,
    )


@mcp.tool()
async def action_apply_bulk_cmdb_changes_with_cr(
    ctx: Context,
    target_ci_sys_ids: List[str],
    field_updates: Dict[str, Any],
    change_request_id: str,
    dry_run: bool = True,
    continue_on_error: bool = False,
    validate_cr_approval: bool = True,
) -> Dict[str, Any]:
    """
    Apply bulk field updates to multiple CIs with Change Request tracking.

    Performs mass updates to CI records with comprehensive validation,
    change request approval checking, and detailed audit trail tracking.

    Args:
        ctx: Tool execution context
        target_ci_sys_ids: List of CI sys_ids to update
        field_updates: Dictionary of field names and new values to apply
        change_request_id: Change Request sys_id authorizing this change
        dry_run: Preview mode - no actual changes (default: True)
        continue_on_error: Continue updating remaining CIs if one fails (default: False)
        validate_cr_approval: Check CR is approved before applying (default: True)

    Returns:
        Bulk change results with audit trail session and update status

    EXAMPLE:
        action_apply_bulk_cmdb_changes_with_cr(
            target_ci_sys_ids=["abc123", "def456"],
            field_updates={"owner": "admin@company.com"},
            change_request_id="84327172835bf210bdcfeec0deaad32c"
        )
    """
    credit_cost = 2  # Fixed cost for bulk changes
    return await _run_action_tool(
        ctx, "action_apply_bulk_cmdb_changes_with_cr", apply_bulk_cmdb_changes_with_cr_impl,
        credit_cost=credit_cost,
        target_ci_sys_ids=target_ci_sys_ids,
        field_updates=field_updates,
        change_request_id=change_request_id,
        dry_run=dry_run,
        continue_on_error=continue_on_error,
        validate_cr_approval=validate_cr_approval,
    )


@mcp.tool()
async def action_normalize_ci_naming_conventions(
    ctx: Context,
    ci_class: str = "cmdb_ci_server",
    naming_pattern: Optional[str] = None,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
    auto_detect_pattern: bool = True,
    case_style: str = "uppercase",
    ci_sys_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Normalize CI names according to organizational naming conventions.

    Standardizes CI names to match patterns (e.g., SERVER-LOC-001, DB-PROD-NYC-01).
    Supports auto-detection of existing patterns or custom regex patterns.

    Args:
        ctx: Tool execution context
        ci_class: CI class to normalize
        naming_pattern: Optional regex pattern for valid names
        change_request_id: Optional Change Request sys_id
        dry_run: Preview mode (default: True)
        auto_detect_pattern: Auto-detect naming pattern (default: True)
        case_style: Case normalization ('uppercase', 'lowercase', 'titlecase')
        ci_sys_ids: Optional list of specific CI sys_ids to normalize (None = all active CIs)

    Returns:
        Normalization results with changes planned/applied
    """
    credit_cost = 2  # Fixed cost for naming normalization
    return await _run_action_tool(
        ctx, "action_normalize_ci_naming_conventions", normalize_ci_naming_conventions_impl,
        credit_cost=credit_cost,
        ci_class=ci_class,
        naming_pattern=naming_pattern,
        change_request_id=change_request_id,
        dry_run=dry_run,
        auto_detect_pattern=auto_detect_pattern,
        case_style=case_style,
        ci_sys_ids=ci_sys_ids,
    )


@mcp.tool()
async def action_rollback_cmdb_changes(
    ctx: Context,
    audit_trail_session_id: str,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
) -> Dict[str, Any]:
    """
    Rollback CMDB changes using audit trail history.

    Reverses changes from a previous action tool execution by reading the
    audit trail and restoring previous values. Requires audit trail session ID.

    Args:
        ctx: Tool execution context
        audit_trail_session_id: Audit trail session to rollback
        change_request_id: Optional Change Request for rollback authorization
        dry_run: Preview mode (default: True)

    Returns:
        Rollback results with changes reverted
    """
    credit_cost = 2  # Fixed cost for rollback
    return await _run_action_tool(
        ctx, "action_rollback_cmdb_changes", rollback_cmdb_changes_impl,
        credit_cost=credit_cost,
        audit_session_id=audit_trail_session_id,
        change_request_id=change_request_id,
        dry_run=dry_run,
    )


@mcp.tool()
async def action_validate_change_approval_status(
    ctx: Context,
    change_request_id: str,
) -> Dict[str, Any]:
    """
    Validate Change Request approval status before CMDB changes.

    Checks if a Change Request is approved and ready for execution.
    Used as a pre-flight check before running action tools.

    Args:
        ctx: Tool execution context
        change_request_id: Change Request sys_id or number

    Returns:
        Approval status, approvers, and execution readiness
    """
    credit_cost = 1  # Fixed cost for validation check
    return await _run_action_tool(
        ctx, "action_validate_change_approval_status", validate_change_approval_status_impl,
        credit_cost=credit_cost,
        change_request_id=change_request_id,
    )


# =============================================================================
# PHASE 2 & PHASE 3 AUDIT TOOLS (NEWLY REGISTERED)
# =============================================================================

@mcp.tool()
async def audit_ci_identifier_rules(
    ctx: Context,
    ci_class: str = "cmdb_ci_server",
    analyze_duplicates: bool = True,
    check_rule_coverage: bool = True,
    check_rule_conflicts: bool = True,
) -> Dict[str, Any]:
    """
    Audit CI identification rule effectiveness.

    Analyzes ServiceNow Identification & Reconciliation Engine (IRE) rules
    to identify misconfiguration, duplicate detection gaps, and optimization
    opportunities.

    Args:
        ctx: Tool execution context
        ci_class: CI class to analyze
        analyze_duplicates: Check for CIs bypassing duplicate detection
        check_rule_coverage: Verify all CIs covered by identifier rules
        check_rule_conflicts: Detect conflicting identifier rules

    Returns:
        Identifier rule analysis with effectiveness metrics and recommendations
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "audit_ci_identifier_rules", audit_ci_identifier_rules_impl,
        credit_cost=credit_cost,
        ci_class=ci_class,
        analyze_duplicates=analyze_duplicates,
        check_rule_coverage=check_rule_coverage,
        check_rule_conflicts=check_rule_conflicts,
    )


@mcp.tool()
async def audit_reconciliation_governance(
    ctx: Context,
    ci_class: str = "cmdb_ci_server",
    check_data_sources: bool = True,
    check_field_precedence: bool = True,
    analyze_conflicts: bool = True,
) -> Dict[str, Any]:
    """
    Audit reconciliation governance and data source precedence.

    Analyzes how ServiceNow reconciles data from multiple sources (Discovery,
    SCCM, manual entry, integrations). Identifies precedence conflicts and
    governance gaps.

    Args:
        ctx: Tool execution context
        ci_class: CI class to analyze
        check_data_sources: Analyze data source distribution
        check_field_precedence: Check field-level precedence rules
        analyze_conflicts: Detect CIs with conflicting source data

    Returns:
        Reconciliation analysis with source conflicts and governance gaps
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "audit_reconciliation_governance", audit_reconciliation_governance_impl,
        credit_cost=credit_cost,
        ci_class=ci_class,
        check_data_sources=check_data_sources,
        check_field_precedence=check_field_precedence,
        analyze_conflicts=analyze_conflicts,
    )


@mcp.tool()
async def audit_ire_health(
    ctx: Context,
    ci_class: Optional[str] = None,
    check_rule_status: bool = True,
    check_reconciliation_states: bool = True,
    check_match_conflicts: bool = True,
    audit_level: AuditLevel = "summary"
) -> Dict[str, Any]:
    """
    Audit IRE (Identification & Reconciliation Engine) health.
    
    Analyzes ServiceNow IRE configuration, reconciliation states, and match rule
    effectiveness. Provides graceful fallback when IRE tables are not accessible
    (requires Discovery or CMDB 360 plugin). Recommends alternative tools when
    IRE features are unavailable.
    
    CIS-DF Domain: Ingestion (19%)
    
    Args:
        ctx: Tool execution context
        ci_class: Optional CI class to filter analysis (e.g., cmdb_ci_server)
        check_rule_status: Audit identification rule configuration
        check_reconciliation_states: Analyze reconciliation state distribution
        check_match_conflicts: Detect match rule conflicts
        audit_level: Audit depth (quick, summary, detailed)
    
    Returns:
        IRE health analysis with recommendations, or alternative tool guidance
        when IRE tables unavailable
    """
    credit_cost = 5
    return await _run_action_tool(
        ctx, "audit_ire_health", audit_ire_health_impl,
        credit_cost=credit_cost,
        ci_class=ci_class,
        check_rule_status=check_rule_status,
        check_reconciliation_states=check_reconciliation_states,
        check_match_conflicts=check_match_conflicts,
        audit_level=audit_level,
    )


# =============================================================================
# PHASE 3 WEEK 3 AUDIT TOOLS
# =============================================================================

@mcp.tool()
async def audit_ci_data_lineage(
    ctx: Context,
    ci_sys_id: str,
    trace_upstream: bool = True,
    trace_downstream: bool = True,
    max_depth: int = 5,
    include_field_history: bool = True,
    include_source_attribution: bool = True,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Trace CI data lineage with relationship paths and modification history (Phase 3 Week 3).

    Provides complete visibility into CI relationships, dependencies, and change history.
    Ideal for impact analysis, compliance auditing, and understanding CI data provenance.

    FEATURES:
    - Upstream dependency tracing (what this CI depends on)
    - Downstream impact analysis (what depends on this CI)
    - Field-level modification history from sys_audit
    - Data source attribution (discovery, manual, integration)
    - Circular dependency detection
    - Orphaned relationship path detection

    CSDM PHASE: GOVERN (data lineage and provenance tracking)

    AUDIT LEVELS:
    - quick: Summary only (counts, no detailed paths)
    - standard: Summary + sample lineage paths (recommended)
    - deep: Full lineage tree with complete field history

    USE CASES:
    - "Show me all dependencies for this critical database server"
    - "Trace the lineage of this application CI - who touched it and when"
    - "Find circular dependencies in my infrastructure relationships"
    - "Identify orphaned relationships before decommissioning"

    Args:
        ctx: Tool execution context with ServiceNow client
        ci_sys_id: Target CI sys_id to trace
        trace_upstream: Include upstream dependencies (default: True)
        trace_downstream: Include downstream impacts (default: True)
        max_depth: Maximum relationship traversal depth (1-10, default: 5)
        include_field_history: Include modification history (default: True)
        include_source_attribution: Include data source analysis (default: True)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - ci_sys_id, ci_name, ci_class: Target CI identification
        - lineage_map: Complete upstream/downstream relationship tree
        - coverage_score: Lineage quality score (0-100)
        - upstream_count: Total upstream dependencies discovered
        - downstream_count: Total downstream impacts discovered
        - circular_dependencies: List of circular relationship chains
        - orphan_paths: Relationships with missing CI endpoints
        - field_history: Field-level change timeline (if enabled)
        - source_attribution: Data source breakdown (if enabled)
        - issues: List of lineage quality issues
        - recommendations: Actionable improvement suggestions

    EXAMPLE OUTPUT:
        "CI srv-db-prod-01 has 12 upstream dependencies, 8 downstream impacts.
         Coverage score: 85/100 (Grade: B).
         Found 1 circular dependency chain and 2 orphaned relationships.
         Field history shows 47 modifications across 8 fields.
         Data source: 80% Discovery, 15% Manual, 5% Integration."

    IMPORTANT:
        - Requires read access to cmdb_rel_ci and sys_audit tables
        - Large max_depth values (>7) may impact performance
        - Field history requires sys_audit table logging enabled
        - Circular dependencies require manual review to resolve
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "audit_ci_data_lineage", audit_ci_data_lineage_impl,
        credit_cost=credit_cost,
        ci_sys_id=ci_sys_id,
        trace_upstream=trace_upstream,
        trace_downstream=trace_downstream,
        max_depth=max_depth,
        include_field_history=include_field_history,
        include_source_attribution=include_source_attribution,
        audit_level=audit_level,
    )


@mcp.tool()
async def audit_compliance_summary_report(
    ctx: Context,
    domain_filter: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_recommendations: bool = True,
) -> Dict[str, Any]:
    """
    Generate executive-level CMDB compliance summary with traffic-light indicators (Phase 3 Week 3).

    Aggregates multiple audit dimensions into a comprehensive compliance report:
    - Completeness: Missing required fields
    - Correctness: Data accuracy issues
    - Relationships: Relationship health
    - Staleness: Outdated CIs
    - Duplicates: Duplicate records

    Each dimension receives a traffic-light status:
    - 🟢 Green (≥80): Healthy, meeting standards
    - 🟡 Yellow (50-79): Needs improvement, monitor closely
    - 🔴 Red (<50): Critical issues, immediate action required

    FEATURES:
    - Five compliance dimensions with weighted scoring
    - Traffic-light indicators per dimension
    - Domain-specific filtering (Infrastructure/Applications/Services)
    - Critical issues identification
    - Prioritized recommendations
    - Executive-friendly summary

    USE CASES:
    - "Give me an overall compliance report for my CMDB"
    - "Show Infrastructure compliance with traffic lights"
    - "What are the critical compliance issues I need to address?"
    - "Generate a monthly compliance summary for leadership"

    Args:
        domain_filter: Optional - "Infrastructure", "Applications", "Services", or None (all)
        audit_level: "quick", "standard", or "deep" - detail level
        include_recommendations: Include actionable recommendations (default: True)

    Returns:
        {
            "overall_compliance_score": 0-100,
            "overall_status": "green/yellow/red",
            "dimensions": {
                "completeness": {score, status, emoji, issues, summary},
                "correctness": {score, status, emoji, issues, summary},
                "relationships": {score, status, emoji, issues, summary},
                "staleness": {score, status, emoji, issues, summary},
                "duplicates": {score, status, emoji, issues, summary}
            },
            "critical_issues": [...],
            "recommendations": [...]
        }
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "audit_compliance_summary_report", audit_compliance_summary_report_impl,
        credit_cost=credit_cost,
        domain_filter=domain_filter,
        audit_level=audit_level,
        include_recommendations=include_recommendations,
    )


@mcp.tool()
async def audit_executive_health_summary(
    ctx: Context,
    include_trends: bool = True,
    include_domain_breakdown: bool = True,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Generate top-level CMDB health summary for executive stakeholders (Phase 3 Week 3).

    Provides the highest-level view of CMDB health designed for CIO/CTO presentations
    and executive dashboards. Aggregates multiple audit dimensions into a single
    health score with letter grade, domain breakdown, and trend indicators.

    HEALTH GRADING SYSTEM:
    - A+ (95-100): Exceptional CMDB quality
    - A (90-94): Excellent CMDB quality
    - B (80-89): Good CMDB quality
    - C (70-79): Acceptable CMDB quality
    - D (60-69): Below expectations, improvement needed
    - F (<60): Failing, major remediation required

    FEATURES:
    - Overall health score (0-100) with letter grade (A+ to F)
    - Domain-specific grades (Infrastructure, Applications, Services)
    - Trend indicators (↑ improving, → steady, ↓ declining)
    - Plain-English executive summary
    - Critical issues count
    - Key metrics dashboard

    USE CASES:
    - "Give me the executive health summary for our CMDB"
    - "What's the overall CMDB health grade and trend?"
    - "Show me the health score breakdown by domain"
    - "Prepare an executive dashboard for the CIO"

    Args:
        include_trends: Include trend indicators (default: True)
        include_domain_breakdown: Show per-domain grades (default: True)
        audit_level: "quick", "standard", or "deep" - detail level

    Returns:
        {
            "overall_health_score": 0-100,
            "health_grade": "A+" to "F",
            "grade_color": emoji indicator,
            "trend_indicator": "↑/↓/→",
            "domains": {
                "infrastructure": {score, grade, trend, key_metrics},
                "applications": {score, grade, trend, key_metrics},
                "services": {score, grade, trend, key_metrics}
            },
            "key_metrics": {...},
            "executive_summary": "Plain-English summary",
            "critical_issues_count": number
        }
    """
    credit_cost = 2
    return await _run_action_tool(
        ctx, "audit_executive_health_summary", audit_executive_health_summary_impl,
        credit_cost=credit_cost,
        include_trends=include_trends,
        include_domain_breakdown=include_domain_breakdown,
        audit_level=audit_level,
    )


# =============================================================================
# PHASE 3 WEEK 4 AUDIT TOOLS
# =============================================================================

@mcp.tool()
async def audit_ci_lifecycle_health(
    ctx: Context,
    ci_class: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_decommission_candidates: bool = True,
    age_threshold_days: int = 1825,
) -> Dict[str, Any]:
    """
    Audit CI lifecycle health across the CMDB (Phase 3 Week 4).

    Analyzes CI lifecycle stage distribution, aging, stale CIs stuck in intermediate
    states, and identifies decommissioning candidates.

    LIFECYCLE STAGES MONITORED:
    - New, In Stock, On Order, In Transit (intermediate states)
    - In Use, In Maintenance (active states)
    - Retired, Disposed (end-of-life states)

    FEATURES:
    - Lifecycle stage distribution analysis
    - CI age distribution tracking
    - Stale lifecycle detection (CIs stuck too long in intermediate states)
    - Decommission candidates identification
    - Lifecycle health score (0-100)

    USE CASES:
    - "Show me CIs stuck in intermediate lifecycle stages"
    - "Find servers ready for decommissioning"
    - "What's the lifecycle health of my infrastructure?"
    - "Identify CIs that have been 'retired' for over 6 months"

    Args:
        ci_class: Optional CI class filter (e.g., "cmdb_ci_server")
        audit_level: "quick", "standard", or "deep"
        include_decommission_candidates: Include decommission-ready CIs (default: True)
        age_threshold_days: Age threshold for old CIs (default: 1825 = 5 years)

    Returns:
        {
            "lifecycle_stage_distribution": {...},
            "age_distribution": {...},
            "stale_lifecycle_cis": [...],
            "decommission_candidates": [...],
            "lifecycle_health_score": 0-100,
            "recommendations": [...]
        }
    """
    return await _run_tool(
        ctx, "audit_ci_lifecycle_health", audit_ci_lifecycle_health_impl,
        ci_class=ci_class,
        audit_level=audit_level,
        include_decommission_candidates=include_decommission_candidates,
        age_threshold_days=age_threshold_days,
    )


@mcp.tool()
async def audit_ci_drift_detection(
    ctx: Context,
    ci_class: Optional[str] = None,
    ci_sys_ids: Optional[List[str]] = None,
    lookback_days: int = 30,
    audit_level: AuditLevel = "standard",
    detect_unauthorized_changes: bool = True,
    check_csdm_compliance: bool = True,
) -> Dict[str, Any]:
    """
    Detect configuration drift in CMDB CIs (Phase 3 Week 4).

    Analyzes field value changes over time to detect unauthorized modifications,
    drift from CSDM standards, and anomalous change patterns.

    DRIFT DETECTION CAPABILITIES:
    - Field value change tracking from sys_audit
    - Unauthorized change detection (non-system users)
    - CSDM compliance violation detection
    - Critical vs. operational field classification
    - Configuration drift score (0-100)

    FIELD SEVERITY CLASSIFICATION:
    - High: name, serial_number, asset_tag, manufacturer (rarely change)
    - Medium: location, department, assignment_group (occasional changes)
    - Low: operational_status, maintenance_schedule (frequent changes)

    FEATURES:
    - Drift events with severity classification
    - Unauthorized changes flagging
    - CSDM rule violation detection
    - Drift trends by CI and by field
    - Configuration stability scoring

    USE CASES:
    - "Detect unauthorized changes to critical server configurations"
    - "Show me what fields changed in the last 30 days"
    - "Find CIs that drifted from CSDM compliance"
    - "Identify configuration instability in my infrastructure"

    Args:
        ci_class: Optional CI class filter (e.g., "cmdb_ci_server")
        ci_sys_ids: Optional specific CI sys_ids to check
        lookback_days: Days to analyze for drift (default: 30)
        audit_level: "quick", "standard", or "deep"
        detect_unauthorized_changes: Flag non-system changes (default: True)
        check_csdm_compliance: Validate against CSDM rules (default: True)

    Returns:
        {
            "drift_events": [...],
            "drift_by_ci": {...},
            "drift_by_field": {...},
            "unauthorized_changes": [...],
            "csdm_violations": [...],
            "drift_score": 0-100,
            "recommendations": [...]
        }
    """
    return await _run_tool(
        ctx, "audit_ci_drift_detection", audit_ci_drift_detection_impl,
        ci_class=ci_class,
        ci_sys_ids=ci_sys_ids,
        lookback_days=lookback_days,
        audit_level=audit_level,
        detect_unauthorized_changes=detect_unauthorized_changes,
        check_csdm_compliance=check_csdm_compliance,
    )


# =============================================================================
# Feature Gate Enforcement
# =============================================================================
# Remove tools not enabled by NEXECUTE_ENABLE_* environment variables.
# This runs at module load time, so disabled tools never appear in the
# MCP tool list and cannot be called by clients.

_CMDB_ACTION_TOOLS = frozenset({
    "action_auto_retire_stale_cis",
    "action_bulk_update_missing_fields",
    "action_merge_duplicate_cis",
    "action_remediate_relationship_health",
    "action_auto_heal_relationship_issues",
    "action_assess_change_impact",
    "action_apply_bulk_cmdb_changes_with_cr",
    "action_normalize_ci_naming_conventions",
    "action_rollback_cmdb_changes",
    "action_validate_change_approval_status",
})

_ITSM_TOOLS = frozenset({
    "search_incidents",
    "search_assignment_groups",
    "search_users",
    "get_incident_details",
    "get_change_request",
    "list_recent_change_requests",
    "find_similar_incidents",
    "create_incident",
    "update_incident",
    "add_comment_to_incident",
})


def _enforce_feature_gates() -> None:
    """Remove tools not enabled by feature flags at startup."""
    gates = {
        "NEXECUTE_ENABLE_CMDB_ACTION": (_CMDB_ACTION_TOOLS, False),
        "NEXECUTE_ENABLE_ITSM": (_ITSM_TOOLS, True),
    }
    # CMDB Audit, Data Access, and Diagnostics are always enabled (free tier)

    disabled_count = 0
    for env_var, (tool_names, default_enabled) in gates.items():
        raw = os.getenv(env_var, str(default_enabled).lower())
        enabled = raw.strip().lower() in ("true", "1", "yes")
        if not enabled:
            for name in tool_names:
                try:
                    mcp.remove_tool(name)
                    disabled_count += 1
                except (KeyError, ValueError):
                    pass  # Tool may not exist
            print(
                f"[Feature Gate] {env_var}=false → {len(tool_names)} tools disabled",
                file=sys.stderr,
            )
        else:
            print(
                f"[Feature Gate] {env_var}=true → {len(tool_names)} tools enabled",
                file=sys.stderr,
            )

    remaining = len(list(mcp._tool_manager.list_tools()))
    print(
        f"[Feature Gate] {remaining} tools registered, {disabled_count} disabled",
        file=sys.stderr,
    )


_enforce_feature_gates()


def main() -> None:
    """
    Main entry point for the ServiceNow MCP server.

    Starts the server with stdio transport for communication.
    """
    print("=" * 60, file=sys.stderr)
    print("  ServiceNow MCP Server", file=sys.stderr)
    print("  Model Context Protocol Server for ServiceNow Integration", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    # Run the server with stdio transport
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
