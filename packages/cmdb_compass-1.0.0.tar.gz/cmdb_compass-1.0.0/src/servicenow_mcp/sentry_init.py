"""Sentry initialization for ServiceNow MCP Server."""

import os
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.starlette import StarletteIntegration
from sentry_sdk.integrations.httpx import HttpxIntegration


def init_sentry() -> None:
    """
    Initialize Sentry for error tracking and performance monitoring.

    This function should be called early in the application startup.
    It configures Sentry with integrations for FastAPI/Starlette and HTTPX.

    Environment Variables:
        SENTRY_DSN: Sentry DSN (required to enable Sentry)
        SENTRY_ENVIRONMENT: Environment name (default: production)
        SENTRY_RELEASE: Release version (default: 1.0.0)

    Sentry is only initialized if SENTRY_DSN is provided.
    """
    dsn = os.getenv("SENTRY_DSN")

    if not dsn:
        # Sentry is optional - only initialize if DSN is provided
        return

    environment = os.getenv("SENTRY_ENVIRONMENT", "production")
    release = os.getenv("SENTRY_RELEASE", "1.0.0")

    sentry_sdk.init(
        dsn=dsn,
        environment=environment,
        # Capture 100% of transactions for performance monitoring
        traces_sample_rate=1.0,
        # Enable profiling (10% of transactions)
        profiles_sample_rate=0.1,
        # Capture unhandled exceptions
        integrations=[
            FastApiIntegration(),
            StarletteIntegration(),
            HttpxIntegration(),
        ],
        # Set release for better tracking in Sentry dashboard
        release=release,
    )

    print(f"✅ Sentry initialized for environment: {environment}", flush=True)
