"""Public package interface for the ServiceNow MCP project."""

from .servicenow import ServiceNowClient

# Lazy import of server to avoid circular imports during testing
def __getattr__(name):
    if name == "mcp":
        from .server import mcp
        return mcp
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = ["__version__", "ServiceNowClient", "mcp"]

__version__ = "0.1.0"
