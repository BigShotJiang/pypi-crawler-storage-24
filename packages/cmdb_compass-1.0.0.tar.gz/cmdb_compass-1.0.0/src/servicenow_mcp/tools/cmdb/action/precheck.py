"""
Pre-Flight Validation for CMDB Action Tools

Centralized soft validation to catch errors before execution.
Reduces runtime failures and improves user experience.
"""

from typing import Any, Dict, List, Optional, Tuple

from servicenow_mcp.servicenow import ServiceNowClient


class CmdbChangePrecheck:
    """Pre-flight validation for CMDB changes."""

    def __init__(self, client: ServiceNowClient):
        self.client = client
        self.errors: List[str] = []
        self.warnings: List[str] = []

    async def validate_change(
        self,
        ci_sys_ids: List[str],
        change_request_id: Optional[str] = None,
        require_cr: bool = True,
        check_locks: bool = True,
        check_criticality: bool = True,
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Run pre-flight checks before CMDB modification.

        Args:
            ci_sys_ids: List of CI sys_ids to validate
            change_request_id: Optional CR sys_id
            require_cr: Whether a change request is required
            check_locks: Whether to check for CI locks
            check_criticality: Whether to check business criticality

        Returns:
            Tuple of (is_valid, validation_report)
        """
        self.errors = []
        self.warnings = []

        # Check 1: CIs exist and are active
        await self._check_cis_exist(ci_sys_ids)

        # Check 2: Change request exists and approved (if required)
        if require_cr and change_request_id:
            await self._check_cr_approved(change_request_id)
        elif require_cr and not change_request_id:
            self.errors.append("Change Request required but not provided")

        # Check 3: CIs not locked by another process
        if check_locks:
            await self._check_ci_locks(ci_sys_ids)

        # Check 4: High-criticality CIs need additional approval
        if check_criticality:
            await self._check_business_criticality(ci_sys_ids)

        # Check 5: Rate limiting (max 1000 CIs per action)
        if len(ci_sys_ids) > 1000:
            self.errors.append(f"Too many CIs ({len(ci_sys_ids)}). Max: 1000 per action.")

        is_valid = len(self.errors) == 0

        return is_valid, {
            "is_valid": is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "cis_checked": len(ci_sys_ids),
            "checks_passed": {
                "existence": "not found" not in str(self.errors).lower(),
                "cr_approval": "Change Request" not in str(self.errors),
                "locks": "locked" not in str(self.errors).lower(),
                "criticality": "criticality" not in str(self.warnings).lower() or len(self.warnings) == 0,
                "rate_limit": len(ci_sys_ids) <= 1000,
            }
        }

    async def _check_cis_exist(self, ci_sys_ids: List[str]):
        """Verify all CIs exist and are active."""
        for sys_id in ci_sys_ids:
            try:
                response = await self.client.get_table_records(
                    table="cmdb_ci",
                    sysparm_query=f"sys_id={sys_id}",
                    sysparm_limit=1
                )
                results = response.get("result", [])
                if not results:
                    self.errors.append(f"CI {sys_id} not found")
                else:
                    ci = results[0]
                    if ci.get("active") == "false":
                        self.warnings.append(f"CI {sys_id} is inactive")
            except Exception as e:
                self.errors.append(f"CI {sys_id} check failed: {str(e)}")

    async def _check_cr_approved(self, cr_sys_id: str):
        """Verify change request is approved."""
        try:
            response = await self.client.get_table_records(
                table="change_request",
                sysparm_query=f"sys_id={cr_sys_id}",
                sysparm_limit=1,
                sysparm_display_value="false",
            )
            results = response.get("result", [])
            if not results:
                self.errors.append(f"Change Request {cr_sys_id} not found")
                return

            cr = results[0]
            approval_state = cr.get("approval", "")
            state = cr.get("state", "")

            # approval: approved, state: implement or scheduled
            # Case-insensitive comparison to handle both display values ("Approved") and raw values ("approved")
            if str(approval_state).lower() != "approved":
                self.errors.append(f"CR {cr_sys_id} not approved (status: {approval_state})")

            # Case-insensitive state check
            if str(state).lower() in ["closed", "canceled"]:
                self.errors.append(f"CR {cr_sys_id} is {state}")

        except Exception as e:
            self.errors.append(f"CR validation failed: {str(e)}")

    async def _check_ci_locks(self, ci_sys_ids: List[str]):
        """Check if CIs are locked by concurrent operations."""
        # Placeholder: Implement lock checking if you use optimistic locking
        # For now, just warn about potential conflicts
        if len(ci_sys_ids) > 100:
            self.warnings.append("Large batch update - potential for concurrent modification")

    async def _check_business_criticality(self, ci_sys_ids: List[str]):
        """Flag high-criticality CIs that need extra approval."""
        try:
            # Query CIs with business_criticality = "1 - Critical"
            # Sample first 10 to avoid performance issues
            sample_ids = ci_sys_ids[:10]

            for sys_id in sample_ids:
                response = await self.client.get_table_records(
                    table="cmdb_ci",
                    sysparm_query=f"sys_id={sys_id}",
                    sysparm_fields="sys_id,name,business_criticality",
                    sysparm_limit=1
                )
                results = response.get("result", [])
                if results:
                    ci = results[0]
                    criticality = ci.get("business_criticality", "")

                    if "critical" in str(criticality).lower() or criticality == "1":
                        self.warnings.append(
                            f"CI {sys_id} ({ci.get('name')}) is business-critical - requires manager approval"
                        )
        except:
            pass  # Soft check - don't fail if criticality unavailable

    async def validate_single_ci(
        self,
        ci_sys_id: str,
        change_request_id: Optional[str] = None,
        require_cr: bool = False,
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Convenience method to validate a single CI.

        Args:
            ci_sys_id: sys_id of the CI to validate
            change_request_id: Optional CR sys_id
            require_cr: Whether a change request is required

        Returns:
            Tuple of (is_valid, validation_report)
        """
        return await self.validate_change(
            ci_sys_ids=[ci_sys_id],
            change_request_id=change_request_id,
            require_cr=require_cr,
        )
