"""Assess Change Impact Tool

Analyzes the impact of proposed CMDB changes by traversing relationships
and identifying affected services, applications, and business processes.
"""

from typing import Any, Dict, List, Optional, Set
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail


async def assess_change_impact(
    client: ServiceNowClient,
    target_ci_sys_ids: List[str],
    change_type: str = "update",
    max_depth: int = 3,
    include_business_services: bool = True,
    include_applications: bool = True,
    include_users: bool = False,
) -> Dict[str, Any]:
    """
    Assess the impact of a proposed CMDB change.

    Traverses CI relationships to identify affected services, applications,
    and business processes. Calculates risk level based on CI criticality
    and dependency count.

    Args:
        client: ServiceNow client instance
        target_ci_sys_ids: List of CI sys_ids that will be changed
        change_type: Type of change - 'update', 'retire', 'delete', 'merge'
        max_depth: Maximum relationship traversal depth (1-5)
        include_business_services: Include affected business services
        include_applications: Include affected applications
        include_users: Include affected users/user groups

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - impact_summary: High-level impact assessment
        - risk_level: Overall risk (low/medium/high/critical)
        - affected_services: List of affected business services
        - affected_applications: List of affected applications
        - affected_users: List of affected users (if requested)
        - dependency_tree: Hierarchical view of dependencies
        - recommendations: List of recommended actions
        - audit_session_id: Audit trail session ID
    """
    try:
        # Step 1: Initialize foundation layers
        precheck = CmdbChangePrecheck(client)
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # Step 2: Validate target CIs exist
        is_valid, validation_report = await precheck.validate_change(
            ci_sys_ids=target_ci_sys_ids,
            require_cr=False,
            check_criticality=True,
        )

        if not is_valid:
            return {
                "status": "error",
                "error": "Pre-flight validation failed - some CIs do not exist",
                "validation_errors": validation_report["errors"],
            }

        # Step 3: Fetch target CI details
        target_cis = []
        for ci_sys_id in target_ci_sys_ids:
            ci_response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={ci_sys_id}",
                sysparm_fields="sys_id,name,sys_class_name,business_criticality,operational_status",
                sysparm_limit=1
            )
            if ci_response.get("result"):
                target_cis.append(ci_response["result"][0])

        # Step 4: Traverse relationships to find dependencies
        affected_cis: Set[str] = set(target_ci_sys_ids)
        dependency_tree = {}

        for target_ci in target_cis:
            ci_sys_id = target_ci["sys_id"]
            ci_name = target_ci.get("name", "Unknown")

            # Find all relationships where this CI is involved (parent or child)
            relationships = await _get_ci_relationships(
                client, ci_sys_id, max_depth
            )

            dependency_tree[ci_sys_id] = {
                "name": ci_name,
                "class": target_ci.get("sys_class_name"),
                "criticality": target_ci.get("business_criticality"),
                "relationships": relationships,
            }

            # Collect all related CIs
            for rel in relationships:
                related_ci = rel.get("related_ci")
                if related_ci:
                    affected_cis.add(related_ci)

        # Step 5: Categorize affected CIs by type
        affected_services = []
        affected_applications = []
        affected_users = []

        for ci_sys_id in affected_cis:
            if ci_sys_id in target_ci_sys_ids:
                continue  # Skip original targets

            ci_response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={ci_sys_id}",
                sysparm_fields="sys_id,name,sys_class_name,business_criticality",
                sysparm_limit=1
            )

            if not ci_response.get("result"):
                continue

            ci = ci_response["result"][0]
            ci_class = ci.get("sys_class_name", "")

            # Categorize by class
            if include_business_services and "service" in ci_class.lower():
                affected_services.append({
                    "sys_id": ci["sys_id"],
                    "name": ci.get("name"),
                    "class": ci_class,
                    "criticality": ci.get("business_criticality"),
                })
            elif include_applications and "application" in ci_class.lower():
                affected_applications.append({
                    "sys_id": ci["sys_id"],
                    "name": ci.get("name"),
                    "class": ci_class,
                    "criticality": ci.get("business_criticality"),
                })

        # Step 6: Calculate risk level
        risk_level = await _calculate_risk_level(
            target_cis,
            len(affected_services),
            len(affected_applications),
            change_type,
        )

        # Step 7: Generate recommendations
        recommendations = _generate_recommendations(
            risk_level,
            len(affected_services),
            len(affected_applications),
            change_type,
            validation_report.get("warnings", []),
        )

        # Step 8: Record impact assessment in audit trail
        for target_ci in target_cis:
            await audit_trail.record_change(
                tool_name="assess_change_impact",
                change_type="assessment",
                ci_sys_id=target_ci["sys_id"],
                ci_name=target_ci.get("name", "Unknown"),
                before_state=target_ci,
                after_state=target_ci,  # No actual change
                field_diffs=[],
                risk_level=risk_level,
            )

        # Step 9: Build impact summary
        impact_summary = {
            "target_cis": len(target_ci_sys_ids),
            "total_affected_cis": len(affected_cis),
            "affected_services": len(affected_services),
            "affected_applications": len(affected_applications),
            "risk_level": risk_level,
            "change_type": change_type,
        }

        return {
            "status": "success",
            "impact_summary": impact_summary,
            "risk_level": risk_level,
            "affected_services": affected_services[:50],  # Limit to top 50
            "affected_applications": affected_applications[:50],
            "dependency_tree": dependency_tree,
            "recommendations": recommendations,
            "validation_warnings": validation_report.get("warnings", []),
            "audit_session_id": audit_trail.session_id,
            "message": f"Impact assessment complete: {len(affected_services)} services and {len(affected_applications)} applications may be affected (Risk: {risk_level})",
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


async def _get_ci_relationships(
    client: ServiceNowClient,
    ci_sys_id: str,
    max_depth: int = 3,
    current_depth: int = 0,
) -> List[Dict[str, Any]]:
    """Recursively fetch CI relationships up to max_depth."""
    if current_depth >= max_depth:
        return []

    relationships = []

    # Find relationships where CI is parent
    parent_rels = await client.get_table_records(
        table="cmdb_rel_ci",
        sysparm_query=f"parent={ci_sys_id}^active=true",
        sysparm_fields="sys_id,child,type.name",
        sysparm_limit=100,
        sysparm_display_value="false",
    )

    for rel in parent_rels.get("result", []):
        child_sys_id = _extract_sys_id(rel.get("child"))
        if not child_sys_id:
            continue

        relationships.append({
            "related_ci": child_sys_id,
            "relationship_type": rel.get("type.name", "unknown"),
            "direction": "downstream",
            "depth": current_depth + 1,
        })

    # Find relationships where CI is child
    child_rels = await client.get_table_records(
        table="cmdb_rel_ci",
        sysparm_query=f"child={ci_sys_id}^active=true",
        sysparm_fields="sys_id,parent,type.name",
        sysparm_limit=100,
        sysparm_display_value="false",
    )

    for rel in child_rels.get("result", []):
        parent_sys_id = _extract_sys_id(rel.get("parent"))
        if not parent_sys_id:
            continue

        relationships.append({
            "related_ci": parent_sys_id,
            "relationship_type": rel.get("type.name", "unknown"),
            "direction": "upstream",
            "depth": current_depth + 1,
        })

    return relationships


def _extract_sys_id(value: Any) -> Optional[str]:
    """Extract a sys_id string from ServiceNow REST responses."""
    if isinstance(value, dict):
        for key in ("value", "sys_id"):
            sys_id = value.get(key)
            if sys_id:
                return sys_id
        link = value.get("link")
        if link:
            return link.rstrip("/").split("/")[-1]
    elif isinstance(value, str):
        return value
    return None


async def _calculate_risk_level(
    target_cis: List[Dict[str, Any]],
    service_count: int,
    app_count: int,
    change_type: str,
) -> str:
    """Calculate overall risk level based on CI criticality and impact scope."""
    # Check for critical CIs
    has_critical_ci = any(
        "critical" in str(ci.get("business_criticality", "")).lower() or
        ci.get("business_criticality") == "1"
        for ci in target_cis
    )

    # Risk factors
    if change_type in ["delete", "retire"] and has_critical_ci:
        return "critical"
    elif change_type in ["delete", "retire"] or (has_critical_ci and service_count > 5):
        return "high"
    elif service_count > 10 or app_count > 20 or has_critical_ci:
        return "high"
    elif service_count > 5 or app_count > 10:
        return "medium"
    elif service_count > 0 or app_count > 0:
        return "low"
    else:
        return "low"


def _generate_recommendations(
    risk_level: str,
    service_count: int,
    app_count: int,
    change_type: str,
    warnings: List[str],
) -> List[str]:
    """Generate recommendations based on impact assessment."""
    recommendations = []

    if risk_level == "critical":
        recommendations.append("⚠️ CRITICAL RISK: Obtain executive approval before proceeding")
        recommendations.append("Create emergency change request with detailed backout plan")
        recommendations.append("Schedule change during maintenance window")
        recommendations.append("Notify affected business service owners")

    elif risk_level == "high":
        recommendations.append("⚠️ HIGH RISK: Require manager approval")
        recommendations.append("Create standard change request with CAB review")
        recommendations.append("Prepare detailed rollback procedure")
        recommendations.append("Test changes in non-production environment first")

    elif risk_level == "medium":
        recommendations.append("MEDIUM RISK: Create change request and notify stakeholders")
        recommendations.append("Document implementation and backout plans")

    else:
        recommendations.append("LOW RISK: Proceed with standard change management process")

    if service_count > 0:
        recommendations.append(f"Notify owners of {service_count} affected service(s)")

    if app_count > 0:
        recommendations.append(f"Coordinate with {app_count} affected application team(s)")

    if change_type in ["delete", "retire"]:
        recommendations.append("Verify no active dependencies before proceeding with retirement")

    if warnings:
        recommendations.append(f"Review {len(warnings)} validation warning(s) before proceeding")

    return recommendations
