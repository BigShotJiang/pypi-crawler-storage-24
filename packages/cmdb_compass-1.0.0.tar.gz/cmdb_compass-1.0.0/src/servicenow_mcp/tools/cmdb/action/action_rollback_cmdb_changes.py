"""Rollback CMDB Changes Tool

Safely rolls back CMDB changes using audit trail snapshots.
Supports session-based rollback and individual CI rollback.
"""

from typing import Any, Dict, List, Optional
import sys
import json
import os
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


AUDIT_TABLE = os.getenv("SERVICENOW_AUDIT_TABLE", "u_cmdb_change_audit_trail")


async def rollback_cmdb_changes(
    client: ServiceNowClient,
    audit_session_id: Optional[str] = None,
    ci_sys_ids: Optional[List[str]] = None,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
    validate_current_state: bool = True,
) -> Dict[str, Any]:
    """
    Rollback CMDB changes using audit trail snapshots.

    Restores CIs to their previous state using before_state snapshots from
    the audit trail. Supports rolling back entire sessions or individual CIs.
    Includes validation to prevent conflicts with concurrent modifications.

    Args:
        client: ServiceNow client instance
        audit_session_id: Session ID to rollback (rolls back all changes in session)
        ci_sys_ids: Specific CI sys_ids to rollback (alternative to session_id)
        change_request_id: Optional CR authorizing the rollback
        dry_run: If True, validate but don't apply rollback (default: True)
        validate_current_state: If True, verify CI state hasn't changed since audit

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - dry_run: Boolean indicating if this was a dry run
        - cis_rolled_back: Count of CIs successfully rolled back
        - cis_failed: Count of CIs that failed to rollback
        - changes_reverted: Total field changes reverted
        - audit_session_id: New audit session ID for the rollback
        - conflicts: List of CIs with state conflicts (if validate_current_state=True)
        - rollback_details: Details of each CI rollback
    """
    try:
        # Step 1: Validate inputs
        if not audit_session_id and not ci_sys_ids:
            return {
                "status": "error",
                "error": "Either audit_session_id or ci_sys_ids must be provided",
            }

        # Step 2: Initialize foundation layers
        precheck = CmdbChangePrecheck(client)
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # Step 3: Fetch audit records from ServiceNow audit trail table
        # Step 4: Fetch audit records
        if audit_session_id:
            # Query all records for this session
            audit_records = await _fetch_audit_by_session(client, audit_session_id)
        else:
            # Query records for specific CIs (must be provided)
            audit_records = await _fetch_audit_by_cis(client, ci_sys_ids)

        if not audit_records:
            # No real changes found - could be dry-run session or invalid session
            # The helper function already checked for dry-run records and logged info
            return {
                "status": "success",
                "dry_run": dry_run,
                "cis_rolled_back": 0,
                "cis_failed": 0,
                "total_cis": 0,
                "changes_reverted": 0,
                "message": f"No changes to rollback for session {audit_session_id or 'individual CIs'}. Either the session contains only dry-run operations, or no matching audit records exist.",
                "audit_session_id": audit_session_id or "N/A",
            }

        # Step 5: Ensure Change Request exists (auto-create if needed for SOX compliance)
        affected_ci_sys_ids = [r["ci_sys_id"] for r in audit_records]
        success, cr_id, error = await ensure_change_request(
            client=client,
            change_request_id=change_request_id,
            ci_sys_ids=affected_ci_sys_ids,
            tool_name="rollback_cmdb_changes",
            change_description=f"Rollback {len(audit_records)} CI(s) to previous state (session: {audit_session_id or 'individual CIs'})",
            dry_run=dry_run,
            auto_approve=True,
        )

        if not success:
            return {
                "status": "error",
                "error": f"Change Request validation failed: {error}",
            }

        # Use the validated/created CR ID
        change_request_id = cr_id

        # Step 6: Process each audit record for rollback
        cis_rolled_back = 0
        cis_failed = 0
        changes_reverted = 0
        conflicts = []
        rollback_details = []
        affected_cis: List[Dict[str, Any]] = []

        for audit_record in audit_records:
            ci_sys_id = audit_record["ci_sys_id"]
            change_type = audit_record.get("change_type", "")
            before_state = audit_record["before_state"]
            after_state = audit_record["after_state"]

            # Fetch current state
            current_response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={ci_sys_id}",
                sysparm_limit=1
            )

            if not current_response.get("result"):
                cis_failed += 1
                rollback_details.append({
                    "ci_sys_id": ci_sys_id,
                    "status": "failed",
                    "error": "CI not found"
                })
                continue

            current_state = current_response["result"][0]

            # Validate current state matches after_state (no concurrent modifications)
            # Skip validation for retire operations since they have special handling
            if validate_current_state and change_type != "retire":
                if _has_conflicting_changes(current_state, after_state):
                    conflicts.append({
                        "ci_sys_id": ci_sys_id,
                        "ci_name": current_state.get("name"),
                        "issue": "CI has been modified since audit record was created"
                    })
                    if not dry_run:
                        # Skip this CI to prevent overwriting newer changes
                        cis_failed += 1
                        rollback_details.append({
                            "ci_sys_id": ci_sys_id,
                            "status": "skipped",
                            "reason": "concurrent_modification_detected"
                        })
                        continue

            # Calculate rollback changes
            rollback_updates = {}
            for field, old_value in before_state.items():
                if field.startswith("sys_") or field.startswith("_"):
                    continue  # Skip system fields and metadata fields
                if current_state.get(field) != old_value:
                    rollback_updates[field] = old_value

            # Special handling for retire operations
            # cmdb_ci does NOT have an 'active' field - retirement uses install_status and operational_status
            # Ensure these fields are restored to operational values, not the before_state values
            if change_type == "retire":
                # Retired CIs should be reactivated by restoring proper status values
                current_install = str(current_state.get("install_status", "")).lower()
                current_operational = str(current_state.get("operational_status", "")).lower()

                # If currently retired (install_status=7), restore to Installed (1)
                if current_install == "7" or current_install == "retired":
                    rollback_updates["install_status"] = "1"  # Installed
                    print(f"[ROLLBACK] Restoring install_status to Installed for CI: {ci_sys_id}", flush=True)

                # If currently non-operational (operational_status=2), restore to Operational (1)
                if current_operational == "2" or current_operational == "non-operational":
                    rollback_updates["operational_status"] = "1"  # Operational
                    print(f"[ROLLBACK] Restoring operational_status to Operational for CI: {ci_sys_id}", flush=True)

            # Apply rollback (unless dry run)
            if rollback_updates:
                if not dry_run:
                    update_response = await client.update_record(
                        table="cmdb_ci",
                        sys_id=ci_sys_id,
                        data=rollback_updates
                    )

                    if update_response.get("status") == "success":
                        cis_rolled_back += 1
                        changes_reverted += len(rollback_updates)
                        affected_cis.append({
                            "ci_sys_id": ci_sys_id,
                            "ci_name": current_state.get("name"),
                            "fields_reverted": list(rollback_updates.keys()),
                        })
                    else:
                        cis_failed += 1
                        print(f"[ROLLBACK ERROR] Update failed: {update_response.get('error', 'Unknown error')}", flush=True)
                else:
                    # Dry run still reports which fields would change
                    affected_cis.append({
                        "ci_sys_id": ci_sys_id,
                        "ci_name": current_state.get("name"),
                        "fields_reverted": list(rollback_updates.keys()),
                    })
                    changes_reverted += len(rollback_updates)

            # Record rollback in audit trail
            await audit_trail.record_change(
                tool_name="rollback_cmdb_changes",
                change_type="rollback",
                ci_sys_id=ci_sys_id,
                ci_name=current_state.get("name", "Unknown"),
                change_request_id=change_request_id,
                before_state=current_state,
                after_state=before_state,  # Rolling back to before state
                field_diffs=audit_trail.get_field_diffs(current_state, before_state),
                risk_level="medium",
                ci_class=current_state.get("sys_class_name", "cmdb_ci"),
                dry_run=dry_run,
            )

            rollback_details.append({
                "ci_sys_id": ci_sys_id,
                "ci_name": current_state.get("name"),
                "status": "success" if not dry_run else "dry_run",
                "fields_reverted": list(rollback_updates.keys()),
                "changes_count": len(rollback_updates)
            })

        # Step 7: Prepare response
        result = {
            "status": "success",
            "dry_run": dry_run,
            "cis_rolled_back": cis_rolled_back,
            "cis_failed": cis_failed,
            "total_cis": len(audit_records),
            "changes_reverted": changes_reverted,
            "audit_session_id": audit_trail.session_id,
            "change_request_id": change_request_id,
            "conflicts": conflicts,
            "rollback_details": rollback_details,
            "affected_cis": affected_cis,
            "message": f"{'[DRY RUN] ' if dry_run else ''}Rolled back {cis_rolled_back} CI(s) with {changes_reverted} field changes reverted",
        }

        if conflicts:
            result["message"] += f" - {len(conflicts)} conflict(s) detected"

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


def _has_conflicting_changes(current_state: Dict[str, Any], expected_state: Dict[str, Any]) -> bool:
    """Check if current state differs from expected state (concurrent modifications)."""
    for field, expected_value in expected_state.items():
        if field.startswith("sys_"):
            continue
        if current_state.get(field) != expected_value:
            return True
    return False


async def _fetch_audit_by_session(client: ServiceNowClient, session_id: str) -> List[Dict[str, Any]]:
    """Fetch all audit records for a session."""
    try:
        response = await client.get_table_records(
            table=AUDIT_TABLE,
            sysparm_query=f"u_session_id={session_id}^u_dry_run=false",
            sysparm_fields="u_ci_sys_id,u_ci_name,u_before_state,u_after_state,u_change_type,u_checksum,sys_created_on",
            sysparm_limit=1000,
            sysparm_order_by="sys_created_on"  # Chronological order for proper rollback
        )

        records = response.get("result", [])

        # If no real changes found, check if session exists with dry-run records
        if not records:
            dry_run_response = await client.get_table_records(
                table=AUDIT_TABLE,
                sysparm_query=f"u_session_id={session_id}^u_dry_run=true",
                sysparm_fields="u_ci_sys_id",
                sysparm_limit=1
            )

            if dry_run_response.get("result"):
                # Session exists but all operations were dry-run
                # Return empty list with special marker (caller will handle gracefully)
                print(f"[INFO] Session {session_id} contains only dry-run operations - no rollback needed", flush=True)
                return []

        # Parse JSON strings back to dicts
        parsed_records = []
        for record in records:
            try:
                parsed_record = {
                    "ci_sys_id": record.get("u_ci_sys_id", ""),
                    "ci_name": record.get("u_ci_name", ""),
                    "change_type": record.get("u_change_type", ""),
                    "before_state": json.loads(record.get("u_before_state", "{}")),
                    "after_state": json.loads(record.get("u_after_state", "{}")),
                    "checksum": record.get("u_checksum", ""),
                    "timestamp": record.get("sys_created_on", ""),
                }
                parsed_records.append(parsed_record)
            except json.JSONDecodeError as e:
                print(f"[WARNING] Failed to parse audit record JSON: {e}", flush=True)
                continue

        return parsed_records

    except Exception as e:
        print(f"[ERROR] Failed to fetch audit records by session: {e}", flush=True)
        return []


async def _fetch_audit_by_cis(client: ServiceNowClient, ci_sys_ids: List[str]) -> List[Dict[str, Any]]:
    """Fetch most recent audit records for specific CIs."""
    try:
        # Build query for multiple CIs using OR
        query_parts = [f"u_ci_sys_id={sys_id}" for sys_id in ci_sys_ids]
        query = "^OR".join(query_parts) + "^u_dry_run=false"

        response = await client.get_table_records(
            table=AUDIT_TABLE,
            sysparm_query=query,
            sysparm_fields="u_ci_sys_id,u_ci_name,u_before_state,u_after_state,u_change_type,u_checksum,sys_created_on",
            sysparm_limit=len(ci_sys_ids) * 10,  # Get more records to find most recent per CI
            sysparm_order_by="sys_created_on^ORDERBYDesc"  # Most recent first
        )

        records = response.get("result", [])

        # Parse JSON and deduplicate (keep most recent per CI)
        ci_latest = {}
        for record in records:
            try:
                ci_sys_id = record.get("u_ci_sys_id", "")
                if ci_sys_id and ci_sys_id not in ci_latest:
                    parsed_record = {
                        "ci_sys_id": ci_sys_id,
                        "ci_name": record.get("u_ci_name", ""),
                        "change_type": record.get("u_change_type", ""),
                        "before_state": json.loads(record.get("u_before_state", "{}")),
                        "after_state": json.loads(record.get("u_after_state", "{}")),
                        "checksum": record.get("u_checksum", ""),
                        "timestamp": record.get("sys_created_on", ""),
                    }
                    ci_latest[ci_sys_id] = parsed_record
            except json.JSONDecodeError as e:
                print(f"[WARNING] Failed to parse audit record JSON: {e}", flush=True)
                continue

        return list(ci_latest.values())

    except Exception as e:
        print(f"[ERROR] Failed to fetch audit records by CIs: {e}", flush=True)
        return []
