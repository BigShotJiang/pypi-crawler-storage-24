"""Apply Bulk CMDB Changes with Change Request Tool

Applies bulk field updates to multiple CIs with change request integration,
validation, and comprehensive audit trail tracking.
"""

from typing import Any, Dict, List, Optional
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail


async def apply_bulk_cmdb_changes_with_cr(
    client: ServiceNowClient,
    target_ci_sys_ids: List[str],
    field_updates: Dict[str, Any],
    change_request_id: str,
    dry_run: bool = True,
    continue_on_error: bool = False,
    validate_cr_approval: bool = True,
) -> Dict[str, Any]:
    """
    Apply bulk field updates to multiple CIs with change request integration.

    This tool performs mass updates to CI records with comprehensive validation,
    change request approval checking, and detailed audit trail tracking. Supports
    dry-run mode for testing and rollback capability via audit trail snapshots.

    Args:
        client: ServiceNow client instance
        target_ci_sys_ids: List of CI sys_ids to update
        field_updates: Dictionary of field names and new values to apply
        change_request_id: Change request sys_id authorizing this change
        dry_run: If True, validate but don't apply changes (default: True)
        continue_on_error: If True, continue processing after individual CI failures
        validate_cr_approval: If True, require CR to be approved before proceeding

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - dry_run: Boolean indicating if this was a dry run
        - cis_processed: Count of CIs successfully updated
        - cis_failed: Count of CIs that failed to update
        - changes_applied: Total field changes made
        - audit_session_id: Audit trail session ID
        - validation_report: Pre-flight validation results
        - failures: List of individual CI failures (if any)
        - rollback_available: Boolean indicating if rollback is possible
    """
    try:
        # Step 1: Initialize foundation layers
        precheck = CmdbChangePrecheck(client)
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # Step 2: Validate change request and CIs
        is_valid, validation_report = await precheck.validate_change(
            ci_sys_ids=target_ci_sys_ids,
            change_request_id=change_request_id,
            require_cr=True,
            check_criticality=True,
        )

        if not is_valid:
            return {
                "status": "error",
                "error": "Pre-flight validation failed",
                "validation_errors": validation_report["errors"],
                "validation_warnings": validation_report["warnings"],
            }

        # Step 3: Validate field_updates is not empty
        if not field_updates:
            return {
                "status": "error",
                "error": "field_updates cannot be empty",
            }

        # Step 4: Fetch CR details and validate approval if required
        cr_response = await client.get_table_records(
            table="change_request",
            sysparm_query=f"sys_id={change_request_id}",
            sysparm_limit=1,
            sysparm_display_value="false",
        )

        if not cr_response.get("result"):
            return {
                "status": "error",
                "error": f"Change request {change_request_id} not found",
            }

        cr = cr_response["result"][0]
        cr_number = cr.get("number")

        approval_state = str(cr.get("approval", "")).lower()
        if validate_cr_approval and approval_state != "approved":
            return {
                "status": "error",
                "error": f"Change request {cr_number} is not approved (status: {cr.get('approval')})",
                "cr_details": {
                    "number": cr_number,
                    "state": cr.get("state"),
                    "approval": cr.get("approval"),
                },
            }

        # Step 5: Process each CI
        cis_processed = 0
        cis_failed = 0
        changes_applied = 0
        failures = []
        audit_records = []

        for ci_sys_id in target_ci_sys_ids:
            try:
                # Fetch current CI state (before snapshot)
                ci_response = await client.get_table_records(
                    table="cmdb_ci",
                    sysparm_query=f"sys_id={ci_sys_id}",
                    sysparm_limit=1
                )

                if not ci_response.get("result"):
                    error_msg = f"CI {ci_sys_id} not found"
                    failures.append({"ci_sys_id": ci_sys_id, "error": error_msg})
                    cis_failed += 1
                    if not continue_on_error:
                        return {
                            "status": "error",
                            "error": error_msg,
                            "cis_processed": cis_processed,
                            "cis_failed": cis_failed,
                        }
                    continue

                before_state = ci_response["result"][0]
                ci_name = before_state.get("name", "Unknown")

                # Apply updates (unless dry run)
                if not dry_run:
                    update_response = await client.update_record(
                        table="cmdb_ci",
                        sys_id=ci_sys_id,
                        data=field_updates
                    )

                    if update_response.get("status") != "success":
                        error_msg = f"Failed to update CI {ci_sys_id}: {update_response.get('error', 'Unknown error')}"
                        failures.append({"ci_sys_id": ci_sys_id, "error": error_msg})
                        cis_failed += 1
                        if not continue_on_error:
                            return {
                                "status": "error",
                                "error": error_msg,
                                "cis_processed": cis_processed,
                                "cis_failed": cis_failed,
                            }
                        continue

                    # Fetch after state
                    after_response = await client.get_table_records(
                        table="cmdb_ci",
                        sysparm_query=f"sys_id={ci_sys_id}",
                        sysparm_limit=1
                    )
                    after_state = after_response.get("result", [{}])[0]
                else:
                    # Dry run: simulate after state
                    after_state = before_state.copy()
                    after_state.update(field_updates)

                # Calculate field diffs
                field_diffs = audit_trail.get_field_diffs(
                    before_state,
                    after_state,
                    tracked_fields=list(field_updates.keys())
                )

                # Record in audit trail
                audit_record = await audit_trail.record_change(
                    tool_name="apply_bulk_cmdb_changes_with_cr",
                    change_type="update" if not dry_run else "dry_run",
                    ci_sys_id=ci_sys_id,
                    ci_name=ci_name,
                    change_request_id=change_request_id,
                    before_state=before_state,
                    after_state=after_state,
                    field_diffs=field_diffs,
                    risk_level=_calculate_risk_level(len(target_ci_sys_ids), len(field_updates)),
                )

                audit_records.append(audit_record)
                cis_processed += 1
                changes_applied += len(field_diffs)

            except Exception as e:
                error_msg = f"Exception processing CI {ci_sys_id}: {str(e)}"
                failures.append({"ci_sys_id": ci_sys_id, "error": error_msg})
                cis_failed += 1
                if not continue_on_error:
                    return {
                        "status": "error",
                        "error": error_msg,
                        "cis_processed": cis_processed,
                        "cis_failed": cis_failed,
                    }

        # Step 6: Prepare response
        result = {
            "status": "success",
            "dry_run": dry_run,
            "cis_processed": cis_processed,
            "cis_failed": cis_failed,
            "total_cis": len(target_ci_sys_ids),
            "changes_applied": changes_applied,
            "audit_session_id": audit_trail.session_id,
            "audit_records": len(audit_records),
            "change_request": {
                "number": cr_number,
                "sys_id": change_request_id,
                "approval": cr.get("approval"),
            },
            "validation_warnings": validation_report.get("warnings", []),
            "rollback_available": not dry_run and cis_processed > 0,
            "message": f"{'[DRY RUN] ' if dry_run else ''}Successfully processed {cis_processed}/{len(target_ci_sys_ids)} CIs with {changes_applied} field changes (CR: {cr_number})",
        }

        if failures:
            result["failures"] = failures
            result["message"] += f" - {cis_failed} CI(s) failed"

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


def _calculate_risk_level(ci_count: int, field_count: int) -> str:
    """Calculate risk level based on scope of changes."""
    if ci_count > 500 or field_count > 10:
        return "critical"
    elif ci_count > 100 or field_count > 5:
        return "high"
    elif ci_count > 50 or field_count > 3:
        return "medium"
    else:
        return "low"
