"""
Auto-Retire Stale CIs Tool

Automatically retire or deactivate CIs that haven't been updated in 180+ days.
Action-level tool for CMDB data quality improvement (paid, credit-based).
"""

import sys
from datetime import datetime, timedelta
from typing import Any, Dict, Optional
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


async def auto_retire_stale_cis(
    client: ServiceNowClient,
    table_name: str,
    days_threshold: int = 180,
    dry_run: bool = True,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
    ci_sys_ids: Optional[list[str]] = None,
    change_request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Automatically retire or deactivate CIs that haven't been updated in 180+ days.

    This remediation tool identifies and optionally retires old, stale CIs from your CMDB.
    CIs older than 180 days are marked for retirement or deactivated to improve data quality.

    WHEN TO USE:
    - "Clean up our old computer records from 2010-2015"
    - "Retire stale servers that haven't been discovered in over 6 months"
    - "Identify equipment ready for removal from CMDB"

    CSDM PHASE: CONSUME (data quality improvement & hygiene)

    AUDIT LEVELS:
    - quick: $0.20 - Count only, no details
    - standard: $0.60 - Count + sample list (RECOMMENDED)
    - deep: $1.40 - Full list + retirement simulation

    CRITICAL FIELDS UPDATED:
    - install_status: Set to "7" (Retired)
    - operational_status: Set to "7" (Retired)
    - comments: Added retirement reason and timestamp

    ⚠️ WARNING: Discovery can revert CIs back to "Installed" if they're still active on network.
              Exclude retired CI IPs from discovery configuration to prevent automatic reversion.

    Args:
        client: ServiceNow client instance
        table_name: The CI class to retire from (e.g., 'cmdb_ci_computer', 'cmdb_ci_server')
        days_threshold: Age threshold in days (default: 180 days = ~6 months)
        dry_run: If True, only show what would be retired (no actual changes)
        limit: Max CIs to retire in one batch (default: 100, max: 500)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        ci_sys_ids: Optional list of specific CI sys_ids to retire (None = all stale CIs)

    Returns:
        Dictionary containing:
        - table: The CI class analyzed
        - candidates_found: Total CIs eligible for retirement
        - retirement_plan: List of CIs to be retired
        - retirement_summary: By operational status and type
        - estimated_data_quality_improvement: Percentage improvement
        - actions_taken: Count of actual retirements (if dry_run=False)
        - retirement_batch_details: Sample of CIs with retirement metadata
        - discovery_warning: Critical warning about discovery reverting status
        - status: success/error
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Found 487 stale computers (180+ days old). Retire 100 in batch 1.
         Preview: dell-2012-04, hp-laptop-2013-06, lenovo-2011-08 (35 more...)
         Data quality improvement: +2.1%
         ⚠️ Remember to exclude these CIs from discovery to prevent status reversion"
    """
    try:
        # Initialize audit trail
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # Validate inputs
        if limit > 500:
            limit = 500
        if limit < 1:
            limit = 1

        # Calculate cutoff date for stale CIs
        cutoff_date = (datetime.utcnow() - timedelta(days=days_threshold)).isoformat()

        # Get total CI count
        total_response = await client.count_records(table_name)
        total_cis = total_response[0] if isinstance(total_response, tuple) else total_response

        # Query for stale CIs: not updated since cutoff_date
        # Build query: filter by sys_ids if provided, otherwise all stale CIs
        if ci_sys_ids:
            # Filter by specific sys_ids AND staleness criteria
            sys_id_query = "^OR".join([f"sys_id={sys_id}" for sys_id in ci_sys_ids])
            stale_query = f"({sys_id_query})^((most_recent_discoveryISEMPTY|most_recent_discovery<{cutoff_date})^ORsys_updated_on<{cutoff_date})"
        else:
            # All stale CIs
            stale_query = f"(most_recent_discoveryISEMPTY|most_recent_discovery<{cutoff_date})^ORsys_updated_on<{cutoff_date}"

        print(f"[auto_retire_stale_cis] Searching for stale CIs older than {days_threshold} days in {table_name}", file=sys.stderr)
        print(f"[auto_retire_stale_cis] Cutoff date: {cutoff_date}", file=sys.stderr)
        if ci_sys_ids:
            print(f"[auto_retire_stale_cis] Filtering by {len(ci_sys_ids)} specific CI sys_ids", file=sys.stderr)

        stale_records_response = await client.get_table_records(
            table=table_name,
            sysparm_query=stale_query,
            sysparm_fields="sys_id,name,sys_updated_on,most_recent_discovery,operational_status,discovery_source,sys_created_on,sys_class_name",
            sysparm_limit=None  # Get all for analysis
        )

        stale_records = stale_records_response.get("result", [])
        print(f"[auto_retire_stale_cis] Found {len(stale_records)} stale CIs for potential retirement", file=sys.stderr)

        # Filter by operational status and prepare retirement plan
        retirement_candidates = []
        operational_status_breakdown = {}

        for record in stale_records:
            ops_status = record.get("operational_status", "")
            if isinstance(ops_status, dict):
                ops_status = ops_status.get("display_value") or ops_status.get("value") or ""
            ops_status_str = str(ops_status).strip()

            if ops_status_str not in operational_status_breakdown:
                operational_status_breakdown[ops_status_str] = 0
            operational_status_breakdown[ops_status_str] += 1

            retirement_candidates.append({
                "sys_id": record.get("sys_id"),
                "name": record.get("name"),
                "created_date": record.get("sys_created_on"),
                "last_updated": record.get("sys_updated_on"),
                "most_recent_discovery": record.get("most_recent_discovery"),
                "operational_status": ops_status_str,
                "discovery_source": record.get("discovery_source"),
                "age_days": (datetime.utcnow() - datetime.fromisoformat(record.get("sys_created_on", "").replace("Z", "+00:00")) if record.get("sys_created_on") else timedelta(0)).days if record.get("sys_created_on") else "unknown"
            })

        # Sort by age (oldest first)
        retirement_candidates.sort(key=lambda x: x.get("age_days", 0) if isinstance(x.get("age_days"), int) else 0, reverse=True)

        # Take first N for this batch
        retirement_batch = retirement_candidates[:limit]
        remaining_candidates = len(retirement_candidates) - len(retirement_batch)

        print(f"[auto_retire_stale_cis] Planning to retire {len(retirement_batch)} CIs (and {remaining_candidates} more in next batches)", file=sys.stderr)

        # Prepare retirement details
        retirement_details = []
        for ci in retirement_batch:
            retirement_details.append({
                "sys_id": ci["sys_id"],
                "name": ci["name"],
                "age_days": ci["age_days"],
                "created": ci["created_date"],
                "last_updated": ci["last_updated"],
                "status": ci["operational_status"],
                "retirement_action": "Mark as retired" if ci["operational_status"] == "1" else "Deactivate record",
                "reason": f"Stale: No discovery/update in {days_threshold}+ days"
            })

        # Estimate data quality improvement
        # Removing stale CIs improves quality score (fewer quality issues)
        quality_improvement = round((len(retirement_batch) / max(total_cis, 1)) * 100, 2)

        # Ensure Change Request exists (auto-create if needed for SOX compliance)
        ci_sys_ids_to_retire = [ci["sys_id"] for ci in retirement_batch]
        success, cr_id, error = await ensure_change_request(
            client=client,
            change_request_id=change_request_id,
            ci_sys_ids=ci_sys_ids_to_retire,
            tool_name="auto_retire_stale_cis",
            change_description=f"Auto-retire {len(retirement_batch)} stale CI(s) from {table_name} (>{days_threshold} days old)",
            dry_run=dry_run,
            auto_approve=True,
        )

        if not success:
            return {
                "table": table_name,
                "status": "error",
                "error": f"Change Request validation failed: {error}",
                "dry_run": dry_run
            }

        # Use the validated/created CR ID
        change_request_id = cr_id

        # EXECUTE RETIREMENT if not dry_run
        actual_updates = 0
        failed_updates = []

        if not dry_run:
            print(f"[auto_retire_stale_cis] Executing retirement for {len(retirement_batch)} CIs...", file=sys.stderr)

            for ci in retirement_batch:
                try:
                    # Fetch current CI state for audit trail
                    ci_response = await client.get_table_records(
                        table=table_name,
                        sysparm_query=f"sys_id={ci['sys_id']}",
                        sysparm_limit=1
                    )
                    current_ci = ci_response.get("result", [{}])[0] if ci_response.get("result") else {}

                    # CRITICAL: Update BOTH fields (they sync via ServiceNow Business Rule)
                    # operational_status = "7" = Retired
                    # install_status = "7" = Retired
                    # Both fields control CI retirement state
                    update_data = {
                        "operational_status": "7",  # 7 = Retired status
                        "install_status": "7",      # Also update install_status (synced by BR)
                        "comments": f"Retired by ServiceNow MCP - Stale CI cleanup. No discovery/update for {days_threshold}+ days. Retired: {datetime.utcnow().isoformat()}"
                    }

                    update_response = await client.update_record(
                        table=table_name,
                        sys_id=ci["sys_id"],
                        data=update_data
                    )

                    if update_response.get("result"):
                        actual_updates += 1
                        print(f"[auto_retire_stale_cis] ✅ Retired: {ci['name']} (sys_id: {ci['sys_id']})", file=sys.stderr)

                        # Record retirement in audit trail
                        after_state = current_ci.copy()
                        after_state.update(update_data)

                        await audit_trail.record_change(
                            tool_name="auto_retire_stale_cis",
                            change_type="retire",
                            ci_sys_id=ci["sys_id"],
                            ci_name=ci.get("name", "Unknown"),
                            change_request_id=change_request_id,
                            before_state=current_ci,
                            after_state=after_state,
                            field_diffs=[
                                {"field": "operational_status", "old_value": current_ci.get("operational_status"), "new_value": "7", "change_type": "modified"},
                                {"field": "install_status", "old_value": current_ci.get("install_status"), "new_value": "7", "change_type": "modified"}
                            ],
                            risk_level="medium",
                            ci_class=current_ci.get("sys_class_name", table_name),
                            dry_run=False,
                        )
                    else:
                        failed_updates.append({"name": ci["name"], "error": "No result in response"})
                        print(f"[auto_retire_stale_cis] ⚠️ Failed to retire: {ci['name']}", file=sys.stderr)

                except Exception as e:
                    failed_updates.append({"name": ci["name"], "error": str(e)})
                    print(f"[auto_retire_stale_cis] ❌ Error retiring {ci['name']}: {e}", file=sys.stderr)

            print(f"[auto_retire_stale_cis] Retirement complete: {actual_updates}/{len(retirement_batch)} successful", file=sys.stderr)

        # Prepare response
        response = {
            "table": table_name,
            "days_threshold": days_threshold,
            "candidates_found": len(retirement_candidates),
            "retirement_batch_size": len(retirement_batch),
            "remaining_candidates": remaining_candidates,
            "dry_run": dry_run,
            "retirement_plan": {
                "batch_size": len(retirement_batch),
                "total_identified": len(retirement_candidates),
                "suggested_batches": max(1, (len(retirement_candidates) + limit - 1) // limit),
                "next_batch_estimate": remaining_candidates
            },
            "retirement_summary": {
                "operational_status_breakdown": operational_status_breakdown,
                "oldest_ci_age_days": max([c["age_days"] for c in retirement_batch if isinstance(c["age_days"], int)], default=0),
                "newest_ci_age_days": min([c["age_days"] for c in retirement_batch if isinstance(c["age_days"], int)], default=0),
                "average_age_days": round(sum([c["age_days"] for c in retirement_batch if isinstance(c["age_days"], int)]) / max(len(retirement_batch), 1), 1)
            },
            "estimated_data_quality_improvement": f"+{quality_improvement}%",
            "retirement_batch_details": retirement_details[:10] if audit_level in ["standard", "deep"] else [],
            "sample_cis": [r["name"] for r in retirement_details[:5]],
            "actions_taken": actual_updates if not dry_run else 0,
            "failed_updates_count": len(failed_updates) if not dry_run else 0,
            "failed_updates": failed_updates if failed_updates else None,
            "next_steps": [
                f"1. Review the {len(retirement_batch)} CIs in retirement_batch_details",
                f"2. Call with dry_run=False to execute retirement",
                f"3. Monitor compliance improvements in CMDB Health Dashboard",
                f"4. Process remaining {remaining_candidates} CIs in subsequent batches" if remaining_candidates > 0 else "4. All stale CIs processed!"
            ] if dry_run else [
                f"✅ Retired {actual_updates}/{len(retirement_batch)} CIs",
                f"⏳ {remaining_candidates} more CIs ready in next batch",
                f"📊 Expected data quality improvement: +{quality_improvement}%"
            ] + (
                [f"⚠️ {len(failed_updates)} CIs failed to retire - check failed_updates list"] if failed_updates else []
            ),
            "discovery_warning": "⚠️ CRITICAL: Discovery can revert 'Retired' CIs back to 'Installed' if they are still active on the network. Exclude these CIs' IPs from your discovery configuration to prevent automatic status reversion.",
            "remediation_steps": [
                "1. Verify CIs are actually retired in ServiceNow (install_status = 7)",
                "2. Exclude retired CI IPs from discovery scopes to prevent reversion",
                "3. Consider decommissioning or removing from network if still present",
                "4. Update any dependent CI relationships as needed"
            ] if not dry_run else [],
            "status": "success" if (dry_run or actual_updates > 0) else "partial_failure",
            "audit_session_id": audit_trail.session_id,
            "change_request_id": change_request_id,
            "audit_metadata": build_audit_metadata(audit_level, len(retirement_candidates), len(retirement_batch))
        }

        return response

    except Exception as e:
        print(f"[ERROR] auto_retire_stale_cis failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "table": table_name,
            "status": "error",
            "error": str(e),
            "dry_run": dry_run
        }
