"""
Auto-Heal Relationship Issues Tool (Phase 3 Week 2 Tool #4)

Automatically remediate relationship integrity violations detected by
audit_validate_relationship_integrity. Removes orphans, normalizes types,
and optionally recreates missing relationships.

Action workflow:
  audit_validate_relationship_integrity → action_auto_heal_relationship_issues

Includes Phase 2C audit_trail + precheck integration for compliance and safety.
"""

import re
import sys
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


async def action_auto_heal_relationship_issues(
    client: ServiceNowClient,
    ci_class: Optional[str] = None,
    fix_orphaned: bool = True,
    fix_invalid_types: bool = True,
    fix_missing_types: bool = False,
    recreate_missing: bool = False,
    dry_run: bool = True,
    change_request_id: Optional[str] = None,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Auto-heal relationship integrity issues (orphans, invalid types, missing types).

    This action tool automatically remediates relationship integrity violations
    identified by audit_validate_relationship_integrity. Removes orphaned
    relationships, normalizes invalid types to CSDM 5.0 standards, and optionally
    classifies untyped relationships.

    CSDM PHASE: REMEDIATE (automated relationship integrity repair)

    REMEDIATION ACTIONS:
    1. Remove orphaned relationships (parent or child CI missing)
    2. Normalize invalid relationship types to CSDM 5.0 equivalents
    3. Classify untyped relationships (optional)
    4. Recreate expected relationships (optional, advanced)

    SAFETY FEATURES:
    - Phase 2C audit_trail integration (full change tracking)
    - Phase 2C precheck validation (soft validation before execution)
    - dry_run mode (preview changes without applying)
    - Batch limit (max 1000 relationships per execution)
    - Change Request integration (optional CR tracking)

    AUDIT LEVELS:
    - quick: Summary only (counts, no details)
    - standard: Summary + sample changes (recommended)
    - deep: Full change log with before/after states

    Args:
        client: ServiceNow client instance
        ci_class: Optional CI class filter (e.g., 'cmdb_ci_server')
        fix_orphaned: Remove orphaned relationships (default: True)
        fix_invalid_types: Normalize invalid types to CSDM (default: True)
        fix_missing_types: Classify untyped relationships (default: False)
        recreate_missing: Recreate expected relationships (default: False, advanced)
        dry_run: Preview mode - no actual changes (default: True)
        change_request_id: Optional Change Request sys_id for tracking
        limit: Max relationships to fix per execution (default: 100, max: 1000)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - ci_class: The CI class filter applied
        - dry_run: Whether this was a preview
        - changes_planned: Total changes to be made
        - changes_applied: Actual changes made (0 if dry_run)
        - orphaned_removed: Count of orphaned relationships removed
        - types_normalized: Count of invalid types normalized
        - types_classified: Count of missing types classified
        - relationships_recreated: Count of relationships recreated (if enabled)
        - change_details: List of individual changes (sample or full)
        - precheck_results: Validation results from precheck
        - audit_trail_session: Audit trail session ID (if changes applied)
        - recommendations: Next steps and follow-up actions
        - status: success/error
        - audit_metadata: Execution details and cost

    EXAMPLE OUTPUT:
        "[DRY RUN] Would remove 145 orphaned relationships, normalize 89 invalid types.
         Total changes: 234. Re-run with dry_run=False to apply changes.
         Change Request: CHG0012345. Audit trail session: CMDB_CHANGE_20250118_123456_a1b2c3d4."

    IMPORTANT:
        - Always run with dry_run=True first to preview changes
        - For production changes, provide change_request_id
        - Circular dependencies require manual review (not auto-healed)
        - Recreating relationships is advanced - use with caution
    """
    try:
        start_time = datetime.now()
        print(f"[action_auto_heal_relationship_issues] Starting (dry_run={dry_run}, ci_class={ci_class})", file=sys.stderr)

        # Validate limit
        if limit > 1000:
            limit = 1000
        if limit < 1:
            limit = 1

        # Initialize audit trail and precheck
        audit_trail = CmdbChangeAuditTrail(client)
        precheck = CmdbChangePrecheck(client)

        # Ensure Change Request exists (auto-create if needed for SOX compliance)
        success, cr_id, error = await ensure_change_request(
            client=client,
            change_request_id=change_request_id,
            ci_sys_ids=[],  # Will be determined during validation
            tool_name="auto_heal_relationship_issues",
            change_description=f"Auto-heal relationship issues (class: {ci_class or 'all'}, orphans: {fix_orphaned}, invalid types: {fix_invalid_types})",
            dry_run=dry_run,
            auto_approve=True,
        )

        if not success:
            return {
                "status": "error",
                "error": f"Change Request validation failed: {error}",
            }

        # Use the validated/created CR ID
        change_request_id = cr_id

        # First, run audit_validate_relationship_integrity to find issues
        print(f"[action_auto_heal_relationship_issues] Running integrity validation...", file=sys.stderr)

        # Import the audit tool
        from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import audit_validate_relationship_integrity

        validation_result = await audit_validate_relationship_integrity(
            client=client,
            ci_class=ci_class,
            audit_level=audit_level,
            check_circular=False,  # Don't check circular deps (not auto-healable)
        )

        if validation_result.get("status") == "error":
            return {
                "status": "error",
                "error": f"Validation failed: {validation_result.get('error')}",
            }

        violation_summary = validation_result.get("violation_summary", {})
        orphaned_list = validation_result.get("orphaned_relationships", [])
        invalid_type_list = validation_result.get("invalid_type_relationships", [])
        missing_type_list = validation_result.get("missing_type_relationships", [])

        print(f"[action_auto_heal_relationship_issues] Found {len(orphaned_list)} orphaned, {len(invalid_type_list)} invalid types, {len(missing_type_list)} missing types", file=sys.stderr)

        # Plan changes
        changes_to_make = []

        # 1. Plan orphaned relationship removals
        if fix_orphaned:
            for orphaned in orphaned_list[:limit]:
                changes_to_make.append({
                    "action": "delete",
                    "relationship_sys_id": orphaned.get("relationship_sys_id"),
                    "reason": f"Orphaned: {orphaned.get('reason')}",
                    "parent_sys_id": orphaned.get("parent_sys_id"),
                    "child_sys_id": orphaned.get("child_sys_id"),
                })

        # 2. Plan invalid type normalizations
        if fix_invalid_types:
            remaining_limit = limit - len(changes_to_make)
            for invalid in invalid_type_list[:remaining_limit]:
                normalized_type = _normalize_relationship_type(invalid.get("invalid_type"))
                changes_to_make.append({
                    "action": "update_type",
                    "relationship_sys_id": invalid.get("relationship_sys_id"),
                    "parent_sys_id": invalid.get("parent_sys_id"),
                    "child_sys_id": invalid.get("child_sys_id"),
                    "old_type": invalid.get("invalid_type"),
                    "new_type": normalized_type,
                    "reason": "Normalize to CSDM 5.0 type",
                })

        # 3. Plan missing type classifications
        if fix_missing_types:
            remaining_limit = limit - len(changes_to_make)
            for missing in missing_type_list[:remaining_limit]:
                # Classify based on parent/child CI classes (placeholder logic)
                suggested_type = "Depends on::Depended on by"  # Default fallback
                changes_to_make.append({
                    "action": "classify",
                    "relationship_sys_id": missing.get("relationship_sys_id"),
                    "parent_sys_id": missing.get("parent_sys_id"),
                    "child_sys_id": missing.get("child_sys_id"),
                    "new_type": suggested_type,
                    "reason": "Classify untyped relationship",
                })

        # 4. Recreate missing relationships (advanced, optional)
        if recreate_missing:
            # This is an advanced feature - would require additional logic
            # to determine which relationships should exist
            pass

        changes_planned = len(changes_to_make)

        # Enrich changes with parent/child sys_ids if missing or invalid.
        # The audit tool may return display names (e.g. "WEBSERVER-FLX") instead of
        # 32-char hex sys_ids when sysparm_display_value isn't set correctly.
        _SYS_ID_RE = re.compile(r'^[0-9a-f]{32}$')

        def _is_valid_sys_id(val: str) -> bool:
            return bool(val and _SYS_ID_RE.match(val))

        changes_needing_enrichment = [
            c for c in changes_to_make
            if not _is_valid_sys_id(c.get("parent_sys_id", ""))
            or not _is_valid_sys_id(c.get("child_sys_id", ""))
        ]
        
        if changes_needing_enrichment:
            print(f"[action_auto_heal_relationship_issues] Enriching {len(changes_needing_enrichment)} changes with parent/child sys_ids", file=sys.stderr)
            rel_sys_ids = [
                r.get("value") if isinstance(r, dict) else r
                for c in changes_needing_enrichment
                if (r := c.get("relationship_sys_id"))
            ]
            
            if rel_sys_ids:
                try:
                    # Batch fetch relationship records with sysparm_display_value=false
                    # to get raw sys_id values for reference fields (parent, child)
                    for i in range(0, len(rel_sys_ids), 50):
                        batch = rel_sys_ids[i:i+50]
                        query = f"sys_idIN{','.join(batch)}"
                        
                        rel_response = await client.get_table_records(
                            table="cmdb_rel_ci",
                            sysparm_query=query,
                            sysparm_fields="sys_id,parent,child",
                            sysparm_limit=len(batch),
                            sysparm_display_value="false",  # Get raw sys_id values
                        )
                        
                        # Build lookup map
                        rel_map = {}
                        for rel in rel_response.get("result", []):
                            rel_id = rel.get("sys_id")
                            parent_val = rel.get("parent")
                            child_val = rel.get("child")
                            
                            # With sysparm_display_value=false, reference fields return as:
                            # - Direct string sys_id (most common)
                            # - Or {"value": "sys_id"} object (less common)
                            # - Or empty string "" if no reference set
                            if isinstance(parent_val, dict):
                                parent_id = parent_val.get("value") or ""
                            else:
                                parent_id = parent_val or ""
                            
                            if isinstance(child_val, dict):
                                child_id = child_val.get("value") or ""
                            else:
                                child_id = child_val or ""
                            
                            rel_map[rel_id] = {"parent": parent_id, "child": child_id}
                            print(f"[DEBUG] Relationship {rel_id}: parent={parent_id}, child={child_id}", file=sys.stderr)
                        
                        # Update changes with enriched data
                        enriched_count = 0
                        for change in changes_to_make:
                            raw_id = change.get("relationship_sys_id")
                            rel_id = raw_id.get("value") if isinstance(raw_id, dict) else raw_id
                            if rel_id in rel_map:
                                if not _is_valid_sys_id(change.get("parent_sys_id", "")) and rel_map[rel_id].get("parent"):
                                    change["parent_sys_id"] = rel_map[rel_id]["parent"]
                                    enriched_count += 1
                                if not _is_valid_sys_id(change.get("child_sys_id", "")) and rel_map[rel_id].get("child"):
                                    change["child_sys_id"] = rel_map[rel_id]["child"]
                                    enriched_count += 1
                        
                        print(f"[action_auto_heal_relationship_issues] Enriched {enriched_count} fields from batch", file=sys.stderr)
                    
                    print(f"[action_auto_heal_relationship_issues] Enrichment complete", file=sys.stderr)
                except Exception as e:
                    print(f"[WARNING] Could not enrich relationship data: {e}", file=sys.stderr)
                    import traceback
                    traceback.print_exc(file=sys.stderr)

        print(f"[action_auto_heal_relationship_issues] Planned {changes_planned} changes", file=sys.stderr)

        # If no changes, return early
        if changes_planned == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "ci_class": ci_class,
                "dry_run": dry_run,
                "changes_planned": 0,
                "changes_applied": 0,
                "status": "success",
                "message": "No relationship issues found to fix",
                "metadata": build_audit_metadata(
                    audit_type="auto_heal_relationships",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class or "all"
                ),
            }

        # Run precheck validation (only for non-dry-run)
        precheck_results = {}
        if not dry_run:
            # Note: Relationships are NOT CIs, so we skip CI-based precheck validation.
            # Relationship records (cmdb_rel_ci) have their own sys_ids that are not in CI tables.
            # Instead, we validate that we have a valid change request if required.
            
            if change_request_id:
                # Just verify the change request exists and is valid
                try:
                    cr_response = await client.query_table(
                        "change_request",
                        query=f"sys_id={change_request_id}",
                        limit=1,
                        fields=["sys_id", "number", "state", "approval"]
                    )
                    if not cr_response:
                        precheck_results = {
                            "valid": False,
                            "error": f"Change Request {change_request_id} not found",
                        }
                        return {
                            "ci_class": ci_class,
                            "dry_run": dry_run,
                            "changes_planned": changes_planned,
                            "changes_applied": 0,
                            "status": "error",
                            "error": "Precheck validation failed - Change Request not found",
                            "precheck_results": precheck_results,
                        }
                    precheck_results = {
                        "valid": True,
                        "change_request": cr_response[0] if cr_response else None,
                        "note": "Relationship changes validated against Change Request",
                    }
                except Exception as e:
                    print(f"[WARN] Could not validate Change Request: {e}", file=sys.stderr)
                    precheck_results = {"valid": True, "note": "CR validation skipped"}
            else:
                precheck_results = {"valid": True, "note": "No CR required for relationship changes"}

        # If dry_run, return preview
        if dry_run:
            sample_size = min(10, changes_planned) if audit_level == "standard" else (0 if audit_level == "quick" else changes_planned)
            execution_time = (datetime.now() - start_time).total_seconds()

            return {
                "ci_class": ci_class,
                "dry_run": True,
                "changes_planned": changes_planned,
                "changes_applied": 0,
                "orphaned_removed": sum(1 for c in changes_to_make if c.get("action") == "delete"),
                "types_normalized": sum(1 for c in changes_to_make if c.get("action") == "update_type"),
                "types_classified": sum(1 for c in changes_to_make if c.get("action") == "classify"),
                "relationships_recreated": 0,
                "affected_cis_linked": 0,
                "change_details": changes_to_make[:sample_size],
                "change_request": change_request_id,
                "recommendations": [
                    {
                        "action": "Re-run with dry_run=False to apply changes",
                        "impact": f"Will modify {changes_planned} relationships",
                    },
                    {
                        "action": "Provide change_request_id for production changes",
                        "impact": "Links changes to approved Change Request",
                    },
                ],
                "status": "success",
                "metadata": build_audit_metadata(
                    audit_type="auto_heal_relationships",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class or "all"
                ),
            }

        # Apply changes (actual execution)
        print(f"[action_auto_heal_relationship_issues] Applying {changes_planned} changes...", file=sys.stderr)

        changes_applied = 0
        orphaned_removed = 0
        types_normalized = 0
        types_classified = 0
        change_log = []

        for change in changes_to_make:
            try:
                action_type = change.get("action")
                raw_rel_id = change.get("relationship_sys_id")
                relationship_sys_id = raw_rel_id.get("value") if isinstance(raw_rel_id, dict) else raw_rel_id

                if action_type == "delete":
                    # Remove orphaned relationship
                    await client.delete_record("cmdb_rel_ci", relationship_sys_id)

                    # Record in audit trail
                    await audit_trail.record_change(
                        tool_name="action_auto_heal_relationship_issues",
                        change_type="delete",
                        ci_sys_id=relationship_sys_id,
                        ci_name=f"Relationship {relationship_sys_id}",
                        change_request_id=change_request_id,
                        before_state={"reason": change.get("reason")},
                        risk_level="low",
                    )

                    orphaned_removed += 1
                    changes_applied += 1

                elif action_type == "update_type":
                    # Normalize invalid type
                    update_data = {
                        "type": change.get("new_type"),
                    }

                    await client.update_record("cmdb_rel_ci", relationship_sys_id, update_data)

                    # Record in audit trail
                    await audit_trail.record_change(
                        tool_name="action_auto_heal_relationship_issues",
                        change_type="update",
                        ci_sys_id=relationship_sys_id,
                        ci_name=f"Relationship {relationship_sys_id}",
                        change_request_id=change_request_id,
                        before_state={"type": change.get("old_type")},
                        after_state={"type": change.get("new_type")},
                        field_diffs=[{
                            "field": "type",
                            "old_value": change.get("old_type"),
                            "new_value": change.get("new_type"),
                            "change_type": "normalize",
                        }],
                        risk_level="low",
                    )

                    types_normalized += 1
                    changes_applied += 1

                elif action_type == "classify":
                    # Classify untyped relationship
                    update_data = {
                        "type": change.get("new_type"),
                    }

                    await client.update_record("cmdb_rel_ci", relationship_sys_id, update_data)

                    # Record in audit trail
                    await audit_trail.record_change(
                        tool_name="action_auto_heal_relationship_issues",
                        change_type="update",
                        ci_sys_id=relationship_sys_id,
                        ci_name=f"Relationship {relationship_sys_id}",
                        change_request_id=change_request_id,
                        after_state={"type": change.get("new_type")},
                        field_diffs=[{
                            "field": "type",
                            "old_value": None,
                            "new_value": change.get("new_type"),
                            "change_type": "classify",
                        }],
                        risk_level="low",
                    )

                    types_classified += 1
                    changes_applied += 1

                change_log.append({
                    "relationship_sys_id": relationship_sys_id,
                    "action": action_type,
                    "status": "success",
                    **change,
                })

            except Exception as e:
                print(f"[ERROR] Failed to apply change for relationship {relationship_sys_id}: {e}", file=sys.stderr)
                change_log.append({
                    "relationship_sys_id": relationship_sys_id,
                    "action": action_type,
                    "status": "error",
                    "error": str(e),
                })

        print(f"[action_auto_heal_relationship_issues] Applied {changes_applied}/{changes_planned} changes successfully", file=sys.stderr)

        # Link affected CIs to the Change Request via task_ci table
        affected_cis_linked = 0
        if change_request_id and changes_applied > 0:
            # Collect unique CI sys_ids from the relationships we modified
            # (parent/child sys_ids are stored in change_log for all action types)
            affected_ci_sys_ids = set()
            for change in change_log:
                if change.get("status") == "success":
                    parent_id = change.get("parent_sys_id")
                    child_id = change.get("child_sys_id")
                    if _is_valid_sys_id(parent_id or ""):
                        affected_ci_sys_ids.add(parent_id)
                    if _is_valid_sys_id(child_id or ""):
                        affected_ci_sys_ids.add(child_id)
            
            # Link CIs to the Change Request (limit to 50 to avoid performance issues)
            linked_count = 0
            for ci_sys_id in list(affected_ci_sys_ids)[:50]:
                try:
                    await client.create_record(
                        table="task_ci",
                        data={
                            "task": change_request_id,
                            "ci_item": ci_sys_id,
                        }
                    )
                    linked_count += 1
                except Exception as e:
                    # Might fail if already linked or ACL restriction
                    print(f"[WARNING] Failed to link CI {ci_sys_id} to CR: {e}", file=sys.stderr)
            
            affected_cis_linked = linked_count
            print(f"[action_auto_heal_relationship_issues] Linked {linked_count}/{len(affected_ci_sys_ids)} affected CIs to Change Request {change_request_id}", file=sys.stderr)

        # Fetch the human-readable CHG number
        change_request_number = None
        if change_request_id:
            try:
                cr_lookup = await client.get_table_records(
                    table="change_request",
                    sysparm_query=f"sys_id={change_request_id}",
                    sysparm_limit=1,
                    sysparm_fields="number",
                )
                if cr_lookup.get("result"):
                    change_request_number = cr_lookup["result"][0].get("number")
            except Exception:
                pass

        # Prepare result
        sample_size = min(10, len(change_log)) if audit_level == "standard" else (0 if audit_level == "quick" else len(change_log))
        execution_time = (datetime.now() - start_time).total_seconds()

        return {
            "ci_class": ci_class,
            "dry_run": False,
            "changes_planned": changes_planned,
            "changes_applied": changes_applied,
            "orphaned_removed": orphaned_removed,
            "types_normalized": types_normalized,
            "types_classified": types_classified,
            "relationships_recreated": 0,
            "affected_cis_linked": affected_cis_linked,
            "change_details": change_log[:sample_size],
            "change_request": change_request_id,
            "change_request_id": change_request_id,
            "change_request_number": change_request_number,
            "audit_trail_session": audit_trail.session_id,
            "audit_session_id": audit_trail.session_id,  # Standardized field name
            "precheck_results": precheck_results,
            "recommendations": [
                {
                    "action": "Re-run audit_validate_relationship_integrity to verify fixes",
                    "impact": "Confirms relationship integrity improved",
                },
                {
                    "action": "Monitor relationship health score over time",
                    "impact": "Tracks sustained data quality improvement",
                },
            ],
            "status": "success",
            "metadata": build_audit_metadata(
                audit_type="auto_heal_relationships",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class or "all"
            ),
        }

    except Exception as e:
        print(f"[ERROR] action_auto_heal_relationship_issues failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "ci_class": ci_class,
            "dry_run": dry_run,
            "status": "error",
            "error": str(e),
        }


def _normalize_relationship_type(invalid_type: str) -> str:
    """
    Normalize invalid relationship type to CSDM 5.0 equivalent.

    Maps common legacy or invalid types to standard CSDM types.
    """
    # Mapping table for common invalid types
    normalization_map = {
        # Legacy types
        "Runs": "Runs on::Runs",
        "Contains": "Contains::Contained by",
        "Uses": "Uses::Used by",
        "Manages": "Manages::Managed by",
        "Depends": "Depends on::Depended on by",
        "Connects": "Connects to::Connected by",
        "Hosts": "Hosted on::Hosts",

        # Common typos or variations
        "runs on": "Runs on::Runs",
        "contains": "Contains::Contained by",
        "depends on": "Depends on::Depended on by",
        "hosted on": "Hosted on::Hosts",
        "connected to": "Connects to::Connected by",

        # Default fallback
        "": "Depends on::Depended on by",
    }

    invalid_lower = invalid_type.lower().strip()

    for key, value in normalization_map.items():
        if key.lower() in invalid_lower:
            return value

    # If no mapping found, return "Depends on" as safe default
    return "Depends on::Depended on by"
