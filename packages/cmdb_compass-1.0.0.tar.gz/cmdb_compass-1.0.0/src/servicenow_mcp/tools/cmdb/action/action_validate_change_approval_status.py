"""Validate Change Approval Status Tool

Validates ServiceNow change request approval status and readiness for CMDB modifications.
Checks approval state, CAB approval, and workflow status.
"""

from typing import Any, Dict, Optional
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient


async def validate_change_approval_status(
    client: ServiceNowClient,
    change_request_id: str,
    require_implementation_ready: bool = False,
) -> Dict[str, Any]:
    """
    Validate change request approval status and readiness.

    Checks if a change request is approved and ready for CMDB modifications.
    Includes approval state, CAB approval status, approver details, and
    workflow validation.

    Args:
        client: ServiceNow client instance
        change_request_id: Change request sys_id or number (CHG0001234)
        require_implementation_ready: If True, require CR to be in implement state

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - is_approved: Boolean indicating if CR is approved
        - is_ready_for_implementation: Boolean for implementation readiness
        - cr_details: Full CR record details
        - approval_history: List of approval records
        - validation_summary: Summary of validation checks
        - recommendations: List of recommended actions
    """
    try:
        # Step 1: Fetch change request (handle both sys_id and number)
        if change_request_id.startswith("CHG"):
            # CR number provided
            query = f"number={change_request_id}"
        else:
            # sys_id provided
            query = f"sys_id={change_request_id}"

        cr_response = await client.get_table_records(
            table="change_request",
            sysparm_query=query,
            sysparm_limit=1
        )

        if not cr_response.get("result"):
            return {
                "status": "error",
                "error": f"Change request {change_request_id} not found",
            }

        cr = cr_response["result"][0]
        cr_sys_id = cr.get("sys_id")
        cr_number = cr.get("number")

        # Step 2: Check approval status (case-insensitive to handle display values)
        approval_display = cr.get("approval", "")
        state_display = cr.get("state", "")
        approval_status = cr.get("approval_status", "")

        approval_value = str(approval_display).lower()
        state_value = str(state_display).lower()

        is_approved = approval_value == "approved"
        is_implementation_ready = state_value in ["implement", "scheduled"]
        is_closed_or_canceled = state_value in ["closed", "canceled"]

        # Step 3: Fetch approval history
        approval_history = []
        try:
            approvals_response = await client.get_table_records(
                table="sysapproval_approver",
                sysparm_query=f"sysapproval={cr_sys_id}",
                sysparm_fields="sys_id,approver.name,state,comments,sys_created_on",
                sysparm_limit=50
            )

            for approval_record in approvals_response.get("result", []):
                approval_history.append({
                    "approver": approval_record.get("approver.name", "Unknown"),
                    "state": approval_record.get("state", ""),
                    "comments": approval_record.get("comments", ""),
                    "timestamp": approval_record.get("sys_created_on", ""),
                })
        except:
            # Approval history is optional, don't fail if not available
            pass

        # Step 4: Perform validation checks
        validation_checks = {
            "cr_exists": True,
            "is_approved": is_approved,
            "not_closed_or_canceled": not is_closed_or_canceled,
            "implementation_ready": is_implementation_ready,
            "has_approval_history": len(approval_history) > 0,
        }

        # Step 5: Determine overall readiness
        is_ready = is_approved and not is_closed_or_canceled

        if require_implementation_ready:
            is_ready = is_ready and is_implementation_ready

        # Step 6: Generate recommendations
        recommendations = []

        if not is_approved:
            recommendations.append(
                f"⚠️ CR {cr_number} is not approved (status: {approval_display}). Obtain required approvals before proceeding."
            )

        if is_closed_or_canceled:
            recommendations.append(
                f"⚠️ CR {cr_number} is {state_display}. Cannot proceed with closed or canceled change requests."
            )

        if require_implementation_ready and not is_implementation_ready:
            recommendations.append(
                f"⚠️ CR {cr_number} is not in implementation state (current: {state_display}). Move CR to 'Implement' or 'Scheduled' state."
            )

        if is_approved and not is_closed_or_canceled and is_implementation_ready:
            recommendations.append(
                f"✓ CR {cr_number} is approved and ready for implementation"
            )
        elif is_approved and not is_closed_or_canceled:
            recommendations.append(
                f"✓ CR {cr_number} is approved. Update state to 'Implement' when ready to proceed."
            )

        # Step 7: Build validation summary
        validation_summary = {
            "overall_status": "ready" if is_ready else "not_ready",
            "approval_state": approval_display,
            "change_state": state_display,
            "approvals_received": len(approval_history),
            "checks_passed": sum(1 for v in validation_checks.values() if v),
            "checks_failed": sum(1 for v in validation_checks.values() if not v),
        }

        # Step 8: Prepare response
        result = {
            "status": "success",
            "is_approved": is_approved,
            "is_ready_for_implementation": is_ready,
            "cr_details": {
                "number": cr_number,
                "sys_id": cr_sys_id,
                "short_description": cr.get("short_description"),
                "state": state_display,
                "approval": approval_display,
                "approval_status": approval_status,
                "risk": cr.get("risk"),
                "impact": cr.get("impact"),
                "priority": cr.get("priority"),
                "requested_by": cr.get("requested_by.name", ""),
                "assigned_to": cr.get("assigned_to.name", ""),
                "start_date": cr.get("start_date", ""),
                "end_date": cr.get("end_date", ""),
            },
            "approval_history": approval_history,
            "validation_checks": validation_checks,
            "validation_summary": validation_summary,
            "recommendations": recommendations,
            "message": f"CR {cr_number} validation complete: {'✓ Ready' if is_ready else '✗ Not ready'} for implementation",
        }

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }
