"""Normalize CI Naming Conventions Tool

Standardizes CI names according to organizational naming conventions.
ACTION tool with precheck validation and audit trail integration.
"""

from typing import Any, Dict, List, Optional
import re
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


async def normalize_ci_naming_conventions(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    naming_pattern: Optional[str] = None,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
    auto_detect_pattern: bool = True,
    case_style: str = "uppercase",  # uppercase, lowercase, titlecase
    ci_sys_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Normalize CI names according to naming conventions.

    Standardizes CI names to match organizational naming patterns. Supports
    auto-detection of existing patterns or custom pattern specification.
    Includes validation, audit trail, and dry-run mode.

    Args:
        client: ServiceNow client instance
        ci_class: CI class to normalize (e.g., cmdb_ci_server)
        naming_pattern: Regex pattern for valid names (None = auto-detect)
        change_request_id: Optional CR authorizing naming changes
        dry_run: If True, analyze but don't apply changes
        auto_detect_pattern: If True, detect common naming pattern from existing CIs
        case_style: Name case normalization (uppercase/lowercase/titlecase)
        ci_sys_ids: Optional list of specific CI sys_ids to normalize (None = all active CIs)

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - dry_run: Boolean indicating if this was a dry run
        - ci_class: CI class analyzed
        - total_cis: Total CIs analyzed
        - non_compliant_cis: Count of CIs needing normalization
        - normalized_count: Count of CIs normalized (0 if dry_run)
        - naming_pattern_used: Pattern used for validation
        - violations: List of naming violations found
        - audit_session_id: Audit trail session ID
        - recommendations: List of recommended naming improvements
    """
    try:
        # Step 1: Initialize foundation layers
        precheck = CmdbChangePrecheck(client)
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # Step 2: Fetch CIs to analyze
        # Build query: filter by sys_ids if provided, otherwise all active CIs
        if ci_sys_ids:
            # Filter by specific sys_ids
            sys_id_query = "^OR".join([f"sys_id={sys_id}" for sys_id in ci_sys_ids])
            query = f"({sys_id_query})^active=true"
        else:
            # All active CIs
            query = "active=true"

        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query=query,
            sysparm_fields="sys_id,name,serial_number,dns_domain,sys_class_name",
            sysparm_limit=1000
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "ci_class": ci_class,
                "total_cis": 0,
                "message": f"No active CIs found for class {ci_class}",
            }

        # Step 3: Determine naming pattern
        if auto_detect_pattern and not naming_pattern:
            naming_pattern = _auto_detect_naming_pattern(cis)

        if not naming_pattern:
            naming_pattern = r"^[A-Z0-9\-]+$"  # Default: uppercase alphanumeric with hyphens

        # Step 4: Analyze naming compliance
        violations = []
        compliant_count = 0

        for ci in cis:
            ci_name = ci.get("name", "")
            ci_sys_id = ci.get("sys_id")

            if not ci_name:
                violations.append({
                    "sys_id": ci_sys_id,
                    "current_name": "",
                    "violation_type": "empty_name",
                    "suggested_name": _generate_suggested_name(ci, case_style),
                })
                continue

            # Check pattern compliance
            if not re.match(naming_pattern, ci_name):
                suggested_name = _normalize_name(ci_name, case_style)

                violations.append({
                    "sys_id": ci_sys_id,
                    "current_name": ci_name,
                    "violation_type": "pattern_mismatch",
                    "suggested_name": suggested_name,
                    "pattern_expected": naming_pattern,
                })
            else:
                compliant_count += 1

        non_compliant_count = len(violations)
        compliance_pct = (compliant_count / total_cis * 100) if total_cis > 0 else 0

        # Ensure Change Request exists (auto-create if needed for SOX compliance)
        if non_compliant_count > 0:
            ci_sys_ids_to_normalize = [v["sys_id"] for v in violations]
            success, cr_id, error = await ensure_change_request(
                client=client,
                change_request_id=change_request_id,
                ci_sys_ids=ci_sys_ids_to_normalize,
                tool_name="normalize_ci_naming_conventions",
                change_description=f"Normalize naming conventions for {non_compliant_count} CI(s) in {ci_class}",
                dry_run=dry_run,
                auto_approve=True,
            )

            if not success:
                return {
                    "status": "error",
                    "error": f"Change Request validation failed: {error}",
                    "ci_class": ci_class,
                }

            # Use the validated/created CR ID
            change_request_id = cr_id

        # Step 5: Validate change request if normalization will occur
        if not dry_run and non_compliant_count > 0:
            ci_sys_ids = [v["sys_id"] for v in violations]

            is_valid, validation_report = await precheck.validate_change(
                ci_sys_ids=ci_sys_ids,
                change_request_id=change_request_id,
                require_cr=True if change_request_id else False,
                check_criticality=True,
            )

            if not is_valid:
                return {
                    "status": "error",
                    "error": "Pre-flight validation failed",
                    "validation_errors": validation_report["errors"],
                }

        # Step 6: Apply normalization (unless dry run)
        normalized_count = 0

        if not dry_run and non_compliant_count > 0:
            for violation in violations:
                ci_sys_id = violation["sys_id"]
                new_name = violation["suggested_name"]

                # Fetch current state
                ci_response = await client.get_table_records(
                    table=ci_class,
                    sysparm_query=f"sys_id={ci_sys_id}",
                    sysparm_limit=1
                )

                if not ci_response.get("result"):
                    continue

                before_state = ci_response["result"][0]

                # Apply update
                update_response = await client.update_record(
                    table=ci_class,
                    sys_id=ci_sys_id,
                    data={"name": new_name}
                )

                if update_response.get("status") == "success":
                    # Record in audit trail
                    after_state = before_state.copy()
                    after_state["name"] = new_name

                    await audit_trail.record_change(
                        tool_name="normalize_ci_naming_conventions",
                        change_type="update",
                        ci_sys_id=ci_sys_id,
                        ci_name=new_name,
                        change_request_id=change_request_id,
                        before_state=before_state,
                        after_state=after_state,
                        field_diffs=[{
                            "field": "name",
                            "old_value": before_state.get("name"),
                            "new_value": new_name,
                            "change_type": "modified",
                        }],
                        risk_level="low",
                        ci_class=before_state.get("sys_class_name", ci_class),
                        dry_run=dry_run,
                    )

                    normalized_count += 1

        # Step 7: Generate recommendations
        recommendations = []

        if compliance_pct < 50:
            recommendations.append(
                f"⚠️ Only {compliance_pct:.1f}% naming compliance. Establish and enforce "
                f"naming standards: {naming_pattern}"
            )
        elif compliance_pct < 80:
            recommendations.append(
                f"💡 {compliance_pct:.1f}% naming compliance. Run normalization to improve consistency."
            )
        else:
            recommendations.append(
                f"✓ Good naming compliance ({compliance_pct:.1f}%). Continue enforcing standards."
            )

        if non_compliant_count > 0:
            recommendations.append(
                f"💡 {non_compliant_count} CI(s) need normalization. "
                f"Use dry_run=False with CR to apply changes."
            )

        # Add case style recommendation
        if case_style != "uppercase":
            recommendations.append(
                f"💡 Using {case_style} case style. Most organizations use UPPERCASE for servers."
            )

        # Step 8: Prepare response
        result = {
            "status": "success",
            "dry_run": dry_run,
            "ci_class": ci_class,
            "total_cis": total_cis,
            "compliant_cis": compliant_count,
            "non_compliant_cis": non_compliant_count,
            "compliance_percentage": round(compliance_pct, 2),
            "normalized_count": normalized_count,
            "naming_pattern_used": naming_pattern,
            "case_style": case_style,
            "violations": violations[:50],  # Limit to first 50
            "audit_session_id": audit_trail.session_id if normalized_count > 0 else None,
            "change_request_id": change_request_id,
            "recommendations": recommendations,
            "message": f"{'[DRY RUN] ' if dry_run else ''}Naming normalization complete for {ci_class}: "
                       f"{compliance_pct:.1f}% compliant, "
                       f"{non_compliant_count} violations found"
                       f"{f', {normalized_count} normalized' if normalized_count > 0 else ''}",
        }

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


def _auto_detect_naming_pattern(cis: List[Dict[str, Any]]) -> str:
    """Auto-detect common naming pattern from existing CIs."""
    if not cis:
        return r"^[A-Z0-9\-]+$"

    # Sample first 100 CIs
    sample_names = [ci.get("name", "") for ci in cis[:100] if ci.get("name")]

    if not sample_names:
        return r"^[A-Z0-9\-]+$"

    # Check for common patterns
    all_uppercase = all(name.isupper() or not name.isalpha() for name in sample_names)
    has_hyphens = sum(1 for name in sample_names if "-" in name) / len(sample_names) > 0.5
    has_underscores = sum(1 for name in sample_names if "_" in name) / len(sample_names) > 0.5

    if all_uppercase and has_hyphens:
        return r"^[A-Z0-9\-]+$"  # UPPERCASE with hyphens
    elif all_uppercase and has_underscores:
        return r"^[A-Z0-9_]+$"  # UPPERCASE with underscores
    elif all_uppercase:
        return r"^[A-Z0-9]+$"  # UPPERCASE alphanumeric
    else:
        return r"^[A-Za-z0-9\-\.]+$"  # Mixed case with hyphens and dots


def _normalize_name(name: str, case_style: str) -> str:
    """Normalize a CI name according to case style."""
    if not name:
        return ""

    # Remove invalid characters
    normalized = re.sub(r'[^\w\-\.]', '-', name)

    # Apply case style
    if case_style == "uppercase":
        normalized = normalized.upper()
    elif case_style == "lowercase":
        normalized = normalized.lower()
    elif case_style == "titlecase":
        normalized = normalized.title()

    # Remove consecutive hyphens
    normalized = re.sub(r'-+', '-', normalized)

    # Remove leading/trailing hyphens
    normalized = normalized.strip('-')

    return normalized


def _generate_suggested_name(ci: Dict[str, Any], case_style: str) -> str:
    """Generate a suggested name from CI attributes."""
    # Try to build name from serial number or other identifiers
    serial = ci.get("serial_number", "")
    dns_domain = ci.get("dns_domain", "")

    if serial:
        suggested = serial
    elif dns_domain:
        suggested = dns_domain.split(".")[0]  # First part of FQDN
    else:
        suggested = f"CI-{ci.get('sys_id', '')[:8]}"

    return _normalize_name(suggested, case_style)
