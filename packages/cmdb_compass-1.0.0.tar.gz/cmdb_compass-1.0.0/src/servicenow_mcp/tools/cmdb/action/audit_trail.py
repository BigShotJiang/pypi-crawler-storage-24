"""
Unified Audit Trail for CMDB Action Tools

Provides standardized change tracking for legal defensibility,
SOX compliance, and Phase 3 impact review capabilities.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import json
import hashlib
import os
import sys

from servicenow_mcp.servicenow import ServiceNowClient


class CmdbChangeAuditTrail:
    """Unified audit trail for all CMDB action tools."""

    def __init__(
        self,
        client: ServiceNowClient,
        user: str = "mcp-automation",
        table_name: Optional[str] = None,
    ):
        self.client = client
        self.user = user
        self.session_id = self._generate_session_id()
        self.table_name = table_name or os.getenv(
            "SERVICENOW_AUDIT_TABLE", "u_cmdb_change_audit_trail"
        )

    def _generate_session_id(self) -> str:
        """Generate unique session ID for audit trail grouping."""
        timestamp = datetime.now(timezone.utc).isoformat()
        timestamp_str = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%SZ')
        return f"CMDB_CHANGE_{timestamp_str}_{hashlib.md5(timestamp.encode()).hexdigest()[:8]}"

    async def record_change(
        self,
        tool_name: str,
        change_type: str,  # merge, update, delete, create, retire, rollback
        ci_sys_id: str,
        ci_name: str,
        change_request_id: Optional[str] = None,
        before_state: Optional[Dict[str, Any]] = None,
        after_state: Optional[Dict[str, Any]] = None,
        field_diffs: Optional[List[Dict]] = None,
        risk_level: str = "low",  # low, medium, high, critical
        ci_class: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        Record CMDB change in audit trail.

        Schema:
        - session_id: Groups related changes (e.g., bulk update)
        - timestamp: UTC ISO format
        - user: Who initiated (MCP user or service account)
        - tool: Which action tool executed
        - change_type: merge/update/delete/create/retire
        - change_request: CR sys_id (if applicable)
        - ci_sys_id: Target CI
        - ci_name: CI display name
        - before_state: JSON snapshot before change
        - after_state: JSON snapshot after change
        - field_diffs: [{field, old_value, new_value, change_type}]
        - risk_level: Impact assessment
        - checksum: SHA-256 of change record (tamper detection)

        Args:
            tool_name: Name of the tool making the change
            change_type: Type of change (merge/update/delete/create/retire)
            ci_sys_id: sys_id of the target CI
            ci_name: Display name of the CI
            change_request_id: Optional CR sys_id
            before_state: State before change
            after_state: State after change
            field_diffs: List of field-level changes
            risk_level: Risk assessment (low/medium/high/critical)

        Returns:
            Dictionary containing the audit record with checksum
        """
        audit_record = {
            "session_id": self.session_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "user": self.user,
            "tool": tool_name,
            "change_type": change_type,
            "change_request": change_request_id,
            "ci_sys_id": ci_sys_id,
            "ci_name": ci_name,
            "before_state": before_state or {},
            "after_state": after_state or {},
            "field_diffs": field_diffs or [],
            "risk_level": risk_level,
        }

        # Add tamper-detection checksum
        record_json = json.dumps(audit_record, sort_keys=True)
        audit_record["checksum"] = hashlib.sha256(record_json.encode()).hexdigest()

        # Persist to ServiceNow u_cmdb_audit_trail table
        # Note: sys_created_on and sys_created_by are auto-populated by ServiceNow
        try:
            create_response = await self.client.create_record(
                table=self.table_name,
                data={
                    "u_session_id": audit_record["session_id"],
                    # u_timestamp removed - using sys_created_on instead
                    # u_user removed - using sys_created_by instead
                    "u_tool": audit_record["tool"],
                    "u_change_type": audit_record["change_type"],
                    "u_change_request": audit_record.get("change_request"),
                    "u_ci_sys_id": audit_record["ci_sys_id"],
                    "u_ci_name": audit_record["ci_name"],
                    "u_ci_class": ci_class or "unknown",
                    "u_before_state": json.dumps(audit_record["before_state"]),
                    "u_after_state": json.dumps(audit_record["after_state"]),
                    "u_field_diffs": json.dumps(audit_record["field_diffs"]),
                    "u_risk_level": audit_record["risk_level"],
                    "u_checksum": audit_record["checksum"],
                    "u_dry_run": dry_run
                }
            )

            result = create_response.get("result", {})
            audit_record["servicenow_sys_id"] = result.get("sys_id")
            audit_record["persisted"] = True

            print(f"[AUDIT] Persisted to ServiceNow: {audit_record['session_id']} - {ci_sys_id} ({change_type})", file=sys.stderr, flush=True)

        except Exception as e:
            # Graceful fallback: Log warning but don't fail the operation
            print(f"[WARNING] Failed to persist audit record to ServiceNow: {e}", file=sys.stderr, flush=True)
            print(f"[WARNING] Audit record will be logged locally only: {audit_record['session_id']}", file=sys.stderr, flush=True)
            audit_record["persisted"] = False
            audit_record["persistence_error"] = str(e)

        return audit_record

    def get_field_diffs(
        self,
        before: Dict[str, Any],
        after: Dict[str, Any],
        tracked_fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Calculate field-level diffs for audit trail.

        Args:
            before: CI state before changes
            after: CI state after changes
            tracked_fields: Optional list of specific fields to track

        Returns:
            List of field difference dictionaries
        """
        diffs = []
        fields_to_check = tracked_fields or list(set(before.keys()) | set(after.keys()))

        for field in fields_to_check:
            if field.startswith("sys_"):
                continue  # Skip system fields

            old_val = before.get(field)
            new_val = after.get(field)

            if old_val != new_val:
                diffs.append({
                    "field": field,
                    "old_value": str(old_val) if old_val else None,
                    "new_value": str(new_val) if new_val else None,
                    "change_type": "modified" if (old_val and new_val) else
                                   "added" if new_val else "removed"
                })

        return diffs

    async def get_session_changes(self) -> List[Dict[str, Any]]:
        """
        Retrieve all changes for the current session.

        Returns:
            List of audit records for this session
        """
        # TODO: Implement retrieval from ServiceNow table
        # For now, this would return changes stored in memory or logs
        return []

    async def get_rollback_snapshot(self, ci_sys_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the most recent before_state snapshot for rollback.

        Args:
            ci_sys_id: sys_id of the CI to get snapshot for

        Returns:
            before_state dictionary or None if not found
        """
        # TODO: Query audit trail for most recent before_state
        # This enables rollback functionality
        return None
