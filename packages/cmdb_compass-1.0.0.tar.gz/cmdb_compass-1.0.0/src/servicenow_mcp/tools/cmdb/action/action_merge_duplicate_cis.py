"""Merge Duplicate CIs Tool

Merge duplicate CI records using ServiceNow's Identification & Reconciliation Engine (IRE).
Action-level tool for data remediation (paid).
"""

from typing import Any, Dict, List, Optional
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


async def merge_duplicate_cis(
    client: ServiceNowClient,
    duplicate_ci_sysids: List[str],
    keep_sysid: str,
    merge_strategy: str = "keep_newest",
    skip_validation: bool = False,
    change_request_id: Optional[str] = None,
    dry_run: bool = True,
) -> Dict[str, Any]:
    """
    Merge duplicate CI records into a single CI record.

    Uses ServiceNow's Identification & Reconciliation Engine (IRE) principles to:
    - Merge field values intelligently (keep newest, most complete, or specified)
    - Redirect relationships to the target CI
    - Update change history and audit trail
    - Handle conflicts and exceptions

    Args:
        client: ServiceNow client instance
        duplicate_ci_sysids: List of sys_ids of duplicate CIs to merge
        keep_sysid: The sys_id of the CI record to keep (target)
        merge_strategy: Strategy for resolving field conflicts:
            - 'keep_newest': Keep values from most recently updated CI
            - 'keep_complete': Prioritize most complete/populated fields
            - 'keep_specified': Use values from keep_sysid
        skip_validation: Skip pre-merge validation checks (not recommended)
        change_request_id: Optional CR authorizing the merge
        dry_run: If True, validate but don't apply changes (default: True)

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - dry_run: Boolean indicating if this was a dry run
        - merged_cis: List of CI sys_ids that were merged into target
        - target_ci: sys_id of the resulting CI
        - relationships_updated: Count of relationships redirected
        - conflicts_resolved: List of field conflicts and resolutions
        - warnings: List of warnings (field loss, orphaned relationships)
        - audit_session_id: Audit trail session ID
    """
    try:
        # Initialize audit trail
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")
        if not duplicate_ci_sysids or not keep_sysid:
            return {
                "status": "error",
                "error": "duplicate_ci_sysids and keep_sysid are required",
            }

        # Ensure Change Request exists (auto-create if needed for SOX compliance)
        success, cr_id, error = await ensure_change_request(
            client=client,
            change_request_id=change_request_id,
            ci_sys_ids=duplicate_ci_sysids + [keep_sysid],
            tool_name="merge_duplicate_cis",
            change_description=f"Merge {len(duplicate_ci_sysids)} duplicate CI(s) into primary CI",
            dry_run=dry_run,
            auto_approve=True,
        )

        if not success:
            return {
                "status": "error",
                "error": f"Change Request validation failed: {error}",
            }

        # Use the validated/created CR ID
        change_request_id = cr_id

        if keep_sysid in duplicate_ci_sysids:
            # Remove target from merge list to avoid self-merge
            duplicate_ci_sysids = [s for s in duplicate_ci_sysids if s != keep_sysid]

        if not duplicate_ci_sysids:
            return {
                "status": "error",
                "error": "At least one duplicate CI (different from keep_sysid) required",
            }

        # Fetch all CIs to be merged
        keep_ci_response = await client.get_table_records(
            table="cmdb_ci",
            sysparm_query=f"sys_id={keep_sysid}",
            sysparm_limit=1,
            sysparm_display_value="false",
        )
        keep_ci = keep_ci_response.get("result", [])[0] if keep_ci_response.get("result") else None

        if not keep_ci:
            return {
                "status": "error",
                "error": f"Target CI {keep_sysid} not found",
            }

        merge_cis = []
        for dup_sysid in duplicate_ci_sysids:
            dup_response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={dup_sysid}",
                sysparm_limit=1,
                sysparm_display_value="false",
            )
            dup_ci = dup_response.get("result", [])[0] if dup_response.get("result") else None
            if dup_ci:
                merge_cis.append(dup_ci)

        if not merge_cis:
            return {
                "status": "error",
                "error": "No valid duplicate CIs found to merge",
            }

        # Pre-merge validation
        warnings: List[str] = []
        conflicts_resolved: List[Dict[str, Any]] = []

        # Merge fields based on strategy
        merged_updates: Dict[str, Any] = {}
        for merge_ci in merge_cis:
            for field_key, field_value in merge_ci.items():
                if field_key == "sys_id" or field_key.startswith("sys_"):
                    continue  # Skip system fields

                current_value = keep_ci.get(field_key)
                if not current_value and field_value:
                    # Field is empty in keep_ci but populated in duplicate
                    if merge_strategy == "keep_complete":
                        merged_updates[field_key] = field_value
                        conflicts_resolved.append({
                            "field": field_key,
                            "strategy": "keep_complete",
                            "source_ci": merge_ci.get("sys_id"),
                            "new_value": field_value,
                        })
                    elif merge_strategy == "keep_specified":
                        # Keep current value (from keep_sysid)
                        conflicts_resolved.append({
                            "field": field_key,
                            "strategy": "keep_specified",
                            "discarded_value": field_value,
                        })

        # Update target CI with merged fields
        if merged_updates:
            if not dry_run:
                update_response = await client.update_record(
                    table="cmdb_ci",
                    sys_id=keep_sysid,
                    data=merged_updates,
                )
                if update_response.get("status") != "success":
                    warnings.append(f"Partial update: {update_response.get('error', 'unknown')}")

        # ALWAYS record merge operation in audit trail (even if no fields updated)
        # The merge is significant because relationships are redirected and duplicates retired
        if not dry_run:
            after_state = keep_ci.copy()
            if merged_updates:
                after_state.update(merged_updates)

            # Add metadata about the merge operation
            after_state["_merge_metadata"] = {
                "duplicate_cis_merged": [m.get("sys_id") for m in merge_cis],
                "fields_updated": len(merged_updates),
                "merge_strategy": merge_strategy
            }

            await audit_trail.record_change(
                tool_name="merge_duplicate_cis",
                change_type="merge",
                ci_sys_id=keep_sysid,
                ci_name=keep_ci.get("name", "Unknown"),
                change_request_id=change_request_id,
                before_state=keep_ci,
                after_state=after_state,
                field_diffs=audit_trail.get_field_diffs(keep_ci, after_state) if merged_updates else [],
                risk_level="high",
                ci_class=keep_ci.get("sys_class_name", "cmdb_ci"),
                dry_run=False,  # This block only runs when dry_run=False
            )

        # Redirect all relationships from duplicate CIs to target CI
        relationships_updated = 0
        for merge_ci in merge_cis:
            merge_ci_sysid = merge_ci.get("sys_id")

            # Find relationships where this CI is the parent
            # BUG FIX #4: Use correct field names (parent/child, not ci_item/related_ci)
            rel_response = await client.get_table_records(
                table="cmdb_rel_ci",
                sysparm_query=f"parent={merge_ci_sysid}^active=true",
                sysparm_fields="sys_id,parent,child,type",
                sysparm_limit=1000,
            )

            for rel in rel_response.get("result", []):
                if not dry_run:
                    rel_update = await client.update_record(
                        table="cmdb_rel_ci",
                        sys_id=rel.get("sys_id"),
                        data={"parent": keep_sysid},
                    )
                    if rel_update.get("status") == "success":
                        relationships_updated += 1
                else:
                    relationships_updated += 1  # Count for dry run

            # Find relationships where this CI is the child
            rel_response_target = await client.get_table_records(
                table="cmdb_rel_ci",
                sysparm_query=f"child={merge_ci_sysid}^active=true",
                sysparm_fields="sys_id,parent,child,type",
                sysparm_limit=1000,
            )

            for rel in rel_response_target.get("result", []):
                if not dry_run:
                    rel_update = await client.update_record(
                        table="cmdb_rel_ci",
                        sys_id=rel.get("sys_id"),
                        data={"child": keep_sysid},
                    )
                    if rel_update.get("status") == "success":
                        relationships_updated += 1
                else:
                    relationships_updated += 1  # Count for dry run

        # Retire/deactivate duplicate CIs
        for merge_ci in merge_cis:
            deactivate_updates: Dict[str, Any] = {}
            desired_states = {
                "install_status": "7",  # Retired
                "operational_status": "2",  # Non-operational
                # Note: cmdb_ci does NOT have an 'active' field - use install_status instead
            }

            for field, desired_value in desired_states.items():
                current_value = merge_ci.get(field)
                # Convert to string for comparison to handle None, True, False, "true", "false"
                current_str = str(current_value).lower() if current_value is not None else "none"
                desired_str = str(desired_value).lower()
                if current_str != desired_str:
                    deactivate_updates[field] = desired_value

            if not dry_run:
                if deactivate_updates:
                    deactivate_response = await client.update_record(
                        table="cmdb_ci",
                        sys_id=merge_ci.get("sys_id"),
                        data=deactivate_updates,
                    )
                    if deactivate_response.get("status") != "success":
                        warnings.append(f"Failed to deactivate duplicate {merge_ci.get('sys_id')}")
                else:
                    warnings.append(
                        f"No eligible fields to retire duplicate {merge_ci.get('sys_id')}; record may already be inactive"
                    )

            # Record deactivation in audit trail
            after_state = merge_ci.copy()
            after_state.update(deactivate_updates or desired_states)

            await audit_trail.record_change(
                tool_name="merge_duplicate_cis",
                change_type="retire",
                ci_sys_id=merge_ci.get("sys_id"),
                ci_name=merge_ci.get("name", "Unknown"),
                change_request_id=change_request_id,
                before_state=merge_ci,
                after_state=after_state,
                field_diffs=audit_trail.get_field_diffs(merge_ci, after_state),
                risk_level="medium",
                ci_class=merge_ci.get("sys_class_name", "cmdb_ci"),
                dry_run=dry_run,
            )

        return {
            "status": "success",
            "dry_run": dry_run,
            "target_ci": keep_sysid,
            "merged_cis": [m.get("sys_id") for m in merge_cis],
            "relationships_updated": relationships_updated,
            "conflicts_resolved": conflicts_resolved,
            "warnings": warnings if warnings else [],
            "audit_session_id": audit_trail.session_id,
            "change_request_id": change_request_id,
            "message": f"{'[DRY RUN] ' if dry_run else ''}Successfully merged {len(merge_cis)} duplicate CI(s) into {keep_sysid}. Updated {relationships_updated} relationship(s).",
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }
