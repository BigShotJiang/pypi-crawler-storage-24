"""
Bulk Update Missing Fields Tool

Bulk populate missing critical fields in CI records.
Action-level tool for data completeness improvement (paid, credit-based).
"""

import sys
from typing import Any, Dict, Optional
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata
from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail
from servicenow_mcp.tools.cmdb.action.auto_cr_helper import ensure_change_request


# Inline helper functions for field mapping and unique value generation

def map_field_name(csdm_field: str) -> str:
    """Map CSDM field name to actual ServiceNow field name."""
    FIELD_MAPPINGS = {
        "os_type": "os",
        "ram_gb": "ram",
        "disk_gb": "disk_space",
    }
    return FIELD_MAPPINGS.get(csdm_field, csdm_field)


def generate_unique_ip(index: int) -> str:
    """Generate unique IP address for CI at given index."""
    third_octet = (index // 255) % 255
    fourth_octet = index % 255 + 1
    return f"10.0.{third_octet}.{fourth_octet}"


def generate_unique_hostname(ci_name: str, index: int) -> str:
    """Generate unique hostname based on CI name and index."""
    clean_name = ci_name.lower().replace(" ", "-").replace("_", "-")
    clean_name = ''.join(c for c in clean_name if c.isalnum() or c == '-')
    return f"{clean_name}-{index:03d}.example.com"


def generate_unique_serial(ci_sys_id: str) -> str:
    """Generate unique serial number based on sys_id."""
    import hashlib
    hash_obj = hashlib.md5(ci_sys_id.encode())
    hash_hex = hash_obj.hexdigest()[:8].upper()
    return f"SN-{hash_hex[:4]}-{hash_hex[4:]}"


async def bulk_update_missing_fields(
    client: ServiceNowClient,
    table_name: str,
    field_mappings: Dict[str, str],
    dry_run: bool = True,
    filter_query: Optional[str] = None,
    limit: int = 100,
    audit_level: AuditLevel = "standard",
    change_request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Bulk populate missing critical fields in CI records.

    Updates CIs with missing values for key fields like owner, support_group,
    environment, business_unit, etc. Uses intelligent mapping to determine
    appropriate values based on existing data.

    WHEN TO USE:
    - "Populate missing owners for all servers"
    - "Set environment to Production for all production servers"
    - "Bulk update support groups based on department"

    CSDM PHASE: CONSUME (data completeness improvement)

    AUDIT LEVELS:
    - quick: $0.20 - Count of CIs to be updated
    - standard: $0.60 - Count + sample updates (RECOMMENDED)
    - deep: $1.40 - Full audit trail with all changes

    Args:
        client: ServiceNow client instance
        table_name: CI class to update (e.g., 'cmdb_ci_server')
        field_mappings: Dict of field->value mappings (e.g., {"owner": "admin@company.com", "environment": "Production"})
        dry_run: If True, only show what would be updated (no actual changes)
        filter_query: ServiceNow query to filter CIs (e.g., "name LIKE prod")
        limit: Max CIs to update in batch (default: 100, max: 500)
        audit_level: Analysis depth: 'quick', 'standard', or 'deep'

    Returns:
        Dictionary containing:
        - table: The CI class updated
        - dry_run: Whether this was a dry run
        - total_cis_matching_filter: CIs eligible for update
        - cis_with_missing_fields: CIs that will be updated
        - field_mappings_applied: Fields to be updated
        - update_summary: By field and count
        - estimated_completeness_improvement: Percentage improvement
        - updates_applied: Actual count (if dry_run=False)
        - sample_updates: Sample of CIs to be updated
        - next_steps: How to process remaining CIs
        - status: success/error
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Found 234 servers with missing owner field.
         Will update 100 in this batch with 'app-team@company.com'
         Completeness improvement: +2.1%"
    """
    try:
        # Initialize audit trail
        audit_trail = CmdbChangeAuditTrail(client, user="mcp-automation")

        # ENHANCEMENT: Check CSDM rules for required fields
        csdm_rules = get_csdm_rules()
        csdm_required_fields = csdm_rules.get_required_fields(table_name)
        csdm_optional_fields = csdm_rules.get_optional_fields(table_name)

        if csdm_required_fields or csdm_optional_fields:
            print(f"[bulk_update_missing_fields] CSDM rules for {table_name}:", file=sys.stderr)
            print(f"  Required fields: {csdm_required_fields}", file=sys.stderr)
            print(f"  Optional fields: {csdm_optional_fields}", file=sys.stderr)

        # Validate inputs
        if limit is not None:
            if limit > 500:
                limit = 500
            if limit < 1:
                limit = 1

        if not field_mappings:
            return {
                "table": table_name,
                "status": "error",
                "error": "field_mappings cannot be empty. Provide at least one field to update."
            }

        # CRITICAL: Handle reference fields that need sys_id lookup instead of text values
        print(f"[bulk_update_missing_fields] Preparing field updates for table {table_name}...", file=sys.stderr)

        # Common reference fields that need sys_id lookup instead of text values
        REFERENCE_FIELDS = {
            "owned_by": "sys_user",  # Maps to sys_user table
            "owner": "sys_user",  # Alternative owner field
            "assignment_group": "sys_user_group",
            "support_group": "sys_user_group",
            "manager": "sys_user",
            "approver": "sys_user",
            "request_for": "sys_user",
        }

        # Validate field names - provide helpful suggestions for common mistakes
        print(f"[bulk_update_missing_fields] Fields to update: {list(field_mappings.keys())}", file=sys.stderr)

        # Check for common field name issues
        if "owner" in field_mappings and "owned_by" not in field_mappings:
            print(f"[WARNING] You specified 'owner' field. ServiceNow uses 'owned_by' for CI ownership. Auto-correcting...", file=sys.stderr)
            field_mappings["owned_by"] = field_mappings.pop("owner")
            print(f"[INFO] Updated field_mappings: {field_mappings}", file=sys.stderr)

        # Map CSDM field names to actual ServiceNow field names
        field_mappings_translated = {}
        for csdm_field, value in field_mappings.items():
            servicenow_field = map_field_name(csdm_field)
            if servicenow_field != csdm_field:
                print(f"[INFO] Field name mapping: {csdm_field} → {servicenow_field}", file=sys.stderr)
            field_mappings_translated[servicenow_field] = value
        field_mappings = field_mappings_translated

        # Detect placeholder values that would cause duplicates
        # If detected, enable auto-generation of unique values
        auto_generate_unique = {}
        PLACEHOLDER_VALUES = {
            "ip_address": ["10.0.0.1", "192.168.1.1", "127.0.0.1"],
            "host_name": ["server.example.com", "hostname.local", "localhost"],
            "serial_number": ["SN-000000", "SERIAL-PLACEHOLDER"],
        }

        for field, value in field_mappings.items():
            if field in PLACEHOLDER_VALUES:
                if value in PLACEHOLDER_VALUES[field]:
                    auto_generate_unique[field] = True
                    print(f"[INFO] Detected placeholder value for {field}='{value}' - will auto-generate unique values", file=sys.stderr)

        # Handle reference fields - need to resolve values to sys_ids
        def is_sys_id(value: str) -> bool:
            """Check if value is a valid ServiceNow sys_id (32-char hexadecimal)."""
            return isinstance(value, str) and len(value) == 32 and all(c in '0123456789abcdefABCDEF' for c in value)

        field_mappings_resolved = {}
        for field, value in field_mappings.items():
            if field in REFERENCE_FIELDS and not is_sys_id(value):
                # This is a reference field with a text value, need to resolve it
                target_table = REFERENCE_FIELDS[field]
                print(f"[bulk_update_missing_fields] Field '{field}' is a reference field, resolving {value} from {target_table}...", file=sys.stderr)

                try:
                    # Lookup user/group by email, name, or username
                    lookup_response = await client.get_table_records(
                        table=target_table,
                        sysparm_query=f"nameSTARTSWITH{value}^ORemailSTARTSWITH{value}^ORusernameLIKE{value}",
                        sysparm_fields="sys_id,name,email,username",
                        sysparm_limit=1
                    )

                    records = lookup_response.get("result", [])
                    if records:
                        resolved_id = records[0].get("sys_id")
                        resolved_name = records[0].get("name", records[0].get("email", value))
                        field_mappings_resolved[field] = resolved_id
                        print(f"[bulk_update_missing_fields] ✅ Resolved '{value}' → {resolved_name} (sys_id: {resolved_id})", file=sys.stderr)
                    else:
                        return {
                            "table": table_name,
                            "status": "error",
                            "error": f"Could not resolve reference for {field}='{value}'. No matching user/group found in {target_table}.",
                            "suggestion": f"Verify the value exists in {target_table} table"
                        }
                except Exception as e:
                    print(f"[ERROR] Failed to resolve reference: {e}", file=sys.stderr)
                    return {
                        "table": table_name,
                        "status": "error",
                        "error": f"Failed to resolve {field}: {str(e)}"
                    }
            else:
                field_mappings_resolved[field] = value

        # Use resolved field mappings for updates
        field_mappings = field_mappings_resolved

        # Validate that we're updating fields that make sense per CSDM
        for field in field_mappings.keys():
            is_required = field in csdm_required_fields if csdm_required_fields else False
            is_optional = field in csdm_optional_fields if csdm_optional_fields else False

            if csdm_required_fields or csdm_optional_fields:
                if not (is_required or is_optional):
                    print(f"[WARNING] Field '{field}' not in CSDM rules for {table_name}", file=sys.stderr)
                else:
                    print(f"[INFO] Updating {field} ({'required' if is_required else 'optional'} per CSDM)", file=sys.stderr)

        # Build query for CIs with missing fields
        missing_field_conditions = []
        for field in field_mappings.keys():
            missing_field_conditions.append(f"{field}ISEMPTY")

        # Combine conditions with OR
        query_part = "^OR".join(missing_field_conditions)
        query = query_part

        # Add filter if provided
        if filter_query:
            query = f"({query})^{filter_query}"

        print(f"[bulk_update_missing_fields] Searching for CIs with missing fields in {table_name}", file=sys.stderr)
        print(f"[bulk_update_missing_fields] Query: {query}", file=sys.stderr)
        print(f"[bulk_update_missing_fields] Fields to update: {list(field_mappings.keys())}", file=sys.stderr)

        # Get CIs with missing fields
        missing_response = await client.get_table_records(
            table=table_name,
            sysparm_query=query,
            sysparm_fields="sys_id,name,owner,support_group,environment,business_unit,location,department",
            sysparm_limit=None  # Get all for planning
        )

        cis_with_missing = missing_response.get("result", [])
        print(f"[bulk_update_missing_fields] Found {len(cis_with_missing)} CIs with missing fields", file=sys.stderr)

        # Get total count for context
        total_response = await client.count_records(table_name)
        total_cis = total_response[0] if isinstance(total_response, tuple) else total_response

        # Prepare batch for update
        update_batch = cis_with_missing[:limit]
        remaining = len(cis_with_missing) - len(update_batch)

        # Analyze which fields are missing in this batch
        field_missing_counts = {field: 0 for field in field_mappings.keys()}
        for ci in update_batch:
            for field in field_mappings.keys():
                if not ci.get(field):
                    field_missing_counts[field] += 1

        # Prepare sample updates
        sample_updates = []
        for index, ci in enumerate(update_batch[:5]):
            updates = {}
            for field, value in field_mappings.items():
                if not ci.get(field):
                    # Apply same unique value generation logic as the actual update
                    if field in auto_generate_unique and auto_generate_unique[field]:
                        if field == "ip_address":
                            value = generate_unique_ip(index)
                        elif field == "host_name":
                            value = generate_unique_hostname(ci.get('name', f'ci-{index}'), index)
                        elif field == "serial_number":
                            value = generate_unique_serial(ci.get('sys_id', str(index)))
                    updates[field] = value

            if updates:
                sample_updates.append({
                    "sys_id": ci.get("sys_id"),
                    "name": ci.get("name"),
                    "current_values": {f: ci.get(f) or "(empty)" for f in field_mappings.keys()},
                    "updates": updates
                })

        # Calculate completeness improvement
        # Each populated field improves completeness score
        completeness_improvement = round((len(update_batch) / max(total_cis, 1)) * 0.5, 1)

        # Ensure Change Request exists (auto-create if needed for SOX compliance)
        ci_sys_ids_to_update = [ci.get("sys_id") for ci in update_batch]
        success, cr_id, error = await ensure_change_request(
            client=client,
            change_request_id=change_request_id,
            ci_sys_ids=ci_sys_ids_to_update,
            tool_name="bulk_update_missing_fields",
            change_description=f"Bulk update missing fields for {len(update_batch)} CI(s) in {table_name}",
            dry_run=dry_run,
            auto_approve=True,
        )

        if not success:
            return {
                "table": table_name,
                "status": "error",
                "error": f"Change Request validation failed: {error}",
                "dry_run": dry_run
            }

        # Use the validated/created CR ID
        change_request_id = cr_id

        # EXECUTE UPDATES if not dry_run
        actual_updates = 0
        failed_updates = []

        if not dry_run:
            print(f"[bulk_update_missing_fields] Executing updates for {len(update_batch)} CIs...", file=sys.stderr)

            for index, ci in enumerate(update_batch):
                try:
                    # Build update data for this CI
                    update_data = {}
                    for field, value in field_mappings.items():
                        # Only update if field is currently empty
                        if not ci.get(field):
                            # Check if we should auto-generate unique value
                            if field in auto_generate_unique and auto_generate_unique[field]:
                                if field == "ip_address":
                                    value = generate_unique_ip(index)
                                elif field == "host_name":
                                    value = generate_unique_hostname(ci.get('name', f'ci-{index}'), index)
                                elif field == "serial_number":
                                    value = generate_unique_serial(ci.get('sys_id', str(index)))
                                print(f"[INFO] Generated unique {field}={value} for {ci.get('name')}", file=sys.stderr)

                            update_data[field] = value

                    if update_data:  # Only update if there are fields to update
                        # Fetch current CI state for audit trail
                        ci_response = await client.get_table_records(
                            table=table_name,
                            sysparm_query=f"sys_id={ci['sys_id']}",
                            sysparm_limit=1
                        )
                        current_ci = ci_response.get("result", [{}])[0] if ci_response.get("result") else ci

                        # Perform the update
                        update_response = await client.update_record(
                            table=table_name,
                            sys_id=ci["sys_id"],
                            data=update_data
                        )

                        if update_response.get("result"):
                            actual_updates += 1
                            print(f"[bulk_update_missing_fields] ✅ Updated: {ci['name']} (sys_id: {ci['sys_id']})", file=sys.stderr)

                            # Record update in audit trail
                            after_state = current_ci.copy()
                            after_state.update(update_data)

                            # Build field diffs
                            field_diffs = []
                            for field, new_value in update_data.items():
                                field_diffs.append({
                                    "field": field,
                                    "old_value": current_ci.get(field),
                                    "new_value": new_value,
                                    "change_type": "added" if not current_ci.get(field) else "modified"
                                })

                            await audit_trail.record_change(
                                tool_name="bulk_update_missing_fields",
                                change_type="update",
                                ci_sys_id=ci["sys_id"],
                                ci_name=ci.get("name", "Unknown"),
                                change_request_id=change_request_id,
                                before_state=current_ci,
                                after_state=after_state,
                                field_diffs=field_diffs,
                                risk_level="low",
                                ci_class=current_ci.get("sys_class_name", table_name),
                                dry_run=False,
                            )
                        else:
                            failed_updates.append({"name": ci["name"], "error": "No result in response"})
                            print(f"[bulk_update_missing_fields] ⚠️ Failed to update: {ci['name']}", file=sys.stderr)

                except Exception as e:
                    failed_updates.append({"name": ci["name"], "error": str(e)})
                    print(f"[bulk_update_missing_fields] ❌ Error updating {ci['name']}: {e}", file=sys.stderr)

            print(f"[bulk_update_missing_fields] Update complete: {actual_updates}/{len(update_batch)} successful", file=sys.stderr)

        response = {
            "table": table_name,
            "dry_run": dry_run,
            "filter_query": filter_query or "All CIs",
            "total_cis_in_table": total_cis,
            "total_cis_matching_filter": len(cis_with_missing),
            "cis_with_missing_fields": len(update_batch),
            "remaining_in_queue": remaining,
            "field_mappings_applied": field_mappings,
            "update_summary": {
                "fields_to_update": list(field_mappings.keys()),
                "field_missing_counts": field_missing_counts,
                "cis_in_batch": len(update_batch),
                "total_field_updates": sum(len([f for f in field_mappings.keys() if not ci.get(f)]) for ci in update_batch)
            },
            "estimated_completeness_improvement": f"+{completeness_improvement}%",
            "updates_applied": actual_updates if not dry_run else 0,
            "failed_updates_count": len(failed_updates) if not dry_run else 0,
            "failed_updates": failed_updates if failed_updates else None,
            "sample_updates": sample_updates if audit_level in ["standard", "deep"] else sample_updates[:2],
            "update_details": {
                "batch_size": len(update_batch),
                "total_updates_to_apply": sum(field_missing_counts.values()),
                "average_fields_per_ci": round(sum(field_missing_counts.values()) / max(len(update_batch), 1), 1)
            },
            "next_steps": [
                f"1. Review sample_updates above to verify mappings",
                f"2. Call with dry_run=False to apply {len(update_batch)} updates",
                f"3. Verify updates in ServiceNow (check audit trail)",
                f"4. Process remaining {remaining} CIs in next batch" if remaining > 0 else "4. All updates complete!",
                f"5. Re-run compliance report to measure improvement"
            ] if dry_run else [
                f"✅ Updated {actual_updates}/{len(update_batch)} CIs",
                f"📝 {sum(field_missing_counts.values())} field values populated",
                f"⏳ {remaining} more CIs ready in next batch" if remaining > 0 else "🎉 All updates applied!",
                f"📊 Expected completeness improvement: +{completeness_improvement}%"
            ] + (
                [f"⚠️ {len(failed_updates)} CIs failed to update - check failed_updates list"] if failed_updates else []
            ),
            "rollback_instructions": "If needed, check audit trail in ServiceNow and revert changes" if not dry_run else "N/A (dry_run only)",
            "status": "success" if (dry_run or actual_updates > 0) else "partial_failure",
            "audit_session_id": audit_trail.session_id,
            "change_request_id": change_request_id,
            "audit_metadata": build_audit_metadata(audit_level, len(cis_with_missing), len(update_batch))
        }

        return response

    except Exception as e:
        print(f"[ERROR] bulk_update_missing_fields failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "table": table_name,
            "status": "error",
            "error": str(e),
            "dry_run": dry_run
        }
