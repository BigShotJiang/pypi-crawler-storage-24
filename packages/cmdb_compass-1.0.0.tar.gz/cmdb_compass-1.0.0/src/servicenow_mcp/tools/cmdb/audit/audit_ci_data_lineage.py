"""Audit CI Data Lineage Tool

Traces upstream/downstream CI relationships, field-level modification history,
and source attribution. Provides complete data lineage visibility for CMDB governance.

Features:
- Relationship path tracing (upstream/downstream)
- Field-level modification history from sys_audit
- Source attribution (discovery, integration, manual)
- Circular dependency detection
- Orphan path detection
- Coverage score calculation
"""

from typing import Any, Dict, List, Optional, Set, Tuple
from datetime import datetime, timedelta
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit import utils


async def audit_ci_data_lineage(
    client: ServiceNowClient,
    ci_sys_id: str,
    trace_upstream: bool = True,
    trace_downstream: bool = True,
    max_depth: int = 5,
    include_field_history: bool = True,
    include_source_attribution: bool = True,
    audit_level: utils.AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Trace CI data lineage with relationship paths and modification history.

    Provides complete visibility into:
    - Upstream dependencies (what this CI depends on)
    - Downstream impacts (what depends on this CI)
    - Field-level change history
    - Data source attribution
    - Circular dependency chains
    - Orphaned relationship paths

    Args:
        client: ServiceNow client instance
        ci_sys_id: Target CI sys_id to trace
        trace_upstream: Include upstream dependencies (default: True)
        trace_downstream: Include downstream impacts (default: True)
        max_depth: Maximum relationship traversal depth (1-10, default: 5)
        include_field_history: Include field modification history (default: True)
        include_source_attribution: Include data source analysis (default: True)
        audit_level: Analysis depth ('quick', 'standard', 'deep')

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ci_sys_id: Target CI identifier
        - ci_name: CI name
        - ci_class: CI class
        - lineage_map: Complete upstream/downstream relationship tree
        - coverage_score: Lineage coverage quality (0-100)
        - upstream_count: Total upstream dependencies
        - downstream_count: Total downstream impacts
        - circular_dependencies: List of circular chains detected
        - orphan_paths: Relationships with missing CI endpoints
        - field_history: Field-level modification timeline (if enabled)
        - source_attribution: Data source breakdown (if enabled)
        - issues: List of lineage quality issues
        - recommendations: Actionable improvement suggestions
    """
    try:
        start_time = datetime.now()

        # Validate max_depth
        max_depth = max(1, min(max_depth, 10))

        # Step 1: Fetch target CI
        ci_response = await client.get_table_records(
            table="cmdb_ci",
            sysparm_query=f"sys_id={ci_sys_id}",
            sysparm_fields="sys_id,name,sys_class_name,discovery_source,sys_created_by,sys_created_on,sys_updated_by,sys_updated_on",
            sysparm_limit=1
        )

        cis = ci_response.get("result", [])
        if not cis:
            return {
                "status": "error",
                "error": f"CI not found: {ci_sys_id}",
                "ci_sys_id": ci_sys_id,
            }

        target_ci = cis[0]
        ci_name = target_ci.get("name", "Unknown")
        ci_class = target_ci.get("sys_class_name", "cmdb_ci")

        # Step 2: Trace upstream relationships
        upstream_map = {}
        upstream_issues = []
        circular_deps_upstream = []

        if trace_upstream:
            upstream_map, upstream_issues, circular_deps_upstream = await _trace_upstream(
                client, ci_sys_id, max_depth
            )

        # Step 3: Trace downstream relationships
        downstream_map = {}
        downstream_issues = []
        circular_deps_downstream = []

        if trace_downstream:
            downstream_map, downstream_issues, circular_deps_downstream = await _trace_downstream(
                client, ci_sys_id, max_depth
            )

        # Step 4: Get field modification history
        field_history = {}
        if include_field_history:
            field_history = await _get_field_history(
                client, ci_sys_id, ci_class, audit_level
            )

        # Step 5: Get source attribution
        source_attribution = {}
        if include_source_attribution:
            source_attribution = await _analyze_source_attribution(
                client, target_ci, upstream_map, downstream_map
            )

        # Step 6: Calculate coverage score
        coverage_score = _calculate_lineage_coverage_score(
            upstream_map, downstream_map, upstream_issues, downstream_issues,
            circular_deps_upstream, circular_deps_downstream
        )

        # Step 7: Aggregate issues
        all_issues = upstream_issues + downstream_issues

        # Add circular dependency issues
        for cycle in circular_deps_upstream + circular_deps_downstream:
            all_issues.append({
                "type": "circular_dependency",
                "severity": "high",
                "description": f"Circular dependency detected: {' → '.join(cycle['path'])}",
                "path": cycle['path']
            })

        # Step 8: Build lineage map
        lineage_map = {
            "ci_sys_id": ci_sys_id,
            "ci_name": ci_name,
            "ci_class": ci_class,
        }

        if trace_upstream and (audit_level in ["standard", "deep"]):
            lineage_map["upstream"] = upstream_map

        if trace_downstream and (audit_level in ["standard", "deep"]):
            lineage_map["downstream"] = downstream_map

        # Step 9: Generate recommendations
        recommendations = _generate_lineage_recommendations(
            all_issues, coverage_score, upstream_map, downstream_map
        )

        # Calculate execution time
        execution_time = (datetime.now() - start_time).total_seconds()

        return {
            "status": "success",
            "ci_sys_id": ci_sys_id,
            "ci_name": ci_name,
            "ci_class": ci_class,
            "lineage_map": lineage_map,
            "coverage_score": round(coverage_score, 1),
            "coverage_grade": _get_coverage_grade(coverage_score),
            "upstream_count": len(upstream_map),
            "downstream_count": len(downstream_map),
            "max_depth_traced": max_depth,
            "circular_dependencies": circular_deps_upstream + circular_deps_downstream,
            "circular_count": len(circular_deps_upstream + circular_deps_downstream),
            "orphan_paths": [issue for issue in all_issues if issue["type"] == "orphan"],
            "orphan_count": len([i for i in all_issues if i["type"] == "orphan"]),
            "field_history": field_history if include_field_history else None,
            "source_attribution": source_attribution if include_source_attribution else None,
            "issues": all_issues[:50] if audit_level == "standard" else all_issues,
            "issues_count": len(all_issues),
            "recommendations": recommendations,
            "metadata": utils.build_audit_metadata(
                audit_type="data_lineage",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            ),
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_sys_id": ci_sys_id,
        }


async def _trace_upstream(
    client: ServiceNowClient,
    ci_sys_id: str,
    max_depth: int
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Trace upstream dependencies (parent relationships)."""
    upstream_map = {}
    issues = []
    circular_deps = []
    visited = set()
    path = []

    await _dfs_upstream(
        client, ci_sys_id, upstream_map, issues, visited, path, max_depth, 0, circular_deps
    )

    return upstream_map, issues, circular_deps


async def _dfs_upstream(
    client: ServiceNowClient,
    ci_sys_id: str,
    result_map: Dict[str, Any],
    issues: List[Dict[str, Any]],
    visited: Set[str],
    path: List[str],
    max_depth: int,
    current_depth: int,
    circular_deps: List[Dict[str, Any]]
):
    """DFS traversal for upstream relationships."""
    if current_depth >= max_depth:
        return

    if ci_sys_id in path:
        # Circular dependency detected
        cycle_start_index = path.index(ci_sys_id)
        cycle_path = path[cycle_start_index:] + [ci_sys_id]
        circular_deps.append({
            "path": cycle_path,
            "depth": current_depth
        })
        return

    if ci_sys_id in visited:
        return

    visited.add(ci_sys_id)
    path.append(ci_sys_id)

    try:
        # Fetch relationships where this CI is the child (parent relationships)
        rel_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=f"child={ci_sys_id}",
            sysparm_fields="sys_id,parent,parent.name,parent.sys_class_name,type.display_value",
            sysparm_limit=100
        )

        relationships = rel_response.get("result", [])

        for rel in relationships:
            parent_ref = rel.get("parent", {})

            if isinstance(parent_ref, dict):
                parent_sys_id = parent_ref.get("value")
                parent_name = parent_ref.get("display_value", "Unknown")
            else:
                parent_sys_id = str(parent_ref) if parent_ref else None
                parent_name = "Unknown"

            if not parent_sys_id:
                issues.append({
                    "type": "orphan",
                    "severity": "medium",
                    "description": f"Relationship {rel.get('sys_id')} has missing parent CI",
                    "relationship_sys_id": rel.get("sys_id")
                })
                continue

            # Verify parent CI exists
            parent_check = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={parent_sys_id}",
                sysparm_fields="sys_id,name",
                sysparm_limit=1
            )

            if not parent_check.get("result"):
                issues.append({
                    "type": "orphan",
                    "severity": "high",
                    "description": f"Parent CI {parent_sys_id} not found in CMDB",
                    "ci_sys_id": parent_sys_id,
                    "relationship_sys_id": rel.get("sys_id")
                })
                continue

            rel_type = rel.get("type", {}).get("display_value", "Unknown")

            result_map[parent_sys_id] = {
                "sys_id": parent_sys_id,
                "name": parent_name,
                "relationship_type": rel_type,
                "depth": current_depth + 1
            }

            # Recursively trace upstream
            await _dfs_upstream(
                client, parent_sys_id, result_map, issues, visited,
                path[:], max_depth, current_depth + 1, circular_deps
            )

    except Exception as e:
        issues.append({
            "type": "error",
            "severity": "high",
            "description": f"Failed to trace upstream from {ci_sys_id}: {str(e)}"
        })

    path.pop()


async def _trace_downstream(
    client: ServiceNowClient,
    ci_sys_id: str,
    max_depth: int
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Trace downstream impacts (child relationships)."""
    downstream_map = {}
    issues = []
    circular_deps = []
    visited = set()
    path = []

    await _dfs_downstream(
        client, ci_sys_id, downstream_map, issues, visited, path, max_depth, 0, circular_deps
    )

    return downstream_map, issues, circular_deps


async def _dfs_downstream(
    client: ServiceNowClient,
    ci_sys_id: str,
    result_map: Dict[str, Any],
    issues: List[Dict[str, Any]],
    visited: Set[str],
    path: List[str],
    max_depth: int,
    current_depth: int,
    circular_deps: List[Dict[str, Any]]
):
    """DFS traversal for downstream relationships."""
    if current_depth >= max_depth:
        return

    if ci_sys_id in path:
        # Circular dependency detected
        cycle_start_index = path.index(ci_sys_id)
        cycle_path = path[cycle_start_index:] + [ci_sys_id]
        circular_deps.append({
            "path": cycle_path,
            "depth": current_depth
        })
        return

    if ci_sys_id in visited:
        return

    visited.add(ci_sys_id)
    path.append(ci_sys_id)

    try:
        # Fetch relationships where this CI is the parent (child relationships)
        rel_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=f"parent={ci_sys_id}",
            sysparm_fields="sys_id,child,child.name,child.sys_class_name,type.display_value",
            sysparm_limit=100
        )

        relationships = rel_response.get("result", [])

        for rel in relationships:
            child_ref = rel.get("child", {})

            if isinstance(child_ref, dict):
                child_sys_id = child_ref.get("value")
                child_name = child_ref.get("display_value", "Unknown")
            else:
                child_sys_id = str(child_ref) if child_ref else None
                child_name = "Unknown"

            if not child_sys_id:
                issues.append({
                    "type": "orphan",
                    "severity": "medium",
                    "description": f"Relationship {rel.get('sys_id')} has missing child CI",
                    "relationship_sys_id": rel.get("sys_id")
                })
                continue

            # Verify child CI exists
            child_check = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={child_sys_id}",
                sysparm_fields="sys_id,name",
                sysparm_limit=1
            )

            if not child_check.get("result"):
                issues.append({
                    "type": "orphan",
                    "severity": "high",
                    "description": f"Child CI {child_sys_id} not found in CMDB",
                    "ci_sys_id": child_sys_id,
                    "relationship_sys_id": rel.get("sys_id")
                })
                continue

            rel_type = rel.get("type", {}).get("display_value", "Unknown")

            result_map[child_sys_id] = {
                "sys_id": child_sys_id,
                "name": child_name,
                "relationship_type": rel_type,
                "depth": current_depth + 1
            }

            # Recursively trace downstream
            await _dfs_downstream(
                client, child_sys_id, result_map, issues, visited,
                path[:], max_depth, current_depth + 1, circular_deps
            )

    except Exception as e:
        issues.append({
            "type": "error",
            "severity": "high",
            "description": f"Failed to trace downstream from {ci_sys_id}: {str(e)}"
        })

    path.pop()


async def _get_field_history(
    client: ServiceNowClient,
    ci_sys_id: str,
    ci_class: str,
    audit_level: utils.AuditLevel
) -> Dict[str, Any]:
    """Get field-level modification history from sys_audit."""
    try:
        # Limit history based on audit level
        limit = {
            "quick": 10,
            "standard": 50,
            "deep": 200
        }.get(audit_level, 50)

        # Fetch audit records for this CI
        audit_response = await client.get_table_records(
            table="sys_audit",
            sysparm_query=f"documentkey={ci_sys_id}^tablename={ci_class}^ORDERBYDESCsys_created_on",
            sysparm_fields="fieldname,oldvalue,newvalue,user,sys_created_on,reason",
            sysparm_limit=limit
        )

        audit_records = audit_response.get("result", [])

        if not audit_records:
            return {
                "history_available": False,
                "message": "No audit history found (sys_audit may not be enabled)"
            }

        # Group by field
        field_changes = {}
        for record in audit_records:
            field_name = record.get("fieldname", "unknown")
            if field_name not in field_changes:
                field_changes[field_name] = []

            field_changes[field_name].append({
                "old_value": record.get("oldvalue"),
                "new_value": record.get("newvalue"),
                "changed_by": record.get("user", {}).get("display_value", "Unknown"),
                "changed_on": record.get("sys_created_on"),
                "reason": record.get("reason")
            })

        return {
            "history_available": True,
            "total_changes": len(audit_records),
            "fields_modified": len(field_changes),
            "field_changes": field_changes if audit_level == "deep" else None,
            "recent_changes_sample": audit_records[:10] if audit_level == "standard" else None,
            "most_frequently_modified_fields": _get_top_modified_fields(field_changes, 5)
        }

    except Exception as e:
        return {
            "history_available": False,
            "error": f"Failed to fetch field history: {str(e)}"
        }


def _get_top_modified_fields(field_changes: Dict[str, List], top_n: int = 5) -> List[Dict[str, Any]]:
    """Get fields with most modifications."""
    field_counts = [(field, len(changes)) for field, changes in field_changes.items()]
    field_counts.sort(key=lambda x: x[1], reverse=True)

    return [
        {"field": field, "modification_count": count}
        for field, count in field_counts[:top_n]
    ]


async def _analyze_source_attribution(
    client: ServiceNowClient,
    target_ci: Dict[str, Any],
    upstream_map: Dict[str, Any],
    downstream_map: Dict[str, Any]
) -> Dict[str, Any]:
    """Analyze data source attribution for CI and its lineage."""
    sources = {
        "target_ci": {
            "discovery_source": target_ci.get("discovery_source"),
            "created_by": target_ci.get("sys_created_by", {}).get("display_value", "Unknown"),
            "created_on": target_ci.get("sys_created_on"),
            "updated_by": target_ci.get("sys_updated_by", {}).get("display_value", "Unknown"),
            "updated_on": target_ci.get("sys_updated_on")
        },
        "lineage_sources": {
            "discovery": 0,
            "manual": 0,
            "integration": 0,
            "unknown": 0
        }
    }

    # Classify target CI source
    discovery_source = target_ci.get("discovery_source")
    if discovery_source:
        sources["lineage_sources"]["discovery"] += 1
    elif target_ci.get("sys_created_by", {}).get("display_value") == "admin":
        sources["lineage_sources"]["manual"] += 1
    else:
        sources["lineage_sources"]["unknown"] += 1

    # Analyze lineage CIs (sample approach for performance)
    all_ci_ids = list(upstream_map.keys())[:20] + list(downstream_map.keys())[:20]

    if all_ci_ids:
        try:
            query = "^OR".join([f"sys_id={ci_id}" for ci_id in all_ci_ids])
            lineage_cis = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=query,
                sysparm_fields="sys_id,discovery_source,sys_created_by",
                sysparm_limit=100
            )

            for ci in lineage_cis.get("result", []):
                if ci.get("discovery_source"):
                    sources["lineage_sources"]["discovery"] += 1
                elif ci.get("sys_created_by", {}).get("display_value") == "admin":
                    sources["lineage_sources"]["manual"] += 1
                else:
                    sources["lineage_sources"]["integration"] += 1

        except Exception:
            pass  # Silently fail source attribution

    return sources


def _calculate_lineage_coverage_score(
    upstream_map: Dict,
    downstream_map: Dict,
    upstream_issues: List,
    downstream_issues: List,
    circular_deps_upstream: List,
    circular_deps_downstream: List
) -> float:
    """Calculate lineage coverage quality score (0-100)."""
    score = 100.0

    # Penalize for lack of relationships
    total_relationships = len(upstream_map) + len(downstream_map)
    if total_relationships == 0:
        score -= 40.0  # Isolated CI
    elif total_relationships < 3:
        score -= 20.0  # Poorly connected

    # Penalize for orphaned paths
    orphan_count = len([i for i in upstream_issues + downstream_issues if i["type"] == "orphan"])
    score -= min(orphan_count * 5, 30)  # Max 30 point penalty

    # Penalize for circular dependencies
    circular_count = len(circular_deps_upstream + circular_deps_downstream)
    score -= min(circular_count * 10, 20)  # Max 20 point penalty

    # Penalize for errors
    error_count = len([i for i in upstream_issues + downstream_issues if i["type"] == "error"])
    score -= min(error_count * 5, 10)  # Max 10 point penalty

    return max(0.0, min(100.0, score))


def _get_coverage_grade(score: float) -> str:
    """Convert coverage score to letter grade."""
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


def _generate_lineage_recommendations(
    issues: List[Dict[str, Any]],
    coverage_score: float,
    upstream_map: Dict,
    downstream_map: Dict
) -> List[str]:
    """Generate actionable recommendations based on lineage analysis."""
    recommendations = []

    # Orphan recommendations
    orphan_count = len([i for i in issues if i["type"] == "orphan"])
    if orphan_count > 0:
        recommendations.append(
            f"Fix {orphan_count} orphaned relationship(s) using action_auto_heal_relationship_issues"
        )

    # Circular dependency recommendations
    circular_count = len([i for i in issues if i["type"] == "circular_dependency"])
    if circular_count > 0:
        recommendations.append(
            f"Review and resolve {circular_count} circular dependency chain(s) manually"
        )

    # Isolated CI recommendations
    if len(upstream_map) == 0 and len(downstream_map) == 0:
        recommendations.append(
            "This CI has no relationships - consider adding connections to improve CMDB accuracy"
        )

    # Coverage score recommendations
    if coverage_score < 70:
        recommendations.append(
            f"Lineage coverage score is {coverage_score:.1f}/100 - improve relationship quality"
        )

    if not recommendations:
        recommendations.append("Lineage quality is good - no immediate actions required")

    return recommendations
