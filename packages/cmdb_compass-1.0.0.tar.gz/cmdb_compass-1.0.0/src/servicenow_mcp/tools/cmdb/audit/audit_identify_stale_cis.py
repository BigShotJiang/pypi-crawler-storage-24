"""Identify Stale CIs Tool

Identifies Configuration Items (CIs) that haven't been updated or discovered recently,
helping prioritize cleanup, retirement, or re-discovery efforts.

Categorizes CIs by staleness:
- Fresh: Updated within 30 days
- Moderate: 30-60 days
- Aging: 60-90 days
- Stale: 90+ days (configurable threshold)

QUERY tool with no modification capability.
"""

from typing import Any, Dict, List
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata


async def identify_stale_cis(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    staleness_threshold_days: int = 90,
    include_details: bool = True,
    sample_size: int = 1000,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Identify stale CIs that haven't been updated/discovered within threshold.

    Analyzes timestamps with fallback logic (last_discovered → last_reported →
    sys_updated_on → u_last_scan_date) to categorize CIs by freshness.

    Useful for identifying CIs that need:
    - Re-discovery
    - Retirement/decommissioning
    - Manual verification

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., cmdb_ci_server)
        staleness_threshold_days: Days threshold for staleness (default: 90)
        include_details: If True, include full CI details in results
        sample_size: Max CIs to analyze for performance (default: 1000)
        audit_level: Analysis depth ('quick', 'standard', 'deep')

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ci_class: CI class analyzed
        - total_cis: Total active CIs found
        - stale_count: Number of stale CIs (> threshold)
        - fresh_count: Number of fresh CIs (< 30 days)
        - staleness_distribution: Breakdown by age buckets
        - stale_cis: List of stale CI details (if include_details=True)
        - fresh_cis: List of fresh CI details (if include_details=True)
        - recommendations: Actionable next steps
        - metadata: Phase 3 audit metadata
    """
    try:
        start_time = datetime.now()
        # Step 1: Fetch active CIs with timestamp fields
        # Include multiple timestamp fields for fallback logic
        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query="active=true",
            sysparm_fields="sys_id,name,sys_updated_on,last_discovered,last_reported,u_last_scan_date,operational_status",
            sysparm_limit=sample_size
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "status": "success",
                "ci_class": ci_class,
                "total_cis": 0,
                "stale_count": 0,
                "fresh_count": 0,
                "message": f"No active CIs found for class {ci_class}",
                "staleness_distribution": {},
                "recommendations": [],
                "metadata": build_audit_metadata(
                    audit_type="stale_cis_identification",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class
                ),
            }

        # Step 2: Analyze staleness for each CI
        staleness_results = _analyze_ci_staleness(
            cis,
            staleness_threshold_days=staleness_threshold_days
        )

        # Step 3: Categorize CIs
        stale_cis = staleness_results["stale_cis"]
        fresh_cis = staleness_results["fresh_cis"]
        moderate_cis = staleness_results["moderate_cis"]
        aging_cis = staleness_results["aging_cis"]
        unknown_cis = staleness_results["unknown_cis"]

        stale_count = len(stale_cis)
        fresh_count = len(fresh_cis)

        # Step 4: Build distribution summary
        staleness_distribution = {
            "0-30d (fresh)": fresh_count,
            "30-60d (moderate)": len(moderate_cis),
            "60-90d (aging)": len(aging_cis),
            f"90d+ (stale, >{staleness_threshold_days}d)": stale_count,
            "unknown": len(unknown_cis),
        }

        # Step 5: Generate recommendations
        recommendations = _generate_staleness_recommendations(
            stale_count=stale_count,
            fresh_count=fresh_count,
            total_cis=total_cis,
            staleness_threshold_days=staleness_threshold_days,
            ci_class=ci_class,
        )

        # Step 6: Prepare response
        # Calculate execution time
        execution_time = (datetime.now() - start_time).total_seconds()

        result = {
            "status": "success",
            "ci_class": ci_class,
            "total_cis": total_cis,
            "stale_count": stale_count,
            "fresh_count": fresh_count,
            "staleness_threshold_days": staleness_threshold_days,
            "staleness_distribution": staleness_distribution,
            "stale_percentage": round((stale_count / total_cis * 100), 2) if total_cis > 0 else 0,
            "fresh_percentage": round((fresh_count / total_cis * 100), 2) if total_cis > 0 else 0,
            "recommendations": recommendations,
            "message": f"Identified {stale_count}/{total_cis} stale CIs (>{staleness_threshold_days}d) in {ci_class}",
            "metadata": build_audit_metadata(
                audit_type="stale_cis_identification",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            ),
        }

        # Include detailed CI lists if requested
        if include_details:
            result["stale_cis"] = [_format_ci_summary(ci) for ci in stale_cis]
            result["fresh_cis"] = [_format_ci_summary(ci) for ci in fresh_cis]
            result["moderate_cis"] = [_format_ci_summary(ci) for ci in moderate_cis]
            result["aging_cis"] = [_format_ci_summary(ci) for ci in aging_cis]
            result["unknown_cis"] = [_format_ci_summary(ci) for ci in unknown_cis]

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
        }


def _analyze_ci_staleness(
    cis: List[Dict[str, Any]],
    staleness_threshold_days: int = 90
) -> Dict[str, List[Dict[str, Any]]]:
    """Analyze each CI and categorize by staleness."""
    now = datetime.now(timezone.utc)
    staleness_threshold = timedelta(days=staleness_threshold_days)

    stale_cis = []
    fresh_cis = []
    moderate_cis = []  # 30-60 days
    aging_cis = []     # 60-90 days
    unknown_cis = []

    for ci in cis:
        # Use timestamp fallback logic: last_discovered → last_reported → sys_updated_on → u_last_scan_date
        # Prioritize discovery timestamps as they're most accurate for staleness detection
        last_activity_str = (
            ci.get("last_discovered") or
            ci.get("last_reported") or
            ci.get("sys_updated_on") or
            ci.get("u_last_scan_date")
        )

        if not last_activity_str:
            ci["staleness_reason"] = "No timestamp available"
            ci["days_since_activity"] = None
            unknown_cis.append(ci)
            continue

        try:
            # Parse ServiceNow datetime format (handles ISO + SN timestamp)
            # Reuse timezone-robust parsing from Phase 3 Tool 1
            sanitized = last_activity_str.replace("Z", "+00:00")
            try:
                last_activity = datetime.fromisoformat(sanitized)
            except ValueError:
                # Fallback for ServiceNow native format "YYYY-MM-DD HH:MM:SS"
                last_activity = datetime.strptime(last_activity_str, "%Y-%m-%d %H:%M:%S")

            # Coerce naive timestamps to UTC
            if last_activity.tzinfo is None:
                last_activity = last_activity.replace(tzinfo=timezone.utc)

            age = now - last_activity
            days_since_activity = age.days

            # Annotate CI with staleness metadata
            ci["last_activity"] = last_activity_str
            ci["days_since_activity"] = days_since_activity

            # Categorize by age
            if age > staleness_threshold:
                ci["staleness_category"] = "stale"
                stale_cis.append(ci)
            elif age > timedelta(days=60):
                ci["staleness_category"] = "aging"
                aging_cis.append(ci)
            elif age > timedelta(days=30):
                ci["staleness_category"] = "moderate"
                moderate_cis.append(ci)
            else:
                ci["staleness_category"] = "fresh"
                fresh_cis.append(ci)

        except (ValueError, AttributeError) as e:
            ci["staleness_reason"] = f"Failed to parse timestamp: {str(e)}"
            ci["days_since_activity"] = None
            unknown_cis.append(ci)

    return {
        "stale_cis": stale_cis,
        "fresh_cis": fresh_cis,
        "moderate_cis": moderate_cis,
        "aging_cis": aging_cis,
        "unknown_cis": unknown_cis,
    }


def _format_ci_summary(ci: Dict[str, Any]) -> Dict[str, Any]:
    """Format CI for output with relevant staleness info."""
    return {
        "sys_id": ci.get("sys_id"),
        "name": ci.get("name"),
        "operational_status": ci.get("operational_status"),
        "last_activity": ci.get("last_activity"),
        "days_since_activity": ci.get("days_since_activity"),
        "staleness_category": ci.get("staleness_category", "unknown"),
        "staleness_reason": ci.get("staleness_reason"),
    }


def _generate_staleness_recommendations(
    stale_count: int,
    fresh_count: int,
    total_cis: int,
    staleness_threshold_days: int,
    ci_class: str,
) -> List[str]:
    """Generate actionable recommendations based on staleness analysis."""
    recommendations = []

    stale_pct = (stale_count / total_cis * 100) if total_cis > 0 else 0

    if stale_count == 0:
        recommendations.append(
            f"✅ Excellent! No stale CIs found. All {total_cis} CIs have been updated within {staleness_threshold_days} days."
        )
        return recommendations

    # High staleness (>50%)
    if stale_pct > 50:
        recommendations.append(
            f"🚨 CRITICAL: {stale_pct:.1f}% ({stale_count}/{total_cis}) CIs are stale. "
            f"Immediate action required to update CMDB."
        )
        recommendations.append(
            f"Action 1: Run ServiceNow Discovery immediately to refresh {ci_class} CIs."
        )
        recommendations.append(
            f"Action 2: Verify if stale CIs are decommissioned - use auto_retire_stale_cis tool."
        )
        recommendations.append(
            f"Action 3: Review manual data imports or integrations that may have stopped."
        )

    # Moderate staleness (20-50%)
    elif stale_pct > 20:
        recommendations.append(
            f"⚠️ WARNING: {stale_pct:.1f}% ({stale_count}/{total_cis}) CIs are stale. "
            f"Schedule discovery or cleanup."
        )
        recommendations.append(
            f"Action 1: Schedule ServiceNow Discovery for {ci_class} to update stale CIs."
        )
        recommendations.append(
            f"Action 2: Review top 10 stale CIs manually to identify patterns."
        )

    # Low staleness (<20%)
    else:
        recommendations.append(
            f"⚠️ {stale_count} CIs ({stale_pct:.1f}%) are stale (>{staleness_threshold_days}d). "
            f"Consider targeted cleanup."
        )
        recommendations.append(
            f"Action: Use auto_retire_stale_cis to retire decommissioned CIs."
        )

    # Fresh CI metrics
    fresh_pct = (fresh_count / total_cis * 100) if total_cis > 0 else 0
    if fresh_pct > 80:
        recommendations.append(
            f"✅ Good: {fresh_pct:.1f}% ({fresh_count}/{total_cis}) CIs are fresh (<30 days)."
        )

    return recommendations
