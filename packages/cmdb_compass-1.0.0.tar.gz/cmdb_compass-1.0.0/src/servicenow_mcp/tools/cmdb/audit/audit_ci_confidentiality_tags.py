"""
Tool #5: audit_ci_confidentiality_tags

Audits data classification tags (PII, PHI, PCI, confidential) for GDPR/DORA compliance.
Part of Phase 2B Governance Execution Plan - Compliance Validator tier (FINAL TOOL).

This tool identifies:
- Missing data classification tags on sensitive systems
- Over-classification (public data marked confidential)
- Under-classification (PII data marked public)
- GDPR compliance gaps (untagged PII/customer data)
- DORA compliance gaps (untagged operational/financial data)
- Classification consistency across related CIs

Enterprise Value:
- Enables GDPR Article 30 compliance (data processing registry)
- Supports DORA ICT risk classification requirements
- Prevents data breach penalties (€20M or 4% revenue under GDPR)
- Generates data classification audit reports for DPOs
- Automates security posture assessment
"""

from typing import Any, Dict, List, Optional, Set
from datetime import datetime
import re

from servicenow_mcp.servicenow import ServiceNowClient
from . import utils


# ==============================================================================
# Data Classification Configuration
# ==============================================================================

# Data classification levels (hierarchical: higher = more sensitive)
CLASSIFICATION_LEVELS = {
    "pii": {
        "level": 5,
        "name": "Personally Identifiable Information (PII)",
        "description": "Personal data subject to GDPR protection",
        "keywords": ["pii", "personal", "gdpr", "customer", "employee", "user", "contact"],
        "compliance_frameworks": ["GDPR"],
        "retention_default": "3_year",  # GDPR default
    },
    "phi": {
        "level": 5,
        "name": "Protected Health Information (PHI)",
        "description": "Health data subject to HIPAA/GDPR protection",
        "keywords": ["phi", "health", "medical", "patient", "hipaa", "clinical"],
        "compliance_frameworks": ["HIPAA", "GDPR"],
        "retention_default": "7_year",  # HIPAA default
    },
    "pci": {
        "level": 5,
        "name": "Payment Card Industry (PCI)",
        "description": "Payment card data subject to PCI-DSS",
        "keywords": ["pci", "payment", "card", "credit", "transaction", "billing"],
        "compliance_frameworks": ["PCI-DSS"],
        "retention_default": "7_year",  # PCI-DSS default
    },
    "confidential": {
        "level": 4,
        "name": "Confidential",
        "description": "Sensitive business data for internal use only",
        "keywords": ["confidential", "sensitive", "proprietary", "trade secret", "intellectual property"],
        "compliance_frameworks": ["DORA", "SOX"],
        "retention_default": "7_year",
    },
    "internal": {
        "level": 3,
        "name": "Internal",
        "description": "Internal business data not for public disclosure",
        "keywords": ["internal", "business", "operational", "finance", "hr"],
        "compliance_frameworks": ["DORA"],
        "retention_default": "3_year",
    },
    "public": {
        "level": 1,
        "name": "Public",
        "description": "Public information with no sensitivity restrictions",
        "keywords": ["public", "marketing", "website", "press", "external"],
        "compliance_frameworks": [],
        "retention_default": "1_year",
    },
    "unclassified": {
        "level": 0,
        "name": "Unclassified",
        "description": "No classification assigned (compliance violation)",
        "keywords": [],
        "compliance_frameworks": [],
        "retention_default": "3_year",
    }
}

# CI classes requiring mandatory data classification
CLASSIFICATION_REQUIRED_CLASSES = [
    "cmdb_ci_server",
    "cmdb_ci_database",
    "cmdb_ci_application",
    "cmdb_ci_service",
    "cmdb_ci_appl_software",
]

# GDPR-relevant data categories
GDPR_DATA_CATEGORIES = ["pii", "phi"]

# DORA-relevant data categories
DORA_DATA_CATEGORIES = ["confidential", "internal", "pci"]


# ==============================================================================
# Classification Detection Functions
# ==============================================================================

def detect_data_classification(ci_record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Detect the appropriate data classification for a CI based on keywords and attributes.

    Returns:
        - detected_classification: Best-match classification level
        - confidence: Confidence score (0-100)
        - reasoning: Why this classification was detected
        - keywords_matched: List of keywords that triggered detection
    """
    ci_name = str(ci_record.get("name", "")).lower()
    ci_class = str(ci_record.get("sys_class_name", "")).lower()
    description = str(ci_record.get("short_description", "")).lower()
    environment = str(ci_record.get("environment", "")).lower()

    # Combine all text fields for keyword matching
    combined_text = f"{ci_name} {ci_class} {description} {environment}"

    # Check each classification level for keyword matches
    matches = []
    for classification, config in CLASSIFICATION_LEVELS.items():
        if classification == "unclassified":
            continue  # Skip unclassified in detection

        keywords = config["keywords"]
        matched_keywords = [kw for kw in keywords if kw in combined_text]

        if matched_keywords:
            # Calculate confidence based on number of keywords matched
            confidence = min(100, len(matched_keywords) * 30)  # 30% per keyword, max 100%
            matches.append({
                "classification": classification,
                "confidence": confidence,
                "keywords_matched": matched_keywords,
                "level": config["level"]
            })

    # Return highest level classification with highest confidence
    if matches:
        # Sort by level (highest first), then confidence
        matches.sort(key=lambda x: (x["level"], x["confidence"]), reverse=True)
        best_match = matches[0]

        return {
            "detected_classification": best_match["classification"],
            "confidence": best_match["confidence"],
            "reasoning": f"Keywords matched: {', '.join(best_match['keywords_matched'])}",
            "keywords_matched": best_match["keywords_matched"],
            "classification_config": CLASSIFICATION_LEVELS[best_match["classification"]]
        }

    # No keywords matched - default to internal for servers/databases, public for others
    if ci_class in ["cmdb_ci_server", "cmdb_ci_database"]:
        default_class = "internal"
        reasoning = "No specific keywords matched - defaulting to Internal for infrastructure"
    else:
        default_class = "public"
        reasoning = "No specific keywords matched - defaulting to Public"

    return {
        "detected_classification": default_class,
        "confidence": 30,  # Low confidence for defaults
        "reasoning": reasoning,
        "keywords_matched": [],
        "classification_config": CLASSIFICATION_LEVELS[default_class]
    }


def check_classification_tag(ci_record: Dict[str, Any]) -> Optional[str]:
    """
    Check if CI has a data classification tag assigned.

    Returns:
        Classification tag value, or None if missing
    """
    # Check common field names for data classification
    classification_fields = [
        "u_data_classification",
        "u_security_classification",
        "data_classification",
        "security_classification",
        "confidentiality"
    ]

    for field in classification_fields:
        value = ci_record.get(field, "")
        if value and str(value).strip():
            return str(value).lower()

    return None


def validate_classification_consistency(
    ci_record: Dict[str, Any],
    assigned_classification: Optional[str],
    detected_classification: str
) -> Dict[str, Any]:
    """
    Validate that assigned classification matches detected classification.

    Returns:
        - is_consistent: bool
        - issue_type: over_classified, under_classified, or None
        - severity: critical, high, medium, low
        - description: explanation of issue
    """
    if not assigned_classification:
        # No classification assigned - missing classification issue
        return {
            "is_consistent": False,
            "issue_type": "missing_classification",
            "severity": "critical" if detected_classification in GDPR_DATA_CATEGORIES else "high",
            "description": f"Missing data classification tag (detected as {detected_classification})",
            "detected_classification": detected_classification,
        }

    # Normalize assigned classification
    assigned_classification = assigned_classification.lower()

    # Map common variations to standard classifications
    classification_mapping = {
        "personal": "pii",
        "sensitive": "confidential",
        "restricted": "confidential",
        "private": "confidential",
        "protected": "confidential",
    }

    normalized_assigned = classification_mapping.get(assigned_classification, assigned_classification)

    # Check if assigned classification exists in our levels
    if normalized_assigned not in CLASSIFICATION_LEVELS:
        return {
            "is_consistent": False,
            "issue_type": "invalid_classification",
            "severity": "high",
            "description": f"Invalid classification tag '{assigned_classification}' - not in approved list",
            "detected_classification": detected_classification,
        }

    # Check if assigned matches detected
    if normalized_assigned == detected_classification:
        return {
            "is_consistent": True,
            "issue_type": None,
            "severity": None,
            "description": "Classification tag is correct",
            "detected_classification": detected_classification,
        }

    # Classification mismatch - determine if over or under
    assigned_level = CLASSIFICATION_LEVELS[normalized_assigned]["level"]
    detected_level = CLASSIFICATION_LEVELS[detected_classification]["level"]

    if assigned_level > detected_level:
        # Over-classification (e.g., public data marked confidential)
        return {
            "is_consistent": False,
            "issue_type": "over_classified",
            "severity": "medium",
            "description": f"Over-classified: Marked as '{normalized_assigned}' but detected as '{detected_classification}'",
            "detected_classification": detected_classification,
            "assigned_classification": normalized_assigned,
        }
    else:
        # Under-classification (e.g., PII data marked public) - CRITICAL
        return {
            "is_consistent": False,
            "issue_type": "under_classified",
            "severity": "critical",
            "description": f"CRITICAL: Under-classified as '{normalized_assigned}' but should be '{detected_classification}'",
            "detected_classification": detected_classification,
            "assigned_classification": normalized_assigned,
        }


# ==============================================================================
# Compliance Calculation Functions
# ==============================================================================

def calculate_gdpr_compliance(
    total_cis: int,
    cis_with_pii_phi: int,
    properly_classified_pii_phi: int,
    under_classified_pii_phi: int
) -> Dict[str, Any]:
    """
    Calculate GDPR compliance score.

    GDPR Article 30: Organizations must maintain records of processing activities,
    including categories of personal data.

    Score:
    - 100% if all PII/PHI is properly classified
    - Deduct for under-classified PII/PHI (critical violation)
    - Deduct for missing classifications on PII/PHI systems
    """
    if cis_with_pii_phi == 0:
        return {
            "gdpr_compliance_score": 100,
            "gdpr_compliant": True,
            "reasoning": "No PII/PHI systems detected"
        }

    # Calculate compliance rate
    compliance_rate = (properly_classified_pii_phi / cis_with_pii_phi * 100) if cis_with_pii_phi > 0 else 0

    # Penalties for under-classification
    under_classification_penalty = (under_classified_pii_phi / cis_with_pii_phi * 100) if cis_with_pii_phi > 0 else 0

    # Final score
    score = compliance_rate - under_classification_penalty
    score = max(0, min(100, score))

    return {
        "gdpr_compliance_score": round(score, 1),
        "gdpr_compliant": score >= 90,  # 90% threshold for compliance
        "pii_phi_systems": cis_with_pii_phi,
        "properly_classified": properly_classified_pii_phi,
        "under_classified": under_classified_pii_phi,
        "reasoning": f"{properly_classified_pii_phi}/{cis_with_pii_phi} PII/PHI systems properly classified"
    }


def calculate_dora_compliance(
    total_cis: int,
    cis_with_operational_data: int,
    properly_classified_operational: int
) -> Dict[str, Any]:
    """
    Calculate DORA compliance score.

    DORA: Digital Operational Resilience Act requires classification of ICT systems
    by criticality and data sensitivity.

    Score:
    - 100% if all operational/financial systems are classified
    - Deduct for missing classifications
    """
    if cis_with_operational_data == 0:
        return {
            "dora_compliance_score": 100,
            "dora_compliant": True,
            "reasoning": "No operational/financial systems detected"
        }

    # Calculate compliance rate
    compliance_rate = (properly_classified_operational / cis_with_operational_data * 100) if cis_with_operational_data > 0 else 0

    return {
        "dora_compliance_score": round(compliance_rate, 1),
        "dora_compliant": compliance_rate >= 90,  # 90% threshold
        "operational_systems": cis_with_operational_data,
        "properly_classified": properly_classified_operational,
        "reasoning": f"{properly_classified_operational}/{cis_with_operational_data} operational systems properly classified"
    }


# ==============================================================================
# Scoring Algorithm
# ==============================================================================

def calculate_confidentiality_score(
    total_cis: int,
    properly_classified: int,
    missing_classification: int,
    over_classified: int,
    under_classified: int
) -> Dict[str, Any]:
    """
    Calculate overall data classification compliance score.

    Scoring:
    - Start at 100 points
    - Missing classification: -5 points each (high severity)
    - Under-classification: -10 points each (critical - data breach risk)
    - Over-classification: -2 points each (medium - operational overhead)
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)
    """
    score = 100

    # Deduct for missing classifications
    score -= (missing_classification * 5)

    # Deduct for under-classifications (critical)
    score -= (under_classified * 10)

    # Deduct for over-classifications (medium)
    score -= (over_classified * 2)

    # Cap at 0
    score = max(0, score)

    # Calculate grade
    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 50:
        grade = "D"
    else:
        grade = "F"

    # Calculate classification rate
    classification_rate = (properly_classified / total_cis * 100) if total_cis > 0 else 0

    return {
        "confidentiality_score": score,
        "grade": grade,
        "classification_rate": round(classification_rate, 1),
        "issues": {
            "missing_classification": missing_classification,
            "under_classified": under_classified,
            "over_classified": over_classified,
        }
    }


# ==============================================================================
# Main Tool Function
# ==============================================================================

async def audit_ci_confidentiality_tags(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
    include_remediation_plan: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit data classification tags (PII, PHI, PCI, confidential) for GDPR/DORA compliance.

    Detects and validates data classification across:
    - PII (Personally Identifiable Information) - GDPR protected
    - PHI (Protected Health Information) - HIPAA/GDPR protected
    - PCI (Payment Card Industry) - PCI-DSS protected
    - Confidential (Business sensitive) - DORA/SOX protected
    - Internal (Business operational) - DORA protected
    - Public (No restrictions)

    **ENTERPRISE VALUE:**
    - Enables GDPR Article 30 compliance (data processing registry)
    - Supports DORA ICT risk classification requirements
    - Prevents data breach penalties (€20M or 4% revenue under GDPR)
    - Generates data classification audit reports for Data Protection Officers
    - Automates security posture assessment across infrastructure

    **CLASSIFICATION LEVELS (Hierarchical):**
    1. PII/PHI/PCI (Level 5): Regulated data requiring strict protection
    2. Confidential (Level 4): Sensitive business data, internal only
    3. Internal (Level 3): Business operational data, not for public
    4. Public (Level 1): Public information, no restrictions
    5. Unclassified (Level 0): No classification assigned (VIOLATION)

    **DETECTION ALGORITHM:**
    - Keyword matching: Scans CI name, class, description for classification keywords
    - Confidence scoring: 30% per keyword matched, max 100%
    - Default fallback: Infrastructure → Internal, Applications → Public
    - Validation: Compares assigned tag vs detected classification

    **CLASSIFICATION ISSUES DETECTED:**

    1. **Missing Classification** (Critical/High):
       - No u_data_classification or u_security_classification field
       - Severity: Critical for PII/PHI, High for others
       - Impact: GDPR Article 30 violation, cannot demonstrate compliance

    2. **Under-Classification** (Critical):
       - PII data marked as Public/Internal
       - PHI data marked as Confidential (should be PHI)
       - Severity: Critical - data breach risk
       - Impact: GDPR fines, data exposure, regulatory penalties

    3. **Over-Classification** (Medium):
       - Public data marked as Confidential
       - Internal data marked as PII
       - Severity: Medium - operational overhead
       - Impact: Unnecessary access restrictions, reduced productivity

    4. **Invalid Classification** (High):
       - Classification tag not in approved list
       - Non-standard values (e.g., "super secret")
       - Impact: Cannot enforce policy, audit failures

    **GDPR COMPLIANCE SCORING:**
    - 100% if all PII/PHI systems properly classified
    - Deduct for under-classified PII/PHI (critical violation)
    - Threshold: 90% for compliance
    - Article 30 requirement: Maintain processing activity records

    **DORA COMPLIANCE SCORING:**
    - 100% if all operational/financial systems classified
    - Deduct for missing classifications
    - Threshold: 90% for compliance
    - Requirement: ICT system risk classification

    WHEN TO USE:
    - "Which systems are missing data classification tags?"
    - "Are we GDPR compliant with data classification?"
    - "Show me under-classified PII/PHI systems (data breach risk)"
    - "Audit DORA ICT risk classification compliance"
    - "Generate data classification report for DPO/auditors"

    AUDIT LEVELS:
    - quick: Sample 100 CIs, classification summary only
    - standard: Full scan with top 50 issues (RECOMMENDED)
    - deep: Full scan with detailed remediation plan

    Args:
        client: ServiceNow client instance
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server')
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_remediation_plan: Include prioritized remediation recommendations
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - confidentiality_score: Overall classification compliance (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs scanned
        - properly_classified: Count of correctly classified CIs
        - missing_classification: Count of untagged CIs
        - over_classified: Count of over-classified CIs
        - under_classified: Count of under-classified CIs (CRITICAL)
        - classification_rate: % of CIs with classification tags
        - classification_breakdown: CIs by classification level
          - pii: Count
          - phi: Count
          - pci: Count
          - confidential: Count
          - internal: Count
          - public: Count
          - unclassified: Count
        - gdpr_compliance: GDPR Article 30 compliance analysis
          - gdpr_compliance_score: Score (0-100)
          - gdpr_compliant: bool (>= 90%)
          - pii_phi_systems: Count
          - properly_classified: Count
          - under_classified: Count
        - dora_compliance: DORA ICT classification compliance
          - dora_compliance_score: Score (0-100)
          - dora_compliant: bool (>= 90%)
          - operational_systems: Count
          - properly_classified: Count
        - top_issues: Top classification issues sorted by severity
        - remediation_priority: Ordered remediation plan (if requested)
        - audit_metadata: Execution details and coverage
    """
    start_time = datetime.now()

    # Determine CI class to audit
    if not ci_class:
        ci_class = "cmdb_ci_server"  # Default to servers

    # Build query
    if audit_level == "quick":
        limit = sample_limit or 100
    else:
        limit = 10000  # Large enough for most audits

    # Fetch CIs
    try:
        response = await client.query_table(
            table=ci_class,
            query="",
            fields=[
                "sys_id", "name", "sys_class_name", "short_description", "environment",
                "u_data_classification", "u_security_classification", "data_classification",
                "security_classification", "confidentiality"
            ],
            limit=limit
        )

        # query_table returns a list directly, not {"result": [...]}
        cis = response
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "confidentiality_score": 100,
                "grade": "A",
                "total_cis": 0,
                "message": f"No CIs found in {ci_class}"
            }

        # Process each CI
        properly_classified = 0
        missing_classification = 0
        over_classified = 0
        under_classified = 0
        invalid_classification = 0

        classification_breakdown = {
            "pii": 0,
            "phi": 0,
            "pci": 0,
            "confidential": 0,
            "internal": 0,
            "public": 0,
            "unclassified": 0
        }

        issues = []
        pii_phi_systems = 0
        properly_classified_pii_phi = 0
        under_classified_pii_phi = 0

        operational_systems = 0
        properly_classified_operational = 0

        for ci in cis:
            # Detect expected classification
            detection = detect_data_classification(ci)
            detected_class = detection["detected_classification"]

            # Check assigned classification
            assigned_class = check_classification_tag(ci)

            # Validate consistency
            validation = validate_classification_consistency(ci, assigned_class, detected_class)

            # Track classification breakdown
            if assigned_class and assigned_class in classification_breakdown:
                classification_breakdown[assigned_class] += 1
            elif not assigned_class:
                classification_breakdown["unclassified"] += 1

            # Count by issue type
            if validation["is_consistent"]:
                properly_classified += 1

                # Track GDPR compliance (PII/PHI)
                if detected_class in GDPR_DATA_CATEGORIES:
                    pii_phi_systems += 1
                    properly_classified_pii_phi += 1

                # Track DORA compliance (Confidential/Internal/PCI)
                if detected_class in DORA_DATA_CATEGORIES:
                    operational_systems += 1
                    properly_classified_operational += 1

            else:
                issue_type = validation["issue_type"]

                if issue_type == "missing_classification":
                    missing_classification += 1

                    # Track GDPR compliance
                    if detected_class in GDPR_DATA_CATEGORIES:
                        pii_phi_systems += 1

                    # Track DORA compliance
                    if detected_class in DORA_DATA_CATEGORIES:
                        operational_systems += 1

                elif issue_type == "under_classified":
                    under_classified += 1

                    # Track GDPR compliance
                    if detected_class in GDPR_DATA_CATEGORIES:
                        pii_phi_systems += 1
                        under_classified_pii_phi += 1

                    # Track DORA compliance
                    if detected_class in DORA_DATA_CATEGORIES:
                        operational_systems += 1

                elif issue_type == "over_classified":
                    over_classified += 1

                elif issue_type == "invalid_classification":
                    invalid_classification += 1

                # Track issue
                issues.append({
                    "ci_name": ci.get("name"),
                    "ci_sys_id": ci.get("sys_id"),
                    "issue_type": issue_type,
                    "severity": validation["severity"],
                    "description": validation["description"],
                    "detected_classification": detected_class,
                    "assigned_classification": assigned_class,
                    "confidence": detection["confidence"],
                    "keywords_matched": detection.get("keywords_matched", [])
                })

        # Calculate overall score
        scoring_result = calculate_confidentiality_score(
            total_cis=total_cis,
            properly_classified=properly_classified,
            missing_classification=missing_classification,
            over_classified=over_classified,
            under_classified=under_classified
        )

        # Calculate GDPR compliance
        gdpr_compliance = calculate_gdpr_compliance(
            total_cis=total_cis,
            cis_with_pii_phi=pii_phi_systems,
            properly_classified_pii_phi=properly_classified_pii_phi,
            under_classified_pii_phi=under_classified_pii_phi
        )

        # Calculate DORA compliance
        dora_compliance = calculate_dora_compliance(
            total_cis=total_cis,
            cis_with_operational_data=operational_systems,
            properly_classified_operational=properly_classified_operational
        )

        # Sort issues by severity
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sorted_issues = sorted(
            issues,
            key=lambda x: (severity_order.get(x.get("severity", "low"), 4), x.get("ci_name", ""))
        )

        # Limit top issues based on audit level
        if audit_level == "quick":
            top_issues = sorted_issues[:10]
        elif audit_level == "standard":
            top_issues = sorted_issues[:50]
        else:  # deep
            top_issues = sorted_issues[:200]

        # Build remediation plan
        remediation_priority = []
        if include_remediation_plan and audit_level in ["standard", "deep"]:
            remediation_priority = build_remediation_plan(issues, audit_level)

        # Build result
        result = {
            "status": "success",
            "ci_class": ci_class,
            "confidentiality_score": scoring_result["confidentiality_score"],
            "grade": scoring_result["grade"],
            "total_cis": total_cis,
            "properly_classified": properly_classified,
            "missing_classification": missing_classification,
            "over_classified": over_classified,
            "under_classified": under_classified,
            "invalid_classification": invalid_classification,
            "classification_rate": scoring_result["classification_rate"],
            "classification_breakdown": classification_breakdown,
            "gdpr_compliance": gdpr_compliance,
            "dora_compliance": dora_compliance,
            "top_issues": top_issues,
        }

        # Add remediation plan if requested
        if remediation_priority:
            result["remediation_priority"] = remediation_priority

        # Add audit metadata with compliance information
        end_time = datetime.now()
        duration_seconds = (end_time - start_time).total_seconds()

        result["audit_metadata"] = utils.build_audit_metadata(
            audit_level=audit_level,
            total_records=total_cis,
            sampled_records=total_cis,
            tool_name="audit_ci_confidentiality_tags",
            parameters={
                "ci_class": ci_class,
                "domain": domain,
                "audit_level": audit_level,
                "include_remediation_plan": include_remediation_plan,
            }
        )
        result["audit_metadata"]["execution_time_seconds"] = round(duration_seconds, 2)
        result["audit_metadata"]["coverage"] = f"{total_cis} CIs scanned"

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
        }


def build_remediation_plan(issues: List[Dict[str, Any]], audit_level: str) -> List[Dict[str, Any]]:
    """
    Build prioritized remediation plan based on classification issues.

    Priority:
    1. Critical: Under-classified PII/PHI (data breach risk)
    2. Critical: Missing classification on PII/PHI systems
    3. High: Missing classification on other systems
    4. High: Invalid classifications
    5. Medium: Over-classifications
    """
    # Group issues by type and severity
    remediation_items = []

    # Count issues by type and severity
    issue_summary = {}
    for issue in issues:
        issue_type = issue.get("issue_type")
        severity = issue.get("severity")
        key = f"{severity}_{issue_type}"

        if key not in issue_summary:
            issue_summary[key] = {
                "type": issue_type,
                "severity": severity,
                "count": 0,
                "sample_cis": []
            }

        issue_summary[key]["count"] += 1

        # Add sample CIs (limit to 5 per issue type)
        if len(issue_summary[key]["sample_cis"]) < 5:
            issue_summary[key]["sample_cis"].append({
                "ci_name": issue.get("ci_name"),
                "ci_sys_id": issue.get("ci_sys_id"),
                "description": issue.get("description"),
                "detected_classification": issue.get("detected_classification"),
            })

    # Convert to remediation items and sort by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    for key, summary in issue_summary.items():
        remediation_items.append({
            "priority": severity_order.get(summary["severity"], 4),
            "severity": summary["severity"],
            "issue_type": summary["type"],
            "count": summary["count"],
            "recommended_action": get_remediation_action(summary["type"], summary["severity"]),
            "sample_issues": summary["sample_cis"] if audit_level == "deep" else summary["sample_cis"][:2],
            "estimated_effort": estimate_effort(summary["count"], summary["severity"]),
        })

    # Sort by priority (severity first, then count)
    remediation_items.sort(key=lambda x: (x["priority"], -x["count"]))

    return remediation_items


def get_remediation_action(issue_type: str, severity: str) -> str:
    """Get recommended remediation action for issue type."""
    actions = {
        "missing_classification": "Add u_data_classification field and populate with appropriate classification level",
        "under_classified": "URGENT: Review and upgrade classification to protect sensitive data - data breach risk",
        "over_classified": "Review and downgrade classification to reduce unnecessary access restrictions",
        "invalid_classification": "Update to approved classification values (PII/PHI/PCI/Confidential/Internal/Public)",
    }
    return actions.get(issue_type, "Review and correct data classification")


def estimate_effort(issue_count: int, severity: str) -> str:
    """Estimate remediation effort based on count and severity."""
    if issue_count < 10:
        effort = "Low (manual fix)"
    elif issue_count < 50:
        effort = "Medium (batch update)"
    elif issue_count < 200:
        effort = "High (automation recommended)"
    else:
        effort = "Very High (requires automation)"

    if severity == "critical":
        effort += " - URGENT"

    return effort
