"""
Executive Health Summary Tool

Generate a top-level CMDB health summary for executive stakeholders (CIO/CTO).
Provides weighted health score, domain grades, trend indicators, and executive summary.

Phase 3 Week 3 - Data Lineage & Executive Reporting
"""

import json
import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, score_to_health_grade
# Import existing audit tools for health calculation
from servicenow_mcp.tools.cmdb.audit.audit_compliance_summary_report import audit_compliance_summary_report
from servicenow_mcp.tools.cmdb.audit.audit_calculate_csdm_maturity_score import calculate_csdm_maturity_score
from servicenow_mcp.tools.cmdb.audit.audit_calculate_cmdb_health_score import calculate_cmdb_health_score


# =============================================================================
# Health Grade Thresholds
# =============================================================================


def _get_grade_color(grade: str) -> str:
    """Get color indicator for grade."""
    if grade.startswith("A"):
        return "🟢"  # Green - Excellent
    elif grade.startswith("B"):
        return "🟡"  # Yellow - Good
    elif grade.startswith("C"):
        return "🟠"  # Orange - Fair
    elif grade.startswith("D"):
        return "🔴"  # Red - Poor
    else:  # F
        return "⚫"  # Black - Critical


def _calculate_trend_indicator(
    current_score: float,
    historical_score: Optional[float],
    threshold: float = 5.0
) -> str:
    """
    Calculate trend indicator based on score change.

    Args:
        current_score: Current health score
        historical_score: Previous health score (if available)
        threshold: Minimum change to consider significant (default: 5.0)

    Returns:
        "↑" (improving), "↓" (declining), or "→" (steady)
    """
    if historical_score is None:
        return "→"  # No historical data, assume steady

    change = current_score - historical_score

    if abs(change) < threshold:
        return "→"  # Steady (change < threshold)
    elif change > 0:
        return "↑"  # Improving
    else:
        return "↓"  # Declining


def _generate_executive_summary(
    overall_score: float,
    overall_grade: str,
    domains: Dict[str, Any],
    trend: str,
    critical_issues_count: int
) -> str:
    """
    Generate plain-English executive summary.

    Args:
        overall_score: Overall health score
        overall_grade: Overall health grade
        domains: Domain breakdown with scores
        trend: Trend indicator
        critical_issues_count: Number of critical issues

    Returns:
        Plain-English summary suitable for executive presentation
    """
    # Determine health level
    health_level = "excellent" if overall_score >= 90 else \
                   "good" if overall_score >= 75 else \
                   "fair" if overall_score >= 60 else \
                   "poor" if overall_score >= 40 else "critical"

    # Determine trend description
    trend_desc = "improving" if trend == "↑" else \
                 "declining" if trend == "↓" else \
                 "stable"

    # Build summary
    summary = f"The CMDB is in {health_level} condition with an overall health score of {overall_score:.1f}% (Grade: {overall_grade}). "

    # Add trend
    summary += f"Health is {trend_desc} {trend}. "

    # Add domain insights
    domain_summaries = []
    for domain_name, domain_data in domains.items():
        domain_grade = domain_data.get("grade", "N/A")
        domain_score = domain_data.get("score", 0)
        domain_summaries.append(f"{domain_name} ({domain_grade}, {domain_score:.1f}%)")

    if domain_summaries:
        summary += f"Domain health: {', '.join(domain_summaries)}. "

    # Add critical issues
    if critical_issues_count > 0:
        summary += f"There are {critical_issues_count} critical issues requiring immediate attention. "
    else:
        summary += "No critical issues identified. "

    # Add recommendation
    if overall_score >= 90:
        summary += "Continue current data governance practices and monitor for emerging issues."
    elif overall_score >= 75:
        summary += "Focus on addressing identified gaps to achieve excellence."
    elif overall_score >= 60:
        summary += "Prioritize remediation of medium and high-priority issues."
    elif overall_score >= 40:
        summary += "Immediate action required to improve data quality and compliance."
    else:
        summary += "URGENT: CMDB requires comprehensive remediation plan and executive sponsorship."

    return summary


# =============================================================================
# Domain Health Calculation
# =============================================================================

async def _calculate_domain_health(
    client: ServiceNowClient,
    domain_name: str,
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Calculate health score for a specific domain.

    Args:
        client: ServiceNow client
        domain_name: "Infrastructure", "Applications", or "Services"
        audit_level: Detail level

    Returns:
        {
            "score": 0-100,
            "grade": "A+" to "F",
            "grade_color": emoji,
            "trend": "↑/↓/→",
            "key_metrics": {...}
        }
    """
    try:
        # Get compliance summary for this domain
        compliance_result = await audit_compliance_summary_report(
            client,
            domain_filter=domain_name,
            audit_level=audit_level,
            include_recommendations=False
        )

        if compliance_result.get("status") == "success":
            domain_score = compliance_result.get("overall_compliance_score", 0)
            domain_grade = score_to_health_grade(domain_score)

            # Extract key metrics
            dimensions = compliance_result.get("dimensions", {})
            key_metrics = {
                "completeness": dimensions.get("completeness", {}).get("score", 0),
                "correctness": dimensions.get("correctness", {}).get("score", 0),
                "relationships": dimensions.get("relationships", {}).get("score", 0),
                "staleness": dimensions.get("staleness", {}).get("score", 0),
                "duplicates": dimensions.get("duplicates", {}).get("score", 0),
            }

            # Calculate trend (simplified - would need historical data in production)
            # For now, estimate based on staleness score (high staleness = declining)
            staleness_score = key_metrics.get("staleness", 0)
            if staleness_score < 60:
                estimated_trend = "↓"  # Declining if staleness is high
            elif staleness_score >= 80:
                estimated_trend = "↑"  # Improving if freshness is good
            else:
                estimated_trend = "→"  # Steady

            return {
                "score": round(domain_score, 1),
                "grade": domain_grade,
                "grade_color": _get_grade_color(domain_grade),
                "trend": estimated_trend,
                "key_metrics": key_metrics,
                "status": "success"
            }
        else:
            # Failed to calculate domain health
            return {
                "score": 0.0,
                "grade": "F",
                "grade_color": "⚫",
                "trend": "→",
                "error": compliance_result.get("error", "Unknown error"),
                "status": "error"
            }

    except Exception as e:
        print(f"[ERROR] Domain health calculation failed for {domain_name}: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "grade": "F",
            "grade_color": "⚫",
            "trend": "→",
            "error": str(e),
            "status": "error"
        }


# =============================================================================
# Main Tool Function
# =============================================================================

async def audit_executive_health_summary(
    client: ServiceNowClient,
    *,
    include_trends: bool = True,
    include_domain_breakdown: bool = True,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Generate a top-level CMDB health summary for executive stakeholders.

    This tool provides the highest-level view of CMDB health, designed for
    CIO/CTO presentations and executive dashboards. It aggregates multiple
    audit dimensions into a single health score with letter grade, domain
    breakdown, and trend indicators.

    Args:
        client: ServiceNow client instance
        include_trends: Whether to include trend indicators (default: True)
        include_domain_breakdown: Whether to show per-domain grades (default: True)
        audit_level: Detail level - "quick", "standard", or "deep"

    Returns:
        Dictionary containing:
        - overall_health_score: Weighted average health (0-100)
        - health_grade: Letter grade ("A+" to "F")
        - grade_color: Emoji indicator for grade
        - trend_indicator: "↑" (improving), "↓" (declining), "→" (steady)
        - domains: Per-domain health breakdown (if included):
            - infrastructure: {score, grade, trend, key_metrics}
            - applications: {score, grade, trend, key_metrics}
            - services: {score, grade, trend, key_metrics}
        - key_metrics: High-level summary statistics
        - executive_summary: Plain-English summary for leadership
        - critical_issues_count: Number of critical issues
        - metadata: Audit metadata

    Example:
        >>> result = await audit_executive_health_summary(
        ...     client,
        ...     include_domain_breakdown=True,
        ...     audit_level="standard"
        ... )
        >>> print(f"CMDB Health: {result['health_grade']} ({result['overall_health_score']}%)")
        >>> print(f"Trend: {result['trend_indicator']}")
        >>> print(f"Summary: {result['executive_summary']}")
    """
    try:
        start_time = datetime.now()

        print(f"[INFO] Generating executive health summary (level: {audit_level})", file=sys.stderr)

        # Calculate domain health (if requested)
        domains = {}
        if include_domain_breakdown:
            print("[INFO] Calculating Infrastructure domain health...", file=sys.stderr)
            domains["infrastructure"] = await _calculate_domain_health(client, "Infrastructure", audit_level)

            print("[INFO] Calculating Applications domain health...", file=sys.stderr)
            domains["applications"] = await _calculate_domain_health(client, "Applications", audit_level)

            print("[INFO] Calculating Services domain health...", file=sys.stderr)
            domains["services"] = await _calculate_domain_health(client, "Services", audit_level)

        # Calculate overall health score
        # If we have domain breakdown, use weighted average
        if domains:
            # Domain weights: Infrastructure (40%), Applications (35%), Services (25%)
            domain_weights = {
                "infrastructure": 0.40,
                "applications": 0.35,
                "services": 0.25,
            }

            overall_score = sum(
                domains[domain_key]["score"] * weight
                for domain_key, weight in domain_weights.items()
                if domains[domain_key]["status"] == "success"
            )

            # Normalize if any domains failed
            successful_domains = [d for d in domains.values() if d["status"] == "success"]
            if len(successful_domains) < len(domains):
                # Renormalize weights
                total_weight = sum(
                    weight for domain_key, weight in domain_weights.items()
                    if domains[domain_key]["status"] == "success"
                )
                if total_weight > 0:
                    overall_score = overall_score / total_weight
        else:
            # No domain breakdown - use overall compliance score
            print("[INFO] Calculating overall compliance score...", file=sys.stderr)
            compliance_result = await audit_compliance_summary_report(
                client,
                domain_filter=None,
                audit_level=audit_level,
                include_recommendations=False
            )
            overall_score = compliance_result.get("overall_compliance_score", 0)

        # Assign grade
        overall_grade = score_to_health_grade(overall_score)
        grade_color = _get_grade_color(overall_grade)

        # Calculate trend (simplified - would need historical data)
        # For now, estimate based on domain trends
        if include_trends and domains:
            domain_trends = [d.get("trend", "→") for d in domains.values()]
            improving_count = domain_trends.count("↑")
            declining_count = domain_trends.count("↓")

            if improving_count > declining_count:
                overall_trend = "↑"
            elif declining_count > improving_count:
                overall_trend = "↓"
            else:
                overall_trend = "→"
        else:
            overall_trend = "→"

        # Calculate critical issues count
        critical_issues_count = 0
        if domains:
            for domain_data in domains.values():
                domain_score = domain_data.get("score", 0)
                if domain_score < 50:  # Critical threshold
                    critical_issues_count += 1

        # Gather key metrics
        key_metrics = {
            "total_domains_assessed": len(domains) if domains else 0,
            "domains_excellent": sum(1 for d in domains.values() if d.get("score", 0) >= 90) if domains else 0,
            "domains_good": sum(1 for d in domains.values() if 75 <= d.get("score", 0) < 90) if domains else 0,
            "domains_fair": sum(1 for d in domains.values() if 60 <= d.get("score", 0) < 75) if domains else 0,
            "domains_poor": sum(1 for d in domains.values() if d.get("score", 0) < 60) if domains else 0,
            "critical_issues_count": critical_issues_count,
        }

        # Generate executive summary
        executive_summary = _generate_executive_summary(
            overall_score=overall_score,
            overall_grade=overall_grade,
            domains=domains,
            trend=overall_trend,
            critical_issues_count=critical_issues_count
        )

        execution_time = (datetime.now() - start_time).total_seconds()

        # Build response
        result = {
            "status": "success",
            "overall_health_score": round(overall_score, 1),
            "health_grade": overall_grade,
            "grade_color": grade_color,
            "trend_indicator": overall_trend if include_trends else None,
            "domains": domains if include_domain_breakdown else None,
            "key_metrics": key_metrics,
            "executive_summary": executive_summary,
            "critical_issues_count": critical_issues_count,
            "metadata": build_audit_metadata(
                audit_type="executive_health_summary",
                audit_level=audit_level,
                execution_time=execution_time
            )
        }

        print(f"[INFO] Executive health summary complete: {overall_grade} ({overall_score:.1f}%) {overall_trend} in {execution_time:.2f}s", file=sys.stderr)

        return result

    except Exception as e:
        print(f"[ERROR] Executive health summary failed: {e}", file=sys.stderr)
        return {
            "status": "error",
            "error": str(e),
        }
