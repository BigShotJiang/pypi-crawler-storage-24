"""
Orchestrate CI Validation Flow

Validates CI readiness before auto-promotion by orchestrating multiple Phase 3 audit tools.
Checks health, freshness, lifecycle status, and relationship integrity.

Phase 4 orchestration tool - aggregates multiple audit results into promotion decision.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient

# Import Phase 3 tools
from servicenow_mcp.tools.cmdb.audit.audit_calculate_cmdb_health_score import calculate_cmdb_health_score
from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis
from servicenow_mcp.tools.cmdb.audit.audit_ci_lifecycle_health import audit_ci_lifecycle_health
from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import audit_validate_relationship_integrity
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, score_to_grade

async def audit_orchestrate_ci_validation_flow(
    client: ServiceNowClient,
    ci_class: str,
    *,
    audit_level: AuditLevel = "standard",
    health_threshold: float = 50.0,
    staleness_threshold_days: int = 90,
    lifecycle_required_states: Optional[List[str]] = None,
    relationship_threshold: float = 60.0,
) -> Dict[str, Any]:
    """
    Orchestrate CI validation flow by checking multiple health dimensions.

    Validates CI readiness for auto-promotion by orchestrating 4 Phase 3 audit tools:
    1. Health Score - Overall CMDB health (completeness, relationships, staleness, duplicates)
    2. Staleness Check - Identifies stale CIs exceeding age threshold
    3. Lifecycle Health - Validates CIs are in acceptable lifecycle states
    4. Relationship Integrity - Checks relationship health (orphans, circular deps)

    Args:
        client: ServiceNow client instance
        ci_class: CI class to validate (e.g., 'cmdb_ci_server')
        audit_level: 'quick', 'standard', or 'deep'
        health_threshold: Minimum health score required (0-100), default 50.0
        staleness_threshold_days: Maximum age in days before CI considered stale, default 90
        lifecycle_required_states: List of acceptable lifecycle states, default ['in_use', 'on_order']
        relationship_threshold: Minimum relationship health score (0-100), default 60.0

    Returns:
        Dictionary with:
        - validation_passed: Overall pass/fail boolean
        - validation_score: Aggregate validation score (0-100)
        - validation_grade: A-F grade based on score
        - checks: Detailed results for each validation check
        - blocking_issues: Issues preventing promotion
        - warnings: Non-blocking concerns
        - recommendation: Promotion decision with reasoning
        - metadata: Phase 3 metadata (audit_type, execution_time, etc.)
    """
    start_time = datetime.now()

    if lifecycle_required_states is None:
        lifecycle_required_states = ['in_use', 'on_order']

    # Track all validation checks
    checks = {}
    blocking_issues = []
    warnings = []

    try:
        # ========================================
        # Check 1: CMDB Health Score
        # ========================================
        print(f"[CI Validation Flow] Running health score check for {ci_class}...", flush=True)
        health_result = await calculate_cmdb_health_score(
            client,
            ci_class=ci_class,
            audit_level=audit_level
        )

        health_score = health_result.get("overall_score", 0)
        health_passed = health_score >= health_threshold

        checks["health_score"] = {
            "name": "CMDB Health Score",
            "passed": health_passed,
            "score": health_score,
            "threshold": health_threshold,
            "details": {
                "completeness_score": health_result.get("completeness_score", 0),
                "relationship_score": health_result.get("relationship_score", 0),
                "staleness_score": health_result.get("staleness_score", 0),
                "duplicate_score": health_result.get("duplicate_score", 0),
            },
            "weight": 0.30  # 30% of total validation score
        }

        if not health_passed:
            blocking_issues.append(
                f"Health score {health_score:.1f} below threshold {health_threshold} "
                f"(completeness: {health_result.get('completeness_score', 0):.1f}, "
                f"relationships: {health_result.get('relationship_score', 0):.1f})"
            )

        # ========================================
        # Check 2: Staleness
        # ========================================
        print(f"[CI Validation Flow] Running staleness check for {ci_class}...", flush=True)
        staleness_result = await identify_stale_cis(
            client,
            ci_class=ci_class,
            staleness_threshold_days=staleness_threshold_days,
            include_details=True
        )

        stale_count = staleness_result.get("stale_cis_count", 0)
        total_cis = staleness_result.get("total_cis", 1)
        staleness_percentage = (stale_count / total_cis * 100) if total_cis > 0 else 0
        staleness_passed = staleness_percentage < 20  # Less than 20% stale

        checks["staleness"] = {
            "name": "Staleness Check",
            "passed": staleness_passed,
            "stale_cis": stale_count,
            "total_cis": total_cis,
            "staleness_percentage": round(staleness_percentage, 1),
            "threshold_days": staleness_threshold_days,
            "weight": 0.25  # 25% of total validation score
        }

        if not staleness_passed:
            blocking_issues.append(
                f"{stale_count} stale CIs detected ({staleness_percentage:.1f}% of total), "
                f"exceeds 20% threshold"
            )
        elif stale_count > 0:
            warnings.append(
                f"{stale_count} CIs are stale (>{staleness_threshold_days} days) but within acceptable range"
            )

        # ========================================
        # Check 3: Lifecycle Health
        # ========================================
        print(f"[CI Validation Flow] Running lifecycle health check for {ci_class}...", flush=True)
        lifecycle_result = await audit_ci_lifecycle_health(
            client,
            ci_class=ci_class,
            audit_level=audit_level
        )

        lifecycle_score = lifecycle_result.get("lifecycle_health_score", 0)
        lifecycle_passed = lifecycle_score >= 70  # Minimum 70/100 lifecycle health

        # Check lifecycle state distribution
        lifecycle_dist = lifecycle_result.get("lifecycle_distribution", {})
        acceptable_states_count = sum(
            lifecycle_dist.get(state, 0) for state in lifecycle_required_states
        )
        acceptable_percentage = (acceptable_states_count / total_cis * 100) if total_cis > 0 else 0

        checks["lifecycle_health"] = {
            "name": "Lifecycle Health",
            "passed": lifecycle_passed,
            "score": lifecycle_score,
            "threshold": 70,
            "acceptable_states": lifecycle_required_states,
            "acceptable_percentage": round(acceptable_percentage, 1),
            "lifecycle_distribution": lifecycle_dist,
            "weight": 0.20  # 20% of total validation score
        }

        if not lifecycle_passed:
            blocking_issues.append(
                f"Lifecycle health score {lifecycle_score:.1f} below threshold 70 "
                f"({acceptable_percentage:.1f}% in acceptable states)"
            )

        # ========================================
        # Check 4: Relationship Integrity
        # ========================================
        print(f"[CI Validation Flow] Running relationship integrity check for {ci_class}...", flush=True)
        relationship_result = await audit_validate_relationship_integrity(
            client,
            ci_class=ci_class,
            audit_level=audit_level,
            check_circular=True,
            max_depth=5
        )

        relationship_score = relationship_result.get("relationship_health_score", 0)
        relationship_passed = relationship_score >= relationship_threshold

        violations = relationship_result.get("violations", {})
        total_violations = sum(v.get("count", 0) for v in violations.values() if isinstance(v, dict))

        checks["relationship_integrity"] = {
            "name": "Relationship Integrity",
            "passed": relationship_passed,
            "score": relationship_score,
            "threshold": relationship_threshold,
            "total_violations": total_violations,
            "violations": violations,
            "weight": 0.25  # 25% of total validation score
        }

        if not relationship_passed:
            blocking_issues.append(
                f"Relationship health score {relationship_score:.1f} below threshold {relationship_threshold} "
                f"({total_violations} violations detected)"
            )
        elif total_violations > 0:
            warnings.append(f"{total_violations} relationship violations detected but score acceptable")

        # ========================================
        # Calculate Aggregate Validation Score
        # ========================================
        validation_score = (
            (health_score * checks["health_score"]["weight"]) +
            ((100 - staleness_percentage) * checks["staleness"]["weight"]) +
            (lifecycle_score * checks["lifecycle_health"]["weight"]) +
            (relationship_score * checks["relationship_integrity"]["weight"])
        )

        validation_passed = len(blocking_issues) == 0
        validation_grade = score_to_grade(validation_score)

        # Generate recommendation
        if validation_passed:
            recommendation = f"✅ APPROVED for promotion - All validation checks passed (score: {validation_score:.1f}/100)"
        else:
            recommendation = f"❌ BLOCKED from promotion - {len(blocking_issues)} blocking issue(s) detected"

        return {
            "validation_passed": validation_passed,
            "validation_score": round(validation_score, 1),
            "validation_grade": validation_grade,
            "ci_class": ci_class,
            "total_cis_evaluated": total_cis,
            "checks": checks,
            "checks_summary": {
                "total": len(checks),
                "passed": sum(1 for c in checks.values() if c.get("passed", False)),
                "failed": sum(1 for c in checks.values() if not c.get("passed", False)),
            },
            "blocking_issues": blocking_issues,
            "warnings": warnings,
            "recommendation": recommendation,
            "status": "success",
            "metadata": build_audit_metadata(
                audit_type="ci_validation_flow",
                audit_level=audit_level,
                execution_time=(datetime.now() - start_time).total_seconds(),
                ci_class=ci_class
            )
        }

    except Exception as e:
        print(f"[ERROR] CI validation flow failed: {e}", flush=True)
        import traceback
        traceback.print_exc()

        return {
            "validation_passed": False,
            "validation_score": 0,
            "validation_grade": "F",
            "ci_class": ci_class,
            "checks": checks,
            "blocking_issues": [f"Validation failed with error: {str(e)}"],
            "warnings": [],
            "recommendation": "❌ BLOCKED - Validation flow encountered errors",
            "status": "error",
            "error": str(e),
            "metadata": build_audit_metadata(
                audit_type="ci_validation_flow",
                audit_level=audit_level,
                execution_time=(datetime.now() - start_time).total_seconds(),
                ci_class=ci_class
            )
        }
