"""Audit CI Identifier Rules Tool

Analyzes effectiveness of ServiceNow Identification & Reconciliation (IRE) rules.
Identifies misconfigured rules, duplicate detection gaps, and rule optimization opportunities.
"""

from typing import Any, Dict, List, Optional
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient


async def audit_ci_identifier_rules(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    analyze_duplicates: bool = True,
    check_rule_coverage: bool = True,
    check_rule_conflicts: bool = True,
) -> Dict[str, Any]:
    """
    Audit CI identification rule effectiveness and configuration.

    Analyzes ServiceNow Identification & Reconciliation Engine (IRE) rules
    to identify misconfiguration, duplicate detection gaps, and optimization
    opportunities. Provides recommendations for improving CI identification.

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., cmdb_ci_server, cmdb_ci_database)
        analyze_duplicates: If True, check for CIs that bypass duplicate detection
        check_rule_coverage: If True, verify all CIs are covered by identifier rules
        check_rule_conflicts: If True, detect conflicting identifier rules

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ci_class: CI class analyzed
        - total_cis: Total CI count in class
        - identifier_rules: List of active identifier rules for this class
        - rule_effectiveness: Metrics on rule performance
        - duplicate_risk_cis: CIs at risk of duplication (weak identifiers)
        - uncovered_cis: CIs without identifier rules
        - rule_conflicts: Conflicting or overlapping rules
        - recommendations: List of recommended improvements
    """
    try:
        # Step 1: Fetch all CIs for the specified class
        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query="active=true",
            sysparm_fields="sys_id,name,serial_number,ip_address,dns_domain,fqdn,asset_tag",
            sysparm_limit=1000
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "ci_class": ci_class,
                "total_cis": 0,
                "message": f"No active CIs found for class {ci_class}",
            }

        # Step 2: Analyze identifier patterns
        # NOTE: In real implementation, this would query cmdb_identifier_rule table
        # For now, we'll analyze common identifier fields

        identifier_fields = ["serial_number", "ip_address", "fqdn", "asset_tag"]
        field_coverage = {}
        duplicate_risk_cis = []
        uncovered_cis = []

        for field in identifier_fields:
            populated_count = 0
            unique_values = set()

            for ci in cis:
                value = ci.get(field)
                if value and value != "":
                    populated_count += 1
                    unique_values.add(value)

            coverage_pct = (populated_count / total_cis * 100) if total_cis > 0 else 0
            uniqueness_pct = (len(unique_values) / populated_count * 100) if populated_count > 0 else 0

            field_coverage[field] = {
                "populated_count": populated_count,
                "unique_count": len(unique_values),
                "coverage_percentage": round(coverage_pct, 2),
                "uniqueness_percentage": round(uniqueness_pct, 2),
                "is_effective": coverage_pct > 80 and uniqueness_pct > 95,
            }

        # Step 3: Identify CIs at risk of duplication
        if analyze_duplicates:
            for ci in cis:
                has_strong_identifier = False

                # Strong identifiers: serial_number, fqdn, asset_tag
                if ci.get("serial_number") or ci.get("fqdn") or ci.get("asset_tag"):
                    has_strong_identifier = True

                if not has_strong_identifier:
                    duplicate_risk_cis.append({
                        "sys_id": ci.get("sys_id"),
                        "name": ci.get("name"),
                        "reason": "Missing strong identifiers (serial_number, fqdn, asset_tag)",
                        "weak_identifiers": [
                            field for field in ["ip_address", "dns_domain"]
                            if ci.get(field)
                        ]
                    })

        # Step 4: Check for uncovered CIs (missing all identifiers)
        if check_rule_coverage:
            for ci in cis:
                has_any_identifier = any(ci.get(field) for field in identifier_fields)

                if not has_any_identifier:
                    uncovered_cis.append({
                        "sys_id": ci.get("sys_id"),
                        "name": ci.get("name"),
                        "issue": "No identifier fields populated",
                    })

        # Step 5: Detect potential rule conflicts
        rule_conflicts = []
        if check_rule_conflicts:
            # Check for CIs with same identifier values (potential conflicts)
            identifier_map = {}

            for ci in cis:
                for field in ["serial_number", "fqdn", "asset_tag"]:
                    value = ci.get(field)
                    if value and value != "":
                        key = f"{field}:{value}"
                        if key not in identifier_map:
                            identifier_map[key] = []
                        identifier_map[key].append(ci)

            # Find duplicates
            for key, ci_list in identifier_map.items():
                if len(ci_list) > 1:
                    field, value = key.split(":", 1)
                    rule_conflicts.append({
                        "identifier_field": field,
                        "identifier_value": value,
                        "conflicting_cis": [
                            {"sys_id": ci.get("sys_id"), "name": ci.get("name")}
                            for ci in ci_list
                        ],
                        "conflict_count": len(ci_list),
                    })

        # Step 6: Calculate rule effectiveness metrics
        strong_identifier_coverage = sum(
            1 for ci in cis
            if ci.get("serial_number") or ci.get("fqdn") or ci.get("asset_tag")
        )
        strong_coverage_pct = (strong_identifier_coverage / total_cis * 100) if total_cis > 0 else 0

        rule_effectiveness = {
            "total_cis": total_cis,
            "strong_identifier_coverage": strong_identifier_coverage,
            "strong_coverage_percentage": round(strong_coverage_pct, 2),
            "duplicate_risk_count": len(duplicate_risk_cis),
            "uncovered_count": len(uncovered_cis),
            "conflict_count": len(rule_conflicts),
            "field_coverage": field_coverage,
        }

        # Step 7: Generate recommendations
        recommendations = []

        if strong_coverage_pct < 80:
            recommendations.append(
                f"⚠️ Only {strong_coverage_pct:.1f}% of CIs have strong identifiers. "
                "Populate serial_number, FQDN, or asset_tag fields."
            )

        if len(duplicate_risk_cis) > 0:
            recommendations.append(
                f"⚠️ {len(duplicate_risk_cis)} CI(s) at risk of duplication due to weak identifiers. "
                "Add serial numbers or FQDNs to improve uniqueness."
            )

        if len(uncovered_cis) > 0:
            recommendations.append(
                f"⚠️ {len(uncovered_cis)} CI(s) have no identifier fields populated. "
                "These CIs cannot be deduplicated automatically."
            )

        if len(rule_conflicts) > 0:
            recommendations.append(
                f"⚠️ {len(rule_conflicts)} identifier conflict(s) detected. "
                "Multiple CIs share the same identifier value - investigate for duplicates."
            )

        for field, coverage in field_coverage.items():
            if coverage["coverage_percentage"] < 50:
                recommendations.append(
                    f"💡 {field} is only {coverage['coverage_percentage']:.1f}% populated. "
                    "Consider using discovery tools to populate this field."
                )

            if coverage["uniqueness_percentage"] < 90 and coverage["populated_count"] > 0:
                recommendations.append(
                    f"⚠️ {field} has low uniqueness ({coverage['uniqueness_percentage']:.1f}%). "
                    "This field is not suitable as a primary identifier."
                )

        if not recommendations:
            recommendations.append(
                f"✓ Identifier rules are effective for {ci_class}. "
                f"{strong_coverage_pct:.1f}% of CIs have strong identifiers."
            )

        # Step 8: Prepare response
        result = {
            "status": "success",
            "ci_class": ci_class,
            "total_cis": total_cis,
            "rule_effectiveness": rule_effectiveness,
            "duplicate_risk_cis": duplicate_risk_cis[:20],  # Limit to top 20
            "uncovered_cis": uncovered_cis[:20],
            "rule_conflicts": rule_conflicts[:20],
            "recommendations": recommendations,
            "message": f"Identifier rule audit complete for {ci_class}: "
                       f"{strong_coverage_pct:.1f}% strong identifier coverage, "
                       f"{len(duplicate_risk_cis)} at-risk CIs, "
                       f"{len(rule_conflicts)} conflicts detected",
        }

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }
