"""
Analyze Service Mappings Tool

Analyze Business Service to Application to Infrastructure dependency chains.
Audit-level tool for service mapping analysis (free).
"""

import sys
from typing import Any, Dict

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata


async def analyze_service_mappings(
    client: ServiceNowClient,
    domain: str = "Service Delivery",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Analyze Business Service to Application to Infrastructure dependency chains.

    This atomic tool validates complete service-to-infrastructure mapping chains
    required for service delivery visibility, impact analysis, and incident
    correlation. Identifies broken or incomplete chains.

    Args:
        client: ServiceNow client instance
        domain: Domain to analyze (typically 'Service Delivery' or 'Design')

    Returns:
        Dictionary containing:
        - services_analyzed: Total business services reviewed
        - complete_chains: Services with full end-to-end mapping
        - broken_chains: Services missing application or infrastructure mapping
        - orphaned_applications: Apps not mapped to any business service
        - orphaned_infrastructure: Infra CIs not mapped to any application
        - service_health: Quality assessment of service chains
        - remediation_actions: Specific mapping gaps to address
    """
    try:
        # Check if cmdb_ci_business_service table exists
        try:
            table_check = await client.get_table_records(
                table="sys_db_object",
                sysparm_query="name=cmdb_ci_business_service",
                sysparm_fields="sys_id,name",
                sysparm_limit=1
            )
            if not table_check.get("result"):
                # Table does not exist - graceful fallback
                return {
                    "domain": domain,
                    "status": "not_available",
                    "message": "cmdb_ci_business_service table not found. This is common in dev environments without CSDM content packs.",
                    "recommendation": "Install CSDM Content Pack or use cmdb_ci_service for legacy records",
                    "services_analyzed": 0,
                    "complete_chains": {"count": 0, "services": []},
                    "broken_chains": {"count": 0, "examples": []},
                    "chain_health": "Unknown",
                    "remediation_actions": [{
                        "priority": "critical",
                        "action": "Install CSDM Content Pack",
                        "impact": "Enable service-to-infrastructure mapping analysis"
                    }],
                    "audit_metadata": build_audit_metadata(audit_level, 0, 0)
                }
        except Exception as table_check_error:
            print(f"[WARNING] Could not check table existence: {table_check_error}", file=sys.stderr)
            # Continue with analysis attempt anyway
            pass

        # Count business services
        services_count = await client.count_records("cmdb_ci_business_service")
        total_services = services_count[0] if isinstance(services_count, tuple) else services_count

        # Get all business services with their applications
        services = await client.get_table_records(
            table="cmdb_ci_business_service",
            sysparm_fields="sys_id,name,short_description",
            sysparm_limit=500
        )

        service_records = services.get("result", [])
        complete_chains = []
        broken_chains = []

        # ── Batch query: all service→child relationships (replaces N per-service calls)
        svc_app_rels = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query="parent.sys_class_name=cmdb_ci_business_service",
            sysparm_fields="parent,child",
            sysparm_limit=10000,
            sysparm_display_value="false",
        )

        # Group by parent service → list of child (app) IDs
        service_to_apps: dict[str, list[str]] = {}
        for rel in svc_app_rels.get("result", []) or []:
            parent_id = rel.get("parent", "")
            child_id = rel.get("child", "")
            if parent_id and child_id:
                service_to_apps.setdefault(parent_id, []).append(child_id)

        # ── Batch query: all app→infra relationships (replaces M per-app calls)
        all_app_ids: set[str] = set()
        for apps in service_to_apps.values():
            all_app_ids.update(apps)

        apps_with_infra: set[str] = set()
        _BATCH = 200
        app_id_list = list(all_app_ids)
        for i in range(0, max(len(app_id_list), 1), _BATCH):
            batch = app_id_list[i:i + _BATCH]
            if not batch:
                break
            infra_rels = await client.get_table_records(
                table="cmdb_rel_ci",
                sysparm_query=f"parentIN{','.join(batch)}",
                sysparm_fields="parent",
                sysparm_limit=10000,
                sysparm_display_value="false",
            )
            for rel in infra_rels.get("result", []) or []:
                pid = rel.get("parent", "")
                if pid:
                    apps_with_infra.add(pid)

        # ── Build chain results in Python (no API calls)
        for service in service_records:
            service_id = service.get("sys_id")
            service_name = service.get("name")
            app_ids = service_to_apps.get(service_id, [])

            if not app_ids:
                broken_chains.append({
                    "service": service_name,
                    "issue": "No applications mapped to this service",
                    "related_apps": 0
                })
                continue

            has_infra = any(aid in apps_with_infra for aid in app_ids)
            if has_infra:
                complete_chains.append({
                    "service": service_name,
                    "service_id": service_id,
                    "applications_mapped": len(app_ids),
                    "infrastructure_mapped": True,
                    "chain_quality": "complete"
                })
            else:
                broken_chains.append({
                    "service": service_name,
                    "service_id": service_id,
                    "applications_mapped": len(app_ids),
                    "issue": "Applications exist but no infrastructure mapped",
                    "chain_quality": "incomplete"
                })

        # Orphaned applications (not mapped to any business service)
        all_apps_count = await client.count_records("cmdb_ci_application")
        total_apps = all_apps_count[0] if isinstance(all_apps_count, tuple) else all_apps_count
        mapped_app_count = len(all_app_ids)
        orphaned_app_count = max(0, total_apps - mapped_app_count)

        # Service health assessment
        if len(complete_chains) > 0 and len(broken_chains) == 0:
            chain_health = "Healthy"
        elif len(complete_chains) >= len(broken_chains):
            chain_health = "Fair"
        else:
            chain_health = "Poor"

        remediation_actions = []
        if len(broken_chains) > 0:
            remediation_actions.append({
                "priority": "high",
                "action": f"Complete mapping for {len(broken_chains)} services",
                "affected_services": [c["service"] for c in broken_chains[:5]],
                "impact": "Enable service-level impact analysis"
            })
        if orphaned_app_count > 0:
            remediation_actions.append({
                "priority": "high",
                "action": f"Map {orphaned_app_count} orphaned applications to services",
                "impact": "Ensure all applications visible in service model"
            })
        if len(complete_chains) == 0:
            remediation_actions.append({
                "priority": "critical",
                "action": "Establish baseline service-to-app mappings",
                "impact": "No service chains currently exist"
            })

        return {
            "domain": domain,
            "services_analyzed": len(service_records),
            "total_business_services": total_services,
            "complete_chains": {
                "count": len(complete_chains),
                "services": complete_chains[:10] if audit_level == "deep" else complete_chains[:5]
            },
            "broken_chains": {
                "count": len(broken_chains),
                "examples": broken_chains[:5] if audit_level == "deep" else broken_chains[:3]
            },
            "orphaned_applications": orphaned_app_count,
            "chain_health": chain_health,
            "remediation_actions": remediation_actions[:10] if audit_level == "deep" else remediation_actions[:5],
            "status": "success",
            "audit_metadata": build_audit_metadata(audit_level, total_services, total_services)
        }
    except Exception as e:
        print(f"[ERROR] analyze_service_mappings failed: {e}", file=sys.stderr)
        return {
            "domain": domain,
            "status": "error",
            "error": str(e)
        }
