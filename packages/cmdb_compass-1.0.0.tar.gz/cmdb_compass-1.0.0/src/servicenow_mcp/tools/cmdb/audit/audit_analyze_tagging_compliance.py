"""
Analyze Tagging Compliance Tool

Audit sys_tags population and tagging strategy compliance across CI classes.
Audit-level tool for tagging compliance analysis (free).
"""

import sys
from typing import Any, Dict

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, _check_table_access, build_audit_metadata, safe_count_records

async def analyze_tagging_compliance(
    client: ServiceNowClient,
    domain: str = "Foundation",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Audit sys_tags population and tagging strategy compliance across CI classes.

    This atomic tool evaluates how consistently CI records are tagged for
    discoverability, automation, and management. Identifies CI classes and
    business areas lacking proper tagging strategy.

    Supports three audit levels:
    - quick: Class-level tagging summary only
    - standard (default): Tagging compliance with sample analysis
    - deep: Full per-class tagging analysis and tag frequency

    Args:
        client: ServiceNow client instance
        domain: Domain to analyze for tagging compliance (default: 'Foundation')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - domain: The analyzed domain
        - ci_classes_analyzed: Number of CI classes checked
        - tagging_results: Per-class tagging population percentages
        - overall_tagging_compliance: Domain-wide tagging score (0-100)
        - classes_without_tags: CI classes with 0% tagging
        - low_tagging_classes: CI classes with < 50% tagging
        - tag_examples: Sample of popular tags in use (full for deep)
        - tagging_recommendations: Strategy for improvement
        - audit_metadata: Cost and coverage information
    """
    try:
        # Load CSDM rules dynamically to get CI classes for the domain
        csdm_rules = get_csdm_rules()
        ci_classes = csdm_rules.get_ci_classes_by_domain(domain)

        # If domain not found or no classes, return error
        if not ci_classes:
            return {
                "domain": domain,
                "status": "error",
                "error": f"Unsupported domain: {domain}. Valid domains: Foundation, Design, Build & Deploy, Service Delivery, Consume, Measure & Improve",
                "ci_classes_analyzed": 0,
                "tagging_results": [],
                "overall_tagging_compliance": 0.0,
                "total_cis_in_domain": 0,
                "tagged_cis_total": 0,
                "classes_without_tags": [],
                "low_tagging_classes": [],
                "top_tags": [],
                "tagging_recommendations": [],
                "audit_metadata": build_audit_metadata(audit_level, 0, 0)
            }

        tagging_results = []
        all_tags = {}
        total_domain_cis = 0
        classes_without_tags = []
        low_tagging_classes = []

        for ci_class in ci_classes:
            try:
                _check_table_access(ci_class)

                # Count total CIs in class
                total_cis = await safe_count_records(client, ci_class)
                total_domain_cis += total_cis

                if total_cis == 0:
                    continue

                # Count CIs with tags
                tagged_query = "sys_tagsNOT EMPTY"
                tagged_cis = await safe_count_records(client, ci_class, sysparm_query=tagged_query)

                tagging_percent = (tagged_cis / total_cis * 100) if total_cis > 0 else 0

                tagging_results.append({
                    "ci_class": ci_class,
                    "total_cis": total_cis,
                    "tagged_cis": tagged_cis,
                    "tagging_percent": round(tagging_percent, 1),
                    "gap": total_cis - tagged_cis
                })

                if tagging_percent == 0:
                    classes_without_tags.append(ci_class)
                elif tagging_percent < 50:
                    low_tagging_classes.append({
                        "ci_class": ci_class,
                        "percent": round(tagging_percent, 1)
                    })

                # Sample tags to understand tagging strategy
                if tagged_cis > 0:
                    sample_records = await client.get_table_records(
                        table=ci_class,
                        sysparm_query="sys_tagsNOT EMPTY",
                        sysparm_fields="sys_id,sys_tags",
                        sysparm_limit=20
                    )

                    for record in sample_records.get("result", []):
                        tags_str = record.get("sys_tags", "")
                        if tags_str:
                            # Parse comma-separated tags
                            tags = [t.strip() for t in tags_str.split(",") if t.strip()]
                            for tag in tags:
                                all_tags[tag] = all_tags.get(tag, 0) + 1

            except PermissionError:
                continue
            except Exception as e:
                print(f"[WARN] Could not analyze tagging for {ci_class}: {e}", file=sys.stderr)
                continue

        # Calculate overall tagging compliance
        total_tagged = sum(r["tagged_cis"] for r in tagging_results)
        overall_tagging_compliance = (total_tagged / total_domain_cis * 100) if total_domain_cis > 0 else 0

        # All tags sorted by frequency (no artificial limit)
        top_tags = sorted(all_tags.items(), key=lambda x: x[1], reverse=True)

        # Tagging recommendations
        recommendations = []
        if overall_tagging_compliance < 20:
            recommendations.append({
                "priority": "critical",
                "action": "Establish tagging standard and governance",
                "impact": "Enable automated workflows and improved searchability"
            })
        if len(classes_without_tags) > 0:
            recommendations.append({
                "priority": "high",
                "action": f"Start tagging initiative for {len(classes_without_tags)} untagged CI classes",
                "classes": classes_without_tags,
                "impact": "Unlock automation and classification benefits"
            })
        if overall_tagging_compliance < 50:
            recommendations.append({
                "priority": "high",
                "action": "Define tag taxonomy and create tagging policy",
                "suggestion": "Use tags like: environment, owner, cost_center, project, sla_tier",
                "impact": "Provide consistent classification across CMDB"
            })

        return {
            "domain": domain,
            "ci_classes_analyzed": len(tagging_results),
            "tagging_results": tagging_results,
            "overall_tagging_compliance": round(overall_tagging_compliance, 1),
            "total_cis_in_domain": total_domain_cis,
            "tagged_cis_total": total_tagged,
            "classes_without_tags": classes_without_tags,
            "low_tagging_classes": low_tagging_classes,
            "top_tags": top_tags,
            "tagging_recommendations": recommendations,
            "status": "success",
            "audit_metadata": build_audit_metadata(audit_level, total_domain_cis, total_domain_cis)
        }
    except Exception as e:
        print(f"[ERROR] analyze_tagging_compliance failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "domain": domain,
            "status": "error",
            "error": str(e)
        }
