"""Audit CI Duplicate Merge Confidence Tool

AI-driven merge confidence scoring to prevent data loss from incorrect CI merges.
Analyzes field matches, relationship overlap, and risk factors to recommend safe merges.

**Enterprise Value:**
- Prevents data loss from incorrect merges (high-risk for production CIs)
- Proves AI intelligence to enterprise buyers (not just queries)
- Enables automated deduplication with confidence thresholds
- Provides audit trail for merge decisions

**Algorithm:**
- Exact field matches (serial_number, hostname, IP): +40-60 pts
- Fuzzy name matching (Levenshtein distance): +20 pts
- Relationship overlap (shared connections): +20 pts
- Discovery source alignment: +10 pts
- Temporal proximity (created together): +10 pts
- Risk factors: Asset tag mismatch, owner conflict, status mismatch

**Confidence Grades:**
- High (90-100): Auto-merge safe
- Medium (70-89): Review recommended
- Low (<70): Manual review required
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit import utils
from servicenow_mcp.tools.cmdb.audit.utils import extract_display_value


async def audit_ci_duplicate_merge_confidence(
    client: ServiceNowClient,
    *,
    ci_sys_id_1: str,
    ci_sys_id_2: str,
    include_recommendations: bool = True,
) -> Dict[str, Any]:
    """
    Score merge confidence for two potentially duplicate CIs.

    Analyzes field similarity, relationship overlap, and risk factors to determine
    if merging two CIs is safe. Prevents data loss from incorrect merges.

    Args:
        client: ServiceNow client instance
        ci_sys_id_1: First CI sys_id (will become primary if merged)
        ci_sys_id_2: Second CI sys_id (will be deprecated if merged)
        include_recommendations: If True, includes detailed merge recommendations

    Returns:
        Dictionary containing:
        - confidence_score: Overall confidence (0-100)
        - confidence_grade: High/Medium/Low
        - recommendation: merge_safe|review_required|manual_review
        - match_analysis: Breakdown of field matches
        - risk_factors: List of identified risks
        - relationship_analysis: Shared relationship overlap
        - merge_strategy: Suggested approach if merge proceeds
        - warnings: Critical issues to resolve before merging
    """

    # Fetch both CIs with all fields
    try:
        ci1_response = await client.get_record_by_id(
            table="cmdb_ci",
            sys_id=ci_sys_id_1,
            sysparm_display_value="false"
        )
        ci1 = ci1_response.get("result", {})

        ci2_response = await client.get_record_by_id(
            table="cmdb_ci",
            sys_id=ci_sys_id_2,
            sysparm_display_value="false"
        )
        ci2 = ci2_response.get("result", {})

        if not ci1 or not ci2:
            return {
                "status": "error",
                "message": "One or both CIs not found",
                "confidence_score": 0,
                "confidence_grade": "Low",
                "recommendation": "cannot_merge"
            }

    except Exception as e:
        print(f"[ERROR] Failed to fetch CIs: {e}", file=sys.stderr)
        return {
            "status": "error",
            "message": f"Failed to fetch CIs: {str(e)}",
            "confidence_score": 0,
            "confidence_grade": "Low",
            "recommendation": "cannot_merge"
        }

    # Get CI class for field prioritization
    ci_class = ci1.get("sys_class_name") or ci2.get("sys_class_name") or "cmdb_ci"
    csdm_loader = get_csdm_rules()

    # Analyze field matches
    match_analysis = _analyze_field_matches(ci1, ci2, ci_class, csdm_loader)

    # Analyze relationship overlap
    relationship_analysis = await _analyze_relationship_overlap(client, ci_sys_id_1, ci_sys_id_2)

    # Identify risk factors
    risk_factors = _identify_risk_factors(ci1, ci2, relationship_analysis)

    # Calculate confidence score
    confidence_score = _calculate_confidence_score(
        match_analysis, relationship_analysis, risk_factors
    )

    # Determine confidence grade
    confidence_grade = _get_confidence_grade(confidence_score)

    # Generate recommendation
    recommendation = _generate_recommendation(
        confidence_score, confidence_grade, risk_factors
    )

    # Build result
    result = {
        "ci1": {
            "sys_id": ci_sys_id_1,
            "name": ci1.get("name", "Unknown"),
            "ci_class": ci1.get("sys_class_name", "Unknown"),
        },
        "ci2": {
            "sys_id": ci_sys_id_2,
            "name": ci2.get("name", "Unknown"),
            "ci_class": ci2.get("sys_class_name", "Unknown"),
        },
        "confidence_score": confidence_score,
        "confidence_grade": confidence_grade,
        "recommendation": recommendation,
        "match_analysis": match_analysis,
        "relationship_analysis": relationship_analysis,
        "risk_factors": risk_factors,
        "audit_metadata": utils.build_audit_metadata(
            audit_level="standard",
            total_records=2,
            sampled_records=2,
            tool_name="audit_ci_duplicate_merge_confidence",
            parameters={
                "ci_sys_id_1": ci_sys_id_1,
                "ci_sys_id_2": ci_sys_id_2,
                "include_recommendations": include_recommendations,
            }
        ),
        "status": "success",
    }

    # Add detailed recommendations if requested
    if include_recommendations:
        result["merge_strategy"] = _generate_merge_strategy(
            ci1, ci2, match_analysis, risk_factors
        )
        result["warnings"] = _generate_warnings(risk_factors, confidence_score)
        result["recommendations"] = _generate_detailed_recommendations(
            confidence_grade, risk_factors, match_analysis
        )

    return result


def _analyze_field_matches(
    ci1: Dict[str, Any],
    ci2: Dict[str, Any],
    ci_class: str,
    csdm_loader,
) -> Dict[str, Any]:
    """Analyze field similarity between two CIs."""

    # Get identification fields for this CI class
    id_fields = csdm_loader.get_duplicate_detection_fields(ci_class)

    # Standard fields to check for all CIs
    standard_fields = [
        "serial_number", "hostname", "host_name", "ip_address", "mac_address",
        "asset_tag", "name", "dns_name", "fqdn"
    ]

    # Combine and deduplicate
    fields_to_check = list(set(id_fields + standard_fields))

    exact_matches = []
    fuzzy_matches = []
    mismatches = []

    for field in fields_to_check:
        val1 = str(ci1.get(field, "")).strip().lower()
        val2 = str(ci2.get(field, "")).strip().lower()

        # Skip empty fields
        if not val1 or not val2:
            continue

        # Exact match
        if val1 == val2:
            exact_matches.append({
                "field": field,
                "value": val1,
                "match_type": "exact"
            })
        # Fuzzy match (Levenshtein distance)
        elif _levenshtein_distance(val1, val2) < 3:
            fuzzy_matches.append({
                "field": field,
                "value1": val1,
                "value2": val2,
                "match_type": "fuzzy",
                "distance": _levenshtein_distance(val1, val2)
            })
        else:
            mismatches.append({
                "field": field,
                "value1": val1,
                "value2": val2,
                "match_type": "mismatch"
            })

    # Calculate match percentage
    total_checked = len(exact_matches) + len(fuzzy_matches) + len(mismatches)
    match_percentage = round(
        ((len(exact_matches) + len(fuzzy_matches) * 0.5) / max(total_checked, 1)) * 100, 1
    ) if total_checked > 0 else 0

    return {
        "exact_matches": exact_matches,
        "fuzzy_matches": fuzzy_matches,
        "mismatches": mismatches,
        "match_percentage": match_percentage,
        "total_fields_checked": total_checked,
    }


async def _analyze_relationship_overlap(
    client: ServiceNowClient,
    ci_sys_id_1: str,
    ci_sys_id_2: str,
) -> Dict[str, Any]:
    """Analyze relationship overlap between two CIs."""

    try:
        # Fetch relationships for CI1
        rel1_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=f"parent={ci_sys_id_1}^ORchild={ci_sys_id_1}",
            sysparm_fields="parent,child,type",
            sysparm_limit=100,
        )
        rel1 = rel1_response.get("result", [])

        # Fetch relationships for CI2
        rel2_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=f"parent={ci_sys_id_2}^ORchild={ci_sys_id_2}",
            sysparm_fields="parent,child,type",
            sysparm_limit=100,
        )
        rel2 = rel2_response.get("result", [])

        # Extract related CI sys_ids
        def extract_related_cis(rels, source_ci):
            related = set()
            for rel in rels:
                parent = _extract_sys_id(rel.get("parent"))
                child = _extract_sys_id(rel.get("child"))
                if parent != source_ci:
                    related.add(parent)
                if child != source_ci:
                    related.add(child)
            return related

        related1 = extract_related_cis(rel1, ci_sys_id_1)
        related2 = extract_related_cis(rel2, ci_sys_id_2)

        # Calculate overlap
        shared_relationships = related1.intersection(related2)
        shared_pct = round(
            (len(shared_relationships) / max(len(related1.union(related2)), 1)) * 100, 1
        )

        return {
            "ci1_relationships": len(rel1),
            "ci2_relationships": len(rel2),
            "shared_relationships": len(shared_relationships),
            "shared_percentage": shared_pct,
            "relationship_count_diff": abs(len(rel1) - len(rel2)),
        }

    except Exception as e:
        print(f"[WARN] Failed to analyze relationships: {e}", file=sys.stderr)
        return {
            "ci1_relationships": 0,
            "ci2_relationships": 0,
            "shared_relationships": 0,
            "shared_percentage": 0,
            "relationship_count_diff": 0,
        }


def _identify_risk_factors(
    ci1: Dict[str, Any],
    ci2: Dict[str, Any],
    relationship_analysis: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Identify risk factors that could cause merge problems."""

    risks = []

    # Risk: Different asset tags
    asset_tag1 = str(ci1.get("asset_tag", "")).strip()
    asset_tag2 = str(ci2.get("asset_tag", "")).strip()
    if asset_tag1 and asset_tag2 and asset_tag1 != asset_tag2:
        risks.append({
            "risk": "asset_tag_mismatch",
            "severity": "critical",
            "message": f"Different asset tags: {asset_tag1} vs {asset_tag2}",
            "impact": "May represent different physical assets",
        })

    # Risk: Different owners
    owner1 = _extract_sys_id(ci1.get("owned_by", ""))
    owner2 = _extract_sys_id(ci2.get("owned_by", ""))
    if owner1 and owner2 and owner1 != owner2:
        risks.append({
            "risk": "owner_mismatch",
            "severity": "high",
            "message": "Different business owners assigned",
            "impact": "Ownership conflict - manual review required",
        })

    # Risk: Different operational status
    status1 = str(ci1.get("operational_status", "")).strip()
    status2 = str(ci2.get("operational_status", "")).strip()
    if status1 and status2 and status1 != status2:
        risks.append({
            "risk": "operational_status_mismatch",
            "severity": "medium",
            "message": f"Different operational status: {status1} vs {status2}",
            "impact": "One CI may be decommissioned while other is active",
        })

    # Risk: Large relationship count difference (potential data loss)
    rel_diff = relationship_analysis.get("relationship_count_diff", 0)
    if rel_diff > 5:
        risks.append({
            "risk": "relationship_count_diff",
            "severity": "high",
            "message": f"Large relationship count difference: {rel_diff} relationships",
            "impact": "DATA LOSS RISK - relationships may be orphaned after merge",
        })

    # Risk: Different discovery sources
    source1 = extract_display_value(ci1.get("discovery_source", ""))
    source2 = extract_display_value(ci2.get("discovery_source", ""))
    if source1 and source2 and source1 != source2:
        risks.append({
            "risk": "discovery_source_mismatch",
            "severity": "medium",
            "message": f"Different discovery sources: {source1} vs {source2}",
            "impact": "May indicate different scanning tools detected different assets",
        })

    return risks


def _calculate_confidence_score(
    match_analysis: Dict[str, Any],
    relationship_analysis: Dict[str, Any],
    risk_factors: List[Dict[str, Any]],
) -> int:
    """Calculate overall merge confidence score (0-100)."""

    score = 0

    # Field match scoring
    exact_matches = match_analysis.get("exact_matches", [])
    fuzzy_matches = match_analysis.get("fuzzy_matches", [])

    # High-value exact matches
    for match in exact_matches:
        field = match["field"]
        if field in ["serial_number"]:
            score += 40  # Serial number is strongest identifier
        elif field in ["hostname", "host_name", "mac_address"]:
            score += 20  # Strong identifiers
        elif field in ["ip_address", "dns_name", "fqdn"]:
            score += 15  # Medium identifiers
        elif field in ["name"]:
            score += 10  # Weak identifier (names can be reused)

    # Fuzzy matches (lower weight)
    for match in fuzzy_matches:
        field = match["field"]
        if field in ["name", "hostname", "host_name"]:
            score += 10  # Fuzzy name match

    # Relationship overlap
    shared_pct = relationship_analysis.get("shared_percentage", 0)
    if shared_pct > 50:
        score += 20  # Strong relationship overlap
    elif shared_pct > 25:
        score += 10  # Moderate overlap

    # Penalize for risk factors
    for risk in risk_factors:
        severity = risk.get("severity", "low")
        if severity == "critical":
            score -= 20
        elif severity == "high":
            score -= 10
        elif severity == "medium":
            score -= 5

    # Cap score at 0-100
    return max(0, min(100, score))


def _get_confidence_grade(score: int) -> str:
    """Convert confidence score to grade."""
    if score >= 90:
        return "High"
    elif score >= 70:
        return "Medium"
    else:
        return "Low"


def _generate_recommendation(
    score: int,
    grade: str,
    risk_factors: List[Dict[str, Any]],
) -> str:
    """Generate merge recommendation."""

    # Check for critical risks
    has_critical_risk = any(r["severity"] == "critical" for r in risk_factors)

    if has_critical_risk:
        return "manual_review"
    elif grade == "High":
        return "merge_safe"
    elif grade == "Medium":
        return "review_required"
    else:
        return "manual_review"


def _generate_merge_strategy(
    ci1: Dict[str, Any],
    ci2: Dict[str, Any],
    match_analysis: Dict[str, Any],
    risk_factors: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Generate suggested merge strategy."""

    # Determine primary CI (keep the one with more data)
    ci1_completeness = sum(1 for v in ci1.values() if v and str(v).strip())
    ci2_completeness = sum(1 for v in ci2.values() if v and str(v).strip())

    primary_ci = "ci1" if ci1_completeness >= ci2_completeness else "ci2"

    # Identify fields to preserve from secondary
    fields_to_preserve = []
    for mismatch in match_analysis.get("mismatches", []):
        field = mismatch["field"]
        if primary_ci == "ci1" and mismatch["value2"]:
            fields_to_preserve.append(field)
        elif primary_ci == "ci2" and mismatch["value1"]:
            fields_to_preserve.append(field)

    return {
        "primary_ci": primary_ci,
        "action": "merge_and_deprecate",
        "fields_to_preserve": fields_to_preserve[:10],  # Top 10
        "relationship_handling": "transfer_all_to_primary",
        "deprecation_action": "mark_duplicate_status",
    }


def _generate_warnings(
    risk_factors: List[Dict[str, Any]],
    confidence_score: int,
) -> List[str]:
    """Generate critical warnings."""

    warnings = []

    # Critical risk warnings
    for risk in risk_factors:
        if risk["severity"] in ["critical", "high"]:
            warnings.append(f"⚠️ {risk['message']} - {risk['impact']}")

    # Low confidence warning
    if confidence_score < 50:
        warnings.append("⚠️ VERY LOW CONFIDENCE - Do not merge without manual verification")

    return warnings


def _generate_detailed_recommendations(
    grade: str,
    risk_factors: List[Dict[str, Any]],
    match_analysis: Dict[str, Any],
) -> List[str]:
    """Generate detailed action recommendations."""

    recommendations = []

    if grade == "High":
        recommendations.append("✅ Safe to merge - high confidence match")
        recommendations.append("Recommend using automated merge workflow")
        recommendations.append("Verify field preservation strategy before executing")

    elif grade == "Medium":
        recommendations.append("⚠️ Review required before merging")
        recommendations.append("Manually verify key identification fields match")
        if risk_factors:
            recommendations.append(f"Resolve {len(risk_factors)} identified risk factors first")
        recommendations.append("Consider using dry-run merge to preview results")

    else:  # Low
        recommendations.append("❌ Manual review strongly recommended")
        recommendations.append("Too many mismatches or high-severity risks detected")
        recommendations.append("Investigate why discovery tools identified these as duplicates")
        if match_analysis.get("match_percentage", 0) < 30:
            recommendations.append("Consider that these may NOT be duplicates")

    return recommendations


def _levenshtein_distance(s1: str, s2: str) -> int:
    """Calculate Levenshtein distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]


def _extract_sys_id(field_value: Any) -> str:
    """Extract sys_id from field that might be string or dict."""
    if isinstance(field_value, dict):
        return field_value.get("value") or field_value.get("sys_id") or ""
    return str(field_value) if field_value else ""
