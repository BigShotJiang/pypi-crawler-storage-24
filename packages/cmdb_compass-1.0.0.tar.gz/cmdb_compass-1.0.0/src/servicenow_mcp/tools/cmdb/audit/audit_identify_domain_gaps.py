"""Identify Domain Gaps Tool

Aggregate completeness and relationship gaps for a CSDM domain.
Audit-level tool for domain-level gap analysis (read-only).
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules

from servicenow_mcp.tools.cmdb.audit import utils
from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health
from servicenow_mcp.tools.cmdb.audit.audit_analyze_ci_relationships import analyze_ci_relationships


async def identify_domain_gaps(
    client: ServiceNowClient,
    *,
    domain: str,
    audit_level: utils.AuditLevel,
    sanitize_table: Callable[[str], str],
) -> Dict[str, Any]:
    """Aggregate completeness and relationship gaps for a CSDM domain."""

    # Load CSDM rules dynamically to get CI classes for the domain
    try:
        csdm_rules = get_csdm_rules()
        ci_classes = csdm_rules.get_ci_classes_by_domain(domain)
    except Exception as e:
        return {
            "domain": domain,
            "status": "error",
            "error": f"Failed to load CSDM rules: {str(e)}",
        }

    if not ci_classes:
        return {
            "domain": domain,
            "status": "error",
            "error": f"Unsupported domain: {domain}. Valid domains: Foundation, Design, Build & Deploy, Service Delivery, Consume, Measure & Improve",
        }

    completeness_gaps: List[Dict[str, Any]] = []
    relationship_gaps: List[Dict[str, Any]] = []
    total_cis_in_domain = 0

    for ci_class in ci_classes:
        try:
            ci_table = sanitize_table(ci_class)
        except PermissionError as exc:
            return {"domain": domain, "status": "error", "error": str(exc)}

        # Use new unified analyze_cmdb_health tool
        health_result = await analyze_cmdb_health(
            client,
            ci_class=ci_class,
            ci_table=ci_table,
            domain=domain,
            audit_level=audit_level,
        )

        # Use new unified analyze_ci_relationships tool
        relationship_result = await analyze_ci_relationships(
            client,
            ci_class=ci_class,
            domain=domain,
            audit_level=audit_level,
        )

        total_cis_in_domain += health_result.get("total_cis", 0)
        completeness_gaps.append(
            {
                "ci_class": ci_class,
                "overall_completeness": health_result.get("completeness", {}).get("score", 0),
                "critical_gaps": health_result.get("completeness", {}).get("gaps", []).__len__(),
            }
        )
        relationship_gaps.append(
            {
                "ci_class": ci_class,
                "coverage_percent": relationship_result.get("coverage", {}).get("coverage_percent", 0),
                "missing_relationship_types": relationship_result.get("relationship_types", {}).get("missing_types", []),
            }
        )

    completeness_gaps_sorted = sorted(completeness_gaps, key=lambda entry: entry["overall_completeness"])
    relationship_gaps_sorted = sorted(relationship_gaps, key=lambda entry: entry["coverage_percent"])

    remediation_priority = "LOW"
    if completeness_gaps_sorted and completeness_gaps_sorted[0]["overall_completeness"] < 70:
        remediation_priority = "HIGH"
    elif relationship_gaps_sorted and relationship_gaps_sorted[0]["coverage_percent"] < 75:
        remediation_priority = "MEDIUM"

    return {
        "domain": domain,
        "ci_classes_analyzed": len(ci_classes),
        "completeness_gaps": completeness_gaps_sorted,
        "relationship_gaps": relationship_gaps_sorted,
        "remediation_priority": remediation_priority,
        "total_cis_in_domain": total_cis_in_domain,
        "status": "success",
        "audit_metadata": utils.build_audit_metadata(audit_level, total_cis_in_domain, total_cis_in_domain),
    }
