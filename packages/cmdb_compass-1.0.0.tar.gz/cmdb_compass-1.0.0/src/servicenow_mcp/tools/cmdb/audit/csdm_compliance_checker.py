"""CMDB/CSDM compliance analytics helper."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from servicenow_mcp.servicenow import ServiceNowClient

try:  # Optional dynamic rule generation imports
    from servicenow_mcp.csdm_generation import CSDMRuleGenerator, GenerationConfig, RuleGenerationError
except ImportError:  # pragma: no cover - optional dependency
    CSDMRuleGenerator = None  # type: ignore[assignment]
    GenerationConfig = None  # type: ignore[assignment]
    RuleGenerationError = RuntimeError  # type: ignore[assignment]


def _resolve_data_dir() -> Path:
    """Determine where static data assets are stored."""
    env_path = os.getenv("SERVICENOW_MCP_DATA_DIR")
    if env_path:
        candidate = Path(env_path).expanduser()
        if candidate.exists():
            return candidate

    package_root = Path(__file__).resolve().parent.parent.parent
    package_data = package_root / "data"
    if package_data.exists():
        return package_data

    cwd_data = Path.cwd() / "data"
    if cwd_data.exists():
        return cwd_data

    return package_data


DATA_DIR = _resolve_data_dir()
CSDM_RULES_PATH = DATA_DIR / "csdm_rules.json"
CSDM_TARGETS_PATH = DATA_DIR / "csdm" / "targets.json"

PAGE_SIZE = 200
DEFAULT_MAX_RECORDS = 5000  # Support full CMDB coverage (was 1000)

DEFAULT_TAGGING_RULES: Dict[str, List[Dict[str, Any]]] = {
    "Tagging": [
        {
            "table": "cmdb_ci",
            "display_name": "CI Tags",
            "query": "install_status=1",
            "required_fields": [
                "sys_tags",
            ],
            "limit": DEFAULT_MAX_RECORDS,
        },
        {
            "table": "cmdb_ci_service",
            "display_name": "Service Tags",
            "query": "",
            "required_fields": [
                "sys_tags",
            ],
            "limit": DEFAULT_MAX_RECORDS,
        },
        {
            "table": "cmdb_ci_appl",
            "display_name": "Application Tags",
            "query": "",
            "required_fields": [
                "sys_tags",
            ],
            "limit": DEFAULT_MAX_RECORDS,
        },
    ]
}

_CSDM_RULES_CACHE: Dict[str, Any] | None = None
_CSDM_TARGETS_CACHE: Dict[str, List[Dict[str, str]]] | None = None
_CSDM_RULE_GENERATOR: CSDMRuleGenerator | None = None

CSDM_DYNAMIC_RULES_ENABLED = os.getenv("CSDM_DYNAMIC_RULES", "1").lower() not in {"0", "false", ""}


def _load_csdm_rules() -> Dict[str, Any]:
    """Load static CSDM rule definitions from disk."""
    global _CSDM_RULES_CACHE  # noqa: PLW0603 - cache stored at module scope by design
    if _CSDM_RULES_CACHE is not None:
        return _CSDM_RULES_CACHE

    try:
        with CSDM_RULES_PATH.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
            if not isinstance(data, dict):
                raise ValueError("CSDM rules file must be a JSON object.")
            _CSDM_RULES_CACHE = data
    except FileNotFoundError:
        _CSDM_RULES_CACHE = {}
    except json.JSONDecodeError as exc:
        print(f"⚠️  Failed to parse CSDM rules: {exc}", file=sys.stderr)
        _CSDM_RULES_CACHE = {}
    except Exception as exc:  # pragma: no cover - defensive logging
        print(f"⚠️  Unexpected error loading CSDM rules: {exc}", file=sys.stderr)
        _CSDM_RULES_CACHE = {}

    return _CSDM_RULES_CACHE


def _load_csdm_targets() -> Dict[str, List[Dict[str, str]]]:
    """Load domain -> table targets for dynamic generation."""
    global _CSDM_TARGETS_CACHE  # noqa: PLW0603
    if _CSDM_TARGETS_CACHE is not None:
        return _CSDM_TARGETS_CACHE

    if not CSDM_TARGETS_PATH.exists():
        _CSDM_TARGETS_CACHE = {}
        return _CSDM_TARGETS_CACHE

    try:
        with CSDM_TARGETS_PATH.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
            if not isinstance(data, dict):
                raise ValueError("CSDM targets file must be a JSON object.")
            _CSDM_TARGETS_CACHE = {
                str(domain): list(entries) for domain, entries in data.items()
            }
    except Exception as exc:  # pragma: no cover - defensive logging
        print(f"⚠️  Failed to load CSDM targets: {exc}", file=sys.stderr)
        _CSDM_TARGETS_CACHE = {}

    return _CSDM_TARGETS_CACHE


def _get_csdm_rule_generator() -> Optional[CSDMRuleGenerator]:
    """Instantiate the dynamic rule generator if dependencies and keys are present."""
    global _CSDM_RULE_GENERATOR  # noqa: PLW0603
    if not CSDM_DYNAMIC_RULES_ENABLED:
        return None
    if CSDMRuleGenerator is None or GenerationConfig is None:
        return None
    if _CSDM_RULE_GENERATOR is not None:
        return _CSDM_RULE_GENERATOR
    try:
        _CSDM_RULE_GENERATOR = CSDMRuleGenerator()
    except Exception as exc:  # pragma: no cover - informative logging
        print(f"⚠️  Dynamic CSDM rule generation disabled: {exc}", file=sys.stderr)
        _CSDM_RULE_GENERATOR = None
    return _CSDM_RULE_GENERATOR


def _generate_dynamic_rules(domains: Sequence[str]) -> Dict[str, Dict[str, Any]]:
    """Generate rule definitions for the requested domains via RAG/LLM."""
    generator = _get_csdm_rule_generator()
    if not generator:
        return {}

    targets = _load_csdm_targets()
    requested_targets = {
        domain: targets.get(domain, [])
        for domain in domains
        if targets.get(domain)
    }

    if not requested_targets:
        return {}

    try:
        return generator.generate_rules(requested_targets)
    except RuleGenerationError as exc:  # pragma: no cover - surface error
        print(f"⚠️  Failed to generate CSDM rules dynamically: {exc}", file=sys.stderr)
    except Exception as exc:  # pragma: no cover - defensive logging
        print(f"⚠️  Unexpected error generating CSDM rules: {exc}", file=sys.stderr)
    return {}


def _extract_value(raw: Any) -> Any:
    """Normalize ServiceNow field representations to primitive values."""
    if isinstance(raw, dict):
        for key in ("value", "display_value", "name"):
            if key in raw and raw[key]:
                return raw[key]
        return raw.get("value") or raw.get("display_value") or raw
    if isinstance(raw, list):
        return [_extract_value(item) for item in raw]
    return raw


def _has_value(raw: Any) -> bool:
    """Determine if a field contains a meaningful value."""
    value = _extract_value(raw)
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, list):
        return any(_has_value(item) for item in value)
    return True


def _format_percentage(passed: int, total: int) -> float:
    """Return a percentage score for passed/total checks."""
    if total <= 0:
        return 100.0 if passed >= 0 else 0.0
    return round((passed / total) * 100, 1)


def _coerce_domain_list(domain: Optional[str]) -> List[str]:
    """Parse the requested domain string into a list of normalized tokens."""
    if not domain:
        return []
    if isinstance(domain, str):
        tokens = [segment.strip() for segment in domain.replace(",", " ").split() if segment.strip()]
        return tokens
    return []


def _legacy_table_to_rule(domain: str, table_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Convert legacy JSON definitions into normalized rule dictionaries."""
    display = payload.get("label") or table_name.replace("_", " ").title()
    fields = payload.get("fields", {})
    required_fields: List[str] = []
    if isinstance(fields, dict):
        required_fields = [
            str(name).strip()
            for name in fields.keys()
            if isinstance(name, str) and str(name).strip()
        ]

    legacy_relationships = payload.get("relationships") or {}
    relationships: List[Dict[str, Any]] = []
    if isinstance(legacy_relationships, dict):
        for rel_name, rel_payload in legacy_relationships.items():
            if not isinstance(rel_payload, dict):
                continue
            relationships.append(
                {
                    "name": str(rel_name or "Relationship"),
                    "query_template": rel_payload.get("query_template", ""),
                    "min_count": rel_payload.get("min_count", 1),
                    "description": str(rel_payload.get("description") or ""),
                }
            )

    rule: Dict[str, Any] = {
        "domain": domain,
        "display_name": display,
        "table": table_name,
        "query": str(payload.get("query") or ""),
        "required_fields": required_fields,
        "relationships": relationships,
        "name_field": str(payload.get("name_field") or "name"),
        "limit": int(payload.get("limit", DEFAULT_MAX_RECORDS)),
    }
    return rule


def _normalize_domain_rules(domain: str, raw_entry: Any) -> List[Dict[str, Any]]:
    """Normalize arbitrary rule formats into canonical rule dictionaries."""
    rules: List[Dict[str, Any]] = []

    if isinstance(raw_entry, list):
        for entry in raw_entry:
            if not isinstance(entry, dict):
                continue
            if "table" in entry:
                normalized = dict(entry)
                normalized.setdefault("domain", domain)
                rules.append(normalized)
                continue
            for table_name, payload in entry.items():
                if isinstance(payload, dict):
                    rules.append(_legacy_table_to_rule(domain, str(table_name), payload))
        return rules

    if isinstance(raw_entry, dict):
        if "table" in raw_entry:
            normalized = dict(raw_entry)
            normalized.setdefault("domain", domain)
            rules.append(normalized)
            return rules
        for table_name, payload in raw_entry.items():
            if isinstance(payload, dict):
                rules.append(_legacy_table_to_rule(domain, str(table_name), payload))

    return rules


async def _evaluate_csdm_domain(
    client: ServiceNowClient,
    domain_key: str,
    rule: Dict[str, Any],
    *,
    check_relations: bool,
) -> Dict[str, Any]:
    """Evaluate a single CSDM rule domain and return compliance analytics."""
    # Ensure rule is actually a dict, not a string or other type
    if not isinstance(rule, dict):
        print(f"[ERROR] _evaluate_csdm_domain: rule is not a dict, type={type(rule).__name__}, value={rule!r}", file=sys.stderr)
        return {
            "domain": domain_key,
            "display_name": domain_key.replace("_", " ").title(),
            "records": 0,
            "passed": 0,
            "total": 0,
            "compliance": 0.0,
            "missing_fields": [],
            "relationship_gaps": [],
            "notes": [],
            "error": f"Rule is not a valid dictionary (type: {type(rule).__name__})",
        }

    display_name = rule.get("display_name") or domain_key.replace("_", " ").title()
    table = rule.get("table")
    if not table:
        return {
            "domain": domain_key,
            "display_name": display_name,
            "records": 0,
            "passed": 0,
            "total": 0,
            "compliance": 0.0,
            "missing_fields": [],
            "relationship_gaps": [],
            "notes": [],
            "error": "Rule is missing a target table definition.",
        }

    query = rule.get("query") or ""
    name_field = str(rule.get("name_field", "name"))

    raw_required_fields = rule.get("required_fields", [])
    required_fields: List[str] = []
    for field in raw_required_fields:
        if isinstance(field, str):
            field_name = field.strip()
            if field_name:
                required_fields.append(field_name)
        elif isinstance(field, dict):
            field_name = field.get("name") or field.get("field") or field.get("id")
            if field_name:
                required_fields.append(str(field_name).strip())

    relationships_raw = rule.get("relationships", [])
    relationships: List[Dict[str, Any]] = []
    for rel in relationships_raw:
        if not isinstance(rel, dict):
            continue
        rel_name = str(rel.get("name", "Unnamed relationship")).strip()
        query_template = str(rel.get("query_template", "") or "").strip()
        min_count = int(rel.get("min_count", 0))
        description = str(rel.get("description", "") or "").strip()
        relationships.append(
            {
                "name": rel_name or "Relationship",
                "query_template": query_template,
                "min_count": max(min_count, 0),
                "description": description,
            }
        )

    field_set = set(required_fields)
    field_set.update({"sys_id", name_field})
    field_list = ",".join(sorted(field_set))

    max_records = int(rule.get("limit") or DEFAULT_MAX_RECORDS)
    records: List[Dict[str, Any]] = []
    offset = 0
    try:
        while True:
            page_size = min(PAGE_SIZE, max_records - len(records))
            if page_size <= 0:
                break
            response = await client.get_table_records(
                table=table,
                sysparm_query=query or None,
                sysparm_limit=page_size,
                sysparm_offset=offset,
                sysparm_display_value="true",
                sysparm_fields=field_list,
            )
            page = response.get("result", [])
            if not isinstance(page, list) or not page:
                break
            records.extend(page)
            offset += page_size
            if len(page) < page_size:
                break
    except Exception as exc:  # pragma: no cover - surface API failure details
        return {
            "domain": domain_key,
            "display_name": display_name,
            "records": 0,
            "passed": 0,
            "total": 0,
            "compliance": 0.0,
            "missing_fields": [],
            "relationship_gaps": [],
            "notes": [],
            "error": f"Failed to query {table}: {exc}",
        }

    if not records:
        return {
            "domain": domain_key,
            "display_name": display_name,
            "records": 0,
            "passed": 0,
            "total": len(required_fields) * 0,
            "compliance": 0.0,
            "missing_fields": [],
            "relationship_gaps": [],
            "notes": ["No records matched the rule query."],
            "error": None,
        }

    total_checks = 0
    passed_checks = 0
    missing_fields_map: Dict[str, set[str]] = {}
    record_labels: Dict[str, str] = {}
    relationship_gaps: List[Dict[str, str]] = []
    notes: List[str] = []

    for idx, record in enumerate(records):
        record_name_raw = record.get(name_field) or record.get("name") or ""
        record_name = _extract_value(record_name_raw) or f"{table} record"
        sys_id_raw = record.get("sys_id")
        sys_id = _extract_value(sys_id_raw)
        record_key = str(sys_id or f"{table}:{idx}")
        record_labels[record_key] = str(record_name)

        for field in required_fields:
            total_checks += 1
            if _has_value(record.get(field)):
                passed_checks += 1
            else:
                missing_fields_map.setdefault(record_key, set()).add(field)
                print(
                    f"⚠️  [{display_name}] {record_name} missing required field '{field}'",
                    file=sys.stderr,
                )

        if not check_relations or not relationships:
            continue

        if not sys_id:
            if relationships:
                notes.append(f"{record_name} is missing a sys_id; unable to inspect relationships.")
            continue

        for relationship in relationships:
            total_checks += 1
            query_template = relationship.get("query_template")
            if not isinstance(query_template, str) or not query_template.strip():
                notes.append(
                    f"{relationship.get('name', 'Relationship')} has no query_template definition."
                )
                continue

            try:
                relation_query = query_template.format(sys_id=sys_id)
            except Exception as exc:  # pragma: no cover - defensive formatting
                notes.append(
                    f"Failed to format relationship query for {relationship.get('name', 'relationship')}: {exc}"
                )
                continue

            min_count = max(int(relationship.get("min_count", 1)), 0)
            rel_limit = max(min_count, int(relationship.get("limit", 10)))

            try:
                rel_records = await client.query_table(
                    table="cmdb_rel_ci",
                    query=relation_query,
                    limit=rel_limit,
                    fields="sys_id",
                )
            except Exception as exc:  # pragma: no cover
                notes.append(
                    f"Failed to evaluate relationship '{relationship.get('name', 'relationship')}': {exc}"
                )
                continue

            rel_count = len(rel_records)
            if rel_count >= min_count:
                passed_checks += 1
            else:
                description = relationship.get("description") or ""
                relationship_gaps.append(
                    {
                        "record": str(record_name),
                        "relationship": relationship.get("name", "Unknown relationship"),
                        "expected": f">={min_count}",
                        "found": str(rel_count),
                        "description": description,
                    }
                )
                print(
                    f"⚠️  [{display_name}] {record_name} missing relationship "
                    f"'{relationship.get('name', 'relationship')}' (expected >= {min_count})",
                    file=sys.stderr,
                )

    compliance = _format_percentage(passed_checks, total_checks)

    missing_fields: List[Dict[str, Any]] = [
        {"record": record_labels[key], "fields": sorted(fields)}
        for key, fields in sorted(missing_fields_map.items())
    ]

    return {
        "domain": domain_key,
        "display_name": display_name,
        "records": len(records),
        "passed": passed_checks,
        "total": total_checks,
        "compliance": compliance,
        "missing_fields": missing_fields,
        "relationship_gaps": relationship_gaps,
        "notes": notes,
        "error": None,
    }


def _extract_tagging_analysis(evaluations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Extract tagging percentages from Tagging domain evaluations."""
    tagging_data = {
        "ci_tagging_percentage": 0.0,
        "service_tagging_percentage": 0.0,
        "application_tagging_percentage": 0.0,
    }

    for evaluation in evaluations:
        domain = evaluation.get("domain", "")
        display_name = evaluation.get("display_name", "")
        compliance = evaluation.get("compliance", 0.0)

        if domain == "Tagging":
            if "CI Tags" in display_name:
                tagging_data["ci_tagging_percentage"] = compliance
            elif "Service Tags" in display_name:
                tagging_data["service_tagging_percentage"] = compliance
            elif "Application Tags" in display_name:
                tagging_data["application_tagging_percentage"] = compliance

    return tagging_data


async def run_compliance_check(
    client: ServiceNowClient,
    *,
    domain: Optional[str] = None,
    use_ai: bool = True,
) -> Dict[str, Any]:
    """
    Evaluate CMDB compliance for the requested domain(s).

    Args:
        client: Initialized ServiceNow client.
        domain: Optional domain name to inspect. When omitted, evaluates every domain with rules.
        use_ai: Toggle dynamic (AI-generated) rule augmentation.

    Returns:
        Structured compliance analytics payload.
    """
    static_rules_raw = _load_csdm_rules()
    static_rules = {
        domain_key: _normalize_domain_rules(domain_key, value)
        for domain_key, value in static_rules_raw.items()
        if value is not None
    }
    for domain, rules_list in DEFAULT_TAGGING_RULES.items():
        if domain not in static_rules:
            static_rules[domain] = []
        if not static_rules[domain]:
            static_rules[domain].extend(rules_list)

    targets = _load_csdm_targets()

    available_domains = sorted({*static_rules.keys(), *targets.keys()})
    if not available_domains:
        return {
            "domain": "none",
            "domains": [],
            "compliance": 0.0,
            "missing_fields": [],
            "summary": (
                "No CSDM rules or targets were available. Provide knowledge sources or disable the tool."
            ),
            "details": [],
            "missing_domains": [],
            "relationship_gaps": [],
            "checks_executed": 0,
        }

    requested_domains = _coerce_domain_list(domain)
    if not requested_domains:
        selected_domains = list(available_domains)
    else:
        lookup = {key.lower(): key for key in available_domains}
        selected_domains = []
        for entry in requested_domains:
            resolved = lookup.get(entry.lower())
            if resolved:
                selected_domains.append(resolved)

    if "Tagging" in static_rules and "Tagging" not in selected_domains:
        selected_domains.append("Tagging")

    missing_domains = sorted(
        {entry for entry in requested_domains if entry and entry.lower() not in {d.lower() for d in available_domains}}
    )

    if not selected_domains:
        return {
            "domain": domain or "unknown",
            "domains": [],
            "compliance": 0.0,
            "missing_fields": [],
            "summary": (
                "Requested domains could not be resolved. "
                f"Missing: {', '.join(missing_domains) if missing_domains else 'None'}"
            ),
            "details": [],
            "missing_domains": missing_domains,
            "relationship_gaps": [],
            "checks_executed": 0,
        }

    dynamic_rules: Dict[str, Dict[str, Any]] = {}
    if use_ai:
        try:
            dynamic_rules = _generate_dynamic_rules(selected_domains)
        except Exception as e:
            print(f"[WARN] Dynamic rule generation failed, skipping: {e}", file=sys.stderr)
            dynamic_rules = {}

    dynamic_by_domain: Dict[str, List[Dict[str, Any]]] = {}
    for key, rule in dynamic_rules.items():
        # Skip non-dict rules from dynamic generation
        if not isinstance(rule, dict):
            print(f"[WARN] Skipping non-dict rule in dynamic_rules: type={type(rule).__name__}, value={rule!r}", file=sys.stderr)
            continue
        domain_name = str(rule.get("domain") or key.split(":", 1)[0])
        dynamic_by_domain.setdefault(domain_name, []).append(rule)

    evaluations: List[Dict[str, Any]] = []
    overall_passed = 0
    overall_total = 0

    for domain_key in selected_domains:
        domain_rules: List[Dict[str, Any]] = []

        if domain_key in dynamic_by_domain:
            # Only add dict items from dynamic_by_domain
            for entry in dynamic_by_domain[domain_key]:
                if isinstance(entry, dict):
                    domain_rules.append(entry)
                else:
                    print(f"[WARN] Skipping non-dict entry in dynamic_by_domain[{domain_key}]: type={type(entry).__name__}, value={entry!r}", file=sys.stderr)
        elif domain_key in static_rules:
            for entry in static_rules[domain_key]:
                if isinstance(entry, dict):
                    rule_copy = dict(entry)
                    rule_copy.setdefault("domain", domain_key)
                    domain_rules.append(rule_copy)
                else:
                    print(f"[WARN] Skipping non-dict entry in static_rules[{domain_key}]: type={type(entry).__name__}, value={entry!r}", file=sys.stderr)

        if not domain_rules:
            if domain_key not in missing_domains:
                missing_domains.append(domain_key)
            continue

        for rule in domain_rules:
            evaluation = await _evaluate_csdm_domain(
                client,
                domain_key,
                rule,
                check_relations=True,
            )
            evaluations.append(evaluation)
            overall_passed += evaluation.get("passed", 0)
            overall_total += evaluation.get("total", 0)

    if not evaluations:
        summary = (
            "Requested domains were not found in the rules file."
            if missing_domains
            else "No domains could be evaluated with the current rules."
        )
        return {
            "domain": domain or "unknown",
            "domains": [],
            "compliance": 0.0,
            "missing_fields": [],
            "summary": summary,
            "details": [],
            "missing_domains": sorted(missing_domains),
            "relationship_gaps": [],
            "checks_executed": 0,
        }

    overall_score = _format_percentage(overall_passed, overall_total)

    missing_field_messages: List[str] = []
    relationship_messages: List[str] = []

    gap_counts: Dict[str, int] = {}
    record_gap_scores: Dict[str, Tuple[int, str]] = {}
    issues_per_table: List[Dict[str, Any]] = []

    summary_chunks: List[str] = [
        f"Overall compliance: {overall_score:.1f}% across {len(evaluations)} rule checks."
    ]

    for evaluation in evaluations:
        summary_chunks.append(
            f"{evaluation['display_name']}: {evaluation['compliance']:.1f}% compliance across "
            f"{evaluation['records']} records."
        )
        if evaluation["error"]:
            summary_chunks.append(f"{evaluation['display_name']} error: {evaluation['error']}")

        for gap in evaluation["missing_fields"]:
            record = gap.get("record", "Record")
            fields_value = gap.get("fields", [])
            if isinstance(fields_value, list):
                field_list = [str(item) for item in fields_value]
            else:
                field_list = [str(fields_value)]
            unique_fields = sorted(set(field_list))
            field_text = ", ".join(unique_fields) or "unspecified field"
            # Show ALL missing field messages, no artificial limit
            missing_field_messages.append(
                f"{evaluation['display_name']}: {record} missing {len(unique_fields)} field(s): {field_text}"
            )

        for gap in evaluation["missing_fields"]:
            record_name = str(gap.get("record", "Record"))
            fields_value = gap.get("fields", [])
            if isinstance(fields_value, list):
                for field in fields_value:
                    gap_counts[field] = gap_counts.get(field, 0) + 1
            else:
                gap_counts[str(fields_value)] = gap_counts.get(str(fields_value), 0) + 1

            score = len(fields_value) if isinstance(fields_value, list) else 1
            current = record_gap_scores.get(record_name)
            if current is None or score > current[0]:
                record_gap_scores[record_name] = (score, evaluation["display_name"])

        for gap in evaluation["relationship_gaps"]:
            description = gap.get("description")
            detail = (
                f"{evaluation['display_name']}: {gap.get('record', 'Record')} lacks relationship "
                f"{gap.get('relationship', 'relationship')} (expected {gap.get('expected')}, "
                f"found {gap.get('found')})"
            )
            if description:
                detail += f" – {description}"
            # Show ALL relationship gaps, no artificial limit
            relationship_messages.append(detail)

        issues_per_table.append(
            {
                "domain": evaluation["domain"],
                "display_name": evaluation["display_name"],
                "passed": evaluation["passed"],
                "total": evaluation["total"],
                "records": evaluation["records"],
                "compliance": evaluation["compliance"],
            }
        )

    summary = " ".join(summary_chunks).strip()

    normalized_domain = (
        selected_domains[0] if len(selected_domains) == 1 else ("all" if not requested_domains else domain or "multiple")
    )

    # Recompute overall pass/total from issue aggregates to guard against missing totals.
    if issues_per_table:
        overall_passed = sum(int(issue.get("passed", 0) or 0) for issue in issues_per_table)
        overall_total = sum(int(issue.get("total", 0) or 0) for issue in issues_per_table)
        overall_score = _format_percentage(overall_passed, overall_total)
    else:
        overall_score = _format_percentage(overall_passed, overall_total)

    # Show ALL records with gaps, not just top 10
    top_records = [
        {"record": name, "missing_fields": count, "domain": domain_label}
        for name, (count, domain_label) in sorted(
            record_gap_scores.items(), key=lambda item: item[1][0], reverse=True
        )
    ]

    return {
        "domain": normalized_domain,
        "domains": selected_domains,
        "compliance": overall_score,
        "missing_fields": missing_field_messages,
        "relationship_gaps": relationship_messages,
        "summary": summary,
        "details": evaluations,
        "missing_domains": sorted(set(missing_domains)),
        "checks_executed": overall_total,
        "gap_counts": dict(sorted(gap_counts.items(), key=lambda item: item[1], reverse=True)),
        "top_records": top_records,
        "issues_per_table": issues_per_table,
    }
