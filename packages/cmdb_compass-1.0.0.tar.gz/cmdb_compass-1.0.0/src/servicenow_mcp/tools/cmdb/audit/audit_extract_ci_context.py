"""
Extract CI Context Tool

Builds comprehensive CI profiles for AI agent understanding. Returns rich context
including relationships, incidents, discovery info, and CSDM compliance metrics.
"""

import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import extract_display_value


async def extract_ci_context(
    sn_client: ServiceNowClient,
    ci_sysid: str,
    include_relationships: bool = True,
    include_incidents: bool = True,
    include_discovery: bool = True,
) -> Dict[str, Any]:
    """
    Extract comprehensive CI context for AI agent understanding.

    Args:
        sn_client: ServiceNow client instance
        ci_sysid: The sys_id of the CI
        include_relationships: Include CI relationships (default: True)
        include_incidents: Include recent incidents (default: True)
        include_discovery: Include discovery information (default: True)

    Returns:
        Dict with complete CI context including profile, relationships,
        incidents, discovery, tags, risk indicators, and suggested actions
    """

    try:
        # ===== 1. Query CI by sysid =====
        # Note: cmdb_ci table does NOT have "owner" field OOB
        # Use "assigned_to" for operational/support responsibility
        # Extended CI classes may have "Owned by" but not cmdb_ci base table
        ci_records = await sn_client.query_table(
            table="cmdb_ci",
            query=f"sys_id={ci_sysid}",
            limit=1,
            fields="sys_id,name,class,status,assigned_to,location,environment,criticality,last_discovered,sys_created_on,sys_updated_on,discovery_source",
        )

        if not ci_records:
            return {
                "status": "error",
                "message": f"CI not found with sys_id: {ci_sysid}",
            }

        ci = ci_records[0]

        # ===== 2. Extract core CI data =====
        context = {
            "status": "success",
            "ci": {
                "sysid": ci.get("sys_id", ""),
                "name": ci.get("name", ""),
                "class": ci.get("class", {}).get("value", "") if isinstance(ci.get("class"), dict) else ci.get("class", ""),
                "status": ci.get("status", ""),
                "assigned_to": extract_display_value(ci.get("assigned_to")),
                "location": extract_display_value(ci.get("location")),
                "environment": ci.get("environment", ""),
                "criticality": ci.get("criticality", ""),
                "last_discovered": ci.get("last_discovered", None),
                "created": ci.get("sys_created_on", ""),
                "updated": ci.get("sys_updated_on", ""),
            },
            "relationships": [],
            "recent_incidents": [],
            "discovery_info": {},
            "tags": [],
            "risk_indicators": {},
            "suggested_actions": [],
            "data_quality_score": 0,
            "csdm_compliance": {},
        }

        ci_class = context["ci"]["class"]

        # ===== 3. Query relationships if requested =====
        if include_relationships:
            context["relationships"] = await _get_ci_relationships(
                sn_client, ci_sysid
            )

        # ===== 4. Query recent incidents if requested =====
        if include_incidents:
            context["recent_incidents"] = await _get_recent_incidents(
                sn_client, ci_sysid
            )

        # ===== 5. Extract discovery info if requested =====
        if include_discovery:
            context["discovery_info"] = _extract_discovery_info(ci)

        # ===== 6. Calculate risk indicators =====
        context["risk_indicators"] = _calculate_risk_indicators(
            ci, context["recent_incidents"], context["relationships"]
        )

        # ===== 7. Get CSDM compliance info =====
        context["csdm_compliance"] = await _get_csdm_compliance(
            sn_client, ci_class, ci
        )

        # ===== 8. Generate suggested actions =====
        context["suggested_actions"] = _generate_suggested_actions(
            ci, context["risk_indicators"], context["recent_incidents"]
        )

        # ===== 9. Calculate data quality score =====
        context["data_quality_score"] = _calculate_data_quality_score(
            ci, context["csdm_compliance"], context["risk_indicators"]
        )

        return context

    except Exception as e:
        return {
            "status": "error",
            "message": f"Error extracting CI context: {str(e)}",
        }


async def _get_ci_relationships(
    sn_client: ServiceNowClient, ci_sysid: str
) -> List[Dict[str, Any]]:
    """Query all active relationships for a CI."""
    try:
        # Get relationships where this CI is either parent or child
        # Exclude relationships to retired CIs
        relationships = []

        # Parent relationships (where this CI is the source/parent)
        parent_rels = await sn_client.query_table(
            table="cmdb_rel_ci",
            query=f"parent={ci_sysid}^childNOT INretired,retired",
            limit=50,
            fields="sys_id,type,parent,child",
        )

        # Child relationships (where this CI is the target/child)
        child_rels = await sn_client.query_table(
            table="cmdb_rel_ci",
            query=f"child={ci_sysid}^parentNOT INretired,retired",
            limit=50,
            fields="sys_id,type,parent,child",
        )

        # Process parent relationships
        for rel in parent_rels:
            child_info = rel.get("child", {})
            if isinstance(child_info, dict):
                child_sysid = child_info.get("value", "")
                child_name = child_info.get("display_value", "")
            else:
                child_sysid = child_info
                child_name = "Unknown"

            relationships.append(
                {
                    "type": rel.get("type", {}).get("display_value", "Unknown") if isinstance(rel.get("type"), dict) else rel.get("type", "Unknown"),
                    "direction": "parent",
                    "target_ci_sysid": child_sysid,
                    "target_ci_name": child_name,
                    "target_ci_class": "",  # Will be empty unless we query more
                }
            )

        # Process child relationships
        for rel in child_rels:
            parent_info = rel.get("parent", {})
            if isinstance(parent_info, dict):
                parent_sysid = parent_info.get("value", "")
                parent_name = parent_info.get("display_value", "")
            else:
                parent_sysid = parent_info
                parent_name = "Unknown"

            relationships.append(
                {
                    "type": rel.get("type", {}).get("display_value", "Unknown") if isinstance(rel.get("type"), dict) else rel.get("type", "Unknown"),
                    "direction": "child",
                    "target_ci_sysid": parent_sysid,
                    "target_ci_name": parent_name,
                    "target_ci_class": "",
                }
            )

        return relationships

    except Exception as e:
        print(f"Warning: Failed to get relationships: {e}")
        return []


async def _get_recent_incidents(
    sn_client: ServiceNowClient, ci_sysid: str
) -> List[Dict[str, Any]]:
    """Query recent incidents for a CI (top 10 by priority, last 90 days)."""
    try:
        # Calculate date 90 days ago
        ninety_days_ago = (datetime.utcnow() - timedelta(days=90)).isoformat()

        incidents = await sn_client.query_table(
            table="incident",
            query=f"configuration_item={ci_sysid}^sys_created_on>={ninety_days_ago}",
            limit=10,
            fields="number,short_description,state,priority,opened_at,closed_at",
        )

        result = []
        for inc in incidents:
            result.append(
                {
                    "number": inc.get("number", ""),
                    "short_description": inc.get("short_description", ""),
                    "state": inc.get("state", ""),
                    "priority": inc.get("priority", ""),
                    "opened_date": inc.get("opened_at", ""),
                    "closed_date": inc.get("closed_at", None),
                }
            )

        return result

    except Exception as e:
        print(f"Warning: Failed to get incidents: {e}")
        return []


def _extract_discovery_info(ci: Dict[str, Any]) -> Dict[str, Any]:
    """Extract discovery information from CI record."""
    return {
        "discovery_source": ci.get("discovery_source", {}).get("display_value", "") if isinstance(ci.get("discovery_source"), dict) else ci.get("discovery_source", ""),
        "last_discovered": ci.get("last_discovered", None),
        "discovery_method": ci.get("discovery_method", ""),
        "discovery_confidence": ci.get("discovery_confidence", None),
    }


def _calculate_risk_indicators(
    ci: Dict[str, Any],
    incidents: List[Dict[str, Any]],
    relationships: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Calculate simple boolean risk indicators."""
    last_discovered = ci.get("last_discovered")
    staleness_days = 999  # Default to very stale

    if last_discovered:
        try:
            discovered_date = datetime.fromisoformat(last_discovered.replace("Z", "+00:00"))
            staleness_days = (datetime.utcnow() - discovered_date.replace(tzinfo=None)).days
        except (ValueError, AttributeError):
            pass

    # cmdb_ci table uses "assigned_to" for operational responsibility
    # (not "owner" - that doesn't exist on base table)
    assigned_to = ci.get("assigned_to")
    has_owner = assigned_to and (not isinstance(assigned_to, dict) or assigned_to.get("value"))

    has_no_owner = not has_owner

    # Count active incidents (state not in resolved/closed states)
    # ServiceNow incident states: 1=New, 2=In Progress, 3=On Hold, 6=Resolved, 7=Closed
    active_incidents = [i for i in incidents if i.get("state") not in ["6", "7", "resolved", "closed"]]

    return {
        "staleness_days": staleness_days,
        "is_stale": staleness_days > 180,
        "missing_critical_fields": _identify_missing_fields(ci),
        "active_incident_count": len(active_incidents),
        "has_no_relationships": len(relationships) == 0,
        "has_no_owner": has_no_owner,
    }


def _identify_missing_fields(ci: Dict[str, Any]) -> List[str]:
    """Identify critical missing fields.

    Note: cmdb_ci uses "assigned_to" (not "owner") for operational responsibility.
    """
    missing = []
    # cmdb_ci table has "assigned_to", not "owner"
    critical_fields = ["assigned_to", "environment", "criticality"]

    for field in critical_fields:
        value = ci.get(field)

        # For all fields, check directly
        if not value or (isinstance(value, dict) and not value.get("value")):
            # Report as "owner" in output for backward compatibility with summaries
            missing.append("owner" if field == "assigned_to" else field)

    return missing


async def _get_csdm_compliance(
    sn_client: ServiceNowClient,
    ci_class: str,
    ci: Dict[str, Any],
) -> Dict[str, Any]:
    """Get CSDM compliance information for the CI class."""
    try:
        csdm_rules = get_csdm_rules()

        # Auto-detect CSDM domain from CI class using ci_class_map
        domain = csdm_rules.ci_class_map.get(ci_class, "Unknown")

        # Get requirements for this CI class
        requirements = csdm_rules.get_ci_class_requirements(ci_class)

        if not requirements:
            return {
                "domain": domain,
                "completeness_percent": 0,
                "missing_required_fields": [],
            }

        # Get required fields using CSDM rules loader
        required_fields = csdm_rules.get_required_fields(ci_class)
        missing_required = []

        for field_name in required_fields:
            value = ci.get(field_name)
            if not value or (isinstance(value, dict) and not value.get("value")):
                missing_required.append(field_name)

        # Calculate completeness
        total_required = len(required_fields)
        completeness = (
            max(0, total_required - len(missing_required)) / total_required * 100
            if total_required > 0
            else 100
        )

        return {
            "domain": domain,
            "completeness_percent": round(completeness, 2),
            "missing_required_fields": missing_required,
        }

    except Exception as e:
        print(f"Warning: Failed to get CSDM compliance: {e}")
        return {
            "domain": "Unknown",
            "completeness_percent": 0,
            "missing_required_fields": [],
        }


def _generate_suggested_actions(
    ci: Dict[str, Any],
    risk_indicators: Dict[str, Any],
    incidents: List[Dict[str, Any]],
) -> List[str]:
    """Generate AI-friendly suggested actions based on risk indicators."""
    actions = []

    if risk_indicators.get("has_no_owner"):
        actions.append("Assign owner (currently missing)")

    if "environment" in risk_indicators.get("missing_critical_fields", []):
        actions.append("Set environment (prod/staging/dev/test)")

    if "criticality" in risk_indicators.get("missing_critical_fields", []):
        actions.append("Set criticality level (1-5)")

    if risk_indicators.get("has_no_relationships"):
        ci_class = ci.get("class", "")
        if ci_class and ci_class != "cmdb_ci":
            actions.append("Verify relationships (seems to be isolated)")

    if risk_indicators.get("is_stale"):
        actions.append("Schedule retirement (CI inactive >180 days)")

    if risk_indicators.get("active_incident_count", 0) > 0:
        actions.append(f"Resolve {risk_indicators.get('active_incident_count')} active incident(s)")

    if not actions:
        actions.append("CI data appears complete and healthy")

    return actions


def _calculate_data_quality_score(
    ci: Dict[str, Any],
    csdm_compliance: Dict[str, Any],
    risk_indicators: Dict[str, Any],
) -> int:
    """
    Calculate overall data quality score (0-100).

    Based on:
    - CSDM completeness (only if CI class is mapped to CSDM domain)
    - Missing critical fields: -5 points each (owner, environment, criticality)
    - Staleness (>180 days): -20 points
    - No relationships: -10 points
    """
    score = 100

    # Only penalize CSDM incompleteness if CI class is actually mapped to CSDM
    # If domain is "Unknown", the CI class isn't in CSDM rules - skip this penalty
    domain = csdm_compliance.get("domain", "Unknown")
    if domain != "Unknown":
        csdm_completeness = csdm_compliance.get("completeness_percent", 100)
        score -= (100 - csdm_completeness) * 0.5

    # Deduct for missing critical fields: -5 points each
    missing_count = len(risk_indicators.get("missing_critical_fields", []))
    score -= missing_count * 5

    # Deduct for staleness (>180 days): -20 points
    if risk_indicators.get("is_stale"):
        score -= 20

    # Deduct for no relationships: -10 points
    if risk_indicators.get("has_no_relationships"):
        score -= 10

    return max(0, min(100, int(score)))
