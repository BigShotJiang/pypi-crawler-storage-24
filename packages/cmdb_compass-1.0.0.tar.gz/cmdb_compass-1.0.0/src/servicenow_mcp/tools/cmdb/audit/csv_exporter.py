"""
CSV Exporter for SIEM Integration

Exports audit results in CSV format for ingestion into SIEM systems like:
- Splunk (Security Information and Event Management)
- ELK Stack (Elasticsearch, Logstash, Kibana)
- QRadar (IBM Security)
- Sentinel (Microsoft Azure)
- ArcSight (OpenText)

Features:
- Flattened CSV format for easy SIEM parsing
- Compliance-ready field naming
- UTF-8 encoding with BOM for Excel compatibility
- Configurable field selection
- Time-series export for historical analysis
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
import csv
import os


# ==============================================================================
# CSV Export Functions
# ==============================================================================

def export_to_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool = True,
    append: bool = False,
) -> Dict[str, Any]:
    """
    Export audit result to CSV format for SIEM ingestion.

    Args:
        audit_result: Audit result dictionary from any governance tool
        output_file: Output CSV file path
        include_metadata: If True, includes compliance metadata columns
        append: If True, appends to existing file (default: False, overwrites)

    Returns:
        Export result with row count and file path
    """
    # Extract tool name to determine export format
    metadata = audit_result.get("audit_metadata", {})
    compliance = metadata.get("compliance", {})
    tool_name = compliance.get("tool_name", "unknown_tool")

    # Route to appropriate exporter based on tool
    if "mandatory_fields" in tool_name:
        return _export_mandatory_fields_csv(audit_result, output_file, include_metadata, append)
    elif "duplicate_merge" in tool_name:
        return _export_duplicate_merge_csv(audit_result, output_file, include_metadata, append)
    elif "policy_violation" in tool_name:
        return _export_policy_violations_csv(audit_result, output_file, include_metadata, append)
    elif "retention_flags" in tool_name:
        return _export_retention_flags_csv(audit_result, output_file, include_metadata, append)
    elif "confidentiality_tags" in tool_name:
        return _export_confidentiality_csv(audit_result, output_file, include_metadata, append)
    else:
        return _export_generic_csv(audit_result, output_file, include_metadata, append)


def _export_mandatory_fields_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export Tool #1 (mandatory fields compliance) to CSV."""

    rows = []
    metadata = audit_result.get("audit_metadata", {})

    # Extract critical missing CIs
    for ci in audit_result.get("critical_missing_cis", []):
        row = {
            "timestamp": metadata.get("timestamp", ""),
            "tool": "mandatory_fields_compliance",
            "ci_sys_id": ci.get("ci_sys_id", ""),
            "ci_name": ci.get("ci_name", ""),
            "ci_class": ci.get("ci_class", ""),
            "severity": ci.get("severity", ""),
            "missing_field_count": ci.get("missing_field_count", 0),
            "missing_fields": ",".join(ci.get("missing_fields", [])),
            "compliance_score": audit_result.get("overall_compliance_score", 0),
            "grade": audit_result.get("grade", ""),
        }

        if include_metadata:
            row.update(_extract_compliance_metadata(metadata))

        rows.append(row)

    return _write_csv(output_file, rows, append)


def _export_duplicate_merge_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export Tool #2 (duplicate merge confidence) to CSV."""

    metadata = audit_result.get("audit_metadata", {})

    row = {
        "timestamp": metadata.get("timestamp", ""),
        "tool": "duplicate_merge_confidence",
        "ci1_sys_id": audit_result.get("ci1", {}).get("sys_id", ""),
        "ci1_name": audit_result.get("ci1", {}).get("name", ""),
        "ci2_sys_id": audit_result.get("ci2", {}).get("sys_id", ""),
        "ci2_name": audit_result.get("ci2", {}).get("name", ""),
        "confidence_score": audit_result.get("confidence_score", 0),
        "confidence_grade": audit_result.get("confidence_grade", ""),
        "recommendation": audit_result.get("recommendation", ""),
        "risk_factor_count": len(audit_result.get("risk_factors", [])),
        "critical_risks": sum(1 for r in audit_result.get("risk_factors", []) if r.get("severity") == "critical"),
    }

    if include_metadata:
        row.update(_extract_compliance_metadata(metadata))

    return _write_csv(output_file, [row], append)


def _export_policy_violations_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export Tool #3 (policy violations) to CSV."""

    rows = []
    metadata = audit_result.get("audit_metadata", {})

    # Export top violations
    for violation in audit_result.get("top_violations", []):
        row = {
            "timestamp": metadata.get("timestamp", ""),
            "tool": "policy_violation_score",
            "ci_sys_id": violation.get("ci_sys_id", ""),
            "ci_name": violation.get("ci_name", ""),
            "violation_type": violation.get("type", ""),
            "severity": violation.get("severity", ""),
            "field": violation.get("field", ""),
            "description": violation.get("description", ""),
            "impact": violation.get("impact", ""),
            "policy_score": audit_result.get("policy_violation_score", 0),
            "grade": audit_result.get("grade", ""),
        }

        if include_metadata:
            row.update(_extract_compliance_metadata(metadata))

        rows.append(row)

    return _write_csv(output_file, rows, append)


def _export_retention_flags_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export Tool #4 (retention flags) to CSV."""

    rows = []
    metadata = audit_result.get("audit_metadata", {})

    # Export deletion candidates
    for candidate in audit_result.get("deletion_candidates", []):
        row = {
            "timestamp": metadata.get("timestamp", ""),
            "tool": "retention_flags",
            "ci_sys_id": candidate.get("ci_sys_id", ""),
            "ci_name": candidate.get("ci_name", ""),
            "install_status": candidate.get("install_status", ""),
            "business_criticality": candidate.get("business_criticality", ""),
            "retention_period": candidate.get("retention_period", ""),
            "compliance_framework": candidate.get("compliance_framework", ""),
            "reason": candidate.get("reason", ""),
            "retirement_age_days": candidate.get("retirement_age_days", 0),
            "days_past_retention": candidate.get("days_past_retention", 0),
            "retention_score": audit_result.get("retention_compliance_score", 0),
            "grade": audit_result.get("grade", ""),
        }

        if include_metadata:
            row.update(_extract_compliance_metadata(metadata))

        rows.append(row)

    return _write_csv(output_file, rows, append)


def _export_confidentiality_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export Tool #5 (confidentiality tags) to CSV."""

    rows = []
    metadata = audit_result.get("audit_metadata", {})

    # Export top issues
    for issue in audit_result.get("top_issues", []):
        row = {
            "timestamp": metadata.get("timestamp", ""),
            "tool": "confidentiality_tags",
            "ci_sys_id": issue.get("ci_sys_id", ""),
            "ci_name": issue.get("ci_name", ""),
            "issue_type": issue.get("issue_type", ""),
            "severity": issue.get("severity", ""),
            "detected_classification": issue.get("detected_classification", ""),
            "assigned_classification": issue.get("assigned_classification", ""),
            "confidence": issue.get("confidence", 0),
            "description": issue.get("description", ""),
            "confidentiality_score": audit_result.get("confidentiality_score", 0),
            "grade": audit_result.get("grade", ""),
            "gdpr_compliant": audit_result.get("gdpr_compliance", {}).get("gdpr_compliant", False),
            "dora_compliant": audit_result.get("dora_compliance", {}).get("dora_compliant", False),
        }

        if include_metadata:
            row.update(_extract_compliance_metadata(metadata))

        rows.append(row)

    return _write_csv(output_file, rows, append)


def _export_generic_csv(
    audit_result: Dict[str, Any],
    output_file: str,
    include_metadata: bool,
    append: bool,
) -> Dict[str, Any]:
    """Export generic audit result to CSV (fallback)."""

    metadata = audit_result.get("audit_metadata", {})

    row = {
        "timestamp": metadata.get("timestamp", ""),
        "tool": metadata.get("compliance", {}).get("tool_name", "unknown"),
        "status": audit_result.get("status", ""),
        "total_records": metadata.get("total_records", 0),
        "audit_level": metadata.get("audit_level", ""),
    }

    if include_metadata:
        row.update(_extract_compliance_metadata(metadata))

    return _write_csv(output_file, [row], append)


def _extract_compliance_metadata(metadata: Dict[str, Any]) -> Dict[str, str]:
    """Extract compliance metadata for CSV columns."""

    compliance = metadata.get("compliance", {})
    frameworks = compliance.get("compliance_frameworks", [])

    return {
        "compliance_frameworks": ",".join([f.get("code", "") for f in frameworks]),
        "executed_by": compliance.get("audit_trail", {}).get("executed_by", ""),
        "execution_environment": compliance.get("audit_trail", {}).get("environment", ""),
    }


def _write_csv(
    output_file: str,
    rows: List[Dict[str, Any]],
    append: bool,
) -> Dict[str, Any]:
    """Write rows to CSV file."""

    if not rows:
        return {
            "status": "success",
            "rows_exported": 0,
            "output_file": output_file,
            "message": "No rows to export"
        }

    try:
        # Determine write mode
        mode = "a" if append and os.path.exists(output_file) else "w"
        file_exists = os.path.exists(output_file) and append

        # Create directory if needed
        output_dir = os.path.dirname(output_file)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        # Write CSV with UTF-8 BOM for Excel compatibility
        with open(output_file, mode, newline='', encoding='utf-8-sig') as csvfile:
            fieldnames = list(rows[0].keys())
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            # Write header only if new file or not appending
            if not file_exists:
                writer.writeheader()

            writer.writerows(rows)

        return {
            "status": "success",
            "rows_exported": len(rows),
            "output_file": output_file,
            "mode": "append" if append else "overwrite",
            "file_size_bytes": os.path.getsize(output_file),
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "output_file": output_file,
        }


def export_bulk_to_csv(
    audit_results: List[Dict[str, Any]],
    output_directory: str,
    include_metadata: bool = True,
    group_by_tool: bool = True,
) -> Dict[str, Any]:
    """
    Export multiple audit results to CSV files.

    Args:
        audit_results: List of audit result dictionaries
        output_directory: Output directory for CSV files
        include_metadata: If True, includes compliance metadata columns
        group_by_tool: If True, creates separate CSV per tool (default: True)

    Returns:
        Bulk export result with file counts
    """
    os.makedirs(output_directory, exist_ok=True)

    if group_by_tool:
        # Group results by tool
        tool_groups = {}
        for result in audit_results:
            metadata = result.get("audit_metadata", {})
            tool_name = metadata.get("compliance", {}).get("tool_name", "unknown")

            if tool_name not in tool_groups:
                tool_groups[tool_name] = []
            tool_groups[tool_name].append(result)

        # Export each group
        export_results = {}
        for tool_name, results in tool_groups.items():
            output_file = os.path.join(output_directory, f"{tool_name}_{datetime.utcnow().strftime('%Y%m%d')}.csv")

            for i, result in enumerate(results):
                export_result = export_to_csv(
                    result,
                    output_file,
                    include_metadata,
                    append=(i > 0)  # Append after first result
                )
                export_results[tool_name] = export_result

        return {
            "status": "success",
            "total_results": len(audit_results),
            "files_created": len(export_results),
            "export_results": export_results,
            "output_directory": output_directory,
        }

    else:
        # Single CSV with all results
        output_file = os.path.join(output_directory, f"audit_results_{datetime.utcnow().strftime('%Y%m%d')}.csv")

        for i, result in enumerate(audit_results):
            export_to_csv(result, output_file, include_metadata, append=(i > 0))

        return {
            "status": "success",
            "total_results": len(audit_results),
            "files_created": 1,
            "output_file": output_file,
            "output_directory": output_directory,
        }
