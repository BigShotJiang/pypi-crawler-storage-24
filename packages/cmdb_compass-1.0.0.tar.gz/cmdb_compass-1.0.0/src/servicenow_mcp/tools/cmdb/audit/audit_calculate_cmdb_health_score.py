"""Calculate CMDB Health Score Tool

Provides comprehensive CMDB health scoring across multiple dimensions:
- Data Completeness: Critical fields populated
- Relationship Integrity: Valid relationships present
- Staleness: Recent activity/discovery
- Duplicate Quality: Unique identifiers

QUERY tool with no modification capability.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import (
    AuditLevel,
    build_audit_metadata,
    cache_audit_baseline,
    get_cached_baseline,
)


async def calculate_cmdb_health_score(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    include_breakdown: bool = True,
    critical_fields: Optional[List[str]] = None,
    sample_size: int = 1000,
    audit_level: AuditLevel = "standard",
    _disable_cache: bool = False,
) -> Dict[str, Any]:
    """
    Calculate comprehensive CMDB health score for a CI class.

    Analyzes data quality across four dimensions:
    1. Completeness: Critical fields populated (0-100)
    2. Relationships: Valid relationships present (0-100)
    3. Staleness: Recent activity/discovery (0-100)
    4. Duplicates: Unique identifier quality (0-100)

    Overall score is weighted average: 40% completeness, 25% relationships,
    20% staleness, 15% duplicates.

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., cmdb_ci_server)
        include_breakdown: If True, include detailed dimensional metrics
        critical_fields: Custom list of critical fields (None = use defaults)
        sample_size: Max CIs to analyze for performance (default: 1000)
        audit_level: Analysis depth ('quick', 'standard', 'deep')

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ci_class: CI class analyzed
        - total_cis: Total CIs in class
        - overall_score: Weighted health score (0-100)
        - completeness_score: Data completeness dimension (0-100)
        - relationship_score: Relationship integrity dimension (0-100)
        - staleness_score: Freshness/activity dimension (0-100)
        - duplicate_score: Deduplication quality dimension (0-100)
        - breakdown: Detailed metrics per dimension (if include_breakdown=True)
        - recommendations: Prioritized improvement actions
        - metadata: Phase 3 audit metadata
    """
    cache_key = f"calculate_cmdb_health_score:{ci_class}:{audit_level}"
    if not _disable_cache:
        cached = get_cached_baseline(cache_key)
        if cached is not None:
            return cached

    try:
        start_time = datetime.now()
        # Step 1: Define critical fields for scoring
        if critical_fields is None:
            # Default critical fields by CI class
            critical_fields_map = {
                "cmdb_ci_server": ["name", "serial_number", "ip_address", "operational_status"],
                "cmdb_ci_database": ["name", "version", "install_directory", "operational_status"],
                "cmdb_ci_app_server": ["name", "version", "ip_address", "operational_status"],
                "cmdb_ci_service": ["name", "service_classification", "operational_status"],
            }
            critical_fields = critical_fields_map.get(ci_class, ["name", "operational_status"])

        # Step 2: Fetch CIs for analysis
        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query="active=true",
            sysparm_fields=f"sys_id,{','.join(critical_fields)},sys_updated_on,last_discovered",
            sysparm_limit=sample_size
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "status": "success",
                "ci_class": ci_class,
                "total_cis": 0,
                "overall_score": 0,
                "message": f"No active CIs found for class {ci_class}",
                "metadata": build_audit_metadata(
                    audit_type="cmdb_health_score",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class
                ),
            }

        # Step 3: Calculate Completeness Score (40% weight)
        completeness_metrics = _calculate_completeness_score(cis, critical_fields)
        completeness_score = completeness_metrics["score"]

        # Step 4: Calculate Relationship Score (25% weight)
        relationship_metrics = await _calculate_relationship_score(client, cis, ci_class)
        relationship_score = relationship_metrics["score"]

        # Step 5: Calculate Staleness Score (20% weight)
        staleness_metrics = _calculate_staleness_score(cis)
        staleness_score = staleness_metrics["score"]

        # Step 6: Calculate Duplicate Score (15% weight)
        duplicate_metrics = _calculate_duplicate_score(cis, critical_fields)
        duplicate_score = duplicate_metrics["score"]

        # Step 7: Calculate Overall Weighted Score
        overall_score = (
            completeness_score * 0.40 +
            relationship_score * 0.25 +
            staleness_score * 0.20 +
            duplicate_score * 0.15
        )

        # Step 8: Generate Recommendations
        recommendations = _generate_recommendations(
            completeness_score,
            relationship_score,
            staleness_score,
            duplicate_score,
            completeness_metrics,
            relationship_metrics,
            staleness_metrics,
            duplicate_metrics,
        )

        # Step 9: Prepare Response
        # Calculate execution time
        execution_time = (datetime.now() - start_time).total_seconds()

        result = {
            "status": "success",
            "ci_class": ci_class,
            "total_cis": total_cis,
            "overall_score": round(overall_score, 2),
            "completeness_score": round(completeness_score, 2),
            "relationship_score": round(relationship_score, 2),
            "staleness_score": round(staleness_score, 2),
            "duplicate_score": round(duplicate_score, 2),
            "health_rating": _get_health_rating(overall_score),
            "recommendations": recommendations,
            "message": f"Health score calculated for {ci_class}: {overall_score:.1f}/100 ({_get_health_rating(overall_score)})",
            "metadata": build_audit_metadata(
                audit_type="cmdb_health_score",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            ),
        }

        if include_breakdown:
            result["breakdown"] = {
                "completeness": completeness_metrics,
                "relationships": relationship_metrics,
                "staleness": staleness_metrics,
                "duplicates": duplicate_metrics,
            }

        if not _disable_cache:
            cache_audit_baseline(cache_key, result)
        return result

    except Exception as e:
        print(f"[ERROR] CMDB health score calculation failed: {e}", file=sys.stderr)
        return {
            "status": "error",
            "error": str(e),
        }


def _calculate_completeness_score(cis: List[Dict[str, Any]], critical_fields: List[str]) -> Dict[str, Any]:
    """Calculate data completeness score based on critical field population."""
    if not cis or not critical_fields:
        return {"score": 0, "total_fields": 0, "populated_count": 0}

    total_possible = len(cis) * len(critical_fields)
    total_populated = 0
    field_stats = {}

    for field in critical_fields:
        populated = sum(1 for ci in cis if ci.get(field) and ci.get(field) != "")
        total_populated += populated
        coverage_pct = (populated / len(cis) * 100) if len(cis) > 0 else 0

        field_stats[field] = {
            "populated": populated,
            "total": len(cis),
            "coverage_percentage": round(coverage_pct, 2),
        }

    completeness_pct = (total_populated / total_possible * 100) if total_possible > 0 else 0

    return {
        "score": completeness_pct,
        "total_fields": len(critical_fields),
        "total_possible": total_possible,
        "populated_count": total_populated,
        "field_stats": field_stats,
    }


async def _calculate_relationship_score(
    client: ServiceNowClient,
    cis: List[Dict[str, Any]],
    ci_class: str
) -> Dict[str, Any]:
    """Calculate relationship integrity score."""
    if not cis:
        return {"score": 0, "cis_with_relationships": 0, "total_relationships": 0}

    # Sample up to 100 CIs for relationship checking (performance)
    sample_cis = cis[:100]
    ci_sys_ids = [ci["sys_id"] for ci in sample_cis]

    # Build query for all sampled CIs
    query_parts = [f"parent={sys_id}^ORchild={sys_id}" for sys_id in ci_sys_ids[:10]]  # Limit query size
    query = "^OR".join(query_parts) if query_parts else "sys_idISEMPTY"

    try:
        relationships_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=query + "^active=true",
            sysparm_fields="sys_id,parent,child",
            sysparm_limit=1000,
            sysparm_display_value="false"
        )

        relationships = relationships_response.get("result", [])
        total_relationships = len(relationships)

        # Count CIs with at least one relationship
        cis_with_rels = set()
        for rel in relationships:
            parent = rel.get("parent")
            child = rel.get("child")
            if parent in ci_sys_ids:
                cis_with_rels.add(parent)
            if child in ci_sys_ids:
                cis_with_rels.add(child)

        cis_with_relationships = len(cis_with_rels)
        relationship_pct = (cis_with_relationships / len(sample_cis) * 100) if len(sample_cis) > 0 else 0

        return {
            "score": relationship_pct,
            "cis_with_relationships": cis_with_relationships,
            "cis_sampled": len(sample_cis),
            "total_relationships": total_relationships,
            "average_relationships_per_ci": round(total_relationships / len(sample_cis), 2) if len(sample_cis) > 0 else 0,
        }

    except Exception:
        # If relationship check fails, return neutral score
        return {
            "score": 50,
            "cis_with_relationships": 0,
            "total_relationships": 0,
            "note": "Relationship scoring unavailable",
        }


def _calculate_staleness_score(cis: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate staleness score based on last update/discovery times."""
    if not cis:
        return {"score": 0, "stale_cis": 0, "fresh_cis": 0}

    now = datetime.now(timezone.utc)
    staleness_threshold = timedelta(days=90)  # 90 days = stale
    fresh_threshold = timedelta(days=30)  # 30 days = fresh

    stale_count = 0
    fresh_count = 0
    age_distribution = {"0-30d": 0, "30-60d": 0, "60-90d": 0, "90d+": 0, "unknown": 0}

    for ci in cis:
        # Use last_discovered if available, otherwise sys_updated_on
        last_activity_str = ci.get("last_discovered") or ci.get("sys_updated_on")

        if not last_activity_str:
            age_distribution["unknown"] += 1
            continue

        try:
            # Parse ServiceNow datetime format (handles ISO + SN timestamp)
            sanitized = last_activity_str.replace("Z", "+00:00")
            try:
                last_activity = datetime.fromisoformat(sanitized)
            except ValueError:
                last_activity = datetime.strptime(last_activity_str, "%Y-%m-%d %H:%M:%S")

            if last_activity.tzinfo is None:
                last_activity = last_activity.replace(tzinfo=timezone.utc)

            age = now - last_activity

            if age > staleness_threshold:
                stale_count += 1
                age_distribution["90d+"] += 1
            elif age > timedelta(days=60):
                age_distribution["60-90d"] += 1
            elif age > timedelta(days=30):
                age_distribution["30-60d"] += 1
            else:
                fresh_count += 1
                age_distribution["0-30d"] += 1

        except (ValueError, AttributeError):
            age_distribution["unknown"] += 1

    # Score: 100% if all fresh, 0% if all stale
    # Fresh CIs + partial credit for 30-60d and 60-90d
    # Unknown timestamps are completely ignored (excluded from both scoring and total)
    weighted_score = (
        fresh_count * 1.0 +
        age_distribution["30-60d"] * 0.7 +
        age_distribution["60-90d"] * 0.4 +
        age_distribution["90d+"] * 0.0
    )

    # Calculate max possible score based only on CIs with valid timestamps
    # Unknown timestamps are excluded from denominator to avoid penalizing missing data
    total_valid_cis = len(cis) - age_distribution["unknown"]

    if total_valid_cis == 0:
        # No valid timestamps - return neutral score
        staleness_pct = 50
    else:
        # Normalize score: if all valid CIs are fresh, score = 100
        staleness_pct = (weighted_score / total_valid_cis * 100)

    return {
        "score": staleness_pct,
        "stale_cis": stale_count,
        "fresh_cis": fresh_count,
        "age_distribution": age_distribution,
    }


def _calculate_duplicate_score(cis: List[Dict[str, Any]], critical_fields: List[str]) -> Dict[str, Any]:
    """Calculate duplicate quality score based on unique identifiers."""
    if not cis:
        return {"score": 0, "duplicates_detected": 0}

    # Check for duplicate serial numbers, IP addresses, FQDNs
    identifier_fields = [f for f in ["serial_number", "ip_address", "fqdn", "asset_tag"] if f in critical_fields]

    if not identifier_fields:
        return {"score": 100, "duplicates_detected": 0, "note": "No identifier fields to check"}

    duplicate_count = 0
    field_duplicates = {}

    for field in identifier_fields:
        values_seen = {}
        field_dups = 0

        for ci in cis:
            value = ci.get(field)
            if value and value != "":
                if value in values_seen:
                    field_dups += 1
                    duplicate_count += 1
                else:
                    values_seen[value] = True

        field_duplicates[field] = field_dups

    # Score: 100% if no duplicates, decreases proportionally with duplicate count
    # Proportional penalty: -1 point per 1% duplicate rate (gentle scaling)
    # This prevents over-penalizing datasets with small amounts of duplicates
    duplicate_pct = (duplicate_count / len(cis) * 100) if len(cis) > 0 else 0

    if duplicate_pct < 5.0:
        # Gentle penalty for low duplicate rates (<5%)
        # -2 points per 1% duplicate rate
        duplicate_score = 100 - (duplicate_pct * 2)
    else:
        # Steeper penalty for significant duplication (≥5%)
        # Start from 90 (at 5% threshold) and decrease by 3 points per additional percent
        duplicate_score = max(0, 90 - (duplicate_pct - 5) * 3)

    return {
        "score": duplicate_score,
        "duplicates_detected": duplicate_count,
        "field_duplicates": field_duplicates,
    }


def _generate_recommendations(
    completeness_score: float,
    relationship_score: float,
    staleness_score: float,
    duplicate_score: float,
    completeness_metrics: Dict[str, Any],
    relationship_metrics: Dict[str, Any],
    staleness_metrics: Dict[str, Any],
    duplicate_metrics: Dict[str, Any],
) -> List[str]:
    """Generate prioritized improvement recommendations."""
    recommendations = []

    # Prioritize by score (lowest first)
    scores = [
        (completeness_score, "completeness"),
        (relationship_score, "relationships"),
        (staleness_score, "staleness"),
        (duplicate_score, "duplicates"),
    ]
    scores.sort(key=lambda x: x[0])

    for score, dimension in scores:
        if dimension == "completeness" and score < 80:
            # Find worst fields
            field_stats = completeness_metrics.get("field_stats", {})
            worst_fields = sorted(
                [(f, s["coverage_percentage"]) for f, s in field_stats.items()],
                key=lambda x: x[1]
            )[:3]

            for field, coverage in worst_fields:
                if coverage < 80:
                    recommendations.append(
                        f"⚠️ Field '{field}' only {coverage:.1f}% populated. Enable discovery or data imports to improve."
                    )

        elif dimension == "relationships" and score < 60:
            recommendations.append(
                f"⚠️ Only {relationship_metrics.get('cis_with_relationships', 0)}/{relationship_metrics.get('cis_sampled', 0)} "
                f"CIs have relationships. Run discovery to map dependencies."
            )

        elif dimension == "staleness" and score < 70:
            stale_count = staleness_metrics.get("stale_cis", 0)
            recommendations.append(
                f"⚠️ {stale_count} CIs are stale (90+ days old). Run 'identify_stale_cis' to find retirement candidates."
            )

        elif dimension == "duplicates" and score < 90:
            dup_count = duplicate_metrics.get("duplicates_detected", 0)
            recommendations.append(
                f"⚠️ {dup_count} potential duplicates detected. Review identifier rules and run deduplication."
            )

    if not recommendations:
        overall = (completeness_score + relationship_score + staleness_score + duplicate_score) / 4
        recommendations.append(f"✓ Good CMDB health ({overall:.1f}/100). Continue monitoring and maintain quality standards.")

    return recommendations


def _get_health_rating(score: float) -> str:
    """Convert numeric score to health rating."""
    if score >= 90:
        return "Excellent"
    elif score >= 75:
        return "Good"
    elif score >= 60:
        return "Fair"
    elif score >= 40:
        return "Poor"
    else:
        return "Critical"
