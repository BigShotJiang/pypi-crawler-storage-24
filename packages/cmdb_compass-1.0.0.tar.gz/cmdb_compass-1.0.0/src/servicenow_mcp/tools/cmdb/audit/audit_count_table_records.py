"""Count Table Records Tool

Return the total count of records in a table matching the query.
Audit-level tool for data access (free).
"""

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.data_access import data_access


async def count_table_records(
    client: ServiceNowClient,
    table: str,
    query: str = "",
) -> int:
    """
    Return the total count of records in a table matching the query.

    Args:
        client: ServiceNow client instance
        table: The table name to query
        query: ServiceNow query string (sysparm_query format)

    Returns:
        Integer count of matching records
    """
    return await data_access.count_table_records(
        client=client,
        table=table,
        query=query,
    )
