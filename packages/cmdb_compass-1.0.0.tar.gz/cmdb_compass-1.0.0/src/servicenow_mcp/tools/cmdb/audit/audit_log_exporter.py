"""
Audit Log Exporter

Provides immutable audit trail export functionality for compliance requirements.
Supports SOX Section 802 (7-year audit trail), GDPR Article 30 (processing records),
and DORA Article 23 (incident reporting).

Features:
- Immutable append-only audit logs
- Structured JSON format for SIEM integration
- Compliance metadata included in every log entry
- Tamper-evident logging with checksums
- Time-series export for historical analysis
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
import json
import hashlib
import os


# ==============================================================================
# Audit Log Export Functions
# ==============================================================================

def export_audit_log(
    audit_result: Dict[str, Any],
    log_directory: str = "/tmp/servicenow_audit_logs",
    include_checksum: bool = True,
) -> Dict[str, Any]:
    """
    Export audit result to immutable audit log.

    Creates append-only JSON log files with compliance metadata and tamper detection.
    One log file per tool per day for easy organization and retention management.

    Args:
        audit_result: Audit result dictionary from any governance tool
        log_directory: Directory to store audit logs (default: /tmp/servicenow_audit_logs)
        include_checksum: If True, includes SHA-256 checksum for tamper detection

    Returns:
        Export result with log file path and metadata
    """
    # Create log directory if it doesn't exist
    os.makedirs(log_directory, exist_ok=True)

    # Extract metadata
    metadata = audit_result.get("audit_metadata", {})
    compliance = metadata.get("compliance", {})
    tool_name = compliance.get("tool_name", "unknown_tool")
    timestamp = metadata.get("timestamp", datetime.utcnow().isoformat() + "Z")

    # Generate log filename: toolname_YYYY-MM-DD.jsonl (JSON Lines format)
    date_str = timestamp.split("T")[0]  # Extract date part
    log_filename = f"{tool_name}_{date_str}.jsonl"
    log_filepath = os.path.join(log_directory, log_filename)

    # Build log entry
    log_entry = {
        "log_timestamp": datetime.utcnow().isoformat() + "Z",
        "tool_execution_timestamp": timestamp,
        "tool_name": tool_name,
        "audit_result": audit_result,
    }

    # Add checksum if requested (for tamper detection)
    if include_checksum:
        log_entry["checksum"] = _calculate_checksum(log_entry["audit_result"])

    # Append to log file (immutable append-only)
    try:
        with open(log_filepath, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        return {
            "status": "success",
            "log_file": log_filepath,
            "log_timestamp": log_entry["log_timestamp"],
            "checksum": log_entry.get("checksum"),
            "entry_size_bytes": len(json.dumps(log_entry)),
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "log_file": log_filepath,
        }


def export_audit_logs_bulk(
    audit_results: List[Dict[str, Any]],
    log_directory: str = "/tmp/servicenow_audit_logs",
    include_checksum: bool = True,
) -> Dict[str, Any]:
    """
    Export multiple audit results in bulk.

    Useful for batch exports from multiple tool executions.

    Args:
        audit_results: List of audit result dictionaries
        log_directory: Directory to store audit logs
        include_checksum: If True, includes checksums for tamper detection

    Returns:
        Bulk export result with counts and status
    """
    success_count = 0
    error_count = 0
    errors = []

    for i, result in enumerate(audit_results):
        export_result = export_audit_log(result, log_directory, include_checksum)

        if export_result["status"] == "success":
            success_count += 1
        else:
            error_count += 1
            errors.append({
                "index": i,
                "error": export_result.get("error"),
            })

    return {
        "status": "success" if error_count == 0 else "partial",
        "total_results": len(audit_results),
        "success_count": success_count,
        "error_count": error_count,
        "errors": errors,
        "log_directory": log_directory,
    }


def read_audit_logs(
    tool_name: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    log_directory: str = "/tmp/servicenow_audit_logs",
    verify_checksums: bool = True,
) -> Dict[str, Any]:
    """
    Read audit logs from disk with optional filtering.

    Supports compliance reporting by retrieving historical audit trails.

    Args:
        tool_name: Filter by specific tool (e.g., 'audit_ci_mandatory_fields_compliance')
        start_date: Filter logs >= this date (YYYY-MM-DD format)
        end_date: Filter logs <= this date (YYYY-MM-DD format)
        log_directory: Directory containing audit logs
        verify_checksums: If True, verifies checksums for tamper detection

    Returns:
        List of audit log entries with metadata
    """
    if not os.path.exists(log_directory):
        return {
            "status": "error",
            "error": f"Log directory does not exist: {log_directory}",
            "entries": [],
        }

    # Find matching log files
    log_files = []
    for filename in os.listdir(log_directory):
        if not filename.endswith(".jsonl"):
            continue

        # Filter by tool name
        if tool_name and not filename.startswith(tool_name):
            continue

        # Filter by date range
        if start_date or end_date:
            # Extract date from filename: toolname_YYYY-MM-DD.jsonl
            parts = filename.rsplit("_", 1)
            if len(parts) == 2:
                file_date = parts[1].replace(".jsonl", "")

                if start_date and file_date < start_date:
                    continue
                if end_date and file_date > end_date:
                    continue

        log_files.append(os.path.join(log_directory, filename))

    # Read log entries
    entries = []
    tampered_count = 0

    for log_file in sorted(log_files):
        try:
            with open(log_file, "r") as f:
                for line in f:
                    if not line.strip():
                        continue

                    entry = json.loads(line)

                    # Verify checksum if requested
                    if verify_checksums and "checksum" in entry:
                        calculated_checksum = _calculate_checksum(entry["audit_result"])
                        if calculated_checksum != entry["checksum"]:
                            entry["tampered"] = True
                            tampered_count += 1
                        else:
                            entry["tampered"] = False

                    entries.append(entry)

        except Exception as e:
            # Log read error but continue with other files
            entries.append({
                "error": f"Failed to read {log_file}: {str(e)}",
                "log_file": log_file,
            })

    return {
        "status": "success",
        "total_entries": len(entries),
        "log_files_read": len(log_files),
        "tampered_entries": tampered_count if verify_checksums else None,
        "entries": entries,
        "filters": {
            "tool_name": tool_name,
            "start_date": start_date,
            "end_date": end_date,
        }
    }


def generate_audit_trail_report(
    tool_name: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    log_directory: str = "/tmp/servicenow_audit_logs",
) -> Dict[str, Any]:
    """
    Generate compliance audit trail report.

    Provides summary statistics for SOX/GDPR/DORA auditors.

    Args:
        tool_name: Filter by specific tool
        start_date: Report start date (YYYY-MM-DD)
        end_date: Report end date (YYYY-MM-DD)
        log_directory: Directory containing audit logs

    Returns:
        Audit trail report with statistics and compliance metadata
    """
    logs_result = read_audit_logs(tool_name, start_date, end_date, log_directory)

    if logs_result["status"] != "success":
        return logs_result

    entries = logs_result["entries"]

    # Calculate statistics
    tools_executed = set()
    frameworks_covered = set()
    total_cis_audited = 0
    execution_count = 0

    for entry in entries:
        if "error" in entry:
            continue

        audit_result = entry.get("audit_result", {})
        metadata = audit_result.get("audit_metadata", {})
        compliance = metadata.get("compliance", {})

        # Track tool name
        if compliance.get("tool_name"):
            tools_executed.add(compliance["tool_name"])

        # Track frameworks
        for framework in compliance.get("compliance_frameworks", []):
            frameworks_covered.add(framework.get("code", ""))

        # Track CI counts
        total_cis = audit_result.get("total_cis", 0)
        total_cis_audited += total_cis
        execution_count += 1

    return {
        "status": "success",
        "report_period": {
            "start_date": start_date or "all",
            "end_date": end_date or "all",
        },
        "summary": {
            "total_audit_executions": execution_count,
            "total_log_entries": len(entries),
            "total_cis_audited": total_cis_audited,
            "tools_executed": sorted(list(tools_executed)),
            "compliance_frameworks_covered": sorted(list(frameworks_covered)),
        },
        "log_integrity": {
            "tampered_entries": logs_result.get("tampered_entries", 0),
            "integrity_verified": logs_result.get("tampered_entries") is not None,
        },
        "log_files": {
            "total_files": logs_result["log_files_read"],
            "log_directory": log_directory,
        },
        "generated_at": datetime.utcnow().isoformat() + "Z",
    }


def purge_old_audit_logs(
    retention_days: int,
    log_directory: str = "/tmp/servicenow_audit_logs",
    dry_run: bool = True,
) -> Dict[str, Any]:
    """
    Purge audit logs older than retention period.

    Supports compliance retention policies (SOX 7-year, GDPR 3-year, etc.).

    Args:
        retention_days: Number of days to retain logs (e.g., 2555 for 7 years)
        log_directory: Directory containing audit logs
        dry_run: If True, only simulates deletion (default: True for safety)

    Returns:
        Purge result with deleted file counts
    """
    if not os.path.exists(log_directory):
        return {
            "status": "error",
            "error": f"Log directory does not exist: {log_directory}",
        }

    cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
    cutoff_date_str = cutoff_date.strftime("%Y-%m-%d")

    files_to_delete = []

    for filename in os.listdir(log_directory):
        if not filename.endswith(".jsonl"):
            continue

        # Extract date from filename
        parts = filename.rsplit("_", 1)
        if len(parts) != 2:
            continue

        file_date = parts[1].replace(".jsonl", "")

        if file_date < cutoff_date_str:
            files_to_delete.append(os.path.join(log_directory, filename))

    # Delete files (if not dry run)
    deleted_count = 0
    if not dry_run:
        for filepath in files_to_delete:
            try:
                os.remove(filepath)
                deleted_count += 1
            except Exception as e:
                pass  # Continue with other files

    return {
        "status": "success",
        "retention_days": retention_days,
        "cutoff_date": cutoff_date_str,
        "files_to_delete": len(files_to_delete),
        "files_deleted": deleted_count if not dry_run else 0,
        "dry_run": dry_run,
        "deleted_files": [os.path.basename(f) for f in files_to_delete] if not dry_run else [],
    }


# ==============================================================================
# Helper Functions
# ==============================================================================

def _calculate_checksum(data: Any) -> str:
    """Calculate SHA-256 checksum for tamper detection."""
    json_str = json.dumps(data, sort_keys=True)
    return hashlib.sha256(json_str.encode()).hexdigest()


from datetime import timedelta  # Add this import at the top if not already present
