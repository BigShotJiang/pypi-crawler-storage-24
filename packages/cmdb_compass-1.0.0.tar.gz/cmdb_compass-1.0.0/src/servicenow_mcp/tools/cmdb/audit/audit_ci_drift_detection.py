"""
CI Configuration Drift Detection Tool

Detect configuration drift from baseline or expected state across CMDB CIs.
Identifies unauthorized changes, anomalous modifications, and deviations from standards.

Phase 3 Week 4 - Advanced CMDB Analytics
"""

import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, sample_limit_for_audit_level


# =============================================================================
# Drift Detection Criteria
# =============================================================================

# Critical fields that should rarely change (high drift severity)
CRITICAL_FIELDS = [
    "name",
    "serial_number",
    "asset_tag",
    "model_id",
    "manufacturer",
    "owned_by",
    "company",
]

# Standard fields (medium drift severity)
STANDARD_FIELDS = [
    "location",
    "department",
    "managed_by",
    "support_group",
    "assignment_group",
    "ip_address",
    "dns_domain",
]

# Operational fields (low drift severity - expected to change)
OPERATIONAL_FIELDS = [
    "operational_status",
    "install_status",
    "maintenance_schedule",
    "comments",
]


def _classify_field_severity(field_name: str) -> str:
    """Classify field change severity based on field type."""
    if field_name in CRITICAL_FIELDS:
        return "high"
    elif field_name in STANDARD_FIELDS:
        return "medium"
    elif field_name in OPERATIONAL_FIELDS:
        return "low"
    else:
        return "medium"  # Default to medium for unknown fields


# =============================================================================
# Drift Analysis Functions
# =============================================================================

async def _get_recent_field_changes(
    client: ServiceNowClient,
    ci_sys_id: str,
    lookback_days: int = 30
) -> List[Dict[str, Any]]:
    """
    Get recent field changes from sys_audit table.

    Args:
        client: ServiceNow client
        ci_sys_id: CI sys_id to check
        lookback_days: How far back to look (default: 30 days)

    Returns:
        List of field change records
    """
    try:
        # Calculate lookback date
        lookback_date = datetime.now() - timedelta(days=lookback_days)
        lookback_str = lookback_date.strftime("%Y-%m-%d %H:%M:%S")

        # Query sys_audit for changes
        query = f"documentkey={ci_sys_id}^sys_created_on>={lookback_str}"
        audit_result = await client.get_table_records(
            table="sys_audit",
            sysparm_query=query,
            sysparm_fields="fieldname,oldvalue,newvalue,sys_created_on,sys_created_by,reason",
            sysparm_limit=500,
            sysparm_display_value="false"
        )

        changes = audit_result.get("result", [])
        return changes

    except Exception as e:
        print(f"[WARNING] Failed to get field changes for {ci_sys_id}: {e}", file=sys.stderr)
        return []


def _calculate_drift_score(
    drift_events: List[Dict[str, Any]],
    total_cis: int
) -> float:
    """
    Calculate configuration drift score (0-100).

    Lower score = more drift (worse)
    Higher score = less drift (better)

    Args:
        drift_events: List of detected drift events
        total_cis: Total CIs analyzed

    Returns:
        Drift score (0-100)
    """
    if total_cis == 0:
        return 100.0

    # Base score
    score = 100.0

    # Penalize based on drift event count and severity
    high_severity_count = len([e for e in drift_events if e.get("severity") == "high"])
    medium_severity_count = len([e for e in drift_events if e.get("severity") == "medium"])
    low_severity_count = len([e for e in drift_events if e.get("severity") == "low"])

    # Penalties
    score -= min(high_severity_count * 5, 50)  # Max 50 point penalty for high severity
    score -= min(medium_severity_count * 2, 30)  # Max 30 point penalty for medium severity
    score -= min(low_severity_count * 1, 20)  # Max 20 point penalty for low severity

    return max(0.0, score)


# =============================================================================
# Main Audit Function
# =============================================================================

async def audit_ci_drift_detection(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    ci_sys_ids: Optional[List[str]] = None,
    lookback_days: int = 30,
    audit_level: AuditLevel = "standard",
    detect_unauthorized_changes: bool = True,
    check_csdm_compliance: bool = True,
) -> Dict[str, Any]:
    """
    Detect configuration drift in CMDB CIs.

    Analyzes:
    - Field value changes over time
    - Unauthorized modifications
    - Drift from CSDM standards
    - Anomalous change patterns
    - Configuration drift score

    Args:
        client: ServiceNow client instance
        ci_class: Optional CI class filter (e.g., "cmdb_ci_server")
        ci_sys_ids: Optional list of specific CI sys_ids to check
        lookback_days: Days to look back for changes (default: 30)
        audit_level: "quick", "standard", or "deep"
        detect_unauthorized_changes: Check for changes by unauthorized users (default: True)
        check_csdm_compliance: Validate drift against CSDM rules (default: True)

    Returns:
        {
            "drift_events": [...],
            "drift_by_ci": {...},
            "drift_by_field": {...},
            "unauthorized_changes": [...],
            "csdm_violations": [...],
            "drift_score": 0-100,
            "recommendations": [...],
            "summary": "...",
            "metadata": {...}
        }

    Example:
        >>> result = await audit_ci_drift_detection(
        ...     client,
        ...     ci_class="cmdb_ci_server",
        ...     lookback_days=30,
        ...     audit_level="standard"
        ... )
        >>> print(f"Drift score: {result['drift_score']}")
        >>> print(f"Drift events: {len(result['drift_events'])}")
    """
    start_time = datetime.now()

    print(f"[INFO] Detecting configuration drift (class: {ci_class or 'specified CIs'}, lookback: {lookback_days} days)", file=sys.stderr)

    # Determine CIs to analyze
    cis_to_check = []

    if ci_sys_ids:
        # Use provided CI sys_ids
        cis_to_check = [{"sys_id": sys_id} for sys_id in ci_sys_ids]
    else:
        # Query CIs by class
        table = ci_class if ci_class else "cmdb_ci"
        record_limit = sample_limit_for_audit_level(audit_level)

        try:
            query_result = await client.get_table_records(
                table=table,
                sysparm_query="",
                sysparm_fields="sys_id,name",
                sysparm_limit=record_limit,
                sysparm_display_value="false"
            )

            cis_to_check = query_result.get("result", [])

        except Exception as e:
            print(f"[ERROR] Failed to query CIs: {e}", file=sys.stderr)
            return {
                "status": "error",
                "error": str(e),
                "summary": "Failed to query CMDB"
            }

    total_cis = len(cis_to_check)

    if total_cis == 0:
        return {
            "status": "success",
            "drift_events": [],
            "drift_by_ci": {},
            "drift_by_field": {},
            "drift_score": 100.0,
            "summary": "No CIs found to analyze",
            "metadata": build_audit_metadata(
                audit_type="drift_detection",
                audit_level=audit_level,
                execution_time=(datetime.now() - start_time).total_seconds()
            )
        }

    print(f"[INFO] Analyzing {total_cis} CIs for configuration drift...", file=sys.stderr)

    # Initialize tracking
    drift_events = []
    drift_by_ci = {}
    drift_by_field = {}
    unauthorized_changes = []

    # Analyze each CI
    for ci in cis_to_check:
        ci_sys_id = ci.get("sys_id")
        ci_name = ci.get("name", "Unknown")

        # Get recent field changes
        field_changes = await _get_recent_field_changes(client, ci_sys_id, lookback_days)

        if not field_changes:
            continue  # No changes, no drift

        ci_drift_count = 0

        for change in field_changes:
            field_name = change.get("fieldname")
            old_value = change.get("oldvalue", "")
            new_value = change.get("newvalue", "")
            changed_by = change.get("sys_created_by", "system")
            changed_on = change.get("sys_created_on")
            reason = change.get("reason", "")

            # Classify field severity
            severity = _classify_field_severity(field_name)

            # Create drift event
            drift_event = {
                "ci_sys_id": ci_sys_id,
                "ci_name": ci_name,
                "field": field_name,
                "old_value": old_value,
                "new_value": new_value,
                "changed_by": changed_by,
                "changed_on": changed_on,
                "severity": severity,
                "reason": reason
            }

            drift_events.append(drift_event)
            ci_drift_count += 1

            # Track drift by field
            if field_name not in drift_by_field:
                drift_by_field[field_name] = {
                    "count": 0,
                    "severity": severity,
                    "affected_cis": []
                }
            drift_by_field[field_name]["count"] += 1
            drift_by_field[field_name]["affected_cis"].append(ci_sys_id)

            # Detect unauthorized changes (simplified - check if user is not 'system' or 'admin')
            if detect_unauthorized_changes and changed_by not in ["system", "admin", "discovery"]:
                unauthorized_changes.append({
                    **drift_event,
                    "reason_for_flag": "Change by non-system user without documented reason" if not reason else None
                })

        # Track drift per CI
        if ci_drift_count > 0:
            drift_by_ci[ci_sys_id] = {
                "ci_name": ci_name,
                "drift_count": ci_drift_count,
                "high_severity_count": len([e for e in drift_events if e["ci_sys_id"] == ci_sys_id and e["severity"] == "high"]),
                "medium_severity_count": len([e for e in drift_events if e["ci_sys_id"] == ci_sys_id and e["severity"] == "medium"]),
                "low_severity_count": len([e for e in drift_events if e["ci_sys_id"] == ci_sys_id and e["severity"] == "low"]),
            }

    # Check CSDM compliance (if requested)
    csdm_violations = []
    if check_csdm_compliance and ci_class:
        try:
            csdm_loader = get_csdm_rules()
            required_fields = csdm_loader.get_required_fields(ci_class)

            # Check if critical required fields were changed
            for drift_event in drift_events:
                if drift_event["field"] in required_fields and drift_event["new_value"] == "":
                    csdm_violations.append({
                        **drift_event,
                        "violation": "Required CSDM field cleared",
                        "csdm_rule": f"{ci_class} requires {drift_event['field']}"
                    })
        except Exception as e:
            print(f"[WARNING] CSDM compliance check failed: {e}", file=sys.stderr)

    # Calculate drift score
    drift_score = _calculate_drift_score(drift_events, total_cis)

    # Sort drift events by severity and timestamp
    drift_events.sort(key=lambda x: (
        {"high": 0, "medium": 1, "low": 2}.get(x["severity"], 3),
        x["changed_on"]
    ), reverse=True)

    # Limit results based on audit level
    if audit_level == "quick":
        drift_events = drift_events[:20]
        unauthorized_changes = unauthorized_changes[:10]
    elif audit_level == "standard":
        drift_events = drift_events[:100]
        unauthorized_changes = unauthorized_changes[:50]
    # deep: return all

    # Generate recommendations
    recommendations = []
    if len(drift_events) > 100:
        recommendations.append({
            "priority": "high",
            "action": "Investigate high volume of configuration changes",
            "impact": f"{len(drift_events)} drift events detected in {lookback_days} days"
        })

    if len(unauthorized_changes) > 10:
        recommendations.append({
            "priority": "high",
            "action": "Review and implement change control policies",
            "impact": f"{len(unauthorized_changes)} unauthorized changes detected"
        })

    if len(csdm_violations) > 0:
        recommendations.append({
            "priority": "high",
            "action": "Restore CSDM-required fields that were cleared or modified",
            "impact": f"{len(csdm_violations)} CSDM compliance violations"
        })

    if drift_score < 70:
        recommendations.append({
            "priority": "medium",
            "action": "Establish configuration baselines and automated drift detection",
            "impact": f"Drift score is {drift_score:.1f}/100, indicating significant configuration instability"
        })

    # Top fields with most drift
    top_drift_fields = sorted(drift_by_field.items(), key=lambda x: x[1]["count"], reverse=True)[:10]

    # Build summary
    summary = (
        f"Drift score: {drift_score:.1f}/100. "
        f"{len(drift_events)} total drift events, {len(unauthorized_changes)} unauthorized changes, "
        f"{len(csdm_violations)} CSDM violations in {lookback_days} days."
    )

    execution_time = (datetime.now() - start_time).total_seconds()

    result = {
        "status": "success",
        "drift_events_count": len(drift_events),
        "drift_events": drift_events if audit_level != "quick" else drift_events[:10],
        "drift_by_ci": drift_by_ci,
        "drift_by_field": {k: v for k, v in top_drift_fields},
        "unauthorized_changes_count": len(unauthorized_changes),
        "unauthorized_changes": unauthorized_changes if detect_unauthorized_changes else None,
        "csdm_violations_count": len(csdm_violations),
        "csdm_violations": csdm_violations if check_csdm_compliance else None,
        "drift_score": round(drift_score, 1),
        "recommendations": recommendations,
        "summary": summary,
        "total_cis_analyzed": total_cis,
        "lookback_days": lookback_days,
        "metadata": build_audit_metadata(
            audit_type="drift_detection",
            audit_level=audit_level,
            execution_time=execution_time,
            ci_class=ci_class
        )
    }

    print(f"[INFO] Drift detection complete: {drift_score:.1f}/100 in {execution_time:.2f}s", file=sys.stderr)

    return result
