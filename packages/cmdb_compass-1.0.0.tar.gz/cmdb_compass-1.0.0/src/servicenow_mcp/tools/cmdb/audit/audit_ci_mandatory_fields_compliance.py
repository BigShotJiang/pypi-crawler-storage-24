"""Audit CI Mandatory Fields Compliance Tool

Foundation tool for governance - identifies CIs missing CSDM-required fields.
Used by policy violation scoring, retention management, and confidentiality validation.

**Enterprise Value:**
- Enables data completeness KPI for CIOs
- Generates field gap reports for CMDB cleanup
- Feeds compliance scorecards (GDPR, DORA, SOX)
- Prioritizes remediation by field criticality

**Algorithm:**
- Primary source: CSDM rules loader (get_required_fields)
- Fallback: ServiceNow sys_dictionary (mandatory=true)
- Weighted scoring: critical=10pts, important=5pts, optional=1pt
- Grade: A (90+), B (75+), C (60+), D (50+), F (<50)
"""

from __future__ import annotations

import sys
from typing import Any, Dict, List, Optional, Set

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit import utils
from servicenow_mcp.tools.cmdb.audit.utils import (
    cache_audit_baseline,
    get_cached_baseline,
    score_to_grade,
)


async def audit_ci_mandatory_fields_compliance(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
    include_optional_fields: bool = False,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit mandatory field compliance across CMDB CIs.

    Identifies CIs missing CSDM-required fields and generates weighted completeness
    scores. Foundation tool for policy violation scoring and compliance reporting.

    Args:
        client: ServiceNow client instance
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server'). If None, audits domain.
        domain: CSDM domain filter (e.g., 'Foundation', 'Manage Infrastructure')
        audit_level: 'quick' (sample-based), 'standard' (full scan), 'deep' (with recommendations)
        include_optional_fields: If True, includes optional field analysis (slower)
        sample_limit: Override default sampling limit for quick audits

    Returns:
        Dictionary containing:
        - overall_compliance_score: Weighted completeness percentage (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs audited
        - field_gaps: Detailed gap analysis by field
        - by_ci_class: Breakdown by CI class (if domain-level audit)
        - critical_missing: List of CIs missing critical fields
        - remediation_priority: Ordered list of fields to fix first
        - field_weights: Weighting used for scoring
    """

    cache_key = f"mandatory_fields_compliance:{ci_class}:{domain}:{audit_level}"
    cached = get_cached_baseline(cache_key)
    if cached is not None:
        return cached

    csdm_loader = get_csdm_rules()

    # If domain specified, audit all CI classes in that domain
    if domain and not ci_class:
        return await _audit_domain_mandatory_fields(
            client, csdm_loader, domain, audit_level, include_optional_fields, sample_limit
        )

    # If no CI class or domain specified, default to all Foundation CIs
    if not ci_class and not domain:
        ci_class = "cmdb_ci"  # Base CI class

    # Single CI class audit
    return await _audit_ci_class_mandatory_fields(
        client, csdm_loader, ci_class, domain, audit_level, include_optional_fields, sample_limit
    )


async def _audit_ci_class_mandatory_fields(
    client: ServiceNowClient,
    csdm_loader,
    ci_class: str,
    domain: Optional[str],
    audit_level: utils.AuditLevel,
    include_optional_fields: bool,
    sample_limit: Optional[int],
) -> Dict[str, Any]:
    """Audit mandatory field compliance for a single CI class."""

    # Determine table name (usually same as CI class)
    table = ci_class

    # Get total CI count
    try:
        total_response = await client.count_records(table)
        total_cis = total_response[0] if isinstance(total_response, tuple) else total_response
    except Exception as e:
        print(f"[ERROR] Failed to count CIs in {table}: {e}", file=sys.stderr)
        return _empty_result(ci_class, f"Table {table} not accessible")

    if total_cis == 0:
        return _empty_result(ci_class, "No CIs found in table")

    # Get required fields from CSDM rules (primary source)
    required_fields = csdm_loader.get_required_fields(ci_class)
    optional_fields = csdm_loader.get_optional_fields(ci_class) if include_optional_fields else set()

    # Fallback: Get mandatory fields from sys_dictionary if CSDM has none
    if not required_fields:
        print(f"[INFO] No CSDM rules for {ci_class}, falling back to sys_dictionary", file=sys.stderr)
        sys_dict_fields = await utils.get_required_fields_from_sys_dictionary(client, table)
        required_fields = set(sys_dict_fields.get("mandatory", []))
        if include_optional_fields:
            optional_fields = set(sys_dict_fields.get("recommended", []))

    if not required_fields and not optional_fields:
        return _empty_result(ci_class, "No required or optional fields defined")

    # Determine sampling based on audit level
    if audit_level == "quick":
        sample_size = sample_limit or min(100, total_cis)
        query = f"active=true^ORDERBYsys_created_on"
    else:
        sample_size = total_cis  # Full scan for standard/deep
        query = "active=true"

    # Query CIs with required fields only (optimization)
    fields_to_query = list(required_fields.union(optional_fields).union({"sys_id", "name", "sys_class_name"}))
    sysparm_fields = ",".join(fields_to_query[:50])  # Limit to 50 fields to avoid API limits

    try:
        cis_response = await client.get_table_records(
            table=table,
            sysparm_query=query,
            sysparm_fields=sysparm_fields,
            sysparm_limit=sample_size,
            sysparm_display_value="false",
        )
        cis = cis_response.get("result", [])
    except Exception as e:
        print(f"[ERROR] Failed to query CIs from {table}: {e}", file=sys.stderr)
        return _empty_result(ci_class, f"Failed to query CIs: {str(e)}")

    if not cis:
        return _empty_result(ci_class, "No active CIs found")

    # Analyze field completeness
    field_analysis = _analyze_field_completeness(
        cis, required_fields, optional_fields, include_optional_fields
    )

    # Calculate weighted compliance score
    weighted_score = _calculate_weighted_completeness(
        field_analysis["required_fields"],
        field_analysis.get("optional_fields", {}) if include_optional_fields else {}
    )

    # Identify critical CIs (missing critical fields)
    critical_missing = _identify_critical_missing_cis(
        cis, field_analysis["required_fields"]
    )

    # Generate remediation priority
    remediation_priority = _generate_remediation_priority(
        field_analysis["required_fields"],
        field_analysis.get("optional_fields", {}),
        total_cis
    )

    # Build result
    result = {
        "ci_class": ci_class,
        "table": table,
        "total_cis": len(cis),
        "total_cis_in_table": total_cis,
        "sampled": len(cis) < total_cis,
        "sample_percent": round((len(cis) / total_cis) * 100, 1) if total_cis > 0 else 0,
        "overall_compliance_score": weighted_score["overall_score"],
        "grade": score_to_grade(weighted_score["overall_score"]),
        "field_gaps": {
            "required": field_analysis["required_fields"],
            "optional": field_analysis.get("optional_fields", {}) if include_optional_fields else {}
        },
        "critical_missing_cis": critical_missing,
        "remediation_priority": remediation_priority,
        "scoring_details": {
            "field_weights": weighted_score["field_weights"],
            "total_possible_points": weighted_score["total_possible_points"],
            "total_earned_points": weighted_score["total_earned_points"],
        },
        "audit_metadata": utils.build_audit_metadata(
            audit_level=audit_level,
            total_records=len(cis),
            sampled_records=len(cis),
            tool_name="audit_ci_mandatory_fields_compliance",
            parameters={
                "ci_class": ci_class,
                "domain": domain,
                "audit_level": audit_level,
                "include_optional_fields": include_optional_fields,
            }
        ),
        "status": "success",
    }

    # Add deep analysis if requested
    if audit_level == "deep":
        result["recommendations"] = _generate_deep_recommendations(
            field_analysis, critical_missing, remediation_priority
        )

    cache_key = f"mandatory_fields_compliance:{ci_class}:{domain}:{audit_level}"
    cache_audit_baseline(cache_key, result)
    return result


async def _audit_domain_mandatory_fields(
    client: ServiceNowClient,
    csdm_loader,
    domain: str,
    audit_level: utils.AuditLevel,
    include_optional_fields: bool,
    sample_limit: Optional[int],
) -> Dict[str, Any]:
    """Audit mandatory field compliance for all CI classes in a domain."""

    # Get all CI classes in the domain
    ci_classes = csdm_loader.get_ci_classes_by_domain(domain)

    if not ci_classes:
        return {
            "domain": domain,
            "status": "error",
            "message": f"No CI classes found in domain '{domain}'",
            "overall_compliance_score": 0,
            "grade": "F",
        }

    # Audit each CI class
    by_ci_class = {}
    total_score = 0
    total_classes = 0
    total_cis_audited = 0
    all_critical_missing = []

    for ci_class in ci_classes[:10]:  # Limit to 10 classes to avoid timeout
        try:
            class_result = await _audit_ci_class_mandatory_fields(
                client, csdm_loader, ci_class, domain, audit_level, include_optional_fields, sample_limit
            )

            if class_result.get("status") == "success" and class_result.get("total_cis", 0) > 0:
                by_ci_class[ci_class] = class_result
                total_score += class_result["overall_compliance_score"]
                total_classes += 1
                total_cis_audited += class_result["total_cis"]
                all_critical_missing.extend(class_result.get("critical_missing_cis", []))
        except Exception as e:
            print(f"[WARN] Failed to audit {ci_class}: {e}", file=sys.stderr)
            continue

    # Calculate domain-wide score (average of class scores)
    domain_score = round(total_score / total_classes, 1) if total_classes > 0 else 0

    return {
        "domain": domain,
        "overall_compliance_score": domain_score,
        "grade": score_to_grade(domain_score),
        "total_cis_audited": total_cis_audited,
        "ci_classes_audited": total_classes,
        "by_ci_class": by_ci_class,
        "critical_missing_cis": all_critical_missing[:100],  # Top 100
        "audit_metadata": utils.build_audit_metadata(
            audit_level=audit_level,
            total_records=total_cis_audited,
            sampled_records=total_cis_audited,
            tool_name="audit_ci_mandatory_fields_compliance",
            parameters={
                "ci_class": None,
                "domain": domain,
                "audit_level": audit_level,
                "include_optional_fields": include_optional_fields,
            }
        ),
        "status": "success",
    }


def _analyze_field_completeness(
    cis: List[Dict[str, Any]],
    required_fields: Set[str],
    optional_fields: Set[str],
    include_optional: bool,
) -> Dict[str, Any]:
    """Analyze field completeness across CIs."""

    required_field_stats = {}
    optional_field_stats = {}

    total_cis = len(cis)

    # Analyze required fields
    for field in required_fields:
        populated_count = sum(1 for ci in cis if ci.get(field) and str(ci.get(field)).strip())
        unpopulated_count = total_cis - populated_count

        required_field_stats[field] = {
            "field_name": field,
            "populated": populated_count,
            "unpopulated": unpopulated_count,
            "population_percent": round((populated_count / total_cis) * 100, 1) if total_cis > 0 else 0,
            "criticality": "critical",  # All required fields are critical
        }

    # Analyze optional fields if requested
    if include_optional:
        for field in optional_fields:
            populated_count = sum(1 for ci in cis if ci.get(field) and str(ci.get(field)).strip())
            unpopulated_count = total_cis - populated_count

            optional_field_stats[field] = {
                "field_name": field,
                "populated": populated_count,
                "unpopulated": unpopulated_count,
                "population_percent": round((populated_count / total_cis) * 100, 1) if total_cis > 0 else 0,
                "criticality": "optional",
            }

    return {
        "required_fields": required_field_stats,
        "optional_fields": optional_field_stats if include_optional else {},
    }


def _calculate_weighted_completeness(
    required_field_stats: Dict[str, Dict],
    optional_field_stats: Dict[str, Dict],
) -> Dict[str, Any]:
    """Calculate weighted completeness score (critical=10pts, important=5pts, optional=1pt)."""

    # Field weights based on criticality
    CRITICAL_WEIGHT = 10  # Required fields
    IMPORTANT_WEIGHT = 5  # Recommended fields (future)
    OPTIONAL_WEIGHT = 1   # Optional fields

    total_possible_points = 0
    total_earned_points = 0
    field_weights = {}

    # Score required fields (critical weight)
    for field, stats in required_field_stats.items():
        possible_points = CRITICAL_WEIGHT
        earned_points = (stats["population_percent"] / 100) * CRITICAL_WEIGHT

        total_possible_points += possible_points
        total_earned_points += earned_points
        field_weights[field] = {"weight": CRITICAL_WEIGHT, "criticality": "critical"}

    # Score optional fields (optional weight)
    for field, stats in optional_field_stats.items():
        possible_points = OPTIONAL_WEIGHT
        earned_points = (stats["population_percent"] / 100) * OPTIONAL_WEIGHT

        total_possible_points += possible_points
        total_earned_points += earned_points
        field_weights[field] = {"weight": OPTIONAL_WEIGHT, "criticality": "optional"}

    # Calculate overall score (0-100)
    overall_score = round(
        (total_earned_points / total_possible_points) * 100, 1
    ) if total_possible_points > 0 else 0

    return {
        "overall_score": overall_score,
        "total_possible_points": round(total_possible_points, 1),
        "total_earned_points": round(total_earned_points, 1),
        "field_weights": field_weights,
    }


def _identify_critical_missing_cis(
    cis: List[Dict[str, Any]],
    required_field_stats: Dict[str, Dict],
) -> List[Dict[str, Any]]:
    """Identify CIs missing critical required fields."""

    critical_missing = []
    required_fields = set(required_field_stats.keys())

    for ci in cis:
        missing_fields = [
            field for field in required_fields
            if not ci.get(field) or not str(ci.get(field)).strip()
        ]

        if missing_fields:
            critical_missing.append({
                "ci_sys_id": ci.get("sys_id"),
                "ci_name": ci.get("name", "Unknown"),
                "ci_class": ci.get("sys_class_name", "Unknown"),
                "missing_fields": missing_fields,
                "missing_field_count": len(missing_fields),
                "severity": "critical" if len(missing_fields) >= 3 else "high" if len(missing_fields) >= 2 else "medium",
            })

    # Sort by missing field count (most critical first)
    critical_missing.sort(key=lambda x: x["missing_field_count"], reverse=True)

    return critical_missing[:100]  # Return top 100


def _generate_remediation_priority(
    required_field_stats: Dict[str, Dict],
    optional_field_stats: Dict[str, Dict],
    total_cis: int,
) -> List[Dict[str, Any]]:
    """Generate prioritized list of fields to remediate first."""

    remediation_list = []

    # Prioritize required fields by unpopulated count
    for field, stats in required_field_stats.items():
        if stats["unpopulated"] > 0:
            remediation_list.append({
                "field_name": field,
                "unpopulated_count": stats["unpopulated"],
                "population_percent": stats["population_percent"],
                "criticality": "critical",
                "priority": 1,  # Highest priority
                "impact": "high",
                "recommendation": f"Populate {field} for {stats['unpopulated']} CIs to improve compliance",
            })

    # Optional fields (lower priority)
    for field, stats in optional_field_stats.items():
        if stats["unpopulated"] > 0:
            remediation_list.append({
                "field_name": field,
                "unpopulated_count": stats["unpopulated"],
                "population_percent": stats["population_percent"],
                "criticality": "optional",
                "priority": 3,  # Lower priority
                "impact": "medium",
                "recommendation": f"Consider populating {field} for {stats['unpopulated']} CIs",
            })

    # Sort by priority, then unpopulated count
    remediation_list.sort(key=lambda x: (x["priority"], -x["unpopulated_count"]))

    return remediation_list


def _generate_deep_recommendations(
    field_analysis: Dict[str, Any],
    critical_missing: List[Dict[str, Any]],
    remediation_priority: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Generate detailed recommendations for deep audit level."""

    recommendations = {
        "summary": f"Identified {len(critical_missing)} CIs missing critical fields",
        "top_actions": [],
        "automation_opportunities": [],
        "data_quality_initiatives": [],
    }

    # Top 3 remediation actions
    for item in remediation_priority[:3]:
        recommendations["top_actions"].append(
            f"Fix {item['unpopulated_count']} CIs missing '{item['field_name']}' ({item['criticality']} field)"
        )

    # Automation opportunities
    if any(item["field_name"] in ["owned_by", "managed_by", "support_group"] for item in remediation_priority):
        recommendations["automation_opportunities"].append(
            "Auto-assign ownership based on discovery source or cost center"
        )

    if any(item["field_name"] in ["ip_address", "mac_address", "serial_number"] for item in remediation_priority):
        recommendations["automation_opportunities"].append(
            "Enable discovery auto-population for network/hardware fields"
        )

    # Data quality initiatives
    if len(critical_missing) > 100:
        recommendations["data_quality_initiatives"].append(
            "Implement data quality dashboard to track field completeness trends"
        )

    recommendations["data_quality_initiatives"].append(
        "Establish CMDB data quality SLA (target: 90% required field completion)"
    )

    return recommendations


def _empty_result(ci_class: str, reason: str) -> Dict[str, Any]:
    """Return empty result when audit cannot be performed."""
    return {
        "ci_class": ci_class,
        "overall_compliance_score": 0,
        "grade": "F",
        "total_cis": 0,
        "field_gaps": {"required": {}, "optional": {}},
        "critical_missing_cis": [],
        "remediation_priority": [],
        "status": "error",
        "message": reason,
    }
