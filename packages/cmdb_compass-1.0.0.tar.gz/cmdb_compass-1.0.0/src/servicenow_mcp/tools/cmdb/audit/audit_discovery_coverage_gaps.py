"""Audit Discovery Coverage Gaps Tool

Identifies gaps in Service Graph Connector and Discovery coverage.
Addresses critical CMDB challenge: "Inadequate CI discovery processes" (Forrester top 3 issue).

Analyzes Ingestion coverage across:
- discovery_source: Identifies manually created vs discovered CIs
- last_discovered: Detects stale discovered CIs needing refresh
- Discovery schedules: Monitors schedule health (optional, if Discovery plugin accessible)

ServiceNow Ingestion Methods (CIS-DF Aligned):
- discovery_source = "ServiceNow" → Discovered by ServiceNow Discovery or Service Graph Connectors
- discovery_source = "Manual Entry" → Manually created CIs (technical debt)
- discovery_source = <External name> → Integration sources (IntegrationHub, custom)
- last_discovered: Updated after successful pattern discovery (does NOT update sys_updated_on)

QUERY tool with no modification capability.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, score_to_grade

async def audit_discovery_coverage_gaps(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_details: bool = True,
    details_limit: int = 50,
    staleness_threshold_days: int = 90,
    sample_size: int = 1000,
    check_discovery_schedules: bool = True,
) -> Dict[str, Any]:
    """
    Audit gaps in Service Graph Connector and Discovery coverage (CIS-DF Ingestion domain).

    Addresses critical CMDB challenge: "Inadequate CI discovery processes affect CMDB
    maintenance, resulting in missing CIs and incomplete data" (Forrester research).

    ServiceNow Ingestion Best Practices (CIS-DF aligned):
    - discovery_source "ServiceNow": Discovered by ServiceNow Discovery or Service Graph Connectors (TARGET)
    - discovery_source "Manual Entry": Manually created CIs (technical debt - GAP)
    - discovery_source <External>: Integration sources (IntegrationHub, CMDB 360 sources)
    - last_discovered: Timestamp of last successful discovery
    - Stale CIs: last_discovered > 90 days (configurable threshold)

    This tool identifies:
    - **Manual CIs**: Not covered by Discovery (discovery_source != "ServiceNow")
    - **Stale discovered CIs**: last_discovered > threshold
    - **Discovery coverage**: % of CIs discovered vs. manual
    - **Discovery schedules**: Health check (optional, if plugin accessible)

    AUDIT LEVELS:
    - quick: Summary only, no CI details (<1s execution)
    - standard: Top 50 manual CIs, coverage metrics (default)
    - deep: Top 100 CIs + discovery schedule health analysis

    Args:
        client: ServiceNow client instance
        ci_class: The CI class to analyze (e.g., 'cmdb_ci_server', 'cmdb_ci_database')
        domain: Optional domain filter for multi-domain instances
        audit_level: Analysis depth ('quick', 'standard', 'deep')
        include_details: Include CI details in response (default: True, disabled in quick mode)
        details_limit: Max CIs to include in details (default: 50, deep: 100)
        staleness_threshold_days: Days since last discovery to consider stale (default: 90)
        sample_size: Max CIs to analyze for performance (default: 1000)
        check_discovery_schedules: Query Discovery schedules (auto-disabled if unavailable)

    Returns:
        Dictionary containing:
        - discovery_coverage_score: 0-100 score
        - discovery_grade: A-F letter grade
        - ci_class: CI class analyzed
        - total_cis: Total active CIs found
        - discovered_cis: CIs with discovery_source = "ServiceNow"
        - manual_cis: CIs with discovery_source != "ServiceNow"
        - discovery_coverage_percentage: % discovered
        - stale_discovered_cis: Discovered CIs with last_discovered > threshold
        - cis_by_source: Breakdown by discovery_source
        - manual_cis_details: List of manual CI details (if include_details=True)
        - stale_cis_details: List of stale discovered CIs (if include_details=True)
        - discovery_schedules_summary: Schedule health (if check_discovery_schedules=True)
        - recommendations: Prioritized actionable next steps
        - metadata: Phase 3 audit metadata
        - status: 'success' or 'error'

    EXAMPLE OUTPUT:
        "cmdb_ci_server: 500 total CIs. 174 manual (34.8%). Discovery coverage: 65.2/100 (Grade D).
         CRITICAL: 34.8% of CIs were manually created - not covered by Discovery.
         45 discovered CIs are stale (>90 days) - schedule rediscovery."

    USE CASES:
    - Identify CIs needing Discovery setup
    - Detect discovery service failures
    - Prioritize rediscovery efforts
    - Track Discovery adoption over time
    - Validate Discovery schedule effectiveness
    """
    try:
        start_time = datetime.now()

        # Adjust details_limit based on audit_level
        if audit_level == "quick":
            include_details = False
        elif audit_level == "deep":
            details_limit = 100

        # Step 1: Build query
        query_parts = ["active=true"]
        if domain:
            query_parts.append(f"sys_domain={domain}")
        query = "^".join(query_parts)

        # Step 2: Fetch CIs with discovery fields
        fields = [
            "sys_id",
            "name",
            "operational_status",
            "install_status",
            "sys_created_on",
            "sys_updated_on",
            "discovery_source",
            "last_discovered",
            "first_discovered"
        ]

        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query=query,
            sysparm_fields=",".join(fields),
            sysparm_limit=sample_size
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "status": "success",
                "discovery_coverage_score": 0,
                "discovery_grade": "N/A",
                "ci_class": ci_class,
                "domain": domain,
                "total_cis": 0,
                "message": f"No active CIs found for class {ci_class}",
                "metadata": build_audit_metadata(
                    audit_type="discovery_coverage_gaps",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class
                )
            }

        # Step 3: Analyze discovery coverage
        discovered_cis = []
        manual_cis = []
        stale_discovered_cis = []
        cis_by_source = {}

        # Calculate staleness cutoff
        now = datetime.now(timezone.utc)
        staleness_cutoff = now - timedelta(days=staleness_threshold_days)

        for ci in cis:
            discovery_source_raw = ci.get("discovery_source")
            if discovery_source_raw is None:
                discovery_source = "Unknown"
            else:
                discovery_source = str(discovery_source_raw).strip()

            # Normalize discovery_source
            if not discovery_source:
                discovery_source = "Unknown"

            # Count by source
            cis_by_source[discovery_source] = cis_by_source.get(discovery_source, 0) + 1

            # Classify: Discovered vs Manual
            if discovery_source == "ServiceNow":
                discovered_cis.append(ci)

                # Check staleness for discovered CIs
                last_discovered_str = ci.get("last_discovered", "")
                if last_discovered_str:
                    try:
                        last_discovered = _parse_servicenow_timestamp(last_discovered_str)
                        if last_discovered and last_discovered < staleness_cutoff:
                            stale_discovered_cis.append({
                                "ci": ci,
                                "last_discovered": last_discovered,
                                "days_since_discovery": (now - last_discovered).days
                            })
                    except Exception:
                        # Failed to parse timestamp, skip staleness check
                        pass
            else:
                # Not discovered by ServiceNow = Manual or other source
                manual_cis.append(ci)

        discovered_count = len(discovered_cis)
        manual_count = len(manual_cis)
        stale_count = len(stale_discovered_cis)

        discovery_coverage_percentage = (discovered_count / total_cis * 100) if total_cis > 0 else 0
        stale_percentage = (stale_count / discovered_count * 100) if discovered_count > 0 else 0

        # Step 4: Calculate discovery coverage score (0-100)
        # Primary metric: % of CIs discovered by ServiceNow Discovery
        # Penalty for staleness: reduce score if >10% discovered CIs are stale
        discovery_coverage_score = discovery_coverage_percentage

        if stale_percentage > 10:
            # Penalize: -1 point per 1% over 10% stale threshold
            staleness_penalty = (stale_percentage - 10)
            discovery_coverage_score = max(0, discovery_coverage_score - staleness_penalty)

        # Step 5: Calculate letter grade
        discovery_grade = score_to_grade(discovery_coverage_score)

        # Step 6: Check Discovery schedules (optional, deep mode only)
        discovery_schedules_available = False
        discovery_schedules_summary = {}

        if check_discovery_schedules and audit_level == "deep":
            try:
                schedules_response = await client.get_table_records(
                    table="discovery_schedule",
                    sysparm_query="",
                    sysparm_fields="sys_id,name,active,schedule,ci_type",
                    sysparm_limit=100
                )

                schedules = schedules_response.get("result", [])
                discovery_schedules_available = True

                active_schedules = [s for s in schedules if s.get("active") == "true" or s.get("active") is True]
                inactive_schedules = [s for s in schedules if s.get("active") == "false" or s.get("active") is False]

                # Find schedules covering this CI class
                ci_classes_covered = set()
                for schedule in schedules:
                    ci_type = schedule.get("ci_type", "").strip()
                    if ci_type:
                        ci_classes_covered.add(ci_type)

                discovery_schedules_summary = {
                    "total_schedules": len(schedules),
                    "active_schedules": len(active_schedules),
                    "inactive_schedules": len(inactive_schedules),
                    "ci_classes_covered": list(ci_classes_covered),
                    "current_ci_class_covered": ci_class in ci_classes_covered
                }

            except Exception as e:
                # Discovery plugin not available or no access to discovery_schedule table
                print(f"[INFO] Discovery schedule check unavailable: {e}", flush=True)
                discovery_schedules_available = False

        # Step 7: Generate recommendations
        recommendations = _generate_recommendations(
            manual_count,
            manual_count / total_cis * 100 if total_cis > 0 else 0,
            stale_count,
            stale_percentage,
            discovery_coverage_score,
            total_cis,
            discovered_count,
            discovery_schedules_summary,
            audit_level,
            ci_class
        )

        # Step 8: Sort and limit manual CIs for details
        manual_cis_details = []
        if include_details and manual_cis:
            # Sort by priority: Operational status first, then recent updates
            sorted_manual = sorted(
                manual_cis,
                key=lambda ci: (
                    ci.get("operational_status", "") != "Operational",
                    ci.get("sys_created_on", "")
                ),
                reverse=False
            )

            for ci in sorted_manual[:details_limit]:
                manual_cis_details.append({
                    "sys_id": ci.get("sys_id"),
                    "name": ci.get("name"),
                    "ci_class": ci_class,
                    "discovery_source": ci.get("discovery_source", "Unknown"),
                    "operational_status": ci.get("operational_status", "Unknown"),
                    "sys_created_on": ci.get("sys_created_on", ""),
                    "sys_updated_on": ci.get("sys_updated_on", "")
                })

        # Step 9: Sort and limit stale CIs for details
        stale_cis_details = []
        if include_details and stale_discovered_cis:
            # Sort by staleness (oldest first)
            sorted_stale = sorted(
                stale_discovered_cis,
                key=lambda item: item["days_since_discovery"],
                reverse=True
            )

            for item in sorted_stale[:details_limit]:
                ci = item["ci"]
                stale_cis_details.append({
                    "sys_id": ci.get("sys_id"),
                    "name": ci.get("name"),
                    "last_discovered": ci.get("last_discovered", ""),
                    "days_since_discovery": item["days_since_discovery"],
                    "discovery_source": "ServiceNow",
                    "operational_status": ci.get("operational_status", "Unknown")
                })

        # Step 10: Build response
        execution_time = (datetime.now() - start_time).total_seconds()

        result = {
            "status": "success",
            "discovery_coverage_score": round(discovery_coverage_score, 1),
            "discovery_grade": discovery_grade,
            "ci_class": ci_class,
            "domain": domain,
            "total_cis": total_cis,
            "discovered_cis": discovered_count,
            "manual_cis": manual_count,
            "discovery_coverage_percentage": round(discovery_coverage_percentage, 1),
            "stale_discovered_cis": stale_count,
            "stale_percentage": round(stale_percentage, 1) if discovered_count > 0 else 0,
            "staleness_threshold_days": staleness_threshold_days,
            "cis_by_source": cis_by_source,
            "discovery_schedules_available": discovery_schedules_available,
            "recommendations": recommendations,
            "metadata": build_audit_metadata(
                audit_type="discovery_coverage_gaps",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            )
        }

        # Add optional details
        if include_details:
            result["manual_cis_details"] = manual_cis_details
            result["stale_cis_details"] = stale_cis_details

        if discovery_schedules_available:
            result["discovery_schedules_summary"] = discovery_schedules_summary

        return result

    except Exception as e:
        print(f"[ERROR] audit_discovery_coverage_gaps failed: {e}", flush=True)
        import traceback
        traceback.print_exc()

        execution_time = (datetime.now() - start_time).total_seconds()
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
            "domain": domain,
            "metadata": build_audit_metadata(
                audit_type="discovery_coverage_gaps",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            )
        }


def _parse_servicenow_timestamp(timestamp_str: str) -> Optional[datetime]:
    """
    Parse ServiceNow timestamp strings with multiple format support.

    ServiceNow timestamp formats:
    - ISO Z format: "2024-12-01T10:00:00Z"
    - ISO offset format: "2024-12-01T10:00:00+00:00"
    - ServiceNow native: "2024-12-01 10:00:00"
    - Naive format: "2024-12-01 10:00:00" (assumed UTC)
    """
    if not timestamp_str:
        return None

    timestamp_str = timestamp_str.strip()

    # Try ISO format with Z
    try:
        return datetime.strptime(timestamp_str, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        pass

    # Try ISO format with offset
    try:
        return datetime.fromisoformat(timestamp_str)
    except ValueError:
        pass

    # Try ServiceNow native format (assume UTC)
    try:
        return datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except ValueError:
        pass

    # Failed to parse
    return None


def _generate_recommendations(
    manual_count: int,
    manual_percentage: float,
    stale_count: int,
    stale_percentage: float,
    overall_score: float,
    total_cis: int,
    discovered_count: int,
    discovery_schedules_summary: Dict[str, Any],
    audit_level: str,
    ci_class: str
) -> List[str]:
    """Generate prioritized, actionable recommendations based on discovery coverage analysis."""
    recommendations = []

    # Critical: High manual CI percentage
    if manual_percentage > 50:
        recommendations.append(
            f"🚨 CRITICAL: {manual_count} CIs ({manual_percentage:.1f}%) were manually created - "
            "not covered by Discovery. Immediate Discovery setup required"
        )
    elif manual_percentage > 20:
        recommendations.append(
            f"⚠️ WARNING: {manual_count} CIs ({manual_percentage:.1f}%) were manually created - "
            "schedule Discovery implementation for this CI class"
        )
    elif manual_percentage > 0:
        recommendations.append(
            f"⚠️ {manual_count} CIs ({manual_percentage:.1f}%) were manually created - "
            "extend Discovery coverage to close gap"
        )

    # Staleness warnings
    if stale_count > 0:
        if stale_percentage > 30:
            recommendations.append(
                f"🚨 CRITICAL: {stale_count} discovered CIs are stale ({stale_percentage:.1f}%) - "
                "Discovery service may have failed. Check Discovery schedules and MID servers"
            )
        elif stale_percentage > 10:
            recommendations.append(
                f"⚠️ WARNING: {stale_count} discovered CIs are stale ({stale_percentage:.1f}%) - "
                "schedule rediscovery to refresh data"
            )
        else:
            recommendations.append(
                f"ℹ️ {stale_count} discovered CIs are stale but within acceptable range (<10%)"
            )

    # Discovery schedule recommendations
    if discovery_schedules_summary:
        if not discovery_schedules_summary.get("current_ci_class_covered", False):
            recommendations.append(
                f"📋 No Discovery schedule found for CI class '{ci_class}' - "
                "create Discovery schedule to automate coverage"
            )

        inactive_count = discovery_schedules_summary.get("inactive_schedules", 0)
        if inactive_count > 0:
            recommendations.append(
                f"⚠️ {inactive_count} Discovery schedules are inactive - "
                "review and activate schedules to improve coverage"
            )

    # Prioritization guidance
    if manual_count > 0:
        recommendations.append(
            "✅ Prioritize Discovery setup: 1) Operational CIs first, 2) Business-critical applications, "
            "3) Recently created manual CIs"
        )

    # Overall score feedback
    if overall_score >= 90:
        recommendations.append(
            f"✅ Excellent discovery coverage ({overall_score:.1f}/100) - maintain current Discovery schedules"
        )
    elif overall_score >= 70:
        recommendations.append(
            f"✅ Good discovery coverage ({overall_score:.1f}/100) - continue improving toward 90% target"
        )
    else:
        recommendations.append(
            f"⚠️ Discovery coverage ({overall_score:.1f}/100) is below target (90%). "
            "Implement Discovery schedules and automate CI data collection"
        )

    # Discovery best practice
    recommendations.append(
        "💡 ServiceNow Best Practice: Schedule recurring Discovery scans to capture new and modified "
        "infrastructure, ensuring CMDB remains current"
    )

    return recommendations
