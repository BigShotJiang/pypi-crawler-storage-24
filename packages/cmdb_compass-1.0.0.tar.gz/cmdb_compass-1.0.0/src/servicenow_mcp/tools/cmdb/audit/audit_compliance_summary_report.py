"""
Compliance Summary Report Tool

Generate an executive-level CMDB compliance summary combining multiple health dimensions.
This tool aggregates results from various audit tools to provide a comprehensive view of
CMDB data quality with traffic-light indicators (green/yellow/red) per dimension.

Phase 3 Week 3 - Data Lineage & Executive Reporting
"""

import json
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata

# Import existing audit tools for aggregation
from servicenow_mcp.tools.cmdb.audit.cmdb_analysis import analyze_ci_completeness, assess_relationship_coverage
from servicenow_mcp.tools.cmdb.audit.audit_cmdb_data_accuracy import audit_cmdb_data_accuracy
from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis
from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis
from servicenow_mcp.tools.cmdb.audit.audit_calculate_csdm_maturity_score import calculate_csdm_maturity_score


# =============================================================================
# Traffic-Light Thresholds
# =============================================================================

TRAFFIC_LIGHT_THRESHOLDS = {
    "green": 80,   # >= 80: Green (healthy)
    "yellow": 50,  # 50-79: Yellow (needs attention)
    # < 50: Red (critical)
}


def _get_traffic_light_status(score: float) -> str:
    """
    Convert a score (0-100) to traffic-light status.

    Args:
        score: Numeric score from 0-100

    Returns:
        "green", "yellow", or "red"
    """
    if score >= TRAFFIC_LIGHT_THRESHOLDS["green"]:
        return "green"
    elif score >= TRAFFIC_LIGHT_THRESHOLDS["yellow"]:
        return "yellow"
    else:
        return "red"


def _get_status_emoji(status: str) -> str:
    """Get emoji for traffic-light status."""
    return {
        "green": "🟢",
        "yellow": "🟡",
        "red": "🔴"
    }.get(status, "⚪")


# =============================================================================
# Domain Classification
# =============================================================================

DOMAIN_CI_CLASSES = {
    "Infrastructure": [
        "cmdb_ci_server",
        "cmdb_ci_linux_server",
        "cmdb_ci_win_server",
        "cmdb_ci_unix_server",
        "cmdb_ci_database",
        "cmdb_ci_storage_device",
        "cmdb_ci_netgear",
        "cmdb_ci_network_adapter",
        "cmdb_ci_ip_router",
        "cmdb_ci_ip_switch",
        "cmdb_ci_load_balancer",
    ],
    "Applications": [
        "cmdb_ci_appl",
        "cmdb_ci_app_server",
        "cmdb_ci_app_server_java",
        "cmdb_ci_web_server",
        "cmdb_ci_service",
    ],
    "Services": [
        "cmdb_ci_service",
        "cmdb_ci_business_app",
        "cmdb_ci_service_auto",
        "cmdb_ci_service_discovered",
    ],
}


def _get_domain_for_ci_class(ci_class: str) -> Optional[str]:
    """Determine which domain a CI class belongs to."""
    for domain, classes in DOMAIN_CI_CLASSES.items():
        if ci_class in classes:
            return domain
    return None


# =============================================================================
# Dimension Aggregation Functions
# =============================================================================

async def _assess_completeness_dimension(
    client: ServiceNowClient,
    domain_filter: Optional[str],
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Assess CMDB completeness dimension.

    Uses analyze_ci_completeness to check for missing required fields.
    """
    try:
        # Get CI classes to check based on domain filter
        ci_classes_to_check = []
        if domain_filter and domain_filter in DOMAIN_CI_CLASSES:
            ci_classes_to_check = DOMAIN_CI_CLASSES[domain_filter]
        else:
            # Check all domains
            for classes in DOMAIN_CI_CLASSES.values():
                ci_classes_to_check.extend(classes)

        # Sample a subset for performance
        sample_classes = ci_classes_to_check[:5] if audit_level == "quick" else ci_classes_to_check[:10] if audit_level == "standard" else ci_classes_to_check

        total_score = 0.0
        class_count = 0
        issues = []

        for ci_class in sample_classes:
            try:
                result = await analyze_ci_completeness(
                    client,
                    table=ci_class,
                    audit_level=audit_level
                )

                if result.get("status") == "success":
                    completeness_score = result.get("completeness_score", 0)
                    total_score += completeness_score
                    class_count += 1

                    # Track classes with low completeness
                    if completeness_score < 70:
                        issues.append({
                            "ci_class": ci_class,
                            "score": completeness_score,
                            "missing_fields_count": result.get("missing_fields_count", 0)
                        })
            except Exception as e:
                print(f"[WARNING] Completeness check failed for {ci_class}: {e}", file=sys.stderr)
                continue

        # Calculate average completeness score
        avg_score = total_score / class_count if class_count > 0 else 0.0

        return {
            "score": round(avg_score, 1),
            "status": _get_traffic_light_status(avg_score),
            "classes_checked": class_count,
            "issues": issues[:10],  # Top 10 issues
            "summary": f"{class_count} CI classes checked, {len(issues)} with completeness < 70%"
        }

    except Exception as e:
        print(f"[ERROR] Completeness dimension assessment failed: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "status": "red",
            "error": str(e),
            "summary": "Assessment failed"
        }


async def _assess_correctness_dimension(
    client: ServiceNowClient,
    domain_filter: Optional[str],
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Assess CMDB data correctness dimension.

    Uses audit_cmdb_data_accuracy to check for data quality issues.
    """
    try:
        result = await audit_cmdb_data_accuracy(
            client,
            audit_level=audit_level
        )

        if result.get("status") == "success":
            accuracy_score = result.get("overall_accuracy_score", 0)
            issues = []

            # Extract issues from the result
            field_issues = result.get("field_accuracy_issues", [])
            for field_issue in field_issues[:10]:  # Top 10
                issues.append({
                    "type": "field_accuracy",
                    "field": field_issue.get("field"),
                    "accuracy": field_issue.get("accuracy_percentage", 0)
                })

            return {
                "score": round(accuracy_score, 1),
                "status": _get_traffic_light_status(accuracy_score),
                "issues": issues,
                "summary": f"Overall data accuracy: {accuracy_score:.1f}%, {len(field_issues)} fields with issues"
            }
        else:
            return {
                "score": 0.0,
                "status": "red",
                "error": result.get("error", "Unknown error"),
                "summary": "Correctness assessment failed"
            }

    except Exception as e:
        print(f"[ERROR] Correctness dimension assessment failed: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "status": "red",
            "error": str(e),
            "summary": "Assessment failed"
        }


async def _assess_relationships_dimension(
    client: ServiceNowClient,
    domain_filter: Optional[str],
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Assess CMDB relationship health dimension.

    Uses assess_relationship_coverage to check relationship quality.
    """
    try:
        # Get CI classes to check based on domain filter
        ci_classes_to_check = []
        if domain_filter and domain_filter in DOMAIN_CI_CLASSES:
            ci_classes_to_check = DOMAIN_CI_CLASSES[domain_filter]
        else:
            # Check key classes from each domain
            ci_classes_to_check = ["cmdb_ci_server", "cmdb_ci_appl", "cmdb_ci_service"]

        # Sample for performance
        sample_classes = ci_classes_to_check[:3] if audit_level == "quick" else ci_classes_to_check[:5]

        total_score = 0.0
        class_count = 0
        issues = []

        for ci_class in sample_classes:
            try:
                result = await assess_relationship_coverage(
                    client,
                    ci_class=ci_class,
                    audit_level=audit_level
                )

                if result.get("status") == "success":
                    coverage_score = result.get("relationship_coverage_score", 0)
                    total_score += coverage_score
                    class_count += 1

                    # Track classes with low relationship coverage
                    if coverage_score < 70:
                        issues.append({
                            "ci_class": ci_class,
                            "score": coverage_score,
                            "missing_relationships": result.get("missing_relationships", 0)
                        })
            except Exception as e:
                print(f"[WARNING] Relationship check failed for {ci_class}: {e}", file=sys.stderr)
                continue

        # Calculate average relationship score
        avg_score = total_score / class_count if class_count > 0 else 0.0

        return {
            "score": round(avg_score, 1),
            "status": _get_traffic_light_status(avg_score),
            "classes_checked": class_count,
            "issues": issues,
            "summary": f"{class_count} CI classes checked, {len(issues)} with relationship coverage < 70%"
        }

    except Exception as e:
        print(f"[ERROR] Relationships dimension assessment failed: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "status": "red",
            "error": str(e),
            "summary": "Assessment failed"
        }


async def _assess_staleness_dimension(
    client: ServiceNowClient,
    domain_filter: Optional[str],
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Assess CMDB staleness dimension.

    Uses audit_identify_stale_cis to check for outdated CIs.
    """
    try:
        # Get CI classes to check based on domain filter
        ci_classes_to_check = []
        if domain_filter and domain_filter in DOMAIN_CI_CLASSES:
            ci_classes_to_check = DOMAIN_CI_CLASSES[domain_filter]
        else:
            # Check key classes from each domain
            ci_classes_to_check = ["cmdb_ci_server", "cmdb_ci_database", "cmdb_ci_appl"]

        # Sample for performance
        sample_classes = ci_classes_to_check[:3] if audit_level == "quick" else ci_classes_to_check[:5]

        total_stale_count = 0
        total_ci_count = 0
        issues = []

        for ci_class in sample_classes:
            try:
                result = await identify_stale_cis(
                    client,
                    ci_class=ci_class,
                    staleness_threshold_days=90,
                    include_details=False
                )

                if result.get("status") == "success":
                    stale_count = result.get("stale_ci_count", 0)
                    total_count = result.get("total_ci_count", 0)

                    total_stale_count += stale_count
                    total_ci_count += total_count

                    if stale_count > 0:
                        stale_percentage = (stale_count / total_count * 100) if total_count > 0 else 0
                        issues.append({
                            "ci_class": ci_class,
                            "stale_count": stale_count,
                            "total_count": total_count,
                            "stale_percentage": round(stale_percentage, 1)
                        })
            except Exception as e:
                print(f"[WARNING] Staleness check failed for {ci_class}: {e}", file=sys.stderr)
                continue

        # Calculate freshness score (inverse of staleness)
        stale_percentage = (total_stale_count / total_ci_count * 100) if total_ci_count > 0 else 0
        freshness_score = max(0, 100 - stale_percentage)

        return {
            "score": round(freshness_score, 1),
            "status": _get_traffic_light_status(freshness_score),
            "stale_ci_count": total_stale_count,
            "total_ci_count": total_ci_count,
            "stale_percentage": round(stale_percentage, 1),
            "issues": issues,
            "summary": f"{total_stale_count}/{total_ci_count} CIs stale (>{90} days), freshness score: {freshness_score:.1f}%"
        }

    except Exception as e:
        print(f"[ERROR] Staleness dimension assessment failed: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "status": "red",
            "error": str(e),
            "summary": "Assessment failed"
        }


async def _assess_duplicates_dimension(
    client: ServiceNowClient,
    domain_filter: Optional[str],
    audit_level: AuditLevel
) -> Dict[str, Any]:
    """
    Assess CMDB duplicate CI dimension.

    Uses audit_duplicate_cis to check for duplicate records.
    """
    try:
        # Get CI classes to check based on domain filter
        ci_classes_to_check = []
        if domain_filter and domain_filter in DOMAIN_CI_CLASSES:
            ci_classes_to_check = DOMAIN_CI_CLASSES[domain_filter]
        else:
            # Check key classes from each domain
            ci_classes_to_check = ["cmdb_ci_server", "cmdb_ci_appl"]

        # Sample for performance
        sample_classes = ci_classes_to_check[:2] if audit_level == "quick" else ci_classes_to_check[:4]

        total_duplicate_count = 0
        total_ci_count = 0
        issues = []

        for ci_class in sample_classes:
            try:
                result = await audit_duplicate_cis(
                    client,
                    table_name=ci_class,
                    audit_level=audit_level
                )

                if result.get("status") == "success":
                    duplicate_count = result.get("total_duplicate_ci_count", 0)
                    duplicate_sets = result.get("duplicate_sets", [])

                    # Estimate total CIs (approximate)
                    total_count = duplicate_count * 3  # Rough estimate

                    total_duplicate_count += duplicate_count
                    total_ci_count += total_count

                    if duplicate_count > 0:
                        issues.append({
                            "ci_class": ci_class,
                            "duplicate_count": duplicate_count,
                            "duplicate_sets": len(duplicate_sets)
                        })
            except Exception as e:
                print(f"[WARNING] Duplicate check failed for {ci_class}: {e}", file=sys.stderr)
                continue

        # Calculate uniqueness score (inverse of duplicate percentage)
        duplicate_percentage = (total_duplicate_count / total_ci_count * 100) if total_ci_count > 0 else 0
        uniqueness_score = max(0, 100 - duplicate_percentage * 2)  # Weight duplicates 2x

        return {
            "score": round(uniqueness_score, 1),
            "status": _get_traffic_light_status(uniqueness_score),
            "duplicate_ci_count": total_duplicate_count,
            "issues": issues,
            "summary": f"{total_duplicate_count} duplicate CIs found, uniqueness score: {uniqueness_score:.1f}%"
        }

    except Exception as e:
        print(f"[ERROR] Duplicates dimension assessment failed: {e}", file=sys.stderr)
        return {
            "score": 0.0,
            "status": "red",
            "error": str(e),
            "summary": "Assessment failed"
        }


# =============================================================================
# Main Tool Function
# =============================================================================

async def audit_compliance_summary_report(
    client: ServiceNowClient,
    *,
    domain_filter: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_recommendations: bool = True,
) -> Dict[str, Any]:
    """
    Generate an executive-level CMDB compliance summary report.

    This tool aggregates multiple audit dimensions to provide a comprehensive
    compliance view with traffic-light indicators (green/yellow/red) per dimension.

    Args:
        client: ServiceNow client instance
        domain_filter: Optional filter - "Infrastructure", "Applications", "Services", or None (all)
        audit_level: Detail level - "quick", "standard", or "deep"
        include_recommendations: Whether to include actionable recommendations

    Returns:
        Dictionary containing:
        - overall_compliance_score: Weighted average across all dimensions (0-100)
        - overall_status: Traffic-light status for overall compliance
        - dimensions: Details for each compliance dimension:
            - completeness: Missing required fields
            - correctness: Data accuracy issues
            - relationships: Relationship health
            - staleness: Outdated CIs
            - duplicates: Duplicate records
        - domain_breakdown: Compliance per domain (if applicable)
        - critical_issues: Top issues requiring immediate attention
        - recommendations: Prioritized action items (if included)
        - metadata: Audit metadata

    Example:
        >>> result = await audit_compliance_summary_report(
        ...     client,
        ...     domain_filter="Infrastructure",
        ...     audit_level="standard"
        ... )
        >>> print(f"Overall compliance: {result['overall_compliance_score']}%")
        >>> print(f"Status: {result['overall_status']}")
    """
    start_time = datetime.now()

    print(f"[INFO] Generating compliance summary report (domain: {domain_filter or 'All'}, level: {audit_level})", file=sys.stderr)

    # Validate domain_filter
    if domain_filter and domain_filter not in DOMAIN_CI_CLASSES:
        return {
            "status": "error",
            "error": f"Invalid domain_filter: {domain_filter}. Must be one of: {list(DOMAIN_CI_CLASSES.keys())} or None",
            "valid_domains": list(DOMAIN_CI_CLASSES.keys())
        }

    try:
        # Assess each compliance dimension
        dimensions = {}

        print("[INFO] Assessing completeness dimension...", file=sys.stderr)
        dimensions["completeness"] = await _assess_completeness_dimension(client, domain_filter, audit_level)

        print("[INFO] Assessing correctness dimension...", file=sys.stderr)
        dimensions["correctness"] = await _assess_correctness_dimension(client, domain_filter, audit_level)

        print("[INFO] Assessing relationships dimension...", file=sys.stderr)
        dimensions["relationships"] = await _assess_relationships_dimension(client, domain_filter, audit_level)

        print("[INFO] Assessing staleness dimension...", file=sys.stderr)
        dimensions["staleness"] = await _assess_staleness_dimension(client, domain_filter, audit_level)

        print("[INFO] Assessing duplicates dimension...", file=sys.stderr)
        dimensions["duplicates"] = await _assess_duplicates_dimension(client, domain_filter, audit_level)

        # Calculate overall compliance score (weighted average)
        dimension_weights = {
            "completeness": 0.25,
            "correctness": 0.25,
            "relationships": 0.20,
            "staleness": 0.15,
            "duplicates": 0.15,
        }

        overall_score = sum(
            dimensions[dim]["score"] * weight
            for dim, weight in dimension_weights.items()
        )
        overall_status = _get_traffic_light_status(overall_score)

        # Identify critical issues (red status dimensions)
        critical_issues = []
        for dim_name, dim_data in dimensions.items():
            if dim_data["status"] == "red":
                critical_issues.append({
                    "dimension": dim_name,
                    "score": dim_data["score"],
                    "summary": dim_data["summary"],
                    "issues": dim_data.get("issues", [])[:5]  # Top 5 issues per dimension
                })

        # Generate recommendations
        recommendations = []
        if include_recommendations:
            if dimensions["completeness"]["status"] in ["red", "yellow"]:
                recommendations.append({
                    "priority": "high" if dimensions["completeness"]["status"] == "red" else "medium",
                    "dimension": "completeness",
                    "action": "Run bulk_update_missing_fields to populate required fields",
                    "impact": "Improve data completeness and CSDM compliance"
                })

            if dimensions["duplicates"]["status"] in ["red", "yellow"]:
                recommendations.append({
                    "priority": "high" if dimensions["duplicates"]["status"] == "red" else "medium",
                    "dimension": "duplicates",
                    "action": "Use audit_duplicate_cis to identify and merge_duplicate_cis to consolidate",
                    "impact": "Reduce duplicate records and improve data quality"
                })

            if dimensions["staleness"]["status"] in ["red", "yellow"]:
                recommendations.append({
                    "priority": "medium",
                    "dimension": "staleness",
                    "action": "Review stale CIs with audit_identify_stale_cis and retire inactive CIs",
                    "impact": "Maintain fresh, up-to-date CMDB data"
                })

            if dimensions["relationships"]["status"] in ["red", "yellow"]:
                recommendations.append({
                    "priority": "high" if dimensions["relationships"]["status"] == "red" else "medium",
                    "dimension": "relationships",
                    "action": "Use audit_validate_relationship_integrity and action_auto_heal_relationship_issues",
                    "impact": "Fix relationship integrity and improve CMDB connectivity"
                })

            if dimensions["correctness"]["status"] in ["red", "yellow"]:
                recommendations.append({
                    "priority": "high",
                    "dimension": "correctness",
                    "action": "Review field accuracy issues and update data validation rules",
                    "impact": "Improve overall data accuracy and trustworthiness"
                })

        # Sort recommendations by priority
        priority_order = {"high": 0, "medium": 1, "low": 2}
        recommendations.sort(key=lambda r: priority_order.get(r["priority"], 3))

        # Build domain breakdown (if no filter applied)
        domain_breakdown = {}
        if not domain_filter:
            for domain in DOMAIN_CI_CLASSES.keys():
                # Estimate domain score based on dimension scores
                # (In reality, would need to re-run assessments per domain)
                domain_breakdown[domain] = {
                    "estimated_score": round(overall_score, 1),  # Simplified for now
                    "status": overall_status
                }

        execution_time = (datetime.now() - start_time).total_seconds()

        # Build response
        result = {
            "status": "success",
            "overall_compliance_score": round(overall_score, 1),
            "overall_status": overall_status,
            "status_emoji": _get_status_emoji(overall_status),
            "dimensions": {
                dim_name: {
                    **dim_data,
                    "emoji": _get_status_emoji(dim_data["status"]),
                    "weight": dimension_weights[dim_name]
                }
                for dim_name, dim_data in dimensions.items()
            },
            "domain_breakdown": domain_breakdown if not domain_filter else None,
            "critical_issues_count": len(critical_issues),
            "critical_issues": critical_issues,
            "recommendations": recommendations if include_recommendations else None,
            "metadata": build_audit_metadata(
                audit_type="compliance_summary_report",
                audit_level=audit_level,
                execution_time=execution_time,
                domain_filter=domain_filter
            )
        }

        print(f"[INFO] Compliance summary complete: {overall_score:.1f}% ({overall_status}) in {execution_time:.2f}s", file=sys.stderr)

        return result

    except Exception as e:
        print(f"[ERROR] Compliance summary report failed: {e}", file=sys.stderr)
        return {
            "status": "error",
            "error": str(e),
        }
