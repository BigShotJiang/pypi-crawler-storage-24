"""Validate Model Hierarchy Tool

Validate software model parent/child structure and SBOM completeness.
Audit-level tool for model structure validation (read-only).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules

from servicenow_mcp.tools.cmdb.audit import utils
from servicenow_mcp.tools.cmdb.audit.utils import score_to_grade


async def validate_model_hierarchy(
    client: ServiceNowClient,
    *,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Validate software model parent/child hierarchy and SBOM completeness.

    Validates software CI model structure covering:
    - Model Hierarchy: Parent/child relationship integrity
    - Empty Models: Software models with no instances
    - Orphan CIs: Software CIs without parent models
    - SBOM Completeness: Software Bill of Materials presence
    - Business Application Mapping: Model → Application linkage

    Directly addresses Reddit pain point:
    "Software models always empty" and "No version tracking"

    Supports three audit levels:
    - quick: $0.15 - Hierarchy score only
    - standard: $0.50 - Score + issues + examples (RECOMMENDED)
    - deep: $1.50 - Full analysis with all metrics and remediation steps

    Args:
        client: ServiceNow client instance
        domain: CSDM domain filter
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary with model hierarchy validation:
        - hierarchy_score: Overall model structure health (0-100)
        - hierarchy_grade: Letter grade (A-F)
        - total_models: Software models in system
        - total_software_cis: Software CI instances
        - empty_models: Models with no instances
        - orphan_cis: CIs without parent models
        - missing_sbom: CIs lacking Software Bill of Materials
        - business_application_mapping: Model → Application linkage coverage
        - remediation_steps: Ordered improvement actions
    """

    try:
        csdm_rules = get_csdm_rules()
    except Exception as e:
        return {
            "status": "error",
            "error": f"Failed to load CSDM rules: {str(e)}",
        }

    # Analyze model hierarchy
    hierarchy = await _analyze_hierarchy_structure(client, audit_level)

    # Analyze empty models
    empty_models = await _analyze_empty_models(client, audit_level)

    # Analyze orphan software CIs
    orphan_cis = await _analyze_orphan_software_cis(client, audit_level)

    # Analyze SBOM coverage
    sbom_coverage = await _analyze_sbom_completeness(client, audit_level)

    # Analyze business application mapping
    ba_mapping = await _analyze_business_application_mapping(client, audit_level)

    # Calculate hierarchy score
    hierarchy_score = _calculate_hierarchy_score(
        hierarchy.get("valid_relationships_percent", 0),
        100 - (empty_models.get("count", 0) / max(1, hierarchy.get("total_models", 1)) * 100),
        100 - (orphan_cis.get("count", 0) / max(1, hierarchy.get("total_software_cis", 1)) * 100),
        sbom_coverage.get("coverage_percent", 0),
        ba_mapping.get("coverage_percent", 0),
    )

    hierarchy_grade = score_to_grade(hierarchy_score)

    # Generate remediation steps
    remediation_steps = _generate_remediation_steps(
        empty_models, orphan_cis, sbom_coverage, ba_mapping, audit_level
    )

    return {
        "hierarchy_score": round(hierarchy_score, 1),
        "hierarchy_grade": hierarchy_grade,
        "status_summary": _get_status_summary(hierarchy_grade),
        "model_structure": hierarchy,
        "empty_models": empty_models,
        "orphan_software_cis": orphan_cis,
        "sbom_completeness": sbom_coverage,
        "business_application_mapping": ba_mapping,
        "overall_health": {
            "model_quality": _assess_model_quality(empty_models, orphan_cis),
            "sbom_status": _assess_sbom_status(sbom_coverage),
            "ba_mapping_status": _assess_ba_mapping_status(ba_mapping),
        },
        "remediation_steps": remediation_steps,
        "audit_metadata": utils.build_audit_metadata(audit_level, hierarchy.get("total_models", 0), 0),
        "status": "success",
    }


async def _analyze_hierarchy_structure(
    client: ServiceNowClient,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Analyze overall software model hierarchy structure."""

    try:
        # Get all software models
        try:
            models_response = await client.get_table_records(
                table="cmdb_model",
                sysparm_fields="sys_id,name,parent,sys_class_name",
                sysparm_limit=5000,
            )
            models = models_response.get("result", []) or []
        except Exception as model_err:
            print(f"[WARN] cmdb_model table not available: {model_err}", flush=True)
            models = []

        total_models = len(models)

        # Get all software CIs (with fallback if table doesn't exist)
        software_cis = []
        try:
            software_response = await client.get_table_records(
                table="cmdb_ci_software",
                sysparm_fields="sys_id,name,model",
                sysparm_limit=5000,
            )
            software_cis = software_response.get("result", []) or []
        except Exception as sw_err:
            print(f"[WARN] cmdb_ci_software table not available: {sw_err}", flush=True)
            # No software CIs available in this instance
            software_cis = []

        total_software_cis = len(software_cis)

        # Analyze parent/child relationships
        models_with_parents = sum(1 for m in models if m.get("parent"))
        models_with_children = 0

        # Check which models have software CI instances
        ci_models = set()
        for ci in software_cis:
            model = ci.get("model")
            if model:
                model_id = model.get("value") if isinstance(model, dict) else str(model)
                ci_models.add(model_id)

        models_with_children = len(ci_models)
        valid_relationships = models_with_parents + models_with_children

        return {
            "total_models": total_models,
            "total_software_cis": total_software_cis,
            "models_with_parent": models_with_parents,
            "models_with_children": models_with_children,
            "valid_relationships_percent": round((valid_relationships / max(1, total_models) * 100), 1),
            "avg_software_cis_per_model": round(total_software_cis / max(1, total_models), 1),
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "total_models": 0,
            "total_software_cis": 0,
        }


async def _analyze_empty_models(
    client: ServiceNowClient,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Identify software models with no instances."""

    try:
        # Get all models
        models = []
        try:
            models_response = await client.get_table_records(
                table="cmdb_model",
                sysparm_fields="sys_id,name",
                sysparm_limit=5000,
            )
            models = models_response.get("result", []) or []
        except Exception as model_err:
            print(f"[WARN] cmdb_model table not available: {model_err}", flush=True)
            models = []

        total_models = len(models)

        # Get models that have software CI instances (with fallback)
        models_in_use = set()
        try:
            software_response = await client.get_table_records(
                table="cmdb_ci_software",
                sysparm_fields="model",
                sysparm_limit=5000,
            )

            software_cis = software_response.get("result", []) or []

            for ci in software_cis:
                model = ci.get("model")
                if model:
                    model_id = model.get("value") if isinstance(model, dict) else str(model)
                    models_in_use.add(model_id)
        except Exception as sw_err:
            print(f"[WARN] cmdb_ci_software table not available: {sw_err}", flush=True)
            # Can't check software CIs, assume no models in use
            models_in_use = set()

        # Models not in use are "empty"
        empty_count = total_models - len(models_in_use)
        empty_models_list = [m for m in models if m.get("sys_id") not in models_in_use]

        return {
            "count": empty_count,
            "percentage": round((empty_count / max(1, total_models) * 100), 1),
            "total_models": total_models,
            "examples": [
                {
                    "sys_id": m.get("sys_id"),
                    "name": m.get("name"),
                    "recommendation": "Link to existing software CIs or delete if obsolete",
                }
                for m in empty_models_list[:5]
            ] if audit_level in ["standard", "deep"] else [],
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "count": 0,
            "percentage": 0.0,
        }


async def _analyze_orphan_software_cis(
    client: ServiceNowClient,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Identify software CIs without parent models."""

    try:
        # Get software CIs without model reference
        orphan_cis = []
        total_software = 0

        try:
            orphan_query = "modelISEMPTY"
            orphan_response = await client.get_table_records(
                table="cmdb_ci_software",
                sysparm_query=orphan_query,
                sysparm_fields="sys_id,name,version",
                sysparm_limit=5000,
            )

            orphan_cis = orphan_response.get("result", []) or []

            # Get total software CIs
            total_response = await client.count_records("cmdb_ci_software")
            total_software = total_response[0] if isinstance(total_response, tuple) else total_response
        except Exception as sw_err:
            print(f"[WARN] cmdb_ci_software table not available: {sw_err}", flush=True)
            # Table doesn't exist - return with no orphans
            return {
                "count": 0,
                "percentage": 0.0,
                "total_software_cis": 0,
                "severity": "low",
            }

        orphan_count = len(orphan_cis)
        orphan_percent = (orphan_count / max(1, total_software) * 100)

        return {
            "count": orphan_count,
            "percentage": round(orphan_percent, 1),
            "total_software_cis": total_software,
            "examples": [
                {
                    "sys_id": ci.get("sys_id"),
                    "name": ci.get("name"),
                    "version": ci.get("version"),
                    "action": "Link to existing model or create new model",
                }
                for ci in orphan_cis[:5]
            ] if audit_level in ["standard", "deep"] else [],
            "severity": "critical" if orphan_percent > 20 else "high" if orphan_percent > 10 else "medium",
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "count": 0,
            "percentage": 0.0,
        }


async def _analyze_sbom_completeness(
    client: ServiceNowClient,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Analyze Software Bill of Materials completeness."""

    try:
        # Get software CIs
        try:
            total_response = await client.count_records("cmdb_ci_software")
            total_software = total_response[0] if isinstance(total_response, tuple) else total_response
        except Exception as sw_err:
            print(f"[WARN] cmdb_ci_software table not available: {sw_err}", flush=True)
            return {
                "total_software_cis": 0,
                "coverage_percent": 0.0,
                "assessment": "Minimal",
            }

        if total_software == 0:
            return {
                "total_software_cis": 0,
                "coverage_percent": 0.0,
                "assessment": "Minimal",
            }

        # Count software CIs with SBOM (simplified: check for version tracking, components, or artifacts)
        # In ServiceNow, SBOM might be indicated by presence of software artifacts table or field
        with_sbom_count = 0
        with_sbom_query = "cmdbSOFTWAREARTIFACT!EMPTY"  # Check for artifacts/components
        try:
            with_sbom_response = await client.count_records("cmdb_ci_software", sysparm_query=with_sbom_query)
            with_sbom_count = with_sbom_response[0] if isinstance(with_sbom_response, tuple) else with_sbom_response
        except Exception:
            # If artifact table doesn't exist, fall back to version check
            with_sbom_count = 0
            version_query = "versionISNOTEMPTY"
            try:
                version_response = await client.count_records("cmdb_ci_software", sysparm_query=version_query)
                with_sbom_count = version_response[0] if isinstance(version_response, tuple) else version_response
            except Exception:
                pass

        coverage_percent = (with_sbom_count / max(1, total_software) * 100)

        return {
            "total_software_cis": total_software,
            "software_cis_with_sbom": with_sbom_count,
            "coverage_percent": round(coverage_percent, 1),
            "assessment": "Complete" if coverage_percent >= 80 else "Partial" if coverage_percent >= 50 else "Minimal",
            "recommendation": _sbom_recommendation(coverage_percent),
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "coverage_percent": 0.0,
        }


async def _analyze_business_application_mapping(
    client: ServiceNowClient,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Analyze Model → Business Application mapping coverage."""

    try:
        # Get models with business application relationships
        models = []
        try:
            ba_response = await client.get_table_records(
                table="cmdb_model",
                sysparm_fields="sys_id,name",
                sysparm_limit=5000,
            )
            models = ba_response.get("result", []) or []
        except Exception as model_err:
            print(f"[WARN] cmdb_model table not available: {model_err}", flush=True)
            models = []

        total_models = len(models)

        # Check for relationships to business applications
        # In ServiceNow, this is typically through the "cmdb_rel_ci" table
        mapped_count = 0

        for model in models:
            model_id = model.get("sys_id")
            if model_id:
                # Query for relationships between this model and business applications
                rel_query = f"ci_item={model_id}&related_ci.sys_class_name=cmdb_ci_business_application"
                try:
                    rel_response = await client.count_records("cmdb_rel_ci", sysparm_query=rel_query)
                    rel_count = rel_response[0] if isinstance(rel_response, tuple) else rel_response
                    if rel_count > 0:
                        mapped_count += 1
                except Exception:
                    pass

        coverage_percent = (mapped_count / max(1, total_models) * 100) if total_models > 0 else 0

        return {
            "total_models": total_models,
            "models_mapped_to_applications": mapped_count,
            "coverage_percent": round(coverage_percent, 1),
            "assessment": "Complete" if coverage_percent >= 80 else "Partial" if coverage_percent >= 60 else "Minimal",
            "recommendation": "Link all models to business applications for impact analysis" if coverage_percent < 80 else "Mapping coverage is good",
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "coverage_percent": 0.0,
        }


def _calculate_hierarchy_score(
    relationship_health: float,
    model_population: float,
    orphan_mitigation: float,
    sbom_coverage: float,
    ba_mapping: float,
) -> float:
    """Calculate overall model hierarchy health score (weighted)."""
    # Weights: relationships (25%), model population (25%), orphan mitigation (20%), SBOM (15%), BA mapping (15%)
    score = (
        (relationship_health * 0.25) +
        (model_population * 0.25) +
        (orphan_mitigation * 0.20) +
        (sbom_coverage * 0.15) +
        (ba_mapping * 0.15)
    )
    return score


def _get_status_summary(grade: str) -> str:
    """Get human-readable status summary."""
    summaries = {
        "A": "🏆 Excellent model hierarchy structure. Well-organized and complete.",
        "B": "✅ Good model structure. Minor gaps to address.",
        "C": "⚠️  Fair model structure. Significant gaps need attention.",
        "D": "🔴 Poor model structure. Comprehensive remediation required.",
        "F": "🚨 Critical model issues. Immediate action needed.",
    }
    return summaries.get(grade, "Unknown")


def _assess_model_quality(empty_models: Dict, orphan_cis: Dict) -> str:
    """Assess overall model quality."""
    empty_pct = empty_models.get("percentage", 0)
    orphan_pct = orphan_cis.get("percentage", 0)

    if empty_pct < 10 and orphan_pct < 10:
        return "Excellent - Well-maintained model structure"
    if empty_pct < 20 and orphan_pct < 20:
        return "Good - Minor cleanup recommended"
    if empty_pct < 50 or orphan_pct < 50:
        return "Fair - Significant remediation needed"
    return "Poor - Critical issues require immediate attention"


def _assess_sbom_status(sbom: Dict) -> str:
    """Assess SBOM coverage status."""
    coverage = sbom.get("coverage_percent", 0)
    if coverage >= 80:
        return "✅ Complete SBOM tracking"
    if coverage >= 50:
        return "⚠️ Partial SBOM coverage - gaps exist"
    return "🔴 Minimal SBOM - add Bill of Materials to software CIs"


def _assess_ba_mapping_status(ba_mapping: Dict) -> str:
    """Assess Business Application mapping status."""
    coverage = ba_mapping.get("coverage_percent", 0)
    if coverage >= 80:
        return "✅ Good model-to-application linkage"
    if coverage >= 60:
        return "⚠️ Partial mapping - some models unlinked"
    return "🔴 Poor linkage - map models to business applications"


def _sbom_recommendation(coverage_percent: float) -> str:
    """Generate SBOM coverage recommendation."""
    if coverage_percent >= 80:
        return "Excellent SBOM coverage. Maintain current tracking."
    if coverage_percent >= 50:
        return "Implement SBOM for software CIs lacking it."
    return "Critical: Add Software Bill of Materials to all software CIs."


def _generate_remediation_steps(
    empty_models: Dict,
    orphan_cis: Dict,
    sbom_coverage: Dict,
    ba_mapping: Dict,
    audit_level: utils.AuditLevel,
) -> List[Dict[str, Any]]:
    """Generate prioritized remediation steps."""

    steps = []

    empty_pct = empty_models.get("percentage", 0)
    orphan_pct = orphan_cis.get("percentage", 0)
    sbom_pct = sbom_coverage.get("coverage_percent", 0)
    ba_pct = ba_mapping.get("coverage_percent", 0)

    # Prioritize by severity and effort
    if orphan_pct > 10:
        steps.append({
            "priority": 1,
            "title": "Link Orphan Software CIs to Models",
            "issue": f"{orphan_cis.get('count', 0)} software CIs without parent models ({orphan_pct:.0f}%)",
            "severity": orphan_cis.get("severity", "high"),
            "effort": "2-3 days",
            "action": "1. Review orphan CIs\n2. Create missing models or link to existing\n3. Validate parent-child relationships",
            "estimated_impact": "+15-20% hierarchy score",
        })

    if empty_pct > 15:
        steps.append({
            "priority": 2,
            "title": "Clean Up Empty Models",
            "issue": f"{empty_models.get('count', 0)} models with no instances ({empty_pct:.0f}%)",
            "severity": "medium",
            "effort": "1-2 days",
            "action": "1. Review empty models\n2. Link to existing CIs or delete obsolete models\n3. Document model retention policy",
            "estimated_impact": "+10-15% hierarchy score",
        })

    if sbom_pct < 70:
        steps.append({
            "priority": 3,
            "title": "Implement SBOM Tracking",
            "issue": f"Only {sbom_coverage.get('software_cis_with_sbom', 0)} of {sbom_coverage.get('total_software_cis', 0)} CIs have SBOM ({sbom_pct:.0f}%)",
            "severity": "medium",
            "effort": "3-5 days",
            "action": "1. Define SBOM tracking standard\n2. Bulk import SBOM data from discovery\n3. Establish CI scanning/update process",
            "estimated_impact": "+10-12% hierarchy score",
        })

    if ba_pct < 70:
        steps.append({
            "priority": 4,
            "title": "Map Models to Business Applications",
            "issue": f"Only {ba_mapping.get('models_mapped_to_applications', 0)} of {ba_mapping.get('total_models', 0)} models linked to applications ({ba_pct:.0f}%)",
            "severity": "low",
            "effort": "2-3 days",
            "action": "1. Identify business applications\n2. Create model-to-BA relationships\n3. Enable impact analysis workflows",
            "estimated_impact": "+8-10% hierarchy score",
        })

    # Include all steps in deep audit
    if audit_level == "quick":
        return steps[:2]  # Top 2 priorities
    elif audit_level == "standard":
        return steps[:3]  # Top 3 priorities
    else:
        return steps  # All steps
