"""
Compliance Metadata Utilities

Provides standardized compliance metadata for all governance tools.
Supports GDPR, SOX, DORA, PCI-DSS, HIPAA, and ITIL v4 compliance frameworks.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
import json
import os


# ==============================================================================
# Compliance Framework Definitions
# ==============================================================================

COMPLIANCE_FRAMEWORKS = {
    "GDPR": {
        "name": "General Data Protection Regulation",
        "jurisdiction": "European Union",
        "applicability": "Organizations processing EU personal data",
        "key_requirements": [
            "Article 30: Records of processing activities",
            "Article 32: Security of processing",
            "Article 33: Data breach notification (72 hours)",
            "Article 35: Data protection impact assessment"
        ],
        "penalties": "Up to €20M or 4% of annual global turnover (whichever is higher)",
        "url": "https://gdpr.eu"
    },
    "SOX": {
        "name": "Sarbanes-Oxley Act",
        "jurisdiction": "United States",
        "applicability": "Publicly traded companies",
        "key_requirements": [
            "Section 302: Corporate responsibility for financial reports",
            "Section 404: Management assessment of internal controls",
            "Section 802: Document retention (7 years)",
            "Section 906: Criminal penalties for financial fraud"
        ],
        "penalties": "Up to $5M fines and 20 years imprisonment",
        "url": "https://www.sarbanes-oxley-101.com"
    },
    "DORA": {
        "name": "Digital Operational Resilience Act",
        "jurisdiction": "European Union",
        "applicability": "Financial institutions and ICT service providers",
        "key_requirements": [
            "Article 6: ICT risk management framework",
            "Article 11: Testing of ICT systems (annually)",
            "Article 23: ICT-related incident reporting",
            "Article 28: ICT third-party risk management"
        ],
        "penalties": "Up to €10M or 5% of annual turnover",
        "url": "https://www.digital-operational-resilience-act.com"
    },
    "PCI-DSS": {
        "name": "Payment Card Industry Data Security Standard",
        "jurisdiction": "Global",
        "applicability": "Organizations processing payment card data",
        "key_requirements": [
            "Requirement 3: Protect stored cardholder data",
            "Requirement 8: Identify and authenticate access",
            "Requirement 10: Track and monitor network access",
            "Requirement 12: Information security policy"
        ],
        "penalties": "Card brand fines ($5k-$100k per month) + liability for fraud",
        "url": "https://www.pcisecuritystandards.org"
    },
    "HIPAA": {
        "name": "Health Insurance Portability and Accountability Act",
        "jurisdiction": "United States",
        "applicability": "Healthcare providers, insurers, and business associates",
        "key_requirements": [
            "Privacy Rule: Protected health information (PHI) safeguards",
            "Security Rule: Electronic PHI (ePHI) security standards",
            "Breach Notification Rule: 60-day breach reporting",
            "Enforcement Rule: Penalties for non-compliance"
        ],
        "penalties": "Up to $1.5M per year per violation category",
        "url": "https://www.hhs.gov/hipaa"
    },
    "ITIL_V4": {
        "name": "Information Technology Infrastructure Library v4",
        "jurisdiction": "Global (best practice framework)",
        "applicability": "IT service management organizations",
        "key_requirements": [
            "Service Value System: Guiding principles",
            "Continual Improvement: Ongoing optimization",
            "Configuration Management: CMDB accuracy and completeness",
            "Change Control: Risk assessment and approval"
        ],
        "penalties": "None (best practice framework, not regulatory)",
        "url": "https://www.axelos.com/certifications/itil-service-management"
    }
}


# ==============================================================================
# Tool Compliance Mappings
# ==============================================================================

TOOL_COMPLIANCE_MAPPINGS = {
    "audit_ci_mandatory_fields_compliance": {
        "frameworks": ["GDPR", "DORA", "ITIL_V4"],
        "standards": [
            "GDPR Article 30 (data completeness)",
            "DORA Article 6 (ICT asset inventory)",
            "ITIL v4 Configuration Management"
        ],
        "use_cases": [
            "Demonstrate CMDB data completeness for auditors",
            "Generate field gap reports for remediation",
            "Track data quality KPIs over time"
        ]
    },
    "audit_ci_duplicate_merge_confidence": {
        "frameworks": ["GDPR", "ITIL_V4"],
        "standards": [
            "GDPR Article 5 (data accuracy principle)",
            "ITIL v4 Configuration Management (duplicate prevention)"
        ],
        "use_cases": [
            "Prevent duplicate CI data (GDPR accuracy requirement)",
            "Automated merge candidate detection",
            "Data quality improvement workflows"
        ]
    },
    "audit_ci_policy_violation_score": {
        "frameworks": ["GDPR", "SOX", "DORA", "ITIL_V4"],
        "standards": [
            "GDPR Article 32 (security of processing)",
            "SOX Section 404 (internal controls)",
            "DORA Article 6 (governance framework)",
            "ITIL v4 Service Design (policy compliance)"
        ],
        "use_cases": [
            "Policy compliance audits for governance boards",
            "SOX 404 internal control validation",
            "GDPR security policy enforcement"
        ]
    },
    "audit_ci_retention_flags": {
        "frameworks": ["GDPR", "SOX", "DORA", "HIPAA"],
        "standards": [
            "GDPR Article 5 (storage limitation principle)",
            "SOX Section 802 (7-year document retention)",
            "DORA Article 6 (data retention policies)",
            "HIPAA Privacy Rule (6-year retention minimum)"
        ],
        "use_cases": [
            "Automated data retention policy enforcement",
            "GDPR right to erasure compliance",
            "SOX document retention validation"
        ]
    },
    "audit_ci_confidentiality_tags": {
        "frameworks": ["GDPR", "DORA", "PCI-DSS", "HIPAA"],
        "standards": [
            "GDPR Article 30 (records of processing activities)",
            "GDPR Article 32 (appropriate security measures)",
            "DORA Article 6 (ICT risk classification)",
            "PCI-DSS Requirement 3 (protect cardholder data)",
            "HIPAA Security Rule (ePHI classification)"
        ],
        "use_cases": [
            "GDPR Article 30 data processing registry",
            "DORA ICT risk classification audits",
            "PCI-DSS data discovery and classification",
            "HIPAA ePHI identification"
        ]
    }
}


# ==============================================================================
# Metadata Builder Functions
# ==============================================================================

def build_compliance_metadata(
    tool_name: str,
    user: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
    include_frameworks: bool = True,
    include_audit_trail: bool = True
) -> Dict[str, Any]:
    """
    Build standardized compliance metadata for a tool execution.

    Args:
        tool_name: Name of the tool (e.g., 'audit_ci_mandatory_fields_compliance')
        user: Username who executed the tool (if available)
        parameters: Tool parameters used in execution
        include_frameworks: Include detailed framework information
        include_audit_trail: Include audit trail metadata

    Returns:
        Dictionary with compliance metadata
    """
    metadata = {
        "tool_name": tool_name,
        "execution_timestamp": datetime.utcnow().isoformat() + "Z",
    }

    # Add compliance frameworks
    if include_frameworks and tool_name in TOOL_COMPLIANCE_MAPPINGS:
        mapping = TOOL_COMPLIANCE_MAPPINGS[tool_name]

        metadata["compliance_frameworks"] = []
        for framework in mapping["frameworks"]:
            if framework in COMPLIANCE_FRAMEWORKS:
                framework_info = COMPLIANCE_FRAMEWORKS[framework]
                metadata["compliance_frameworks"].append({
                    "code": framework,
                    "name": framework_info["name"],
                    "applicability": framework_info["applicability"],
                    "key_requirements": framework_info["key_requirements"][:2],  # Top 2 requirements
                    "url": framework_info["url"]
                })

        metadata["compliance_standards"] = mapping["standards"]
        metadata["compliance_use_cases"] = mapping["use_cases"]

    # Add audit trail
    if include_audit_trail:
        metadata["audit_trail"] = {
            "executed_by": user or "system",
            "execution_timestamp": datetime.utcnow().isoformat() + "Z",
            "parameters": parameters or {},
            "hostname": os.getenv("HOSTNAME", "unknown"),
            "environment": os.getenv("ENVIRONMENT", "production"),
        }

    return metadata


def build_export_metadata(
    tool_name: str,
    export_format: str,
    record_count: int,
    filters_applied: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Build metadata for exported compliance reports.

    Args:
        tool_name: Name of the tool
        export_format: Export format (csv, json, etc.)
        record_count: Number of records in export
        filters_applied: Filters applied during execution

    Returns:
        Dictionary with export metadata
    """
    return {
        "export_timestamp": datetime.utcnow().isoformat() + "Z",
        "export_format": export_format,
        "tool_name": tool_name,
        "record_count": record_count,
        "filters_applied": filters_applied or {},
        "generated_by": "ServiceNow AI MCP - Governance Tools",
        "format_version": "1.0"
    }


def get_framework_requirements(framework: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed requirements for a specific compliance framework.

    Args:
        framework: Framework code (GDPR, SOX, DORA, etc.)

    Returns:
        Framework information dictionary, or None if not found
    """
    return COMPLIANCE_FRAMEWORKS.get(framework)


def get_tool_frameworks(tool_name: str) -> List[str]:
    """
    Get list of compliance frameworks supported by a tool.

    Args:
        tool_name: Name of the tool

    Returns:
        List of framework codes
    """
    if tool_name in TOOL_COMPLIANCE_MAPPINGS:
        return TOOL_COMPLIANCE_MAPPINGS[tool_name]["frameworks"]
    return []
