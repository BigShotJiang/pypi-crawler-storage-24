"""
Tool #3: audit_ci_policy_violation_score

Detects governance policy violations across CMDB CIs and generates weighted severity scores.
Part of Phase 2B Governance Execution Plan - Compliance Validator tier.

This tool identifies:
- Missing business context (owner, support group, criticality)
- Environment misclassification (prod CIs in dev, critical CIs marked low)
- Naming convention violations
- Data quality gaps (orphaned CIs, missing discovery data)
- Compliance gaps (audit trail, security classifications)

Enterprise Value:
- Enables policy compliance KPIs for CIOs
- Generates violation reports for governance boards
- Prioritizes remediation by business risk
- Feeds compliance scorecards (SOX, DORA, GDPR)
"""

from typing import Any, Dict, List, Optional
import re
from datetime import datetime, timedelta

from servicenow_mcp.servicenow import ServiceNowClient
from . import utils


# ==============================================================================
# Policy Violation Configuration
# ==============================================================================

# Naming convention patterns (configurable per organization)
NAMING_CONVENTIONS = {
    "cmdb_ci_server": {
        "pattern": r"^[a-z]{3}-[a-z]{3,4}-[a-z0-9]{3,6}-\d{2,4}$",
        "description": "Format: env-type-function-number (e.g., prd-app-web-001)",
        "examples": ["prd-app-web-001", "dev-db-mysql-1234"]
    },
    "cmdb_ci_application": {
        "pattern": r"^[A-Z]{2,4}[_-][A-Za-z0-9]+$",
        "description": "Format: PREFIX_ApplicationName (e.g., ERP_Salesforce)",
        "examples": ["ERP_Salesforce", "ITSM_ServiceNow"]
    },
    "cmdb_ci_database": {
        "pattern": r"^[a-z]{3}-db-[a-z0-9]{3,8}-\d{2,4}$",
        "description": "Format: env-db-type-number (e.g., prd-db-oracle-001)",
        "examples": ["prd-db-oracle-001", "dev-db-mysql-0042"]
    }
}

# Environment classification rules
ENVIRONMENT_RULES = {
    "production": {
        "expected_criticality": ["1 - Critical", "2 - High"],
        "allowed_status": ["1 - Installed", "2 - In Use"],
        "keywords": ["prod", "production", "live"]
    },
    "development": {
        "expected_criticality": ["3 - Medium", "4 - Low"],
        "allowed_status": ["1 - Installed", "2 - In Use", "3 - Retired"],
        "keywords": ["dev", "development", "test", "uat", "staging"]
    }
}

# Required business fields by CI class
REQUIRED_BUSINESS_FIELDS = {
    "cmdb_ci_server": ["owned_by", "support_group", "business_criticality", "cost_center", "environment"],
    "cmdb_ci_application": ["owned_by", "support_group", "business_criticality", "u_business_owner"],
    "cmdb_ci_database": ["owned_by", "support_group", "business_criticality", "cost_center"],
    "cmdb_ci_service": ["owned_by", "support_group", "business_criticality", "service_owner"],
}

# Default required fields for all CI classes
DEFAULT_REQUIRED_BUSINESS_FIELDS = ["owned_by", "support_group", "business_criticality"]


# ==============================================================================
# Violation Detection Functions
# ==============================================================================

def detect_missing_business_context(ci_record: Dict[str, Any], ci_class: str) -> List[Dict[str, Any]]:
    """
    Detect missing critical business fields.

    Severity: Critical (owner, support_group), High (others)
    """
    violations = []
    required_fields = REQUIRED_BUSINESS_FIELDS.get(ci_class, DEFAULT_REQUIRED_BUSINESS_FIELDS)

    for field in required_fields:
        value = ci_record.get(field, "")

        # Check if field is empty or null
        if not value or str(value).strip() == "" or value == "null":
            severity = "critical" if field in ["owned_by", "support_group"] else "high"
            violations.append({
                "type": "missing_business_context",
                "severity": severity,
                "field": field,
                "description": f"Missing required business field: {field}",
                "ci_name": ci_record.get("name", "Unknown"),
                "ci_sys_id": ci_record.get("sys_id", ""),
                "impact": "Prevents ownership tracking and SLA enforcement" if field == "owned_by" else "Reduces data completeness"
            })

    return violations


def detect_environment_misclassification(ci_record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Detect environment/criticality mismatches.

    Severity: High (production CIs with low criticality)
    """
    violations = []

    environment = str(ci_record.get("environment", "")).lower()
    criticality = str(ci_record.get("business_criticality", ""))
    install_status = str(ci_record.get("install_status", ""))
    name = str(ci_record.get("name", "")).lower()

    # Check if production CI has low criticality
    is_production = any(keyword in environment or keyword in name
                       for keyword in ENVIRONMENT_RULES["production"]["keywords"])

    if is_production:
        if criticality in ["3 - Medium", "4 - Low", "5 - Planning", ""]:
            violations.append({
                "type": "environment_misclassification",
                "severity": "high",
                "field": "business_criticality",
                "description": f"Production CI has low/missing criticality: {criticality or 'Not Set'}",
                "ci_name": ci_record.get("name", "Unknown"),
                "ci_sys_id": ci_record.get("sys_id", ""),
                "environment": environment or name,
                "current_criticality": criticality,
                "expected_criticality": "1 - Critical or 2 - High",
                "impact": "SLA breaches and incorrect incident prioritization"
            })

    # Check if active production CI is marked as retired
    if is_production and install_status in ["7 - Retired", "8 - Disposed"]:
        violations.append({
            "type": "environment_misclassification",
            "severity": "high",
            "field": "install_status",
            "description": f"Production CI marked as {install_status}",
            "ci_name": ci_record.get("name", "Unknown"),
            "ci_sys_id": ci_record.get("sys_id", ""),
            "current_status": install_status,
            "expected_status": "1 - Installed or 2 - In Use",
            "impact": "Prevents accurate inventory and impact analysis"
        })

    return violations


def detect_naming_convention_violations(ci_record: Dict[str, Any], ci_class: str) -> List[Dict[str, Any]]:
    """
    Detect naming convention violations.

    Severity: Medium (reduces discoverability and standardization)
    """
    violations = []

    # Only check if naming convention is defined for this CI class
    if ci_class not in NAMING_CONVENTIONS:
        return violations

    convention = NAMING_CONVENTIONS[ci_class]
    ci_name = str(ci_record.get("name", ""))

    if not ci_name:
        violations.append({
            "type": "naming_convention_violation",
            "severity": "medium",
            "field": "name",
            "description": "CI name is empty",
            "ci_name": ci_record.get("name", "Unknown"),
            "ci_sys_id": ci_record.get("sys_id", ""),
            "impact": "Prevents CI identification and automation"
        })
        return violations

    # Check if name matches pattern
    pattern = convention["pattern"]
    if not re.match(pattern, ci_name):
        violations.append({
            "type": "naming_convention_violation",
            "severity": "medium",
            "field": "name",
            "description": f"Name does not match convention: {convention['description']}",
            "ci_name": ci_name,
            "ci_sys_id": ci_record.get("sys_id", ""),
            "current_name": ci_name,
            "expected_pattern": convention["description"],
            "examples": convention["examples"],
            "impact": "Reduces automation effectiveness and increases manual errors"
        })

    return violations


def detect_data_quality_gaps(ci_record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Detect data quality issues.

    Severity: High (missing discovery data), Medium (missing audit fields)
    """
    violations = []

    # Check discovery staleness
    last_discovered = ci_record.get("last_discovered", "")
    if last_discovered:
        try:
            discovered_date = datetime.strptime(last_discovered.split(" ")[0], "%Y-%m-%d")
            days_since_discovery = (datetime.now() - discovered_date).days

            if days_since_discovery > 90:  # 90 days threshold
                violations.append({
                    "type": "data_quality_gap",
                    "severity": "high",
                    "field": "last_discovered",
                    "description": f"CI not discovered in {days_since_discovery} days (stale data)",
                    "ci_name": ci_record.get("name", "Unknown"),
                    "ci_sys_id": ci_record.get("sys_id", ""),
                    "last_discovered": last_discovered,
                    "days_stale": days_since_discovery,
                    "impact": "Data may be inaccurate or outdated"
                })
        except (ValueError, AttributeError):
            pass  # Invalid date format, skip
    else:
        # Never discovered
        violations.append({
            "type": "data_quality_gap",
            "severity": "medium",
            "field": "last_discovered",
            "description": "CI has never been discovered (manual entry)",
            "ci_name": ci_record.get("name", "Unknown"),
            "ci_sys_id": ci_record.get("sys_id", ""),
            "impact": "Cannot verify CI accuracy through automated discovery"
        })

    # Check for missing audit trail
    updated_by = ci_record.get("sys_updated_by", "")
    if not updated_by or updated_by == "system":
        violations.append({
            "type": "data_quality_gap",
            "severity": "medium",
            "field": "sys_updated_by",
            "description": "Missing audit trail (no user attribution)",
            "ci_name": ci_record.get("name", "Unknown"),
            "ci_sys_id": ci_record.get("sys_id", ""),
            "impact": "Cannot track who made changes for compliance"
        })

    return violations


def detect_compliance_gaps(ci_record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Detect compliance-related gaps.

    Severity: Critical (missing security classification for sensitive data)
    """
    violations = []

    # Check for missing security classification on servers/databases
    ci_class = ci_record.get("sys_class_name", "")
    if ci_class in ["cmdb_ci_server", "cmdb_ci_database"]:
        security_classification = ci_record.get("u_security_classification", "")

        if not security_classification:
            violations.append({
                "type": "compliance_gap",
                "severity": "critical",
                "field": "u_security_classification",
                "description": "Missing security classification (required for GDPR/SOX)",
                "ci_name": ci_record.get("name", "Unknown"),
                "ci_sys_id": ci_record.get("sys_id", ""),
                "impact": "GDPR/SOX compliance violation - cannot determine data sensitivity"
            })

    return violations


# ==============================================================================
# Scoring Algorithm
# ==============================================================================

def calculate_violation_score(violations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Calculate overall policy violation score.

    Scoring:
    - Start at 100 points
    - Critical violation: -10 points
    - High violation: -5 points
    - Medium violation: -2 points
    - Low violation: -1 point
    - Minimum score: 0
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)
    """
    score = 100
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    severity_penalties = {"critical": 10, "high": 5, "medium": 2, "low": 1}

    for violation in violations:
        severity = violation.get("severity", "low")
        severity_counts[severity] += 1
        score -= severity_penalties.get(severity, 1)

    # Cap at 0 (cannot go negative)
    score = max(0, score)

    # Calculate grade
    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 50:
        grade = "D"
    else:
        grade = "F"

    return {
        "policy_violation_score": score,
        "grade": grade,
        "total_violations": len(violations),
        "violations_by_severity": severity_counts,
        "points_deducted": {
            "critical": severity_counts["critical"] * severity_penalties["critical"],
            "high": severity_counts["high"] * severity_penalties["high"],
            "medium": severity_counts["medium"] * severity_penalties["medium"],
            "low": severity_counts["low"] * severity_penalties["low"],
        }
    }


# ==============================================================================
# Main Tool Function
# ==============================================================================

async def audit_ci_policy_violation_score(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
    include_remediation_plan: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit governance policy violations across CMDB CIs.

    Detects violations in:
    - Business context (missing owner, support group, criticality)
    - Environment classification (prod CIs with low criticality)
    - Naming conventions (non-standard formats)
    - Data quality (stale discovery, missing audit trail)
    - Compliance (missing security classifications)

    **ENTERPRISE VALUE:**
    - Enables policy compliance KPIs for CIOs
    - Generates violation reports for governance boards
    - Prioritizes remediation by business risk
    - Feeds compliance scorecards (SOX, DORA, GDPR)

    **SCORING ALGORITHM:**
    - Start at 100 points
    - Critical violations: -10 points each (owner, support group, security classification)
    - High violations: -5 points each (environment misclassification, stale data)
    - Medium violations: -2 points each (naming conventions, missing audit trail)
    - Low violations: -1 point each
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)

    WHEN TO USE:
    - "What policy violations exist in our CMDB?"
    - "Show me CIs missing owners or support groups"
    - "Which production CIs have incorrect criticality?"
    - "Generate a governance compliance report"

    AUDIT LEVELS:
    - quick: Sample-based scan (100 CIs), violation counts only
    - standard: Full scan with top violations (RECOMMENDED)
    - deep: Full scan with detailed remediation plan

    Args:
        client: ServiceNow client instance
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server')
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_remediation_plan: Include prioritized remediation recommendations
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - policy_violation_score: Overall compliance score (0-100)
        - grade: Letter grade (A-F)
        - total_violations: Total violation count
        - violations_by_severity: Breakdown by critical/high/medium/low
        - violations_by_type: Breakdown by violation category
        - top_violations: Top 50 violations sorted by severity
        - cis_with_violations: Count of CIs with at least one violation
        - violation_rate: Percentage of CIs with violations
        - remediation_priority: Ordered list of fixes (if include_remediation_plan=True)
        - audit_metadata: Execution details and coverage
    """
    start_time = datetime.now()

    # Determine CI class to audit
    if not ci_class:
        ci_class = "cmdb_ci_server"  # Default to servers

    # Build query
    query_params = {}
    if audit_level == "quick":
        limit = sample_limit or 100
    else:
        limit = 10000  # Large enough for most audits

    # Fetch CIs
    try:
        response = await client.query_table(
            table=ci_class,
            query="",
            fields=[
                "sys_id", "name", "sys_class_name", "owned_by", "support_group",
                "business_criticality", "cost_center", "environment", "install_status",
                "last_discovered", "sys_updated_by", "u_security_classification",
                "u_business_owner"
            ],
            limit=limit
        )

        # query_table returns a list directly, not {"result": [...]}
        cis = response
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "policy_violation_score": 100,
                "grade": "A",
                "total_violations": 0,
                "total_cis": 0,
                "message": f"No CIs found in {ci_class}"
            }

        # Detect violations across all CIs
        all_violations = []
        cis_with_violations = set()
        violations_by_type = {
            "missing_business_context": 0,
            "environment_misclassification": 0,
            "naming_convention_violation": 0,
            "data_quality_gap": 0,
            "compliance_gap": 0,
        }

        for ci in cis:
            ci_violations = []

            # Run violation detection
            ci_violations.extend(detect_missing_business_context(ci, ci_class))
            ci_violations.extend(detect_environment_misclassification(ci))
            ci_violations.extend(detect_naming_convention_violations(ci, ci_class))
            ci_violations.extend(detect_data_quality_gaps(ci))
            ci_violations.extend(detect_compliance_gaps(ci))

            if ci_violations:
                cis_with_violations.add(ci.get("sys_id"))
                all_violations.extend(ci_violations)

                # Count by type
                for violation in ci_violations:
                    vtype = violation.get("type", "unknown")
                    if vtype in violations_by_type:
                        violations_by_type[vtype] += 1

        # Calculate overall score
        scoring_result = calculate_violation_score(all_violations)

        # Sort violations by severity for top violations
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sorted_violations = sorted(
            all_violations,
            key=lambda v: (severity_order.get(v.get("severity", "low"), 4), v.get("ci_name", ""))
        )

        # Limit top violations based on audit level
        if audit_level == "quick":
            top_violations = sorted_violations[:10]
        elif audit_level == "standard":
            top_violations = sorted_violations[:50]
        else:  # deep
            top_violations = sorted_violations[:200]

        # Build remediation plan
        remediation_priority = []
        if include_remediation_plan and audit_level in ["standard", "deep"]:
            remediation_priority = build_remediation_plan(all_violations, audit_level)

        # Calculate violation rate
        violation_rate = (len(cis_with_violations) / total_cis * 100) if total_cis > 0 else 0

        # Build result
        result = {
            "status": "success",
            "ci_class": ci_class,
            "policy_violation_score": scoring_result["policy_violation_score"],
            "grade": scoring_result["grade"],
            "total_violations": scoring_result["total_violations"],
            "total_cis": total_cis,
            "cis_with_violations": len(cis_with_violations),
            "violation_rate": round(violation_rate, 1),
            "violations_by_severity": scoring_result["violations_by_severity"],
            "points_deducted": scoring_result["points_deducted"],
            "violations_by_type": violations_by_type,
            "top_violations": top_violations,
        }

        # Add remediation plan if requested
        if remediation_priority:
            result["remediation_priority"] = remediation_priority

        # Add audit metadata with compliance information
        end_time = datetime.now()
        duration_seconds = (end_time - start_time).total_seconds()

        result["audit_metadata"] = utils.build_audit_metadata(
            audit_level=audit_level,
            total_records=total_cis,
            sampled_records=total_cis,
            tool_name="audit_ci_policy_violation_score",
            parameters={
                "ci_class": ci_class,
                "domain": domain,
                "audit_level": audit_level,
                "include_remediation_plan": include_remediation_plan,
            }
        )
        result["audit_metadata"]["execution_time_seconds"] = round(duration_seconds, 2)
        result["audit_metadata"]["coverage"] = f"{total_cis} CIs scanned"

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
        }


def build_remediation_plan(violations: List[Dict[str, Any]], audit_level: str) -> List[Dict[str, Any]]:
    """
    Build prioritized remediation plan based on violations.

    Priority:
    1. Critical violations (owner, support group, security classification)
    2. High violations (environment misclassification, stale data)
    3. Medium violations (naming conventions, audit trail)
    4. Low violations (other gaps)
    """
    # Group violations by type and severity
    remediation_items = []

    # Count violations by type and severity
    violation_summary = {}
    for violation in violations:
        vtype = violation.get("type")
        severity = violation.get("severity")
        key = f"{severity}_{vtype}"

        if key not in violation_summary:
            violation_summary[key] = {
                "type": vtype,
                "severity": severity,
                "count": 0,
                "affected_fields": set(),
                "sample_cis": []
            }

        violation_summary[key]["count"] += 1
        violation_summary[key]["affected_fields"].add(violation.get("field", "unknown"))

        # Add sample CIs (limit to 5 per violation type)
        if len(violation_summary[key]["sample_cis"]) < 5:
            violation_summary[key]["sample_cis"].append({
                "ci_name": violation.get("ci_name"),
                "ci_sys_id": violation.get("ci_sys_id"),
                "description": violation.get("description"),
            })

    # Convert to remediation items and sort by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    for key, summary in violation_summary.items():
        remediation_items.append({
            "priority": severity_order.get(summary["severity"], 4),
            "severity": summary["severity"],
            "violation_type": summary["type"],
            "count": summary["count"],
            "affected_fields": list(summary["affected_fields"]),
            "recommended_action": get_remediation_action(summary["type"], summary["severity"]),
            "sample_violations": summary["sample_cis"] if audit_level == "deep" else summary["sample_cis"][:2],
            "estimated_effort": estimate_effort(summary["count"], summary["severity"]),
        })

    # Sort by priority (severity first, then count)
    remediation_items.sort(key=lambda x: (x["priority"], -x["count"]))

    return remediation_items


def get_remediation_action(violation_type: str, severity: str) -> str:
    """Get recommended remediation action for violation type."""
    actions = {
        "missing_business_context": "Populate missing business fields through bulk update or assignment rules",
        "environment_misclassification": "Correct environment tags and criticality levels; review naming standards",
        "naming_convention_violation": "Rename CIs to match organizational standards; update automation scripts",
        "data_quality_gap": "Re-run discovery on stale CIs; enable automated discovery schedules",
        "compliance_gap": "Add security classifications; enable audit logging; review change management process",
    }
    return actions.get(violation_type, "Review and remediate violations manually")


def estimate_effort(violation_count: int, severity: str) -> str:
    """Estimate remediation effort based on count and severity."""
    if violation_count < 10:
        effort = "Low (manual fix)"
    elif violation_count < 50:
        effort = "Medium (batch update)"
    elif violation_count < 200:
        effort = "High (automation recommended)"
    else:
        effort = "Very High (requires automation)"

    if severity == "critical":
        effort += " - URGENT"

    return effort
