"""
Suggest CI Relationship Mappings Tool

Suggest new CI relationship mappings based on patterns in your CMDB.
Audit-level tool for relationship discovery and CSDM maturity (free).
"""

import sys
from typing import Any, Dict, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, sample_limit_for_audit_level


async def suggest_ci_relationship_mappings(
    client: ServiceNowClient,
    source_ci_class: str = "cmdb_ci_server",
    target_ci_class: Optional[str] = None,
    limit: int = 20,
    confidence_threshold: str = "medium",
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Suggest new CI relationship mappings based on patterns in your CMDB.

    Analyzes existing relationships and CI attributes to recommend new
    connections that are likely missing. Uses pattern matching to identify
    CIs that should be related but aren't yet.

    WHEN TO USE:
    - "Find missing server-to-database relationships"
    - "Suggest mappings for our 50 unlinked applications"
    - "Identify CIs that should be related but aren't"

    CSDM PHASE: CONSUME (relationship mapping & dependency analysis)

    AUDIT LEVELS:
    - quick: $0.20 - Count only
    - standard: $0.60 - Count + high-confidence suggestions (RECOMMENDED)
    - deep: $1.40 - Full mapping with all confidence levels

    Args:
        client: ServiceNow client instance
        source_ci_class: Source CI class to analyze (e.g., 'cmdb_ci_server')
        target_ci_class: Target CI class (e.g., 'cmdb_ci_database', None for all)
        limit: Max suggestions to return (default: 20)
        confidence_threshold: Minimum confidence: 'high', 'medium' (default), 'low'
        audit_level: Analysis depth: 'quick', 'standard', or 'deep'

    Returns:
        Dictionary containing:
        - source_class: Source CI class analyzed
        - target_classes: Target classes included
        - unmapped_pairs: CIs that should likely be related
        - mapping_suggestions: Suggested relationships with reasoning
        - confidence_breakdown: Distribution of confidence levels
        - estimated_relationship_improvement: % improvement in coverage
        - next_steps: How to apply suggested mappings
        - status: success/error
        - audit_metadata: Cost and coverage information

    EXAMPLE OUTPUT:
        "Analyzed 40 servers. Found 15 missing database relationships.
         Suggestions: server-prod-db1 -> database-prod (high confidence, 92%)
         Expected coverage improvement: +3.4%"
    """
    try:
        # ENHANCEMENT: Load CSDM relationship rules for source CI class
        csdm_rules = get_csdm_rules()
        source_relationships = csdm_rules.get_relationship_rules(source_ci_class)

        # Build mapping of target patterns to relationship types from CSDM rules
        csdm_rel_type_map = {}
        if source_relationships:
            print(f"[suggest_ci_relationship_mappings] Found {len(source_relationships)} CSDM relationships for {source_ci_class}", file=sys.stderr)
            # Use ALL CSDM relationships, not just top 5
            for target_class, rel_info in source_relationships.items():
                rel_type = rel_info.get("type", "unknown")
                print(f"  - {source_ci_class} -> {target_class}: {rel_type}", file=sys.stderr)
                # Extract simple pattern from CI class (e.g., "database" from "cmdb_ci_database")
                if "database" in target_class.lower():
                    csdm_rel_type_map["database"] = rel_type
                elif "server" in target_class.lower():
                    csdm_rel_type_map["server"] = rel_type
                elif "application" in target_class.lower():
                    csdm_rel_type_map["application"] = rel_type
                elif "service" in target_class.lower():
                    csdm_rel_type_map["service"] = rel_type

        print(f"[suggest_ci_relationship_mappings] CSDM relationship type map: {csdm_rel_type_map}", file=sys.stderr)

        # Query source CIs
        print(f"[suggest_ci_relationship_mappings] Analyzing {source_ci_class} for relationship suggestions", file=sys.stderr)

        # Try with infrastructure-specific fields first, fall back to basic fields if it fails
        try:
            source_response = await client.get_table_records(
                table=source_ci_class,
                sysparm_fields="sys_id,name,ip_address,host_name,environment,business_unit",
                sysparm_limit=sample_limit_for_audit_level(audit_level),
            )
        except Exception as e:
            # Likely an application/software CI that doesn't have infrastructure fields
            # Retry with just basic fields
            print(f"[suggest_ci_relationship_mappings] Retrying with basic fields for {source_ci_class}", file=sys.stderr)
            source_response = await client.get_table_records(
                table=source_ci_class,
                sysparm_fields="sys_id,name,environment,business_unit",
                sysparm_limit=sample_limit_for_audit_level(audit_level),
            )

        source_cis = source_response.get("result", [])
        print(f"[suggest_ci_relationship_mappings] Retrieved {len(source_cis)} source CIs", file=sys.stderr)

        # Get existing relationships for analysis
        rel_response = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_fields="parent,child,type",
            sysparm_limit=sample_limit_for_audit_level(audit_level),
        )

        existing_rels = rel_response.get("result", [])
        # Build two sets: one for parent->child pairs, one for child->parent pairs
        existing_pairs_forward = set()
        existing_pairs_reverse = set()
        for rel in existing_rels:
            parent = rel.get("parent", "")
            child = rel.get("child", "")
            if isinstance(parent, dict):
                parent = parent.get("value", "")
            if isinstance(child, dict):
                child = child.get("value", "")
            if parent and child:
                existing_pairs_forward.add((str(parent), str(child)))
                existing_pairs_reverse.add((str(child), str(parent)))

        print(f"[suggest_ci_relationship_mappings] Loaded {len(existing_rels)} existing relationships", file=sys.stderr)

        # Generate suggestions
        suggestions = []
        confidence_high = 0
        confidence_medium = 0
        confidence_low = 0

        for source_ci in source_cis[:limit]:
            source_id = source_ci.get("sys_id")
            source_name = source_ci.get("name")
            source_env = source_ci.get("environment", "")

            # Extract environment from name if not set
            if not source_env and "prod" in source_name.lower():
                source_env = "Production"
            elif not source_env and "dev" in source_name.lower():
                source_env = "Development"
            elif not source_env and "test" in source_name.lower():
                source_env = "Testing"

            # Pattern 1: Servers should connect to databases in same environment
            # Determine target pattern based on source CI naming
            if "database" in source_name.lower() or "db" in source_name.lower():
                target_pattern = "application"
                target_table = "cmdb_ci_application"
                confidence = "high"
            elif "server" in source_name.lower():
                target_pattern = "database"
                target_table = "cmdb_ci_database"
                confidence = "high"
            elif "application" in source_name.lower() or "app" in source_name.lower():
                target_pattern = "server"
                target_table = "cmdb_ci_server"
                confidence = "medium"
            else:
                target_pattern = "service"
                target_table = "cmdb_ci_service"
                confidence = "low"

            # BUG FIX #3: Resolve target pattern to actual CI
            # Query target table to find specific CIs matching pattern and environment
            target_cis = []
            try:
                # Build query to find target CIs in same environment
                # If no environment, use active=true to get all active CIs
                if source_env:
                    target_query = f"active=true^environment={source_env}"
                else:
                    target_query = "active=true"

                print(f"[DEBUG] Querying {target_table} with: {target_query}", file=sys.stderr)

                target_response = await client.get_table_records(
                    table=target_table,
                    sysparm_query=target_query,
                    sysparm_fields="sys_id,name,environment",
                    sysparm_limit=10  # Limit to top 10 potential targets
                )
                target_cis = target_response.get("result", [])
                print(f"[DEBUG] Found {len(target_cis)} potential {target_pattern} targets for {source_name} from table {target_table}", file=sys.stderr)

                # If no CIs found in specific environment, try without environment filter
                if not target_cis and source_env:
                    print(f"[DEBUG] No CIs in environment '{source_env}', retrying without environment filter", file=sys.stderr)
                    target_response = await client.get_table_records(
                        table=target_table,
                        sysparm_query="active=true",
                        sysparm_fields="sys_id,name,environment",
                        sysparm_limit=10
                    )
                    target_cis = target_response.get("result", [])
                    print(f"[DEBUG] Retry found {len(target_cis)} CIs in {target_table}", file=sys.stderr)

            except Exception as e:
                print(f"[ERROR] Failed to query {target_table}: {type(e).__name__}: {e}", file=sys.stderr)
                import traceback
                traceback.print_exc()
                target_cis = []

            # BUG FIX: Check if this source CI already has ANY relationships
            # Check both forward (source->target) and reverse (target->source) relationships
            has_relationship = False
            for pair in existing_pairs_forward:
                if pair[0] == source_id:
                    has_relationship = True
                    break
            if not has_relationship:
                for pair in existing_pairs_reverse:
                    if pair[0] == source_id:
                        has_relationship = True
                        break

            if not has_relationship:
                # Use CSDM-derived relationship type if available, otherwise use generic "Depends on"
                relationship_type = csdm_rel_type_map.get(target_pattern, "Depends on")

                # BUG FIX #3 (continued): Create suggestions with actual target CIs
                if target_cis:
                    # Found specific target CIs - create suggestion for each
                    for target_ci in target_cis[:3]:  # Limit to top 3 targets per source
                        target_id = target_ci.get("sys_id")
                        target_name = target_ci.get("name")
                        target_env = target_ci.get("environment", "")

                        # Skip if relationship already exists with this specific target
                        if (source_id, target_id) in existing_pairs_forward or (source_id, target_id) in existing_pairs_reverse:
                            continue

                        # Update confidence counts
                        if confidence == "high":
                            confidence_high += 1
                        elif confidence == "medium":
                            confidence_medium += 1
                        else:
                            confidence_low += 1

                        suggestions.append({
                            "source_ci": source_name,
                            "source_id": source_id,
                            "target_ci": target_name,
                            "target_id": target_id,
                            "target_pattern": target_pattern,
                            "environment": source_env or "Unknown",
                            "target_environment": target_env or "Unknown",
                            "confidence": confidence,
                            "confidence_score": 92 if confidence == "high" else 72 if confidence == "medium" else 45,
                            "relationship_type": relationship_type,
                            "relationship_type_source": "CSDM" if target_pattern in csdm_rel_type_map else "default",
                            "reasoning": f"Pattern match: {source_name} (env: {source_env or 'Unknown'}) should relate to {target_name} (env: {target_env or 'Unknown'}). No existing relationships found.",
                            "action": f"Create relationship: {source_name} -> {target_name} [{confidence}]"
                        })
                else:
                    # No specific target CIs found - use generic pattern (backward compatibility)
                    # Update confidence counts
                    if confidence == "high":
                        confidence_high += 1
                    elif confidence == "medium":
                        confidence_medium += 1
                    else:
                        confidence_low += 1

                    suggestions.append({
                        "source_ci": source_name,
                        "source_id": source_id,
                        "suggested_target_pattern": target_pattern,
                        "target_ci": None,
                        "target_id": None,
                        "environment": source_env or "Unknown",
                        "confidence": confidence,
                        "confidence_score": 92 if confidence == "high" else 72 if confidence == "medium" else 45,
                        "relationship_type": relationship_type,
                        "relationship_type_source": "CSDM" if target_pattern in csdm_rel_type_map else "default",
                        "reasoning": f"Pattern match: {source_name} (environment: {source_env}) should relate to {target_pattern}. No existing relationships found. No specific {target_pattern} CIs found in environment.",
                        "action": f"Create relationship: {source_name} -> <{target_pattern}> [{confidence}]"
                    })

        # Sort by confidence score descending
        suggestions.sort(key=lambda x: x["confidence_score"], reverse=True)

        # Calculate relationship improvement
        relationship_improvement = round((len(suggestions) * 0.3), 1)  # Each new relationship adds ~0.3%

        response = {
            "source_class": source_ci_class,
            "target_classes": target_ci_class or "All applicable",
            "source_cis_analyzed": len(source_cis),
            "unmapped_pairs_found": len(suggestions),
            "mapping_suggestions": suggestions[:limit],
            "confidence_breakdown": {
                "high": confidence_high,
                "medium": confidence_medium,
                "low": confidence_low,
                "total_analyzed": len(suggestions)
            },
            "suggestion_categories": {
                "high_confidence": [s for s in suggestions if s["confidence"] == "high"],
                "medium_confidence": [s for s in suggestions if s["confidence"] == "medium"],
                "low_confidence": [s for s in suggestions if s["confidence"] == "low"]
            },
            "estimated_relationship_improvement": f"+{relationship_improvement}%",
            "impact_summary": {
                "relationship_coverage_improvement": f"{relationship_improvement}%",
                "expected_compliance_gain": "0.5-1.2% overall",
                "recommended_quick_wins": f"Apply {confidence_high} high-confidence mappings first"
            },
            "next_steps": [
                f"1. Review {confidence_high} high-confidence suggestions",
                f"2. Validate with domain experts before applying",
                f"3. Create relationships in bulk or via API",
                f"4. Re-run CMDB Health scan to measure impact",
                f"5. Process {confidence_medium} medium-confidence suggestions in phase 2"
            ],
            "status": "success",
            "audit_metadata": build_audit_metadata(audit_level, len(source_cis), len(suggestions))
        }

        return response

    except Exception as e:
        print(f"[ERROR] suggest_ci_relationship_mappings failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "source_class": source_ci_class,
            "status": "error",
            "error": str(e)
        }
