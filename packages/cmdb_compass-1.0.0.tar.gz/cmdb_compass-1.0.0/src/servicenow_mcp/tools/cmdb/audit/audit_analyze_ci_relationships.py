"""Analyze CI Relationships Tool

Unified relationship intelligence providing coverage analysis, classification,
and CSDM compliance for CI relationships.
Consolidates assess_relationship_coverage + classify_ci_relationships functionality.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules

from servicenow_mcp.tools.cmdb.audit import utils
from servicenow_mcp.tools.cmdb.audit.utils import (
    cache_audit_baseline,
    extract_display_value,
    get_cached_baseline,
    safe_count_records,
    sample_limit_for_audit_level,
    score_to_grade,
)


async def analyze_ci_relationships(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
    include_suggestions: bool = True,
) -> Dict[str, Any]:
    """
    Unified CI relationship analysis: coverage + classification + compliance.

    Deep-dive into relationship quality and topology covering:
    - Coverage: Percentage of CIs with relationships
    - Classification: Identify unclassified and non-CSDM relationships
    - CSDM Compliance: Validate against CSDM 5.0 relationship types
    - Suggestions: Recommend missing standard relationships

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes all.
        domain: CSDM domain filter
        audit_level: 'quick', 'standard', or 'deep'
        include_suggestions: Whether to suggest relationship classifications

    Returns:
        Dictionary with unified relationship health and recommendations
    """

    cache_key = f"analyze_ci_relationships:{ci_class}:{domain}:{audit_level}"
    cached = get_cached_baseline(cache_key)
    if cached is not None:
        return cached

    start_time = datetime.now()

    try:
        csdm_rules = get_csdm_rules()
    except Exception as e:
        return {
            "status": "error",
            "error": f"Failed to load CSDM rules: {str(e)}",
        }

    # Get relationship coverage metrics
    coverage = await _analyze_coverage(client, ci_class, csdm_rules, audit_level)

    if coverage["status"] == "error":
        return coverage

    # Get unclassified and non-compliant relationships
    classification = await _analyze_classification(
        client, ci_class, csdm_rules, audit_level, include_suggestions
    )

    # Get topology and dependency information
    topology = await _analyze_topology(client, ci_class, audit_level)

    # Calculate relationship quality score
    rel_quality_score = _calculate_relationship_quality(coverage, classification)

    result = {
        "ci_class": ci_class,
        "domain": domain,
        "relationship_quality_score": rel_quality_score,
        "relationship_quality_grade": score_to_grade(rel_quality_score),
        "coverage": {
            "total_cis": coverage.get("total_cis", 0),
            "cis_with_relationships": coverage.get("cis_with_relationships", 0),
            "cis_without_relationships": coverage.get("cis_without_relationships", 0),
            "coverage_percent": coverage.get("coverage_percent", 0.0),
            "total_relationships": coverage.get("total_relationships", 0),
        },
        "relationship_types": {
            "types_in_use": coverage.get("types_in_use", []),
            "types_in_use_count": len(coverage.get("types_in_use", [])),
            "expected_types": coverage.get("expected_types", []),
            "expected_types_count": len(coverage.get("expected_types", [])),
            "missing_types": coverage.get("missing_types", []),
            "missing_types_count": len(coverage.get("missing_types", [])),
            "relationship_distribution": coverage.get("relationship_type_distribution", {}),
        },
        "data_quality": {
            "orphan_relationships": classification.get("orphan_relationships", 0),
            "unclassified_relationships": classification.get("unclassified_count", 0),
        },
        "topology": topology,
        "recommendations": _generate_recommendations(coverage, classification),
        "metadata": utils.build_audit_metadata(
            audit_type="relationship_analysis",
            audit_level=audit_level,
            execution_time=(datetime.now() - start_time).total_seconds(),
            ci_class=ci_class or "all"
        ),
        "status": "success",
    }

    cache_audit_baseline(cache_key, result)
    return result


async def _analyze_coverage(
    client: ServiceNowClient,
    ci_class: Optional[str],
    csdm_rules: Any,
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Analyze relationship coverage for CI class."""

    try:
        # Get relationships for this CI class first to determine scope
        # Special handling for base class 'cmdb_ci' - query all relationships
        if ci_class and ci_class != "cmdb_ci":
            rel_query = f"parent.sys_class_name={ci_class}"
        else:
            # Query all relationships for base class or when no class specified
            rel_query = ""

        rel_records = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=rel_query if rel_query else None,
            sysparm_fields="sys_id,parent,parent.name,parent.sys_class_name,type,child,child.name",
            sysparm_display_value="true",
            sysparm_limit=sample_limit_for_audit_level(audit_level),
        )
        relationships = rel_records.get("result", []) or []

        # Analyze relationship types
        rel_types: Dict[str, int] = {}
        ci_with_rels: set[str] = set()
        unclassified_count = 0

        for rel in relationships:
            parent = rel.get("parent")
            parent_id_val = extract_display_value(parent)
            if parent_id_val:
                ci_with_rels.add(parent_id_val)

            rel_type = rel.get("type")
            rel_type_name = extract_display_value(rel_type)
            if rel_type_name:
                # Simplify type name: "Depends on::Used by" → "Depends on"
                simplified_name = rel_type_name.split("::")[0] if "::" in rel_type_name else rel_type_name
                rel_types[simplified_name] = rel_types.get(simplified_name, 0) + 1
            else:
                unclassified_count += 1

        # Get total CIs count
        if ci_class:
            total_cis = await safe_count_records(client, ci_class)
        else:
            # When analyzing all relationships without specific CI class,
            # total_cis = unique CIs that appear in relationships
            total_cis = len(ci_with_rels)

        # Get expected relationship types from CSDM rules for this CI class
        expected_rel_types = []
        if ci_class and ci_class != "cmdb_ci":
            # Get CSDM relationship rules for specific CI class
            rel_rules = csdm_rules.get_relationship_rules(ci_class)
            if rel_rules:
                # Extract relationship type names from CSDM rules
                for target_class, rel_info in rel_rules.items():
                    rel_type = rel_info.get("type", "")
                    if rel_type:
                        # Normalize: "deployed_on" → "Deployed on"
                        formatted_type = rel_type.replace("_", " ").title()
                        expected_rel_types.append(formatted_type)

        # Fallback to common types if no CSDM rules found or analyzing all CIs
        if not expected_rel_types:
            expected_rel_types = [
                "Hosted on",
                "Depends on",
                "Runs on",
                "Managed by",
                "Deployed on",
                "Consumes",
                "Connects to",
                "Composed of",
                "Used by",
                "Supports",
            ]

        # Find which expected types are missing
        types_in_use = list(rel_types.keys())
        missing_types = [t for t in expected_rel_types if t not in types_in_use]

        coverage_percent = (len(ci_with_rels) / total_cis * 100) if total_cis > 0 else 0.0

        return {
            "total_cis": total_cis,
            "cis_with_relationships": len(ci_with_rels),
            "cis_without_relationships": max(0, total_cis - len(ci_with_rels)),
            "total_relationships": len(relationships),
            "unclassified_relationships": unclassified_count,
            "coverage_percent": round(coverage_percent, 1),
            "types_in_use": types_in_use,
            "expected_types": expected_rel_types,
            "missing_types": missing_types,
            "relationship_type_distribution": rel_types,
            "status": "success",
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


async def _analyze_classification(
    client: ServiceNowClient,
    ci_class: Optional[str],
    csdm_rules: Any,
    audit_level: utils.AuditLevel,
    include_suggestions: bool,
) -> Dict[str, Any]:
    """Analyze relationship classification and CSDM compliance."""

    try:
        # Special handling for base class 'cmdb_ci' - query all relationships
        if ci_class and ci_class != "cmdb_ci":
            rel_query = f"parent.sys_class_name={ci_class}"
        else:
            rel_query = ""

        rel_records = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=rel_query if rel_query else None,
            sysparm_fields="sys_id,parent,parent.sys_class_name,type,child,child.sys_class_name",
            sysparm_display_value="all",
            sysparm_limit=sample_limit_for_audit_level(audit_level),
        )
        relationships = rel_records.get("result", []) or []

        # Count classification status
        unclassified = []
        orphan = []
        duplicate = []
        csdm_compliant = 0
        csdm_non_compliant = 0
        invalid_types = []
        suggestions = []

        processed_rels = set()

        for rel in relationships:
            rel_sys_id = rel.get("sys_id", "")
            if rel_sys_id in processed_rels:
                continue
            processed_rels.add(rel_sys_id)

            ci_from = rel.get("parent")
            ci_from_sys_id = ci_from.get("value") if isinstance(ci_from, dict) else ""
            ci_from_class = rel.get("parent.sys_class_name", "")

            ci_to = rel.get("child")
            ci_to_sys_id = ci_to.get("value") if isinstance(ci_to, dict) else ""
            ci_to_class = rel.get("child.sys_class_name", "")

            rel_type = rel.get("type")
            rel_type_name = extract_display_value(rel_type)

            # Check for orphan relationships
            if not ci_from_sys_id or not ci_to_sys_id:
                orphan.append({
                    "sys_id": rel_sys_id,
                    "ci_from": extract_display_value(ci_from),
                    "ci_to": extract_display_value(ci_to),
                })
                continue

            # Check for unclassified
            if not rel_type_name or rel_type_name == "":
                unclassified.append({
                    "sys_id": rel_sys_id,
                    "ci_from": f"{extract_display_value(ci_from)} ({ci_from_class})",
                    "ci_to": f"{extract_display_value(ci_to)} ({ci_to_class})",
                })

                # Generate suggestion if enabled
                if include_suggestions:
                    suggestion = await _suggest_relationship_type(
                        csdm_rules, ci_from_class, ci_to_class
                    )
                    if suggestion:
                        suggestions.append({
                            "sys_id": rel_sys_id,
                            "suggested_type": suggestion["type"],
                            "confidence": suggestion["confidence"],
                            "reason": suggestion["reason"],
                        })
                continue

            # Check CSDM compliance
            valid_rel_types = csdm_rules.get_valid_relationship_types()
            normalized_type = _normalize_relationship_type(rel_type_name)
            if normalized_type in valid_rel_types:
                csdm_compliant += 1
            else:
                csdm_non_compliant += 1
                invalid_types.append(rel_type_name)

        compliance_percent = (
            (csdm_compliant / (csdm_compliant + csdm_non_compliant) * 100)
            if (csdm_compliant + csdm_non_compliant) > 0
            else 0.0
        )

        return {
            "unclassified_count": len(unclassified),
            "unclassified_examples": unclassified[:5] if audit_level in ["standard", "deep"] else unclassified[:1],
            "orphan_relationships": len(orphan),
            "orphan_examples": orphan[:3] if audit_level == "deep" else [],
            "duplicate_relationships": len(duplicate),
            "csdm_compliant_count": csdm_compliant,
            "csdm_non_compliant_count": csdm_non_compliant,
            "compliance_percent": round(compliance_percent, 1),
            "invalid_relationship_types": list(set(invalid_types)),
            "suggestions": suggestions[:10] if audit_level in ["standard", "deep"] else suggestions[:3],
            "total_suggestions": len(suggestions),
            "status": "success",
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


async def _analyze_topology(
    client: ServiceNowClient,
    ci_class: Optional[str],
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Analyze service topology and dependency patterns."""

    if audit_level == "quick":
        return {
            "message": "Available in standard and deep audit levels",
        }

    try:
        # Special handling for base class 'cmdb_ci' - query all relationships
        if ci_class and ci_class != "cmdb_ci":
            rel_query = f"parent.sys_class_name={ci_class}"
        else:
            rel_query = ""

        rel_records = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=rel_query if rel_query else None,
            sysparm_fields="type,parent.sys_class_name,child.sys_class_name",
            sysparm_limit=sample_limit_for_audit_level(audit_level),
        )
        relationships = rel_records.get("result", []) or []

        # Build topology connections
        connections_by_type: Dict[str, int] = {}
        class_relationships: Dict[str, list] = {}

        for rel in relationships:
            rel_type = extract_display_value(rel.get("type"))
            ci_from_class = rel.get("parent.sys_class_name", "")
            ci_to_class = rel.get("child.sys_class_name", "")

            if rel_type:
                connections_by_type[rel_type] = connections_by_type.get(rel_type, 0) + 1

            key = f"{ci_from_class} → {ci_to_class}"
            if key not in class_relationships:
                class_relationships[key] = []
            class_relationships[key].append(rel_type)

        return {
            "connection_types_used": len(connections_by_type),
            "connections_by_type": dict(sorted(
                connections_by_type.items(),
                key=lambda x: x[1],
                reverse=True
            )[:10]),
            "class_patterns": len(class_relationships),
            "common_patterns": list(class_relationships.keys())[:10] if audit_level == "deep" else [],
        }
    except Exception as e:
        return {
            "error": str(e),
        }


async def _suggest_relationship_type(
    csdm_rules: Any,
    ci_from_class: str,
    ci_to_class: str,
) -> Optional[Dict[str, str]]:
    """Suggest appropriate relationship type based on CSDM rules."""

    try:
        # Get CSDM rules for source CI class
        from_rel_rules = csdm_rules.get_relationship_rules(ci_from_class)
        if from_rel_rules:
            for target_class, rel_info in from_rel_rules.items():
                if target_class in ci_to_class:
                    return {
                        "type": rel_info.get("type", "references"),
                        "confidence": "high",
                        "reason": f"CSDM rule: {ci_from_class} → {ci_to_class}",
                    }

        # Use heuristic patterns as fallback
        if "server" in ci_from_class.lower() and "database" in ci_to_class.lower():
            return {
                "type": "Hosted on",
                "confidence": "high",
                "reason": "Pattern: Server hosts Database",
            }
        elif "application" in ci_from_class.lower() and "server" in ci_to_class.lower():
            return {
                "type": "Deployed on",
                "confidence": "high",
                "reason": "Pattern: Application deployed on Server",
            }
        elif "application" in ci_from_class.lower() and "database" in ci_to_class.lower():
            return {
                "type": "Depends on",
                "confidence": "high",
                "reason": "Pattern: Application depends on Database",
            }

        return None
    except Exception:
        return None


def _calculate_relationship_quality(
    coverage: Dict[str, Any],
    classification: Dict[str, Any],
) -> float:
    """Calculate overall relationship quality score (0-100) based on coverage and data quality."""

    coverage_score = coverage.get("coverage_percent", 0.0)

    # Calculate type diversity score (using 10 common types as baseline)
    types_in_use = coverage.get("types_in_use", [])
    type_diversity = min(100, len(types_in_use) * 10)  # 10 types = 100%

    # Penalty for data quality issues
    orphan_count = classification.get("orphan_relationships", 0)
    unclassified_count = classification.get("unclassified_count", 0)
    total_rels = coverage.get("total_relationships", 1)
    quality_penalty = ((orphan_count + unclassified_count) / total_rels * 100) if total_rels > 0 else 0

    # Weighted: coverage 60%, type diversity 30%, quality penalty -10%
    quality = (coverage_score * 0.6) + (type_diversity * 0.3) - (quality_penalty * 0.1)
    return round(max(0, min(100, quality)), 1)


def _generate_recommendations(
    coverage: Dict[str, Any],
    classification: Dict[str, Any],
) -> List[str]:
    """Generate actionable recommendations."""

    recommendations = []
    coverage_pct = coverage.get("coverage_percent", 0.0)
    cis_without_rels = coverage.get("cis_without_relationships", 0)
    missing_types = coverage.get("missing_types", [])
    types_in_use = coverage.get("types_in_use", [])
    expected_count = len(coverage.get("expected_types", []))

    # Coverage recommendations
    if coverage_pct < 50:
        recommendations.append(
            f"Add relationships to {cis_without_rels:,} CIs ({100-coverage_pct:.1f}% coverage gap)"
        )
    elif coverage_pct < 80:
        recommendations.append(
            f"Improve coverage to 80%+ by linking {cis_without_rels:,} more CIs"
        )
    elif coverage_pct < 100:
        recommendations.append(
            f"Link remaining {cis_without_rels:,} CIs to reach 100% coverage"
        )

    # Type diversity recommendations based on CSDM expected types
    if missing_types:
        missing_count = len(missing_types)
        type_coverage = ((expected_count - missing_count) / expected_count * 100) if expected_count > 0 else 0
        recommendations.append(
            f"Implement {missing_count} missing relationship type(s) - {type_coverage:.0f}% type coverage"
        )

    # Data quality recommendations
    orphan_count = classification.get("orphan_relationships", 0)
    if orphan_count > 0:
        recommendations.append(
            f"Fix {orphan_count} orphan relationship(s) with missing CIs"
        )

    if not recommendations:
        recommendations.append("Excellent coverage and type diversity - continue monitoring")

    return recommendations


def _normalize_relationship_type(rel_type_name: str) -> str:
    """
    Normalize ServiceNow relationship type name to CSDM format.

    ServiceNow format: "Depends on::Used by" or "Hosted on::Hosts"
    CSDM format: "depends_on" or "hosted_on"

    Extracts parent descriptor and converts to lowercase underscore format.
    """
    if not rel_type_name:
        return ""

    # Extract parent descriptor (before "::")
    if "::" in rel_type_name:
        rel_type_name = rel_type_name.split("::")[0]

    # Convert to lowercase underscore format
    return rel_type_name.lower().replace(" ", "_").strip()
