"""
Check CSDM Rules Tool

Check and load CSDM 5.0 rules from configuration file.
Audit-level tool for CSDM configuration validation (free).
"""

import sys
from pathlib import Path
from typing import Any, Dict

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules


async def check_csdm_rules(client: ServiceNowClient) -> Dict[str, Any]:
    """
    Check and load CSDM 5.0 rules from configuration file.

    This tool explicitly verifies that CSDM rules are loaded and available
    for other tools to use. Run this before other tools to ensure CSDM
    intelligence is activated.

    WHEN TO USE:
    - "Check if CSDM rules are loaded"
    - "Verify CSDM configuration"
    - "Show me what CSDM rules we have"

    CSDM PHASE: DISCOVER (configuration validation)

    Returns:
        Dictionary containing:
        - rules_loaded: bool - Whether rules loaded successfully
        - csdm_file_path: str - Path to csdm_rules.json
        - file_size_kb: float - Size of rules file
        - domains_count: int - Number of CSDM domains
        - total_ci_classes: int - Total CI classes defined
        - relationship_types_count: int - Valid relationship types
        - domains: list - Details of each domain
        - ci_classes_by_domain: dict - CI classes grouped by domain
        - valid_relationship_types: list - All valid relationship types
        - status: success/error

    EXAMPLE OUTPUT:
        "✓ CSDM rules loaded successfully from data/csdm_rules.json
         - 2 domains (Foundation, Service)
         - 45 CI classes defined
         - 22 valid relationship types
         - File size: 53 KB"
    """
    try:
        print("[check_csdm_rules] Loading CSDM rules...", file=sys.stderr)

        # Load CSDM rules
        csdm_rules = get_csdm_rules()

        # Check if rules were actually loaded
        if not csdm_rules.rules:
            print("[check_csdm_rules] WARNING: Rules dictionary is empty!", file=sys.stderr)
            return {
                "rules_loaded": False,
                "error": "CSDM rules file not found or failed to parse",
                "csdm_file_path": str(Path(__file__).parent.parent.parent / "data" / "csdm_rules.json"),
                "status": "error"
            }

        # Get file information
        rules_file = Path(__file__).parent.parent.parent / "data" / "csdm_rules.json"
        file_size_kb = rules_file.stat().st_size / 1024 if rules_file.exists() else 0

        # Analyze loaded rules
        domains = list(csdm_rules.rules.keys())
        total_ci_classes = 0
        ci_classes_by_domain = {}

        for domain in domains:
            domain_data = csdm_rules.rules.get(domain, {})
            if isinstance(domain_data, dict):
                # Count CI classes (skip metadata keys starting with _)
                ci_classes = [k for k in domain_data.keys() if not k.startswith("_")]
                total_ci_classes += len(ci_classes)
                ci_classes_by_domain[domain] = ci_classes

        # Get valid relationship types
        relationship_types = list(csdm_rules.get_valid_relationship_types())

        # Build domain details
        domain_details = []
        for domain in domains:
            domain_data = csdm_rules.rules.get(domain, {})
            if isinstance(domain_data, dict):
                ci_count = len([k for k in domain_data.keys() if not k.startswith("_")])
                domain_details.append({
                    "domain": domain,
                    "ci_classes_count": ci_count,
                    "ci_classes": [k for k in domain_data.keys() if not k.startswith("_")]
                })

        print(f"[check_csdm_rules] Successfully loaded {len(domains)} domains with {total_ci_classes} CI classes", file=sys.stderr)
        print(f"[check_csdm_rules] Found {len(relationship_types)} valid relationship types", file=sys.stderr)

        response = {
            "rules_loaded": True,
            "csdm_file_path": str(rules_file),
            "file_exists": rules_file.exists(),
            "file_size_kb": round(file_size_kb, 1),
            "domains_count": len(domains),
            "total_ci_classes": total_ci_classes,
            "relationship_types_count": len(relationship_types),
            "domains": domain_details,
            "ci_classes_by_domain": ci_classes_by_domain,
            "valid_relationship_types": sorted(relationship_types),
            "sample_duplicate_detection_fields": {
                "cmdb_ci_computer": csdm_rules.get_duplicate_detection_fields("cmdb_ci_computer"),
                "cmdb_ci_server": csdm_rules.get_duplicate_detection_fields("cmdb_ci_server"),
                "cmdb_ci_database": csdm_rules.get_duplicate_detection_fields("cmdb_ci_database"),
            },
            "status": "success",
            "message": f"✓ CSDM rules loaded successfully: {len(domains)} domains, {total_ci_classes} CI classes, {len(relationship_types)} relationship types"
        }

        return response

    except Exception as e:
        print(f"[ERROR] check_csdm_rules failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "rules_loaded": False,
            "status": "error",
            "error": str(e),
            "message": "Failed to load CSDM rules"
        }
