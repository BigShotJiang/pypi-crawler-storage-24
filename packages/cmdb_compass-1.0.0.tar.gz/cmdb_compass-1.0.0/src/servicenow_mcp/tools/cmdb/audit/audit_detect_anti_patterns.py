"""Detect CMDB Anti-Patterns Tool

Identify non-normalized data and anti-patterns that block CSDM compliance.
Audit-level tool for data structure validation (read-only).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules

from servicenow_mcp.tools.cmdb.audit import utils


async def detect_anti_patterns(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Detect CMDB anti-patterns blocking CSDM compliance.

    Identifies non-normalized data structures that prevent CSDM compliance:
    - Custom reference fields used instead of CSDM relationships
    - Non-standard CI classes or attributes
    - Data stored in custom fields instead of proper model structure
    - Missing CSDM-compliant linking patterns

    This tool directly addresses the Reddit pain point:
    "Servers linked via custom reference fields, not relationships"

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., 'cmdb_ci_server'). If None, analyzes all.
        domain: CSDM domain filter
        audit_level: 'quick', 'standard', or 'deep'

    Returns:
        Dictionary with detected anti-patterns and remediation guidance
    """

    try:
        csdm_rules = get_csdm_rules()
    except Exception as e:
        return {
            "status": "error",
            "error": f"Failed to load CSDM rules: {str(e)}",
        }

    anti_patterns = []

    # Detect custom reference fields
    custom_refs = await _detect_custom_reference_fields(client, ci_class, csdm_rules, audit_level)
    if custom_refs:
        anti_patterns.append(custom_refs)

    # Detect non-standard CI classes
    non_standard = await _detect_non_standard_ci_classes(client, ci_class, csdm_rules, audit_level)
    if non_standard:
        anti_patterns.append(non_standard)

    # Detect missing model structure
    missing_model = await _detect_missing_model_structure(client, ci_class, csdm_rules, audit_level)
    if missing_model:
        anti_patterns.append(missing_model)

    # Calculate anti-pattern score
    total_issues = sum(p.get("issue_count", 0) for p in anti_patterns)
    severity = _calculate_severity(total_issues)

    return {
        "ci_class": ci_class,
        "domain": domain,
        "total_anti_patterns_detected": len(anti_patterns),
        "total_affected_cis": total_issues,
        "severity": severity,
        "severity_level": _severity_to_level(severity),
        "anti_patterns": anti_patterns,
        "compliance_impact": _calculate_compliance_impact(anti_patterns),
        "remediation_priority": _prioritize_remediation(anti_patterns),
        "next_steps": _generate_remediation_steps(anti_patterns),
        "audit_metadata": utils.build_audit_metadata(audit_level, total_issues, 0),
        "status": "success",
    }


async def _detect_custom_reference_fields(
    client: ServiceNowClient,
    ci_class: Optional[str],
    csdm_rules: Any,
    audit_level: utils.AuditLevel,
) -> Optional[Dict[str, Any]]:
    """Detect custom reference fields used instead of CSDM relationships."""

    try:
        # Get all custom reference fields from sys_dictionary
        # Simplified query for better compatibility
        if ci_class:
            query = f"name={ci_class}&type=reference"
        else:
            query = "type=reference"

        try:
            dict_response = await client.get_table_records(
                table="sys_dictionary",
                sysparm_query=query,
                sysparm_fields="name,element,label,reference_target",
                sysparm_limit=200,
            )
            custom_fields = dict_response.get("result", []) or []
        except Exception as dict_error:
            # Fallback: return empty result instead of failing
            print(f"[WARN] Could not query sys_dictionary: {dict_error}", flush=True)
            custom_fields = []

        if not custom_fields:
            return None

        affected_cis_list = []
        problematic_fields = []

        # For each custom reference field, find CIs using it
        for field_def in custom_fields:
            table = field_def.get("name")
            field_name = field_def.get("element")
            field_label = field_def.get("label")
            ref_target = field_def.get("reference_target")

            # Count how many CIs have this field populated
            count_query = f"{field_name}!EMPTY"
            count_response = await client.count_records(table, sysparm_query=count_query)
            count = count_response[0] if isinstance(count_response, tuple) else count_response

            if count > 0:
                # Check if this should be a CSDM relationship instead
                suggested_relationship = _suggest_csdm_relationship(
                    csdm_rules, table, field_name, ref_target
                )

                problematic_field = {
                    "table": table,
                    "field_name": field_name,
                    "field_label": field_label,
                    "reference_target": ref_target,
                    "affected_ci_count": count,
                    "issue": f"Custom reference field '{field_name}' bypasses CSDM relationships",
                    "severity": "high" if count > 10 else "medium",
                    "suggested_replacement": suggested_relationship,
                    "remediation": f"Convert '{field_name}' to CSDM relationship type: {suggested_relationship}",
                }

                problematic_fields.append(problematic_field)
                affected_cis_list.extend([f"{table}:{field_name}" for _ in range(count)])

        if not problematic_fields:
            return None

        return {
            "pattern_name": "Custom Reference Fields",
            "pattern_description": "Using custom reference fields instead of CSDM-compliant relationships",
            "reddit_reference": "Servers linked via custom reference fields, not relationships",
            "issue_count": len(affected_cis_list),
            "affected_ci_examples": problematic_fields[:5] if audit_level in ["standard", "deep"] else problematic_fields[:2],
            "total_affected_fields": len(problematic_fields),
            "compliance_impact_percent": min(100, len(problematic_fields) * 5),
            "severity": "high",
            "remediation_effort": "medium",
            "estimated_effort_days": max(1, len(problematic_fields) // 3),
        }

    except Exception as e:
        return {
            "pattern_name": "Custom Reference Fields",
            "error": str(e),
            "issue_count": 0,
        }


async def _detect_non_standard_ci_classes(
    client: ServiceNowClient,
    ci_class: Optional[str],
    csdm_rules: Any,
    audit_level: utils.AuditLevel,
) -> Optional[Dict[str, Any]]:
    """Detect non-standard (non-CSDM) CI classes in use."""

    try:
        # Get all CI classes in use
        all_classes_response = await client.get_table_records(
            table="cmdb_ci",
            sysparm_fields="sys_class_name",
            sysparm_limit=500,
        )

        all_classes = all_classes_response.get("result", []) or []
        class_set = set()
        class_counts: Dict[str, int] = {}

        for record in all_classes:
            class_name = record.get("sys_class_name")
            if class_name:
                class_set.add(class_name)
                class_counts[class_name] = class_counts.get(class_name, 0) + 1

        # Find non-CSDM classes
        non_standard_classes = []
        for class_name in class_set:
            if not csdm_rules.is_valid_ci_class(class_name):
                non_standard_classes.append({
                    "ci_class": class_name,
                    "ci_count": class_counts[class_name],
                    "issue": f"CI class '{class_name}' is not in CSDM 5.0 standard",
                    "suggestion": _suggest_csdm_alternative(csdm_rules, class_name),
                })

        if not non_standard_classes:
            return None

        total_non_standard_cis = sum(c["ci_count"] for c in non_standard_classes)

        return {
            "pattern_name": "Non-Standard CI Classes",
            "pattern_description": "CI classes not defined in CSDM 5.0 standard",
            "issue_count": total_non_standard_cis,
            "affected_classes": non_standard_classes[:10] if audit_level in ["standard", "deep"] else non_standard_classes[:3],
            "total_non_standard_classes": len(non_standard_classes),
            "compliance_impact_percent": min(100, len(non_standard_classes) * 10),
            "severity": "high",
            "remediation_effort": "high",
            "estimated_effort_days": max(3, len(non_standard_classes) // 2),
        }

    except Exception as e:
        return {
            "pattern_name": "Non-Standard CI Classes",
            "error": str(e),
            "issue_count": 0,
        }


async def _detect_missing_model_structure(
    client: ServiceNowClient,
    ci_class: Optional[str],
    csdm_rules: Any,
    audit_level: utils.AuditLevel,
) -> Optional[Dict[str, Any]]:
    """Detect CIs missing proper model/parent structure."""

    try:
        # Check for software CIs without model references
        empty_model_query = "modelISEMPTY"
        empty_count = await client.count_records("cmdb_ci_software", sysparm_query=empty_model_query)
        empty_software_count = empty_count[0] if isinstance(empty_count, tuple) else empty_count

        if empty_software_count == 0:
            return None

        # Get examples
        empty_response = await client.get_table_records(
            table="cmdb_ci_software",
            sysparm_query=empty_model_query,
            sysparm_fields="sys_id,name,model,version",
            sysparm_limit=10,
        )

        empty_examples = empty_response.get("result", []) or []

        return {
            "pattern_name": "Missing Model Structure",
            "pattern_description": "Software CIs without parent model references",
            "reddit_reference": "Software models always empty",
            "issue_count": empty_software_count,
            "affected_examples": [
                {
                    "sys_id": ex.get("sys_id"),
                    "name": ex.get("name"),
                    "issue": "Software CI missing model reference",
                    "remediation": "Link to parent software model or create new model",
                }
                for ex in empty_examples[:3]
            ],
            "compliance_impact_percent": min(100, (empty_software_count // 10) * 5),
            "severity": "medium",
            "remediation_effort": "medium",
            "estimated_effort_days": max(1, empty_software_count // 100),
        }

    except Exception as e:
        return {
            "pattern_name": "Missing Model Structure",
            "error": str(e),
            "issue_count": 0,
        }


def _suggest_csdm_relationship(
    csdm_rules: Any,
    ci_class: str,
    field_name: str,
    ref_target: Optional[str],
) -> str:
    """Suggest appropriate CSDM relationship for custom field."""

    # Map common custom field patterns to CSDM relationships
    field_lower = field_name.lower()

    if "server" in field_lower or "host" in field_lower:
        return "Hosted on"
    if "database" in field_lower or "db" in field_lower:
        return "Depends on"
    if "application" in field_lower or "app" in field_lower:
        return "Deployed on"
    if "parent" in field_lower or "owner" in field_lower:
        return "Composed of"
    if "manager" in field_lower or "manage" in field_lower:
        return "Managed by"
    if "network" in field_lower or "connect" in field_lower:
        return "Connects to"

    # Default fallback
    return "references"


def _suggest_csdm_alternative(csdm_rules: Any, non_standard_class: str) -> str:
    """Suggest CSDM-compliant alternative for non-standard class."""

    # Pattern matching for common anti-patterns
    class_lower = non_standard_class.lower()

    if "server" in class_lower or "cmdb_ci_server" in class_lower:
        return "cmdb_ci_server (CSDM standard)"
    if "database" in class_lower:
        return "cmdb_ci_database (CSDM standard)"
    if "application" in class_lower:
        return "cmdb_ci_application (CSDM standard)"
    if "network" in class_lower:
        return "cmdb_ci_network_adapter (CSDM standard)"
    if "service" in class_lower:
        return "cmdb_ci_service (CSDM standard)"

    return "Review CSDM 5.0 CI class registry (132+ types)"


def _calculate_severity(issue_count: int) -> float:
    """Calculate overall severity score (0-100)."""
    # Map issue count to severity
    if issue_count == 0:
        return 0.0
    if issue_count < 5:
        return 20.0
    if issue_count < 20:
        return 40.0
    if issue_count < 50:
        return 60.0
    if issue_count < 100:
        return 80.0
    return 100.0


def _severity_to_level(severity: float) -> str:
    """Convert severity score to level."""
    if severity >= 80:
        return "Critical"
    if severity >= 60:
        return "High"
    if severity >= 40:
        return "Medium"
    if severity >= 20:
        return "Low"
    return "None"


def _calculate_compliance_impact(anti_patterns: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate impact of anti-patterns on CSDM compliance."""

    total_issues = sum(p.get("issue_count", 0) for p in anti_patterns)
    avg_impact = sum(p.get("compliance_impact_percent", 0) for p in anti_patterns) / len(anti_patterns) if anti_patterns else 0

    return {
        "total_affected_cis": total_issues,
        "estimated_compliance_loss_percent": min(100, avg_impact),
        "message": f"{total_issues} CIs affected by anti-patterns. "
                  f"Estimated compliance loss: {min(100, avg_impact):.1f}%",
    }


def _prioritize_remediation(anti_patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Prioritize remediation by effort vs impact."""

    prioritized = []
    for pattern in anti_patterns:
        effort_days = pattern.get("estimated_effort_days", 1)
        impact_percent = pattern.get("compliance_impact_percent", 0)
        priority_score = impact_percent / max(1, effort_days)

        prioritized.append({
            "pattern": pattern.get("pattern_name"),
            "priority_score": round(priority_score, 1),
            "effort_days": effort_days,
            "impact_percent": impact_percent,
            "recommendation": "High priority" if priority_score > 5 else "Medium priority" if priority_score > 2 else "Low priority",
        })

    # Sort by priority score (descending)
    return sorted(prioritized, key=lambda x: x["priority_score"], reverse=True)


def _generate_remediation_steps(anti_patterns: List[Dict[str, Any]]) -> List[str]:
    """Generate actionable remediation steps."""

    steps = [
        "1. Review detected anti-patterns above to understand compliance gaps",
        "2. For custom reference fields: Convert to CSDM relationships (high priority)",
        "3. For non-standard CI classes: Migrate records to CSDM equivalents",
        "4. For missing model structure: Link software CIs to parent models",
        "5. Test CMDB compliance score after each remediation batch",
        "6. Document any legacy dependencies on custom fields before removing",
    ]

    custom_refs = next((p for p in anti_patterns if "Custom Reference" in p.get("pattern_name", "")), None)
    if custom_refs:
        steps.insert(2, f"   → Priority: Convert {custom_refs.get('total_affected_fields', 0)} custom reference fields")

    non_standard = next((p for p in anti_patterns if "Non-Standard" in p.get("pattern_name", "")), None)
    if non_standard:
        steps.insert(3, f"   → Migrate {non_standard.get('total_non_standard_classes', 0)} non-CSDM CI classes")

    return steps
