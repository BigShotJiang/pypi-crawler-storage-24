"""
Audit Duplicate CIs Tool

Detects duplicate Configuration Items using ServiceNow CI Identification Rules.
Pure duplicate detection without staleness logic (use audit_identify_stale_cis for staleness).

Duplicate workflow:
  audit_duplicate_cis → audit_ci_duplicate_merge_confidence → action_merge_duplicate_cis
"""

import sys
from typing import Any, Dict
from datetime import datetime

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, get_ci_identification_rules, safe_count_records, sample_limit_for_audit_level, sample_limit_for_audit_level

async def audit_duplicate_cis(
    client: ServiceNowClient,
    table_name: str,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Detect duplicate CIs using ServiceNow CI Identification Rules.

    Uses priority-based identification matching ServiceNow algorithm:
    1. Serial number (primary identifier for physical assets)
    2. Asset tag (secondary identifier)
    3. MAC address (for network devices)
    4. Host name (for servers)
    5. IP address (for network devices)

    AUDIT LEVELS:
    - quick: Counts only
    - standard: Counts plus sample issues (recommended)
    - deep: Full duplicate listing

    Args:
        client: ServiceNow client instance
        table_name: CI class to analyze (e.g., 'cmdb_ci_server')
        audit_level: Choose 'quick', 'standard', or 'deep'

    Returns:
        - table: Analyzed CI class
        - total_cis: Total CIs in table
        - duplicate_cis: Count + details
        - pre_marked_duplicates: CIs already marked as Duplicate
        - data_quality_score: Duplicate-based quality score (0-100)
        - remediation_items: CIs to merge
        - audit_metadata: Execution details
    """
    try:
        start_time = datetime.now()

        # Count total CIs
        total_cis = await safe_count_records(client, table_name)

        duplicate_cis = []

        # Find potential duplicates using ServiceNow CI Identification Rules
        records = []
        try:
            all_records = await client.get_table_records(
                table=table_name,
                sysparm_fields="sys_id,name,serial_number,asset_tag,mac_address,host_name,ip_address,discovery_source,sys_created_on",
                sysparm_limit=sample_limit_for_audit_level(audit_level),
            )
            records = all_records.get("result", []) or []
        except Exception as e:
            print(f"[WARN] Could not retrieve records from {table_name}: {e}", file=sys.stderr)
            records = []

        print(f"[audit_duplicate_cis] Retrieved {len(records)} records from {table_name}", file=sys.stderr)

        # Check for CIs already marked as Duplicate
        marked_duplicates = []
        try:
            duplicate_query = "discovery_sourceLIKEDuplicate"
            duplicate_marked_records = await client.get_table_records(
                table=table_name,
                sysparm_query=duplicate_query,
                sysparm_fields="sys_id,name,serial_number,asset_tag,discovery_source",
                sysparm_limit=sample_limit_for_audit_level(audit_level),
            )
            marked_duplicates = duplicate_marked_records.get("result", []) or []
        except Exception as e:
            print(f"[WARN] Could not query marked duplicates: {e}", file=sys.stderr)
            marked_duplicates = []

        # Fetch CI Identification Rules
        all_rules = get_ci_identification_rules()
        table_rules = all_rules.get(table_name, {})
        identification_fields = table_rules.get("identification_fields", ["name", "sys_id"])
        identification_rules = [{"field": field, "order": i} for i, field in enumerate(identification_fields)]

        # Enhance with CSDM rules if ServiceNow rules unavailable
        if not identification_rules:
            try:
                csdm_rules = get_csdm_rules()
                if hasattr(csdm_rules, 'get_duplicate_detection_fields'):
                    csdm_dup_fields = csdm_rules.get_duplicate_detection_fields(table_name) or []
                    identification_rules = [{"field": field, "order": i} for i, field in enumerate(csdm_dup_fields)]
            except Exception:
                pass

        # Build identification maps
        identification_maps = {}
        for rule in identification_rules:
            field_name = rule.get("field", "")
            if field_name:
                identification_maps[field_name] = {}

        def extract_field_value(val):
            """Extract string value from field (handles dict, None, empty)"""
            if not val:
                return ""
            if isinstance(val, dict):
                return str(val.get("display_value") or val.get("value") or "").strip()
            return str(val).strip()

        # Populate identification maps
        for record in records:
            # Skip if already marked as duplicate
            discovery_source_val = record.get("discovery_source", "")
            if isinstance(discovery_source_val, dict):
                discovery_source_val = discovery_source_val.get("display_value") or discovery_source_val.get("value") or ""
            discovery_source_str = str(discovery_source_val).strip().lower() if discovery_source_val else ""
            if discovery_source_str == "duplicate":
                continue

            # Check each identification rule
            for rule in identification_rules:
                field_name = rule.get("field", "")
                if not field_name or field_name not in record:
                    continue

                field_value = extract_field_value(record.get(field_name))

                if field_value and field_value.lower() not in ("none", "null", ""):
                    if field_value not in identification_maps[field_name]:
                        identification_maps[field_name][field_value] = []
                    identification_maps[field_name][field_value].append(record)

        # Build duplicate list
        processed_sets = set()

        for rule in identification_rules:
            field_name = rule.get("field", "")
            priority = rule.get("order", 999)

            if field_name not in identification_maps:
                continue

            for field_value, records_list in identification_maps[field_name].items():
                if len(records_list) > 1:
                    sys_ids_tuple = tuple(sorted([r.get("sys_id") for r in records_list]))
                    if sys_ids_tuple not in processed_sets:
                        processed_sets.add(sys_ids_tuple)

                        duplicate_cis.append({
                            "type": f"duplicate_{field_name}",
                            "identifier": field_name,
                            "value": field_value,
                            "count": len(records_list),
                            "sys_ids": [r.get("sys_id") for r in records_list],
                            "names": [r.get("name") for r in records_list],
                            "reason": f"Multiple CIs share {field_name.replace('_', ' ')} '{field_value}' (priority: {priority})"
                        })

        total_duplicate_count = len(duplicate_cis) + len(marked_duplicates)

        # Calculate quality score based on duplicates only
        data_quality_score = max(0, 100 - (total_duplicate_count / max(total_cis, 1) * 100))

        # Build remediation items
        remediation_items = []
        for dup in duplicate_cis[:10]:
            ci_name = dup["names"][0] if dup.get("names") else "Unknown"
            remediation_items.append({
                "type": "duplicate",
                "ci": ci_name,
                "rule": dup.get("identifier", "unknown"),
                "action": f"Merge {dup['count']} duplicate records using {dup.get('identifier')}",
                "sys_ids": dup["sys_ids"]
            })

        return {
            "table": table_name,
            "total_cis": total_cis,
            "duplicate_cis": {
                "count": len(duplicate_cis),
                "pre_marked_duplicates": len(marked_duplicates),
                "total_duplicates": total_duplicate_count,
                "detection_method": "ServiceNow CI Identification Rules (priority: serial, asset_tag, mac, hostname, ip)",
                "examples": duplicate_cis[:5] if audit_level == "deep" else duplicate_cis[:2]
            },
            "data_quality_score": round(data_quality_score, 1),
            "remediation_items": remediation_items if audit_level == "deep" else remediation_items[:5],
            "status": "success",
            "metadata": build_audit_metadata(
                audit_type="duplicate_detection",
                audit_level=audit_level,
                execution_time=(datetime.now() - start_time).total_seconds(),
                ci_class=table_name
            )
        }
    except Exception as e:
        print(f"[ERROR] audit_duplicate_cis failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "table": table_name,
            "status": "error",
            "error": str(e)
        }
