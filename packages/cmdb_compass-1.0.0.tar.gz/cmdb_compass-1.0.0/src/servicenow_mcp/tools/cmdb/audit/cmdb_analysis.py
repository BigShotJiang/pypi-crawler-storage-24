"""CMDB analysis helpers used by MCP tools."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient

from . import utils
from servicenow_mcp.tools.cmdb.audit.utils import extract_display_value, safe_count_records, sample_limit_for_audit_level


async def analyze_ci_completeness(
    client: ServiceNowClient,
    *,
    ci_class: str,
    ci_table: str,
    domain: Optional[str],
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Evaluate field completeness for a given CI class."""
    total_cis = await safe_count_records(client, ci_table)

    if total_cis == 0:
        return {
            "ci_class": ci_class,
            "total_cis": 0,
            "critical_fields": {},
            "overall_completeness": 0.0,
            "populated_by_field": {},
            "gaps": [],
            "status": "success",
            "audit_metadata": utils.build_audit_metadata(audit_level, 0, 0),
            "note": "No CIs found in class",
        }

    if audit_level == "quick":
        return {
            "ci_class": ci_class,
            "total_cis": total_cis,
            "critical_fields": {},
            "overall_completeness": 50.0,
            "populated_by_field": {},
            "gaps": [],
            "status": "success",
            "audit_metadata": utils.build_audit_metadata(audit_level, total_cis, 0),
            "quick_summary": "Run standard audit for field-by-field detail.",
        }

    sample_size = total_cis if audit_level == "deep" else utils.calculate_sample_size(total_cis)
    sample_percentage = 100 if audit_level == "deep" else utils.SAMPLE_SIZE_PERCENT

    required_fields = await utils.get_required_fields_from_sys_dictionary(client, ci_table)
    critical_fields = required_fields.get("mandatory", []) or [
        "name",
        "sys_class_name",
        "operational_status",
        "install_status",
        "managed_by",
        "owned_by",
    ]
    business_context_fields = required_fields.get("business_critical", []) or [
        "support_group",
        "environment",
        "location",
        "cost_center",
    ]
    tagging_fields = ["sys_tags"]

    field_population: Dict[str, Dict[str, Any]] = {}
    gaps: List[Dict[str, Any]] = []

    async def _count_populated(field: str) -> int:
        query = f"{field}!EMPTY"
        response = await client.count_records(ci_table, sysparm_query=query)
        return response[0] if isinstance(response, tuple) else response

    for field in critical_fields + business_context_fields + tagging_fields:
        populated = await _count_populated(field)
        category = (
            "critical"
            if field in critical_fields
            else "business_context"
            if field in business_context_fields
            else "tagging"
        )
        population_percent = (populated / total_cis * 100) if total_cis > 0 else 0.0
        field_population[field] = {
            "populated": populated,
            "percentage": round(population_percent, 1),
            "category": category,
        }

        if population_percent < 80:
            gaps.append(
                {
                    "field": field,
                    "percentage": round(population_percent, 1),
                    "populated_count": populated,
                    "total": total_cis,
                    "category": category,
                    "recommendation": _generate_field_recommendation(field, category),
                }
            )

    critical_scores = [info["percentage"] for info in field_population.values() if info["category"] == "critical"]
    business_scores = [info["percentage"] for info in field_population.values() if info["category"] == "business_context"]
    tagging_scores = [info["percentage"] for info in field_population.values() if info["category"] == "tagging"]

    critical_avg = sum(critical_scores) / len(critical_scores) if critical_scores else 0.0
    business_avg = sum(business_scores) / len(business_scores) if business_scores else 0.0
    tagging_avg = sum(tagging_scores) / len(tagging_scores) if tagging_scores else 0.0

    overall_completeness = round((critical_avg + business_avg + tagging_avg) / 3, 1)

    # Show ALL gaps, no artificial limits
    gaps_sorted = sorted(gaps, key=lambda item: item["percentage"])

    result: Dict[str, Any] = {
        "ci_class": ci_class,
        "total_cis": total_cis,
        "sample_size": sample_size,
        "sample_percent": sample_percentage,
        "critical_fields": field_population,
        "overall_completeness": overall_completeness,
        "gaps": gaps_sorted,
        "critical_gaps_count": len([g for g in gaps_sorted if g["category"] == "critical"]),
        "business_gaps_count": len([g for g in gaps_sorted if g["category"] == "business_context"]),
        "tagging_gaps_count": len([g for g in gaps_sorted if g["category"] == "tagging"]),
        "domain": domain,
        "status": "success",
        "audit_metadata": utils.build_audit_metadata(audit_level, total_cis, sample_size),
    }

    if audit_level == "standard":
        result["confidence_interval"] = utils.calculate_confidence_interval(
            overall_completeness,
            sample_size,
            total_cis,
        )

    return result


async def assess_relationship_coverage(
    client: ServiceNowClient,
    *,
    ci_class: str,
    ci_table: str,
    domain: Optional[str],
    audit_level: utils.AuditLevel,
) -> Dict[str, Any]:
    """Evaluate relationship coverage for a CI class."""
    total_cis = await safe_count_records(client, ci_table)

    rel_query = f"ci_item.sys_class_name={ci_class}"
    rel_records = await client.get_table_records(
        table="cmdb_rel_ci",
        sysparm_query=rel_query,
        sysparm_fields="sys_id,ci_item,ci_item.name,rel_type,related_ci,related_ci.name",
        sysparm_display_value="true",
        sysparm_limit=sample_limit_for_audit_level(audit_level),
    )
    relationships = rel_records.get("result", []) or []

    rel_types: Dict[str, int] = {}
    ci_with_rels: set[str] = set()
    unclassified: List[Dict[str, Any]] = []

    for rel in relationships:
        ci_item = rel.get("ci_item")
        ci_id_val = extract_display_value(ci_item)
        if ci_id_val:
            ci_with_rels.add(ci_id_val)

        rel_type = rel.get("rel_type")
        rel_type_name = extract_display_value(rel_type)
        if rel_type_name:
            rel_types[rel_type_name] = rel_types.get(rel_type_name, 0) + 1
        else:
            related_ci = extract_display_value(rel.get("related_ci"))
            unclassified.append(
                {
                    "ci": ci_id_val,
                    "rel_sys_id": rel.get("sys_id"),
                    "related_ci": related_ci,
                    "rel_type_raw": rel_type,
                }
            )

    coverage_percent = (len(ci_with_rels) / total_cis * 100) if total_cis > 0 else 0.0
    expected_rel_types = [
        "Hosted on::Hosts",
        "Deployed on::Deploys",
        "Depends on::Dependency",
        "Composed of::Component of",
        "Managed by::Manages",
    ]
    missing_types = [rel for rel in expected_rel_types if rel not in rel_types]

    return {
        "ci_class": ci_class,
        "total_cis": total_cis,
        "total_relationships": len(relationships),
        "relationship_types": rel_types,
        "unclassified_relationships": len(unclassified),
        "unclassified_examples": unclassified[:3] if audit_level == "deep" else unclassified[:1],
        "coverage_percent": round(coverage_percent, 1),
        "cis_with_relationships": len(ci_with_rels),
        "cis_without_relationships": total_cis - len(ci_with_rels),
        "expected_relationship_types": expected_rel_types,
        "missing_relationship_types": missing_types,
        "relationship_quality": _relationship_quality_label(coverage_percent),
        "quality_note": (
            "Several relationships are missing type information" if unclassified else None
        ),
        "domain": domain,
        "status": "success",
        "audit_metadata": utils.build_audit_metadata(audit_level, total_cis, len(ci_with_rels)),
    }


async def identify_domain_gaps(
    client: ServiceNowClient,
    *,
    domain: str,
    audit_level: utils.AuditLevel,
    sanitize_table: Callable[[str], str],
) -> Dict[str, Any]:
    """Aggregate completeness and relationship gaps for a CSDM domain."""
    domain_ci_classes = {
        "foundation": [
            "cmdb_ci_server",
            "cmdb_ci_network_adapter",
            "cmdb_ci_computer",
            "cmdb_ci_database",
            "cmdb_ci_storage_device",
        ],
        "design": [
            "cmdb_ci_application",
            "cmdb_ci_service",
            "cmdb_ci_business_service",
            "cmdb_ci_app_module",
        ],
        "service_delivery": [
            "cmdb_ci_business_service",
            "cmdb_ci_service",
            "cmdb_ci_service_received",
        ],
    }

    selected_domain = domain.lower().strip()
    ci_classes = domain_ci_classes.get(selected_domain, [])
    if not ci_classes:
        return {
            "domain": domain,
            "status": "error",
            "error": f"Unsupported domain: {domain}",
        }

    completeness_gaps: List[Dict[str, Any]] = []
    relationship_gaps: List[Dict[str, Any]] = []
    total_cis_in_domain = 0

    for ci_class in ci_classes:
        try:
            ci_table = sanitize_table(ci_class)
        except PermissionError as exc:
            return {"domain": domain, "status": "error", "error": str(exc)}

        completeness_result = await analyze_ci_completeness(
            client,
            ci_class=ci_class,
            ci_table=ci_table,
            domain=domain,
            audit_level=audit_level,
        )
        relationship_result = await assess_relationship_coverage(
            client,
            ci_class=ci_class,
            ci_table=ci_table,
            domain=domain,
            audit_level=audit_level,
        )

        total_cis_in_domain += completeness_result.get("total_cis", 0)
        completeness_gaps.append(
            {
                "ci_class": ci_class,
                "overall_completeness": completeness_result.get("overall_completeness", 0),
                "critical_gaps": completeness_result.get("critical_gaps_count", 0),
            }
        )
        relationship_gaps.append(
            {
                "ci_class": ci_class,
                "coverage_percent": relationship_result.get("coverage_percent", 0),
                "missing_relationship_types": relationship_result.get("missing_relationship_types", []),
            }
        )

    completeness_gaps_sorted = sorted(completeness_gaps, key=lambda entry: entry["overall_completeness"])
    relationship_gaps_sorted = sorted(relationship_gaps, key=lambda entry: entry["coverage_percent"])

    remediation_priority = "LOW"
    if completeness_gaps_sorted and completeness_gaps_sorted[0]["overall_completeness"] < 70:
        remediation_priority = "HIGH"
    elif relationship_gaps_sorted and relationship_gaps_sorted[0]["coverage_percent"] < 75:
        remediation_priority = "MEDIUM"

    return {
        "domain": domain,
        "ci_classes_analyzed": len(ci_classes),
        "completeness_gaps": completeness_gaps_sorted,
        "relationship_gaps": relationship_gaps_sorted,
        "remediation_priority": remediation_priority,
        "total_cis_in_domain": total_cis_in_domain,
        "status": "success",
        "audit_metadata": utils.build_audit_metadata(audit_level, total_cis_in_domain, total_cis_in_domain),
    }


def _generate_field_recommendation(field: str, category: str) -> str:
    if category == "critical":
        return f"Populate {field} for all critical CIs to meet audit requirements."
    if category == "business_context":
        return f"Enrich {field} to restore ownership and accountability."
    return f"Tag {field} consistently to enable downstream analytics."


def _relationship_quality_label(coverage_percent: float) -> str:
    if coverage_percent >= 80:
        return "good"
    if coverage_percent >= 50:
        return "fair"
    return "poor"
