"""
Calculate CSDM Maturity Score Tool

Calculate CSDM 5.0 maturity score based on component metrics.
Audit-level tool for maturity assessment (free).
"""

import sys
from typing import Any, Dict

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata


async def calculate_csdm_maturity_score(
    client: ServiceNowClient,
    completeness_score: float = 0,
    relationship_score: float = 0,
    data_quality_score: float = 0,
    standardization_score: float = 0,
    audit_level: AuditLevel = "standard",
) -> Dict[str, Any]:
    """
    Calculate the CSDM 5.0 maturity score based on analysis results.

    This atomic tool aggregates individual assessment scores into an overall
    CSDM maturity level (1-5) and provides maturity grade indicators.

    Supports three audit levels:
    - quick: Maturity score only, no recommendations
    - standard (default): Score with key insights
    - deep: Full analysis with detailed roadmap

    Args:
        client: ServiceNow client instance
        completeness_score: CI field completeness percentage (0-100)
        relationship_score: CI relationship coverage percentage (0-100)
        data_quality_score: Data quality and validity score (0-100)
        standardization_score: Standardization and classification score (0-100)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'

    Returns:
        Dictionary containing:
        - maturity_level: CSDM maturity level (1-5)
        - maturity_grade: Grade (Bronze/Silver/Gold/Platinum)
        - overall_score: Weighted average score (0-100)
        - component_scores: Individual scores for each dimension
        - key_strengths: Top performing areas
        - key_weaknesses: Areas needing improvement (limited for quick)
        - roadmap_recommendations: Priority actions for improvement (full for deep only)
        - audit_metadata: Cost and coverage information
    """
    try:
        # Use provided scores or defaults
        scores = {
            "completeness": max(0, min(100, completeness_score)),
            "relationships": max(0, min(100, relationship_score)),
            "data_quality": max(0, min(100, data_quality_score)),
            "standardization": max(0, min(100, standardization_score))
        }

        # Calculate weighted overall score
        # Weight distribution for CSDM maturity
        weights = {
            "completeness": 0.35,
            "relationships": 0.25,
            "data_quality": 0.25,
            "standardization": 0.15
        }

        overall_score = sum(scores[key] * weights[key] for key in scores.keys())

        # Determine maturity level (1-5)
        if overall_score >= 90:
            maturity_level = 5
            maturity_grade = "Platinum"
            level_description = "Advanced - Highly mature CSDM with excellent data governance"
        elif overall_score >= 75:
            maturity_level = 4
            maturity_grade = "Gold"
            level_description = "Managed - Well-established CSDM practices"
        elif overall_score >= 60:
            maturity_level = 3
            maturity_grade = "Silver"
            level_description = "Optimized - CSDM foundation in place with improvement areas"
        elif overall_score >= 40:
            maturity_level = 2
            maturity_grade = "Bronze"
            level_description = "Defined - Basic CSDM structure with significant gaps"
        else:
            maturity_level = 1
            maturity_grade = "Initial"
            level_description = "Ad hoc - CMDB exists but lacks CSDM structure"

        # Identify strengths and weaknesses
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        key_strengths = [
            {"dimension": k, "score": v, "assessment": "Excellent" if v >= 80 else "Good"}
            for k, v in sorted_scores[:2]
        ]

        key_weaknesses = [
            {"dimension": k, "score": v, "assessment": "Critical" if v < 50 else "Needs Improvement"}
            for k, v in sorted_scores[-2:]
        ]

        # Generate roadmap recommendations with estimated maturity impact
        recommendations = []

        if scores["completeness"] < 80:
            # Estimate impact: completeness is weighted 35%, fixing to 90% = +0.35*25 = +8.75 points
            estimated_impact = round((90 - scores["completeness"]) * weights["completeness"], 1)
            recommendations.append({
                "priority": "high",
                "area": "Field Completeness",
                "action": "Implement CI enrichment process to populate missing fields",
                "impact": "Improve data availability for AI-driven operations",
                "current_score": round(scores["completeness"], 1),
                "target_score": 90,
                "estimated_improvement": estimated_impact,
                "new_overall_score": round(overall_score + estimated_impact, 1)
            })

        if scores["relationships"] < 80:
            # Estimate impact: relationships weighted 25%, fixing to 80% = +0.25*gap
            estimated_impact = round((80 - scores["relationships"]) * weights["relationships"], 1)
            recommendations.append({
                "priority": "high",
                "area": "Relationship Coverage",
                "action": "Define and enforce CSDM relationship mappings",
                "impact": "Enable impact analysis and change management",
                "current_score": round(scores["relationships"], 1),
                "target_score": 80,
                "estimated_improvement": estimated_impact,
                "new_overall_score": round(overall_score + estimated_impact, 1)
            })

        if scores["data_quality"] < 80:
            estimated_impact = round((80 - scores["data_quality"]) * weights["data_quality"], 1)
            recommendations.append({
                "priority": "medium",
                "area": "Data Quality",
                "action": "Establish data quality rules and deduplication process",
                "impact": "Reduce CMDB reconciliation effort and improve automation reliability",
                "current_score": round(scores["data_quality"], 1),
                "target_score": 80,
                "estimated_improvement": estimated_impact,
                "new_overall_score": round(overall_score + estimated_impact, 1)
            })

        if scores["standardization"] < 70:
            estimated_impact = round((80 - scores["standardization"]) * weights["standardization"], 1)
            recommendations.append({
                "priority": "medium",
                "area": "Standardization",
                "action": "Enforce CI type taxonomy and classification standards",
                "impact": "Improve CMDB consistency and searchability",
                "current_score": round(scores["standardization"], 1),
                "target_score": 80,
                "estimated_improvement": estimated_impact,
                "new_overall_score": round(overall_score + estimated_impact, 1)
            })

        if not recommendations:
            recommendations = [{
                "priority": "low",
                "area": "Continuous Improvement",
                "action": "Monitor CSDM metrics and maintain current practices",
                "impact": "Sustain CSDM maturity level",
                "estimated_improvement": 0
            }]

        return {
            "maturity_level": maturity_level,
            "maturity_grade": maturity_grade,
            "level_description": level_description,
            "overall_score": round(overall_score, 1),
            "component_scores": {k: round(v, 1) for k, v in scores.items()},
            "score_weights": weights,
            "key_strengths": key_strengths,
            "key_weaknesses": key_weaknesses[:3] if audit_level in ["quick", "standard"] else key_weaknesses,
            "roadmap_recommendations": recommendations if audit_level == "deep" else recommendations[:3],
            "status": "success",
            "audit_metadata": build_audit_metadata(audit_level, 1, 1)
        }
    except Exception as e:
        print(f"[ERROR] calculate_csdm_maturity_score failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "status": "error",
            "error": str(e)
        }
