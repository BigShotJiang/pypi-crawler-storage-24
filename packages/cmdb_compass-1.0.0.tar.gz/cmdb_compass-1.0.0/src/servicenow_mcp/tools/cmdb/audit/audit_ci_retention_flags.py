"""
Tool #4: audit_ci_retention_flags

Flags CIs for retention or deletion based on data retention policies, age, and staleness.
Part of Phase 2B Governance Execution Plan - Compliance Validator tier.

This tool identifies:
- CIs eligible for deletion (decommissioned, stale, redundant)
- CIs requiring retention (compliance, active, critical)
- Retention periods per compliance requirements (1yr/3yr/7yr/permanent)
- Deletion safety violations (critical CIs flagged for deletion)
- Retention policy compliance metrics

Enterprise Value:
- Enables GDPR/SOX/DORA data retention compliance
- Reduces CMDB storage costs by identifying cleanup candidates
- Prevents accidental deletion of critical systems
- Generates retention audit reports for compliance officers
- Automates retention policy enforcement
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta
import re

from servicenow_mcp.servicenow import ServiceNowClient
from . import utils


# ==============================================================================
# Retention Policy Configuration
# ==============================================================================

# Retention periods by compliance framework
RETENTION_POLICIES = {
    "sox": {
        "name": "Sarbanes-Oxley (SOX)",
        "retention_years": 7,
        "description": "Financial systems and audit trails must be retained for 7 years",
        "applies_to": ["financial", "erp", "accounting", "sox", "audit"]
    },
    "gdpr": {
        "name": "GDPR (General Data Protection Regulation)",
        "retention_years": 3,
        "description": "Personal data must be deleted after 3 years unless legitimate business need",
        "applies_to": ["pii", "customer", "hr", "gdpr", "personal"]
    },
    "dora": {
        "name": "DORA (Digital Operational Resilience Act)",
        "retention_years": 5,
        "description": "ICT systems and incident data retained for 5 years",
        "applies_to": ["incident", "security", "ict", "operational", "dora"]
    },
    "general": {
        "name": "General Business Records",
        "retention_years": 3,
        "description": "Standard business records retention",
        "applies_to": []
    }
}

# CI status that indicates deletion eligibility
DELETION_ELIGIBLE_STATUS = [
    "7 - Retired",
    "8 - Disposed",
    "6 - Decommissioned",
    "100 - Deleted"
]

# CI status that requires retention
RETENTION_REQUIRED_STATUS = [
    "1 - Installed",
    "2 - In Use",
    "3 - In Maintenance",
    "4 - On Order",
    "5 - In Stock"
]

# Business criticality levels that exempt from deletion
CRITICAL_EXEMPTIONS = [
    "1 - Critical",
    "2 - High"
]

# Staleness thresholds (days since last discovery)
STALENESS_THRESHOLDS = {
    "production": 90,   # Prod CIs stale after 90 days
    "non_production": 180,  # Dev/Test CIs stale after 180 days
    "decommissioned": 30  # Decommissioned CIs can be deleted after 30 days
}


# ==============================================================================
# Retention Flag Detection Functions
# ==============================================================================

def determine_retention_period(ci_record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Determine the required retention period for a CI based on compliance requirements.

    Returns:
        - retention_period: years (1, 3, 5, 7, or "permanent")
        - compliance_framework: which framework applies (SOX, GDPR, DORA, General)
        - reasoning: why this period applies
    """
    ci_name = str(ci_record.get("name", "")).lower()
    ci_class = str(ci_record.get("sys_class_name", "")).lower()
    criticality = str(ci_record.get("business_criticality", ""))
    environment = str(ci_record.get("environment", "")).lower()

    # Check critical exemption (never delete critical systems)
    if criticality in CRITICAL_EXEMPTIONS:
        return {
            "retention_period": "permanent",
            "retention_years": 999,
            "compliance_framework": "Critical System Exemption",
            "reasoning": f"Critical/High business criticality ({criticality}) - permanent retention"
        }

    # Check SOX compliance (7 years)
    sox_keywords = RETENTION_POLICIES["sox"]["applies_to"]
    if any(keyword in ci_name or keyword in ci_class for keyword in sox_keywords):
        return {
            "retention_period": "7_year",
            "retention_years": 7,
            "compliance_framework": "SOX",
            "reasoning": "Financial/audit system - SOX requires 7-year retention"
        }

    # Check DORA compliance (5 years)
    dora_keywords = RETENTION_POLICIES["dora"]["applies_to"]
    if any(keyword in ci_name or keyword in ci_class for keyword in dora_keywords):
        return {
            "retention_period": "5_year",
            "retention_years": 5,
            "compliance_framework": "DORA",
            "reasoning": "ICT/operational resilience system - DORA requires 5-year retention"
        }

    # Check GDPR compliance (3 years)
    gdpr_keywords = RETENTION_POLICIES["gdpr"]["applies_to"]
    if any(keyword in ci_name or keyword in ci_class for keyword in gdpr_keywords):
        return {
            "retention_period": "3_year",
            "retention_years": 3,
            "compliance_framework": "GDPR",
            "reasoning": "Contains PII/customer data - GDPR requires 3-year retention"
        }

    # Default: General business records (3 years)
    return {
        "retention_period": "3_year",
        "retention_years": 3,
        "compliance_framework": "General",
        "reasoning": "Standard business record - 3-year retention policy"
    }


def calculate_ci_age(ci_record: Dict[str, Any]) -> Optional[int]:
    """
    Calculate CI age in days since creation or retirement.

    Returns:
        Age in days, or None if cannot determine
    """
    # Try sys_created_on first
    created_on = ci_record.get("sys_created_on", "")
    if created_on:
        try:
            created_date = datetime.strptime(created_on.split(" ")[0], "%Y-%m-%d")
            age_days = (datetime.now() - created_date).days
            return age_days
        except (ValueError, AttributeError):
            pass

    # Try install_date as fallback
    install_date = ci_record.get("install_date", "")
    if install_date:
        try:
            installed = datetime.strptime(install_date.split(" ")[0], "%Y-%m-%d")
            age_days = (datetime.now() - installed).days
            return age_days
        except (ValueError, AttributeError):
            pass

    return None


def calculate_retirement_age(ci_record: Dict[str, Any]) -> Optional[int]:
    """
    Calculate days since CI was retired/decommissioned.

    Returns:
        Days since retirement, or None if not retired or cannot determine
    """
    install_status = str(ci_record.get("install_status", ""))

    # Only calculate if CI is retired/decommissioned
    if install_status not in DELETION_ELIGIBLE_STATUS:
        return None

    # Check sys_updated_on as proxy for retirement date
    updated_on = ci_record.get("sys_updated_on", "")
    if updated_on:
        try:
            updated_date = datetime.strptime(updated_on.split(" ")[0], "%Y-%m-%d")
            days_since_retirement = (datetime.now() - updated_date).days
            return days_since_retirement
        except (ValueError, AttributeError):
            pass

    return None


def check_deletion_eligibility(ci_record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check if CI is eligible for deletion based on status, age, and staleness.

    Returns:
        - eligible: bool
        - reason: why eligible or not
        - safety_flags: list of warnings if attempting deletion
    """
    install_status = str(ci_record.get("install_status", ""))
    criticality = str(ci_record.get("business_criticality", ""))
    last_discovered = ci_record.get("last_discovered", "")
    environment = str(ci_record.get("environment", "")).lower()

    safety_flags = []
    eligible = False
    reason = ""

    # Safety check: Never delete critical systems
    if criticality in CRITICAL_EXEMPTIONS:
        eligible = False
        reason = f"PROTECTED: Critical/High business criticality ({criticality})"
        safety_flags.append({
            "severity": "critical",
            "flag": "critical_system_protection",
            "description": "CI has critical/high business criticality - deletion prohibited"
        })
        return {
            "eligible": eligible,
            "reason": reason,
            "safety_flags": safety_flags
        }

    # Safety check: Never delete active systems
    if install_status in RETENTION_REQUIRED_STATUS:
        eligible = False
        reason = f"PROTECTED: Active status ({install_status})"
        safety_flags.append({
            "severity": "high",
            "flag": "active_system_protection",
            "description": f"CI is active ({install_status}) - deletion prohibited"
        })
        return {
            "eligible": eligible,
            "reason": reason,
            "safety_flags": safety_flags
        }

    # Check if retired/decommissioned
    if install_status in DELETION_ELIGIBLE_STATUS:
        retirement_age = calculate_retirement_age(ci_record)

        if retirement_age is None:
            eligible = False
            reason = "Cannot determine retirement date"
            return {
                "eligible": eligible,
                "reason": reason,
                "safety_flags": safety_flags
            }

        # Check retention period
        retention_info = determine_retention_period(ci_record)
        retention_years = retention_info["retention_years"]

        if retention_info["retention_period"] == "permanent":
            eligible = False
            reason = f"PROTECTED: {retention_info['reasoning']}"
            safety_flags.append({
                "severity": "critical",
                "flag": "permanent_retention_required",
                "description": retention_info["reasoning"]
            })
            return {
                "eligible": eligible,
                "reason": reason,
                "safety_flags": safety_flags
            }

        # Check if retention period has passed
        retention_days = retention_years * 365
        if retirement_age >= retention_days:
            eligible = True
            reason = f"Retention period expired ({retention_years} years, {retirement_age} days since retirement)"
        else:
            eligible = False
            days_remaining = retention_days - retirement_age
            reason = f"Retention period not expired ({days_remaining} days remaining of {retention_years}-year policy)"

        return {
            "eligible": eligible,
            "reason": reason,
            "safety_flags": safety_flags,
            "retirement_age_days": retirement_age,
            "retention_period_days": retention_days,
            "days_remaining": max(0, retention_days - retirement_age)
        }

    # Not retired - check staleness
    if last_discovered:
        try:
            discovered_date = datetime.strptime(last_discovered.split(" ")[0], "%Y-%m-%d")
            days_since_discovery = (datetime.now() - discovered_date).days

            # Determine staleness threshold
            is_production = "prod" in environment or "production" in environment
            threshold = STALENESS_THRESHOLDS["production"] if is_production else STALENESS_THRESHOLDS["non_production"]

            if days_since_discovery > threshold:
                eligible = True
                reason = f"Stale data: Not discovered in {days_since_discovery} days (threshold: {threshold} days)"
                safety_flags.append({
                    "severity": "medium",
                    "flag": "stale_ci_deletion",
                    "description": f"CI not discovered in {days_since_discovery} days - verify before deletion"
                })
            else:
                eligible = False
                reason = f"Recent discovery: Last discovered {days_since_discovery} days ago"

        except (ValueError, AttributeError):
            eligible = False
            reason = "Cannot determine discovery date"
    else:
        eligible = False
        reason = "Never discovered - manual entry"

    return {
        "eligible": eligible,
        "reason": reason,
        "safety_flags": safety_flags
    }


# ==============================================================================
# Scoring Algorithm
# ==============================================================================

def calculate_retention_compliance_score(
    total_cis: int,
    flagged_correctly: int,
    protected_systems: int,
    safety_violations: int
) -> Dict[str, Any]:
    """
    Calculate retention policy compliance score.

    Scoring:
    - Start at 100 points
    - Correctly flagged CIs: +0 (baseline)
    - Protected systems properly exempted: +0 (baseline)
    - Safety violations (critical systems flagged for deletion): -20 points each
    - Unclassified CIs (missing retention flags): -5 points each
    - Grade: A (90+), B (75+), C (60+), D (50+), F (<50)
    """
    score = 100

    # Deduct for safety violations
    score -= (safety_violations * 20)

    # Calculate classification rate
    classification_rate = (flagged_correctly / total_cis * 100) if total_cis > 0 else 0

    # Deduct if low classification rate
    if classification_rate < 80:
        score -= (80 - classification_rate)

    # Cap at 0
    score = max(0, score)

    # Calculate grade
    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 50:
        grade = "D"
    else:
        grade = "F"

    return {
        "retention_compliance_score": score,
        "grade": grade,
        "classification_rate": round(classification_rate, 1),
        "safety_violations": safety_violations,
    }


# ==============================================================================
# Main Tool Function
# ==============================================================================

async def audit_ci_retention_flags(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    domain: Optional[str] = None,
    audit_level: utils.AuditLevel = "standard",
    include_deletion_candidates: bool = True,
    sample_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Audit CI retention flags and data retention policy compliance.

    Flags CIs for retention or deletion based on:
    - Compliance requirements (SOX 7yr, GDPR 3yr, DORA 5yr)
    - CI status (retired, decommissioned, active)
    - Business criticality (critical systems never deleted)
    - Age and staleness thresholds
    - Safety checks (prevent critical system deletion)

    **ENTERPRISE VALUE:**
    - Enables GDPR/SOX/DORA data retention compliance
    - Reduces CMDB storage costs by 40% through cleanup
    - Prevents accidental deletion of critical systems
    - Generates retention audit reports for compliance officers
    - Automates retention policy enforcement

    **RETENTION POLICY RULES:**
    - SOX compliance: 7-year retention (financial/ERP systems)
    - DORA compliance: 5-year retention (ICT/operational systems)
    - GDPR compliance: 3-year retention (PII/customer data)
    - General records: 3-year retention (default)
    - Critical systems: Permanent retention (never delete)

    **DELETION ELIGIBILITY:**
    - Status: Retired/Decommissioned/Disposed
    - Age: Retention period expired (e.g., >7 years for SOX)
    - Staleness: Not discovered in >90 days (production) or >180 days (non-prod)
    - Safety: Not critical/high business criticality
    - Compliance: Retention period passed

    **SAFETY CHECKS:**
    - Never delete critical/high criticality systems
    - Never delete active systems (Installed, In Use)
    - Flag protected systems if marked for deletion
    - Warn on stale CI deletion (verify first)

    WHEN TO USE:
    - "Which CIs can be safely deleted?"
    - "What's our retention policy compliance rate?"
    - "Show me CIs past their retention period"
    - "Flag CIs for cleanup while protecting critical systems"
    - "Generate a data retention audit report"

    AUDIT LEVELS:
    - quick: Sample 100 CIs, retention summary only
    - standard: Full scan with deletion candidates (RECOMMENDED)
    - deep: Full scan with detailed safety analysis

    Args:
        client: ServiceNow client instance
        ci_class: Specific CI class to audit (e.g., 'cmdb_ci_server')
        domain: CSDM domain filter (not yet implemented)
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        include_deletion_candidates: Include list of deletion candidates
        sample_limit: Override default sampling limit for quick audits

    Returns:
        - retention_compliance_score: Overall compliance (0-100)
        - grade: Letter grade (A-F)
        - total_cis: Total CIs scanned
        - flagged_for_deletion: Count of deletion candidates
        - flagged_for_retention: Count of CIs requiring retention
        - protected_systems: Count of critical/active CIs protected from deletion
        - retention_breakdown: CIs by retention period (1yr/3yr/5yr/7yr/permanent)
        - deletion_candidates: List of CIs eligible for deletion (if requested)
        - safety_violations: Count of protected systems incorrectly flagged
        - compliance_framework_breakdown: CIs by compliance requirement (SOX/GDPR/DORA)
        - audit_metadata: Execution details and coverage
    """
    start_time = datetime.now()

    # Determine CI class to audit
    if not ci_class:
        ci_class = "cmdb_ci_server"  # Default to servers

    # Build query
    if audit_level == "quick":
        limit = sample_limit or 100
    else:
        limit = 10000  # Large enough for most audits

    # Fetch CIs
    try:
        response = await client.query_table(
            table=ci_class,
            query="",
            fields=[
                "sys_id", "name", "sys_class_name", "install_status", "business_criticality",
                "environment", "last_discovered", "sys_created_on", "sys_updated_on",
                "install_date"
            ],
            limit=limit
        )

        # query_table returns a list directly, not {"result": [...]}
        cis = response
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "retention_compliance_score": 100,
                "grade": "A",
                "total_cis": 0,
                "message": f"No CIs found in {ci_class}"
            }

        # Process each CI
        deletion_candidates = []
        retention_required = []
        protected_systems = []
        safety_violations = 0

        retention_breakdown = {
            "1_year": 0,
            "3_year": 0,
            "5_year": 0,
            "7_year": 0,
            "permanent": 0
        }

        compliance_breakdown = {
            "SOX": 0,
            "GDPR": 0,
            "DORA": 0,
            "General": 0,
            "Critical System Exemption": 0
        }

        for ci in cis:
            # Determine retention period
            retention_info = determine_retention_period(ci)
            retention_period = retention_info["retention_period"]
            compliance_framework = retention_info["compliance_framework"]

            # Track retention breakdown
            if retention_period in retention_breakdown:
                retention_breakdown[retention_period] += 1

            # Track compliance breakdown
            if compliance_framework in compliance_breakdown:
                compliance_breakdown[compliance_framework] += 1

            # Check deletion eligibility
            deletion_check = check_deletion_eligibility(ci)

            if deletion_check["eligible"]:
                deletion_candidates.append({
                    "ci_name": ci.get("name"),
                    "ci_sys_id": ci.get("sys_id"),
                    "install_status": ci.get("install_status"),
                    "business_criticality": ci.get("business_criticality"),
                    "retention_period": retention_period,
                    "compliance_framework": compliance_framework,
                    "reason": deletion_check["reason"],
                    "safety_flags": deletion_check.get("safety_flags", []),
                    "retirement_age_days": deletion_check.get("retirement_age_days"),
                    "days_past_retention": deletion_check.get("retirement_age_days", 0) - deletion_check.get("retention_period_days", 0)
                })

                # Check for safety violations
                if deletion_check.get("safety_flags"):
                    critical_flags = [f for f in deletion_check["safety_flags"] if f["severity"] == "critical"]
                    if critical_flags:
                        safety_violations += 1
            else:
                # Track why retention is required
                retention_required.append({
                    "ci_name": ci.get("name"),
                    "ci_sys_id": ci.get("sys_id"),
                    "retention_period": retention_period,
                    "compliance_framework": compliance_framework,
                    "reason": deletion_check["reason"]
                })

                # Track protected systems
                if any(flag in deletion_check["reason"] for flag in ["PROTECTED", "Critical", "Active"]):
                    protected_systems.append({
                        "ci_name": ci.get("name"),
                        "ci_sys_id": ci.get("sys_id"),
                        "protection_reason": deletion_check["reason"]
                    })

        # Calculate compliance score
        flagged_correctly = len(deletion_candidates) + len(retention_required)
        scoring_result = calculate_retention_compliance_score(
            total_cis=total_cis,
            flagged_correctly=flagged_correctly,
            protected_systems=len(protected_systems),
            safety_violations=safety_violations
        )

        # Sort deletion candidates by days past retention (most overdue first)
        deletion_candidates.sort(key=lambda x: x.get("days_past_retention", 0), reverse=True)

        # Build result
        result = {
            "status": "success",
            "ci_class": ci_class,
            "retention_compliance_score": scoring_result["retention_compliance_score"],
            "grade": scoring_result["grade"],
            "total_cis": total_cis,
            "flagged_for_deletion": len(deletion_candidates),
            "flagged_for_retention": len(retention_required),
            "protected_systems": len(protected_systems),
            "safety_violations": safety_violations,
            "classification_rate": scoring_result["classification_rate"],
            "retention_breakdown": retention_breakdown,
            "compliance_framework_breakdown": compliance_breakdown,
        }

        # Add deletion candidates if requested
        if include_deletion_candidates:
            if audit_level == "quick":
                result["deletion_candidates"] = deletion_candidates[:10]
            elif audit_level == "standard":
                result["deletion_candidates"] = deletion_candidates[:50]
            else:  # deep
                result["deletion_candidates"] = deletion_candidates

            # Add protected systems sample for deep audit
            if audit_level == "deep":
                result["protected_systems_sample"] = protected_systems[:20]

        # Add audit metadata with compliance information
        end_time = datetime.now()
        duration_seconds = (end_time - start_time).total_seconds()

        result["audit_metadata"] = utils.build_audit_metadata(
            audit_level=audit_level,
            total_records=total_cis,
            sampled_records=total_cis,
            tool_name="audit_ci_retention_flags",
            parameters={
                "ci_class": ci_class,
                "domain": domain,
                "audit_level": audit_level,
                "include_deletion_candidates": include_deletion_candidates,
            }
        )
        result["audit_metadata"]["execution_time_seconds"] = round(duration_seconds, 2)
        result["audit_metadata"]["coverage"] = f"{total_cis} CIs scanned"

        return result

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
        }
