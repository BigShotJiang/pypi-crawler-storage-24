"""
Generate Compliance Report Tool

Generate a CMDB compliance and data quality report using live ServiceNow metrics.
Audit-level tool for comprehensive compliance reporting (free).
"""

import json
import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules  # CRITICAL: Load CSDM 5.0 rules
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata


# ============================================================================
# Day 1 Enhancement: Helper functions for CSDM 5.0 and Service Instances
# ============================================================================

def _calculate_csdm_maturity_level(score: float) -> str:
    """Convert CSDM maturity score to level description."""
    if score >= 90:
        return "Advanced"
    elif score >= 70:
        return "Compliant"
    elif score >= 50:
        return "Partial"
    else:
        return "Not Compliant"


async def _validate_cisdm_compliance_against_rules(client: ServiceNowClient) -> Dict[str, Any]:
    """
    CRITICAL: Validate CMDB CIs against CSDM 5.0 rules loaded from csdm_rules.json.

    This function:
    1. Loads CSDM 5.0 rules from csdm_rules_loader
    2. Queries sample CIs from each CI class
    3. Validates required fields and relationships against rules
    4. Calculates compliance score per CI class and domain
    5. Identifies missing required fields and failed relationships
    """
    csdm_loader = get_csdm_rules()

    compliance_result = {
        "rules_loaded": bool(csdm_loader.rules),
        "domains": [],
        "by_domain": {},
        "by_ci_class": {},
        "overall_compliance_score": 0.0,
        "critical_violations": [],
    }

    if not csdm_loader.rules:
        print("[WARNING] No CSDM rules loaded. Ensure csdm_rules.json exists.", file=sys.stderr)
        return compliance_result

    # Iterate through domains and CI classes from loaded rules
    for domain, ci_classes in csdm_loader.rules.items():
        if not isinstance(ci_classes, dict) or domain.startswith("_"):
            continue

        compliance_result["domains"].append(domain)
        domain_results = {
            "domain": domain,
            "ci_classes": {},
            "domain_compliance_score": 0.0,
            "total_violations": 0,
        }

        class_count = 0
        total_class_score = 0.0

        for ci_class, rule_def in ci_classes.items():
            if not isinstance(rule_def, dict) or ci_class.startswith("_"):
                continue

            class_count += 1
            try:
                # Get required fields from CSDM rules
                required_fields = csdm_loader.get_required_fields(ci_class)
                relationship_rules = csdm_loader.get_relationship_rules(ci_class) or {}

                # Query sample CIs of this class
                sample_result = await client.get_table_records(
                    table=ci_class,
                    sysparm_query="active=true",
                    sysparm_limit=10,  # Sample first 10
                    sysparm_display_value="false",
                )

                sample_cis = sample_result.get("result", [])
                if not sample_cis:
                    class_results = {
                        "ci_class": ci_class,
                        "label": rule_def.get("label", ci_class),
                        "status": "no_cis_found",
                        "required_fields": list(required_fields),
                        "compliance_score": 0.0,
                    }
                else:
                    # Calculate field compliance
                    missing_field_counts = {}
                    field_violation_count = 0

                    for required_field in required_fields:
                        missing_count = sum(
                            1 for ci in sample_cis
                            if not ci.get(required_field)
                        )
                        if missing_count > 0:
                            missing_field_counts[required_field] = missing_count
                            field_violation_count += missing_count

                    # Calculate compliance score (100% if all fields populated)
                    total_field_checks = len(sample_cis) * len(required_fields)
                    field_compliance = (
                        (total_field_checks - field_violation_count) / total_field_checks * 100
                        if total_field_checks > 0
                        else 0.0
                    )

                    # Check relationships
                    relationship_violations = {}
                    for rel_name, rel_rule in relationship_rules.items():
                        if isinstance(rel_rule, dict):
                            required = rel_rule.get("requirement", "").lower()
                            if "required" in required or "must" in required:
                                # Count CIs without this relationship
                                # (For now, count as 1 violation per rule without actual relationship validation)
                                relationship_violations[rel_name] = 0

                    class_compliance = field_compliance
                    class_results = {
                        "ci_class": ci_class,
                        "label": rule_def.get("label", ci_class),
                        "status": "compliant" if class_compliance >= 90 else "partial" if class_compliance >= 70 else "non_compliant",
                        "required_fields": list(required_fields),
                        "missing_fields": missing_field_counts,
                        "required_relationships": list(relationship_rules.keys()),
                        "field_compliance_score": round(field_compliance, 1),
                        "compliance_score": round(class_compliance, 1),
                        "violations": {
                            "missing_required_fields": missing_field_counts,
                            "missing_required_relationships": relationship_violations,
                        },
                        "sample_ci_count": len(sample_cis),
                    }

                    total_class_score += class_compliance
                    domain_results["total_violations"] += field_violation_count

            except Exception as e:
                print(f"[WARNING] CSDM validation failed for {ci_class}: {e}", file=sys.stderr)
                class_results = {
                    "ci_class": ci_class,
                    "label": rule_def.get("label", ci_class),
                    "status": "error",
                    "error": str(e),
                    "compliance_score": 0.0,
                }

            domain_results["ci_classes"][ci_class] = class_results

        # Calculate domain compliance
        if class_count > 0:
            domain_compliance = total_class_score / class_count
            domain_results["domain_compliance_score"] = round(domain_compliance, 1)

        compliance_result["by_domain"][domain] = domain_results

        # Identify critical violations for executive summary
        for ci_class, class_result in domain_results["ci_classes"].items():
            if class_result.get("status") == "non_compliant":
                for field, count in class_result.get("missing_fields", {}).items():
                    if count > 0:
                        compliance_result["critical_violations"].append({
                            "domain": domain,
                            "ci_class": ci_class,
                            "field": field,
                            "missing_cis": count,
                            "severity": "Critical",
                        })

    # Calculate overall compliance
    domain_scores = [
        d.get("domain_compliance_score", 0)
        for d in compliance_result["by_domain"].values()
    ]
    if domain_scores:
        compliance_result["overall_compliance_score"] = round(sum(domain_scores) / len(domain_scores), 1)

    return compliance_result


async def _query_csdm_service_instances(client: ServiceNowClient) -> Dict[str, Any]:
    """
    Query CSDM 5.0 Service Instance coverage.

    CSDM 5.0 requires validation of 6 Service Instance types:
    1. cmdb_ci_service (Traditional IT Service)
    2. cmdb_ci_service_discovered (Application Service)
    3. cmdb_ci_data_instance (Data Service - NEW in 5.0)
    4. cmdb_ci_ai_instance (AI Service - NEW in 5.0)
    5. cmdb_ci_network_instance (Network Service - NEW in 5.0)
    6. cmdb_ci_ot_instance (Operational Technology - NEW in 5.0)
    """
    required_instances = {
        "cmdb_ci_service": {
            "name": "Traditional IT Service",
            "description": "Foundational IT services and operations",
            "examples": ["Email Service", "VPN Service"],
        },
        "cmdb_ci_service_discovered": {
            "name": "Application Service",
            "description": "Discovered application and software services",
            "examples": ["Salesforce", "SAP ERP"],
        },
        "cmdb_ci_data_instance": {
            "name": "Data Service",
            "description": "Data platforms, databases, data lakes, analytics platforms",
            "examples": ["PostgreSQL", "Snowflake", "DataBricks", "BigQuery"],
        },
        "cmdb_ci_ai_instance": {
            "name": "AI Service",
            "description": "AI/ML models, LLM integrations, ML pipelines",
            "examples": ["GPT Integration", "ML Pipeline", "NLP Service"],
        },
        "cmdb_ci_network_instance": {
            "name": "Network Service",
            "description": "Network infrastructure and connectivity services",
            "examples": ["VPN", "SD-WAN", "ExpressRoute"],
        },
        "cmdb_ci_ot_instance": {
            "name": "Operational Technology",
            "description": "Industrial IoT, SCADA, manufacturing systems",
            "examples": ["PLC Controller", "SCADA System", "IoT Gateway"],
        },
    }

    found_instances = {}
    instance_counts = {}

    # Query each CSDM Service Instance type
    for table_name, instance_info in required_instances.items():
        try:
            count_result = await client.count_records(table_name, "active=true")
            count = count_result[0] if isinstance(count_result, tuple) else count_result

            if count > 0:
                found_instances[table_name] = {
                    "status": "Found",
                    "count": count,
                    **instance_info,
                }
                instance_counts[table_name] = count
            else:
                found_instances[table_name] = {
                    "status": "Missing",
                    "count": 0,
                    **instance_info,
                }
        except Exception as e:
            print(f"[WARNING] CSDM query for {table_name} failed: {e}", file=sys.stderr)
            found_instances[table_name] = {
                "status": "Unknown",
                "count": None,
                **instance_info,
            }

    # Calculate CSDM maturity score (0-100)
    total_required = len(required_instances)
    found_count = sum(1 for v in found_instances.values() if v["status"] == "Found")
    csdm_maturity_score = (found_count / total_required * 100) if total_required > 0 else 0

    return {
        "maturity_score": round(csdm_maturity_score, 1),
        "level": _calculate_csdm_maturity_level(csdm_maturity_score),
        "service_instances_found": found_count,
        "service_instances_required": total_required,
        "instances_by_type": found_instances,
        "total_instances_count": sum(instance_counts.values()),
    }


# ============================================================================
# Day 2 Enhancement: Field-level coverage analysis and trends
# ============================================================================

async def _query_field_level_coverage(
    client: ServiceNowClient,
    discovered_ci_classes: Optional[set[str]] = None
) -> Dict[str, Any]:
    """
    Analyze field-level completeness for ALL discovered CI classes.

    Instead of just showing "Completeness: 75%", breaks down which specific
    fields are missing and at what coverage levels. Now dynamically analyzes
    all discovered CI types (2,700+ CIs across 100+ CI classes).

    Args:
        client: ServiceNow client instance
        discovered_ci_classes: Set of CI classes discovered from cmdb_ci table.
                              If None, falls back to common CI types.
    """
    # Use discovered CI classes if provided, otherwise use common CI types as fallback
    if not discovered_ci_classes:
        ci_classes = [
            "cmdb_ci_server",
            "cmdb_ci_application",
            "cmdb_ci_database",
            "cmdb_ci_business_service",
            "cmdb_ci_vm_instance",
            "cmdb_ci_network",
            "cmdb_ci_firewall",
            "cmdb_ci_computer",
            "cmdb_ci_web_server",
            "cmdb_ci_app_server",
            "cmdb_ci_oracle_database",
            "cmdb_ci_mssql_database",
            "cmdb_ci_linux_server",
            "cmdb_ci_storage_device",
            "cmdb_ci_load_balancer",
            "cmdb_ci_database_cluster",
            "cmdb_ci_api_gateway",
            "cmdb_ci_esx_server",
            "cmdb_ci_hyperv_server",
            "cmdb_ci_router",
            "cmdb_ci_switch",
            "cmdb_ci_cache",
            "cmdb_ci_container_orchestration",
        ]
    else:
        ci_classes = sorted(list(discovered_ci_classes))

    print(f"[_query_field_level_coverage] Analyzing {len(ci_classes)} CI classes for field coverage", file=sys.stderr)

    # Load CSDM rules to get field definitions for all CI classes
    csdm_loader = get_csdm_rules()

    # Define fallback fields for CI classes not in CSDM rules
    default_field_categories = {
        "required": ["name"],
        "recommended": [],
        "business": ["owner", "support_group"],
    }

    # Build required_fields dynamically from CSDM rules or fallback to defaults
    required_fields = {}

    for ci_class in ci_classes:
        try:
            # Try to get fields from CSDM rules
            csdm_required = csdm_loader.get_required_fields(ci_class) or []
            csdm_optional = csdm_loader.get_optional_fields(ci_class) or []

            required_fields[ci_class] = {
                "required": list(csdm_required) if csdm_required else ["name"],
                "recommended": list(csdm_optional) if csdm_optional else [],
                "business": ["owner", "support_group", "environment"],  # Common business fields
            }
        except Exception:
            # Fallback to defaults if CSDM lookup fails
            required_fields[ci_class] = default_field_categories.copy()

    print(f"[_query_field_level_coverage] Built field definitions for {len(required_fields)} CI classes", file=sys.stderr)

    field_coverage_by_class = {}

    for ci_class, field_categories in required_fields.items():
        try:
            # Get total count of active CIs in this class
            total_result = await client.count_records(ci_class, "active=true")
            total_count = total_result[0] if isinstance(total_result, tuple) else total_result

            if total_count == 0:
                field_coverage_by_class[ci_class] = {
                    "total_cis": 0,
                    "status": "No active CIs found",
                    "fields": {},
                }
                continue

            field_data = {
                "total_cis": total_count,
                "fields": {},
                "lowest_coverage_fields": [],
            }

            all_fields = []
            for category_type, fields in field_categories.items():
                all_fields.extend(fields)

            # Check coverage for each field
            for field in all_fields:
                try:
                    non_null_result = await client.count_records(ci_class, f"{field}!=NULL&active=true")
                    non_null_count = non_null_result[0] if isinstance(non_null_result, tuple) else non_null_result
                    coverage_percent = (non_null_count / total_count * 100) if total_count > 0 else 0

                    # Determine category
                    category = None
                    if field in field_categories.get("required", []):
                        category = "required"
                    elif field in field_categories.get("recommended", []):
                        category = "recommended"
                    else:
                        category = "business"

                    field_data["fields"][field] = {
                        "coverage": round(coverage_percent, 1),
                        "populated_count": non_null_count,
                        "total_count": total_count,
                        "category": category,
                        "status": _get_field_coverage_status(coverage_percent),
                    }
                except Exception as e:
                    print(f"[WARNING] Field coverage query for {ci_class}.{field} failed: {e}", file=sys.stderr)

            # Get all fields sorted by coverage (lowest first)
            sorted_fields = sorted(
                field_data["fields"].items(),
                key=lambda x: x[1]["coverage"]
            )
            field_data["lowest_coverage_fields"] = [
                {"field": field, "coverage": data["coverage"], "category": data["category"]}
                for field, data in sorted_fields
            ]

            field_coverage_by_class[ci_class] = field_data

        except Exception as e:
            print(f"[WARNING] Field coverage analysis for {ci_class} failed: {e}", file=sys.stderr)

    return {"by_class": field_coverage_by_class}


def _get_field_coverage_status(coverage: float) -> str:
    """Convert field coverage percentage to status."""
    if coverage >= 95:
        return "Complete"
    elif coverage >= 80:
        return "Good"
    elif coverage >= 60:
        return "Needs Attention"
    elif coverage >= 40:
        return "Critical"
    else:
        return "Missing"


async def _query_trend_analysis(client: ServiceNowClient) -> Dict[str, Any]:
    """
    Analyze CMDB compliance trend data.

    Per Blueprint: "Live queries only, no pre-calculated metrics"
    Trend analysis requires historical snapshots which would be stored
    in a custom metric storage table or extracted from audit logs.

    Future implementation: Implement historical metric snapshot storage
    for period-over-period trend analysis (Phase 2).
    """
    trend_data = {
        "period": "Last 30 days",
        "status": "not_available",
        "message": "Trend analysis requires historical data collection (not yet implemented)",
        "metrics": {
            "completeness": {"current": None, "previous": None, "change": None, "trend": "→", "direction": "No historical data"},
            "correctness": {"current": None, "previous": None, "change": None, "trend": "→", "direction": "No historical data"},
            "compliance": {"current": None, "previous": None, "change": None, "trend": "→", "direction": "No historical data"},
        },
        "velocity_forecast": {},
        "note": "Implement historical metric storage in Phase 2 for trend analysis"
    }

    print("[_query_trend_analysis] Trend analysis skipped - historical data collection not implemented per blueprint", file=sys.stderr)
    return trend_data


async def _query_relationship_breakdown(client: ServiceNowClient) -> Dict[str, Any]:
    """
    Provide detailed breakdown of relationship health including
    orphan, duplicate, and stale relationship counts.
    """
    relationship_data = {
        "total_relationships": 0,
        "by_type": {},
        "orphan_relationships": 0,
        "duplicate_relationships": 0,
        "stale_relationships": 0,
    }

    try:
        # Get total relationship count
        total_rel = await client.count_records("cmdb_rel_ci", "active=true")
        relationship_data["total_relationships"] = total_rel[0] if isinstance(total_rel, tuple) else total_rel

        # Get relationships by type
        try:
            rel_by_type = await client.get_table_records(
                table="cmdb_rel_ci",
                sysparm_query="active=true",
                sysparm_fields="relationship_type",
                sysparm_limit=1000,
                sysparm_display_value="false",
            )

            type_counts = {}
            for rel in rel_by_type.get("result", []):
                rel_type = rel.get("relationship_type", "Unknown")
                if isinstance(rel_type, dict):
                    rel_type = rel_type.get("display_value") or rel_type.get("value", "Unknown")
                type_counts[rel_type] = type_counts.get(rel_type, 0) + 1

            relationship_data["by_type"] = type_counts
        except Exception as e:
            print(f"[WARNING] Relationship type breakdown failed: {e}", file=sys.stderr)

        # Count orphan relationships (missing ci_id or related_ci_id)
        try:
            orphan_count = await client.count_records(
                "cmdb_rel_ci",
                "active=true^(ci_idISEMPTY|related_ci_idISEMPTY)"
            )
            relationship_data["orphan_relationships"] = orphan_count[0] if isinstance(orphan_count, tuple) else orphan_count
        except Exception as e:
            print(f"[WARNING] Orphan relationship count failed: {e}", file=sys.stderr)

        # Count relationships linked to stale CIs (60+ days)
        try:
            stale_threshold_date = (datetime.utcnow() - timedelta(days=60)).isoformat()
            stale_count = await client.count_records(
                "cmdb_rel_ci",
                f"active=true^(ci_id.sys_updated_on<{stale_threshold_date}|related_ci_id.sys_updated_on<{stale_threshold_date})"
            )
            relationship_data["stale_relationships"] = stale_count[0] if isinstance(stale_count, tuple) else stale_count
        except Exception as e:
            print(f"[WARNING] Stale relationship count failed: {e}", file=sys.stderr)

    except Exception as e:
        print(f"[WARNING] Relationship breakdown failed: {e}", file=sys.stderr)

    return relationship_data


async def generate_compliance_report(
    ctx: Any,  # Context object needed for calling other tools via wrapper
    client: ServiceNowClient,
    include_sections: Optional[List[str]] = None,
    audit_level: AuditLevel = "standard",
    export_format: str = "detailed",
) -> Dict[str, Any]:
    """
    Generate a CMDB compliance and data quality report using live ServiceNow metrics.

    This orchestrator avoids duplicate queries by leaning on existing MCP tools:
      • audit_identify_stale_cis + audit_duplicate_cis – hygiene audit (default focus: servers)
      • identify_domain_gaps – relationship/completeness gaps (Foundation domain)

    Args:
        ctx: Tool execution context (required for calling other tools)
        client: ServiceNow client instance
        include_sections: List of report sections to include
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        export_format: Output format ('detailed' or 'json')

    Returns:
        Dictionary containing comprehensive compliance report with metrics, issues,
        relationships, recommendations, and implementation roadmap
    """
    try:
        if not include_sections:
            include_sections = ["summary", "csdm", "metrics", "quality_issues", "relationships", "recommendations"]

        print(
            f"[generate_compliance_report] Generating compliance report with sections: {include_sections}",
            file=sys.stderr,
        )

        # Import inside function to avoid circular imports
        from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis
        from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis
        from servicenow_mcp.tools.cmdb.audit.audit_identify_domain_gaps import identify_domain_gaps

        # ====== Day 1 Enhancement: Query CSDM 5.0 Compliance (RULES-BASED + Service Instances) ======
        csdm_result: Dict[str, Any] = {}
        csdm_rules_result: Dict[str, Any] = {}
        try:
            print("[generate_compliance_report] Validating CMDB against CSDM 5.0 rules...", file=sys.stderr)
            csdm_rules_result = await _validate_cisdm_compliance_against_rules(client)
        except Exception as csdm_rules_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: CSDM rules validation failed: {csdm_rules_error}", file=sys.stderr)

        try:
            print("[generate_compliance_report] Querying CSDM 5.0 Service Instance coverage...", file=sys.stderr)
            csdm_result = await _query_csdm_service_instances(client)
        except Exception as csdm_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: CSDM query failed: {csdm_error}", file=sys.stderr)

        # ====== Discover all active CI classes BEFORE field coverage analysis ======
        # This ensures we analyze ALL CIs in the CMDB, not just hardcoded 24 types
        discovered_ci_classes: set[str] = set()
        try:
            print("[generate_compliance_report] Discovering all active CI classes from cmdb_ci...", file=sys.stderr)
            page_size = 500
            offset = 0
            fetched = 0
            while fetched < 10000:  # Increased from 5000 to capture all CI types
                response = await client.get_table_records(
                    table="cmdb_ci",
                    sysparm_query="active=true",
                    sysparm_fields="sys_class_name",
                    sysparm_limit=page_size,
                    sysparm_offset=offset,
                    sysparm_display_value="false",
                )
                records = response.get("result", [])
                if not isinstance(records, list) or not records:
                    break
                for record in records:
                    cls = record.get("sys_class_name")
                    if isinstance(cls, dict):
                        cls_value = cls.get("value") or cls.get("display_value")
                    else:
                        cls_value = cls
                    if cls_value and str(cls_value) != "cmdb_ci":
                        discovered_ci_classes.add(str(cls_value))
                count = len(records)
                fetched += count
                if count < page_size:
                    break
                offset += page_size
            print(f"[generate_compliance_report] Discovered {len(discovered_ci_classes)} active CI classes", file=sys.stderr)
        except Exception as class_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: CI class discovery failed: {class_error}", file=sys.stderr)

        # ====== Day 2 Enhancement: Query Field-Level Coverage, Trends, and Relationships ======
        field_coverage_result: Dict[str, Any] = {}
        trend_result: Dict[str, Any] = {}
        relationship_result: Dict[str, Any] = {}
        try:
            print("[generate_compliance_report] Analyzing field-level coverage by CI class...", file=sys.stderr)
            field_coverage_result = await _query_field_level_coverage(client, discovered_ci_classes if discovered_ci_classes else None)
        except Exception as field_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: Field coverage query failed: {field_error}", file=sys.stderr)

        try:
            print("[generate_compliance_report] Analyzing month-over-month trends...", file=sys.stderr)
            trend_result = await _query_trend_analysis(client)
        except Exception as trend_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: Trend analysis failed: {trend_error}", file=sys.stderr)

        try:
            print("[generate_compliance_report] Analyzing relationship health breakdown...", file=sys.stderr)
            relationship_result = await _query_relationship_breakdown(client)
        except Exception as rel_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: Relationship breakdown failed: {rel_error}", file=sys.stderr)

        # ====== LIVE QUERY APPROACH: Calculate metrics dynamically from primary tables ======
        # Per Blueprint: "Live queries only, no pre-calculated metrics"
        # Calculate total_cis from field coverage analysis (already completed above)
        total_cis = sum(
            int(class_data.get("total_cis") or 0)
            for class_data in field_coverage_result.get("by_class", {}).values()
            if isinstance(class_data, dict)
        )

        print(f"[generate_compliance_report] Using dynamic calculations - total_cis: {total_cis}", file=sys.stderr)

        # Calculate completeness from field coverage
        if total_cis > 0 and field_coverage_result:
            total_fields_expected = 0
            total_fields_populated = 0

            for class_data in field_coverage_result.get("by_class", {}).values():
                if isinstance(class_data, dict):
                    class_total = class_data.get("total_cis", 0)
                    class_fields = class_data.get("fields", {})

                    # Count required fields only
                    for field_info in class_fields.values():
                        if isinstance(field_info, dict) and field_info.get("category") == "required":
                            total_fields_expected += class_total
                            total_fields_populated += int(field_info.get("populated_count", 0))

            completeness_percent = (total_fields_populated / total_fields_expected * 100) if total_fields_expected > 0 else 0
        else:
            completeness_percent = 0.0

        # Calculate correctness (non-stale, non-duplicate CIs)
        try:
            stale_threshold_date = (datetime.utcnow() - timedelta(days=60)).isoformat()
            stale_count = await client.count_records(
                "cmdb_ci",
                f"active=true^sys_updated_on<{stale_threshold_date}"
            )
            stale_cis_count = stale_count[0] if isinstance(stale_count, tuple) else stale_count
            correctness_percent = ((total_cis - stale_cis_count) / total_cis * 100) if total_cis > 0 else 0
        except Exception as e:
            print(f"[WARNING] generate_compliance_report: stale CI calculation failed: {e}", file=sys.stderr)
            stale_cis_count = 0
            correctness_percent = 0.0

        # Compliance (relationships) - count orphan relationships as non-compliant
        try:
            orphan_count = await client.count_records(
                "cmdb_rel_ci",
                "active=true^(ci_idISEMPTY|related_ci_idISEMPTY)"
            )
            orphan_relationships = orphan_count[0] if isinstance(orphan_count, tuple) else orphan_count

            total_relationships_result = await client.count_records("cmdb_rel_ci", "active=true")
            total_relationships = total_relationships_result[0] if isinstance(total_relationships_result, tuple) else total_relationships_result

            compliance_percent = ((total_relationships - orphan_relationships) / total_relationships * 100) if total_relationships > 0 else 0
        except Exception as e:
            print(f"[WARNING] generate_compliance_report: compliance calculation failed: {e}", file=sys.stderr)
            compliance_percent = 0.0

        # Overall health is weighted average
        overall_health = (completeness_percent * 0.4 + correctness_percent * 0.35 + compliance_percent * 0.25)

        # Health grade based on overall score
        if overall_health >= 90:
            health_grade = "A"
        elif overall_health >= 75:
            health_grade = "B"
        elif overall_health >= 60:
            health_grade = "C"
        elif overall_health >= 40:
            health_grade = "D"
        else:
            health_grade = "F"

        duplicate_cis_count = 0  # Queried via audit_duplicate_cis below
        complete_cis = int(round((completeness_percent / 100.0) * total_cis))
        correct_cis = int(round((correctness_percent / 100.0) * total_cis))
        compliant_cis = int(round((compliance_percent / 100.0) * total_cis))

        data_quality_result: Dict[str, Any] = {}
        stale_result: Dict[str, Any] = {}
        duplicate_result: Dict[str, Any] = {}
        domain_gap_result: Dict[str, Any] = {}

        # Call separate stale and duplicate detection tools
        try:
            stale_result = await identify_stale_cis(
                client=client,
                ci_class="cmdb_ci_server",
                staleness_threshold_days=60,
                include_details=False,
            )
        except Exception as stale_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: stale CI scan failed: {stale_error}", file=sys.stderr)

        try:
            duplicate_result = await audit_duplicate_cis(
                client=client,
                table_name="cmdb_ci_server",
                audit_level=audit_level,
            )
        except Exception as dup_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: duplicate CI scan failed: {dup_error}", file=sys.stderr)

        # Combine results for backward compatibility
        data_quality_result = {
            "table": "cmdb_ci_server",
            "total_cis": stale_result.get("total_cis", 0) or duplicate_result.get("total_cis", 0),
            "stale_cis": {
                "count": stale_result.get("stale_count", 0),
                "threshold_days": 60,
            },
            "duplicate_cis": {
                "count": duplicate_result.get("duplicate_count", 0),
                "total_duplicates": duplicate_result.get("duplicate_count", 0),
            },
            "status": "success" if (stale_result.get("status") == "success" or duplicate_result.get("status") == "success") else "partial",
        }

        try:
            domain_gap_result = await identify_domain_gaps(
                client=client,
                domain="Foundation",
                audit_level=audit_level,
            )
        except Exception as domain_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: domain gap analysis failed: {domain_error}", file=sys.stderr)

        total_relationships: Optional[int] = None
        try:
            rel_count = await client.count_records("cmdb_rel_ci", "active=true")
            total_relationships = rel_count[0] if isinstance(rel_count, tuple) else rel_count
        except Exception as rel_error:  # pragma: no cover
            print(f"[WARNING] generate_compliance_report: relationship count failed: {rel_error}", file=sys.stderr)

        # Note: CI class discovery now happens earlier in the function (line ~685) to ensure
        # field coverage analysis includes ALL discovered CI classes, not just hardcoded types
        ci_class_count = len(discovered_ci_classes) if discovered_ci_classes else None

        target_overall = 85.0
        compliance_gap = round(max(0, target_overall - overall_health), 1)

        key_findings: List[str] = []
        if total_cis:
            key_findings.append(
                f"✅ CMDB inventory includes {total_cis:,} active CIs with {completeness_percent:.1f}% completeness."
            )
        if stale_cis_count:
            key_findings.append(
                f"⚠️  {stale_cis_count:,} CIs have not been updated in 60+ days (stale hygiene risk)."
            )
        if duplicate_cis_count:
            key_findings.append(
                f"⚠️  {duplicate_cis_count:,} CIs are flagged as potential duplicates."
            )
        if compliance_percent < 70:
            key_findings.append(
                f"❌ Relationship compliance is {compliance_percent:.1f}% (target ≥ 70%)."
            )
        if not key_findings:
            key_findings.append("ℹ️ Metrics are within healthy thresholds; continue continuous monitoring.")

        report: Dict[str, Any] = {
            "report_metadata": {
                "title": "ServiceNow CMDB Compliance & Data Quality Report",
                "generated_timestamp": datetime.utcnow().isoformat(timespec="seconds") + "Z",
                "audit_level": audit_level,
                "sections_included": include_sections,
            }
        }

        if "summary" in include_sections:
            report["executive_summary"] = {
                "overall_compliance_score": round(overall_health, 1),
                "target_compliance": target_overall,
                "compliance_gap": compliance_gap,
                "key_findings": key_findings,
                "maturity_level": health_grade or "Unknown",
                "grade": health_grade or "Unknown",
                "confidence": "High (aligned with ServiceNow CMDB Health Dashboard)",
            }

        # ====== Day 1 Enhancement: Add CSDM 5.0 Compliance Section ======
        if "csdm" in include_sections or "summary" in include_sections:
            if csdm_result:
                report["csdm_5_0_compliance"] = {
                    "maturity_score": csdm_result.get("maturity_score", 0),
                    "compliance_level": csdm_result.get("level", "Unknown"),
                    "service_instances_found": csdm_result.get("service_instances_found", 0),
                    "service_instances_required": csdm_result.get("service_instances_required", 6),
                    "total_instances": csdm_result.get("total_instances_count", 0),
                    "instances_summary": {},
                }

                # Build instances summary
                instances_by_type = csdm_result.get("instances_by_type", {})
                missing_instances = []
                for table_name, instance_info in instances_by_type.items():
                    status = instance_info.get("status", "Unknown")
                    count = instance_info.get("count", 0)

                    report["csdm_5_0_compliance"]["instances_summary"][instance_info.get("name", table_name)] = {
                        "status": status,
                        "count": count,
                        "description": instance_info.get("description"),
                        "examples": instance_info.get("examples", []),
                    }

                    if status == "Missing":
                        missing_instances.append({
                            "type": instance_info.get("name"),
                            "description": instance_info.get("description"),
                            "examples": instance_info.get("examples", []),
                            "recommendation": f"Create {instance_info.get('name')} CIs to achieve full CSDM 5.0 compliance.",
                        })

                report["csdm_5_0_compliance"]["missing_instances"] = missing_instances

                # Add CSDM key findings to executive summary if present
                if "executive_summary" in report and missing_instances:
                    csdm_finding = f"⚠️ CSDM 5.0 Maturity: {csdm_result.get('maturity_score')}% ({csdm_result.get('level')}). Missing {len(missing_instances)} Service Instance type(s)."
                    if csdm_finding not in report["executive_summary"]["key_findings"]:
                        report["executive_summary"]["key_findings"].insert(0, csdm_finding)

        if "metrics" in include_sections:
            def _status_from_score(score: float) -> str:
                if score >= 90:
                    return "Excellent"
                if score >= 75:
                    return "Good"
                if score >= 60:
                    return "Fair"
                if score >= 40:
                    return "Poor"
                return "Critical"

            report["compliance_metrics"] = {
                "completeness": {
                    "score": round(completeness_percent, 1),
                    "status": _status_from_score(completeness_percent),
                    "description": "Percentage of CIs with all required attributes populated.",
                    "passing_cis": complete_cis,
                    "failing_cis": max(total_cis - complete_cis, 0),
                },
                "correctness": {
                    "score": round(correctness_percent, 1),
                    "status": _status_from_score(correctness_percent),
                    "description": "CIs without stale, duplicate, or invalid indicators.",
                    "passing_cis": correct_cis,
                    "failing_cis": max(total_cis - correct_cis, 0),
                },
                "compliance": {
                    "score": round(compliance_percent, 1),
                    "status": _status_from_score(compliance_percent),
                    "description": "CIs meeting CSDM relationship standards.",
                    "passing_cis": compliant_cis,
                    "failing_cis": max(total_cis - compliant_cis, 0),
                },
                "overall_health": {
                    "score": round(overall_health, 1),
                    "status": health_grade or _status_from_score(overall_health),
                    "description": "Weighted CMDB Health Dashboard score.",
                },
            }

        if "quality_issues" in include_sections:
            quality_section: Dict[str, Any] = {"critical_issues": [], "medium_issues": []}

            if stale_cis_count:
                quality_section["critical_issues"].append(
                    {
                        "issue": "Stale CIs (60+ days)",
                        "count": stale_cis_count,
                        "severity": "High",
                        "impact": "Unmaintained records depress correctness metrics.",
                        "recommendation": "Use auto_retire_stale_cis or update lifecycle data for affected CIs.",
                    }
                )

            if duplicate_cis_count:
                quality_section["critical_issues"].append(
                    {
                        "issue": "Duplicate CI records",
                        "count": duplicate_cis_count,
                        "severity": "High",
                        "impact": "Duplication causes conflicting automation and reporting.",
                        "recommendation": "Leverage audit_duplicate_cis and action_merge_duplicate_cis to identify and merge queued duplicates.",
                    }
                )

            if data_quality_result.get("status") == "success":
                invalid_count = int(data_quality_result.get("invalid_cis", {}).get("count") or 0)
                if invalid_count:
                    quality_section["medium_issues"].append(
                        {
                            "issue": "Missing business ownership",
                            "count": invalid_count,
                            "severity": "Medium",
                            "impact": "Records lack owner/support_group/environment.",
                            "recommendation": "Run bulk_update_missing_fields for highlighted CIs.",
                        }
                    )
                quality_section["remediation_samples"] = data_quality_result.get("remediation_items", [])
            elif data_quality_result:
                quality_section["notes"] = ["Data quality scan unavailable (see stderr warnings)."]

            report["data_quality_issues"] = quality_section

        if "relationships" in include_sections:
            relationship_section: Dict[str, Any] = {
                "total_relationships": total_relationships,
                "relationship_gap_summary": None,
                "domain_analysis": None,
            }

            if domain_gap_result.get("status") == "success":
                relationship_section["domain_analysis"] = {
                    "domain": domain_gap_result.get("domain"),
                    "ci_classes_analyzed": domain_gap_result.get("ci_classes_analyzed"),
                    "relationship_gaps": domain_gap_result.get("relationship_gaps"),
                    "completeness_gaps": domain_gap_result.get("completeness_gaps"),
                    "recommendations": domain_gap_result.get("remediation_priority"),
                }
                gap_count = len(domain_gap_result.get("relationship_gaps") or [])
                if gap_count:
                    relationship_section["relationship_gap_summary"] = (
                        f"{gap_count} CI classes in the Foundation domain need relationship enrichment."
                    )
            elif domain_gap_result:
                relationship_section["relationship_gap_summary"] = (
                    "Relationship gap analysis unavailable (see stderr warnings)."
                )

            report["relationship_analysis"] = relationship_section

        # ====== Day 2 Enhancement: Add Field-Level Coverage Section ======
        if "field_coverage" in include_sections or "metrics" in include_sections:
            if field_coverage_result:
                report["detailed_field_coverage"] = field_coverage_result.get("by_class", {})

                # Add field coverage findings to key findings
                if "executive_summary" in report:
                    critical_fields = []
                    for ci_class, field_data in field_coverage_result.get("by_class", {}).items():
                        lowest = field_data.get("lowest_coverage_fields", [])
                        if lowest:
                            lowest_field = lowest[0]
                            if lowest_field.get("coverage", 100) < 70:
                                critical_fields.append(
                                    f"{lowest_field.get('field')} in {ci_class} ({lowest_field.get('coverage')}% coverage)"
                                )
                    if critical_fields:
                        field_finding = f"📊 Low field coverage detected: {critical_fields[0]}. See detailed_field_coverage for full breakdown."
                        if field_finding not in report["executive_summary"]["key_findings"]:
                            report["executive_summary"]["key_findings"].append(field_finding)

        # ====== Day 2 Enhancement: Add Trend Analysis Section ======
        if "trends" in include_sections or "metrics" in include_sections:
            if trend_result:
                report["trend_analysis"] = {
                    "period": "Last 30 days",
                    "metrics": {},
                    "velocity_forecast": trend_result.get("velocity", {}),
                }

                for metric in ["completeness", "correctness", "compliance"]:
                    metric_data = trend_result.get(metric, {})
                    current = metric_data.get("current")
                    previous = metric_data.get("previous")
                    change = metric_data.get("change")
                    trend = metric_data.get("trend", "→")

                    if current is not None:
                        report["trend_analysis"]["metrics"][metric] = {
                            "current": current,
                            "previous": previous,
                            "change": change,
                            "trend": trend,
                            "direction": "Improving ↑" if (change and change > 0) else "Declining ↓" if (change and change < 0) else "Stable →",
                        }

                # Add trend findings to key findings
                if "executive_summary" in report:
                    for metric, data in report["trend_analysis"]["metrics"].items():
                        if data.get("change") and data.get("change") > 2:
                            trend_finding = f"📈 {metric.capitalize()} improving: {data.get('change')}% increase month-over-month"
                            if trend_finding not in report["executive_summary"]["key_findings"]:
                                report["executive_summary"]["key_findings"].append(trend_finding)

        # ====== Day 2 Enhancement: Add Relationship Breakdown Section ======
        if "relationships" in include_sections:
            if relationship_result:
                # Enhance existing relationship_analysis section with breakdown
                if "relationship_analysis" in report:
                    report["relationship_analysis"]["orphan_relationships"] = relationship_result.get("orphan_relationships", 0)
                    report["relationship_analysis"]["stale_relationships"] = relationship_result.get("stale_relationships", 0)
                    report["relationship_analysis"]["relationships_by_type"] = relationship_result.get("by_type", {})

                    # Add relationship findings to key findings
                    if "executive_summary" in report:
                        if relationship_result.get("orphan_relationships", 0) > 0:
                            orphan_finding = f"🔗 {relationship_result.get('orphan_relationships')} orphan relationships detected (missing parent or child CI)"
                            if orphan_finding not in report["executive_summary"]["key_findings"]:
                                report["executive_summary"]["key_findings"].append(orphan_finding)

        if "recommendations" in include_sections:
            remediation_items: List[Dict[str, Any]] = []
            if data_quality_result.get("status") == "success":
                remediation_items.extend(data_quality_result.get("remediation_items", []))
            if domain_gap_result.get("status") == "success":
                remediation_items.append(
                    {
                        "type": "relationship",
                        "action": "Target low-coverage classes for relationship enrichment.",
                        "details": domain_gap_result.get("relationship_gaps", []),
                    }
                )

            report["remediation_roadmap"] = {
                "immediate_actions_30_days": [
                    {
                        "action": "Stabilize CMDB hygiene",
                        "priority": "Critical",
                        "items": [
                            "Retire or update stale CIs (focus on servers first).",
                            "Work duplicate merge backlog to reduce conflicts.",
                            "Populate missing owner/support_group fields on invalid CIs.",
                        ],
                        "expected_improvement": "+3-5% correctness uplift",
                        "tools_to_use": [
                            "action_auto_retire_stale_cis",
                            "audit_identify_stale_cis",
                            "audit_duplicate_cis",
                            "action_bulk_update_missing_fields",
                        ],
                    }
                ],
                "next_90_days": [
                    {
                        "action": "Improve relationship compliance",
                        "priority": "High",
                        "items": [
                            "Classify remaining untyped relationships via classify_ci_relationships.",
                            "Bridge service/application mappings surfaced by identify_domain_gaps.",
                            "Adopt the CSDM relationship governance playbook.",
                        ],
                        "expected_improvement": "+5-8% compliance uplift",
                        "tools_to_use": [
                            "classify_ci_relationships",
                            "suggest_ci_relationship_mappings",
                            "identify_domain_gaps",
                        ],
                    }
                ],
                "recommended_follow_up": remediation_items,
            }

            report["implementation_roadmap"] = {
                "tooling_overview": [
                    {
                        "name": "audit_identify_stale_cis",
                        "status": stale_result.get("status", "unknown"),
                        "focus": "Detect stale CIs not recently discovered/updated (extend per class as needed).",
                    },
                    {
                        "name": "audit_duplicate_cis",
                        "status": duplicate_result.get("status", "unknown"),
                        "focus": "Detect duplicate CIs using ServiceNow identification rules (extend per class as needed).",
                    },
                    {
                        "name": "identify_domain_gaps",
                        "status": domain_gap_result.get("status", "unknown"),
                        "focus": "Domain-level completeness and relationship coverage.",
                    },
                ],
                "quick_start": {
                    "step_1": "Validate stale CI backlog with audit_identify_stale_cis and duplicates with audit_duplicate_cis (servers).",
                    "step_2": "Prioritize duplicate merges using ServiceNow identification rules via action_merge_duplicate_cis.",
                    "step_3": "Run classify_ci_relationships on lowest-coverage classes.",
                    "step_4": "Re-run generate_compliance_report to confirm KPI uplift.",
                },
            }

        report["summary_statistics"] = {
            "total_cis": total_cis,
            "ci_classes": ci_class_count,
            "total_relationships": total_relationships,
            "stale_cis": stale_cis_count,
            "duplicate_cis": duplicate_cis_count,
            "invalid_cis": (
                int(data_quality_result.get("invalid_cis", {}).get("count") or 0)
                if data_quality_result.get("status") == "success"
                else None
            ),
            "automation_potential": (
                "Leverage MCP tooling for relationship classification, stale retirement, and enrichment automation."
            ),
        }

        issues_total = stale_cis_count + duplicate_cis_count
        if data_quality_result.get("status") == "success":
            issues_total += int(data_quality_result.get("invalid_cis", {}).get("count") or 0)

        report["status"] = "success"
        report["audit_metadata"] = build_audit_metadata(
            audit_level,
            total_cis or 1,
            issues_total,
        )

        if export_format == "json":
            report["report_json"] = json.dumps(report, indent=2, default=str)

        return report

    except Exception as e:
        print(f"[ERROR] generate_compliance_report failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return {
            "status": "error",
            "error": str(e),
            "audit_level": audit_level,
        }
