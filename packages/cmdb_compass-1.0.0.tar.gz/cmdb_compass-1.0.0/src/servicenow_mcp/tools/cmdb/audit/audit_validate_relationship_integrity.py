"""
Validate Relationship Integrity Tool (Phase 3 Week 2 Tool #3)

Comprehensive relationship validation detecting orphans, circular dependencies,
and invalid relationship types. Provides relationship health score and remediation recommendations.

Relationship workflow:
  audit_validate_relationship_integrity → action_auto_heal_relationship_issues
"""

import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple
from collections import defaultdict

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.csdm_rules_loader import get_csdm_rules
from servicenow_mcp.tools.cmdb.audit.utils import (
    AuditLevel,
    build_audit_metadata,
    cache_audit_baseline,
    get_cached_baseline,
    sample_limit_for_audit_level,
)


async def audit_validate_relationship_integrity(
    client: ServiceNowClient,
    ci_class: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    check_circular: bool = True,
    max_depth: int = 10,
) -> Dict[str, Any]:
    """
    Validate relationship integrity: detect orphans, circular dependencies, and invalid types.

    This tool performs comprehensive relationship validation to ensure CMDB relationship
    data quality. Identifies orphaned relationships (missing parent/child), circular
    dependency chains, and relationships using invalid or deprecated types.

    CSDM PHASE: CONSUME (data quality & integrity validation)

    VALIDATION CHECKS:
    1. Orphaned Relationships: parent or child CI no longer exists
    2. Circular Dependencies: CI references itself through relationship chain
    3. Invalid Relationship Types: type not in CSDM 5.0 allowed types
    4. Missing Relationship Types: relationships without type classification
    5. Bidirectional Consistency: parent→child and child→parent match

    AUDIT LEVELS:
    - quick: Summary counts only (fast)
    - standard: Counts + sample violations (recommended)
    - deep: Full violation list + circular dependency paths

    Args:
        client: ServiceNow client instance
        ci_class: Optional CI class filter (e.g., 'cmdb_ci_server')
        audit_level: Analysis depth: 'quick', 'standard' (default), or 'deep'
        check_circular: Whether to check for circular dependencies (expensive)
        max_depth: Maximum depth for circular dependency detection (default: 10)

    Returns (varies by audit level):
        - ci_class: The analyzed CI class filter
        - total_relationships: Total relationships checked
        - relationship_health_score: Overall integrity score (0-100)
        - health_grade: Letter grade (A-F) or tier
        - violation_summary:
          * orphaned_count: Relationships with missing parent or child
          * circular_count: Circular dependency chains detected
          * invalid_type_count: Relationships with invalid types
          * missing_type_count: Relationships without type
        - orphaned_relationships: List of orphaned relationships (sample/full)
        - circular_dependencies: List of circular chains (sample/full)
        - invalid_types: List of invalid relationship types found
        - missing_types: List of relationships without types (sample/full)
        - recommendations: Actionable remediation steps
        - audit_metadata: Execution details and cost

    EXAMPLE OUTPUT:
        "Validated 4,523 relationships. Health Score: 87% (Grade: B).
         Issues: 145 orphaned (3.2%), 12 circular dependencies, 89 invalid types (2.0%).
         Top issue: Remove 145 orphaned relationships pointing to deleted CIs."
    """
    cache_key = f"validate_relationship_integrity:{ci_class}:{audit_level}"
    cached = get_cached_baseline(cache_key)
    if cached is not None:
        return cached

    try:
        start_time = datetime.now()
        print(f"[audit_validate_relationship_integrity] Starting validation (ci_class={ci_class}, audit_level={audit_level})", file=sys.stderr)

        # Load CSDM rules for valid relationship types
        try:
            csdm_rules = get_csdm_rules()
            valid_relationship_types = _get_valid_relationship_types(csdm_rules)
        except Exception as e:
            print(f"[WARNING] Could not load CSDM rules: {e}", file=sys.stderr)
            valid_relationship_types = set()

        # Get all relationships (with optional CI class filter)
        relationships = await _fetch_relationships(client, ci_class, audit_level)
        total_relationships = len(relationships)

        if total_relationships == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "ci_class": ci_class,
                "total_relationships": 0,
                "relationship_health_score": 100.0,
                "health_grade": "A",
                "status": "success",
                "message": "No relationships found to validate",
                "metadata": build_audit_metadata(
                    audit_type="relationship_integrity",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class or "all"
                ),
            }

        print(f"[audit_validate_relationship_integrity] Found {total_relationships} relationships to validate", file=sys.stderr)

        # Check 1: Detect orphaned relationships
        orphaned_relationships = await _detect_orphaned_relationships(
            client, relationships, audit_level
        )
        orphaned_count = len(orphaned_relationships)

        # Check 2: Detect circular dependencies (optional - expensive)
        circular_dependencies = []
        circular_count = 0
        if check_circular:
            circular_dependencies = await _detect_circular_dependencies(
                client, relationships, audit_level, max_depth
            )
            circular_count = len(circular_dependencies)

        # Check 3: Detect invalid relationship types
        invalid_types, invalid_type_relationships = _detect_invalid_types(
            relationships, valid_relationship_types, audit_level
        )
        invalid_type_count = len(invalid_type_relationships)

        # Check 4: Detect missing relationship types
        missing_type_relationships = _detect_missing_types(relationships, audit_level)
        missing_type_count = len(missing_type_relationships)

        # Calculate relationship health score
        health_score = _calculate_relationship_health_score(
            total_relationships,
            orphaned_count,
            circular_count,
            invalid_type_count,
            missing_type_count,
        )

        health_grade = _get_health_grade(health_score)

        # Build recommendations
        recommendations = _generate_recommendations(
            orphaned_count,
            circular_count,
            invalid_type_count,
            missing_type_count,
            total_relationships,
        )

        # Prepare sample or full data based on audit level
        sample_size = _get_sample_size(audit_level, total_relationships)

        # Calculate execution time
        execution_time = (datetime.now() - start_time).total_seconds()

        result = {
            "ci_class": ci_class,
            "total_relationships": total_relationships,
            "relationship_health_score": round(health_score, 1),
            "health_grade": health_grade,
            "violation_summary": {
                "orphaned_count": orphaned_count,
                "orphaned_percentage": round((orphaned_count / total_relationships * 100), 2) if total_relationships > 0 else 0.0,
                "circular_count": circular_count,
                "invalid_type_count": invalid_type_count,
                "invalid_type_percentage": round((invalid_type_count / total_relationships * 100), 2) if total_relationships > 0 else 0.0,
                "missing_type_count": missing_type_count,
                "missing_type_percentage": round((missing_type_count / total_relationships * 100), 2) if total_relationships > 0 else 0.0,
            },
            "orphaned_relationships": orphaned_relationships[:sample_size] if audit_level != "deep" else orphaned_relationships,
            "circular_dependencies": circular_dependencies[:sample_size] if audit_level != "deep" else circular_dependencies,
            "invalid_types": list(invalid_types),
            "invalid_type_relationships": invalid_type_relationships[:sample_size] if audit_level != "deep" else invalid_type_relationships,
            "missing_type_relationships": missing_type_relationships[:sample_size] if audit_level != "deep" else missing_type_relationships,
            "recommendations": recommendations,
            "status": "success",
            "metadata": build_audit_metadata(
                audit_type="relationship_integrity",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class or "all"
            ),
        }

        print(f"[audit_validate_relationship_integrity] Completed: health_score={health_score:.1f}%, violations={orphaned_count + circular_count + invalid_type_count + missing_type_count}", file=sys.stderr)

        cache_audit_baseline(cache_key, result)
        return result

    except Exception as e:
        print(f"[ERROR] audit_validate_relationship_integrity failed: {e}", file=sys.stderr)
        return {
            "ci_class": ci_class,
            "status": "error",
            "error": str(e),
        }


async def _fetch_relationships(
    client: ServiceNowClient, ci_class: Optional[str], audit_level: AuditLevel
) -> List[Dict[str, Any]]:
    """Fetch relationships from cmdb_rel_ci table using pagination.

    Uses ``client.paginate()`` to avoid ServiceNow API timeouts and
    memory issues on enterprise CMDBs with 100k+ relationships.
    """
    try:
        query = None
        if ci_class:
            query = f"parent.sys_class_name={ci_class}^ORchild.sys_class_name={ci_class}"

        # Max records per audit level (None = unlimited for deep)
        max_records = sample_limit_for_audit_level(audit_level)

        relationships: List[Dict[str, Any]] = []
        page_num = 0
        async for page in client.paginate(
            "cmdb_rel_ci",
            sysparm_query=query,
            sysparm_fields="sys_id,parent,child,type,type.name",
            sysparm_display_value="all",
        ):
            relationships.extend(page)
            page_num += 1
            print(
                f"[audit_validate_relationship_integrity] "
                f"Fetched page {page_num} ({len(relationships)} relationships so far)",
                file=sys.stderr,
            )
            if max_records and len(relationships) >= max_records:
                relationships = relationships[:max_records]
                break

        return relationships

    except Exception as e:
        print(f"[ERROR] Failed to fetch relationships: {e}", file=sys.stderr)
        return []


async def _detect_orphaned_relationships(
    client: ServiceNowClient, relationships: List[Dict[str, Any]], audit_level: AuditLevel
) -> List[Dict[str, Any]]:
    """Detect relationships where parent or child CI no longer exists."""
    orphaned = []

    # Extract all unique parent and child sys_ids
    parent_ids = set()
    child_ids = set()

    for rel in relationships:
        parent_val = rel.get("parent")
        child_val = rel.get("child")

        parent_id = parent_val.get("value") if isinstance(parent_val, dict) else parent_val
        child_id = child_val.get("value") if isinstance(child_val, dict) else child_val

        if parent_id:
            parent_ids.add(parent_id)
        if child_id:
            child_ids.add(child_id)

    all_ci_ids = parent_ids.union(child_ids)

    if not all_ci_ids:
        return []

    # Check which CIs exist (batch query)
    existing_cis = await _check_cis_exist(client, list(all_ci_ids))

    # Identify orphaned relationships
    for rel in relationships:
        parent_val = rel.get("parent")
        child_val = rel.get("child")

        parent_id = parent_val.get("value") if isinstance(parent_val, dict) else parent_val
        child_id = child_val.get("value") if isinstance(child_val, dict) else child_val

        orphan_reason = []
        if parent_id and parent_id not in existing_cis:
            orphan_reason.append(f"parent CI {parent_id} missing")
        if child_id and child_id not in existing_cis:
            orphan_reason.append(f"child CI {child_id} missing")

        if orphan_reason:
            orphaned.append({
                "relationship_sys_id": _extract_sys_id(rel.get("sys_id")),
                "parent_sys_id": parent_id,
                "child_sys_id": child_id,
                "type": _extract_relationship_type(rel),
                "reason": ", ".join(orphan_reason),
            })

    return orphaned


async def _check_cis_exist(client: ServiceNowClient, ci_ids: List[str]) -> Set[str]:
    """Check which CIs exist in cmdb_ci table (batch IN query)."""
    if not ci_ids:
        return set()

    existing = set()

    # Batch in chunks of 200 using IN syntax (more efficient than ^OR)
    chunk_size = 200
    for i in range(0, len(ci_ids), chunk_size):
        chunk = ci_ids[i:i + chunk_size]
        query = f"sys_idIN{','.join(chunk)}"

        try:
            response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=query,
                sysparm_fields="sys_id",
                sysparm_limit=len(chunk),
                sysparm_display_value="false",
            )

            for ci in response.get("result", []):
                existing.add(ci.get("sys_id"))

        except Exception as e:
            print(f"[WARNING] Failed to check CI existence for chunk: {e}", file=sys.stderr)

    return existing


async def _detect_circular_dependencies(
    client: ServiceNowClient,
    relationships: List[Dict[str, Any]],
    audit_level: AuditLevel,
    max_depth: int,
) -> List[Dict[str, Any]]:
    """Detect circular dependency chains (CI references itself through relationships)."""
    # Build adjacency list for relationship graph
    graph = defaultdict(list)

    for rel in relationships:
        parent_val = rel.get("parent")
        child_val = rel.get("child")

        parent_id = parent_val.get("value") if isinstance(parent_val, dict) else parent_val
        child_id = child_val.get("value") if isinstance(child_val, dict) else child_val

        if parent_id and child_id:
            graph[parent_id].append(child_id)

    # Detect cycles using DFS
    circular_chains = []
    visited_global = set()

    for start_node in graph.keys():
        if start_node in visited_global:
            continue

        path = []
        visited_in_path = set()

        if _dfs_find_cycle(graph, start_node, path, visited_in_path, visited_global, max_depth):
            circular_chains.append({
                "cycle_path": path,
                "cycle_length": len(path),
                "start_ci": start_node,
            })

    return circular_chains


def _dfs_find_cycle(
    graph: Dict[str, List[str]],
    node: str,
    path: List[str],
    visited_in_path: Set[str],
    visited_global: Set[str],
    max_depth: int,
) -> bool:
    """DFS helper to detect cycles."""
    if len(path) > max_depth:
        return False

    if node in visited_in_path:
        # Found a cycle
        cycle_start_index = path.index(node)
        path[:] = path[cycle_start_index:]
        return True

    if node in visited_global:
        return False

    path.append(node)
    visited_in_path.add(node)

    for neighbor in graph.get(node, []):
        if _dfs_find_cycle(graph, neighbor, path, visited_in_path, visited_global, max_depth):
            return True

    path.pop()
    visited_in_path.remove(node)
    visited_global.add(node)

    return False


def _detect_invalid_types(
    relationships: List[Dict[str, Any]],
    valid_types: Set[str],
    audit_level: AuditLevel,
) -> Tuple[Set[str], List[Dict[str, Any]]]:
    """Detect relationships using invalid or deprecated types."""
    invalid_types = set()
    invalid_type_relationships = []

    if not valid_types:
        # If CSDM rules not loaded, skip this check
        return invalid_types, invalid_type_relationships

    for rel in relationships:
        rel_type = _extract_relationship_type(rel)

        if rel_type and rel_type not in valid_types:
            invalid_types.add(rel_type)
            invalid_type_relationships.append({
                "relationship_sys_id": _extract_sys_id(rel.get("sys_id")),
                "parent_sys_id": _extract_sys_id(rel.get("parent")),
                "child_sys_id": _extract_sys_id(rel.get("child")),
                "invalid_type": rel_type,
            })

    return invalid_types, invalid_type_relationships


def _detect_missing_types(
    relationships: List[Dict[str, Any]], audit_level: AuditLevel
) -> List[Dict[str, Any]]:
    """Detect relationships without a type classification."""
    missing_types = []

    for rel in relationships:
        rel_type = _extract_relationship_type(rel)

        if not rel_type or rel_type.strip() == "":
            missing_types.append({
                "relationship_sys_id": _extract_sys_id(rel.get("sys_id")),
                "parent_sys_id": _extract_sys_id(rel.get("parent")),
                "child_sys_id": _extract_sys_id(rel.get("child")),
            })

    return missing_types


def _calculate_relationship_health_score(
    total: int,
    orphaned: int,
    circular: int,
    invalid: int,
    missing: int,
) -> float:
    """Calculate relationship health score (0-100)."""
    if total == 0:
        return 100.0

    # Weight different violations
    orphaned_penalty = (orphaned / total) * 40  # Orphaned = 40% max penalty
    circular_penalty = min((circular / total) * 30, 30)  # Circular = 30% max penalty
    invalid_penalty = (invalid / total) * 20  # Invalid types = 20% max penalty
    missing_penalty = (missing / total) * 10  # Missing types = 10% max penalty

    total_penalty = orphaned_penalty + circular_penalty + invalid_penalty + missing_penalty

    health_score = max(0.0, 100.0 - total_penalty)

    return health_score


def _get_health_grade(score: float) -> str:
    """Convert health score to letter grade."""
    if score >= 95:
        return "A+ (Excellent)"
    elif score >= 90:
        return "A (Very Good)"
    elif score >= 85:
        return "B+ (Good)"
    elif score >= 80:
        return "B (Acceptable)"
    elif score >= 75:
        return "C+ (Fair)"
    elif score >= 70:
        return "C (Needs Improvement)"
    elif score >= 60:
        return "D (Poor)"
    else:
        return "F (Critical)"


def _generate_recommendations(
    orphaned: int,
    circular: int,
    invalid: int,
    missing: int,
    total: int,
) -> List[Dict[str, str]]:
    """Generate actionable remediation recommendations."""
    recommendations = []

    if orphaned > 0:
        recommendations.append({
            "priority": "High",
            "issue": f"{orphaned} orphaned relationships ({round(orphaned/total*100, 1)}%)",
            "action": "Use action_auto_heal_relationship_issues to remove orphaned relationships",
            "impact": "Improves data quality and query performance",
        })

    if circular > 0:
        recommendations.append({
            "priority": "Critical",
            "issue": f"{circular} circular dependency chains detected",
            "action": "Manual review required - break circular chains by removing key relationships",
            "impact": "Prevents infinite loops in dependency traversal",
        })

    if invalid > 0:
        recommendations.append({
            "priority": "Medium",
            "issue": f"{invalid} relationships with invalid types ({round(invalid/total*100, 1)}%)",
            "action": "Use action_auto_heal_relationship_issues to normalize invalid types to CSDM 5.0 types",
            "impact": "Ensures CSDM compliance and reporting accuracy",
        })

    if missing > 0:
        recommendations.append({
            "priority": "Medium",
            "issue": f"{missing} relationships without type classification ({round(missing/total*100, 1)}%)",
            "action": "Use action_auto_heal_relationship_issues to classify untyped relationships",
            "impact": "Enables proper relationship filtering and reporting",
        })

    if not recommendations:
        recommendations.append({
            "priority": "Low",
            "issue": "No critical relationship integrity issues detected",
            "action": "Continue monitoring with periodic integrity audits",
            "impact": "Maintains high relationship data quality",
        })

    return recommendations


def _get_valid_relationship_types(csdm_rules: Dict[str, Any]) -> Set[str]:
    """Extract valid CSDM 5.0 relationship types from rules."""
    valid_types = set()

    # Extract from CSDM rules structure
    if "relationship_types" in csdm_rules:
        for rel_type in csdm_rules["relationship_types"]:
            if isinstance(rel_type, dict):
                valid_types.add(rel_type.get("name", ""))
            else:
                valid_types.add(str(rel_type))

    # Add common CSDM relationship types as fallback
    fallback_types = {
        "Runs on::Runs",
        "Contains::Contained by",
        "Uses::Used by",
        "Manages::Managed by",
        "Depends on::Depended on by",
        "Connects to::Connected by",
        "Hosted on::Hosts",
        "Provides service to::Receives service from",
    }

    valid_types.update(fallback_types)

    return valid_types


def _extract_relationship_type(rel: Dict[str, Any]) -> str:
    """Extract relationship type from relationship record."""
    type_val = rel.get("type")

    if isinstance(type_val, dict):
        # Try display_value first, then name
        return type_val.get("display_value") or type_val.get("name") or type_val.get("value") or ""
    else:
        return str(type_val) if type_val else ""


def _extract_sys_id(value: Any) -> str:
    """Extract sys_id from value (handles both string and dict)."""
    if isinstance(value, dict):
        return value.get("value") or value.get("sys_id") or ""
    else:
        return str(value) if value else ""


def _get_sample_size(audit_level: AuditLevel, total: int) -> int:
    """Determine sample size based on audit level."""
    if audit_level == "quick":
        return 0
    elif audit_level == "standard":
        return min(50, total)
    else:  # deep
        return total
