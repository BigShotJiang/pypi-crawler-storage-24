"""Shared utilities and helper functions for CMDB audit tools."""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from typing import Any, Dict, Literal, Optional

from servicenow_mcp.servicenow import ServiceNowClient

# Import compliance metadata module
try:
    from servicenow_mcp.tools.cmdb.audit.compliance_metadata import build_compliance_metadata
except ImportError:
    # Fallback if compliance_metadata not available
    def build_compliance_metadata(tool_name, user=None, parameters=None, **kwargs):
        return {}

# ============================================================================
# Type Definitions
# ============================================================================

AuditLevel = Literal["quick", "standard", "deep"]

# ============================================================================
# Constants
# ============================================================================

SAMPLE_SIZE_PERCENT = 10  # 10% of total records for standard audit sampling
AUDIT_BASELINE_CACHE: Dict[str, Any] = {}  # In-memory cache for audit baselines
LAST_AUDIT_TIMESTAMP: Dict[str, datetime] = {}  # Track last audit time per table
FULL_AUDIT_INTERVAL_SECONDS = 3600  # Run full audit every hour (3600 seconds)

# ============================================================================
# Audit Sampling Utilities
# ============================================================================


def calculate_sample_size(total_count: int, sample_percent: int = SAMPLE_SIZE_PERCENT) -> int:
    """
    Calculate sample size for audit based on total count.

    Args:
        total_count: Total number of records in table
        sample_percent: Percentage to sample (default 10%)

    Returns:
        Sample size (minimum 100, maximum total_count)
    """
    sample_size = max(100, int(total_count * (sample_percent / 100)))
    return min(sample_size, total_count)


def sample_limit_for_audit_level(
    audit_level: AuditLevel,
    total_count: int = 0,
) -> Optional[int]:
    """Return the record limit that should be used for the given audit level.

    - ``quick``:    10 % sample (min 100)
    - ``standard``: 50 % sample (min 100)
    - ``deep``:     ``None`` (no limit — fetch everything, use pagination)

    When *total_count* is unknown or 0 the function falls back to sensible
    defaults (500 for quick, 2000 for standard).
    """
    if audit_level == "deep":
        return None

    if total_count <= 0:
        # Sensible defaults when total is unknown
        return 500 if audit_level == "quick" else 2000

    pct = 10 if audit_level == "quick" else 50
    return calculate_sample_size(total_count, pct)


def calculate_confidence_interval(
    metric: float, sample_size: int, population_size: int, confidence_level: float = 0.95
) -> Dict[str, float]:
    """
    Calculate confidence interval for a metric based on sample.

    Args:
        metric: The sampled metric value (0-100)
        sample_size: Size of sample
        population_size: Total population size
        confidence_level: Confidence level (default 0.95 for 95%)

    Returns:
        Dict with lower and upper bounds
    """
    if sample_size < 2 or population_size < sample_size:
        return {"lower": metric * 0.9, "upper": metric * 1.1, "margin_of_error": 10.0}

    # Simplified margin of error calculation
    margin_of_error = (100 / (sample_size ** 0.5)) * 1.96 if confidence_level == 0.95 else 5.0

    return {
        "lower": max(0, metric - margin_of_error),
        "upper": min(100, metric + margin_of_error),
        "margin_of_error": margin_of_error,
    }


def build_sampling_query(
    base_query: str = "",
    limit: Optional[int] = None,
    offset: int = 0,
) -> str:
    """
    Build a query string with sampling parameters.

    Args:
        base_query: Base query string
        limit: Record limit
        offset: Record offset for pagination

    Returns:
        Query string with sampling
    """
    if not base_query:
        return f"LIMIT {limit or 100} OFFSET {offset}"

    return f"{base_query}^LIMIT {limit or 100}^OFFSET {offset}"


# ============================================================================
# Audit Metadata
# ============================================================================


def build_audit_metadata(
    audit_level: Optional[AuditLevel] = None,
    total_records: Optional[int] = None,
    sampled_records: Optional[int] = None,
    tool_name: Optional[str] = None,
    user: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
    # Phase 3 parameters
    audit_type: Optional[str] = None,
    execution_time: Optional[float] = None,
    ci_class: Optional[str] = None,
    domain_filter: Optional[str] = None,
    **kwargs: Any
) -> Dict[str, Any]:
    """
    Build audit metadata for results with compliance information.

    Supports two usage patterns:
    1. Legacy pattern (with total_records, sampled_records)
    2. Phase 3 pattern (with audit_type, execution_time)

    Args:
        audit_level: Level of audit (quick, standard, deep)
        total_records: Total records analyzed (legacy pattern)
        sampled_records: Records actually sampled/analyzed (legacy pattern)
        tool_name: Name of the tool being executed (for compliance metadata)
        user: Username who executed the tool (for audit trail)
        parameters: Tool parameters used in execution (for audit trail)
        audit_type: Type of audit being performed (Phase 3 pattern)
        execution_time: Execution time in seconds (Phase 3 pattern)
        ci_class: CI class filter (Phase 3 pattern)
        domain_filter: Domain filter (Phase 3 pattern)
        **kwargs: Additional optional parameters

    Returns:
        Metadata dictionary with compliance information
    """
    # Phase 3 simplified pattern
    if audit_type is not None:
        metadata = {
            "audit_type": audit_type,
            "audit_level": audit_level or "standard",
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }

        if execution_time is not None:
            metadata["execution_time_seconds"] = round(execution_time, 2)

        if ci_class is not None:
            metadata["ci_class"] = ci_class

        if domain_filter is not None:
            metadata["domain_filter"] = domain_filter

        # Add any additional kwargs
        for key, value in kwargs.items():
            if value is not None:
                metadata[key] = value

        return metadata

    # Legacy pattern with sampling statistics
    if total_records is not None and sampled_records is not None:
        sample_percent = (sampled_records / total_records * 100) if total_records > 0 else 100

        metadata = {
            "audit_level": audit_level or "standard",
            "total_records": total_records,
            "sampled_records": sampled_records,
            "sample_percent": round(sample_percent, 1),
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }

        # Add compliance metadata if tool_name provided
        if tool_name:
            compliance_meta = build_compliance_metadata(
                tool_name=tool_name,
                user=user,
                parameters=parameters,
                include_frameworks=True,
                include_audit_trail=True
            )
            metadata["compliance"] = compliance_meta

        return metadata

    # Fallback: minimal metadata
    return {
        "audit_level": audit_level or "standard",
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


# ============================================================================
# Audit State Management
# ============================================================================


def cache_audit_baseline(cache_key: str, baseline: Dict[str, Any]) -> None:
    """
    Cache an audit result for later reuse.

    Args:
        cache_key: Unique key (e.g. "audit_analyze_cmdb_health:cmdb_ci_server")
        baseline: Full audit result dict
    """
    AUDIT_BASELINE_CACHE[cache_key] = baseline
    LAST_AUDIT_TIMESTAMP[cache_key] = datetime.utcnow()


def get_cached_baseline(cache_key: str) -> Optional[Dict[str, Any]]:
    """
    Return cached audit result if still fresh (< FULL_AUDIT_INTERVAL_SECONDS).

    Args:
        cache_key: Same key used in ``cache_audit_baseline``

    Returns:
        Cached result dict with ``_cache`` metadata added, or None if stale/missing.
    """
    if cache_key not in LAST_AUDIT_TIMESTAMP:
        return None

    age = (datetime.utcnow() - LAST_AUDIT_TIMESTAMP[cache_key]).total_seconds()
    if age >= FULL_AUDIT_INTERVAL_SECONDS:
        # Stale — evict
        AUDIT_BASELINE_CACHE.pop(cache_key, None)
        LAST_AUDIT_TIMESTAMP.pop(cache_key, None)
        return None

    cached = AUDIT_BASELINE_CACHE.get(cache_key)
    if cached is None:
        return None

    # Return a shallow copy with cache metadata
    result = dict(cached)
    result["_cache"] = {
        "hit": True,
        "age_seconds": round(age, 1),
        "max_age_seconds": FULL_AUDIT_INTERVAL_SECONDS,
    }
    return result


def invalidate_audit_cache(table: str) -> int:
    """
    Invalidate all cached baselines associated with a table.

    Called by action tools after write operations so that subsequent
    audit calls re-query ServiceNow.

    Args:
        table: Table name (matches cache keys containing this table)

    Returns:
        Number of cache entries invalidated.
    """
    keys_to_remove = [k for k in AUDIT_BASELINE_CACHE if table in k]
    for k in keys_to_remove:
        AUDIT_BASELINE_CACHE.pop(k, None)
        LAST_AUDIT_TIMESTAMP.pop(k, None)
    return len(keys_to_remove)


def should_run_incremental_audit(table: str) -> bool:
    """
    Determine if incremental audit should run vs full audit.

    Args:
        table: Table name

    Returns:
        True if incremental, False if full audit needed
    """
    if table not in LAST_AUDIT_TIMESTAMP:
        return False

    time_since_last = datetime.utcnow() - LAST_AUDIT_TIMESTAMP[table]
    return time_since_last.total_seconds() < FULL_AUDIT_INTERVAL_SECONDS


def calculate_audit_delta(baseline: Dict[str, Any], current: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculate changes between baseline and current audit.

    Args:
        baseline: Previous audit results
        current: Current audit results

    Returns:
        Delta/changes dictionary
    """
    delta = {}

    for key in set(baseline.keys()) | set(current.keys()):
        baseline_val = baseline.get(key, 0)
        current_val = current.get(key, 0)

        if isinstance(baseline_val, (int, float)) and isinstance(current_val, (int, float)):
            delta[key] = {
                "previous": baseline_val,
                "current": current_val,
                "change": current_val - baseline_val,
                "percent_change": ((current_val - baseline_val) / baseline_val * 100)
                if baseline_val != 0
                else 0,
            }

    return delta


# ============================================================================
# CI Identification and Field Rules
# ============================================================================


def get_ci_identification_rules() -> Dict[str, Dict[str, Any]]:
    """
    Get CI identification rules for various CI classes.

    Returns:
        Dictionary of CI class rules
    """
    return {
        "cmdb_ci_server": {
            "identification_fields": ["name", "serial_number", "fqdn"],
            "mandatory_fields": ["name", "sys_class_name"],
            "business_critical_fields": ["operational_status", "managed_by"],
        },
        "cmdb_ci_computer": {
            "identification_fields": ["name", "serial_number", "asset_tag"],
            "mandatory_fields": ["name", "sys_class_name"],
            "business_critical_fields": ["environment", "owned_by"],
        },
        "cmdb_ci_application": {
            "identification_fields": ["name", "vendor"],
            "mandatory_fields": ["name", "sys_class_name"],
            "business_critical_fields": ["owner", "support_group"],
        },
        "cmdb_ci_service": {
            "identification_fields": ["name"],
            "mandatory_fields": ["name", "sys_class_name"],
            "business_critical_fields": ["service_owner"],
        },
    }


async def get_required_fields_from_sys_dictionary(
    client: ServiceNowClient, table: str
) -> Dict[str, Any]:
    """
    Retrieve required field definitions from sys_dictionary.

    Args:
        client: ServiceNow client
        table: Table name

    Returns:
        Dictionary of mandatory and business-critical fields
    """
    try:
        # Default rules
        rules = get_ci_identification_rules()

        if table in rules:
            return {
                "mandatory": rules[table].get("mandatory_fields", []),
                "business_critical": rules[table].get("business_critical_fields", []),
            }

        # For other tables, return safe defaults
        return {
            "mandatory": ["name", "sys_class_name"],
            "business_critical": ["operational_status"],
        }
    except Exception as exc:
        print(f"[get_required_fields_from_sys_dictionary] Error: {exc}", file=sys.stderr)
        return {"mandatory": [], "business_critical": []}


# ============================================================================
# Metrics and Extrapolation
# ============================================================================


def extrapolate_sample_metrics(
    sample_metric: float, sample_size: int, total_size: int
) -> Dict[str, float]:
    """
    Extrapolate sample metrics to population level.

    Args:
        sample_metric: Metric value from sample (0-100)
        sample_size: Size of sample
        total_size: Total population size

    Returns:
        Dictionary with extrapolated metrics and confidence
    """
    if sample_size == 0:
        return {"extrapolated": sample_metric, "confidence": 0.0}

    # The extrapolated value is the sample metric itself
    # Confidence increases with larger samples
    confidence = min(100, (sample_size / total_size * 100) if total_size > 0 else 100)

    return {
        "extrapolated": sample_metric,
        "confidence": round(confidence, 1),
        "sample_size": sample_size,
        "population_size": total_size,
    }


# ============================================================================
# Compliance Utilities (from compliance_utils.py)
# ============================================================================


async def calculate_csdm_compliance_count(
    client: ServiceNowClient,
    ci_class: str,
    *,
    limit: int = 5_000,
) -> int:
    """
    Calculate how many configuration items meet baseline CSDM compliance checks.

    The compliance logic mirrors the five standard ServiceNow checks:
        1. Has at least one relationship
        2. Has a valid classification (sys_class_name)
        3. Has a discovery source that is not manual
        4. Is mapped to a service (cmdb_rel_ci child relationship to cmdb_ci_service)
        5. Has at least one tag entry in label_entry

    Uses batch queries to avoid N+1 API call patterns. Instead of 3 API calls
    per CI (potentially 15,000+ for 5,000 CIs), makes ~3 class-level queries
    plus chunked IN queries for large sets.

    Args:
        client: Initialized ServiceNow client.
        ci_class: CI table / class to check, e.g. ``cmdb_ci_server``.
        limit: Maximum number of records to inspect (defaults to 5,000).

    Returns:
        Number of CIs that pass all five checks.
    """
    try:
        response = await client.get_table_records(
            table=ci_class,
            sysparm_fields="sys_id,sys_class_name,discovery_source",
            sysparm_limit=limit,
            sysparm_display_value="false",
        )
    except Exception as exc:
        print(f"[calculate_csdm_compliance_count] Error: {exc}", file=sys.stderr)
        return 0

    cis = response.get("result", []) or []
    if not cis:
        return 0

    ci_ids = [ci.get("sys_id") for ci in cis if ci.get("sys_id")]
    ci_id_set = set(ci_ids)

    print(
        f"[calculate_csdm_compliance_count] Checking {len(cis)} CIs "
        f"with batch queries",
        file=sys.stderr,
    )

    # ── Batch query 1: relationship presence ────────────────────────
    # Collect sys_ids that appear as parent or child in cmdb_rel_ci
    has_relationship: set[str] = set()
    _BATCH = 200
    for i in range(0, len(ci_ids), _BATCH):
        batch_csv = ",".join(ci_ids[i:i + _BATCH])
        rels = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=f"parentIN{batch_csv}^ORchildIN{batch_csv}",
            sysparm_fields="parent,child",
            sysparm_limit=10000,
            sysparm_display_value="false",
        )
        for r in rels.get("result", []) or []:
            pid = r.get("parent", "")
            cid = r.get("child", "")
            if pid in ci_id_set:
                has_relationship.add(pid)
            if cid in ci_id_set:
                has_relationship.add(cid)

    # ── Batch query 2: service mapping ──────────────────────────────
    # CIs that are children in a relationship where parent is a service
    has_service_mapping: set[str] = set()
    for i in range(0, len(ci_ids), _BATCH):
        batch_csv = ",".join(ci_ids[i:i + _BATCH])
        svc_rels = await client.get_table_records(
            table="cmdb_rel_ci",
            sysparm_query=(
                f"childIN{batch_csv}"
                f"^parent.sys_class_name=cmdb_ci_service"
            ),
            sysparm_fields="child",
            sysparm_limit=10000,
            sysparm_display_value="false",
        )
        for r in svc_rels.get("result", []) or []:
            cid = r.get("child", "")
            if cid:
                has_service_mapping.add(cid)

    # ── Batch query 3: tagging presence ─────────────────────────────
    has_tagging: set[str] = set()
    for i in range(0, len(ci_ids), _BATCH):
        batch_csv = ",".join(ci_ids[i:i + _BATCH])
        tags = await client.get_table_records(
            table="label_entry",
            sysparm_query=f"table=cmdb_ci^table_keyIN{batch_csv}",
            sysparm_fields="table_key",
            sysparm_limit=10000,
            sysparm_display_value="false",
        )
        for r in tags.get("result", []) or []:
            tk = r.get("table_key", "")
            if tk:
                has_tagging.add(tk)

    # ── Evaluate compliance per CI (pure Python, no API calls) ──────
    compliant = 0
    for ci in cis:
        ci_sys_id = ci.get("sys_id", "")

        # Check 1: relationship presence
        if ci_sys_id not in has_relationship:
            continue

        # Check 2: valid classification
        sys_class = ci.get("sys_class_name", "")
        if not (sys_class and str(sys_class).strip()):
            continue

        # Check 3: discovery source (non-manual)
        discovery_source = ci.get("discovery_source", "")
        ds = str(discovery_source).strip() if discovery_source else ""
        if not ds or ds.lower() == "manual":
            continue

        # Check 4: service mapping
        if ci_sys_id not in has_service_mapping:
            continue

        # Check 5: tagging
        if ci_sys_id not in has_tagging:
            continue

        compliant += 1

    num_batches = (len(ci_ids) + _BATCH - 1) // _BATCH
    print(
        f"[calculate_csdm_compliance_count] {compliant}/{len(cis)} compliant "
        f"({num_batches * 3} API calls vs {len(cis) * 3} before batching)",
        file=sys.stderr,
    )
    return compliant


# ============================================================================
# Shared Utility Helpers
# ============================================================================


def extract_display_value(value: Any) -> str:
    """Extract display value from a ServiceNow reference field.

    ServiceNow reference fields can be a plain string, a dict with
    ``display_value``/``value``/``name``/``sys_id`` keys, or ``None``.
    This helper normalises all variants to a plain string.
    """
    if isinstance(value, dict):
        return (
            value.get("display_value")
            or value.get("value")
            or value.get("name")
            or value.get("sys_id")
            or ""
        )
    return str(value) if value else ""


# -- Grade conversion -------------------------------------------------------

_SIMPLE_GRADE_THRESHOLDS: list[tuple[float, str]] = [
    (90, "A"),
    (80, "B"),
    (70, "C"),
    (60, "D"),
]

_HEALTH_GRADE_THRESHOLDS: list[tuple[float, str]] = [
    (95, "A+"), (90, "A"), (87, "A-"),
    (85, "B+"), (80, "B"), (77, "B-"),
    (75, "C+"), (70, "C"), (67, "C-"),
    (65, "D+"), (60, "D"), (40, "D-"),
]


def score_to_grade(score: float) -> str:
    """Convert a 0-100 score to a simple letter grade (A/B/C/D/F).

    Thresholds: A >= 90, B >= 80, C >= 70, D >= 60, F < 60.
    """
    for threshold, grade in _SIMPLE_GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return "F"


def score_to_health_grade(score: float) -> str:
    """Convert a 0-100 score to a granular health grade (A+/A/A-/…/F).

    Used by executive-level summaries that need finer resolution.
    """
    for threshold, grade in _HEALTH_GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return "F"


# -- Safe count extraction ---------------------------------------------------


async def safe_count_records(
    client: ServiceNowClient,
    table: str,
    query: str = "",
) -> int:
    """Return a record count from ServiceNow, handling tuple responses.

    ``client.count_records()`` may return an ``int`` or a ``(count, …)`` tuple
    depending on the client version.  This helper normalises both to ``int``.
    """
    result = await client.count_records(table, query)
    return result[0] if isinstance(result, tuple) else int(result)


# -- Error response builder --------------------------------------------------


def build_error_response(error: Exception, **context: Any) -> Dict[str, Any]:
    """Build a standardised error dict for tool responses.

    Always contains ``status`` and ``error`` keys.  Any extra keyword
    arguments are merged into the response (e.g. ``audit_scope="all"``).
    """
    resp: Dict[str, Any] = {"status": "error", "error": str(error)}
    resp.update(context)
    return resp


def _check_table_access(table: str) -> bool:
    """
    Check if a table is accessible (stub implementation).

    Args:
        table: Table name

    Returns:
        True if accessible
    """
    # By default assume accessible
    # In production, this would check actual ServiceNow ACLs
    return True
