"""Audit IRE Health Tool

Audits ServiceNow IRE (Identification & Reconciliation Engine) health and configuration.
Identifies misconfigured rules, reconciliation state issues, and optimization opportunities.

CIS-DF Domain: Ingestion (19%)
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import sys
from pathlib import Path

from servicenow_mcp.servicenow import ServiceNowClient


async def audit_ire_health(
    client: ServiceNowClient,
    ci_class: Optional[str] = None,
    check_rule_status: bool = True,
    check_reconciliation_states: bool = True,
    check_match_conflicts: bool = True,
    audit_level: str = "summary"
) -> Dict[str, Any]:
    """
    Audit IRE (Identification & Reconciliation Engine) health.
    
    Analyzes ServiceNow IRE configuration, reconciliation states, and match rule
    effectiveness to identify misconfigurations, reconciliation issues, and 
    optimization opportunities.
    
    CIS-DF Ingestion Domain: Validates IRE configuration and multisource 
    reconciliation health across CMDB 360 data sources.
    
    Args:
        client: ServiceNow client instance
        ci_class: Optional CI class to filter analysis (e.g., cmdb_ci_server)
        check_rule_status: If True, audit identification rule configuration
        check_reconciliation_states: If True, analyze reconciliation state distribution
        check_match_conflicts: If True, detect match rule conflicts
        audit_level: Audit depth ('quick', 'summary', 'detailed')
        
    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ire_configuration: Identification rule health analysis
        - reconciliation_health: State distribution and issues
        - match_rules: Match rule coverage and conflicts
        - recommendations: List of recommended improvements
        - metadata: Audit metadata (timestamp, CI class, audit level)
    """
    
    try:
        result = {
            "status": "success",
            "ci_class": ci_class or "all",
            "audit_level": audit_level,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "ire_configuration": {},
            "reconciliation_health": {},
            "match_rules": {},
            "recommendations": []
        }
        
        # Step 1: Audit Identification Rules (sys_id_rule)
        if check_rule_status:
            rule_analysis = await _audit_identification_rules(client, ci_class)
            result["ire_configuration"] = rule_analysis
            
        # Step 2: Analyze Reconciliation States (cmdb_reconciliation_state)
        if check_reconciliation_states:
            recon_analysis = await _audit_reconciliation_states(client, ci_class)
            result["reconciliation_health"] = recon_analysis
            
        # Step 3: Check Match Rule Conflicts (cmdb_key_value)
        if check_match_conflicts:
            match_analysis = await _audit_match_rules(client, ci_class)
            result["match_rules"] = match_analysis
            
        # Step 4: Check if any IRE features are available
        ire_config = result.get("ire_configuration", {})
        recon_health = result.get("reconciliation_health", {})
        match_rules = result.get("match_rules", {})
        
        ire_available = (
            ire_config.get("available", False) or
            recon_health.get("available", False) or
            match_rules.get("available", False)
        )
        
        result["ire_available"] = ire_available
        
        if not ire_available:
            # Provide helpful positioning when IRE is not available
            result["message"] = (
                "IRE (Identification & Reconciliation Engine) features are not accessible "
                "in this ServiceNow instance. This typically requires ServiceNow Discovery "
                "plugin or CMDB 360."
            )
            result["alternative_tools"] = [
                {
                    "tool": "audit_ci_identifier_rules",
                    "description": "Analyze duplicate detection effectiveness (works without IRE tables)",
                    "domain": "Configuration, Ingestion"
                },
                {
                    "tool": "audit_discovery_coverage_gaps",
                    "description": "Identify manual vs discovered CIs and coverage gaps",
                    "domain": "Ingestion"
                },
                {
                    "tool": "audit_reconciliation_governance",
                    "description": "Analyze CMDB 360 multisource data precedence",
                    "domain": "Ingestion, Governance"
                },
                {
                    "tool": "audit_duplicate_cis",
                    "description": "Detect duplicate CIs using ServiceNow ID rules",
                    "domain": "Configuration, Ingestion"
                }
            ]
            result["recommendations"] = [
                "📋 Use alternative Nexecute tools above for IRE-related CMDB analysis",
                "🔧 Contact your ServiceNow administrator to enable Discovery or CMDB 360 for full IRE functionality",
                "📊 Current tools provide 75% of CIS-DF Ingestion domain coverage without IRE tables"
            ]
        else:
            # Generate recommendations based on available data
            result["recommendations"] = _generate_ire_recommendations(result)
            
            # Calculate health score if we have data
            result["health_score"] = _calculate_ire_health_score(result)
        
        return result
        
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class or "all"
        }


async def _audit_identification_rules(
    client: ServiceNowClient,
    ci_class: Optional[str]
) -> Dict[str, Any]:
    """
    Audit identification rules (sys_id_rule table).
    
    Returns:
        - total_rules: Count of identification rules
        - active_rules: Count of active rules
        - inactive_rules: Count of inactive rules
        - rules_by_class: Distribution of rules by CI class
        - misconfigured_rules: Rules with issues
    """
    
    try:
        # Build query for sys_id_rule table
        sysparm_query = f"table={ci_class}" if ci_class else None
        
        # Query identification rules
        response = await client.get_table_records(
            table="sys_id_rule",
            sysparm_limit=1000,
            sysparm_query=sysparm_query
        )
        
        if response.get("error"):
            return {
                "available": False,
                "error": f"Unable to query sys_id_rule table: {response['error']}",
                "note": "IRE identification rules table not accessible. This feature requires ServiceNow Discovery plugin or CMDB 360.",
                "recommendation": "Contact your ServiceNow administrator to enable Discovery or CMDB 360 for full IRE functionality."
            }
        
        rules = response.get("result", [])
        
        if not rules:
            return {
                "available": True,
                "total_rules": 0,
                "note": "No identification rules configured. This is normal for new instances or when IRE is not yet enabled.",
                "recommendation": "Configure identification rules in ServiceNow to enable automated CI matching and duplicate detection."
            }
        
        # Analyze rules
        active_rules = [r for r in rules if r.get("active") == "true"]
        inactive_rules = [r for r in rules if r.get("active") == "false"]
        
        # Group by CI class
        rules_by_class = {}
        for rule in rules:
            ci_class_name = rule.get("table", "unknown")
            rules_by_class[ci_class_name] = rules_by_class.get(ci_class_name, 0) + 1
        
        # Identify misconfigured rules (e.g., no attributes defined)
        misconfigured = [
            {
                "name": r.get("name"),
                "table": r.get("table"),
                "issue": "No identification attributes defined"
            }
            for r in rules
            if not r.get("attributes") or r.get("attributes") == ""
        ]
        
        return {
            "available": True,
            "total_rules": len(rules),
            "active_rules": len(active_rules),
            "inactive_rules": len(inactive_rules),
            "rules_by_class": rules_by_class,
            "misconfigured_rules": misconfigured,
            "coverage": f"{len(active_rules)}/{len(rules)} rules active"
        }
        
    except Exception as e:
        # Graceful fallback for 400 Bad Request or other exceptions
        error_msg = str(e)
        if "400" in error_msg or "Bad Request" in error_msg:
            return {
                "available": False,
                "error": "sys_id_rule table not found in ServiceNow instance",
                "note": "This feature requires ServiceNow Discovery plugin or CMDB 360.",
                "recommendation": "Contact your ServiceNow administrator to enable these features for full IRE health analysis."
            }
        return {
            "available": False,
            "error": f"Exception during identification rule audit: {str(e)}"
        }


async def _audit_reconciliation_states(
    client: ServiceNowClient,
    ci_class: Optional[str]
) -> Dict[str, Any]:
    """
    Audit reconciliation states (cmdb_reconciliation_state table).
    
    Returns:
        - total_cis: Count of CIs with reconciliation state
        - state_distribution: Breakdown by state (Reconciled, Skipped, In Progress)
        - stale_reconciliations: CIs with old reconciliation timestamps
    """
    
    try:
        # Build query for cmdb_reconciliation_state table
        # Note: May need to join with cmdb_ci to filter by CI class
        
        response = await client.get_table_records(
            table="cmdb_reconciliation_state",
            sysparm_limit=1000
        )
        
        if response.get("error"):
            return {
                "available": False,
                "error": f"Unable to query cmdb_reconciliation_state table: {response['error']}",
                "note": "Reconciliation state tracking requires CMDB 360 or advanced reconciliation features.",
                "recommendation": "Enable CMDB 360 for multisource reconciliation tracking and conflict resolution."
            }
        
        states = response.get("result", [])
        
        if not states:
            return {
                "available": True,
                "total_cis": 0,
                "note": "No reconciliation state data found. This is normal when CMDB 360 is not configured or no reconciliation has occurred.",
                "recommendation": "Configure CMDB 360 multisource reconciliation to track CI data source conflicts."
            }
        
        # Analyze reconciliation states
        state_counts = {}
        for state_record in states:
            state = state_record.get("state", "unknown")
            state_counts[state] = state_counts.get(state, 0) + 1
        
        return {
            "available": True,
            "total_cis": len(states),
            "state_distribution": state_counts,
            "note": "Full analysis may require CI class filtering"
        }
        
    except Exception as e:
        # Graceful fallback for 400 Bad Request or other exceptions
        error_msg = str(e)
        if "400" in error_msg or "Bad Request" in error_msg:
            return {
                "available": False,
                "error": "cmdb_reconciliation_state table not found in ServiceNow instance",
                "note": "This feature requires CMDB 360 or advanced reconciliation features.",
                "recommendation": "Contact your ServiceNow administrator to enable CMDB 360 for multisource reconciliation tracking."
            }
        return {
            "available": False,
            "error": f"Exception during reconciliation state audit: {str(e)}"
        }


async def _audit_match_rules(
    client: ServiceNowClient,
    ci_class: Optional[str]
) -> Dict[str, Any]:
    """
    Audit match rules (cmdb_key_value table).
    
    Returns:
        - total_match_rules: Count of match rules
        - sources: List of data sources
        - conflicts: Match rules with conflicts
    """
    
    try:
        response = await client.get_table_records(
            table="cmdb_key_value",
            sysparm_limit=1000
        )
        
        if response.get("error"):
            return {
                "available": False,
                "error": f"Unable to query cmdb_key_value table: {response['error']}",
                "note": "Match rule data may require specific ServiceNow configuration or plugins."
            }
        
        match_rules = response.get("result", [])
        
        if not match_rules:
            return {
                "available": True,
                "total_match_rules": 0,
                "data_sources": [],
                "note": "No match rules configured. This is normal when IRE identification rules are not yet set up.",
                "recommendation": "Configure identification rules in ServiceNow to enable match rule generation."
            }
        
        # Analyze data sources
        sources = set()
        for rule in match_rules:
            source = rule.get("source", "unknown")
            sources.add(source)
        
        return {
            "available": True,
            "total_match_rules": len(match_rules),
            "data_sources": list(sources),
            "note": "Conflict detection requires deeper analysis (future enhancement)"
        }
        
    except Exception as e:
        # Graceful fallback
        error_msg = str(e)
        if "400" in error_msg or "Bad Request" in error_msg:
            return {
                "available": False,
                "error": "cmdb_key_value table not found",
                "note": "Match rules require IRE configuration."
            }
        return {
            "available": False,
            "error": f"Exception during match rule audit: {str(e)}"
        }


def _generate_ire_recommendations(result: Dict[str, Any]) -> List[str]:
    """Generate actionable recommendations based on IRE health analysis."""
    
    recommendations = []
    
    # Check identification rules
    ire_config = result.get("ire_configuration", {})
    if ire_config.get("available"):
        if ire_config.get("inactive_rules", 0) > 0:
            recommendations.append(
                f"⚠️ {ire_config['inactive_rules']} identification rules are inactive. "
                "Review and enable necessary rules for CI identification."
            )
        
        if ire_config.get("misconfigured_rules"):
            recommendations.append(
                f"🚨 {len(ire_config['misconfigured_rules'])} rules have no identification attributes. "
                "Configure attributes for proper CI matching."
            )
        
        if ire_config.get("total_rules", 0) == 0:
            recommendations.append(
                "📋 No identification rules configured. Set up IRE rules in ServiceNow for automated CI matching."
            )
    else:
        recommendations.append(
            f"ℹ️ Identification rules: {ire_config.get('note', 'Not available')}"
        )
    
    # Check reconciliation health
    recon_health = result.get("reconciliation_health", {})
    if recon_health.get("available"):
        state_dist = recon_health.get("state_distribution", {})
        
        skipped_count = state_dist.get("Skipped", 0)
        total_cis = recon_health.get("total_cis", 1)
        
        if total_cis > 0 and skipped_count / total_cis > 0.1:
            recommendations.append(
                f"⚠️ {skipped_count}/{total_cis} CIs have 'Skipped' reconciliation state (>10%). "
                "Investigate why reconciliation is being skipped."
            )
        
        if total_cis == 0:
            recommendations.append(
                "📋 No reconciliation state data. Configure CMDB 360 for multisource tracking."
            )
    else:
        recommendations.append(
            f"ℹ️ Reconciliation tracking: {recon_health.get('note', 'Not available')}"
        )
    
    # Check match rules
    match_rules = result.get("match_rules", {})
    if match_rules.get("available") and match_rules.get("total_match_rules", 0) == 0:
        recommendations.append(
            "📋 No match rules found. Configure identification rules to enable match rule generation."
        )
    
    if not recommendations:
        recommendations.append("✅ IRE health looks good. No critical issues detected.")
    
    return recommendations


def _calculate_ire_health_score(result: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate overall IRE health score (0-100)."""
    
    ire_config = result.get("ire_configuration", {})
    
    # If IRE not available, return N/A
    if not ire_config.get("available"):
        return {
            "score": None,
            "rating": "N/A",
            "note": "Health score unavailable - IRE tables not accessible"
        }
    
    score = 100
    rating = "Excellent"
    
    # Deduct points for inactive rules
    inactive_pct = 0
    if ire_config.get("total_rules", 0) > 0:
        inactive_pct = (ire_config.get("inactive_rules", 0) / ire_config["total_rules"]) * 100
        score -= inactive_pct * 0.5  # -0.5 points per 1% inactive
    
    # Deduct points for misconfigured rules
    misconfigured_count = len(ire_config.get("misconfigured_rules", []))
    if misconfigured_count > 0:
        score -= misconfigured_count * 5  # -5 points per misconfigured rule
    
    # No rules configured = Poor score
    if ire_config.get("total_rules", 0) == 0:
        score = 40
    
    # Determine rating
    if score >= 90:
        rating = "Excellent"
    elif score >= 75:
        rating = "Good"
    elif score >= 60:
        rating = "Fair"
    elif score >= 40:
        rating = "Poor"
    else:
        rating = "Critical"
    
    return {
        "score": max(0, round(score, 1)),
        "rating": rating
    }
