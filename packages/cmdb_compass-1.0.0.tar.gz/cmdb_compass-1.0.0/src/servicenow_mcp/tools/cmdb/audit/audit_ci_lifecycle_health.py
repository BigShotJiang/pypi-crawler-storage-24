"""
CI Lifecycle Health Audit Tool

Analyze CI lifecycle state distribution, transitions, and health across the CMDB.
Identifies CIs stuck in intermediate states, aging issues, and decommissioning candidates.

Phase 3 Week 4 - Advanced CMDB Analytics
"""

import sys
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, sample_limit_for_audit_level


# =============================================================================
# Lifecycle Stage Definitions
# =============================================================================

# Standard CMDB lifecycle stages (ServiceNow)
LIFECYCLE_STAGES = {
    "new": {"label": "New", "expected_duration_days": 30, "severity_if_exceeded": "medium"},
    "in_stock": {"label": "In Stock", "expected_duration_days": 90, "severity_if_exceeded": "low"},
    "on_order": {"label": "On Order", "expected_duration_days": 60, "severity_if_exceeded": "medium"},
    "in_transit": {"label": "In Transit", "expected_duration_days": 14, "severity_if_exceeded": "high"},
    "in_use": {"label": "In Use", "expected_duration_days": None, "severity_if_exceeded": None},  # Active state
    "in_maintenance": {"label": "In Maintenance", "expected_duration_days": 30, "severity_if_exceeded": "high"},
    "retired": {"label": "Retired", "expected_duration_days": 180, "severity_if_exceeded": "medium"},  # Should be decommissioned
    "disposed": {"label": "Disposed", "expected_duration_days": None, "severity_if_exceeded": None},  # End state
    "stolen": {"label": "Stolen", "expected_duration_days": None, "severity_if_exceeded": None},
    "lost": {"label": "Lost", "expected_duration_days": 90, "severity_if_exceeded": "medium"},
}


# =============================================================================
# Helper Functions
# =============================================================================

def _calculate_age_days(install_date_str: Optional[str]) -> Optional[int]:
    """Calculate age in days from install/created date."""
    if not install_date_str:
        return None

    try:
        # Parse ServiceNow datetime format (YYYY-MM-DD HH:MM:SS)
        install_date = datetime.strptime(install_date_str[:19], "%Y-%m-%d %H:%M:%S")
        age_days = (datetime.now() - install_date).days
        return max(0, age_days)
    except Exception as e:
        return None


def _classify_age_bucket(age_days: Optional[int]) -> str:
    """Classify CI age into buckets."""
    if age_days is None:
        return "unknown"
    elif age_days < 90:
        return "< 90 days"
    elif age_days < 180:
        return "90-180 days"
    elif age_days < 365:
        return "180-365 days"
    elif age_days < 730:
        return "1-2 years"
    elif age_days < 1825:
        return "2-5 years"
    else:
        return "> 5 years"


def _is_lifecycle_stage_stale(stage: str, age_days: Optional[int]) -> Dict[str, Any]:
    """
    Determine if a CI has been in a lifecycle stage for too long.

    Returns:
        {
            "is_stale": bool,
            "severity": "low" | "medium" | "high",
            "expected_duration_days": int,
            "actual_duration_days": int
        }
    """
    stage_info = LIFECYCLE_STAGES.get(stage.lower(), {})
    expected_duration = stage_info.get("expected_duration_days")

    if expected_duration is None or age_days is None:
        return {"is_stale": False, "severity": None}

    is_stale = age_days > expected_duration
    severity = stage_info.get("severity_if_exceeded", "low") if is_stale else None

    return {
        "is_stale": is_stale,
        "severity": severity,
        "expected_duration_days": expected_duration,
        "actual_duration_days": age_days
    }


# =============================================================================
# Main Audit Function
# =============================================================================

async def audit_ci_lifecycle_health(
    client: ServiceNowClient,
    *,
    ci_class: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_decommission_candidates: bool = True,
    age_threshold_days: int = 1825,  # 5 years default
) -> Dict[str, Any]:
    """
    Audit CI lifecycle health across the CMDB.

    Analyzes:
    - Lifecycle stage distribution
    - CI age distribution
    - Stale CIs stuck in intermediate stages
    - Decommissioning candidates (old retired CIs)
    - Lifecycle health score

    Args:
        client: ServiceNow client instance
        ci_class: Optional CI class filter (e.g., "cmdb_ci_server")
        audit_level: "quick", "standard", or "deep"
        include_decommission_candidates: Include CIs ready for decommissioning (default: True)
        age_threshold_days: Age threshold for old CIs (default: 1825 = 5 years)

    Returns:
        {
            "lifecycle_stage_distribution": {...},
            "age_distribution": {...},
            "stale_lifecycle_cis": [...],
            "decommission_candidates": [...],
            "lifecycle_health_score": 0-100,
            "recommendations": [...],
            "summary": "...",
            "metadata": {...}
        }

    Example:
        >>> result = await audit_ci_lifecycle_health(
        ...     client,
        ...     ci_class="cmdb_ci_server",
        ...     audit_level="standard"
        ... )
        >>> print(f"Lifecycle health: {result['lifecycle_health_score']}")
    """
    start_time = datetime.now()

    print(f"[INFO] Auditing CI lifecycle health (class: {ci_class or 'all'}, level: {audit_level})", file=sys.stderr)

    # Determine table to query
    table = ci_class if ci_class else "cmdb_ci"

    # Determine record limit based on audit level
    record_limit = sample_limit_for_audit_level(audit_level)

    # Query CIs with lifecycle and age fields
    try:
        query_result = await client.get_table_records(
            table=table,
            sysparm_query="",
            sysparm_fields="sys_id,name,install_status,sys_created_on,install_date,last_discovered,sys_updated_on",
            sysparm_limit=record_limit,
            sysparm_display_value="false"
        )

        cis = query_result.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            return {
                "status": "success",
                "lifecycle_stage_distribution": {},
                "age_distribution": {},
                "stale_lifecycle_cis": [],
                "decommission_candidates": [],
                "lifecycle_health_score": 0.0,
                "summary": f"No CIs found in {table}",
                "metadata": build_audit_metadata(
                    audit_type="lifecycle_health",
                    audit_level=audit_level,
                    execution_time=(datetime.now() - start_time).total_seconds()
                )
            }

        print(f"[INFO] Analyzing {total_cis} CIs for lifecycle health...", file=sys.stderr)

    except Exception as e:
        print(f"[ERROR] Failed to query CIs: {e}", file=sys.stderr)
        return {
            "status": "error",
            "error": str(e),
            "summary": "Failed to query CMDB"
        }

    # Initialize counters
    lifecycle_stage_distribution = {}
    age_distribution = {
        "< 90 days": 0,
        "90-180 days": 0,
        "180-365 days": 0,
        "1-2 years": 0,
        "2-5 years": 0,
        "> 5 years": 0,
        "unknown": 0
    }
    stale_lifecycle_cis = []
    decommission_candidates = []

    # Analyze each CI
    for ci in cis:
        ci_sys_id = ci.get("sys_id")
        ci_name = ci.get("name", "Unknown")
        install_status = ci.get("install_status", "unknown")

        # Determine lifecycle stage (install_status numeric codes in ServiceNow)
        # Map numeric codes to lifecycle stages
        # (Common ServiceNow codes: 1=In use, 6=Retired, 7=Disposed, etc.)
        stage_mapping = {
            "1": "in_use",
            "2": "in_maintenance",
            "6": "retired",
            "7": "disposed",
            "100": "new",
            "101": "in_stock",
            "102": "on_order",
            "103": "in_transit",
        }
        lifecycle_stage = stage_mapping.get(str(install_status), "unknown")

        # Count stage distribution
        lifecycle_stage_distribution[lifecycle_stage] = lifecycle_stage_distribution.get(lifecycle_stage, 0) + 1

        # Calculate CI age
        install_date = ci.get("install_date") or ci.get("sys_created_on")
        age_days = _calculate_age_days(install_date)

        # Classify age bucket
        age_bucket = _classify_age_bucket(age_days)
        age_distribution[age_bucket] += 1

        # Check if lifecycle stage is stale
        stale_check = _is_lifecycle_stage_stale(lifecycle_stage, age_days)
        if stale_check["is_stale"]:
            stale_lifecycle_cis.append({
                "sys_id": ci_sys_id,
                "name": ci_name,
                "lifecycle_stage": lifecycle_stage,
                "age_days": age_days,
                "expected_duration_days": stale_check["expected_duration_days"],
                "severity": stale_check["severity"]
            })

        # Identify decommission candidates (retired > 180 days or very old)
        if include_decommission_candidates:
            if lifecycle_stage == "retired" and age_days and age_days > 180:
                decommission_candidates.append({
                    "sys_id": ci_sys_id,
                    "name": ci_name,
                    "lifecycle_stage": lifecycle_stage,
                    "age_days": age_days,
                    "reason": "Retired > 180 days, ready for disposal"
                })
            elif age_days and age_days > age_threshold_days and lifecycle_stage != "disposed":
                decommission_candidates.append({
                    "sys_id": ci_sys_id,
                    "name": ci_name,
                    "lifecycle_stage": lifecycle_stage,
                    "age_days": age_days,
                    "reason": f"Age > {age_threshold_days} days, review for retirement"
                })

    # Calculate lifecycle health score
    # Factors:
    # - Percentage of CIs in "in_use" (healthy active state): +40 max
    # - Low percentage in intermediate states (new, in_transit, etc.): +30 max
    # - Low stale lifecycle count: +20 max
    # - Low decommission candidates: +10 max

    in_use_pct = (lifecycle_stage_distribution.get("in_use", 0) / total_cis * 100) if total_cis > 0 else 0
    intermediate_states = ["new", "in_stock", "on_order", "in_transit", "in_maintenance"]
    intermediate_count = sum(lifecycle_stage_distribution.get(state, 0) for state in intermediate_states)
    intermediate_pct = (intermediate_count / total_cis * 100) if total_cis > 0 else 0
    stale_pct = (len(stale_lifecycle_cis) / total_cis * 100) if total_cis > 0 else 0
    decommission_pct = (len(decommission_candidates) / total_cis * 100) if total_cis > 0 else 0

    health_score = 0.0
    health_score += min(in_use_pct, 40)  # Max 40 points for in_use percentage
    health_score += max(0, 30 - intermediate_pct * 0.5)  # Penalize high intermediate %
    health_score += max(0, 20 - stale_pct)  # Penalize stale CIs
    health_score += max(0, 10 - decommission_pct * 0.5)  # Penalize high decommission %

    # Sort stale CIs by severity
    stale_lifecycle_cis.sort(key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x["severity"], 3))

    # Limit results based on audit level
    if audit_level == "quick":
        stale_lifecycle_cis = stale_lifecycle_cis[:10]
        decommission_candidates = decommission_candidates[:10]
    elif audit_level == "standard":
        stale_lifecycle_cis = stale_lifecycle_cis[:50]
        decommission_candidates = decommission_candidates[:50]
    # deep: return all

    # Generate recommendations
    recommendations = []
    if len(stale_lifecycle_cis) > 0:
        recommendations.append({
            "priority": "high" if len(stale_lifecycle_cis) > 50 else "medium",
            "action": "Review and transition CIs stuck in intermediate lifecycle stages",
            "impact": f"{len(stale_lifecycle_cis)} CIs have exceeded expected duration in their lifecycle stage"
        })

    if len(decommission_candidates) > 0:
        recommendations.append({
            "priority": "medium",
            "action": "Decommission or retire old CIs to maintain CMDB hygiene",
            "impact": f"{len(decommission_candidates)} CIs are candidates for decommissioning"
        })

    if intermediate_pct > 20:
        recommendations.append({
            "priority": "medium",
            "action": "Reduce percentage of CIs in intermediate states (new, in_transit, in_maintenance)",
            "impact": f"{intermediate_pct:.1f}% of CIs are in intermediate states (target: <20%)"
        })

    if in_use_pct < 50:
        recommendations.append({
            "priority": "low",
            "action": "Increase percentage of CIs in active 'in_use' state",
            "impact": f"Only {in_use_pct:.1f}% of CIs are actively in use (target: >50%)"
        })

    # Build summary
    summary = (
        f"Lifecycle health score: {health_score:.1f}/100. "
        f"{in_use_pct:.1f}% in use, {intermediate_pct:.1f}% in intermediate states, "
        f"{len(stale_lifecycle_cis)} stale lifecycle CIs, {len(decommission_candidates)} decommission candidates."
    )

    execution_time = (datetime.now() - start_time).total_seconds()

    result = {
        "status": "success",
        "lifecycle_stage_distribution": lifecycle_stage_distribution,
        "age_distribution": age_distribution,
        "stale_lifecycle_cis_count": len(stale_lifecycle_cis),
        "stale_lifecycle_cis": stale_lifecycle_cis if audit_level != "quick" else stale_lifecycle_cis[:5],
        "decommission_candidates_count": len(decommission_candidates),
        "decommission_candidates": decommission_candidates if include_decommission_candidates else None,
        "lifecycle_health_score": round(health_score, 1),
        "recommendations": recommendations,
        "summary": summary,
        "total_cis_analyzed": total_cis,
        "metadata": build_audit_metadata(
            audit_type="lifecycle_health",
            audit_level=audit_level,
            execution_time=execution_time,
            ci_class=ci_class
        )
    }

    print(f"[INFO] Lifecycle health audit complete: {health_score:.1f}/100 in {execution_time:.2f}s", file=sys.stderr)

    return result
