"""Audit Data Ownership Assignment Tool

Identifies missing CI owners and ownership conflicts to address the #1 CMDB challenge:
"Lack of data ownership" (Forrester research, ServiceNow community best practices).

Analyzes ownership coverage across:
- owned_by: Business owner responsible for CI data accuracy
- managed_by: Operational owner managing CI from ops perspective
- support_group: Incident handling team (deep mode only)
- assigned_to: End user assignment (deep mode only, device-specific)

QUERY tool with no modification capability.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import sys
from pathlib import Path

# Add tools directory to path for foundation layer imports

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.audit.utils import AuditLevel, build_audit_metadata, score_to_grade

async def audit_data_ownership_assignment(
    client: ServiceNowClient,
    ci_class: str = "cmdb_ci_server",
    domain: Optional[str] = None,
    audit_level: AuditLevel = "standard",
    include_details: bool = True,
    details_limit: int = 50,
    sample_size: int = 1000,
) -> Dict[str, Any]:
    """
    Audit data ownership assignment for CIs to identify orphaned and conflicted ownership.

    Addresses #1 CMDB challenge: "Lack of data ownership is the #1 challenge organizations
    face in their data quality improvement endeavors" (Forrester research).

    ServiceNow Best Practices:
    - owned_by: Business owner responsible for CI data accuracy (PRIMARY)
    - managed_by: Operational owner managing CI from ops perspective
    - support_group: Incident handling team
    - assigned_to: End user (for devices only)

    Args:
        client: ServiceNow client instance
        ci_class: CI class to analyze (e.g., cmdb_ci_server)
        domain: Optional domain filter
        audit_level: Analysis depth ('quick', 'standard', 'deep')
            - quick: Summary only, no CI details
            - standard: Top 50 orphaned CIs, check owned_by + managed_by
            - deep: Top 100 CIs, check ALL ownership fields + conflict detection
        include_details: If True, include CI details (disabled in quick mode)
        details_limit: Max CIs to include in details (default: 50, deep: 100)
        sample_size: Max CIs to analyze for performance (default: 1000)

    Returns:
        Dictionary containing:
        - status: 'success' or 'error'
        - ownership_coverage_score: 0-100 score
        - ownership_grade: A-F letter grade
        - ci_class: CI class analyzed
        - total_cis: Total active CIs found
        - owned_cis: CIs with at least one ownership field populated
        - orphaned_cis: CIs with no owner assigned
        - orphaned_percentage: % of CIs without owner
        - conflicted_cis: CIs with ownership conflicts (deep mode only)
        - ownership_by_field: Breakdown by ownership field
        - orphaned_cis_details: List of orphaned CI details (if include_details=True)
        - conflicted_cis_details: List of conflicted CIs (deep mode only)
        - recommendations: Prioritized actionable next steps
        - metadata: Phase 3 audit metadata
    """
    try:
        start_time = datetime.now()

        # Adjust details_limit based on audit_level
        if audit_level == "quick":
            include_details = False
        elif audit_level == "deep":
            details_limit = 100

        # Define ownership fields to check based on audit_level
        if audit_level == "deep":
            ownership_fields = ["owned_by", "managed_by", "assigned_to", "support_group"]
        else:
            ownership_fields = ["owned_by", "managed_by"]

        # Step 1: Build query
        query_parts = ["active=true"]
        if domain:
            query_parts.append(f"sys_domain={domain}")
        query = "^".join(query_parts)

        # Step 2: Fetch CIs with ownership fields
        fields = [
            "sys_id",
            "name",
            "operational_status",
            "install_status",
            "sys_created_on",
            "sys_updated_on"
        ] + ownership_fields

        cis_response = await client.get_table_records(
            table=ci_class,
            sysparm_query=query,
            sysparm_fields=",".join(fields),
            sysparm_limit=sample_size
        )

        cis = cis_response.get("result", [])
        total_cis = len(cis)

        if total_cis == 0:
            execution_time = (datetime.now() - start_time).total_seconds()
            return {
                "status": "success",
                "ownership_coverage_score": 0,
                "ownership_grade": "N/A",
                "ci_class": ci_class,
                "domain": domain,
                "total_cis": 0,
                "message": f"No active CIs found for class {ci_class}",
                "metadata": build_audit_metadata(
                    audit_type="data_ownership_assignment",
                    audit_level=audit_level,
                    execution_time=execution_time,
                    ci_class=ci_class
                )
            }

        # Step 3: Analyze ownership coverage
        orphaned_cis = []
        owned_cis = []
        conflicted_cis = []

        ownership_by_field = {field: 0 for field in ownership_fields}
        ownership_by_field["no_owner"] = 0

        for ci in cis:
            # Check which ownership fields are populated
            populated_fields = []
            for field in ownership_fields:
                value = _normalize_reference_value(ci.get(field))
                if value:
                    ownership_by_field[field] += 1
                    populated_fields.append(field)

            # Classify CI
            if len(populated_fields) == 0:
                # Orphaned: No owner assigned
                orphaned_cis.append(ci)
                ownership_by_field["no_owner"] += 1
            else:
                owned_cis.append(ci)

                # Deep mode: Check for ownership conflicts
                if audit_level == "deep" and len(populated_fields) >= 2:
                    # Check if owned_by and managed_by point to different users
                    owned_by = _normalize_reference_value(ci.get("owned_by"))
                    managed_by = _normalize_reference_value(ci.get("managed_by"))

                    if owned_by and managed_by and owned_by != managed_by:
                        # This is normal - business vs ops owner
                        # Only flag if it seems like unclear responsibility
                        # For now, we'll just track multi-owner CIs
                        pass

                    # Flag CIs with unusual ownership patterns (e.g., only assigned_to, no owned_by)
                    if "assigned_to" in populated_fields and "owned_by" not in populated_fields:
                        conflicted_cis.append({
                            "sys_id": ci.get("sys_id"),
                            "name": ci.get("name"),
                            "conflict_type": "missing_business_owner",
                            "assigned_to": _normalize_reference_value(ci.get("assigned_to")),
                            "owned_by": "",
                            "managed_by": managed_by,
                            "support_group": _normalize_reference_value(ci.get("support_group"))
                        })

        owned_count = len(owned_cis)
        orphaned_count = len(orphaned_cis)
        orphaned_percentage = (orphaned_count / total_cis * 100) if total_cis > 0 else 0

        # Step 4: Calculate ownership coverage score (0-100)
        # Primary weight: owned_by (50%), managed_by (30%), others (20%)
        owned_by_coverage = (ownership_by_field.get("owned_by", 0) / total_cis * 100) if total_cis > 0 else 0
        managed_by_coverage = (ownership_by_field.get("managed_by", 0) / total_cis * 100) if total_cis > 0 else 0

        if audit_level == "deep":
            # Include all fields in scoring
            assigned_to_coverage = (ownership_by_field.get("assigned_to", 0) / total_cis * 100) if total_cis > 0 else 0
            support_group_coverage = (ownership_by_field.get("support_group", 0) / total_cis * 100) if total_cis > 0 else 0

            ownership_coverage_score = (
                (owned_by_coverage * 0.40) +
                (managed_by_coverage * 0.30) +
                (assigned_to_coverage * 0.15) +
                (support_group_coverage * 0.15)
            )
        else:
            # Standard/quick: Focus on business + ops ownership
            ownership_coverage_score = (
                (owned_by_coverage * 0.60) +
                (managed_by_coverage * 0.40)
            )

        # Step 5: Calculate letter grade
        ownership_grade = score_to_grade(ownership_coverage_score)

        # Step 6: Generate recommendations
        recommendations = _generate_recommendations(
            orphaned_percentage,
            owned_by_coverage,
            managed_by_coverage,
            ownership_coverage_score,
            total_cis,
            orphaned_count,
            conflicted_cis,
            audit_level
        )

        # Step 7: Sort and limit orphaned CIs for details
        orphaned_cis_details = []
        if include_details and orphaned_cis:
            # Sort by priority: Operational status first, then recent updates
            sorted_orphaned = sorted(
                orphaned_cis,
                key=lambda ci: (
                    ci.get("operational_status", "") != "Operational",  # Operational CIs first
                    ci.get("sys_updated_on", "")  # Recent updates next
                ),
                reverse=False
            )

            for ci in sorted_orphaned[:details_limit]:
                orphaned_cis_details.append({
                    "sys_id": ci.get("sys_id"),
                    "name": ci.get("name"),
                    "ci_class": ci_class,
                    "operational_status": ci.get("operational_status", "Unknown"),
                    "install_status": ci.get("install_status", "Unknown"),
                    "sys_updated_on": ci.get("sys_updated_on", ""),
                    "sys_created_on": ci.get("sys_created_on", "")
                })

        # Step 8: Build response
        execution_time = (datetime.now() - start_time).total_seconds()

        result = {
            "status": "success",
            "ownership_coverage_score": round(ownership_coverage_score, 1),
            "ownership_grade": ownership_grade,
            "ci_class": ci_class,
            "domain": domain,
            "total_cis": total_cis,
            "owned_cis": owned_count,
            "orphaned_cis": orphaned_count,
            "orphaned_percentage": round(orphaned_percentage, 1),
            "ownership_by_field": ownership_by_field,
            "recommendations": recommendations,
            "metadata": build_audit_metadata(
                audit_type="data_ownership_assignment",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            )
        }

        # Add optional details
        if include_details:
            result["orphaned_cis_details"] = orphaned_cis_details

        if audit_level == "deep":
            result["conflicted_cis"] = len(conflicted_cis)
            if include_details and conflicted_cis:
                result["conflicted_cis_details"] = conflicted_cis[:details_limit]

        return result

    except Exception as e:
        print(f"[ERROR] audit_data_ownership_assignment failed: {e}", flush=True)
        import traceback
        traceback.print_exc()

        execution_time = (datetime.now() - start_time).total_seconds()
        return {
            "status": "error",
            "error": str(e),
            "ci_class": ci_class,
            "domain": domain,
            "metadata": build_audit_metadata(
                audit_type="data_ownership_assignment",
                audit_level=audit_level,
                execution_time=execution_time,
                ci_class=ci_class
            )
        }


        return "F"


def _generate_recommendations(
    orphaned_percentage: float,
    owned_by_coverage: float,
    managed_by_coverage: float,
    overall_score: float,
    total_cis: int,
    orphaned_count: int,
    conflicted_cis: List[Dict],
    audit_level: str
) -> List[str]:
    """Generate prioritized, actionable recommendations based on ownership analysis."""
    recommendations = []

    # Critical: High orphaned percentage
    if orphaned_percentage > 50:
        recommendations.append(
            f"🚨 CRITICAL: {orphaned_count} CIs ({orphaned_percentage:.1f}%) have no assigned owner - "
            "immediate ownership assignment required"
        )
    elif orphaned_percentage > 20:
        recommendations.append(
            f"⚠️ WARNING: {orphaned_count} CIs ({orphaned_percentage:.1f}%) have no assigned owner - "
            "schedule ownership assignment initiative"
        )
    elif orphaned_percentage > 0:
        recommendations.append(
            f"⚠️ {orphaned_count} CIs ({orphaned_percentage:.1f}%) have no assigned owner - "
            "assign owners to close coverage gap"
        )

    # Business owner (owned_by) priority
    if owned_by_coverage < 60:
        recommendations.append(
            f"📋 Business ownership gap: Only {owned_by_coverage:.1f}% of CIs have 'owned_by' field populated. "
            "Business owners are responsible for CI data accuracy (ServiceNow best practice)"
        )

    # Operational owner (managed_by) priority
    if managed_by_coverage < 60:
        recommendations.append(
            f"📋 Operational ownership gap: Only {managed_by_coverage:.1f}% of CIs have 'managed_by' field populated. "
            "Assign operational managers for CI maintenance"
        )

    # Prioritization guidance
    if orphaned_count > 0:
        recommendations.append(
            "✅ Prioritize ownership assignment: 1) Operational CIs first, 2) Recently updated CIs, "
            "3) Business-critical applications"
        )

    # Conflict detection (deep mode only)
    if audit_level == "deep" and conflicted_cis:
        recommendations.append(
            f"⚠️ {len(conflicted_cis)} CIs have ownership conflicts (e.g., assigned_to set but no owned_by). "
            "Review for unclear responsibility"
        )

    # Overall score feedback
    if overall_score >= 90:
        recommendations.append(
            f"✅ Excellent ownership coverage ({overall_score:.1f}/100) - maintain current governance process"
        )
    elif overall_score >= 70:
        recommendations.append(
            f"✅ Good ownership coverage ({overall_score:.1f}/100) - continue improving toward 90% target"
        )
    else:
        recommendations.append(
            f"⚠️ Ownership coverage ({overall_score:.1f}/100) is below target (90%). "
            "Implement ownership assignment workflow and governance"
        )

    # Governance best practice
    recommendations.append(
        "💡 ServiceNow Best Practice: Keep ownership at group level (not individual) to reduce churn "
        "when personnel changes"
    )

    return recommendations


def _normalize_reference_value(value: Any) -> str:
    """Normalize reference field values from ServiceNow responses."""
    if value is None:
        return ""

    if isinstance(value, dict):
        for key in ("value", "display_value"):
            normalized = value.get(key)
            if normalized:
                return _normalize_reference_value(normalized)
        return ""

    if isinstance(value, str):
        return value.strip()

    # Fallback for unexpected types
    return str(value).strip()
