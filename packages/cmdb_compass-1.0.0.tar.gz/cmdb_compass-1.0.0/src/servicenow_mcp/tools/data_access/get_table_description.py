"""
Get Table Description Tool

Retrieve schema information for any ServiceNow table.
Audit-level tool for table schema inspection (free).
"""

import sys
from typing import Any

from servicenow_mcp.servicenow import ServiceNowClient


async def get_table_description(client: ServiceNowClient, table_name: str) -> str:
    """
    Get schema information for any ServiceNow table.

    This tool retrieves metadata about a table's structure, including field names,
    labels, types, and whether they are required. Useful for understanding
    table structures before querying or creating records.

    Args:
        client: ServiceNow client instance
        table_name: The name of the ServiceNow table (e.g., 'incident', 'change_request')

    Returns:
        Formatted string with field information (limited to first 20 fields for readability)
    """
    try:
        # Get table schema from ServiceNow dictionary
        schema = await client.get_table_schema(table_name)
        fields = schema.get("fields", []) if isinstance(schema, dict) else schema

        if not fields:
            return f"**Table Schema**\n\nNo schema information found for table: {table_name}"

        # Limit to first 20 fields for readability
        fields_to_show = fields[:20]

        result = f"**Table Schema: {table_name}**\n\n"
        result += f"Showing {len(fields_to_show)} of {len(fields)} fields\n\n"

        for field in fields_to_show:
            field_name = field.get("name") or field.get("element", "N/A")
            field_label = field.get("label") or field.get("column_label", "N/A")
            field_type = field.get("type") or field.get("internal_type", "N/A")
            is_required = "Yes" if field.get("mandatory") else "No"

            result += f"**{field_name}** ({field_label})\n"
            result += f"  **Type:** {field_type}\n"
            result += f"  **Required:** {is_required}\n\n"

        if len(fields) > 20:
            result += f"\n... and {len(fields) - 20} more fields"

        return result

    except Exception as e:
        print(f"[ERROR] get_table_description failed: {e}", file=sys.stderr)
        return f"**Error Getting Table Schema**\n\n**Error:** {str(e)}"
