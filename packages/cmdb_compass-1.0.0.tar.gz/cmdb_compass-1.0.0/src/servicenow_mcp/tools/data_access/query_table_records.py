"""Query Table Records Tool

Query arbitrary ServiceNow table with sysparm_query and return records.
Audit-level tool for data access (free).
"""

from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.data_access import data_access


async def query_table_records(
    client: ServiceNowClient,
    table: str,
    query: str = "",
    fields: Optional[List[str]] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """
    Query arbitrary ServiceNow table with sysparm_query and return records.

    Args:
        client: ServiceNow client instance
        table: The table name to query (e.g., 'incident', 'cmdb_ci_server')
        query: ServiceNow query string (sysparm_query format)
        fields: Specific fields to retrieve (optional)
        limit: Maximum number of records to return (default: 100)

    Returns:
        List of dictionary records matching the query
    """
    if limit <= 0:
        raise ValueError("Limit must be a positive integer.")

    return await data_access.query_table_records(
        client=client,
        table=table,
        query=query,
        fields=fields,
        limit=limit,
    )
