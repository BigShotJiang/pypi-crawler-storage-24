"""Data Access tools - generic utilities for querying and exploring tables."""

from .data_access import query_table_records, list_tables_and_fields

__all__ = ["query_table_records", "list_tables_and_fields"]
