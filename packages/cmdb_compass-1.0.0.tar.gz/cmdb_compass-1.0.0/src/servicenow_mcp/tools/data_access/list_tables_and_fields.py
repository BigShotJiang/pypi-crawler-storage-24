"""List Tables and Fields Tool

List available tables and their fields (optionally filtered by name pattern).
Audit-level tool for data access (free).
"""

from typing import Any, Dict, Optional

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.data_access import data_access


async def list_tables_and_fields(
    client: ServiceNowClient,
    pattern: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List available tables and their fields (optionally filtered by name pattern).

    OPTIMIZED for large result sets:
    - Limits to 15 tables when pattern matches many
    - Limits to 25 fields per table (prioritizes key fields)
    - Returns summary view for large datasets

    Args:
        client: ServiceNow client instance
        pattern: Optional pattern to filter table names

    Returns:
        Dictionary containing filtered tables and their field information
    """
    return await data_access.list_tables_and_fields(
        client=client,
        pattern=pattern,
        max_tables=15,
        max_fields_per_table=25,
    )
