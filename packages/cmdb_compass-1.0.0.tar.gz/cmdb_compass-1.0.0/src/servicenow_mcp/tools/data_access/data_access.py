"""
Data access utilities for ServiceNow MCP tools.
"""

from typing import Any, Dict, List, Optional

from servicenow_mcp.servicenow import ServiceNowClient


async def count_table_records(
    client: ServiceNowClient,
    table: str,
    query: str = "",
) -> int:
    """Count records in a table matching the query."""
    count, _ = await client.count_records(
        table=table,
        sysparm_query=query if query else None,
    )
    return count


async def query_table_records(
    client: ServiceNowClient,
    table: str,
    query: str = "",
    fields: Optional[List[str]] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Query table records and return the result list."""
    fields_str = ','.join(fields) if fields else None

    response = await client.get_table_records(
        table=table,
        sysparm_query=query,
        sysparm_fields=fields_str,
        sysparm_limit=limit,
    )

    return response.get("result", [])


async def list_tables_and_fields(
    client: ServiceNowClient,
    pattern: Optional[str] = None,
    max_tables: int = 15,
    max_fields_per_table: int = 25,
) -> Dict[str, Any]:
    """List tables and their fields with optional pattern filtering."""
    # Query sys_db_object for table names
    table_query = ""
    if pattern:
        table_query = f"nameLIKE{pattern}"

    tables_response = await client.get_table_records(
        table="sys_db_object",
        sysparm_query=table_query,
        sysparm_fields="name,label",
        sysparm_limit=max_tables,
    )

    tables = {}
    for table_record in tables_response.get("result", []):
        table_name = table_record.get("name")
        if table_name:
            # Get fields for this table
            fields_response = await client.get_table_records(
                table="sys_dictionary",
                sysparm_query=f"name={table_name}",
                sysparm_fields="name,label,type",
                sysparm_limit=max_fields_per_table,
            )

            fields = []
            for field_record in fields_response.get("result", []):
                fields.append({
                    "name": field_record.get("name", ""),
                    "label": field_record.get("label", ""),
                    "type": field_record.get("type", ""),
                })

            tables[table_name] = {
                "label": table_record.get("label", table_name),
                "fields": fields
            }

    return {"tables": tables}
