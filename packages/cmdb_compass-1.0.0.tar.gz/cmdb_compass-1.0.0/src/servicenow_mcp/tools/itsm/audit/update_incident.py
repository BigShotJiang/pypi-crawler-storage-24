"""Update Incident Tool

Update incident fields (state, priority, assignment, work notes).
Audit-level tool for incident updates (write operation).
"""

from typing import Any, Dict, Optional

from servicenow_mcp.servicenow import ServiceNowClient


async def update_incident(
    client: ServiceNowClient,
    *,
    incident_number: str,
    state: Optional[str],
    priority: Optional[str],
    assigned_to: Optional[str],
    work_notes: Optional[str],
) -> str:
    """Update incident fields and return a formatted status message.

    Args:
        client: ServiceNow client instance
        incident_number: Incident number to update
        state: New state (optional)
        priority: New priority (optional)
        assigned_to: New assigned user sys_id (optional)
        work_notes: Work notes to add (optional)

    Returns:
        Formatted string with update result
    """
    try:
        response = await client.get_record_by_number(table="incident", number=incident_number)
        records = response.get("result", [])
        if not records:
            return f"**Incident Not Found**\n\nNo incident found with number: {incident_number}"

        sys_id = records[0].get("sys_id")
        update_data: Dict[str, Any] = {}
        changes: list[str] = []

        if state is not None:
            update_data["state"] = state
            changes.append(f"State: {state}")
        if priority is not None:
            update_data["priority"] = priority
            changes.append(f"Priority: {priority}")
        if assigned_to is not None:
            update_data["assigned_to"] = assigned_to
            changes.append(f"Assigned To: {assigned_to}")
        if work_notes is not None:
            update_data["work_notes"] = work_notes
            changes.append("Work Notes: Added")

        if not update_data:
            return "**No Updates Specified**\n\nPlease specify at least one field to update."

        await client.update_record(
            table="incident",
            sys_id=sys_id,
            data=update_data,
        )

        result = "✅ **Incident Updated Successfully**\n\n"
        result += f"**Incident Number:** {incident_number}\n"
        result += "**Changes Made:**\n"
        for change in changes:
            result += f"  - {change}\n"
        return result
    except Exception as exc:  # pragma: no cover
        return f"**Error Updating Incident**\n\n**Error:** {exc}"
