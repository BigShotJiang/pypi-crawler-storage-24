"""Get Incident Details Tool

Fetch detailed information for a specific incident by number.
Audit-level tool for incident details (read-only).
"""

from servicenow_mcp.servicenow import ServiceNowClient


async def get_incident_details(
    client: ServiceNowClient,
    *,
    incident_number: str,
) -> str:
    """Return a detailed description of a single incident.

    Args:
        client: ServiceNow client instance
        incident_number: Incident number (e.g., INC0010001)

    Returns:
        Formatted string with detailed incident information
    """
    try:
        incidents = await client.query_table(
            table="incident",
            query=f"number={incident_number}",
            limit=1,
        )

        if not incidents:
            return f"**Incident Not Found**\n\nNo incident found with number: {incident_number}"

        incident = incidents[0]
        result = f"**Incident Details: {incident.get('number', 'N/A')}**\n\n"

        result += "**Overview**\n"
        result += f"  **Short Description:** {incident.get('short_description', 'N/A')}\n"
        result += f"  **Description:** {incident.get('description', 'N/A')}\n"
        result += f"  **Category:** {incident.get('category', 'N/A')}\n"
        result += f"  **Subcategory:** {incident.get('subcategory', 'N/A')}\n"

        result += "\n**Impact & Urgency**\n"
        result += f"  **Impact:** {incident.get('impact', 'N/A')}\n"
        result += f"  **Urgency:** {incident.get('urgency', 'N/A')}\n"
        result += f"  **Priority:** {incident.get('priority', 'N/A')}\n"

        result += "\n**Status & Assignment**\n"
        result += f"  **State:** {incident.get('state', 'N/A')}\n"
        result += f"  **Assignment Group:** "
        assignment_group = incident.get("assignment_group", {})
        if isinstance(assignment_group, dict):
            result += f"{assignment_group.get('display_value', 'N/A')}\n"
        else:
            result += f"{assignment_group or 'N/A'}\n"

        result += "\n**Caller**\n"
        caller = incident.get("caller_id", {})
        if isinstance(caller, dict):
            result += f"  **Caller:** {caller.get('display_value', 'N/A')}\n"
        else:
            result += f"  **Caller:** {caller or 'N/A'}\n"

        result += "\n**Dates**\n"
        result += f"  **Opened:** {incident.get('opened_at', 'N/A')}\n"
        result += f"  **Updated:** {incident.get('sys_updated_on', 'N/A')}\n"
        result += f"  **Resolved:** {incident.get('resolved_at', 'N/A')}\n"
        result += f"  **Closed:** {incident.get('closed_at', 'N/A')}\n"

        work_notes = incident.get("work_notes", "")
        if work_notes:
            result += "\n**Work Notes**\n"
            result += f"  {work_notes}\n"

        return result
    except Exception as exc:  # pragma: no cover
        return f"**Error Getting Incident Details**\n\n**Error:** {exc}"
