"""
Link CIs to Change Request Tool

Add Configuration Items to the Affected CIs tab of a Change Request.
Uses the task_ci table which is ServiceNow's standard M2M relationship.
"""

import sys
from typing import Any, Dict, List
from servicenow_mcp.servicenow import ServiceNowClient


async def link_cis_to_change_request(
    client: ServiceNowClient,
    change_request_id: str,
    ci_sys_ids: List[str],
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Link CIs to a Change Request's Affected CIs tab.
    
    Creates records in the task_ci table to associate CIs with a change request.
    This populates the "Affected CIs" related list on the change request form.
    
    Args:
        client: ServiceNow client instance
        change_request_id: The sys_id of the change request
        ci_sys_ids: List of CI sys_ids to link
        dry_run: If True, validate but don't create links (default: False)
    
    Returns:
        Dictionary containing:
        - success: Boolean indicating overall success
        - linked: Count of CIs successfully linked
        - skipped: Count of CIs already linked (duplicates)
        - failed: Count of CIs that failed to link
        - details: List of individual results
    
    EXAMPLE:
        link_cis_to_change_request(
            change_request_id='84327172835bf210bdcfeec0deaad32c',
            ci_sys_ids=['abc123', 'def456', 'ghi789']
        )
    """
    try:
        # Validate change request exists
        cr_response = await client.get_table_records(
            table="change_request",
            sysparm_query=f"sys_id={change_request_id}",
            sysparm_fields="sys_id,number,short_description",
            sysparm_limit=1,
        )
        
        if not cr_response.get("result"):
            return {
                "success": False,
                "error": f"Change request {change_request_id} not found",
            }
        
        cr = cr_response["result"][0]
        cr_number = cr.get("number", change_request_id)
        
        # Check for existing links to avoid duplicates
        existing_query = f"task={change_request_id}^ci_itemIN{','.join(ci_sys_ids)}"
        existing_response = await client.get_table_records(
            table="task_ci",
            sysparm_query=existing_query,
            sysparm_fields="ci_item",
            sysparm_limit=1000,
        )
        
        existing_ci_ids = set()
        for record in existing_response.get("result", []):
            ci_id = record.get("ci_item")
            if isinstance(ci_id, dict):
                ci_id = ci_id.get("value")
            if ci_id:
                existing_ci_ids.add(ci_id)
        
        linked = 0
        skipped = 0
        failed = 0
        details = []
        
        for ci_sys_id in ci_sys_ids:
            # Skip if already linked
            if ci_sys_id in existing_ci_ids:
                details.append({
                    "ci_sys_id": ci_sys_id,
                    "status": "skipped",
                    "reason": "Already linked to this change request",
                })
                skipped += 1
                continue
            
            # Validate CI exists
            ci_response = await client.get_table_records(
                table="cmdb_ci",
                sysparm_query=f"sys_id={ci_sys_id}",
                sysparm_fields="sys_id,name,sys_class_name",
                sysparm_limit=1,
            )
            
            if not ci_response.get("result"):
                details.append({
                    "ci_sys_id": ci_sys_id,
                    "status": "failed",
                    "reason": "CI not found",
                })
                failed += 1
                continue
            
            ci = ci_response["result"][0]
            ci_name = ci.get("name", ci_sys_id)
            ci_class = ci.get("sys_class_name", "cmdb_ci")
            
            if dry_run:
                details.append({
                    "ci_sys_id": ci_sys_id,
                    "ci_name": ci_name,
                    "ci_class": ci_class,
                    "status": "would_link",
                })
                linked += 1
                continue
            
            # Create the task_ci record
            try:
                create_response = await client.create_record(
                    table="task_ci",
                    data={
                        "task": change_request_id,
                        "ci_item": ci_sys_id,
                    }
                )
                
                if create_response.get("result"):
                    details.append({
                        "ci_sys_id": ci_sys_id,
                        "ci_name": ci_name,
                        "ci_class": ci_class,
                        "status": "linked",
                        "task_ci_sys_id": create_response["result"].get("sys_id"),
                    })
                    linked += 1
                else:
                    details.append({
                        "ci_sys_id": ci_sys_id,
                        "ci_name": ci_name,
                        "status": "failed",
                        "reason": str(create_response.get("error", "Unknown error")),
                    })
                    failed += 1
                    
            except Exception as e:
                details.append({
                    "ci_sys_id": ci_sys_id,
                    "ci_name": ci_name,
                    "status": "failed",
                    "reason": str(e),
                })
                failed += 1
        
        return {
            "success": failed == 0,
            "dry_run": dry_run,
            "change_request": {
                "sys_id": change_request_id,
                "number": cr_number,
            },
            "summary": {
                "total": len(ci_sys_ids),
                "linked": linked,
                "skipped": skipped,
                "failed": failed,
            },
            "details": details,
            "message": f"{'[DRY RUN] ' if dry_run else ''}Linked {linked} CI(s) to {cr_number}" + 
                      (f", skipped {skipped} (already linked)" if skipped else "") +
                      (f", {failed} failed" if failed else ""),
        }
        
    except Exception as e:
        print(f"[link_cis_to_change_request] Error: {e}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e),
        }
