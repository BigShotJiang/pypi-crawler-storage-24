"""Find Similar Incidents Tool

Find incidents similar to a reference incident based on keywords.
Audit-level tool for pattern matching (read-only).
"""

from servicenow_mcp.servicenow import ServiceNowClient


async def find_similar_incidents(
    client: ServiceNowClient,
    *,
    incident_number: str,
    limit: int,
) -> str:
    """Find similar incidents based on a reference incident.

    Args:
        client: ServiceNow client instance
        incident_number: Reference incident number
        limit: Maximum number of similar incidents to return

    Returns:
        Formatted string with similar incidents
    """
    try:
        incidents = await client.query_table(
            table="incident",
            query=f"number={incident_number}",
            limit=1,
        )

        if not incidents:
            return f"**Reference Incident Not Found**\n\nNo incident found with number: {incident_number}"

        reference_incident = incidents[0]
        short_description = reference_incident.get("short_description", "")
        if not short_description:
            return (
                f"**No Description Available**\n\n"
                f"Incident {incident_number} has no short description to extract keywords from."
            )

        words = short_description.split()
        keywords = [
            word.strip(".,!?;:\"'()[]{}")
            for word in words
            if len(word.strip(".,!?;:\"'()[]{}")) > 4
        ]
        keywords = keywords[:3]

        if not keywords:
            return (
                f"**Insufficient Keywords**\n\n"
                f"Incident {incident_number} does not contain enough descriptive words."
            )

        keyword_query = "^OR".join([f"short_descriptionLIKE{key}" for key in keywords])
        encoded_query = f"{keyword_query}^number!={incident_number}" if keyword_query else ""

        similar_incidents = await client.query_table(
            table="incident",
            query=encoded_query,
            limit=limit,
            fields="number,short_description,state,resolution_notes,priority",
        )

        if not similar_incidents:
            return (
                f"**No Similar Incidents Found**\n\n"
                f"No incidents found matching keywords: {', '.join(keywords)}"
            )

        result = (
            f"**Similar Incidents to {incident_number}**\n\n"
            f"**Keywords:** {', '.join(keywords)}\n"
            f"**Results:** {len(similar_incidents)} found\n\n"
        )

        for incident in similar_incidents:
            result += f"**{incident.get('number', 'N/A')}**\n"
            result += f"  **Description:** {incident.get('short_description', 'N/A')}\n"
            result += f"  **State:** {incident.get('state', 'N/A')}\n"
            result += f"  **Priority:** {incident.get('priority', 'N/A')}\n"

            resolution_notes = incident.get("resolution_notes", "")
            if resolution_notes:
                if isinstance(resolution_notes, dict):
                    resolution_notes = resolution_notes.get("display_value", "")
                result += f"  **Resolution Notes:** {resolution_notes[:200]}{'...' if len(resolution_notes) > 200 else ''}\n"
            result += "\n"

        return result
    except Exception as exc:  # pragma: no cover
        return f"**Error Finding Similar Incidents**\n\n**Error:** {exc}"
