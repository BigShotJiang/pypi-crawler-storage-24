"""
Get Change Request Details Tool

Retrieve details of a Change Request by sys_id or number.
Useful for tracking CMDB changes and verifying change management compliance.
"""

import sys
from typing import Any, Dict, Optional, List
from servicenow_mcp.servicenow import ServiceNowClient


async def get_change_request(
    client: ServiceNowClient,
    sys_id: Optional[str] = None,
    number: Optional[str] = None,
    fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Get details of a Change Request by sys_id or CHG number.
    
    Args:
        client: ServiceNow client instance
        sys_id: The sys_id of the change request
        number: The CHG number (e.g., 'CHG0012345')
        fields: Specific fields to retrieve (optional, defaults to common fields)
    
    Returns:
        Dictionary containing change request details or error
    
    EXAMPLE:
        get_change_request(sys_id='84327172835bf210bdcfeec0deaad32c')
        get_change_request(number='CHG0012345')
    """
    try:
        if not sys_id and not number:
            return {
                "success": False,
                "error": "Must provide either sys_id or number",
            }
        
        # Default fields for change requests
        default_fields = [
            "sys_id",
            "number", 
            "short_description",
            "description",
            "state",
            "approval",
            "priority",
            "risk",
            "impact",
            "category",
            "type",
            "requested_by",
            "assigned_to",
            "assignment_group",
            "opened_at",
            "closed_at",
            "start_date",
            "end_date",
            "work_notes",
            "cmdb_ci",
        ]
        
        fields_to_fetch = fields or default_fields
        fields_str = ",".join(fields_to_fetch)
        
        # Build query
        if sys_id:
            query = f"sys_id={sys_id}"
        else:
            query = f"number={number}"
        
        print(f"[get_change_request] Querying change_request with: {query}", file=sys.stderr)
        
        # Try to get the record
        try:
            response = await client.get_table_records(
                table="change_request",
                sysparm_query=query,
                sysparm_fields=fields_str,
                sysparm_limit=1,
                sysparm_display_value="all",  # Get both value and display_value
            )
            
            results = response.get("result", [])
            
            if not results:
                return {
                    "success": False,
                    "error": f"Change Request not found: {sys_id or number}",
                }
            
            cr = results[0]
            
            return {
                "success": True,
                "change_request": cr,
                "number": cr.get("number", {}).get("value") if isinstance(cr.get("number"), dict) else cr.get("number"),
                "state": cr.get("state", {}).get("display_value") if isinstance(cr.get("state"), dict) else cr.get("state"),
                "short_description": cr.get("short_description", {}).get("value") if isinstance(cr.get("short_description"), dict) else cr.get("short_description"),
            }
            
        except Exception as api_error:
            print(f"[get_change_request] API error: {api_error}", file=sys.stderr)
            
            # Fallback: Try task table (change_request extends task)
            try:
                response = await client.get_table_records(
                    table="task",
                    sysparm_query=f"{query}^sys_class_name=change_request",
                    sysparm_fields=fields_str,
                    sysparm_limit=1,
                    sysparm_display_value="all",
                )
                
                results = response.get("result", [])
                if results:
                    cr = results[0]
                    return {
                        "success": True,
                        "change_request": cr,
                        "number": cr.get("number"),
                        "note": "Retrieved via task table fallback",
                    }
            except:
                pass
            
            return {
                "success": False,
                "error": f"Could not retrieve change request: {str(api_error)}",
                "hint": "This may be an ACL (Access Control) issue. Ensure your ServiceNow user has read access to change_request table.",
            }
            
    except Exception as e:
        print(f"[get_change_request] Error: {e}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e),
        }
