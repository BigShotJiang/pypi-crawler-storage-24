"""Add Comment to Incident Tool

Add a comment or work note to an incident.
Audit-level tool for incident comments (write operation).
"""

from servicenow_mcp.servicenow import ServiceNowClient


async def add_comment_to_incident(
    client: ServiceNowClient,
    *,
    incident_number: str,
    comment: str,
    work_notes: bool,
) -> str:
    """Add a comment or work note to an incident.

    Args:
        client: ServiceNow client instance
        incident_number: Incident number to add comment to
        comment: Comment text
        work_notes: If True, adds to internal work notes; if False, adds to customer comments

    Returns:
        Formatted string with result
    """
    try:
        response = await client.get_record_by_number(table="incident", number=incident_number)
        records = response.get("result", [])
        if not records:
            return f"**Incident Not Found**\n\nNo incident found with number: {incident_number}"

        sys_id = records[0].get("sys_id")
        field_name = "work_notes" if work_notes else "comments"
        comment_type = "Work Note (Internal)" if work_notes else "Comment (Customer Visible)"

        await client.update_record(
            table="incident",
            sys_id=sys_id,
            data={field_name: comment},
        )

        result = "✅ **Comment Added Successfully**\n\n"
        result += f"**Incident Number:** {incident_number}\n"
        result += f"**Type:** {comment_type}\n"
        result += f"**Comment:** {comment}\n"
        return result
    except Exception as exc:  # pragma: no cover
        return f"**Error Adding Comment**\n\n**Error:** {exc}"
