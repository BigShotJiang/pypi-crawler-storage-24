"""Search Assignment Groups Tool

Query assignment groups by name.
Audit-level tool for group lookup (read-only).
"""

from servicenow_mcp.servicenow import ServiceNowClient


async def search_assignment_groups(
    client: ServiceNowClient,
    *,
    name: str,
    limit: int,
) -> str:
    """Return assignment group lookup results.

    Args:
        client: ServiceNow client instance
        name: Name pattern to search for
        limit: Maximum number of results to return

    Returns:
        Formatted string with assignment group results
    """
    try:
        query = f"nameLIKE{name}" if name else ""
        groups = await client.query_table(
            table="sys_user_group",
            query=query,
            limit=limit,
            fields="sys_id,name,manager",
        )

        if not groups:
            if name:
                return f"**Assignment Group Search**\n\nNo groups found for '{name}'."
            return "**Assignment Group Search**\n\nNo groups found."

        result = (
            "**Assignment Group Search**\n\n"
            f"**Query:** {name or '(none)'}\n"
            f"**Results:** {len(groups)} found\n\n"
        )

        for group in groups:
            group_name = group.get("name", "Unknown")
            manager = group.get("manager")
            if isinstance(manager, dict):
                manager_display = manager.get("display_value", "Unassigned")
            else:
                manager_display = manager or "Unassigned"

            sys_id_value = group.get("sys_id")
            if isinstance(sys_id_value, dict):
                sys_id_value = sys_id_value.get("value", "Unknown")

            result += f"**{group_name}**\n"
            result += f"  **Sys ID:** {sys_id_value or 'Unknown'}\n"
            result += f"  **Manager:** {manager_display}\n\n"

        return result
    except Exception as exc:  # pragma: no cover
        return f"**Assignment Group Search Error**\n\n**Error:** {exc}"
