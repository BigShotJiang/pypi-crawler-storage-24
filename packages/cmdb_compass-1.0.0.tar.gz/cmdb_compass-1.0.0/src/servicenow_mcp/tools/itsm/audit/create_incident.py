"""Create Incident Tool

Create a new incident in ServiceNow.
Audit-level tool for incident creation (write operation).
"""

from typing import Any, Dict, Optional

from servicenow_mcp.servicenow import ServiceNowClient


async def create_incident(
    client: ServiceNowClient,
    *,
    short_description: str,
    description: Optional[str],
    urgency: str,
    impact: str,
    caller: Optional[str],
    assignment_group: Optional[str],
) -> str:
    """Create a new incident and return a formatted success message.

    Args:
        client: ServiceNow client instance
        short_description: Brief incident summary (required)
        description: Detailed incident description (optional)
        urgency: Urgency level (1-5)
        impact: Impact level (1-5)
        caller: Caller user sys_id (optional)
        assignment_group: Assignment group sys_id (optional)

    Returns:
        Formatted string with incident creation result
    """
    priority = str(min(int(urgency), int(impact)))
    incident_data: Dict[str, Any] = {
        "short_description": short_description,
        "urgency": urgency,
        "impact": impact,
        "priority": priority,
    }

    if description is not None:
        incident_data["description"] = description
    if caller is not None:
        incident_data["caller_id"] = caller
    if assignment_group is not None:
        incident_data["assignment_group"] = assignment_group

    response = await client.create_record(table="incident", data=incident_data)
    result_data = response.get("result", {})
    incident_number = result_data.get("number", "Unknown")
    sys_id = result_data.get("sys_id", "Unknown")

    result = "✅ **Incident Created Successfully**\n\n"
    result += f"**Incident Number:** {incident_number}\n"
    result += f"**Sys ID:** {sys_id}\n"
    result += f"**Short Description:** {short_description}\n"
    result += (
        f"**Priority:** {priority} (calculated from urgency={urgency}, impact={impact})\n"
    )
    return result
