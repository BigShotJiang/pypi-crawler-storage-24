"""
List Recent Change Requests Tool

Retrieve a list of recent change requests with optional filtering.
Useful for monitoring CMDB changes and change management oversight.
"""

import sys
from typing import Any, Dict, Optional
from servicenow_mcp.servicenow import ServiceNowClient


async def list_recent_change_requests(
    client: ServiceNowClient,
    limit: int = 10,
    state: Optional[str] = None,
    opened_after: Optional[str] = None,
) -> Dict[str, Any]:
    """
    List recent change requests with optional filtering.
    
    Args:
        client: ServiceNow client instance
        limit: Maximum number of records (default: 10)
        state: Filter by state (e.g., 'new', 'assess', 'implement', 'closed')
        opened_after: ISO date string to filter by opened_at (e.g., '2026-03-01')
    
    Returns:
        Dictionary containing list of change requests
    
    EXAMPLE:
        list_recent_change_requests(limit=5)
        list_recent_change_requests(state='implement', opened_after='2026-03-01')
    """
    try:
        query_parts = []
        
        if state:
            query_parts.append(f"state={state}")
        if opened_after:
            query_parts.append(f"opened_at>={opened_after}")
        
        query_parts.append("ORDERBYDESCopened_at")
        query = "^".join(query_parts)
        
        fields = "sys_id,number,short_description,state,priority,opened_at,assigned_to"
        
        response = await client.get_table_records(
            table="change_request",
            sysparm_query=query,
            sysparm_fields=fields,
            sysparm_limit=limit,
            sysparm_display_value="true",
        )
        
        results = response.get("result", [])
        
        return {
            "success": True,
            "count": len(results),
            "change_requests": results,
        }
        
    except Exception as e:
        print(f"[list_recent_change_requests] Error: {e}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e),
        }
