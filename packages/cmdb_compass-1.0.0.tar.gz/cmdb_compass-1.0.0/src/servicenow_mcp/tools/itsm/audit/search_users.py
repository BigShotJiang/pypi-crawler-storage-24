"""Search Users Tool

Query users by name.
Audit-level tool for user lookup (read-only).
"""

from servicenow_mcp.servicenow import ServiceNowClient


async def search_users(
    client: ServiceNowClient,
    *,
    name: str,
    limit: int,
) -> str:
    """Return user lookup results.

    Args:
        client: ServiceNow client instance
        name: Name pattern to search for
        limit: Maximum number of results to return

    Returns:
        Formatted string with user results
    """
    try:
        query = f"nameLIKE{name}" if name else ""
        users = await client.query_table(
            table="sys_user",
            query=query,
            limit=limit,
            fields="sys_id,name,user_name,email",
        )

        if not users:
            if name:
                return f"**User Search**\n\nNo users found for '{name}'."
            return "**User Search**\n\nNo users found."

        result = (
            "**User Search**\n\n"
            f"**Query:** {name or '(none)'}\n"
            f"**Results:** {len(users)} found\n\n"
        )

        for user in users:
            full_name = user.get("name", "Unknown")
            username = user.get("user_name", "Unknown")
            email = user.get("email", "Unknown")

            sys_id_value = user.get("sys_id")
            if isinstance(sys_id_value, dict):
                sys_id_value = sys_id_value.get("value", "Unknown")

            result += f"**{full_name}**\n"
            result += f"  **Username:** {username}\n"
            result += f"  **Email:** {email or 'N/A'}\n"
            result += f"  **Sys ID:** {sys_id_value or 'Unknown'}\n\n"

        return result
    except Exception as exc:  # pragma: no cover
        return f"**User Search Error**\n\n**Error:** {exc}"
