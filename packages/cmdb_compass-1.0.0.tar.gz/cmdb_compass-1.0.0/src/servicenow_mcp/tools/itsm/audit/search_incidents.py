"""Search Incidents Tool

Query incident table with filters for priority, state, assigned_to.
Audit-level tool for incident lookup (read-only).
"""

from typing import Optional

from servicenow_mcp.servicenow import ServiceNowClient


async def search_incidents(
    client: ServiceNowClient,
    *,
    query: str | None,
    priority: Optional[str],
    state: Optional[str],
    assigned_to: Optional[str],
    limit: int,
) -> str:
    """Return a formatted incident search result.

    Args:
        client: ServiceNow client instance
        query: Text to search in short_description and description
        priority: Filter by priority level
        state: Filter by incident state
        assigned_to: Filter by assigned user name
        limit: Maximum number of results to return

    Returns:
        Formatted string with incident search results
    """
    try:
        query_parts: list[str] = []

        if query:
            query_parts.append(f"short_descriptionLIKE{query}^ORdescriptionLIKE{query}")
        if priority:
            query_parts.append(f"priority={priority}")
        if state:
            query_parts.append(f"state={state}")
        if assigned_to:
            query_parts.append(f"assigned_to.user_name={assigned_to}")

        encoded_query = "^".join(query_parts) if query_parts else ""
        incidents = await client.query_table(
            table="incident",
            query=encoded_query,
            limit=limit,
        )

        if not incidents:
            return "**Incident Search Results**\n\nNo incidents found matching the criteria."

        result = f"**Incident Search Results** ({len(incidents)} found)\n\n"
        for incident in incidents:
            result += f"**{incident.get('number', 'N/A')}**\n"
            result += f"  **Description:** {incident.get('short_description', 'N/A')}\n"
            result += f"  **State:** {incident.get('state', 'N/A')}\n"
            result += f"  **Priority:** {incident.get('priority', 'N/A')}\n"
            assigned = incident.get("assigned_to", {})
            if isinstance(assigned, dict):
                result += f"  **Assigned To:** {assigned.get('display_value', 'Unassigned')}\n"
            else:
                result += f"  **Assigned To:** {assigned or 'Unassigned'}\n"
            result += "\n"

        return result
    except Exception as exc:  # pragma: no cover
        return f"**Incident Search Error**\n\n**Error:** {exc}"
