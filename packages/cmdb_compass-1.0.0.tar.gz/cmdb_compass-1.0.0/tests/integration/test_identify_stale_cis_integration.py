"""
Integration tests for Identify Stale CIs tool

These tests validate end-to-end functionality with realistic data scenarios.
"""

import pytest
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis
from tests.utils.sn_client_mock import ServiceNowClientMock


class TestIdentifyStaleCisIntegration:
    """Integration tests for identify_stale_cis with realistic scenarios."""

    @pytest.fixture
    def synthetic_client(self):
        """Create a synthetic ServiceNow client with controlled data."""
        return ServiceNowClientMock()

    @pytest.mark.asyncio
    async def test_realistic_mixed_staleness(self, synthetic_client):
        """Test with realistic mix of fresh, moderate, aging, and stale CIs."""
        now = datetime.now(timezone.utc)

        # Create realistic dataset
        cis = []

        # 10 fresh CIs (0-30 days)
        for i in range(10):
            days_old = i * 3  # 0, 3, 6, 9, 12, 15, 18, 21, 24, 27 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"fresh_{i}",
                "name": f"FreshServer{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        # 5 moderate CIs (30-60 days)
        for i in range(5):
            days_old = 30 + (i * 6)  # 30, 36, 42, 48, 54 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"moderate_{i}",
                "name": f"ModerateServer{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        # 3 aging CIs (60-90 days)
        for i in range(3):
            days_old = 60 + (i * 10)  # 60, 70, 80 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"aging_{i}",
                "name": f"AgingServer{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        # 7 stale CIs (90+ days)
        for i in range(7):
            days_old = 90 + (i * 30)  # 90, 120, 150, 180, 210, 240, 270 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"stale_{i}",
                "name": f"StaleServer{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        synthetic_client.set_table_data("cmdb_ci_server", cis)

        result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
            include_details=True,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 25
        assert result["stale_count"] == 7
        assert result["fresh_count"] == 10
        assert result["staleness_distribution"]["0-30d (fresh)"] == 10
        assert result["staleness_distribution"]["30-60d (moderate)"] == 5
        assert result["staleness_distribution"]["60-90d (aging)"] == 3
        assert result["staleness_distribution"]["90d+ (stale, >90d)"] == 7
        assert len(result["stale_cis"]) == 7
        assert len(result["fresh_cis"]) == 10

    @pytest.mark.asyncio
    async def test_discovery_gap_scenario(self, synthetic_client):
        """Test scenario where discovery stopped running."""
        now = datetime.now(timezone.utc)

        # Simulate discovery running 6 months ago, then stopped
        discovery_stopped_date = now - timedelta(days=180)

        cis = []
        for i in range(20):
            # All CIs last discovered 180+ days ago
            last_discovered = (discovery_stopped_date - timedelta(days=i*2)).isoformat()
            # But sys_updated_on is more recent (manual updates)
            sys_updated = (now - timedelta(days=i*5)).isoformat()

            cis.append({
                "sys_id": f"ci_{i}",
                "name": f"Server{i}",
                "operational_status": "1",
                "sys_updated_on": sys_updated,
                "last_discovered": last_discovered,
            })

        synthetic_client.set_table_data("cmdb_ci_server", cis)

        # Tool should use last_discovered (older) when available
        result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 20
        # All should be stale because last_discovered is 180+ days old
        assert result["stale_count"] == 20
        assert "CRITICAL" in result["recommendations"][0]
        assert "Discovery" in result["recommendations"][1]

    @pytest.mark.asyncio
    async def test_decommissioned_infrastructure_scenario(self, synthetic_client):
        """Test scenario with old decommissioned infrastructure."""
        now = datetime.now(timezone.utc)

        cis = []

        # 5 active servers (fresh)
        for i in range(5):
            timestamp = (now - timedelta(days=i*2)).isoformat()
            cis.append({
                "sys_id": f"active_{i}",
                "name": f"ActiveServer{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        # 15 decommissioned servers (very stale)
        for i in range(15):
            days_old = 365 + (i * 10)  # 1+ years old
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"decomm_{i}",
                "name": f"DecommServer{i}",
                "operational_status": "1",  # Still marked active incorrectly
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        synthetic_client.set_table_data("cmdb_ci_server", cis)

        result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 20
        assert result["stale_count"] == 15
        assert result["fresh_count"] == 5
        assert result["stale_percentage"] == 75.0
        assert "CRITICAL" in result["recommendations"][0]
        assert "auto_retire_stale_cis" in result["recommendations"][2]

    @pytest.mark.asyncio
    async def test_custom_threshold_30_days(self, synthetic_client):
        """Test with aggressive 30-day threshold."""
        now = datetime.now(timezone.utc)

        cis = []
        for i in range(10):
            days_old = i * 10  # 0, 10, 20, 30, 40, 50, 60, 70, 80, 90 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            cis.append({
                "sys_id": f"ci_{i}",
                "name": f"Server{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        synthetic_client.set_table_data("cmdb_ci_server", cis)

        result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=30,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 10
        assert result["staleness_threshold_days"] == 30
        # CIs at 0, 10, 20 days are fresh (3 CIs)
        # CIs at 30+ days are stale (7 CIs)
        assert result["fresh_count"] == 3
        assert result["stale_count"] == 7

    @pytest.mark.asyncio
    async def test_multi_class_comparison(self, synthetic_client):
        """Test comparing staleness across different CI classes."""
        now = datetime.now(timezone.utc)

        # Servers: mostly fresh (good discovery)
        server_cis = []
        for i in range(20):
            days_old = i * 4  # 0-76 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            server_cis.append({
                "sys_id": f"server_{i}",
                "name": f"Server{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        # Databases: mostly stale (poor discovery)
        db_cis = []
        for i in range(20):
            days_old = 60 + (i * 10)  # 60-250 days
            timestamp = (now - timedelta(days=days_old)).isoformat()
            db_cis.append({
                "sys_id": f"db_{i}",
                "name": f"Database{i}",
                "operational_status": "1",
                "sys_updated_on": timestamp,
                "last_discovered": timestamp,
            })

        synthetic_client.set_table_data("cmdb_ci_server", server_cis)
        synthetic_client.set_table_data("cmdb_ci_database", db_cis)

        # Test servers
        server_result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        # Test databases
        db_result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_database",
            staleness_threshold_days=90,
        )

        assert server_result["status"] == "success"
        assert db_result["status"] == "success"

        # Servers should have low staleness
        assert server_result["stale_percentage"] < 30

        # Databases should have high staleness
        assert db_result["stale_percentage"] > 50
        assert "CRITICAL" in db_result["recommendations"][0]

    @pytest.mark.asyncio
    async def test_timezone_edge_cases(self, synthetic_client):
        """Test various timezone format edge cases."""
        now = datetime.now(timezone.utc)

        cis = [
            # ISO 8601 with Z
            {
                "sys_id": "ci_iso_z",
                "name": "ServerISOZ",
                "operational_status": "1",
                "sys_updated_on": (now - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "last_discovered": None,
            },
            # ServiceNow native format
            {
                "sys_id": "ci_sn_native",
                "name": "ServerSNNative",
                "operational_status": "1",
                "sys_updated_on": (now - timedelta(days=20)).strftime("%Y-%m-%d %H:%M:%S"),
                "last_discovered": None,
            },
            # ISO 8601 with timezone offset
            {
                "sys_id": "ci_iso_offset",
                "name": "ServerISOOffset",
                "operational_status": "1",
                "sys_updated_on": (now - timedelta(days=15)).isoformat(),
                "last_discovered": None,
            },
            # Stale timestamp in various formats
            {
                "sys_id": "ci_stale_z",
                "name": "ServerStaleZ",
                "operational_status": "1",
                "sys_updated_on": (now - timedelta(days=120)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "last_discovered": None,
            },
            # Missing timestamp
            {
                "sys_id": "ci_no_timestamp",
                "name": "ServerNoTimestamp",
                "operational_status": "1",
                "sys_updated_on": None,
                "last_discovered": None,
            },
        ]

        synthetic_client.set_table_data("cmdb_ci_server", cis)

        result = await identify_stale_cis(
            client=synthetic_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 5
        assert result["fresh_count"] == 3  # ISO Z, SN native, ISO offset
        assert result["stale_count"] == 1  # Stale Z
        assert result["staleness_distribution"]["unknown"] == 1  # Missing timestamp
