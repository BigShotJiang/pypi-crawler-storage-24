#!/usr/bin/env python3
"""
Live MCP Server Tool Testing Script

This script starts the ServiceNow MCP server and tests all tools via the MCP protocol.
It provides real-world testing results with actual ServiceNow connectivity.
"""

import asyncio
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add project paths
project_root = Path(__file__).parent.parent.parent.parent  # Go up from tests/integration/ to project root
mcp_src = project_root / "mcp-server" / "src"

for path in [str(mcp_src), str(project_root)]:
    if path not in sys.path:
        sys.path.insert(0, path)

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class MCPServerTester:
    """Test all MCP tools via live server connection."""

    def __init__(self):
        self.server_process: Optional[subprocess.Popen] = None
        self.session: Optional[ClientSession] = None
        self.results: Dict[str, Any] = {
            "server_started": False,
            "connection_established": False,
            "tools_discovered": [],
            "tool_results": {},
            "errors": [],
            "summary": {}
        }

    async def start_server(self) -> bool:
        """Start the MCP server as a subprocess."""
        try:
            print("🚀 Starting ServiceNow MCP server...")

            # Use the same environment setup as the launcher script
            env = os.environ.copy()
            env["PYTHONPATH"] = f"{project_root}/mcp-server/src:{project_root}:{env.get('PYTHONPATH', '')}"

            # Load .env file if it exists
            env_file = project_root / ".env"
            if env_file.exists():
                from dotenv import load_dotenv
                load_dotenv(env_file)
                print("📄 Loaded environment variables from .env")

            # Start server
            cmd = [
                sys.executable,
                str(project_root / "infra" / "scripts" / "run_mcp_server.py")
            ]

            self.server_process = subprocess.Popen(
                cmd,
                cwd=str(project_root),
                env=env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Wait for server to start
            time.sleep(3)

            # Check if server is still running
            if self.server_process.poll() is None:
                print("✅ MCP server started successfully")
                self.results["server_started"] = True
                return True
            else:
                stdout, stderr = self.server_process.communicate()
                error_msg = f"Server failed to start: {stderr}"
                print(f"❌ {error_msg}")
                self.results["errors"].append(error_msg)
                return False

        except Exception as e:
            error_msg = f"Failed to start server: {str(e)}"
            print(f"❌ {error_msg}")
            self.results["errors"].append(error_msg)
            return False

    async def connect_to_server(self) -> bool:
        """Connect to the MCP server via stdio."""
        try:
            print("🔌 Connecting to MCP server...")

            # Create stdio parameters for the server process
            server_params = StdioServerParameters(
                command=sys.executable,
                args=[str(project_root / "infra" / "scripts" / "run_mcp_server.py")],
                cwd=str(project_root),
                env={
                    "PYTHONPATH": f"{project_root}/mcp-server/src:{project_root}",
                    **os.environ
                }
            )

            async with stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    self.session = session

                    # Initialize the session
                    await session.initialize()
                    print("✅ Connected to MCP server")
                    self.results["connection_established"] = True

                    # Test the connection
                    await self.test_tools()

        except Exception as e:
            error_msg = f"Failed to connect to server: {str(e)}"
            print(f"❌ {error_msg}")
            self.results["errors"].append(error_msg)
            return False

    async def test_tools(self):
        """Discover and test all available tools."""
        try:
            print("🔍 Discovering available tools...")

            # List all tools
            tools_response = await self.session.list_tools()
            tools = tools_response.tools

            print(f"📋 Found {len(tools)} tools:")
            for tool in tools:
                print(f"  - {tool.name}: {tool.description[:50]}...")

            self.results["tools_discovered"] = [tool.name for tool in tools]

            # Test each tool with minimal parameters
            await self.test_all_tools(tools)

        except Exception as e:
            error_msg = f"Failed to test tools: {str(e)}"
            print(f"❌ {error_msg}")
            self.results["errors"].append(error_msg)

    async def test_all_tools(self, tools):
        """Test each tool with appropriate parameters."""
        print("🧪 Testing all tools...")

        # Define test parameters for each tool
        test_params = {
            # Data Access Tools
            "query_table_records": {"table": "cmdb_ci", "limit": 5},
            "count_table_records": {"table": "cmdb_ci"},
            "list_tables_and_fields": {},
            "get_table_description": {"table_name": "incident"},

            # CMDB Audit Tools
            "analyze_ci_completeness": {"table": "cmdb_ci_server", "audit_level": "quick"},
            "assess_relationship_coverage": {"ci_class": "cmdb_ci_server", "audit_level": "quick"},
            "identify_domain_gaps": {"domain": "Foundation", "audit_level": "quick"},
            "check_csdm_rules": {},
            "audit_identify_stale_cis": {"ci_class": "cmdb_ci_server", "staleness_threshold_days": 60, "include_details": False},
            "audit_duplicate_cis": {"table_name": "cmdb_ci_server", "audit_level": "quick"},
            "calculate_csdm_maturity_score": {"audit_level": "quick"},
            "analyze_tagging_compliance": {"audit_level": "quick"},
            "analyze_service_mappings": {"audit_level": "quick"},
            "classify_ci_relationships": {"audit_level": "quick"},
            "suggest_ci_relationship_mappings": {"audit_level": "quick"},
            "extract_ci_context": {"ci_sysid": "test_sys_id"},

            # CMDB Action Tools (with dry_run=True)
            "auto_retire_stale_cis": {"table": "cmdb_ci_server", "dry_run": True, "audit_level": "quick"},
            "bulk_update_missing_fields": {"table": "cmdb_ci_server", "field_mappings": {"test_field": "test_value"}, "dry_run": True},
            "merge_duplicate_cis": {"duplicate_ci_sysids": ["test1", "test2"], "keep_sysid": "test1"},
            "remediate_relationship_health": {"dry_run": True},

            # ITSM Tools
            "search_incidents": {"query": "test"},
            "get_incident_details": {"incident_number": "INC0010001"},
            "create_incident": {"short_description": "Test incident", "dry_run": True},
            "update_incident": {"incident_number": "INC0010001", "dry_run": True},
            "add_comment_to_incident": {"incident_number": "INC0010001", "comment": "Test comment", "dry_run": True},
            "search_assignment_groups": {"name": "test"},
            "search_users": {"name": "test"},
            "find_similar_incidents": {"incident_number": "INC0010001"},

            # Diagnostics
            "test_servicenow_connection": {},
            "generate_compliance_report": {"audit_level": "quick"},
        }

        successful_tests = 0
        failed_tests = 0

        for tool in tools:
            tool_name = tool.name
            print(f"  🛠️  Testing {tool_name}...")

            try:
                # Get test parameters
                params = test_params.get(tool_name, {})

                # Call the tool
                start_time = time.time()
                result = await self.session.call_tool(tool_name, params)
                end_time = time.time()

                # Check result
                if result.content:
                    status = "success"
                    successful_tests += 1
                    execution_time = end_time - start_time
                    print(".2f")
                else:
                    status = "no_content"
                    failed_tests += 1
                    print(f"    ⚠️  No content returned")

                self.results["tool_results"][tool_name] = {
                    "status": status,
                    "execution_time": execution_time if 'execution_time' in locals() else None,
                    "has_content": bool(result.content),
                    "content_length": len(result.content) if result.content else 0
                }

            except Exception as e:
                failed_tests += 1
                error_msg = f"Tool {tool_name} failed: {str(e)}"
                print(f"    ❌ {error_msg}")
                self.results["tool_results"][tool_name] = {
                    "status": "error",
                    "error": str(e)
                }
                self.results["errors"].append(error_msg)

        # Update summary
        self.results["summary"] = {
            "total_tools": len(tools),
            "successful_tests": successful_tests,
            "failed_tests": failed_tests,
            "success_rate": ".1f"
        }

        print("\n📊 Test Summary:")
        print(f"  Total tools: {len(tools)}")
        print(f"  Successful: {successful_tests}")
        print(f"  Failed: {failed_tests}")
        print(".1f")
    async def cleanup(self):
        """Clean up server process."""
        if self.server_process:
            print("🧹 Cleaning up server process...")
            try:
                self.server_process.terminate()
                self.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.server_process.kill()
            print("✅ Server process cleaned up")

    def save_results(self):
        """Save test results to file."""
        artifacts_dir = Path(__file__).parent.parent / ".artifacts"
        artifacts_dir.mkdir(exist_ok=True)
        results_file = artifacts_dir / "live_test_results.json"

        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)

        print(f"💾 Results saved to {results_file}")
        return results_file


async def main():
    """Main testing function."""
    print("🧪 ServiceNow MCP Server Live Testing")
    print("=" * 50)

    tester = MCPServerTester()

    try:
        # Start server
        if not await tester.start_server():
            print("❌ Cannot proceed without server")
            return

        # Connect and test
        await tester.connect_to_server()

    except KeyboardInterrupt:
        print("\n⚠️  Test interrupted by user")
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        tester.results["errors"].append(str(e))
    finally:
        await tester.cleanup()

        # Save results
        results_file = tester.save_results()

        print("\n🎯 Live Test Complete!")
        print(f"Results saved to: {results_file}")

        # Print summary
        if tester.results["summary"]:
            summary = tester.results["summary"]
            print("\n📈 Summary:")
            print(f"  Tools tested: {summary['total_tools']}")
            print(f"  Success rate: {summary['success_rate']}%")

        if tester.results["errors"]:
            print("\n⚠️  Errors encountered:")
            for error in tester.results["errors"][:5]:  # Show first 5 errors
                print(f"  - {error}")
            if len(tester.results["errors"]) > 5:
                print(f"  ... and {len(tester.results['errors']) - 5} more")


if __name__ == "__main__":
    asyncio.run(main())
