"""
Dynamic integration tests for ServiceNow MCP tools.

This module discovers all MCP tools dynamically and runs smoke tests
with the mock ServiceNow client.
"""

import json
import os
import pytest
from pathlib import Path


class TestToolDiscovery:
    """Test tool discovery and basic validation."""

    def test_server_imports(self):
        """Test that server module imports successfully."""
        # This should not raise any exceptions
        from servicenow_mcp import server
        assert server is not None

    def test_decorator_count(self, tool_registry):
        """Test that we discover the expected number of tools."""
        tool_count = len(tool_registry)
        tool_names = [name for name, _ in tool_registry]

        assert tool_count >= 50, f"Expected at least 50 tools, found {tool_count}: {tool_names}"

    def test_tool_inventory_persistence(self, tool_registry):
        """Persist tool inventory to artifacts."""
        artifacts_dir = Path(__file__).parent.parent / ".artifacts"
        inventory_file = artifacts_dir / "tool_inventory.txt"

        tool_names = [name for name, _ in tool_registry]
        with open(inventory_file, 'w') as f:
            for name in tool_names:
                f.write(f"{name}\n")

        assert inventory_file.exists()
        assert len(tool_names) >= 50, f"Expected at least 50 tools in inventory"


class TestToolSmokeTests:
    """Smoke tests for all discovered tools."""

    @pytest.mark.asyncio
    async def test_all_tools_smoke(self, tool_registry, default_inputs, call_tool):
        """Run smoke test on all tools with minimal inputs."""
        results = {}
        passed_count = 0
        failed_count = 0

        for tool_name, tool_func in tool_registry:
            kwargs = default_inputs.get(tool_name, {})

            # Call the tool
            try:
                result = await call_tool(tool_func, **kwargs)

                # Basic validation: should return dict or list or str, not raise exception
                if isinstance(result, (dict, list, str)):
                    results[tool_name] = {"status": "passed"}
                    passed_count += 1
                else:
                    results[tool_name] = {"status": "failed", "error": f"Invalid return type: {type(result)}"}
                    failed_count += 1

            except Exception as e:
                results[tool_name] = {"status": "failed", "error": str(e)}
                failed_count += 1

        # Log results for debugging
        print(f"Smoke test results: {passed_count} passed, {failed_count} failed")

        # For the framework test, we just need some tools to work
        # This validates the discovery and calling mechanism
        assert passed_count > 0, f"No tools passed smoke test. Results: {results}"
        assert len(results) == len(tool_registry), "All tools should be tested"

    @pytest.mark.asyncio
    async def test_parameter_validation(self, tool_registry, call_tool):
        """Test parameter validation for specific tools."""

        # Test merge_duplicate_cis with empty duplicate_ci_sysids
        merge_tool = None
        for name, func in tool_registry:
            if name == 'merge_duplicate_cis':
                merge_tool = func
                break

        if merge_tool:
            # Should fail with empty list
            result = await call_tool(merge_tool, duplicate_ci_sysids=[], keep_sysid="test")
            assert isinstance(result, dict)
            assert "error" in result or "status" in result

        # Test remediate_relationship_health with invalid remediation_type
        health_tool = None
        for name, func in tool_registry:
            if name == 'remediate_relationship_health':
                health_tool = func
                break

        if health_tool:
            result = await call_tool(health_tool, remediation_type="invalid", dry_run=True)
            assert isinstance(result, dict)
            # Should either return error or handle gracefully

        # Test query_table_records with high limit
        query_tool = None
        for name, func in tool_registry:
            if name == 'query_table_records':
                query_tool = func
                break

        if query_tool:
            result = await call_tool(query_tool, table="cmdb_ci", limit=2000)
            # Should either clamp limit or return reasonable result
            assert isinstance(result, (dict, list))

    @pytest.mark.asyncio
    async def test_generate_compliance_report_phase1_checks(self, tool_registry, call_tool):
        """Test Phase 1 refactor assertions for generate_compliance_report."""
        # Check the implementation, not the wrapper
        import inspect
        from servicenow_mcp.tools.cmdb.audit.audit_generate_compliance_report import generate_compliance_report as impl

        source = inspect.getsource(impl)
        assert "get_cmdb360_dashboard_metrics" not in source, "Phase 1: Should not contain get_cmdb360_dashboard_metrics"
        assert "cmdb_ci" in source, "Phase 1: Should use live queries from cmdb_ci table"
        assert "field_coverage_result" in source, "Phase 1: Should calculate metrics dynamically from field coverage"

        # Test the wrapper tool exists
        compliance_tool = None
        for name, func in tool_registry:
            if name in ('generate_compliance_report', 'audit_generate_compliance_report'):
                compliance_tool = func
                break

        assert compliance_tool is not None, "generate_compliance_report tool not found"

        # Test that it returns some result (even if it fails due to mock limitations)
        result = await call_tool(compliance_tool, audit_level="quick")
        assert isinstance(result, (dict, str)), "Should return dict or string result"

    @pytest.mark.asyncio
    async def test_environment_gating(self, tool_registry, call_tool):
        """Test that action tools are properly gated by environment variables."""
        # Ensure NEXECUTE_ENABLE_CMDB_ACTION is false
        assert os.getenv("NEXECUTE_ENABLE_CMDB_ACTION") == "false"

        action_tools = [
            'auto_retire_stale_cis', 'classify_ci_relationships',
            'suggest_ci_relationship_mappings', 'bulk_update_missing_fields',
            'merge_duplicate_cis', 'remediate_relationship_health'
        ]

        for tool_name in action_tools:
            tool_func = None
            for name, func in tool_registry:
                if name == tool_name:
                    tool_func = func
                    break

            if tool_func:
                # These should either return unavailable or handle gracefully
                result = await call_tool(tool_func, dry_run=True, audit_level="quick")
                # Either returns dict with unavailable status or processes successfully with dry_run
                assert isinstance(result, (dict, list, str))


class TestToolCategories:
    """Test tool categorization and coverage."""

    def test_tool_categories(self, tool_registry):
        """Test that tools can be categorized properly."""
        # Define expected categories based on naming patterns
        categories = {
            "Data Access": [],
            "CMDB Audit": [],
            "CMDB Action": [],
            "ITSM": [],
            "Diagnostics": []
        }

        category_patterns = {
            "Data Access": ["query_table_records", "count_table_records", "list_tables_and_fields", "get_table_description"],
            "CMDB Audit": ["analyze_ci_completeness", "assess_relationship_coverage", "identify_domain_gaps",
                          "audit_identify_stale_cis", "audit_duplicate_cis", "calculate_csdm_maturity_score", "analyze_tagging_compliance",
                          "analyze_service_mappings", "check_csdm_rules", "classify_ci_relationships",
                          "suggest_ci_relationship_mappings", "extract_ci_context"],
            "CMDB Action": ["auto_retire_stale_cis", "bulk_update_missing_fields", "merge_duplicate_cis",
                           "remediate_relationship_health"],
            "ITSM": ["search_incidents", "get_incident_details", "create_incident", "update_incident",
                    "add_comment_to_incident", "search_assignment_groups", "search_users", "find_similar_incidents"],
            "Diagnostics": ["test_servicenow_connection", "generate_compliance_report"]
        }

        tool_names = [name for name, _ in tool_registry]

        for tool_name in tool_names:
            categorized = False
            for category, patterns in category_patterns.items():
                if any(pattern in tool_name for pattern in patterns):
                    categories[category].append(tool_name)
                    categorized = True
                    break

            if not categorized:
                # If not categorized by pattern, assign based on keywords
                if 'incident' in tool_name or 'search_' in tool_name:
                    categories["ITSM"].append(tool_name)
                elif 'analyze_' in tool_name or 'assess_' in tool_name or 'find_' in tool_name:
                    categories["CMDB Audit"].append(tool_name)
                elif 'retire' in tool_name or 'bulk_' in tool_name or 'merge_' in tool_name:
                    categories["CMDB Action"].append(tool_name)
                else:
                    categories["Diagnostics"].append(tool_name)

        # Verify we have reasonable distribution
        total_categorized = sum(len(tools) for tools in categories.values())
        assert total_categorized == len(tool_names), f"All {len(tool_names)} tools should be categorized"

        # Should have at least some tools in each major category
        assert len(categories["Data Access"]) > 0
        assert len(categories["CMDB Audit"]) > 0
        assert len(categories["ITSM"]) > 0
