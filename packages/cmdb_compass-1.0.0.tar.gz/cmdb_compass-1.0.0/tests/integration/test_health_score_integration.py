"""
Integration tests for Calculate CMDB Health Score tool
Run against live ServiceNow instance to validate production behavior
"""

import asyncio
import os
import sys
from pathlib import Path
from datetime import datetime

# Add tools directory to path

mcp_path = Path(__file__).parent.parent.parent / "src"
sys.path.insert(0, str(mcp_path))

from servicenow_mcp.servicenow import ServiceNowClient
from servicenow_mcp.tools.cmdb.query.calculate_cmdb_health_score import calculate_cmdb_health_score


def print_header(text: str):
    """Print a formatted header."""
    print("\n" + "=" * 80)
    print(f"  {text}")
    print("=" * 80)


def print_section(text: str):
    """Print a formatted section."""
    print(f"\n--- {text} ---")


def print_result(label: str, value, indent=0):
    """Print a formatted result."""
    prefix = "  " * indent
    print(f"{prefix}{label}: {value}")


async def test_basic_health_score(client: ServiceNowClient):
    """Test 1: Basic health score calculation for servers."""
    print_header("Test 1: Basic Health Score - cmdb_ci_server")

    result = await calculate_cmdb_health_score(
        client=client,
        ci_class="cmdb_ci_server",
        include_breakdown=True,
        sample_size=1000
    )

    print_section("Status & Overview")
    print_result("Status", result.get("status"))
    print_result("CI Class", result.get("ci_class"))
    print_result("Total CIs Analyzed", result.get("total_cis"))

    print_section("Health Scores")
    print_result("Overall Score", f"{result.get('overall_score', 0)}/100")
    print_result("Health Rating", result.get("health_rating"))
    print_result("├─ Completeness (40%)", f"{result.get('completeness_score', 0):.1f}/100")
    print_result("├─ Relationships (25%)", f"{result.get('relationship_score', 0):.1f}/100")
    print_result("├─ Staleness (20%)", f"{result.get('staleness_score', 0):.1f}/100")
    print_result("└─ Duplicates (15%)", f"{result.get('duplicate_score', 0):.1f}/100")

    if "breakdown" in result:
        print_section("Detailed Breakdown")

        # Completeness details
        if "completeness" in result["breakdown"]:
            comp = result["breakdown"]["completeness"]
            print_result("Completeness Details", "")
            print_result("Total Fields Checked", comp.get("total_fields"), 1)
            print_result("Populated Count", f"{comp.get('populated_count')}/{comp.get('total_possible')}", 1)

            if "field_stats" in comp:
                print_result("Field Coverage", "", 1)
                for field, stats in comp["field_stats"].items():
                    coverage = stats.get("coverage_percentage", 0)
                    print_result(f"  • {field}", f"{coverage:.1f}% ({stats.get('populated')}/{stats.get('total')} CIs)", 2)

        # Staleness details
        if "staleness" in result["breakdown"]:
            stale = result["breakdown"]["staleness"]
            print_result("Staleness Details", "")
            print_result("Fresh CIs (0-30 days)", stale.get("fresh_cis"), 1)
            print_result("Stale CIs (90+ days)", stale.get("stale_cis"), 1)

            if "age_distribution" in stale:
                print_result("Age Distribution", "", 1)
                age_dist = stale["age_distribution"]
                print_result("  • 0-30 days", age_dist.get("0-30d", 0), 2)
                print_result("  • 30-60 days", age_dist.get("30-60d", 0), 2)
                print_result("  • 60-90 days", age_dist.get("60-90d", 0), 2)
                print_result("  • 90+ days (stale)", age_dist.get("90d+", 0), 2)
                print_result("  • Unknown", age_dist.get("unknown", 0), 2)

        # Relationship details
        if "relationships" in result["breakdown"]:
            rels = result["breakdown"]["relationships"]
            print_result("Relationship Details", "")
            print_result("CIs with Relationships", f"{rels.get('cis_with_relationships')}/{rels.get('cis_sampled')}", 1)
            print_result("Total Relationships", rels.get("total_relationships"), 1)
            print_result("Avg per CI", rels.get("average_relationships_per_ci"), 1)

        # Duplicate details
        if "duplicates" in result["breakdown"]:
            dups = result["breakdown"]["duplicates"]
            print_result("Duplicate Details", "")
            print_result("Duplicates Detected", dups.get("duplicates_detected"), 1)

            if "field_duplicates" in dups and dups["field_duplicates"]:
                print_result("By Field", "", 1)
                for field, count in dups["field_duplicates"].items():
                    if count > 0:
                        print_result(f"  • {field}", count, 2)

    print_section("Recommendations")
    recommendations = result.get("recommendations", [])
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            print(f"  {i}. {rec}")
    else:
        print("  (No recommendations - excellent health!)")

    # Validation
    print_section("Validation")
    validations = []

    if result.get("status") == "success":
        validations.append("✅ Status is success")
    else:
        validations.append("❌ Status is not success")

    overall = result.get("overall_score", 0)
    if 0 <= overall <= 100:
        validations.append(f"✅ Overall score in valid range: {overall}/100")
    else:
        validations.append(f"❌ Overall score out of range: {overall}")

    if result.get("health_rating") in ["Excellent", "Good", "Fair", "Poor", "Critical"]:
        validations.append(f"✅ Valid health rating: {result.get('health_rating')}")
    else:
        validations.append(f"❌ Invalid health rating: {result.get('health_rating')}")

    if result.get("total_cis", 0) > 0:
        validations.append(f"✅ Found {result.get('total_cis')} CIs to analyze")
    else:
        validations.append("⚠️  No CIs found - may be empty class")

    if len(result.get("recommendations", [])) > 0:
        validations.append(f"✅ Generated {len(result.get('recommendations'))} recommendations")
    else:
        validations.append("✅ No recommendations (perfect health or no data)")

    for validation in validations:
        print(f"  {validation}")

    return result


async def test_different_ci_classes(client: ServiceNowClient):
    """Test 2: Health scores across different CI classes."""
    print_header("Test 2: Health Scores Across CI Classes")

    ci_classes = [
        "cmdb_ci_server",
        "cmdb_ci_database",
        "cmdb_ci_service",
        "cmdb_ci_app_server",
    ]

    results = {}

    for ci_class in ci_classes:
        print_section(f"Analyzing {ci_class}")

        try:
            result = await calculate_cmdb_health_score(
                client=client,
                ci_class=ci_class,
                include_breakdown=False,  # Skip breakdown for speed
                sample_size=500
            )

            results[ci_class] = result

            print_result("Status", result.get("status"))
            print_result("Total CIs", result.get("total_cis"))
            print_result("Overall Score", f"{result.get('overall_score', 0):.1f}/100")
            print_result("Health Rating", result.get("health_rating"))

        except Exception as e:
            print(f"  ❌ Error: {str(e)}")
            results[ci_class] = {"error": str(e)}

    # Summary comparison
    print_section("Cross-Class Comparison")

    print(f"\n{'CI Class':<30} {'CIs':<10} {'Score':<10} {'Rating':<15}")
    print("-" * 70)

    for ci_class, result in results.items():
        if "error" in result:
            print(f"{ci_class:<30} {'ERROR':<10} {'-':<10} {'-':<15}")
        else:
            total = result.get("total_cis", 0)
            score = result.get("overall_score", 0)
            rating = result.get("health_rating", "Unknown")
            print(f"{ci_class:<30} {total:<10} {score:<10.1f} {rating:<15}")

    return results


async def test_custom_critical_fields(client: ServiceNowClient):
    """Test 3: Custom critical fields for specialized scoring."""
    print_header("Test 3: Custom Critical Fields")

    print_section("Default Fields vs Custom Fields")

    # Test with default fields
    print("\n📋 Default Critical Fields:")
    result_default = await calculate_cmdb_health_score(
        client=client,
        ci_class="cmdb_ci_server",
        include_breakdown=True,
        sample_size=100
    )

    print_result("Completeness Score (default)", f"{result_default.get('completeness_score', 0):.1f}/100")

    if "breakdown" in result_default and "completeness" in result_default["breakdown"]:
        comp = result_default["breakdown"]["completeness"]
        if "field_stats" in comp:
            print("  Fields checked:")
            for field in comp["field_stats"].keys():
                print(f"    • {field}")

    # Test with custom fields
    print("\n📋 Custom Critical Fields:")
    custom_fields = ["name", "serial_number", "ip_address"]

    result_custom = await calculate_cmdb_health_score(
        client=client,
        ci_class="cmdb_ci_server",
        critical_fields=custom_fields,
        include_breakdown=True,
        sample_size=100
    )

    print_result("Completeness Score (custom)", f"{result_custom.get('completeness_score', 0):.1f}/100")
    print("  Custom fields:")
    for field in custom_fields:
        print(f"    • {field}")

    return {"default": result_default, "custom": result_custom}


async def test_sample_size_performance(client: ServiceNowClient):
    """Test 4: Performance with different sample sizes."""
    print_header("Test 4: Sample Size Performance Testing")

    sample_sizes = [50, 100, 500, 1000]

    print(f"\n{'Sample Size':<15} {'CIs Found':<15} {'Duration (s)':<15} {'Score':<10}")
    print("-" * 60)

    for sample_size in sample_sizes:
        start_time = datetime.now()

        result = await calculate_cmdb_health_score(
            client=client,
            ci_class="cmdb_ci_server",
            include_breakdown=False,
            sample_size=sample_size
        )

        duration = (datetime.now() - start_time).total_seconds()

        total_cis = result.get("total_cis", 0)
        score = result.get("overall_score", 0)

        print(f"{sample_size:<15} {total_cis:<15} {duration:<15.2f} {score:<10.1f}")

    print("\n✅ Performance test complete")


async def test_edge_cases(client: ServiceNowClient):
    """Test 5: Edge cases and error handling."""
    print_header("Test 5: Edge Cases & Error Handling")

    test_cases = [
        {
            "name": "Empty/Non-existent CI Class",
            "params": {
                "ci_class": "cmdb_ci_nonexistent_class_xyz",
                "sample_size": 100
            }
        },
        {
            "name": "Very Small Sample Size",
            "params": {
                "ci_class": "cmdb_ci_server",
                "sample_size": 1
            }
        },
        {
            "name": "No Breakdown",
            "params": {
                "ci_class": "cmdb_ci_server",
                "include_breakdown": False,
                "sample_size": 100
            }
        },
    ]

    for i, test_case in enumerate(test_cases, 1):
        print_section(f"Edge Case {i}: {test_case['name']}")

        try:
            result = await calculate_cmdb_health_score(
                client=client,
                **test_case["params"]
            )

            print_result("Status", result.get("status"))
            print_result("Total CIs", result.get("total_cis"))

            if result.get("status") == "success":
                print("  ✅ Handled gracefully")
            else:
                print(f"  ⚠️  Returned error: {result.get('error')}")

        except Exception as e:
            print(f"  ❌ Exception raised: {str(e)}")


async def run_all_tests():
    """Run all integration tests."""
    print_header("CMDB Health Score - Integration Test Suite")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Get ServiceNow credentials from environment
    instance_url = os.getenv("SERVICENOW_INSTANCE_URL")
    username = os.getenv("SERVICENOW_USERNAME")
    password = os.getenv("SERVICENOW_PASSWORD")

    if not all([instance_url, username, password]):
        print("\n❌ ERROR: Missing ServiceNow credentials")
        print("\nPlease set environment variables:")
        print("  export SERVICENOW_INSTANCE_URL='https://your-instance.service-now.com'")
        print("  export SERVICENOW_USERNAME='your-username'")
        print("  export SERVICENOW_PASSWORD='your-password'")
        return

    print(f"\nServiceNow Instance: {instance_url}")
    print(f"Username: {username}")

    # Initialize client
    client = ServiceNowClient(
        instance_url=instance_url,
        username=username,
        password=password
    )

    try:
        # Run tests
        test_results = {}

        test_results["basic"] = await test_basic_health_score(client)
        test_results["multi_class"] = await test_different_ci_classes(client)
        test_results["custom_fields"] = await test_custom_critical_fields(client)
        await test_sample_size_performance(client)
        await test_edge_cases(client)

        # Final summary
        print_header("Integration Test Summary")

        basic = test_results["basic"]
        print(f"\n📊 Primary Test Results (cmdb_ci_server):")
        print(f"   Total CIs: {basic.get('total_cis', 0)}")
        print(f"   Overall Score: {basic.get('overall_score', 0):.1f}/100")
        print(f"   Health Rating: {basic.get('health_rating', 'Unknown')}")

        print(f"\n📈 Dimensional Scores:")
        print(f"   Completeness: {basic.get('completeness_score', 0):.1f}/100")
        print(f"   Relationships: {basic.get('relationship_score', 0):.1f}/100")
        print(f"   Staleness: {basic.get('staleness_score', 0):.1f}/100")
        print(f"   Duplicates: {basic.get('duplicate_score', 0):.1f}/100")

        print(f"\n💡 Top 3 Recommendations:")
        recommendations = basic.get("recommendations", [])
        for i, rec in enumerate(recommendations[:3], 1):
            print(f"   {i}. {rec}")

        print(f"\n✅ All integration tests completed successfully!")
        print(f"Finished: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    except Exception as e:
        print(f"\n❌ Test suite failed with error: {str(e)}")
        import traceback
        traceback.print_exc()

    finally:
        # Close client connection
        await client.close()


if __name__ == "__main__":
    asyncio.run(run_all_tests())
