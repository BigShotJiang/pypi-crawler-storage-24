"""Tests for audit_ire_health tool

Tests IRE health auditing functionality including:
- Identification rule analysis
- Reconciliation state analysis
- Match rule analysis
- Health scoring
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from servicenow_mcp.tools.cmdb.audit.audit_ire_health import (
    audit_ire_health,
    _audit_identification_rules,
    _audit_reconciliation_states,
    _audit_match_rules,
    _generate_ire_recommendations,
    _calculate_ire_health_score
)


@pytest.fixture
def mock_client():
    """Create mock ServiceNow client."""
    client = Mock()
    client.get_table_records = AsyncMock()
    return client


@pytest.fixture
def sample_identification_rules():
    """Sample identification rules from sys_id_rule table."""
    return [
        {
            "name": "Server - Serial Number",
            "table": "cmdb_ci_server",
            "active": "true",
            "priority": "100",
            "attributes": "serial_number",
            "condition": ""
        },
        {
            "name": "Server - IP Address",
            "table": "cmdb_ci_server",
            "active": "true",
            "priority": "200",
            "attributes": "ip_address",
            "condition": ""
        },
        {
            "name": "Server - Hostname (Inactive)",
            "table": "cmdb_ci_server",
            "active": "false",
            "priority": "300",
            "attributes": "name",
            "condition": ""
        },
        {
            "name": "Server - Misconfigured",
            "table": "cmdb_ci_server",
            "active": "true",
            "priority": "400",
            "attributes": "",  # No attributes - misconfigured
            "condition": ""
        },
        {
            "name": "Database - Name",
            "table": "cmdb_ci_database",
            "active": "true",
            "priority": "100",
            "attributes": "name,version",
            "condition": ""
        }
    ]


@pytest.fixture
def sample_reconciliation_states():
    """Sample reconciliation states from cmdb_reconciliation_state table."""
    return [
        {
            "cmdb_ci": "ci_001",
            "state": "Reconciled",
            "last_reconciled": "2026-03-06 10:00:00",
            "source": "ServiceNow Discovery"
        },
        {
            "cmdb_ci": "ci_002",
            "state": "Reconciled",
            "last_reconciled": "2026-03-06 09:00:00",
            "source": "ServiceNow Discovery"
        },
        {
            "cmdb_ci": "ci_003",
            "state": "Skipped",
            "last_reconciled": "2026-03-05 10:00:00",
            "source": "Manual Entry"
        },
        {
            "cmdb_ci": "ci_004",
            "state": "In Progress",
            "last_reconciled": "2026-03-06 11:00:00",
            "source": "SCCM"
        },
        {
            "cmdb_ci": "ci_005",
            "state": "Skipped",
            "last_reconciled": "2026-03-04 10:00:00",
            "source": "Manual Entry"
        }
    ]


@pytest.fixture
def sample_match_rules():
    """Sample match rules from cmdb_key_value table."""
    return [
        {
            "source": "ServiceNow Discovery",
            "key": "serial_number",
            "value": "SN123456",
            "cmdb_ci": "ci_001"
        },
        {
            "source": "SCCM",
            "key": "hostname",
            "value": "server01",
            "cmdb_ci": "ci_002"
        },
        {
            "source": "Manual Entry",
            "key": "ip_address",
            "value": "192.168.1.100",
            "cmdb_ci": "ci_003"
        }
    ]


class TestAuditIREHealth:
    """Test audit_ire_health main function."""
    
    @pytest.mark.asyncio
    async def test_full_audit_success(self, mock_client, sample_identification_rules, 
                                      sample_reconciliation_states, sample_match_rules):
        """Test successful full IRE health audit."""
        
        # Mock API responses
        mock_client.get_table_records.side_effect = [
            {"result": sample_identification_rules},  # sys_id_rule
            {"result": sample_reconciliation_states},  # cmdb_reconciliation_state
            {"result": sample_match_rules}  # cmdb_key_value
        ]
        
        result = await audit_ire_health(
            client=mock_client,
            ci_class="cmdb_ci_server",
            check_rule_status=True,
            check_reconciliation_states=True,
            check_match_conflicts=True
        )
        
        assert result["status"] == "success"
        assert result["ci_class"] == "cmdb_ci_server"
        assert "ire_configuration" in result
        assert "reconciliation_health" in result
        assert "match_rules" in result
        assert "recommendations" in result
        assert "health_score" in result
    
    @pytest.mark.asyncio
    async def test_audit_quick_level(self, mock_client):
        """Test quick audit level."""
        mock_client.get_table_records.return_value = {"result": []}
        
        result = await audit_ire_health(
            client=mock_client,
            audit_level="quick"
        )
        
        assert result["audit_level"] == "quick"
    
    @pytest.mark.asyncio
    async def test_audit_with_error(self, mock_client):
        """Test handling of API errors."""
        mock_client.get_table_records.side_effect = Exception("API Error")
        
        result = await audit_ire_health(
            client=mock_client
        )
        
        # Tool handles errors gracefully, returns success with available=false
        assert result["status"] == "success"
        assert result["ire_available"] == False
        # Check that at least one component has an error
        has_error = any(
            comp.get("error") or comp.get("available") == False
            for comp in [result.get("ire_configuration", {}), 
                        result.get("reconciliation_health", {}),
                        result.get("match_rules", {})]
        )
        assert has_error


class TestIdentificationRulesAudit:
    """Test identification rules analysis."""
    
    @pytest.mark.asyncio
    async def test_audit_identification_rules_success(self, mock_client, sample_identification_rules):
        """Test successful identification rules audit."""
        mock_client.get_table_records.return_value = {"result": sample_identification_rules}
        
        result = await _audit_identification_rules(mock_client, "cmdb_ci_server")
        
        assert result["available"] == True
        assert result["total_rules"] == 5
        # 4 rules have active=true (including the misconfigured one), 1 is inactive
        assert result["active_rules"] == 4
        assert result["inactive_rules"] == 1
        assert "cmdb_ci_server" in result["rules_by_class"]
        # 1 misconfigured rule (active but no attributes)
        assert len(result["misconfigured_rules"]) == 1
        assert result["misconfigured_rules"][0]["name"] == "Server - Misconfigured"
    
    @pytest.mark.asyncio
    async def test_audit_identification_rules_api_error(self, mock_client):
        """Test handling of API errors."""
        mock_client.get_table_records.return_value = {"error": "Table not found"}
        
        result = await _audit_identification_rules(mock_client, None)
        
        assert "error" in result
        assert "sys_id_rule" in result["error"]
    
    @pytest.mark.asyncio
    async def test_audit_no_rules(self, mock_client):
        """Test when no identification rules exist."""
        mock_client.get_table_records.return_value = {"result": []}
        
        result = await _audit_identification_rules(mock_client, None)
        
        assert result["available"] == True
        assert result["total_rules"] == 0
        assert "note" in result
        assert "recommendation" in result


class TestReconciliationStatesAudit:
    """Test reconciliation states analysis."""
    
    @pytest.mark.asyncio
    async def test_audit_reconciliation_states_success(self, mock_client, sample_reconciliation_states):
        """Test successful reconciliation states audit."""
        mock_client.get_table_records.return_value = {"result": sample_reconciliation_states}
        
        result = await _audit_reconciliation_states(mock_client, "cmdb_ci_server")
        
        assert result["total_cis"] == 5
        assert result["state_distribution"]["Reconciled"] == 2
        assert result["state_distribution"]["Skipped"] == 2
        assert result["state_distribution"]["In Progress"] == 1
    
    @pytest.mark.asyncio
    async def test_audit_reconciliation_states_api_error(self, mock_client):
        """Test handling of API errors."""
        mock_client.get_table_records.return_value = {"error": "Access denied"}
        
        result = await _audit_reconciliation_states(mock_client, None)
        
        assert "error" in result
        assert "cmdb_reconciliation_state" in result["error"]


class TestMatchRulesAudit:
    """Test match rules analysis."""
    
    @pytest.mark.asyncio
    async def test_audit_match_rules_success(self, mock_client, sample_match_rules):
        """Test successful match rules audit."""
        mock_client.get_table_records.return_value = {"result": sample_match_rules}
        
        result = await _audit_match_rules(mock_client, None)
        
        assert result["total_match_rules"] == 3
        assert len(result["data_sources"]) == 3
        assert "ServiceNow Discovery" in result["data_sources"]
        assert "SCCM" in result["data_sources"]
        assert "Manual Entry" in result["data_sources"]


class TestRecommendations:
    """Test recommendation generation."""
    
    def test_recommendations_inactive_rules(self):
        """Test recommendations when rules are inactive."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 7,
                "inactive_rules": 3,
                "misconfigured_rules": []
            },
            "reconciliation_health": {
                "available": True,
                "total_cis": 100,
                "state_distribution": {"Reconciled": 100}
            }
        }
        
        recommendations = _generate_ire_recommendations(result)
        
        assert any("inactive" in r.lower() for r in recommendations)
        assert any("3" in r for r in recommendations)
    
    def test_recommendations_misconfigured_rules(self):
        """Test recommendations when rules are misconfigured."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 5,
                "active_rules": 5,
                "inactive_rules": 0,
                "misconfigured_rules": [
                    {"name": "Bad Rule 1"},
                    {"name": "Bad Rule 2"}
                ]
            },
            "reconciliation_health": {
                "available": True,
                "total_cis": 100,
                "state_distribution": {"Reconciled": 100}
            }
        }
        
        recommendations = _generate_ire_recommendations(result)
        
        assert any("misconfigured" in r.lower() or "no identification attributes" in r.lower() 
                   for r in recommendations)
    
    def test_recommendations_high_skipped_rate(self):
        """Test recommendations when many CIs have Skipped state."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 5,
                "active_rules": 5,
                "inactive_rules": 0,
                "misconfigured_rules": []
            },
            "reconciliation_health": {
                "available": True,
                "total_cis": 100,
                "state_distribution": {
                    "Reconciled": 70,
                    "Skipped": 30  # 30% skipped
                }
            }
        }
        
        recommendations = _generate_ire_recommendations(result)
        
        assert any("skipped" in r.lower() for r in recommendations)
    
    def test_recommendations_healthy_ire(self):
        """Test recommendations when IRE is healthy."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 10,
                "inactive_rules": 0,
                "misconfigured_rules": []
            },
            "reconciliation_health": {
                "available": True,
                "total_cis": 100,
                "state_distribution": {"Reconciled": 100}
            },
            "match_rules": {
                "available": True,
                "total_match_rules": 100
            }
        }
        
        recommendations = _generate_ire_recommendations(result)
        
        assert any("good" in r.lower() or "no critical issues" in r.lower() for r in recommendations)


class TestHealthScore:
    """Test IRE health score calculation."""
    
    def test_score_perfect_health(self):
        """Test score when IRE is perfectly healthy."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 10,
                "inactive_rules": 0,
                "misconfigured_rules": []
            }
        }
        
        score = _calculate_ire_health_score(result)
        
        assert score["score"] == 100
        assert score["rating"] == "Excellent"
    
    def test_score_with_inactive_rules(self):
        """Test score deduction for inactive rules."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 5,
                "inactive_rules": 5,  # 50% inactive
                "misconfigured_rules": []
            }
        }
        
        score = _calculate_ire_health_score(result)
        
        # 50% inactive = -25 points (50 * 0.5)
        assert score["score"] == 75
        assert score["rating"] == "Good"
    
    def test_score_with_misconfigured_rules(self):
        """Test score deduction for misconfigured rules."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 10,
                "inactive_rules": 0,
                "misconfigured_rules": [{"name": f"Rule {i}"} for i in range(3)]  # 3 misconfigured
            }
        }
        
        score = _calculate_ire_health_score(result)
        
        # 3 misconfigured = -15 points (3 * 5)
        assert score["score"] == 85
        assert score["rating"] == "Good"
    
    def test_score_ratings(self):
        """Test different score rating thresholds."""
        
        # Excellent: >= 90
        result1 = {"ire_configuration": {"available": True, "total_rules": 10, "active_rules": 10, "inactive_rules": 0, "misconfigured_rules": []}}
        assert _calculate_ire_health_score(result1)["rating"] == "Excellent"
        
        # Good: >= 75
        result2 = {"ire_configuration": {"available": True, "total_rules": 10, "active_rules": 5, "inactive_rules": 5, "misconfigured_rules": []}}
        assert _calculate_ire_health_score(result2)["rating"] == "Good"
        
        # Fair: >= 60
        result3 = {"ire_configuration": {"available": True, "total_rules": 10, "active_rules": 2, "inactive_rules": 8, "misconfigured_rules": []}}
        assert _calculate_ire_health_score(result3)["rating"] == "Fair"
        
        # Poor: >= 40
        result4 = {"ire_configuration": {"available": True, "total_rules": 10, "active_rules": 0, "inactive_rules": 10, "misconfigured_rules": [{"name": "Rule 1"}]}}
        score4 = _calculate_ire_health_score(result4)
        assert score4["rating"] == "Poor"
        
    def test_score_floor_at_zero(self):
        """Test that score never goes below 0."""
        result = {
            "ire_configuration": {
                "available": True,
                "total_rules": 10,
                "active_rules": 0,
                "inactive_rules": 10,
                "misconfigured_rules": [{"name": f"Rule {i}"} for i in range(30)]  # Way too many
            }
        }
        
        score = _calculate_ire_health_score(result)
        
        assert score["score"] >= 0
        assert score["rating"] == "Critical"
    
    def test_score_unavailable(self):
        """Test health score when IRE not available."""
        result = {
            "ire_configuration": {
                "available": False,
                "error": "Table not found"
            }
        }
        
        score = _calculate_ire_health_score(result)
        
        assert score["score"] is None
        assert score["rating"] == "N/A"
        assert "note" in score
