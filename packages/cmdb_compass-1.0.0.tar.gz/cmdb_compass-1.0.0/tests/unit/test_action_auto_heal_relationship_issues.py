"""
Unit tests for action_auto_heal_relationship_issues (Phase 3 Week 2 Tool #4)
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime, timezone
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.action.action_auto_heal_relationship_issues import action_auto_heal_relationship_issues


@pytest.fixture
def mock_client():
    """Create a mock ServiceNow client."""
    client = Mock()
    client.get_table_records = AsyncMock()
    client.delete_record = AsyncMock()
    client.update_record = AsyncMock()
    return client


@pytest.fixture
def mock_validation_result():
    """Mock validation result from audit_validate_relationship_integrity."""
    return {
        "status": "success",
        "total_relationships": 5,
        "relationship_health_score": 60.0,
        "violation_summary": {
            "orphaned_count": 2,
            "invalid_type_count": 2,
            "missing_type_count": 1,
            "circular_count": 0,
        },
        "orphaned_relationships": [
            {
                "relationship_sys_id": "rel_orphan_1",
                "parent_sys_id": "missing_parent",
                "child_sys_id": "ci2",
                "reason": "parent CI missing_parent missing",
            },
            {
                "relationship_sys_id": "rel_orphan_2",
                "parent_sys_id": "ci3",
                "child_sys_id": "missing_child",
                "reason": "child CI missing_child missing",
            },
        ],
        "invalid_type_relationships": [
            {
                "relationship_sys_id": "rel_invalid_1",
                "invalid_type": "BadType",
            },
            {
                "relationship_sys_id": "rel_invalid_2",
                "invalid_type": "Runs",
            },
        ],
        "missing_type_relationships": [
            {
                "relationship_sys_id": "rel_missing_1",
            },
        ],
    }


@pytest.fixture
def mock_audit_trail():
    """Mock CmdbChangeAuditTrail."""
    audit_trail = Mock()
    audit_trail.session_id = "CMDB_CHANGE_20250118_123456_test"
    audit_trail.record_change = AsyncMock()
    return audit_trail


@pytest.fixture
def mock_precheck():
    """Mock CmdbChangePrecheck."""
    precheck = Mock()
    precheck.validate_change = AsyncMock(return_value=(True, {"validation": "passed"}))
    return precheck


class TestActionAutoHealRelationshipIssues:
    """Test action_auto_heal_relationship_issues functionality."""

    @pytest.mark.asyncio
    async def test_dry_run_preview_mode(self, mock_client, mock_validation_result):
        """Test dry_run mode returns preview without making changes."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck'):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                        fix_invalid_types=True,
                        fix_missing_types=False,
                    )

        assert result["status"] == "success"
        assert result["dry_run"] is True
        assert result["changes_planned"] == 4  # 2 orphaned + 2 invalid types
        assert result["changes_applied"] == 0
        assert result["orphaned_removed"] == 2
        assert result["types_normalized"] == 2
        assert result["types_classified"] == 0

        # Verify no actual changes were made
        mock_client.delete_record.assert_not_called()
        mock_client.update_record.assert_not_called()

    @pytest.mark.asyncio
    async def test_fix_orphaned_relationships(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test removing orphaned relationships."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=True,
                        fix_invalid_types=False,
                        fix_missing_types=False,
                    )

        assert result["status"] == "success"
        assert result["dry_run"] is False
        assert result["changes_applied"] == 2
        assert result["orphaned_removed"] == 2

        # Verify delete_record was called for both orphaned relationships
        assert mock_client.delete_record.call_count == 2
        mock_client.delete_record.assert_any_call("cmdb_rel_ci", "rel_orphan_1")
        mock_client.delete_record.assert_any_call("cmdb_rel_ci", "rel_orphan_2")

        # Verify audit trail recorded changes
        assert mock_audit_trail.record_change.call_count == 2

    @pytest.mark.asyncio
    async def test_normalize_invalid_types(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test normalizing invalid relationship types to CSDM 5.0."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=False,
                        fix_invalid_types=True,
                        fix_missing_types=False,
                    )

        assert result["status"] == "success"
        assert result["types_normalized"] == 2

        # Verify update_record was called for invalid types
        assert mock_client.update_record.call_count == 2

        # Verify "Runs" was normalized to "Runs on::Runs"
        calls = mock_client.update_record.call_args_list
        assert any("Runs on::Runs" in str(call) for call in calls)

    @pytest.mark.asyncio
    async def test_classify_missing_types(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test classifying relationships with missing types."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=False,
                        fix_invalid_types=False,
                        fix_missing_types=True,
                    )

        assert result["status"] == "success"
        assert result["types_classified"] == 1

        # Verify update_record was called for missing type
        mock_client.update_record.assert_called_once()

    @pytest.mark.asyncio
    async def test_batch_limit_enforcement(self, mock_client, mock_validation_result):
        """Test that batch limit is enforced."""
        # Create validation result with many violations
        large_validation_result = {
            "status": "success",
            "violation_summary": {
                "orphaned_count": 150,
                "invalid_type_count": 0,
                "missing_type_count": 0,
                "circular_count": 0,
            },
            "orphaned_relationships": [
                {
                    "relationship_sys_id": f"rel_{i}",
                    "parent_sys_id": f"missing_{i}",
                    "child_sys_id": f"ci_{i}",
                    "reason": f"parent CI missing_{i} missing",
                }
                for i in range(150)
            ],
            "invalid_type_relationships": [],
            "missing_type_relationships": [],
        }

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=large_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck'):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                        limit=50,
                    )

        # Should only plan 50 changes, not 150
        assert result["changes_planned"] == 50
        assert len(result["change_details"]) <= 10  # Standard audit level shows sample

    @pytest.mark.asyncio
    async def test_precheck_validation_failure(self, mock_client, mock_validation_result):
        """Test that precheck validation failure prevents changes."""
        mock_precheck_fail = Mock()
        mock_precheck_fail.validate_change = AsyncMock(
            return_value=(False, {"validation": "failed", "reason": "CI locked"})
        )

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck_fail):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=True,
                    )

        assert result["status"] == "error"
        assert "Precheck validation failed" in result["error"]
        assert result["changes_applied"] == 0

        # Verify no changes were made
        mock_client.delete_record.assert_not_called()
        mock_client.update_record.assert_not_called()

    @pytest.mark.asyncio
    async def test_change_request_integration(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test Change Request ID is passed through to audit trail."""
        change_request_id = "CHG0012345"

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=True,
                        fix_invalid_types=False,
                        change_request_id=change_request_id,
                    )

        assert result["status"] == "success"
        assert result["change_request"] == change_request_id

        # Verify precheck was called with change_request_id
        mock_precheck.validate_change.assert_called_once()
        call_args = mock_precheck.validate_change.call_args
        assert call_args.kwargs["change_request_id"] == change_request_id

        # Verify audit trail recorded changes with CR
        for call in mock_audit_trail.record_change.call_args_list:
            assert call.kwargs["change_request_id"] == change_request_id

    @pytest.mark.asyncio
    async def test_no_issues_found(self, mock_client):
        """Test handling when no issues are found."""
        clean_validation_result = {
            "status": "success",
            "violation_summary": {
                "orphaned_count": 0,
                "invalid_type_count": 0,
                "missing_type_count": 0,
                "circular_count": 0,
            },
            "orphaned_relationships": [],
            "invalid_type_relationships": [],
            "missing_type_relationships": [],
        }

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=clean_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck'):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                    )

        assert result["status"] == "success"
        assert result["changes_planned"] == 0
        assert result["changes_applied"] == 0
        assert "No relationship issues found" in result["message"]

    @pytest.mark.asyncio
    async def test_audit_levels(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test different audit levels return appropriate detail."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    # Quick level
                    result_quick = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                        fix_invalid_types=True,
                        audit_level="quick",
                    )

                    # Standard level
                    result_standard = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                        fix_invalid_types=True,
                        audit_level="standard",
                    )

                    # Deep level
                    result_deep = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                        fix_invalid_types=True,
                        audit_level="deep",
                    )

        # Quick should have no details
        assert len(result_quick["change_details"]) == 0

        # Standard should have sample (up to 10)
        assert len(result_standard["change_details"]) <= 10

        # Deep should have all details
        assert len(result_deep["change_details"]) == result_deep["changes_planned"]

    @pytest.mark.asyncio
    async def test_combined_fixes(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test fixing multiple issue types in one run."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=True,
                        fix_invalid_types=True,
                        fix_missing_types=True,
                    )

        assert result["status"] == "success"
        assert result["changes_applied"] == 5  # 2 orphaned + 2 invalid + 1 missing
        assert result["orphaned_removed"] == 2
        assert result["types_normalized"] == 2
        assert result["types_classified"] == 1

        # Verify both delete and update operations were performed
        assert mock_client.delete_record.call_count == 2
        assert mock_client.update_record.call_count == 3

    @pytest.mark.asyncio
    async def test_partial_failure_handling(self, mock_client, mock_validation_result, mock_audit_trail, mock_precheck):
        """Test handling when some changes fail."""
        # Make one delete fail
        mock_client.delete_record.side_effect = [
            None,  # First delete succeeds
            Exception("Database error"),  # Second delete fails
        ]

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail',
                       return_value=mock_audit_trail):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck',
                           return_value=mock_precheck):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=False,
                        fix_orphaned=True,
                        fix_invalid_types=False,
                    )

        # Should still return success but with fewer changes applied
        assert result["status"] == "success"
        assert result["changes_planned"] == 2
        assert result["changes_applied"] == 1  # Only 1 succeeded

    @pytest.mark.asyncio
    async def test_validation_error_handling(self, mock_client):
        """Test error handling when validation fails."""
        error_validation_result = {
            "status": "error",
            "error": "Failed to fetch relationships",
        }

        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=error_validation_result):
            result = await action_auto_heal_relationship_issues(
                client=mock_client,
                dry_run=True,
            )

        assert result["status"] == "error"
        assert "Validation failed" in result["error"]

    @pytest.mark.asyncio
    async def test_recommendations_in_dry_run(self, mock_client, mock_validation_result):
        """Test that recommendations are provided in dry_run mode."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck'):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        fix_orphaned=True,
                    )

        assert "recommendations" in result
        assert len(result["recommendations"]) > 0
        assert any("dry_run=False" in rec.get("action", "") for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_limit_exceeds_maximum(self, mock_client, mock_validation_result):
        """Test that limit is capped at 1000."""
        with patch('cmdb.action.action_auto_heal_relationship_issues.audit_validate_relationship_integrity',
                   return_value=mock_validation_result):
            with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangeAuditTrail'):
                with patch('cmdb.action.action_auto_heal_relationship_issues.CmdbChangePrecheck'):
                    result = await action_auto_heal_relationship_issues(
                        client=mock_client,
                        dry_run=True,
                        limit=5000,  # Try to set limit above 1000
                    )

        # Should still succeed with capped limit
        assert result["status"] == "success"
        # Actual limit used internally is capped at 1000
