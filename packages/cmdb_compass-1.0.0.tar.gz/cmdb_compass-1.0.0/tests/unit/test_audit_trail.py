"""
Unit tests for CMDB Audit Trail
"""

import pytest
import json
import hashlib
from datetime import datetime
from unittest.mock import Mock, AsyncMock
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.action.audit_trail import CmdbChangeAuditTrail


class TestCmdbChangeAuditTrail:
    """Test CMDB Change Audit Trail functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        client.update_record = AsyncMock()
        return client

    @pytest.fixture
    def audit_trail(self, mock_client):
        """Create an audit trail instance."""
        return CmdbChangeAuditTrail(mock_client, user="test_user")

    def test_session_id_generation(self, audit_trail):
        """Test that session IDs are generated correctly."""
        session_id = audit_trail.session_id
        assert session_id.startswith("CMDB_CHANGE_")
        assert len(session_id) > 20  # Should include timestamp and hash

    def test_session_id_uniqueness(self, mock_client):
        """Test that each audit trail gets a unique session ID."""
        import time
        trail1 = CmdbChangeAuditTrail(mock_client)
        time.sleep(0.001)  # Small delay to ensure different timestamps
        trail2 = CmdbChangeAuditTrail(mock_client)
        assert trail1.session_id != trail2.session_id

    @pytest.mark.asyncio
    async def test_record_change_basic(self, audit_trail):
        """Test basic change recording."""
        record = await audit_trail.record_change(
            tool_name="test_tool",
            change_type="update",
            ci_sys_id="ci_123",
            ci_name="Test CI",
        )

        assert record["session_id"] == audit_trail.session_id
        assert record["user"] == "test_user"
        assert record["tool"] == "test_tool"
        assert record["change_type"] == "update"
        assert record["ci_sys_id"] == "ci_123"
        assert record["ci_name"] == "Test CI"
        assert record["risk_level"] == "low"
        assert "timestamp" in record
        assert "checksum" in record

    @pytest.mark.asyncio
    async def test_record_change_with_states(self, audit_trail):
        """Test change recording with before/after states."""
        before_state = {"name": "Old Name", "environment": "dev"}
        after_state = {"name": "New Name", "environment": "prod"}

        record = await audit_trail.record_change(
            tool_name="test_tool",
            change_type="update",
            ci_sys_id="ci_123",
            ci_name="Test CI",
            before_state=before_state,
            after_state=after_state,
        )

        assert record["before_state"] == before_state
        assert record["after_state"] == after_state

    @pytest.mark.asyncio
    async def test_checksum_generation(self, audit_trail):
        """Test that checksums are generated correctly."""
        record = await audit_trail.record_change(
            tool_name="test_tool",
            change_type="update",
            ci_sys_id="ci_123",
            ci_name="Test CI",
        )

        # Verify checksum is a valid SHA-256 hash
        assert len(record["checksum"]) == 64
        assert all(c in '0123456789abcdef' for c in record["checksum"])

        # Verify checksum is deterministic
        record_copy = record.copy()
        checksum = record_copy.pop("checksum")
        record_json = json.dumps(record_copy, sort_keys=True)
        expected_checksum = hashlib.sha256(record_json.encode()).hexdigest()
        assert checksum == expected_checksum

    @pytest.mark.asyncio
    async def test_record_change_with_cr(self, audit_trail):
        """Test change recording with change request."""
        record = await audit_trail.record_change(
            tool_name="test_tool",
            change_type="update",
            ci_sys_id="ci_123",
            ci_name="Test CI",
            change_request_id="CHG0001234",
        )

        assert record["change_request"] == "CHG0001234"

    def test_get_field_diffs_basic(self, audit_trail):
        """Test field diff calculation."""
        before = {"name": "Old Name", "environment": "dev"}
        after = {"name": "New Name", "environment": "dev"}

        diffs = audit_trail.get_field_diffs(before, after)

        assert len(diffs) == 1
        assert diffs[0]["field"] == "name"
        assert diffs[0]["old_value"] == "Old Name"
        assert diffs[0]["new_value"] == "New Name"
        assert diffs[0]["change_type"] == "modified"

    def test_get_field_diffs_added(self, audit_trail):
        """Test field diff for added fields."""
        before = {"name": "Test"}
        after = {"name": "Test", "environment": "prod"}

        diffs = audit_trail.get_field_diffs(before, after)

        assert len(diffs) == 1
        assert diffs[0]["field"] == "environment"
        assert diffs[0]["old_value"] is None
        assert diffs[0]["new_value"] == "prod"
        assert diffs[0]["change_type"] == "added"

    def test_get_field_diffs_removed(self, audit_trail):
        """Test field diff for removed fields."""
        before = {"name": "Test", "environment": "prod"}
        after = {"name": "Test"}

        diffs = audit_trail.get_field_diffs(before, after)

        assert len(diffs) == 1
        assert diffs[0]["field"] == "environment"
        assert diffs[0]["old_value"] == "prod"
        assert diffs[0]["new_value"] is None
        assert diffs[0]["change_type"] == "removed"

    def test_get_field_diffs_skip_system_fields(self, audit_trail):
        """Test that system fields are skipped."""
        before = {"name": "Test", "sys_id": "123", "sys_created_on": "2024-01-01"}
        after = {"name": "New", "sys_id": "123", "sys_created_on": "2024-01-02"}

        diffs = audit_trail.get_field_diffs(before, after)

        # Only name should be in diffs, sys_ fields should be skipped
        assert len(diffs) == 1
        assert diffs[0]["field"] == "name"

    def test_get_field_diffs_tracked_fields_only(self, audit_trail):
        """Test tracking specific fields only."""
        before = {"name": "Test", "environment": "dev", "location": "US"}
        after = {"name": "New", "environment": "prod", "location": "EU"}

        diffs = audit_trail.get_field_diffs(
            before, after, tracked_fields=["name", "environment"]
        )

        # Only name and environment should be tracked
        assert len(diffs) == 2
        field_names = [d["field"] for d in diffs]
        assert "name" in field_names
        assert "environment" in field_names
        assert "location" not in field_names

    @pytest.mark.asyncio
    async def test_risk_level_setting(self, audit_trail):
        """Test different risk levels."""
        for risk_level in ["low", "medium", "high", "critical"]:
            record = await audit_trail.record_change(
                tool_name="test_tool",
                change_type="update",
                ci_sys_id="ci_123",
                ci_name="Test CI",
                risk_level=risk_level,
            )
            assert record["risk_level"] == risk_level

    @pytest.mark.asyncio
    async def test_change_types(self, audit_trail):
        """Test different change types."""
        change_types = ["merge", "update", "delete", "create", "retire"]
        for change_type in change_types:
            record = await audit_trail.record_change(
                tool_name="test_tool",
                change_type=change_type,
                ci_sys_id="ci_123",
                ci_name="Test CI",
            )
            assert record["change_type"] == change_type
