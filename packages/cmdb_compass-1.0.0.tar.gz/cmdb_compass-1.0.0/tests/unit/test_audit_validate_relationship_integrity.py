"""
Unit tests for audit_validate_relationship_integrity (Phase 3 Week 2 Tool #3)
"""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timezone
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import audit_validate_relationship_integrity


@pytest.fixture
def mock_client():
    """Create a mock ServiceNow client."""
    client = Mock()
    client.get_table_records = AsyncMock()
    
    # Create async iterator for paginate method  
    async def mock_paginate(*args, **kwargs):
        # Properly trigger the mock to handle side_effect (exceptions)
        try:
            # This will trigger side_effect if set, or return return_value
            result = await client.get_table_records(*args, **kwargs)
            if result and "result" in result:
                yield result["result"]
            else:
                yield []
        except Exception:
            # Re-raise exceptions (like database errors) for proper error handling
            raise
    
    client.paginate = mock_paginate
    return client


@pytest.fixture
def mock_csdm_rules():
    """Mock CSDM rules with valid relationship types."""
    return {
        "relationship_types": [
            {"name": "Runs on::Runs"},
            {"name": "Contains::Contained by"},
            {"name": "Uses::Used by"},
            {"name": "Depends on::Depended on by"},
        ]
    }


class TestAuditValidateRelationshipIntegrity:
    """Test audit_validate_relationship_integrity functionality."""

    @pytest.mark.asyncio
    async def test_basic_validation_no_violations(self, mock_client, mock_csdm_rules):
        """Test basic relationship validation with no violations."""
        # Mock relationships response
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "rel1",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "Runs on::Runs"},
                },
                {
                    "sys_id": "rel2",
                    "parent": {"value": "ci2"},
                    "child": {"value": "ci3"},
                    "type": {"display_value": "Contains::Contained by"},
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci1", "ci2", "ci3"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        assert result["status"] == "success"
        assert result["total_relationships"] == 2
        assert result["relationship_health_score"] >= 95.0
        assert result["violation_summary"]["orphaned_count"] == 0

    @pytest.mark.asyncio
    async def test_orphaned_relationship_detection(self, mock_client, mock_csdm_rules):
        """Test detection of orphaned relationships."""
        # Mock relationships with orphaned parent
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "rel1",
                    "parent": {"value": "missing_ci"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "Runs on::Runs"},
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci2"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        assert result["status"] == "success"
        assert result["violation_summary"]["orphaned_count"] == 1
        assert result["relationship_health_score"] < 100.0
        assert len(result["orphaned_relationships"]) > 0
        assert "parent CI missing_ci missing" in result["orphaned_relationships"][0]["reason"]

    @pytest.mark.asyncio
    async def test_invalid_relationship_type_detection(self, mock_client, mock_csdm_rules):
        """Test detection of invalid relationship types."""
        # Mock relationships with invalid type
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "rel1",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "InvalidType"},
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci1", "ci2"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        assert result["status"] == "success"
        assert result["violation_summary"]["invalid_type_count"] == 1
        assert "InvalidType" in result["invalid_types"]
        assert result["relationship_health_score"] < 100.0

    @pytest.mark.asyncio
    async def test_missing_relationship_type_detection(self, mock_client, mock_csdm_rules):
        """Test detection of relationships without types."""
        # Mock relationships with no type
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "rel1",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci2"},
                    "type": None,
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci1", "ci2"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        assert result["status"] == "success"
        assert result["violation_summary"]["missing_type_count"] == 1
        assert len(result["missing_type_relationships"]) > 0

    @pytest.mark.asyncio
    async def test_no_relationships_found(self, mock_client, mock_csdm_rules):
        """Test handling when no relationships exist."""
        mock_client.get_table_records.return_value = {
            "result": []
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            result = await audit_validate_relationship_integrity(
                client=mock_client,
                audit_level="quick",
                check_circular=False,
            )

        assert result["status"] == "success"
        assert result["total_relationships"] == 0
        assert result["relationship_health_score"] == 100.0

    @pytest.mark.asyncio
    async def test_audit_levels(self, mock_client, mock_csdm_rules):
        """Test different audit levels return appropriate data."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": f"rel{i}",
                    "parent": {"value": f"ci{i}"},
                    "child": {"value": f"ci{i+1}"},
                    "type": {"display_value": "Runs on::Runs"},
                }
                for i in range(100)
            ]
        }

        existing_cis = {f"ci{i}" for i in range(101)}

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value=existing_cis):
                # Quick level
                result_quick = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="quick",
                    check_circular=False,
                )

                # Standard level
                result_standard = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

                # Deep level
                result_deep = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="deep",
                    check_circular=False,
                )

        # Quick should have no details
        assert len(result_quick["orphaned_relationships"]) == 0

        # Standard should have sample
        assert len(result_standard["orphaned_relationships"]) <= 50

        # Deep should have all (but there are none in this test)
        assert result_deep["total_relationships"] == 100

    @pytest.mark.asyncio
    async def test_health_score_calculation(self, mock_client, mock_csdm_rules):
        """Test health score calculation with multiple violation types."""
        # Create mix of violations
        mock_client.get_table_records.return_value = {
            "result": [
                # 1 orphaned
                {
                    "sys_id": "rel1",
                    "parent": {"value": "missing_ci"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "Runs on::Runs"},
                },
                # 1 invalid type
                {
                    "sys_id": "rel2",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "BadType"},
                },
                # 1 missing type
                {
                    "sys_id": "rel3",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci3"},
                    "type": None,
                },
                # 2 healthy
                {
                    "sys_id": "rel4",
                    "parent": {"value": "ci1"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "Runs on::Runs"},
                },
                {
                    "sys_id": "rel5",
                    "parent": {"value": "ci2"},
                    "child": {"value": "ci3"},
                    "type": {"display_value": "Contains::Contained by"},
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci1", "ci2", "ci3"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        # Should have penalties for violations
        assert result["relationship_health_score"] < 100.0
        assert result["relationship_health_score"] > 50.0  # But not terrible
        assert result["violation_summary"]["orphaned_count"] == 1
        assert result["violation_summary"]["invalid_type_count"] == 1
        assert result["violation_summary"]["missing_type_count"] == 1

    @pytest.mark.asyncio
    async def test_recommendations_generated(self, mock_client, mock_csdm_rules):
        """Test that recommendations are generated for violations."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "rel1",
                    "parent": {"value": "missing_ci"},
                    "child": {"value": "ci2"},
                    "type": {"display_value": "Runs on::Runs"},
                },
            ]
        }

        with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity.get_csdm_rules', return_value=mock_csdm_rules):
            with patch('servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity._check_cis_exist', return_value={"ci2"}):
                result = await audit_validate_relationship_integrity(
                    client=mock_client,
                    audit_level="standard",
                    check_circular=False,
                )

        assert "recommendations" in result
        assert len(result["recommendations"]) > 0
        assert any("action_auto_heal_relationship_issues" in rec.get("action", "") for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_error_handling(self, mock_client):
        """Test error handling when validation fails."""
        mock_client.get_table_records.side_effect = Exception("Database error")

        result = await audit_validate_relationship_integrity(
            client=mock_client,
            audit_level="standard",
            check_circular=False,
        )

        assert result["status"] == "error"
        assert "error" in result
