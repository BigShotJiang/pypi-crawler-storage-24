"""
Unit tests for CMDB Precheck Validation
"""

import pytest
from unittest.mock import Mock, AsyncMock
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.action.precheck import CmdbChangePrecheck


class TestCmdbChangePrecheck:
    """Test CMDB Change Precheck functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.fixture
    def precheck(self, mock_client):
        """Create a precheck instance."""
        return CmdbChangePrecheck(mock_client)

    @pytest.mark.asyncio
    async def test_validate_change_ci_exists(self, precheck, mock_client):
        """Test validation when CI exists and is active."""
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=False,
        )

        assert is_valid is True
        assert report["is_valid"] is True
        assert len(report["errors"]) == 0
        assert report["cis_checked"] == 1
        assert report["checks_passed"]["existence"] is True

    @pytest.mark.asyncio
    async def test_validate_change_ci_not_found(self, precheck, mock_client):
        """Test validation when CI does not exist."""
        mock_client.get_table_records.return_value = {"result": []}

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=False,
        )

        assert is_valid is False
        assert report["is_valid"] is False
        assert len(report["errors"]) > 0
        assert "CI ci_123 not found" in report["errors"]
        assert report["checks_passed"]["existence"] is False

    @pytest.mark.asyncio
    async def test_validate_change_ci_inactive(self, precheck, mock_client):
        """Test validation when CI is inactive."""
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_123", "name": "Test CI", "active": "false"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=False,
        )

        # Should still be valid, but with a warning
        assert is_valid is True
        assert len(report["warnings"]) > 0
        assert "CI ci_123 is inactive" in report["warnings"]

    @pytest.mark.asyncio
    async def test_validate_change_cr_required_missing(self, precheck, mock_client):
        """Test validation when CR is required but not provided."""
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=True,
            change_request_id=None,
        )

        assert is_valid is False
        assert "Change Request required but not provided" in report["errors"]

    @pytest.mark.asyncio
    async def test_validate_change_cr_approved(self, precheck, mock_client):
        """Test validation when CR is approved."""
        # First call for CI check
        # Second call for CR check
        mock_client.get_table_records.side_effect = [
            {"result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]},
            {"result": [{"sys_id": "CHG123", "approval": "approved", "state": "scheduled"}]},
        ]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=True,
            change_request_id="CHG123",
        )

        assert is_valid is True
        assert report["checks_passed"]["cr_approval"] is True

    @pytest.mark.asyncio
    async def test_validate_change_cr_not_approved(self, precheck, mock_client):
        """Test validation when CR is not approved."""
        mock_client.get_table_records.side_effect = [
            {"result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]},
            {"result": [{"sys_id": "CHG123", "approval": "pending", "state": "new"}]},
        ]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=True,
            change_request_id="CHG123",
        )

        assert is_valid is False
        assert any("not approved" in err for err in report["errors"])

    @pytest.mark.asyncio
    async def test_validate_change_cr_closed(self, precheck, mock_client):
        """Test validation when CR is closed."""
        mock_client.get_table_records.side_effect = [
            {"result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]},
            {"result": [{"sys_id": "CHG123", "approval": "approved", "state": "closed"}]},
        ]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=True,
            change_request_id="CHG123",
        )

        assert is_valid is False
        assert any("closed" in err for err in report["errors"])

    @pytest.mark.asyncio
    async def test_validate_change_rate_limit_exceeded(self, precheck, mock_client):
        """Test validation when too many CIs are provided."""
        ci_sys_ids = [f"ci_{i}" for i in range(1001)]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=ci_sys_ids,
            require_cr=False,
            check_locks=False,
            check_criticality=False,
        )

        assert is_valid is False
        assert any("Too many CIs" in err for err in report["errors"])
        assert report["checks_passed"]["rate_limit"] is False

    @pytest.mark.asyncio
    async def test_validate_change_large_batch_warning(self, precheck, mock_client):
        """Test warning for large batch updates."""
        ci_sys_ids = [f"ci_{i}" for i in range(101)]

        # Mock successful CI existence checks
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_1", "name": "Test CI", "active": "true"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=ci_sys_ids,
            require_cr=False,
            check_locks=True,
        )

        # Should still be valid but with warning
        assert is_valid is True
        assert any("Large batch update" in warn for warn in report["warnings"])

    @pytest.mark.asyncio
    async def test_validate_change_business_criticality(self, precheck, mock_client):
        """Test business criticality check."""
        mock_client.get_table_records.side_effect = [
            {"result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]},
            {"result": [{"sys_id": "ci_123", "name": "Critical Server", "business_criticality": "1"}]},
        ]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=False,
            check_criticality=True,
        )

        # Should be valid but with criticality warning
        assert is_valid is True
        assert any("business-critical" in warn for warn in report["warnings"])

    @pytest.mark.asyncio
    async def test_validate_single_ci_convenience(self, precheck, mock_client):
        """Test the convenience method for single CI validation."""
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]
        }

        is_valid, report = await precheck.validate_single_ci(
            ci_sys_id="ci_123",
            require_cr=False,
        )

        assert is_valid is True
        assert report["cis_checked"] == 1

    @pytest.mark.asyncio
    async def test_validate_change_multiple_cis(self, precheck, mock_client):
        """Test validation with multiple CIs."""
        # All CIs exist
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_1", "name": "Test CI 1", "active": "true"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_1", "ci_2", "ci_3"],
            require_cr=False,
        )

        assert report["cis_checked"] == 3

    @pytest.mark.asyncio
    async def test_validate_change_cr_not_found(self, precheck, mock_client):
        """Test validation when CR does not exist."""
        mock_client.get_table_records.side_effect = [
            {"result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]},
            {"result": []},  # CR not found
        ]

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=True,
            change_request_id="CHG123",
        )

        assert is_valid is False
        assert any("Change Request CHG123 not found" in err for err in report["errors"])

    @pytest.mark.asyncio
    async def test_validate_change_skip_checks(self, precheck, mock_client):
        """Test skipping optional checks."""
        mock_client.get_table_records.return_value = {
            "result": [{"sys_id": "ci_123", "name": "Test CI", "active": "true"}]
        }

        is_valid, report = await precheck.validate_change(
            ci_sys_ids=["ci_123"],
            require_cr=False,
            check_locks=False,
            check_criticality=False,
        )

        assert is_valid is True
        # No criticality warnings since check was skipped
        assert "criticality" not in str(report["warnings"]).lower()
