"""Error path tests for top tools.

Tests graceful handling of:
- API exceptions (connection errors, timeouts)
- Empty CMDB (0 records)
- Malformed API responses (missing keys, None values, wrong types)
- Bad parameters
"""

import pytest
from unittest.mock import AsyncMock, Mock


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_client(**overrides):
    """Create a mock client with sane defaults; override specific methods."""
    client = Mock()
    client.get_table_records = AsyncMock(return_value={"result": []})
    client.count_records = AsyncMock(return_value=(0, {"result": []}))
    client.query_table = AsyncMock(return_value=[])
    client.create_record = AsyncMock(return_value={"result": {}})
    client.update_record = AsyncMock(return_value={"result": {}})
    client.get_record_by_number = AsyncMock(return_value={"result": []})
    client.get_table_schema = AsyncMock(return_value={"fields": []})
    client.paginate = AsyncMock()
    for name, mock in overrides.items():
        setattr(client, name, mock)
    return client


# ═══════════════════════════════════════════════════════════════════════════
# 1. analyze_cmdb_health — main audit entry point
# ═══════════════════════════════════════════════════════════════════════════

class TestAnalyzeCmdbHealthErrors:
    @pytest.mark.asyncio
    async def test_empty_cmdb_returns_zero_scores(self):
        from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health

        client = _make_client()

        result = await analyze_cmdb_health(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="quick",
        )

        assert isinstance(result, dict)
        assert result.get("completeness", {}).get("total_cis", 0) == 0

    @pytest.mark.asyncio
    async def test_count_api_exception(self):
        """count_records failure should be handled gracefully."""
        from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health

        client = _make_client(
            count_records=AsyncMock(side_effect=Exception("Connection refused")),
        )

        result = await analyze_cmdb_health(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="quick",
        )

        assert isinstance(result, dict)
        # Should contain completeness key with 0 or error info, not crash
        completeness = result.get("completeness", {})
        assert completeness.get("total_cis", 0) == 0 or "error" in str(result).lower()

    @pytest.mark.asyncio
    async def test_malformed_get_table_response(self):
        """get_table_records returning unexpected structure."""
        from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health

        client = _make_client(
            get_table_records=AsyncMock(return_value={}),  # missing "result" key
        )

        result = await analyze_cmdb_health(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="standard",
        )

        assert isinstance(result, dict)
        # Should not crash — empty result is treated as 0 CIs

    @pytest.mark.asyncio
    async def test_none_ci_class_uses_cmdb_ci(self):
        """When ci_class is None, should query cmdb_ci base table."""
        from servicenow_mcp.tools.cmdb.audit.audit_analyze_cmdb_health import analyze_cmdb_health

        client = _make_client()

        result = await analyze_cmdb_health(
            client=client,
            ci_class=None,
            audit_level="quick",
        )

        assert isinstance(result, dict)


# ═══════════════════════════════════════════════════════════════════════════
# 2. audit_validate_relationship_integrity
# ═══════════════════════════════════════════════════════════════════════════

class TestRelationshipIntegrityErrors:
    @pytest.mark.asyncio
    async def test_empty_relationships(self):
        from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import (
            audit_validate_relationship_integrity,
        )

        async def empty_paginate(*args, **kwargs):
            return
            yield  # make it an async generator that yields nothing

        client = _make_client()
        client.paginate = empty_paginate

        result = await audit_validate_relationship_integrity(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="quick",
            check_circular=False,
        )

        assert isinstance(result, dict)
        assert result.get("total_relationships", 0) == 0

    @pytest.mark.asyncio
    async def test_paginate_api_exception(self):
        from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import (
            audit_validate_relationship_integrity,
        )

        async def failing_paginate(*args, **kwargs):
            raise Exception("Timeout reading from ServiceNow")
            yield  # make it an async generator

        client = _make_client()
        client.paginate = failing_paginate

        result = await audit_validate_relationship_integrity(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="quick",
            check_circular=False,
        )

        assert isinstance(result, dict)
        # Should handle the error — either return 0 relationships or error status
        total = result.get("total_relationships", 0)
        assert total == 0 or result.get("status") == "error"

    @pytest.mark.asyncio
    async def test_relationships_with_missing_fields(self):
        """Relationships missing parent/child sys_ids should not crash."""
        from servicenow_mcp.tools.cmdb.audit.audit_validate_relationship_integrity import (
            audit_validate_relationship_integrity,
        )

        async def paginate_with_bad_data(*args, **kwargs):
            yield [
                {"sys_id": "rel1", "parent": "", "child": "", "type": ""},
                {"sys_id": "rel2", "parent": None, "child": None, "type": None},
                {"sys_id": "rel3"},  # completely missing fields
            ]

        client = _make_client()
        client.paginate = paginate_with_bad_data

        result = await audit_validate_relationship_integrity(
            client=client,
            ci_class="cmdb_ci_server",
            audit_level="quick",
            check_circular=False,
        )

        assert isinstance(result, dict)
        assert result.get("total_relationships", 0) == 3


# ═══════════════════════════════════════════════════════════════════════════
# 3. audit_duplicate_cis
# ═══════════════════════════════════════════════════════════════════════════

class TestDuplicateCisErrors:
    @pytest.mark.asyncio
    async def test_empty_table(self):
        from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis

        client = _make_client()

        result = await audit_duplicate_cis(
            client=client,
            table_name="cmdb_ci_server",
            audit_level="quick",
        )

        assert isinstance(result, dict)
        assert result.get("total_records", 0) == 0

    @pytest.mark.asyncio
    async def test_api_exception_on_records_fetch(self):
        from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis

        client = _make_client(
            get_table_records=AsyncMock(side_effect=Exception("Table not found")),
        )

        result = await audit_duplicate_cis(
            client=client,
            table_name="nonexistent_table",
            audit_level="quick",
        )

        assert isinstance(result, dict)
        # Should handle gracefully, not crash
        assert result.get("total_records", 0) == 0

    @pytest.mark.asyncio
    async def test_records_with_empty_fields(self):
        """Records with all empty identification fields should not produce false duplicates."""
        from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis

        client = _make_client(
            get_table_records=AsyncMock(return_value={
                "result": [
                    {"sys_id": "ci1", "name": "", "serial_number": "", "asset_tag": "",
                     "mac_address": "", "host_name": "", "ip_address": "", "discovery_source": "",
                     "sys_created_on": ""},
                    {"sys_id": "ci2", "name": "", "serial_number": "", "asset_tag": "",
                     "mac_address": "", "host_name": "", "ip_address": "", "discovery_source": "",
                     "sys_created_on": ""},
                ]
            }),
        )

        result = await audit_duplicate_cis(
            client=client,
            table_name="cmdb_ci_server",
            audit_level="standard",
        )

        assert isinstance(result, dict)
        # The tool stores record count under "summary.total_records_analyzed" or similar
        assert result.get("status") == "success" or "duplicate_cis" in result

    @pytest.mark.asyncio
    async def test_records_with_dict_field_values(self):
        """ServiceNow sometimes returns dict values like {"value": "x", "display_value": "y"}."""
        from servicenow_mcp.tools.cmdb.audit.audit_duplicate_cis import audit_duplicate_cis

        client = _make_client(
            get_table_records=AsyncMock(return_value={
                "result": [
                    {"sys_id": "ci1", "name": {"value": "Server-A", "display_value": "Server-A"},
                     "serial_number": "SN001", "asset_tag": "", "mac_address": "",
                     "host_name": "", "ip_address": "", "discovery_source": "",
                     "sys_created_on": "2026-01-01"},
                ]
            }),
        )

        result = await audit_duplicate_cis(
            client=client,
            table_name="cmdb_ci_server",
            audit_level="quick",
        )

        assert isinstance(result, dict)


# ═══════════════════════════════════════════════════════════════════════════
# 4. query_table_records — foundational data access
# ═══════════════════════════════════════════════════════════════════════════

class TestQueryTableRecordsErrors:
    @pytest.mark.asyncio
    async def test_api_exception(self):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        client = _make_client(
            get_table_records=AsyncMock(side_effect=Exception("Connection timeout")),
        )

        with pytest.raises(Exception, match="Connection timeout"):
            await query_table_records(
                client=client,
                table="cmdb_ci",
                query="",
                limit=10,
            )

    @pytest.mark.asyncio
    async def test_missing_result_key(self):
        """Response without 'result' key should return empty list."""
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        client = _make_client(
            get_table_records=AsyncMock(return_value={"error": "bad request"}),
        )

        result = await query_table_records(
            client=client,
            table="cmdb_ci",
            query="",
            limit=10,
        )

        assert result == []

    @pytest.mark.asyncio
    async def test_result_is_none(self):
        """Response with result=None."""
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        client = _make_client(
            get_table_records=AsyncMock(return_value={"result": None}),
        )

        result = await query_table_records(
            client=client,
            table="cmdb_ci",
            query="",
            limit=10,
        )

        # None from .get("result", []) returns None, not []; tool should handle or propagate
        # The current implementation returns None here, which is a known limitation
        assert result is None or result == []

    @pytest.mark.asyncio
    async def test_zero_limit_raises(self):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        client = _make_client()

        with pytest.raises(ValueError, match="positive"):
            await query_table_records(client=client, table="cmdb_ci", query="", limit=0)


# ═══════════════════════════════════════════════════════════════════════════
# 5. create_incident — highest-risk write operation
# ═══════════════════════════════════════════════════════════════════════════

class TestCreateIncidentErrors:
    @pytest.mark.asyncio
    async def test_api_exception(self):
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        client = _make_client(
            create_record=AsyncMock(side_effect=Exception("403 Forbidden")),
        )

        with pytest.raises(Exception, match="403 Forbidden"):
            await create_incident(
                client=client,
                short_description="Test",
                description=None,
                urgency="3",
                impact="3",
                caller=None,
                assignment_group=None,
            )

    @pytest.mark.asyncio
    async def test_empty_response(self):
        """API returns empty result dict."""
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        client = _make_client(
            create_record=AsyncMock(return_value={"result": {}}),
        )

        result = await create_incident(
            client=client,
            short_description="Test",
            description=None,
            urgency="3",
            impact="3",
            caller=None,
            assignment_group=None,
        )

        assert isinstance(result, str)
        assert "Unknown" in result  # number and sys_id default to "Unknown"

    @pytest.mark.asyncio
    async def test_missing_result_key(self):
        """API response missing 'result' key."""
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        client = _make_client(
            create_record=AsyncMock(return_value={}),
        )

        result = await create_incident(
            client=client,
            short_description="Test",
            description=None,
            urgency="3",
            impact="3",
            caller=None,
            assignment_group=None,
        )

        assert isinstance(result, str)
        assert "Unknown" in result


# ═══════════════════════════════════════════════════════════════════════════
# 6. update_incident — error paths
# ═══════════════════════════════════════════════════════════════════════════

class TestUpdateIncidentErrors:
    @pytest.mark.asyncio
    async def test_get_record_api_failure(self):
        """get_record_by_number raises — should return error string."""
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        client = _make_client(
            get_record_by_number=AsyncMock(side_effect=Exception("Connection reset")),
        )

        result = await update_incident(
            client=client,
            incident_number="INC001",
            state="2",
            priority=None,
            assigned_to=None,
            work_notes=None,
        )

        assert isinstance(result, str)
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_update_api_failure(self):
        """update_record raises after incident is found."""
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        client = _make_client(
            get_record_by_number=AsyncMock(return_value={
                "result": [{"sys_id": "abc123"}]
            }),
            update_record=AsyncMock(side_effect=Exception("Write permission denied")),
        )

        result = await update_incident(
            client=client,
            incident_number="INC001",
            state="2",
            priority=None,
            assigned_to=None,
            work_notes=None,
        )

        assert isinstance(result, str)
        assert "Error" in result


# ═══════════════════════════════════════════════════════════════════════════
# 7. Timeout behavior (httpx.TimeoutException simulation)
# ═══════════════════════════════════════════════════════════════════════════

class TestTimeoutBehavior:
    @pytest.mark.asyncio
    async def test_query_timeout(self):
        """Simulate httpx timeout on query_table_records."""
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        try:
            from httpx import TimeoutException
        except ImportError:
            TimeoutException = TimeoutError

        client = _make_client(
            get_table_records=AsyncMock(side_effect=TimeoutException("Read timed out")),
        )

        with pytest.raises((TimeoutException, TimeoutError)):
            await query_table_records(
                client=client,
                table="cmdb_ci",
                query="",
                limit=10,
            )

    @pytest.mark.asyncio
    async def test_count_timeout(self):
        """Simulate timeout on count_table_records."""
        from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records

        try:
            from httpx import TimeoutException
        except ImportError:
            TimeoutException = TimeoutError

        client = _make_client(
            count_records=AsyncMock(side_effect=TimeoutException("Read timed out")),
        )

        with pytest.raises((TimeoutException, TimeoutError)):
            await count_table_records(
                client=client,
                table="cmdb_ci",
                query="",
            )

    @pytest.mark.asyncio
    async def test_search_incidents_timeout(self):
        """Timeout on search_incidents should return error string."""
        from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents

        try:
            from httpx import TimeoutException
        except ImportError:
            TimeoutException = TimeoutError

        client = _make_client(
            query_table=AsyncMock(side_effect=TimeoutException("Read timed out")),
        )

        result = await search_incidents(
            client=client,
            query="test",
            priority=None,
            state=None,
            assigned_to=None,
            limit=10,
        )

        assert isinstance(result, str)
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_get_table_description_timeout(self):
        """Timeout on get_table_description should return error string."""
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        try:
            from httpx import TimeoutException
        except ImportError:
            TimeoutException = TimeoutError

        client = _make_client(
            get_table_schema=AsyncMock(side_effect=TimeoutException("Read timed out")),
        )

        result = await get_table_description(client=client, table_name="incident")

        assert isinstance(result, str)
        assert "Error" in result


# ═══════════════════════════════════════════════════════════════════════════
# 8. get_table_description — edge cases
# ═══════════════════════════════════════════════════════════════════════════

class TestGetTableDescriptionEdgeCases:
    @pytest.mark.asyncio
    async def test_schema_returns_none(self):
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        client = _make_client(
            get_table_schema=AsyncMock(return_value=None),
        )

        result = await get_table_description(client=client, table_name="bad_table")

        assert isinstance(result, str)
        assert "No schema" in result or "Error" in result

    @pytest.mark.asyncio
    async def test_fields_with_missing_keys(self):
        """Fields missing name/label/type should not crash."""
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        client = _make_client(
            get_table_schema=AsyncMock(return_value={
                "fields": [
                    {},  # completely empty field
                    {"name": "state"},  # missing label and type
                ]
            }),
        )

        result = await get_table_description(client=client, table_name="incident")

        assert isinstance(result, str)
        assert "incident" in result


# ═══════════════════════════════════════════════════════════════════════════
# 9. list_tables_and_fields — edge cases
# ═══════════════════════════════════════════════════════════════════════════

class TestListTablesEdgeCases:
    @pytest.mark.asyncio
    async def test_table_record_missing_name(self):
        """Table records without 'name' key should be skipped."""
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        client = _make_client(
            get_table_records=AsyncMock(return_value={
                "result": [
                    {"label": "Orphan Table"},  # missing "name"
                ]
            }),
        )

        result = await list_tables_and_fields(client=client, pattern="orphan")

        assert result == {"tables": {}}

    @pytest.mark.asyncio
    async def test_api_exception(self):
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        client = _make_client(
            get_table_records=AsyncMock(side_effect=Exception("ACL denied")),
        )

        with pytest.raises(Exception, match="ACL denied"):
            await list_tables_and_fields(client=client, pattern="cmdb")
