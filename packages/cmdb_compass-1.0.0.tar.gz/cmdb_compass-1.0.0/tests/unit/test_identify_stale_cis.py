"""
Unit tests for Identify Stale CIs tool
"""

import pytest
from unittest.mock import Mock, AsyncMock
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.audit.audit_identify_stale_cis import identify_stale_cis


class TestIdentifyStaleCis:
    """Test identify_stale_cis functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_identify_stale_cis_basic(self, mock_client):
        """Test basic stale CI identification."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()
        stale = (now - timedelta(days=120)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_fresh",
                    "name": "FreshServer",
                    "operational_status": "1",
                    "sys_updated_on": recent,
                    "last_discovered": recent,
                },
                {
                    "sys_id": "ci_stale",
                    "name": "StaleServer",
                    "operational_status": "1",
                    "sys_updated_on": stale,
                    "last_discovered": stale,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["ci_class"] == "cmdb_ci_server"
        assert result["total_cis"] == 2
        assert result["stale_count"] == 1
        assert result["fresh_count"] == 1
        assert result["staleness_threshold_days"] == 90
        assert result["stale_percentage"] == 50.0
        assert result["fresh_percentage"] == 50.0
        assert len(result["recommendations"]) > 0

    @pytest.mark.asyncio
    async def test_identify_stale_cis_no_cis(self, mock_client):
        """Test with no CIs found."""
        mock_client.get_table_records.return_value = {"result": []}

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 0
        assert result["stale_count"] == 0
        assert result["fresh_count"] == 0
        assert "No active CIs found" in result["message"]

    @pytest.mark.asyncio
    async def test_identify_stale_cis_all_stale(self, mock_client):
        """Test when all CIs are stale."""
        now = datetime.now(timezone.utc)
        stale1 = (now - timedelta(days=100)).isoformat()
        stale2 = (now - timedelta(days=120)).isoformat()
        stale3 = (now - timedelta(days=200)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "operational_status": "1",
                    "sys_updated_on": stale1,
                    "last_discovered": stale1,
                },
                {
                    "sys_id": "ci_2",
                    "name": "Server2",
                    "operational_status": "1",
                    "sys_updated_on": stale2,
                    "last_discovered": stale2,
                },
                {
                    "sys_id": "ci_3",
                    "name": "Server3",
                    "operational_status": "1",
                    "sys_updated_on": stale3,
                    "last_discovered": stale3,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["stale_count"] == 3
        assert result["fresh_count"] == 0
        assert result["stale_percentage"] == 100.0
        assert "CRITICAL" in result["recommendations"][0] or "WARNING" in result["recommendations"][0]

    @pytest.mark.asyncio
    async def test_identify_stale_cis_all_fresh(self, mock_client):
        """Test when all CIs are fresh."""
        now = datetime.now(timezone.utc)
        recent1 = (now - timedelta(days=5)).isoformat()
        recent2 = (now - timedelta(days=10)).isoformat()
        recent3 = (now - timedelta(days=20)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "operational_status": "1",
                    "sys_updated_on": recent1,
                    "last_discovered": recent1,
                },
                {
                    "sys_id": "ci_2",
                    "name": "Server2",
                    "operational_status": "1",
                    "sys_updated_on": recent2,
                    "last_discovered": recent2,
                },
                {
                    "sys_id": "ci_3",
                    "name": "Server3",
                    "operational_status": "1",
                    "sys_updated_on": recent3,
                    "last_discovered": recent3,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["stale_count"] == 0
        assert result["fresh_count"] == 3
        assert result["stale_percentage"] == 0.0
        assert result["fresh_percentage"] == 100.0
        assert "Excellent" in result["recommendations"][0]

    @pytest.mark.asyncio
    async def test_identify_stale_cis_custom_threshold(self, mock_client):
        """Test with custom staleness threshold."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()
        threshold_edge = (now - timedelta(days=35)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_fresh",
                    "name": "FreshServer",
                    "operational_status": "1",
                    "sys_updated_on": recent,
                    "last_discovered": recent,
                },
                {
                    "sys_id": "ci_stale",
                    "name": "StaleServer",
                    "operational_status": "1",
                    "sys_updated_on": threshold_edge,
                    "last_discovered": threshold_edge,
                },
            ]
        }

        # With 30-day threshold, the 35-day CI should be stale
        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=30,
        )

        assert result["status"] == "success"
        assert result["staleness_threshold_days"] == 30
        assert result["stale_count"] == 1
        assert result["fresh_count"] == 1

    @pytest.mark.asyncio
    async def test_identify_stale_cis_mixed_distribution(self, mock_client):
        """Test staleness distribution across all age buckets."""
        now = datetime.now(timezone.utc)
        fresh = (now - timedelta(days=10)).isoformat()
        moderate = (now - timedelta(days=45)).isoformat()
        aging = (now - timedelta(days=75)).isoformat()
        stale = (now - timedelta(days=120)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_fresh",
                    "name": "FreshServer",
                    "operational_status": "1",
                    "sys_updated_on": fresh,
                    "last_discovered": fresh,
                },
                {
                    "sys_id": "ci_moderate",
                    "name": "ModerateServer",
                    "operational_status": "1",
                    "sys_updated_on": moderate,
                    "last_discovered": moderate,
                },
                {
                    "sys_id": "ci_aging",
                    "name": "AgingServer",
                    "operational_status": "1",
                    "sys_updated_on": aging,
                    "last_discovered": aging,
                },
                {
                    "sys_id": "ci_stale",
                    "name": "StaleServer",
                    "operational_status": "1",
                    "sys_updated_on": stale,
                    "last_discovered": stale,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 4
        assert result["stale_count"] == 1
        assert result["fresh_count"] == 1
        assert result["staleness_distribution"]["0-30d (fresh)"] == 1
        assert result["staleness_distribution"]["30-60d (moderate)"] == 1
        assert result["staleness_distribution"]["60-90d (aging)"] == 1
        assert result["staleness_distribution"]["90d+ (stale, >90d)"] == 1

    @pytest.mark.asyncio
    async def test_identify_stale_cis_timezone_handling(self, mock_client):
        """Test timezone-robust timestamp parsing."""
        now = datetime.now(timezone.utc)

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_iso_z",
                    "name": "ServerISOZ",
                    "operational_status": "1",
                    "sys_updated_on": (now - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "last_discovered": None,
                },
                {
                    "sys_id": "ci_sn_format",
                    "name": "ServerSN",
                    "operational_status": "1",
                    "sys_updated_on": (now - timedelta(days=15)).strftime("%Y-%m-%d %H:%M:%S"),
                    "last_discovered": None,
                },
                {
                    "sys_id": "ci_iso_offset",
                    "name": "ServerISOOffset",
                    "operational_status": "1",
                    "sys_updated_on": (now - timedelta(days=20)).isoformat(),
                    "last_discovered": None,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 3
        assert result["fresh_count"] == 3  # All timestamps parsed successfully
        assert result["stale_count"] == 0

    @pytest.mark.asyncio
    async def test_identify_stale_cis_missing_timestamps(self, mock_client):
        """Test handling of CIs with missing timestamps."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_with_timestamp",
                    "name": "ServerWithTimestamp",
                    "operational_status": "1",
                    "sys_updated_on": recent,
                    "last_discovered": recent,
                },
                {
                    "sys_id": "ci_no_timestamp",
                    "name": "ServerNoTimestamp",
                    "operational_status": "1",
                    "sys_updated_on": None,
                    "last_discovered": None,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 2
        assert result["fresh_count"] == 1
        assert result["staleness_distribution"]["unknown"] == 1

    @pytest.mark.asyncio
    async def test_identify_stale_cis_include_details(self, mock_client):
        """Test including detailed CI lists."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()
        stale = (now - timedelta(days=120)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_fresh",
                    "name": "FreshServer",
                    "operational_status": "1",
                    "sys_updated_on": recent,
                    "last_discovered": recent,
                },
                {
                    "sys_id": "ci_stale",
                    "name": "StaleServer",
                    "operational_status": "1",
                    "sys_updated_on": stale,
                    "last_discovered": stale,
                },
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
            include_details=True,
        )

        assert result["status"] == "success"
        assert "stale_cis" in result
        assert "fresh_cis" in result
        assert len(result["stale_cis"]) == 1
        assert len(result["fresh_cis"]) == 1
        assert result["stale_cis"][0]["sys_id"] == "ci_stale"
        assert result["fresh_cis"][0]["sys_id"] == "ci_fresh"
        assert "days_since_activity" in result["stale_cis"][0]

    @pytest.mark.asyncio
    async def test_identify_stale_cis_exclude_details(self, mock_client):
        """Test excluding detailed CI lists."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "operational_status": "1",
                    "sys_updated_on": recent,
                    "last_discovered": recent,
                }
            ]
        }

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
            include_details=False,
        )

        assert result["status"] == "success"
        assert "stale_cis" not in result
        assert "fresh_cis" not in result

    @pytest.mark.asyncio
    async def test_identify_stale_cis_high_staleness_recommendations(self, mock_client):
        """Test recommendations for high staleness (>50%)."""
        now = datetime.now(timezone.utc)
        stale = (now - timedelta(days=120)).isoformat()

        # Create 6 stale CIs and 4 fresh CIs (60% stale)
        cis = []
        for i in range(6):
            cis.append({
                "sys_id": f"ci_stale_{i}",
                "name": f"StaleServer{i}",
                "operational_status": "1",
                "sys_updated_on": stale,
                "last_discovered": stale,
            })

        recent = (now - timedelta(days=10)).isoformat()
        for i in range(4):
            cis.append({
                "sys_id": f"ci_fresh_{i}",
                "name": f"FreshServer{i}",
                "operational_status": "1",
                "sys_updated_on": recent,
                "last_discovered": recent,
            })

        mock_client.get_table_records.return_value = {"result": cis}

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
            staleness_threshold_days=90,
        )

        assert result["status"] == "success"
        assert result["stale_percentage"] == 60.0
        assert "CRITICAL" in result["recommendations"][0]
        assert "Discovery" in result["recommendations"][1]

    @pytest.mark.asyncio
    async def test_identify_stale_cis_error_handling(self, mock_client):
        """Test error handling."""
        mock_client.get_table_records.side_effect = Exception("API Error")

        result = await identify_stale_cis(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "error"
        assert "API Error" in result["error"]
