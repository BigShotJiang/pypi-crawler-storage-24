"""Unit tests for Data Access tools.

Covers 4 data access tools: query_table_records, list_tables_and_fields,
get_table_description, and count_table_records.
"""

import pytest
from unittest.mock import AsyncMock, Mock


class TestQueryTableRecords:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_basic_query(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        mock_client.get_table_records.return_value = {
            "result": [
                {"sys_id": "abc1", "name": "Server A"},
                {"sys_id": "abc2", "name": "Server B"},
            ]
        }

        result = await query_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="",
            fields=None,
            limit=100,
        )

        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["name"] == "Server A"

    @pytest.mark.asyncio
    async def test_with_query_filter(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        mock_client.get_table_records.return_value = {"result": [{"sys_id": "abc1", "name": "Prod Server"}]}

        result = await query_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="nameLIKEProd",
            fields=None,
            limit=50,
        )

        assert len(result) == 1
        call_args = mock_client.get_table_records.call_args
        assert call_args.kwargs.get("sysparm_query") == "nameLIKEProd"

    @pytest.mark.asyncio
    async def test_with_specific_fields(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        mock_client.get_table_records.return_value = {"result": [{"name": "Server A"}]}

        await query_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="",
            fields=["name", "ip_address"],
            limit=10,
        )

        call_args = mock_client.get_table_records.call_args
        assert call_args.kwargs.get("sysparm_fields") == "name,ip_address"

    @pytest.mark.asyncio
    async def test_empty_results(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        mock_client.get_table_records.return_value = {"result": []}

        result = await query_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="name=nonexistent",
            limit=100,
        )

        assert result == []

    @pytest.mark.asyncio
    async def test_invalid_limit_raises(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        with pytest.raises(ValueError, match="positive"):
            await query_table_records(
                client=mock_client,
                table="cmdb_ci_server",
                query="",
                limit=0,
            )

    @pytest.mark.asyncio
    async def test_negative_limit_raises(self, mock_client):
        from servicenow_mcp.tools.data_access.query_table_records import query_table_records

        with pytest.raises(ValueError, match="positive"):
            await query_table_records(
                client=mock_client,
                table="cmdb_ci_server",
                query="",
                limit=-5,
            )


class TestListTablesAndFields:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_list_tables(self, mock_client):
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        # First call: sys_db_object for table names
        # Second call: sys_dictionary for fields of that table
        mock_client.get_table_records.side_effect = [
            {"result": [{"name": "incident", "label": "Incident"}]},
            {"result": [
                {"name": "number", "label": "Number", "type": "string"},
                {"name": "state", "label": "State", "type": "integer"},
            ]},
        ]

        result = await list_tables_and_fields(client=mock_client, pattern="incident")

        assert "tables" in result
        assert "incident" in result["tables"]
        assert len(result["tables"]["incident"]["fields"]) == 2

    @pytest.mark.asyncio
    async def test_no_tables_found(self, mock_client):
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        mock_client.get_table_records.return_value = {"result": []}

        result = await list_tables_and_fields(client=mock_client, pattern="nonexistent")

        assert result == {"tables": {}}

    @pytest.mark.asyncio
    async def test_pattern_builds_query(self, mock_client):
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        mock_client.get_table_records.return_value = {"result": []}

        await list_tables_and_fields(client=mock_client, pattern="cmdb")

        call_args = mock_client.get_table_records.call_args
        assert "cmdb" in (call_args.kwargs.get("sysparm_query") or "")

    @pytest.mark.asyncio
    async def test_no_pattern(self, mock_client):
        from servicenow_mcp.tools.data_access.list_tables_and_fields import list_tables_and_fields

        mock_client.get_table_records.return_value = {"result": []}

        await list_tables_and_fields(client=mock_client, pattern=None)

        call_args = mock_client.get_table_records.call_args
        query = call_args.kwargs.get("sysparm_query") or ""
        assert query == ""


class TestGetTableDescription:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.get_table_schema = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_basic_schema(self, mock_client):
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        mock_client.get_table_schema.return_value = {
            "fields": [
                {"name": "number", "label": "Number", "type": "string", "mandatory": True},
                {"name": "state", "label": "State", "type": "integer", "mandatory": False},
            ]
        }

        result = await get_table_description(client=mock_client, table_name="incident")

        assert isinstance(result, str)
        assert "incident" in result
        assert "number" in result
        assert "Number" in result
        assert "Required:** Yes" in result

    @pytest.mark.asyncio
    async def test_empty_schema(self, mock_client):
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        mock_client.get_table_schema.return_value = {"fields": []}

        result = await get_table_description(client=mock_client, table_name="unknown_table")

        assert "No schema information found" in result

    @pytest.mark.asyncio
    async def test_more_than_20_fields_truncated(self, mock_client):
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        fields = [
            {"name": f"field_{i}", "label": f"Field {i}", "type": "string", "mandatory": False}
            for i in range(30)
        ]
        mock_client.get_table_schema.return_value = {"fields": fields}

        result = await get_table_description(client=mock_client, table_name="big_table")

        assert "Showing 20 of 30 fields" in result
        assert "10 more fields" in result

    @pytest.mark.asyncio
    async def test_schema_as_list(self, mock_client):
        """get_table_schema may return a list directly instead of a dict with 'fields' key."""
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        mock_client.get_table_schema.return_value = [
            {"element": "number", "column_label": "Number", "internal_type": "string"},
        ]

        result = await get_table_description(client=mock_client, table_name="incident")

        assert "number" in result
        assert "Number" in result

    @pytest.mark.asyncio
    async def test_error_handling(self, mock_client):
        from servicenow_mcp.tools.data_access.get_table_description import get_table_description

        mock_client.get_table_schema.side_effect = Exception("Connection refused")

        result = await get_table_description(client=mock_client, table_name="incident")

        assert "Error" in result
        assert "Connection refused" in result


class TestCountTableRecords:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.count_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_basic_count(self, mock_client):
        from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records

        mock_client.count_records.return_value = (42, {"result": []})

        result = await count_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="",
        )

        assert result == 42

    @pytest.mark.asyncio
    async def test_count_with_query(self, mock_client):
        from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records

        mock_client.count_records.return_value = (5, {"result": []})

        result = await count_table_records(
            client=mock_client,
            table="incident",
            query="priority=1",
        )

        assert result == 5
        call_args = mock_client.count_records.call_args
        assert call_args.kwargs.get("sysparm_query") == "priority=1"

    @pytest.mark.asyncio
    async def test_count_zero(self, mock_client):
        from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records

        mock_client.count_records.return_value = (0, {"result": []})

        result = await count_table_records(
            client=mock_client,
            table="cmdb_ci_server",
            query="name=nonexistent",
        )

        assert result == 0

    @pytest.mark.asyncio
    async def test_empty_query_passes_none(self, mock_client):
        from servicenow_mcp.tools.cmdb.audit.audit_count_table_records import count_table_records

        mock_client.count_records.return_value = (100, {"result": []})

        await count_table_records(client=mock_client, table="incident", query="")

        call_args = mock_client.count_records.call_args
        assert call_args.kwargs.get("sysparm_query") is None
