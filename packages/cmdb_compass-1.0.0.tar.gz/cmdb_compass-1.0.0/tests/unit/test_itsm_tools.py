"""Unit tests for ITSM tools.

Covers all 8 ITSM tools: 3 write operations (create, update, add_comment)
and 5 read operations (search, get_details, find_similar, search_groups, search_users).
"""

import pytest
from unittest.mock import AsyncMock, Mock


# ── Write tools ──────────────────────────────────────────────────────────────

class TestCreateIncident:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.create_record = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_basic_creation(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        mock_client.create_record.return_value = {
            "result": {
                "number": "INC0010042",
                "sys_id": "abc123",
            }
        }

        result = await create_incident(
            client=mock_client,
            short_description="Server down",
            description="Production server is unreachable",
            urgency="2",
            impact="1",
            caller=None,
            assignment_group=None,
        )

        assert isinstance(result, str)
        assert "INC0010042" in result
        assert "abc123" in result
        assert "Server down" in result
        mock_client.create_record.assert_called_once()

    @pytest.mark.asyncio
    async def test_priority_calculation(self, mock_client):
        """Priority = min(urgency, impact)."""
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        mock_client.create_record.return_value = {"result": {"number": "INC0010043", "sys_id": "x"}}

        await create_incident(
            client=mock_client,
            short_description="Test",
            description=None,
            urgency="3",
            impact="1",
            caller=None,
            assignment_group=None,
        )

        call_args = mock_client.create_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert data["priority"] == "1"

    @pytest.mark.asyncio
    async def test_optional_fields_included(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        mock_client.create_record.return_value = {"result": {"number": "INC0010044", "sys_id": "y"}}

        await create_incident(
            client=mock_client,
            short_description="Test",
            description="Details here",
            urgency="2",
            impact="2",
            caller="user_sys_id_123",
            assignment_group="group_sys_id_456",
        )

        call_args = mock_client.create_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert data["description"] == "Details here"
        assert data["caller_id"] == "user_sys_id_123"
        assert data["assignment_group"] == "group_sys_id_456"

    @pytest.mark.asyncio
    async def test_optional_fields_excluded_when_none(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        mock_client.create_record.return_value = {"result": {"number": "INC0010045", "sys_id": "z"}}

        await create_incident(
            client=mock_client,
            short_description="Test",
            description=None,
            urgency="3",
            impact="3",
            caller=None,
            assignment_group=None,
        )

        call_args = mock_client.create_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert "description" not in data
        assert "caller_id" not in data
        assert "assignment_group" not in data

    @pytest.mark.asyncio
    async def test_success_message_format(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.create_incident import create_incident

        mock_client.create_record.return_value = {"result": {"number": "INC0010046", "sys_id": "w"}}

        result = await create_incident(
            client=mock_client,
            short_description="Test incident",
            description=None,
            urgency="2",
            impact="3",
            caller=None,
            assignment_group=None,
        )

        assert "Incident Created Successfully" in result
        assert "Priority" in result
        assert "urgency=2" in result
        assert "impact=3" in result


class TestUpdateIncident:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.get_record_by_number = AsyncMock()
        client.update_record = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_basic_update(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        mock_client.get_record_by_number.return_value = {
            "result": [{"sys_id": "inc_sys_id_1", "number": "INC0010001"}]
        }

        result = await update_incident(
            client=mock_client,
            incident_number="INC0010001",
            state="2",
            priority=None,
            assigned_to=None,
            work_notes=None,
        )

        assert "Updated Successfully" in result
        assert "INC0010001" in result
        assert "State: 2" in result
        mock_client.update_record.assert_called_once()

    @pytest.mark.asyncio
    async def test_incident_not_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        mock_client.get_record_by_number.return_value = {"result": []}

        result = await update_incident(
            client=mock_client,
            incident_number="INC9999999",
            state="2",
            priority=None,
            assigned_to=None,
            work_notes=None,
        )

        assert "Not Found" in result
        assert "INC9999999" in result
        mock_client.update_record.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_updates_specified(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        mock_client.get_record_by_number.return_value = {
            "result": [{"sys_id": "inc_sys_id_1"}]
        }

        result = await update_incident(
            client=mock_client,
            incident_number="INC0010001",
            state=None,
            priority=None,
            assigned_to=None,
            work_notes=None,
        )

        assert "No Updates Specified" in result
        mock_client.update_record.assert_not_called()

    @pytest.mark.asyncio
    async def test_multiple_field_updates(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.update_incident import update_incident

        mock_client.get_record_by_number.return_value = {
            "result": [{"sys_id": "inc_sys_id_2"}]
        }

        result = await update_incident(
            client=mock_client,
            incident_number="INC0010002",
            state="6",
            priority="1",
            assigned_to="user123",
            work_notes="Escalated to P1",
        )

        assert "State: 6" in result
        assert "Priority: 1" in result
        assert "Assigned To: user123" in result
        assert "Work Notes: Added" in result

        call_args = mock_client.update_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert data["state"] == "6"
        assert data["priority"] == "1"
        assert data["assigned_to"] == "user123"
        assert data["work_notes"] == "Escalated to P1"


class TestAddCommentToIncident:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.get_record_by_number = AsyncMock()
        client.update_record = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_add_work_note(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.add_comment_to_incident import add_comment_to_incident

        mock_client.get_record_by_number.return_value = {
            "result": [{"sys_id": "inc_sys_id_1"}]
        }

        result = await add_comment_to_incident(
            client=mock_client,
            incident_number="INC0010001",
            comment="Investigated root cause",
            work_notes=True,
        )

        assert "Comment Added Successfully" in result
        assert "Internal" in result
        assert "Investigated root cause" in result

        call_args = mock_client.update_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert "work_notes" in data
        assert data["work_notes"] == "Investigated root cause"

    @pytest.mark.asyncio
    async def test_add_customer_comment(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.add_comment_to_incident import add_comment_to_incident

        mock_client.get_record_by_number.return_value = {
            "result": [{"sys_id": "inc_sys_id_2"}]
        }

        result = await add_comment_to_incident(
            client=mock_client,
            incident_number="INC0010002",
            comment="We are working on a fix",
            work_notes=False,
        )

        assert "Customer Visible" in result

        call_args = mock_client.update_record.call_args
        data = call_args.kwargs.get("data") or call_args[1].get("data")
        assert "comments" in data
        assert "work_notes" not in data

    @pytest.mark.asyncio
    async def test_incident_not_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.add_comment_to_incident import add_comment_to_incident

        mock_client.get_record_by_number.return_value = {"result": []}

        result = await add_comment_to_incident(
            client=mock_client,
            incident_number="INC9999999",
            comment="test",
            work_notes=True,
        )

        assert "Not Found" in result
        mock_client.update_record.assert_not_called()


# ── Read tools ───────────────────────────────────────────────────────────────

class TestSearchIncidents:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.query_table = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_search_with_query(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents

        mock_client.query_table.return_value = [
            {
                "number": "INC0010001",
                "short_description": "Server down in DC1",
                "state": "2",
                "priority": "1",
                "assigned_to": {"display_value": "John Admin"},
            }
        ]

        result = await search_incidents(
            client=mock_client,
            query="server down",
            priority=None,
            state=None,
            assigned_to=None,
            limit=10,
        )

        assert "INC0010001" in result
        assert "Server down in DC1" in result
        assert "1 found" in result

    @pytest.mark.asyncio
    async def test_search_no_results(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents

        mock_client.query_table.return_value = []

        result = await search_incidents(
            client=mock_client,
            query="nonexistent issue",
            priority=None,
            state=None,
            assigned_to=None,
            limit=10,
        )

        assert "No incidents found" in result

    @pytest.mark.asyncio
    async def test_search_with_filters(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents

        mock_client.query_table.return_value = [
            {"number": "INC001", "short_description": "test", "state": "1", "priority": "2", "assigned_to": ""}
        ]

        await search_incidents(
            client=mock_client,
            query=None,
            priority="2",
            state="1",
            assigned_to="admin",
            limit=5,
        )

        call_args = mock_client.query_table.call_args
        query_str = call_args.kwargs.get("query") or call_args[1].get("query", "")
        assert "priority=2" in query_str
        assert "state=1" in query_str
        assert "assigned_to.user_name=admin" in query_str

    @pytest.mark.asyncio
    async def test_search_assigned_to_string(self, mock_client):
        """Test that assigned_to handles non-dict values."""
        from servicenow_mcp.tools.itsm.audit.search_incidents import search_incidents

        mock_client.query_table.return_value = [
            {"number": "INC001", "short_description": "test", "state": "1", "priority": "2", "assigned_to": "admin"}
        ]

        result = await search_incidents(
            client=mock_client,
            query=None,
            priority=None,
            state=None,
            assigned_to=None,
            limit=10,
        )

        assert "admin" in result


class TestGetIncidentDetails:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.query_table = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_get_details(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.get_incident_details import get_incident_details

        mock_client.query_table.return_value = [
            {
                "number": "INC0010001",
                "short_description": "Server down",
                "description": "Production server is unreachable",
                "category": "Hardware",
                "subcategory": "Server",
                "impact": "1",
                "urgency": "1",
                "priority": "1",
                "state": "2",
                "assignment_group": {"display_value": "Server Team"},
                "caller_id": {"display_value": "Jane Doe"},
                "opened_at": "2026-01-15",
                "sys_updated_on": "2026-01-16",
                "resolved_at": "",
                "closed_at": "",
                "work_notes": "Investigating root cause",
            }
        ]

        result = await get_incident_details(
            client=mock_client,
            incident_number="INC0010001",
        )

        assert "INC0010001" in result
        assert "Server down" in result
        assert "Hardware" in result
        assert "Server Team" in result
        assert "Jane Doe" in result
        assert "Investigating root cause" in result

    @pytest.mark.asyncio
    async def test_incident_not_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.get_incident_details import get_incident_details

        mock_client.query_table.return_value = []

        result = await get_incident_details(
            client=mock_client,
            incident_number="INC9999999",
        )

        assert "Not Found" in result

    @pytest.mark.asyncio
    async def test_assignment_group_as_string(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.get_incident_details import get_incident_details

        mock_client.query_table.return_value = [
            {
                "number": "INC001",
                "short_description": "test",
                "assignment_group": "Plain Group Name",
                "caller_id": "plain_caller",
            }
        ]

        result = await get_incident_details(client=mock_client, incident_number="INC001")
        assert "Plain Group Name" in result


class TestFindSimilarIncidents:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.query_table = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_find_similar(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        # First call: reference incident lookup
        # Second call: similar incidents search
        mock_client.query_table.side_effect = [
            [{"number": "INC0010001", "short_description": "Production server outage in datacenter"}],
            [
                {"number": "INC0010005", "short_description": "Server outage in DC2", "state": "6", "priority": "2"},
            ],
        ]

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC0010001",
            limit=5,
        )

        assert "Similar Incidents" in result
        assert "INC0010005" in result
        assert "Keywords" in result

    @pytest.mark.asyncio
    async def test_reference_not_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        mock_client.query_table.return_value = []

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC9999999",
            limit=5,
        )

        assert "Not Found" in result

    @pytest.mark.asyncio
    async def test_no_description(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        mock_client.query_table.return_value = [
            {"number": "INC001", "short_description": ""}
        ]

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC001",
            limit=5,
        )

        assert "No Description" in result

    @pytest.mark.asyncio
    async def test_short_words_filtered_out(self, mock_client):
        """Words <= 4 chars are filtered out. If all words are short, should return insufficient."""
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        mock_client.query_table.return_value = [
            {"number": "INC001", "short_description": "CPU is up on a VM"}
        ]

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC001",
            limit=5,
        )

        assert "Insufficient Keywords" in result

    @pytest.mark.asyncio
    async def test_no_similar_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        mock_client.query_table.side_effect = [
            [{"number": "INC001", "short_description": "Production server outage scenario"}],
            [],  # No similar incidents
        ]

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC001",
            limit=5,
        )

        assert "No Similar Incidents Found" in result

    @pytest.mark.asyncio
    async def test_resolution_notes_as_dict(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.find_similar_incidents import find_similar_incidents

        mock_client.query_table.side_effect = [
            [{"number": "INC001", "short_description": "Database connection timeout error"}],
            [
                {
                    "number": "INC002",
                    "short_description": "Database timeout",
                    "state": "7",
                    "priority": "3",
                    "resolution_notes": {"display_value": "Increased connection pool size"},
                },
            ],
        ]

        result = await find_similar_incidents(
            client=mock_client,
            incident_number="INC001",
            limit=5,
        )

        assert "Increased connection pool size" in result


class TestSearchAssignmentGroups:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.query_table = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_search_groups(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_assignment_groups import search_assignment_groups

        mock_client.query_table.return_value = [
            {"sys_id": "grp001", "name": "Network Team", "manager": {"display_value": "Alice"}},
        ]

        result = await search_assignment_groups(
            client=mock_client,
            name="Network",
            limit=10,
        )

        assert "Network Team" in result
        assert "Alice" in result
        assert "1 found" in result

    @pytest.mark.asyncio
    async def test_no_groups_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_assignment_groups import search_assignment_groups

        mock_client.query_table.return_value = []

        result = await search_assignment_groups(
            client=mock_client,
            name="NonexistentGroup",
            limit=10,
        )

        assert "No groups found" in result

    @pytest.mark.asyncio
    async def test_sys_id_as_dict(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_assignment_groups import search_assignment_groups

        mock_client.query_table.return_value = [
            {"sys_id": {"value": "grp002"}, "name": "DB Team", "manager": "Bob"},
        ]

        result = await search_assignment_groups(client=mock_client, name="DB", limit=10)
        assert "grp002" in result
        assert "Bob" in result


class TestSearchUsers:
    @pytest.fixture
    def mock_client(self):
        client = Mock()
        client.query_table = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_search_users(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_users import search_users

        mock_client.query_table.return_value = [
            {"sys_id": "usr001", "name": "Alice Admin", "user_name": "alice.admin", "email": "alice@example.com"},
        ]

        result = await search_users(client=mock_client, name="Alice", limit=10)

        assert "Alice Admin" in result
        assert "alice.admin" in result
        assert "alice@example.com" in result

    @pytest.mark.asyncio
    async def test_no_users_found(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_users import search_users

        mock_client.query_table.return_value = []

        result = await search_users(client=mock_client, name="Nobody", limit=10)
        assert "No users found" in result

    @pytest.mark.asyncio
    async def test_sys_id_as_dict(self, mock_client):
        from servicenow_mcp.tools.itsm.audit.search_users import search_users

        mock_client.query_table.return_value = [
            {"sys_id": {"value": "usr002"}, "name": "Bob", "user_name": "bob", "email": ""},
        ]

        result = await search_users(client=mock_client, name="Bob", limit=10)
        assert "usr002" in result
