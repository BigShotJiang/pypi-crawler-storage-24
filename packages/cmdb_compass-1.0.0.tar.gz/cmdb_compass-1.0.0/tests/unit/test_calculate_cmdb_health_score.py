"""
Unit tests for Calculate CMDB Health Score tool
"""

import pytest
from unittest.mock import Mock, AsyncMock
from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.audit.audit_calculate_cmdb_health_score import calculate_cmdb_health_score


class TestCalculateCmdbHealthScore:
    """Test calculate_cmdb_health_score functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_health_score_basic(self, mock_client):
        """Test basic health score calculation."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs fetch
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                        "last_discovered": recent,
                    },
                    {
                        "sys_id": "ci_2",
                        "name": "Server2",
                        "serial_number": "SN124",
                        "ip_address": "192.168.1.2",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                        "last_discovered": recent,
                    },
                ]
            },
            # Relationships fetch
            {
                "result": [
                    {"sys_id": "rel_1", "parent": "ci_1", "child": "ci_2"},
                ]
            },
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["ci_class"] == "cmdb_ci_server"
        assert result["total_cis"] == 2
        assert result["overall_score"] > 0
        assert result["completeness_score"] == 100.0  # All fields populated
        assert result["health_rating"] in ["Excellent", "Good", "Fair", "Poor", "Critical"]
        assert len(result["recommendations"]) > 0

    @pytest.mark.asyncio
    async def test_health_score_no_cis(self, mock_client):
        """Test health score with no CIs."""
        mock_client.get_table_records.return_value = {"result": []}

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 0
        assert result["overall_score"] == 0
        assert "No active CIs" in result["message"]

    @pytest.mark.asyncio
    async def test_health_score_incomplete_data(self, mock_client):
        """Test health score with incomplete critical fields."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs with missing fields
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "",  # Missing
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                    {
                        "sys_id": "ci_2",
                        "name": "Server2",
                        "serial_number": "SN124",
                        "ip_address": "",  # Missing
                        "operational_status": "",  # Missing
                        "sys_updated_on": recent,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["completeness_score"] < 100.0  # Some fields missing
        assert any("populated" in rec for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_health_score_stale_cis(self, mock_client):
        """Test health score with stale CIs."""
        now = datetime.now(timezone.utc)
        old = (now - timedelta(days=100)).isoformat()  # Stale (>90 days)

        mock_client.get_table_records.side_effect = [
            # Stale CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": old,
                        "last_discovered": old,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["staleness_score"] < 50.0  # Low score for stale data
        assert any("stale" in rec.lower() for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_health_score_duplicates(self, mock_client):
        """Test health score with duplicate identifiers."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs with duplicate serial numbers
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",  # Duplicate
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                    {
                        "sys_id": "ci_2",
                        "name": "Server2",
                        "serial_number": "SN123",  # Duplicate
                        "ip_address": "192.168.1.2",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["duplicate_score"] < 100.0  # Penalty for duplicates
        assert any("duplicate" in rec.lower() for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_health_score_no_relationships(self, mock_client):
        """Test health score with no relationships."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                ]
            },
            # No relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["relationship_score"] == 0.0  # No relationships
        assert any("relationship" in rec.lower() for rec in result["recommendations"])

    @pytest.mark.asyncio
    async def test_health_score_custom_critical_fields(self, mock_client):
        """Test health score with custom critical fields."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "custom_field": "value1",
                        "sys_updated_on": recent,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
            critical_fields=["name", "custom_field"],
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["completeness_score"] == 100.0  # Both custom fields populated

    @pytest.mark.asyncio
    async def test_health_score_with_breakdown(self, mock_client):
        """Test health score with detailed breakdown."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
            include_breakdown=True,
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert "breakdown" in result
        assert "completeness" in result["breakdown"]
        assert "relationships" in result["breakdown"]
        assert "staleness" in result["breakdown"]
        assert "duplicates" in result["breakdown"]

    @pytest.mark.asyncio
    async def test_health_score_without_breakdown(self, mock_client):
        """Test health score without detailed breakdown."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        mock_client.get_table_records.side_effect = [
            # CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
            include_breakdown=False,
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert "breakdown" not in result

    @pytest.mark.asyncio
    async def test_health_score_excellent_rating(self, mock_client):
        """Test health score with excellent rating."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=5)).isoformat()

        mock_client.get_table_records.side_effect = [
            # Perfect CIs
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                        "last_discovered": recent,
                    },
                    {
                        "sys_id": "ci_2",
                        "name": "Server2",
                        "serial_number": "SN124",
                        "ip_address": "192.168.1.2",
                        "operational_status": "1",
                        "sys_updated_on": recent,
                        "last_discovered": recent,
                    },
                ]
            },
            # Good relationships
            {
                "result": [
                    {"sys_id": "rel_1", "parent": "ci_1", "child": "ci_2"},
                    {"sys_id": "rel_2", "parent": "ci_2", "child": "ci_1"},
                ]
            },
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["overall_score"] >= 90.0
        assert result["health_rating"] in ["Excellent", "Good"]

    @pytest.mark.asyncio
    async def test_health_score_age_distribution(self, mock_client):
        """Test health score with varied age distribution."""
        now = datetime.now(timezone.utc)

        mock_client.get_table_records.side_effect = [
            # CIs with different ages
            {
                "result": [
                    {
                        "sys_id": "ci_1",
                        "name": "Server1",
                        "serial_number": "SN123",
                        "ip_address": "192.168.1.1",
                        "operational_status": "1",
                        "sys_updated_on": (now - timedelta(days=10)).isoformat(),  # 0-30d
                    },
                    {
                        "sys_id": "ci_2",
                        "name": "Server2",
                        "serial_number": "SN124",
                        "ip_address": "192.168.1.2",
                        "operational_status": "1",
                        "sys_updated_on": (now - timedelta(days=45)).isoformat(),  # 30-60d
                    },
                    {
                        "sys_id": "ci_3",
                        "name": "Server3",
                        "serial_number": "SN125",
                        "ip_address": "192.168.1.3",
                        "operational_status": "1",
                        "sys_updated_on": (now - timedelta(days=75)).isoformat(),  # 60-90d
                    },
                    {
                        "sys_id": "ci_4",
                        "name": "Server4",
                        "serial_number": "SN126",
                        "ip_address": "192.168.1.4",
                        "operational_status": "1",
                        "sys_updated_on": (now - timedelta(days=100)).isoformat(),  # 90d+
                    },
                ]
            },
            # Relationships
            {"result": []},
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
            include_breakdown=True,
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert "breakdown" in result
        assert "staleness" in result["breakdown"]
        age_dist = result["breakdown"]["staleness"]["age_distribution"]
        assert age_dist["0-30d"] == 1
        assert age_dist["30-60d"] == 1
        assert age_dist["60-90d"] == 1
        assert age_dist["90d+"] == 1

    @pytest.mark.asyncio
    async def test_health_score_sample_size_limit(self, mock_client):
        """Test health score respects sample size limit."""
        now = datetime.now(timezone.utc)
        recent = (now - timedelta(days=10)).isoformat()

        # Create 1500 CIs (more than default sample_size of 1000)
        large_ci_list = [
            {
                "sys_id": f"ci_{i}",
                "name": f"Server{i}",
                "serial_number": f"SN{i}",
                "ip_address": f"192.168.1.{i % 255}",
                "operational_status": "1",
                "sys_updated_on": recent,
            }
            for i in range(100)  # Mock returns first 100
        ]

        mock_client.get_table_records.side_effect = [
            {"result": large_ci_list},
            {"result": []},  # Relationships
        ]

        result = await calculate_cmdb_health_score(
            client=mock_client,
            ci_class="cmdb_ci_server",
            sample_size=100,  # Limit sample
        
            _disable_cache=True,
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 100  # Respects sample_size
