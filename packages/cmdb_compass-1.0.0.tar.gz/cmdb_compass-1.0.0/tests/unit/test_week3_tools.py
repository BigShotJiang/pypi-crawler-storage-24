"""
Unit tests for Week 3 tools: identifier rules, reconciliation governance, naming normalization
"""

import pytest
from unittest.mock import Mock, AsyncMock
import sys
from pathlib import Path

# Add tools directory to path

from servicenow_mcp.tools.cmdb.action.audit_ci_identifier_rules import audit_ci_identifier_rules
from servicenow_mcp.tools.cmdb.action.audit_reconciliation_governance import audit_reconciliation_governance
from servicenow_mcp.tools.cmdb.action.normalize_ci_naming_conventions import normalize_ci_naming_conventions


class TestAuditCiIdentifierRules:
    """Test audit_ci_identifier_rules functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_identifier_audit_basic(self, mock_client):
        """Test basic identifier rule audit."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "serial_number": "SN12345",
                    "ip_address": "192.168.1.1",
                    "fqdn": "server1.example.com",
                },
                {
                    "sys_id": "ci_2",
                    "name": "Server2",
                    "serial_number": "SN12346",
                    "ip_address": "192.168.1.2",
                    "fqdn": "server2.example.com",
                },
            ]
        }

        result = await audit_ci_identifier_rules(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 2
        assert "rule_effectiveness" in result
        assert "field_coverage" in result["rule_effectiveness"]

    @pytest.mark.asyncio
    async def test_identifier_audit_no_cis(self, mock_client):
        """Test identifier audit with no CIs."""
        mock_client.get_table_records.return_value = {"result": []}

        result = await audit_ci_identifier_rules(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 0

    @pytest.mark.asyncio
    async def test_identifier_audit_duplicate_risk(self, mock_client):
        """Test detection of CIs at risk of duplication."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "serial_number": None,
                    "ip_address": "192.168.1.1",
                    "fqdn": None,
                    "asset_tag": None,
                },
            ]
        }

        result = await audit_ci_identifier_rules(
            client=mock_client,
            ci_class="cmdb_ci_server",
            analyze_duplicates=True,
        )

        assert result["status"] == "success"
        assert len(result["duplicate_risk_cis"]) == 1
        assert result["duplicate_risk_cis"][0]["reason"] == "Missing strong identifiers (serial_number, fqdn, asset_tag)"

    @pytest.mark.asyncio
    async def test_identifier_audit_rule_conflicts(self, mock_client):
        """Test detection of identifier conflicts."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "serial_number": "SN12345",
                    "fqdn": "server.example.com",
                },
                {
                    "sys_id": "ci_2",
                    "name": "Server2",
                    "serial_number": "SN12345",  # Duplicate serial number
                    "fqdn": "server.example.com",  # Duplicate FQDN
                },
            ]
        }

        result = await audit_ci_identifier_rules(
            client=mock_client,
            ci_class="cmdb_ci_server",
            check_rule_conflicts=True,
        )

        assert result["status"] == "success"
        assert len(result["rule_conflicts"]) > 0


class TestAuditReconciliationGovernance:
    """Test audit_reconciliation_governance functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_reconciliation_audit_basic(self, mock_client):
        """Test basic reconciliation governance audit."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "discovery_source": "ServiceNow Discovery",
                    "sys_created_by": "system",
                    "sys_updated_by": "system",
                },
                {
                    "sys_id": "ci_2",
                    "name": "Server2",
                    "discovery_source": "",
                    "sys_created_by": "admin",
                    "sys_updated_by": "admin",
                },
            ]
        }

        result = await audit_reconciliation_governance(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 2
        assert "data_sources" in result
        assert len(result["data_sources"]) > 0

    @pytest.mark.asyncio
    async def test_reconciliation_audit_no_cis(self, mock_client):
        """Test reconciliation audit with no CIs."""
        mock_client.get_table_records.return_value = {"result": []}

        result = await audit_reconciliation_governance(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 0

    @pytest.mark.asyncio
    async def test_reconciliation_audit_source_conflicts(self, mock_client):
        """Test detection of source conflicts."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "discovery_source": "Discovery",
                    "sys_created_by": "admin",  # Manual creation
                    "sys_updated_by": "system",
                },
            ]
        }

        result = await audit_reconciliation_governance(
            client=mock_client,
            ci_class="cmdb_ci_server",
            analyze_conflicts=True,
        )

        assert result["status"] == "success"
        assert "source_conflicts" in result

    @pytest.mark.asyncio
    async def test_reconciliation_audit_precedence(self, mock_client):
        """Test field precedence analysis."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "Server1",
                    "serial_number": "SN123",
                    "ip_address": "192.168.1.1",
                },
            ]
        }

        result = await audit_reconciliation_governance(
            client=mock_client,
            ci_class="cmdb_ci_server",
            check_field_precedence=True,
        )

        assert result["status"] == "success"
        assert "precedence_analysis" in result
        assert "serial_number" in result["precedence_analysis"]


class TestNormalizeCiNamingConventions:
    """Test normalize_ci_naming_conventions functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock ServiceNow client."""
        client = Mock()
        client.get_table_records = AsyncMock()
        client.update_record = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_naming_normalization_dry_run(self, mock_client):
        """Test naming normalization in dry run mode."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "server-01",  # lowercase, needs normalization
                    "serial_number": "SN12345",
                },
                {
                    "sys_id": "ci_2",
                    "name": "SERVER-02",  # Already compliant
                    "serial_number": "SN12346",
                },
            ]
        }

        result = await normalize_ci_naming_conventions(
            client=mock_client,
            ci_class="cmdb_ci_server",
            dry_run=True,
            case_style="uppercase",
        )

        assert result["status"] == "success"
        assert result["dry_run"] is True
        assert result["total_cis"] == 2
        assert result["non_compliant_cis"] >= 0

    @pytest.mark.asyncio
    async def test_naming_normalization_no_cis(self, mock_client):
        """Test naming normalization with no CIs."""
        mock_client.get_table_records.return_value = {"result": []}

        result = await normalize_ci_naming_conventions(
            client=mock_client,
            ci_class="cmdb_ci_server",
        )

        assert result["status"] == "success"
        assert result["total_cis"] == 0

    @pytest.mark.asyncio
    async def test_naming_normalization_auto_detect(self, mock_client):
        """Test auto-detection of naming pattern."""
        mock_client.get_table_records.return_value = {
            "result": [
                {"sys_id": "ci_1", "name": "SERVER-01"},
                {"sys_id": "ci_2", "name": "SERVER-02"},
                {"sys_id": "ci_3", "name": "SERVER-03"},
            ]
        }

        result = await normalize_ci_naming_conventions(
            client=mock_client,
            ci_class="cmdb_ci_server",
            auto_detect_pattern=True,
            dry_run=True,
        )

        assert result["status"] == "success"
        assert "naming_pattern_used" in result

    @pytest.mark.asyncio
    async def test_naming_normalization_violations(self, mock_client):
        """Test detection of naming violations."""
        mock_client.get_table_records.return_value = {
            "result": [
                {
                    "sys_id": "ci_1",
                    "name": "",  # Empty name
                    "serial_number": "SN12345",
                },
                {
                    "sys_id": "ci_2",
                    "name": "server@#$01",  # Invalid characters
                },
            ]
        }

        result = await normalize_ci_naming_conventions(
            client=mock_client,
            ci_class="cmdb_ci_server",
            dry_run=True,
        )

        assert result["status"] == "success"
        assert len(result["violations"]) >= 0
        # Check for violation types
        violation_types = [v["violation_type"] for v in result["violations"]]
        assert "empty_name" in violation_types or "pattern_mismatch" in violation_types

    @pytest.mark.asyncio
    async def test_naming_normalization_case_styles(self, mock_client):
        """Test different case style options."""
        mock_client.get_table_records.return_value = {
            "result": [
                {"sys_id": "ci_1", "name": "MixedCaseServer"},
            ]
        }

        for case_style in ["uppercase", "lowercase", "titlecase"]:
            result = await normalize_ci_naming_conventions(
                client=mock_client,
                ci_class="cmdb_ci_server",
                case_style=case_style,
                dry_run=True,
            )

            assert result["status"] == "success"
            assert result["case_style"] == case_style
