"""
ServiceNow Client Mock for Testing

Provides an in-memory ServiceNow client implementation for testing MCP tools.
Supports basic CRUD operations and relationship management.
"""

import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple, Union
from collections import defaultdict
import random
import string


class InMemoryTable:
    """In-memory table implementation with basic query support."""

    def __init__(self, name: str, schema: Optional[Dict[str, Any]] = None):
        self.name = name
        self.records: Dict[str, Dict[str, Any]] = {}
        self.schema = schema or {}
        self.next_sys_id = 1

    def generate_sys_id(self) -> str:
        """Generate a unique sys_id."""
        sys_id = f"sys_id_{self.next_sys_id}"
        self.next_sys_id += 1
        return sys_id

    def insert(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Insert a new record."""
        if 'sys_id' not in record:
            record['sys_id'] = self.generate_sys_id()
        if 'sys_created_on' not in record:
            record['sys_created_on'] = datetime.now().isoformat()
        if 'sys_updated_on' not in record:
            record['sys_updated_on'] = datetime.now().isoformat()

        self.records[record['sys_id']] = record.copy()
        return record

    def update(self, sys_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an existing record."""
        if sys_id not in self.records:
            return None

        record = self.records[sys_id]
        record.update(updates)
        record['sys_updated_on'] = datetime.now().isoformat()
        return record

    def delete(self, sys_id: str) -> bool:
        """Delete a record."""
        if sys_id in self.records:
            del self.records[sys_id]
            return True
        return False

    def get(self, sys_id: str) -> Optional[Dict[str, Any]]:
        """Get a record by sys_id."""
        return self.records.get(sys_id)

    def query(self, filters: Optional[Dict[str, Any]] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Query records with optional filters."""
        results = list(self.records.values())

        if filters:
            filtered = []
            for record in results:
                match = True
                for key, value in filters.items():
                    record_value = record.get(key)
                    if isinstance(value, str) and value.startswith('!='):
                        # Handle != operator
                        if record_value == value[2:]:
                            match = False
                            break
                    elif isinstance(value, str) and value.startswith('>='):
                        # Handle >= operator for dates
                        filter_value = value[2:]
                        if record_value and record_value < filter_value:
                            match = False
                            break
                    elif isinstance(value, str) and value.startswith('LIKE'):
                        # Handle LIKE operator
                        pattern = value[5:].replace('%', '.*')
                        if not re.search(pattern, record_value or '', re.IGNORECASE):
                            match = False
                            break
                    elif value is None:
                        # Handle empty/null checks (ISEMPTY)
                        if record_value is not None and record_value != '':
                            match = False
                            break
                    elif record_value != value:
                        match = False
                        break
                if match:
                    filtered.append(record)
            results = filtered

        return results[:limit]

    def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """Count records matching filters."""
        return len(self.query(filters))


class ServiceNowClientMock:
    """Mock ServiceNow client for testing."""

    def __init__(self):
        self.instance_url = "https://test.servicenow.com"
        self.tables: Dict[str, InMemoryTable] = {}
        self._initialize_mock_data()

    def _initialize_mock_data(self):
        """Initialize mock data for testing."""
        # Create tables
        self.tables['cmdb_ci'] = InMemoryTable('cmdb_ci')
        self.tables['cmdb_ci_server'] = InMemoryTable('cmdb_ci_server')
        self.tables['cmdb_ci_application'] = InMemoryTable('cmdb_ci_application')
        self.tables['cmdb_ci_database'] = InMemoryTable('cmdb_ci_database')
        self.tables['cmdb_ci_computer'] = InMemoryTable('cmdb_ci_computer')
        self.tables['cmdb_rel_ci'] = InMemoryTable('cmdb_rel_ci')
        self.tables['incident'] = InMemoryTable('incident')
        self.tables['sys_user'] = InMemoryTable('sys_user')
        self.tables['sys_user_group'] = InMemoryTable('sys_user_group')
        self.tables['sys_db_object'] = InMemoryTable('sys_db_object')
        self.tables['sys_dictionary'] = InMemoryTable('sys_dictionary')

        # Populate with mock data
        self._populate_mock_cis()
        self._populate_mock_incidents()
        self._populate_mock_users()
        self._populate_mock_relationships()

    def _populate_mock_cis(self):
        """Populate mock CI data."""
        servers = [
            {
                'name': 'web-server-01',
                'sys_class_name': 'cmdb_ci_server',
                'install_status': '1',  # Installed
                'operational_status': '1',  # Operational
                'environment': 'production',
                'location': 'datacenter-1',
                'owned_by': 'user_001',
                'support_group': 'server_team',
                'most_recent_discovery': (datetime.now() - timedelta(days=1)).isoformat(),
                'sys_tags': 'web,production,critical'
            },
            {
                'name': 'db-server-01',
                'sys_class_name': 'cmdb_ci_server',
                'install_status': '1',
                'operational_status': '1',
                'environment': 'production',
                'location': 'datacenter-1',
                'owned_by': 'user_002',
                'support_group': 'database_team',
                'most_recent_discovery': (datetime.now() - timedelta(days=30)).isoformat(),
                'sys_tags': 'database,production'
            },
            {
                'name': 'old-server-01',
                'sys_class_name': 'cmdb_ci_server',
                'install_status': '1',
                'operational_status': '1',
                'environment': 'production',
                'location': 'datacenter-1',
                'most_recent_discovery': (datetime.now() - timedelta(days=200)).isoformat(),
                'sys_tags': 'legacy'
            },
            {
                'name': 'app-server-01',
                'sys_class_name': 'cmdb_ci_server',
                'install_status': '1',
                'operational_status': '1',
                'environment': 'production',
                'owned_by': 'user_003',
                'support_group': 'app_team',
                'most_recent_discovery': (datetime.now() - timedelta(days=5)).isoformat(),
                'sys_tags': 'application,production'
            }
        ]

        apps = [
            {
                'name': 'web-app',
                'sys_class_name': 'cmdb_ci_application',
                'install_status': '1',
                'operational_status': '1',
                'owned_by': 'user_003',
                'support_group': 'app_team',
                'version': '1.2.3'
            },
            {
                'name': 'api-app',
                'sys_class_name': 'cmdb_ci_application',
                'install_status': '1',
                'operational_status': '1',
                'owned_by': 'user_003',
                'support_group': 'app_team',
                'version': '2.1.0'
            }
        ]

        computers = [
            {
                'name': 'laptop-001',
                'sys_class_name': 'cmdb_ci_computer',
                'install_status': '1',
                'operational_status': '1',
                'owned_by': 'user_001',
                'asset_tag': 'AST001',
                'serial_number': 'SN001'
            },
            {
                'name': 'desktop-001',
                'sys_class_name': 'cmdb_ci_computer',
                'install_status': '7',  # Retired
                'operational_status': '7',
                'owned_by': '',
                'asset_tag': 'AST002',
                'serial_number': 'SN002'
            },
            {
                'name': 'desktop-002',
                'sys_class_name': 'cmdb_ci_computer',
                'install_status': '1',
                'operational_status': '1',
                'owned_by': '',
                'asset_tag': 'AST003',
                'serial_number': 'SN003'
            }
        ]

        # Insert all CIs
        for ci in servers + apps + computers:
            self.tables['cmdb_ci'].insert(ci)
            # Also insert into specific class tables
            table_name = ci['sys_class_name']
            if table_name in self.tables:
                self.tables[table_name].insert(ci)

    def _populate_mock_incidents(self):
        """Populate mock incident data."""
        incidents = [
            {
                'number': 'INC0010001',
                'short_description': 'Web server is down',
                'description': 'The production web server web-server-01 is not responding',
                'state': '2',  # In Progress
                'priority': '1',  # Critical
                'urgency': '1',
                'impact': '1',
                'category': 'hardware',
                'caller_id': 'user_001',
                'assigned_to': 'user_002',
                'assignment_group': 'server_team',
                'opened_at': (datetime.now() - timedelta(hours=2)).isoformat(),
                'sys_updated_on': (datetime.now() - timedelta(minutes=30)).isoformat(),
                'work_notes': 'Investigating server connectivity issues'
            },
            {
                'number': 'INC0010002',
                'short_description': 'Database performance slow',
                'description': 'Users reporting slow response times from database',
                'state': '1',  # New
                'priority': '3',  # Moderate
                'urgency': '2',
                'impact': '2',
                'category': 'software',
                'caller_id': 'user_003',
                'assignment_group': 'database_team',
                'opened_at': (datetime.now() - timedelta(hours=1)).isoformat(),
                'sys_updated_on': (datetime.now() - timedelta(hours=1)).isoformat()
            },
            {
                'number': 'INC0010003',
                'short_description': 'Email service outage',
                'description': 'Company email service is completely down',
                'state': '6',  # Resolved
                'priority': '1',  # Critical
                'urgency': '1',
                'impact': '3',
                'category': 'network',
                'caller_id': 'user_001',
                'assigned_to': 'user_004',
                'assignment_group': 'network_team',
                'opened_at': (datetime.now() - timedelta(days=1)).isoformat(),
                'resolved_at': (datetime.now() - timedelta(hours=4)).isoformat(),
                'sys_updated_on': (datetime.now() - timedelta(hours=4)).isoformat(),
                'work_notes': 'Fixed email server configuration. Root cause: misconfigured DNS settings'
            }
        ]

        for incident in incidents:
            self.tables['incident'].insert(incident)

    def _populate_mock_users(self):
        """Populate mock user data."""
        users = [
            {
                'user_name': 'admin',
                'name': 'System Administrator',
                'email': 'admin@company.com',
                'sys_id': 'user_001'
            },
            {
                'user_name': 'dbadmin',
                'name': 'Database Administrator',
                'email': 'db@company.com',
                'sys_id': 'user_002'
            },
            {
                'user_name': 'appdev',
                'name': 'Application Developer',
                'email': 'dev@company.com',
                'sys_id': 'user_003'
            },
            {
                'user_name': 'netadmin',
                'name': 'Network Administrator',
                'email': 'net@company.com',
                'sys_id': 'user_004'
            }
        ]

        groups = [
            {
                'name': 'Server Team',
                'sys_id': 'server_team'
            },
            {
                'name': 'Database Team',
                'sys_id': 'database_team'
            },
            {
                'name': 'Application Team',
                'sys_id': 'app_team'
            },
            {
                'name': 'Network Team',
                'sys_id': 'network_team'
            }
        ]

        for user in users:
            self.tables['sys_user'].insert(user)

        for group in groups:
            self.tables['sys_user_group'].insert(group)

    def _populate_mock_relationships(self):
        """Populate mock CI relationships."""
        relationships = [
            {
                'parent': 'sys_id_1',  # web-server-01
                'child': 'sys_id_5',   # web-app
                'type': 'Hosted on::Hosts'
            },
            {
                'parent': 'sys_id_2',  # db-server-01
                'child': 'sys_id_5',   # web-app
                'type': 'Depends on::Used by'
            },
            {
                'parent': 'sys_id_4',  # app-server-01
                'child': 'sys_id_6',   # api-app
                'type': 'Hosted on::Hosts'
            },
            # Duplicate relationship for testing
            {
                'parent': 'sys_id_1',  # web-server-01
                'child': 'sys_id_5',   # web-app
                'type': 'Hosted on::Hosts'
            }
        ]

        for rel in relationships:
            self.tables['cmdb_rel_ci'].insert(rel)


    async def test_connection(self) -> Dict[str, Any]:
        """Mock connection test."""
        return {
            "status": "success",
            "user": {
                "name": "Test User",
                "user_name": "testuser"
            },
            "instance": self.instance_url
        }

    async def get_table_records(
        self,
        table: str,
        sysparm_query: Optional[str] = None,
        sysparm_fields: Optional[str] = None,
        sysparm_limit: int = 10,
        sysparm_offset: int = 0,
        sysparm_display_value: str = "true",
        **additional_params,
    ) -> Dict[str, Any]:
        """Get records from a table with ServiceNow-style parameters."""
        if table not in self.tables:
            raise ValueError(f"Table {table} not found")

        # Parse simple query (for testing purposes)
        filters = {}
        if sysparm_query:
            # Simple query parsing: field=value or field!=value
            parts = sysparm_query.split('^')
            for part in parts:
                if '=' in part:
                    if '!=' in part:
                        key, value = part.split('!=', 1)
                        filters[key] = f"!={value}"
                    elif 'ISEMPTY' in part:
                        key = part.replace('ISEMPTY', '').strip()
                        filters[key] = None  # Empty/null check
                    else:
                        key, value = part.split('=', 1)
                        filters[key] = value

        # Apply offset and limit
        limit = sysparm_limit or 10
        offset = sysparm_offset or 0
        records = self.tables[table].query(filters, limit + offset)
        if offset:
            records = records[offset:]

        # Filter fields if specified
        if sysparm_fields:
            fields_list = [f.strip() for f in sysparm_fields.split(',')]
            filtered_records = []
            for record in records:
                filtered = {k: v for k, v in record.items() if k in fields_list}
                filtered_records.append(filtered)
            records = filtered_records

        return {"result": records}

    async def get_record_by_number(self, table: str, number: str) -> Dict[str, Any]:
        """Get a record by its number field."""
        records = self.tables[table].query({'number': number}, limit=1)
        if records:
            return {"result": records}
        return {"result": []}

    async def insert_record(self, table: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """Insert a new record."""
        if table not in self.tables:
            raise ValueError(f"Table {table} not found")

        inserted = self.tables[table].insert(record)
        return {"result": [inserted]}

    async def update_record(self, table: str, sys_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing record."""
        if table not in self.tables:
            raise ValueError(f"Table {table} not found")

        updated = self.tables[table].update(sys_id, updates)
        if updated:
            return {"result": [updated]}
        return {"result": []}

    async def delete_record(self, table: str, sys_id: str) -> Dict[str, Any]:
        """Delete a record."""
        if table not in self.tables:
            raise ValueError(f"Table {table} not found")

        deleted = self.tables[table].delete(sys_id)
        return {"result": [{"deleted": deleted}]}

    async def get_table_schema(self, table: str) -> Dict[str, Any]:
        """Get table schema information."""
        # Mock schema data
        schemas = {
            'incident': [
                {'name': 'number', 'type': 'string', 'label': 'Number'},
                {'name': 'short_description', 'type': 'string', 'label': 'Short Description'},
                {'name': 'description', 'type': 'string', 'label': 'Description'},
                {'name': 'state', 'type': 'integer', 'label': 'State'},
                {'name': 'priority', 'type': 'integer', 'label': 'Priority'},
                {'name': 'opened_at', 'type': 'datetime', 'label': 'Opened'},
                {'name': 'caller_id', 'type': 'reference', 'label': 'Caller'},
                {'name': 'assigned_to', 'type': 'reference', 'label': 'Assigned To'},
                {'name': 'assignment_group', 'type': 'reference', 'label': 'Assignment Group'},
            ],
            'cmdb_ci_server': [
                {'name': 'name', 'type': 'string', 'label': 'Name'},
                {'name': 'install_status', 'type': 'integer', 'label': 'Install Status'},
                {'name': 'operational_status', 'type': 'integer', 'label': 'Operational Status'},
                {'name': 'environment', 'type': 'string', 'label': 'Environment'},
                {'name': 'owned_by', 'type': 'reference', 'label': 'Owned By'},
                {'name': 'support_group', 'type': 'reference', 'label': 'Support Group'},
                {'name': 'most_recent_discovery', 'type': 'datetime', 'label': 'Last Discovery'},
                {'name': 'sys_tags', 'type': 'string', 'label': 'Tags'},
            ]
        }

        return {"result": schemas.get(table, [])}

    async def count_records(self, table: str, sysparm_query: Optional[str] = None) -> Tuple[int, Dict[str, Any]]:
        """Return the record count for a table (ServiceNow-style)."""
        if table not in self.tables:
            raise ValueError(f"Table {table} not found")

        filters = {}
        if sysparm_query:
            # Simple query parsing
            parts = sysparm_query.split('^')
            for part in parts:
                if '=' in part:
                    if '!=' in part:
                        key, value = part.split('!=', 1)
                        filters[key] = f"!={value}"
                    elif 'ISEMPTY' in part:
                        key = part.replace('ISEMPTY', '').strip()
                        filters[key] = None
                    else:
                        key, value = part.split('=', 1)
                        filters[key] = value

        count = self.tables[table].count(filters)
        return count, {"result": []}

    async def get_table_count(self, table: str, query: str = "") -> int:
        """Get count of records in a table (legacy method for compatibility)."""
        count, _ = await self.count_records(table, sysparm_query=query)
        return count

    async def close(self):
        """Close the mock client (no-op)."""
        pass
