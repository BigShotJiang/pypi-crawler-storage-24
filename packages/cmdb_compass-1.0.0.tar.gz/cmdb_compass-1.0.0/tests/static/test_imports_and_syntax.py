"""
Static tests for imports and syntax validation.
"""

import subprocess
import sys
from pathlib import Path
import pytest


class TestSyntaxAndImports:
    """Test basic syntax and import validation."""

    def test_python_syntax_compilation(self):
        """Test that all Python files compile without syntax errors."""
        # Find all Python files in the project
        project_root = Path(__file__).parent.parent.parent
        python_files = []

        # Use git ls-files to get tracked Python files
        try:
            result = subprocess.run(
                ["git", "ls-files", "*.py"],
                cwd=project_root,
                capture_output=True,
                text=True,
                check=True
            )
            python_files = result.stdout.strip().split('\n')
            python_files = [project_root / f for f in python_files if f.strip()]
        except subprocess.CalledProcessError:
            # Fallback: find Python files manually
            python_files = list(project_root.rglob("*.py"))

        assert len(python_files) > 0, "No Python files found"

        # Test compilation of each file
        failed_files = []
        for py_file in python_files:
            if py_file.exists():
                try:
                    compile(py_file.read_text(), str(py_file), 'exec')
                except SyntaxError as e:
                    failed_files.append((str(py_file), str(e)))
                except Exception as e:
                    # Other errors (like import errors) are OK for syntax check
                    pass

        assert len(failed_files) == 0, f"Syntax errors in files: {failed_files}"

    def test_server_import(self):
        """Test that the main server module imports successfully."""
        # This should not raise any ImportError or SyntaxError
        try:
            from servicenow_mcp import server
            assert server is not None
            assert hasattr(server, 'mcp'), "Server should have MCP app instance"
        except Exception as e:
            pytest.fail(f"Failed to import server module: {e}")

    def test_server_quick_import(self):
        """Test quick import using subprocess (isolated environment)."""
        # Since we can't easily set up the module path in subprocess,
        # we'll test the import within the current test environment
        # which already has the proper path setup from conftest.py
        try:
            from servicenow_mcp import server
            assert server is not None
            assert hasattr(server, 'mcp')
        except ImportError as e:
            pytest.fail(f"Import failed: {e}")

    def test_core_dependencies(self):
        """Test that core dependencies can be imported."""
        # Test MCP server framework
        try:
            from mcp.server.fastmcp import FastMCP
            assert FastMCP is not None
        except ImportError as e:
            pytest.fail(f"Failed to import FastMCP: {e}")

        # Test other core imports used by server
        core_imports = [
            'json',
            'os',
            'sys',
            'pathlib',
            'typing',
            'collections.abc',
            'contextlib',
            'dataclasses',
            'datetime',
            'pathlib'
        ]

        for module in core_imports:
            try:
                __import__(module)
            except ImportError as e:
                pytest.fail(f"Failed to import core module {module}: {e}")

    def test_sentry_initialization(self):
        """Test that Sentry is properly configured (without actually sending)."""
        # This should not raise any exceptions
        try:
            import sentry_sdk
            assert sentry_sdk is not None

            # Check if Sentry was initialized
            # Note: We can't easily check if init was called without side effects,
            # but we can verify the import works
        except ImportError:
            # Sentry is optional, so import failure is OK
            pass
