"""
Pytest configuration and fixtures for ServiceNow MCP tests.
"""

import os
import json
import inspect
from typing import Any, Dict, List, Optional, Callable
from pathlib import Path

import pytest

from tests.utils.sn_client_mock import ServiceNowClientMock


@pytest.fixture(scope="session", autouse=True)
def load_test_environment():
    """Load environment variables for testing."""
    # Add src to Python path for imports
    import sys
    src_path = Path(__file__).parent.parent / "src"

    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))

    # Load .env if present
    env_path = Path(__file__).parent.parent / ".env"
    if env_path.exists():
        from dotenv import load_dotenv
        load_dotenv(env_path)

    # Set test defaults if not already set
    defaults = {
        "NEXECUTE_ENABLE_CMDB_AUDIT": "true",
        "NEXECUTE_ENABLE_CMDB_ACTION": "false",
    }

    for key, value in defaults.items():
        if key not in os.environ:
            os.environ[key] = value


@pytest.fixture(scope="session")
def sn_client_mock():
    """Provide a mock ServiceNow client for testing."""
    return ServiceNowClientMock()


@pytest.fixture(scope="session")
def tool_registry():
    """Discover and return all MCP tools dynamically."""
    from servicenow_mcp import server

    tools = []

    # Find all functions decorated with @mcp.tool()
    # The FastMCP decorator stores tool info in the function's __mcp_tool__ attribute
    for name, obj in inspect.getmembers(server):
        if inspect.isfunction(obj) or inspect.iscoroutinefunction(obj):
            # Check for MCP tool decorator metadata
            if hasattr(obj, '__mcp_tool__') and obj.__mcp_tool__ is not None:
                tools.append((name, obj))
            # Fallback: check function signature for ctx parameter and async nature
            elif name not in ['_get_app_context', '_get_servicenow_client', 'generate_compliance_report_impl']:
                sig = inspect.signature(obj)
                params = list(sig.parameters.keys())
                if (params and params[0] == 'ctx' and
                    (inspect.iscoroutinefunction(obj) or name in [
                        'query_table_records', 'count_table_records', 'list_tables_and_fields',
                        'analyze_ci_completeness', 'assess_relationship_coverage', 'identify_domain_gaps',
                        'audit_identify_stale_cis', 'audit_duplicate_cis', 'calculate_csdm_maturity_score', 'analyze_tagging_compliance',
                        'analyze_service_mappings', 'test_servicenow_connection', 'extract_ci_context',
                        'search_incidents', 'search_assignment_groups', 'search_users', 'get_incident_details',
                        'get_table_description', 'find_similar_incidents', 'create_incident', 'update_incident',
                        'add_comment_to_incident', 'auto_retire_stale_cis', 'classify_ci_relationships',
                        'suggest_ci_relationship_mappings', 'bulk_update_missing_fields', 'merge_duplicate_cis',
                        'remediate_relationship_health', 'generate_compliance_report', 'check_csdm_rules',
                        'audit_validate_relationship_integrity', 'action_auto_heal_relationship_issues',
                        'audit_ci_identifier_rules', 'audit_reconciliation_governance',
                        'audit_ci_data_lineage', 'audit_compliance_summary_report', 'audit_executive_health_summary',
                        'audit_ci_lifecycle_health', 'audit_ci_drift_detection',
                        'action_assess_change_impact', 'action_apply_bulk_cmdb_changes_with_cr',
                        'action_normalize_ci_naming_conventions',
                        'action_rollback_cmdb_changes', 'action_validate_change_approval_status'
                    ])):
                    tools.append((name, obj))

    # Remove duplicates and sort
    seen = set()
    unique_tools = []
    for name, obj in tools:
        if name not in seen:
            seen.add(name)
            unique_tools.append((name, obj))

    unique_tools.sort(key=lambda x: x[0])
    return unique_tools


def _get_tool_signature(tool_func) -> Dict[str, Any]:
    """Extract tool signature for generating test inputs."""
    sig = inspect.signature(tool_func)
    params = {}

    for name, param in sig.parameters.items():
        if name == 'ctx':
            continue  # Skip context parameter

        param_info = {
            'name': name,
            'annotation': str(param.annotation) if param.annotation != param.empty else 'Any',
            'default': None if param.default == param.empty else param.default
        }
        params[name] = param_info

    return params


def _infer_default_for_param(param_name: str, annotation: str) -> Any:
    """Infer a sensible test default from a parameter's name and type annotation."""
    ann = annotation.lower()

    # Well-known parameter names (checked first — override type-based inference)
    name_defaults = {
        "audit_level": "quick",
        "table": "cmdb_ci",
        "table_name": "cmdb_ci_server",
        "ci_class": "cmdb_ci_server",
        "ci_sys_id": "sys_id_1",
        "ci_sysid": "sys_id_1",
        "incident_number": "INC0010001",
        "change_request_id": "CHG0012345",
        "query": "",
        "domain": "Foundation",
        "domain_filter": None,
        "short_description": "Test incident",
        "comment": "Test comment",
        "name": "",
        "pattern": None,
        "dry_run": True,
        "check_circular": False,
        "include_details": False,
        "include_recommendations": True,
        "include_trends": True,
        "include_domain_breakdown": True,
        "include_decommission_candidates": True,
        "trace_upstream": True,
        "trace_downstream": True,
        "detect_unauthorized_changes": True,
        "check_csdm_compliance": True,
        "analyze_duplicates": True,
        "check_rule_coverage": True,
        "check_data_sources": True,
        "check_field_precedence": True,
        "auto_detect_pattern": True,
        "fix_orphaned": True,
    }
    if param_name in name_defaults:
        return name_defaults[param_name]

    # Optional parameters with unknown names → None (let tool use its own default)
    if "optional" in ann or "none" in ann:
        return None

    # Type-based inference (required params only, since Optional is handled above)
    if "bool" in ann:
        return False
    if "int" in ann:
        return 10
    if "float" in ann:
        return 1.0
    if "list" in ann:
        return []
    if "dict" in ann:
        return {}
    if "str" in ann:
        return "test"

    return None


# Explicit overrides for tools whose parameters can't be auto-inferred
_MANUAL_OVERRIDES: Dict[str, Dict[str, Any]] = {
    'merge_duplicate_cis': {'duplicate_ci_sysids': ['sys_id_1', 'sys_id_2'], 'keep_sysid': 'sys_id_1'},
    'bulk_update_missing_fields': {'table': 'cmdb_ci_server', 'field_mappings': {'environment': 'test'}},
    'action_apply_bulk_cmdb_changes_with_cr': {
        'changes': [{'sys_id': 'sys_id_1', 'name': 'test'}],
        'change_request_id': 'CHG0012345', 'dry_run': True,
    },
    'action_assess_change_impact': {'target_ci_sys_ids': ['sys_id_1'], 'change_type': 'update', 'max_depth': 3},
    'action_rollback_cmdb_changes': {'audit_trail_session_id': 'CMDB_CHANGE_20250118_123456', 'dry_run': True},
    'audit_ci_data_lineage': {'ci_sys_id': 'sys_id_1', 'max_depth': 3, 'audit_level': 'quick'},
}


def _generate_minimal_inputs(tool_name: str, tool_func) -> Dict[str, Any]:
    """Generate minimal valid inputs for a tool.

    Uses explicit overrides first, then auto-infers from parameter names and
    type annotations so new tools get smoke-tested without manual updates.
    """
    # Use manual override if available
    if tool_name in _MANUAL_OVERRIDES:
        return dict(_MANUAL_OVERRIDES[tool_name])

    params = _get_tool_signature(tool_func)
    inputs: Dict[str, Any] = {}

    for param_name, param_info in params.items():
        annotation = param_info.get("annotation", "Any")
        default = param_info.get("default")

        # If the parameter already has a default, skip it (pytest will use the default)
        if default is not None:
            continue

        # Auto-infer a value
        inputs[param_name] = _infer_default_for_param(param_name, annotation)

    return inputs


@pytest.fixture(scope="session")
def default_inputs(tool_registry):
    """Generate default inputs for all tools."""
    inputs = {}
    for tool_name, tool_func in tool_registry:
        inputs[tool_name] = _generate_minimal_inputs(tool_name, tool_func)
    return inputs


@pytest.fixture
def call_tool(sn_client_mock):
    """Helper fixture to call tools with mock client injection."""
    async def _call_tool(tool_func, **kwargs):
        """Call a tool function with mock client injection."""
        # Set dry_run=True for action tools if parameter exists
        if 'dry_run' in kwargs and kwargs['dry_run'] is None:
            kwargs['dry_run'] = True

        # For testing, we'll directly call async functions
        # In real MCP, these would be called through the MCP protocol
        try:
            # Import the actual AppContext class
            from servicenow_mcp.server import AppContext

            # Create a mock context that matches the expected structure
            class MockContext:
                def __init__(self, client):
                    self.request_context = MockRequestContext(client)

            class MockRequestContext:
                def __init__(self, client):
                    self.lifespan_context = AppContext(servicenow=client)

            ctx = MockContext(sn_client_mock)

            # Call the tool
            if inspect.iscoroutinefunction(tool_func):
                result = await tool_func(ctx, **kwargs)
            else:
                result = tool_func(ctx, **kwargs)

            return result

        except Exception as e:
            # Return error dict for failed calls
            return {"status": "error", "error": str(e)}

    return _call_tool


@pytest.fixture(scope="session", autouse=True)
def create_artifacts_dir():
    """Ensure artifacts directory exists."""
    artifacts_dir = Path(__file__).parent / ".artifacts"
    artifacts_dir.mkdir(exist_ok=True)
