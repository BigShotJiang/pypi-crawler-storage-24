# ServiceNow MCP Server

Core FastMCP application exposing ServiceNow automation tools via the Model Context Protocol (MCP).

## Local Development

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e .
uvicorn servicenow_mcp.server:mcp.streamable_http_app
```

## Tests

```bash
pytest
```

---

**Authoritative architecture and tool catalog:** [PROJECT_DOC.md](../PROJECT_DOC.md)
