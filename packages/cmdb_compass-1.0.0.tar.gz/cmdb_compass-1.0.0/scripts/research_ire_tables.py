#!/usr/bin/env python3
"""
IRE Table Research Script

Queries ServiceNow IRE-related tables to document schema and availability.
Run this to understand what data is available for audit_ire_health tool.

Usage:
    python scripts/research_ire_tables.py
"""

import asyncio
import sys
from pathlib import Path
import json
import os
from dotenv import load_dotenv

# Load .env file from project root
project_root = Path(__file__).parent.parent.parent
env_path = project_root / ".env"
load_dotenv(env_path)

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from servicenow_mcp.servicenow import ServiceNowClient


async def research_table(client: ServiceNowClient, table_name: str, limit: int = 5):
    """Query a table and document its schema and sample data."""
    print(f"\n{'='*80}")
    print(f"Table: {table_name}")
    print('='*80)
    
    try:
        # Query table with limit
        response = await client.get_table_records(
            table=table_name,
            sysparm_limit=limit
        )
        
        if response.get("error"):
            print(f"❌ ERROR: {response['error']}")
            return
        
        records = response.get("result", [])
        
        if not records:
            print("⚠️  No records found in table")
            return
        
        print(f"✅ Found {len(records)} records\n")
        
        # Document schema from first record
        first_record = records[0]
        print("SCHEMA (Fields Available):")
        print("-" * 80)
        
        for field, value in sorted(first_record.items()):
            value_type = type(value).__name__
            value_preview = str(value)[:60] + "..." if len(str(value)) > 60 else str(value)
            print(f"  {field:30s} | {value_type:10s} | {value_preview}")
        
        print("\n" + "="*80)
        print("SAMPLE RECORD (Full):")
        print("="*80)
        print(json.dumps(records[0], indent=2))
        
    except Exception as e:
        print(f"❌ EXCEPTION: {str(e)}")


async def main():
    """Research all IRE-related tables."""
    
    print("\n" + "="*80)
    print("IRE TABLE RESEARCH")
    print("="*80)
    print("Testing ServiceNow API access to IRE-related tables...")
    
    client = ServiceNowClient()
    
    # Tables to research
    tables = [
        ("sys_id_rule", "Identification Rules (IRE configuration)"),
        ("cmdb_reconciliation_state", "Reconciliation Status"),
        ("cmdb_key_value", "Match Rules (identifier key-value pairs)"),
        ("cmdb_ci_history", "CI Change History"),
        ("cmdb_rel_ci", "CI Relationships (for reconciliation validation)"),
    ]
    
    print("\nTesting access to IRE tables:")
    for table_name, description in tables:
        print(f"\n  - {table_name}: {description}")
    
    print("\n" + "="*80)
    
    for table_name, description in tables:
        await research_table(client, table_name, limit=3)
        await asyncio.sleep(0.5)  # Rate limiting
    
    print("\n" + "="*80)
    print("RESEARCH COMPLETE")
    print("="*80)
    print("\nNext Steps:")
    print("1. Review schema output above")
    print("2. Document findings in docs/phase2-research/IRE_API_RESEARCH.md")
    print("3. Design audit_ire_health tool based on available fields")
    print("4. If any table returned ERROR, that table may not be available in your instance")


if __name__ == "__main__":
    asyncio.run(main())
