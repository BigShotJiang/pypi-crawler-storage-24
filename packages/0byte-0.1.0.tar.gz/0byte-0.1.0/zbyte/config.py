from pydantic import BaseModel, Field

class Config(BaseModel):
    api_key: str = Field(..., description="0byte API key")
    endpoint: str = Field(default="https://api.0byte.dev", description="0byte API endpoint")
    timeout: float = Field(default=30.0, description="Request timeout in seconds")
