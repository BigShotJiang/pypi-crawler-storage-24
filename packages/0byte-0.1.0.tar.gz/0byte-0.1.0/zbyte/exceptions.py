class SDKError(Exception):
    """Base exception for 0byte SDK"""

class ProofError(SDKError):
    """Raised when proof creation fails"""

class VerificationError(SDKError):
    """Raised when content verification fails"""

class AuthenticationError(SDKError):
    """Raised when API authentication fails"""
