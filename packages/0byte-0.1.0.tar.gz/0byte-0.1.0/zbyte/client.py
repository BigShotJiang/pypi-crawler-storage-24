import base64
import httpx
from .config import Config
from .exceptions import AuthenticationError, ProofError, VerificationError
from .utils import logger


class Proof:
    """A cryptographic proof of AI content origin."""

    def __init__(self, data: dict):
        self.id = data["id"]
        self.fingerprint = data["fingerprint"]
        self.provider = data["provider"]
        self.model = data["model"]
        self.content_type = data["content_type"]
        self.timestamp = data["timestamp"]
        self.signature = data["signature"]
        self.verify_url = data["verify_url"]
        self.metadata = data.get("metadata")

    def __repr__(self):
        return f"Proof(id={self.id!r}, provider={self.provider!r}, model={self.model!r})"


class VerificationResult:
    """Result of verifying content against the 0byte registry."""

    def __init__(self, data: dict):
        self.matched = data["matched"]
        self.confidence = data["confidence"]
        self.proof = Proof(data["proof"]) if data.get("proof") else None

    def __repr__(self):
        if self.matched:
            return f"VerificationResult(matched=True, confidence={self.confidence:.3f}, proof={self.proof.id!r})"
        return "VerificationResult(matched=False)"


class Client:
    """0byte API client for stamping and verifying AI content."""

    def __init__(self, api_key: str = None, endpoint: str = "https://api.0byte.dev", timeout: float = 30.0):
        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self._http = httpx.Client(timeout=timeout)

    def stamp(
        self,
        content: bytes,
        content_type: str,
        provider: str,
        model: str,
        metadata: dict = None,
    ) -> Proof:
        """Create a cryptographic proof of origin for AI-generated content."""
        if not self.api_key:
            raise AuthenticationError("API key required for stamping. Pass api_key to Client().")

        payload = {
            "content": base64.b64encode(content).decode(),
            "content_type": content_type,
            "provider": provider,
            "model": model,
        }
        if metadata:
            payload["metadata"] = metadata

        logger.info("Stamping content (provider=%s, model=%s)", provider, model)

        response = self._http.post(
            f"{self.endpoint}/v1/stamp",
            json=payload,
            headers={"Authorization": f"Bearer {self.api_key}"},
        )

        if response.status_code == 401:
            raise AuthenticationError("Invalid API key")
        if response.status_code != 200:
            raise ProofError(f"Stamp failed ({response.status_code}): {response.text}")

        data = response.json()
        logger.info("Proof created: %s", data["id"])
        return Proof(data)

    def verify(self, content: bytes, content_type: str = "image/png") -> VerificationResult:
        """Verify content against the 0byte registry."""
        payload = {
            "content": base64.b64encode(content).decode(),
            "content_type": content_type,
        }

        logger.info("Verifying content against registry")

        response = self._http.post(
            f"{self.endpoint}/v1/verify",
            json=payload,
        )

        if response.status_code != 200:
            raise VerificationError(f"Verification failed ({response.status_code}): {response.text}")

        data = response.json()
        result = VerificationResult(data)
        if result.matched:
            logger.info("Match found: %s (confidence=%.3f)", result.proof.id, result.confidence)
        else:
            logger.info("No match found in registry")
        return result

    def get_proof(self, proof_id: str) -> Proof:
        """Look up a proof by ID."""
        response = self._http.get(f"{self.endpoint}/v1/proofs/{proof_id}")

        if response.status_code == 404:
            raise ProofError(f"Proof not found: {proof_id}")
        if response.status_code != 200:
            raise ProofError(f"Lookup failed ({response.status_code}): {response.text}")

        return Proof(response.json())

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
