# -*- coding: utf-8 -*-
"""Auth helpers."""

from .service import (
    AuthError,
    AuthUser,
    SESSION_COOKIE_NAME,
    SESSION_COOKIE_SECURE,
    authenticate_session,
    change_password,
    clear_all_sessions,
    create_session_for_user,
    delete_account,
    force_reset_password,
    get_registered_user,
    get_registered_username,
    get_session_ttl_days,
    is_user_registered,
    register_first_user,
    revoke_session,
    set_session_ttl_days,
    verify_user_credentials,
)

__all__ = [
    "AuthError",
    "AuthUser",
    "SESSION_COOKIE_NAME",
    "SESSION_COOKIE_SECURE",
    "authenticate_session",
    "change_password",
    "clear_all_sessions",
    "create_session_for_user",
    "delete_account",
    "force_reset_password",
    "get_registered_user",
    "get_registered_username",
    "get_session_ttl_days",
    "is_user_registered",
    "register_first_user",
    "revoke_session",
    "set_session_ttl_days",
    "verify_user_credentials",
]
