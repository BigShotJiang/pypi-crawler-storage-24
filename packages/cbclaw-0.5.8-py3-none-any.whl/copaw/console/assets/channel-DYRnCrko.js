import{as as o,at as s}from"./index-GlYmN68p.js";const t=(a,r)=>o.lang.round(s.parse(a)[r]);export{t as c};
