# -*- coding: utf-8 -*-
"""Agent file management API."""

import asyncio
import json
import logging

from fastapi import APIRouter, Body, HTTPException, Request
from fastapi.responses import StreamingResponse
from agentscope_runtime.engine.schemas.agent_schemas import AgentRequest
from pydantic import BaseModel, Field

from ...config import (
    load_config,
    save_config,
    AgentsRunningConfig,
)

from ...agents.memory.agent_md_manager import AGENT_MD_MANAGER

router = APIRouter(prefix="/agent", tags=["agent"])
logger = logging.getLogger(__name__)
_running_stream_tasks: dict[str, asyncio.Task] = {}
_running_stream_lock = asyncio.Lock()


def _get_runner(request: Request):
    runner = getattr(request.app.state, "runner", None)
    if runner is None:
        raise HTTPException(status_code=503, detail="Runner not initialized.")
    return runner


def _stream_task_key(agent_request: AgentRequest) -> str:
    user_id = (agent_request.user_id or "default").strip() or "default"
    session_id = (agent_request.session_id or "").strip()
    return f"{user_id}:{session_id}"


def _stream_task_key_by_values(user_id: str, session_id: str) -> str:
    return f"{(user_id or 'default').strip() or 'default'}:{(session_id or '').strip()}"


def _to_sse_data(event) -> str:
    if hasattr(event, "model_dump_json"):
        payload = event.model_dump_json()
    elif hasattr(event, "json"):
        payload = event.json()
    else:
        payload = json.dumps({"text": str(event)}, ensure_ascii=False)
    return f"data: {payload}\n\n"


@router.post(
    "/process",
    summary="Process agent request",
    description=(
        "Custom process endpoint that keeps generation running even if the "
        "client disconnects."
    ),
)
async def process_agent_request(
    http_request: Request,
    agent_request: AgentRequest = Body(...),
):
    runner = _get_runner(http_request)

    if not agent_request.session_id:
        raise HTTPException(status_code=400, detail="session_id is required.")
    if not agent_request.user_id:
        agent_request.user_id = "default"

    task_key = _stream_task_key(agent_request)
    queue: asyncio.Queue[str | None] = asyncio.Queue()
    consumer_connected = True
    logger.info(
        "process start: user=%s session=%s",
        agent_request.user_id,
        agent_request.session_id,
    )

    async def worker():
        nonlocal consumer_connected
        try:
            async for event in runner.stream_query(agent_request):
                if consumer_connected:
                    await queue.put(_to_sse_data(event))
        except Exception as exc:  # pylint: disable=broad-except
            logger.exception(
                "agent process stream failed: session=%s error=%s",
                agent_request.session_id,
                exc,
            )
            if consumer_connected:
                await queue.put(
                    f"data: {json.dumps({'error': str(exc)})}\n\n",
                )
        finally:
            if consumer_connected:
                await queue.put(None)
            logger.info(
                "process finish: user=%s session=%s connected=%s",
                agent_request.user_id,
                agent_request.session_id,
                consumer_connected,
            )
            async with _running_stream_lock:
                current = _running_stream_tasks.get(task_key)
                if current is asyncio.current_task():
                    _running_stream_tasks.pop(task_key, None)

    async with _running_stream_lock:
        running = _running_stream_tasks.get(task_key)
        if running is not None and not running.done():
            raise HTTPException(
                status_code=409,
                detail="Current session is already running.",
            )
        task = asyncio.create_task(worker())
        _running_stream_tasks[task_key] = task

    async def stream_response():
        nonlocal consumer_connected
        try:
            while True:
                item = await queue.get()
                if item is None:
                    break
                yield item
        finally:
            consumer_connected = False
            logger.info(
                "process client disconnected: user=%s session=%s",
                agent_request.user_id,
                agent_request.session_id,
            )

    return StreamingResponse(
        stream_response(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


@router.get(
    "/process-status",
    summary="Get process running status for one session",
)
async def get_process_status(
    session_id: str,
    user_id: str = "default",
):
    if not session_id or not session_id.strip():
        raise HTTPException(status_code=400, detail="session_id is required.")

    task_key = _stream_task_key_by_values(user_id, session_id)
    async with _running_stream_lock:
        task = _running_stream_tasks.get(task_key)
        running = bool(task is not None and not task.done())

    return {
        "running": running,
        "session_id": session_id,
        "user_id": user_id or "default",
    }


class MdFileInfo(BaseModel):
    """Markdown file metadata."""

    filename: str = Field(..., description="File name")
    path: str = Field(..., description="File path")
    size: int = Field(..., description="Size in bytes")
    created_time: str = Field(..., description="Created time")
    modified_time: str = Field(..., description="Modified time")


class MdFileContent(BaseModel):
    """Markdown file content."""

    content: str = Field(..., description="File content")


@router.get(
    "/files",
    response_model=list[MdFileInfo],
    summary="List working files",
    description="List all working files",
)
async def list_working_files() -> list[MdFileInfo]:
    """List working directory markdown files."""
    try:
        files = [
            MdFileInfo.model_validate(file)
            for file in AGENT_MD_MANAGER.list_working_mds()
        ]
        return files
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/files/{md_name}",
    response_model=MdFileContent,
    summary="Read a working file",
    description="Read a working markdown file",
)
async def read_working_file(
    md_name: str,
) -> MdFileContent:
    """Read a working directory markdown file."""
    try:
        content = AGENT_MD_MANAGER.read_working_md(md_name)
        return MdFileContent(content=content)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.put(
    "/files/{md_name}",
    response_model=dict,
    summary="Write a working file",
    description="Create or update a working file",
)
async def write_working_file(
    md_name: str,
    request: MdFileContent,
) -> dict:
    """Write a working directory markdown file."""
    try:
        AGENT_MD_MANAGER.write_working_md(md_name, request.content)
        return {"written": True}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/memory",
    response_model=list[MdFileInfo],
    summary="List memory files",
    description="List all memory files",
)
async def list_memory_files() -> list[MdFileInfo]:
    """List memory directory markdown files."""
    try:
        files = [
            MdFileInfo.model_validate(file)
            for file in AGENT_MD_MANAGER.list_memory_mds()
        ]
        return files
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/memory/{md_name}",
    response_model=MdFileContent,
    summary="Read a memory file",
    description="Read a memory markdown file",
)
async def read_memory_file(
    md_name: str,
) -> MdFileContent:
    """Read a memory directory markdown file."""
    try:
        content = AGENT_MD_MANAGER.read_memory_md(md_name)
        return MdFileContent(content=content)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.put(
    "/memory/{md_name}",
    response_model=dict,
    summary="Write a memory file",
    description="Create or update a memory file",
)
async def write_memory_file(
    md_name: str,
    request: MdFileContent,
) -> dict:
    """Write a memory directory markdown file."""
    try:
        AGENT_MD_MANAGER.write_memory_md(md_name, request.content)
        return {"written": True}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/running-config",
    response_model=AgentsRunningConfig,
    summary="Get agent running config",
    description="Retrieve agent runtime behavior configuration",
)
async def get_agents_running_config() -> AgentsRunningConfig:
    """Get agent running configuration."""
    config = load_config()
    return config.agents.running


@router.put(
    "/running-config",
    response_model=AgentsRunningConfig,
    summary="Update agent running config",
    description="Update agent runtime behavior configuration",
)
async def put_agents_running_config(
    running_config: AgentsRunningConfig = Body(
        ...,
        description="Updated agent running configuration",
    ),
) -> AgentsRunningConfig:
    """Update agent running configuration."""
    config = load_config()
    config.agents.running = running_config
    save_config(config)
    return running_config
