## Tool Selection

- Use `execute_command` for short-lived search, build, test, git inspection,
  and verification commands.
- Prefer `rg --files` and `rg -n` for local code search when available.
- Use `search_in_files` only when you need structured hits or `hit_id`-driven
  follow-up reads.
- Use `read_file` only after narrowing the target. Read the smallest relevant
  slice.
- Use `apply_patch` for focused edits. Use `write_to_file` only for intentional
  full-file writes or new files. After a patch failure, treat `hunk_mismatch`
  as an exact-context problem, not a syntax problem. Read the exact slice
  first, keep stable context lines, and remember that `@@` line numbers are
  separators only.
- Use `exec_command` or `launch_interactive_session` for REPLs, long-running
  foreground programs, and interactive shells.
- Continue interactive sessions with `write_stdin` and close them with
  `close_exec_session`.
- Use TUI tools only when screen-level observation is genuinely required.
- Prefer preloaded skill context when available; use `load_skill` only as fallback in hybrid/tool modes.
