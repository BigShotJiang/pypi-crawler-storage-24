"""Custom exceptions for maxtest-bridge."""


class MaxtestBridgeError(Exception):
    """Base exception for all maxtest-bridge errors."""
    pass


class ConfigurationError(MaxtestBridgeError):
    """Raised when configuration is invalid or missing."""
    pass


class AuthenticationError(MaxtestBridgeError):
    """Raised when authentication fails (401)."""
    pass


class ArchiveError(MaxtestBridgeError):
    """Raised when archiving/zipping fails."""
    pass


class UploadError(MaxtestBridgeError):
    """Raised when upload fails but should not break the pipeline."""
    pass


class NetworkError(MaxtestBridgeError):
    """Raised when network communication fails."""
    pass
