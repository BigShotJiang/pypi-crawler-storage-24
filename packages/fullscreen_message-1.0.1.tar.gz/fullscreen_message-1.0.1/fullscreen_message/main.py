#!/usr/bin/env python3
"""Display fullscreen messages that close on keypress."""
import argparse
import tkinter as tk
import tkinter.font as tkfont
import sys

from screeninfo import get_monitors


def get_current_monitor_size(root, debug=False):
    """Get the size of the monitor the window is currently on."""
    monitors = get_monitors()
    wx = root.winfo_x()
    wy = root.winfo_y()
    if debug:
        print(f"[debug] window position: {wx}, {wy}")
        for m in monitors:
            print(f"[debug] monitor: {m}")
    for m in monitors:
        if m.x <= wx < m.x + m.width and m.y <= wy < m.y + m.height:
            if debug:
                print(f"[debug] selected monitor: {m}")
            return m.width, m.height
    m = monitors[0]
    if debug:
        print(f"[debug] fallback to first monitor: {m}")
    return m.width, m.height


def measure_wrapped(font, text, max_width):
    """Return (total_width, total_height) for text wrapped at max_width."""
    words = text.split()
    lines = []
    current = []
    for word in words:
        test = ' '.join(current + [word])
        if font.measure(test) <= max_width:
            current.append(word)
        else:
            if current:
                lines.append(' '.join(current))
            current = [word]
    if current:
        lines.append(' '.join(current))

    if not lines:
        return 0, 0

    line_height = font.metrics('linespace')
    max_line_width = max(font.measure(l) for l in lines)
    total_height = line_height * len(lines)
    return max_line_width, total_height


def find_optimal_font_size(text, screen_width, screen_height, font_family='Arial', debug=False):
    """Find the largest font size that fits the wrapped text on screen."""
    target_width = screen_width * 0.9
    target_height = screen_height * 0.9

    if debug:
        print(f"[debug] screen: {screen_width}x{screen_height}")
        print(f"[debug] target: {target_width}x{target_height}")

    temp_root = tk.Tk()
    temp_root.withdraw()

    min_size = 10
    max_size = 1000
    optimal_size = min_size

    while min_size <= max_size:
        mid_size = (min_size + max_size) // 2
        font = tkfont.Font(family=font_family, size=mid_size, weight='bold', root=temp_root)
        w, h = measure_wrapped(font, text, target_width)
        if w <= target_width and h <= target_height:
            optimal_size = mid_size
            min_size = mid_size + 1
        else:
            max_size = mid_size - 1

    temp_root.destroy()

    if debug:
        print(f"[debug] optimal font size: {optimal_size}")

    return optimal_size


def show_fullscreen_message(message, bg_color="black", text_color="white", screenshot=None, debug=False):
    """Display a fullscreen message that closes on any key press."""
    root = tk.Tk()
    root.attributes('-fullscreen', True)
    root.configure(background=bg_color)

    root.update_idletasks()
    screen_width, screen_height = get_current_monitor_size(root, debug=debug)

    if debug:
        print(f"[debug] message: {message!r}")
        print(f"[debug] wraplength: {int(screen_width * 0.9)}")

    font_size = find_optimal_font_size(message, screen_width, screen_height, debug=debug)

    root.bind('<Key>', lambda e: root.destroy())
    root.bind('<Escape>', lambda e: root.destroy())

    label = tk.Label(
        root,
        text=message,
        font=('Arial', font_size, 'bold'),
        bg=bg_color,
        fg=text_color,
        wraplength=int(screen_width * 0.9),
        justify='center',
    )
    label.pack(expand=True)

    if screenshot:
        def take_screenshot():
            root.update()
            try:
                from PIL import ImageGrab
                img = ImageGrab.grab(bbox=(0, 0, screen_width, screen_height))
                img.save(screenshot)
                print(f"Screenshot saved to {screenshot}")
            except ImportError:
                import subprocess
                subprocess.run(["scrot", "-z", screenshot], check=False)
                print(f"Screenshot saved to {screenshot}")
            root.destroy()
        root.after(200, take_screenshot)

    root.mainloop()


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(description="Display a fullscreen message")
    parser.add_argument("message", nargs="*", help="Message to display")
    parser.add_argument("--screenshot", metavar="FILE",
                        help="Save a screenshot to FILE instead of waiting for keypress")
    parser.add_argument("--debug", action="store_true",
                        help="Print debug info about font size calculation")
    args = parser.parse_args()

    if not args.message and not sys.stdin.isatty():
        message = sys.stdin.read().strip()
    else:
        message = ' '.join(args.message) if args.message else "PRESS ANY KEY"

    show_fullscreen_message(message, screenshot=args.screenshot, debug=args.debug)


if __name__ == "__main__":
    main()
