# manju

AI-powered comic drama production pipeline.

> Script in, episode out.

Coming soon.
