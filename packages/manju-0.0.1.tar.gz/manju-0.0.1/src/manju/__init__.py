"""Manju - AI-powered comic drama production pipeline."""

__version__ = "0.0.1"
