"""
Orchestrator — ReAct control loop with navigation stack.

Flow per step:
  1. screenshot(device)
  2. qwen.decide(screenshot, task, history, nav_stack)
     → if "ground": ui_agent.grounding_targeted → qwen.decide phase-2
     → else: direct action
  3. Update nav_stack based on action type:
     - tap / swipe / launch_app  → push new frame (navigated deeper)
     - press_key(BACK)           → pop one frame
     - press_key(HOME)           → clear stack to root
  4. Execute, repeat.

Navigation stack gives Qwen full context:
  [0] Home Screen
  [1] Settings       (via tap(195,453))
  [2] Wi-Fi          (via tap(390,128))  ← current
"""
from __future__ import annotations

import re
import time
from urllib.parse import urlparse
from typing import Callable, Optional

from logger import get_logger
from agents.qwen_agent import QwenAgent
from agents.ui_agent import UIAgent
from mdb.bridge import DeviceBridge
from mdb.models import Action
from vision_screenshot_server import get_screenshot_url, set_current_screenshot

from .result import NavFrame, ScrollState, StepLog, TaskResult

log = get_logger("orchestrator")

MAX_GROUND_PER_STEP = 2
MAX_SAME_ACTION_REPEAT = 3

# ── Gesture fast-path ─────────────────────────────────────────────────────────
# Maps simple atomic gesture keywords → (action_type, *args).
# Conventions (iPhone 16 Pro, 402×874 logical points):
#
#   "往右滑" = show content to the RIGHT  → finger moves LEFT  → swipe(350,437,50,437)
#   "往左滑" = show content to the LEFT   → finger moves RIGHT → swipe(50,437,350,437)
#   "往上滑" = show content BELOW         → finger moves UP    → swipe(201,700,201,200)
#   "往下滑" = show content ABOVE         → finger moves DOWN  → swipe(201,200,201,700)
#
# This is the standard "direction = where content goes" convention used in
# Chinese mobile UI, not the raw gesture-direction convention.

_GESTURE_MAP: dict[str, tuple] = {
    # ── Horizontal ────────────────────────────────────────────────────────────
    # "往右滑" / "swipe right" = next page / show right-side content
    "往右滑":      ("swipe", 350, 437, 50,  437, 300),
    "右滑":        ("swipe", 350, 437, 50,  437, 300),
    "向右滑":      ("swipe", 350, 437, 50,  437, 300),
    "swipe right": ("swipe", 350, 437, 50,  437, 300),
    "scroll right":("swipe", 350, 437, 50,  437, 300),
    # "往左滑" / "swipe left" = prev page / show left-side content
    "往左滑":      ("swipe", 50,  437, 350, 437, 300),
    "左滑":        ("swipe", 50,  437, 350, 437, 300),
    "向左滑":      ("swipe", 50,  437, 350, 437, 300),
    "swipe left":  ("swipe", 50,  437, 350, 437, 300),
    "scroll left": ("swipe", 50,  437, 350, 437, 300),
    # ── Vertical ──────────────────────────────────────────────────────────────
    # "往上滑" / "scroll down" = reveal content below (finger goes up)
    "往上滑":      ("swipe", 201, 700, 201, 200, 400),
    "上滑":        ("swipe", 201, 700, 201, 200, 400),
    "向上滑":      ("swipe", 201, 700, 201, 200, 400),
    "swipe up":    ("swipe", 201, 700, 201, 200, 400),
    "scroll down": ("swipe", 201, 700, 201, 200, 400),
    # "往下滑" / "scroll up" = reveal content above (finger goes down)
    "往下滑":      ("swipe", 201, 200, 201, 700, 400),
    "下滑":        ("swipe", 201, 200, 201, 700, 400),
    "向下滑":      ("swipe", 201, 200, 201, 700, 400),
    "swipe down":  ("swipe", 201, 200, 201, 700, 400),
    "scroll up":   ("swipe", 201, 200, 201, 700, 400),
    # ── Navigation keys ───────────────────────────────────────────────────────
    "返回":        ("press_key", "BACK"),
    "回上一頁":    ("press_key", "BACK"),
    "back":        ("press_key", "BACK"),
    "go back":     ("press_key", "BACK"),
    "go home":     ("press_key", "HOME"),
    "home":        ("press_key", "HOME"),
    "回home":      ("press_key", "HOME"),
    "回主畫面":    ("press_key", "HOME"),
}


def _extract_input_text(task: str) -> Optional[str]:
    """
    For tasks like '輸入 X [in/on Y]' / 'type X [in Y]' / 'input_text X',
    extract and return the text X that should be typed.

    Examples:
      '輸入https://google.com on address textfield' → 'https://google.com'
      'input_text https://google.com'               → 'https://google.com'
      'type hello world in search bar'              → 'hello world'
      'input abc'                                   → 'abc'
    """
    t = task.strip()
    # Ordered from most specific to most general.
    patterns = [
        # Explicit input_text command (MCP / CLI primitive)
        r"^input_text\s+(https?://\S+)",
        r"^input_text\s+(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
        # URL variants (no-space text)
        r"^輸入\s*(https?://\S+)",
        r"^input\s+(https?://\S+)",
        r"^type\s+(https?://\S+)",
        # General: capture text up to optional "in/on/at/to <field>" suffix
        r"^輸入\s*(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
        r"^打字\s+(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
        r"^打入\s*(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
        r"^type\s+(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
        r"^input\s+(.+?)(?:\s+(?:in|on|at|to|into)\s+\S.*)?$",
    ]
    for pat in patterns:
        m = re.match(pat, t, re.I)
        if m:
            text = m.group(1).strip()
            if text:
                return text
    return None


def _detect_gesture(task: str) -> Optional[Action]:
    """
    If *task* is a simple atomic gesture keyword, return the corresponding
    Action immediately (no Qwen needed).  Returns None otherwise.

    Matching is done on the normalised task string; any surrounding whitespace
    or punctuation is stripped so "往右滑！" still matches "往右滑".
    """
    t = task.strip().rstrip("！!。.").lower()
    spec = _GESTURE_MAP.get(t)
    if spec is None:
        # Try substring match for short tasks (e.g. "請往右滑一下")
        for kw, s in _GESTURE_MAP.items():
            if kw in t and len(t) <= len(kw) + 8:
                spec = s
                break
    if spec is None:
        return None

    action_type = spec[0]
    if action_type == "swipe":
        _, x, y, x2, y2, dur = spec
        return Action(
            action_type="swipe", x=x, y=y, x2=x2, y2=y2, duration_ms=dur,
            reasoning=f"Gesture fast-path: {task!r}",
        )
    if action_type == "press_key":
        return Action(
            action_type="press_key", key=spec[1],
            reasoning=f"Gesture fast-path: {task!r}",
        )
    return None


def _best_tap_from_elements(elements: list[dict], query: str) -> Action:
    """
    Auto-pick the best element to tap when Qwen refuses to decide.
    Handles both logical-point coords (from accessibility) and 0-1000 norm (from UI-UG).
    """
    keywords = {w.lower() for w in query.split() if len(w) > 2}

    def score(el: dict) -> int:
        label = el.get("label", "").lower()
        return sum(1 for kw in keywords if kw in label)

    best = max(elements, key=score)
    from_acc = best.get("description") == "from_accessibility"

    # Accessibility elements typically provide cx/cy in logical points.
    if "cx" in best and "cy" in best:
        cx, cy = int(best.get("cx", 0)), int(best.get("cy", 0))
    # UI grounding elements usually provide center/bbox in norm1000.
    # Use the pre-computed center if available.
    elif best.get("center") and len(best.get("center", [])) == 2:
        center = best.get("center", [])
        cx, cy = center[0], center[1]
    # Fallback to bbox center if present.
    else:
        bbox = best.get("bbox", [0, 0, 0, 0])
        cx = (bbox[0] + bbox[2]) // 2
        cy = (bbox[1] + bbox[3]) // 2

    if from_acc:
        return Action(
            action_type="tap", x=cx, y=cy,
            reasoning=f"accessibility auto-picked {query!r}: {best.get('label')!r} at ({cx},{cy})",
        )
    return Action(
        action_type="tap", x=cx, y=cy,
        reasoning=f"norm1000 auto-picked {query!r}: {best.get('label')!r} at norm({cx},{cy})",
    )

def _best_acc_match(elements: list[dict], query: str) -> Action:
    """
    Auto-pick the best accessibility element when Qwen can't decide.
    Elements are already in logical point coordinates (cx, cy).
    Uses simple word-overlap scoring — good enough as a last resort.
    """
    q_words = {w.lower() for w in query.split() if len(w) > 1}

    def score(el: dict) -> int:
        label = el.get("label", "").lower()
        return sum(1 for w in q_words if w in label)

    best = max(elements, key=score)
    cx = best.get("cx", 0)
    cy = best.get("cy", 0)
    return Action(
        action_type="tap", x=cx, y=cy,
        reasoning=f"acc auto-picked for {query!r}: '{best.get('label')}' at ({cx},{cy})",
    )


# Task patterns that mean "open / launch / tap an app"
_OPEN_APP_NORMALIZE = {"檔案": "files", "設定": "settings", "相片": "photos", "日曆": "calendar"}
_OPEN_APP_BUNDLE_SUBSTR = {
    "files": ["documentsapp", "files"],
    "settings": ["preferences", "settings"],
    "photos": ["mobileslideshow", "photos"],
    "calendar": ["mobilecal", "calendar"],
}

# All phrasings that mean "open / tap / launch app X".
# Each pattern must have exactly one capture group for the app name.
_APP_TASK_PATTERNS = [
    r"打開\s*([^\s]+)(?:\s*app)?",
    r"open\s+(\w+)(?:\s+app)?",
    r"點\s*([^\s]+)(?:\s*app)?",       # 點 watch app / 點watch
    r"點擊\s*([^\s]+)(?:\s*app)?",     # 點擊 watch app
    r"tap\s+(\w+)(?:\s*app)?",         # tap watch / tap watch app
    r"click\s+(\w+)(?:\s*app)?",       # click watch
    r"launch\s+(\w+)(?:\s*app)?",      # launch watch
]


def _extract_app_target(task: str) -> Optional[str]:
    """
    Return the normalised app name from any recognised app-task phrasing,
    or None if the task doesn't look like an open/tap-app command.
    """
    t = task.strip()
    for pat in _APP_TASK_PATTERNS:
        m = re.search(pat, t, re.I)
        if m:
            x = m.group(1).strip().lower()
            x_norm = _OPEN_APP_NORMALIZE.get(x, x)
            if len(x_norm) >= 2:
                return x_norm
    return None


def _open_app_tap_if_visible(task: str, acc_elements: list) -> Optional[Action]:
    """
    If task is an open/tap-app command and the app icon is visible as a
    Button in elements, return a direct tap action — no Qwen needed.
    """
    if not acc_elements:
        return None
    x_norm = _extract_app_target(task)
    if x_norm is None:
        return None
    keywords = [x_norm] + _OPEN_APP_BUNDLE_SUBSTR.get(x_norm, [])
    visible_buttons = [
        e for e in acc_elements
        if e.get("visible", True) and e.get("type") == "Button"
    ]
    for el in visible_buttons:
        label = el.get("label", "").lower()
        if any(kw in label for kw in keywords):
            cx, cy = el.get("cx", 0), el.get("cy", 0)
            log.info(
                f"App icon '{el.get('label')}' visible in elements → "
                f"direct tap({cx},{cy}), skip Qwen"
            )
            return Action(
                action_type="tap", x=cx, y=cy,
                reasoning=f"App icon '{el.get('label')}' visible in elements, tapped directly.",
            )
    return None


def _url_task_done_from_elements(task: str, acc_elements: list[dict]) -> Optional[Action]:
    """
    Fast-path for URL tasks: if target host is visible in accessibility labels/values,
    treat as loaded and done.
    """
    m = re.search(r"https?://[^\s'\"）)]+", task, re.I)
    if not m:
        return None
    try:
        host = (urlparse(m.group(0)).netloc or "").lower()
    except Exception:
        host = ""
    if not host:
        return None
    host = host[4:] if host.startswith("www.") else host
    visible = [e for e in acc_elements if e.get("visible", True)]
    haystack = " ".join(
        f"{e.get('label', '')} {e.get('value', '')}".strip()
        for e in visible
    ).lower()
    if host in haystack:
        return Action(
            action_type="done",
            result=f"Target URL host '{host}' is visible on screen.",
            reasoning="Deterministic verification: accessibility labels/values include the target host.",
        )
    return None


def _url_navigation_fast_action(
    task: str,
    acc_elements: list[dict],
    keyboard_open: bool,
    history: list[dict],
    foreground_app: Optional[dict] = None,
) -> Optional[Action]:
    """
    Deterministic fast-path for URL navigation tasks:
      1) If keyboard is open -> input URL (or press ENTER after input)
      2) Else tap address/search field by accessibility label
    """
    m = re.search(r"https?://[^\s'\"）)]+", task, re.I)
    if not m:
        return None
    bid = (foreground_app or {}).get("bundle_id", "").lower()
    name = (foreground_app or {}).get("name", "").lower()
    if "safari" not in bid and "safari" not in name:
        return None

    target_url = m.group(0).strip()
    last_action = str(history[-1].get("action", "")) if history else ""
    last2 = " | ".join(str(h.get("action", "")) for h in history[-2:])

    if keyboard_open:
        if target_url not in last2:
            return Action(
                action_type="input_text",
                text=target_url,
                reasoning="URL task fast-path: keyboard is open, input target URL directly.",
            )
        if "input_text" in last_action and "press_key(ENTER)" not in last2:
            return Action(
                action_type="press_key",
                key="ENTER",
                reasoning="URL task fast-path: submit typed URL with ENTER.",
            )
        return None

    visible = [e for e in acc_elements if e.get("visible", True)]
    candidates = []
    for el in visible:
        label = (el.get("label", "") or "").lower()
        etype = (el.get("type", "") or "").lower()
        if not label:
            continue
        score = 0
        if any(k in label for k in ("address", "search", "url", "網址", "網站")):
            score += 3
        if any(k in label for k in ("enter website", "search or enter", "網址列", "address")):
            score += 2
        if etype in ("textfield", "searchfield"):
            score += 2
        if score > 0:
            # Prefer top navigation field if multiple candidates exist.
            y = int(el.get("cy", 437))
            score += 1 if y < 180 else 0
            candidates.append((score, el))

    if candidates:
        _, best = sorted(candidates, key=lambda p: p[0], reverse=True)[0]
        candidate_action = f"tap({int(best.get('cx', 201))}, {int(best.get('cy', 100))})"
        if candidate_action == last_action:
            return None
        return Action(
            action_type="tap",
            x=int(best.get("cx", 201)),
            y=int(best.get("cy", 100)),
            reasoning=f"URL task fast-path: tap address field '{best.get('label', '')}'.",
        )
    return None


def _open_app_done_from_elements(task: str, acc_elements: list) -> Optional[Action]:
    """
    Pure-elements fast-path for open/tap-app tasks.
    If elements have Tab Bar + (No Recents | in-app empty state) AND an "X | Application"
    label that matches the target app → done, no MDB needed.

    Example elements when inside Files:
      Files | Application
      No Recents | StaticText
      Tab Bar | Group
    """
    if not acc_elements:
        return None
    x_norm = _extract_app_target(task.strip())
    if x_norm is None:
        return None

    visible = [e for e in acc_elements if e.get("visible", True)]
    labels_lower = " ".join(e.get("label", "") for e in visible).lower()

    has_tab_bar = "tab bar" in labels_lower
    has_in_app_state = "no recents" in labels_lower or "recently opened" in labels_lower
    if not (has_tab_bar and has_in_app_state):
        return None

    # Look for "X | Application" where X matches the target app name
    keywords = [x_norm] + _OPEN_APP_BUNDLE_SUBSTR.get(x_norm, [])
    app_label = next(
        (e.get("label", "") for e in visible
         if "application" in e.get("type", "").lower() or
            (e.get("label", "") and any(kw in e.get("label", "").lower() for kw in keywords))),
        None
    )
    if app_label and any(kw in app_label.lower() for kw in keywords):
        return Action(
            action_type="done",
            result=f"Elements confirm '{app_label}' is open (Tab Bar + No Recents detected).",
            reasoning="Accessibility elements show in-app UI for target app; done without LLM or MDB.",
        )
    return None


def _open_app_done_if_foreground(
    task: str, foreground_app: dict, acc_elements: list
) -> Optional[Action]:
    """
    Fast-path for open/tap-app tasks: elements-first, MDB as fallback confirmation.
    Handles all task phrasings: 打開 X app, open X, 點 X app, tap X, 點擊 X …
    Priority: pure elements check (no stale MDB issues) → MDB + elements combined.
    """
    # Try pure-elements path first (doesn't depend on MDB at all)
    action = _open_app_done_from_elements(task, acc_elements)
    if action:
        return action

    # Fallback: MDB foreground + elements showing in-app
    if not foreground_app:
        return None
    labels_lower = " ".join(
        e.get("label", "") for e in acc_elements if e.get("visible", True)
    ).lower()
    has_tab_bar = "tab bar" in labels_lower
    has_in_app = "no recents" in labels_lower or "application" in labels_lower
    if not (has_tab_bar and has_in_app):
        return None

    x_norm = _extract_app_target(task.strip())
    if x_norm is None:
        return None
    name = (foreground_app.get("name") or "").lower()
    bid = (foreground_app.get("bundle_id") or "").lower()
    keywords = [x_norm] + _OPEN_APP_BUNDLE_SUBSTR.get(x_norm, [])
    if any(kw in name or kw in bid for kw in keywords):
        return Action(
            action_type="done",
            result=f"App '{foreground_app.get('name', '')}' in foreground and elements show in-app (MDB+AX).",
            reasoning="Foreground matches task and accessibility shows in-app UI; done without LLM.",
        )
    return None


def _extract_screen_label(action: Action) -> str:
    """Extract a short screen label from Qwen's reasoning or action."""
    if action.reasoning:
        # Take first sentence, truncate
        first = action.reasoning.split(".")[0].strip()
        return first[:60] if first else "unknown screen"
    return f"after {action}"



def _swipe_direction(action: Action) -> str:
    """
    Classify a swipe action:
      "scroll_down"  — finger moves up (y decreases) → content scrolls down
      "scroll_up"    — finger moves down → content scrolls up
      "scroll_right" — finger moves left → content scrolls right (next page)
      "scroll_left"  — finger moves right → content scrolls left (prev page)
      "navigate"     — large horizontal swipe (page/carousel navigation)
    """
    if action.action_type != "swipe":
        return ""
    dx = (action.x2 or 0) - (action.x or 0)
    dy = (action.y2 or 0) - (action.y or 0)
    if abs(dy) >= abs(dx):
        return "scroll_down" if dy < 0 else "scroll_up"
    # Horizontal swipe — treat as navigation (page swipe) if large, else horizontal scroll
    return "navigate" if abs(dx) > 150 else ("scroll_right" if dx < 0 else "scroll_left")


def _is_navigation_action(action: Action) -> bool:
    """True if this action navigates to a new screen (not a scroll)."""
    if action.action_type == "tap":
        return True
    if action.action_type == "launch_app":
        return True
    if action.action_type == "swipe":
        return _swipe_direction(action) == "navigate"
    return False


def _is_back_action(action: Action) -> bool:
    return action.action_type == "press_key" and action.key in ("BACK", "HOME")


class Orchestrator:
    def __init__(
        self,
        mdb: DeviceBridge,
        qwen: QwenAgent,
        ui_agent: UIAgent,
        max_steps: int = 20,
        step_delay_ms: int = 800,
        on_step: Optional[Callable[[StepLog], None]] = None,
    ) -> None:
        self.mdb = mdb
        self.qwen = qwen
        self.ui_agent = ui_agent
        self.max_steps = max_steps
        self.step_delay_ms = step_delay_ms
        self.on_step = on_step

    def _is_on_home_screen(self, device_udid: str) -> bool:
        """
        True if SpringBoard is the foreground app (home screen / app grid).
        SpringBoard bundle ID: com.apple.springboard
        """
        try:
            fg = self.mdb.get_foreground_app(device_udid)
            if fg:
                bid = (fg.get("bundle_id") or "").lower()
                return "springboard" in bid
        except Exception:
            pass
        return False

    def run(self, task: str, device_udid: str, reset: bool = True) -> TaskResult:
        """
        Execute *task* on *device_udid*.

        reset=True  (default / ``run`` command): press HOME first, navigate to the
                    main home page, then start the ReAct loop.  Guarantees a clean,
                    known-good starting state.

        reset=False (``act`` command): start from whatever screen is currently
                    visible.  Use this when you want to continue from a previous
                    session or when the caller (e.g. an MCP client) has already
                    placed the device in the desired state.
        """
        logs: list[StepLog] = []
        history: list[dict] = []

        log.info(f"Starting task: {task!r} on device {device_udid[:12]}...  reset={reset}")
        task_plan: Optional[str] = None

        if reset:
            # ── Pre-flight: ensure we start from the MAIN home screen page ──────
            # Main home page: has app icon Buttons (Files, Contacts…) AND ≤ 12 elements.
            # Today View: also has dock but has 13+ elements (widgets). Distinguish by count.
            def _on_main_home() -> bool:
                try:
                    els = self.mdb.list_elements(device_udid)
                    visible = [e for e in els if e.get("visible", True)]
                    # Main home: small element count + at least one app icon Button
                    has_app_icons = any(
                        e.get("type") == "Button" and len(e.get("label", "")) > 2
                        for e in visible
                    )
                    return has_app_icons and len(visible) <= 12
                except Exception:
                    return False

            try:
                if not self._is_on_home_screen(device_udid):
                    log.info("Not on home screen — pressing HOME to exit foreground app.")
                    self.mdb.press_key(device_udid, "HOME")
                    time.sleep(0.9)

                if not _on_main_home():
                    # Today View is to the LEFT of page 0; swipe LEFT (350→50) to go to page 0.
                    log.info("On a side page (Today View?) — swiping left to main home page.")
                    self.mdb.swipe(device_udid, 350, 437, 50, 437, 300)
                    time.sleep(0.6)

                if not _on_main_home():
                    log.info("Still not on main home — pressing HOME once more.")
                    self.mdb.press_key(device_udid, "HOME")
                    time.sleep(0.6)

                if not _on_main_home():
                    log.info("Trying swipe left once more to reach page 0.")
                    self.mdb.swipe(device_udid, 350, 437, 50, 437, 300)
                    time.sleep(0.5)
            except Exception as e:
                log.warning(f"Pre-flight HOME/swipe failed (non-fatal): {e}")
        else:
            log.info("reset=False — skipping pre-flight, continuing from current screen.")

        # ── Gesture fast-path ────────────────────────────────────────────────────
        # For atomic gesture tasks (往右滑, swipe down, back, …) we skip the
        # entire ReAct loop: execute the mapped MDB action once, then done.
        # This gives deterministic direction (no Qwen hallucination) and
        # instant completion (no verification needed for a pure gesture).
        gesture_action = _detect_gesture(task)
        if gesture_action is not None:
            log.info(f"Gesture fast-path: {task!r} → {gesture_action}")
            step_log = StepLog(step=1, action=gesture_action)
            if self.on_step:
                self.on_step(step_log)
            try:
                self.mdb.execute(device_udid, gesture_action)
                log.info("Gesture executed OK")
                time.sleep(0.3)
            except Exception as e:
                log.error(f"Gesture execute failed: {e}")
                return TaskResult(
                    success=False, task=task, steps_taken=1,
                    conclusion=f"Gesture failed: {e}",
                    plan=None, logs=[step_log], blocked_reason=str(e),
                    device_udid=device_udid,
                )
            return TaskResult(
                success=True, task=task, steps_taken=1,
                conclusion=f"Gesture '{task}' executed.",
                plan=None, logs=[step_log], device_udid=device_udid,
            )

        # Navigation stack root — label reflects whether we know the start point
        root_label = "Root / Home Screen" if reset else "Current Screen (unknown)"
        nav_stack: list[NavFrame] = [
            NavFrame(depth=0, screen_label=root_label, action_taken=None, step=0)
        ]
        last_action_str: Optional[str] = None
        same_action_count = 0

        for step in range(1, self.max_steps + 1):
            step_log = StepLog(step=step, action=Action(action_type="error"))
            log.info(f"── Step {step}/{self.max_steps} ──────────────────")
            log.info(f"Nav depth: {len(nav_stack)-1}  path: {' → '.join(f.screen_label for f in nav_stack)}")

            # ── 1. Screenshot ─────────────────────────────────────────────────
            log.info("Taking screenshot...")
            t_shot = time.time()
            try:
                shot = self.mdb.screenshot(device_udid)
                step_log.screenshot_base64 = shot.base64
                log.info(f"Screenshot OK  {len(shot.png_bytes)//1024}KB  ({time.time()-t_shot:.2f}s)")
            except Exception as e:
                step_log.error = f"Screenshot failed: {e}"
                logs.append(step_log)
                return TaskResult(
                    success=False, task=task, steps_taken=step,
                    conclusion=f"Screenshot failed: {e}",
                    plan=task_plan, logs=logs, blocked_reason=str(e),
                    device_udid=device_udid,
                )

            # ── 1b. Dialog detection + auto-dismiss ───────────────────────────
            # Check before every step. If a system dialog is blocking:
            #   - Determine if the task NEEDS the permission
            #   - If not, auto-dismiss with the recommended button (no Qwen needed)
            #   - If yes, pass dialog info to Qwen to decide
            dialog_info: Optional[dict] = None
            try:
                dialog_info = self.mdb.detect_system_dialog(device_udid)
                if dialog_info:
                    btn_names = [b["label"] for b in dialog_info["buttons"]]
                    log.info(f"Dialog detected: {dialog_info['type']!r} — "
                             f"msg={dialog_info['message'][:60]!r}  "
                             f"buttons={btn_names}")

                    # Keywords that suggest the task REQUIRES the permission
                    _NEEDS_PERMISSION = {
                        "location": ["location", "map", "gps", "地圖", "位置", "地點"],
                        "camera":   ["camera", "photo", "video", "相機", "拍照", "相片"],
                        "mic":      ["microphone", "record", "voice", "麥克風", "錄音"],
                        "contact":  ["contact", "通訊錄"],
                        "notify":   ["notification", "通知"],
                    }
                    task_l = task.lower()
                    needs = any(
                        kw in task_l
                        for keywords in _NEEDS_PERMISSION.values()
                        for kw in keywords
                    )

                    if not needs:
                        # Auto-dismiss: find the dismiss button and tap it
                        dismiss = next(
                            (b for b in dialog_info["buttons"]
                             if b["label"] == dialog_info["dismiss_label"]),
                            dialog_info["buttons"][-1],
                        )
                        log.info(f"Auto-dismissing dialog (task doesn't need permission): "
                                 f"tap '{dismiss['label']}' at ({dismiss['cx']}, {dismiss['cy']})")
                        dismiss_action = Action(
                            action_type="tap",
                            x=dismiss["cx"], y=dismiss["cy"],
                            reasoning=f"Auto-dismiss dialog: '{dismiss['label']}'",
                        )
                        step_log.action = dismiss_action
                        logs.append(step_log)
                        history.append({"step": step, "action": str(dismiss_action)})
                        if self.on_step:
                            self.on_step(step_log)
                        try:
                            self.mdb.execute(device_udid, dismiss_action)
                            log.info("Dialog dismissed OK")
                        except Exception as e:
                            log.warning(f"Dialog dismiss failed: {e}")
                        time.sleep(0.5)
                        dialog_info = None  # cleared — proceed to Qwen
                        # Fall through to Qwen so it can proceed with the original task
            except Exception as e:
                log.debug(f"Dialog detection error (non-fatal): {e}")

            # ── 1c. Fast-path for pure navigation tasks ────────────────────────
            # If task is "go home" and no dialog is present, skip Qwen and just HOME.
            _GOTO_HOME_KEYWORDS = [
                "回到home", "回主畫面", "回首頁", "回home", "回到首頁",
                "go home", "home screen", "launcher", "主畫面", "首頁",
                "press home", "按home",
            ]
            if not dialog_info and any(kw in task.lower() for kw in _GOTO_HOME_KEYWORDS):
                if step == 1:
                    log.info("Fast-path: 'go home' task → pressing HOME directly")
                    action = Action(
                        action_type="press_key", key="HOME",
                        reasoning="Go-home task: press HOME directly",
                    )
                    step_log.action = action
                    logs.append(step_log)
                    history.append({"step": step, "action": str(action)})
                    if self.on_step:
                        self.on_step(step_log)
                    log.info(f"Executing: {action}")
                    try:
                        self.mdb.execute(device_udid, action)
                        log.info("Action executed OK")
                    except Exception as e:
                        log.error(f"Execute failed: {e}")
                    # HOME for go-home task = done
                    log.info("HOME pressed — task complete.")
                    return TaskResult(
                        success=True, task=task, steps_taken=step,
                        conclusion="Returned to home screen successfully.",
                        plan=task_plan, logs=logs, device_udid=device_udid,
                    )

            # ── 1d. Accessibility elements + scroll info snapshot ─────────────
            # Fetch ALL labeled elements (including off-screen) so Qwen can:
            #   1. Semantic-match task language to screen labels (no translation table)
            #   2. See off-screen elements and know scrolling is needed
            acc_elements: list[dict] = []
            scroll_info: dict = {}
            keyboard_open: bool = False
            try:
                acc_elements = self.mdb.list_elements(device_udid)
                visible_count = sum(1 for e in acc_elements if e.get("visible", True))
                offscreen_count = len(acc_elements) - visible_count
                # Keyboard is open if single-letter Button elements are present
                keyboard_open = any(
                    e.get("type") == "Button" and len(e.get("label", "").strip()) == 1
                    for e in acc_elements
                )
                if keyboard_open:
                    log.info(f"Accessibility: {visible_count} visible + {offscreen_count} off-screen "
                             f"(keyboard open)")
                else:
                    log.info(f"Accessibility: {visible_count} visible + {offscreen_count} off-screen elements")
                if acc_elements:
                    scroll_info = self.mdb.get_scroll_info(device_udid)
                    if scroll_info.get("has_content_below") or scroll_info.get("has_content_above"):
                        log.info(f"Scroll: content_below={scroll_info.get('has_content_below')} "
                                 f"content_above={scroll_info.get('has_content_above')} "
                                 f"total_h≈{scroll_info.get('content_height_pt')}pt")
            except Exception as e:
                log.debug(f"list_elements error (non-fatal): {e}")

            # ── 1e. Keyboard-open fast-path for input_text / type / 輸入 ─────────
            # When the keyboard is already open (e.g. after a previous act tap),
            # we can type immediately without asking Qwen.
            # Handles:  input_text X / type X / 輸入 X  (no field-tap needed).
            _input_text_val: Optional[str] = None
            if keyboard_open:
                _input_text_val = _extract_input_text(task)
            if _input_text_val and keyboard_open:
                log.info(
                    f"Keyboard open + input task — typing {_input_text_val!r} directly (skip Qwen)"
                )
                action = Action(
                    action_type="input_text",
                    text=_input_text_val,
                    reasoning=f"Keyboard already open; typing {_input_text_val!r} directly.",
                )
            else:
                action = None   # will be filled by fast-paths or Qwen below

            # ── 2. Qwen phase-1 (or MDB fast-path for "打開 X app") ─────────────
            set_current_screenshot(shot.png_bytes)
            foreground_app = self.mdb.get_foreground_app(device_udid)
            if foreground_app:
                log.debug(f"Foreground app: {foreground_app.get('bundle_id')} ({foreground_app.get('name')})")
            if action is not None:
                pass   # keyboard fast-path already set action
            elif (app_done := _open_app_done_if_foreground(task, foreground_app or {}, acc_elements)) is not None:
                action = app_done
                log.info(f"MDB foreground matches task → done (skip Qwen): {action.result}")
            elif (tap_action := _open_app_tap_if_visible(task, acc_elements)) is not None:
                action = tap_action
            elif (url_done := _url_task_done_from_elements(task, acc_elements)) is not None:
                action = url_done
                log.info(f"URL host visible in accessibility → done (skip Qwen): {action.result}")
            elif (url_fast := _url_navigation_fast_action(
                task, acc_elements, keyboard_open, history, foreground_app
            )) is not None:
                action = url_fast
                log.info(f"URL task fast-path selected action (skip Qwen): {action}")
            else:
                log.info("Qwen analyzing screen...")
                t_qwen = time.time()
                try:
                    action = self.qwen.decide(
                        task=task,
                        screenshot_data_url=shot.data_url,
                        screenshot_url=get_screenshot_url(),
                        ui_elements=acc_elements,
                        history=history,
                        step=step,
                        max_steps=self.max_steps,
                        nav_stack=nav_stack,
                        dialog_info=dialog_info,
                        scroll_info=scroll_info,
                        keyboard_open=keyboard_open,
                        foreground_app=foreground_app,
                    )
                    log.info(f"Qwen phase-1 ({time.time()-t_qwen:.1f}s): {action}")
                except Exception as e:
                    logs.append(step_log)
                    log.error(f"Qwen phase-1 failed: {e}")
                    return TaskResult(
                        success=False, steps_taken=step,
                        conclusion=f"Qwen reasoning failed: {e}",
                        plan=task_plan, logs=logs, blocked_reason=str(e),
                        device_udid=device_udid, task=task,
                    )

            # ── 2b. Snap tap to nearest accessible element ────────────────────
            # Qwen sometimes hallucinates coordinates from the screenshot.
            # When we have accessibility elements (which already carry correct
            # cx/cy from the system), snap any tap that is out-of-bounds or
            # suspiciously far from every element to the closest match by label.
            if (action.action_type == "tap" and acc_elements and
                    (action.x is None or action.y is None or
                     action.x > 402 or action.y > 874)):
                visible_els = [e for e in acc_elements if e.get("visible", True)]
                if visible_els:
                    best = min(
                        visible_els,
                        key=lambda e: (
                            (e.get("cx", 201) - (action.x or 201)) ** 2 +
                            (e.get("cy", 437) - (action.y or 437)) ** 2
                        ),
                    )
                    old_coords = (action.x, action.y)
                    action = Action(
                        action_type="tap",
                        x=best["cx"], y=best["cy"],
                        reasoning=action.reasoning,
                    )
                    log.warning(
                        f"Tap coords {old_coords} out of bounds — "
                        f"snapped to nearest element '{best.get('label')}' "
                        f"at ({best['cx']},{best['cy']})"
                    )

            # ── 3. Ground loop ────────────────────────────────────────────────
            # Qwen emits ground(query) when it cannot determine exact coordinates.
            #
            # Resolution priority:
            #   A. acc_elements already fetched in step 1d
            #      → pass to Qwen phase-2 as context; let Qwen pick semantically
            #      → this covers language bridging (設定→Settings) without hardcoding
            #   B. acc_elements is empty (game / canvas / custom view)
            #      → fall back to UI-UG visual grounding + Qwen phase-2
            ground_count = 0
            while action.action_type == "ground" and ground_count < MAX_GROUND_PER_STEP:
                ground_count += 1
                query = action.ground_query or "visible UI elements"
                log.info(f"Ground {ground_count}/{MAX_GROUND_PER_STEP}: {query!r}")

                if acc_elements:
                    # ── Strategy A: Qwen picks from accessibility elements ─────
                    # Accessibility elements are already in logical point coordinates.
                    # We have the full list — let Qwen do semantic matching.
                    log.info(f"Accessibility has {len(acc_elements)} elements — "
                             "asking Qwen to select the best match")
                    set_current_screenshot(shot.png_bytes)
                    t2 = time.time()
                    try:
                        action = self.qwen.decide(
                            task=task,
                            screenshot_data_url=shot.data_url,
                            screenshot_url=get_screenshot_url(),
                            ui_elements=acc_elements,
                            history=history,
                            step=step,
                            max_steps=self.max_steps,
                            grounding_result=acc_elements,
                            nav_stack=nav_stack,
                            ground_query=query,
                            foreground_app=foreground_app,
                        )
                        log.info(f"Qwen phase-2/acc ({time.time()-t2:.1f}s): {action}")
                    except Exception as e:
                        log.warning(f"Qwen phase-2 exception: {e}")
                        action = Action(action_type="error", result=str(e))

                    if action.action_type in ("ground", "error"):
                        action = _best_acc_match(acc_elements, query)
                        log.warning(f"Phase-2 acc fallback — auto-picked: {action}")

                else:
                    # ── Strategy B: UI-UG visual grounding (no accessibility) ──
                    log.info(f"No accessibility elements — using UI-UG for {query!r}")
                    set_current_screenshot(shot.png_bytes)
                    try:
                        elements = self.ui_agent.grounding_targeted(
                            shot.png_bytes, query, screenshot_url=get_screenshot_url()
                        )
                        step_log.ui_elements = elements
                        log.info(f"UI-UG: {len(elements)} element(s) for {query!r}")
                    except Exception as e:
                        elements = []
                        log.warning(f"UI-UG failed: {e}")
                    element_dicts = [el.to_dict() for el in elements]

                    # Qwen phase-2 picks from UI-UG results
                    log.info("Qwen phase-2/visual: deciding from UI-UG grounding...")
                    set_current_screenshot(shot.png_bytes)
                    t2 = time.time()
                    try:
                        action = self.qwen.decide(
                            task=task,
                            screenshot_data_url=shot.data_url,
                            screenshot_url=get_screenshot_url(),
                            ui_elements=element_dicts,
                            history=history,
                            step=step,
                            max_steps=self.max_steps,
                            grounding_result=element_dicts,
                            nav_stack=nav_stack,
                            ground_query=query,
                            foreground_app=foreground_app,
                        )
                        log.info(f"Qwen phase-2/visual ({time.time()-t2:.1f}s): {action}")
                    except Exception as e:
                        log.warning(f"Qwen phase-2 exception: {e}")
                        action = Action(action_type="error", result=str(e))

                    if action.action_type in ("ground", "error") and element_dicts:
                        action = _best_tap_from_elements(element_dicts, query)
                        log.warning(f"Phase-2 visual fallback — auto-picked: {action}")

            if action.action_type == "ground":
                # Ground loop exhausted — force backtrack to parent screen
                log.warning("Ground loop limit — forcing BACK to previous screen")
                action = Action(
                    action_type="press_key", key="BACK",
                    reasoning="Could not find target. Going back to try a different path.",
                )

            # ── 4. Dead-end detection: same action repeated too many times ────
            current_action_str = str(action)
            if current_action_str == last_action_str:
                same_action_count += 1
            else:
                same_action_count = 1
                last_action_str = current_action_str

            if same_action_count >= MAX_SAME_ACTION_REPEAT and not action.done:
                log.warning(
                    f"Same action repeated {same_action_count}x ({action}) — "
                    "forcing HOME to escape dead end"
                )
                action = Action(
                    action_type="press_key", key="HOME",
                    reasoning=f"Stuck: {action} repeated {same_action_count} times without progress.",
                )
                same_action_count = 0

            # ── 5. Log step ───────────────────────────────────────────────────
            prev_action_str = str(history[-1]["action"]) if history else ""
            step_log.action = action
            logs.append(step_log)
            history.append({
                "step": step,
                "action": str(action),
                "nav_depth": len(nav_stack) - 1,
            })

            if self.on_step:
                self.on_step(step_log)

            # ── 5b. Guard: input_text → done without ENTER ───────────────────
            # If Qwen calls done immediately after input_text (e.g. typed a URL
            # but forgot to press ENTER), intercept and inject press_key(ENTER).
            last_was_input = "input_text" in prev_action_str
            if action.action_type == "done" and last_was_input:
                deterministic_done = (
                    (action.reasoning or "").startswith("Deterministic verification")
                    or "Target URL host" in (action.result or "")
                )
                if deterministic_done:
                    log.info("Deterministic done signal after input_text — accepting done without ENTER injection.")
                else:
                    log.warning(
                        "Qwen called done right after input_text — "
                        "injecting press_key(ENTER) to submit"
                    )
                    enter_action = Action(
                        action_type="press_key", key="ENTER",
                        reasoning="Auto-injected ENTER after input_text before done.",
                    )
                    try:
                        self.mdb.execute(device_udid, enter_action)
                        history.append({"step": step, "action": str(enter_action), "auto_injected": True})
                        time.sleep(0.5)
                        # Continue the loop; Qwen will re-evaluate on the next step
                        continue
                    except Exception as e:
                        log.warning(f"Auto ENTER injection failed: {e}")

            # ── 6. Terminal actions ────────────────────────────────────────────
            if action.action_type == "done":
                # ── Done verification: re-screenshot + ask Qwen to confirm ──
                # Prevents false positives where Qwen hallucinates completion.
                log.info(f"Qwen says done: '{action.result}' — verifying with fresh screenshot...")
                try:
                    verify_shot = self.mdb.screenshot(device_udid)
                    set_current_screenshot(verify_shot.png_bytes)
                    verify_elements = self.mdb.list_elements(device_udid)
                    verify_foreground_app = self.mdb.get_foreground_app(device_udid)

                    # Deterministic verification first (fast and stable).
                    deterministic_done = (
                        _open_app_done_if_foreground(
                            task,
                            verify_foreground_app or {},
                            verify_elements,
                        )
                        or _url_task_done_from_elements(task, verify_elements)
                    )
                    if deterministic_done and deterministic_done.action_type == "done":
                        log.info(f"Task done (deterministic verify): {deterministic_done.result}")
                        return TaskResult(
                            success=True, task=task, plan=task_plan,
                            steps_taken=step,
                            conclusion=deterministic_done.result or action.result or "Task completed.",
                            logs=logs, device_udid=device_udid,
                        )

                    verify_action = self.qwen.decide(
                        task=f"VERIFY ONLY: Is this task actually complete? Task: {task}\n"
                             f"Qwen previously said done: '{action.result}'\n"
                             f"Look at the CURRENT screenshot and elements carefully. "
                             f"If the task result is clearly visible on screen → output done. "
                             f"If NOT (e.g. wrong page, URL not loaded, content missing) → output the next action needed.",
                        screenshot_data_url=verify_shot.data_url,
                        screenshot_url=get_screenshot_url(),
                        ui_elements=verify_elements,
                        history=history,
                        step=step,
                        max_steps=self.max_steps,
                        nav_stack=nav_stack,
                        foreground_app=verify_foreground_app,
                        force_thinking=False,
                    )
                    log.info(f"Verification result: {verify_action}")
                    if verify_action.action_type == "done":
                        log.info(f"Task done (verified): {verify_action.result or action.result}")
                        return TaskResult(
                            success=True, task=task, plan=task_plan,
                            steps_taken=step,
                            conclusion=verify_action.result or action.result or "Task completed.",
                            logs=logs, device_udid=device_udid,
                        )
                    else:
                        log.warning("Verification failed — continuing loop with corrected action.")
                        action = verify_action
                        # Fall through to execute the corrected action
                except Exception as e:
                    log.warning(f"Verification screenshot failed ({e}) — accepting original done.")
                    return TaskResult(
                        success=True, task=task, plan=task_plan,
                        steps_taken=step,
                        conclusion=action.result or "Task completed.",
                        logs=logs, device_udid=device_udid,
                    )
            if action.action_type == "error":
                log.warning(f"Task error: {action.result}")
                return TaskResult(
                    success=False, task=task, steps_taken=step,
                    conclusion=action.result or "Task failed.",
                    plan=task_plan, logs=logs, blocked_reason=action.result,
                    device_udid=device_udid,
                )

            # ── 7. Execute ────────────────────────────────────────────────────
            log.info(f"Executing: {action}")
            try:
                self.mdb.execute(device_udid, action)
                log.info("Action executed OK")
            except Exception as e:
                log.error(f"Execute failed: {e}")
                step_log.error = str(e)
                # Don't terminate — let Qwen see the failure and recover
                history[-1]["error"] = str(e)
                time.sleep(0.3)
                continue

            # ── 7b. act mode: one action per call → return immediately ────────
            # `act` (reset=False) is designed for MCP / vibe-coding callers that
            # issue ONE atomic command at a time (tap, swipe, scroll, pan, back…).
            # The caller uses `screen` to observe the result and decide next step.
            # We never verify or loop — executing the action IS the success signal.
            #
            # Exception — input/type tasks: "輸入 X in Y" is semantically ONE
            # intent but physically TWO MDB calls:
            #   1. tap(field)      → focuses field, opens keyboard
            #   2. input_text(X)   → types the content
            # After the tap we extract X from the task, wait for the keyboard,
            # and inject input_text directly — no second Qwen call needed.
            if not reset:
                _is_input_task = any(
                    kw in task.lower()
                    for kw in ("輸入", "input_text", "input ", "type ", "打字", "打入")
                )
                if _is_input_task and step == 1 and action.action_type == "tap":
                    input_text_val = _extract_input_text(task)
                    if input_text_val:
                        time.sleep(0.8)   # wait for keyboard animation
                        type_action = Action(
                            action_type="input_text",
                            text=input_text_val,
                            reasoning=f"act input task: type {input_text_val!r}",
                        )
                        log.info(f"act mode input task: typing {input_text_val!r}")
                        try:
                            self.mdb.execute(device_udid, type_action)
                            log.info("Input text executed OK")
                        except Exception as e:
                            log.error(f"Input text failed: {e}")
                            return TaskResult(
                                success=False, task=task, steps_taken=step,
                                conclusion=f"Typed {input_text_val!r} but execute failed: {e}",
                                plan=None, logs=logs, device_udid=device_udid,
                                blocked_reason=str(e),
                            )
                        return TaskResult(
                            success=True, task=task, steps_taken=step,
                            conclusion=f"Typed {input_text_val!r} into field.",
                            plan=None, logs=logs, device_udid=device_udid,
                        )
                    # No text extracted — fall through to normal step 2
                    log.info(
                        "act mode: tap for input task but no text extracted — "
                        "continuing to step 2."
                    )
                else:
                    time.sleep(0.3)   # let screen settle before caller polls
                    log.info("act mode: action executed — returning done (one-shot).")
                    return TaskResult(
                        success=True, task=task, steps_taken=step,
                        conclusion=f"Action completed: {action}",
                        plan=None, logs=logs, device_udid=device_udid,
                    )

            # ── 8. Update navigation stack ────────────────────────────────────
            if _is_navigation_action(action):
                # Pushed deeper — record this screen transition
                label = _extract_screen_label(action)
                nav_stack.append(NavFrame(
                    depth=len(nav_stack),
                    screen_label=label,
                    action_taken=action,
                    step=step,
                ))
                log.info(f"Nav push → depth {len(nav_stack)-1}: {label!r}")

            elif action.action_type == "swipe":
                # Scroll within the same screen — update scroll offset in current frame
                direction = _swipe_direction(action)
                current = nav_stack[-1]
                dx = (action.x2 or 0) - (action.x or 0)
                dy = (action.y2 or 0) - (action.y or 0)
                if direction in ("scroll_down", "scroll_up"):
                    current.scroll.scroll_y -= dy   # dy<0 → scrolled down → offset increases
                    current.scroll.at_top    = not scroll_info.get("has_content_above", False)
                    current.scroll.at_bottom = not scroll_info.get("has_content_below", True)
                    current.scroll.at_top    = current.scroll.scroll_y <= 0
                    if scroll_info.get("content_height_pt"):
                        current.scroll.content_height_hint = scroll_info["content_height_pt"]
                    log.info(f"Scroll {direction}: offset_y now ~{current.scroll.scroll_y}pt  "
                             f"{'(at bottom)' if current.scroll.at_bottom else ''}")
                elif direction in ("scroll_left", "scroll_right"):
                    current.scroll.scroll_x -= dx
                    current.scroll.at_left  = current.scroll.scroll_x <= 0
                    if scroll_info.get("content_width_pt"):
                        current.scroll.content_width_hint = scroll_info["content_width_pt"]
                    log.info(f"Scroll {direction}: offset_x now ~{current.scroll.scroll_x}pt")

            elif action.action_type == "press_key":
                if action.key == "BACK" and len(nav_stack) > 1:
                    popped = nav_stack.pop()
                    log.info(f"Nav pop ← back from {popped.screen_label!r}, now depth {len(nav_stack)-1}")
                    # Reset scroll on the screen we return to (it may have scrolled before)
                    nav_stack[-1].scroll = ScrollState()
                elif action.key == "HOME":
                    nav_stack = [nav_stack[0]]   # keep root only
                    log.info("Nav reset → HOME (depth 0)")

                    # For "go home" tasks, pressing HOME is the definitive success.
                    # iOS HOME always navigates to the home screen — no need for Qwen to verify.
                    _GOTO_HOME_KEYWORDS = [
                        "回到home", "回主畫面", "回首頁", "回home", "回到首頁",
                        "go home", "home screen", "launcher", "主畫面", "首頁",
                        "press home", "按home",
                    ]
                    if any(kw in task.lower() for kw in _GOTO_HOME_KEYWORDS):
                        log.info("HOME key confirms task completion for 'go home' task.")
                        return TaskResult(
                            success=True, task=task, steps_taken=step,
                            conclusion="Returned to home screen successfully.",
                            plan=task_plan, logs=logs, device_udid=device_udid,
                        )

            # ── 9. Post-action screen context injection ────────────────────
            # After tap/launch, quickly read the new screen's key elements
            # and inject into history so AI can detect "done" on next step.
            if action.action_type in ("tap", "launch_app"):
                try:
                    time.sleep(0.3)
                    post_elements = self.mdb.list_elements(device_udid)
                    # Extract headings/nav bar labels as a screen summary
                    screen_hints = []
                    for el in post_elements:
                        if el.get("type") in ("Heading", "NavigationBar") and el.get("label"):
                            screen_hints.append(f"{el['type']}: {el['label']}")
                    if screen_hints:
                        history[-1]["screen_after"] = ", ".join(screen_hints[:3])
                except Exception:
                    pass

            # ── 10. Wait before next step ──────────────────────────────────────
            if self.step_delay_ms > 0:
                time.sleep(self.step_delay_ms / 1000.0)

        return TaskResult(
            success=False, task=task, steps_taken=self.max_steps,
            conclusion=f"Reached max steps ({self.max_steps}) without completing the task.",
            plan=task_plan, logs=logs, blocked_reason="max_steps_reached",
            device_udid=device_udid,
        )
