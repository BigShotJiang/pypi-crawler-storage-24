"""
rosud-harness Python SDK

Usage:
    from rosud_harness import Harness

    h = Harness(api_key="your-key")
    agent = h.agents.register(name="my-agent", memory_enabled=True)
    result = h.tasks.run(agent.agent_id, "Hello!")
    print(result.output)
"""
import httpx
from typing import Optional, Iterator
from .types import Agent, Task, Memory, Subscription, Usage

DEFAULT_BASE_URL = "https://api.rosud.com"
DEFAULT_TIMEOUT = 30.0


class HarnessError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")


def _req(client: httpx.Client, method: str, url: str, **kwargs) -> dict:
    r = client.request(method, url, **kwargs)
    if not r.is_success:
        raise HarnessError(r.status_code, r.text[:200])
    return r.json()


class AgentsClient:
    def __init__(self, base: str, headers: dict):
        self._base = base
        self._h = headers

    def register(self, name: str, model: str = "anthropic.claude-3-5-haiku-20241022-v1:0",
                 memory_enabled: bool = False, guardrail_enabled: bool = True,
                 system_prompt: Optional[str] = None) -> Agent:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "POST", f"{self._base}/v1/harness/agents", json={
                "name": name, "model": model,
                "memory_enabled": memory_enabled, "guardrail_enabled": guardrail_enabled,
                "system_prompt": system_prompt,
            })
        return Agent(
            agent_id=d.get("agent_id", d.get("id", "")),
            name=d.get("name", name), model=d.get("model", model),
            memory_enabled=d.get("memory_enabled", memory_enabled),
            guardrail_enabled=d.get("guardrail_enabled", guardrail_enabled),
            active=d.get("active", True), created_at=d.get("created_at", ""),
        )

    def list(self) -> list[Agent]:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/agents")
        return [Agent(agent_id=a.get("id",""), name=a.get("name",""), model=a.get("model",""),
                      memory_enabled=a.get("memory_enabled",False), guardrail_enabled=a.get("guardrail_enabled",True),
                      active=a.get("active",True), created_at=a.get("created_at","")) for a in d.get("agents",[])]

    def deregister(self, agent_id: str) -> dict:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            return _req(c, "DELETE", f"{self._base}/v1/harness/agents/{agent_id}")


class TasksClient:
    def __init__(self, base: str, headers: dict):
        self._base = base
        self._h = headers

    def create(self, agent_id: str, instruction: str, zdr_enabled: bool = False,
               max_iterations: int = 3) -> Task:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "POST", f"{self._base}/v1/harness/tasks", json={
                "agent_id": agent_id, "instruction": instruction,
                "zdr_enabled": zdr_enabled, "max_iterations": max_iterations,
            })
        return Task(task_id=d.get("task_id",""), agent_id=agent_id,
                    status=d.get("status","queued"), zdr_enabled=zdr_enabled,
                    stream_url=d.get("stream_url",""))

    def get(self, task_id: str) -> Task:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/tasks/{task_id}")
        return Task(task_id=d.get("id",task_id), agent_id=d.get("agent_id",""),
                    status=d.get("status",""), zdr_enabled=d.get("zdr_enabled",False),
                    stream_url="", output=d.get("output"), error=d.get("error"))

    def run(self, agent_id: str, instruction: str, poll_interval: float = 1.0,
            timeout: float = 120.0) -> Task:
        """태스크 생성 후 완료까지 폴링. output이 채워진 Task 반환."""
        import time
        task = self.create(agent_id, instruction)
        start = time.time()
        while time.time() - start < timeout:
            t = self.get(task.task_id)
            if t.status in ("done", "failed"):
                return t
            time.sleep(poll_interval)
        raise TimeoutError(f"Task {task.task_id} did not complete within {timeout}s")

    def list(self) -> list[Task]:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/tasks")
        return [Task(task_id=t.get("id",""), agent_id=t.get("agent_id",""),
                     status=t.get("status",""), zdr_enabled=t.get("zdr_enabled",False),
                     stream_url="", created_at=t.get("created_at")) for t in d.get("tasks",[])]


class MemoryClient:
    def __init__(self, base: str, headers: dict):
        self._base = base
        self._h = headers

    def store(self, agent_id: str, content: str, tags: Optional[list] = None) -> dict:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            return _req(c, "POST", f"{self._base}/v1/harness/memory/{agent_id}",
                        json={"content": content, "tags": tags or []})

    def list(self, agent_id: str, limit: int = 20) -> list[Memory]:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/memory/{agent_id}?limit={limit}")
        return [Memory(id=m.get("id",""), agent_id=agent_id, content=m.get("content",""),
                       tags=m.get("tags",[]), expires_at=m.get("expires_at"),
                       created_at=m.get("created_at")) for m in d.get("memories",[])]

    def search(self, agent_id: str, query: str, limit: int = 10) -> list[Memory]:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/memory/{agent_id}/search?q={query}&limit={limit}")
        return [Memory(id=m.get("id",""), agent_id=agent_id, content=m.get("content",""),
                       tags=m.get("tags",[])) for m in d.get("results",[])]

    def delete(self, agent_id: str, memory_id: str) -> dict:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            return _req(c, "DELETE", f"{self._base}/v1/harness/memory/{agent_id}/{memory_id}")


class BillingClient:
    def __init__(self, base: str, headers: dict):
        self._base = base
        self._h = headers

    def subscription(self) -> Subscription:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/subscription")
        return Subscription(plan=d.get("plan","free"), status=d.get("status","active"),
                            product=d.get("product","harness"), current_period_end=d.get("current_period_end"))

    def usage(self) -> Usage:
        with httpx.Client(headers=self._h, timeout=DEFAULT_TIMEOUT) as c:
            d = _req(c, "GET", f"{self._base}/v1/harness/usage")
        return Usage(month=d.get("month",""), task_count=d.get("task_count",0),
                     token_in=d.get("token_in",0), token_out=d.get("token_out",0),
                     memory_mb=d.get("memory_mb",0.0), agent_count=d.get("agent_count",0))


class Harness:
    """rosud-harness Python SDK entry point."""

    def __init__(self, api_key: str, base_url: str = DEFAULT_BASE_URL):
        if not api_key:
            raise ValueError("rosud-harness: api_key is required")
        headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
        base = base_url.rstrip("/")
        self.agents = AgentsClient(base, headers)
        self.tasks = TasksClient(base, headers)
        self.memory = MemoryClient(base, headers)
        self.billing = BillingClient(base, headers)

    def ping(self) -> dict:
        with httpx.Client(timeout=10) as c:
            r = c.get(f"https://api.rosud.com/harness-health")
        return r.json()
