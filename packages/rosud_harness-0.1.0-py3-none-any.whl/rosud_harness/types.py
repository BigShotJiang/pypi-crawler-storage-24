from dataclasses import dataclass, field
from typing import Optional

@dataclass
class Agent:
    agent_id: str
    name: str
    model: str
    memory_enabled: bool
    guardrail_enabled: bool
    active: bool
    created_at: str

@dataclass
class Task:
    task_id: str
    agent_id: str
    status: str  # queued | running | done | failed
    zdr_enabled: bool
    stream_url: str
    output: Optional[str] = None
    error: Optional[str] = None
    created_at: Optional[str] = None

@dataclass
class Memory:
    id: str
    agent_id: str
    content: str
    tags: list = field(default_factory=list)
    expires_at: Optional[str] = None
    created_at: Optional[str] = None

@dataclass
class Subscription:
    plan: str
    status: str
    product: str
    current_period_end: Optional[str] = None

@dataclass
class Usage:
    month: str
    task_count: int
    token_in: int
    token_out: int
    memory_mb: float
    agent_count: int
