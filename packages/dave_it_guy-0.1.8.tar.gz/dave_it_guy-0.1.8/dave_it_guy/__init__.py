"""Dave IT Guy — Deploy AI stacks with one command. Wraps KrakenWhip."""
