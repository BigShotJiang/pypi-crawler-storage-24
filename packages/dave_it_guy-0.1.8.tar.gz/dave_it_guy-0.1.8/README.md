# Dave IT Guy

**Deploy AI stacks with one command.**

Dave IT Guy is the same powerful stack as KrakenWhip—OpenClaw, Ollama, and Qdrant—under one name. One command, fully containerized.

```bash
pip install dave-it-guy
dave-it-guy deploy openclaw
docker exec -it krakenwhip-openclaw openclaw tui
```

**Gateway:** http://localhost:18789

Requires **krakenwhip** (installed automatically). MIT License.
