"""OTS 存储后端。

封装 TableStore SDK 的底层操作，负责五张表的建表和 CRUD。
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from tablestore import AsyncOTSClient  # type: ignore[import-untyped]
from tablestore import BatchWriteRowRequest  # type: ignore[import-untyped]
from tablestore import (
    CapacityUnit,
    ComparatorType,
    Condition,
    DeleteRowItem,
    Direction,
    INF_MAX,
    INF_MIN,
    OTSClient,
    OTSServiceError,
    PK_AUTO_INCR,
    ReservedThroughput,
    ReturnType,
    Row,
    RowExistenceExpectation,
    SecondaryIndexMeta,
    SecondaryIndexType,
    SingleColumnCondition,
    TableInBatchWriteRowItem,
    TableMeta,
    TableOptions,
)

from agentrun.conversation_service.model import (
    ConversationEvent,
    ConversationSession,
    DEFAULT_APP_STATE_TABLE,
    DEFAULT_CONVERSATION_SEARCH_INDEX,
    DEFAULT_CONVERSATION_SECONDARY_INDEX,
    DEFAULT_CONVERSATION_TABLE,
    DEFAULT_EVENT_TABLE,
    DEFAULT_STATE_TABLE,
    DEFAULT_USER_STATE_TABLE,
    StateData,
    StateScope,
)
from agentrun.conversation_service.utils import (
    deserialize_state,
    from_chunks,
    MAX_COLUMN_SIZE,
    nanoseconds_timestamp,
    serialize_state,
    to_chunks,
)

logger = logging.getLogger(__name__)

# OTS BatchWriteRow 每批最多 200 行
_BATCH_WRITE_LIMIT = 200


class OTSBackend:
    """TableStore 存储后端。

    封装 OTS SDK 底层操作，理解表结构，提供五张表的 CRUD。
    同时提供异步（_async 后缀）和同步方法。

    Args:
        ots_client: 预构建的 OTS SDK 同步客户端实例（同步方法使用）。
        table_prefix: 表名前缀，用于多租户隔离。
        async_ots_client: 预构建的 OTS SDK 异步客户端实例（异步方法使用）。
    """

    def __init__(
        self,
        ots_client: Optional[OTSClient] = None,
        table_prefix: str = "",
        *,
        async_ots_client: Optional[AsyncOTSClient] = None,
    ) -> None:
        self._client = ots_client
        self._async_client = async_ots_client
        self._table_prefix = table_prefix

        # 根据前缀生成实际表名
        self._conversation_table = f"{table_prefix}{DEFAULT_CONVERSATION_TABLE}"
        self._event_table = f"{table_prefix}{DEFAULT_EVENT_TABLE}"
        self._state_table = f"{table_prefix}{DEFAULT_STATE_TABLE}"
        self._app_state_table = f"{table_prefix}{DEFAULT_APP_STATE_TABLE}"
        self._user_state_table = f"{table_prefix}{DEFAULT_USER_STATE_TABLE}"
        self._conversation_secondary_index = (
            f"{table_prefix}{DEFAULT_CONVERSATION_SECONDARY_INDEX}"
        )
        self._conversation_search_index = (
            f"{table_prefix}{DEFAULT_CONVERSATION_SEARCH_INDEX}"
        )

    # -----------------------------------------------------------------------
    # 建表（异步）/ Table creation (async)
    # -----------------------------------------------------------------------

    async def init_tables_async(self) -> None:
        """创建五张表和 Conversation 二级索引（异步）。

        表已存在时跳过（catch OTSServiceError 并 log warning）。
        """
        await self._create_conversation_table_async()
        await self._create_event_table_async()
        await self._create_state_table_async(
            self._state_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
        )
        await self._create_state_table_async(
            self._app_state_table,
            [("agent_id", "STRING")],
        )
        await self._create_state_table_async(
            self._user_state_table,
            [("agent_id", "STRING"), ("user_id", "STRING")],
        )

    async def init_core_tables_async(self) -> None:
        """创建核心表（Conversation + Event）和二级索引（异步）。"""
        await self._create_conversation_table_async()
        await self._create_event_table_async()

    async def init_state_tables_async(self) -> None:
        """创建三张 State 表（异步）。"""
        await self._create_state_table_async(
            self._state_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
        )
        await self._create_state_table_async(
            self._app_state_table,
            [("agent_id", "STRING")],
        )
        await self._create_state_table_async(
            self._user_state_table,
            [("agent_id", "STRING"), ("user_id", "STRING")],
        )

    async def init_search_index_async(self) -> None:
        """创建 Conversation 多元索引（异步）。按需调用。"""
        await self._create_conversation_search_index_async()

    async def _create_conversation_table_async(self) -> None:
        """创建 Conversation 表 + 二级索引（异步）。"""
        table_meta = TableMeta(
            self._conversation_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
            # 二级索引引用的非 PK 列必须声明为 defined_columns
            defined_columns=[
                ("updated_at", "INTEGER"),
                ("summary", "STRING"),
                ("labels", "STRING"),
                ("framework", "STRING"),
                ("extensions", "STRING"),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        # 二级索引：按 updated_at 排序
        secondary_index_meta = SecondaryIndexMeta(
            self._conversation_secondary_index,
            [
                "agent_id",
                "user_id",
                "updated_at",
                "session_id",
            ],
            [
                "summary",
                "labels",
                "framework",
                "extensions",
            ],
            index_type=SecondaryIndexType.GLOBAL_INDEX,
        )

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
                secondary_indexes=[secondary_index_meta],
            )
            logger.info(
                "Created table: %s with secondary index: %s",
                self._conversation_table,
                self._conversation_secondary_index,
            )
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._conversation_table,
                )
            else:
                raise

    async def _create_event_table_async(self) -> None:
        """创建 Event 表（seq_id 为 AUTO_INCREMENT）（异步）。"""
        table_meta = TableMeta(
            self._event_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
                ("seq_id", "INTEGER", PK_AUTO_INCR),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
            )
            logger.info("Created table: %s", self._event_table)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._event_table,
                )
            else:
                raise

    async def _create_state_table_async(
        self,
        table_name: str,
        pk_schema: list[tuple[str, str]],
    ) -> None:
        """创建 State 类型表（通用方法）（异步）。"""
        table_meta = TableMeta(table_name, pk_schema)
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
            )
            logger.info("Created table: %s", table_name)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    table_name,
                )
            else:
                raise

    async def _create_conversation_search_index_async(self) -> None:
        """创建 Conversation 表的多元索引（异步）。

        多元索引支持全文检索 summary、精确匹配过滤 labels/framework/is_pinned、
        范围查询 updated_at/created_at、跨 user 查询等场景。
        索引已存在时跳过。
        """
        from tablestore import AnalyzerType  # type: ignore[import-untyped]
        from tablestore import FieldType  # type: ignore[import-untyped]
        from tablestore import IndexSetting  # type: ignore[import-untyped]
        from tablestore import SortOrder  # type: ignore[import-untyped]
        from tablestore import FieldSchema
        from tablestore import (
            FieldSort as OTSFieldSort,
        )  # type: ignore[import-untyped]
        from tablestore import SearchIndexMeta
        from tablestore import Sort as OTSSort  # type: ignore[import-untyped]

        fields = [
            FieldSchema(
                "agent_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "user_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "session_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "updated_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "created_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "is_pinned",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "framework",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "summary",
                FieldType.TEXT,
                index=True,
                analyzer=AnalyzerType.SINGLEWORD,
            ),
            FieldSchema(
                "labels",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
        ]

        index_setting = IndexSetting(routing_fields=["agent_id"])
        index_sort = OTSSort(
            sorters=[OTSFieldSort("updated_at", sort_order=SortOrder.DESC)]
        )
        index_meta = SearchIndexMeta(
            fields,
            index_setting=index_setting,
            index_sort=index_sort,
        )

        try:
            await self._async_client.create_search_index(
                self._conversation_table,
                self._conversation_search_index,
                index_meta,
            )
            logger.info(
                "Created search index: %s on table: %s",
                self._conversation_search_index,
                self._conversation_table,
            )
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Search index %s already exists, skipping.",
                    self._conversation_search_index,
                )
            else:
                raise

    # -----------------------------------------------------------------------
    # Session CRUD（异步）/ Session CRUD (async)
    # -----------------------------------------------------------------------

    async def put_session_async(self, session: ConversationSession) -> None:
        """PutRow 写入/覆盖 Session 行（异步）。"""
        primary_key = [
            ("agent_id", session.agent_id),
            ("user_id", session.user_id),
            ("session_id", session.session_id),
        ]

        attribute_columns = [
            ("created_at", session.created_at),
            ("updated_at", session.updated_at),
            ("is_pinned", session.is_pinned),
            ("version", session.version),
        ]

        if session.summary is not None:
            attribute_columns.append(("summary", session.summary))
        if session.labels is not None:
            attribute_columns.append(("labels", session.labels))
        if session.framework is not None:
            attribute_columns.append(("framework", session.framework))
        if session.extensions is not None:
            attribute_columns.append((
                "extensions",
                json.dumps(session.extensions, ensure_ascii=False),
            ))

        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.put_row(
            self._conversation_table, row, condition
        )

    async def get_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> Optional[ConversationSession]:
        """GetRow 点读 Session（异步）。"""
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]

        _, row, _ = await self._async_client.get_row(
            self._conversation_table,
            primary_key,
            max_version=1,
        )

        if row is None or row.primary_key is None:
            return None

        return self._row_to_session(row)

    async def delete_session_row_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> None:
        """DeleteRow 删除 Session 单行（不含级联）（异步）。"""
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]
        row = Row(primary_key)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.delete_row(
            self._conversation_table, row, condition
        )

    async def update_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        columns_to_put: dict[str, Any],
        version: int,
    ) -> None:
        """UpdateRow + 乐观锁更新 Session 行（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            columns_to_put: 要更新的列及其值。
            version: 当前版本号（乐观锁校验）。
        """
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]

        put_cols = list(columns_to_put.items())
        update_of_attribute_columns = {"PUT": put_cols}

        row = Row(primary_key, update_of_attribute_columns)
        condition = Condition(
            RowExistenceExpectation.EXPECT_EXIST,
            SingleColumnCondition(
                "version",
                version,
                ComparatorType.EQUAL,
            ),
        )
        await self._async_client.update_row(
            self._conversation_table, row, condition
        )

    async def list_sessions_async(
        self,
        agent_id: str,
        user_id: str,
        limit: Optional[int] = None,
        order_desc: bool = True,
    ) -> list[ConversationSession]:
        """通过二级索引按 updated_at 排序扫描 Session 列表（异步）。"""

        if order_desc:
            # 倒序：从最新到最旧
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MAX),
                ("session_id", INF_MAX),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MIN),
                ("session_id", INF_MIN),
            ]
            direction = Direction.BACKWARD
        else:
            # 正序：从最旧到最新
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MIN),
                ("session_id", INF_MIN),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MAX),
                ("session_id", INF_MAX),
            ]
            direction = Direction.FORWARD

        sessions: list[ConversationSession] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._conversation_secondary_index,
                direction,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                session = self._row_to_session_from_index(row)
                sessions.append(session)
                if limit is not None and len(sessions) >= limit:
                    return sessions

            if next_token is None:
                break
            next_start = next_token

        return sessions

    async def list_all_sessions_async(
        self,
        agent_id: str,
        limit: Optional[int] = None,
    ) -> list[ConversationSession]:
        """扫描 agent_id 下所有用户的 Session（主表 GetRange）（异步）。

        不走二级索引，直接扫主表。返回结果不含 events，
        适用于 ADK list_sessions(user_id=None) 场景。

        Args:
            agent_id: 智能体 ID。
            limit: 最多返回条数，None 表示全部。

        Returns:
            ConversationSession 列表。
        """
        inclusive_start = [
            ("agent_id", agent_id),
            ("user_id", INF_MIN),
            ("session_id", INF_MIN),
        ]
        exclusive_end = [
            ("agent_id", agent_id),
            ("user_id", INF_MAX),
            ("session_id", INF_MAX),
        ]

        sessions: list[ConversationSession] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._conversation_table,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                session = self._row_to_session(row)
                sessions.append(session)
                if limit is not None and len(sessions) >= limit:
                    return sessions

            if next_token is None:
                break
            next_start = next_token

        return sessions

    async def search_sessions_async(
        self,
        agent_id: str,
        *,
        user_id: Optional[str] = None,
        summary_keyword: Optional[str] = None,
        labels: Optional[str] = None,
        framework: Optional[str] = None,
        updated_after: Optional[int] = None,
        updated_before: Optional[int] = None,
        is_pinned: Optional[bool] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[ConversationSession], int]:
        """通过多元索引搜索 Session（异步）。

        支持全文搜索 summary、精确过滤 labels/framework/is_pinned、
        范围查询 updated_at 以及跨 user_id 查询。

        Args:
            agent_id: 智能体 ID（必填，作为 routing 键优化查询）。
            user_id: 用户 ID（可选，精确匹配）。
            summary_keyword: summary 关键词（全文搜索）。
            labels: 标签 JSON 字符串（精确匹配）。
            framework: 框架标识（精确匹配）。
            updated_after: 仅返回 updated_at >= 此值的记录。
            updated_before: 仅返回 updated_at < 此值的记录。
            is_pinned: 是否置顶过滤。
            limit: 最多返回条数，默认 20。
            offset: 分页偏移量，默认 0。

        Returns:
            (结果列表, 总匹配数) 二元组。
        """
        from tablestore import BoolQuery  # type: ignore[import-untyped]
        from tablestore import MatchQuery  # type: ignore[import-untyped]
        from tablestore import SortOrder  # type: ignore[import-untyped]
        from tablestore import TermQuery  # type: ignore[import-untyped]
        from tablestore import ColumnReturnType, ColumnsToGet
        from tablestore import (
            FieldSort as OTSFieldSort,
        )  # type: ignore[import-untyped]
        from tablestore import RangeQuery, SearchQuery
        from tablestore import Sort as OTSSort  # type: ignore[import-untyped]

        must_queries: list[Any] = [
            TermQuery("agent_id", agent_id),
        ]

        if user_id is not None:
            must_queries.append(TermQuery("user_id", user_id))
        if summary_keyword is not None:
            must_queries.append(MatchQuery("summary", summary_keyword))
        if labels is not None:
            must_queries.append(TermQuery("labels", labels))
        if framework is not None:
            must_queries.append(TermQuery("framework", framework))
        if is_pinned is not None:
            must_queries.append(
                TermQuery("is_pinned", "true" if is_pinned else "false")
            )
        if updated_after is not None or updated_before is not None:
            must_queries.append(
                RangeQuery(
                    "updated_at",
                    range_from=updated_after,
                    include_lower=True if updated_after is not None else None,
                    range_to=updated_before,
                    include_upper=False if updated_before is not None else None,
                )
            )

        query = BoolQuery(must_queries=must_queries)

        search_query = SearchQuery(
            query,
            sort=OTSSort(
                sorters=[OTSFieldSort("updated_at", sort_order=SortOrder.DESC)]
            ),
            limit=limit,
            offset=offset,
            get_total_count=True,
        )

        columns_to_get = ColumnsToGet(
            return_type=ColumnReturnType.ALL,
        )

        search_response = await self._async_client.search(
            self._conversation_table,
            self._conversation_search_index,
            search_query,
            columns_to_get,
        )

        sessions: list[ConversationSession] = []
        for row in search_response.rows:
            # search API 返回 (primary_key, attribute_columns) 元组，
            # 需要包装为 Row 对象以复用 _row_to_session
            if isinstance(row, tuple):
                row = Row(row[0], row[1])
            sessions.append(self._row_to_session(row))

        return sessions, search_response.total_count or 0

    # -----------------------------------------------------------------------
    # Event CRUD（异步）/ Event CRUD (async)
    # -----------------------------------------------------------------------

    async def put_event_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        event_type: str,
        content: dict[str, Any],
        created_at: Optional[int] = None,
        updated_at: Optional[int] = None,
        raw_event: Optional[str] = None,
    ) -> int:
        """PutRow 写入事件（seq_id AUTO_INCREMENT），返回 OTS 生成的 seq_id（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            event_type: 事件类型。
            content: 事件数据。
            created_at: 创建时间（纳秒时间戳），默认当前时间。
            updated_at: 更新时间（纳秒时间戳），默认当前时间。
            raw_event: 框架原生 Event 的完整 JSON 序列化（可选）。
                用于精确还原框架特定的 Event 对象（如 ADK Event）。

        Returns:
            OTS 生成的 seq_id。
        """
        now = nanoseconds_timestamp()
        if created_at is None:
            created_at = now
        if updated_at is None:
            updated_at = now

        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", PK_AUTO_INCR),
        ]

        content_json = json.dumps(content, ensure_ascii=False)
        attribute_columns = [
            ("type", event_type),
            ("content", content_json),
            ("created_at", created_at),
            ("updated_at", updated_at),
            ("version", 0),
        ]

        if raw_event is not None:
            attribute_columns.append(("raw_event", raw_event))

        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)

        # put_row 返回 (consumed, return_row)
        # 使用 ReturnType.RT_PK 让 OTS 返回自增 PK 值
        _, return_row = await self._async_client.put_row(
            self._event_table,
            row,
            condition,
            return_type=ReturnType.RT_PK,
        )

        # 从返回的主键中提取 seq_id
        seq_id: int = 0
        if return_row is not None and return_row.primary_key is not None:
            for pk_col in return_row.primary_key:
                if pk_col[0] == "seq_id":
                    seq_id = pk_col[1]  # type: ignore[assignment]
                    break

        return seq_id

    async def get_events_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        direction: str = "FORWARD",
        limit: Optional[int] = None,
    ) -> list[ConversationEvent]:
        """GetRange 扫描事件列表（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            direction: 'FORWARD'（正序）或 'BACKWARD'（倒序）。
            limit: 最多返回条数。
        """
        if direction == "BACKWARD":
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MAX),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MIN),
            ]
            ots_direction = Direction.BACKWARD
        else:
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MIN),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MAX),
            ]
            ots_direction = Direction.FORWARD

        events: list[ConversationEvent] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._event_table,
                ots_direction,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                event = self._row_to_event(row)
                events.append(event)
                if limit is not None and len(events) >= limit:
                    return events

            if next_token is None:
                break
            next_start = next_token

        return events

    async def delete_events_by_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> int:
        """批量删除 Session 下所有 Event，返回删除条数（异步）。

        先 GetRange 扫出所有 PK，再分批 BatchWriteRow 删除。
        """
        # 1. 扫描所有 Event 的 PK
        inclusive_start = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", INF_MIN),
        ]
        exclusive_end = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", INF_MAX),
        ]

        all_pks: list[list[tuple[str, Any]]] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._event_table,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                columns_to_get=[],  # 只取 PK，不读属性列
                max_version=1,
            )

            for row in rows:
                all_pks.append(row.primary_key)

            if next_token is None:
                break
            next_start = next_token

        if not all_pks:
            return 0

        # 2. 分批 BatchWriteRow 删除
        deleted = 0
        for i in range(0, len(all_pks), _BATCH_WRITE_LIMIT):
            batch = all_pks[i : i + _BATCH_WRITE_LIMIT]
            delete_items = []
            for pk in batch:
                row = Row(pk)
                condition = Condition(RowExistenceExpectation.IGNORE)
                delete_items.append(DeleteRowItem(row, condition))

            request = BatchWriteRowRequest()
            request.add(
                TableInBatchWriteRowItem(self._event_table, delete_items)
            )
            await self._async_client.batch_write_row(request)
            deleted += len(batch)

        return deleted

    # -----------------------------------------------------------------------
    # State CRUD（JSON 字符串存储 + 列分片）（异步）
    # -----------------------------------------------------------------------

    async def put_state_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
        state: dict[str, Any],
        version: int,
    ) -> None:
        """序列化 + 列分片写入 State（异步）。

        State 以 JSON 字符串（STRING 类型）存储，不压缩。
        当 JSON 字符串超过 1.5M 字符时自动分片。

        Args:
            scope: 状态作用域（APP / USER / SESSION）。
            agent_id: 智能体 ID。
            user_id: 用户 ID（APP scope 时忽略）。
            session_id: 会话 ID（APP/USER scope 时忽略）。
            state: 状态字典。
            version: 当前版本号（乐观锁校验，首次写入传 0）。
        """
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )

        now = nanoseconds_timestamp()
        state_json = serialize_state(state)

        put_cols: list[tuple[str, Any]] = [
            ("updated_at", now),
            ("version", version + 1),
        ]

        # 首次写入需要 created_at
        if version == 0:
            put_cols.append(("created_at", now))

        if len(state_json) <= MAX_COLUMN_SIZE:
            # 不分片
            new_chunk_count = 0
            put_cols.append(("chunk_count", 0))
            put_cols.append(("state", state_json))
        else:
            # 分片
            chunks = to_chunks(state_json)
            new_chunk_count = len(chunks)
            put_cols.append(("chunk_count", new_chunk_count))
            for idx, chunk in enumerate(chunks):
                put_cols.append((f"state_{idx}", chunk))

        update_of_attribute_columns: dict[str, Any] = {"PUT": put_cols}

        # 如果是更新（version > 0），需要清理旧的分片列
        delete_cols: list[str] = []
        if version > 0:
            old_chunk_count = await self._get_chunk_count_async(
                table_name, primary_key
            )

            if new_chunk_count == 0 and old_chunk_count > 0:
                # 旧的有分片，新的不分片：删除所有 state_N 列
                for i in range(old_chunk_count):
                    delete_cols.append(f"state_{i}")
            elif new_chunk_count > 0 and old_chunk_count == 0:
                # 旧的不分片，新的有分片：删除 state 列
                delete_cols.append("state")
            elif new_chunk_count > 0 and old_chunk_count > new_chunk_count:
                # 都分片，但旧的分片更多：删除多余分片列
                for i in range(new_chunk_count, old_chunk_count):
                    delete_cols.append(f"state_{i}")

        if delete_cols:
            update_of_attribute_columns["DELETE_ALL"] = delete_cols

        row = Row(primary_key, update_of_attribute_columns)

        if version == 0:
            # 首次写入
            condition = Condition(RowExistenceExpectation.IGNORE)
        else:
            condition = Condition(
                RowExistenceExpectation.EXPECT_EXIST,
                SingleColumnCondition(
                    "version",
                    version,
                    ComparatorType.EQUAL,
                ),
            )

        await self._async_client.update_row(table_name, row, condition)

    async def get_state_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> Optional[StateData]:
        """读取 + 拼接分片 + 反序列化 State（异步）。"""
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )

        _, row, _ = await self._async_client.get_row(
            table_name,
            primary_key,
            max_version=1,
        )

        if row is None or row.primary_key is None:
            return None

        attrs = self._attrs_to_dict(row.attribute_columns)

        chunk_count = attrs.get("chunk_count", 0)
        if chunk_count == 0:
            raw_state = attrs.get("state")
            if raw_state is None:
                return None
            state = deserialize_state(str(raw_state))
        else:
            chunks: list[str] = []
            for i in range(chunk_count):
                chunk = attrs.get(f"state_{i}")
                if chunk is None:
                    raise ValueError(f"Missing state chunk: state_{i}")
                chunks.append(str(chunk))
            merged_str = from_chunks(chunks)
            state = deserialize_state(merged_str)

        return StateData(
            state=state,
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            version=attrs.get("version", 0),
        )

    async def delete_state_row_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> None:
        """删除 State 行（异步）。"""
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )
        row = Row(primary_key)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.delete_row(table_name, row, condition)

    # -----------------------------------------------------------------------
    # 内部辅助方法（I/O 相关，异步）
    # -----------------------------------------------------------------------

    async def _get_chunk_count_async(
        self,
        table_name: str,
        primary_key: list[tuple[str, str]],
    ) -> int:
        """读取指定行的 chunk_count 值（异步）。"""
        _, row, _ = await self._async_client.get_row(
            table_name,
            primary_key,
            columns_to_get=["chunk_count"],
            max_version=1,
        )
        if row is None or row.primary_key is None:
            return 0

        attrs = self._attrs_to_dict(row.attribute_columns)
        return attrs.get("chunk_count", 0)

    # -----------------------------------------------------------------------
    # 内部辅助方法（纯计算，不涉及 I/O，保持同步）
    # -----------------------------------------------------------------------

    def _resolve_state_table_and_pk(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> tuple[str, list[tuple[str, str]]]:
        """根据 scope 返回对应的表名和主键列表。"""
        if scope == StateScope.APP:
            return self._app_state_table, [
                ("agent_id", agent_id),
            ]
        elif scope == StateScope.USER:
            return self._user_state_table, [
                ("agent_id", agent_id),
                ("user_id", user_id),
            ]
        else:  # SESSION
            return self._state_table, [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
            ]

    @staticmethod
    def _attrs_to_dict(
        attribute_columns: list[Any],
    ) -> dict[str, Any]:
        """将 OTS 属性列列表转换为字典。

        OTS 返回的属性列格式为 [(name, value, timestamp), ...]
        """
        result: dict[str, Any] = {}
        if attribute_columns is None:
            return result
        for col in attribute_columns:
            # col 格式: (name, value, timestamp)
            name = col[0]
            value = col[1]
            result[name] = value
        return result

    @staticmethod
    def _pk_to_dict(
        primary_key: list[Any],
    ) -> dict[str, Any]:
        """将 OTS 主键列表转换为字典。"""
        result: dict[str, Any] = {}
        if primary_key is None:
            return result
        for col in primary_key:
            name = col[0]
            value = col[1]
            result[name] = value
        return result

    def _row_to_session(self, row: Row) -> ConversationSession:
        """将 OTS Row 转换为 ConversationSession。"""
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        extensions = None
        ext_raw = attrs.get("extensions")
        if ext_raw is not None and isinstance(ext_raw, str):
            extensions = json.loads(ext_raw)

        return ConversationSession(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            is_pinned=attrs.get("is_pinned", False),
            summary=attrs.get("summary"),
            labels=attrs.get("labels"),
            framework=attrs.get("framework"),
            extensions=extensions,
            version=attrs.get("version", 0),
        )

    def _row_to_session_from_index(self, row: Row) -> ConversationSession:
        """将二级索引 Row 转换为 ConversationSession。

        二级索引的 PK 包含 updated_at，属性列只有预定义的列。
        """
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        extensions = None
        ext_raw = attrs.get("extensions")
        if ext_raw is not None and isinstance(ext_raw, str):
            extensions = json.loads(ext_raw)

        return ConversationSession(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            created_at=0,  # 二级索引不含 created_at
            updated_at=pk.get("updated_at", 0),
            summary=attrs.get("summary"),
            labels=attrs.get("labels"),
            framework=attrs.get("framework"),
            extensions=extensions,
        )

    def _row_to_event(self, row: Row) -> ConversationEvent:
        """将 OTS Row 转换为 ConversationEvent。"""
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        content_raw = attrs.get("content", "{}")
        if isinstance(content_raw, str):
            content = json.loads(content_raw)
        else:
            content = {}

        return ConversationEvent(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            seq_id=pk.get("seq_id"),
            type=attrs.get("type", ""),
            content=content,
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            version=attrs.get("version", 0),
            raw_event=attrs.get("raw_event"),
        )
