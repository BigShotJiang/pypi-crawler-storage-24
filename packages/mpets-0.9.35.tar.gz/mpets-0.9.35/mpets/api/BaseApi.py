from typing import Optional, Dict, TYPE_CHECKING
from urllib.parse import unquote, urlsplit

import aiohttp
from aiohttp_socks import ProxyConnector
from loguru import logger

from mpets.api import api
from mpets.utils.rate_limiter import RateLimiter

if TYPE_CHECKING:
    from mpets import MpetsApi


class BaseApi:
    def __init__(self, cookie, timeout, connector, proxy, mpets_api,
                 proxy_for_start_only: bool = False,
                 requests_per_second: Optional[float] = None):
        self._cookie = cookie
        self._timeout = aiohttp.ClientTimeout(timeout)
        self._session: Optional[aiohttp.ClientSession] = None
        self._connector = connector
        self._proxy, self._proxy_auth, self._proxy_connector_url = self._parse_proxy(proxy)
        self._proxy_for_start_only = proxy_for_start_only
        self._session_uses_proxy_connector = False
        self._mpets_api: MpetsApi = mpets_api
        self._rate_limiter = RateLimiter(requests_per_second)

    @staticmethod
    def _parse_proxy(proxy: Optional[str]):
        if proxy is None:
            return None, None, None

        value = proxy.strip()
        if not value:
            return None, None, None

        # Supports "host:port:login:password"
        if "://" not in value and "@" not in value:
            parts = value.split(":")
            if len(parts) >= 4:
                host = parts[0]
                port = parts[1]
                username = parts[2]
                password = ":".join(parts[3:])
                return f"http://{host}:{port}", aiohttp.BasicAuth(unquote(username), unquote(password)), None

        # Supports "host:port@login:password"
        if "://" not in value and "@" in value:
            host_port, credentials = value.split("@", 1)
            if ":" in credentials:
                username, password = credentials.split(":", 1)
                return f"http://{host_port}", aiohttp.BasicAuth(unquote(username), unquote(password)), None

        if "://" not in value:
            value = f"http://{value}"

        parsed = urlsplit(value)
        if parsed.scheme.lower().startswith("socks"):
            return None, None, value

        if parsed.username is None:
            return value, None, None

        host = parsed.hostname
        if host is None:
            return value, None, None

        port = f":{parsed.port}" if parsed.port else ""
        normalized_proxy = f"{parsed.scheme}://{host}{port}"
        username = unquote(parsed.username)
        password = unquote(parsed.password or "")
        return normalized_proxy, aiohttp.BasicAuth(username, password), None

    def _resolve_connector(self, use_proxy_connector: bool):
        if use_proxy_connector and self._proxy_connector_url is not None:
            return ProxyConnector.from_url(self._proxy_connector_url)
        return self._connector

    @property
    def session(self):
        return self._session

    @property
    def cookie(self):
        return self._cookie

    @cookie.setter
    def cookie(self, value):
        self._cookie = value

    async def get_new_session(self, cookie=None, use_proxy_connector: bool = False) -> aiohttp.ClientSession:
        if self._session is not None:
            logger.debug("Закрыл сессию")
            try:
                await self._session.close()
            except Exception as ex:
                pass

        if cookie is not None:
            self._cookie = cookie
        self._session_uses_proxy_connector = use_proxy_connector
        return aiohttp.ClientSession(
            cookies=self._cookie,
            timeout=self._timeout,
            connector=self._resolve_connector(use_proxy_connector),
        )

    async def get_session(self, cookies=None, use_proxy_connector: bool = False) -> Optional[aiohttp.ClientSession]:
        if self._session is None or self._session.closed:
            self._session = await self.get_new_session(cookie=cookies,
                                                       use_proxy_connector=use_proxy_connector)
        elif self._session_uses_proxy_connector != use_proxy_connector:
            self._session = await self.get_new_session(cookie=cookies,
                                                       use_proxy_connector=use_proxy_connector)

        if not self._session._loop.is_running():  # NOQA
            # Hate `aiohttp` devs because it juggles event-loops and breaks already opened session
            # So... when we detect a broken session need to fix it by re-creating it
            # @asvetlov, if you read this, please no more juggle event-loop inside aiohttp, it breaks the brain.
            await self._session.close()
            self._session = await self.get_new_session(cookie=cookies,
                                                       use_proxy_connector=use_proxy_connector)

        return self._session

    async def request(self, type: str,
                      method: str,
                      params: Optional[Dict] = None,
                      data: Optional[Dict] = None):
        """
        Запрос
        """
        use_proxy = not self._proxy_for_start_only or method == "/start"
        use_proxy_connector = use_proxy and self._proxy_connector_url is not None
        proxy = self._proxy if use_proxy and not use_proxy_connector else None
        proxy_auth = self._proxy_auth if use_proxy and not use_proxy_connector else None

        if type == "GET":
            return await api.make_get_request(await self.get_session(use_proxy_connector=use_proxy_connector),
                                              method,
                                              params,
                                              proxy=proxy,
                                              proxy_auth=proxy_auth,
                                              rate_limiter=self._rate_limiter)
        elif type == "POST":
            return await api.make_post_request(await self.get_session(use_proxy_connector=use_proxy_connector),
                                               method,
                                               data,
                                               proxy=proxy,
                                               proxy_auth=proxy_auth,
                                               rate_limiter=self._rate_limiter)

    async def close_session(self):
        if self._session is not None:
            await self._session.close()

    @property
    def mpets_api(self):
        return self._mpets_api

    @property
    def proxy(self):
        return self._proxy

    @property
    def proxy_auth(self):
        return self._proxy_auth

    @property
    def proxy_for_start_only(self):
        return self._proxy_for_start_only

    @property
    def rate_limit(self) -> Optional[float]:
        return self._rate_limiter.requests_per_second

    def set_rate_limit(self, requests_per_second: Optional[float]):
        self._rate_limiter.set_rate(requests_per_second)
