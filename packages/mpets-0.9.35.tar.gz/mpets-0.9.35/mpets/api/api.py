import asyncio

from loguru import logger

from mpets.utils.constants import HOST_URL


class FastClick(Exception):
    def __init__(self, text):
        self.txt = text


def check_result(method_name: str, content_type: str, status_code: int, body: str):
    """
    """
    # logger.debug(f'Ответ метода {method_name}: [{status_code}] {body}')
    if "Предупреждение" in body:
        raise FastClick("Вы кликаете очень быстро")
    return True


async def make_get_request(session, method, params, proxy, proxy_auth=None, rate_limiter=None):
    # logger.debug(f"Выполняется {method}")
    url = f"{HOST_URL}{method}"
    trace = {}
    try:
        if rate_limiter is not None:
            await rate_limiter.wait()
        async with session.get(url, params=params, proxy=proxy, proxy_auth=proxy_auth) as response:
            if check_result(url, response.content_type, response.status, await response.text()):
                return response
    except FastClick:
        logger.debug(f"fast click {url}")
        if "wakeup" in url:
            return
        await asyncio.sleep(1)
        return await make_get_request(session,
                                      method,
                                      params,
                                      proxy=proxy,
                                      proxy_auth=proxy_auth,
                                      rate_limiter=rate_limiter)
    except asyncio.TimeoutError as e:
        logger.debug(f"timeout error {url}")
        return await make_get_request(session,
                                      method,
                                      params,
                                      proxy=proxy,
                                      proxy_auth=proxy_auth,
                                      rate_limiter=rate_limiter)
    except Exception as e:
        raise e


async def make_post_request(session, method, data, proxy, proxy_auth=None, rate_limiter=None):
    # logger.debug(f"Выполняется {method} с данными {data}")
    url = f"{HOST_URL}{method}"
    trace = {}
    try:
        if rate_limiter is not None:
            await rate_limiter.wait()
        async with session.post(url, data=data, proxy=proxy, proxy_auth=proxy_auth) as response:
            if check_result(url, response.content_type, response.status, await response.text()):
                return response
    except asyncio.TimeoutError as e:
        logger.debug(f"timeout error {url}")
        return await make_post_request(session,
                                       method,
                                       data,
                                       proxy=proxy,
                                       proxy_auth=proxy_auth,
                                       rate_limiter=rate_limiter)
    except Exception as e:
        raise e
