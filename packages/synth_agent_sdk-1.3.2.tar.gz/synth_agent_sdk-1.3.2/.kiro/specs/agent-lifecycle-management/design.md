# Design Document: Agent Lifecycle Management

## Overview

This feature closes three gaps in the Synth SDK's agent management story:

1. **AgentCore Invocation Bridge** — The `/api/chat/stream` endpoint currently stubs out remote agent invocation. This design adds a `RemoteAgentInvoker` class that calls `InvokeAgentRuntime` on the `bedrock-agentcore` data plane via boto3, manages AgentCore sessions per conversation, and streams the response back as SSE events matching the existing token/done event format.

2. **Status-Aware UI Controls** — The `/api/agents` response gains an `actions` field computed from each agent's lifecycle status. The mapping is deterministic: ACTIVE → [connect, destroy], FAILED → [redeploy, destroy], CREATING/UPDATING → [] (disabled), DELETING → [] (disabled), local → [deploy]. The UI renders buttons based on this field rather than hardcoding Start/Stop.

3. **Destroy & Redeploy Flows** — New endpoints (`POST /api/agents/{name}/destroy`, `POST /api/agents/{name}/redeploy`, `POST /api/agents/{name}/deploy`) and a CLI command (`synth agents destroy`) enable teardown and recovery. Redeploy and deploy delegate to the existing `run_deploy()` pipeline.

All new code follows existing SDK patterns: boto3 is lazily imported behind try/except, credentials are resolved at call time from environment/profile, errors inherit from `SynthError`, and the UI server uses `run_in_executor` to avoid blocking the event loop.

## Architecture

```mermaid
graph TD
    subgraph Browser
        UI[Agents Tab] -->|fetch| API_AGENTS[GET /api/agents]
        UI -->|click Connect| API_CONNECT[POST /api/agents/.../connect]
        UI -->|click Destroy| API_DESTROY[POST /api/agents/.../destroy]
        UI -->|click Redeploy| API_REDEPLOY[POST /api/agents/.../redeploy]
        UI -->|click Deploy| API_DEPLOY[POST /api/agents/.../deploy]
        UI -->|click Disconnect| API_DISCONNECT[POST /api/agents/disconnect]
        UI -->|send prompt| CHAT[POST /api/chat/stream]
    end

    subgraph UI Server - server.py
        API_AGENTS -->|enriches| ACTION_MAP[_compute_actions]
        API_CONNECT -->|sets| REMOTE_STATE[_remote_agent state]
        API_DISCONNECT -->|clears| REMOTE_STATE
        CHAT -->|checks| REMOTE_STATE
        CHAT -->|if remote| INVOKER[RemoteAgentInvoker]
        CHAT -->|if local| LOCAL[Local agent.stream]
        API_DESTROY -->|delegates| DESTROY_CMD[_run_agentcore_cmd destroy]
        API_REDEPLOY -->|delegates| DEPLOY_FN[run_deploy]
        API_DEPLOY -->|delegates| DEPLOY_FN
    end

    subgraph Session Manager
        INVOKER -->|resolves| SESS_MGR[_session_store]
        SESS_MGR -->|tracks| SESS_MAP["conv_id → {session_id, last_used}"]
    end

    subgraph AWS
        INVOKER -->|InvokeAgentRuntime| DATA_PLANE[bedrock-agentcore<br>Data Plane]
        DESTROY_CMD -->|agentcore destroy| AC_CLI[AgentCore CLI]
        API_AGENTS -->|ListAgentRuntimes| CTRL_PLANE[bedrock-agentcore-control<br>Control Plane]
    end

    subgraph Data Layer
        DESTROY_CMD -->|removes| REG[Registry Store<br>~/.synth/registry.json]
        DEPLOY_FN -->|updates| REG
    end
```

### Key Design Decisions

1. **boto3 data plane over AgentCore CLI for invocation**: The `InvokeAgentRuntime` API provides structured JSON responses with session management. The CLI is used only for lifecycle operations (destroy) where no structured API is needed from the SDK side.

2. **Session store as module-level dict**: Sessions are ephemeral UI server state — they don't need persistence. A simple `dict[str, SessionEntry]` keyed by `"{agent_name}:{conv_id}"` is sufficient. The 15-minute idle timeout is checked on each invocation.

3. **`_compute_actions()` as a pure function**: The status-to-actions mapping is a pure function of the status string. This makes it trivially testable and keeps the `/api/agents` endpoint thin.

4. **Reuse `_run_agentcore_cmd` for destroy**: The existing helper already handles subprocess execution, credential errors, and timeout. Adding `"destroy"` as an action requires no structural changes.

5. **Redeploy/deploy run in executor**: `run_deploy()` is synchronous and long-running. It runs in `run_in_executor` to avoid blocking the FastAPI event loop, matching the pattern used by start/stop.

6. **Error sanitization as a standalone function**: `_sanitize_error_message()` is reusable across invocation errors, destroy errors, and deploy errors. It strips AWS key patterns, file paths, and stack traces using regex.

## Components and Interfaces

### 1. Remote Agent Invoker (`synth/cli/_ui_assets/server.py`)

A new class within the UI server module that handles the AgentCore data plane call.

```python
@dataclass
class SessionEntry:
    """Tracks an AgentCore session for a conversation."""
    session_id: str
    last_used: float  # time.time() epoch

class RemoteAgentInvoker:
    """Invokes a remote AgentCore agent via the data plane API.

    Parameters
    ----------
    agent_name:
        The AgentCore runtime name.
    region:
        AWS region of the deployed agent.
    aws_profile:
        Optional AWS profile for credential resolution.
    """

    _SESSION_IDLE_TIMEOUT = 900  # 15 minutes in seconds

    def __init__(
        self,
        agent_name: str,
        region: str,
        aws_profile: str | None = None,
    ) -> None: ...

    def invoke(
        self,
        prompt: str,
        conversation_id: str,
    ) -> dict[str, Any]:
        """Call InvokeAgentRuntime synchronously.

        Returns
        -------
        dict[str, Any]
            {"text": str, "session_id": str}
        """

    def _get_or_create_session(
        self,
        conversation_id: str,
    ) -> str:
        """Resolve session ID, creating a new one if expired or missing."""

    def _create_client(self) -> Any:
        """Create a boto3 client for bedrock-agentcore.

        Raises SynthConfigError if boto3 is not installed.
        """
```

The invoker is instantiated when `_remote_agent` is set (on connect) and called from the `chat_stream` endpoint's `generate()` function. It runs inside `run_in_executor` since boto3 calls are blocking.

### 2. Session Store (module-level in `server.py`)

```python
_session_store: dict[str, SessionEntry] = {}
```

Keyed by `"{agent_name}:{conversation_id}"`. Entries are created on first invocation and refreshed on each subsequent call. Expired entries (idle > 15 min) are replaced with a new session ID.

### 3. Action Computation (`server.py`)

```python
_STATUS_ACTIONS: dict[str, list[str]] = {
    "active": ["connect", "destroy"],
    "failed": ["redeploy", "destroy"],
    "creating": [],
    "updating": [],
    "deleting": [],
    "local": ["deploy"],
    "unknown": ["destroy"],
}

def _compute_actions(status: str) -> list[str]:
    """Return valid UI actions for an agent based on its status.

    Parameters
    ----------
    status:
        Lowercase agent status string.

    Returns
    -------
    list[str]
        Action identifiers the UI should render as buttons.
    """
    return _STATUS_ACTIONS.get(status, [])
```

### 4. New API Endpoints (`server.py`)

```python
@app.post("/api/agents/{name}/destroy")
async def destroy_agent(name: str) -> JSONResponse:
    """Destroy an AgentCore agent runtime and remove from registry."""

@app.post("/api/agents/{name}/redeploy")
async def redeploy_agent(name: str) -> JSONResponse:
    """Redeploy a failed agent using stored configuration."""

@app.post("/api/agents/{name}/deploy")
async def deploy_agent(name: str) -> JSONResponse:
    """Deploy a local-only agent to AgentCore."""

@app.post("/api/agents/disconnect")
async def disconnect_agent() -> JSONResponse:
    """Clear remote agent routing and return to local agent."""
```

### 5. Modified `/api/agents` Response

The existing `list_agents` endpoint is modified to include an `actions` field in each agent dict:

```python
# In list_agents(), after building each agent dict:
agent_dict["actions"] = _compute_actions(agent_dict["status"])
```

### 6. Modified `/api/chat/stream` Endpoint

The `generate()` inner function gains a remote-agent branch before the existing multi-agent/single-agent logic:

```python
if is_remote:
    invoker = RemoteAgentInvoker(
        agent_name=_remote_agent["name"],
        region=_remote_agent["region"],
        aws_profile=_remote_agent.get("aws_profile"),
    )
    try:
        result = await loop.run_in_executor(
            None, invoker.invoke, prompt, conv_id,
        )
        yield f"data: {json.dumps({'type': 'token', 'text': result['text']})}\n\n"
        # ... emit done event with metadata
    except SynthConfigError as exc:
        yield f"data: {json.dumps({'type': 'error', 'error': str(exc)})}\n\n"
    return
```

### 7. CLI Destroy Command (`synth/cli/agents_cmd.py`)

```python
@agents_group.command("destroy")
@click.argument("name")
def agents_destroy_cmd(name: str) -> None:
    """Destroy a deployed AgentCore agent runtime."""
```

Follows the same pattern as `agents_start_cmd` / `agents_stop_cmd`: look up the agent in the registry, resolve region/profile, call `agentcore destroy` via subprocess, and remove from registry on success.

### 8. Error Sanitization (`server.py`)

```python
_AWS_KEY_PATTERN = re.compile(
    r'(A[SK]IA[A-Z0-9]{16}|[A-Za-z0-9/+=]{40})',
)
_FILE_PATH_PATTERN = re.compile(
    r'(/[a-zA-Z0-9._-]+){3,}\.py',
)
_TRACEBACK_PATTERN = re.compile(
    r'Traceback \(most recent call last\):.*?(?=\n\S|\Z)',
    re.DOTALL,
)

def _sanitize_error_message(message: str) -> str:
    """Remove sensitive details from error messages.

    Strips AWS key patterns, internal file paths, and stack traces
    while preserving the error type and human-readable description.
    """
```

## Data Models

### SessionEntry

| Field | Type | Description |
|-------|------|-------------|
| session_id | str | UUID identifying the AgentCore session |
| last_used | float | `time.time()` epoch of last invocation |

### Remote Agent State (`_remote_agent`)

The existing `_remote_agent: dict[str, str] | None` module variable is unchanged. When set:

| Key | Type | Description |
|-----|------|-------------|
| name | str | AgentCore runtime name |
| region | str | AWS region |
| aws_profile | str | AWS profile name (empty string if default) |

### Agent List Response (modified)

Each agent object in the `GET /api/agents` response gains:

| Field | Type | Description |
|-------|------|-------------|
| actions | list[str] | Valid UI actions: "connect", "destroy", "redeploy", "deploy" |

### Status-to-Actions Mapping

| Status | Actions | UI Rendering |
|--------|---------|-------------|
| active | ["connect", "destroy"] | Connect button + Destroy button |
| failed | ["redeploy", "destroy"] | Redeploy button + Destroy button |
| creating | [] | Spinner / disabled |
| updating | [] | Spinner / disabled |
| deleting | [] | Disabled |
| local | ["deploy"] | Deploy button |
| unknown | ["destroy"] | Destroy button |

### InvokeAgentRuntime Request Shape

```python
{
    "agentRuntimeId": "<agent_name>",
    "sessionId": "<uuid>",
    "input": {"text": "<prompt>"},
}
```

### InvokeAgentRuntime Response Shape

```python
{
    "output": {"text": "<response_text>"},
    "sessionId": "<uuid>",
    "contentType": "application/json",
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

The following properties were derived from the acceptance criteria in the requirements document. Each property is universally quantified and suitable for property-based testing with Hypothesis.

### Property 1: Invocation payload correctness

*For any* non-empty prompt string and any valid session ID, calling `RemoteAgentInvoker.invoke()` SHALL produce an `InvokeAgentRuntime` call whose payload contains the prompt in `input.text` and the session ID in `sessionId`.

**Validates: Requirements 1.1**

### Property 2: SSE response contains agent output

*For any* response text returned by the AgentCore data plane, the SSE output from the chat stream endpoint SHALL contain a token event with that exact text and a subsequent done event.

**Validates: Requirements 1.2**

### Property 3: Session reuse within a conversation

*For any* sequence of two or more invocations with the same agent name and conversation ID where the time between invocations is less than 15 minutes, all invocations SHALL use the same session ID.

**Validates: Requirements 1.3, 8.2**

### Property 4: Expired session replacement

*For any* session entry whose `last_used` timestamp is more than 15 minutes in the past, the next invocation for that conversation SHALL generate a new session ID that differs from the expired one.

**Validates: Requirements 1.4, 8.4**

### Property 5: Error sanitization removes sensitive patterns

*For any* string containing AWS access key patterns (AKIA/ASIA followed by 16 alphanumeric characters), secret key patterns (40-character base64-like strings), internal file paths, or Python stack traces, `_sanitize_error_message()` SHALL return a string that contains none of those patterns.

**Validates: Requirements 1.6, 9.1, 9.2**

### Property 6: Error sanitization preserves error type

*For any* error message of the form `"ErrorType: description"`, `_sanitize_error_message()` SHALL return a string that still contains `"ErrorType"`.

**Validates: Requirements 9.3**

### Property 7: Status-to-actions mapping completeness

*For any* agent status string in the set {active, failed, creating, updating, deleting, local, unknown}, `_compute_actions(status)` SHALL return the expected action list as defined in the status-to-actions mapping table.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**

### Property 8: Actions field present in agent list response

*For any* list of agents returned by `GET /api/agents`, every agent object SHALL contain an `actions` field whose value equals `_compute_actions(agent["status"])`.

**Validates: Requirements 3.6**

### Property 9: Destroy removes agent from registry

*For any* agent name present in the Registry_Store, after a successful destroy operation (mocked subprocess returning 0), calling `RegistryStore.get_agent(name)` SHALL return `None`.

**Validates: Requirements 4.2, 7.2**

### Property 10: Unique session per new conversation

*For any* set of distinct conversation IDs, calling `_get_or_create_session()` for each SHALL produce distinct session IDs.

**Validates: Requirements 8.1, 8.3**

### Property 11: Connect replaces previous remote agent

*For any* two distinct agent names, connecting to the first then connecting to the second SHALL result in `_remote_agent["name"]` equaling the second agent name.

**Validates: Requirements 2.2**

### Property 12: Deploy/redeploy delegates with correct source file

*For any* agent record in the Registry_Store with a valid `source_file`, the redeploy and deploy endpoints SHALL invoke `run_deploy` with `file=record.source_file`.

**Validates: Requirements 5.1, 6.1**

## Error Handling

### Invocation Errors

| Scenario | Detection | User-Facing Message |
|----------|-----------|-------------------|
| boto3 not installed | `ImportError` on `import boto3` | "AgentCore invocation requires boto3. Install with: pip install synth-agent-sdk[agentcore]" |
| Credential expired/invalid | `botocore.exceptions.ClientError` with "expired", "token", or "credentials" in message | "AWS credentials expired or invalid. Run `aws sso login` to refresh." |
| Agent runtime not found | `botocore.exceptions.ClientError` with "ResourceNotFoundException" | "Agent '{name}' not found in AgentCore. It may have been deleted." |
| Invocation timeout | `botocore.exceptions.ReadTimeoutError` | "AgentCore invocation timed out. The agent may be starting up — try again in a moment." |
| Other API error | Any other `botocore.exceptions.ClientError` | Sanitized error message via `_sanitize_error_message()` |

### Destroy Errors

Handled by the existing `_run_agentcore_cmd` helper. Credential errors return the standard refresh message. Other errors return the sanitized stderr/stdout from the subprocess.

### Deploy/Redeploy Errors

| Scenario | Detection | User-Facing Message |
|----------|-----------|-------------------|
| Source file missing | `not Path(source_file).exists()` | "Source file '{path}' not found. Re-deploy manually with: synth deploy --target agentcore <file>" |
| Deploy wizard failure | `SystemExit` or `Exception` from `run_deploy()` | Sanitized exception message |

### Error Sanitization Rules

The `_sanitize_error_message()` function applies these transformations in order:

1. Strip Python tracebacks (`Traceback (most recent call last):` through the final exception line)
2. Replace AWS access key IDs (`AKIA...` / `ASIA...` + 16 chars) with `[REDACTED_KEY]`
3. Replace 40-char base64-like strings (potential secret keys) with `[REDACTED_SECRET]`
4. Replace absolute file paths (`/path/to/file.py`) with `[internal path]`
5. Trim to first 500 characters to prevent oversized error messages

## Testing Strategy

### Unit Tests

**`tests/unit/test_remote_invoker.py`**:
- `TestRemoteAgentInvoker`:
  - `test_invoke_calls_data_plane`: mock boto3 client, verify `invoke_agent_runtime` called with correct payload
  - `test_invoke_returns_response_text`: mock response, verify returned dict has `text` field
  - `test_invoke_boto3_missing`: patch `import boto3` to raise ImportError, verify SynthConfigError
  - `test_invoke_credential_error`: mock ClientError with "expired token", verify credential message
  - `test_invoke_resource_not_found`: mock ResourceNotFoundException, verify agent-not-found message
- `TestSessionStore`:
  - `test_new_conversation_creates_session`: first call creates entry in store
  - `test_same_conversation_reuses_session`: second call returns same session ID
  - `test_expired_session_creates_new`: set last_used to 16 min ago, verify new session ID
  - `test_different_conversations_different_sessions`: two conv IDs get different sessions

**`tests/unit/test_lifecycle_endpoints.py`**:
- `TestDestroyEndpoint`:
  - `test_destroy_success_removes_from_registry`: mock subprocess success, verify registry removal
  - `test_destroy_credential_error`: mock credential failure, verify error message
  - `test_destroy_agent_not_found`: no record in registry, verify 400 response
- `TestRedeployEndpoint`:
  - `test_redeploy_success`: mock run_deploy success, verify 200 response
  - `test_redeploy_missing_source_file`: source file doesn't exist, verify error
  - `test_redeploy_deploy_failure`: mock run_deploy raising, verify error response
- `TestDeployEndpoint`:
  - `test_deploy_success`: mock run_deploy success, verify 200
  - `test_deploy_missing_source_file`: verify error
- `TestDisconnectEndpoint`:
  - `test_disconnect_clears_remote_agent`: verify _remote_agent is None after disconnect
- `TestComputeActions`:
  - `test_active_actions`: verify ["connect", "destroy"]
  - `test_failed_actions`: verify ["redeploy", "destroy"]
  - `test_creating_actions`: verify []
  - `test_local_actions`: verify ["deploy"]
- `TestListAgentsActions`:
  - `test_actions_field_present`: mock agents, verify each has `actions` field

**`tests/unit/test_agents_destroy_cmd.py`**:
- `TestAgentsDestroyCmd`:
  - `test_destroy_success`: mock subprocess, verify OK output and registry removal
  - `test_destroy_not_found`: verify error with available names
  - `test_destroy_credential_error`: verify credential refresh message
  - `test_destroy_agentcore_cli_not_found`: verify install hint

### Property Tests (`tests/property/test_lifecycle_props.py`)

Property-based tests using Hypothesis with minimum 100 iterations per property. Each test is tagged with its design property reference.

```python
# Feature: agent-lifecycle-management, Property 1: Invocation payload correctness
@given(prompt=st.text(min_size=1, max_size=500), session_id=st.uuids())
@settings(max_examples=100)
def test_invocation_payload_correctness(prompt, session_id): ...

# Feature: agent-lifecycle-management, Property 3: Session reuse within a conversation
@given(
    agent_name=st.text(min_size=1, max_size=48).filter(lambda s: s[0].isalpha()),
    conv_id=st.text(min_size=1, max_size=50),
    num_calls=st.integers(min_value=2, max_value=10),
)
@settings(max_examples=100)
def test_session_reuse_within_conversation(agent_name, conv_id, num_calls): ...

# Feature: agent-lifecycle-management, Property 4: Expired session replacement
@given(
    conv_id=st.text(min_size=1, max_size=50),
    idle_seconds=st.integers(min_value=901, max_value=36000),
)
@settings(max_examples=100)
def test_expired_session_replacement(conv_id, idle_seconds): ...

# Feature: agent-lifecycle-management, Property 5: Error sanitization removes sensitive patterns
@given(
    base_msg=st.text(min_size=1, max_size=200),
    aws_key=st.from_regex(r'AKIA[A-Z0-9]{16}', fullmatch=True),
    file_path=st.from_regex(r'/[a-z]+/[a-z]+/[a-z]+\.py', fullmatch=True),
)
@settings(max_examples=100)
def test_sanitization_removes_sensitive_patterns(base_msg, aws_key, file_path): ...

# Feature: agent-lifecycle-management, Property 6: Error sanitization preserves error type
@given(
    error_type=st.sampled_from([
        "ValueError", "TypeError", "ClientError",
        "SynthConfigError", "RuntimeError",
    ]),
    description=st.text(min_size=1, max_size=100),
)
@settings(max_examples=100)
def test_sanitization_preserves_error_type(error_type, description): ...

# Feature: agent-lifecycle-management, Property 7: Status-to-actions mapping completeness
@given(status=st.sampled_from([
    "active", "failed", "creating", "updating",
    "deleting", "local", "unknown",
]))
@settings(max_examples=100)
def test_status_to_actions_mapping(status): ...

# Feature: agent-lifecycle-management, Property 9: Destroy removes agent from registry
@given(record=st.builds(RegistryRecord, ...))
@settings(max_examples=100)
def test_destroy_removes_from_registry(record, tmp_path): ...

# Feature: agent-lifecycle-management, Property 10: Unique session per new conversation
@given(conv_ids=st.lists(
    st.text(min_size=1, max_size=50),
    min_size=2, max_size=20, unique=True,
))
@settings(max_examples=100)
def test_unique_session_per_conversation(conv_ids): ...

# Feature: agent-lifecycle-management, Property 11: Connect replaces previous remote agent
@given(
    name1=st.text(min_size=1, max_size=48),
    name2=st.text(min_size=1, max_size=48),
)
@settings(max_examples=100)
def test_connect_replaces_previous(name1, name2): ...
```

### Hypothesis Strategies

Reuse the existing strategies from `tests/property/test_registry_props.py` for `RegistryRecord` generation. Additional strategies:

- `prompt`: `st.text(min_size=1, max_size=500).filter(lambda s: s.strip())`
- `session_id`: `st.uuids().map(str)`
- `conv_id`: `st.text(min_size=1, max_size=50).filter(lambda s: s.strip())`
- `agent_status`: `st.sampled_from(["active", "failed", "creating", "updating", "deleting", "local", "unknown"])`
- `aws_key`: `st.from_regex(r'AKIA[A-Z0-9]{16}', fullmatch=True)`

### Testing Library

- **Property-based testing**: Hypothesis (already used in the project)
- **Test runner**: pytest
- **Async tests**: `@pytest.mark.asyncio` for FastAPI endpoint tests
- **CLI testing**: Click's `CliRunner` for destroy command tests
- **HTTP testing**: `httpx.AsyncClient` with FastAPI's `TestClient` for endpoint tests
