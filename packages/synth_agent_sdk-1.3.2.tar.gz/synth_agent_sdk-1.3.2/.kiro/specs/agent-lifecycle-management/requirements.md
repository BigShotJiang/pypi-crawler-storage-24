# Requirements Document

## Introduction

The Synth SDK's agent registry feature provides local tracking and UI display of deployed AgentCore agents. Three gaps remain: (1) the "Connect" button in the UI sets routing state but never actually invokes the remote agent — the AgentCore data plane call is stubbed out; (2) the UI shows Start/Stop buttons for every agent regardless of lifecycle state, even though AgentCore runtimes are serverless and have no start/stop concept; (3) agents in FAILED state have no recovery path from the UI. This feature closes all three gaps by implementing the AgentCore invocation bridge, status-aware UI controls, and a redeploy flow for failed agents.

## Glossary

- **Invocation_Bridge**: The server-side component in `server.py` that translates a user chat prompt into an `InvokeAgentRuntime` call to the AgentCore data plane and streams the response back as SSE events.
- **AgentCore_Data_Plane**: The AWS `bedrock-agentcore` boto3 service that provides `InvokeAgentRuntime` for synchronous invocation of deployed agent runtimes.
- **Session**: An AgentCore isolation unit identified by a `sessionId`. Each session runs in a dedicated microVM with a 15-minute idle timeout and 8-hour maximum lifetime.
- **SSE_Stream**: Server-Sent Events stream used by the `/api/chat/stream` endpoint to deliver token, tool_call, tool_result, and done events to the browser UI.
- **Agent_Status**: One of the lifecycle states returned by `ListAgentRuntimes`: READY (mapped to ACTIVE), CREATING, CREATE_FAILED (mapped to FAILED), UPDATING, UPDATE_FAILED (mapped to FAILED), or DELETING.
- **UI_Server**: The FastAPI application in `synth/cli/_ui_assets/server.py` that serves the browser dashboard and API endpoints.
- **Registry_Store**: The `RegistryStore` class in `synth/cli/registry.py` that manages the local `~/.synth/registry.json` file.
- **Deploy_Wizard**: The `run_deploy()` function in `synth/cli/deploy_cmd.py` that executes the seven-stage deployment pipeline.

## Requirements

### Requirement 1: Invoke Remote Agent via AgentCore Data Plane

**User Story:** As a developer, I want to chat with a deployed AgentCore agent through the browser UI, so that I can test and interact with my remote agent without leaving the Synth dashboard.

#### Acceptance Criteria

1. WHEN a user sends a chat prompt while connected to a remote agent, THE Invocation_Bridge SHALL call `InvokeAgentRuntime` on the AgentCore_Data_Plane with the prompt and a session identifier.
2. WHEN the AgentCore_Data_Plane returns a response, THE Invocation_Bridge SHALL emit the response text as SSE token events followed by a done event containing token counts and latency.
3. WHEN the Invocation_Bridge invokes a remote agent, THE Invocation_Bridge SHALL reuse the same Session for messages within a single conversation to preserve context.
4. WHEN a Session has been idle for more than 15 minutes, THE Invocation_Bridge SHALL create a new Session for the next invocation rather than reusing the expired one.
5. IF the `InvokeAgentRuntime` call fails with a credential error, THEN THE Invocation_Bridge SHALL emit an SSE error event with a message instructing the user to refresh AWS credentials.
6. IF the `InvokeAgentRuntime` call fails with a non-credential error, THEN THE Invocation_Bridge SHALL emit an SSE error event containing the sanitized error message without exposing internal stack traces or credential fragments.
7. IF boto3 is not installed, THEN THE Invocation_Bridge SHALL emit an SSE error event instructing the user to install `synth-agent-sdk[agentcore]`.

### Requirement 2: Disconnect from Remote Agent

**User Story:** As a developer, I want to disconnect from a remote agent and return to my local agent, so that I can switch between remote and local testing.

#### Acceptance Criteria

1. WHEN a user sends a disconnect request, THE UI_Server SHALL clear the remote agent routing state and resume routing prompts to the local agent.
2. WHEN a user connects to a different remote agent while already connected, THE UI_Server SHALL replace the current remote agent routing state with the new agent.

### Requirement 3: Status-Aware UI Button Rendering

**User Story:** As a developer, I want the Agents tab to show contextually appropriate action buttons based on each agent's lifecycle state, so that I can only perform valid operations on each agent.

#### Acceptance Criteria

1. WHEN an agent has ACTIVE status, THE UI_Server SHALL return action buttons for "Connect" and "Destroy" in the agent list response.
2. WHEN an agent has FAILED status, THE UI_Server SHALL return action buttons for "Redeploy" and "Destroy" in the agent list response.
3. WHEN an agent has CREATING or UPDATING status, THE UI_Server SHALL return a disabled state indicator with no actionable buttons in the agent list response.
4. WHEN an agent has DELETING status, THE UI_Server SHALL return a disabled state indicator with no actionable buttons in the agent list response.
5. WHEN an agent has "local" status (exists in registry but not in AWS), THE UI_Server SHALL return a "Deploy" action button in the agent list response.
6. THE UI_Server SHALL include an `actions` field in each agent object of the `/api/agents` response containing the list of valid actions for that agent's current status.

### Requirement 4: Destroy Agent Runtime

**User Story:** As a developer, I want to destroy a deployed agent from the UI, so that I can clean up agents I no longer need without using the CLI.

#### Acceptance Criteria

1. WHEN a user requests destruction of an agent, THE UI_Server SHALL call the AgentCore CLI `agentcore destroy` command with the agent name and region.
2. WHEN the destroy command succeeds, THE UI_Server SHALL remove the agent from the Registry_Store and return a success response.
3. IF the destroy command fails, THEN THE UI_Server SHALL return an error response with the sanitized error message.
4. IF the destroy command fails with a credential error, THEN THE UI_Server SHALL return an error response instructing the user to refresh AWS credentials.

### Requirement 5: Redeploy Failed Agent

**User Story:** As a developer, I want to redeploy an agent that is in a FAILED state from the UI, so that I can recover from deployment failures without manually re-running the deploy command.

#### Acceptance Criteria

1. WHEN a user requests redeployment of a failed agent, THE UI_Server SHALL invoke the Deploy_Wizard with the agent's stored source file from the Registry_Store.
2. WHEN the Deploy_Wizard completes successfully, THE UI_Server SHALL return a success response with the updated agent metadata.
3. IF the agent's source file from the Registry_Store does not exist on disk, THEN THE UI_Server SHALL return an error response indicating the source file is missing and suggesting the user re-deploy manually via `synth deploy`.
4. IF the Deploy_Wizard fails, THEN THE UI_Server SHALL return an error response with the sanitized failure message.

### Requirement 6: Deploy Local-Only Agent from UI

**User Story:** As a developer, I want to deploy a local-only agent (registered but not yet in AWS) from the UI, so that I can initiate deployments without switching to the CLI.

#### Acceptance Criteria

1. WHEN a user requests deployment of a local-only agent, THE UI_Server SHALL invoke the Deploy_Wizard with the agent's stored source file from the Registry_Store.
2. IF the agent's source file does not exist on disk, THEN THE UI_Server SHALL return an error response indicating the source file is missing.
3. WHEN the Deploy_Wizard completes successfully, THE UI_Server SHALL return a success response.

### Requirement 7: CLI Destroy Command

**User Story:** As a developer, I want a `synth agents destroy` CLI command, so that I can tear down deployed agents from the terminal.

#### Acceptance Criteria

1. WHEN a user runs `synth agents destroy <name>`, THE CLI SHALL call the AgentCore CLI `agentcore destroy` command with the agent name and region.
2. WHEN the destroy command succeeds, THE CLI SHALL remove the agent from the Registry_Store and print a success message.
3. IF the agent is not found in the Registry_Store or in AWS, THEN THE CLI SHALL print an error message listing available agent names.
4. IF the destroy command fails with a credential error, THEN THE CLI SHALL print a message instructing the user to refresh AWS credentials.

### Requirement 8: Session Management for Remote Invocations

**User Story:** As a developer, I want the system to manage AgentCore sessions automatically, so that my conversation context is preserved across messages and expired sessions are handled transparently.

#### Acceptance Criteria

1. THE Invocation_Bridge SHALL generate a unique session identifier for each new conversation with a remote agent.
2. WHEN a conversation already has an active session, THE Invocation_Bridge SHALL reuse that session identifier for subsequent invocations.
3. THE Invocation_Bridge SHALL store the mapping of conversation identifiers to session identifiers and their last-used timestamps.
4. WHEN a session's last-used timestamp exceeds 15 minutes, THE Invocation_Bridge SHALL treat the session as expired and generate a new session identifier for the next invocation.

### Requirement 9: Error Message Sanitization

**User Story:** As a developer, I want error messages from remote agent invocations to be informative without exposing sensitive internal details, so that I can debug issues safely.

#### Acceptance Criteria

1. THE Invocation_Bridge SHALL remove AWS access key patterns, secret key patterns, and session token fragments from error messages before returning them to the client.
2. THE Invocation_Bridge SHALL remove internal file paths and full stack traces from error messages before returning them to the client.
3. WHEN sanitizing error messages, THE Invocation_Bridge SHALL preserve the error type and a human-readable description of the failure.
