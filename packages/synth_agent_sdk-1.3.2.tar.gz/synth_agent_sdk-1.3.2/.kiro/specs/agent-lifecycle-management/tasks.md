# Implementation Plan: Agent Lifecycle Management

## Overview

Implements the AgentCore invocation bridge, status-aware UI controls, destroy/redeploy/deploy endpoints, and the CLI destroy command. All changes target existing modules (`server.py`, `agents_cmd.py`) plus new test files. The implementation proceeds bottom-up: utility functions first, then the invoker, then endpoints, then CLI, then wiring.

## Tasks

- [x] 1. Add error sanitization utility and status-to-actions mapping
  - [x] 1.1 Implement `_sanitize_error_message()` in `synth/cli/_ui_assets/server.py`
    - Add `_AWS_KEY_PATTERN`, `_FILE_PATH_PATTERN`, `_TRACEBACK_PATTERN` regex constants
    - Implement the function that strips AWS keys, file paths, tracebacks, and trims to 500 chars
    - _Requirements: 9.1, 9.2, 9.3_
  - [x] 1.2 Implement `_compute_actions()` and `_STATUS_ACTIONS` mapping in `synth/cli/_ui_assets/server.py`
    - Add the `_STATUS_ACTIONS` dict mapping status strings to action lists
    - Implement `_compute_actions(status: str) -> list[str]` as a pure function
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6_
  - [x] 1.3 Write property tests for error sanitization and actions mapping
    - **Property 5: Error sanitization removes sensitive patterns**
    - **Validates: Requirements 1.6, 9.1, 9.2**
    - **Property 6: Error sanitization preserves error type**
    - **Validates: Requirements 9.3**
    - **Property 7: Status-to-actions mapping completeness**
    - **Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**

- [x] 2. Implement session management and RemoteAgentInvoker
  - [x] 2.1 Add `SessionEntry` dataclass and `_session_store` module variable in `synth/cli/_ui_assets/server.py`
    - Define `SessionEntry` with `session_id: str` and `last_used: float`
    - Add `_session_store: dict[str, SessionEntry] = {}` at module level
    - _Requirements: 8.1, 8.3_
  - [x] 2.2 Implement `RemoteAgentInvoker` class in `synth/cli/_ui_assets/server.py`
    - Constructor takes `agent_name`, `region`, `aws_profile`
    - `_create_client()` lazily imports boto3, creates `bedrock-agentcore` client with session/region/profile, raises `SynthConfigError` if boto3 missing
    - `_get_or_create_session(conversation_id)` checks `_session_store` for existing non-expired session, creates new UUID if missing or expired (15 min idle timeout), updates `last_used`
    - `invoke(prompt, conversation_id)` calls `invoke_agent_runtime` with `agentRuntimeId`, `sessionId`, and `input.text`, returns `{"text": ..., "session_id": ...}`
    - Handle credential errors, resource-not-found, and timeout with appropriate error messages using `_sanitize_error_message()`
    - _Requirements: 1.1, 1.4, 1.5, 1.6, 1.7, 8.1, 8.2, 8.3, 8.4_
  - [x] 2.3 Write property tests for session management
    - **Property 3: Session reuse within a conversation**
    - **Validates: Requirements 1.3, 8.2**
    - **Property 4: Expired session replacement**
    - **Validates: Requirements 1.4, 8.4**
    - **Property 10: Unique session per new conversation**
    - **Validates: Requirements 8.1, 8.3**
  - [x] 2.4 Write property test for invocation payload
    - **Property 1: Invocation payload correctness**
    - **Validates: Requirements 1.1**

- [x] 3. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 4. Wire remote invocation into chat stream and add disconnect endpoint
  - [x] 4.1 Modify `chat_stream` in `synth/cli/_ui_assets/server.py` to handle remote agent invocation
    - Replace the stub comment with actual `RemoteAgentInvoker` usage inside the `is_remote` branch
    - Instantiate invoker from `_remote_agent` state, call `invoke()` via `run_in_executor`
    - Emit SSE token event with response text, then done event with latency
    - Catch `SynthConfigError` and emit SSE error event
    - Save conversation messages to `_conversations` and persist
    - _Requirements: 1.1, 1.2, 1.5, 1.6, 1.7_
  - [x] 4.2 Add `POST /api/agents/disconnect` endpoint in `synth/cli/_ui_assets/server.py`
    - Clear `_remote_agent` to `None`
    - Return `{"success": True, "message": "Disconnected from remote agent"}`
    - _Requirements: 2.1_
  - [x] 4.3 Write property test for SSE response and connect/disconnect
    - **Property 2: SSE response contains agent output**
    - **Validates: Requirements 1.2**
    - **Property 11: Connect replaces previous remote agent**
    - **Validates: Requirements 2.2**

- [x] 5. Add status-aware actions to agent list and new lifecycle endpoints
  - [x] 5.1 Modify `list_agents` endpoint to include `actions` field
    - After building each agent dict, add `agent_dict["actions"] = _compute_actions(agent_dict["status"])`
    - _Requirements: 3.6_
  - [x] 5.2 Add `POST /api/agents/{name}/destroy` endpoint in `synth/cli/_ui_assets/server.py`
    - Look up agent in registry for region/profile, fall back to defaults
    - Call `_run_agentcore_cmd("destroy", name, region, profile)` via `run_in_executor`
    - On success, call `RegistryStore().remove_agent(name)`
    - On failure, return sanitized error; detect credential errors
    - _Requirements: 4.1, 4.2, 4.3, 4.4_
  - [x] 5.3 Add `POST /api/agents/{name}/redeploy` endpoint in `synth/cli/_ui_assets/server.py`
    - Look up agent in registry, verify source file exists on disk
    - Call `run_deploy(target="agentcore", dry_run=False, file=record.source_file)` via `run_in_executor`
    - Return success or sanitized error
    - _Requirements: 5.1, 5.2, 5.3, 5.4_
  - [x] 5.4 Add `POST /api/agents/{name}/deploy` endpoint in `synth/cli/_ui_assets/server.py`
    - Same pattern as redeploy but for local-only agents
    - Verify source file exists, call `run_deploy`, return result
    - _Requirements: 6.1, 6.2, 6.3_
  - [x] 5.5 Write property test for actions field in agent list
    - **Property 8: Actions field present in agent list response**
    - **Validates: Requirements 3.6**
  - [x] 5.6 Write property test for destroy registry removal
    - **Property 9: Destroy removes agent from registry**
    - **Validates: Requirements 4.2, 7.2**
  - [x] 5.7 Write property test for deploy/redeploy delegation
    - **Property 12: Deploy/redeploy delegates with correct source file**
    - **Validates: Requirements 5.1, 6.1**

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Add CLI destroy command
  - [x] 7.1 Implement `agents_destroy_cmd` in `synth/cli/agents_cmd.py`
    - Add `@agents_group.command("destroy")` with `@click.argument("name")`
    - Look up agent in registry; if not found, query live status; if still not found, call `_agent_not_found`
    - Resolve region/profile from record or defaults
    - Find agentcore binary, build `[agentcore, destroy, name, --region, region]` command
    - Run subprocess, handle success (remove from registry, print OK), credential errors, and general failures
    - _Requirements: 7.1, 7.2, 7.3, 7.4_
  - [x] 7.2 Write unit tests for CLI destroy command
    - Test destroy success with registry removal
    - Test agent not found error
    - Test credential error message
    - Test agentcore CLI not found
    - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [x] 8. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- boto3 is always lazily imported behind try/except to keep it an optional dependency
