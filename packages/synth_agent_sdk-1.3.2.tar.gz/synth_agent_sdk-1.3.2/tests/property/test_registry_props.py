# Feature: agent-registry
"""Property-based tests for the agent registry data layer.

Validates the following properties and requirements:

- **Property 1: Registry data round-trip** — Requirements 1.6, 1.7, 7.2
- **Property 2: Add-then-get consistency** — Requirements 1.1
- **Property 3: Upsert deduplication** — Requirements 1.3
- **Property 4: Remove-then-get absence** — Requirements 1.5
- **Property 5: Validation rejects incomplete records** — Requirements 1.4
- **Property 6: CLI list output contains all agents** — Requirements 2.1
- **Property 7: CLI status output contains all fields** — Requirements 3.1
- **Property 8: API response contains all agents** — Requirements 5.2
- **Property 9: No credentials in serialized registry** — Requirements 6.1
"""

from __future__ import annotations

import json
import re
import tempfile
from datetime import timezone
from pathlib import Path

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.cli.registry import (
    RegistryData,
    RegistryRecord,
    RegistryStore,
    ServerInfo,
)

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

agent_name_st = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N"), whitelist_characters="_-"
    ),
    min_size=1,
    max_size=48,
).filter(lambda s: s[0].isalpha())

region_st = st.sampled_from(
    ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"]
)

model_id_st = st.text(min_size=1, max_size=100).filter(lambda s: s.strip())

source_file_st = st.text(min_size=1, max_size=200).filter(
    lambda s: s.strip()
)

deployed_at_st = st.datetimes(timezones=st.just(timezone.utc)).map(
    lambda dt: dt.isoformat()
)

aws_profile_st = st.one_of(
    st.none(),
    st.text(min_size=1, max_size=50).filter(lambda s: s.strip()),
)

registry_record_st = st.builds(
    RegistryRecord,
    agent_name=agent_name_st,
    region=region_st,
    model_id=model_id_st,
    source_file=source_file_st,
    deployed_at=deployed_at_st,
    aws_profile=aws_profile_st,
)

server_info_st = st.builds(
    ServerInfo,
    pid=st.integers(min_value=1, max_value=2**31),
    port=st.integers(min_value=1024, max_value=65535),
    started_at=deployed_at_st,
)

registry_data_st = st.builds(
    RegistryData,
    agents=st.lists(registry_record_st, max_size=10),
    server=st.one_of(st.none(), server_info_st),
)

# Required fields for a valid RegistryRecord
_REQUIRED_FIELDS = [
    "agent_name", "region", "model_id", "source_file", "deployed_at",
]


# ---------------------------------------------------------------------------
# Property 1: Registry data round-trip
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(data=registry_data_st)
def test_registry_round_trip(data: RegistryData, tmp_path_factory):
    """**Property 1: Registry data round-trip**

    For any valid RegistryData, serialize then deserialize produces
    equivalent data.

    **Validates: Requirements 1.6, 1.7, 7.2**
    """
    tmp_path = tmp_path_factory.mktemp("roundtrip")
    store = RegistryStore(path=tmp_path / "registry.json")
    store.save(data)
    loaded = store.load()

    assert len(loaded.agents) == len(data.agents)

    for original, restored in zip(data.agents, loaded.agents):
        assert restored.agent_name == original.agent_name
        assert restored.region == original.region
        assert restored.model_id == original.model_id
        assert restored.source_file == original.source_file
        assert restored.deployed_at == original.deployed_at
        assert restored.aws_profile == original.aws_profile

    if data.server is None:
        assert loaded.server is None
    else:
        assert loaded.server is not None
        assert loaded.server.pid == data.server.pid
        assert loaded.server.port == data.server.port
        assert loaded.server.started_at == data.server.started_at


# ---------------------------------------------------------------------------
# Property 2: Add-then-get consistency
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(record=registry_record_st)
def test_add_then_get(record: RegistryRecord, tmp_path_factory):
    """**Property 2: Add-then-get consistency**

    For any valid RegistryRecord, after add_agent(), get_agent() returns
    an equivalent record.

    **Validates: Requirements 1.1**
    """
    tmp_path = tmp_path_factory.mktemp("addget")
    store = RegistryStore(path=tmp_path / "registry.json")
    store.add_agent(record)
    retrieved = store.get_agent(record.agent_name)

    assert retrieved is not None
    assert retrieved.agent_name == record.agent_name
    assert retrieved.region == record.region
    assert retrieved.model_id == record.model_id
    assert retrieved.source_file == record.source_file
    assert retrieved.deployed_at == record.deployed_at
    assert retrieved.aws_profile == record.aws_profile


# ---------------------------------------------------------------------------
# Property 3: Upsert deduplication
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    record1=registry_record_st,
    record2=registry_record_st,
)
def test_upsert_deduplication(
    record1: RegistryRecord,
    record2: RegistryRecord,
    tmp_path_factory,
):
    """**Property 3: Upsert deduplication**

    Adding two records with the same agent_name results in exactly one
    record matching the second.

    **Validates: Requirements 1.3**
    """
    tmp_path = tmp_path_factory.mktemp("upsert")
    record2.agent_name = record1.agent_name

    store = RegistryStore(path=tmp_path / "registry.json")
    store.add_agent(record1)
    store.add_agent(record2)

    agents = store.list_agents()
    matching = [a for a in agents if a.agent_name == record1.agent_name]

    assert len(matching) == 1, (
        "Upsert must leave exactly one record per agent_name"
    )

    result = matching[0]
    assert result.region == record2.region
    assert result.model_id == record2.model_id
    assert result.source_file == record2.source_file
    assert result.deployed_at == record2.deployed_at
    assert result.aws_profile == record2.aws_profile


# ---------------------------------------------------------------------------
# Property 4: Remove-then-get absence
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(record=registry_record_st)
def test_remove_then_get(record: RegistryRecord, tmp_path_factory):
    """**Property 4: Remove-then-get absence**

    After remove_agent(), get_agent() returns None and count decreases
    by one.

    **Validates: Requirements 1.5**
    """
    tmp_path = tmp_path_factory.mktemp("remove")
    store = RegistryStore(path=tmp_path / "registry.json")
    store.add_agent(record)

    count_before = len(store.list_agents())
    removed = store.remove_agent(record.agent_name)
    count_after = len(store.list_agents())

    assert removed is True
    assert store.get_agent(record.agent_name) is None
    assert count_after == count_before - 1


# ---------------------------------------------------------------------------
# Property 5: Validation rejects incomplete records
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    fields_to_drop=st.sets(
        st.sampled_from(_REQUIRED_FIELDS),
        min_size=1,
    ),
)
def test_validation_rejects_incomplete(
    fields_to_drop: set,
    tmp_path_factory,
):
    """**Property 5: Validation rejects incomplete records**

    JSON dicts missing required fields are skipped during load.

    **Validates: Requirements 1.4**
    """
    tmp_path = tmp_path_factory.mktemp("validate")
    complete_record = {
        "agent_name": "test_agent",
        "region": "us-east-1",
        "model_id": "anthropic.claude-sonnet-4-20250514",
        "source_file": "agent.py",
        "deployed_at": "2025-01-15T10:30:00+00:00",
        "aws_profile": None,
    }
    incomplete = {
        k: v for k, v in complete_record.items()
        if k not in fields_to_drop
    }

    registry_path = tmp_path / "registry.json"
    registry_path.write_text(
        json.dumps({"agents": [incomplete], "server": None}),
        encoding="utf-8",
    )

    store = RegistryStore(path=registry_path)
    data = store.load()

    assert len(data.agents) == 0, (
        f"Record missing {fields_to_drop} should have been skipped"
    )


# ---------------------------------------------------------------------------
# Property 9: No credentials in serialized registry
# ---------------------------------------------------------------------------

_AWS_KEY_PATTERN = re.compile(r"(AKIA|ASIA)[A-Z0-9]{16}")
_AWS_SECRET_PATTERN = re.compile(r"[A-Za-z0-9/+=]{40}")


@settings(max_examples=100)
@given(data=registry_data_st)
def test_no_credentials_in_json(data: RegistryData, tmp_path_factory):
    """**Property 9: No credentials in serialized registry**

    Serialized JSON contains no AWS access key patterns.

    **Validates: Requirements 6.1**
    """
    tmp_path = tmp_path_factory.mktemp("creds")
    store = RegistryStore(path=tmp_path / "registry.json")
    store.save(data)

    raw_json = (tmp_path / "registry.json").read_text(encoding="utf-8")

    assert not _AWS_KEY_PATTERN.search(raw_json), (
        "Serialized registry must not contain AWS access key patterns"
    )
    assert not _AWS_SECRET_PATTERN.search(raw_json), (
        "Serialized registry must not contain AWS secret key patterns"
    )


# ---------------------------------------------------------------------------
# Property 6: CLI list output contains all agents
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    records=st.lists(registry_record_st, min_size=1, max_size=8),
)
def test_list_output_contains_all(
    records: list[RegistryRecord],
    tmp_path_factory,
):
    """**Property 6: CLI list output contains all agents**

    For any list of RegistryRecords with unique agent_names stored in the
    registry, the ``synth agents list`` CLI output contains every agent's
    name and region.

    **Validates: Requirements 2.1**
    """
    from unittest.mock import patch

    from click.testing import CliRunner
    from hypothesis import assume

    from synth.cli.agents_cmd import agents_group

    # Ensure unique agent names
    names = [r.agent_name for r in records]
    assume(len(names) == len(set(names)))

    tmp_path = tmp_path_factory.mktemp("cli_list")
    registry_path = tmp_path / "registry.json"
    store = RegistryStore(path=registry_path)
    for rec in records:
        store.add_agent(rec)

    runner = CliRunner()
    with patch(
        "synth.cli.agents_cmd._query_live_status", return_value={}
    ), patch(
        "synth.cli.agents_cmd.RegistryStore",
        return_value=store,
    ):
        result = runner.invoke(agents_group, ["list"])

    assert result.exit_code == 0, (
        f"CLI exited with code {result.exit_code}: {result.output}"
    )

    for rec in records:
        assert rec.agent_name in result.output, (
            f"Agent name {rec.agent_name!r} missing from list output"
        )
        assert rec.region in result.output, (
            f"Region {rec.region!r} missing from list output"
        )


# ---------------------------------------------------------------------------
# Property 7: CLI status output contains all fields
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(record=registry_record_st)
def test_status_output_contains_fields(
    record: RegistryRecord,
    tmp_path_factory,
):
    """**Property 7: CLI status output contains all fields**

    For any valid RegistryRecord, the ``synth agents status <name>``
    CLI output contains the record's agent_name, region, model_id,
    source_file, deployed_at, and aws_profile values.

    **Validates: Requirements 3.1**
    """
    from unittest.mock import patch

    from click.testing import CliRunner

    from synth.cli.agents_cmd import agents_group

    tmp_path = tmp_path_factory.mktemp("cli_status")
    registry_path = tmp_path / "registry.json"
    store = RegistryStore(path=registry_path)
    store.add_agent(record)

    runner = CliRunner()
    with patch(
        "synth.cli.agents_cmd._query_live_status", return_value={}
    ), patch(
        "synth.cli.agents_cmd.RegistryStore",
        return_value=store,
    ), patch(
        "synth.cli.agents_cmd._probe_credentials", return_value=None,
    ):
        result = runner.invoke(agents_group, ["status", record.agent_name])

    assert result.exit_code == 0, (
        f"CLI exited with code {result.exit_code}: {result.output}"
    )

    assert record.agent_name in result.output, (
        f"agent_name {record.agent_name!r} missing from status output"
    )
    assert record.region in result.output, (
        f"region {record.region!r} missing from status output"
    )
    assert record.model_id in result.output, (
        f"model_id {record.model_id!r} missing from status output"
    )
    assert record.source_file in result.output, (
        f"source_file {record.source_file!r} missing from status output"
    )
    assert record.deployed_at in result.output, (
        f"deployed_at {record.deployed_at!r} missing from status output"
    )

    # aws_profile displays as "(default)" when None
    expected_profile = record.aws_profile or "(default)"
    assert expected_profile in result.output, (
        f"aws_profile {expected_profile!r} missing from status output"
    )


# ---------------------------------------------------------------------------
# Property 8: API response contains all agents
# ---------------------------------------------------------------------------


@settings(max_examples=100, deadline=None)
@given(
    records=st.lists(registry_record_st, min_size=1, max_size=8),
)
def test_api_response_contains_all(
    records: list[RegistryRecord],
    tmp_path_factory,
):
    """**Property 8: API response contains all agents**

    For any list of RegistryRecords with unique agent_names stored in the
    registry, the JSON response from ``GET /api/agents`` contains an entry
    for every agent, and each entry includes ``agent_name`` and ``region``.

    **Validates: Requirements 5.2**
    """
    import asyncio
    from unittest.mock import patch

    import httpx
    from hypothesis import assume

    # The FastAPI app mounts a StaticFiles directory at import time.
    # Ensure the directory exists so the import succeeds.
    import synth.cli as _cli_pkg
    _static_dir = (
        Path(_cli_pkg.__file__).parent / "_ui_assets" / "static"
    )
    _static_dir.mkdir(parents=True, exist_ok=True)

    from synth.cli._ui_assets.server import app

    # Ensure unique agent names
    names = [r.agent_name for r in records]
    assume(len(names) == len(set(names)))

    tmp_path = tmp_path_factory.mktemp("api_agents")
    registry_path = tmp_path / "registry.json"
    store = RegistryStore(path=registry_path)
    for rec in records:
        store.add_agent(rec)

    async def _call_api() -> httpx.Response:
        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
        async with httpx.AsyncClient(
            transport=transport, base_url="http://test"
        ) as client:
            return await client.get("/api/agents")

    with patch(
        "synth.cli.registry.RegistryStore",
        return_value=store,
    ), patch(
        "synth.cli._ui_assets.server._query_remote_agents",
        return_value=({}, None),
    ):
        response = asyncio.run(_call_api())

    assert response.status_code == 200, (
        f"Expected 200, got {response.status_code}"
    )

    body = response.json()["agents"]
    assert isinstance(body, list)
    assert len(body) == len(records), (
        f"Expected {len(records)} agents, got {len(body)}"
    )

    returned_names = {entry["agent_name"] for entry in body}
    for rec in records:
        assert rec.agent_name in returned_names, (
            f"Agent {rec.agent_name!r} missing from API response"
        )

    for entry in body:
        assert "agent_name" in entry, "Entry missing 'agent_name' field"
        assert "region" in entry, "Entry missing 'region' field"
