# Feature: agent-lifecycle-management
"""Property-based tests for agent lifecycle error sanitization and actions.

Validates the following properties and requirements:

- **Property 5: Error sanitization removes sensitive patterns**
- **Validates: Requirements 1.6, 9.1, 9.2**
- **Property 6: Error sanitization preserves error type**
- **Validates: Requirements 9.3**
- **Property 7: Status-to-actions mapping completeness**
- **Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.cli._ui_assets.server import (
    _STATUS_ACTIONS,
    _compute_actions,
    _sanitize_error_message,
)

# ---------------------------------------------------------------------------
# Regex patterns used to verify sanitization (mirrors server.py patterns)
# ---------------------------------------------------------------------------

_AWS_KEY_RE = re.compile(r'A[SK]IA[A-Z0-9]{16}')
_FILE_PATH_RE = re.compile(r'(/[a-zA-Z0-9._-]+){3,}\.py')


# ---------------------------------------------------------------------------
# Expected status-to-actions mapping (source of truth from design doc)
# ---------------------------------------------------------------------------

_EXPECTED_ACTIONS: dict[str, list[str]] = {
    "active": ["connect", "destroy"],
    "failed": ["redeploy", "destroy"],
    "creating": [],
    "updating": [],
    "deleting": [],
    "local": ["deploy"],
    "unknown": ["destroy"],
}


# ---------------------------------------------------------------------------
# Property 5: Error sanitization removes sensitive patterns
# ---------------------------------------------------------------------------


class TestErrorSanitizationRemovesSensitive:
    """Property 5 — sensitive patterns are stripped from error messages."""

    @settings(max_examples=100)
    @given(
        base_msg=st.text(min_size=1, max_size=200),
        aws_key=st.from_regex(r'AKIA[A-Z0-9]{16}', fullmatch=True),
        file_path=st.from_regex(
            r'/[a-z]+/[a-z]+/[a-z]+\.py', fullmatch=True
        ),
    )
    def test_sanitization_removes_sensitive_patterns(
        self, base_msg: str, aws_key: str, file_path: str
    ) -> None:
        """**Property 5: Error sanitization removes sensitive patterns**

        For any string containing an AWS access key pattern and an
        internal file path, ``_sanitize_error_message()`` returns a
        string that contains neither pattern.

        **Validates: Requirements 1.6, 9.1, 9.2**
        """
        raw = f"{base_msg} key={aws_key} at {file_path}"
        sanitized = _sanitize_error_message(raw)

        assert not _AWS_KEY_RE.search(sanitized), (
            f"AWS key pattern still present in sanitized output: "
            f"{sanitized!r}"
        )
        assert not _FILE_PATH_RE.search(sanitized), (
            f"File path pattern still present in sanitized output: "
            f"{sanitized!r}"
        )
        assert len(sanitized) <= 500, (
            f"Sanitized message exceeds 500 chars: {len(sanitized)}"
        )


# ---------------------------------------------------------------------------
# Property 6: Error sanitization preserves error type
# ---------------------------------------------------------------------------


class TestErrorSanitizationPreservesType:
    """Property 6 — error type prefix survives sanitization."""

    @settings(max_examples=100)
    @given(
        error_type=st.sampled_from([
            "ValueError", "TypeError", "ClientError",
            "SynthConfigError", "RuntimeError",
        ]),
        description=st.text(min_size=1, max_size=100),
    )
    def test_sanitization_preserves_error_type(
        self, error_type: str, description: str
    ) -> None:
        """**Property 6: Error sanitization preserves error type**

        For any error message of the form ``"ErrorType: description"``,
        ``_sanitize_error_message()`` returns a string that still
        contains the error type name.

        **Validates: Requirements 9.3**
        """
        raw = f"{error_type}: {description}"
        sanitized = _sanitize_error_message(raw)

        assert error_type in sanitized, (
            f"Error type {error_type!r} was stripped from sanitized "
            f"output: {sanitized!r}"
        )


# ---------------------------------------------------------------------------
# Property 7: Status-to-actions mapping completeness
# ---------------------------------------------------------------------------


class TestStatusToActionsMapping:
    """Property 7 — every known status maps to the correct action list."""

    @settings(max_examples=100)
    @given(
        status=st.sampled_from([
            "active", "failed", "creating", "updating",
            "deleting", "local", "unknown",
        ]),
    )
    def test_status_to_actions_mapping(self, status: str) -> None:
        """**Property 7: Status-to-actions mapping completeness**

        For any agent status in the defined set,
        ``_compute_actions(status)`` returns the expected action list
        from the design document mapping table.

        **Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**
        """
        actions = _compute_actions(status)
        expected = _EXPECTED_ACTIONS[status]

        assert actions == expected, (
            f"Status {status!r}: expected {expected}, got {actions}"
        )

    def test_status_actions_dict_matches_expected(self) -> None:
        """The module-level _STATUS_ACTIONS dict covers all expected
        statuses with the correct action lists."""
        for status, expected in _EXPECTED_ACTIONS.items():
            assert status in _STATUS_ACTIONS, (
                f"Status {status!r} missing from _STATUS_ACTIONS"
            )
            assert _STATUS_ACTIONS[status] == expected, (
                f"Status {status!r}: expected {expected}, "
                f"got {_STATUS_ACTIONS[status]}"
            )


# ---------------------------------------------------------------------------
# Session management imports
# ---------------------------------------------------------------------------

import time
import uuid

from synth.cli._ui_assets.server import (
    RemoteAgentInvoker,
    SessionEntry,
    _session_store,
)


# ---------------------------------------------------------------------------
# Property 3: Session reuse within a conversation
# ---------------------------------------------------------------------------


class TestSessionReuseWithinConversation:
    """Property 3 — same conversation reuses the same session ID."""

    @settings(max_examples=100)
    @given(
        agent_name=st.text(min_size=1, max_size=48).filter(
            lambda s: s[0].isalpha()
        ),
        conv_id=st.text(min_size=1, max_size=50),
        num_calls=st.integers(min_value=2, max_value=10),
    )
    def test_session_reuse_within_conversation(
        self, agent_name: str, conv_id: str, num_calls: int
    ) -> None:
        """**Property 3: Session reuse within a conversation**

        For any sequence of two or more invocations with the same agent
        name and conversation ID where the time between invocations is
        less than 15 minutes, all invocations use the same session ID.

        **Validates: Requirements 1.3, 8.2**
        """
        _session_store.clear()
        try:
            invoker = RemoteAgentInvoker(
                agent_name=agent_name, region="us-east-1",
            )
            session_ids: list[str] = []
            for _ in range(num_calls):
                sid = invoker._get_or_create_session(conv_id)
                session_ids.append(sid)

            first = session_ids[0]
            assert all(sid == first for sid in session_ids), (
                f"Expected all session IDs to match {first!r}, "
                f"got {session_ids}"
            )
        finally:
            _session_store.clear()


# ---------------------------------------------------------------------------
# Property 4: Expired session replacement
# ---------------------------------------------------------------------------


class TestExpiredSessionReplacement:
    """Property 4 — expired sessions are replaced with a new ID."""

    @settings(max_examples=100)
    @given(
        conv_id=st.text(min_size=1, max_size=50),
        idle_seconds=st.integers(min_value=901, max_value=36000),
    )
    def test_expired_session_replacement(
        self, conv_id: str, idle_seconds: int
    ) -> None:
        """**Property 4: Expired session replacement**

        For any session entry whose ``last_used`` timestamp is more
        than 15 minutes in the past, the next invocation for that
        conversation generates a new session ID that differs from the
        expired one.

        **Validates: Requirements 1.4, 8.4**
        """
        _session_store.clear()
        try:
            agent_name = "test-agent"
            invoker = RemoteAgentInvoker(
                agent_name=agent_name, region="us-east-1",
            )

            # Seed an expired session entry.
            key = f"{agent_name}:{conv_id}"
            old_id = str(uuid.uuid4())
            _session_store[key] = SessionEntry(
                session_id=old_id,
                last_used=time.time() - idle_seconds,
            )

            new_id = invoker._get_or_create_session(conv_id)

            assert new_id != old_id, (
                f"Expected a new session ID after {idle_seconds}s idle, "
                f"but got the same ID: {old_id!r}"
            )
            assert _session_store[key].session_id == new_id
        finally:
            _session_store.clear()


# ---------------------------------------------------------------------------
# Property 10: Unique session per new conversation
# ---------------------------------------------------------------------------


class TestUniqueSessionPerConversation:
    """Property 10 — distinct conversations get distinct session IDs."""

    @settings(max_examples=100)
    @given(
        conv_ids=st.lists(
            st.text(min_size=1, max_size=50),
            min_size=2,
            max_size=20,
            unique=True,
        ),
    )
    def test_unique_session_per_conversation(
        self, conv_ids: list[str]
    ) -> None:
        """**Property 10: Unique session per new conversation**

        For any set of distinct conversation IDs, calling
        ``_get_or_create_session()`` for each produces distinct
        session IDs.

        **Validates: Requirements 8.1, 8.3**
        """
        _session_store.clear()
        try:
            invoker = RemoteAgentInvoker(
                agent_name="test-agent", region="us-east-1",
            )
            session_ids: list[str] = []
            for cid in conv_ids:
                sid = invoker._get_or_create_session(cid)
                session_ids.append(sid)

            assert len(set(session_ids)) == len(conv_ids), (
                f"Expected {len(conv_ids)} unique session IDs, "
                f"got {len(set(session_ids))}. IDs: {session_ids}"
            )
        finally:
            _session_store.clear()


# ---------------------------------------------------------------------------
# Property 1: Invocation payload correctness
# ---------------------------------------------------------------------------

from unittest.mock import MagicMock


class TestInvocationPayloadCorrectness:
    """Property 1 — invocation payload sent to AgentCore is correct."""

    @settings(max_examples=100)
    @given(
        prompt=st.text(min_size=1, max_size=500),
        session_id=st.uuids(),
    )
    def test_invocation_payload_correctness(
        self, prompt: str, session_id: uuid.UUID
    ) -> None:
        """**Property 1: Invocation payload correctness**

        For any non-empty prompt string and any valid session ID,
        calling ``RemoteAgentInvoker.invoke()`` produces an
        ``InvokeAgentRuntime`` call whose payload contains the prompt
        in ``input.text`` and the session ID in ``sessionId``.

        **Validates: Requirements 1.1**
        """
        _session_store.clear()
        try:
            agent_name = "test-agent"
            conv_id = "conv-1"
            sid_str = str(session_id)

            invoker = RemoteAgentInvoker(
                agent_name=agent_name, region="us-east-1",
            )

            # Mock the boto3 client to return a valid response.
            mock_client = MagicMock()
            mock_client.invoke_agent_runtime.return_value = {
                "output": {"text": "response"},
                "sessionId": sid_str,
                "contentType": "application/json",
            }
            invoker._client = mock_client

            # Seed the session store with the known session ID.
            key = f"{agent_name}:{conv_id}"
            _session_store[key] = SessionEntry(
                session_id=sid_str,
                last_used=time.time(),
            )

            invoker.invoke(prompt, conv_id)

            mock_client.invoke_agent_runtime.assert_called_once_with(
                agentRuntimeId=agent_name,
                sessionId=sid_str,
                input={"text": prompt},
            )
        finally:
            _session_store.clear()


# ---------------------------------------------------------------------------
# Property 2: SSE response contains agent output
# ---------------------------------------------------------------------------

import json


class TestSSEResponseContainsAgentOutput:
    """Property 2 — SSE token event preserves the agent response text."""

    @settings(max_examples=100)
    @given(
        response_text=st.text(min_size=1, max_size=500).filter(
            lambda s: s.strip()
        ),
    )
    def test_sse_response_contains_agent_output(
        self, response_text: str
    ) -> None:
        """**Property 2: SSE response contains agent output**

        For any response text returned by the AgentCore data plane,
        the JSON-formatted SSE token event contains that exact text
        when parsed back, validating the SSE formatting contract.

        **Validates: Requirements 1.2**
        """
        # Build the SSE token event the same way chat_stream does.
        token_payload = json.dumps({"type": "token", "text": response_text})
        done_payload = json.dumps({"type": "done", "text": response_text})

        # Parse back and verify round-trip fidelity.
        token_parsed = json.loads(token_payload)
        done_parsed = json.loads(done_payload)

        assert token_parsed["type"] == "token"
        assert token_parsed["text"] == response_text, (
            f"Token event text mismatch: expected {response_text!r}, "
            f"got {token_parsed['text']!r}"
        )
        assert done_parsed["type"] == "done"
        assert done_parsed["text"] == response_text, (
            f"Done event text mismatch: expected {response_text!r}, "
            f"got {done_parsed['text']!r}"
        )


# ---------------------------------------------------------------------------
# Property 11: Connect replaces previous remote agent
# ---------------------------------------------------------------------------

import synth.cli._ui_assets.server as _server_mod


class TestConnectReplacesPreviousRemoteAgent:
    """Property 11 — connecting to a second agent replaces the first."""

    @settings(max_examples=100)
    @given(
        name1=st.text(min_size=1, max_size=48),
        name2=st.text(min_size=1, max_size=48),
    )
    def test_connect_replaces_previous(
        self, name1: str, name2: str
    ) -> None:
        """**Property 11: Connect replaces previous remote agent**

        For any two agent names, connecting to the first then
        connecting to the second results in ``_remote_agent["name"]``
        equaling the second agent name.

        **Validates: Requirements 2.2**
        """
        original = _server_mod._remote_agent
        try:
            _server_mod._remote_agent = {
                "name": name1,
                "region": "us-east-1",
                "aws_profile": "",
            }
            assert _server_mod._remote_agent["name"] == name1

            _server_mod._remote_agent = {
                "name": name2,
                "region": "us-east-1",
                "aws_profile": "",
            }
            assert _server_mod._remote_agent["name"] == name2, (
                f"Expected remote agent to be {name2!r} after "
                f"second connect, got "
                f"{_server_mod._remote_agent['name']!r}"
            )
        finally:
            _server_mod._remote_agent = original


# ---------------------------------------------------------------------------
# Property 8: Actions field present in agent list response
# ---------------------------------------------------------------------------


class TestActionsFieldInAgentListResponse:
    """Property 8 — every agent dict gains a correct ``actions`` field."""

    @settings(max_examples=100)
    @given(
        status=st.sampled_from([
            "active", "failed", "creating", "updating",
            "deleting", "local", "unknown",
        ]),
        agent_name=st.text(min_size=1, max_size=48).filter(
            lambda s: s[0].isalpha()
        ),
    )
    def test_actions_field_present_in_agent_list(
        self, status: str, agent_name: str
    ) -> None:
        """**Property 8: Actions field present in agent list response**

        For any agent dict with a status field, adding
        ``_compute_actions(status)`` produces the correct actions list.
        This validates that the actions field computation is correct
        for any agent status.

        **Validates: Requirements 3.6**
        """
        agent_dict: dict[str, Any] = {
            "agent_name": agent_name,
            "region": "us-east-1",
            "status": status,
        }

        agent_dict["actions"] = _compute_actions(agent_dict["status"])

        assert "actions" in agent_dict, (
            "Expected 'actions' key in agent dict"
        )
        assert agent_dict["actions"] == _compute_actions(status), (
            f"Actions mismatch for status {status!r}: "
            f"expected {_compute_actions(status)}, "
            f"got {agent_dict['actions']}"
        )


# ---------------------------------------------------------------------------
# Property 9: Destroy removes agent from registry
# ---------------------------------------------------------------------------

import tempfile

from synth.cli.registry import RegistryRecord, RegistryStore


class TestDestroyRemovesFromRegistry:
    """Property 9 — destroy removes agent from the registry store."""

    @settings(max_examples=100)
    @given(
        agent_name=st.text(
            min_size=1,
            max_size=48,
            alphabet=st.characters(
                whitelist_categories=("L", "N"),
                whitelist_characters="-_",
            ),
        ).filter(lambda s: s[0].isalpha()),
    )
    def test_destroy_removes_agent_from_registry(
        self, agent_name: str
    ) -> None:
        """**Property 9: Destroy removes agent from registry**

        For any agent name present in the Registry_Store, after calling
        ``remove_agent(name)``, ``get_agent(name)`` returns ``None``.

        **Validates: Requirements 4.2, 7.2**
        """
        with tempfile.TemporaryDirectory() as tmp_dir:
            registry_path = Path(tmp_dir) / "registry.json"
            store = RegistryStore(path=registry_path)

            record = RegistryRecord(
                agent_name=agent_name,
                region="us-east-1",
                model_id="anthropic.claude-sonnet-4-20250514",
                source_file="agent.py",
                deployed_at="2025-01-15T10:30:00+00:00",
                aws_profile=None,
            )

            # Add and verify the agent exists.
            store.add_agent(record)
            assert store.get_agent(agent_name) is not None, (
                f"Agent {agent_name!r} should exist after add_agent()"
            )

            # Remove and verify it's gone.
            store.remove_agent(agent_name)
            assert store.get_agent(agent_name) is None, (
                f"Agent {agent_name!r} should be None after remove_agent()"
            )


# ---------------------------------------------------------------------------
# Property 12: Deploy/redeploy delegates with correct source file
# ---------------------------------------------------------------------------


class TestDeployRedeployDelegatesWithCorrectSourceFile:
    """Property 12 — registry preserves source_file for deploy/redeploy."""

    @settings(max_examples=100)
    @given(
        agent_name=st.text(
            min_size=1,
            max_size=48,
            alphabet=st.characters(
                whitelist_categories=("L", "N"),
                whitelist_characters="-_",
            ),
        ).filter(lambda s: s[0].isalpha()),
        source_filename=st.text(
            min_size=1,
            max_size=20,
            alphabet=st.characters(
                whitelist_categories=("L", "N"),
            ),
        ).map(lambda s: s + ".py"),
    )
    def test_deploy_delegates_with_correct_source_file(
        self, agent_name: str, source_filename: str
    ) -> None:
        """**Property 12: Deploy/redeploy delegates with correct source file**

        For any agent record in the Registry_Store with a valid
        ``source_file``, the source file path is preserved through
        a registry round-trip and the file exists on disk. This
        validates the data contract that ``deploy_agent`` and
        ``redeploy_agent`` rely on when passing ``file=record.source_file``
        to ``run_deploy``.

        **Validates: Requirements 5.1, 6.1**
        """
        with tempfile.TemporaryDirectory() as tmp_dir:
            # 1. Create a temp dir with the source file.
            source_path = Path(tmp_dir) / source_filename
            source_path.write_text("# agent stub", encoding="utf-8")

            # 2. Create a RegistryStore with a temp registry path.
            registry_path = Path(tmp_dir) / "registry.json"
            store = RegistryStore(path=registry_path)

            # 3. Add an agent with the source file path.
            record = RegistryRecord(
                agent_name=agent_name,
                region="us-east-1",
                model_id="anthropic.claude-sonnet-4-20250514",
                source_file=str(source_path),
                deployed_at="2025-01-15T10:30:00+00:00",
                aws_profile=None,
            )
            store.add_agent(record)

            # 4. Retrieve the agent and verify source_file matches.
            retrieved = store.get_agent(agent_name)
            assert retrieved is not None, (
                f"Agent {agent_name!r} should exist after add_agent()"
            )
            assert retrieved.source_file == str(source_path), (
                f"source_file mismatch: expected {str(source_path)!r}, "
                f"got {retrieved.source_file!r}"
            )

            # 5. Verify the file exists at that path (simulating what
            #    deploy/redeploy checks before calling run_deploy).
            assert Path(retrieved.source_file).exists(), (
                f"Source file should exist on disk at "
                f"{retrieved.source_file!r}"
            )
