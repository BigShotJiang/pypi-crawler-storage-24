"""Unit tests for ``RemoteAgentInvoker`` in the UI server module.

Covers client creation, session management, invocation payload, and
error handling paths.
"""

from __future__ import annotations

import time
import uuid
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from synth.cli._ui_assets.server import (
    RemoteAgentInvoker,
    SessionEntry,
    _session_store,
)
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_invoker(
    agent_name: str = "my-agent",
    region: str = "us-east-1",
    aws_profile: str | None = None,
) -> RemoteAgentInvoker:
    """Create an invoker with a mocked boto3 client."""
    return RemoteAgentInvoker(
        agent_name=agent_name,
        region=region,
        aws_profile=aws_profile,
    )


def _mock_client(response_text: str = "Hello!") -> MagicMock:
    """Return a mock boto3 client whose ``invoke_agent_runtime`` returns
    a well-formed response."""
    client = MagicMock()
    client.invoke_agent_runtime.return_value = {
        "output": {"text": response_text},
        "sessionId": str(uuid.uuid4()),
        "contentType": "application/json",
    }
    return client


# ---------------------------------------------------------------------------
# TestCreateClient
# ---------------------------------------------------------------------------


class TestCreateClient:
    """Tests for ``_create_client()`` — lazy boto3 import and session setup."""

    def test_boto3_missing_raises_config_error(self) -> None:
        """When boto3 is not installed, ``_create_client`` raises
        ``SynthConfigError`` with install instructions."""
        invoker = _make_invoker()
        with patch.dict("sys.modules", {"boto3": None}):
            with pytest.raises(
                SynthConfigError,
                match=r"synth-agent-sdk\[agentcore\]",
            ):
                invoker._create_client()

    def test_create_client_uses_profile_and_region(self) -> None:
        """boto3.Session is called with the configured profile and region."""
        invoker = _make_invoker(
            region="eu-west-1", aws_profile="my-profile",
        )
        mock_session_cls = MagicMock()
        mock_session_instance = MagicMock()
        mock_session_cls.return_value = mock_session_instance

        with patch.dict(
            "sys.modules",
            {"boto3": MagicMock(Session=mock_session_cls)},
        ):
            invoker._create_client()

        mock_session_cls.assert_called_once_with(
            profile_name="my-profile",
            region_name="eu-west-1",
        )
        mock_session_instance.client.assert_called_once_with(
            "bedrock-agentcore",
        )

    def test_create_client_no_profile(self) -> None:
        """When aws_profile is None, profile_name is omitted from Session."""
        invoker = _make_invoker(region="us-west-2", aws_profile=None)
        mock_session_cls = MagicMock()
        mock_session_instance = MagicMock()
        mock_session_cls.return_value = mock_session_instance

        with patch.dict(
            "sys.modules",
            {"boto3": MagicMock(Session=mock_session_cls)},
        ):
            invoker._create_client()

        mock_session_cls.assert_called_once_with(
            region_name="us-west-2",
        )


# ---------------------------------------------------------------------------
# TestSessionEntry
# ---------------------------------------------------------------------------


class TestSessionEntry:
    """Tests for the ``SessionEntry`` dataclass contract."""

    def test_fields_stored_correctly(self) -> None:
        """Constructor stores session_id and last_used as given."""
        entry = SessionEntry(session_id="abc-123", last_used=1000.0)
        assert entry.session_id == "abc-123"
        assert entry.last_used == 1000.0

    def test_equality(self) -> None:
        """Two entries with identical fields are equal (dataclass default)."""
        a = SessionEntry(session_id="s1", last_used=42.0)
        b = SessionEntry(session_id="s1", last_used=42.0)
        assert a == b

    def test_inequality_on_different_session_id(self) -> None:
        """Entries with different session_id are not equal."""
        a = SessionEntry(session_id="s1", last_used=42.0)
        b = SessionEntry(session_id="s2", last_used=42.0)
        assert a != b

    def test_inequality_on_different_last_used(self) -> None:
        """Entries with different last_used are not equal."""
        a = SessionEntry(session_id="s1", last_used=1.0)
        b = SessionEntry(session_id="s1", last_used=2.0)
        assert a != b

    def test_mutable_last_used(self) -> None:
        """last_used can be updated in place (not frozen)."""
        entry = SessionEntry(session_id="s1", last_used=0.0)
        entry.last_used = 999.0
        assert entry.last_used == 999.0

    def test_session_store_is_module_level_dict(self) -> None:
        """_session_store is a plain dict usable as a session cache."""
        _session_store.clear()
        try:
            entry = SessionEntry(session_id="x", last_used=1.0)
            _session_store["key"] = entry
            assert _session_store["key"] is entry
        finally:
            _session_store.clear()


# ---------------------------------------------------------------------------
# TestGetOrCreateSession
# ---------------------------------------------------------------------------


class TestGetOrCreateSession:
    """Tests for ``_get_or_create_session()`` — session lifecycle."""

    def setup_method(self) -> None:
        _session_store.clear()

    def teardown_method(self) -> None:
        _session_store.clear()

    def test_new_conversation_creates_session(self) -> None:
        """First call for a conversation creates a new session entry."""
        invoker = _make_invoker(agent_name="agent-a")
        sid = invoker._get_or_create_session("conv-1")

        assert sid
        key = "agent-a:conv-1"
        assert key in _session_store
        assert _session_store[key].session_id == sid

    def test_same_conversation_reuses_session(self) -> None:
        """Subsequent calls within timeout return the same session ID."""
        invoker = _make_invoker(agent_name="agent-a")
        sid1 = invoker._get_or_create_session("conv-1")
        sid2 = invoker._get_or_create_session("conv-1")

        assert sid1 == sid2

    def test_expired_session_creates_new(self) -> None:
        """A session idle for >15 min is replaced with a new UUID."""
        invoker = _make_invoker(agent_name="agent-a")
        key = "agent-a:conv-1"

        # Seed an expired entry.
        old_id = str(uuid.uuid4())
        _session_store[key] = SessionEntry(
            session_id=old_id,
            last_used=time.time() - 901,  # 15 min + 1 sec
        )

        new_id = invoker._get_or_create_session("conv-1")
        assert new_id != old_id
        assert _session_store[key].session_id == new_id

    def test_different_conversations_different_sessions(self) -> None:
        """Two distinct conversation IDs get different session IDs."""
        invoker = _make_invoker(agent_name="agent-a")
        sid1 = invoker._get_or_create_session("conv-1")
        sid2 = invoker._get_or_create_session("conv-2")

        assert sid1 != sid2

    def test_session_last_used_updated_on_reuse(self) -> None:
        """Reusing a session updates its ``last_used`` timestamp."""
        invoker = _make_invoker(agent_name="agent-a")
        key = "agent-a:conv-1"

        _session_store[key] = SessionEntry(
            session_id="fixed-id",
            last_used=time.time() - 100,
        )

        before = time.time()
        invoker._get_or_create_session("conv-1")
        after = time.time()

        assert _session_store[key].last_used >= before
        assert _session_store[key].last_used <= after


# ---------------------------------------------------------------------------
# TestInvoke
# ---------------------------------------------------------------------------


class TestInvoke:
    """Tests for ``invoke()`` — payload construction and response parsing."""

    def setup_method(self) -> None:
        _session_store.clear()

    def teardown_method(self) -> None:
        _session_store.clear()

    def test_invoke_calls_data_plane_with_correct_payload(self) -> None:
        """``invoke_agent_runtime`` is called with the right args."""
        invoker = _make_invoker(agent_name="my-agent")
        client = _mock_client("response text")
        invoker._client = client

        invoker.invoke("Hello", "conv-1")

        call_kwargs = client.invoke_agent_runtime.call_args
        assert call_kwargs.kwargs["agentRuntimeId"] == "my-agent"
        assert call_kwargs.kwargs["input"] == {"text": "Hello"}
        assert "sessionId" in call_kwargs.kwargs

    def test_invoke_returns_response_text(self) -> None:
        """The returned dict contains the response text and session ID."""
        invoker = _make_invoker()
        invoker._client = _mock_client("Hi there!")

        result = invoker.invoke("Hey", "conv-1")

        assert result["text"] == "Hi there!"
        assert "session_id" in result

    def test_invoke_lazily_creates_client(self) -> None:
        """If ``_client`` is None, ``_create_client`` is called."""
        invoker = _make_invoker()
        assert invoker._client is None

        mock_client = _mock_client()
        with patch.object(
            invoker, "_create_client", return_value=mock_client,
        ) as mock_create:
            invoker.invoke("test", "conv-1")

        mock_create.assert_called_once()
        assert invoker._client is mock_client


# ---------------------------------------------------------------------------
# TestInvokeErrorHandling
# ---------------------------------------------------------------------------


class TestInvokeErrorHandling:
    """Tests for error handling in ``invoke()``."""

    def setup_method(self) -> None:
        _session_store.clear()

    def teardown_method(self) -> None:
        _session_store.clear()

    def test_credential_error(self) -> None:
        """Credential-related errors produce a clear refresh message."""
        invoker = _make_invoker()
        client = MagicMock()
        client.invoke_agent_runtime.side_effect = Exception(
            "The security token included in the request is expired"
        )
        invoker._client = client

        with pytest.raises(SynthConfigError, match="credentials expired"):
            invoker.invoke("test", "conv-1")

    def test_resource_not_found_error(self) -> None:
        """ResourceNotFoundException produces agent-not-found message."""
        invoker = _make_invoker(agent_name="missing-agent")

        exc = type("ResourceNotFoundException", (Exception,), {})
        client = MagicMock()
        client.invoke_agent_runtime.side_effect = exc(
            "Agent not found"
        )
        invoker._client = client

        with pytest.raises(
            SynthConfigError, match="not found in AgentCore",
        ):
            invoker.invoke("test", "conv-1")

    def test_read_timeout_error(self) -> None:
        """ReadTimeoutError produces a timeout message."""
        invoker = _make_invoker()

        exc = type("ReadTimeoutError", (Exception,), {})
        client = MagicMock()
        client.invoke_agent_runtime.side_effect = exc(
            "Read timed out"
        )
        invoker._client = client

        with pytest.raises(SynthConfigError, match="timed out"):
            invoker.invoke("test", "conv-1")

    def test_generic_error_sanitized(self) -> None:
        """Other errors are sanitized via ``_sanitize_error_message``."""
        invoker = _make_invoker()
        client = MagicMock()
        client.invoke_agent_runtime.side_effect = Exception(
            "Something went wrong at /home/user/app/main.py"
        )
        invoker._client = client

        with pytest.raises(SynthConfigError) as exc_info:
            invoker.invoke("test", "conv-1")

        # File path should be sanitized
        assert "/home/user/app/main.py" not in str(exc_info.value)

    def test_error_chaining_preserved(self) -> None:
        """Raised ``SynthConfigError`` chains the original exception."""
        invoker = _make_invoker()
        original = ValueError("original error with expired token")
        client = MagicMock()
        client.invoke_agent_runtime.side_effect = original
        invoker._client = client

        with pytest.raises(SynthConfigError) as exc_info:
            invoker.invoke("test", "conv-1")

        assert exc_info.value.__cause__ is original

    def test_boto3_missing_on_invoke(self) -> None:
        """If boto3 is missing, invoke raises SynthConfigError."""
        invoker = _make_invoker()
        with patch.object(
            invoker,
            "_create_client",
            side_effect=SynthConfigError(
                "AgentCore invocation requires boto3.",
                component="RemoteAgentInvoker",
                suggestion="pip install synth-agent-sdk[agentcore]",
            ),
        ):
            with pytest.raises(
                SynthConfigError, match="requires boto3",
            ):
                invoker.invoke("test", "conv-1")
