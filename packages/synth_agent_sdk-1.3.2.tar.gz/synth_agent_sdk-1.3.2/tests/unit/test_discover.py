"""Tests for synth.cli.discover — agent discovery and selection."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from synth.cli.discover import (
    DiscoveredAgent,
    _parse_agentcore_list,
    _parse_agentcore_status,
    _query_agentcore_cli,
    check_agentcore_status,
    discover_agents,
)


# ---------------------------------------------------------------------------
# DiscoveredAgent dataclass
# ---------------------------------------------------------------------------


class TestDiscoveredAgent:
    """Tests for the DiscoveredAgent dataclass defaults and fields."""

    def test_minimal_construction(self) -> None:
        agent = DiscoveredAgent(file="agent.py", name="my-agent")
        assert agent.file == "agent.py"
        assert agent.name == "my-agent"
        assert agent.model == ""
        assert agent.has_agentcore_yaml is False
        assert agent.is_deployed is False
        assert agent.aws_region == ""
        assert agent.cloud_status == ""
        assert agent.agent_id == ""

    def test_full_construction(self) -> None:
        agent = DiscoveredAgent(
            file="proj/agent.py",
            name="proj",
            model="claude-sonnet-4-5",
            has_agentcore_yaml=True,
            is_deployed=True,
            aws_region="us-west-2",
            cloud_status="ACTIVE",
            agent_id="agt-12345",
        )
        assert agent.cloud_status == "ACTIVE"
        assert agent.agent_id == "agt-12345"
        assert agent.is_deployed is True
        assert agent.aws_region == "us-west-2"

    def test_cloud_status_default_empty(self) -> None:
        agent = DiscoveredAgent(file="a.py", name="a")
        assert agent.cloud_status == ""

    def test_agent_id_default_empty(self) -> None:
        agent = DiscoveredAgent(file="a.py", name="a")
        assert agent.agent_id == ""


# ---------------------------------------------------------------------------
# discover_agents
# ---------------------------------------------------------------------------


class TestDiscoverAgents:
    """Tests for the discover_agents() directory scanner."""

    def test_finds_agent_py(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "agent"
        assert agents[0].model == "claude-sonnet-4-5"

    def test_finds_agent_prefixed_files(self, tmp_path: Path) -> None:
        (tmp_path / "agent_writer.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "agent_writer"

    def test_ignores_non_agent_files(self, tmp_path: Path) -> None:
        (tmp_path / "tools.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_ignores_files_without_agent_pattern(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            "# just a comment, no Agent usage\nx = 1\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_reads_agentcore_yaml(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="bedrock/claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: us-east-1\ndeployed: true\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].has_agentcore_yaml is True
        assert agents[0].is_deployed is True
        assert agents[0].aws_region == "us-east-1"

    def test_agentcore_yaml_not_deployed(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="bedrock/claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: eu-west-1\ndeployed: false\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert agents[0].is_deployed is False
        assert agents[0].aws_region == "eu-west-1"

    def test_skips_hidden_directories(self, tmp_path: Path) -> None:
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_skips_pycache(self, tmp_path: Path) -> None:
        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_subdirectory_agent_uses_dir_name(self, tmp_path: Path) -> None:
        sub = tmp_path / "my_project"
        sub.mkdir()
        (sub / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "my_project"

    def test_multiple_agents_sorted_by_file(self, tmp_path: Path) -> None:
        content = 'from synth import Agent\nagent = Agent(model="gpt-4o")\n'
        (tmp_path / "agent.py").write_text(content, encoding="utf-8")
        sub = tmp_path / "beta"
        sub.mkdir()
        (sub / "agent.py").write_text(content, encoding="utf-8")
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 2
        assert agents[0].file < agents[1].file

    def test_empty_directory(self, tmp_path: Path) -> None:
        agents = discover_agents(str(tmp_path))
        assert agents == []

    def test_new_fields_default_in_discovered_agents(self, tmp_path: Path) -> None:
        """Discovered agents have empty cloud_status and agent_id by default."""
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].cloud_status == ""
        assert agents[0].agent_id == ""


# ---------------------------------------------------------------------------
# _parse_agentcore_status
# ---------------------------------------------------------------------------


class TestParseAgentcoreStatus:
    """Tests for the _parse_agentcore_status() output parser."""

    def test_parses_status_and_arn(self) -> None:
        output = "Status: ACTIVE\nARN: arn:aws:agentcore:us-east-1:123:agent/my-agent\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "ACTIVE"
        assert result["agent_id"] == "arn:aws:agentcore:us-east-1:123:agent/my-agent"

    def test_parses_status_with_agent_id_line(self) -> None:
        output = "Status: CREATING\nAgent ID: agt-12345\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "CREATING"
        assert result["agent_id"] == "agt-12345"

    def test_status_uppercased(self) -> None:
        output = "Status: active\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "ACTIVE"

    def test_returns_none_when_no_status_line(self) -> None:
        output = "ARN: arn:aws:agentcore:us-east-1:123:agent/my-agent\n"
        assert _parse_agentcore_status(output) is None

    def test_returns_none_for_empty_output(self) -> None:
        assert _parse_agentcore_status("") is None

    def test_returns_none_for_whitespace_only(self) -> None:
        assert _parse_agentcore_status("   \n  \n") is None

    def test_status_without_colon_uses_whitespace_split(self) -> None:
        output = "Status  FAILED\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "FAILED"

    def test_arn_without_colon_uses_whitespace_split(self) -> None:
        output = "Status: ACTIVE\nARN  some-arn-value\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["agent_id"] == "some-arn-value"

    def test_agent_id_with_colon_separator(self) -> None:
        output = "Status: ACTIVE\nAgent ID: xyz-789\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["agent_id"] == "xyz-789"

    def test_agent_id_without_colon_includes_trailing_key_word(self) -> None:
        """Without a colon, split(None, 1) on 'Agent ID  xyz' yields
        ['Agent', 'ID  xyz'] — the parser keeps everything after the
        first whitespace token, so 'ID' leaks into the value."""
        output = "Status: ACTIVE\nAgent ID  xyz-789\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        # The whitespace-split path keeps "ID  xyz-789" as the value
        assert "xyz-789" in result["agent_id"]

    def test_status_line_with_extra_whitespace(self) -> None:
        output = "  Status:   ACTIVE  \n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "ACTIVE"

    def test_empty_agent_id_when_no_arn_or_id_line(self) -> None:
        output = "Status: ACTIVE\nSome other info: blah\n"
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "ACTIVE"
        assert result["agent_id"] == ""

    def test_status_only_keyword_no_value(self) -> None:
        """A line with just 'Status' and no value after split."""
        output = "Status\n"
        assert _parse_agentcore_status(output) is None

    def test_arn_line_preferred_over_agent_id_line(self) -> None:
        """When both ARN and Agent ID lines exist, last one wins."""
        output = (
            "Status: ACTIVE\n"
            "ARN: arn:first\n"
            "Agent ID: id-second\n"
        )
        result = _parse_agentcore_status(output)
        assert result is not None
        # agent_id line comes after arn, so it overwrites
        assert result["agent_id"] == "id-second"

    def test_multiline_verbose_output(self) -> None:
        output = (
            "Agent Details\n"
            "=============\n"
            "Name: my-agent\n"
            "Status: ACTIVE\n"
            "Region: us-west-2\n"
            "ARN: arn:aws:agentcore:us-west-2:999:agent/my-agent\n"
            "Created: 2026-01-01\n"
        )
        result = _parse_agentcore_status(output)
        assert result is not None
        assert result["status"] == "ACTIVE"
        assert "arn:aws:agentcore" in result["agent_id"]


# ---------------------------------------------------------------------------
# _parse_agentcore_list (deprecated, backward compat)
# ---------------------------------------------------------------------------


class TestParseAgentcoreList:
    """Tests for the deprecated _parse_agentcore_list() parser."""

    def test_parses_standard_table(self) -> None:
        output = (
            "NAME            STATUS    AGENT_ID\n"
            "my-agent        ACTIVE    abc-123\n"
            "other-agent     CREATING  def-456\n"
        )
        result = _parse_agentcore_list(output)
        assert "my-agent" in result
        assert result["my-agent"]["status"] == "ACTIVE"
        assert result["my-agent"]["agent_id"] == "abc-123"
        assert result["other-agent"]["status"] == "CREATING"

    def test_empty_output_returns_empty(self) -> None:
        assert _parse_agentcore_list("") == {}

    def test_header_only_returns_empty(self) -> None:
        output = "NAME  STATUS  AGENT_ID\n"
        assert _parse_agentcore_list(output) == {}

    def test_skips_separator_lines(self) -> None:
        output = (
            "NAME            STATUS    AGENT_ID\n"
            "---             ------    --------\n"
            "my-agent        ACTIVE    abc-123\n"
        )
        result = _parse_agentcore_list(output)
        assert "my-agent" in result

    def test_row_without_agent_id(self) -> None:
        output = (
            "NAME            STATUS\n"
            "my-agent        ACTIVE\n"
        )
        result = _parse_agentcore_list(output)
        assert result["my-agent"]["agent_id"] == ""


# ---------------------------------------------------------------------------
# _query_agentcore_cli
# ---------------------------------------------------------------------------


class TestQueryAgentcoreCli:
    """Tests for _query_agentcore_cli() per-agent status querying."""

    def _make_agent(
        self,
        name: str = "test-agent",
        region: str = "us-east-1",
        file: str = "agent.py",
        has_yaml: bool = True,
    ) -> DiscoveredAgent:
        return DiscoveredAgent(
            file=file,
            name=name,
            has_agentcore_yaml=has_yaml,
            aws_region=region,
        )

    def test_returns_empty_when_agentcore_not_found(self) -> None:
        agents = [self._make_agent()]
        with patch("shutil.which", return_value=None):
            result = _query_agentcore_cli(agents)
        assert result == {}

    def test_queries_each_agent_individually(self) -> None:
        agents = [
            self._make_agent(name="agent-a"),
            self._make_agent(name="agent-b"),
        ]
        calls: list[list[str]] = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = f"Status: ACTIVE\nARN: arn-{cmd[3]}\n"
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            result = _query_agentcore_cli(agents)

        assert len(calls) == 2
        assert calls[0][3] == "agent-a"
        assert calls[1][3] == "agent-b"
        assert "agent-a" in result
        assert "agent-b" in result

    def test_includes_region_flag_when_available(self) -> None:
        agents = [self._make_agent(region="eu-west-1")]
        captured_cmd: list[str] = []

        def fake_run(cmd, **kwargs):
            captured_cmd.extend(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = "Status: ACTIVE\n"
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            _query_agentcore_cli(agents)

        assert "--region" in captured_cmd
        assert "eu-west-1" in captured_cmd

    def test_skips_agent_on_nonzero_returncode(self) -> None:
        agents = [self._make_agent(name="fail-agent")]

        def fake_run(cmd, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 1
            mock_result.stdout = ""
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            result = _query_agentcore_cli(agents)

        assert result == {}

    def test_skips_agent_on_timeout(self) -> None:
        agents = [self._make_agent(name="slow-agent")]

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch(
                 "subprocess.run",
                 side_effect=subprocess.TimeoutExpired(cmd="agentcore", timeout=30),
             ):
            result = _query_agentcore_cli(agents)

        assert result == {}

    def test_skips_agent_when_parse_returns_none(self) -> None:
        agents = [self._make_agent(name="no-status")]

        def fake_run(cmd, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = "No status info here\n"
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            result = _query_agentcore_cli(agents)

        assert result == {}

    def test_reads_aws_profile_from_agentcore_yaml(
        self, tmp_path: Path,
    ) -> None:
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("# agent", encoding="utf-8")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(
            "aws_region: us-east-1\naws_profile: my-profile\n",
            encoding="utf-8",
        )
        agents = [self._make_agent(file=str(agent_file))]
        captured_env: dict[str, str] = {}

        def fake_run(cmd, **kwargs):
            captured_env.update(kwargs.get("env", {}))
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = "Status: ACTIVE\n"
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            _query_agentcore_cli(agents)

        assert captured_env.get("AWS_PROFILE") == "my-profile"

    def test_partial_success_returns_successful_agents_only(self) -> None:
        agents = [
            self._make_agent(name="good-agent"),
            self._make_agent(name="bad-agent"),
        ]
        call_count = 0

        def fake_run(cmd, **kwargs):
            nonlocal call_count
            call_count += 1
            mock_result = MagicMock()
            if cmd[3] == "good-agent":
                mock_result.returncode = 0
                mock_result.stdout = "Status: ACTIVE\nARN: arn-good\n"
            else:
                mock_result.returncode = 1
                mock_result.stdout = ""
            return mock_result

        with patch("shutil.which", return_value="/usr/bin/agentcore"), \
             patch("subprocess.run", side_effect=fake_run):
            result = _query_agentcore_cli(agents)

        assert "good-agent" in result
        assert "bad-agent" not in result
        assert call_count == 2

    def test_empty_agents_list_returns_empty(self) -> None:
        with patch("shutil.which", return_value="/usr/bin/agentcore"):
            result = _query_agentcore_cli([])
        assert result == {}

    def test_uses_fallback_binary_path(self) -> None:
        """Falls back to scripts dir when shutil.which returns None."""
        agents = [self._make_agent()]
        captured_cmd: list[str] = []

        def fake_run(cmd, **kwargs):
            captured_cmd.extend(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = "Status: ACTIVE\n"
            return mock_result

        with patch("shutil.which", return_value=None), \
             patch("pathlib.Path.exists", return_value=True), \
             patch("subprocess.run", side_effect=fake_run):
            result = _query_agentcore_cli(agents)

        # Should have found the fallback binary and queried
        assert len(captured_cmd) > 0


# ---------------------------------------------------------------------------
# check_agentcore_status
# ---------------------------------------------------------------------------


class TestCheckAgentcoreStatus:
    """Tests for check_agentcore_status() enrichment logic."""

    def test_enriches_agents_with_live_status(self) -> None:
        agents = [
            DiscoveredAgent(
                file="agent.py",
                name="my-agent",
                has_agentcore_yaml=True,
                aws_region="us-east-1",
            ),
        ]
        mock_map = {"my-agent": {"status": "ACTIVE", "agent_id": "agt-1"}}
        with patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value=mock_map,
        ):
            result = check_agentcore_status(agents)

        assert result[0].cloud_status == "ACTIVE"
        assert result[0].agent_id == "agt-1"
        assert result[0].is_deployed is True

    def test_sets_unknown_when_cloud_has_no_info(self) -> None:
        agents = [
            DiscoveredAgent(
                file="agent.py",
                name="my-agent",
                has_agentcore_yaml=True,
                is_deployed=True,
                aws_region="us-east-1",
            ),
        ]
        with patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value={},
        ):
            result = check_agentcore_status(agents)

        assert result[0].cloud_status == "UNKNOWN"

    def test_skips_agents_without_agentcore_yaml(self) -> None:
        agents = [
            DiscoveredAgent(file="agent.py", name="local-only"),
        ]
        with patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value={},
        ) as mock_query:
            check_agentcore_status(agents)

        mock_query.assert_not_called()

    def test_non_active_status_sets_is_deployed_false(self) -> None:
        agents = [
            DiscoveredAgent(
                file="agent.py",
                name="my-agent",
                has_agentcore_yaml=True,
                aws_region="us-east-1",
            ),
        ]
        mock_map = {"my-agent": {"status": "CREATING", "agent_id": "agt-1"}}
        with patch(
            "synth.cli.discover._query_agentcore_cli",
            return_value=mock_map,
        ):
            result = check_agentcore_status(agents)

        assert result[0].cloud_status == "CREATING"
        assert result[0].is_deployed is False
