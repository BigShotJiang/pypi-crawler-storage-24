"""Unit tests for agent registry API endpoints in server.py.

Tests the GET /api/agents, POST /api/agents/{name}/start,
POST /api/agents/{name}/stop, and POST /api/agents/{name}/connect
endpoints defined in ``synth/cli/_ui_assets/server.py``.

Requirements: 5.2, 5.3, 5.4, 5.5
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

from synth.cli.registry import RegistryRecord, RegistryStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sample_record(name: str = "my_agent") -> RegistryRecord:
    """Create a sample registry record for testing."""
    return RegistryRecord(
        agent_name=name,
        region="us-west-2",
        model_id="anthropic.claude-sonnet-4-20250514",
        source_file="agent.py",
        deployed_at="2025-01-15T10:30:00+00:00",
        aws_profile="dev-profile",
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _ensure_static_dir() -> None:
    """Ensure the static assets directory exists so the FastAPI app imports."""
    import synth.cli as _cli_pkg

    static_dir = (
        Path(_cli_pkg.__file__).parent / "_ui_assets" / "static"
    )
    static_dir.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Test class
# ---------------------------------------------------------------------------

class TestAgentsAPI:
    """Tests for the /api/agents endpoints."""

    @pytest.mark.asyncio
    async def test_get_agents_empty_registry(self, tmp_path: Path) -> None:
        """GET /api/agents returns an empty JSON array when no agents exist."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._query_remote_agents",
            return_value=({}, None),
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.get("/api/agents")

        assert resp.status_code == 200
        assert resp.json()["agents"] == []

    @pytest.mark.asyncio
    async def test_get_agents_populated(self, tmp_path: Path) -> None:
        """GET /api/agents returns all agents with correct fields."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        rec_a = _sample_record("agent_alpha")
        rec_b = _sample_record("agent_beta")
        store.add_agent(rec_a)
        store.add_agent(rec_b)

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._query_remote_agents",
            return_value=({}, None),
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.get("/api/agents")

        assert resp.status_code == 200
        body = resp.json()["agents"]
        assert len(body) == 2

        names = {entry["agent_name"] for entry in body}
        assert names == {"agent_alpha", "agent_beta"}

        for entry in body:
            assert "region" in entry
            assert "model_id" in entry
            assert "source_file" in entry
            assert "deployed_at" in entry
            assert "aws_profile" in entry
            assert "status" in entry
            assert entry["status"] == "unknown"

    @pytest.mark.asyncio
    async def test_start_agent_success(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/start returns success on subprocess ok."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        cmd_result = {"success": True, "message": "Agent launch succeeded"}

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._run_agentcore_cmd",
            return_value=cmd_result,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/start")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True
        assert "launch" in body["message"].lower() or "succeeded" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_start_agent_not_found(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/start returns 400 for unknown agent."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._get_default_region_and_profile",
            return_value=("", None),
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/nonexistent/start")

        assert resp.status_code == 400
        body = resp.json()
        assert body["success"] is False

    @pytest.mark.asyncio
    async def test_stop_agent_success(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/stop returns success on subprocess ok."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        cmd_result = {"success": True, "message": "Agent stop succeeded"}

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._run_agentcore_cmd",
            return_value=cmd_result,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/stop")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True

    @pytest.mark.asyncio
    async def test_stop_agent_not_found(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/stop returns 400 for unknown agent."""
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ), patch(
            "synth.cli._ui_assets.server._get_default_region_and_profile",
            return_value=("", None),
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/ghost/stop")

        assert resp.status_code == 400
        body = resp.json()
        assert body["success"] is False

    @pytest.mark.asyncio
    async def test_connect_agent(self, tmp_path: Path) -> None:
        """POST /api/agents/{name}/connect sets _remote_agent state."""
        import synth.cli._ui_assets.server as server_mod
        from synth.cli._ui_assets.server import app

        store = RegistryStore(path=tmp_path / "registry.json")
        store.add_agent(_sample_record("my_agent"))

        # Reset state before test
        server_mod._remote_agent = None

        with patch(
            "synth.cli.registry.RegistryStore",
            return_value=store,
        ):
            transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
            async with httpx.AsyncClient(
                transport=transport, base_url="http://test"
            ) as client:
                resp = await client.post("/api/agents/my_agent/connect")

        assert resp.status_code == 200
        body = resp.json()
        assert body["success"] is True
        assert "my_agent" in body["message"]

        # Verify module-level state was set
        assert server_mod._remote_agent is not None
        assert server_mod._remote_agent["name"] == "my_agent"
        assert server_mod._remote_agent["region"] == "us-west-2"
        assert server_mod._remote_agent["aws_profile"] == "dev-profile"

        # Clean up
        server_mod._remote_agent = None


# ---------------------------------------------------------------------------
# Direct tests for _run_agentcore_cmd
# ---------------------------------------------------------------------------

class TestRunAgentcoreCmd:
    """Tests for the _run_agentcore_cmd helper function."""

    def test_agent_name_included_in_command(self) -> None:
        """The agent_name argument is passed as a positional arg to the CLI."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
        ) as mock_run:
            mock_run.return_value.returncode = 0
            _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", "dev-profile"
            )

        cmd = mock_run.call_args[0][0]
        assert cmd == [
            "/usr/bin/agentcore", "launch", "my_agent",
            "--region", "us-west-2",
        ]

    def test_stop_action_includes_agent_name(self) -> None:
        """Stop action also passes agent_name positionally."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
        ) as mock_run:
            mock_run.return_value.returncode = 0
            _run_agentcore_cmd(
                "stop", "other_agent", "eu-west-1", None
            )

        cmd = mock_run.call_args[0][0]
        assert cmd == [
            "/usr/bin/agentcore", "stop", "other_agent",
            "--region", "eu-west-1",
        ]

    def test_success_returns_true(self) -> None:
        """Successful subprocess returns success dict."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
        ) as mock_run:
            mock_run.return_value.returncode = 0
            result = _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", None
            )

        assert result["success"] is True
        assert "succeeded" in result["message"].lower()

    def test_nonzero_returncode_returns_failure(self) -> None:
        """Non-zero exit code returns failure with stderr message."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
        ) as mock_run:
            mock_run.return_value.returncode = 1
            mock_run.return_value.stderr = "credentials expired"
            mock_run.return_value.stdout = ""
            result = _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", None
            )

        assert result["success"] is False
        assert "credentials expired" in result["message"]

    def test_agentcore_bin_not_found(self) -> None:
        """Returns failure when agentcore binary is not found."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value=None,
        ):
            result = _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", None
            )

        assert result["success"] is False
        assert "not found" in result["message"].lower()

    def test_timeout_returns_failure(self) -> None:
        """Subprocess timeout returns a descriptive failure."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="agentcore", timeout=120),
        ):
            result = _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", None
            )

        assert result["success"] is False
        assert "timed out" in result["message"].lower()

    def test_file_not_found_returns_failure(self) -> None:
        """FileNotFoundError returns install suggestion."""
        from synth.cli._ui_assets.server import _run_agentcore_cmd

        with patch(
            "synth.cli._ui_assets.server._find_agentcore_bin",
            return_value="/usr/bin/agentcore",
        ), patch(
            "synth.cli._ui_assets.server.subprocess.run",
            side_effect=FileNotFoundError,
        ):
            result = _run_agentcore_cmd(
                "launch", "my_agent", "us-west-2", None
            )

        assert result["success"] is False
        assert "not found" in result["message"].lower()
