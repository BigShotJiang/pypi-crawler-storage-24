"""CLI commands for managing deployed AgentCore agents.

Provides the ``synth agents`` command group with ``list``, ``status``,
``start``, and ``stop`` subcommands.  All commands read from the local
agent registry (``~/.synth/registry.json``) and delegate to the
``agentcore`` CLI binary for live operations.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

import click

from synth.cli.registry import RegistryRecord, RegistryStore


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_AGENTCORE_INSTALL_HINT = (
    "AgentCore CLI not found. "
    "Install it with: pip install bedrock-agentcore-starter-toolkit"
)

_CREDENTIAL_KEYWORDS = ("expired", "token", "credentials")

_CREDENTIAL_EXPIRED_MSG = (
    "AWS session expired. Run `aws login` to refresh your credentials."
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_agentcore_bin() -> str | None:
    """Locate the ``agentcore`` binary on ``PATH`` or next to the interpreter."""
    agentcore_bin = shutil.which("agentcore")
    if agentcore_bin:
        return agentcore_bin

    scripts_dir = os.path.dirname(sys.executable)
    suffix = ".exe" if sys.platform == "win32" else ""
    candidate = os.path.join(scripts_dir, f"agentcore{suffix}")
    if os.path.isfile(candidate):
        return candidate

    return None


def _is_credential_error(text: str) -> bool:
    """Return ``True`` if *text* looks like an AWS credential expiry error."""
    lower = text.lower()
    return any(kw in lower for kw in _CREDENTIAL_KEYWORDS)


def _print_ok(label: str, message: str) -> None:
    """Print a ``[  OK  ]`` status line."""
    status = click.style("[  OK  ]", fg="green")
    click.echo(f"  {status} {label}: {message}")


def _print_fail(label: str, message: str, suggestion: str | None = None) -> None:
    """Print a ``[FAIL]`` status line with an optional suggestion."""
    status = click.style("[FAIL]", fg="red")
    click.echo(f"  {status}  {label}: {message}")
    if suggestion:
        click.echo(
            f"         {click.style('Suggestion:', fg='yellow')} {suggestion}"
        )


def _agent_not_found(name: str, store: RegistryStore) -> None:
    """Print an error for a missing agent and list available names."""
    agents = store.list_agents()
    if agents:
        names = ", ".join(a.agent_name for a in agents)
        _print_fail(
            "Agent lookup",
            f"Agent '{name}' not found in registry",
            f"Available agents: {names}. Run `synth deploy` to register a new agent.",
        )
    else:
        _print_fail(
            "Agent lookup",
            f"Agent '{name}' not found in registry",
            "No agents registered. Run `synth deploy` to register an agent.",
        )


def _get_default_region_and_profile() -> tuple[str, str | None]:
    """Read region and aws_profile from the nearest agentcore.yaml.

    Walks up from CWD looking for ``agentcore.yaml`` and extracts
    ``aws_region`` and ``aws_profile`` values.

    Returns
    -------
    tuple[str, str | None]
        ``(region, aws_profile)`` — empty string if region not found.
    """
    from pathlib import Path

    cwd = Path.cwd()
    yaml_path = cwd / "agentcore.yaml"
    if not yaml_path.exists():
        return "", None

    region = ""
    aws_profile: str | None = None
    try:
        text = yaml_path.read_text(encoding="utf-8")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("aws_region:"):
                region = (
                    stripped.split(":", 1)[1].strip().strip("\"'")
                )
            if stripped.startswith("aws_profile:"):
                aws_profile = (
                    stripped.split(":", 1)[1].strip().strip("\"'")
                )
    except Exception:
        pass
    return region, aws_profile


def _query_live_status(
    store: RegistryStore,
) -> dict[str, dict[str, str]]:
    """Query AgentCore for live status of all agents in the account.

    Uses boto3 ``list_agent_runtimes`` as the primary source, which
    discovers all agents including those deployed from other machines.
    Falls back to ``_query_agentcore_cli`` from ``discover.py`` when
    boto3 is unavailable.

    Returns ``{name: {status, agent_id}}`` or an empty dict on failure.
    """
    agents = store.list_agents()

    # Determine region and profile from registry
    region = ""
    aws_profile: str | None = None
    for rec in agents:
        if rec.region:
            region = rec.region
            break
    for rec in agents:
        if rec.aws_profile:
            aws_profile = rec.aws_profile
            break

    # If no registry agents, try agentcore.yaml
    if not region:
        region, aws_profile = _get_default_region_and_profile()

    # Try boto3 API first — discovers all agents in the account
    from synth.cli.discover import _list_agent_runtimes_boto3
    result = _list_agent_runtimes_boto3(region, aws_profile)
    if result is not None:
        return result

    # Fallback: per-agent CLI queries via discover module
    if not agents:
        return {}

    from synth.cli.discover import (
        DiscoveredAgent,
        _query_agentcore_cli,
    )

    discovered: list[DiscoveredAgent] = []
    for rec in agents:
        da = DiscoveredAgent(
            name=rec.agent_name,
            file=rec.source_file,
            has_agentcore_yaml=True,
            aws_region=rec.region,
        )
        discovered.append(da)

    try:
        return _query_agentcore_cli(discovered)
    except Exception:
        return {}


def _build_subprocess_env(record: RegistryRecord) -> dict[str, str]:
    """Build an environment dict with ``AWS_PROFILE`` set if applicable."""
    env = os.environ.copy()
    if record.aws_profile:
        env["AWS_PROFILE"] = record.aws_profile
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONWARNINGS"] = "ignore"
    return env


# ---------------------------------------------------------------------------
# Command group
# ---------------------------------------------------------------------------

@click.group("agents")
def agents_group() -> None:
    """Manage deployed AgentCore agents."""


# ---------------------------------------------------------------------------
# synth agents list
# ---------------------------------------------------------------------------

@agents_group.command("list")
def agents_list_cmd() -> None:
    """List all agents from AWS AgentCore with local registry enrichment."""
    store = RegistryStore()
    registry_agents = store.list_agents()
    registry_by_name: dict[str, RegistryRecord] = {
        rec.agent_name: rec for rec in registry_agents
    }

    # Query live status from AWS
    live_status = _query_live_status(store)

    # Merge: remote agents first, then local-only
    seen: set[str] = set()
    rows: list[tuple[str, str, str, str]] = []

    for name, info in sorted(live_status.items()):
        seen.add(name)
        local = registry_by_name.get(name)
        region = local.region if local else ""
        deployed = local.deployed_at if local else ""
        rows.append((name, region, info["status"].lower(), deployed))

    for rec in registry_agents:
        if rec.agent_name not in seen:
            seen.add(rec.agent_name)
            rows.append((
                rec.agent_name, rec.region, "unknown", rec.deployed_at,
            ))

    if not rows:
        click.echo(
            "No agents found. Run `synth deploy` to deploy an agent, "
            "or check your AWS credentials."
        )
        return

    # Header
    click.echo()
    header = (
        f"  {'Name':<30} {'Region':<16} {'Status':<12} {'Deployed'}"
    )
    click.echo(click.style(header, bold=True))
    click.echo(
        f"  {'─' * 30} {'─' * 16} {'─' * 12} {'─' * 24}"
    )

    color_map = {
        "active": "green",
        "creating": "yellow",
        "failed": "red",
        "deleting": "yellow",
        "unknown": "white",
    }

    for name, region, status_text, deployed in rows:
        color = color_map.get(status_text, "white")
        styled_status = click.style(status_text, fg=color)
        click.echo(
            f"  {name:<30} {region:<16} "
            f"{styled_status:<21} {deployed}"
        )

    click.echo()
    _print_ok("Agent list", f"{len(rows)} agent(s) found")


# ---------------------------------------------------------------------------
# synth agents status <name>
# ---------------------------------------------------------------------------

@agents_group.command("status")
@click.argument("name")
def agents_status_cmd(name: str) -> None:
    """Show detailed status for a specific agent.

    Checks the local registry first, then falls back to querying AWS
    directly so that remote-only agents can be inspected.
    """
    store = RegistryStore()
    record = store.get_agent(name)

    # Query live status
    live_status = _query_live_status(store)
    info = live_status.get(name)

    if record is None and info is None:
        _agent_not_found(name, store)
        sys.exit(1)

    if info:
        status_text = info["status"].lower()
    else:
        status_text = "unknown"

    # Check for credential errors when status is unknown
    if not info and record is not None:
        try:
            _probe_credentials(record)
        except _CredentialExpiredError:
            click.echo(click.style(_CREDENTIAL_EXPIRED_MSG, fg="yellow"))
            sys.exit(1)

    region = record.region if record else ""
    model_id = record.model_id if record else ""
    source_file = record.source_file if record else ""
    deployed_at = record.deployed_at if record else ""
    aws_profile = record.aws_profile if record else None

    click.echo()
    click.echo(click.style(f"  Agent: {name}", bold=True))
    click.echo(f"  Region:      {region or '(from AWS)'}")
    click.echo(f"  Model:       {model_id or '—'}")
    click.echo(f"  Source:      {source_file or '—'}")
    click.echo(f"  Deployed:    {deployed_at or '—'}")
    click.echo(f"  AWS Profile: {aws_profile or '(default)'}")
    click.echo(f"  Status:      {status_text}")
    if info and info.get("agent_id"):
        click.echo(f"  Agent ID:    {info['agent_id']}")
    click.echo()
    _print_ok("Agent status", f"Details for '{name}'")


# ---------------------------------------------------------------------------
# Credential probing
# ---------------------------------------------------------------------------

class _CredentialExpiredError(Exception):
    """Internal signal for expired AWS credentials."""


def _probe_credentials(record: RegistryRecord) -> None:
    """Probe AWS credentials by attempting a lightweight API call.

    Tries boto3 ``list_agent_runtimes`` first (single page, max 1
    result).  Falls back to ``agentcore status`` CLI if boto3 is
    unavailable.

    Raises
    ------
    _CredentialExpiredError
        If the call indicates expired credentials.
    """
    try:
        import boto3
        import botocore.exceptions

        session_kwargs: dict[str, str] = {}
        if record.aws_profile:
            session_kwargs["profile_name"] = record.aws_profile
        if record.region:
            session_kwargs["region_name"] = record.region

        session = boto3.Session(**session_kwargs)
        client = session.client("bedrock-agentcore-control")
        client.list_agent_runtimes(maxResults=1)
        return  # Credentials are valid
    except ImportError:
        pass  # boto3 not installed, fall through to CLI
    except Exception as exc:
        msg = str(exc).lower()
        if any(kw in msg for kw in _CREDENTIAL_KEYWORDS):
            raise _CredentialExpiredError() from exc
        return  # Other errors are not credential issues

    # Fallback: CLI probe
    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        return

    env = _build_subprocess_env(record)
    cmd = [
        agentcore_bin, "status",
        "--agent", record.agent_name,
        "--region", record.region,
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        if result.returncode != 0 and _is_credential_error(combined):
            raise _CredentialExpiredError()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass


# ---------------------------------------------------------------------------
# synth agents start <name>
# ---------------------------------------------------------------------------

@agents_group.command("start")
@click.argument("name")
def agents_start_cmd(name: str) -> None:
    """Start a deployed agent via AgentCore.

    Looks up the agent in the local registry first.  If not found,
    falls back to the default region and profile from agentcore.yaml
    so that remote-only agents can still be started.
    """
    store = RegistryStore()
    record = store.get_agent(name)

    if record is not None:
        region = record.region
        profile = record.aws_profile
        env = _build_subprocess_env(record)
    else:
        region, profile = _get_default_region_and_profile()
        if not region:
            _print_fail(
                "Start agent",
                f"Cannot determine AWS region for agent '{name}'",
                "Set aws_region in agentcore.yaml or deploy the "
                "agent with `synth deploy` first.",
            )
            sys.exit(1)
        # Build env manually for non-registry agents
        env = os.environ.copy()
        if profile:
            env["AWS_PROFILE"] = profile
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONWARNINGS"] = "ignore"

    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        _print_fail("Start agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

    cmd = [agentcore_bin, "launch", name, "--region", region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"

        if result.returncode == 0:
            _print_ok("Start agent", f"Agent '{name}' started successfully")
        else:
            if _is_credential_error(combined):
                _print_fail(
                    "Start agent",
                    _CREDENTIAL_EXPIRED_MSG,
                )
            else:
                msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                _print_fail(
                    "Start agent",
                    f"Failed to start agent '{name}'",
                    msg,
                )
            sys.exit(1)

    except subprocess.TimeoutExpired:
        _print_fail(
            "Start agent",
            f"Timed out starting agent '{name}'",
            "The AgentCore CLI did not respond within 120 seconds.",
        )
        sys.exit(1)
    except FileNotFoundError:
        _print_fail("Start agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)


# ---------------------------------------------------------------------------
# synth agents stop <name>
# ---------------------------------------------------------------------------

@agents_group.command("stop")
@click.argument("name")
def agents_stop_cmd(name: str) -> None:
    """Stop a deployed agent via AgentCore.

    Falls back to default region/profile when the agent is not in the
    local registry (i.e. it was discovered from AWS directly).
    """
    store = RegistryStore()
    record = store.get_agent(name)

    if record is not None:
        region = record.region
        profile = record.aws_profile
        env = _build_subprocess_env(record)
    else:
        region, profile = _get_default_region_and_profile()
        if not region:
            _print_fail(
                "Stop agent",
                f"Cannot determine AWS region for agent '{name}'",
                "Set aws_region in agentcore.yaml or deploy the "
                "agent with `synth deploy` first.",
            )
            sys.exit(1)
        env = os.environ.copy()
        if profile:
            env["AWS_PROFILE"] = profile
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONWARNINGS"] = "ignore"

    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        _print_fail("Stop agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

    cmd = [agentcore_bin, "stop", name, "--region", region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"

        if result.returncode == 0:
            _print_ok("Stop agent", f"Agent '{name}' stopped successfully")
        else:
            if _is_credential_error(combined):
                _print_fail(
                    "Stop agent",
                    _CREDENTIAL_EXPIRED_MSG,
                )
            else:
                msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                _print_fail(
                    "Stop agent",
                    f"Failed to stop agent '{name}'",
                    msg,
                )
            sys.exit(1)

    except subprocess.TimeoutExpired:
        _print_fail(
            "Stop agent",
            f"Timed out stopping agent '{name}'",
            "The AgentCore CLI did not respond within 120 seconds.",
        )
        sys.exit(1)
    except FileNotFoundError:
        _print_fail("Stop agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

# ---------------------------------------------------------------------------
# synth agents destroy <name>
# ---------------------------------------------------------------------------

@agents_group.command("destroy")
@click.argument("name")
def agents_destroy_cmd(name: str) -> None:
    """Destroy a deployed AgentCore agent runtime."""
    store = RegistryStore()
    record = store.get_agent(name)

    if record is None:
        # Try to discover the agent from AWS before giving up.
        live_status = _query_live_status(store)
        if name not in live_status:
            _agent_not_found(name, store)
            sys.exit(1)

    if record is not None:
        region = record.region
        profile = record.aws_profile
        env = _build_subprocess_env(record)
    else:
        region, profile = _get_default_region_and_profile()
        if not region:
            _print_fail(
                "Destroy agent",
                f"Cannot determine AWS region for agent '{name}'",
                "Set aws_region in agentcore.yaml or deploy the "
                "agent with `synth deploy` first.",
            )
            sys.exit(1)
        env = os.environ.copy()
        if profile:
            env["AWS_PROFILE"] = profile
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONWARNINGS"] = "ignore"

    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        _print_fail("Destroy agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

    cmd = [agentcore_bin, "destroy", name, "--region", region]
    if profile:
        cmd.extend(["--profile", profile])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        combined = f"{result.stdout}\n{result.stderr}"

        if result.returncode == 0:
            store.remove_agent(name)
            _print_ok("Destroy agent", f"Agent '{name}' destroyed successfully")
        else:
            if _is_credential_error(combined):
                _print_fail(
                    "Destroy agent",
                    _CREDENTIAL_EXPIRED_MSG,
                )
            else:
                msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
                _print_fail(
                    "Destroy agent",
                    f"Failed to destroy agent '{name}'",
                    msg,
                )
            sys.exit(1)

    except subprocess.TimeoutExpired:
        _print_fail(
            "Destroy agent",
            f"Timed out destroying agent '{name}'",
            "The AgentCore CLI did not respond within 120 seconds.",
        )
        sys.exit(1)
    except FileNotFoundError:
        _print_fail("Destroy agent", _AGENTCORE_INSTALL_HINT)
        sys.exit(1)

