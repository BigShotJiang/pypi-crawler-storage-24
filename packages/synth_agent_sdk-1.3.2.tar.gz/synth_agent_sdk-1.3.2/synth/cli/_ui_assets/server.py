"""Local testing UI server — bridges the browser to your Synth agent.

Run:
    python server.py

Then open http://localhost:8420 in your browser.
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
except ImportError:
    print("Missing dependencies. Install them with:")
    print("  pip install uvicorn fastapi")
    sys.exit(1)

from synth.errors import SynthConfigError
from synth.types import (
    DoneEvent,
    StageEvent,
    ThinkingEvent,
    TokenEvent,
    ToolCallEvent,
    ToolResultEvent,
)

# ---------------------------------------------------------------------------
# Multi-agent orchestration type detection
# ---------------------------------------------------------------------------

_MULTI_AGENT_TYPE: str | None = None  # "team", "pipeline", "graph", or None

# ---------------------------------------------------------------------------
# Remote agent routing state
# ---------------------------------------------------------------------------

_remote_agent: dict[str, str] | None = None

# ---------------------------------------------------------------------------
# Evaluation data models
# ---------------------------------------------------------------------------


@dataclass
class EvaluationResult:
    """A single evaluation score from AgentCore Evaluations.

    Parameters
    ----------
    evaluator_name : str
        Name of the evaluator that produced this score.
    score : float
        Numeric evaluation score.
    level : str
        Evaluation granularity — one of ``"SESSION"``, ``"TRACE"``, or
        ``"TOOL_CALL"``.
    timestamp : str
        ISO 8601 timestamp of when the evaluation was performed.
    """

    evaluator_name: str
    score: float
    level: str
    timestamp: str


@dataclass
class EvaluationConfigStatus:
    """Online evaluation configuration status.

    Parameters
    ----------
    config_name : str
        Name of the online evaluation configuration.
    active : bool
        Whether the configuration is currently active.
    sampling_rate : float
        Fraction of traffic sampled for evaluation (0.0–1.0).
    evaluators : list[str]
        List of evaluator identifiers included in this configuration.
    """

    config_name: str
    active: bool
    sampling_rate: float
    evaluators: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Configuration — point this at your agent file
# ---------------------------------------------------------------------------
AGENT_FILE = os.environ.get("SYNTH_AGENT_FILE", "../agent.py")
PERSIST_FILE = Path(__file__).parent / "conversations.json"
PROMPTS_FILE = Path(__file__).parent / "prompts.json"
EVALS_FILE = Path(__file__).parent / "evals.json"
SCENARIOS_FILE = Path(__file__).parent / "scenarios.json"

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

@asynccontextmanager
async def _lifespan(application: FastAPI):
    """Load persisted data and the agent on startup."""
    _load_conversations()
    _load_prompts()
    _load_evals()
    _load_scenarios()
    try:
        _load_agent()
        print(f"Agent loaded from {AGENT_FILE}")
    except Exception as exc:
        _agent_status["error"] = str(exc)
        print(f"Warning: could not load agent: {exc}")
    yield


app = FastAPI(title="Synth Agent UI", lifespan=_lifespan)
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

_agent = None
_agent_status: dict[str, Any] = {"loaded": False, "error": None, "file": AGENT_FILE, "tool_errors": []}
_conversations: dict[str, list[dict]] = {"default": []}
_current_conv = "default"
_prompts: dict[str, list[dict]] = {}
_evals: list[dict] = []
_scenarios: list[dict] = []

# Runtime configuration state for drift detection and tool toggling
_original_config: dict[str, Any] = {}
_disabled_tools: set[str] = set()
_all_tools: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------

def _load_conversations():
    global _conversations
    if PERSIST_FILE.exists():
        try:
            _conversations = json.loads(PERSIST_FILE.read_text(encoding="utf-8"))
        except Exception:
            _conversations = {"default": []}
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _save_conversations():
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _load_prompts():
    global _prompts
    if PROMPTS_FILE.exists():
        try:
            _prompts = json.loads(PROMPTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _prompts = {}


def _save_prompts():
    try:
        PROMPTS_FILE.write_text(json.dumps(_prompts, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save prompts: {e}")


def _load_evals():
    global _evals
    if EVALS_FILE.exists():
        try:
            _evals = json.loads(EVALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _evals = []


def _save_evals():
    try:
        EVALS_FILE.write_text(json.dumps(_evals, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save evals: {e}")


def _load_scenarios():
    global _scenarios
    if SCENARIOS_FILE.exists():
        try:
            _scenarios = json.loads(SCENARIOS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _scenarios = []


def _save_scenarios():
    try:
        SCENARIOS_FILE.write_text(json.dumps(_scenarios, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save scenarios: {e}")


# ---------------------------------------------------------------------------
# Agent loader
# ---------------------------------------------------------------------------

def _load_agent():
    """Load the agent module and snapshot its configuration.

    Supports both single-agent files (exporting ``agent``) and
    multi-agent orchestration files (exporting ``team``, ``pipeline``,
    or ``graph``).
    """
    global _agent, _agent_status, _original_config
    global _disabled_tools, _all_tools, _MULTI_AGENT_TYPE

    # Ensure the agent's parent directory is on sys.path so that
    # sibling imports (e.g. ``from tools import ...``) resolve
    # regardless of where the server is launched from.
    agent_dir = str(Path(AGENT_FILE).resolve().parent)
    if agent_dir not in sys.path:
        sys.path.insert(0, agent_dir)

    spec = importlib.util.spec_from_file_location("_agent_mod", AGENT_FILE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load agent from '{AGENT_FILE}'")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Detect orchestration type: team > pipeline > graph > agent
    # Use isinstance checks to avoid false positives from MagicMock
    # or other dynamic attribute creation.
    _MULTI_AGENT_TYPE = None

    def _is_orchestration(obj: Any, cls_name: str) -> bool:
        """Check if obj is a real orchestration instance."""
        return type(obj).__name__ == cls_name

    candidate = getattr(mod, "team", None)
    if candidate is not None and _is_orchestration(
        candidate, "AgentTeam",
    ):
        _agent = candidate
        _MULTI_AGENT_TYPE = "team"
    else:
        candidate = getattr(mod, "pipeline", None)
        if candidate is not None and _is_orchestration(
            candidate, "Pipeline",
        ):
            _agent = candidate
            _MULTI_AGENT_TYPE = "pipeline"
        else:
            candidate = getattr(mod, "graph", None)
            if candidate is not None and _is_orchestration(
                candidate, "Graph",
            ):
                _agent = candidate
                _MULTI_AGENT_TYPE = "graph"
            elif hasattr(mod, "agent"):
                _agent = mod.agent
            else:
                raise RuntimeError(
                    f"'{AGENT_FILE}' must define 'agent', 'team', "
                    f"'pipeline', or 'graph'.",
                )

    _agent_status = {
        "loaded": True,
        "error": None,
        "file": AGENT_FILE,
        "tool_errors": [],
        "multi_agent": _MULTI_AGENT_TYPE,
    }

    # Snapshot original config for drift detection, catching tool init errors
    tool_errors: list[str] = []
    try:
        tools = getattr(_agent, "_registered_tools", {})
    except Exception as exc:
        tool_errors.append(f"Failed to access registered tools: {exc}")
        tools = {}

    try:
        _original_config = {
            "model": getattr(_agent, "model", ""),
            "instructions": getattr(_agent, "instructions", ""),
            "tool_names": sorted(tools.keys()),
        }
    except Exception as exc:
        tool_errors.append(f"Failed to snapshot tool config: {exc}")
        _original_config = {
            "model": getattr(_agent, "model", ""),
            "instructions": getattr(_agent, "instructions", ""),
            "tool_names": [],
        }

    # Populate full tool registry (never mutated after load)
    try:
        _all_tools = dict(tools)
    except Exception as exc:
        tool_errors.append(f"Failed to build tool registry: {exc}")
        _all_tools = {}

    # Validate each tool's schema to catch initialization issues early
    for tool_name, tool_obj in list(_all_tools.items()):
        try:
            if hasattr(tool_obj, "get_schema"):
                tool_obj.get_schema()
        except Exception as exc:
            tool_errors.append(
                f"Tool '{tool_name}' failed to initialize: {exc}",
            )

    if tool_errors:
        _agent_status["tool_errors"] = tool_errors
        for err in tool_errors:
            print(f"Warning: {err}")

    # Reset disabled tools on fresh load
    _disabled_tools = set()

    return _agent


def _has_drift() -> bool:
    """Check if current agent config differs from the original snapshot."""
    if not _original_config or _agent is None:
        return False
    current_model = getattr(_agent, "model", "")
    current_instructions = getattr(_agent, "instructions", "")
    current_tools = getattr(_agent, "_registered_tools", {})
    current_tool_names = sorted(current_tools.keys())
    return (
        current_model != _original_config.get("model", "")
        or current_instructions != _original_config.get("instructions", "")
        or current_tool_names != _original_config.get("tool_names", [])
    )


def _run_agent(prompt: str, thread_id: str | None = None):
    """Run agent synchronously, return (result, elapsed_ms)."""
    start = time.perf_counter()
    if _MULTI_AGENT_TYPE == "team":
        result = _agent.run(prompt)
    elif _MULTI_AGENT_TYPE == "pipeline":
        result = _agent.run(prompt)
    elif _MULTI_AGENT_TYPE == "graph":
        result = _agent.run({"input": prompt})
    else:
        result = _agent.run(prompt, thread_id=thread_id)
    elapsed = (time.perf_counter() - start) * 1000
    return result, elapsed


def _build_msg(result, elapsed_ms: float) -> dict:
    """Build the final SSE message payload from a run result.

    Handles both single-agent ``RunResult`` and multi-agent
    ``TeamResult`` objects.
    """
    from synth.types import TeamResult

    if isinstance(result, TeamResult):
        contributions = []
        for c in result.contributions:
            contributions.append({
                "agent_name": c.agent_name,
                "text": c.result.text,
                "tokens": {
                    "input": c.result.tokens.input_tokens,
                    "output": c.result.tokens.output_tokens,
                    "total": c.result.tokens.total_tokens,
                },
                "cost": c.result.cost,
                "latency_ms": round(c.result.latency_ms, 1),
                "tool_calls": [
                    {
                        "name": tc.name,
                        "args": tc.args,
                        "result": str(tc.result),
                        "latency_ms": round(tc.latency_ms, 1),
                    }
                    for tc in c.result.tool_calls
                ],
            })
        return {
            "type": "done",
            "text": result.answer,
            "output": None,
            "tokens": {
                "input": sum(
                    c.result.tokens.input_tokens
                    for c in result.contributions
                ),
                "output": sum(
                    c.result.tokens.output_tokens
                    for c in result.contributions
                ),
                "total": sum(
                    c.result.tokens.total_tokens
                    for c in result.contributions
                ),
            },
            "cost": result.total_cost,
            "latency_ms": round(elapsed_ms, 1),
            "tool_calls": [],
            "trace": [],
            "multi_agent": {
                "type": _MULTI_AGENT_TYPE,
                "contributions": contributions,
            },
        }

    text = result.text or (
        result.output.answer if result.output else ""
    )
    return {
        "type": "done",
        "text": text,
        "output": (
            result.output.model_dump() if result.output else None
        ),
        "tokens": {
            "input": result.tokens.input_tokens,
            "output": result.tokens.output_tokens,
            "total": result.tokens.total_tokens,
        },
        "cost": result.cost,
        "latency_ms": round(elapsed_ms, 1),
        "tool_calls": [
            {
                "name": tc.name,
                "args": tc.args,
                "result": str(tc.result),
                "latency_ms": round(tc.latency_ms, 1),
            }
            for tc in result.tool_calls
        ],
        "trace": _serialize_trace(result),
    }


def _serialize_trace(result):
    trace = getattr(result, "trace", None)
    if trace is None:
        return []
    spans = getattr(trace, "spans", [])
    return [
        {
            "name": getattr(s, "name", "?"),
            "type": getattr(s, "span_type", "?"),
            "duration_ms": round(getattr(s, "duration_ms", 0.0), 1),
            "metadata": {k: v for k, v in getattr(s, "metadata", {}).items()},
        }
        for s in spans
    ]


async def _evaluate_guards_for_ui(
    response_text: str,
    tool_call_names: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Evaluate all agent guards and return results for UI display.

    Runs each guard's ``check()`` method individually with timing,
    capturing pass/fail status and violation messages.  This is a
    read-only evaluation for visibility — it does not raise on failure.

    Parameters
    ----------
    response_text:
        The agent response text to check against output guards.
    tool_call_names:
        Names of tools called during the run (may be empty).

    Returns
    -------
    list[dict[str, Any]]
        One dict per guard with keys: name, guard_type, passed,
        duration_ms, violation_message.
    """
    if _agent is None or not getattr(_agent, "guards", None):
        return []

    from synth.types import GuardContext

    context = GuardContext(
        cumulative_cost=0.0,
        tool_calls=tool_call_names or [],
        run_id=None,
    )

    results: list[dict[str, Any]] = []
    for guard in _agent.guards:
        start = time.perf_counter()
        try:
            result = await guard.check(response_text, context)
            elapsed = (time.perf_counter() - start) * 1000
            results.append({
                "name": guard.name,
                "guard_type": type(guard).__name__,
                "passed": result.passed,
                "duration_ms": round(elapsed, 2),
                "violation_message": result.violation_message,
            })
        except Exception as exc:
            elapsed = (time.perf_counter() - start) * 1000
            results.append({
                "name": guard.name,
                "guard_type": type(guard).__name__,
                "passed": False,
                "duration_ms": round(elapsed, 2),
                "violation_message": str(exc),
            })

    return results


@app.get("/", response_class=HTMLResponse)
async def index():
    html = (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


# ---------------------------------------------------------------------------
# Streaming chat endpoint (SSE)
# ---------------------------------------------------------------------------
@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    if _agent is None:
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'No agent loaded.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")

    if not prompt.strip():
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'Empty prompt.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    # --- Remote agent routing ---
    # When _remote_agent is set via /api/agents/{name}/connect, prompts
    # are routed through the AgentCore invocation API instead of the
    # local agent.  A full implementation would call the AgentCore
    # gateway here; for now we note the routing intent.
    is_remote = _remote_agent is not None

    async def generate():
        start = time.perf_counter()
        try:
            loop = asyncio.get_event_loop()

            # ----- Remote agent invocation via AgentCore -----
            if is_remote:
                invoker = RemoteAgentInvoker(
                    agent_name=_remote_agent["name"],
                    region=_remote_agent["region"],
                    aws_profile=_remote_agent.get("aws_profile") or None,
                )
                try:
                    t0 = time.time()
                    result = await loop.run_in_executor(
                        None, invoker.invoke, prompt, conv_id,
                    )
                    latency_ms = (time.time() - t0) * 1000

                    yield f"data: {json.dumps({'type': 'token', 'text': result['text']})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'text': result['text'], 'latency_ms': round(latency_ms, 1), 'session_id': result['session_id']})}\n\n"

                    if conv_id not in _conversations:
                        _conversations[conv_id] = []
                    _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
                    _conversations[conv_id].append({
                        "role": "agent",
                        "data": {
                            "type": "done",
                            "text": result["text"],
                            "latency_ms": round(latency_ms, 1),
                            "session_id": result["session_id"],
                        },
                        "ts": time.time(),
                    })
                    _save_conversations()
                except SynthConfigError as exc:
                    yield f"data: {json.dumps({'type': 'error', 'error': str(exc)})}\n\n"
                return

            full_text = ""
            full_thinking = ""
            result = None
            tool_call_names: list[str] = []

            # ----- Multi-agent: Team (no streaming, emit delegation events) -----
            if _MULTI_AGENT_TYPE == "team":
                result, elapsed = await loop.run_in_executor(
                    None, lambda: _run_agent(prompt, conv_id),
                )
                from synth.types import TeamResult
                if isinstance(result, TeamResult):
                    for c in result.contributions:
                        yield f"data: {json.dumps({'type': 'agent_start', 'agent_name': c.agent_name})}\n\n"
                        await asyncio.sleep(0)
                        if c.result.tool_calls:
                            for tc in c.result.tool_calls:
                                yield f"data: {json.dumps({'type': 'tool_call', 'name': tc.name, 'args': tc.args, 'agent_name': c.agent_name})}\n\n"
                                yield f"data: {json.dumps({'type': 'tool_result', 'name': tc.name, 'result': str(tc.result)[:2000], 'agent_name': c.agent_name})}\n\n"
                                await asyncio.sleep(0)
                        yield f"data: {json.dumps({'type': 'agent_complete', 'agent_name': c.agent_name, 'text': c.result.text[:2000], 'latency_ms': round(c.result.latency_ms, 1), 'cost': c.result.cost})}\n\n"
                        await asyncio.sleep(0)
                    msg = _build_msg(result, elapsed)
                    if conv_id not in _conversations:
                        _conversations[conv_id] = []
                    _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
                    _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
                    _save_conversations()
                    yield f"data: {json.dumps(msg)}\n\n"
                    return

            # ----- Multi-agent: Pipeline (streaming with StageEvent) -----
            elif _MULTI_AGENT_TYPE == "pipeline":
                current_stage = None

                def _stream_pipeline(q: queue.Queue) -> None:
                    try:
                        for event in _agent.stream(prompt):
                            q.put(event)
                    except Exception as exc:
                        q.put(exc)
                    finally:
                        q.put(None)

                q: queue.Queue = queue.Queue()
                thread = threading.Thread(
                    target=_stream_pipeline, args=(q,), daemon=True,
                )
                thread.start()

                while True:
                    item = await loop.run_in_executor(None, q.get)
                    if item is None:
                        break
                    if isinstance(item, Exception):
                        raise item
                    event = item
                    if isinstance(event, StageEvent):
                        stage_name = event.stage_name
                        inner = event.event
                        if stage_name != current_stage:
                            if current_stage is not None:
                                yield f"data: {json.dumps({'type': 'agent_complete', 'agent_name': current_stage, 'text': '', 'latency_ms': 0, 'cost': 0})}\n\n"
                            current_stage = stage_name
                            yield f"data: {json.dumps({'type': 'agent_start', 'agent_name': stage_name})}\n\n"
                            await asyncio.sleep(0)
                        if isinstance(inner, TokenEvent):
                            full_text += inner.text
                            yield f"data: {json.dumps({'type': 'token', 'text': inner.text, 'agent_name': stage_name})}\n\n"
                        elif isinstance(inner, ToolCallEvent):
                            tool_call_names.append(inner.name)
                            yield f"data: {json.dumps({'type': 'tool_call', 'name': inner.name, 'args': inner.args, 'agent_name': stage_name})}\n\n"
                        elif isinstance(inner, ToolResultEvent):
                            yield f"data: {json.dumps({'type': 'tool_result', 'name': inner.name, 'result': str(inner.result)[:2000], 'agent_name': stage_name})}\n\n"
                        elif isinstance(inner, ThinkingEvent):
                            full_thinking += inner.text
                            yield f"data: {json.dumps({'type': 'thinking', 'text': inner.text, 'agent_name': stage_name})}\n\n"
                        elif isinstance(inner, DoneEvent):
                            result = inner.result
                            yield f"data: {json.dumps({'type': 'agent_complete', 'agent_name': stage_name, 'text': (inner.result.text or '')[:2000], 'latency_ms': round(inner.result.latency_ms, 1), 'cost': inner.result.cost})}\n\n"
                        await asyncio.sleep(0)

                elapsed = (time.perf_counter() - start) * 1000
                if result is None:
                    result, elapsed = await loop.run_in_executor(
                        None, lambda: _run_agent(prompt, conv_id),
                    )
                msg = _build_msg(result, elapsed)
                msg["text"] = full_text or msg.get("text", "")
                if conv_id not in _conversations:
                    _conversations[conv_id] = []
                _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
                _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
                _save_conversations()
                yield f"data: {json.dumps(msg)}\n\n"
                return

            # ----- Multi-agent: Graph (no streaming, emit node events) -----
            elif _MULTI_AGENT_TYPE == "graph":
                result, elapsed = await loop.run_in_executor(
                    None, lambda: _run_agent(prompt, conv_id),
                )
                msg = _build_msg(result, elapsed)
                if conv_id not in _conversations:
                    _conversations[conv_id] = []
                _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
                _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
                _save_conversations()
                yield f"data: {json.dumps(msg)}\n\n"
                return

            # ----- Single agent (original flow) -----
            def _stream_to_queue(q: queue.Queue) -> None:
                try:
                    for event in _agent.stream(prompt, thread_id=conv_id):
                        q.put(event)
                except Exception as exc:
                    q.put(exc)
                finally:
                    q.put(None)

            q: queue.Queue = queue.Queue()
            thread = threading.Thread(
                target=_stream_to_queue, args=(q,), daemon=True,
            )
            thread.start()

            while True:
                item = await loop.run_in_executor(None, q.get)
                if item is None:
                    break
                if isinstance(item, Exception):
                    raise item
                event = item
                if isinstance(event, ThinkingEvent):
                    thinking = event.text
                    if thinking:
                        full_thinking += thinking
                        yield f"data: {json.dumps({'type': 'thinking', 'text': thinking})}\n\n"
                        await asyncio.sleep(0)
                elif isinstance(event, TokenEvent):
                    token = event.text
                    if token:
                        full_text += token
                        yield f"data: {json.dumps({'type': 'token', 'text': token})}\n\n"
                        await asyncio.sleep(0)
                elif isinstance(event, ToolCallEvent):
                    tool_call_names.append(event.name)
                    yield f"data: {json.dumps({'type': 'tool_call', 'name': event.name, 'args': event.args})}\n\n"
                    await asyncio.sleep(0)
                elif isinstance(event, ToolResultEvent):
                    yield f"data: {json.dumps({'type': 'tool_result', 'name': event.name, 'result': str(event.result)[:2000]})}\n\n"
                    await asyncio.sleep(0)
                elif isinstance(event, DoneEvent):
                    result = event.result

            elapsed = (time.perf_counter() - start) * 1000
            if result is None:
                result = await loop.run_in_executor(
                    None, lambda: _agent.run(prompt, thread_id=conv_id),
                )
                full_text = result.text or ""

            text = full_text or result.text or (
                result.output.answer if result.output else ""
            )

            # Evaluate guards for UI visibility
            guard_results = await _evaluate_guards_for_ui(
                text, tool_call_names,
            )
            if guard_results:
                yield f"data: {json.dumps({'type': 'guard_result', 'guards': guard_results})}\n\n"
                await asyncio.sleep(0)

            msg = _build_msg(result, elapsed)
            msg["text"] = text
            if full_thinking:
                msg["thinking"] = full_thinking

            if conv_id not in _conversations:
                _conversations[conv_id] = []
            _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
            _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
            _save_conversations()
            yield f"data: {json.dumps(msg)}\n\n"
        except Exception as exc:
            import traceback
            traceback.print_exc()
            yield f"data: {json.dumps({'type': 'error', 'error': str(exc)})}\n\n"

    return StreamingResponse(
        generate(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Non-streaming fallback
# ---------------------------------------------------------------------------
@app.post("/api/chat")
async def chat(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")
    if not prompt.strip():
        return JSONResponse({"error": "Empty prompt."}, status_code=400)
    try:
        loop = asyncio.get_event_loop()
        result, elapsed = await loop.run_in_executor(
            None, lambda: _run_agent(prompt, thread_id=conv_id),
        )
        msg = _build_msg(result, elapsed)

        # Evaluate guards for UI visibility
        response_text = msg.get("text", "")
        tool_names = [tc["name"] for tc in msg.get("tool_calls", [])]
        guard_results = await _evaluate_guards_for_ui(
            response_text, tool_names,
        )
        msg["guards"] = guard_results

        if conv_id not in _conversations:
            _conversations[conv_id] = []
        _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
        _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
        _save_conversations()
        return JSONResponse(msg)
    except Exception as exc:
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Agent management
# ---------------------------------------------------------------------------

@app.post("/api/reload")
async def reload_agent():
    try:
        _load_agent()
        return JSONResponse({"status": "reloaded"})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


def _parse_agentcore_yaml() -> dict[str, Any] | None:
    """Parse agentcore.yaml from the agent file directory, if present.

    The returned dict includes an ``evaluations_configured`` flag that is
    ``True`` when either the YAML contains an ``evaluations`` section or
    an ``eval_config.json`` file exists alongside the agent.
    """
    agent_dir = Path(AGENT_FILE).resolve().parent
    yaml_path = agent_dir / "agentcore.yaml"
    if not yaml_path.exists():
        return None
    try:
        import yaml  # type: ignore[import-untyped]

        with yaml_path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        # Detect evaluations: YAML section OR eval_config.json presence
        has_eval_section = bool(data.get("evaluations"))
        has_eval_config = _parse_eval_config() is not None
        evaluations_configured = has_eval_section or has_eval_config

        return {
            "detected": True,
            "agent_name": data.get("agent_name", ""),
            "aws_region": data.get("aws_region", ""),
            "model_id": data.get("model_id", ""),
            "evaluations_configured": evaluations_configured,
        }
    except ImportError:
        return None
    except Exception:
        return None


def _parse_eval_config() -> dict[str, Any] | None:
    """Parse eval_config.json from the agent file directory, if present.

    Returns
    -------
    dict[str, Any] | None
        Parsed JSON contents, or ``None`` when the file is missing or
        contains invalid JSON.
    """
    agent_dir = Path(AGENT_FILE).resolve().parent
    config_path = agent_dir / "eval_config.json"
    if not config_path.exists():
        return None
    try:
        with config_path.open(encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return None


@app.get("/api/config")
async def get_config():
    """Return the agent's current runtime configuration."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    # Build tools list with enabled status
    tools_list: list[dict[str, Any]] = []
    for name, fn in _all_tools.items():
        schema = getattr(fn, "_tool_schema", {})
        description = schema.get("description", "") or fn.__doc__ or ""
        tools_list.append({
            "name": name,
            "description": description,
            "enabled": name not in _disabled_tools,
        })

    # Build guards list
    guards_list: list[dict[str, str]] = []
    for guard in getattr(_agent, "guards", []):
        guard_name = getattr(guard, "name", "") or getattr(guard, "_name", "")
        guards_list.append({
            "name": guard_name,
            "type": type(guard).__name__,
        })

    response: dict[str, Any] = {
        "model": getattr(_agent, "model", ""),
        "instructions": getattr(_agent, "instructions", ""),
        "tools": tools_list,
        "guards": guards_list,
        "has_drift": _has_drift(),
    }

    # Include AgentCore deployment metadata if available
    agentcore = _parse_agentcore_yaml()
    if agentcore is not None:
        response["agentcore"] = agentcore
    else:
        response["agentcore"] = {"detected": False}

    return JSONResponse(response)


@app.patch("/api/config")
async def update_config(request: Request) -> JSONResponse:
    """Update the agent's runtime configuration (model, instructions, tools).

    Accepts optional ``model``, ``instructions``, and ``tools`` fields.
    Only provided fields are updated.
    """
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    body = await request.json()
    warnings_list: list[str] = []

    # --- Model update ---
    if "model" in body:
        new_model = body["model"]
        from synth.providers.router import ProviderRouter
        from synth.errors import SynthConfigError

        router = ProviderRouter()
        try:
            base_url = getattr(_agent, "base_url", None)
            new_provider = router.resolve(new_model, base_url=base_url)
            _agent.model = new_model
            _agent.provider = new_provider
        except SynthConfigError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=400,
            )

    # --- Instructions update ---
    if "instructions" in body:
        _agent.instructions = body["instructions"]

    # --- Tool toggles ---
    if "tools" in body:
        tool_toggles: dict[str, bool] = body["tools"]
        for tool_name, enabled in tool_toggles.items():
            if tool_name not in _all_tools:
                continue
            if enabled:
                _disabled_tools.discard(tool_name)
            else:
                _disabled_tools.add(tool_name)

        # Rebuild active tool set from _all_tools minus disabled
        active_tools = {
            k: v for k, v in _all_tools.items() if k not in _disabled_tools
        }
        _agent._registered_tools = active_tools

        # Rebuild tool executor with updated tool set
        from synth.tools.executor import ToolExecutor

        _agent.tool_executor = ToolExecutor(active_tools)

    return JSONResponse({
        "status": "updated",
        "warnings": warnings_list,
        "has_drift": _has_drift(),
    })


@app.post("/api/config/save")
async def save_config(request: Request) -> JSONResponse:
    """Persist the current runtime config to the agent file on disk.

    Reads the agent source, applies regex patches for model, instructions,
    and tools list, then writes atomically.  Fields whose source patterns
    don't match (e.g. env-var references) are skipped with a warning.
    """
    global _original_config

    if _agent is None:
        return JSONResponse(
            {"error": "No agent loaded."},
            status_code=503,
        )

    current_model: str = getattr(_agent, "model", "")
    current_instructions: str = getattr(_agent, "instructions", "")

    if not current_model:
        return JSONResponse(
            {"error": "Model string must not be empty."},
            status_code=400,
        )
    if not current_instructions:
        return JSONResponse(
            {"error": "Instructions must not be empty."},
            status_code=400,
        )

    from synth.cli.edit_cmd import (
        _atomic_write,
        _patch_instructions,
        _patch_model,
        _patch_tools_list,
    )

    agent_path = str(Path(AGENT_FILE).resolve())
    warnings_list: list[str] = []

    try:
        source = Path(agent_path).read_text(encoding="utf-8")
    except Exception as exc:
        return JSONResponse(
            {"error": f"Failed to read agent file: {exc}"},
            status_code=500,
        )

    # --- Patch model ---
    patched = _patch_model(source, current_model)
    if patched == source:
        warnings_list.append(
            "Could not patch 'model' — value is not a string literal."
        )
    source = patched

    # --- Patch instructions ---
    patched = _patch_instructions(source, current_instructions)
    if patched == source:
        warnings_list.append(
            "Could not patch 'instructions' — value is not a string literal."
        )
    source = patched

    # --- Patch tools list ---
    active_tools = getattr(_agent, "_registered_tools", {})
    tool_names = sorted(active_tools.keys())
    patched = _patch_tools_list(source, tool_names)
    if patched == source:
        warnings_list.append(
            "Could not patch 'tools' — tools list pattern not found."
        )
    source = patched

    # --- Write atomically ---
    try:
        _atomic_write(agent_path, source)
    except Exception as exc:
        return JSONResponse(
            {"error": f"Failed to write agent file: {exc}"},
            status_code=500,
        )

    # Update the original config snapshot so drift resets
    _original_config = {
        "model": current_model,
        "instructions": current_instructions,
        "tool_names": tool_names,
    }

    return JSONResponse({"status": "saved", "warnings": warnings_list})


def _build_models_by_provider() -> dict[str, list[str]]:
    """Build a mapping of provider display names to available model IDs.

    Combines ``_PROVIDERS`` from ``synth.cli.init_cmd`` (display names and
    default models) with ``_PROVIDER_SPECS`` from ``synth.providers.router``
    (prefix-based routing metadata).
    """
    from synth.cli.init_cmd import _PROVIDERS
    from synth.providers.router import _PROVIDER_SPECS  # noqa: F401

    # Build grouped result from _PROVIDERS, keyed by display name.
    # Each _PROVIDERS entry has a display name and a default model.
    providers: dict[str, list[str]] = {}

    for _key, pcfg in _PROVIDERS.items():
        display = pcfg.get("display", _key)
        model = pcfg.get("model", "")
        if not model:
            continue
        if display not in providers:
            providers[display] = []
        if model not in providers[display]:
            providers[display].append(model)

    return providers



@app.get("/api/models")
async def get_models() -> JSONResponse:
    """Return available models grouped by provider display name."""
    providers = _build_models_by_provider()
    return JSONResponse({"providers": providers})


@app.get("/api/tools")
async def list_tools():
    if _agent is None:
        return JSONResponse({"tools": []})
    tools = getattr(_agent, "_registered_tools", {})
    tool_list = []
    for name, fn in tools.items():
        schema = getattr(fn, "_tool_schema", {})
        tool_list.append({
            "name": name,
            "description": schema.get("description", ""),
            "parameters": schema.get("parameters", {}),
        })
    return JSONResponse({"tools": tool_list})


@app.post("/api/tools/test")
async def test_tool(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    tool_name = body.get("name", "")
    tool_args = body.get("args", {})
    tools = getattr(_agent, "_registered_tools", {})
    if tool_name not in tools:
        return JSONResponse({"error": f"Tool '{tool_name}' not found."}, status_code=404)
    start = time.perf_counter()
    try:
        fn = tools[tool_name]
        if asyncio.iscoroutinefunction(fn):
            result = await fn(**tool_args)
        else:
            result = fn(**tool_args)
        elapsed = (time.perf_counter() - start) * 1000
        return JSONResponse({"result": str(result), "latency_ms": round(elapsed, 1)})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Conversations
# ---------------------------------------------------------------------------

@app.get("/api/conversations")
async def list_conversations():
    return JSONResponse({"conversations": list(_conversations.keys()), "current": _current_conv})


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str):
    return JSONResponse({"messages": _conversations.get(conv_id, [])})


@app.post("/api/conversations")
async def create_conversation(request: Request):
    global _current_conv
    body = await request.json()
    conv_id = body.get("id", f"chat-{len(_conversations) + 1}")
    _conversations[conv_id] = []
    _current_conv = conv_id
    _save_conversations()
    return JSONResponse({"id": conv_id})


@app.delete("/api/conversations/{conv_id}")
async def delete_conversation(conv_id: str):
    global _current_conv
    if conv_id in _conversations and conv_id != "default":
        del _conversations[conv_id]
        if _current_conv == conv_id:
            _current_conv = "default"
        _save_conversations()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# Prompt management
# ---------------------------------------------------------------------------

@app.get("/api/prompts")
async def list_prompts():
    return JSONResponse({"prompts": {n: v for n, v in _prompts.items()}})


@app.post("/api/prompts")
async def save_prompt(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    text = body.get("text", "").strip()
    notes = body.get("notes", "")
    if not name or not text:
        return JSONResponse({"error": "name and text required"}, status_code=400)
    if name not in _prompts:
        _prompts[name] = []
    version = len(_prompts[name]) + 1
    _prompts[name].append({"version": version, "text": text, "notes": notes, "created_at": time.time()})
    _save_prompts()
    return JSONResponse({"name": name, "version": version})


@app.delete("/api/prompts/{name}")
async def delete_prompt(name: str):
    if name in _prompts:
        del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


@app.delete("/api/prompts/{name}/{version}")
async def delete_prompt_version(name: str, version: int):
    if name in _prompts:
        _prompts[name] = [v for v in _prompts[name] if v["version"] != version]
        if not _prompts[name]:
            del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# A/B testing
# ---------------------------------------------------------------------------

@app.post("/api/ab-test")
async def ab_test(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    input_text = body.get("input", "").strip()
    prompt_a = body.get("prompt_a", "").strip()
    prompt_b = body.get("prompt_b", "").strip()
    if not input_text:
        return JSONResponse({"error": "input required"}, status_code=400)
    loop = asyncio.get_event_loop()

    async def run_variant(system_prompt, label):
        try:
            full_prompt = f"{system_prompt}\n\n{input_text}" if system_prompt else input_text
            result, elapsed = await loop.run_in_executor(None, lambda: _run_agent(full_prompt))
            return {
                "label": label, "prompt": system_prompt,
                "text": result.text or (result.output.answer if result.output else ""),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost, "latency_ms": round(elapsed, 1),
            }
        except Exception as exc:
            return {"label": label, "prompt": system_prompt, "error": str(exc)}

    results = await asyncio.gather(run_variant(prompt_a, "A"), run_variant(prompt_b, "B"))
    return JSONResponse({"results": list(results), "input": input_text})


# ---------------------------------------------------------------------------
# Evals
# ---------------------------------------------------------------------------

@app.get("/api/evals")
async def list_evals():
    return JSONResponse({"evals": _evals})


@app.post("/api/evals")
async def create_eval(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    input_text = body.get("input", "").strip()
    expected = body.get("expected", "").strip()
    if not name or not input_text:
        return JSONResponse({"error": "name and input required"}, status_code=400)
    eval_case = {"id": str(uuid.uuid4())[:8], "name": name, "input": input_text, "expected": expected, "golden": None, "created_at": time.time()}
    _evals.append(eval_case)
    _save_evals()
    return JSONResponse(eval_case)


@app.delete("/api/evals/{eval_id}")
async def delete_eval(eval_id: str):
    global _evals
    _evals = [e for e in _evals if e["id"] != eval_id]
    _save_evals()
    return JSONResponse({"status": "deleted"})


@app.post("/api/evals/run")
async def run_evals(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    ids = body.get("ids", None)
    use_llm_judge = body.get("llm_judge", False)
    cases = _evals if ids is None else [e for e in _evals if e["id"] in ids]
    if not cases:
        return JSONResponse({"results": []})
    loop = asyncio.get_event_loop()
    results = []
    for case in cases:
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=case: _run_agent(c["input"]))
            actual = result.text or (result.output.answer if result.output else "")
            expected = case.get("expected", "")
            golden = case.get("golden")
            score = _simple_score(actual, expected) if expected else None
            regression = _simple_score(actual, golden) if golden else None
            llm_score, llm_reason = None, None
            if use_llm_judge and expected:
                llm_score, llm_reason = await loop.run_in_executor(None, lambda a=actual, e=expected: _llm_judge(a, e))
            results.append({
                "id": case["id"], "name": case["name"], "input": case["input"],
                "expected": expected, "actual": actual, "score": score,
                "llm_score": llm_score, "llm_reason": llm_reason,
                "regression_score": regression, "golden": golden,
                "latency_ms": round(elapsed, 1),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost, "pass": score is not None and score >= 0.5,
            })
        except Exception as exc:
            results.append({"id": case["id"], "name": case["name"], "error": str(exc), "pass": False})
    return JSONResponse({"results": results})


@app.post("/api/evals/{eval_id}/set-golden")
async def set_golden(eval_id: str, request: Request):
    body = await request.json()
    text = body.get("text", "")
    for e in _evals:
        if e["id"] == eval_id:
            e["golden"] = text
            _save_evals()
            return JSONResponse({"status": "saved"})
    return JSONResponse({"error": "not found"}, status_code=404)


def _simple_score(actual, expected):
    if not expected:
        return 1.0
    a_words = set(actual.lower().split())
    e_words = set(expected.lower().split())
    if not e_words:
        return 1.0
    return round(len(a_words & e_words) / len(e_words), 3)


def _llm_judge(actual, expected):
    import re
    judge_prompt = (
        f"You are an evaluator. Score the following response against the expected output.\n\n"
        f"Expected: {expected}\n\nActual: {actual}\n\n"
        f'Reply with JSON only: {{"score": <0.0-1.0>, "reason": "<one sentence>"}}'
    )
    try:
        result = _agent.run(judge_prompt)
        text = result.text or ""
        m = re.search(r'\{.*\}', text, re.DOTALL)
        if m:
            data = json.loads(m.group())
            return float(data.get("score", 0)), str(data.get("reason", ""))
    except Exception:
        pass
    return 0.0, "Judge failed"


# ---------------------------------------------------------------------------
# Scenarios (multi-turn)
# ---------------------------------------------------------------------------

@app.get("/api/scenarios")
async def list_scenarios():
    return JSONResponse({"scenarios": _scenarios})


@app.post("/api/scenarios")
async def create_scenario(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    turns = body.get("turns", [])
    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)
    scenario = {"id": str(uuid.uuid4())[:8], "name": name, "turns": turns, "created_at": time.time()}
    _scenarios.append(scenario)
    _save_scenarios()
    return JSONResponse(scenario)


@app.put("/api/scenarios/{scenario_id}")
async def update_scenario(scenario_id: str, request: Request):
    body = await request.json()
    for s in _scenarios:
        if s["id"] == scenario_id:
            s["name"] = body.get("name", s["name"])
            s["turns"] = body.get("turns", s["turns"])
            _save_scenarios()
            return JSONResponse(s)
    return JSONResponse({"error": "not found"}, status_code=404)


@app.delete("/api/scenarios/{scenario_id}")
async def delete_scenario(scenario_id: str):
    global _scenarios
    _scenarios = [s for s in _scenarios if s["id"] != scenario_id]
    _save_scenarios()
    return JSONResponse({"status": "deleted"})


@app.post("/api/scenarios/{scenario_id}/run")
async def run_scenario(scenario_id: str):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    scenario = next((s for s in _scenarios if s["id"] == scenario_id), None)
    if not scenario:
        return JSONResponse({"error": "not found"}, status_code=404)
    loop = asyncio.get_event_loop()
    results = []
    for turn in scenario["turns"]:
        if turn.get("role") != "user":
            continue
        content = turn["content"]
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=content: _run_agent(c))
            results.append({
                "input": content,
                "output": result.text or (result.output.answer if result.output else ""),
                "latency_ms": round(elapsed, 1),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost,
            })
        except Exception as exc:
            results.append({"input": content, "error": str(exc)})
    return JSONResponse({"scenario": scenario["name"], "results": results})


# ---------------------------------------------------------------------------
# Error message sanitization
# ---------------------------------------------------------------------------

_AWS_KEY_PATTERN = re.compile(
    r'(A[SK]IA[A-Z0-9]{16}|[A-Za-z0-9/+=]{40})',
)
_FILE_PATH_PATTERN = re.compile(
    r'(/[a-zA-Z0-9._-]+){3,}\.py',
)
_TRACEBACK_PATTERN = re.compile(
    r'Traceback \(most recent call last\):.*?(?=\n\S|\Z)',
    re.DOTALL,
)


def _sanitize_error_message(message: str) -> str:
    """Remove sensitive details from error messages.

    Strips AWS key patterns, internal file paths, and stack traces
    while preserving the error type and human-readable description.

    Transformations are applied in order:

    1. Strip Python tracebacks.
    2. Replace AWS access key IDs (``AKIA``/``ASIA`` + 16 chars) with
       ``[REDACTED_KEY]``.
    3. Replace 40-char base64-like strings (potential secret keys) with
       ``[REDACTED_SECRET]``.
    4. Replace absolute file paths (``/path/to/file.py``) with
       ``[internal path]``.
    5. Trim to first 500 characters.

    Parameters
    ----------
    message:
        Raw error message that may contain sensitive information.

    Returns
    -------
    str
        Sanitized error message safe for user display.
    """
    # 1. Strip Python tracebacks
    result = _TRACEBACK_PATTERN.sub('', message)

    # 2. Replace AWS access key IDs (AKIA.../ASIA... + 16 chars)
    result = re.sub(r'A[SK]IA[A-Z0-9]{16}', '[REDACTED_KEY]', result)

    # 3. Replace 40-char base64-like strings (potential secret keys)
    result = re.sub(r'[A-Za-z0-9/+=]{40}', '[REDACTED_SECRET]', result)

    # 4. Replace absolute file paths
    result = _FILE_PATH_PATTERN.sub('[internal path]', result)

    # 5. Trim to 500 characters
    return result[:500]


# ---------------------------------------------------------------------------
# Status-to-actions mapping
# ---------------------------------------------------------------------------

_STATUS_ACTIONS: dict[str, list[str]] = {
    "active": ["connect", "destroy"],
    "failed": ["redeploy", "destroy"],
    "creating": [],
    "updating": [],
    "deleting": [],
    "local": ["deploy"],
    "unknown": ["destroy"],
}


def _compute_actions(status: str) -> list[str]:
    """Return valid UI actions for an agent based on its lifecycle status.

    The mapping is deterministic: each status string maps to a fixed list
    of action identifiers that the UI should render as buttons.

    Parameters
    ----------
    status:
        Lowercase agent status string (e.g. ``"active"``, ``"failed"``).

    Returns
    -------
    list[str]
        Action identifiers the UI should render as buttons.  Returns an
        empty list for unrecognised statuses.
    """
    return _STATUS_ACTIONS.get(status, [])


# ---------------------------------------------------------------------------
# Session management
# ---------------------------------------------------------------------------


@dataclass
class SessionEntry:
    """Tracks an AgentCore session for a conversation.

    Each entry maps a conversation to its AgentCore session identifier
    and records when the session was last used, enabling idle-timeout
    detection (15-minute window).
    """

    session_id: str
    last_used: float  # time.time() epoch


_session_store: dict[str, SessionEntry] = {}


class RemoteAgentInvoker:
    """Invokes a remote AgentCore agent via the data plane API.

    Manages session lifecycle per conversation and translates boto3
    responses into a simple ``{"text": ..., "session_id": ...}`` dict
    consumed by the SSE chat stream.

    Parameters
    ----------
    agent_name:
        The AgentCore runtime name (``agentRuntimeId``).
    region:
        AWS region of the deployed agent.
    aws_profile:
        Optional AWS profile for credential resolution.
    """

    _SESSION_IDLE_TIMEOUT = 900  # 15 minutes in seconds

    def __init__(
        self,
        agent_name: str,
        region: str,
        aws_profile: str | None = None,
    ) -> None:
        self._agent_name = agent_name
        self._region = region
        self._aws_profile = aws_profile
        self._client: Any = None

    def _create_client(self) -> Any:
        """Create a boto3 client for ``bedrock-agentcore``.

        The client is lazily created on first use.  boto3 is imported
        inside this method so it remains an optional dependency.

        Returns
        -------
        Any
            A boto3 ``bedrock-agentcore`` service client.

        Raises
        ------
        SynthConfigError
            If boto3 is not installed.
        """
        try:
            import boto3  # noqa: PLC0415
        except ImportError as exc:
            raise SynthConfigError(
                "AgentCore invocation requires boto3. "
                "Install with: pip install synth-agent-sdk[agentcore]",
                component="RemoteAgentInvoker",
                suggestion=(
                    "pip install synth-agent-sdk[agentcore]"
                ),
            ) from exc

        session_kwargs: dict[str, str] = {}
        if self._aws_profile:
            session_kwargs["profile_name"] = self._aws_profile
        if self._region:
            session_kwargs["region_name"] = self._region

        session = boto3.Session(**session_kwargs)
        return session.client("bedrock-agentcore")

    def _get_or_create_session(self, conversation_id: str) -> str:
        """Resolve session ID, creating a new one if expired or missing.

        The store key is ``"{agent_name}:{conversation_id}"``.  If an
        existing entry's ``last_used`` timestamp exceeds the 15-minute
        idle timeout, a fresh UUID is generated.

        Parameters
        ----------
        conversation_id:
            Conversation identifier from the UI.

        Returns
        -------
        str
            The AgentCore session ID to use for this invocation.
        """
        key = f"{self._agent_name}:{conversation_id}"
        now = time.time()

        entry = _session_store.get(key)
        if entry is not None:
            elapsed = now - entry.last_used
            if elapsed <= self._SESSION_IDLE_TIMEOUT:
                entry.last_used = now
                return entry.session_id

        # Missing or expired — create a new session.
        new_id = str(uuid.uuid4())
        _session_store[key] = SessionEntry(
            session_id=new_id, last_used=now,
        )
        return new_id

    def invoke(self, prompt: str, conversation_id: str) -> dict[str, Any]:
        """Call ``InvokeAgentRuntime`` synchronously.

        Parameters
        ----------
        prompt:
            The user's chat message.
        conversation_id:
            Conversation identifier used for session resolution.

        Returns
        -------
        dict[str, Any]
            ``{"text": str, "session_id": str}``

        Raises
        ------
        SynthConfigError
            On credential errors, missing agent, timeout, or if boto3
            is not installed.
        """
        if self._client is None:
            self._client = self._create_client()

        session_id = self._get_or_create_session(conversation_id)

        try:
            result = self._client.invoke_agent_runtime(
                agentRuntimeId=self._agent_name,
                sessionId=session_id,
                input={"text": prompt},
            )
            return {
                "text": result["output"]["text"],
                "session_id": session_id,
            }
        except Exception as exc:
            self._handle_invoke_error(exc)
            raise  # unreachable, but keeps type checkers happy

    def _handle_invoke_error(self, exc: Exception) -> None:
        """Translate boto3 exceptions into ``SynthConfigError``.

        Parameters
        ----------
        exc:
            The exception raised by the boto3 call.

        Raises
        ------
        SynthConfigError
            Always — with a user-friendly, sanitized message.
        """
        exc_name = type(exc).__name__
        exc_msg = str(exc)

        # Credential errors
        if _is_credential_error(exc_msg):
            raise SynthConfigError(
                "AWS credentials expired or invalid. "
                "Run `aws sso login` to refresh.",
                component="RemoteAgentInvoker",
                suggestion="aws sso login",
            ) from exc

        # Resource not found
        if "ResourceNotFoundException" in exc_name or (
            "ResourceNotFoundException" in exc_msg
        ):
            raise SynthConfigError(
                f"Agent '{self._agent_name}' not found in AgentCore. "
                "It may have been deleted.",
                component="RemoteAgentInvoker",
                suggestion=(
                    "Check the agent name and region, or redeploy "
                    "with: synth deploy --target agentcore"
                ),
            ) from exc

        # Read timeout
        if "ReadTimeoutError" in exc_name:
            raise SynthConfigError(
                "AgentCore invocation timed out. The agent may be "
                "starting up — try again in a moment.",
                component="RemoteAgentInvoker",
                suggestion="Wait a few seconds and retry.",
            ) from exc

        # Fallback — sanitize and re-raise
        sanitized = _sanitize_error_message(exc_msg)
        raise SynthConfigError(
            sanitized,
            component="RemoteAgentInvoker",
            suggestion="Check the error details and retry.",
        ) from exc


# ---------------------------------------------------------------------------
# Credential scrubbing helper
# ---------------------------------------------------------------------------


def _scrub_credentials(text: str) -> str:
    """Apply credential redaction to *text*, returning it unchanged if the
    ``CredentialResolver`` is unavailable.
    """
    try:
        from synth.deploy.agentcore.credentials import (
            CredentialResolver,
        )

        return CredentialResolver().redact_credentials(text)
    except ImportError:
        return text


def _scrub_dict(data: Any) -> Any:
    """Recursively scrub credential patterns from all string values in a
    JSON-serialisable structure.
    """
    if isinstance(data, str):
        return _scrub_credentials(data)
    if isinstance(data, dict):
        return {k: _scrub_dict(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_scrub_dict(item) for item in data]
    return data


# ---------------------------------------------------------------------------
# AgentCore Evaluations endpoints
# ---------------------------------------------------------------------------


@app.get("/api/agentcore/evaluations")
async def get_evaluations() -> JSONResponse:
    """Return evaluation scores from AgentCore Evaluations API.

    Returns a list of :class:`EvaluationResult` dicts.  When evaluations
    are not configured (no ``eval_config.json``), returns an empty list
    with an informational message.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse({
            "results": [],
            "message": "Evaluations not configured — "
                       "no eval_config.json found.",
        })

    try:
        # TODO: Replace stub with real AgentCore Evaluations API call
        # via AgentCore_Client once the client service is implemented.
        # For now, return placeholder data shaped from the config.
        from datetime import datetime, timezone

        results: list[dict[str, Any]] = []
        for evaluator in eval_cfg.get("evaluators", []):
            result = EvaluationResult(
                evaluator_name=evaluator.get("id", "unknown"),
                score=0.0,
                level=evaluator.get("level", "TRACE"),
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            results.append(asdict(result))

        scrubbed = _scrub_dict({"results": results})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


@app.post("/api/agentcore/evaluations/run")
async def run_on_demand_evaluation(request: Request) -> JSONResponse:
    """Trigger an on-demand evaluation against the most recent session.

    Accepts a JSON body with an optional ``evaluators`` list to select
    which evaluators to run.  When omitted, all configured evaluators
    are used.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse(
            {"error": "Evaluations not configured — "
                      "no eval_config.json found."},
            status_code=400,
        )

    try:
        body = await request.json()
    except Exception:
        body = {}

    requested = body.get("evaluators")

    try:
        # TODO: Replace stub with real AgentCore Evaluations API call
        # via AgentCore_Client.  Should invoke RunEvaluation against
        # the most recent agent session.
        from datetime import datetime, timezone

        configured = eval_cfg.get("evaluators", [])
        if requested:
            configured = [
                e for e in configured
                if e.get("id") in requested
            ]

        results: list[dict[str, Any]] = []
        for evaluator in configured:
            result = EvaluationResult(
                evaluator_name=evaluator.get("id", "unknown"),
                score=0.0,
                level=evaluator.get("level", "TRACE"),
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            results.append(asdict(result))

        scrubbed = _scrub_dict({"results": results})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


@app.get("/api/agentcore/evaluations/config")
async def get_evaluation_config() -> JSONResponse:
    """Return the current online evaluation configuration status.

    Returns an :class:`EvaluationConfigStatus` dict when configured,
    or a ``null`` config with a message when ``eval_config.json`` is
    absent.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse({
            "config": None,
            "message": "Evaluations not configured — "
                       "no eval_config.json found.",
        })

    try:
        evaluator_ids = [
            e.get("id", "unknown")
            for e in eval_cfg.get("evaluators", [])
        ]
        status = EvaluationConfigStatus(
            config_name=eval_cfg.get("config_name", ""),
            active=True,
            sampling_rate=float(eval_cfg.get("sampling_rate", 1.0)),
            evaluators=evaluator_ids,
        )
        scrubbed = _scrub_dict({"config": asdict(status)})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# Info / health
# ---------------------------------------------------------------------------

@app.get("/api/info")
async def agent_info():
    """Return agent configuration summary including memory status."""
    tools = getattr(_agent, "_registered_tools", {}) if _agent else {}

    # Detect memory backend
    memory_info: dict[str, Any] = {"configured": False, "type": None}
    if _agent:
        mem = getattr(_agent, "memory", None)
        if mem is not None:
            memory_info["configured"] = True
            memory_info["type"] = type(mem).__name__

    # Multi-agent metadata
    multi_agent_info: dict[str, Any] | None = None
    if _MULTI_AGENT_TYPE and _agent:
        multi_agent_info = {"type": _MULTI_AGENT_TYPE}
        if _MULTI_AGENT_TYPE == "team":
            agents = getattr(_agent, "_agents", [])
            multi_agent_info["agents"] = [
                {
                    "name": getattr(a, "instructions", "")[:30].strip()
                    or getattr(a, "model", "unnamed"),
                    "model": getattr(a, "model", "unknown"),
                }
                for a in agents
            ]
            multi_agent_info["strategy"] = getattr(
                _agent, "_strategy", "auto",
            )
        elif _MULTI_AGENT_TYPE == "pipeline":
            stages = getattr(_agent, "_stages", [])
            multi_agent_info["stages"] = [
                {
                    "name": getattr(s, "instructions", "")[:30].strip()
                    or getattr(s, "model", f"stage_{i}"),
                    "model": getattr(s, "model", "unknown"),
                }
                for i, s in enumerate(stages)
            ]

    return JSONResponse({
        "model": getattr(_agent, "model", "unknown") if _agent else "not loaded",
        "tools": len(tools),
        "instructions": getattr(_agent, "instructions", "")[:200] if _agent else "",
        "status": _agent_status,
        "tool_errors": _agent_status.get("tool_errors", []),
        "memory": memory_info,
        "multi_agent": multi_agent_info,
    })


# ---------------------------------------------------------------------------
# Agent registry API helpers
# ---------------------------------------------------------------------------

def _find_agentcore_bin() -> str | None:
    """Locate the ``agentcore`` binary on PATH or next to the interpreter."""
    agentcore_bin = shutil.which("agentcore")
    if agentcore_bin:
        return agentcore_bin

    scripts_dir = os.path.dirname(sys.executable)
    suffix = ".exe" if sys.platform == "win32" else ""
    candidate = os.path.join(scripts_dir, f"agentcore{suffix}")
    if os.path.isfile(candidate):
        return candidate

    return None


def _build_subprocess_env(
    aws_profile: str | None,
) -> dict[str, str]:
    """Build an environment dict with ``AWS_PROFILE`` set if applicable."""
    env = os.environ.copy()
    if aws_profile:
        env["AWS_PROFILE"] = aws_profile
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONWARNINGS"] = "ignore"
    return env


_CREDENTIAL_KEYWORDS = ("expired", "token", "credentials")


def _is_credential_error(text: str) -> bool:
    """Return ``True`` if *text* looks like an AWS credential expiry error."""
    lower = text.lower()
    return any(kw in lower for kw in _CREDENTIAL_KEYWORDS)


def _get_default_region_and_profile() -> tuple[str, str | None]:
    """Extract region and AWS profile from the current agent's agentcore.yaml.

    Returns
    -------
    tuple[str, str | None]
        ``(region, aws_profile)`` — empty string for region if not found.
    """
    config = _parse_agentcore_yaml()
    if config:
        region = config.get("aws_region", "")
        # aws_profile is not in the parsed config; read it directly
        agent_dir = Path(AGENT_FILE).resolve().parent
        yaml_path = agent_dir / "agentcore.yaml"
        aws_profile: str | None = None
        if yaml_path.exists():
            try:
                text = yaml_path.read_text(encoding="utf-8")
                for line in text.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("aws_profile:"):
                        aws_profile = (
                            stripped.split(":", 1)[1]
                            .strip().strip("\"'")
                        )
                        break
            except Exception:
                pass
        return region, aws_profile
    return "", None


def _query_remote_agents(
    region: str,
    aws_profile: str | None,
) -> tuple[dict[str, dict[str, str]], str | None]:
    """Query all deployed agents via the AWS API.

    Uses boto3 ``list_agent_runtimes`` to discover every agent in the
    account, not just locally known ones.  Falls back to per-agent
    ``agentcore status`` CLI calls when boto3 is unavailable.

    Parameters
    ----------
    region:
        AWS region for the API call.
    aws_profile:
        Optional AWS profile name.

    Returns
    -------
    tuple[dict[str, dict[str, str]], str | None]
        ``(agents_map, error_message)`` where ``agents_map`` is
        ``{name: {status, agent_id}}`` and ``error_message`` is
        ``None`` on success or a user-facing string on failure.
    """
    from synth.cli.discover import _list_agent_runtimes_boto3

    # Try boto3 API first — discovers all agents in the account
    result = _list_agent_runtimes_boto3(region, aws_profile)
    if result is not None:
        return result, None

    # Fallback: per-agent CLI queries for locally known agents only
    return _query_remote_agents_cli(region, aws_profile)


def _query_remote_agents_cli(
    region: str,
    aws_profile: str | None,
) -> tuple[dict[str, dict[str, str]], str | None]:
    """Fallback: query per-agent status via ``agentcore status`` CLI.

    Discovers agent names from the local registry and
    ``.bedrock_agentcore/`` directory, then runs
    ``agentcore status --agent <name>`` for each.
    """
    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        return {}, (
            "AgentCore CLI not found and boto3 unavailable. "
            "Install with: pip install synth-agent-sdk[agentcore]"
        )

    env = _build_subprocess_env(aws_profile)

    # Discover agent names from registry and .bedrock_agentcore/
    from synth.cli.registry import RegistryStore

    agent_names: set[str] = set()
    store = RegistryStore()
    for rec in store.list_agents():
        agent_names.add(rec.agent_name)

    agent_dir = Path(AGENT_FILE).resolve().parent
    agentcore_dir = agent_dir / ".bedrock_agentcore"
    if agentcore_dir.is_dir():
        for entry in agentcore_dir.iterdir():
            if entry.is_dir():
                agent_names.add(entry.name)

    if not agent_names:
        return {}, None

    result: dict[str, dict[str, str]] = {}
    last_error: str | None = None

    for name in sorted(agent_names):
        cmd = [agentcore_bin, "status", "--agent", name]
        if region:
            cmd.extend(["--region", region])

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30,
                env=env,
            )
            combined = f"{proc.stdout}\n{proc.stderr}"

            if proc.returncode != 0:
                if _is_credential_error(combined):
                    return {}, (
                        "AWS credentials expired or invalid. "
                        "Run `aws sso login` or refresh your "
                        "credentials."
                    )
                last_error = (
                    proc.stderr.strip()
                    or proc.stdout.strip()
                    or f"Unknown error querying agent '{name}'"
                )
                continue

            from synth.cli.discover import _parse_agentcore_status
            parsed = _parse_agentcore_status(proc.stdout)
            if parsed:
                result[name] = parsed

        except subprocess.TimeoutExpired:
            last_error = f"Timed out querying agent '{name}' (30s)"
        except FileNotFoundError:
            return {}, (
                "AgentCore CLI not found. "
                "Install it with: "
                "pip install bedrock-agentcore-starter-toolkit"
            )

    # Only surface error if we got zero results
    error = last_error if not result else None
    return result, error


def _run_agentcore_cmd(
    action: str,
    agent_name: str,
    region: str,
    aws_profile: str | None,
) -> dict[str, Any]:
    """Run an ``agentcore`` subcommand synchronously.

    Parameters
    ----------
    action:
        The agentcore subcommand — ``"launch"`` or ``"stop"``.
    agent_name:
        The agent name to pass to the agentcore CLI.
    region:
        AWS region for the ``--region`` flag.
    aws_profile:
        Optional AWS profile name to inject into the environment.

    Returns
    -------
    dict[str, Any]
        ``{"success": bool, "message": str}``
    """
    agentcore_bin = _find_agentcore_bin()
    if not agentcore_bin:
        return {
            "success": False,
            "message": (
                "AgentCore CLI not found. "
                "Install it with: pip install bedrock-agentcore-starter-toolkit"
            ),
        }

    env = _build_subprocess_env(aws_profile)
    cmd = [agentcore_bin, action, agent_name, "--region", region]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=env,
        )
        if result.returncode == 0:
            return {"success": True, "message": f"Agent {action} succeeded"}

        combined = f"{result.stdout}\n{result.stderr}"
        if _is_credential_error(combined):
            return {
                "success": False,
                "message": (
                    "AWS credentials expired or invalid. "
                    "Run `aws sso login` or refresh your credentials."
                ),
            }

        msg = (
            result.stderr.strip()
            or result.stdout.strip()
            or "Unknown error"
        )
        return {"success": False, "message": msg}

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "message": f"Timed out running agentcore {action}",
        }
    except FileNotFoundError:
        return {
            "success": False,
            "message": (
                "AgentCore CLI not found. "
                "Install it with: pip install bedrock-agentcore-starter-toolkit"
            ),
        }


# ---------------------------------------------------------------------------
# Agent registry API endpoints
# ---------------------------------------------------------------------------

@app.get("/api/agents")
async def list_agents() -> JSONResponse:
    """List agents using AWS AgentCore as the primary source of truth.

    Queries ``agentcore status --agent <name>`` for each known agent,
    then enriches each record with local metadata from the persistent
    registry and ``.bedrock_agentcore/`` directory.  Agents that exist
    only locally (not yet deployed) are appended with ``"local"`` status.
    Credential errors are surfaced as a top-level ``error`` field so the
    UI can display an actionable message.
    """
    from synth.cli.registry import RegistryRecord, RegistryStore

    store = RegistryStore()
    registry_agents = store.list_agents()
    registry_by_name: dict[str, RegistryRecord] = {
        rec.agent_name: rec for rec in registry_agents
    }

    # Resolve default region and profile from agentcore.yaml
    default_region, default_profile = _get_default_region_and_profile()

    # Use profile from first registry agent if yaml doesn't have one
    if not default_profile:
        for rec in registry_agents:
            if rec.aws_profile:
                default_profile = rec.aws_profile
                break

    # Use region from first registry agent if yaml doesn't have one
    if not default_region:
        for rec in registry_agents:
            if rec.region:
                default_region = rec.region
                break

    # Query AWS for live agents
    remote_agents, query_error = await asyncio.get_event_loop().run_in_executor(
        None,
        _query_remote_agents,
        default_region,
        default_profile,
    )

    # Build result: start with remote agents (source of truth)
    seen_names: set[str] = set()
    result: list[dict[str, Any]] = []

    for name, info in sorted(remote_agents.items()):
        seen_names.add(name)
        local = registry_by_name.get(name)
        agent_dict = {
            "agent_name": name,
            "region": local.region if local else default_region,
            "model_id": local.model_id if local else "",
            "source_file": local.source_file if local else "",
            "deployed_at": local.deployed_at if local else "",
            "aws_profile": (
                local.aws_profile if local else default_profile
            ),
            "status": info["status"].lower(),
            "agent_id": info.get("agent_id", ""),
            "source": "remote",
        }
        agent_dict["actions"] = _compute_actions(agent_dict["status"])
        result.append(agent_dict)

    # Append local-only agents (in registry but not in AWS response)
    for rec in registry_agents:
        if rec.agent_name not in seen_names:
            seen_names.add(rec.agent_name)
            agent_dict = {
                "agent_name": rec.agent_name,
                "region": rec.region,
                "model_id": rec.model_id,
                "source_file": rec.source_file,
                "deployed_at": rec.deployed_at,
                "aws_profile": rec.aws_profile,
                "status": "unknown",
                "agent_id": "",
                "source": "registry",
            }
            agent_dict["actions"] = _compute_actions(agent_dict["status"])
            result.append(agent_dict)

    # Append .bedrock_agentcore/ agents not seen anywhere else
    agent_dir = Path(AGENT_FILE).resolve().parent
    agentcore_dir = agent_dir / ".bedrock_agentcore"
    if agentcore_dir.is_dir():
        for entry in sorted(agentcore_dir.iterdir()):
            if entry.is_dir() and entry.name not in seen_names:
                seen_names.add(entry.name)
                agent_dict = {
                    "agent_name": entry.name,
                    "region": default_region,
                    "model_id": "",
                    "source_file": str(
                        entry.relative_to(agent_dir)
                    ),
                    "deployed_at": "",
                    "aws_profile": default_profile,
                    "status": "local",
                    "agent_id": "",
                    "source": "local",
                }
                agent_dict["actions"] = _compute_actions(agent_dict["status"])
                result.append(agent_dict)

    payload: dict[str, Any] = {"agents": result}
    if query_error:
        payload["error"] = query_error

    return JSONResponse(payload)


@app.post("/api/agents/disconnect")
async def disconnect_agent() -> JSONResponse:
    """Clear remote agent routing and return to local agent."""
    global _remote_agent
    _remote_agent = None
    return JSONResponse({"success": True, "message": "Disconnected from remote agent"})


@app.post("/api/agents/{name}/start")
async def start_agent(name: str) -> JSONResponse:
    """Start a deployed agent via AgentCore.

    Looks up the agent in the local registry first.  If not found,
    falls back to the default region and profile from agentcore.yaml
    so that remote-only agents can still be started from the UI.
    """
    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    if record is not None:
        region = record.region
        profile = record.aws_profile
    else:
        region, profile = _get_default_region_and_profile()

    if not region:
        return JSONResponse(
            {
                "success": False,
                "message": (
                    f"Cannot determine AWS region for agent '{name}'. "
                    "Set aws_region in agentcore.yaml or deploy the "
                    "agent with `synth deploy` first."
                ),
            },
            status_code=400,
        )

    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        _run_agentcore_cmd,
        "launch",
        name,
        region,
        profile,
    )
    status_code = 200 if result["success"] else 500
    return JSONResponse(result, status_code=status_code)


@app.post("/api/agents/{name}/stop")
async def stop_agent(name: str) -> JSONResponse:
    """Stop a deployed agent via AgentCore.

    Falls back to default region/profile when the agent is not in the
    local registry (i.e. it was discovered from AWS directly).
    """
    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    if record is not None:
        region = record.region
        profile = record.aws_profile
    else:
        region, profile = _get_default_region_and_profile()

    if not region:
        return JSONResponse(
            {
                "success": False,
                "message": (
                    f"Cannot determine AWS region for agent '{name}'. "
                    "Set aws_region in agentcore.yaml or deploy the "
                    "agent with `synth deploy` first."
                ),
            },
            status_code=400,
        )

    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        _run_agentcore_cmd,
        "stop",
        name,
        region,
        profile,
    )
    status_code = 200 if result["success"] else 500
    return JSONResponse(result, status_code=status_code)

@app.post("/api/agents/{name}/destroy")
async def destroy_agent(name: str) -> JSONResponse:
    """Destroy an AgentCore agent runtime and remove from registry."""
    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    default_region, default_profile = _get_default_region_and_profile()
    region = (record.region if record else None) or default_region
    profile = (record.aws_profile if record else None) or default_profile

    if not region:
        return JSONResponse(
            {
                "success": False,
                "message": (
                    f"Cannot determine AWS region for agent '{name}'. "
                    "Set aws_region in agentcore.yaml or deploy the "
                    "agent with `synth deploy` first."
                ),
            },
            status_code=400,
        )

    loop = asyncio.get_event_loop()
    try:
        result = await loop.run_in_executor(
            None, _run_agentcore_cmd, "destroy", name, region, profile,
        )
        if result.get("success"):
            store.remove_agent(name)
            return JSONResponse(
                {"success": True, "message": f"Agent '{name}' destroyed"}
            )

        error_msg = result.get("message", "Unknown error")
        if _is_credential_error(error_msg):
            return JSONResponse(
                {
                    "success": False,
                    "error": (
                        "AWS credentials expired or invalid. "
                        "Run `aws sso login` to refresh."
                    ),
                },
                status_code=401,
            )
        return JSONResponse(
            {"success": False, "error": _sanitize_error_message(error_msg)},
            status_code=500,
        )
    except Exception as exc:
        return JSONResponse(
            {"success": False, "error": _sanitize_error_message(str(exc))},
            status_code=500,
        )

@app.post("/api/agents/{name}/redeploy")
async def redeploy_agent(name: str) -> JSONResponse:
    """Redeploy a failed agent using stored configuration."""
    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    if not record:
        return JSONResponse(
            {"success": False, "error": f"Agent '{name}' not found in registry"},
            status_code=404,
        )

    source_file = record.source_file
    if not source_file or not Path(source_file).exists():
        return JSONResponse(
            {
                "success": False,
                "error": (
                    f"Source file '{source_file}' not found. Re-deploy manually "
                    "with: synth deploy --target agentcore <file>"
                ),
            },
            status_code=400,
        )

    loop = asyncio.get_event_loop()
    try:
        from synth.cli.deploy_cmd import run_deploy

        await loop.run_in_executor(
            None,
            lambda: run_deploy(target="agentcore", dry_run=False, file=source_file),
        )
        return JSONResponse(
            {"success": True, "message": f"Agent '{name}' redeployment started"}
        )
    except Exception as exc:
        return JSONResponse(
            {"success": False, "error": _sanitize_error_message(str(exc))},
            status_code=500,
        )


@app.post("/api/agents/{name}/deploy")
async def deploy_agent(name: str) -> JSONResponse:
    """Deploy a local-only agent to AgentCore."""
    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    if not record:
        return JSONResponse(
            {"success": False, "error": f"Agent '{name}' not found in registry"},
            status_code=404,
        )

    source_file = record.source_file
    if not source_file or not Path(source_file).exists():
        return JSONResponse(
            {
                "success": False,
                "error": (
                    f"Source file '{source_file}' not found. Re-deploy manually "
                    "with: synth deploy --target agentcore <file>"
                ),
            },
            status_code=400,
        )

    loop = asyncio.get_event_loop()
    try:
        from synth.cli.deploy_cmd import run_deploy

        await loop.run_in_executor(
            None,
            lambda: run_deploy(target="agentcore", dry_run=False, file=source_file),
        )
        return JSONResponse(
            {"success": True, "message": f"Agent '{name}' deployment started"}
        )
    except Exception as exc:
        return JSONResponse(
            {"success": False, "error": _sanitize_error_message(str(exc))},
            status_code=500,
        )


@app.post("/api/agents/{name}/connect")
async def connect_agent(name: str) -> JSONResponse:
    """Switch the active chat session to route through a deployed agent."""
    global _remote_agent

    from synth.cli.registry import RegistryStore

    store = RegistryStore()
    record = store.get_agent(name)

    if record is not None:
        region = record.region
        profile = record.aws_profile or ""
    else:
        region, profile_val = _get_default_region_and_profile()
        profile = profile_val or ""

    _remote_agent = {
        "name": name,
        "region": region,
        "aws_profile": profile,
    }

    return JSONResponse({
        "success": True,
        "message": f"Connected to {name}",
    })


@app.get("/api/health")
async def health():
    return JSONResponse({"ok": True, "agent_loaded": _agent is not None})


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8420)
