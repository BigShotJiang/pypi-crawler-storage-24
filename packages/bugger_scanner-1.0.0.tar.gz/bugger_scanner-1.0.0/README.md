# BUGGER

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

Terminal HTML vulnerability scanner. Find XSS risks, insecure forms, missing headers — get fixes and prevention guides. No fluff, just results.

## Quick start

```bash
pip install bugger
bugger
```

Or from source:

```bash
git clone https://github.com/vikingopsec/bugger.git
cd bugger
pip install -e .
bugger
```

CI mode (exit 1 if HIGH findings):

```bash
bugger --ci ./src
```

## What it does

- **Scans HTML, JS, CSS** — file, paste, URL, or directory. XSS risks (inline scripts, event handlers, innerHTML), forms over GET, HTTP scripts, eval, document.write, and more.
- **Fixes** — each finding comes with a concrete fix you can copy.
- **Prevention guides** — so you don't repeat the same mistake.
- **Headers, cookies, CSP, redirects** — paste and get a security report with Nginx/Apache snippets.
- **Reference** — snippets, templates, checklists, OWASP-style reminders.

## Features

| Feature | Description |
|---------|-------------|
| Grade | One command → letter (A–F). Quick "how bad is it?" |
| Risk score + quick wins | 0–100 score and top 3 fixes to tackle first |
| Directory scan | Scans .html, .htm, .js, .css. Respects .buggerignore |
| Export | txt, json, html, markdown, SARIF (for GitHub Code Scanning) |
| Baseline | Save a baseline, compare later — see what's new vs fixed |
| Config checker | nginx.conf, Apache, .htaccess — missing headers, TLS tips |
| CI mode | `bugger --ci path` — exit 1 if HIGH findings |

## Usage

At the `bugger>` prompt, type a number or command:

| Command | What it does |
|---------|--------------|
| `grade` | Quick scan → letter grade + top 3 fixes |
| `scan` | Full scan (file, paste, URL, directory) |
| `diff` | Compare two scans |
| `headers` | Paste headers → what's missing |
| `csp` | Validate or generate CSP |
| `cookies` | Check Set-Cookie (HttpOnly, Secure, SameSite) |
| `redirects` | Flag open redirects |
| `config` | Check nginx/Apache/.htaccess |
| `auth` | Password/login checklist |
| `https` | HTTPS/TLS checklist |
| `why` | Why each finding matters |
| `guides` | Prevention guides |
| `cheatsheet` | OWASP top 5 |
| `snippets` | Safe code snippets |
| `templates` | Header one-liners + minimal safe HTML |

`/search text` filters tools. `help` and `exit` do what you'd expect.

## .buggerignore

Skip files during directory scans. Same pattern style as .gitignore:

```
node_modules/
vendor/
*.min.js
dist/
```

## GitHub Action

```yaml
- uses: vikingopsec/bugger-action@v1
  with:
    path: ./src
```

Or run manually:

```yaml
- run: pip install bugger && bugger --ci ./src
```

## Pre-commit

Add to `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: local
    hooks:
      - id: bugger
        name: bugger
        entry: bugger --ci .
        language: system
        pass_filenames: false
```

## Adding your own tools

Drop a `.py` in `bugger/tools/` with a `TOOL` dict and `run()` function. Type `reload` to pick it up.

## License

MIT — use it, change it, ship it.
