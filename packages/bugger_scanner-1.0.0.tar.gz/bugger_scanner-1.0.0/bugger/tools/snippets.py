from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Safe Snippets",
    "category": "Scanner",
    "description": "Copy-paste safe HTML/JS snippets.",
    "command": "snippets",
}

SNIPPETS = [
    ("Meta charset (early in <head>)", "<meta charset=\"UTF-8\">"),
    ("Safe link with target=_blank", "<a href=\"https://example.com\" target=\"_blank\" rel=\"noopener noreferrer\">Open</a>"),
    ("Form with POST and action", "<form action=\"/submit\" method=\"post\">\n  <input type=\"hidden\" name=\"csrf_token\" value=\"{{ token }}\">\n  <!-- fields -->\n  <button type=\"submit\">Submit</button>\n</form>"),
    ("Script with SRI (integrity)", "<script src=\"https://cdn.example.com/lib.js\"\n  integrity=\"sha384-...\"\n  crossorigin=\"anonymous\"></script>"),
    ("Safe text output in JS (no innerHTML)", "element.textContent = userInput;  // escapes automatically"),
    ("Nginx: security headers", "add_header X-Frame-Options DENY;\nadd_header X-Content-Type-Options nosniff;\nadd_header Content-Security-Policy \"default-src 'self';\";"),
    ("Strict CSP for static site", "Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; frame-ancestors 'none';"),
    ("Session cookie (example)", "Set-Cookie: SID=...; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=3600"),
]


def run() -> None:
    print(style("Safe Snippets", Color.CYAN, Color.BOLD))
    print(style("Use these as a starting point. Replace placeholders (e.g. {{ token }}).", Color.DIM))
    print()
    for i, (title, code) in enumerate(SNIPPETS, 1):
        print(style(f"{i}. {title}", Color.YELLOW, Color.BOLD))
        print(style("─" * 40, Color.DIM))
        for line in code.split("\n"):
            print(style(f"   {line}", Color.WHITE))
        print()
    pause()

