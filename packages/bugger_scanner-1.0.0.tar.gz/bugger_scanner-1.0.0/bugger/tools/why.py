from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Why This Matters",
    "category": "Reference",
    "description": "Quick explanations for each vulnerability type.",
    "command": "why",
}

EXPLANATIONS = [
    ("Inline script (XSS)", "Attackers can inject script if they control any data that ends up in the page. Inline scripts with no nonce are hard to lock down, so CSP often has to allow 'unsafe-inline', which weakens protection. Moving to external scripts + nonces means only your intended code runs."),
    ("Event handlers (onclick, etc.)", "If the value of onclick or onerror comes from user input (or a database), an attacker can break out of the attribute and run their own JavaScript. The page then runs their code in your origin — they can steal cookies, change content, or act as the user."),
    ("Form GET with sensitive data", "GET parameters go in the URL. URLs appear in server logs, browser history, Referer headers, and shared links. Anyone with access to those can see the password or token. POST body is not logged or sent in Referer by default."),
    ("Script over HTTP", "On an HTTPS page, loading a script over HTTP is 'mixed content'. Browsers may block it or it can be tampered with on the network. An attacker on the same network could replace the script with malicious code."),
    ("innerHTML / document.write", "Putting unsanitized user input into innerHTML or document.write runs whatever HTML/JS is in that string. That's classic stored/reflected XSS: the attacker's script runs in your site's context and can do anything the user can do."),
    ("Missing charset", "Without a declared charset, the browser guesses encoding. Wrong guess can break escaping and allow encoding-based XSS. Declaring UTF-8 early removes guesswork and keeps encoding consistent."),
    ("target=_blank without noopener", "The new tab can use window.opener to access your page. A malicious site can redirect your page (e.g. to phishing) via opener.location. rel=noopener (and noreferrer) prevents the new page from having a reference to yours."),
    ("Form without action", "The form submits to the current URL. That can cause double submits, wrong endpoint, or confusion. Explicit action makes intent clear and avoids accidental submission to the wrong place."),
    ("javascript: in href", "javascript: URLs run code when the link is followed. They're often blocked by CSP, are bad for accessibility, and mix markup with behavior. Use a button or link + event listener instead."),
    ("HTTP resources (mixed content)", "On HTTPS, loading scripts/styles/images over HTTP can be blocked by the browser or modified in transit. Use HTTPS (or protocol-relative //) for all resources so the page stays fully secure."),
    ("Missing SRI (integrity=)", "If you load a script or stylesheet from a CDN, a compromised CDN or MITM could serve malicious content. integrity= lets the browser verify the file hash; if it changes, the browser won't run it."),
]


def run() -> None:
    print(style("Why This Matters", Color.CYAN, Color.BOLD))
    print(style("Short explanations for each finding the scanner reports.", Color.DIM))
    print()
    for title, explanation in EXPLANATIONS:
        print(style(title, Color.YELLOW, Color.BOLD))
        print(style(f"  {explanation}", Color.WHITE))
        print()
    pause()

