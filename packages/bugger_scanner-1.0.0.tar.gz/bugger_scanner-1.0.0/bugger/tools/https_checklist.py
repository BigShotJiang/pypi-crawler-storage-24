from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "HTTPS Checklist",
    "category": "Check",
    "description": "Checklist: HTTPS, HSTS, redirect HTTP→HTTPS.",
    "command": "https",
}

ITEMS = [
    ("Site served over HTTPS?", "Use a valid TLS cert (e.g. Let's Encrypt). All pages and assets over HTTPS.", "Don't serve login or sensitive pages over HTTP."),
    ("HTTP redirects to HTTPS?", "Redirect 301 or 302 from http:// to https:// for the same host/path.", "Don't leave HTTP as default; users might type or follow old links."),
    ("HSTS header set?", "Strict-Transport-Security: max-age=31536000; includeSubDomains (and preload if ready).", "First visit may still be HTTP; after that browser will use HTTPS only."),
    ("Mixed content?", "All scripts, styles, images, iframes use https:// or relative URLs.", "No http:// resources on HTTPS pages; browsers may block or warn."),
    ("Cookies Secure?", "Set Secure on all cookies so they're only sent over HTTPS.", "Otherwise cookies can be sent on HTTP and intercepted."),
]


def run() -> None:
    print(style("HTTPS Checklist", Color.CYAN, Color.BOLD))
    print(style("Quick yes/no. Then see do/don't.", Color.DIM))
    print()
    for title, do, dont in ITEMS:
        print(style(title, Color.YELLOW, Color.BOLD))
        ans = input(style("  [y/n/?]: ", Color.GREEN)).strip().lower()
        if ans == "?" or ans == "n":
            print(style(f"  Do:   {do}", Color.GREEN))
            print(style(f"  Don't: {dont}", Color.RED))
        print()
    print(style("Use 'headers' to paste and check your actual response headers.", Color.DIM))
    print()
    pause()

