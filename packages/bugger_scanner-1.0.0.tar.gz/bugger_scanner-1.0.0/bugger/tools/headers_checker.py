from __future__ import annotations

from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Headers Checker",
    "category": "Check",
    "description": "Paste response headers; get security report and fixes.",
    "command": "headers",
}

HEADERS = [
    ("content-security-policy", "Content-Security-Policy", "Restricts script/source; reduces XSS. Set default-src, script-src.", "MED"),
    ("x-frame-options", "X-Frame-Options", "Prevent clickjacking. Use DENY or SAMEORIGIN.", "MED"),
    ("x-content-type-options", "X-Content-Type-Options", "Use nosniff to prevent MIME sniffing.", "MED"),
    ("strict-transport-security", "Strict-Transport-Security", "Enforce HTTPS. e.g. max-age=31536000; includeSubDomains.", "MED"),
    ("referrer-policy", "Referrer-Policy", "Control Referer leakage. e.g. strict-origin-when-cross-origin.", "LOW"),
    ("permissions-policy", "Permissions-Policy", "Disable unneeded features (camera, geolocation, etc.).", "LOW"),
]


def run() -> None:
    print(style("Headers Checker", Color.CYAN, Color.BOLD))
    print(style("Paste HTTP response headers (one per line). End with a line containing only 'END'.", Color.DIM))
    print()
    lines = []
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    raw = "\n".join(lines)
    if not raw.strip():
        print(style("No headers entered.", Color.YELLOW))
        pause()
        return

    seen = {}
    for line in raw.splitlines():
        line = line.strip()
        if ":" in line:
            name = line.split(":", 1)[0].strip().lower()
            value = line.split(":", 1)[1].strip()
            seen[name] = value

    print()
    print(style("Security header report", Color.CYAN, Color.BOLD))
    print(style("─" * 50, Color.DIM))
    missing = []
    for key, label, recommendation, sev in HEADERS:
        if key in seen:
            print(style(f"  [OK] {label}", Color.GREEN))
            print(style(f"       {seen[key][:60]}{'...' if len(seen[key]) > 60 else ''}", Color.DIM))
        else:
            missing.append((label, recommendation, sev))
            color = Color.RED if sev == "MED" else Color.YELLOW
            print(style(f"  [MISSING] {label}", color, Color.BOLD))
            print(style(f"       {recommendation}", Color.DIM))
    print()
    if missing:
        print(style("Add the missing headers on your server.", Color.YELLOW))
        print()
        print(style("  Nginx (add inside server { }):", Color.CYAN, Color.BOLD))
        for key, label, recommendation, _ in HEADERS:
            if key not in seen:
                if key == "content-security-policy":
                    print(style('    add_header Content-Security-Policy "default-src \'self\'; script-src \'self\'";', Color.WHITE))
                elif key == "x-frame-options":
                    print(style("    add_header X-Frame-Options DENY;", Color.WHITE))
                elif key == "x-content-type-options":
                    print(style("    add_header X-Content-Type-Options nosniff;", Color.WHITE))
                elif key == "strict-transport-security":
                    print(style("    add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains\";", Color.WHITE))
                elif key == "referrer-policy":
                    print(style("    add_header Referrer-Policy strict-origin-when-cross-origin;", Color.WHITE))
                elif key == "permissions-policy":
                    print(style("    add_header Permissions-Policy \"camera=(), geolocation=(), microphone=()\";", Color.WHITE))
        print()
        print(style("  Apache (.htaccess or config):", Color.CYAN, Color.BOLD))
        for key, label, recommendation, _ in HEADERS:
            if key not in seen:
                if key == "x-frame-options":
                    print(style("    Header always set X-Frame-Options DENY", Color.WHITE))
                elif key == "x-content-type-options":
                    print(style("    Header always set X-Content-Type-Options nosniff", Color.WHITE))
                elif key == "strict-transport-security":
                    print(style("    Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains\"", Color.WHITE))
                elif key == "referrer-policy":
                    print(style("    Header always set Referrer-Policy strict-origin-when-cross-origin", Color.WHITE))
    else:
        print(style("All checked headers present. Keep maintaining them.", Color.GREEN))
    print()
    pause()
