from __future__ import annotations

from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from bugger.core.colors import Color, style
from bugger.core.utils import pause

from bugger.tools.html_scanner import _run_scan, CHECKS

TOOL = {
    "name": "Scan Diff",
    "category": "Scan",
    "description": "Scan two HTML sources; see fixed vs new findings.",
    "command": "diff",
}


def _get_html(source: str) -> tuple[str, str] | None:
    if source.startswith("http://") or source.startswith("https://"):
        try:
            req = Request(source, headers={"User-Agent": "BUGGER-Scanner/1.0"})
            with urlopen(req, timeout=10) as r:
                return r.read().decode("utf-8", errors="replace"), source
        except (URLError, HTTPError, OSError) as e:
            print(style(f"Could not fetch: {e}", Color.RED))
            return None
    p = Path(source)
    if p.is_file():
        try:
            return p.read_text(encoding="utf-8", errors="replace"), source
        except Exception as e:
            print(style(f"Could not read file: {e}", Color.RED))
            return None
    return None


def run() -> None:
    print(style("Scan Diff", Color.CYAN, Color.BOLD))
    print(style("Compare two scans (e.g. before vs after fix). File path or URL.", Color.DIM))
    print()
    a_src = input(style("First (file or URL)> ", Color.GREEN)).strip()
    if not a_src:
        print(style("Nothing entered.", Color.YELLOW))
        pause()
        return
    result_a = _get_html(a_src)
    if not result_a:
        pause()
        return
    html_a, path_a = result_a
    report_a = _run_scan(html_a, path_a, do_print=False)
    names_a = {e["name"] for e in report_a}

    b_src = input(style("Second (file or URL)> ", Color.GREEN)).strip()
    if not b_src:
        print(style("Nothing entered.", Color.YELLOW))
        pause()
        return
    result_b = _get_html(b_src)
    if not result_b:
        pause()
        return
    html_b, path_b = result_b
    report_b = _run_scan(html_b, path_b, do_print=False)
    names_b = {e["name"] for e in report_b}

    fixed = names_a - names_b
    new = names_b - names_a
    still = names_a & names_b

    print()
    print(style("Comparison", Color.CYAN, Color.BOLD))
    print(style("─" * 50, Color.DIM))
    if fixed:
        print(style(f"  Fixed ({len(fixed)}): no longer in second scan", Color.GREEN))
        for n in sorted(fixed):
            print(style(f"    · {n}", Color.WHITE))
    else:
        print(style("  Fixed: none", Color.DIM))
    if new:
        print(style(f"  New ({len(new)}): only in second scan", Color.RED, Color.BOLD))
        for n in sorted(new):
            print(style(f"    · {n}", Color.WHITE))
    else:
        print(style("  New: none", Color.DIM))
    if still:
        print(style(f"  Still present ({len(still)}): in both", Color.YELLOW))
        for n in sorted(still)[:5]:
            print(style(f"    · {n}", Color.WHITE))
        if len(still) > 5:
            print(style(f"    ... and {len(still) - 5} more", Color.DIM))
    print()
    pause()
