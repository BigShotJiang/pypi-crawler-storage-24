from __future__ import annotations

from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from bugger.core.colors import Color, style
from bugger.core.utils import pause

from bugger.tools.html_scanner import CHECKS, _run_scan

TOOL = {
    "name": "Quick Grade",
    "category": "Scan",
    "description": "Scan HTML and get a letter grade (A–F) + top 3 fixes.",
    "command": "grade",
}

SEV_POINTS = {"HIGH": 25, "MED": 10, "LOW": 3}
GRADE = [(90, "A"), (80, "B"), (70, "C"), (60, "D"), (0, "F")]


def _score(report: list) -> tuple[int, str]:
    points = 100
    for entry in report:
        p = SEV_POINTS.get(entry["severity"], 5) * len(entry["matches"])
        points = max(0, points - p)
    for threshold, letter in GRADE:
        if points >= threshold:
            return points, letter
    return points, "F"


def run() -> None:
    print(style("Quick Grade", Color.CYAN, Color.BOLD))
    print(style("File path or URL → letter grade + top 3 fixes.", Color.DIM))
    print()
    path_in = input(style("file or url> ", Color.GREEN)).strip()
    if not path_in:
        print(style("Nothing to scan.", Color.YELLOW))
        pause()
        return

    html: str
    path: str | None = None
    if path_in.startswith("http://") or path_in.startswith("https://"):
        try:
            req = Request(path_in, headers={"User-Agent": "BUGGER/1.0"})
            with urlopen(req, timeout=10) as r:
                html = r.read().decode("utf-8", errors="replace")
            path = path_in
        except (URLError, HTTPError, OSError) as e:
            print(style(f"Could not fetch: {e}", Color.RED))
            pause()
            return
    elif Path(path_in).is_file():
        try:
            html = Path(path_in).read_text(encoding="utf-8", errors="replace")
            path = path_in
        except Exception as e:
            print(style(f"Could not read: {e}", Color.RED))
            pause()
            return
    else:
        print(style("Enter a file path or URL.", Color.YELLOW))
        pause()
        return

    report = _run_scan(html, path, do_print=False, min_severity="all")
    points, letter = _score(report)

    print()
    print(style("─" * 40, Color.DIM))
    grade_color = Color.GREEN if letter in ("A", "B") else Color.YELLOW if letter in ("C", "D") else Color.RED
    print(style(f"  Grade: {letter}  (score: {points}/100)", grade_color, Color.BOLD))
    print(style("─" * 40, Color.DIM))
    if not report:
        print(style("  No issues found. Solid.", Color.GREEN))
    else:
        print(style("  Top fixes to tackle first:", Color.CYAN))
        for i, entry in enumerate(report[:3], 1):
            print(style(f"    {i}. [{entry['severity']}] {entry['name']}", Color.WHITE))
            print(style(f"       Fix: {entry['fix'][:70]}...", Color.DIM) if len(entry["fix"]) > 70 else style(f"       Fix: {entry['fix']}", Color.DIM))
    print()
    pause()
