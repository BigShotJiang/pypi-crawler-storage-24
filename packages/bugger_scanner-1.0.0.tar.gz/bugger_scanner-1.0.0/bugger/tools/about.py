from bugger.core.utils import pause

TOOL = {
    "name": "About Bugger",
    "category": "Core",
    "description": "What BUGGER does and how to use it.",
    "command": "about",
}


def run() -> None:
    print("BUGGER — HTML vulnerability scanner")
    print()
    print("Scan HTML files or pasted code for common vulnerabilities.")
    print("Get concrete fixes and guides so you can apply them and prevent")
    print("the same issues from happening again.")
    print()
    print("Features:")
    print("  · scan, diff  — HTML scanner (severity filter, URL, export); compare two scans")
    print("  · headers, csp, cookies — Paste headers/cookies; security report and suggestions")
    print("  · redirects   — Flag open redirects in URLs or params")
    print("  · auth, https — Password/auth and HTTPS checklists")
    print("  · why, guides, cheatsheet — Explanations, prevention guides, OWASP top 5")
    print("  · snippets, templates    — Safe code snippets; header and HTML templates")
    print()
    pause()
