from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Prevention Guides",
    "category": "Reference",
    "description": "How to avoid XSS, injection, and insecure patterns.",
    "command": "guides",
}

GUIDES = [
    ("XSS (Cross-Site Scripting)", [
        "· Never insert unsanitized user input into HTML (innerHTML, document.write, attributes).",
        "· Use textContent for plain text; use a sanitizer (e.g. DOMPurify) if you need HTML.",
        "· Prefer addEventListener in JS over onclick/onerror etc. in HTML.",
        "· Set Content-Security-Policy (CSP) to restrict script sources and use nonces for inline script.",
        "· Use HttpOnly (and Secure) cookies for session tokens so JS cannot read them.",
    ]),
    ("Forms & sensitive data", [
        "· Use method=\"POST\" for login, passwords, tokens, or any sensitive data.",
        "· Serve forms over HTTPS; use CSRF tokens for state-changing requests.",
        "· Set autocomplete=\"off\" on sensitive inputs only when appropriate (e.g. one-time codes).",
        "· Do not put secrets in URL query params or Referer will leak them.",
    ]),
    ("Scripts & resources", [
        "· Load all scripts over HTTPS. Prefer same-origin or use SRI (integrity=) for CDNs.",
        "· Avoid inline script when possible; if needed, use CSP nonce or hash.",
        "· Set <meta charset=\"UTF-8\"> early in <head> to avoid encoding issues.",
    ]),
    ("Keeping it from happening again", [
        "· Use the scanner (scan) on new or changed HTML before deploy.",
        "· Add security headers (CSP, X-Content-Type-Options, etc.) on the server.",
        "· Validate and sanitize all user input on the server; treat front-end as untrusted.",
        "· Prefer frameworks/libraries that escape by default and use safe APIs.",
    ]),
]


def run() -> None:
    print(style("Prevention Guides", Color.CYAN, Color.BOLD))
    print(style("Quick reference so vulnerabilities don’t come back.", Color.DIM))
    print()
    for title, bullets in GUIDES:
        print(style(title, Color.YELLOW, Color.BOLD))
        for b in bullets:
            print(style(b, Color.WHITE))
        print()
    pause()
