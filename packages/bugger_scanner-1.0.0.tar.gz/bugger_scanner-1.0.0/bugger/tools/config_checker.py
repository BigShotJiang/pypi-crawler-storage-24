"""Check nginx, Apache, and .htaccess configs for security issues."""
from __future__ import annotations

import re
from pathlib import Path

from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Config Checker",
    "category": "Check",
    "description": "Check nginx.conf, Apache config, .htaccess for security headers and directives.",
    "command": "config",
}

CHECKS = [
    (r"add_header\s+X-Frame-Options", "X-Frame-Options (nginx)", "OK", "DENY or SAMEORIGIN prevents clickjacking."),
    (r"add_header\s+X-Content-Type-Options", "X-Content-Type-Options (nginx)", "OK", "nosniff prevents MIME sniffing."),
    (r"add_header\s+Strict-Transport-Security", "HSTS (nginx)", "OK", "Enforce HTTPS."),
    (r"add_header\s+Content-Security-Policy", "CSP (nginx)", "OK", "Restrict script/source."),
    (r"Header\s+set\s+X-Frame-Options", "X-Frame-Options (Apache)", "OK", "Prevent clickjacking."),
    (r"Header\s+set\s+X-Content-Type-Options", "X-Content-Type-Options (Apache)", "OK", "nosniff."),
    (r"Header\s+set\s+Strict-Transport-Security", "HSTS (Apache)", "OK", "Enforce HTTPS."),
    (r"Header\s+set\s+Content-Security-Policy", "CSP (Apache)", "OK", "Restrict script/source."),
    (r"ssl_protocols\s+", "TLS protocols (nginx)", "OK", "Use TLSv1.2 TLSv1.3; avoid SSLv3."),
    (r"ssl_ciphers\s+", "TLS ciphers (nginx)", "OK", "Use strong cipher suite."),
]
MISSING = [
    ("X-Frame-Options", "Add add_header X-Frame-Options DENY; (nginx) or Header set X-Frame-Options DENY (Apache)."),
    ("X-Content-Type-Options", "Add add_header X-Content-Type-Options nosniff; or Header set X-Content-Type-Options nosniff."),
    ("Strict-Transport-Security", "Add HSTS with max-age=31536000; includeSubDomains."),
    ("Content-Security-Policy", "Add CSP with default-src 'self'; script-src 'self'."),
]


def run() -> None:
    print(style("Config Checker", Color.CYAN, Color.BOLD))
    print(style("Enter path to nginx.conf, Apache config, or .htaccess.", Color.DIM))
    path = input(style("config path> ", Color.GREEN)).strip()
    if not path:
        print(style("No path entered.", Color.YELLOW))
        pause()
        return
    p = Path(path)
    if not p.is_file():
        print(style(f"File not found: {path}", Color.RED))
        pause()
        return
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        print(style(f"Could not read file: {e}", Color.RED))
        pause()
        return
    is_nginx = "nginx" in path.lower() or "nginx" in content[:500].lower()
    is_apache = "apache" in path.lower() or ".htaccess" in path or "Header set" in content
    print()
    print(style(f"Scanning: {path}", Color.DIM))
    print(style("─" * 50, Color.DIM))
    found = []
    for pattern, label, _status, hint in CHECKS:
        if re.search(pattern, content, re.I):
            print(style(f"  [OK] {label}", Color.GREEN))
            found.append(label)
    for name, fix in MISSING:
        if not any(name in f for f in found):
            print(style(f"  [MISSING] {name}", Color.YELLOW))
            print(style(f"    {fix}", Color.DIM))
    print()
    if is_nginx:
        print(style("Nginx snippet (add inside server { }):", Color.CYAN))
        print(style('  add_header X-Frame-Options DENY;', Color.WHITE))
        print(style('  add_header X-Content-Type-Options nosniff;', Color.WHITE))
        print(style('  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";', Color.WHITE))
    elif is_apache:
        print(style("Apache / .htaccess snippet:", Color.CYAN))
        print(style('  Header set X-Frame-Options DENY', Color.WHITE))
        print(style('  Header set X-Content-Type-Options nosniff', Color.WHITE))
        print(style('  Header set Strict-Transport-Security "max-age=31536000; includeSubDomains"', Color.WHITE))
    pause()
