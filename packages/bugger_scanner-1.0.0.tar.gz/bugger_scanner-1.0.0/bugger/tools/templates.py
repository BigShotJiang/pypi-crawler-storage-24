from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Templates",
    "category": "Reference",
    "description": "Ready-to-use header one-liners and minimal safe HTML.",
    "command": "templates",
}

HEADERS = [
    ("Strict CSP (static site)", "Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self';"),
    ("Common security headers (Nginx)", "add_header X-Frame-Options DENY;\nadd_header X-Content-Type-Options nosniff;\nadd_header Referrer-Policy strict-origin-when-cross-origin;\nadd_header Strict-Transport-Security \"max-age=31536000; includeSubDomains\";"),
    ("CSP with nonce (for inline script)", "Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{RANDOM}'; style-src 'self' 'nonce-{RANDOM}'; (replace {RANDOM} per request)"),
]

SAFE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Optional: Content-Security-Policy via meta or server header -->
  <title>Page</title>
</head>
<body>
  <form action="/submit" method="post">
    <input type="hidden" name="csrf_token" value="REPLACE_WITH_TOKEN">
    <label>Name <input type="text" name="name" autocomplete="name"></label>
    <button type="submit">Submit</button>
  </form>
  <a href="https://example.com" rel="noopener noreferrer" target="_blank">Safe link</a>
</body>
</html>
"""


def run() -> None:
    print(style("Templates", Color.CYAN, Color.BOLD))
    print(style("1 = Headers  2 = Minimal safe HTML", Color.DIM))
    choice = input(style("Choice [1/2]: ", Color.GREEN)).strip() or "1"
    print()
    if choice == "2":
        print(style("Minimal safe HTML template", Color.YELLOW, Color.BOLD))
        print(style("─" * 50, Color.DIM))
        print(SAFE_HTML)
        print(style("Copy above. Replace csrf_token and paths.", Color.DIM))
    else:
        print(style("Security header one-liners", Color.YELLOW, Color.BOLD))
        print(style("─" * 50, Color.DIM))
        for title, value in HEADERS:
            print(style(title, Color.CYAN, Color.BOLD))
            for line in value.split("\n"):
                print(style(f"  {line}", Color.WHITE))
            print()
    pause()

