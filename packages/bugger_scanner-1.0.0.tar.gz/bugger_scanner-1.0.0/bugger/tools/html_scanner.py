from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from bugger.core.colors import Color, style
from bugger.core.utils import pause

BUGGERIGNORE = ".buggerignore"

TOOL = {
    "name": "HTML Scanner",
    "category": "Scan",
    "description": "Scan HTML for vulns; get fixes and how to prevent them.",
    "command": "scan",
}

SEV = {"HIGH": (Color.RED, Color.BOLD), "MED": (Color.YELLOW, Color.BOLD), "LOW": (Color.CYAN,)}


def _snippet(line: str, max_len: int = 80) -> str:
    s = line.strip()
    return (s[:max_len] + "...") if len(s) > max_len else s


def _find_inline_scripts(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"<script\s*[^>]*>(?![^<]*</script>)", line, re.I | re.S):
            if "nonce=" not in line.lower() and "type=\"module\"" not in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_event_handlers(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"on\w+\s*=", line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_forms_get(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'<form[^>]*method\s*=\s*["\']?get["\']?', line, re.I):
            if "password" in line.lower() or "token" in line.lower() or "secret" in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_script_http(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'<script[^>]*src\s*=\s*["\']http://', line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_inner_html(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"\.innerHTML\s*=", line) or re.search(r"document\.write\s*\(", line):
            out.append((_snippet(line), i))
    return out[:5]


def _find_no_charset(html: str, _path: str | None) -> list[tuple[str, int]]:
    head = html[: min(2000, len(html))]
    if re.search(r"<meta[^>]+charset", head, re.I) or re.search(r"<meta[^>]+content\s*=[^>]*charset", head, re.I):
        return []
    for i, line in enumerate(html.splitlines(), 1):
        if "<head" in line.lower() or "<meta" in line.lower():
            return [(_snippet(line), i)]
    return [("<head> or first <meta>", 1)]


def _find_target_blank_no_rel(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'target\s*=\s*["\']?_blank["\']?', line, re.I):
            if "noopener" not in line.lower() and "noreferrer" not in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_form_no_action(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"<form\s", line, re.I) and not re.search(r'action\s*=', line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_javascript_href(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'href\s*=\s*["\']?\s*javascript\s*:', line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_http_resources(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'(src|href)\s*=\s*["\']http://', line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_missing_sri(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'<(script|link)[^>]*(src|href)\s*=\s*["\']https?://', line, re.I):
            if "integrity" not in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_dangerous_js(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"\beval\s*\(", line) or re.search(r"new\s+Function\s*\(", line):
            out.append((_snippet(line), i))
        elif re.search(r"setTimeout\s*\(\s*['\"]", line) or re.search(r"setInterval\s*\(\s*['\"]", line):
            out.append((_snippet(line), i))
        elif re.search(r"\.html\s*\(\s*[^)]*\)", line) and "jquery" in html.lower():
            out.append((_snippet(line), i))
    return out[:5]


def _find_meta_refresh(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'<meta[^>]+http-equiv\s*=\s*["\']?refresh["\']?', line, re.I):
            if "url=" in line.lower() or "content=" in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_data_uri_script(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r'(src|href)\s*=\s*["\']?\s*data\s*:', line, re.I):
            if "script" in line.lower() or "javascript" in line.lower():
                out.append((_snippet(line), i))
    return out[:5]


def _find_iframe_no_sandbox(html: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(html.splitlines(), 1):
        if re.search(r"<iframe", line, re.I) and "sandbox" not in line.lower():
            out.append((_snippet(line), i))
    return out[:5]


def _find_js_eval(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r"\beval\s*\(", line) or re.search(r"new\s+Function\s*\(", line):
            out.append((_snippet(line), i))
    return out[:5]


def _find_js_settimeout_string(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r"setTimeout\s*\(\s*['\"]", line) or re.search(r"setInterval\s*\(\s*['\"]", line):
            out.append((_snippet(line), i))
    return out[:5]


def _find_js_inner_html(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r"\.innerHTML\s*=", line) or re.search(r"document\.write\s*\(", line):
            out.append((_snippet(line), i))
    return out[:5]


def _find_js_jquery_html(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r"\.html\s*\(\s*[^)]*\)", line):
            out.append((_snippet(line), i))
    return out[:5]


def _find_css_expression(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r"expression\s*\(", line, re.I) or re.search(r"-moz-binding", line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


def _find_css_http_url(content: str, _path: str | None) -> list[tuple[str, int]]:
    out = []
    for i, line in enumerate(content.splitlines(), 1):
        if re.search(r'url\s*\(\s*["\']?http://', line, re.I):
            out.append((_snippet(line), i))
    return out[:5]


CHECKS = [
    ("Inline script (XSS risk)", "HIGH", _find_inline_scripts,
     "Inline <script> without nonce/CSP can allow XSS.",
     "Use a nonce: <script nonce=\"{{ csp_nonce }}\">... or move to external file and enforce CSP.",
     "Prefer external scripts; use Content-Security-Policy with nonce or hash. Avoid inline scripts with user data."),
    ("Event handler attributes (XSS risk)", "MED", _find_event_handlers,
     "onclick/onerror/onload etc. can inject script if value is user-controlled.",
     "Use addEventListener in external JS instead of onclick=\"...\". Escape any user data before putting in DOM.",
     "Never put unsanitized user input in HTML attributes. Bind events in JS and validate/escape input."),
    ("Form with GET and sensitive field", "MED", _find_forms_get,
     "Sending passwords/tokens via GET leaks them in URL and logs.",
     "Use method=\"POST\" for any form with password, token, or secret. Use HTTPS.",
     "Never use GET for sensitive data. Always POST for login/auth; use HTTPS and consider CSRF tokens."),
    ("Script loaded over HTTP", "MED", _find_script_http,
     "Mixed content or HTTP script can be tampered with in transit.",
     "Use HTTPS: <script src=\"https://...\"> or relative // if page is HTTPS.",
     "Load all scripts over HTTPS. Prefer same-origin or trusted CDNs with SRI (integrity=)."),
    ("innerHTML / document.write", "HIGH", _find_inner_html,
     "Inserting unsanitized data into DOM can cause XSS.",
     "Use textContent for plain text, or a sanitizer (e.g. DOMPurify) before innerHTML. Avoid document.write.",
     "Never put raw user input into innerHTML. Use textContent or a safe sanitizer; prefer DOM APIs."),
    ("Missing charset in document", "LOW", _find_no_charset,
     "No charset can cause encoding issues and sometimes XSS via encoding tricks.",
     "Add in <head>: <meta charset=\"UTF-8\"> as early as possible.",
     "Always set <meta charset=\"UTF-8\"> in the first 1024 bytes of the document."),
    ("target=\"_blank\" without rel=\"noopener noreferrer\"", "MED", _find_target_blank_no_rel,
     "Opened tab can access window.opener and redirect or abuse the opener.",
     "Add rel=\"noopener noreferrer\" to the link: <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"...\">.",
     "Always use rel=\"noopener\" (and noreferrer if you don't need Referer) when using target=\"_blank\"."),
    ("Form without action", "LOW", _find_form_no_action,
     "Form may submit to current URL; can be confusing or lead to double-submit.",
     "Set action to the intended endpoint: <form action=\"/submit\" method=\"post\">.",
     "Always set form action explicitly. Use POST for state-changing requests and CSRF tokens."),
    ("javascript: in href", "HIGH", _find_javascript_href,
     "javascript: URLs can be abused and are often blocked by CSP.",
     "Use a button or link with role=\"button\" and addEventListener; avoid href=\"javascript:...\".",
     "Never use href=\"javascript:...\". Use buttons or link + event listener; keep logic in JS."),
    ("HTTP resources (mixed content risk)", "MED", _find_http_resources,
     "Loading scripts/styles over HTTP on an HTTPS page can be blocked or tampered with.",
     "Use HTTPS for all src/href URLs, or relative // so they follow the page scheme.",
     "Serve all assets over HTTPS. Use relative URLs or https:// for scripts, styles, and iframes."),
    ("External script/link without SRI", "MED", _find_missing_sri,
     "CDN or external resource could be tampered with; integrity= verifies the file.",
     "Add integrity=\"sha384-...\" and crossorigin=\"anonymous\". Generate hash: openssl dgst -sha384 -binary file.js | openssl base64 -A",
     "Use Subresource Integrity (integrity=) for any script or link loaded from another origin."),
    ("eval / setTimeout string / jQuery .html()", "HIGH", _find_dangerous_js,
     "eval, new Function, or setTimeout(string) can execute injected code. jQuery .html() with user data = XSS.",
     "Avoid eval and new Function. Use setTimeout(fn, ms) not setTimeout('code'). Sanitize before .html().",
     "Never pass user input to eval, Function, or setTimeout string. Use DOMPurify before .html()."),
    ("Meta refresh redirect", "MED", _find_meta_refresh,
     "Meta refresh with url= can be open redirect if URL is user-controlled.",
     "Use server-side redirects (302) or JavaScript with allowlisted URLs. Validate url= strictly.",
     "Avoid meta refresh for redirects. If needed, validate the URL against an allowlist."),
    ("data: URI for script", "HIGH", _find_data_uri_script,
     "data: URIs in script/link can bypass CSP and inject code.",
     "Remove data: URIs for scripts. Use external files with nonce or hash in CSP.",
     "Don't use data: for scripts. CSP can't effectively restrict them."),
    ("iframe without sandbox", "MED", _find_iframe_no_sandbox,
     "Unrestricted iframe can run scripts; sandbox limits what it can do.",
     "Add sandbox=\"\" or sandbox=\"allow-scripts\" (minimal). Add allow= for features you need.",
     "Use sandbox on iframes embedding untrusted content. Restrict allow= to minimum needed."),
]

JS_CSS_CHECKS = [
    ("eval / new Function", "HIGH", _find_js_eval,
     "eval and new Function execute arbitrary code; dangerous with user input.",
     "Avoid eval and new Function. Use JSON.parse for data; refactor to avoid dynamic code execution.",
     "Never pass user input to eval or new Function. Use safe parsing and structured data."),
    ("setTimeout/setInterval with string", "HIGH", _find_js_settimeout_string,
     "setTimeout('code') or setInterval('code') executes code from a string; can be exploited.",
     "Use setTimeout(fn, ms) not setTimeout('code'). Pass function references, not strings.",
     "Always pass function references to setTimeout/setInterval, never code strings."),
    ("innerHTML / document.write", "HIGH", _find_js_inner_html,
     "Inserting unsanitized data into DOM can cause XSS.",
     "Use textContent for plain text, or a sanitizer (e.g. DOMPurify) before innerHTML.",
     "Never put raw user input into innerHTML. Use textContent or DOMPurify."),
    ("jQuery .html() with dynamic content", "HIGH", _find_js_jquery_html,
     "jQuery .html() with user-controlled data can cause XSS.",
     "Use .text() for plain text, or sanitize with DOMPurify before .html().",
     "Sanitize user input before passing to .html(). Prefer .text() when possible."),
    ("CSS expression() / -moz-binding", "MED", _find_css_expression,
     "expression() and -moz-binding can execute JS; legacy IE/Firefox vectors.",
     "Remove expression() and -moz-binding. Use modern CSS or JS for behavior.",
     "Avoid CSS that executes JavaScript. These are deprecated and unsafe."),
    ("HTTP url() in CSS (mixed content)", "MED", _find_css_http_url,
     "Loading resources over HTTP can be tampered with; use HTTPS.",
     "Use url('https://...') or relative paths. Ensure all assets use HTTPS.",
     "Serve all assets over HTTPS. Avoid http:// in url() for production."),
]


def _run_scan(html: str, path: str | None, do_print: bool = True, min_severity: str = "all", checks: list | None = None) -> list[dict]:
    order = {"HIGH": 3, "MED": 2, "LOW": 1}
    min_level = order.get(min_severity.upper(), 0) if min_severity and min_severity.upper() != "ALL" else 0
    use_checks = checks if checks is not None else CHECKS
    report = []
    total = 0
    for name, severity, finder, message, fix_snippet, prevent_guide in use_checks:
        if min_level and order.get(severity, 0) < min_level:
            continue
        matches = finder(html, path)
        if not matches:
            continue
        total += len(matches)
        entry = {
            "name": name, "severity": severity, "message": message,
            "fix": fix_snippet, "prevent": prevent_guide,
            "matches": [(s, n) for s, n in matches],
        }
        report.append(entry)
        if do_print:
            colors = SEV.get(severity, (Color.WHITE,))
            print(style(f"\n[{severity}] {name}", *colors))
            print(style(f"  {message}", Color.DIM))
            for snippet, line_no in matches[:3]:
                print(style(f"  Line {line_no}: {snippet}", Color.WHITE))
            if len(matches) > 3:
                print(style(f"  ... and {len(matches) - 3} more", Color.DIM))
            print(style("  Fix:", Color.GREEN))
            print(style(f"    {fix_snippet}", Color.WHITE))
            print(style("  Prevent:", Color.CYAN))
            print(style(f"    {prevent_guide}", Color.WHITE))
    if do_print:
        if total == 0:
            print(style("\nNo issues found. Keep hardening (charset, CSP, validation).", Color.GREEN))
        else:
            print(style(f"\nTotal findings: {total}", Color.YELLOW, Color.BOLD))
    return report


def _risk_score(report: list[dict]) -> tuple[int, str]:
    high = sum(len(e["matches"]) for e in report if e["severity"] == "HIGH")
    med = sum(len(e["matches"]) for e in report if e["severity"] == "MED")
    low = sum(len(e["matches"]) for e in report if e["severity"] == "LOW")
    score = max(0, 100 - high * 15 - med * 5 - low * 2)
    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 40:
        grade = "D"
    else:
        grade = "F"
    return score, grade


def _quick_wins(report: list[dict], n: int = 3) -> list[dict]:
    order = {"HIGH": 3, "MED": 2, "LOW": 1}
    sorted_report = sorted(report, key=lambda e: (-order.get(e["severity"], 0), -len(e.get("matches", []))))
    return sorted_report[:n]


BASELINE_FILE = Path(".bugger_baseline.json")


def _load_ignore_patterns(root: Path) -> set[str]:
    for loc in [root, Path.cwd()]:
        ignore_file = loc / ".buggerignore"
        if ignore_file.is_file():
            try:
                return {line.strip() for line in ignore_file.read_text().splitlines() if line.strip() and not line.strip().startswith("#")}
            except Exception:
                pass
    return set()


def _should_ignore(file_path: Path, patterns: set[str], root: Path) -> bool:
    if not patterns:
        return False
    try:
        rel = file_path.resolve().relative_to(root.resolve())
    except ValueError:
        return False
    parts = rel.parts
    for p in patterns:
        if not p:
            continue
        if p.startswith("*"):
            if any(p[1:] in str(part) for part in parts):
                return True
        elif p in parts or p in str(rel):
            return True
    return False


def _save_baseline(report: list[dict], path: str | None) -> None:
    data = {}
    if BASELINE_FILE.exists():
        try:
            data = json.loads(BASELINE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    key = path or "(unknown)"
    findings = []
    for e in report:
        m = e.get("matches", [])
        findings.append({"name": e["name"], "severity": e["severity"], "file": e.get("file", ""), "matches": [[s, n] for s, n in m]})
    data[key] = {"path": path, "findings": findings}
    BASELINE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(style(f"Baseline saved for {key}", Color.GREEN))


def _compare_baseline(report: list[dict], path: str | None) -> None:
    if not BASELINE_FILE.exists():
        print(style("No baseline found. Save one first with Export > baseline.", Color.YELLOW))
        return
    try:
        data = json.loads(BASELINE_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        print(style(f"Could not read baseline: {e}", Color.RED))
        return
    key = path or "(unknown)"
    if key not in data:
        print(style(f"No baseline for {key}. Save one first.", Color.YELLOW))
        return
    base_findings = {(f["name"], f.get("file", "")) for f in data[key].get("findings", [])}
    current_findings = {(e["name"], e.get("file", "")) for e in report}
    new_only = current_findings - base_findings
    fixed = base_findings - current_findings
    if not new_only and not fixed:
        print(style("No change vs baseline.", Color.DIM))
        return
    if new_only:
        print(style(f"\nNew findings ({len(new_only)}):", Color.RED, Color.BOLD))
        for name, f in sorted(new_only):
            print(style(f"  + {name} — {f}", Color.RED))
    if fixed:
        print(style(f"\nFixed since baseline ({len(fixed)}):", Color.GREEN, Color.BOLD))
        for name, f in sorted(fixed):
            print(style(f"  - {name} — {f}", Color.GREEN))


def _do_export(report: list[dict], path: str | None, fmt: str) -> None:
    high_c = sum(len(e.get("matches", [])) for e in report if e["severity"] == "HIGH")
    med_c = sum(len(e.get("matches", [])) for e in report if e["severity"] == "MED")
    low_c = sum(len(e.get("matches", [])) for e in report if e["severity"] == "LOW")
    if fmt == "txt":
        out = Path("scan_report.txt")
        with out.open("w", encoding="utf-8") as f:
            f.write(f"BUGGER Scan Report: {path}\n")
            f.write("=" * 60 + "\n\n")
            for entry in report:
                f.write(f"[{entry['severity']}] {entry['name']}\n")
                f.write(f"  {entry['message']}\n")
                for s, n in entry.get("matches", []):
                    f.write(f"  Line {n}: {s}\n")
                f.write(f"  Fix: {entry['fix']}\n")
                f.write(f"  Prevent: {entry['prevent']}\n\n")
        print(style(f"Report saved to {out.resolve()}", Color.GREEN))
    elif fmt == "json":
        out = Path("scan_report.json")
        findings = []
        for e in report:
            m = e.get("matches", [])
            findings.append({"name": e["name"], "severity": e["severity"], "message": e["message"], "fix": e["fix"], "prevent": e["prevent"], "matches": [[s, n] for s, n in m]})
        data = {"path": path, "high_count": high_c, "med_count": med_c, "low_count": low_c, "findings": findings}
        with out.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(style(f"Report saved to {out.resolve()}", Color.GREEN))
    elif fmt == "html":
        out = Path("scan_report.html")
        rows = ""
        for e in report:
            sev = e["severity"]
            color = "#dc3545" if sev == "HIGH" else "#ffc107" if sev == "MED" else "#17a2b8"
            rows += f'<tr><td style="color:{color};font-weight:bold">{sev}</td><td>{e["name"]}</td><td>{e["message"]}</td><td>{e["fix"]}</td></tr>'
        html = f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><title>BUGGER Scan Report</title></head><body>
<h1>BUGGER Scan Report</h1><p><b>Path:</b> {path}</p><p>HIGH: {high_c} | MED: {med_c} | LOW: {low_c}</p>
<table border="1" cellpadding="8"><tr><th>Severity</th><th>Finding</th><th>Message</th><th>Fix</th></tr>{rows}</table>
</body></html>"""
        out.write_text(html, encoding="utf-8")
        print(style(f"Report saved to {out.resolve()}", Color.GREEN))
    elif fmt == "md":
        out = Path("scan_report.md")
        lines = [f"# BUGGER Scan Report\n", f"**Path:** {path}\n", f"**Summary:** HIGH: {high_c} | MED: {med_c} | LOW: {low_c}\n", ""]
        for e in report:
            lines.append(f"## [{e['severity']}] {e['name']}\n")
            lines.append(f"{e['message']}\n")
            for s, n in e.get("matches", []):
                lines.append(f"- Line {n}: `{s[:60]}{'...' if len(s) > 60 else ''}`\n")
            lines.append(f"**Fix:** {e['fix']}\n")
            lines.append("")
        out.write_text("".join(lines), encoding="utf-8")
        print(style(f"Report saved to {out.resolve()}", Color.GREEN))
    elif fmt == "sarif":
        out = Path("scan_report.sarif.json")
        results = []
        for e in report:
            uri = e.get("file") or path or "unknown"
            for s, n in e.get("matches", []):
                results.append({
                    "ruleId": e["name"].replace(" ", "_")[:50],
                    "level": "error" if e["severity"] == "HIGH" else "warning" if e["severity"] == "MED" else "note",
                    "message": {"text": e["message"]},
                    "locations": [{"physicalLocation": {"artifactLocation": {"uri": uri}, "region": {"startLine": n}}}],
                })
        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [{"tool": {"driver": {"name": "BUGGER", "version": "1.0.0"}}, "results": results}],
        }
        with out.open("w", encoding="utf-8") as f:
            json.dump(sarif, f, indent=2)
        print(style(f"Report saved to {out.resolve()}", Color.GREEN))


def run() -> None:
    print(style("HTML Scanner", Color.CYAN, Color.BOLD))
    min_sev = input(style("Minimum severity? (high/med/low/all) [all]: ", Color.GREEN)).strip().lower() or "all"
    print(style("File path, paste HTML (end with END), or URL (only your own sites).", Color.DIM))
    print()
    first_line = input(style("file / paste / url> ", Color.GREEN)).strip()
    if not first_line or first_line.upper() == "END":
        print(style("Nothing to scan.", Color.YELLOW))
        pause()
        return

    html: str
    path: str | None = None

    if first_line.startswith("http://") or first_line.startswith("https://"):
        print(style("Only scan sites you own or have permission to test.", Color.YELLOW))
        try:
            req = Request(first_line, headers={"User-Agent": "BUGGER-Scanner/1.0"})
            with urlopen(req, timeout=10) as r:
                html = r.read().decode("utf-8", errors="replace")
            path = first_line
        except (URLError, HTTPError, OSError) as e:
            print(style(f"Could not fetch URL: {e}", Color.RED))
            pause()
            return
    elif Path(first_line).is_dir():
        root = Path(first_line)
        html_files = list(root.rglob("*.html")) + list(root.rglob("*.htm"))
        js_files = list(root.rglob("*.js"))
        css_files = list(root.rglob("*.css"))
        raw = html_files + js_files + css_files
        ignore = _load_ignore_patterns(root)
        all_files = [f for f in raw if not _should_ignore(f, ignore, root)]
        if not all_files:
            print(style("No .html, .htm, .js, or .css files found (or all ignored).", Color.YELLOW))
            pause()
            return
        print(style(f"Found {len(all_files)} files. Scanning...", Color.CYAN))
        all_report = []
        for i, f in enumerate(all_files):
            if len(all_files) > 8 and (i + 1) % max(1, len(all_files) // 10) == 0:
                print(style(f"  {i + 1}/{len(all_files)}", Color.DIM), end="\r")
            try:
                h = f.read_text(encoding="utf-8", errors="replace")
                checks = JS_CSS_CHECKS if str(f).lower().endswith((".js", ".css")) else None
                r = _run_scan(h, str(f), do_print=False, min_severity=min_sev, checks=checks)
                for e in r:
                    e["file"] = str(f.absolute()) if hasattr(f, 'absolute') else str(f)
                    all_report.append(e)
            except Exception:
                pass
        seen = set()
        report = []
        for e in all_report:
            k = (e["name"], e.get("file", ""))
            if k not in seen:
                seen.add(k)
                report.append(e)
        path = first_line
        print(style(f"\nDirectory scan: {path}", Color.DIM))
        print(style(f"Files scanned: {len(all_files)} | Total finding types: {len(report)}", Color.DIM))
        high = sum(1 for e in report if e["severity"] == "HIGH")
        med = sum(1 for e in report if e["severity"] == "MED")
        low = sum(1 for e in report if e["severity"] == "LOW")
        if high or med or low:
            print(style(f"HIGH: {high}  MED: {med}  LOW: {low}", Color.YELLOW))
        for e in report[:10]:
            colors = SEV.get(e["severity"], (Color.WHITE,))
            fname = e.get("file", path)
            print(style(f"  [{e['severity']}] {e['name']} — {fname}", *colors))
        if len(report) > 10:
            print(style(f"  ... and {len(report) - 10} more", Color.DIM))
        score, grade = _risk_score(report)
        print(style(f"\n  Risk score: {score}/100  Grade: {grade}", Color.CYAN, Color.BOLD))
        wins = _quick_wins(report)
        if wins:
            print(style("\n  Quick wins (fix these first):", Color.GREEN))
            for w in wins:
                print(style(f"    · {w['name']}: {w['fix'][:60]}...", Color.WHITE) if len(w['fix']) > 60 else style(f"    · {w['name']}: {w['fix']}", Color.WHITE))
        dir_export = input(style("\nExport report? (txt/json/html/md/sarif/baseline/n) [n]: ", Color.GREEN)).strip().lower() or "n"
        if dir_export in ("txt", "json", "html", "md", "sarif"):
            _do_export(report, path, dir_export)
        elif dir_export == "baseline":
            _save_baseline(report, path)
        compare_ = input(style("Compare to baseline? [y/N]: ", Color.GREEN)).strip().lower()
        if compare_ == "y":
            _compare_baseline(report, path)
        pause()
        return
    elif Path(first_line).is_file():
        try:
            html = Path(first_line).read_text(encoding="utf-8", errors="replace")
            path = first_line
            use_checks = JS_CSS_CHECKS if path.lower().endswith((".js", ".css")) else None
        except Exception as e:
            print(style(f"Could not read file: {e}", Color.RED))
            pause()
            return
    else:
        lines = [first_line]
        while True:
            line = input()
            if line.strip().upper() == "END":
                break
            lines.append(line)
        html = "\n".join(lines)
        path = "(pasted)"
        use_checks = None

    print()
    print(style(f"Scanning: {path}", Color.DIM))
    if min_sev and min_sev != "all":
        print(style(f"Reporting: {min_sev} and above", Color.DIM))
    print(style("─" * 60, Color.DIM))
    report = _run_scan(html, path, do_print=True, min_severity=min_sev, checks=use_checks)
    print()

    if report:
        export_ = input(style("Export report? (txt/json/html/md/sarif/baseline/n) [n]: ", Color.GREEN)).strip().lower() or "n"
        if export_ in ("txt", "json", "html", "md", "sarif"):
            _do_export(report, path, export_)
        elif export_ == "baseline":
            _save_baseline(report, path)
    if path and path != "(pasted)":
        compare_ = input(style("Compare to baseline? [y/N]: ", Color.GREEN)).strip().lower()
        if compare_ == "y":
            _compare_baseline(report, path)
    pause()
