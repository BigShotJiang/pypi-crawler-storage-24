from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Auth Checklist",
    "category": "Checklist",
    "description": "Password and login security checklist with do/don't tips.",
    "command": "auth",
}

ITEMS = [
    ("Passwords hashed?", "Do: Use a strong hash (e.g. argon2, bcrypt). Never store plaintext.", "Don't: Store or log plaintext passwords. Don't use MD5/SHA1 alone."),
    ("HTTPS for login?", "Do: Serve login form and all auth over HTTPS only.", "Don't: Send credentials over HTTP. Redirect HTTP→HTTPS."),
    ("Session timeout?", "Do: Expire sessions after inactivity and on logout. Use short-lived tokens.", "Don't: Leave sessions valid forever. Invalidate on password change."),
    ("CSRF on forms?", "Do: Use CSRF tokens on login and all state-changing requests.", "Don't: Rely only on cookies for auth on POST; add token or SameSite."),
    ("Rate limiting?", "Do: Limit login attempts per IP/user to reduce brute force.", "Don't: Allow unlimited attempts. Consider lockout or captcha."),
    ("Error messages?", "Do: Use generic messages (e.g. 'Invalid credentials'). Log details server-side.", "Don't: Reveal 'user not found' vs 'wrong password' to attackers."),
]


def run() -> None:
    print(style("Auth Checklist", Color.CYAN, Color.BOLD))
    print(style("Quick yes/no for each. Then see do/don't.", Color.DIM))
    print()
    for title, do, dont in ITEMS:
        print(style(title, Color.YELLOW, Color.BOLD))
        ans = input(style("  [y/n/? for tip]: ", Color.GREEN)).strip().lower()
        if ans == "?" or ans == "tip":
            print(style(f"  Do:   {do}", Color.GREEN))
            print(style(f"  Don't: {dont}", Color.RED))
        elif ans == "n":
            print(style(f"  → Fix: {do}", Color.CYAN))
        print()
    print(style("Harden each item before going to production.", Color.DIM))
    print()
    pause()

