from __future__ import annotations

import re
from urllib.parse import urlparse, parse_qs

from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Redirect Checker",
    "category": "Check",
    "description": "Paste redirect URLs or params; flag open redirects.",
    "command": "redirects",
}

REDIRECT_PARAMS = ["next", "redirect", "return", "returnUrl", "url", "dest", "destination", "redir", "redirect_uri", "continue", "goto"]


def _is_absolute_or_off_site(value: str, allow_origin: str | None) -> bool:
    value = value.strip()
    if not value:
        return False
    if re.match(r"https?://", value, re.I):
        return True
    if value.startswith("//"):
        return True
    if value.startswith("/") and "\\" in value:
        return True
    return False


def run() -> None:
    print(style("Redirect Checker", Color.CYAN, Color.BOLD))
    print(style("Paste URLs or query strings (one per line). End with END.", Color.DIM))
    print()
    lines = []
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    if not lines:
        print(style("Nothing entered.", Color.YELLOW))
        pause()
        return

    print()
    print(style("Open redirect check", Color.CYAN, Color.BOLD))
    print(style("─" * 50, Color.DIM))
    for raw in lines:
        raw = raw.strip()
        if not raw:
            continue
        if "?" in raw:
            try:
                parsed = urlparse(raw)
                qs = parse_qs(parsed.query)
                for param in REDIRECT_PARAMS:
                    if param in qs:
                        val = qs[param][0] if qs[param] else ""
                        if _is_absolute_or_off_site(val, None):
                            print(style(f"  [RISK] Param '{param}' has absolute/off-site URL", Color.RED, Color.BOLD))
                            print(style(f"    URL: {raw[:70]}...", Color.DIM) if len(raw) > 70 else style(f"    URL: {raw}", Color.DIM))
                            print(style(f"    Value: {val[:60]}", Color.WHITE))
                            print(style("    Fix: Allow only relative paths or a strict allowlist of hostnames.", Color.GREEN))
                if not any(p in qs for p in REDIRECT_PARAMS):
                    print(style(f"  No common redirect params in: {raw[:50]}...", Color.DIM))
            except Exception:
                print(style(f"  Could not parse: {raw[:50]}", Color.DIM))
        else:
            if _is_absolute_or_off_site(raw, None):
                print(style(f"  [RISK] Absolute URL used as redirect target: {raw[:60]}", Color.RED, Color.BOLD))
    print()
    print(style("Allowlist: Accept only /path or https://yourdomain.com/path. Reject everything else.", Color.CYAN))
    print()
    pause()

