from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "OWASP Cheat Sheet",
    "category": "Reference",
    "description": "Top 5 front-end security reminders and quick refs.",
    "command": "cheatsheet",
}

ITEMS = [
    ("1. XSS (Cross-Site Scripting)", [
        "Escape all user output. Use textContent, or a sanitizer (DOMPurify) for HTML.",
        "No unsanitized data in innerHTML, document.write, or HTML attributes.",
        "CSP: default-src 'self'; script-src 'self' or nonce-; no 'unsafe-inline' where possible.",
    ]),
    ("2. CSRF (Cross-Site Request Forgery)", [
        "Use CSRF tokens on state-changing requests (POST/PUT/DELETE).",
        "SameSite=Strict or Lax on session cookies.",
        "Check Origin/Referer on sensitive endpoints (server-side).",
    ]),
    ("3. Headers", [
        "Content-Security-Policy — restrict script/source.",
        "X-Frame-Options: DENY or SAMEORIGIN.",
        "X-Content-Type-Options: nosniff.",
        "Strict-Transport-Security for HTTPS.",
    ]),
    ("4. Cookies & session", [
        "HttpOnly on session cookies so JS cannot read them.",
        "Secure so they only go over HTTPS.",
        "SameSite=Strict or Lax.",
    ]),
    ("5. Forms & input", [
        "POST for login and any sensitive data; never GET.",
        "Validate and sanitize on the server; never trust the client.",
        "Use HTTPS for the whole site.",
    ]),
]


def run() -> None:
    print(style("OWASP-style cheat sheet", Color.CYAN, Color.BOLD))
    print(style("Top 5 for HTML / front-end security. Use scan + headers + csp for details.", Color.DIM))
    print()
    for title, bullets in ITEMS:
        print(style(title, Color.YELLOW, Color.BOLD))
        for b in bullets:
            print(style(f"  · {b}", Color.WHITE))
        print()
    print(style("More: https://cheatsheetseries.owasp.org/", Color.DIM))
    print()
    pause()
