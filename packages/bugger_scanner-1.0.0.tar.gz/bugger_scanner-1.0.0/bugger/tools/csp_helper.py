from __future__ import annotations

import re
from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "CSP Helper",
    "category": "Check",
    "description": "Paste CSP header; get validation and improvement tips.",
    "command": "csp",
}

IMPORTANT = ["default-src", "script-src", "style-src", "frame-ancestors", "base-uri", "form-action"]
SOURCES_SAFE = ["'self'", "'none'", "https:", "nonce-", "hash-"]
WEAK = ["'unsafe-inline'", "'unsafe-eval'", "*", "http:"]


def _generate_csp() -> None:
    print(style("CSP Generator", Color.CYAN, Color.BOLD))
    print(style("Answer a few questions to build a Content-Security-Policy.", Color.DIM))
    print()
    inline = input(style("Inline scripts? (y/n) [n]: ", Color.GREEN)).strip().lower() != "y"
    cdn = input(style("Load scripts/styles from CDN (e.g. cdnjs)? (y/n) [n]: ", Color.GREEN)).strip().lower() == "y"
    frames = input(style("Allow iframes from same origin? (y/n) [n]: ", Color.GREEN)).strip().lower() == "y"
    strict = input(style("Strict mode (no unsafe-inline/unsafe-eval)? (y/n) [y]: ", Color.GREEN)).strip().lower() != "n"

    parts = []
    parts.append("default-src 'self'")
    script = ["'self'"]
    if not strict:
        script.append("'unsafe-inline'")
        script.append("'unsafe-eval'")
    elif inline:
        script.append("'nonce-{RANDOM}'")
    if cdn:
        script.append("https://cdnjs.cloudflare.com")
        script.append("https://cdn.jsdelivr.net")
    parts.append("script-src " + " ".join(script))
    style_src = ["'self'"]
    if not strict:
        style_src.append("'unsafe-inline'")
    if cdn:
        style_src.append("https://cdnjs.cloudflare.com")
        style_src.append("https://cdn.jsdelivr.net")
    parts.append("style-src " + " ".join(style_src))
    parts.append("frame-ancestors 'self'" if frames else "frame-ancestors 'none'")
    parts.append("base-uri 'self'")
    parts.append("form-action 'self'")

    csp = "; ".join(parts)
    print()
    print(style("Generated CSP (copy to your server):", Color.GREEN, Color.BOLD))
    print(style("─" * 50, Color.DIM))
    print(csp)
    print()
    if "'nonce-{RANDOM}'" in csp:
        print(style("Replace {RANDOM} with a fresh nonce per request.", Color.YELLOW))
    print()


def run() -> None:
    print(style("CSP Helper", Color.CYAN, Color.BOLD))
    mode = input(style("Validate existing CSP or generate new? (validate/generate) [validate]: ", Color.GREEN)).strip().lower() or "validate"
    if mode == "generate":
        _generate_csp()
        pause()
        return

    print(style("Paste your Content-Security-Policy header value (single or multi-line). End with 'END'.", Color.DIM))
    print()
    lines = []
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    csp = " ".join(" ".join(lines).split()).strip()
    if not csp:
        print(style("No CSP entered.", Color.YELLOW))
        pause()
        return

    directives = {}
    for part in re.split(r";\s*", csp):
        part = part.strip()
        if not part:
            continue
        if " " in part:
            name, rest = part.split(None, 1)
            directives[name.lower()] = rest.strip()
        else:
            directives[part.lower()] = ""

    print()
    print(style("CSP validation & tips", Color.CYAN, Color.BOLD))
    print(style("─" * 50, Color.DIM))

    for d in IMPORTANT:
        if d in directives:
            val = directives[d]
            if any(w in val for w in WEAK):
                print(style(f"  [WEAK] {d}", Color.YELLOW, Color.BOLD))
                print(style(f"       {val[:70]}...", Color.DIM) if len(val) > 70 else style(f"       {val}", Color.DIM))
                print(style("       Prefer 'self', nonce-, or hash- instead of 'unsafe-inline' / 'unsafe-eval'.", Color.DIM))
            else:
                print(style(f"  [OK] {d}", Color.GREEN))
                print(style(f"       {val[:70]}", Color.DIM))
        else:
            print(style(f"  [MISSING] {d}", Color.RED))
            if d == "default-src":
                print(style("       Add default-src 'self'; to restrict defaults.", Color.DIM))
            elif d == "script-src":
                print(style("       Add script-src 'self' or nonce-; to limit script sources.", Color.DIM))
            elif d == "frame-ancestors":
                print(style("       Add frame-ancestors 'none' or 'self' to reduce clickjacking.", Color.DIM))

    if "script-src" in directives and "'unsafe-inline'" in directives.get("script-src", ""):
        print()
        print(style("  Tip: Replace 'unsafe-inline' with nonces or hashes for inline scripts.", Color.CYAN))
    if "default-src" not in directives and not any(d.startswith("default") for d in directives):
        print()
        print(style("  Tip: Add default-src 'self'; so unspecified directives fall back to same-origin only.", Color.CYAN))
    print()
    pause()
