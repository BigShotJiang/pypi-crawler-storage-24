from __future__ import annotations

import re
from bugger.core.colors import Color, style
from bugger.core.utils import pause

TOOL = {
    "name": "Cookie Checker",
    "category": "Check",
    "description": "Paste Set-Cookie headers; report missing flags and suggest values.",
    "command": "cookies",
}


def run() -> None:
    print(style("Cookie Checker", Color.CYAN, Color.BOLD))
    print(style("Paste Set-Cookie header(s). One cookie per line or full header lines. End with END.", Color.DIM))
    print()
    lines = []
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    raw = "\n".join(lines)
    if not raw.strip():
        print(style("No cookies entered.", Color.YELLOW))
        pause()
        return

    parts = re.split(r"Set-Cookie:\s*", raw, flags=re.I)
    cookies = []
    for p in parts[1:]:
        first_line = p.split("\n")[0].strip()
        cookies.append(first_line)

    print()
    print(style("Cookie security report", Color.CYAN, Color.BOLD))
    print(style("─" * 50, Color.DIM))
    for i, cookie in enumerate(cookies, 1):
        name = cookie.split("=")[0].strip() if "=" in cookie else "(unknown)"
        c_lower = cookie.lower()
        issues = []
        if "httponly" not in c_lower:
            issues.append("HttpOnly")
        if "secure" not in c_lower:
            issues.append("Secure")
        if "samesite" not in c_lower:
            issues.append("SameSite")
        if "max-age" not in c_lower and "expires" not in c_lower:
            issues.append("Max-Age or Expires (session vs persistent)")

        if not issues:
            print(style(f"  Cookie {i}: {name[:40]} — OK (HttpOnly, Secure, SameSite present)", Color.GREEN))
        else:
            print(style(f"  Cookie {i}: {name[:40]}", Color.YELLOW, Color.BOLD))
            print(style(f"    Missing: {', '.join(issues)}", Color.DIM))
            print(style("    Suggest: Add HttpOnly; Secure (if HTTPS); SameSite=Strict or Lax", Color.CYAN))
    print()
    print(style("Session cookies: Set-Cookie: SID=...; HttpOnly; Secure; SameSite=Strict; Path=/", Color.DIM))
    print()
    pause()

