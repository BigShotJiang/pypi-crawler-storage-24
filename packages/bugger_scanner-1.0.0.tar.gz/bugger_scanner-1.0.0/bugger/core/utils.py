from __future__ import annotations

import os
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / 'data'
TOOLS_DIR = BASE_DIR / 'bugger' / 'tools'


def clear() -> None:
    os.system('cls' if os.name == 'nt' else 'clear')


def pause(message: str = 'Press Enter to return to BUGGER...') -> None:
    input(message)


def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def type_print(text: str, delay: float = 0.001) -> None:
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)


def sanitize_command_name(name: str) -> str:
    return ''.join(ch.lower() for ch in name if ch.isalnum() or ch in ('_', '-', ' ')).strip()
