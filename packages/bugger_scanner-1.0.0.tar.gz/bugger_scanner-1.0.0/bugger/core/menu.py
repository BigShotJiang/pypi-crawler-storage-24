from __future__ import annotations

from collections import defaultdict
from typing import Iterable, List

from bugger.core.banner import LOGO, SUBTITLE
from bugger.core.colors import Color, style
from bugger.core.tool_loader import Tool


CATEGORY_ORDER = ("Core", "Scan", "Check", "Reference", "Checklist")


def render_header() -> None:
    print(style(LOGO, Color.GREEN, Color.BOLD))
    print(style(f"  {SUBTITLE}", Color.CYAN))
    print()


def render_tools(tools: Iterable[Tool], search: str | None = None) -> None:
    groups: dict[str, list] = defaultdict(list)
    for tool in tools:
        groups[tool.category].append(tool)

    if search:
        print(style(f"Filter: {search}", Color.YELLOW, Color.BOLD))
        print()

    for category in CATEGORY_ORDER:
        if category not in groups:
            continue
        print(style(f"  {category}", Color.MAGENTA, Color.BOLD))
        for tool in groups[category]:
            print(style(f"    {tool.key}. {tool.name:<20}  {tool.command}", Color.WHITE))
        print()

    for category in sorted(groups.keys(), key=str.lower):
        if category in CATEGORY_ORDER:
            continue
        print(style(f"  {category}", Color.MAGENTA, Color.BOLD))
        for tool in groups[category]:
            print(style(f"    {tool.key}. {tool.name:<20}  {tool.command}", Color.WHITE))
        print()


def render_help() -> None:
    print(style('Commands', Color.CYAN, Color.BOLD))
    print('  <number>           Run a tool by its menu number')
    print('  <command>          Run a tool by command name')
    print('  /search text       Filter tools by name/category/description')
    print('  all                Show all tools again')
    print('  reload             Reload auto-discovered tools')
    print('  clear              Clear the screen')
    print('  help               Show this help')
    print('  exit               Quit BUGGER')
    print()


def command_words(tools: List[Tool]) -> List[str]:
    words = ['help', 'reload', 'clear', 'exit', 'all']
    words.extend(str(tool.key) for tool in tools)
    words.extend(tool.command for tool in tools)
    return sorted(set(words), key=str.lower)
