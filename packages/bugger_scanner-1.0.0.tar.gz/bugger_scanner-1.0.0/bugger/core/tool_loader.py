from __future__ import annotations

from dataclasses import dataclass
import importlib
import pkgutil
from typing import Callable, List

from bugger.core.utils import sanitize_command_name


@dataclass
class Tool:
    key: int
    name: str
    category: str
    description: str
    command: str
    run: Callable[[], None]
    module_name: str


def load_tools() -> List[Tool]:
    tools: List[Tool] = []
    package = importlib.import_module('bugger.tools')

    for module_info in pkgutil.iter_modules(package.__path__):
        if module_info.name.startswith('_'):
            continue

        module = importlib.import_module(f'bugger.tools.{module_info.name}')
        metadata = getattr(module, 'TOOL', None)
        run_func = getattr(module, 'run', None)

        if not isinstance(metadata, dict) or not callable(run_func):
            continue

        name = metadata.get('name', module_info.name.replace('_', ' ').title())
        category = metadata.get('category', 'Misc')
        description = metadata.get('description', 'No description provided.')
        command = metadata.get('command', sanitize_command_name(name).replace(' ', '-'))

        tools.append(
            Tool(
                key=0,
                name=name,
                category=category,
                description=description,
                command=command,
                run=run_func,
                module_name=module_info.name,
            )
        )

    tools.sort(key=lambda t: (t.category.lower(), t.name.lower()))

    for index, tool in enumerate(tools, start=1):
        tool.key = index

    return tools
