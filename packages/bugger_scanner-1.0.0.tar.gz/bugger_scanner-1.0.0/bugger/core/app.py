from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import List

from bugger.core.banner import LOGO
from bugger.core.colors import Color, style
from bugger.core.menu import command_words, render_header, render_help, render_tools
from bugger.core.prompting import get_input
from bugger.core.tool_loader import Tool, load_tools
from bugger.core.utils import clear, ensure_data_dir, pause, type_print


def startup_animation() -> None:
    clear()
    type_print(style(LOGO, Color.GREEN, Color.BOLD), delay=0.0003)
    type_print(style('Bootstrapping BUGGER modules...\n', Color.CYAN), delay=0.003)
    for label in ['scanner', 'rules', 'guides', 'terminal']:
        type_print(style(f'[+] loading {label}\n', Color.DIM), delay=0.002)
        time.sleep(0.05)
    time.sleep(0.2)


def filter_tools(tools: List[Tool], query: str) -> List[Tool]:
    q = query.lower().strip()
    if not q:
        return tools
    return [
        tool for tool in tools
        if q in tool.name.lower()
        or q in tool.category.lower()
        or q in tool.description.lower()
        or q in tool.command.lower()
    ]


def find_tool(tools: List[Tool], raw: str) -> Tool | None:
    value = raw.strip().lower()
    if value.isdigit():
        for tool in tools:
            if tool.key == int(value):
                return tool
    for tool in tools:
        if value in {tool.command.lower(), tool.name.lower()}:
            return tool
    return None


def main() -> None:
    ensure_data_dir()
    startup_animation()
    tools = load_tools()
    visible_tools = tools
    filter_query = ''

    while True:
        clear()
        render_header()
        render_tools(visible_tools, filter_query if filter_query else None)
        user_input = get_input('bugger> ', command_words(tools)).strip()

        if not user_input:
            continue

        lowered = user_input.lower()

        if lowered in {'exit', 'quit', 'q'}:
            clear()
            print(style('BUGGER shutting down.', Color.RED, Color.BOLD))
            return

        if lowered == 'help':
            print()
            render_help()
            pause()
            continue

        if lowered == 'clear':
            continue

        if lowered == 'reload':
            tools = load_tools()
            visible_tools = tools
            filter_query = ''
            print(style('Tool registry reloaded.', Color.YELLOW, Color.BOLD))
            pause()
            continue

        if lowered == 'all':
            visible_tools = tools
            filter_query = ''
            continue

        if lowered.startswith('/search'):
            filter_query = user_input[7:].strip()
            visible_tools = filter_tools(tools, filter_query)
            if not visible_tools:
                print(style('No tools matched that search.', Color.RED, Color.BOLD))
                pause()
                visible_tools = tools
                filter_query = ''
            continue

        tool = find_tool(tools, user_input)
        if tool is None:
            print(style(f'Unknown selection: {user_input}', Color.RED, Color.BOLD))
            pause()
            continue

        clear()
        print(style(f'Launching {tool.name} [{tool.category}]\n', Color.CYAN, Color.BOLD))
        try:
            tool.run()
        except Exception as exc:  # pragma: no cover
            print(style(f'Tool crashed: {exc}', Color.RED, Color.BOLD))
            pause()


def run_cli() -> None:
    if len(sys.argv) >= 3 and sys.argv[1] == "--ci":
        from bugger.tools.html_scanner import JS_CSS_CHECKS, _run_scan
        p = Path(sys.argv[2])
        if not p.exists():
            print(f"BUGGER CI: path not found: {sys.argv[2]}", file=sys.stderr)
            sys.exit(2)
        report = []
        if p.is_file():
            content = p.read_text(encoding="utf-8", errors="replace")
            checks = JS_CSS_CHECKS if str(p).lower().endswith((".js", ".css")) else None
            report = _run_scan(content, str(p), do_print=False, checks=checks)
        elif p.is_dir():
            files = list(p.rglob("*.html")) + list(p.rglob("*.htm")) + list(p.rglob("*.js")) + list(p.rglob("*.css"))
            for f in files:
                try:
                    content = f.read_text(encoding="utf-8", errors="replace")
                    checks = JS_CSS_CHECKS if str(f).lower().endswith((".js", ".css")) else None
                    for e in _run_scan(content, str(f), do_print=False, checks=checks):
                        e["file"] = str(f)
                        report.append(e)
                except Exception:
                    pass
        high = sum(1 for e in report if e["severity"] == "HIGH")
        if high:
            print(f"BUGGER CI: {high} HIGH finding(s). Failing.", file=sys.stderr)
            sys.exit(1)
        print("BUGGER CI: No HIGH findings. Pass.")
        sys.exit(0)
    main()
