from __future__ import annotations

from typing import List

try:
    from prompt_toolkit import prompt
    from prompt_toolkit.completion import WordCompleter
except Exception:  # pragma: no cover
    prompt = None
    WordCompleter = None


def get_input(prompt_text: str, words: List[str]) -> str:
    if prompt is not None and WordCompleter is not None:
        completer = WordCompleter(words, ignore_case=True)
        try:
            return prompt(prompt_text, completer=completer, complete_while_typing=False)
        except (EOFError, KeyboardInterrupt):
            return 'exit'

    try:
        return input(prompt_text)
    except (EOFError, KeyboardInterrupt):
        return 'exit'
