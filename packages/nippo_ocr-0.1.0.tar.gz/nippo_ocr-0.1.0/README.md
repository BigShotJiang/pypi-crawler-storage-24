# nippo-ocr

A high-speed, lightweight Screen OCR engine optimized for reading Japanese and English text from screen captures. Built for the Nippo automated daily report system.

## Installation

```bash
pip install nippo-ocr
```

*(Note: PyPI upload pending)*

## Usage

```python
import cv2
from nippo_ocr import ProductionOCRBaseline

engine = ProductionOCRBaseline()
prev_img = cv2.imread("prev.png")
curr_img = cv2.imread("curr.png")

canvas, p_lines = engine.process_frames(prev_img, curr_img)
results = engine.run_ocr(canvas, p_lines)

print(results)
```
