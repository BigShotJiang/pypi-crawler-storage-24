## Django Model Seeder

[![GitHub stars](https://img.shields.io/github/stars/christiangarcia0311/django-model-seeder?style=social)](https://github.com/christiangarcia0311/django-model-seeder/stargazers)
[![GitHub issues](https://img.shields.io/github/issues/christiangarcia0311/django-model-seeder?style=flat)](https://github.com/christiangarcia0311/django-model-seeder/issues)
![Static Badge](https://img.shields.io/badge/License-MIT-orange?style=flat)
![Static Badge](https://img.shields.io/badge/Github-django_model_seeder-green?style=flat&logo=github)
![Static Badge](https://img.shields.io/badge/Pypi-django_model_seeder-blue?style=flat&logo=pypi&logoColor=white)
![Static Badge](https://img.shields.io/badge/Django-5.2+-green?style=flat&logo=django&logoColor=white)
![Static Badge](https://img.shields.io/badge/Python-3.9+-blue?style=flat&logo=python&logoColor=white)
[![Last commit](https://img.shields.io/github/last-commit/christiangarcia0311/django-model-seeder?style=flat)](https://github.com/christiangarcia0311/django-model-seeder/commits/main)
[![Latest release](https://img.shields.io/github/v/release/christiangarcia0311/django-model-seeder?style=flat)](https://github.com/christiangarcia0311/django-model-seeder/releases/latest)

**Command-based synthetic data generation and seeding for Django models using [data-seed-ph](https://github.com/christiangarcia0311/data-seed-ph).**

>[!NOTE]
> Designed for rapid database population in development environments, API testing, QA automation, and demo applications with seamless integration to Django's management command system.

[View full documentation](https://github.com/christiangarcia0311/django-model-seeder)

