'''
List command


This management command lists all available Django models that can be used
for seeding or data operations. It supports filtering by app and optionally
displaying record counts for each model.
'''

from django.core.management.base import BaseCommand, CommandError
from django.apps import apps 


class Command(BaseCommand):
    
    help = 'List all available Django models for seeding'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--app',
            type=str,
            default=None,
            help='Filter by specific app label name'
        )
        parser.add_argument(
            '--count',
            action='store_true',
            help='Show record count each model'
        )
        
    def handle(self, *args, **options):
        app_name_filter = options.get('app')
        show_record_count = options.get('count', False)
        
        self.stdout.write(
            self.style.SUCCESS('Available for seeding:\n')
        )
        
        for app_config in apps.get_app_configs():
            if app_name_filter and app_config.label != app_name_filter:
                continue
            
            models = app_config.get_models()
            
            if models:
                self.stdout.write(
                    self.style.WARNING(f'{app_config.label}: ')
                )
                
                for model in models:
                    model_name = model.__name__ 
                    count = model.objects.count() if show_record_count else None 
                    
                    if show_record_count:
                        self.stdout.write(
                            f'{model_name} ({count} records)'
                        )
                    else: 
                        self.stdout.write(f'{model_name}')
                self.stdout.write('')
        