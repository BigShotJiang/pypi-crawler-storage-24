# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 38
- **Lines**: 11155
- **Functions**: 346
- **Classes**: 45
- **Avg CC**: 3.5
- **Critical (CC≥10)**: 14

## Architecture

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 14L, 0 functions)

- `project.sh` — 14L, 0 methods, CC↑0

### scripts/ (2 files, 136L, 0 functions)

- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- `setup.sh` — 93L, 0 methods, CC↑0

### src/proxym/ (4 files, 400L, 6 functions)

- `ctl.py` — 179L, 2 methods, CC↑7
- `config.py` — 93L, 2 methods, CC↑3
- `main.py` — 125L, 2 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 346L, 20 functions)

- `__init__.py` — 346L, 20 methods, CC↑10

### src/proxym/api/ (6 files, 627L, 31 functions)

- `completions.py` — 293L, 10 methods, CC↑12
- `frontend.py` — 96L, 6 methods, CC↑5
- `system.py` — 67L, 5 methods, CC↑4
- `_state.py` — 69L, 6 methods, CC↑2
- `context_api.py` — 86L, 4 methods, CC↑2
- _1 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (6 files, 351L, 21 functions)

- `_client.py` — 39L, 3 methods, CC↑9
- `system.py` — 69L, 3 methods, CC↑7
- `accounts.py` — 70L, 3 methods, CC↑6
- `browser.py` — 65L, 4 methods, CC↑6
- `vms.py` — 107L, 8 methods, CC↑6
- _1 more files_

### src/proxym/context/ (5 files, 510L, 20 functions)

- `detector.py` — 208L, 9 methods, CC↑9
- `session.py` — 144L, 8 methods, CC↑6
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (3 files, 622L, 51 functions)

- `panel.jsx` — 347L, 26 methods, CC↑13
- `__init__.py` — 265L, 20 methods, CC↑3
- `api.js` — 10L, 5 methods, CC↑2

### src/proxym/dashboard/hooks/ (1 files, 52L, 4 functions)

- `useDashboardData.js` — 52L, 4 methods, CC↑8

### src/proxym/mcp/ (4 files, 380L, 16 functions)

- `client.py` — 148L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `registry.py` — 113L, 8 methods, CC↑4
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/middleware/ (1 files, 60L, 3 functions)

- `__init__.py` — 60L, 3 methods, CC↑5

### src/proxym/providers/ (1 files, 330L, 4 functions)

- `__init__.py` — 330L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 593L, 28 functions)

- `strategy.py` — 253L, 14 methods, CC↑9
- `__init__.py` — 340L, 14 methods, CC↑8

### src/proxym/virt/ (7 files, 1207L, 58 functions)

- `_config.py` — 87L, 1 methods, CC↑9
- `browser_profiles.py` — 325L, 11 methods, CC↑9
- `_orchestrator.py` — 510L, 28 methods, CC↑7
- `clonebox_adapter.py` — 209L, 17 methods, CC↑5
- `_check.py` — 17L, 1 methods, CC↑3
- _2 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **AccountCredentials** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)

## Hotspots (High Fan-Out)

- **main** — fan-out=26: Orchestrates 26 calls
- **chat_completions** — fan-out=22: OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X
- **useDashboardData** — fan-out=18: Orchestrates 18 calls
- **detect_firefox_profiles** — fan-out=17: Detect Firefox profiles by parsing profiles.ini.
- **_detect_chromium_family** — fan-out=17: Detect profiles for Chrome/Chromium from Local State file.
- **analyze_request** — fan-out=15: Analysis pipeline, 15 stages
- **sortColumn** — fan-out=15: Orchestrates 15 calls

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split god module htmlcov/coverage_html_cb_dd2e7eb5.js (735L, 0 classes) | high | high |
| 2 | Split god module src/proxym/virt/_orchestrator.py (510L, 1 classes) | high | high |
| 3 | Split table (CC=21 → target CC<10) | medium | low |
| 4 | Split table_body_rows (CC=21 → target CC<10) | medium | low |
| 5 | Split no_rows (CC=21 → target CC<10) | medium | low |
| 6 | Split footer (CC=21 → target CC<10) | medium | low |
| 7 | Split ratio_columns (CC=21 → target CC<10) | medium | low |
| 8 | Split filter_handler (CC=21 → target CC<10) | medium | low |
| 9 | Break circular dependency: src.proxym.virt.profiles.merge_profiles | medium | low |
| 10 | Reduce main fan-out (currently 26) | medium | medium |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

