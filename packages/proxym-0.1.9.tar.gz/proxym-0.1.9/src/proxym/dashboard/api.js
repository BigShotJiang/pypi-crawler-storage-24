// Dashboard API client — HTTP helpers and configuration.
// Loaded as a <script> before panel.jsx; exposes globals.

const API = window.APP_CONFIG?.api_url || "http://localhost:4000";
const KEY = window.APP_CONFIG?.api_key || "sk-proxy-local-dev";
const DEBUG = window.APP_CONFIG?.debug || false;

const _headers = { Authorization: `Bearer ${KEY}`, "Content-Type": "application/json" };
const get = (path) => fetch(`${API}${path}`, { headers: _headers }).then(r => r.json()).catch(() => null);
const post = (path, body) => fetch(`${API}${path}`, { method: "POST", headers: _headers, body: JSON.stringify(body) }).then(r => r.json()).catch(() => null);
