"""Live integration tests for Proxym Dashboard."""

import pytest
import httpx
import time


class TestDashboardLive:
    """Live integration tests for dashboard."""

    def setup_method(self):
        """Setup HTTP client for live server."""
        self.client = httpx.Client(base_url="http://localhost:4001", timeout=10.0)

    def teardown_method(self):
        """Cleanup HTTP client."""
        self.client.close()

    def test_live_server_health(self):
        """Test that live server is running."""
        response = self.client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_dashboard_ui_live(self):
        """Test dashboard UI on live server."""
        response = self.client.get("/dashboard-ui")
        
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]
        assert "<!DOCTYPE html>" in response.text
        assert "Proxym Dashboard" in response.text

    def test_dashboard_jsx_live(self):
        """Test JSX file on live server."""
        response = self.client.get("/proxym-dashboard.jsx")
        
        assert response.status_code == 200
        assert "text/javascript" in response.headers["content-type"]
        assert "// DEPRECATED: This file is kept for backward compatibility only." in response.text

    def test_dashboard_api_live(self):
        """Test dashboard API on live server."""
        response = self.client.get("/dashboard/system")
        
        assert response.status_code == 200
        assert "application/json" in response.headers["content-type"]
        
        data = response.json()
        required_keys = ["accounts", "vms", "libvirt"]
        for key in required_keys:
            assert key in data

    def test_dashboard_performance_live(self):
        """Test dashboard performance."""
        endpoints = ["/dashboard-ui", "/dashboard/system"]
        
        for endpoint in endpoints:
            start_time = time.time()
            response = self.client.get(endpoint)
            end_time = time.time()
            
            assert response.status_code == 200
            assert (end_time - start_time) < 2.0

    def test_dashboard_concurrent_live(self):
        """Test concurrent requests."""
        import threading
        
        results = []
        
        def make_request():
            response = self.client.get("/dashboard/system")
            results.append(response.status_code)
        
        threads = []
        for _ in range(10):
            thread = threading.Thread(target=make_request)
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()
        
        assert all(status == 200 for status in results)
