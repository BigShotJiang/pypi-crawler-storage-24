"""CLI module for weavbot."""
