"""Base channel interface for chat platforms."""

import mimetypes
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from loguru import logger

from weavbot.bus.events import InboundMessage, OutboundMessage
from weavbot.bus.queue import MessageBus


class BaseChannel(ABC):
    """
    Abstract base class for chat channel implementations.

    Each channel (Telegram, Discord, etc.) should implement this interface
    to integrate with the weavbot message bus.
    """

    name: str = "base"

    def __init__(self, config: Any, bus: MessageBus, workspace: Path):
        """
        Initialize the channel.

        Args:
            config: Channel-specific configuration.
            bus: The message bus for communication.
            workspace: The workspace root directory.
        """
        self.config = config
        self.bus = bus
        self.workspace = workspace
        self.media_dir = workspace / "media"
        self.media_dir.mkdir(parents=True, exist_ok=True)
        self._running = False

    def resolve_media_path(self, path: str) -> Path:
        """Resolve a media file path against workspace. Absolute paths are kept as-is."""
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = self.workspace / p
        return p.resolve()

    @abstractmethod
    async def start(self) -> None:
        """
        Start the channel and begin listening for messages.

        This should be a long-running async task that:
        1. Connects to the chat platform
        2. Listens for incoming messages
        3. Forwards messages to the bus via _handle_message()
        """
        pass

    @abstractmethod
    async def stop(self) -> None:
        """Stop the channel and clean up resources."""
        pass

    @abstractmethod
    async def send(self, msg: OutboundMessage) -> None:
        """
        Send a message through this channel.

        Args:
            msg: The message to send.
        """
        pass

    def is_allowed(self, sender_id: str) -> bool:
        """Check if *sender_id* is permitted.  Empty list → allow all; ``"*"`` → allow all."""
        allow_list = getattr(self.config, "allow_from", [])
        if not allow_list:
            return True
        if "*" in allow_list:
            return True
        sender_str = str(sender_id)
        return sender_str in allow_list or any(p in allow_list for p in sender_str.split("|") if p)

    async def _handle_message(
        self,
        sender_id: str,
        chat_id: str,
        content: str,
        media: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        session_key: str | None = None,
    ) -> None:
        """
        Handle an incoming message from the chat platform.

        This method checks permissions and forwards to the bus.

        Args:
            sender_id: The sender's identifier.
            chat_id: The chat/channel identifier.
            content: Message text content.
            media: Optional list of media URLs.
            metadata: Optional channel-specific metadata.
            session_key: Optional session key override (e.g. thread-scoped sessions).
        """
        if not self.is_allowed(sender_id):
            logger.warning(
                "Access denied for sender {} on channel {}. "
                "Add them to allowFrom list in config to grant access.",
                sender_id,
                self.name,
            )
            return

        image_media: list[str] = []
        non_image_paths: list[str] = []
        for path in media or []:
            mime, _ = mimetypes.guess_type(path)
            if mime and mime.startswith("image/"):
                image_media.append(path)
            else:
                non_image_paths.append(path)

        if non_image_paths:
            file_lines = "\n".join(f"- {p}" for p in non_image_paths)
            file_note = f"Attached files (path only, not multimodal):\n{file_lines}"
            content = f"{content}\n{file_note}" if content else file_note

        msg = InboundMessage(
            channel=self.name,
            sender_id=str(sender_id),
            chat_id=str(chat_id),
            content=content,
            media=image_media,
            metadata=metadata or {},
            session_key_override=session_key,
        )

        await self.bus.publish_inbound(msg)

    @property
    def is_running(self) -> bool:
        """Check if the channel is running."""
        return self._running
