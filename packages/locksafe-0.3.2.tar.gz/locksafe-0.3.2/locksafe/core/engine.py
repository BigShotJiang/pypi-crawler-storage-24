from locksafe.core.analyzer.migration_analyzer import MigrationAnalyzer
from locksafe.core.parser.parse_sql import SQLParser
from locksafe.core.rules.rule_registry import RuleRegistry
from locksafe.utils.logger import Logger


class LockSafeEngine:
    # Main entry point for analyzing migrations.

    def __init__(self, debug=False):

        self.logger = Logger("locksafe")

        if debug:
            self.logger.setLevel("DEBUG")
        else:
            self.logger.setLevel("ERROR")

        parser = SQLParser(self.logger)
        rules = RuleRegistry(self.logger)

        self.analyzer = MigrationAnalyzer(
            parser,
            rules,
            self.logger,
        )

    def analyze(self, sql: str):

        self.logger.debug("Engine analysis started")

        results = self.analyzer.analyze(sql)

        self.logger.debug(
            "Engine analysis finished",
            findings=len(results),
        )

        return results
