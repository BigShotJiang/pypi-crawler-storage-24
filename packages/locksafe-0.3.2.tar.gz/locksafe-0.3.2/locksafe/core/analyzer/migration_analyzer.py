class MigrationAnalyzer:
    # Runs registered rules against parsed SQL AST.

    def __init__(self, parser, rule_registry, logger):
        self.parser = parser
        self.rule_registry = rule_registry
        self.logger = logger

    def analyze(self, sql: str):

        self.logger.info("Starting migration analysis")

        ast = self.parser.parse(sql)

        findings = []

        for statement in ast:
            for node in statement.walk():
                for rule in self.rule_registry.get_rules():
                    result = rule.check(node)

                    if result:
                        findings.append(result)

        self.logger.info(
            "Migration analysis completed",
            findings=len(findings),
        )

        return findings
