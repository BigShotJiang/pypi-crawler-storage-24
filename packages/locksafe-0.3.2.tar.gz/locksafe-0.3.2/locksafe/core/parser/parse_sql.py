import sqlglot


class SQLParser:
    # Responsible for parsing SQL migrations into AST nodes.

    def __init__(self, logger):
        self.logger = logger

    def parse(self, sql: str):
        """
        Parse SQL string into AST statements.
        """

        self.logger.debug("Starting SQL parsing")

        try:
            ast = sqlglot.parse(sql, read="postgres")

            self.logger.debug(
                "SQL parsing completed",
                statements=len(ast),
            )

            return ast

        except Exception as exc:
            self.logger.error(
                "SQL parsing failed",
                error=str(exc),
            )
            raise
