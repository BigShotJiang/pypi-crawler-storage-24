from abc import ABC, abstractmethod


class BaseRule(ABC):
    rule_id: str
    severity: str
    description: str

    def __init__(self, logger):
        self.logger = logger

    @abstractmethod
    def check(self, node):
        pass
