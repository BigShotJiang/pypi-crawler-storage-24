from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class ExplicitLockRule(BaseRule):
    rule_id = "explicit-lock-table"
    severity = "HIGH"

    def check(self, node):

        if isinstance(node, exp.Command):
            if str(node).upper().startswith("LOCK"):
                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": "Explicit LOCK TABLE detected in migration",
                }
