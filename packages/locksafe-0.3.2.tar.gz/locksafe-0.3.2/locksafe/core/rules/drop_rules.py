from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class DropColumnRule(BaseRule):
    rule_id = "drop-column"
    severity = "HIGH"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        for action in node.args.get("actions", []):
            if isinstance(action, exp.Drop) and isinstance(action.this, exp.Column):
                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": "Dropping column may break rolling deploy",
                }


class DropTableRule(BaseRule):
    rule_id = "drop-table"
    severity = "CRITICAL"

    def check(self, node):

        if isinstance(node, exp.Drop):
            if node.args.get("kind") == "TABLE":
                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": "DROP TABLE permanently deletes table and data",
                }
