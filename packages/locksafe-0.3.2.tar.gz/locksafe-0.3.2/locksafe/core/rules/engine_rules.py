from collections import defaultdict

from sqlglot import exp


class MultipleDDLSameTableRule:
    rule_id = "multiple-ddl-same-table"
    severity = "MEDIUM"

    def __init__(self, logger):
        self.logger = logger

    def check(self, statements):

        tables = defaultdict(list)

        for stmt in statements:
            if isinstance(stmt, exp.Alter):
                table = stmt.this.name

                tables[table].append(stmt)

        findings = []

        for table, ops in tables.items():
            if len(ops) > 1:
                findings.append(
                    {
                        "rule_id": self.rule_id,
                        "severity": self.severity,
                        "message": f"Multiple DDL operations on table '{table}'",
                    }
                )

        return findings
