from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class TruncateRule(BaseRule):
    rule_id = "truncate"
    severity = "CRITICAL"

    def check(self, node):
        if not isinstance(node, exp.TruncateTable):
            return None

        tables = []

        expressions = node.args.get("expressions") or []

        for table in expressions:
            if isinstance(table, exp.Table):
                tables.append(table.name)

        table_list = ", ".join(tables)

        return {
            "rule_id": self.rule_id,
            "severity": self.severity,
            "message": f"TRUNCATE destroys all rows in {table_list}",
        }
