from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class AddForeignKeyRule(BaseRule):
    rule_id = "add-foreign-key-not-valid"
    severity = "MEDIUM"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        for action in node.args.get("actions", []):
            if not isinstance(action, exp.AddConstraint):
                continue

            fk_node = action.find(exp.ForeignKey)

            if fk_node is None:
                continue

            action_sql = action.sql(dialect="postgres").upper()
            has_not_valid = "NOT VALID" in action_sql

            if not has_not_valid:
                table_name = node.this.name if node.this else "unknown"

                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": (
                        f"Foreign key on '{table_name}' added without NOT VALID. "
                        f"Postgres will scan the entire '{table_name}' table to validate "
                        f"all existing rows, holding ShareRowExclusiveLock and blocking "
                        f"all writes for the duration of the scan. "
                        f"Use NOT VALID to create the constraint instantly, then run "
                        f"ALTER TABLE {table_name} VALIDATE CONSTRAINT <name> separately "
                        f"(uses only ShareUpdateExclusiveLock — writes continue normally)."
                    ),
                }

        return None
