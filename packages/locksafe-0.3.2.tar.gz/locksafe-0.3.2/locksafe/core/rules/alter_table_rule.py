from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class AlterTableRule(BaseRule):
    # Detects ALTER TABLE statements which may cause table locks.

    rule_id = "ALTER_TABLE"
    description = "ALTER TABLE may cause table locks"
    severity = "HIGH"

    def check(self, node):

        if isinstance(node, exp.Alter):
            table = node.this.sql() if node.this else "unknown"

            self.logger.info(
                "ALTER TABLE detected",
                rule=self.rule_id,
                table=table,
                severity=self.severity,
            )

            return {
                "rule_id": self.rule_id,
                "severity": self.severity,
                "message": f"ALTER TABLE detected on {table}",
            }

        return None
