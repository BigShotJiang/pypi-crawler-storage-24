from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class AlterColumnTypeRule(BaseRule):
    rule_id = "alter-column-type"
    severity = "HIGH"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        for action in node.args.get("actions", []):
            if isinstance(action, exp.AlterColumn):
                if action.args.get("dtype") is not None:
                    return {
                        "rule_id": self.rule_id,
                        "severity": self.severity,
                        "message": "ALTER COLUMN TYPE may trigger full table rewrite",
                    }
