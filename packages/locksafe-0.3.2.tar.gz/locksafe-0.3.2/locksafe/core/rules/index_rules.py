from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class CreateIndexNonConcurrentRule(BaseRule):
    rule_id = "create-index-non-concurrent"
    severity = "CRITICAL"

    def check(self, node):

        if not isinstance(node, exp.Create):
            return None

        if node.args.get("kind") != "INDEX":
            return None

        props = node.args.get("properties")

        concurrent = False
        if props:
            concurrent = any(
                isinstance(p, exp.ConcurrentlyProperty) for p in props.expressions
            )

        if not concurrent:
            table = node.find(exp.Table)

            return {
                "rule_id": self.rule_id,
                "severity": self.severity,
                "message": f"CREATE INDEX without CONCURRENTLY on table '{table}'",
            }


class DropIndexNonConcurrentRule(BaseRule):
    rule_id = "drop-index-non-concurrent"
    severity = "HIGH"

    def check(self, node):

        if not isinstance(node, exp.Drop):
            return None

        if node.args.get("kind") != "INDEX":
            return None

        concurrent = node.args.get("concurrent", False)

        if not concurrent:
            return {
                "rule_id": self.rule_id,
                "severity": self.severity,
                "message": "DROP INDEX without CONCURRENTLY acquires AccessExclusiveLock",
            }
