from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule

VOLATILE_FUNCTIONS = {
    "now",
    "current_timestamp",
    "random",
    "gen_random_uuid",
    "clock_timestamp",
}


def is_volatile(expr):

    for node in expr.walk():
        if isinstance(node, exp.Anonymous):
            if node.name.lower() in VOLATILE_FUNCTIONS:
                return True

        if isinstance(node, exp.CurrentTimestamp):
            return True

    return False


class AddColumnNotNullRule(BaseRule):
    rule_id = "add-column-not-null-no-default"
    severity = "CRITICAL"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        column_defs = node.find_all(exp.ColumnDef)

        for col in column_defs:
            constraints = col.find_all(exp.NotNullColumnConstraint)

            has_not_null = any(
                isinstance(c, exp.NotNullColumnConstraint) for c in constraints
            )

            default = next(
                (c for c in col.find_all(exp.DefaultColumnConstraint)),
                None,
            )

            if has_not_null and default is None:
                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": "ADD COLUMN NOT NULL without DEFAULT causes table rewrite",
                }

            if default and is_volatile(default.this):
                return {
                    "rule_id": "add-column-volatile-default",
                    "severity": "CRITICAL",
                    "message": "ADD COLUMN NOT NULL with volatile DEFAULT causes rewrite",
                }


class SetNotNullRule(BaseRule):
    rule_id = "set-not-null-no-check"
    severity = "HIGH"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        for action in node.find_all(exp.AlterColumn):
            if action.args.get("not_null"):
                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": "SET NOT NULL performs full table scan",
                }
