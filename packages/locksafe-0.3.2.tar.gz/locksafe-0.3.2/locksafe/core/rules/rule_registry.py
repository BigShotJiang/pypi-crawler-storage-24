from locksafe.core.rules.add_column_rules import (
    AddColumnNotNullRule,
    SetNotNullRule,
)
from locksafe.core.rules.alter_type_rules import (
    AlterColumnTypeRule,
)
from locksafe.core.rules.drop_rules import (
    DropColumnRule,
    DropTableRule,
)
from locksafe.core.rules.fk_rules import (
    AddForeignKeyRule,
)
from locksafe.core.rules.index_rules import (
    CreateIndexNonConcurrentRule,
    DropIndexNonConcurrentRule,
)
from locksafe.core.rules.lock_rules import (
    ExplicitLockRule,
)
from locksafe.core.rules.rename_rules import (
    RenameRule,
)
from locksafe.core.rules.truncate_rules import (
    TruncateRule,
)


class RuleRegistry:
    def __init__(self, logger):
        self.logger = logger

        self.rules = [
            CreateIndexNonConcurrentRule(logger),
            DropIndexNonConcurrentRule(logger),
            AddColumnNotNullRule(logger),
            SetNotNullRule(logger),
            AlterColumnTypeRule(logger),
            DropColumnRule(logger),
            DropTableRule(logger),
            AddForeignKeyRule(logger),
            TruncateRule(logger),
            RenameRule(logger),
            ExplicitLockRule(logger),
        ]

    def get_rules(self):
        return self.rules
