from sqlglot import exp

from locksafe.core.rules.base_rule import BaseRule


class RenameRule(BaseRule):
    rule_id = "rename-table-or-column"
    severity = "HIGH"

    def check(self, node):

        if not isinstance(node, exp.Alter):
            return None

        actions = node.args.get("actions") or []

        for action in actions:
            if isinstance(action, exp.AlterRename):
                old_name = node.this
                new_name = action.this

                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": (
                        f"Renaming table '{old_name}' to '{new_name}' will immediately "
                        f"break any running application pods referencing the old name. "
                        f"Create a compatibility view with the old name first, migrate "
                        f"all application code, then drop the view."
                    ),
                }

            if isinstance(action, exp.RenameColumn):
                old_col = action.this
                new_col = action.args.get("to")

                return {
                    "rule_id": self.rule_id,
                    "severity": self.severity,
                    "message": (
                        f"Renaming column '{old_col}' to '{new_col}' will immediately "
                        f"break any running application pods referencing the old column name. "
                        f"Use a two-deploy strategy: add new column, backfill, dual-write, "
                        f"then drop the old column."
                    ),
                }

        return None
