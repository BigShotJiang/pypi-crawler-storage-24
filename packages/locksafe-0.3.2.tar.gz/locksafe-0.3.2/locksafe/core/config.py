import tomllib
from pathlib import Path

DEFAULT_CONFIG = {
    "dialect": "postgres",
    "severity_threshold": "LOW",
    "exclude_patterns": [],
    "ignore": [],
}


def load_config() -> dict:
    config_path = Path(".locksafe.toml")

    if not config_path.exists():
        return DEFAULT_CONFIG

    with open(config_path, "rb") as f:
        data = tomllib.load(f)

    return {**DEFAULT_CONFIG, **data.get("locksafe", {})}
