import logging
from pathlib import Path


class ConsoleHandler(logging.StreamHandler):
    def __init__(self):
        super().__init__()

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        self.setFormatter(formatter)


class CustomFileHandler(logging.FileHandler):
    def __init__(self):

        log_dir = Path(".locksafe_logs")
        log_dir.mkdir(exist_ok=True)

        log_file = log_dir / "locksafe.log"

        super().__init__(log_file)

        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )

        self.setFormatter(formatter)


class Logger(logging.Logger):
    def __init__(self, name: str) -> None:
        super().__init__(name)

        self.setLevel(logging.DEBUG)
        self.propagate = False

        console_handler = ConsoleHandler()
        self.addHandler(console_handler)

        file_handler = CustomFileHandler()
        self.addHandler(file_handler)

    def info(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.INFO):
            msg = self._append_additional_info(msg, kwargs)
            self._log(logging.INFO, msg, args)

    def debug(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.DEBUG):
            msg = self._append_additional_info(msg, kwargs)
            self._log(logging.DEBUG, msg, args)

    def warning(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.WARNING):
            msg = self._append_additional_info(msg, kwargs)
            self._log(logging.WARNING, msg, args)

    def error(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.ERROR):
            msg = self._append_additional_info(msg, kwargs)
            self._log(logging.ERROR, msg, args)

    def critical(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.CRITICAL):
            msg = self._append_additional_info(msg, kwargs)
            self._log(logging.CRITICAL, msg, args)

    def _append_additional_info(self, msg, kwargs):

        if not kwargs:
            return msg

        additional_info = " ".join(f"({k}: {v})" for k, v in kwargs.items())

        return f"{msg} {additional_info}"
