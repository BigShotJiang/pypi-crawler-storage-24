import click
from rich.progress import Progress, SpinnerColumn, TextColumn

from locksafe.cli.ui.console import console
from locksafe.cli.ui.renderer import render_findings, render_summary
from locksafe.core.engine import LockSafeEngine


@click.command()
@click.argument("file", type=click.Path(exists=True))
@click.pass_context
def analyze(ctx, file):

    with open(file) as f:
        sql = f.read()

    debug = ctx.obj.get("debug", False)

    engine = LockSafeEngine(debug=debug)

    with Progress(
        SpinnerColumn(),
        TextColumn("[cyan]Analyzing migration..."),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("analyze", total=None)

        findings = engine.analyze(sql)

        progress.update(task, completed=True)

    statements = len(sql.split(";"))

    render_summary(file, statements, findings)

    if findings:
        console.print("\n⚠ Migration risks detected\n")

        render_findings(findings)

        raise SystemExit(1)

    else:
        console.print("\n✅ No dangerous migrations detected.\n")

        raise SystemExit(0)
