import click

from locksafe import __version__


@click.command()
def version() -> None:
    """Show LockSafe version."""
    click.echo(f"LockSafe v{__version__}")
