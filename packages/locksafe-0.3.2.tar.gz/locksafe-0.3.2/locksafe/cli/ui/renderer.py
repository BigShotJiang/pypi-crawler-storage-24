from rich import box
from rich.panel import Panel
from rich.text import Text

from .console import console
from .theme import SEVERITY_STYLES


def render_summary(file_path, statements, findings):

    counts = {
        "CRITICAL": 0,
        "HIGH": 0,
        "MEDIUM": 0,
        "LOW": 0,
    }

    for f in findings:
        counts[f["severity"]] += 1

    summary = (
        f"File: {file_path}\n"
        f"Statements: {statements}  │  "
        f"Critical: {counts['CRITICAL']}  │  "
        f"High: {counts['HIGH']}  │  "
        f"Medium: {counts['MEDIUM']}  │  "
        f"Low: {counts['LOW']}"
    )

    console.print(
        Panel(
            summary,
            title="🔐 LockSafe Analysis",
            border_style="cyan",
            box=box.ROUNDED,
        )
    )


def render_findings(findings):

    for i, finding in enumerate(findings, start=1):
        icon, style = SEVERITY_STYLES.get(finding["severity"], ("⚪", "white"))

        header = Text(
            f"[{finding['severity']}] Statement {i}",
            style=style,
        )

        console.print()
        console.print(icon, header)

        if "statement" in finding:
            console.print(f"[bold]{finding['statement']}[/bold]")

        console.print(f"↳ {finding['message']}")

        if "fix" in finding:
            console.print(f"[green]✓ Fix:[/green] {finding['fix']}")
