SEVERITY_STYLES = {
    "CRITICAL": ("🔴", "bold red"),
    "HIGH": ("🟠", "orange1"),
    "MEDIUM": ("🟡", "yellow"),
    "LOW": ("🔵", "blue"),
    "SAFE": ("✅", "green"),
}
