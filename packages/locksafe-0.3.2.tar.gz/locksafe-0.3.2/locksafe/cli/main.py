import logging

import click

from locksafe.cli.commands.analyze import analyze
from locksafe.cli.commands.version import version


@click.group()
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
@click.version_option("0.1.1")
def cli(ctx, debug):
    """LockSafe CLI"""

    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug

    if debug:
        logging.getLogger("locksafe").setLevel(logging.DEBUG)
    else:
        logging.getLogger("locksafe").setLevel(logging.WARNING)


cli.add_command(version)
cli.add_command(analyze)
