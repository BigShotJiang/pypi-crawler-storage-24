# 🔒 LockSafe

> **Stop production downtime caused by unsafe Postgres migrations — before they ever run.**

LockSafe analyzes Postgres migration files, detects dangerous operations, estimates lock duration, and rewrites migrations using safe patterns — integrated directly into CI/CD.

---

## The Product

| | |
|---|---|
| **Problem** | Alembic, Flyway, Liquibase run migrations with zero safety awareness |
| **Solution** | Pre-run static analyzer + CI/CD integration + safe rewrite engine |
| **Free tier** | `pip install locksafe` — local CLI, forever free, no account needed |
| **Team plan** | ₹1,499/mo — GitHub Action, PR comments, lock estimator, dashboard |
| **Business plan** | ₹4,999/mo — safe rewrite engine, Slack alerts, audit log |
| **MRR target** | ₹50,000 by Month 3 · ₹2,00,000 by Month 9 |

---

## Build Timeline

| Phase | Dates | Status |
|---|---|---|
| Project setup + CLI scaffold | Mar 14 – Mar 28 | 🟡 In progress |
| SQL parser + risk rule engine | Mar 28 – Apr 18 | ⬜ Upcoming |
| Safe rewrite engine | Apr 18 – May 9 | ⬜ Upcoming |
| GitHub Actions integration | May 9 – May 23 | ⬜ Upcoming |
| Payments + landing page | May 23 – May 30 | ⬜ Upcoming |
| Beta testing + bug fixes | May 30 – Jun 12 | ⬜ Upcoming |
| **Public launch** | **Jun 12, 2026** | ⬜ Upcoming |
| First revenue target | Jun 26, 2026 | ⬜ Upcoming |

---

## Repo Structure

```
.
├── README.md
│
├── docs/                          # Business, strategy, and product decisions
│   ├── Idea/                      # Problem discovery, market research, competition
│   ├── Validation/                # Customer interviews, waitlist, pre-sales
│   ├── Planning/                  # Roadmap, MVP scope, tech stack, dev plan
│   ├── Design/                    # Wireframes, UX flows, design system
│   ├── Launch/                    # Landing page, Product Hunt, early adopters
│   ├── Acquisition/               # SEO, content, social, cold email
│   ├── Distribution/              # Directories, communities, partnerships
│   ├── Conversion/                # Funnel, pricing, freemium, checkout
│   ├── Revenue/                   # Subscriptions, upsells, enterprise
│   ├── Analytics/                 # Tracking, funnels, KPIs, A/B tests
│   ├── Retention/                 # Onboarding, email automation, churn
│   ├── Growth/                    # Referrals, PLG, viral loops
│   └── Scaling/                   # Automation, hiring, exit
│
└── tech/                          # Engineering decisions and implementation docs
    ├── Development/               # Backend, frontend, APIs, database, auth
    ├── Infrastructure/            # Cloud hosting, DevOps, CI/CD, monitoring
    └── Testing/                   # Unit, integration, performance, beta
```

---

## Tech Stack

```
CLI          → Python + Click       pip install locksafe
SQL Parser   → sqlglot              Postgres AST, no regex
Backend API  → FastAPI + asyncpg    Async, raw SQL, no ORM
Database     → PostgreSQL           RDS on AWS
File Storage → AWS S3               Report archives
Payments     → Razorpay             Subscriptions + webhooks
Deployment   → Docker Compose → EC2 (MVP)  →  EKS + Terraform (post-revenue)
```

---

## Quick Links

| | |
|---|---|
| Product & feature spec | [docs/Planning/MVP-Scope](docs/Planning/MVP-Scope/README.md) |
| Full roadmap | [docs/Planning/Product-Roadmap](docs/Planning/Product-Roadmap/README.md) |
| Tech stack decisions | [docs/Planning/Tech-Stack](docs/Planning/Tech-Stack/README.md) |
| Development plan | [docs/Planning/Development-Plan](docs/Planning/Development-Plan/README.md) |
| Pricing strategy | [docs/Conversion/Pricing-Strategy](docs/Conversion/Pricing-Strategy/README.md) |
| Backend architecture | [tech/Development/Backend](tech/Development/Backend/README.md) |
| Database schema | [tech/Development/Database](tech/Development/Database/README.md) |
| CI/CD setup | [tech/Infrastructure/CI-CD](tech/Infrastructure/CI-CD/README.md) |
| Competitor analysis | [docs/Idea/Competitor-Analysis](docs/Idea/Competitor-Analysis/README.md) |
| KPI dashboard | [docs/Analytics/KPI-Dashboard](docs/Analytics/KPI-Dashboard/README.md) |

---

*Solo build · Part-time · 10–20 hrs/week · Started March 14, 2026*