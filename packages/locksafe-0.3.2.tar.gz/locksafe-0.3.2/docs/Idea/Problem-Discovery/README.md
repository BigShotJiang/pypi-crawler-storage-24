# Problem Discovery

## The Core Problem

Every backend team running Postgres has a migration horror story. Standard tools — Alembic, Flyway, Liquibase — are dumb runners. They execute SQL with zero safety awareness.

The problem is not careless developers. The problem is that **the tools give no warning**.

---

## Dangerous Operations (Documented)

| Operation | What Postgres Does | Real Impact |
|---|---|---|
| `ADD COLUMN NOT NULL` (no default) | Full table rewrite, every row touched | Minutes of table lock |
| `CREATE INDEX` (non-concurrent) | Blocks all writes during index build | 8+ min on 50M rows |
| `DROP COLUMN` during rolling deploy | Old pods read missing column | 10 min of 500 errors |
| `ALTER COLUMN TYPE` | Full table rewrite | Production locked |
| `ADD FOREIGN KEY` | Table scan + ShareRowExclusiveLock | Blocks concurrent writes |
| `TRUNCATE` on wrong environment | Irreversible data loss | Career-ending |
| 2s staging → 45min production | 10k rows staging, 200M rows prod | Surprise outage |

---

## Why Existing Tools Don't Solve This

- **Alembic** — runs migrations. No safety checks.
- **Flyway** — versioning, checksums, ordering. No semantic SQL analysis.
- **Liquibase** — XML/YAML changesets. Complex. No lock estimation.
- **Bytebase** — schema management UI. Not a pre-run analyzer.

None of them parse the SQL AST and say "this will lock your table for 8 minutes."

---

## The Knowledge Gap

Safety knowledge exists — senior DBAs know to use `CREATE INDEX CONCURRENTLY`, the shadow column pattern, `NOT VALID` foreign keys. But this knowledge lives in people's heads. It doesn't exist in the toolchain.

**LockSafe is the senior DBA in your CI/CD pipeline.**

---

## Problem Statement

> Backend engineering teams running Postgres in production have no automated way to detect dangerous migration operations before they execute. The result is preventable production downtime.

---

## Evidence of Pain (to collect)

- [ ] GitHub issues on Alembic/Flyway requesting safety checks
- [ ] HN threads about migration-caused downtime
- [ ] Personal migration incident (add yours)
- [ ] Stack Overflow questions about lock duration

---

*Last updated: March 2026*
