# Niche Selection

## Decision: Postgres-Only · Migration Safety · Developer CLI First

### Postgres only (not MySQL, SQLite, MSSQL)

- Postgres is #1 most used DB (Stack Overflow 2024)
- Postgres locking semantics are specific — rules differ from MySQL
- One DB done well beats many DBs done poorly
- Expand post-revenue if MySQL demand is validated

### Migration safety (not schema management)

- Schema management is crowded: Bytebase, Atlas, Liquibase
- Migration safety niche: **zero direct competitors**
- Safety is upstream — you catch the problem before management even applies it
- Natural CI/CD hook — runs automatically on every PR

### CLI first (not SaaS UI first)

- `pip install locksafe` = three keystrokes, instant value
- Developers trust tools they run locally before giving them production access
- CLI proves value; SaaS monetizes it
- GitHub stars + PyPI downloads = compounding social proof

### B2B subscription (not B2C, not usage-based)

- Individual developers don't pay for tooling (especially in India)
- Teams pay when it protects production
- Subscription is predictable and churn-resistant
- Bottom-up: developer installs it → team sees value → manager approves subscription

---

## Niche Definition

> Backend engineering teams at Postgres-backed SaaS companies who deploy database migrations via CI/CD and want automated safety guarantees before migrations run in production.

---

## Explicit Non-Scope

- ❌ Schema visualization
- ❌ Migration runner (we never execute SQL)
- ❌ Database monitoring (runtime queries)
- ❌ General SQL linter
- ❌ Multi-database support (MVP)

---

*Last updated: March 2026*
