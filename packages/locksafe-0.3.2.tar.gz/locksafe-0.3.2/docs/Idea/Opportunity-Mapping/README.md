# Opportunity Mapping

## Why This, Why Now

| Factor | Assessment |
|---|---|
| Postgres adoption | Accelerating — #1 DB for new SaaS |
| CI/CD maturity | GitHub Actions near-universal — one YAML step is trivial to add |
| OSS monetization | Proven model (Sentry, PostHog, PlanetScale) |
| Direct competition | Zero — market is open |
| Founder fit | Backend engineer, Postgres user, has felt this pain |

---

## Opportunity Score

| Dimension | Score /5 | Notes |
|---|---|---|
| Problem severity | 5 | Production downtime = crisis |
| Market clarity | 4 | Clear ICP, known channels |
| Competition | 5 | Effectively zero direct |
| Monetization | 4 | Clear B2B subscription path |
| Distribution | 4 | PyPI + HN + GitHub Marketplace |
| Founder fit | 5 | Backend eng, Postgres, knows the pain |
| Time to first value | 5 | Instant: `pip install && locksafe check` |

**31/35 — Strong opportunity.**

---

## Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| Flyway/Liquibase adds safety features | Low | They move slowly; we're CLI-native |
| Free → paid conversion is low | Medium | GitHub Action is the conversion trigger |
| False positives break trust | Medium | Extensive fixture test suite pre-launch |
| Market too small | Low | 40 Team customers = ₹60k MRR |
| Solo founder bandwidth | High | Strict MVP scope, no feature creep |

---

## The Asymmetric Bet

- **Downside:** 3 months work, don't hit MRR target. OSS project still valuable. Deep Postgres knowledge gained.
- **Upside:** ₹2L MRR in 9 months. Bootstrapped B2B SaaS. Expandable to MySQL, enterprise, more rules.

---

*Last updated: March 2026*
