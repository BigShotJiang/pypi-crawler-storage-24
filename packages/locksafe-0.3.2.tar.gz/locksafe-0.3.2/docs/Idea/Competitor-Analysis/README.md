# Competitor Analysis

## Direct Competitors

**None.** No tool specifically:
1. Parses Postgres migration SQL via proper AST analysis
2. Detects dangerous operations pre-run with semantic rules
3. Estimates lock duration from live pg_class statistics
4. Rewrites migrations using safe Postgres patterns

---

## Indirect Competitors

| Tool | Gap vs LockSafe |
|---|---|
| **Flyway** | Migration runner only. Zero safety analysis. |
| **Liquibase** | Complex enterprise tool. No lock estimation. No rewrite. |
| **Alembic** | Python runner. No analysis layer. |
| **Bytebase** | Schema management UI. Not CLI-native. Not pre-run safety. |
| **Atlas** | Declarative schema / drift detection. Different problem. |
| **pganalyze** | Runtime query analysis. Not pre-run. Expensive. |
| **Squawk** | Closest competitor. OSS SQL linter. No lock estimator, no rewrites, less maintained. |

---

## Squawk Deep Dive

Squawk (github.com/sbdchd/squawk) is the most relevant comparison:
- Postgres SQL linter with some migration rules
- Rust-based CLI, ~2k GitHub stars
- Has basic rules (non-concurrent index, etc.)
- **Missing:** lock duration estimator, rewrite engine, CI/CD product, SaaS tier, active maintenance

**Conclusion:** Squawk validates the problem. LockSafe is the complete, productized solution.

---

## Positioning

> LockSafe is the only Postgres migration tool that catches dangerous operations pre-run, estimates production lock duration, and automatically rewrites migrations to be safe — natively in CI/CD.

---

## Moat

1. Lock estimator — requires empirical calibration, hard to copy quickly
2. Rewrite engine — significant AST-level engineering depth
3. GitHub Action + PR workflow integration — switching cost
4. Rule accuracy — false positives kill trust; we invest in edge cases
5. Distribution — first mover on PyPI, HN, GitHub Marketplace

---

*Last updated: March 2026*
