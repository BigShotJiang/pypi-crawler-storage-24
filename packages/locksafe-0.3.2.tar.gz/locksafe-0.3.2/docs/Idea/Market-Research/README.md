# Market Research

## Target Customer

**Primary:** Backend engineers and platform teams at B2B SaaS companies running Postgres in production.

**Firmographic sweet spot:**
- 5–200 engineers
- Postgres as primary database
- Multiple deploys per week
- Using GitHub + GitHub Actions CI/CD

---

## Market Size

| Segment | Estimate |
|---|---|
| Companies using Postgres globally | ~800,000 |
| Companies with 5–500 engineers | ~120,000 |
| Actively deploying migrations weekly | ~60,000 |
| Reachable via GitHub/HN/developer communities | ~15,000 |

**SAM:** 15,000 teams × ₹2,500/mo avg = **₹37.5 Cr ARR potential**

Capturing 0.3% = ₹11 Lakh ARR. Our ₹2L MRR target requires ~0.06%.

---

## How Developers Discover Tools

1. Hacker News (Show HN posts)
2. GitHub — starred repos, README links
3. Reddit (r/postgres, r/devops, r/Python)
4. Colleague recommendation after an incident
5. Blog posts ("I wrote a tool that saved us from...")
6. GitHub Marketplace (Action discovery)
7. PyPI search

---

## Key Market Insight

Stack Overflow Developer Survey 2024: Postgres is the #1 most used database (49%). Growth is accelerating. Every new SaaS company defaults to Postgres. This is a growing market.

---

## India-Specific Notes

- Large pool of Postgres-using startups (Razorpay, Zerodha, Groww etc. all use Postgres)
- ₹1,499/mo is below the mental budget threshold for most funded teams
- Indian SaaS founders actively support bootstrapped Indian tools
- Equivalent tool priced in USD would be $18/mo — very competitive globally

---

*Last updated: March 2026*
