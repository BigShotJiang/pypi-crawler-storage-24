# Subscriptions

## Subscription Plans

| Plan | Price | Billing Cycles |
|---|---|---|
| Team | ₹1,499/mo | Monthly, Annual (₹14,990) |
| Business | ₹4,999/mo | Monthly, Annual (₹49,990) |

---

## Razorpay Setup

1. Create subscription plans in Razorpay dashboard
2. Plan IDs stored in environment config
3. Checkout triggered from dashboard "Upgrade" button
4. Razorpay hosted checkout handles payment
5. Webhook `subscription.activated` → set org plan in DB
6. Webhook `subscription.cancelled` → schedule plan downgrade at period end

---

## Subscription Lifecycle

```
User clicks "Start Team Plan"
  → Razorpay checkout (hosted)
  → Payment succeeds
  → Webhook: subscription.activated
  → org.plan = 'team'
  → Onboarding email sent

User cancels
  → Webhook: subscription.cancelled
  → schedule: org.plan = 'free' at current_period_end
  → Exit survey email
```

---

## Revenue Targets

| Month | Team Subs | Biz Subs | MRR |
|---|---|---|---|
| Jun 2026 | 3 | 0 | ₹4,497 |
| Jul 2026 | 8 | 1 | ₹16,991 |
| Aug 2026 | 15 | 3 | ₹37,482 |
| Sep 2026 | 25 | 6 | ₹67,469 |
| Dec 2026 | 60 | 15 | ₹1,64,925 |

---

*Last updated: March 2026*
