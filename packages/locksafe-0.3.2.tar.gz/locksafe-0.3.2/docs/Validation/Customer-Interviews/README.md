# Customer Interviews

## Goal

Validate that the problem is real, frequent, and painful enough to pay for solving. Find the exact language customers use — it will become our copy.

---

## Target Interviewees

- [ ] Backend engineers at funded Indian startups (Razorpay, CRED, Zerodha stack)
- [ ] Platform / DevOps engineers at 20–100 person SaaS companies
- [ ] Engineering managers who've dealt with migration-caused incidents
- [ ] Open source contributors to Alembic / SQLAlchemy

---

## Interview Script

**Opening (2 min)**
"I'm building a tool for Postgres teams. I'm not selling you anything today — I want to understand your experience with database migrations. Tell me about your current migration workflow."

**Core questions:**
1. Walk me through what happens when you deploy a migration to production.
2. Have you ever had a migration cause unexpected downtime or slowness?
3. What happened? How long did it take to diagnose?
4. How do you currently validate a migration is safe before running it?
5. If a tool could tell you "this migration will lock your users table for 6 minutes" — would that change what you do?
6. What would you pay for that, as a team?

**Closing:**
"Would you be willing to try an early version and give feedback?"

---

## Interview Log

| Date | Name / Role | Company Size | Key Insight | Would Pay? |
|---|---|---|---|---|
| | | | | |

---

## Patterns to Listen For

- "We've had incidents" — high pain, likely buyer
- "We have a senior DBA who reviews" — they're solving it manually, we automate that
- "We just hope it works" — unaware of the risk, need education
- "We use staging" — staging row count ≠ production row count (classic gap)

---

## Target: 10 interviews before launch

- [ ] Interview 1
- [ ] Interview 2
- [ ] Interview 3
- [ ] Interview 4
- [ ] Interview 5
- [ ] Interview 6
- [ ] Interview 7
- [ ] Interview 8
- [ ] Interview 9
- [ ] Interview 10

---

*Last updated: March 2026*
