# Pre-Sales

## Goal

Collect paid commitments (or strong verbal commitments) before the full product ships. Even 2–3 pre-sales validates pricing and urgency.

---

## Pre-Sale Offer

**Founding Team Plan:** ₹999/mo (33% off forever) for the first 20 teams.
- Locked in at this price as long as they stay subscribed
- Direct access to the founder for feedback
- Features shaped by their input

---

## How to Find Pre-Sale Customers

1. Customer interview participants who expressed strong interest
2. Twitter/X DMs to engineers who've publicly complained about migration downtime
3. LinkedIn outreach to platform engineers at target companies
4. r/postgres / r/devops posts asking "would you pay for this?"
5. HN "Who wants this?" thread

---

## Pre-Sale Conversation Script

"I'm building LockSafe — a tool that analyzes your Postgres migrations and catches dangerous operations before CI/CD runs them. We're offering founding team pricing at ₹999/mo (normally ₹1,499). No charge until the product ships. Would you be willing to commit to a 3-month trial in exchange for shaping the features?"

---

## Pre-Sale Tracker

| Date | Company | Contact | Plan | Status | Notes |
|---|---|---|---|---|---|
| | | | | | |

---

## Target: 5 pre-sales before launch

Current: 0 / 5

---

*Last updated: March 2026*
