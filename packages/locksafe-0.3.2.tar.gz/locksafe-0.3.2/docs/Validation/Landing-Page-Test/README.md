# Landing Page Test

## Goal

Measure conversion intent before the product is fully built. A waitlist signup = a vote that the problem is real.

---

## Landing Page URL

> TBD — target: locksafe.dev

---

## Page Structure (Planned)

1. **Hero:** "Stop migration downtime before it happens" + `pip install locksafe`
2. **Problem:** 3 real incident examples with impact numbers
3. **Solution:** How LockSafe works (parser → rules → report → fix)
4. **Features:** CLI (free) vs Team vs Business
5. **Demo:** Embedded terminal showing a real check output
6. **CTA:** "Join the waitlist" or "Get early access"
7. **Social proof:** GitHub stars counter once live

---

## Metrics to Track

| Metric | Target |
|---|---|
| Unique visitors | 500+ in first month |
| Waitlist signups | 50+ before launch |
| Email open rate | > 40% |
| PyPI installs (post-launch) | 200+ in week 1 |

---

## Tech Stack for Landing Page

- Framework: Next.js or plain HTML (speed over complexity)
- Analytics: Plausible (privacy-friendly, developer-trusted)
- Email capture: ConvertKit or Mailchimp
- Hosting: Vercel or Netlify

---

## A/B Test Ideas (Post-Launch)

- Hero: "Stop migration downtime" vs "The Postgres migration safety tool"
- CTA: "Get early access" vs "Install free" vs "Try the CLI"
- Social proof: GitHub stars vs testimonial quotes

---

*Last updated: March 2026*
