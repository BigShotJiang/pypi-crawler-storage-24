# Demand Testing

## Demand Signals (Track These)

| Signal | Where | Current |
|---|---|---|
| GitHub stars | github.com/locksafe/locksafe | 0 |
| PyPI weekly downloads | pypi.org/project/locksafe | 0 |
| Waitlist signups | Landing page | 0 |
| Pre-sales | Direct outreach | 0 |
| HN upvotes (Show HN post) | news.ycombinator.com | TBD |
| Reddit upvotes | r/postgres, r/devops | TBD |

---

## Validation Thresholds

Before investing significant time in a feature, it must pass at least one threshold:

| Signal | Threshold = "Build it" |
|---|---|
| Customer interviews mentioning it | 3+ unprompted mentions |
| GitHub issues requesting it | 5+ issues |
| Waitlist signups citing it | 10+ signups from that channel |
| Pre-sales contingent on it | 1+ pre-sale |

---

## Experiments to Run

- [ ] Post on r/postgres: "Does your team have a process for checking migration safety before running in prod?"
- [ ] Tweet: "What's your biggest migration horror story?" — measure engagement
- [ ] HN: Ask HN — "How do you verify Postgres migrations are safe before production?"
- [ ] LinkedIn poll: "Have you had a migration cause production downtime in the last 12 months?"

---

*Last updated: March 2026*
