# Waitlist

## Goal

Collect early signups to (a) validate demand and (b) have an audience for launch day.

---

## Waitlist Channels

- [ ] Landing page email form
- [ ] Twitter/X bio link
- [ ] HN profile
- [ ] GitHub repo README (early access link)
- [ ] Reddit posts with "DM me for early access"

---

## Email Sequence (Post-Signup)

1. **Immediate:** "You're on the list. Here's what LockSafe does and why we built it." (+ link to CLI if available)
2. **Week 2:** "Here's the migration that caused us to build this." (story-based, builds trust)
3. **Week 4:** "Beta is live. You get first access." (conversion email)

---

## Waitlist Tracker

| Date | Source | Signups | Notes |
|---|---|---|---|
| | | | |

---

## Target: 100 signups before public launch

Current: 0 / 100

---

*Last updated: March 2026*
