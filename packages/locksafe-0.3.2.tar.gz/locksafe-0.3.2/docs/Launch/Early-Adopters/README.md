# Early Adopters

## Target Profile

Engineers who:
- Have had a migration incident before (or know someone who has)
- Are active on GitHub, HN, or r/postgres
- Work at a company with an active migration cadence
- Are willing to give detailed feedback in exchange for founding pricing

---

## Founding User Benefits

- ₹999/mo Team plan (33% off forever, locked in)
- Direct access to founder on Slack/WhatsApp
- Feature requests prioritized
- Listed as "Founding Team" on website (if they want)

---

## Where to Find Early Adopters

- [ ] HN: "Ask HN: How does your team handle Postgres migration safety?"
- [ ] r/postgres: "I built a tool that catches dangerous migrations before CI/CD runs them"
- [ ] Twitter/X: threads on migration horror stories
- [ ] LinkedIn: reach out to platform engineers at Indian startups
- [ ] Personal network: ex-colleagues who have felt this pain
- [ ] GitHub: contributors to Alembic / SQLAlchemy

---

## Early Adopter Tracker

| Name | Company | Contact | Plan | Status | Feedback |
|---|---|---|---|---|---|
| | | | | | |

---

## Target: 10 founding users before public launch

Current: 0 / 10

---

*Last updated: March 2026*
