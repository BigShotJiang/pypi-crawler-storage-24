# Product Hunt Launch

## Target Date: June 12, 2026

---

## Pre-Launch Checklist

- [ ] Create Product Hunt profile (do this now)
- [ ] Build a following on PH before launch (upvote others, comment)
- [ ] Find a hunter with 500+ followers to hunt us
- [ ] Prepare all assets:
  - [ ] Logo (240x240px)
  - [ ] Tagline (60 chars max)
  - [ ] Description (260 chars)
  - [ ] Gallery images (1270x952px) — 5 images
  - [ ] Demo video (optional but very high impact)
- [ ] Schedule launch for Tuesday or Wednesday (highest traffic days)
- [ ] Notify waitlist 24h before launch

---

## Tagline Options

- "Stop Postgres migration downtime before it happens"
- "The migration safety tool your senior DBA wishes existed"
- "Catch dangerous SQL before CI/CD runs it"

---

## Launch Day Plan

- 12:01 AM PST: Product goes live
- Post to personal Twitter/X, LinkedIn
- Message developer communities (r/postgres, r/devops)
- Email waitlist
- Ask friends/contacts to upvote (not beg — share the story)
- Respond to every comment within 30 minutes

---

## Goal: Top 5 on launch day

Top 5 = featured in PH newsletter = ~10,000 additional impressions.

---

*Last updated: March 2026*
