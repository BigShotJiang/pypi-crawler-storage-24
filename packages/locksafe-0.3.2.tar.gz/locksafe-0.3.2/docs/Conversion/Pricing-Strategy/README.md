# Pricing Strategy

## Current Pricing

| Plan | Price | Billing |
|---|---|---|
| Free OSS | ₹0 | Forever |
| Team | ₹1,499/mo | Monthly (₹14,990/yr = ~16% discount) |
| Business | ₹4,999/mo | Monthly (₹49,990/yr = ~17% discount) |

---

## Pricing Rationale

**₹1,499/mo Team:**
- Below the mental "needs approval" threshold for most engineering leads
- Equivalent to $18/mo — globally competitive
- One prevented migration incident = many months of subscription value
- Comparable to 1 hour of senior dev time

**₹4,999/mo Business:**
- Rewrite engine saves 30 min of senior eng time per migration = ROI positive from day 1
- Slack alerts + audit log has compliance value
- 3.3x the Team plan = reasonable for "unlimited + automation"

---

## Annual Discount

Offer 2 months free on annual plans:
- Team Annual: ₹14,990/yr (saves ₹3,998 vs monthly)
- Business Annual: ₹49,990/yr (saves ₹9,998 vs monthly)

Annual plan = 12 months upfront = better cash flow for us.

---

## Founding Pricing

First 20 Team customers: ₹999/mo locked forever.
This is the pre-launch conversion strategy — limited seats, urgency.

---

## Pricing Review Trigger

Revisit pricing when:
- Churn > 5% and exit surveys mention price
- Sales velocity slows despite strong activation
- Enterprise customers ask for custom pricing

---

## Future: Enterprise Pricing

Custom quote for:
- 200+ engineer orgs
- Unlimited projects + priority SLA
- Self-hosted option
- SAML SSO
- Estimated: ₹50,000–2,00,000/mo depending on size

---

*Last updated: March 2026*
