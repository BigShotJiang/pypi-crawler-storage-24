# Freemium Model

## The Model

LockSafe uses a **developer-led freemium** model:

1. Developer discovers LockSafe (HN, GitHub, colleague)
2. Installs free CLI (`pip install locksafe`)
3. Uses it locally — gets value immediately
4. Wants CI/CD integration → hits the paid tier wall
5. Pitches to team lead → company subscribes

---

## Free Tier: What's Free Forever

- `locksafe check <file>` — all 9 risk rules
- `locksafe explain <rule>` — full explanations
- `.locksafe.toml` config
- Non-zero exit code on CRITICAL
- Offline, no account required

**The free tier is complete.** It's not a trial. It's not crippled. This is essential — developers trust free tools that are genuinely useful, and they advocate for them to their teams.

---

## Conversion Triggers

The moment a developer wants any of these, they need Team:

| Want | Requires |
|---|---|
| "Block the PR automatically" | GitHub Action (Team) |
| "Post a comment with the report" | PR comment bot (Team) |
| "Show me how long it'll lock the table" | Lock estimator (Team) |
| "Keep a history of all our migrations" | Report storage (Team) |
| "Just fix it for me" | Rewrite engine (Business) |
| "Alert us on Slack" | Slack integration (Business) |

---

## Why This Works

- No time limit on free tier (eliminates churn anxiety)
- Conversion happens naturally when team needs team features
- Developer is already sold before the manager sees the invoice
- B2B subscription = low churn once adopted in workflow

---

*Last updated: March 2026*
