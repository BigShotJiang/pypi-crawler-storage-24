# Product-Led Growth

## PLG Flywheel

```
Developer installs free CLI
        ↓
Gets value from first check
        ↓
Shares with team ("look what this caught")
        ↓
Team wants CI/CD integration
        ↓
Manager approves Team plan
        ↓
PR comments visible to whole team
        ↓
Other devs on team see it and install CLI
        ↓
(repeat)
```

---

## PLG Mechanisms Built Into the Product

| Mechanism | How |
|---|---|
| **Viral PR comments** | Every PR comment says "Powered by LockSafe" with a link. Visible to all reviewers. |
| **Exit code in CI** | CI failure message: "LockSafe found CRITICAL issues" — visible to entire team |
| **`locksafe explain`** | Devs share explanations with colleagues as educational content |
| **GitHub stars** | Public signal; developers check star count before installing |
| **PyPI download count** | Social proof on pypi.org listing |

---

## Distribution Channels (Ranked by Expected ROI)

1. **Hacker News (Show HN)** — highest quality, highest upside
2. **GitHub** — stars compound over time, marketplace discovery
3. **r/postgres + r/devops** — targeted, high intent
4. **Twitter/X** — developer community, migration horror story threads
5. **Blog posts** — long-tail SEO, evergreen
6. **Cold email to platform engineers** — direct, measurable

---

## Content Strategy

One blog post per major migration danger pattern:
- "Why CREATE INDEX can bring down your Postgres database"
- "The right way to add a NOT NULL column to a large table"
- "How we prevented 6 minutes of downtime with one line of CI/CD"

These rank for developer search queries and convert to CLI installs.

---

*Last updated: March 2026*
