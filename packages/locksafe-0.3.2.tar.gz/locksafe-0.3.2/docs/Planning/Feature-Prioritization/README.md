# Feature Prioritization

## Framework: Impact vs Effort

| Feature | Impact (1–5) | Effort (1–5) | Priority |
|---|---|---|---|
| `locksafe check` — core rules | 5 | 3 | 🔴 P0 |
| Non-zero exit code on CRITICAL | 5 | 1 | 🔴 P0 |
| GitHub Action integration | 5 | 3 | 🔴 P0 |
| PR comment bot | 5 | 2 | 🔴 P0 |
| Razorpay billing | 5 | 2 | 🔴 P0 |
| Lock duration estimator | 4 | 3 | 🟠 P1 |
| Safe rewrite engine (3 patterns) | 4 | 5 | 🟠 P1 |
| Team dashboard | 3 | 3 | 🟠 P1 |
| Slack alerts | 3 | 1 | 🟡 P2 |
| Audit log | 2 | 2 | 🟡 P2 |
| `locksafe explain` | 3 | 1 | 🟠 P1 |
| `.locksafe.toml` config | 3 | 1 | 🟠 P1 |
| Email onboarding sequence | 3 | 2 | 🟡 P2 |
| MySQL support | 2 | 5 | ⬜ Backlog |
| SAML SSO | 1 | 4 | ⬜ Backlog |
| VS Code extension | 2 | 4 | ⬜ Backlog |

---

## P0 Definition

Features without which the product cannot launch or cannot generate revenue. Non-negotiable for MVP.

## P1 Definition

Features that significantly improve conversion or retention. Build after P0, before launch.

## P2 Definition

Nice-to-have for launch, but shipped in Month 2 based on user feedback.

---

*Last updated: March 2026*
