# Tech Stack

## Decisions & Rationale

| Layer | Choice | Why |
|---|---|---|
| CLI language | Python | Same language as target users (backend devs), pip ecosystem |
| CLI framework | Click | Simple, composable, well-documented |
| SQL parser | sqlglot | Proper AST (not regex), Postgres dialect, active maintenance |
| Backend | FastAPI | Async, auto-OpenAPI docs, you already know it |
| DB driver | asyncpg (raw SQL) | No ORM overhead, explicit queries, fast |
| Database | PostgreSQL | Ironic and appropriate. RDS on AWS. |
| File storage | AWS S3 | Report archive, signed URL downloads |
| Payments | Razorpay | Indian payments, subscription support, good API |
| Deployment (MVP) | Docker Compose → EC2 | Simple, fast to ship, no K8s overhead pre-revenue |
| Deployment (post-revenue) | EKS + Terraform | After first paying customers justify the complexity |
| Terminal output | Rich | Beautiful terminal tables, colors, progress bars |
| Testing | pytest + pytest-asyncio | Standard, async support |
| Linting | ruff | Fastest Python linter |
| Type checking | mypy | Catches real bugs, especially in the rule engine |
| Package manager | uv | Significantly faster than pip/poetry |

---

## Explicitly Rejected

| Tool | Rejected Because |
|---|---|
| SQLAlchemy ORM | Overhead not needed; raw SQL keeps lock estimator queries explicit |
| Celery | Async queue not needed until sync proves too slow |
| Kubernetes (MVP) | Adds weeks of setup before first customer |
| Poetry | uv is strictly faster and simpler |
| Django | Overkill; FastAPI is the right weight |
| Redis | Not needed in MVP — no caching or rate limiting until scale |

---

## Development Environment

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone and setup
git clone https://github.com/yourusername/locksafe
cd locksafe
uv sync

# Run CLI locally
uv run locksafe check migrations/example.sql

# Run API locally
docker compose up  # starts postgres + api
```

---

*Last updated: March 2026*
