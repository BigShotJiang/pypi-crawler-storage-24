# MVP Scope

## Hard Boundary

The MVP ships on **June 12, 2026**. Everything below the line is in scope. Everything above is not.

---

## In Scope

### Free CLI
- `locksafe check <file>` with all 9 risk rules
- `locksafe explain <rule>` with full explanations
- `.locksafe.toml` support (ignore, threshold, exclude_patterns)
- Colored terminal output
- Non-zero exit code on CRITICAL

### Team Plan (₹1,499/mo)
- FastAPI backend with API key auth
- `POST /analyze` endpoint (calls core engine)
- Report storage in PostgreSQL + S3
- GitHub Action (`locksafe/action@v1`)
- Automatic PR comment with safety report
- Lock duration estimator (pg_class based)
- Basic dashboard: list reports, filter by severity
- Razorpay Team subscription
- Email alert on CRITICAL finding

### Business Plan (₹4,999/mo)
- Safe rewrite engine: 3 patterns (CREATE INDEX, ADD COLUMN NOT NULL, ADD FOREIGN KEY)
- Slack webhook alerts
- Razorpay Business subscription
- Plan gating middleware

---

## Explicitly Out of Scope (MVP)

| Feature | Reason |
|---|---|
| Audit log | Post-MVP Month 2 |
| SAML SSO | No enterprise customers yet |
| Custom rules per project | Add after we know what users want to tune |
| MySQL support | Postgres-only focus |
| Rewrite patterns 4–9 | Ship 3 solid; add rest on demand |
| Kubernetes deployment | Docker Compose on EC2 until revenue |
| Async task queue | Sync is fast enough at MVP scale |
| VS Code extension | Post-revenue |
| GitLab CI | Post-launch if demand exists |

---

## Definition of Done (MVP)

- [ ] `pip install locksafe && locksafe check migration.sql` works for any developer
- [ ] GitHub Action posts a formatted PR comment in < 30 seconds
- [ ] Razorpay subscription creates, upgrades, and cancels correctly
- [ ] Zero false positives on known-safe migration fixture library
- [ ] Rewrite engine produces valid SQL for all 3 supported patterns

---

*Last updated: March 2026*
