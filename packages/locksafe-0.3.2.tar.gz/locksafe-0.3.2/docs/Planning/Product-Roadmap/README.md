# Product Roadmap

## MVP (Target: June 12, 2026)

### Free OSS CLI
- [x] Project structure defined
- [ ] `locksafe check <file>` — all 9 risk rules
- [ ] `locksafe explain <rule>` — human-readable explanations
- [ ] `.locksafe.toml` config file support
- [ ] Non-zero exit code on CRITICAL findings
- [ ] Terminal output with severity badges

### Team Plan Infrastructure
- [ ] FastAPI backend + auth (API keys)
- [ ] PostgreSQL schema + asyncpg
- [ ] `POST /analyze` endpoint
- [ ] Report storage (PostgreSQL + S3)
- [ ] GitHub Action (`locksafe/action@v1`)
- [ ] PR comment bot
- [ ] Lock duration estimator (pg_class)
- [ ] Basic team dashboard (report list)
- [ ] Razorpay subscription billing

### Business Plan Features
- [ ] Safe rewrite engine (3 patterns: index, add-column, foreign key)
- [ ] Slack webhook alerts
- [ ] Plan gating middleware

---

## Post-MVP (Month 2–3)

- [ ] Audit log
- [ ] Report retention controls (30/90 day)
- [ ] Rewrite engine: additional patterns (ALTER TYPE, DROP COLUMN)
- [ ] Dashboard: trend charts, severity history
- [ ] Email onboarding sequence
- [ ] Custom rule config per project

---

## Future (Month 4+, if revenue validates)

- [ ] MySQL support
- [ ] SAML SSO
- [ ] Kubernetes deployment (currently Docker Compose)
- [ ] VS Code extension
- [ ] GitLab CI integration
- [ ] Async task queue (Celery/ARQ) for large migration analysis
- [ ] Self-hosted enterprise tier

---

*Last updated: March 2026*
