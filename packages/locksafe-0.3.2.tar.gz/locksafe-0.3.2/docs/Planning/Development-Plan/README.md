# Development Plan

## Constraints

- Solo founder
- Part-time: 10–20 hours/week
- Full-time job alongside
- Target launch: June 12, 2026 (13 weeks from March 14)

---

## Weekly Plan

| Week | Dates | Focus | Deliverable |
|---|---|---|---|
| 1 | Mar 14–21 | Repo setup, uv workspace, project structure | Folder structure, pyproject.toml, CI skeleton |
| 2 | Mar 21–28 | FastAPI skeleton, Click CLI scaffold | `locksafe --help` works, `/health` endpoint live |
| 3 | Apr 4–11 | sqlglot integration, AST exploration | Parser module, first 2 rules (index, add-column) |
| 4 | Apr 11–18 | Complete rule engine (all 9 rules) | `locksafe check` works end-to-end |
| 5 | Apr 18–25 | Lock estimator (pg_class) | Duration estimation working locally |
| 6 | Apr 25–May 2 | Safe rewrite engine (pattern 1: index) | `CREATE INDEX CONCURRENTLY` rewrite |
| 7 | May 2–9 | Safe rewrite engine (patterns 2 & 3) | ADD COLUMN + FK rewrites |
| 8 | May 9–16 | GitHub Action (file detection + API call) | Action triggers on PR |
| 9 | May 16–23 | PR comment bot | Safety report posted as PR comment |
| 10 | May 23–28 | Razorpay billing, plan gating | Subscription flow works end-to-end |
| 11 | May 28–Jun 4 | Landing page, dashboard UI | locksafe.dev live |
| 12–13 | Jun 4–12 | Beta testing, bug fixes, polish | Launch-ready |

---

## Daily Routine (Part-Time)

- Weekday evenings: 1.5–2 hrs (focused coding, no context switching)
- Weekend mornings: 4–5 hrs (architecture, complex features)
- Total: ~12–15 hrs/week

---

## Risk Buffer

2 weeks of slack built into the timeline (weeks 12–13 are buffer + testing). If a week slips, it absorbs into the buffer — not the launch date.

---

## Scope Freeze Date

**May 30, 2026** — No new features after this date. Bug fixes and polish only until launch.

---

*Last updated: March 2026*
