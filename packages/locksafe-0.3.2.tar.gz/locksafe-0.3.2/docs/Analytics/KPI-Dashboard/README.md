# KPI Dashboard

## North Star Metric

**Weekly Active CLI Users** — the number of unique machines running `locksafe check` per week.

This metric:
- Grows with distribution (more installs)
- Correlates with eventual paid conversion
- Is measurable without invasive tracking

---

## Core KPIs

| Metric | Definition | Target (Month 3) |
|---|---|---|
| CLI WAU | Unique machines running `locksafe check` / week | 500 |
| GitHub Stars | OSS repo stars | 300 |
| PyPI weekly downloads | pypi downloads/week | 1,000 |
| Waitlist signups | Total email signups pre-launch | 100 |
| Trial starts | Orgs that generate an API key | 30 |
| Trial → Paid | % of trials converting | 30% |
| MRR | Monthly Recurring Revenue | ₹50,000 |
| Churn | % of paying customers cancelling/month | < 5% |
| Analysis latency p95 | Time to return `/analyze` response | < 5s |
| False positive rate | CRITICAL flags on known-safe migrations | < 2% |

---

## Tracking Plan

### CLI (anonymous, opt-out)
```
Event: check_run
Properties: rule_count, critical_count, high_count, duration_ms
No: file content, SQL, IP address
```

Users can opt out: `locksafe config --no-telemetry`

### API (server-side, no opt-out)
- Every `/analyze` call logged with: org_id, project_id, finding summary, latency
- Funnel: API key created → first analysis → 10th analysis → still active at 30 days

---

## Monthly Review Cadence

Review on the 1st of each month:
- MRR growth/decline
- Churn and reasons (exit survey)
- Top feature requests
- False positive reports
- Conversion funnel drop-off

---

*Last updated: March 2026*
