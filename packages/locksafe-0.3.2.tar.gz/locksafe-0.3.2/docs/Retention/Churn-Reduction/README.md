# Churn Reduction

## Churn Targets

- Month 1 churn: < 10% (some trial churn expected)
- Month 3+ churn: < 5%
- Annual plan churn: < 2%

---

## Churn Drivers (Hypothesis)

| Driver | Prevention |
|---|---|
| No GitHub Action set up → no ongoing value | Onboarding email at Day 14 if not connected |
| False positive broke trust | Track FP rate, fast fix, proactive communication |
| Team changed CI/CD system | Add GitLab, Bitbucket support on demand |
| Price not justified | Improve rewrite engine value, or offer annual discount |
| Company lost funding, cut tools | Nothing to prevent; track as involuntary |

---

## Exit Survey

Triggered 24h after cancellation:

1. Why did you cancel? (Multiple choice + free text)
2. What would have made you stay?
3. Would you recommend LockSafe to a colleague? (NPS)

---

## Winback Campaign

30 days after cancellation: "We've shipped [new feature] since you left. Here's what's new."

---

## Stickiness Features

- Report history: the longer you use it, the more history you have → switching cost
- GitHub Action: embedded in CI/CD workflow → hard to remove
- `.locksafe.toml`: committed to repo → institutional knowledge

---

*Last updated: March 2026*
