# User Onboarding

## Free CLI Onboarding

No account. No email. The tool just works.

```bash
pip install locksafe
locksafe check migrations/0042_add_user_index.sql
```

First run should produce a clear, colored report. If there are no issues, say so explicitly ("All clear — 3 statements analyzed, 0 issues found."). Silence on success builds distrust.

---

## Team Plan Onboarding

Target: User goes from API key to first PR comment in < 15 minutes.

**Step 1: API key** (30 seconds)
→ Dashboard → Create project → Copy API key

**Step 2: GitHub Action** (5 minutes)
→ Add 6 lines to `.github/workflows/ci.yml`
→ Paste API key into GitHub secrets

**Step 3: First analysis** (on next PR)
→ Automatic comment appears on first PR touching migration files

---

## Onboarding Email Sequence

- **Day 0:** "Here's your API key and the quickstart guide"
- **Day 1:** "Did you get your first PR comment? Here's what the report means"
- **Day 3:** "How to configure LockSafe for your team (.locksafe.toml)"
- **Day 7:** "You've run X analyses. Here's what we found most common in your migrations"
- **Day 14:** If no GitHub Action set up: "You haven't connected to CI yet — here's why that matters"

---

## Success Moment Definition

A user has been "activated" when:
- They have received at least 1 PR comment from LockSafe
- OR they have run `locksafe check` at least 5 times

Activated users churn at < 2% / month.

---

*Last updated: March 2026*
