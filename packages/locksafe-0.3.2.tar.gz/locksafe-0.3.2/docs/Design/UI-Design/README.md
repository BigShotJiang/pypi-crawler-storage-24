# UI Design

## Design Direction

Clean, dark-accent developer tool aesthetic. Think: Vercel, Railway, Supabase.

- Primary: Deep navy `#1A1A2E`
- Accent: Indigo `#4F46E5`
- Success: Green `#16A34A`
- Critical: Red `#DC2626`
- High: Orange `#EA580C`
- Medium: Amber `#D97706`
- Font: Inter or Geist

---

## Component Library

Build with Tailwind CSS + shadcn/ui (React). No custom component library from scratch.

---

## Status

Deferred until Week 11. Build the product first; design the UI just before launch.

---

*Last updated: March 2026*
