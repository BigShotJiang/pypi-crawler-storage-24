# Prototype

## Prototype Plan

Build a working prototype, not a click-through mockup. The CLI is the prototype.

### Phase 1 Prototype (Week 4)
- `locksafe check` working end-to-end
- All 9 rules producing correct output
- Terminal output formatted with Rich

### Phase 2 Prototype (Week 9)
- GitHub Action posting real PR comments
- Dashboard showing real report data
- Lock estimator returning real estimates

---

## User Testing

Give Phase 1 prototype to 3 developers from customer interview pool.

Questions:
1. Is the output clear enough to understand the risk?
2. Is the fix suggestion actionable?
3. What would you do differently with this information?
4. Would you install this on your work repo?

---

*Last updated: March 2026*
