# Wireframes

## Status: Not started (Week 11 of build plan)

---

## Pages to Wireframe

- [ ] Landing page (locksafe.dev)
- [ ] Dashboard — report list
- [ ] Dashboard — single report detail
- [ ] Dashboard — project settings + API key
- [ ] Onboarding flow (new org → create project → copy API key → setup guide)
- [ ] Billing / upgrade page

---

## Tools

Figma or Excalidraw. Keep it low-fidelity until the core product is built.

---

## Key UX Principle

The dashboard is secondary. The primary interface is the terminal and the PR comment. The dashboard exists for history, trends, and settings — not for daily use.

---

*Last updated: March 2026*
