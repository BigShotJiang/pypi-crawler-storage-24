# Design System

## CLI Design System

### Severity Colors (Rich terminal)
- 🔴 CRITICAL — `red bold`
- 🟠 HIGH — `orange1`
- 🟡 MEDIUM — `yellow`
- 🔵 LOW — `blue`
- ✅ SAFE — `green`

### Output Format
```
┌─ LockSafe Analysis ──────────────────────────────────┐
│ File: migrations/0042_add_user_index.sql             │
│ Statements: 3  │  Critical: 1  │  High: 1  │  OK: 1 │
└──────────────────────────────────────────────────────┘

  [CRITICAL]  Statement 1
  CREATE INDEX ON users(email)
  ↳ Non-concurrent index build blocks all writes.
  ✓ Fix: CREATE INDEX CONCURRENTLY ON users(email)

  [HIGH]  Statement 2
  ALTER TABLE orders DROP COLUMN legacy_id
  ↳ Column may still be referenced by running application code.
  ✓ Fix: Deprecate first — remove references, then drop in next deploy.
```

### Exit Codes
- `0` — No issues found (or all below threshold)
- `1` — Issues found at or above severity threshold
- `2` — Parse error or invalid input

---

## Web Design System

Deferred to Week 11. Will use Tailwind + shadcn/ui tokens.

---

*Last updated: March 2026*
