# UX Flows

## Critical Flows to Design

### 1. Developer CLI Flow (Free)
```
pip install locksafe
→ locksafe check migration.sql
→ See colored report in terminal
→ Fix issue
→ Re-run → "All clear"
```

### 2. Team Onboarding Flow
```
Visit locksafe.dev
→ Sign up (email + org name)
→ API key generated
→ Copy GitHub Action snippet
→ Paste into .github/workflows/ci.yml
→ Add LOCKSAFE_API_KEY to GitHub secrets
→ Open PR with migration file
→ See automated PR comment
→ First activation moment
```

### 3. Upgrade Flow (Team → Business)
```
Hit rewrite engine route (403 on Team plan)
→ Banner: "Safe rewrites require Business plan"
→ Click "Upgrade"
→ Razorpay checkout
→ Immediate access to rewrite engine
```

### 4. PR Comment Interaction Flow
```
Developer opens PR
→ LockSafe bot posts comment
→ Developer clicks "View full report"
→ Redirected to dashboard report detail
→ Sees safe rewrite (if Business)
→ Copies safe SQL
→ Updates migration file
```

---

*Last updated: March 2026*
