# Exit Strategy

## Current Focus

Not thinking about exit. Thinking about ₹2L MRR.

---

## Potential Paths (For Reference)

### Acquisition targets (if we get there)

- **GitHub** — developer tools, CI/CD native integration, fits Actions marketplace strategy
- **Datadog** — expanding into developer tooling, DB observability
- **PlanetScale / Neon** — Postgres-native companies, safety tooling adds value
- **Atlassian** — Bitbucket Pipelines, developer workflow tools
- **Snyk** — developer security tooling, same PLG motion

### Bootstrapped exit

- Sell to a PE firm or indie acquirer at 3–5x ARR
- At ₹2L MRR (₹24L ARR): exit value ₹72L–1.2Cr
- At ₹10L MRR (₹1.2Cr ARR): exit value ₹3.6Cr–6Cr

### Keep and run

Most likely outcome for a bootstrapped solo SaaS. Reach ramen profitability → replace full-time job income → run indefinitely.

---

## Pre-Conditions for Thinking About Exit

- [ ] ₹1L+ MRR for 6+ consecutive months
- [ ] < 3% monthly churn
- [ ] Clear path to ₹5L MRR without heroic effort
- [ ] Inbound acquisition interest

Until then: build, ship, learn.

---

*Last updated: March 2026*
