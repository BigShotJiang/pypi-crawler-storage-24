# Content Marketing

## Strategy

Educate developers about migration safety. Position LockSafe as the resource they find when they search for this topic.

---

## Content Types

### Blog posts (high effort, high ROI)
- Deep technical posts on migration dangers
- "We analyzed 10,000 Alembic migration files — here's what we found"
- Post-mortems of migration-caused incidents (with permission or fictionalized)

### Twitter/X threads (low effort, fast distribution)
- "7 Postgres operations that can take down production (thread 🧵)"
- "The right way to add a NOT NULL column without downtime"
- Reply to threads about production incidents with helpful context

### README / docs (permanent, compounds)
- The CLI's README is a content asset
- Clear, detailed rule explanations in `locksafe explain`
- Docs site with migration safety guide

---

## Content Calendar (Post-Launch)

| Month | Post |
|---|---|
| Jun | "Why we built LockSafe" — founder story post |
| Jul | "CREATE INDEX CONCURRENTLY: complete guide" |
| Aug | "Postgres lock types every backend engineer should know" |
| Sep | "How to add NOT NULL columns to large Postgres tables" |
| Oct | "Migration horror stories: a collection" |

---

*Last updated: March 2026*
