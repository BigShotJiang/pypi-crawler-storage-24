# Cold Email

## Target: Engineering leads and platform engineers at Postgres-using startups

---

## List Building

- LinkedIn search: "platform engineer" + "backend" at Series A/B Indian startups
- GitHub: contributors to Alembic, Flask-Migrate, Django-migrations
- AngelList / YC company list filtered by tech stack

---

## Email Template

**Subject:** "Quick question about your Postgres migration workflow"

**Body:**
Hi [Name],

I'm building LockSafe — a CLI tool that analyzes Postgres migrations before they run and flags dangerous operations (non-concurrent indexes, table rewrites, etc.).

Has your team ever had a migration cause unexpected downtime in production?

If yes, I'd love 15 minutes to understand your workflow and see if LockSafe could help. No pitch — just genuinely trying to understand the problem.

If you're curious: `pip install locksafe && locksafe check <any migration file>` takes 10 seconds.

[Your name]

---

## Personalization Notes

- Reference a specific technology they use (Alembic, SQLAlchemy)
- Mention any open-source work they've done
- If they've written about database ops publicly, reference that post

---

## Metrics

Target: 50 emails/week, 20% reply rate, 5% book a call.

---

*Last updated: March 2026*
