# SEO Wins

## Target Keywords

| Keyword | Monthly Searches (est.) | Intent |
|---|---|---|
| postgres migration safety | 500 | High — direct |
| create index concurrently postgres | 2,000 | High — educational |
| add column not null postgres production | 800 | High — problem-aware |
| postgres migration lock timeout | 600 | High — pain-aware |
| alembic migration safety | 400 | Medium |
| postgres alter table lock | 1,200 | High |
| flyway safe migrations | 300 | Medium |

---

## Content Plan

One deep blog post per keyword cluster:

1. "CREATE INDEX without CONCURRENTLY: How to bring down Postgres in production"
2. "ADD COLUMN NOT NULL: The migration that locked our table for 6 minutes"
3. "Postgres migration lock cheat sheet: every DDL operation and its lock type"
4. "How to check if your database migration is safe before running it"
5. "Alembic migration best practices: 7 patterns that cause production downtime"

---

## Technical SEO

- Fast static site (Next.js, Vercel)
- Structured data on docs pages
- Code blocks indexed properly
- Canonical URLs for docs

---

## Timeline

Week 11 (landing page): basic SEO setup.
Month 2+: content marketing in earnest.

---

*Last updated: March 2026*
