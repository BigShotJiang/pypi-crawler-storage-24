# Communities

## Target Communities

| Community | Platform | Strategy |
|---|---|---|
| r/postgres | Reddit | Share educational content, answer questions, soft-launch post |
| r/devops | Reddit | CI/CD integration angle |
| r/Python | Reddit | CLI tool post on launch day |
| Postgres Slack | Slack | Active participation before launch |
| HN | Hacker News | Show HN on launch day |
| Dev.to | Blog | Publish educational posts |
| Lobste.rs | Community | Technical audience, high quality |
| IndieHackers | Forum | Bootstrapper community, share journey |

---

## Community Rules

1. Give value before promoting. Answer questions, help people, then mention LockSafe when relevant.
2. Never spam. One launch post per community, clearly marked.
3. Engage with comments. Every reply on launch day.
4. Build relationships. Regular presence, not just launch day.

---

## Pre-Launch Community Prep

- [ ] Create accounts on all platforms (do this now)
- [ ] r/postgres: participate in 5 threads before launch
- [ ] HN: comment on relevant threads before Show HN
- [ ] IndieHackers: document the build journey (builds audience + backlinks)

---

*Last updated: March 2026*
