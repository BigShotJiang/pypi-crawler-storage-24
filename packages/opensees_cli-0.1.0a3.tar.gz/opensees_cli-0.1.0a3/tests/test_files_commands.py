"""Tests for ops files subcommands — list, upload, download, delete."""

from pathlib import Path
from unittest.mock import patch

import pytest

from opensees_cli.main import app


class TestFilesList:
    def test_list_empty(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/files/list", json={"files": []})
        result = cli_runner.invoke(app, ["files", "list"])
        assert result.exit_code == 0
        assert "No files" in result.output

    def test_list_with_files(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/files/list", json={
            "files": [
                {"path": "model.py", "size": 1234, "last_modified": "2025-01-01T00:00:00Z"},
                {"path": "data.csv", "size": 5678, "last_modified": "2025-01-02T00:00:00Z"},
            ]
        })
        result = cli_runner.invoke(app, ["files", "list"])
        assert result.exit_code == 0
        assert "model.py" in result.output
        assert "data.csv" in result.output


class TestFilesUpload:
    def test_upload_single_file(self, cli_runner, logged_in_creds, patch_httpx, mock_router, tmp_file):
        mock_router.add("GET", "/prod/files/list", json={"files": []})
        mock_router.add("POST", "/prod/files/upload", json={
            "upload_url": "https://s3.example.com/presigned-put?sig=abc"
        })
        mock_router.add_any_url("PUT", status=200)
        result = cli_runner.invoke(app, ["files", "upload", str(tmp_file)])
        assert result.exit_code == 0
        assert "Uploaded" in result.output

    def test_upload_nonexistent_file(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["files", "upload", "/tmp/nonexistent_xyz.py"])
        assert result.exit_code == 1
        assert "Not found" in result.output

    def test_upload_overwrite_declined(self, cli_runner, logged_in_creds, patch_httpx, mock_router, tmp_file):
        mock_router.add("GET", "/prod/files/list", json={
            "files": [{"path": tmp_file.name, "size": 100, "last_modified": "2025-01-01T00:00:00Z"}]
        })
        result = cli_runner.invoke(app, ["files", "upload", str(tmp_file)], input="n\n")
        assert result.exit_code == 0
        assert "Cancelled" in result.output


class TestFilesDownload:
    def test_download_single_file(self, cli_runner, logged_in_creds, patch_httpx, mock_router, tmp_path):
        mock_router.add("GET", "/prod/files/list", json={
            "files": [{"path": "model.py", "size": 15, "last_modified": "2025-01-01T00:00:00Z"}]
        })
        mock_router.add("GET", "/prod/files/download", json={
            "download_url": "https://s3.example.com/presigned-get?sig=abc"
        })
        mock_router.add_any_url("GET", status=200, content=b"print('hello')\n")

        out = tmp_path / "out.py"
        result = cli_runner.invoke(app, ["files", "download", "model.py", "-o", str(out)])
        assert result.exit_code == 0
        assert "Downloaded" in result.output
        assert out.read_bytes() == b"print('hello')\n"

    def test_download_file_not_found(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/files/list", json={"files": []})
        result = cli_runner.invoke(app, ["files", "download", "nope.py"])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestFilesDelete:
    def test_delete_single(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/files/list", json={
            "files": [{"path": "model.py", "size": 100, "last_modified": "2025-01-01T00:00:00Z"}]
        })
        mock_router.add("POST", "/prod/files/delete", json={})
        result = cli_runner.invoke(app, ["files", "delete", "model.py"])
        assert result.exit_code == 0
        assert "Deleted" in result.output

    def test_delete_not_found(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/files/list", json={"files": []})
        result = cli_runner.invoke(app, ["files", "delete", "nope.py"])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()
