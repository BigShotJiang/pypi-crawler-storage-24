"""Tests for ops run subcommands + quota/submit-lock scenarios."""

from unittest.mock import patch

import pytest

from opensees_cli.main import app


# ---------------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------------

class TestSubmit:
    def test_submit_remote_file(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        """Remote submit (no local file) — happy path."""
        mock_router.add("POST", "/prod/run/submit", json={
            "analysis_id": "aaa11111-0000-0000-0000-000000000000",
            "task_id": "ttt11111-0000-0000-0000-000000000000",
            "total_tasks": 1,
            "stdout_url": "",
            "result_url": "",
        })
        result = cli_runner.invoke(app, ["run", "submit", "Truss.py", "--no-wait"])
        assert result.exit_code == 0
        assert "Simulation submitted" in result.output

    def test_submit_local_file(self, cli_runner, logged_in_creds, patch_httpx, mock_router, tmp_file):
        """Local file upload + submit."""
        mock_router.add("POST", "/prod/files/upload", json={
            "upload_url": "https://s3.example.com/presigned-put?sig=abc"
        })
        mock_router.add_any_url("PUT", status=200)
        mock_router.add("POST", "/prod/run/submit", json={
            "analysis_id": "aaa22222",
            "task_id": "ttt22222",
            "total_tasks": 1,
        })
        result = cli_runner.invoke(app, ["run", "submit", str(tmp_file), "--no-wait"])
        assert result.exit_code == 0
        assert "Uploading" in result.output
        assert "Simulation submitted" in result.output

    def test_submit_count_zero(self, cli_runner, logged_in_creds):
        result = cli_runner.invoke(app, ["run", "submit", "model.py", "--count", "0", "--no-wait"])
        assert result.exit_code == 1


class TestSubmitQuota:
    """Quota-plan CLI scenarios — the CLI only sees HTTP results."""

    def test_submit_locked_429(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/submit", status=429, json={
            "error": "Another submission in progress",
            "code": "submit_locked",
        })
        result = cli_runner.invoke(app, ["run", "submit", "Truss.py", "--no-wait"])
        assert result.exit_code == 1
        assert "submission" in result.output.lower() or "Another" in result.output

    def test_runtime_quota_429(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/submit", status=429, json={
            "error": "Monthly runtime quota exceeded",
            "code": "quota_runtime",
        })
        result = cli_runner.invoke(app, ["run", "submit", "Truss.py", "--no-wait"])
        assert result.exit_code == 1
        assert "quota" in result.output.lower() or "runtime" in result.output.lower()

    def test_storage_quota_429(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/submit", status=429, json={
            "error": "Storage quota exceeded",
            "code": "quota_storage",
        })
        result = cli_runner.invoke(app, ["run", "submit", "Truss.py", "--no-wait"])
        assert result.exit_code == 1

    def test_partial_concurrent_confirm(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        """Server returns partial — user confirms, second POST succeeds."""
        call_count = {"n": 0}
        original_handle = mock_router.handle

        def routing_handle(request):
            import httpx as _httpx
            path = _httpx.URL(str(request.url)).raw_path.decode().split("?")[0]
            if path == "/prod/run/submit":
                call_count["n"] += 1
                mock_router._calls.append({"method": request.method, "url": str(request.url), "content": request.content})
                if call_count["n"] == 1:
                    return _httpx.Response(
                        200,
                        json={
                            "status": "partial",
                            "available": 3,
                            "requested": 10,
                            "active": 2,
                            "max_concurrent": 5,
                        },
                        headers={"content-type": "application/json"},
                        request=request,
                    )
                else:
                    return _httpx.Response(
                        200,
                        json={
                            "analysis_id": "aaa33333",
                            "task_id": "ttt33333",
                            "total_tasks": 3,
                        },
                        headers={"content-type": "application/json"},
                        request=request,
                    )
            return original_handle(request)

        mock_router.handle = routing_handle
        result = cli_runner.invoke(
            app,
            ["run", "submit", "Truss.py", "--count", "10", "--no-wait"],
            input="y\n",
        )
        assert result.exit_code == 0
        assert "Only 3" in result.output or "3 tasks" in result.output.lower()

    def test_partial_concurrent_decline(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/submit", json={
            "status": "partial",
            "available": 2,
            "requested": 10,
            "active": 3,
            "max_concurrent": 5,
        })
        result = cli_runner.invoke(
            app,
            ["run", "submit", "Truss.py", "--count", "10", "--no-wait"],
            input="n\n",
        )
        assert result.exit_code == 0
        assert "Cancelled" in result.output


# ---------------------------------------------------------------------------
# follow (shallow mock — don't exercise full poll loop)
# ---------------------------------------------------------------------------

class TestFollow:
    def test_follow_already_completed(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/status", json={
            "task_id": "ttt44444",
            "status": "completed",
            "total_tasks": 1,
        })
        result = cli_runner.invoke(app, ["run", "follow", "ttt44444"])
        assert result.exit_code == 0
        assert "already completed" in result.output.lower()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

class TestRunStatus:
    def test_status_single_task(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/status", json={
            "task_id": "ttt55555",
            "analysis_id": "aaa55555",
            "status": "completed",
            "filename": "model.py",
            "total_tasks": 1,
            "created_at": "2025-06-01T00:00:00Z",
            "runtime_seconds": 12.5,
            "return_code": 0,
        })
        result = cli_runner.invoke(app, ["run", "status", "aaa55555"])
        assert result.exit_code == 0
        assert "completed" in result.output.lower()

    def test_status_no_running(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/list", json={"analyses": []})
        result = cli_runner.invoke(app, ["run", "status"])
        assert result.exit_code == 0
        assert "No running" in result.output


# ---------------------------------------------------------------------------
# output
# ---------------------------------------------------------------------------

class TestOutput:
    def test_output_single(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/output", json={"output": "Hello from OpenSees\n"})
        result = cli_runner.invoke(app, ["run", "output", "ttt66666"])
        assert result.exit_code == 0
        assert "Hello from OpenSees" in result.output

    def test_output_no_output(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/output", json={"output": ""})
        result = cli_runner.invoke(app, ["run", "output", "ttt66666"])
        assert result.exit_code == 0
        assert "No output" in result.output


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------

class TestStats:
    def test_stats_single(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/result", json={
            "result": {"return_code": 0, "ram_peak_kb": 1024},
            "runtime_seconds": 5.3,
        })
        result = cli_runner.invoke(app, ["run", "stats", "ttt77777"])
        assert result.exit_code == 0

    def test_stats_no_result(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/result", json={"result": None})
        result = cli_runner.invoke(app, ["run", "stats", "ttt77777"])
        assert result.exit_code == 0
        assert "No result" in result.output


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------

class TestCancel:
    def test_cancel(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/cancel", json={"cancelled": 1})
        result = cli_runner.invoke(app, ["run", "cancel", "aaa88888"])
        assert result.exit_code == 0
        assert "Cancelled" in result.output

    def test_cancel_error(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/run/cancel", status=404, json={"error": "Not found"})
        result = cli_runner.invoke(app, ["run", "cancel", "bad_id"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------

class TestClear:
    def test_clear_by_id(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/status", json={
            "task_id": "ttt99999",
            "total_tasks": 1,
            "status": "completed",
        })
        mock_router.add("POST", "/prod/run/clear", json={"cleared": 1})
        result = cli_runner.invoke(app, ["run", "clear", "ttt99999", "-y"])
        assert result.exit_code == 0
        assert "Cleared" in result.output

    def test_clear_no_args(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["run", "clear"])
        assert result.exit_code == 0
        assert "Provide" in result.output


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------

class TestData:
    def test_data_single_task(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/data", json={
            "files": [
                {"path": "result.json", "size": 256, "last_modified": "2025-06-01T00:00:00Z", "download_url": "https://s3/r.json"},
            ],
            "task_id": "ttt_data1",
        })
        result = cli_runner.invoke(app, ["run", "data", "ttt_data1"])
        assert result.exit_code == 0
        assert "result.json" in result.output


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

class TestList:
    def test_list_analyses(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/list", json={
            "analyses": [
                {
                    "analysis_id": "aaa_list1",
                    "status": "completed",
                    "filename": "model.py",
                    "total_tasks": 1,
                    "runtime": 2.5,
                    "size": 1024,
                    "created_at": "2099-12-31T00:00:00Z",
                },
            ]
        })
        result = cli_runner.invoke(app, ["run", "list", "--all"])
        assert result.exit_code == 0
        assert "model.py" in result.output

    def test_list_empty(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/run/list", json={"analyses": []})
        result = cli_runner.invoke(app, ["run", "list"])
        assert result.exit_code == 0
        assert "No analyses" in result.output
