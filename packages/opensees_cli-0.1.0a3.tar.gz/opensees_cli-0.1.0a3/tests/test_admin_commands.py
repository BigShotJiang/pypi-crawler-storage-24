"""Tests for ops admin subcommands — one test per command, using admin creds."""

from unittest.mock import patch

from opensees_cli.main import app


class TestListUsers:
    def test_list_users(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/admin/users", json={
            "users": [
                {
                    "email": "alice@test.com",
                    "status": "CONFIRMED",
                    "enabled": True,
                    "is_admin": False,
                    "last_login_at": "2025-01-01T00:00:00Z",
                    "last_activity_at": "",
                    "last_cli_version": "0.1.0a2",
                },
            ]
        })
        result = cli_runner.invoke(app, ["admin", "list-users"])
        assert result.exit_code == 0
        assert "alice@te" in result.output

    def test_list_users_empty(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/admin/users", json={"users": []})
        result = cli_runner.invoke(app, ["admin", "list-users"])
        assert result.exit_code == 0
        assert "No users" in result.output


class TestDisableUser:
    def test_disable_user(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/disable-user", json={"message": "User disabled."})
        result = cli_runner.invoke(app, ["admin", "disable-user", "-e", "alice@test.com"])
        assert result.exit_code == 0
        assert "disabled" in result.output.lower()


class TestEnableUser:
    def test_enable_user(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/enable-user", json={"message": "User enabled."})
        result = cli_runner.invoke(app, ["admin", "enable-user", "-e", "alice@test.com"])
        assert result.exit_code == 0
        assert "enabled" in result.output.lower()


class TestDeleteUser:
    def test_delete_user_confirmed(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/delete-user", json={"message": "User deleted."})
        result = cli_runner.invoke(app, ["admin", "delete-user", "-e", "alice@test.com"], input="y\n")
        assert result.exit_code == 0
        assert "deleted" in result.output.lower()

    def test_delete_user_cancelled(self, cli_runner, admin_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["admin", "delete-user", "-e", "alice@test.com"], input="n\n")
        assert result.exit_code == 0
        assert "Cancelled" in result.output


class TestUserInfo:
    def test_user_info(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/user-info", json={
            "email": "alice@test.com",
            "is_admin": False,
            "is_enabled": True,
            "quota": {
                "max_concurrent_runs": 5,
                "max_tasks_per_analysis": 100,
                "max_monthly_runtime": 3600,
                "monthly_runtime_used": 0,
                "monthly_runtime_remaining": 3600,
                "max_monthly_storage": 1073741824,
                "storage_used": 0,
            },
        })
        result = cli_runner.invoke(app, ["admin", "user-info", "-e", "alice@test.com"])
        assert result.exit_code == 0
        assert "alice@test.com" in result.output


class TestSetQuota:
    def test_set_quota_runtime(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/set-quota", json={"message": "Quota updated."})
        result = cli_runner.invoke(app, ["admin", "set-quota", "-e", "alice@test.com", "-r", "2h"])
        assert result.exit_code == 0
        assert "updated" in result.output.lower()

    def test_set_quota_no_flags(self, cli_runner, admin_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["admin", "set-quota", "-e", "alice@test.com"])
        assert result.exit_code == 0
        assert "Provide at least one" in result.output

    def test_set_quota_invalid_runtime(self, cli_runner, admin_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["admin", "set-quota", "-e", "a@t.com", "-r", "abc"])
        assert result.exit_code == 1
        assert "Invalid" in result.output

    def test_set_quota_storage(self, cli_runner, admin_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/admin/set-quota", json={"message": "Quota updated."})
        result = cli_runner.invoke(app, ["admin", "set-quota", "-e", "a@t.com", "-s", "10mb"])
        assert result.exit_code == 0
        assert "updated" in result.output.lower()
