# OpenSees CLI Documentation

Command-line interface for authentication and simulation runs.

## Install

```bash
pip install opensees-cli
```

For local development from this repo:

```bash
pip install -e cli/
```

For development with test dependencies:

```bash
pip install -e "cli/[dev]"
```

## Running tests

```bash
cd cli
pytest
```

## Quick Start

```bash
# 1) Create account
ops auth signup --email you@example.com

# 2) Confirm account
ops auth confirm --email you@example.com --code 123456

# 3) Log in
ops auth login --email you@example.com

# 4) Submit a simulation
ops run submit ./model.py --timeout 300 --wait
```

## Top-Level Commands

```bash
ops version
ops status
ops quota
ops help
```

- `version`: print CLI version
- `status`: show account details, signup time, and quota (calls the API)
- `quota`: show your current run quota

## Auth Commands

```bash
ops auth signup --email you@example.com
ops auth confirm --email you@example.com --code 123456
ops auth resend-code --email you@example.com
ops auth login --email you@example.com
ops auth logout
ops auth status
ops auth forgot-password --email you@example.com
ops auth reset-password --email you@example.com --code 123456
ops auth change-password
ops auth help
```

## Run Commands

```bash
ops run submit ./model.py --timeout 120 --wait
ops run status <run_id>
ops run output <run_id>
ops run result <run_id>
ops run cancel <run_id>
ops run list --limit 20
ops run help
```

### `run submit` options

- `file` (required positional): path to a `.py` simulation script
- `--timeout`, `-t`: max wall time per task in seconds (default `120`). The API requires your **monthly runtime remaining** ≥ `timeout ×` number of tasks. Runs above **900s** use Fargate when configured; otherwise the **900s** Lambda limit applies.
- `--wait/--no-wait`: stream output until completion (default `--wait`)

Validation enforced by CLI:
- file must exist
- file extension must be `.py`
- file size must be <= 200 KB

## Common Workflows

### Check account + quota

```bash
ops status
ops quota
```

### Submit and monitor a run later

```bash
ops run submit ./model.py --no-wait
ops run status <run_id>
ops run output <run_id>
ops run result <run_id>
```

### Reset password

```bash
ops auth forgot-password --email you@example.com
ops auth reset-password --email you@example.com --code 123456
```
