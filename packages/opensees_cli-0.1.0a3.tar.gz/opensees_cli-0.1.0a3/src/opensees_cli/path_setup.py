"""First-run PATH check and auto-fix.

After ``pip install opensees-cli`` the ``ops`` / ``opensees`` console-scripts
are placed in a platform-specific *scripts* directory that may not be on the
user's PATH.  This module detects the situation on first run, prompts the
user, and—if they agree—appends the directory to the appropriate shell
profile so future terminal sessions find the commands automatically.

State is tracked via a marker file (``~/.opensees/path_fixed``) so the
prompt only appears once.
"""

from __future__ import annotations

import os
import platform
import sysconfig
import sys
from pathlib import Path

from rich.console import Console

from opensees_cli.config import CONFIG_DIR

_MARKER = CONFIG_DIR / "path_fixed"
_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ensure_path() -> None:
    """Check whether the scripts directory is on PATH; offer to fix it."""
    if _MARKER.exists():
        return

    scripts_dir = _scripts_dir()
    if scripts_dir is None:
        return

    if _is_on_path(scripts_dir):
        _write_marker()
        return

    _prompt_and_fix(scripts_dir)
    _write_marker()


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _scripts_dir() -> str | None:
    """Return the directory where pip installed console-scripts."""
    # In a regular pip install the "scripts" sysconfig path is correct.
    # Inside a venv, this returns the venv's bin/ which is almost always
    # already on PATH, so the caller's ``_is_on_path`` check short-circuits.
    d = sysconfig.get_path("scripts")
    if d and Path(d).is_dir():
        return d

    # Fallback: --user installs land in the "user scripts" directory.
    d = sysconfig.get_path("scripts", f"{os.name}_user")
    if d and Path(d).is_dir():
        return d

    return None


def _is_on_path(directory: str) -> bool:
    dirs = os.environ.get("PATH", "").split(os.pathsep)
    target = Path(directory).resolve()
    return any(Path(d).resolve() == target for d in dirs if d)


def _write_marker() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _MARKER.touch()


def _prompt_and_fix(scripts_dir: str) -> None:
    _console.print(
        f"\n[yellow]The [bold]ops[/bold] command was installed to "
        f"[bold]{scripts_dir}[/bold] which is not on your PATH.[/yellow]"
    )

    try:
        answer = _console.input("[bold]Add it now? [Y/n] [/bold]").strip().lower()
    except (EOFError, KeyboardInterrupt):
        _console.print()
        return

    if answer and answer not in ("y", "yes"):
        return

    system = platform.system()
    if system == "Windows":
        _fix_windows(scripts_dir)
    else:
        _fix_unix(scripts_dir)


# ---------------------------------------------------------------------------
# Unix (macOS / Linux)
# ---------------------------------------------------------------------------

_BANNER = "# Added by opensees-cli"


def _fix_unix(scripts_dir: str) -> None:
    profile = _choose_unix_profile()
    if profile is None:
        _console.print(
            "[red]Could not determine your shell profile. "
            f"Please add the following line manually:[/red]\n"
            f'  export PATH="{scripts_dir}:$PATH"'
        )
        return

    export_line = f'export PATH="{scripts_dir}:$PATH"'
    block = f"\n{_BANNER}\n{export_line}\n"

    # Don't duplicate if the line is already in the file.
    if profile.exists() and export_line in profile.read_text():
        _console.print(
            f"[dim]PATH entry already present in {profile} — skipping.[/dim]"
        )
        return

    shell_name = _current_shell_name()
    if shell_name == "fish":
        _fix_fish(scripts_dir)
        return

    with profile.open("a") as f:
        f.write(block)

    _console.print(
        f"\n[green]Done![/green] Added to [bold]{profile}[/bold].\n"
        f"Restart your terminal or run:  [bold]source {profile}[/bold]"
    )


def _current_shell_name() -> str:
    shell = os.environ.get("SHELL", "")
    return Path(shell).name if shell else ""


def _choose_unix_profile() -> Path | None:
    shell = _current_shell_name()
    home = Path.home()

    if shell == "fish":
        cfg = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        return cfg / "fish" / "config.fish"

    if shell == "zsh":
        return home / ".zshrc"

    if platform.system() == "Darwin":
        # macOS default shell is zsh since Catalina.
        zshrc = home / ".zshrc"
        if zshrc.exists():
            return zshrc
        bash_profile = home / ".bash_profile"
        if bash_profile.exists():
            return bash_profile
        return zshrc  # create .zshrc if nothing exists yet

    # Linux with bash (or unknown shell)
    bashrc = home / ".bashrc"
    if bashrc.exists():
        return bashrc
    profile = home / ".profile"
    if profile.exists():
        return profile
    return bashrc


def _fix_fish(scripts_dir: str) -> None:
    cfg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    config_fish = cfg / "fish" / "config.fish"
    line = f"fish_add_path {scripts_dir}"

    if config_fish.exists() and line in config_fish.read_text():
        _console.print(
            f"[dim]PATH entry already present in {config_fish} — skipping.[/dim]"
        )
        return

    config_fish.parent.mkdir(parents=True, exist_ok=True)
    with config_fish.open("a") as f:
        f.write(f"\n{_BANNER}\n{line}\n")

    _console.print(
        f"\n[green]Done![/green] Added to [bold]{config_fish}[/bold].\n"
        "Restart your terminal for the change to take effect."
    )


# ---------------------------------------------------------------------------
# Windows
# ---------------------------------------------------------------------------

def _fix_windows(scripts_dir: str) -> None:
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        _console.print(
            "[red]Cannot modify the Windows registry on this platform.[/red]\n"
            f"Please add [bold]{scripts_dir}[/bold] to your PATH manually."
        )
        return

    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Environment",
        0,
        winreg.KEY_READ | winreg.KEY_WRITE,
    )
    try:
        current, _ = winreg.QueryValueEx(key, "Path")
    except FileNotFoundError:
        current = ""

    entries = [e for e in current.split(";") if e]
    target = str(Path(scripts_dir).resolve())

    if any(Path(e).resolve() == Path(target).resolve() for e in entries if e):
        _console.print("[dim]PATH entry already present — skipping.[/dim]")
        winreg.CloseKey(key)
        return

    entries.append(target)
    winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, ";".join(entries))
    winreg.CloseKey(key)

    _broadcast_setting_change()

    _console.print(
        f"\n[green]Done![/green] Added [bold]{scripts_dir}[/bold] to your user PATH.\n"
        "Open a new terminal for the change to take effect."
    )


def _broadcast_setting_change() -> None:
    """Tell Windows to re-read environment variables without a reboot."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        ctypes.windll.user32.SendMessageTimeoutW(  # type: ignore[attr-defined]
            HWND_BROADCAST, WM_SETTINGCHANGE, 0,
            "Environment", SMTO_ABORTIFHUNG, 5000, ctypes.byref(ctypes.c_long()),
        )
    except Exception:
        pass
