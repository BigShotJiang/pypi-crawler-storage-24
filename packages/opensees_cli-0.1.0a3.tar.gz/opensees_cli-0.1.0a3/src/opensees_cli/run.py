"""Simulation analysis CLI commands."""

import json
import random
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

import click
import typer
from rich.console import Console
from rich.table import Table

from opensees_cli import api
from opensees_cli.auth import _to_local, _fmt_bytes

console = Console()

_BARE_FLAG_DEFAULTS = {"--week": "0", "-w": "0", "--month": "0", "-m": "0"}


class _BareDefaultCommand(typer.core.TyperCommand):
    """Typer command that injects default values for bare --week/--month flags."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        patched: list[str] = []
        i = 0
        while i < len(args):
            arg = args[i]
            if arg in _BARE_FLAG_DEFAULTS:
                patched.append(arg)
                nxt = args[i + 1] if i + 1 < len(args) else None
                if nxt is None or nxt.startswith("-"):
                    patched.append(_BARE_FLAG_DEFAULTS[arg])
            else:
                patched.append(arg)
            i += 1
        return super().parse_args(ctx, patched)
app = typer.Typer(
    help="""Submit and manage simulation analyses.

Each 'ops run submit' creates an analysis with one or more tasks.
Use --count to run multiple tasks in parallel.

\b
Examples:
  ops run submit model.py                 Single-task analysis
  ops run submit model.py --count 100     100-task parallel analysis
  ops run submit model.py --no-wait       Submit without waiting
  ops run submit model.py -t 300          Set 300s timeout
  ops run follow abc12345                 Stream live output
  ops run follow abc12345 -t 2            Stream task 2's output
  ops run list                            List today's analyses
  ops run list --week                    List this week's analyses
  ops run list --month                   List this month's analyses
  ops run status abc12345                 Analysis summary
  ops run status abc12345 0-9            Status of tasks 0-9
  ops run output abc12345 0              Stdout from task 0
  ops run stats abc12345 all             Execution stats from all tasks
  ops run data abc12345                   Data summary for analysis
  ops run data abc12345 0 -d .           Download data from task 0
  ops run cancel abc12345                 Cancel an analysis or task
  ops run clear abc12345                  Delete an entire analysis
""",
)


@app.callback(invoke_without_command=True)
def _run_callback(ctx: typer.Context) -> None:
    api.require_login()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


_OPENSEES_TIPS = [
    # --- 2026 posts (Portwood Digital page 1) ---
    ("All Possible Sets of Possible Redundants",
     "The force method can systematically select redundants via equilibrium matrix reduction.",
     "https://portwooddigital.com/2026/03/15/all-possible-sets-of-possible-redundants/"),
    ("More Than One Way to Heat Up a Truss",
     "Truss elements don't directly support thermal loading — use imposed deformation patterns instead.",
     "https://portwooddigital.com/2026/03/03/more-than-one-way-to-heat-up-a-truss/"),
    ("Inside the Equation Numbers",
     "Equation numbering is behind the scenes, but choosing the right numberer affects bandwidth and solve time.",
     "https://portwooddigital.com/2026/02/24/inside-the-equation-numbers/"),
    ("Stop Cargo Culting BandGeneral and Plain Numberer",
     "Use RCM or AMD numberer with sparse solvers like UmfPack or Mumps for better performance.",
     "https://portwooddigital.com/2026/02/17/stop-cargo-culting-bandgeneral-and-plain-numberer/"),
    ("Remote Control with Rigid Links",
     "Numerical issues from rigid links? Consider using equivalent force-couples instead.",
     "https://portwooddigital.com/2026/02/10/remote-control/"),
    ("Leaning Column for P-Delta",
     "Approximate global P-Delta effects of gravity loads by connecting a leaning column to your lateral system.",
     "https://portwooddigital.com/2026/02/03/leaning-column/"),
    ("Why Your Eigenvalue Analysis Failed",
     "Check for mechanisms, disconnected nodes, or zero-stiffness DOFs before running eigen().",
     "https://portwooddigital.com/2026/01/27/why-your-eigenvalue-analysis-failed/"),
    ("Partial-Span Uniform Loads",
     "For beams framing around floor openings, tributary area gives partial-span uniform loads.",
     "https://portwooddigital.com/2026/01/20/partial-span-uniform-loads/"),
    ("Empty Spaces in ProfileSPD",
     "Large models with bad numbering + ProfileSPD = slow solve. Switch to UmfPack or SparseSYM.",
     "https://portwooddigital.com/2026/01/13/empty-spaces/"),
    ("Reverse Engineering the Equation Numberer",
     "No matter how you number nodes, the equation numberer cleans up the mess — but some do it better.",
     "https://portwooddigital.com/2026/01/06/reverse-engineering-the-equation-numberer/"),
    # --- late 2025 posts (page 2) ---
    ("Eigen Almost Hear You Sigh",
     "ARPACK quickly finds a few eigenpairs for large models — great for Rayleigh damping and mode checks.",
     "https://portwooddigital.com/2025/12/30/eigen-almost-hear-you-sigh/"),
    ("Modeling Is Always Nonlinear",
     "Modeling decisions are always nonlinear, even if the structural response is not.",
     "https://portwooddigital.com/2025/12/23/modeling-is-always-nonlinear-but-not-the-response/"),
    ("Three Acts with the Two Node Link",
     "TwoNodeLinkSection is like a TwoNodeLink but uses a section object — great for coupled response.",
     "https://portwooddigital.com/2025/12/21/three-acts-with-the-two-node-link/"),
    ("Combined Loadings",
     "OpenSees handles combined loadings on trusses — deflections, reactions, and member forces all at once.",
     "https://portwooddigital.com/2025/12/14/combined-loadings/"),
    ("Concrete23 and Me",
     "Beware material model clones with one or two mutations — always check parameters against the original.",
     "https://portwooddigital.com/2025/12/07/concrete23andme/"),
    ("Ways to Analyze This",
     "When default Newton-Raphson fails on nonlinear models, try alternative algorithms and step sizes.",
     "https://portwooddigital.com/2025/11/30/ways-to-analyze-this/"),
    ("Evergreen OpenSees Content",
     "The 30 most-read Portwood Digital posts cover timeless OpenSees fundamentals.",
     "https://portwooddigital.com/2025/10/31/evergreen-opensees-content/"),
    ("Daisy Chains and Gaffes",
     "Daisy-chaining multi-point constraints can cause sequencing problems with the Transformation handler.",
     "https://portwooddigital.com/2025/10/26/daisy-chains-and-gaffes/"),
    # --- mid 2025 posts (page 3) ---
    ("OpenSees Malapropisms",
     "Similar-sounding OpenSees commands can lead to confusing mistakes — double-check API names.",
     "https://portwooddigital.com/2025/10/21/opensees-malapropisms/"),
    ("Positive OpenSees Contact",
     "OpenSees can handle contact nonlinearity — even cantilevers that push onto adjacent spans.",
     "https://portwooddigital.com/2025/10/19/positive-opensees-contact/"),
    ("The Three-Act Verification",
     "Good verification needs setup, confrontation, and resolution — not just 'the assertions pass'.",
     "https://portwooddigital.com/2025/10/12/the-three-act-verification/"),
    ("Analyze This",
     "Even a simple nonlinear frame model can stump default analysis options — challenge yourself.",
     "https://portwooddigital.com/2025/10/05/analyze-this/"),
    ("Minimal Random Process Example",
     "DiscretizedRandomProcess constructs time series from filtered random variables for stochastic analysis.",
     "https://portwooddigital.com/2025/09/28/minimal-random-process-example/"),
    ("Rotated Local Axes",
     "Verify element local axes carefully when members are rotated about their longitudinal axis.",
     "https://portwooddigital.com/2025/09/21/rotated-local-axes/"),
    ("Celestial OpenSeesing",
     "OpenSees can approximate the three-body problem trajectories with numerical time-stepping methods.",
     "https://portwooddigital.com/2025/09/14/celestial-openseesing/"),
    ("Double Inverted Pendulum",
     "A double inverted pendulum needs active control — OpenSees can simulate base-excited stability problems.",
     "https://portwooddigital.com/2025/09/08/double-inverted-pendulum/"),
    # --- early-mid 2025 posts (page 4) ---
    ("How to Use pytest with OpenSees",
     "Wrap OpenSees models in pytest to systematically test and verify your analysis scripts.",
     "https://portwooddigital.com/2025/08/30/how-to-use-pytest-with-opensees/"),
    ("Distributed Moments",
     "Applying distributed moments in OpenSees is less intuitive than distributed forces — be careful.",
     "https://portwooddigital.com/2025/08/17/distributed-moments/"),
    ("A Model of Inconsistency",
     "Using an inconsistent tangent with Newton-Raphson? A simple two-DOF spring model shows what goes wrong.",
     "https://portwooddigital.com/2025/08/10/a-model-of-inconsistency/"),
    ("Bring Your Own Matrix",
     "Use printA() to export stiffness matrices from OpenSees and fullGeneral system to import external ones.",
     "https://portwooddigital.com/2025/07/27/bring-your-own-matrix/"),
    ("Can't Truss It",
     "Modified Newton for nonlinear trusses works but may converge slowly — know when to update the tangent.",
     "https://portwooddigital.com/2025/07/20/cant-truss-it/"),
    ("How to Apply Surface Loads",
     "Surface loads on solid/shell elements need equivalent nodal loads — hard for complex meshes.",
     "https://portwooddigital.com/2025/07/12/how-to-apply-surface-loads/"),
    ("Counting FLOPs",
     "Sparse solvers reduce floating point operations dramatically vs dense solvers on large models.",
     "https://portwooddigital.com/2025/07/06/counting-flops/"),
    ("Choose Your Own Topology",
     "Different sparse matrix elimination orderings yield vastly different fill-in and solve times.",
     "https://portwooddigital.com/2025/06/22/choose-your-own-topology/"),
    # --- spring 2025 posts (page 5) ---
    ("Buckling of Restrained Plates",
     "Plate buckling with all four sides restrained is more complex than minimal Euler buckling cases.",
     "https://portwooddigital.com/2025/05/31/buckling-of-restrained-plates/"),
    ("Minimal Plate Buckling Example",
     "Linear buckling analysis in OpenSees works for shell models with a simple eigenvalue workaround.",
     "https://portwooddigital.com/2025/05/24/minimal-plate-buckling-example/"),
    ("The Mechanically Separated Wall",
     "MVLEM elements separate in-plane fiber behavior from out-of-plane linear-elastic plate behavior.",
     "https://portwooddigital.com/2025/05/04/the-mechanically-separated-wall/"),
    ("Statically Equivalent Loads",
     "Numerical integration in frame elements converts distributed loads to equivalent nodal loads.",
     "https://portwooddigital.com/2025/04/14/statically-equivalent-loads/"),
    ("Apples and Oranges",
     "Displacement-based and force-based elements are not interchangeable — know the assumptions of each.",
     "https://portwooddigital.com/2025/04/06/apples-and-oranges/"),
    ("Section Warping Analysis",
     "For warping analysis you need non-zero length elements — ZeroLengthSection can't handle 7 DOFs per node.",
     "https://portwooddigital.com/2025/03/29/section-warping-analysis/"),
    ("OpenSees Coming and Going",
     "The boundary conditions of a problem define everything — get them right before analyzing.",
     "https://portwooddigital.com/2025/03/10/opensees-coming-and-going/"),
    ("One Is All You Need",
     "A single force-based element can simulate material nonlinear response of an entire frame member.",
     "https://portwooddigital.com/2025/03/02/one-is-all-you-need/"),
    # --- winter 2024-2025 posts (page 6) ---
    ("Two Node Link's Awakening",
     "TwoNodeLink is a zeroLength element with length — useful for link elements like those in SAP.",
     "https://portwooddigital.com/2025/02/23/two-node-links-awakening/"),
    ("Damping Is a Sensitive Subject",
     "DDM-based response sensitivity works in OpenSees, but not all elements implement damping sensitivity.",
     "https://portwooddigital.com/2025/02/09/damping-is-a-sensitive-subject/"),
    ("One Fiber at a Time",
     "The fiber command adds individual fibers by (y,z) coordinates, area, and material tag to a section.",
     "https://portwooddigital.com/2025/01/19/one-fiber-at-a-time/"),
    ("Minimal Damper Example",
     "Even a 40-story shear frame with dampers can be modeled with zero-length elements in series.",
     "https://portwooddigital.com/2025/01/12/minimal-damper-example/"),
    ("J2 Plasticity Parameters",
     "J2Plasticity was the first multi-axial plasticity model in OpenSees — check its parameter definitions.",
     "https://portwooddigital.com/2025/01/05/j2-plasticity-parameters/"),
    ("How to Profile an OpenSeesPy Analysis",
     "Use pyinstrument or cProfile to find where time goes, but drill into state determinations for real insight.",
     "https://portwooddigital.com/2024/12/22/how-to-profile-an-openseespy-analysis/"),
    ("Invertible Does Not Mean Stable",
     "A stiffness matrix that inverts does not guarantee a numerically stable structural model.",
     "https://portwooddigital.com/2024/12/11/invertible-does-not-mean-stable/"),
    # --- general best-practice tips (with portwooddigital.com root link) ---
    ("Newton-Raphson Convergence",
     "If Newton-Raphson doesn't converge, try ModifiedNewton, KrylovNewton, or reduce your load step.",
     "https://portwooddigital.com/2025/11/30/ways-to-analyze-this/"),
    ("Fiber Sections for Nonlinear Analysis",
     "Fiber sections capture moment-axial interaction automatically — no yield surface needed.",
     "https://portwooddigital.com/2025/01/19/one-fiber-at-a-time/"),
    ("Force-Based vs Displacement-Based Elements",
     "Force-based elements satisfy equilibrium exactly; use fewer elements but more integration points.",
     "https://portwooddigital.com/2025/04/06/apples-and-oranges/"),
    ("Rayleigh Damping Pitfalls",
     "Anchor Rayleigh damping to two modes that bracket your frequency range of interest.",
     "https://portwooddigital.com/2025/02/09/damping-is-a-sensitive-subject/"),
    ("Corotational Transformation",
     "For large displacements, use '-corotational' geometric transformation instead of '-PDelta'.",
     "https://portwooddigital.com/2025/03/02/one-is-all-you-need/"),
    ("Recorder Performance",
     "Heavy recorders that log every DOF at every step slow analysis — record only what you need.",
     "https://portwooddigital.com/2026/01/13/empty-spaces/"),
    ("Zero-Length Elements",
     "Zero-length elements connect two nodes at the same coordinate — great for springs, hinges, and gaps.",
     "https://portwooddigital.com/2025/01/12/minimal-damper-example/"),
    ("Constraint Handlers Matter",
     "Transformation, Penalty, and Lagrange handlers behave differently — pick the right one for your BCs.",
     "https://portwooddigital.com/2025/10/26/daisy-chains-and-gaffes/"),
    ("Integration Points in Force-Based Elements",
     "Use at least 4-5 Gauss-Lobatto integration points in forceBeamColumn for accurate plastic hinge spread.",
     "https://portwooddigital.com/2025/04/14/statically-equivalent-loads/"),
    ("Geometric Nonlinearity Options",
     "'-Linear', '-PDelta', and '-Corotational' transformations cover small to very large displacement ranges.",
     "https://portwooddigital.com/2026/02/03/leaning-column/"),
    ("Check Your Eigenvalues First",
     "Run eigen() early to catch rigid body modes, mechanisms, and modeling errors before dynamic analysis.",
     "https://portwooddigital.com/2026/01/27/why-your-eigenvalue-analysis-failed/"),
    ("ARPACK for Large Models",
     "ARPACK quickly finds a small number of eigenpairs for large models — ideal for Rayleigh damping setup.",
     "https://portwooddigital.com/2025/12/30/eigen-almost-hear-you-sigh/"),
    ("Tangent Stiffness Consistency",
     "Inconsistent tangent stiffness slows Newton-Raphson convergence — make sure element and material agree.",
     "https://portwooddigital.com/2025/08/10/a-model-of-inconsistency/"),
    ("Sparse Solver Selection",
     "UmfPack, Mumps, and SuperLU are better than BandGeneral for most real-world models.",
     "https://portwooddigital.com/2026/02/17/stop-cargo-culting-bandgeneral-and-plain-numberer/"),
    ("Matrix Bandwidth and Fill-In",
     "Equation numbering order determines bandwidth; RCM or AMD minimizes fill-in for sparse solvers.",
     "https://portwooddigital.com/2025/06/22/choose-your-own-topology/"),
    ("Testing OpenSees Models",
     "Use pytest to write repeatable assertions for node displacements, reactions, and member forces.",
     "https://portwooddigital.com/2025/08/30/how-to-use-pytest-with-opensees/"),
    ("Stiffness Matrix Export",
     "Use printA() to export the assembled stiffness matrix for debugging or external verification.",
     "https://portwooddigital.com/2025/07/27/bring-your-own-matrix/"),
    ("Load Step Size Matters",
     "Too large a load step can prevent convergence; too small wastes time. Start coarse, refine near peaks.",
     "https://portwooddigital.com/2025/11/30/ways-to-analyze-this/"),
    ("Surface Loads on Shell Elements",
     "Applying pressure loads to shell meshes requires computing equivalent nodal loads — not trivial.",
     "https://portwooddigital.com/2025/07/12/how-to-apply-surface-loads/"),
    ("Buckling with Eigenvalues",
     "OpenSees can do linear buckling analysis for shells and frames via an eigenvalue workaround.",
     "https://portwooddigital.com/2025/05/24/minimal-plate-buckling-example/"),
    ("P-Delta Effects",
     "Use '-PDelta' geometric transformation to capture gravity load effects on lateral stiffness.",
     "https://portwooddigital.com/2026/02/03/leaning-column/"),
    ("Profile Your Script",
     "pyinstrument and cProfile show where time goes in OpenSeesPy — look beyond just analyze() calls.",
     "https://portwooddigital.com/2024/12/22/how-to-profile-an-openseespy-analysis/"),
    ("Rigid Body Modes",
     "Rigid body modes in eigen() mean your model has unrestrained DOFs — check boundary conditions.",
     "https://portwooddigital.com/2026/01/27/why-your-eigenvalue-analysis-failed/"),
    ("Numerical Stability",
     "An invertible stiffness matrix does not guarantee a stable model — check condition numbers too.",
     "https://portwooddigital.com/2024/12/11/invertible-does-not-mean-stable/"),
    ("MVLEM Wall Elements",
     "MVLEM separates in-plane fiber response from out-of-plane plate behavior — know the assumptions.",
     "https://portwooddigital.com/2025/05/04/the-mechanically-separated-wall/"),
    ("Multi-Point Constraints",
     "Constraint handlers (Transformation, Penalty, Lagrange) differ in accuracy and numerical conditioning.",
     "https://portwooddigital.com/2025/10/26/daisy-chains-and-gaffes/"),
    ("Verify Before You Trust",
     "Always verify OpenSees results against hand calculations or textbook solutions for simple submodels.",
     "https://portwooddigital.com/2025/10/12/the-three-act-verification/"),
    ("Material Model Selection",
     "OpenSees has many concrete and steel models — Concrete01/02, Steel01/02 cover most common needs.",
     "https://portwooddigital.com/2025/12/07/concrete23andme/"),
    ("Dynamic Analysis Setup",
     "For dynamic analysis: set Rayleigh damping, choose a time integration scheme, and verify with eigen().",
     "https://portwooddigital.com/2025/12/30/eigen-almost-hear-you-sigh/"),
    ("Shear Frame Modeling",
     "Any shear frame can be modeled with simple springs and masses — even 40 stories with dampers.",
     "https://portwooddigital.com/2025/01/12/minimal-damper-example/"),
    ("Algorithm Selection for Convergence",
     "Try Newton, ModifiedNewton, BFGS, Broyden, or KrylovNewton depending on your problem type.",
     "https://portwooddigital.com/2025/11/30/ways-to-analyze-this/"),
    ("Local Axes for 3D Models",
     "In 3D models, verify element local axes orientation — rotated sections can give wrong results.",
     "https://portwooddigital.com/2025/09/21/rotated-local-axes/"),
    ("Contact Nonlinearity",
     "Gap and contact elements in OpenSees model surfaces that open and close during loading.",
     "https://portwooddigital.com/2025/10/19/positive-opensees-contact/"),
    ("Random Vibrations",
     "DiscretizedRandomProcess in OpenSees constructs stochastic time series for reliability analysis.",
     "https://portwooddigital.com/2025/09/28/minimal-random-process-example/"),
    ("Section Analysis with ZeroLength",
     "Load a ZeroLengthSection element to compute moment-curvature and shear-deformation response.",
     "https://portwooddigital.com/2025/03/29/section-warping-analysis/"),
    ("Distributed Plasticity",
     "Distributed plasticity with force-based elements captures hinge spread along member length.",
     "https://portwooddigital.com/2025/04/06/apples-and-oranges/"),
    ("Sensitivity Analysis (DDM)",
     "Direct differentiation gives response gradients with respect to model parameters for optimization.",
     "https://portwooddigital.com/2025/02/09/damping-is-a-sensitive-subject/"),
    ("Multiaxial Plasticity",
     "J2Plasticity handles 3D stress states for solid and shell elements — check shear yield carefully.",
     "https://portwooddigital.com/2025/01/05/j2-plasticity-parameters/"),
    ("Mesh Refinement",
     "Displacement-based elements need mesh refinement; force-based elements need integration point refinement.",
     "https://portwooddigital.com/2025/03/02/one-is-all-you-need/"),
    ("OpenSees on the Cloud",
     "Build and analyze OpenSees models in the cloud from any device with OpenSees Cloud.",
     "https://portwooddigital.com/"),
    ("Thermal Loading Workarounds",
     "OpenSees truss elements lack direct thermal loading — impose equivalent initial strains instead.",
     "https://portwooddigital.com/2026/03/03/more-than-one-way-to-heat-up-a-truss/"),
    ("Equivalent Nodal Loads",
     "Distributed element loads become nodal loads via numerical integration — more points = more accuracy.",
     "https://portwooddigital.com/2025/04/14/statically-equivalent-loads/"),
    ("Concrete Material Variants",
     "Concrete01 has no tensile strength; Concrete02 adds tension softening — pick based on your needs.",
     "https://portwooddigital.com/2025/12/07/concrete23andme/"),
    ("Penalty Method Constraints",
     "Penalty constraints use large stiffness values — too large causes ill-conditioning, too small causes drift.",
     "https://portwooddigital.com/2025/10/26/daisy-chains-and-gaffes/"),
    ("Corotational Mesh Strategy",
     "A corotational mesh of displacement-based elements handles combined material and geometric nonlinearity.",
     "https://portwooddigital.com/2025/03/02/one-is-all-you-need/"),
    ("Modal Damping",
     "Modal damping applies different damping ratios to different modes — more flexible than Rayleigh.",
     "https://portwooddigital.com/2025/12/30/eigen-almost-hear-you-sigh/"),
    ("Response Spectrum Analysis",
     "Compute natural frequencies with eigen(), then combine modal responses with CQC or SRSS.",
     "https://portwooddigital.com/2026/01/27/why-your-eigenvalue-analysis-failed/"),
    ("Time Series Options",
     "Path, Sine, Linear, Constant, and Pulse time series cover most loading patterns in OpenSees.",
     "https://portwooddigital.com/2025/09/28/minimal-random-process-example/"),
    ("Ground Motion Input",
     "Use Path time series with UniformExcitation to apply recorded ground motions at the base.",
     "https://portwooddigital.com/2025/09/28/minimal-random-process-example/"),
    ("Model Debugging Checklist",
     "Check reactions sum, run eigen for mechanisms, verify with simple loads before complex analysis.",
     "https://portwooddigital.com/2025/10/12/the-three-act-verification/"),
    ("Wipe Before Reuse",
     "Call wipe() to clear all model state before building a new model in the same script.",
     "https://portwooddigital.com/"),
]


def _next_tip_interval_seconds() -> float:
    """Rotate tips every 10s while waiting for the first stdout."""
    return 10.0


def _status_with_tip(headline: str, tip: Tuple[str, str, str]) -> str:
    title, body, url = tip
    return (
        f"{headline}\n"
        f"  [dim italic]Tip: {title}[/dim italic]\n"
        f"  [dim]{body}[/dim]\n"
        f"  [dim blue]{url}[/dim blue]"
    )


def _print_tip() -> None:
    title, tip, url = random.choice(_OPENSEES_TIPS)
    console.print(f"\n  [dim italic]Tip: {title}[/dim italic]")
    console.print(f"  [dim]{tip}[/dim]")
    console.print(f"  [dim blue]{url}[/dim blue]\n")


def _parse_params(
    raw: Optional[List[str]],
    params_file: Optional[Path],
) -> Optional[dict]:
    """Merge -p key=value pairs and --params-file into a single dict.

    Values are auto-coerced: int → int, float → float, JSON arrays → list,
    otherwise kept as str.  Returns None when no params are provided.
    """
    merged: dict = {}
    if params_file is not None:
        if not params_file.exists():
            console.print(f"[red]Params file not found: {params_file}[/red]")
            raise typer.Exit(1)
        try:
            loaded = json.loads(params_file.read_text())
        except (json.JSONDecodeError, ValueError) as e:
            console.print(f"[red]Invalid JSON in params file: {e}[/red]")
            raise typer.Exit(1)
        if not isinstance(loaded, dict):
            console.print("[red]Params file must contain a JSON object (not array). "
                          "Use -p for individual key=value pairs.[/red]")
            raise typer.Exit(1)
        merged.update(loaded)
    for item in raw or []:
        if "=" not in item:
            console.print(f"[red]Invalid param format: {item!r}  (expected key=value)[/red]")
            raise typer.Exit(1)
        key, _, val = item.partition("=")
        key = key.strip()
        val = val.strip()
        if not key:
            console.print(f"[red]Empty key in param: {item!r}[/red]")
            raise typer.Exit(1)
        # Auto-coerce value types
        if val.startswith("["):
            try:
                merged[key] = json.loads(val)
                continue
            except (json.JSONDecodeError, ValueError):
                pass
        try:
            merged[key] = int(val)
            continue
        except ValueError:
            pass
        try:
            merged[key] = float(val)
            continue
        except ValueError:
            pass
        merged[key] = val
    return merged or None


@app.command()
def submit(
    filename: str = typer.Argument(..., help="Local .py file or uploaded filename (e.g. Truss.py or ./Truss.py)"),
    timeout: int = typer.Option(
        120,
        "--timeout",
        "-t",
        help="Max runtime per task in seconds (cannot exceed your monthly runtime remaining)",
    ),
    count: int = typer.Option(1, "--count", "-n", help="Number of parallel tasks (default 1)"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for completion"),
    param: Optional[List[str]] = typer.Option(None, "--param", "-p", help="Parameter as key=value (repeatable). Script: from openseespy.cli_params import cli_params"),
    params_file: Optional[Path] = typer.Option(None, "--params-file", help="JSON file with parameters (object of key-value pairs)."),
):
    """Submit a simulation analysis.

    \b
    If a local file path is given, it is uploaded automatically.
    Use --count to run multiple tasks in parallel for parameter studies.
    Use --no-wait to return immediately; use 'ops run follow' to stream output.
    Use -p to pass parameters; load in script with: from openseespy.cli_params import cli_params

    \b
    Examples:
      ops run submit model.py                 Single-task analysis
      ops run submit model.py --count 100     100-task parallel analysis
      ops run submit model.py --no-wait       Submit without waiting
      ops run submit model.py -t 300          Set 300s timeout
      ops run submit model.py -p E=3000 -p A=10.0
      ops run submit model.py --params-file study.json
    """
    if count < 1:
        console.print("[red]--count must be at least 1.[/red]")
        raise typer.Exit(1)

    cli_params = _parse_params(param, params_file)

    entry_filename = filename
    local = Path(filename)
    if local.exists():
        if not local.is_file():
            console.print(f"[red]Not a file: {local}[/red]")
            raise typer.Exit(1)
        if not local.name.endswith(".py"):
            console.print("[red]Only .py files are supported.[/red]")
            raise typer.Exit(1)
        entry_filename = local.name
        console.print(f"Uploading local file [bold]{local}[/bold] as [bold]{entry_filename}[/bold]...")
        try:
            upload = api.post("/files/upload", {"path": entry_filename, "content_type": "text/x-python"})
            api.upload_file(upload["upload_url"], local.read_bytes(), content_type="text/x-python")
        except api.ApiError as e:
            console.print(f"[red]Upload failed: {e.message}[/red]")
            raise typer.Exit(1)
    if not entry_filename.endswith(".py"):
        console.print("[red]Only .py files are supported.[/red]")
        raise typer.Exit(1)

    count_label = f", {count} tasks" if count > 1 else ""
    console.print(f"Submitting [bold]{entry_filename}[/bold] (timeout {timeout}s{count_label})...")

    submit_body: dict = {"filename": entry_filename, "timeout": timeout}
    if count > 1:
        submit_body["count"] = count
    if cli_params:
        submit_body["params"] = cli_params

    try:
        r = api.post("/run/submit", submit_body)
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    if r.get("status") == "partial":
        available = r.get("available", 0)
        requested = r.get("requested", count)
        active = r.get("active", "?")
        max_conc = r.get("max_concurrent", "?")
        console.print(
            f"[yellow]Your concurrent task quota is {max_conc} "
            f"({active} currently running). "
            f"Only {available} of the {requested} requested tasks can start.[/yellow]"
        )
        if not typer.confirm(f"Submit {available} tasks instead?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)
        submit_body["count"] = available
        submit_body["confirmed"] = True
        try:
            r = api.post("/run/submit", submit_body)
        except api.ApiError as e:
            console.print(f"[red]{e.message}[/red]")
            raise typer.Exit(1)

    analysis_id = r.get("analysis_id") or r.get("run_id", "")
    task_id = r.get("task_id") or r.get("run_id", "")
    total_tasks = int(r.get("total_tasks", 1))
    dep_files = r.get("files", [])

    console.print(f"  Analysis: [dim]{analysis_id[:8]}[/dim]")
    if total_tasks > 1:
        console.print(f"  Tasks:    {total_tasks}")
    if len(dep_files) > 1:
        console.print(f"  Files:    {', '.join(dep_files)}")

    failed_inv = r.get("failed_invocations", 0)
    if failed_inv:
        console.print(f"  [red]{failed_inv} task(s) failed to start.[/red]")

    console.print("[green]Simulation submitted. Starting...[/green]")
    # With --wait, tips rotate every 10s on the status spinner (no duplicate here).
    if not wait:
        _print_tip()
    if total_tasks > 1:
        console.print(f"  [dim]Stream output: ops run follow {analysis_id[:8]}[/dim]")

    if wait and total_tasks == 1:
        _poll_and_stream(
            task_id,
            timeout,
            stdout_url=r.get("stdout_url", ""),
            result_url=r.get("result_url", ""),
        )
    elif wait and total_tasks > 1:
        _poll_analysis(analysis_id, timeout, total_tasks)


@app.command()
def follow(
    id: str = typer.Argument(..., help="Analysis or task ID"),
    task: Optional[int] = typer.Option(None, "--task", "-t", help="Task index to follow (0-based, for multi-task analyses)"),
):
    """Stream live output from a running analysis or task.

    \b
    For single-task analyses, streams that task's stdout in real time.
    For multi-task analyses, use --task to pick which task to follow
    (defaults to task 0).

    \b
    Examples:
      ops run follow abc12345            Follow a single-task analysis
      ops run follow abc12345 -t 2       Follow task 2 of a multi-task analysis
    """
    try:
        st = api.get("/run/status", {"id": id, "run_id": id, "tasks": "1"})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    total_tasks = int(st.get("total_tasks", 1))
    task_list = st.get("tasks", [])

    if total_tasks > 1 and task_list:
        idx = task if task is not None else 0
        if idx < 0 or idx >= total_tasks:
            console.print(f"[red]--task must be between 0 and {total_tasks - 1}.[/red]")
            raise typer.Exit(1)
        t = next((t for t in task_list if int(t.get("task_index", -1)) == idx), None)
        if not t:
            console.print(f"[red]Task {idx} not found in analysis.[/red]")
            raise typer.Exit(1)
        follow_tid = t.get("task_id") or t.get("run_id", "")
        console.print(f"[blue]Following task {idx} ({follow_tid[:8]})...[/blue]")
    else:
        follow_tid = st.get("task_id") or st.get("run_id") or id
        if total_tasks > 1:
            console.print(f"[blue]Following task 0 ({follow_tid[:8]})...[/blue]")

    status_val = st.get("status", "")
    if status_val in ("completed", "failed", "cancelled"):
        console.print(f"[dim]Task already {status_val}. Use 'ops run output {id}' to view output.[/dim]")
        return

    try:
        su = api.get("/run/stdout-url", {"id": follow_tid, "run_id": follow_tid})
        stdout_url = su.get("stdout_url", "")
    except api.ApiError:
        stdout_url = ""

    timeout = int(st.get("timeout", 120))
    _poll_and_stream(follow_tid, timeout, stdout_url=stdout_url)


@app.command()
def status(
    id: Optional[str] = typer.Argument(None, help="Analysis ID (omit to list running analyses)"),
    range_: Optional[str] = typer.Argument(None, help="Task range: index, start-end, or 'all'"),
):
    """Check analysis or task status.

    \b
    Examples:
      ops run status                     List all running analyses
      ops run status abc12345            Analysis summary
      ops run status abc12345 0          Status of task 0
      ops run status abc12345 0-9        Status of tasks 0 through 9
      ops run status abc12345 all        Status of all tasks
    """
    if id:
        query: dict = {"id": id, "run_id": id}
        if range_:
            query["tasks"] = "1"
            query["range"] = range_
        try:
            r = api.get("/run/status", query)
        except api.ApiError as e:
            console.print(f"[red]{e.message}[/red]")
            raise typer.Exit(1)
        _print_status(r)
        return

    try:
        r = api.get("/run/list", {"limit": 50})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    items = r.get("analyses") or r.get("runs") or []
    active = [a for a in items if a.get("status") in ("pending", "running")]
    if not active:
        console.print("[dim]No running analyses.[/dim]")
        return

    table = Table(show_header=True, title="Running analyses")
    table.add_column("Analysis", style="dim", max_width=8)
    table.add_column("Status")
    table.add_column("File")
    table.add_column("Tasks")
    table.add_column("Created")

    for a in active:
        aid = (a.get("analysis_id") or a.get("task_id") or a.get("run_id") or "")[:8]
        total = int(a.get("total_tasks", 1))
        if total > 1:
            completed = a.get("completed", 0)
            tasks_str = f"{completed}/{total}"
        else:
            tasks_str = "1"
        table.add_row(
            aid,
            _status_style(a.get("status", "")),
            a.get("filename", ""),
            tasks_str,
            _to_local(a.get("created_at", "")) if a.get("created_at") else "",
        )
    console.print(table)


@app.command()
def output(
    id: str = typer.Argument(..., help="Analysis ID"),
    range_: Optional[str] = typer.Argument(None, help="Task range: index, start-end, or 'all'"),
):
    """Show the printed output (stdout).

    \b
    Without a range, shows the output for a single-task analysis.
    With a range, shows per-task output for multi-task analyses.

    Examples:
      ops run output abc12345               Output for single-task analysis
      ops run output abc12345 0             Output from task 0
      ops run output abc12345 0-9           Output from tasks 0 through 9
      ops run output abc12345 all           Output from all tasks
    """
    query: dict = {"id": id, "run_id": id}
    if range_:
        query["range"] = range_
    try:
        r = api.get("/run/output", query)
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    if "tasks" in r:
        tasks = r["tasks"]
        total = int(r.get("total_tasks", len(tasks)))

        if not range_:
            console.print(f"[dim]Analysis has {total} tasks. Specify a range to see output.[/dim]")
            console.print(f"[dim]  ops run output {id[:8]} 0        Output from task 0[/dim]")
            console.print(f"[dim]  ops run output {id[:8]} 0-9      Output from tasks 0-9[/dim]")
            console.print(f"[dim]  ops run output {id[:8]} all      Output from all tasks[/dim]")
            return

        for t in tasks:
            idx = int(t.get("task_index", 0))
            tid = (t.get("task_id") or "")[:8]
            text = t.get("output", "")
            console.print(f"[bold]── Task ID: {idx} | {tid} (total {total} tasks) ──[/bold]")
            if text:
                console.print(text)
            else:
                console.print("[dim]No output.[/dim]")
            console.print()
        return

    text = r.get("output", "")
    if text:
        console.print(text)
    else:
        console.print("[dim]No output available yet.[/dim]")



def _print_stats(
    res: dict,
    runtime_seconds: Optional[float] = None,
) -> None:
    """Format task execution stats."""
    rc = res.get("return_code", None)
    if rc is not None:
        rc_str = "[green]0[/green]" if rc == 0 else f"[red]{rc}[/red]"
        console.print(f"  Return code:  {rc_str}")
    if res.get("error"):
        console.print(f"  Error:        [red]{res['error']}[/red]")
    task_id = res.get("task_id") or res.get("run_id", "")
    if task_id:
        console.print(f"  Task ID:      [dim]{task_id}[/dim]")
    entry = res.get("entry_relpath", "")
    if entry:
        console.print(f"  Entry:        {entry}")
    if runtime_seconds is not None and runtime_seconds >= 0:
        console.print(f"  Runtime:      {runtime_seconds:.2f}s")
    ram = res.get("ram_peak_kb")
    if ram is not None:
        console.print(f"  RAM peak:     {ram:,} KB")


@app.command()
def stats(
    id: str = typer.Argument(..., help="Analysis ID"),
    range_: Optional[str] = typer.Argument(None, help="Task range: index, start-end, or 'all'"),
):
    """Show task execution stats (return code, runtime, RAM, etc.).

    \b
    Without a range, shows stats for a single-task analysis.
    With a range, shows per-task stats for multi-task analyses.

    Examples:
      ops run stats abc12345               Stats for single-task analysis
      ops run stats abc12345 0             Stats from task 0
      ops run stats abc12345 0-9           Stats from tasks 0 through 9
      ops run stats abc12345 all           Stats from all tasks
    """
    query: dict = {"id": id, "run_id": id}
    if range_:
        query["range"] = range_
    try:
        r = api.get("/run/result", query)
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    if "tasks" in r:
        tasks = r["tasks"]
        total = int(r.get("total_tasks", len(tasks)))

        if not range_:
            console.print(f"[dim]Analysis has {total} tasks. Specify a range to see stats.[/dim]")
            console.print(f"[dim]  ops run stats {id[:8]} 0        Stats from task 0[/dim]")
            console.print(f"[dim]  ops run stats {id[:8]} 0-9      Stats from tasks 0-9[/dim]")
            console.print(f"[dim]  ops run stats {id[:8]} all      Stats from all tasks[/dim]")
            return

        for t in tasks:
            idx = int(t.get("task_index", 0))
            tid = (t.get("task_id") or "")[:8]
            res = t.get("result")
            console.print(f"[bold]── Task ID: {idx} | {tid} (total {total} tasks) ──[/bold]")
            if res is None:
                console.print("[dim]No result available.[/dim]")
            else:
                _print_stats(res, runtime_seconds=t.get("runtime_seconds"))
            console.print()
        return

    res = r.get("result")
    if res is None:
        console.print("[dim]No result available yet.[/dim]")
    else:
        _print_stats(res, runtime_seconds=r.get("runtime_seconds"))


@app.command()
def cancel(id: str = typer.Argument(..., help="Analysis or task ID")):
    """Cancel a pending or running analysis or task.

    \b
    Examples:
      ops run cancel abc12345    Cancel entire analysis (all tasks)
      ops run cancel d4e5f6a7    Cancel a single task
    """
    try:
        r = api.post("/run/cancel", {"id": id, "run_id": id})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    cancelled = r.get("cancelled")
    if cancelled is not None and cancelled > 1:
        console.print(f"[yellow]Cancelled {cancelled} tasks in analysis {id[:8]}...[/yellow]")
    else:
        console.print(f"[yellow]Cancelled {id[:8]}...[/yellow]")


@app.command()
def clear(
    id: Optional[str] = typer.Argument(None, help="Analysis or task ID (omit to use time range)"),
    before: Optional[str] = typer.Option(None, "--before", "-b", help="Clear analyses created before this date (YYYY-MM-DD or ISO 8601)"),
    after: Optional[str] = typer.Option(None, "--after", "-a", help="Clear analyses created after this date (YYYY-MM-DD or ISO 8601)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Delete completed analyses and their data.

    \b
    Clear a single analysis by ID, or clear analyses in a time range.

    Examples:
      ops run clear abc12345                            Clear an analysis (all tasks)
      ops run clear --before 2025-01-01                 Clear analyses before a date
      ops run clear --after 2025-06-01                  Clear analyses after a date
      ops run clear --before 2025-03-01 --after 2025-01-01
      ops run clear --before 2025-01-01 -y              Skip confirmation
    """
    if not id and not before and not after:
        console.print("Provide an analysis/task ID, --before, --after, or a combination.\n")
        console.print("[dim]Examples:[/dim]")
        console.print("  [dim]ops run clear abc12345[/dim]                            Clear an analysis")
        console.print("  [dim]ops run clear --before 2025-01-01[/dim]                 Clear before a date")
        console.print("  [dim]ops run clear --after 2025-06-01[/dim]                  Clear after a date")
        console.print("  [dim]ops run clear --before 2025-03-01 --after 2025-01-01[/dim]")
        console.print("  [dim]ops run clear --before 2025-01-01 -y[/dim]              Skip confirmation")
        raise typer.Exit(0)

    if before:
        before = _normalize_date(before)
    if after:
        after = _normalize_date(after)

    if id:
        try:
            r = api.get("/run/status", {"id": id, "run_id": id})
        except api.ApiError as e:
            console.print(f"[red]{e.message}[/red]")
            raise typer.Exit(1)

        total_tasks = int(r.get("total_tasks", 1))
        desc = f"analysis {id[:8]} ({total_tasks} task{'s' if total_tasks > 1 else ''})" if total_tasks > 1 else f"task {id[:8]}"

        if not yes:
            if not typer.confirm(f"\nClear {desc}? This cannot be undone"):
                console.print("[dim]Cancelled.[/dim]")
                raise typer.Exit(0)

        try:
            r = api.post("/run/clear", {"id": id, "run_id": id})
        except api.ApiError as e:
            console.print(f"[red]{e.message}[/red]")
            raise typer.Exit(1)

        cleared = r.get("cleared", 0)
        console.print(f"[green]Cleared {cleared} task{'s' if cleared != 1 else ''}.[/green]")
        return

    # Time range
    try:
        r = api.get("/run/list", {"limit": 50})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    targets = []
    for a in (r.get("analyses") or r.get("runs") or []):
        if a.get("status") in ("pending", "running"):
            continue
        created = a.get("created_at", "")
        if before and created >= before:
            continue
        if after and created <= after:
            continue
        targets.append(a)

    if not targets:
        console.print("[dim]No analyses matched.[/dim]")
        raise typer.Exit(0)

    table = Table(show_header=True, title=f"Analyses to clear ({len(targets)})")
    table.add_column("Analysis", style="dim", max_width=8)
    table.add_column("Status")
    table.add_column("File")
    table.add_column("Tasks")
    table.add_column("Created")
    for a in targets:
        table.add_row(
            (a.get("analysis_id") or a.get("task_id") or a.get("run_id") or "")[:8],
            _status_style(a.get("status", "")),
            a.get("filename", ""),
            str(a.get("total_tasks", 1)),
            _to_local(a.get("created_at", "")) if a.get("created_at") else "",
        )
    console.print(table)

    if not yes:
        if not typer.confirm(f"\nClear {len(targets)} analysis/analyses? This cannot be undone"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    total_cleared = 0
    for a in targets:
        aid = a.get("analysis_id") or a.get("task_id") or a.get("run_id") or ""
        if not aid:
            continue
        try:
            r = api.post("/run/clear", {"id": aid, "run_id": aid})
            total_cleared += r.get("cleared", 0)
        except api.ApiError:
            pass

    console.print(f"[green]Cleared {total_cleared} task{'s' if total_cleared != 1 else ''}.[/green]")


def _week_range(week: int) -> tuple[datetime, datetime]:
    """Return (start, end) UTC datetimes for a given ISO week number.

    week=0 means the current week; 1-52 refers to that week of the current year.
    """
    now = datetime.now().astimezone()
    year = now.year

    if week == 0:
        monday = now - timedelta(days=now.weekday())
        start = monday.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7)
    else:
        if week < 1 or week > 52:
            console.print("[red]--week must be 0 (this week) or 1-52.[/red]")
            raise typer.Exit(1)
        start = datetime.strptime(f"{year}-W{week:02d}-1", "%G-W%V-%u").replace(
            tzinfo=now.tzinfo
        )
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7)

    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


def _month_range(month: int) -> tuple[datetime, datetime]:
    """Return (start, end) UTC datetimes for a given month.

    month=0 means the current month; 1-12 refers to that month of the current year.
    """
    now = datetime.now().astimezone()
    year = now.year

    if month == 0:
        month = now.month

    if month < 1 or month > 12:
        console.print("[red]--month must be 0 (this month) or 1-12.[/red]")
        raise typer.Exit(1)

    start = datetime(year, month, 1, tzinfo=now.tzinfo)
    start = start.replace(hour=0, minute=0, second=0, microsecond=0)
    if month == 12:
        end = datetime(year + 1, 1, 1, tzinfo=now.tzinfo)
    else:
        end = datetime(year, month + 1, 1, tzinfo=now.tzinfo)
    end = end.replace(hour=0, minute=0, second=0, microsecond=0)

    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


def _normalize_date(s: str) -> str:
    from datetime import datetime, timezone
    s = s.strip()
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.astimezone()
        return dt.astimezone(timezone.utc).isoformat()
    except ValueError:
        pass
    try:
        dt = datetime.strptime(s, "%Y-%m-%d").astimezone()
        return dt.astimezone(timezone.utc).isoformat()
    except ValueError:
        console.print(f"[red]Invalid date format: {s}. Use YYYY-MM-DD or ISO 8601.[/red]")
        raise typer.Exit(1)


@app.command()
def data(
    id: str = typer.Argument(..., help="Analysis ID"),
    range_: Optional[str] = typer.Argument(None, help="Task range: index, start-end, or 'all'"),
    download: Optional[str] = typer.Option(None, "--download", "-d", help="Download a specific file by path"),
    output_dir: str = typer.Option(".", "--output", "-o", help="Directory to save downloaded file"),
):
    """List or download data files (output, results, artifacts).

    \b
    Without a range, shows a data summary for the analysis.
    With a range, shows per-task data files.

    Examples:
      ops run data abc12345                 Data summary for analysis
      ops run data abc12345 0              List data from task 0
      ops run data abc12345 0-9            List data from tasks 0-9
      ops run data abc12345 all            List data from all tasks
      ops run data abc12345 all -d .       Download all files (all tasks)
      ops run data abc12345 0 -d result    Download result.json from task 0
    """
    query: dict = {"id": id, "run_id": id}
    if range_:
        query["range"] = range_
    elif download:
        query["range"] = "all"
    try:
        r = api.get("/run/data", query)
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    if "tasks" in r:
        _print_multi_task_data(r, download, output_dir, has_range=range_ is not None)
        return

    files = r.get("files", [])

    if download:
        matches = _resolve_download(files, download)
        if not matches:
            console.print(f"[red]No match for '{download}'[/red]")
            console.print(f"Available: {', '.join(f['path'] for f in files)}")
            raise typer.Exit(1)
        _download_files(matches, output_dir)
        return

    if not files:
        console.print("[dim]No data files for this task.[/dim]")
        return

    table = Table(show_header=True)
    table.add_column("Path")
    table.add_column("Size", justify="right")
    table.add_column("Modified")

    for f in files:
        table.add_row(
            f["path"],
            _fmt_bytes(f["size"]),
            _to_local(f["last_modified"]) if f.get("last_modified") else "",
        )

    console.print(table)
    total = sum(f["size"] for f in files)
    task_id = r.get("task_id") or id
    console.print(f"\n  Task [dim]{task_id[:8]}[/dim]: [bold]{len(files)}[/bold] files, [bold]{_fmt_bytes(total)}[/bold] total")
    console.print(f"  [dim]Download with: ops run data {task_id[:8]} -d <path>[/dim]")


def _print_multi_task_data(
    r: dict, download: Optional[str], output_dir: str,
    *, has_range: bool = False,
) -> None:
    """Display or download data from tasks in a multi-task analysis."""
    tasks_data = r.get("tasks", [])
    total = int(r.get("total_tasks", len(tasks_data)))
    analysis_id = (r.get("analysis_id") or "")[:8]

    if download:
        all_files = []
        for t in tasks_data:
            idx = int(t.get("task_index", 0))
            tid = (t.get("task_id") or "")[:8]
            for f in t.get("files", []):
                f_copy = dict(f)
                f_copy["path"] = f"task_{idx}_{tid}/{f['path']}"
                all_files.append(f_copy)
        matches = _resolve_download(all_files, download)
        if not matches:
            console.print(f"[red]No match for '{download}'[/red]")
            raise typer.Exit(1)
        _download_files(matches, output_dir)
        return

    if not has_range:
        console.print(f"  Analysis: [dim]{analysis_id}[/dim]")
        console.print(f"  Tasks:    {total}")
        console.print()
        console.print(f"[dim]  ops run data {analysis_id} 0        Data from task 0[/dim]")
        console.print(f"[dim]  ops run data {analysis_id} 0-9      Data from tasks 0-9[/dim]")
        console.print(f"[dim]  ops run data {analysis_id} all      Data from all tasks[/dim]")
        return

    grand_files = 0
    grand_bytes = 0
    for t in tasks_data:
        idx = int(t.get("task_index", 0))
        tid = (t.get("task_id") or "")[:8]
        files = t.get("files", [])
        task_bytes = sum(f["size"] for f in files)
        grand_files += len(files)
        grand_bytes += task_bytes

        if not files:
            console.print(f"[bold]Task ID: {idx} | {tid}[/bold] (total {total} tasks): [dim]no files[/dim]")
            continue

        table = Table(show_header=True, title=f"Task ID: {idx} | {tid} (total {total} tasks)")
        table.add_column("Path")
        table.add_column("Size", justify="right")
        table.add_column("Modified")
        for f in files:
            table.add_row(
                f["path"],
                _fmt_bytes(f["size"]),
                _to_local(f["last_modified"]) if f.get("last_modified") else "",
            )
        console.print(table)
        console.print()

    console.print(
        f"  Analysis [dim]{analysis_id}[/dim]: "
        f"[bold]{len(tasks_data)}[/bold] tasks shown, "
        f"[bold]{grand_files}[/bold] files, "
        f"[bold]{_fmt_bytes(grand_bytes)}[/bold] total"
    )


@app.command("list", cls=_BareDefaultCommand)
def list_analyses(
    limit: int = typer.Option(20, "--limit", "-n", help="Max number of analyses to show"),
    after: Optional[str] = typer.Option(None, "--after", help="Show analyses after date (YYYY-MM-DD)"),
    before: Optional[str] = typer.Option(None, "--before", help="Show analyses before date (YYYY-MM-DD)"),
    week: Optional[int] = typer.Option(None, "--week", "-w", min=0, max=52,
        help="Filter by week (1-52, or omit number for this week)"),
    month: Optional[int] = typer.Option(None, "--month", "-m", min=0, max=12,
        help="Filter by month (1-12, or omit number for this month)"),
    all_: bool = typer.Option(False, "--all", "-a", help="Show all analyses (not just today)"),
):
    """List your recent analyses.

    \b
    By default, shows today's analyses only.
    Use --week, --month, --after, --before, or --all to adjust the range.

    \b
    Examples:
      ops run list                                   Today's analyses
      ops run list --week                            This week's analyses
      ops run list --week 10                         Week 10 of the current year
      ops run list --month                           This month's analyses
      ops run list --month 2                         February's analyses
      ops run list --after 2026-03-10                After a date
      ops run list --before 2026-03-15               Before a date
      ops run list --all                             All analyses
    """
    try:
        r = api.get("/run/list", {"limit": limit})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    items = r.get("analyses") or r.get("runs") or []

    after_dt = None
    before_dt = None

    if week is not None:
        after_dt, before_dt = _week_range(week)
    elif month is not None:
        after_dt, before_dt = _month_range(month)
    elif after:
        try:
            after_dt = datetime.strptime(after, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            console.print("[red]Invalid --after date. Use YYYY-MM-DD.[/red]")
            raise typer.Exit(1)
    elif not all_ and not before:
        local_now = datetime.now().astimezone()
        after_dt = local_now.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc)

    if before and week is None and month is None:
        try:
            before_dt = datetime.strptime(before, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            console.print("[red]Invalid --before date. Use YYYY-MM-DD.[/red]")
            raise typer.Exit(1)

    total_count = len(items)
    if after_dt or before_dt:
        filtered = []
        for a in items:
            created = a.get("created_at", "")
            if after_dt and created < after_dt.isoformat():
                continue
            if before_dt and created >= before_dt.isoformat():
                continue
            filtered.append(a)
        items = filtered

    if not items:
        if week is not None:
            console.print("[dim]No analyses found for that week.[/dim]")
        elif month is not None:
            console.print("[dim]No analyses found for that month.[/dim]")
        elif after_dt and not after and not before:
            console.print("[dim]No analyses today. Use --all, --week, --month, or --after/--before to adjust range.[/dim]")
        else:
            console.print("[dim]No analyses found.[/dim]")
        return

    table = Table(show_header=True)
    table.add_column("Analysis", style="dim", max_width=8)
    table.add_column("Status")
    table.add_column("File")
    table.add_column("Tasks")
    table.add_column("Runtime", justify="right")
    table.add_column("Size", justify="right")
    table.add_column("Created")

    for a in items:
        aid = (a.get("analysis_id") or a.get("task_id") or a.get("run_id") or "")[:8]
        total = int(a.get("total_tasks", 1))

        status_str = _status_style(a.get("status", ""))
        if total > 1:
            completed = a.get("completed")
            if completed is not None:
                tasks_str = f"{completed}/{total}"
                failed = a.get("failed", 0)
                if failed:
                    tasks_str += f" ({failed} fail)"
            else:
                tasks_str = str(total)
        else:
            tasks_str = "1"

        rt = a.get("runtime")
        rt_str = f"{rt:.2f}s" if rt is not None else ""
        size = a.get("size", 0)
        created = _to_local(a.get("created_at", "")) if a.get("created_at") else ""

        table.add_row(
            aid,
            status_str,
            a.get("filename", ""),
            tasks_str,
            rt_str,
            _fmt_bytes(size) if size else "",
            created,
        )

    console.print(table)

    if (after_dt or before_dt) and total_count > len(items):
        hidden = total_count - len(items)
        console.print(f"[dim]{hidden} analyses not shown. Use --all, --week, --month, or --after/--before to adjust range.[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_download(files: list, pattern: str) -> list:
    exact = [f for f in files if f["path"] == pattern]
    if exact:
        return exact
    folder = pattern.rstrip("/") + "/"
    folder_matches = [f for f in files if f["path"].startswith(folder)]
    if folder_matches:
        return folder_matches
    partial = [f for f in files if pattern in f["path"]]
    if len(partial) == 1:
        return partial
    if len(partial) > 1:
        console.print(f"[red]Ambiguous match for '{pattern}':[/red]")
        for f in partial:
            console.print(f"  {f['path']}")
        raise typer.Exit(1)
    return []


def _download_files(matches: list, output_dir: str) -> None:
    import httpx
    from pathlib import Path
    from rich.progress import Progress, BarColumn, DownloadColumn, TransferSpeedColumn

    total_size = sum(f.get("size", 0) for f in matches)
    multi = len(matches) > 1
    with Progress(
        "[progress.description]{task.description}",
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        console=console,
        disable=(total_size < 100 * 1024 and not multi),
    ) as progress:
        overall = progress.add_task("Total", total=total_size) if multi else None
        for f in matches:
            fpath = f["path"]
            fsize = f.get("size", 0)
            local = Path(output_dir) / fpath
            local.parent.mkdir(parents=True, exist_ok=True)
            task = progress.add_task(fpath, total=fsize or None)
            try:
                with httpx.stream("GET", f["download_url"], timeout=60.0, follow_redirects=True) as stream:
                    stream.raise_for_status()
                    with open(local, "wb") as out:
                        for chunk in stream.iter_bytes(chunk_size=8192):
                            out.write(chunk)
                            progress.advance(task, len(chunk))
                            if overall is not None:
                                progress.advance(overall, len(chunk))
            except Exception as e:
                console.print(f"[red]Failed to download {fpath}: {e}[/red]")
                continue
            if not multi:
                console.print(f"[green]Downloaded {fpath} -> {local} ({_fmt_bytes(local.stat().st_size)})[/green]")
    if multi:
        console.print(f"[green]Downloaded {len(matches)} files to {output_dir}/[/green]")


def _status_style(s: str) -> str:
    styles = {
        "pending": "[dim]pending[/dim]",
        "running": "[blue]running[/blue]",
        "completed": "[green]completed[/green]",
        "failed": "[red]failed[/red]",
        "cancelled": "[yellow]cancelled[/yellow]",
        "partial_failure": "[red]partial failure[/red]",
    }
    return styles.get(s, s)


def _print_status(r: dict) -> None:
    """Print analysis summary, per-task list, or individual task detail."""
    # Multi-task analysis
    if "total_tasks" in r and int(r.get("total_tasks", 1)) > 1 and "completed" in r:
        analysis_id = r.get("analysis_id", "")
        console.print(f"  Analysis: [dim]{analysis_id}[/dim]")
        console.print(f"  File:     {r.get('filename', '')}")
        total = r["total_tasks"]
        completed = r.get("completed", 0)
        failed = r.get("failed", 0)
        running = r.get("running", 0)
        console.print(f"  Tasks:    {completed}/{total} completed", end="")
        if failed:
            console.print(f", [red]{failed} failed[/red]", end="")
        if running:
            console.print(f", [blue]{running} running[/blue]", end="")
        console.print()
        if r.get("runtime") is not None:
            console.print(f"  Runtime:  {r['runtime']:.2f}s")
        if r.get("size"):
            console.print(f"  Size:     {_fmt_bytes(r['size'])}")
        if r.get("created_at"):
            console.print(f"  Created:  {_to_local(r['created_at'])}")

        task_list = r.get("tasks")
        if task_list:
            console.print()
            for t in task_list:
                idx = int(t.get("task_index", 0))
                tid = (t.get("task_id") or "")[:8]
                st = _status_style(t.get("status", ""))
                line = f"  Task {idx} | {tid}  {st}"
                rc = t.get("return_code")
                if rc is not None:
                    line += f"  rc={rc}"
                rt = t.get("runtime_seconds")
                if rt is not None and rt >= 0:
                    line += f"  {rt:.2f}s"
                err = t.get("error_message")
                if err:
                    line += f"  [red]{err[:50]}[/red]"
                console.print(line)
        return

    # Single task detail
    task_id = r.get("task_id") or r.get("run_id", "")
    analysis_id = r.get("analysis_id") or r.get("run_id", "")
    total_tasks = int(r.get("total_tasks", 1))

    if total_tasks > 1:
        console.print(f"  Task:     [dim]{task_id}[/dim]")
        console.print(f"  Analysis: [dim]{analysis_id}[/dim]")
        console.print(f"  Index:    {int(r.get('task_index', 0))} / {total_tasks}")
    else:
        console.print(f"  Analysis: [dim]{analysis_id}[/dim]")

    console.print(f"  Status:   {_status_style(r.get('status', ''))}")
    if r.get("filename"):
        console.print(f"  File:     {r['filename']}")
    if r.get("created_at"):
        console.print(f"  Created:  {_to_local(r['created_at'])}")
    if r.get("started_at"):
        console.print(f"  Started:  {_to_local(r['started_at'])}")
    if r.get("completed_at"):
        console.print(f"  Finished: {_to_local(r['completed_at'])}")
    rt = r.get("runtime_seconds")
    if rt is not None and rt >= 0:
        console.print(f"  Runtime:  {rt:.2f}s")
    if r.get("return_code") is not None:
        console.print(f"  Return:   {r['return_code']}")
    if r.get("error_message"):
        console.print(f"  Error:    [red]{r['error_message']}[/red]")



def _analysis_spinner_headline(
    completed: int, total_tasks: int, failed: int, running: int
) -> str:
    return (
        f"[blue]{completed}/{total_tasks} completed"
        + (f", [red]{failed} failed[/red]" if failed else "")
        + (f", {running} running" if running else "")
        + "[/blue]"
    )


def _stdout_delta_from_snapshot(prev: bytes, new: bytes) -> bytes:
    """Compute new stdout bytes to display when S3 is overwritten with a rolling tail.

    The simulation uploads only the last N KB of stdout (see ``tail_buf`` in
    ``opensees_simulation.py``), replacing the object each flush — not append-only.
    Incremental Range reads by byte offset are wrong; we always fetch the full
    object and diff using suffix/prefix overlap with the last snapshot.
    """
    if not new:
        return b""
    if not prev:
        return new
    if new.startswith(prev):
        return new[len(prev) :]
    if prev.startswith(new):
        return b""
    max_k = min(len(prev), len(new))
    for k in range(max_k, 0, -1):
        if prev[-k:] == new[:k]:
            return new[k:]
    return new


def _fetch_stdout_snapshot(stdout_url: str) -> bytes:
    """Fetch the full S3 stdout object (not a range)."""
    data, _ = api.fetch_s3_range(stdout_url, start_byte=0)
    return data or b""


def _drain_stdout_until_stable(stdout_url: str, last_snapshot: bytes) -> bytes:
    """Print any late S3 stdout below the status line (append only, no cursor tricks)."""
    snap = last_snapshot
    idle = 0
    max_idle = 15
    while idle < max_idle:
        new_snap = _fetch_stdout_snapshot(stdout_url)
        if new_snap:
            delta = _stdout_delta_from_snapshot(snap, new_snap)
            if delta:
                console.print(
                    delta.decode("utf-8", errors="replace"),
                    end="",
                    highlight=False,
                )
                snap = new_snap
                idle = 0
                continue
        idle += 1
        time.sleep(0.2)
    return snap


def _poll_and_stream(
    task_id: str,
    timeout: int,
    stdout_url: str = "",
    result_url: str = "",
) -> None:
    """Stream task output in real time and wait for completion.

    Phase 1 — Waiting: Show a spinner with rotating tips until the first
    stdout bytes arrive from S3.
    Phase 2 — Streaming: Kill the spinner entirely and print stdout directly
    to the terminal (no Rich live display). Only poll status + stdout.
    As soon as the task is terminal, print ``Completed successfully.`` / failure /
    cancelled / timeout **before** the final drain.     A dim line explains we are fetching any remaining log; late S3 stdout is
    printed **below** that (no cursor manipulation).

    Phase 2 polls ``/run/status`` each loop (~0.25s between loops), with status
    checked *before* sleep so we do not wait an extra second before noticing completion.
    """
    console.print()
    last_snapshot = b""
    # Phase 1: gentle poll while waiting for first stdout (tips + API load).
    poll_interval = 1.0
    # Phase 2: check status *before* sleeping so the green line appears as soon as
    # the API reports completion (not after an extra 1s sleep + throttled status).
    phase2_poll = 0.25
    max_wait = timeout + 60
    waited = 0.0
    status_check_interval = 1.0
    last_status_check = 0.0
    task_status = "running"

    # --- Phase 1: spinner with tips until first stdout ---
    current_tip: Tuple[str, str, str] = random.choice(_OPENSEES_TIPS)
    next_tip_at = time.monotonic() + _next_tip_interval_seconds()
    run_headline = "[blue]Waiting for task to start...[/blue]"

    with console.status(
        _status_with_tip(run_headline, current_tip), spinner="dots"
    ) as spinner:
        while waited < max_wait:
            time.sleep(poll_interval)
            waited += poll_interval

            if time.monotonic() >= next_tip_at:
                current_tip = random.choice(_OPENSEES_TIPS)
                next_tip_at = time.monotonic() + _next_tip_interval_seconds()
                spinner.update(_status_with_tip(run_headline, current_tip))

            if stdout_url:
                new_snap = _fetch_stdout_snapshot(stdout_url)
                if new_snap:
                    spinner.stop()
                    console.print(
                        new_snap.decode("utf-8", errors="replace"),
                        end="",
                        highlight=False,
                    )
                    last_snapshot = new_snap
                    break  # move to phase 2

            if waited - last_status_check >= status_check_interval:
                last_status_check = waited
                task_status = _check_task_status(task_id)

            if task_status in ("completed", "failed", "cancelled"):
                spinner.stop()
                break

    # --- Phase 2: no spinner; status checked every loop *before* sleep (fast green line)
    while waited < max_wait and task_status not in ("completed", "failed", "cancelled"):
        task_status = _check_task_status(task_id)
        if task_status in ("completed", "failed", "cancelled"):
            break

        if stdout_url:
            new_snap = _fetch_stdout_snapshot(stdout_url)
            if new_snap:
                delta = _stdout_delta_from_snapshot(last_snapshot, new_snap)
                if delta:
                    console.print(
                        delta.decode("utf-8", errors="replace"),
                        end="",
                        highlight=False,
                    )
                last_snapshot = new_snap

        time.sleep(phase2_poll)
        waited += phase2_poll

    # --- Status line first (fast feedback), then any late S3 stdout ---
    console.print()
    if task_status == "completed":
        console.print("[green]Completed successfully.[/green]")
    elif task_status == "failed":
        console.print("[red]Failed.[/red]")
    elif task_status == "cancelled":
        console.print("[yellow]Cancelled.[/yellow]")
    else:
        console.print("[yellow]Timed out waiting. Use 'ops run status' to check later.[/yellow]")

    if stdout_url:
        console.print(
            "  [dim]Fetching any remaining log output…[/dim]"
        )
        _drain_stdout_until_stable(stdout_url, last_snapshot)


def _check_task_status(task_id: str) -> str:
    """Poll the API for task status, returning the status string."""
    try:
        st = api.get("/run/status", {"id": task_id, "run_id": task_id, "tasks": "1"})
        status = st.get("status", "")
        if not status and st.get("tasks"):
            for tk in st["tasks"]:
                tid = tk.get("task_id") or tk.get("run_id", "")
                if task_id.startswith(tid) or tid.startswith(task_id):
                    status = tk.get("status", "")
                    break
        if not status and "completed" in st:
            done = int(st.get("completed", 0)) + int(st.get("failed", 0))
            if done >= int(st.get("total_tasks", 1)):
                status = "completed" if int(st.get("failed", 0)) == 0 else "failed"
        return status or "running"
    except api.ApiError:
        return "running"


def _poll_analysis(analysis_id: str, timeout: int, total_tasks: int) -> None:
    """Poll analysis status and show progress until all tasks complete."""
    console.print()
    poll_interval = 3.0
    max_wait = timeout + 120
    waited = 0.0
    last_completed = 0
    current_tip: Tuple[str, str, str] = random.choice(_OPENSEES_TIPS)
    next_tip_at = time.monotonic() + _next_tip_interval_seconds()
    initial_headline = f"[blue]Running {total_tasks} tasks...[/blue]"

    with console.status(
        _status_with_tip(initial_headline, current_tip), spinner="dots"
    ) as spinner:
        while waited < max_wait:
            time.sleep(poll_interval)
            waited += poll_interval

            try:
                st = api.get("/run/status", {"id": analysis_id, "run_id": analysis_id})
            except api.ApiError:
                continue

            completed = int(st.get("completed", 0))
            failed = int(st.get("failed", 0))
            running = int(st.get("running", 0))
            done = completed + failed

            headline = _analysis_spinner_headline(
                completed, total_tasks, failed, running
            )

            tip_rotated = False
            if time.monotonic() >= next_tip_at:
                current_tip = random.choice(_OPENSEES_TIPS)
                next_tip_at = time.monotonic() + _next_tip_interval_seconds()
                tip_rotated = True

            if completed != last_completed or failed:
                spinner.update(_status_with_tip(headline, current_tip))
                last_completed = completed
            elif tip_rotated:
                spinner.update(_status_with_tip(headline, current_tip))

            if done >= total_tasks:
                spinner.stop()
                console.print()
                if failed == 0:
                    console.print(
                        f"[green]Analysis completed: {completed}/{total_tasks} tasks succeeded.[/green]"
                    )
                else:
                    console.print(
                        f"[red]Analysis finished: {completed} succeeded, {failed} failed "
                        f"(of {total_tasks}).[/red]"
                    )
                    console.print(
                        f"  [dim]View failures: ops run status {analysis_id[:8]} --failed[/dim]"
                    )
                return

    console.print(
        f"[yellow]Timed out waiting ({total_tasks - last_completed} tasks still running). "
        f"Use 'ops run status {analysis_id[:8]}' to check later.[/yellow]"
    )
