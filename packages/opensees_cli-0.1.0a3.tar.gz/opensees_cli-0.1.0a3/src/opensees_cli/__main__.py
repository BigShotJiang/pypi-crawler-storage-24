"""Allow ``python -m opensees_cli`` as a fallback when ``ops`` is not on PATH."""

from opensees_cli.main import app

app()
