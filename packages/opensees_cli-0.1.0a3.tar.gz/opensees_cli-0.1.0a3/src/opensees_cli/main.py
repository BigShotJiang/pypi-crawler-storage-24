"""OpenSees CLI entry point."""

import click
import typer
from rich.console import Console

from opensees_cli import __version__
from opensees_cli.auth import app as auth_app, print_me, print_quota
from opensees_cli.admin import app as admin_app
from opensees_cli.run import app as run_app
from opensees_cli.files import app as files_app
from opensees_cli import api, config
from opensees_cli.path_setup import ensure_path

console = Console()

app = typer.Typer(
    name="ops",
    help="Run OpenSees simulations in the cloud.",
    add_completion=False,
    invoke_without_command=True,
)

app.add_typer(auth_app, name="auth")
app.add_typer(run_app, name="run")
app.add_typer(files_app, name="files")
app.add_typer(admin_app, name="admin", hidden=not config.is_admin())


def _add_help_command(typer_app: typer.Typer) -> None:
    """Add a 'help' command that prints the same output as --help."""
    @typer_app.command("help", hidden=True)
    def help_cmd(ctx: typer.Context):
        """Show help."""
        parent = ctx.parent
        if parent:
            click.echo(parent.get_help())
        raise typer.Exit()


_add_help_command(app)
_add_help_command(auth_app)
_add_help_command(run_app)
_add_help_command(files_app)
_add_help_command(admin_app)


def _is_logged_in() -> bool:
    creds = config.load_credentials()
    return bool(creds and creds.get("access_token"))


def _print_help() -> None:
    logged_in = _is_logged_in()
    console.print(f"[bold]ops[/bold] — OpenSees cloud CLI (v{__version__})\n")

    if logged_in:
        creds = config.load_credentials() or {}
        console.print(f"  Logged in as [green]{creds.get('email', '')}[/green]\n")
        console.print("[bold]Commands:[/bold]\n")
        console.print("  [bold]ops version[/bold]       Show the OpenSees version")
        console.print("  [bold]ops status[/bold]        Show account details and quota")
        console.print("  [bold]ops quota[/bold]          Show usage quota")
        console.print()
        console.print("[bold]ops run[/bold]\n")
        console.print("  [bold]submit[/bold] <file>     Submit an analysis (--count N for parallel)")
        console.print("  [bold]follow[/bold] <id>       Stream live output from a running task")
        console.print("  [bold]list[/bold]              List recent analyses")
        console.print("  [bold]status[/bold] <id> [range] Analysis summary or per-task status")
        console.print("  [bold]output[/bold] <id> [range] Task stdout")
        console.print("  [bold]stats[/bold] <id> [range]  Task execution stats (runtime, RAM)")
        console.print("  [bold]data[/bold] <id> [range]   List or download task data files")
        console.print("  [bold]cancel[/bold] <id>       Cancel an analysis or task")
        console.print("  [bold]clear[/bold] [id]        Delete analysis data (by ID or time range)")
        console.print()
        console.print("[bold]ops files[/bold]\n")
        console.print("  [bold]list[/bold]              List uploaded files")
        console.print("  [bold]upload[/bold] <path>     Upload a file or folder")
        console.print("  [bold]download[/bold] <path>   Download a file or folder")
        console.print("  [bold]delete[/bold] <path>     Delete a file or folder")
        console.print()
        console.print("[bold]ops auth[/bold]\n")
        console.print("  [bold]change-password[/bold]   Change your password")
        console.print("  [bold]logout[/bold]            Log out")
        if config.is_admin():
            console.print()
            console.print("[bold]ops admin[/bold]\n")
            console.print("  [bold]list-users[/bold]        List all users")
            console.print("  [bold]user-info[/bold]         Show a user's details")
            console.print("  [bold]set-quota[/bold]         Update a user's quota")
            console.print("  [bold]enable-user[/bold]       Re-enable a user")
            console.print("  [bold]disable-user[/bold]      Disable a user")
            console.print("  [bold]delete-user[/bold]       Delete a user")
    else:
        console.print("  Not logged in.\n")
        console.print("[bold]Get started:[/bold]\n")
        console.print("  [bold]ops auth signup[/bold]          Create a new account")
        console.print("  [bold]ops auth login[/bold]           Log in to an existing account")
        console.print("  [bold]ops auth confirm[/bold]         Verify your email")
        console.print("  [bold]ops auth forgot-password[/bold] Reset your password")
        console.print()
        console.print("  [bold]ops version[/bold]              Show the OpenSees version")
        console.print("  [bold]ops status[/bold]               Show account details and quota")

    console.print()
    console.print("[dim]Run any command with --help for more details.[/dim]")


@app.callback(invoke_without_command=True)
def _root_callback(ctx: typer.Context) -> None:
    ensure_path()
    if ctx.invoked_subcommand is None:
        _print_help()
        raise typer.Exit(0)


@app.command()
def version():
    """Show the OpenSees version."""
    console.print(f"openseespy {__version__}")


@app.command()
def status():
    """Show your account details, signup time, and quota."""
    api.require_login()
    try:
        r = api.get("/auth/me")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)
    print_me(r)

@app.command()
def quota():
    """Show your usage quota."""
    api.require_login()
    try:
        r = api.get("/auth/me")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)
    q = r.get("quota")
    if not q:
        console.print("[dim]No quota info available.[/dim]")
        raise typer.Exit(0)
    print_quota(q)


