(function () {
  if (window.parent === window) return;

  let parentOrigin = "*";
  try {
    if (document.referrer) {
      parentOrigin = new URL(document.referrer).origin;
    }
  } catch (e) {}

  function currentPage() {
    return location.pathname.split("/").pop() || "webli1.html";
  }

  function getHeight() {
    const b = document.body;
    const e = document.documentElement;
    return Math.max(
      b ? b.scrollHeight : 0,
      b ? b.offsetHeight : 0,
      e ? e.scrollHeight : 0,
      e ? e.offsetHeight : 0,
      e ? e.clientHeight : 0
    );
  }

  function send(type, extra) {
    window.parent.postMessage(
      Object.assign({ type: type, page: currentPage() }, extra || {}),
      parentOrigin
    );
  }

  function update() {
    send("sync-page");
    send("iframe-height", { height: getHeight() });
  }

  document.addEventListener("click", function (e) {
    const a = e.target.closest && e.target.closest("a[href]");
    if (!a) return;

    const href = a.getAttribute("href");
    if (!href) return;
    if (
      href.startsWith("#") ||
      href.startsWith("mailto:") ||
      href.startsWith("tel:") ||
      href.startsWith("javascript:")
    ) {
      return;
    }

    let url;
    try {
      url = new URL(href, location.href);
    } catch (err) {
      return;
    }

    if (url.origin !== location.origin) return;
    if (!/\.html?$/i.test(url.pathname)) return;

    e.preventDefault();
    send("navigate-page", {
      page: url.pathname.split("/").pop() + (url.search || "")
    });
  });

  window.addEventListener("load", update);
  window.addEventListener("resize", update);
  window.addEventListener("pageshow", update);

  if (window.MutationObserver) {
    new MutationObserver(update).observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
})();