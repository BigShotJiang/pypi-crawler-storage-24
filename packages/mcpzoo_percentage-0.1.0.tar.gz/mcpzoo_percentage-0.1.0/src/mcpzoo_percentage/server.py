from mcp.server.fastmcp import FastMCP

mcp = FastMCP("percentage")

@mcp.tool()
def calc_percentage(part: float = 0, total: float = 0, old_val: float = 0, new_val: float = 0) -> str:
    """计算百分比和百分比变化。
    
    使用方式：
    1. 计算占比: 提供 part 和 total (如果 total=200, part=25 -> 12.5%)
    2. 计算变化率: 提供 old_val 和 new_val (如果 old=100, new=120 -> +20%)
    """
    res = []
    
    if total != 0:
        pct = (part / total) * 100
        res.append(f"{part} 是 {total} 的 {pct:.2f}%")
        
    if old_val != 0:
        diff = new_val - old_val
        change = (diff / abs(old_val)) * 100
        sign = "+" if change > 0 else ""
        res.append(f"从 {old_val} 到 {new_val} 变化了: {sign}{change:.2f}% (绝对值差: {diff})")
        
    if not res:
        return "请提供 (part 和 total) 或 (old_val 和 new_val)"
        
    return "\n".join(res)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
