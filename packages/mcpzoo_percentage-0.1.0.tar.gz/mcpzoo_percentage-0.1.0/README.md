# mcpzoo-percentage

> 百分比计算 — 计算百分比和百分比变化

## Installation

```bash
uvx mcpzoo-percentage
```

## uvx JSON

```json
{
  "mcpServers": {
    "percentage": {
      "args": ["mcpzoo-percentage"],
      "command": "uvx"
    }
  }
}
```
