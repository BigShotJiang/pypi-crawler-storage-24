"""Document tools — format conversion between Markdown, HTML, CSV, JSON, YAML."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(mcp: FastMCP) -> None:
    from peasy_document import engine

    @mcp.tool()
    def doc_markdown_to_html(markdown_text: str, extensions: list[str] | None = None) -> str:
        """Convert Markdown to HTML.

        extensions: Optional markdown extensions like ['tables', 'fenced_code'].
        Returns: HTML string.
        """
        return engine.markdown_to_html(markdown_text, extensions=extensions or []).content

    @mcp.tool()
    def doc_html_to_text(html: str) -> str:
        """Convert HTML to plain text, stripping all tags.

        Returns: Plain text.
        """
        return engine.html_to_text(html).content

    @mcp.tool()
    def doc_html_to_markdown(html: str) -> str:
        """Convert HTML to Markdown.

        Returns: Markdown string.
        """
        return engine.html_to_markdown(html).content

    @mcp.tool()
    def doc_text_to_html(text: str) -> str:
        """Convert plain text to HTML with paragraphs and line breaks.

        Returns: HTML string.
        """
        return engine.text_to_html(text).content

    @mcp.tool()
    def doc_csv_to_json(csv_text: str, delimiter: str = ",") -> str:
        """Convert CSV to JSON array.

        delimiter: Column delimiter.
        Returns: JSON string.
        """
        return engine.csv_to_json(csv_text, delimiter=delimiter).content

    @mcp.tool()
    def doc_json_to_csv(json_text: str) -> str:
        """Convert JSON array to CSV.

        json_text: JSON array of objects.
        Returns: CSV string.
        """
        return engine.json_to_csv(json_text).content

    @mcp.tool()
    def doc_csv_to_markdown(csv_text: str, delimiter: str = ",") -> str:
        """Convert CSV to a Markdown table.

        Returns: Markdown table string.
        """
        return engine.csv_to_markdown(csv_text, delimiter=delimiter).content

    @mcp.tool()
    def doc_csv_to_html(csv_text: str, delimiter: str = ",") -> str:
        """Convert CSV to an HTML table.

        Returns: HTML table string.
        """
        return engine.csv_to_html(csv_text, delimiter=delimiter).content

    @mcp.tool()
    def doc_json_to_yaml(json_text: str) -> str:
        """Convert JSON to YAML.

        Returns: YAML string.
        """
        return engine.json_to_yaml(json_text).content
