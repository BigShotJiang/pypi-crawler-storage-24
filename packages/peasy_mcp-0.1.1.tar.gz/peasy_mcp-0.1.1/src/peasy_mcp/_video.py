"""Video tools — trim, resize, extract audio, thumbnails, and more.

Video tools use file paths since video files are too large for base64 transport.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(mcp: FastMCP) -> None:
    from peasy_video import engine

    @mcp.tool()
    def video_info(file_path: str) -> dict[str, object]:
        """Get video file information.

        file_path: Path to video file.
        Returns: Dict with duration, width, height, fps, size_bytes, has_audio.
        """
        r = engine.info(file_path)
        return {
            "duration": r.duration,
            "size": r.size,
            "fps": r.fps,
            "file_size_bytes": r.file_size_bytes,
            "has_audio": r.has_audio,
            "n_frames": r.n_frames,
        }

    @mcp.tool()
    def video_trim(file_path: str, output_path: str, start: float = 0.0, end: float = 0.0) -> str:
        """Trim video to a time range.

        start: Start time in seconds.
        end: End time in seconds (0 = end of video).
        Returns: Output file path.
        """
        return str(engine.trim(file_path, output_path, start=start, end=end))

    @mcp.tool()
    def video_resize(file_path: str, output_path: str, width: int = 0, height: int = 0) -> str:
        """Resize a video. Specify width, height, or both.

        width: Target width (0 = auto from height).
        height: Target height (0 = auto from width).
        Returns: Output file path.
        """
        return str(engine.resize(file_path, output_path, width=width, height=height))

    @mcp.tool()
    def video_extract_audio(file_path: str, output_path: str, fmt: str = "mp3") -> str:
        """Extract audio track from a video.

        fmt: Audio format (mp3, wav, ogg).
        Returns: Output audio file path.
        """
        return str(engine.extract_audio(file_path, output_path, format=fmt))

    @mcp.tool()
    def video_thumbnail(file_path: str, time: float = 0.0) -> str:
        """Extract a single frame from a video as a PNG image.

        time: Timestamp in seconds.
        Returns: Base64-encoded PNG image.
        """
        import base64

        r = engine.thumbnail(file_path, time=time)
        return base64.b64encode(r.data).decode("ascii")

    @mcp.tool()
    def video_concatenate(file_paths: list[str], output_path: str) -> str:
        """Concatenate multiple videos into one.

        file_paths: List of paths to video files.
        output_path: Path for output file.
        Returns: Output file path.
        """
        return str(engine.concatenate(file_paths, output_path))

    @mcp.tool()
    def video_rotate(file_path: str, output_path: str, angle: float = 90) -> str:
        """Rotate a video by degrees.

        angle: Rotation angle (90, 180, 270).
        Returns: Output file path.
        """
        return str(engine.rotate(file_path, output_path, angle=angle))

    @mcp.tool()
    def video_speed(file_path: str, output_path: str, factor: float = 2.0) -> str:
        """Change video playback speed.

        factor: Speed multiplier (0.5 = half speed, 2.0 = double speed).
        Returns: Output file path.
        """
        return str(engine.speed(file_path, output_path, factor=factor))

    @mcp.tool()
    def video_strip_audio(file_path: str, output_path: str) -> str:
        """Remove audio track from a video.

        Returns: Output file path.
        """
        return str(engine.strip_audio(file_path, output_path))
