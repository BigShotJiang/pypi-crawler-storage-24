"""Allow running with ``python -m peasy_mcp``."""

from peasy_mcp.server import mcp

mcp.run()
