"""peasy-mcp — Unified MCP server for all Peasy tools.

Run::

    uvx --from "peasy-mcp[all]" python -m peasy_mcp

Configure in Claude Desktop / Cursor / Windsurf::

    {
        "mcpServers": {
            "peasy": {
                "command": "uvx",
                "args": ["--from", "peasy-mcp[all]", "python", "-m", "peasy_mcp"]
            }
        }
    }

Install only what you need::

    uvx --from "peasy-mcp[pdf,text]" python -m peasy_mcp
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "peasy",
    instructions=(
        "Unified Peasy tools for AI assistants. "
        "PDF, image, text, CSS, compress, document, audio, and video tools. "
        "Binary data (PDFs, images, archives) is exchanged as base64-encoded strings. "
        "Video and audio tools use file paths."
    ),
)

_registered: list[str] = []


def _try_register(name: str, register_fn_path: str) -> None:
    """Try to import and register a tool module."""
    try:
        import importlib

        mod = importlib.import_module(register_fn_path)
        mod.register(mcp)
        _registered.append(name)
    except ImportError:
        pass


_try_register("pdf", "peasy_mcp._pdf")
_try_register("text", "peasy_mcp._text")
_try_register("css", "peasy_mcp._css")
_try_register("image", "peasy_mcp._image")
_try_register("compress", "peasy_mcp._compress")
_try_register("document", "peasy_mcp._document")
_try_register("audio", "peasy_mcp._audio")
_try_register("video", "peasy_mcp._video")
