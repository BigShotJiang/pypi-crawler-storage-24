"""Image tools — resize, crop, convert, filter, and more."""

from __future__ import annotations

import base64
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _raw(b64: str) -> bytes:
    return base64.b64decode(b64)


def register(mcp: FastMCP) -> None:
    from peasy_image import engine

    @mcp.tool()
    def image_resize(
        file_b64: str,
        width: int = 0,
        height: int = 0,
        fmt: str = "png",
    ) -> str:
        """Resize an image. Specify width, height, or both.

        file_b64: Base64-encoded image.
        width: Target width (0 = auto from height).
        height: Target height (0 = auto from width).
        fmt: Output format (png, jpg, webp).
        Returns: Base64-encoded resized image.
        """
        return _b64(engine.resize(_raw(file_b64), width=width, height=height, fmt=fmt))

    @mcp.tool()
    def image_crop(
        file_b64: str,
        left: int = 0,
        top: int = 0,
        right: int = 0,
        bottom: int = 0,
        fmt: str = "png",
    ) -> str:
        """Crop an image to a region.

        file_b64: Base64-encoded image.
        left, top, right, bottom: Crop box coordinates.
        Returns: Base64-encoded cropped image.
        """
        return _b64(
            engine.crop(_raw(file_b64), left=left, top=top, right=right, bottom=bottom, fmt=fmt)
        )

    @mcp.tool()
    def image_rotate(file_b64: str, angle: float = 90, fmt: str = "png") -> str:
        """Rotate an image by degrees (counter-clockwise).

        Returns: Base64-encoded rotated image.
        """
        return _b64(engine.rotate(_raw(file_b64), angle=angle, fmt=fmt))

    @mcp.tool()
    def image_flip(file_b64: str, direction: str = "horizontal", fmt: str = "png") -> str:
        """Flip an image horizontally or vertically.

        direction: 'horizontal' or 'vertical'.
        Returns: Base64-encoded flipped image.
        """
        return _b64(engine.flip(_raw(file_b64), mode=direction, fmt=fmt))  # type: ignore[arg-type]

    @mcp.tool()
    def image_compress(file_b64: str, quality: int = 75, fmt: str = "jpg") -> str:
        """Compress an image to reduce file size.

        quality: 1-100 (lower = smaller file).
        Returns: Base64-encoded compressed image.
        """
        return _b64(engine.compress(_raw(file_b64), quality=quality, fmt=fmt))

    @mcp.tool()
    def image_convert(file_b64: str, fmt: str = "webp") -> str:
        """Convert an image to a different format.

        fmt: Target format (png, jpg, webp, bmp, gif, tiff).
        Returns: Base64-encoded converted image.
        """
        return _b64(engine.convert(_raw(file_b64), fmt=fmt))  # type: ignore[arg-type]

    @mcp.tool()
    def image_grayscale(file_b64: str, fmt: str = "png") -> str:
        """Convert an image to grayscale.

        Returns: Base64-encoded grayscale image.
        """
        return _b64(engine.grayscale(_raw(file_b64), fmt=fmt))

    @mcp.tool()
    def image_blur(file_b64: str, radius: float = 2.0, fmt: str = "png") -> str:
        """Apply Gaussian blur to an image.

        radius: Blur radius.
        Returns: Base64-encoded blurred image.
        """
        return _b64(engine.blur(_raw(file_b64), radius=radius, fmt=fmt))

    @mcp.tool()
    def image_sharpen(file_b64: str, factor: float = 2.0, fmt: str = "png") -> str:
        """Sharpen an image.

        factor: Sharpening factor (1.0 = no change, 2.0 = sharper).
        Returns: Base64-encoded sharpened image.
        """
        return _b64(engine.sharpen(_raw(file_b64), factor=factor, fmt=fmt))

    @mcp.tool()
    def image_invert(file_b64: str, fmt: str = "png") -> str:
        """Invert the colors of an image.

        Returns: Base64-encoded inverted image.
        """
        return _b64(engine.invert(_raw(file_b64), fmt=fmt))

    @mcp.tool()
    def image_thumbnail(file_b64: str, size: int = 128, fmt: str = "png") -> str:
        """Create a square thumbnail of an image.

        size: Thumbnail size in pixels.
        Returns: Base64-encoded thumbnail.
        """
        return _b64(engine.thumbnail(_raw(file_b64), size=size, fmt=fmt))

    @mcp.tool()
    def image_info(file_b64: str) -> dict[str, object]:
        """Get image information (dimensions, format, mode, size).

        Returns: Dict with width, height, format, mode, size_bytes.
        """
        r = engine.info(_raw(file_b64))
        return {
            "width": r.width,
            "height": r.height,
            "format": r.format,
            "mode": r.mode,
            "file_size": r.file_size,
        }
