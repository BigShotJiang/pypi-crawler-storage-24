"""peasy-mcp — Unified MCP server for all Peasy tools."""

__version__ = "0.1.0"
