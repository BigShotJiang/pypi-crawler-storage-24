# peasy-mcp

[![PyPI](https://img.shields.io/pypi/v/peasy-mcp)](https://pypi.org/project/peasy-mcp/)
[![Python](https://img.shields.io/pypi/pyversions/peasy-mcp)](https://pypi.org/project/peasy-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Unified [MCP](https://modelcontextprotocol.io/) server that exposes **82 tools across 8 modules** — PDF manipulation, image processing, text analysis, CSS generation, file compression, document conversion, audio processing, and video editing — to AI assistants like Claude, Cursor, and Windsurf. Each module maps to a standalone Peasy library, and peasy-mcp wires them all into a single MCP server so your AI assistant can merge PDFs, resize images, convert between document formats, generate CSS layouts, and process media files without leaving the conversation.

Built from [Peasy Tools](https://peasytools.com), the developer tools platform with 255 free browser-based tools across 16 sites. The same engines that power the interactive tools at [PeasyPDF](https://peasypdf.com), [PeasyImage](https://peasyimage.com), [PeasyText](https://peasytext.com), and [PeasyCSS](https://peasycss.com) are available here as MCP tools for your AI coding assistant.

> **Try the interactive tools at [peasytools.com](https://peasytools.com)** — [PDF Tools](https://peasypdf.com), [Image Tools](https://peasyimage.com), [Text Tools](https://peasytext.com), [CSS Tools](https://peasycss.com), [Audio Tools](https://peasyaudio.com), [Video Tools](https://peasyvideo.com)

<p align="center">
  <img src="demo.gif" alt="peasy-mcp demo — 82 MCP tools across 8 modules for AI assistants" width="800">
</p>

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
  - [Claude Desktop](#claude-desktop)
  - [Cursor](#cursor)
  - [Windsurf](#windsurf)
  - [Claude Code](#claude-code)
- [What You Can Do](#what-you-can-do)
  - [How MCP Tools Work](#how-mcp-tools-work)
  - [Work with PDFs](#work-with-pdfs)
  - [Process Images](#process-images)
  - [Analyze and Transform Text](#analyze-and-transform-text)
  - [Generate CSS Code](#generate-css-code)
  - [Compress and Archive Files](#compress-and-archive-files)
  - [Convert Between Document Formats](#convert-between-document-formats)
  - [Process Audio Files](#process-audio-files)
  - [Edit Video Files](#edit-video-files)
- [Tool Reference](#tool-reference)
  - [PDF Tools (11)](#pdf-tools-11)
  - [Text Tools (15)](#text-tools-15)
  - [CSS Tools (9)](#css-tools-9)
  - [Image Tools (12)](#image-tools-12)
  - [Compress Tools (9)](#compress-tools-9)
  - [Document Tools (9)](#document-tools-9)
  - [Audio Tools (8)](#audio-tools-8)
  - [Video Tools (9)](#video-tools-9)
- [Install Only What You Need](#install-only-what-you-need)
- [Data Exchange Formats](#data-exchange-formats)
- [Peasy Developer Tools](#peasy-developer-tools)
- [License](#license)

## Install

```bash
# Install with all 82 tools
pip install "peasy-mcp[all]"

# Or use uvx to run without installing
uvx --from "peasy-mcp[all]" python -m peasy_mcp
```

## Quick Start

### Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS, `%APPDATA%\Claude\claude_desktop_config.json` on Windows):

```json
{
    "mcpServers": {
        "peasy": {
            "command": "uvx",
            "args": ["--from", "peasy-mcp[all]", "python", "-m", "peasy_mcp"]
        }
    }
}
```

Restart Claude Desktop. You should see 82 tools available in the tools menu.

### Cursor

Add to `.cursor/mcp.json` in your project root:

```json
{
    "mcpServers": {
        "peasy": {
            "command": "uvx",
            "args": ["--from", "peasy-mcp[all]", "python", "-m", "peasy_mcp"]
        }
    }
}
```

### Windsurf

Add to your Windsurf MCP config (`~/.codeium/windsurf/mcp_config.json`):

```json
{
    "mcpServers": {
        "peasy": {
            "command": "uvx",
            "args": ["--from", "peasy-mcp[all]", "python", "-m", "peasy_mcp"]
        }
    }
}
```

### Claude Code

```bash
claude mcp add peasy -- uvx --from "peasy-mcp[all]" python -m peasy_mcp
```

## What You Can Do

### How MCP Tools Work

The [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) is an open standard created by Anthropic that lets AI assistants call external tools. Instead of the AI describing what it would do, MCP lets it actually do it — merge your PDFs, resize your images, generate CSS code, or convert document formats, all within the conversation.

peasy-mcp runs as a local MCP server on your machine. When your AI assistant needs to process a file or generate code, it calls the appropriate tool through MCP. The tool executes locally using the Peasy engine libraries, and the result is returned directly to the conversation.

| Concept | How peasy-mcp implements it |
|---------|---------------------------|
| **Server** | Single `peasy` server exposes all 82 tools |
| **Tools** | Each tool maps to a function in a Peasy engine library |
| **Binary data** | PDFs, images, and archives are exchanged as base64-encoded strings |
| **Large files** | Audio and video tools use file paths to avoid memory issues |
| **Modular install** | Only install the extras you need — uninstalled modules are skipped automatically |

The server uses [FastMCP](https://pypi.org/project/mcp/) for the MCP protocol layer and dynamically registers tool modules at startup. If a backing library is not installed (for example, you installed `peasy-mcp[text,css]` but not the `pdf` extra), those tools are silently skipped and the server starts with only the available tools.

Learn more: [What is MCP?](https://modelcontextprotocol.io/) · [MCP Specification](https://spec.modelcontextprotocol.io/) · [Peasy Tools](https://peasytools.com)

### Work with PDFs

PDF manipulation is one of the most common tasks developers delegate to AI assistants. The 11 PDF tools let your assistant merge multiple PDFs into a single document, split a PDF into parts by page ranges or at regular intervals, rotate pages, compress file size, extract text content, read and write metadata, encrypt with password protection, decrypt protected files, delete specific pages, and reverse page order.

All PDF operations are powered by [peasy-pdf](https://pypi.org/project/peasy-pdf/), which uses PyPDF2 for reliable PDF processing. PDFs are exchanged as base64-encoded strings, so your assistant can receive a PDF, process it, and return the result within a single conversation turn.

| Operation | Tool | What it does |
|-----------|------|-------------|
| Merge | `pdf_merge` | Combine 2+ PDFs into one document |
| Split | `pdf_split` | Break a PDF by page ranges (`1-3,4-6`) or every N pages |
| Rotate | `pdf_rotate` | Rotate specific pages by 90, 180, or 270 degrees |
| Compress | `pdf_compress` | Reduce file size for sharing or storage |
| Extract text | `pdf_extract_text` | Pull text content from all or specific pages |
| Metadata | `pdf_info`, `pdf_metadata` | Read or set title, author, subject, keywords |
| Security | `pdf_encrypt`, `pdf_decrypt` | Add or remove password protection |
| Pages | `pdf_delete_pages`, `pdf_reverse` | Remove pages or reverse page order |

Learn more: [PeasyPDF Tools](https://peasypdf.com) · [peasy-pdf on PyPI](https://pypi.org/project/peasy-pdf/)

### Process Images

The 12 image tools cover the most common image manipulation tasks: resizing by width, height, or both (with automatic aspect ratio preservation), cropping to a region, rotating by any angle, flipping horizontally or vertically, compressing with quality control, converting between formats (PNG, JPG, WebP, BMP, GIF, TIFF), applying grayscale, Gaussian blur, sharpening, color inversion, thumbnail generation, and metadata inspection.

Image processing is powered by [peasy-image](https://pypi.org/project/peasy-image/), which uses Pillow for image operations. Like PDFs, images are exchanged as base64-encoded strings. The `image_info` tool returns width, height, format, color mode, and file size without modifying the image.

| Operation | Tool | Formats |
|-----------|------|---------|
| Resize | `image_resize` | PNG, JPG, WebP output |
| Crop | `image_crop` | Pixel coordinates (left, top, right, bottom) |
| Transform | `image_rotate`, `image_flip` | Any angle; horizontal/vertical flip |
| Optimize | `image_compress` | Quality 1-100 with format conversion |
| Convert | `image_convert` | PNG, JPG, WebP, BMP, GIF, TIFF |
| Filter | `image_grayscale`, `image_blur`, `image_sharpen`, `image_invert` | Gaussian blur radius, unsharp mask factor |
| Thumbnail | `image_thumbnail` | Square crop + resize in one step |
| Inspect | `image_info` | Width, height, format, mode, file size |

Learn more: [PeasyImage Tools](https://peasyimage.com) · [peasy-image on PyPI](https://pypi.org/project/peasy-image/)

### Analyze and Transform Text

The 15 text tools handle case conversion across 13 styles (camelCase, snake_case, kebab-case, PascalCase, CONSTANT_CASE, dot.case, path/case, Title Case, Sentence case, and more), URL slug generation, character/word/sentence counting with reading time estimation, line sorting (alphabetical, by length, numeric, reverse, shuffle), Base64 encoding/decoding, URL encoding/decoding, HTML entity encoding/decoding, find-and-replace with regex support, duplicate line removal, line number management, pattern extraction (emails, URLs, phone numbers, IP addresses, hashtags, mentions), Lorem Ipsum generation, text reversal, JSON formatting/minification/validation, and line-by-line diff with similarity scoring.

Text tools are zero-dependency — they require no heavy libraries beyond [peasytext](https://pypi.org/project/peasytext/) itself.

| Category | Tools | Key features |
|----------|-------|-------------|
| Case conversion | `text_case`, `text_slug` | 13 case styles + URL-safe slugs |
| Analysis | `text_count`, `text_diff` | Characters, words, sentences, reading time, similarity |
| Encoding | `text_base64`, `text_url_encode`, `text_html_entities` | Encode/decode in both directions |
| Manipulation | `text_sort`, `text_dedupe`, `text_line_numbers`, `text_reverse` | Sort, deduplicate, number, reverse |
| Search | `text_find_replace`, `text_extract` | Regex support, extract emails/URLs/IPs |
| Generation | `text_lorem` | Paragraphs, sentences, or words |
| JSON | `text_json` | Format, minify, validate |

Learn more: [PeasyText Tools](https://peasytext.com) · [peasytext on PyPI](https://pypi.org/project/peasytext/)

### Generate CSS Code

The 9 CSS tools generate production-ready CSS code snippets. Instead of looking up CSS syntax or tweaking values in a browser DevTools panel, ask your AI assistant to generate a linear gradient, configure a flexbox layout, create a CSS Grid, add a box shadow, set up an animation, apply a transform, create a glassmorphism effect, build a fluid typography scale with `clamp()`, or wrap CSS in a media query.

Every tool returns a complete CSS rule with the selector included, ready to paste into a stylesheet. CSS generation is powered by [peasy-css](https://pypi.org/project/peasy-css/), which is zero-dependency.

| Tool | CSS Property | Example output |
|------|-------------|----------------|
| `css_gradient` | `background` | Linear, radial, or conic gradients with multiple color stops |
| `css_box_shadow` | `box-shadow` | Offset, blur, spread, color, inset support |
| `css_flexbox` | `display: flex` | Direction, wrap, justify, align, gap |
| `css_grid` | `display: grid` | Template columns, rows, gap |
| `css_animation` | `animation` | Name, duration, timing function shorthand |
| `css_transform` | `transform` | Translate, rotate, scale combined |
| `css_glassmorphism` | `backdrop-filter` | Blur + semi-transparent background |
| `css_clamp_font` | `font-size: clamp()` | Min, preferred (vw), max fluid sizing |
| `css_media_query` | `@media` | min-width/max-width breakpoint wrapper |

Learn more: [PeasyCSS Tools](https://peasycss.com) · [peasy-css on PyPI](https://pypi.org/project/peasy-css/)

### Compress and Archive Files

The 9 compression tools support ZIP archive creation and extraction, plus three compression algorithms: gzip, bzip2, and LZMA/xz. ZIP tools can create archives from multiple files, extract all contents, and list archive entries with size information. The compression algorithms work on raw data — useful for compressing individual files or data streams.

All data is exchanged as base64-encoded strings. The `compress_zip_create` tool accepts a dictionary of filename-to-content mappings, making it easy for your AI assistant to bundle multiple files into a single archive.

| Algorithm | Compress | Decompress | Typical use |
|-----------|----------|------------|-------------|
| ZIP | `compress_zip_create` | `compress_zip_extract` | Multi-file archives with directory structure |
| gzip | `compress_gzip` | `compress_gunzip` | Single-file compression, HTTP content encoding |
| bzip2 | `compress_bz2` | `compress_bunzip2` | Higher compression ratio than gzip |
| LZMA/xz | `compress_lzma` | `compress_unlzma` | Maximum compression ratio |

Learn more: [peasy-compress on PyPI](https://pypi.org/project/peasy-compress/)

### Convert Between Document Formats

The 9 document conversion tools handle the most common format transformations: Markdown to HTML, HTML to plain text, HTML to Markdown, plain text to HTML (with paragraph wrapping), CSV to JSON, JSON to CSV, CSV to Markdown table, CSV to HTML table, and JSON to YAML.

Document conversion is powered by [peasy-document](https://pypi.org/project/peasy-document/). These tools are particularly useful when your AI assistant needs to convert data between formats for different systems — for example, converting a CSV export to a Markdown table for documentation, or transforming JSON API responses to YAML configuration files.

| Conversion | Tool | Direction |
|-----------|------|-----------|
| Markdown | `doc_markdown_to_html` | `.md` to `.html` with extension support |
| HTML | `doc_html_to_text`, `doc_html_to_markdown` | Strip tags or convert to Markdown |
| Text | `doc_text_to_html` | Wrap in `<p>` tags with line breaks |
| CSV | `doc_csv_to_json`, `doc_csv_to_markdown`, `doc_csv_to_html` | To JSON array, Markdown table, or HTML table |
| JSON | `doc_json_to_csv`, `doc_json_to_yaml` | Array-of-objects to CSV or YAML |

Learn more: [peasy-document on PyPI](https://pypi.org/project/peasy-document/)

### Process Audio Files

The 8 audio tools handle format conversion (MP3, WAV, OGG, FLAC, AAC), trimming to a time range, merging multiple files, volume normalization, speed adjustment, reverse playback, and volume changes in decibels. The `audio_info` tool reports duration, channels, sample rate, and file size.

Audio processing is powered by [peasy-audio](https://pypi.org/project/peasy-audio/), which uses pydub and FFmpeg. Audio tools accept **file paths** as input (rather than base64) since audio files can be large. Output audio data is returned as base64-encoded bytes along with metadata (format, duration, size).

| Operation | Tool | Parameters |
|-----------|------|-----------|
| Inspect | `audio_info` | Duration, channels, frame rate, size |
| Convert | `audio_convert` | Target format + bitrate control |
| Trim | `audio_trim` | Start/end in milliseconds |
| Merge | `audio_merge` | Concatenate multiple files |
| Normalize | `audio_normalize` | Automatic volume leveling |
| Speed | `audio_speed` | 0.5x to 2.0x+ playback speed |
| Reverse | `audio_reverse` | Reverse playback direction |
| Volume | `audio_volume` | Adjust by decibels (+/-) |

Learn more: [PeasyAudio Tools](https://peasyaudio.com) · [peasy-audio on PyPI](https://pypi.org/project/peasy-audio/)

### Edit Video Files

The 9 video tools cover trimming, resizing, audio extraction, frame capture, concatenation, rotation, speed adjustment, and audio removal. Video processing is powered by [peasy-video](https://pypi.org/project/peasy-video/), which uses MoviePy and FFmpeg.

Video tools use **file paths** for both input and output since video files are too large for base64 transport. The one exception is `video_thumbnail`, which returns a single frame as a base64-encoded PNG.

| Operation | Tool | Input/Output |
|-----------|------|-------------|
| Inspect | `video_info` | Duration, dimensions, FPS, audio presence, frame count |
| Trim | `video_trim` | Start/end in seconds, writes to output path |
| Resize | `video_resize` | Width/height with auto aspect ratio |
| Extract audio | `video_extract_audio` | MP3, WAV, or OGG output |
| Thumbnail | `video_thumbnail` | Base64 PNG at specified timestamp |
| Concatenate | `video_concatenate` | Join multiple videos sequentially |
| Rotate | `video_rotate` | 90, 180, or 270 degrees |
| Speed | `video_speed` | 0.5x to 2.0x+ playback speed |
| Strip audio | `video_strip_audio` | Remove audio track, keep video |

Learn more: [PeasyVideo Tools](https://peasyvideo.com) · [peasy-video on PyPI](https://pypi.org/project/peasy-video/)

## Tool Reference

peasy-mcp exposes **82 tools** across 8 modules. Tools from uninstalled packages are automatically skipped at startup.

### PDF Tools (11)

Powered by [peasy-pdf](https://pypi.org/project/peasy-pdf/) — merge, split, rotate, compress, and manipulate PDFs.

| Tool | Description |
|------|-------------|
| `pdf_merge` | Merge multiple PDFs into one |
| `pdf_split` | Split a PDF into parts by ranges or page count |
| `pdf_rotate` | Rotate pages (90, 180, 270 degrees) |
| `pdf_compress` | Compress PDF to reduce file size |
| `pdf_extract_text` | Extract text content from PDF pages |
| `pdf_info` | Get page count, metadata, file size |
| `pdf_metadata` | Set title, author, subject, keywords |
| `pdf_encrypt` | Password-protect a PDF |
| `pdf_decrypt` | Remove password protection |
| `pdf_delete_pages` | Remove specific pages |
| `pdf_reverse` | Reverse page order |

### Text Tools (15)

Powered by [peasytext](https://pypi.org/project/peasytext/) — case conversion, encoding, search, and text analysis.

| Tool | Description |
|------|-------------|
| `text_case` | Convert between 13 case styles (camel, snake, kebab, pascal, constant, dot, path...) |
| `text_slug` | URL-friendly slug generation with custom separator and max length |
| `text_count` | Character, word, sentence, paragraph counts + reading time |
| `text_sort` | Sort lines alphabetically, by length, numerically, reverse, or shuffle |
| `text_base64` | Base64 encode/decode |
| `text_url_encode` | URL encode/decode |
| `text_html_entities` | HTML entity encode/decode |
| `text_find_replace` | Find and replace with regex support |
| `text_dedupe` | Remove duplicate lines, preserving order |
| `text_line_numbers` | Add or remove line numbers |
| `text_extract` | Extract emails, URLs, phones, IPs, hashtags, or mentions from text |
| `text_lorem` | Generate Lorem Ipsum placeholder text (paragraphs, sentences, or words) |
| `text_reverse` | Reverse by characters, words, or lines |
| `text_json` | Format, minify, or validate JSON |
| `text_diff` | Compare two texts line by line with similarity scoring |

### CSS Tools (9)

Powered by [peasy-css](https://pypi.org/project/peasy-css/) — generate production-ready CSS code.

| Tool | Description |
|------|-------------|
| `css_gradient` | Linear, radial, or conic gradients with multiple color stops |
| `css_box_shadow` | Box shadow with offset, blur, spread, color, and inset support |
| `css_flexbox` | Flexbox layout with direction, wrap, justify, align, gap |
| `css_grid` | CSS Grid with template columns, rows, and gap |
| `css_animation` | Animation shorthand with name, duration, timing function |
| `css_transform` | Transform combining translate, rotate, and scale |
| `css_glassmorphism` | Glassmorphism effect with backdrop-filter blur |
| `css_clamp_font` | Fluid typography with `clamp()` for responsive font sizing |
| `css_media_query` | Media query wrapper for min-width or max-width breakpoints |

### Image Tools (12)

Powered by [peasy-image](https://pypi.org/project/peasy-image/) — resize, crop, convert, and apply filters.

| Tool | Description |
|------|-------------|
| `image_resize` | Resize by width, height, or both with aspect ratio preservation |
| `image_crop` | Crop to a region by pixel coordinates |
| `image_rotate` | Rotate by any angle (counter-clockwise) |
| `image_flip` | Flip horizontally or vertically |
| `image_compress` | Reduce file size with quality control (1-100) |
| `image_convert` | Convert between PNG, JPG, WebP, BMP, GIF, TIFF |
| `image_grayscale` | Convert to grayscale |
| `image_blur` | Apply Gaussian blur with configurable radius |
| `image_sharpen` | Sharpen with unsharp mask factor |
| `image_invert` | Invert colors |
| `image_thumbnail` | Create square thumbnails at specified pixel size |
| `image_info` | Get width, height, format, color mode, file size |

### Compress Tools (9)

Powered by [peasy-compress](https://pypi.org/project/peasy-compress/) — ZIP archives and compression algorithms.

| Tool | Description |
|------|-------------|
| `compress_zip_create` | Create ZIP archive from a dictionary of files |
| `compress_zip_extract` | Extract all files from a ZIP archive |
| `compress_zip_list` | List ZIP contents with file count, sizes, and entries |
| `compress_gzip` | Gzip compress with configurable level |
| `compress_gunzip` | Gzip decompress |
| `compress_bz2` | Bzip2 compress with configurable level |
| `compress_bunzip2` | Bzip2 decompress |
| `compress_lzma` | LZMA/xz compress |
| `compress_unlzma` | LZMA/xz decompress |

### Document Tools (9)

Powered by [peasy-document](https://pypi.org/project/peasy-document/) — convert between document formats.

| Tool | Description |
|------|-------------|
| `doc_markdown_to_html` | Markdown to HTML with optional extensions (tables, fenced_code) |
| `doc_html_to_text` | HTML to plain text, stripping all tags |
| `doc_html_to_markdown` | HTML to Markdown |
| `doc_text_to_html` | Plain text to HTML with paragraphs and line breaks |
| `doc_csv_to_json` | CSV to JSON array with custom delimiter |
| `doc_json_to_csv` | JSON array of objects to CSV |
| `doc_csv_to_markdown` | CSV to Markdown table |
| `doc_csv_to_html` | CSV to HTML table |
| `doc_json_to_yaml` | JSON to YAML |

### Audio Tools (8)

Powered by [peasy-audio](https://pypi.org/project/peasy-audio/) — convert, trim, merge, and process audio. Requires FFmpeg.

| Tool | Description |
|------|-------------|
| `audio_info` | Get duration, channels, sample rate, format, file size |
| `audio_convert` | Convert between MP3, WAV, OGG, FLAC, AAC with bitrate control |
| `audio_trim` | Trim to a time range (start/end in milliseconds) |
| `audio_merge` | Merge multiple audio files into one |
| `audio_normalize` | Normalize volume to a standard level |
| `audio_speed` | Change playback speed (0.5x-2.0x+) |
| `audio_reverse` | Reverse audio playback |
| `audio_volume` | Adjust volume in decibels (+/-) |

### Video Tools (9)

Powered by [peasy-video](https://pypi.org/project/peasy-video/) — trim, resize, extract audio, and process video. Requires FFmpeg.

| Tool | Description |
|------|-------------|
| `video_info` | Get duration, dimensions, FPS, audio presence, frame count |
| `video_trim` | Trim to a time range (start/end in seconds) |
| `video_resize` | Resize by width, height, or both |
| `video_extract_audio` | Extract audio track as MP3, WAV, or OGG |
| `video_thumbnail` | Extract a single frame as base64 PNG |
| `video_concatenate` | Join multiple videos into one |
| `video_rotate` | Rotate by 90, 180, or 270 degrees |
| `video_speed` | Change playback speed (0.5x-2.0x+) |
| `video_strip_audio` | Remove audio track from video |

## Install Only What You Need

Install specific tool modules to keep the server lightweight. Uninstalled modules are automatically skipped at startup.

```bash
# Text + CSS only (zero heavy dependencies, fast startup)
uvx --from "peasy-mcp[text,css]" python -m peasy_mcp

# PDF + Image (adds PyPDF2 and Pillow)
uvx --from "peasy-mcp[pdf,image]" python -m peasy_mcp

# Document conversion only
uvx --from "peasy-mcp[document]" python -m peasy_mcp

# Media processing (requires FFmpeg installed on your system)
uvx --from "peasy-mcp[audio,video]" python -m peasy_mcp

# Everything — all 82 tools
uvx --from "peasy-mcp[all]" python -m peasy_mcp
```

Available extras: `pdf`, `image`, `text`, `css`, `compress`, `document`, `audio`, `video`, `all`.

| Extra | Package | Dependencies | Tools |
|-------|---------|-------------|-------|
| `pdf` | peasy-pdf | PyPDF2 | 11 |
| `text` | peasytext | None (pure Python) | 15 |
| `css` | peasy-css | None (pure Python) | 9 |
| `image` | peasy-image | Pillow | 12 |
| `compress` | peasy-compress | None (stdlib only) | 9 |
| `document` | peasy-document | markdown, beautifulsoup4, PyYAML | 9 |
| `audio` | peasy-audio | pydub + FFmpeg | 8 |
| `video` | peasy-video | moviepy + FFmpeg | 9 |

## Data Exchange Formats

Different tool modules use different data exchange strategies depending on file size:

| Module | Input | Output | Reason |
|--------|-------|--------|--------|
| PDF | Base64 string | Base64 string | PDFs are typically small enough for in-conversation exchange |
| Image | Base64 string | Base64 string | Images can be embedded directly in responses |
| Text | Plain string | Plain string / dict | Text is inherently string-based |
| CSS | Parameters | CSS string | Pure code generation, no binary data |
| Compress | Base64 string | Base64 string / dict | Archives need binary transport |
| Document | Plain string | Plain string | Format conversion between text-based formats |
| Audio | File path | Base64 + metadata dict | Audio files can be large; paths avoid memory issues |
| Video | File path | File path (mostly) | Video files are too large for base64; `video_thumbnail` returns base64 PNG |

## Peasy Developer Tools

| Package | PyPI | npm | Description |
|---------|------|-----|-------------|
| peasy-pdf | [PyPI](https://pypi.org/project/peasy-pdf/) | [npm](https://www.npmjs.com/package/peasy-pdf) | PDF processing — merge, split, compress, rotate — [peasypdf.com](https://peasypdf.com) |
| peasy-image | [PyPI](https://pypi.org/project/peasy-image/) | [npm](https://www.npmjs.com/package/peasy-image) | Image ops — resize, crop, convert, filter — [peasyimage.com](https://peasyimage.com) |
| peasytext | [PyPI](https://pypi.org/project/peasytext/) | [npm](https://www.npmjs.com/package/peasytext) | Text analysis — case, encoding, diff — [peasytext.com](https://peasytext.com) |
| peasy-css | [PyPI](https://pypi.org/project/peasy-css/) | [npm](https://www.npmjs.com/package/peasy-css) | CSS generation — gradients, shadows, flexbox, grid — [peasycss.com](https://peasycss.com) |
| peasy-compress | [PyPI](https://pypi.org/project/peasy-compress/) | [npm](https://www.npmjs.com/package/peasy-compress) | ZIP, gzip, bz2, LZMA compression |
| peasy-document | [PyPI](https://pypi.org/project/peasy-document/) | [npm](https://www.npmjs.com/package/peasy-document) | Format conversion — Markdown, HTML, CSV, JSON |
| peasy-audio | [PyPI](https://pypi.org/project/peasy-audio/) | — | Audio processing — convert, trim, merge — [peasyaudio.com](https://peasyaudio.com) |
| peasy-video | [PyPI](https://pypi.org/project/peasy-video/) | — | Video processing — trim, resize, extract — [peasyvideo.com](https://peasyvideo.com) |
| peasy-convert | [PyPI](https://pypi.org/project/peasy-convert/) | — | Unified CLI — all tools in one command |
| **peasy-mcp** | **[PyPI](https://pypi.org/project/peasy-mcp/)** | — | **Unified MCP server — 82 tools for AI assistants** |

Part of the [Peasy](https://peasytools.com) developer tools ecosystem — 255 free tools across 16 sites.

## License

MIT
