"""Tests for peasy-mcp server."""

from __future__ import annotations

import importlib

from peasy_mcp.server import _registered, mcp


class TestServerSetup:
    def test_mcp_instance_created(self) -> None:
        assert mcp is not None
        assert mcp.name == "peasy"

    def test_instructions_set(self) -> None:
        # FastMCP stores instructions on the instance
        instructions = getattr(mcp, "_instructions", "") or getattr(mcp, "instructions", "") or ""
        assert "Unified Peasy tools" in instructions or mcp.name == "peasy"

    def test_registered_modules(self) -> None:
        # At minimum, text and css should be available (pure Python, no heavy deps)
        # PDF requires pypdf, image requires Pillow, etc.
        assert len(_registered) >= 0  # basic sanity

    def test_conditional_import_handles_missing(self) -> None:
        """Missing packages should not crash the server."""
        # Re-import to verify no crash
        importlib.reload(importlib.import_module("peasy_mcp.server"))


class TestModuleRegistration:
    """Test that individual modules register correctly when their deps are available."""

    def test_text_tools_registered(self) -> None:
        try:
            import peasytext  # noqa: F401

            assert "text" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "text_case" in tool_names
            assert "text_slug" in tool_names
            assert "text_count" in tool_names
        except ImportError:
            pass

    def test_css_tools_registered(self) -> None:
        try:
            import peasy_css  # noqa: F401

            assert "css" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "css_gradient" in tool_names
            assert "css_flexbox" in tool_names
        except ImportError:
            pass

    def test_pdf_tools_registered(self) -> None:
        try:
            import peasy_pdf  # noqa: F401

            assert "pdf" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "pdf_merge" in tool_names
            assert "pdf_info" in tool_names
        except ImportError:
            pass

    def test_image_tools_registered(self) -> None:
        try:
            import peasy_image  # noqa: F401

            assert "image" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "image_resize" in tool_names
            assert "image_info" in tool_names
        except ImportError:
            pass

    def test_compress_tools_registered(self) -> None:
        try:
            import peasy_compress  # noqa: F401

            assert "compress" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "compress_zip_create" in tool_names
            assert "compress_gzip" in tool_names
        except ImportError:
            pass

    def test_document_tools_registered(self) -> None:
        try:
            import peasy_document  # noqa: F401

            assert "document" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "doc_markdown_to_html" in tool_names
            assert "doc_csv_to_json" in tool_names
        except ImportError:
            pass

    def test_audio_tools_registered(self) -> None:
        try:
            import peasy_audio  # noqa: F401

            assert "audio" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "audio_info" in tool_names
            assert "audio_convert" in tool_names
        except ImportError:
            pass

    def test_video_tools_registered(self) -> None:
        try:
            import peasy_video  # noqa: F401

            assert "video" in _registered
            tools = mcp._tool_manager.list_tools()
            tool_names = [t.name for t in tools]
            assert "video_info" in tool_names
            assert "video_trim" in tool_names
        except ImportError:
            pass
