"""Integration tests for individual MCP tools.

Only tests for packages that are actually installed.
"""

from __future__ import annotations

import base64

import pytest


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


# ── Text tools ──────────────────────────────────────────────


class TestTextTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasytext")

    def test_text_case(self) -> None:
        from mcp.server.fastmcp import FastMCP

        from peasy_mcp._text import register

        server = FastMCP("test")
        register(server)
        # Verify tools were registered
        tools = server._tool_manager.list_tools()
        names = [t.name for t in tools]
        assert "text_case" in names

    def test_text_slug(self) -> None:
        from peasytext import engine

        assert engine.slugify("Hello World!") == "hello-world"

    def test_text_count(self) -> None:
        from peasytext import engine

        stats = engine.count_text("Hello world")
        assert stats.words == 2


# ── CSS tools ──────────────────────────────────────────────


class TestCSSTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasy_css")

    def test_css_gradient(self) -> None:
        from peasy_css import engine

        result = engine.gradient_css(".el", ["#ff0000", "#0000ff"])
        assert "linear-gradient" in result

    def test_css_flexbox(self) -> None:
        from peasy_css import engine

        result = engine.flexbox_css(".container")
        assert "display: flex" in result


# ── Compress tools ──────────────────────────────────────────


class TestCompressTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasy_compress")

    def test_gzip_roundtrip(self) -> None:
        from peasy_compress import engine

        data = b"Hello, compression!"
        compressed = engine.gzip_compress(data)
        assert engine.gzip_decompress(compressed) == data

    def test_zip_create_and_list(self) -> None:
        from peasy_compress import engine

        archive = engine.zip_create({"test.txt": b"hello"})
        info = engine.zip_list(archive)
        assert info.file_count == 1


# ── Document tools ──────────────────────────────────────────


class TestDocumentTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasy_document")

    def test_markdown_to_html(self) -> None:
        from peasy_document import engine

        result = engine.markdown_to_html("# Hello")
        assert "<h1" in result.content

    def test_csv_to_json(self) -> None:
        from peasy_document import engine

        result = engine.csv_to_json("name,age\nAlice,30")
        assert "Alice" in result.content


# ── PDF tools ──────────────────────────────────────────────


class TestPDFTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasy_pdf")

    def test_pdf_info(self) -> None:
        from peasy_pdf import engine

        # Create a minimal PDF
        from pypdf import PdfWriter

        writer = PdfWriter()
        writer.add_blank_page(width=612, height=792)
        import io

        buf = io.BytesIO()
        writer.write(buf)
        pdf_bytes = buf.getvalue()

        info = engine.info(pdf_bytes)
        assert info.pages == 1


# ── Image tools ──────────────────────────────────────────────


class TestImageTools:
    @pytest.fixture(autouse=True)
    def _check_available(self) -> None:
        pytest.importorskip("peasy_image")

    def test_image_info(self) -> None:
        import io

        from peasy_image import engine

        # Create a minimal PNG
        from PIL import Image

        img = Image.new("RGB", (100, 50), color="red")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        png_bytes = buf.getvalue()

        info = engine.info(png_bytes)
        assert info.width == 100
        assert info.height == 50

    def test_image_resize(self) -> None:
        import io

        from peasy_image import engine
        from PIL import Image

        img = Image.new("RGB", (200, 100), color="blue")
        buf = io.BytesIO()
        img.save(buf, format="PNG")

        result = engine.resize(buf.getvalue(), width=100)
        resized = Image.open(io.BytesIO(result))
        assert resized.width == 100
