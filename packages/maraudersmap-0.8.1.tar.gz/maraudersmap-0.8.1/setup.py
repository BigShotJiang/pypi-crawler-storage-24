
import setuptools

setuptools.setup()
