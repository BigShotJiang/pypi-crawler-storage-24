"""Tools to convert MMAP data to Moonframe data"""


def flatten_struct(data: dict):
    """[RECURSIVE] Flatten the `struct_repo.json` file to be compatible with the 
    circular packing graph of Moonframe.
    The root path is set to `root`.

    Args:
        data (dict): Data from the `struct_repo.json` file.

    Returns:
        dict: Flatten struct file
    """
    if data["path"] != ".":
        path = "root/" + data["path"].replace(":", "/")
    else:
        path = "root"
    struct = {path: {k: v for k, v in data.items() if k != "children"}}
    if "children" in data.keys():
        children = data["children"]
        if children:
            for child in children:
                struct.update(flatten_struct(child))
    return struct
