# MetricCompute

::: aitaem.insights.MetricCompute
