from datetime import date

from django.utils.http import urlencode
from rest_framework.reverse import reverse
from wbcore import serializers
from wbcore.contrib.currency.serializers import CurrencyRepresentationSerializer
from wbcore.contrib.directory.serializers import EntryRepresentationSerializer
from wbcore.metadata.configs.buttons import WidgetButton
from wbcrm.serializers import AccountRepresentationSerializer, ProductRepresentationSerializer

from wbaccounting.models import BookingEntry
from wbaccounting.models.booking_entry import BookingEntryType
from wbaccounting.serializers import InvoiceRepresentationSerializer


class BookingEntryTypeRepresentationSerializer(serializers.RepresentationSerializer):
    _detail = serializers.HyperlinkField(reverse_name="wbaccounting:bookingentrytype-detail")

    class Meta:
        model = BookingEntryType
        fields = (
            "id",
            "key",
            "title",
            "_detail",
        )


class BookingEntryRepresentationSerializer(serializers.RepresentationSerializer):
    _detail = serializers.HyperlinkField(reverse_name="wbaccounting:bookingentry-detail")

    class Meta:
        model = BookingEntry
        fields = (
            "id",
            "title",
            "_detail",
        )


class BookingEntryTypeModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingEntryType
        fields = (
            "id",
            "key",
            "title",
        )


class BookingEntryModelSerializer(serializers.ModelSerializer):
    _currency = CurrencyRepresentationSerializer(source="currency")
    _counterparty = EntryRepresentationSerializer(source="counterparty")
    _invoice = InvoiceRepresentationSerializer(source="invoice")
    _product = ProductRepresentationSerializer(source="product")
    _account = AccountRepresentationSerializer(source="account")
    _type = BookingEntryTypeRepresentationSerializer(source="type")
    title = serializers.CharField(required=False)
    invoice_currency = serializers.StringRelatedField(
        source="invoice.invoice_currency", read_only=True, label="Inv. Currency"
    )
    booking_date = serializers.DateField(default=lambda: date.today())
    net_value = serializers.DecimalField(read_only=True, max_digits=16, decimal_places=4)
    invoice_net_value = serializers.DecimalField(read_only=True, max_digits=16, decimal_places=4)
    invoice_gross_value = serializers.DecimalField(read_only=True, max_digits=16, decimal_places=4)

    @serializers.register_dynamic_button()
    def dynamic_buttons(self, instance, request, user):
        buttons = []

        if backlinks := instance.backlinks:
            for _, backlink in backlinks.items():
                buttons.append(
                    WidgetButton(
                        label=backlink["title"],
                        endpoint=f"{reverse(backlink['reverse'], request=request)}?{urlencode(backlink['parameters'])}",
                    )
                )

        return buttons

    class Meta:
        model = BookingEntry
        decorators = {
            "gross_value": serializers.decorator(decorator_type="text", position="left", value="{{_currency.symbol}}"),
            "net_value": serializers.decorator(decorator_type="text", position="left", value="{{_currency.symbol}}"),
        }
        percent_fields = ["vat"]
        read_only_fields = ["invoice_net_value", "invoice_gross_value", "invoice_fx_rate", "quantity"]

        fields = (
            "id",
            "title",
            "product",
            "type",
            "account",
            "_product",
            "_account",
            "_type",
            "booking_date",
            "due_date",
            "payment_date",
            "reference_date",
            "net_value",
            "gross_value",
            "period",
            "quantity",
            "vat",
            "invoice_net_value",
            "invoice_gross_value",
            "invoice_fx_rate",
            "currency",
            "_currency",
            "counterparty",
            "_counterparty",
            "invoice",
            "_invoice",
            "invoice_currency",
            "_additional_resources",
            "_buttons",
        )
