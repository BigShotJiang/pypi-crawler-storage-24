.. seaquest documentation master file, created by
   sphinx-quickstart on Thu Mar 12 18:16:55 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

seaquest documentation
======================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 4
   :caption: Contents:

   seaquest
