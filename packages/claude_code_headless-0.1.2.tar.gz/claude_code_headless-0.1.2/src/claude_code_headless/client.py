"""
Claude Code Headless Client - Core functionality for calling Claude via CLI.
"""
import subprocess
import json
import sys
import time
from typing import Callable, Optional, Union, Literal


# Available model aliases
ModelAlias = Literal["sonnet", "opus", "haiku"]

# Default model to use
DEFAULT_MODEL: Optional[str] = None

# Default rate limit (seconds between calls). None = no limit.
DEFAULT_RATE_LIMIT: Optional[float] = None

# Timestamp of the last call
_last_call_time: float = 0.0


def set_default_model(model: str) -> None:
    """
    Set the default model for all calls.

    Args:
        model: Model alias ('sonnet', 'opus', 'haiku') or full model name

    Example:
        >>> set_default_model("opus")
        >>> call_claude("Hello")  # Uses opus
    """
    global DEFAULT_MODEL
    DEFAULT_MODEL = model


def set_default_rate_limit(seconds: Optional[float]) -> None:
    """
    Set the default minimum delay between calls (rate limiting).

    Args:
        seconds: Minimum seconds to wait between calls. None disables rate limiting.

    Example:
        >>> set_default_rate_limit(2.0)  # Wait at least 2 seconds between calls
        >>> set_default_rate_limit(None)  # Disable rate limiting
    """
    global DEFAULT_RATE_LIMIT
    DEFAULT_RATE_LIMIT = seconds


def _apply_rate_limit(rate_limit: Optional[float]) -> None:
    """Enforce minimum delay between calls."""
    global _last_call_time
    effective = rate_limit if rate_limit is not None else DEFAULT_RATE_LIMIT
    if effective and effective > 0:
        elapsed = time.monotonic() - _last_call_time
        wait = effective - elapsed
        if wait > 0:
            time.sleep(wait)
    _last_call_time = time.monotonic()


def _run_claude_command(
    args: list,
    streaming: bool = False
) -> Union[subprocess.CompletedProcess, subprocess.Popen]:
    """
    Run a Claude CLI command, handling Windows/WSL compatibility.

    Args:
        args: List of arguments to pass to claude CLI
        streaming: If True, return Popen object for streaming output

    Returns:
        CompletedProcess for normal calls, Popen for streaming
    """
    base_cmd = ["claude"] + args

    # Check if we're on Windows (need to go through WSL)
    is_windows = sys.platform == "win32"

    if is_windows:
        # Escape arguments properly for bash
        escaped_args = []
        for arg in base_cmd:
            # Escape single quotes and wrap in single quotes
            escaped = arg.replace("'", "'\\''")
            escaped_args.append(f"'{escaped}'")
        cmd_str = " ".join(escaped_args)
        # Add common npm/node paths and source profiles to ensure claude is found
        path_setup = (
            "export PATH=\"$HOME/.npm-global/bin:$HOME/.nvm/versions/node/*/bin:"
            "$HOME/.local/bin:/usr/local/bin:$PATH\"; "
            "source ~/.nvm/nvm.sh 2>/dev/null; "
            "source ~/.bashrc 2>/dev/null; "
        )
        shell_cmd = f"{path_setup}{cmd_str}"
        cmd = ["wsl", "bash", "-c", shell_cmd]
    else:
        cmd = base_cmd

    if streaming:
        return subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            bufsize=1
        )
    else:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )


def call_claude(
    prompt: str,
    allowed_tools: Optional[list] = None,
    model: Optional[str] = None,
    rate_limit: Optional[float] = None
) -> str:
    """
    Call Claude Code CLI with a given prompt.

    Args:
        prompt: The user message to send to Claude
        allowed_tools: Optional list of tools to allow (e.g., ["Read", "Bash"])
        model: Model to use ('sonnet', 'opus', 'haiku' or full model name)

    Returns:
        The text response from Claude

    Raises:
        RuntimeError: If Claude Code returns an error

    Example:
        >>> response = call_claude("What is 2 + 2?")
        >>> print(response)
        4

        >>> response = call_claude("Complex task", model="opus")
        >>> response = call_claude("Hello", rate_limit=2.0)  # Wait 2s between calls
    """
    _apply_rate_limit(rate_limit)
    args = ["-p", prompt, "--output-format", "text"]

    effective_model = model or DEFAULT_MODEL
    if effective_model:
        args.extend(["--model", effective_model])

    if allowed_tools:
        args.extend(["--allowedTools", ",".join(allowed_tools)])

    result = _run_claude_command(args)

    if result.returncode != 0:
        raise RuntimeError(f"Claude Code error: {result.stderr}")

    return result.stdout.strip()


def call_claude_with_system(
    prompt: str,
    system: str,
    model: Optional[str] = None,
    rate_limit: Optional[float] = None
) -> str:
    """
    Call Claude Code CLI with a system prompt and user message.

    Args:
        prompt: The user message to send to Claude
        system: The system prompt to set Claude's behavior
        model: Model to use ('sonnet', 'opus', 'haiku' or full model name)

    Returns:
        The text response from Claude

    Raises:
        RuntimeError: If Claude Code returns an error

    Example:
        >>> response = call_claude_with_system(
        ...     prompt="Explain gravity",
        ...     system="You are a teacher for 5-year-olds."
        ... )
    """
    _apply_rate_limit(rate_limit)
    args = ["-p", prompt, "--system-prompt", system, "--output-format", "text"]

    effective_model = model or DEFAULT_MODEL
    if effective_model:
        args.extend(["--model", effective_model])

    result = _run_claude_command(args)

    if result.returncode != 0:
        raise RuntimeError(f"Claude Code error: {result.stderr}")

    return result.stdout.strip()


def call_claude_json(
    prompt: str,
    allowed_tools: Optional[list] = None,
    model: Optional[str] = None,
    rate_limit: Optional[float] = None
) -> dict:
    """
    Call Claude Code CLI and get JSON output with full metadata.

    Args:
        prompt: The user message to send to Claude
        allowed_tools: Optional list of tools to allow
        model: Model to use ('sonnet', 'opus', 'haiku' or full model name)

    Returns:
        Dictionary containing:
        - result: The text response
        - usage: Token usage statistics
        - duration_ms: Response time in milliseconds
        - session_id: Session identifier

    Raises:
        RuntimeError: If Claude Code returns an error

    Example:
        >>> response = call_claude_json("What is the capital of France?")
        >>> print(response["result"])
        Paris
        >>> print(response["usage"])
        {'input_tokens': 10, 'output_tokens': 5, ...}
    """
    _apply_rate_limit(rate_limit)
    args = ["-p", prompt, "--output-format", "json"]

    effective_model = model or DEFAULT_MODEL
    if effective_model:
        args.extend(["--model", effective_model])

    if allowed_tools:
        args.extend(["--allowedTools", ",".join(allowed_tools)])

    result = _run_claude_command(args)

    if result.returncode != 0:
        raise RuntimeError(f"Claude Code error: {result.stderr}")

    return json.loads(result.stdout)


def call_claude_streaming(
    prompt: str,
    allowed_tools: Optional[list] = None,
    callback: Optional[Callable[[str], None]] = None,
    model: Optional[str] = None,
    rate_limit: Optional[float] = None
) -> str:
    """
    Call Claude Code CLI with streaming output.

    Args:
        prompt: The user message to send to Claude
        allowed_tools: Optional list of tools to allow
        callback: Optional function called with each text chunk.
                  If None, prints to stdout.
        model: Model to use ('sonnet', 'opus', 'haiku' or full model name)

    Returns:
        The complete response text

    Example:
        >>> # Print as it streams
        >>> response = call_claude_streaming("Write a poem")

        >>> # Custom callback
        >>> chunks = []
        >>> response = call_claude_streaming(
        ...     "Write a poem",
        ...     callback=lambda chunk: chunks.append(chunk)
        ... )
    """
    _apply_rate_limit(rate_limit)
    args = [
        "-p", prompt,
        "--output-format", "stream-json",
        "--verbose",
        "--include-partial-messages"
    ]

    effective_model = model or DEFAULT_MODEL
    if effective_model:
        args.extend(["--model", effective_model])

    if allowed_tools:
        args.extend(["--allowedTools", ",".join(allowed_tools)])

    process = _run_claude_command(args, streaming=True)

    last_text_length = 0
    full_response = ""

    for line in iter(process.stdout.readline, ''):
        line = line.strip()
        if not line:
            continue

        try:
            data = json.loads(line)
            msg_type = data.get("type")

            if msg_type == "assistant":
                message = data.get("message", {})
                content = message.get("content", [])

                for block in content:
                    if block.get("type") == "text":
                        full_text = block.get("text", "")
                        new_text = full_text[last_text_length:]

                        if new_text:
                            if callback:
                                callback(new_text)
                            else:
                                print(new_text, end="", flush=True)
                            last_text_length = len(full_text)
                            full_response = full_text

        except json.JSONDecodeError:
            continue

    process.wait()

    if not callback:
        print()  # Final newline

    return full_response


class ClaudeClient:
    """
    A class-based interface for calling Claude via Claude Code CLI.

    Example:
        >>> client = ClaudeClient(model="opus")
        >>> response = client.ask("Summarize README.md")

        >>> client = ClaudeClient(model="haiku", default_tools=["Read"])
        >>> response = client.ask("What's in this file?")
    """

    def __init__(
        self,
        default_tools: Optional[list] = None,
        default_system: Optional[str] = None,
        model: Optional[str] = None,
        rate_limit: Optional[float] = None
    ):
        """
        Initialize the Claude client.

        Args:
            default_tools: Default tools to allow for all calls
            default_system: Default system prompt for all calls
            model: Default model ('sonnet', 'opus', 'haiku' or full name)
            rate_limit: Minimum seconds between calls (e.g. 2.0)
        """
        self.default_tools = default_tools
        self.default_system = default_system
        self.model = model
        self.rate_limit = rate_limit

    def ask(
        self,
        prompt: str,
        tools: Optional[list] = None,
        system: Optional[str] = None,
        model: Optional[str] = None
    ) -> str:
        """
        Send a prompt to Claude and get a response.

        Args:
            prompt: The message to send
            tools: Tools to allow (overrides default_tools)
            system: System prompt (overrides default_system)
            model: Model to use (overrides default model)

        Returns:
            Text response from Claude
        """
        effective_tools = tools if tools is not None else self.default_tools
        effective_system = system if system is not None else self.default_system
        effective_model = model if model is not None else self.model

        if effective_system:
            return call_claude_with_system(prompt, effective_system, model=effective_model, rate_limit=self.rate_limit)
        else:
            return call_claude(prompt, effective_tools, model=effective_model, rate_limit=self.rate_limit)

    def ask_json(
        self,
        prompt: str,
        tools: Optional[list] = None,
        model: Optional[str] = None
    ) -> dict:
        """
        Send a prompt and get JSON response with metadata.

        Args:
            prompt: The message to send
            tools: Tools to allow (overrides default_tools)
            model: Model to use (overrides default model)

        Returns:
            Dictionary with response and metadata
        """
        effective_tools = tools if tools is not None else self.default_tools
        effective_model = model if model is not None else self.model
        return call_claude_json(prompt, effective_tools, model=effective_model, rate_limit=self.rate_limit)

    def ask_streaming(
        self,
        prompt: str,
        tools: Optional[list] = None,
        callback: Optional[Callable[[str], None]] = None,
        model: Optional[str] = None
    ) -> str:
        """
        Send a prompt with streaming output.

        Args:
            prompt: The message to send
            tools: Tools to allow (overrides default_tools)
            callback: Function called with each chunk
            model: Model to use (overrides default model)

        Returns:
            Complete response text
        """
        effective_tools = tools if tools is not None else self.default_tools
        effective_model = model if model is not None else self.model
        return call_claude_streaming(prompt, effective_tools, callback, model=effective_model, rate_limit=self.rate_limit)
