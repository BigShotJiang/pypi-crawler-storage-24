"""
Claude Code Headless - Call Claude using your Max subscription via Claude Code CLI.

This package provides a Python interface to Claude Code's headless mode,
allowing you to integrate Claude into your scripts without API credits.

Example:
    >>> from claude_code_headless import call_claude
    >>> response = call_claude("What is the meaning of life?")
    >>> print(response)

    >>> # Use a specific model
    >>> response = call_claude("Complex reasoning task", model="opus")

    >>> from claude_code_headless import ClaudeClient
    >>> client = ClaudeClient(model="sonnet", default_system="Be concise.")
    >>> response = client.ask("Explain Python in one sentence.")

Available models:
    - "sonnet" (default, balanced)
    - "opus" (most capable)
    - "haiku" (fastest)
    - Or use full model names like "claude-sonnet-4-5-20250929"
"""

from .client import (
    call_claude,
    call_claude_with_system,
    call_claude_json,
    call_claude_streaming,
    ClaudeClient,
    set_default_model,
    set_default_rate_limit,
    DEFAULT_MODEL,
    DEFAULT_RATE_LIMIT,
)

__version__ = "0.1.2"
__all__ = [
    "call_claude",
    "call_claude_with_system",
    "call_claude_json",
    "call_claude_streaming",
    "ClaudeClient",
    "set_default_model",
    "set_default_rate_limit",
]
