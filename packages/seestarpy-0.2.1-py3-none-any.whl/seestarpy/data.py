# seestar_smb_utils.py
# Utilities for listing, deleting, and downloading data from a Seestar S50
# Listing/deleting uses pysmb over direct SMB (port 445)
# Downloading uses mounted SMB paths on Unix; Windows uses native SMB paths

import os
from typing import Dict

from smb.SMBConnection import SMBConnection
from smb.smb_structs import OperationFailure
from .connection import multiple_ips
from .raw import get_albums

SHARE_NAME = "EMMC Images"
ROOT_DIR = "MyWorks"


def _connect_smb() -> SMBConnection:
    """
    Create and return an SMBConnection using direct TCP (port 445).

    Uses the module-level :data:`connection.DEFAULT_IP`, which the
    :func:`~connection.multiple_ips` decorator swaps per-thread.

    Returns
    -------
    SMBConnection
        An open SMB connection to the Seestar.

    Raises
    ------
    ConnectionError
        If the connection to the Seestar fails.
    """
    from . import connection

    ip = connection.DEFAULT_IP
    conn = SMBConnection(
        username='',
        password='',
        my_name='raspi',
        remote_name='seestar',
        use_ntlm_v2=False,
        is_direct_tcp=True
    )
    connected = conn.connect(ip, 445)

    if not connected:
        raise ConnectionError(f"Could not connect to Seestar at {ip} via SMB")

    return conn


@multiple_ips
def list_folders() -> Dict[str, int]:
    """
    List all observation folders stored on the Seestar's internal eMMC.

    Each observation session creates a folder under ``MyWorks`` (e.g.
    ``"M 81"``, ``"Lunar"``).  This function returns every folder
    together with the number of album entries it contains (i.e. stacked
    results, not individual files).  Use :func:`list_folder_contents` to
    get the actual file listing.

    Returns
    -------
    dict of {str: int}
        Mapping of folder names to the number of album entries they
        contain.

    Examples
    --------

        >>> from seestarpy import data
        >>> data.list_folders()
        {'M 81': 1, 'M 81_sub': 2053, 'Lunar': 2}

    """
    response = get_albums()
    summary = {}
    for group in response.get("result", {}).get("list", []):
        for entry in group.get("files", []):
            summary[entry["name"]] = entry["count"]
    return summary


@multiple_ips
def list_folder_contents(folder: str, filetype: str = "*") -> Dict[str, int]:
    """
    List every file inside an observation folder on the Seestar's eMMC.

    Parameters
    ----------
    folder : str
        Name of the folder under ``MyWorks`` to list (e.g. ``"M 81_sub"``).
    filetype : str, optional
        Filter files by type. One of:

        - ``"*"`` — all files (default)
        - ``"fit"`` — FITS files only (``.fit``)
        - ``"jpg"`` — full-size JPEGs only (excludes thumbnails)
        - ``"thn.jpg"`` — thumbnail JPEGs only (``_thn.jpg``)
        - ``"*jpg"`` — all JPEGs (full-size and thumbnails)

    Returns
    -------
    dict of {str: int}
        Mapping of file names to their sizes in bytes.

    Examples
    --------

        >>> from seestarpy import data
        >>> files = data.list_folder_contents("M 81_sub", filetype="fit")
        >>> for name, size in list(files.items())[:3]:
        ...     print(f"{name}: {size / 1024:.0f} KB")
        Light_M 81_10.0s_IRCUT_20250607-221746.fit: 4050 KB
        Light_M 81_10.0s_IRCUT_20250607-221758.fit: 4050 KB
        Light_M 81_10.0s_IRCUT_20250607-221810.fit: 4050 KB

    """
    _valid = {"*", "fit", "jpg", "thn.jpg", "*jpg"}
    if filetype not in _valid:
        raise ValueError(f"filetype must be one of {_valid}, got {filetype!r}")

    conn = _connect_smb()
    contents = {}

    try:
        entries = conn.listPath(SHARE_NAME, f"{ROOT_DIR}/{folder}")
        for entry in entries:
            if not entry.isDirectory and entry.filename not in {".", ".."}:
                name = entry.filename
                if filetype == "*":
                    pass
                elif filetype == "fit":
                    if not name.endswith(".fit"):
                        continue
                elif filetype == "thn.jpg":
                    if not name.endswith("_thn.jpg"):
                        continue
                elif filetype == "*jpg":
                    if not name.endswith(".jpg"):
                        continue
                elif filetype == "jpg":
                    if not name.endswith(".jpg") or name.endswith("_thn.jpg"):
                        continue
                contents[name] = entry.file_size
    except OperationFailure:
        pass
    finally:
        conn.close()

    return contents


@multiple_ips
def delete_folder(folder: str) -> None:
    """
    Recursively delete an observation folder and all its files via SMB.

    .. warning::
        This permanently removes data from the Seestar's internal eMMC
        storage. There is no undo.

    Parameters
    ----------
    folder : str
        Name of the folder under ``MyWorks`` to delete (e.g.
        ``"M 81_sub"``).

    Examples
    --------

        >>> from seestarpy import data
        >>> data.list_folders()
        {'M 81': 3, 'M 81_sub': 37, 'Lunar': 2}
        >>> data.delete_folder("M 81_sub")
        >>> data.list_folders()
        {'M 81': 3, 'Lunar': 2}

    """
    conn = _connect_smb()

    try:
        path = f"{ROOT_DIR}/{folder}"
        entries = conn.listPath(SHARE_NAME, path)

        for entry in entries:
            if entry.filename in {".", ".."}:
                continue

            full_path = f"{path}/{entry.filename}"
            if entry.isDirectory:
                _delete_folder_recursive(conn, f"{folder}/{entry.filename}")
            else:
                conn.deleteFiles(SHARE_NAME, full_path)

        conn.deleteDirectory(SHARE_NAME, path)
    except OperationFailure:
        pass
    finally:
        conn.close()


def _delete_folder_recursive(conn: SMBConnection, folder: str) -> None:
    """Recursively delete a subfolder using an existing SMB connection."""
    path = f"{ROOT_DIR}/{folder}"
    entries = conn.listPath(SHARE_NAME, path)

    for entry in entries:
        if entry.filename in {".", ".."}:
            continue

        full_path = f"{path}/{entry.filename}"
        if entry.isDirectory:
            _delete_folder_recursive(conn, f"{folder}/{entry.filename}")
        else:
            conn.deleteFiles(SHARE_NAME, full_path)

    conn.deleteDirectory(SHARE_NAME, path)


@multiple_ips
def download_folder(folder: str = "", dest: str = "") -> None:
    """
    Download an entire observation folder from the Seestar's eMMC via SMB.

    Copies every file from the given folder under ``MyWorks`` to a local
    directory.  Progress is printed to stdout as each file completes.

    Parameters
    ----------
    folder : str
        Name of the folder under ``MyWorks`` to download (e.g.
        ``"M 81_sub"``).
    dest : str
        Local directory where the folder will be saved.  Created
        automatically if it does not exist.

    Examples
    --------

        >>> from seestarpy import data
        >>> data.download_folder("M 81_sub", dest="/home/user/astro")
        Downloading 37 files from 'M 81_sub' (150.0 MB)...
          [1/37] Light_M 81_10.0s_IRCUT_20250607-221746.fit (4.05 MB) ✓
          ...
        ✓ Download complete: 37 files

    """
    os.makedirs(dest, exist_ok=True)

    # List files and download each one using SMB
    files = list_folder_contents(folder)
    folder_dest = os.path.join(dest, folder)
    os.makedirs(folder_dest, exist_ok=True)

    total_files = len(files)
    total_size = sum(files.values())
    print(
        f"📁 Downloading {total_files} files from '{folder}' ({total_size / 1024 / 1024:.1f} MB)...")

    conn = _connect_smb()
    try:
        for idx, (fname, fsize) in enumerate(files.items(), 1):
            remote_path = f"{ROOT_DIR}/{folder}/{fname}"
            local_path = os.path.join(folder_dest, fname)
            print(
                f"  [{idx}/{total_files}] {fname} ({fsize / 1024 / 1024:.2f} MB)",
                end="", flush=True)
            with open(local_path, "wb") as f:
                conn.retrieveFile(SHARE_NAME, remote_path, f)
            print(" ✓")
        print(f"✓ Download complete: {total_files} files")
    finally:
        conn.close()
