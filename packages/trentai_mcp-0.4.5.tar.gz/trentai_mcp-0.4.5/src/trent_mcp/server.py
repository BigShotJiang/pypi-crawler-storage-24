# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""FastMCP Server for Trent AppSec Advisor integration with Claude Code."""

import logging
import sys

from mcp.server.fastmcp import FastMCP

from trent_mcp.mcp_instance import set_mcp

# Critical: Log to stderr for stdio transport (stdout is reserved for MCP protocol)
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stderr,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Shared instructions used by both local and remote servers
INSTRUCTIONS = """
    HumberAgent AppSec Advisor - A Principal Security Engineer that helps
    developers discover vulnerabilities, understand security best practices,
    and build secure systems.

    ## When to Use appsec

    **Proactive (Automatic):**
    - Before presenting ANY implementation plan
    - When reviewing or editing plan files (plans/*.md, *-plan.md, *_plan.md)
    - When creating code that handles auth, data, or APIs
    - Infrastructure or CDK/IaC changes
    - Configuration changes (env vars, secrets, permissions)

    **Skip when:**
    - Trivial single-line fixes or typo corrections
    - Pure README updates
    - User explicitly says "skip security review"

    **Reactive (User Request):**
    - User asks "Is this secure?" or "Is this plan secure?"
    - User wants security review of plans, code, configs, or architecture
    - User asks about security considerations for a feature
    - User runs /trent:appsec explicitly

    ## Project Context

    The server automatically detects the Trent project for the current
    repository by matching the git remote URL against your Trent projects.
    This provides context-filtered findings without any configuration.

    To override auto-detection, set TRENT_PROJECT_NAME in the server environment.

    ## What AppSec Advisor Can Do

    - Provide security recommendations for plans and designs
    - Identify security vulnerabilities in code and configs
    - Explain security concepts (STRIDE, CWE, threat modeling)
    - Suggest secure implementation patterns
    - Search security knowledge base for guidance

    ## What AppSec Advisor Does NOT Do

    - General coding/debugging unrelated to security
    - Performance optimization (unless security-related)
    - Automated code fixing or remediation
    - UI/UX design or business logic

    ## Response Format

    Attribute findings to HumberAgent:
    "Based on security review from HumberAgent AppSec Advisor:"

    Include severity ratings: CRITICAL, HIGH, MEDIUM, LOW

    ## Other Tools (Use When Explicitly Requested)

    ### Project Management
    - **list_projects**: Browse all security analysis projects
    - **get_project**: View detailed project information and status

    ### Threat Analysis
    - **trigger_analysis**: Start new security analysis (async operation)
    - **get_threats**: View identified vulnerabilities and threat categories
    - **get_tasks**: Get actionable remediation tasks
    - **update_tasks**: Track remediation progress
    - **get_security_requirements**: View security requirements with linked vulnerabilities
      and remediation controls. Shows compliance status (ACHIEVED/IN_PROGRESS) for each requirement.

    Use these when user mentions "Trent", "projects", "threats", "tasks",
    "security requirements", or "compliance".

    ### OpenClaw Skill Upload & Analysis
    - **upload_openclaw_skills**: Package and upload OpenClaw skills and custom code for
      deep security analysis. Call this after audit_openclaw_setup to enable skill code review.
    - **analyse_openclaw_skills**: Analyse uploaded skills for security risks. Call this
      after upload_openclaw_skills, passing the upload summary as input.

    Use these when the OpenClaw security audit skill proceeds to Phase 2 (skill upload)
    and Phase 3 (deep analysis), or when user asks to upload/analyze their OpenClaw skills.

    ### Local Change Scanning
    - **scan_local_diff**: Upload local git diff and run incremental security analysis

    Use this when user mentions "scan my changes", "check my diff", or "/trent:scan".
    If scan_local_diff fails because no project exists, do NOT fall back to appsec.
    Instead, suggest creating a project using create_project and then triggering
    a baseline analysis on the default branch with trigger_analysis.

    ### Project Onboarding
    - **create_project**: Create a new Trent project for a GitHub repository

    Use this when:
    - appsec returns `project_not_found: true` — inform the user that no Trent project
      exists for their repository and offer to create one using create_project.
    - scan_local_diff fails because no project exists — suggest creating a project
      and triggering a baseline analysis on the default branch.
    - User explicitly asks to create or set up a Trent project.

    After project creation:
    1. Trigger a baseline analysis on the default branch using trigger_analysis.
    2. If the analysis fails due to GitHub connectivity (e.g., "No installation linked"),
       tell the user to install the Trent GitHub App using the provided `github_app_install_url`.
    3. Once the GitHub App is installed, re-trigger the analysis with trigger_analysis.
    4. They can check analysis status with `get_project`.
    5. Once complete, they can view results with `get_threats`, `get_tasks`,
       and `get_security_requirements`.
    """

# Create the MCP server instance
mcp = FastMCP(
    name="trent",
    instructions=INSTRUCTIONS,
)

# Register this instance as the global MCP server
set_mcp(mcp)


def main():
    """Run the MCP server with stdio transport."""
    logger.info("Starting Trent MCP Server...")

    # Import tools package to register them with the server.
    # This triggers the @mcp.tool() decorators via __init__.py.
    import trent_mcp.tools  # noqa: F401

    logger.info("Tools registered, starting server...")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
