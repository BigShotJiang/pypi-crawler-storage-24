# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""OpenClaw skill packaging and upload MCP tool for Trent MCP Server.

Thin MCP wrapper around the shared upload logic in
``trent_mcp.openclaw.upload_skills``.
"""

import logging
from pathlib import Path
from typing import Annotated

from mcp.server.fastmcp import Context
from pydantic import Field

from trent_mcp.mcp_instance import get_mcp
from trent_mcp.tools.appsec import _get_shared_client

mcp = get_mcp()

logger = logging.getLogger(__name__)

SOURCE_NAME = "HumberAgent OpenClaw Skill Upload"


@mcp.tool()
async def upload_openclaw_skills(
    openclaw_workspace_path: Annotated[
        str | None,
        Field(
            description="Path to OpenClaw workspace directory. Defaults to ~/.openclaw/workspace. "
            "This is where skills and custom code are located."
        ),
    ] = None,
    ctx: Context | None = None,
) -> dict:
    """
    Package and upload OpenClaw skills and custom code for deep security analysis.

    Scans the OpenClaw workspace for installed skills and custom code projects,
    packages each as a .skill ZIP archive, and uploads them to Trent via
    presigned S3 URLs. Uses SHA256 digest-based deduplication to skip
    unchanged skills.

    Call this after audit_openclaw_setup to enable deep skill code analysis.
    The .skill files are left in the workspace after upload.
    """
    from trent_mcp.openclaw.package_skills import scan_workspace
    from trent_mcp.openclaw.upload_skills import upload_packaged_skills

    if ctx:
        await ctx.info("Packaging OpenClaw skills and custom code...")
        await ctx.report_progress(progress=5, total=100)

    # --- Package skills ---
    workspace_arg = Path(openclaw_workspace_path) if openclaw_workspace_path else None
    try:
        skills = scan_workspace(workspace=workspace_arg)
    except Exception as e:
        logger.error("Failed to scan workspace: %s", e, exc_info=True)
        return {
            "source": SOURCE_NAME,
            "error": True,
            "message": f"Failed to scan workspace: {e}",
        }

    if ctx:
        await ctx.info(f"Found {len(skills)} skill(s). Starting upload...")
        await ctx.report_progress(progress=10, total=100)

    # --- Upload via shared logic ---
    client = _get_shared_client()

    async def _mcp_progress(message: str, progress: int, total: int) -> None:
        if ctx:
            await ctx.info(message)
            await ctx.report_progress(progress=progress, total=total)

    return await upload_packaged_skills(
        client=client,
        skills=skills,
        on_progress=_mcp_progress,
    )
