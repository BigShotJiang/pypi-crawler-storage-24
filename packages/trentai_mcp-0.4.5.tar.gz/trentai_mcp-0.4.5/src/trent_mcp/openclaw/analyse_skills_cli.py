# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""CLI entry point for deep analysis of uploaded OpenClaw skills."""

import argparse
import asyncio
import json
import sys

from trent_mcp import __version__

CLI_ANALYSE_TIMEOUT = 180  # seconds


def main():
    """Analyse uploaded OpenClaw skills for security risks."""
    parser = argparse.ArgumentParser(
        prog="trent-openclaw-analyse-skills",
        description="Analyse uploaded OpenClaw skills for security risks.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--thread-id",
        type=str,
        required=True,
        help="Chat thread ID from Phase 1 audit (for conversation continuity)",
    )
    parser.add_argument(
        "--upload-summary",
        type=str,
        required=True,
        help="Path to upload summary JSON file from Phase 2, or '-' for stdin",
    )
    args = parser.parse_args()

    # Read upload summary
    try:
        if args.upload_summary == "-":
            upload_summary = json.load(sys.stdin)
        else:
            with open(args.upload_summary) as f:
                upload_summary = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in upload summary: {e}", file=sys.stderr)
        sys.exit(1)
    except OSError as e:
        print(f"Error: Cannot read upload summary: {e}", file=sys.stderr)
        sys.exit(1)

    # Validate upload summary has skills
    skills = upload_summary.get("skills", [])
    analysable = [s for s in skills if s.get("status") in ("uploaded", "skipped")]
    if not analysable:
        print("No uploaded or unchanged skills to analyse.", file=sys.stderr)
        sys.exit(0)

    print(
        f"Analysing {len(analysable)} skill(s) on thread {args.thread_id[:12]}...",
        file=sys.stderr,
    )

    async def _do_analyse():
        from trent_mcp.client.trent_api import TrentAPIClient
        from trent_mcp.tools.openclaw_audit import _build_skill_analysis_prompt

        client = TrentAPIClient(thread_id=args.thread_id)
        message = _build_skill_analysis_prompt(upload_summary)
        try:
            return await asyncio.wait_for(
                client.chat(message=message),
                timeout=CLI_ANALYSE_TIMEOUT,
            )
        finally:
            await client.close()

    try:
        response = asyncio.run(_do_analyse())
    except asyncio.TimeoutError:
        print(
            f"\n  Analysis timed out after {CLI_ANALYSE_TIMEOUT}s. Try again later.",
            file=sys.stderr,
        )
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n  Analysis cancelled.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n  Analysis failed: {e}", file=sys.stderr)
        sys.exit(1)

    if response.get("error"):
        print(f"\n  Error: {response['content']}", file=sys.stderr)
        sys.exit(1)

    print("--- OpenClaw Deep Skill Analysis Results ---\n")
    print(response["content"])
    print("\n--- End of Skill Analysis ---")

    thread_id = response.get("thread_id")
    if thread_id:
        print(f"\n[TRENT_THREAD_ID:{thread_id}]")


if __name__ == "__main__":
    main()
