# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""CLI entry point for packaging and uploading OpenClaw skills."""

import argparse
import asyncio
import json
import sys
from pathlib import Path

from trent_mcp import __version__

CLI_UPLOAD_TIMEOUT = 300  # seconds (upload can be slow for many/large skills)


def main():
    """Package and upload OpenClaw skills for deep security analysis."""
    parser = argparse.ArgumentParser(
        prog="trent-openclaw-upload-skills",
        description="Package and upload OpenClaw skills for deep security analysis.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to OpenClaw workspace directory (default: ~/.openclaw/workspace)",
    )
    args = parser.parse_args()

    from trent_mcp.openclaw.package_skills import scan_workspace

    workspace_arg = Path(args.path) if args.path else None
    try:
        skills = scan_workspace(workspace=workspace_arg)
    except Exception as e:
        print(f"Error: Failed to scan workspace: {e}", file=sys.stderr)
        sys.exit(1)

    if not skills:
        # Output valid JSON even when empty
        print(
            json.dumps(
                {
                    "skills": [],
                    "summary": {
                        "total": 0,
                        "uploaded": 0,
                        "skipped": 0,
                        "failed": 0,
                        "too_large": 0,
                    },
                },
                indent=2,
            )
        )
        print("No skills or custom code found in workspace.", file=sys.stderr)
        return

    print(f"Found {len(skills)} skill(s). Uploading...", file=sys.stderr)

    def _cli_progress(message: str, progress: int, total: int) -> None:
        print(f"  [{progress}/{total}] {message}", file=sys.stderr)

    async def _do_upload():
        from trent_mcp.client.trent_api import TrentAPIClient
        from trent_mcp.openclaw.upload_skills import upload_packaged_skills

        client = TrentAPIClient()
        try:
            return await asyncio.wait_for(
                upload_packaged_skills(
                    client=client,
                    skills=skills,
                    on_progress=_cli_progress,
                ),
                timeout=CLI_UPLOAD_TIMEOUT,
            )
        finally:
            await client.close()

    try:
        result = asyncio.run(_do_upload())
    except asyncio.TimeoutError:
        print(
            f"\n  Upload timed out after {CLI_UPLOAD_TIMEOUT}s. Try again later.",
            file=sys.stderr,
        )
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n  Upload cancelled.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n  Upload failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Output upload summary as JSON to stdout (consumed by Phase 3 CLI)
    print(json.dumps(result, indent=2))

    summary = result.get("summary", {})
    print(
        f"\nDone: {summary.get('uploaded', 0)} uploaded, "
        f"{summary.get('skipped', 0)} unchanged, "
        f"{summary.get('failed', 0)} failed, "
        f"{summary.get('too_large', 0)} too large.",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
