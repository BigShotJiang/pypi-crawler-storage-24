# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""CLI commands for OpenClaw Trent audit."""

import argparse
import sys
from pathlib import Path

from trent_mcp import __version__

CLI_AUDIT_TIMEOUT = 180  # seconds (sub-agent + attack chain validation takes ~120s)
CLI_UPLOAD_TIMEOUT = 300  # seconds (upload can be slow for many/large skills)
CLI_ANALYSE_TIMEOUT = 180  # seconds


def _run_audit_sync(metadata: dict, system_info: dict | None = None) -> dict | None:
    """Run the OpenClaw security audit synchronously from the CLI.

    Returns the API response dict (with ``content`` and ``thread_id``) on
    success, or ``None`` on failure.
    """
    import asyncio

    redacted_count = len(metadata.get("redacted_paths", []))
    skill_count = len(metadata.get("skills", []))
    print(f"  Collected metadata: {skill_count} skill(s), {redacted_count} secret(s) redacted")
    if system_info:
        os_type = system_info.get("os", {}).get("os_type", "unknown")
        hw_type = system_info.get("hardware", {}).get("type", "unknown")
        print(f"  System context: {os_type} / {hw_type}")
    print("  Sending to Trent AppSec Advisor (no secrets transmitted)...\n")

    # Build prompt
    from trent_mcp.openclaw.audit_prompt import build_audit_prompt

    message = build_audit_prompt(metadata, system_info=system_info)

    # Send to chat endpoint
    async def _do_audit():
        from trent_mcp.client.trent_api import TrentAPIClient

        client = TrentAPIClient()
        try:
            return await asyncio.wait_for(
                client.chat(message=message),
                timeout=CLI_AUDIT_TIMEOUT,
            )
        finally:
            await client.close()

    try:
        response = asyncio.run(_do_audit())
    except asyncio.TimeoutError:
        print(
            f"\n  Audit timed out after {CLI_AUDIT_TIMEOUT}s. Try again later.",
            file=sys.stderr,
        )
        return None
    except KeyboardInterrupt:
        print("\n  Audit cancelled.", file=sys.stderr)
        return None
    except Exception as e:
        print(f"\n  Audit failed: {e}", file=sys.stderr)
        return None

    if response.get("error"):
        print(f"\n  Error: {response['content']}", file=sys.stderr)
        return None

    print("--- OpenClaw Security Audit Results ---\n")
    print(response["content"])
    print("\n--- End of Audit ---")

    thread_id = response.get("thread_id")
    if thread_id:
        print(f"\n[TRENT_THREAD_ID:{thread_id}]")

    return response


def _run_full_audit_sync(metadata: dict, system_info: dict | None = None) -> None:
    """Run all 3 audit phases in a single process with shared client."""
    import asyncio

    redacted_count = len(metadata.get("redacted_paths", []))
    skill_count = len(metadata.get("skills", []))
    print(f"  Collected metadata: {skill_count} skill(s), {redacted_count} secret(s) redacted")
    if system_info:
        os_type = system_info.get("os", {}).get("os_type", "unknown")
        hw_type = system_info.get("hardware", {}).get("type", "unknown")
        print(f"  System context: {os_type} / {hw_type}")
    print("  Sending to Trent AppSec Advisor (no secrets transmitted)...\n")

    from trent_mcp.openclaw.audit_prompt import build_audit_prompt

    message = build_audit_prompt(metadata, system_info=system_info)

    async def _do_full_audit():
        from trent_mcp.client.trent_api import TrentAPIClient
        from trent_mcp.openclaw.package_skills import scan_workspace
        from trent_mcp.openclaw.upload_skills import upload_packaged_skills
        from trent_mcp.tools.openclaw_audit import _build_skill_analysis_prompt

        # Single client instance — thread_id flows automatically across phases
        client = TrentAPIClient()
        try:
            # --- Phase 1: Configuration Audit ---
            print("=== Phase 1: Configuration Audit ===\n")
            response = await asyncio.wait_for(
                client.chat(message=message),
                timeout=CLI_AUDIT_TIMEOUT,
            )

            if response.get("error"):
                print(f"  Error: {response['content']}", file=sys.stderr)
                return

            print(response["content"])
            print("\n--- Phase 1 complete ---\n")

            # --- Phase 2: Skill Upload ---
            print("=== Phase 2: Skill Upload ===\n")
            skills = scan_workspace()

            if not skills:
                print("  No skills or custom code found. Skipping Phase 2 and 3.")
                return

            def _cli_progress(msg: str, progress: int, total: int) -> None:
                print(f"  [{progress}/{total}] {msg}", file=sys.stderr)

            upload_result = await asyncio.wait_for(
                upload_packaged_skills(
                    client=client,
                    skills=skills,
                    on_progress=_cli_progress,
                ),
                timeout=CLI_UPLOAD_TIMEOUT,
            )

            summary = upload_result.get("summary", {})
            uploaded = summary.get("uploaded", 0)
            skipped = summary.get("skipped", 0)
            failed = summary.get("failed", 0)
            print(
                f"\n  {uploaded} uploaded, {skipped} unchanged, {failed} failed.",
                file=sys.stderr,
            )

            # Check if there's anything to analyse
            analysable = [
                s
                for s in upload_result.get("skills", [])
                if s.get("status") in ("uploaded", "skipped")
            ]
            if not analysable:
                print("  No skills available for deep analysis.")
                return

            print("\n--- Phase 2 complete ---\n")

            # --- Phase 3: Deep Skill Analysis ---
            print("=== Phase 3: Deep Skill Analysis ===\n")
            analysis_msg = _build_skill_analysis_prompt(upload_result)

            analysis_response = await asyncio.wait_for(
                client.chat(message=analysis_msg),
                timeout=CLI_ANALYSE_TIMEOUT,
            )

            if analysis_response.get("error"):
                print(f"  Error: {analysis_response['content']}", file=sys.stderr)
                return

            print(analysis_response["content"])
            print("\n--- Phase 3 complete ---")

            thread_id = analysis_response.get("thread_id")
            if thread_id:
                print(f"\n[TRENT_THREAD_ID:{thread_id}]")

        finally:
            await client.close()

    try:
        asyncio.run(_do_full_audit())
    except asyncio.TimeoutError:
        print("\n  Audit timed out. Try again later.", file=sys.stderr)
    except KeyboardInterrupt:
        print("\n  Audit cancelled.", file=sys.stderr)
    except Exception as e:
        print(f"\n  Audit failed: {e}", file=sys.stderr)


def audit():
    """Run OpenClaw security audit from the CLI."""
    parser = argparse.ArgumentParser(
        prog="trent-openclaw-audit",
        description="Audit your OpenClaw deployment for security risks.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to OpenClaw config directory (default: ~/.openclaw)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output raw JSON metadata instead of sending to Trent API",
    )
    parser.add_argument(
        "--config-only",
        action="store_true",
        help="Run only Phase 1 (configuration audit) without skill upload and analysis",
    )
    args = parser.parse_args()

    from trent_mcp.openclaw.openclaw_config.collector import collect_openclaw_metadata
    from trent_mcp.openclaw.system_analyzer import collect_system_analysis

    path_arg = Path(args.path) if args.path else None
    metadata = collect_openclaw_metadata(openclaw_path=path_arg)

    if metadata.get("error"):
        print(f"Error: {metadata['message']}", file=sys.stderr)
        sys.exit(1)

    system_info = collect_system_analysis(openclaw_path=path_arg)

    if args.json:
        import json

        metadata["system_analysis"] = system_info
        print(json.dumps(metadata, indent=2, default=str))
        return

    print("\nAnalyzing your OpenClaw configuration for security risks...\n")

    if args.config_only:
        _run_audit_sync(metadata, system_info=system_info)
    else:
        _run_full_audit_sync(metadata, system_info=system_info)
