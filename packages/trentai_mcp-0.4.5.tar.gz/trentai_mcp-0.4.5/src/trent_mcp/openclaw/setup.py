# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""OpenClaw Trent setup — installs skill, saves API key, runs first audit."""

import argparse
import os
import shutil
import stat
import sys
from pathlib import Path

from trent_mcp import __version__
from trent_mcp.config import TRENT_API_KEY_FILE, TRENT_CONFIG_DIR

SKILL_NAME = "trent-openclaw-security"
SKILL_FILENAME = "OPENCLAW_SECURITY_AUDIT.md"
KEY_FILE_PERMISSIONS = 0o600
CONFIG_DIR_PERMISSIONS = 0o700

DEFAULT_OPENCLAW_PATH = Path.home() / ".openclaw"


def _is_safe_path(path: Path) -> bool:
    """Check that path is not a symlink."""
    if path.is_symlink():
        print(f"Error: {path} is a symlink — refusing to write.", file=sys.stderr)
        return False
    return True


def _save_api_key(api_key: str) -> bool:
    """Save API key to ~/.trent/api-key with secure permissions."""
    if not _is_safe_path(TRENT_API_KEY_FILE):
        return False

    TRENT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(TRENT_CONFIG_DIR, CONFIG_DIR_PERMISSIONS)

    TRENT_API_KEY_FILE.write_text(api_key.strip() + "\n")
    os.chmod(TRENT_API_KEY_FILE, KEY_FILE_PERMISSIONS)

    # Verify permissions and ownership
    st = os.stat(TRENT_API_KEY_FILE)
    if st.st_uid != os.getuid():
        print("Error: Key file owned by different user.", file=sys.stderr)
        TRENT_API_KEY_FILE.unlink()
        return False
    if stat.S_IMODE(st.st_mode) != KEY_FILE_PERMISSIONS:
        print("Error: Failed to set secure permissions on key file.", file=sys.stderr)
        TRENT_API_KEY_FILE.unlink()
        return False

    print(f"  Key saved to {TRENT_API_KEY_FILE}")
    return True


def _install_skill(workspace_path: Path) -> bool:
    """Install SKILL.md to OpenClaw workspace skills directory."""
    package_dir = Path(__file__).parent
    src = package_dir / "skills" / SKILL_FILENAME

    if not src.exists():
        print(f"Error: Skill file not found at {src}", file=sys.stderr)
        return False

    target_dir = workspace_path / "skills" / SKILL_NAME
    if not _is_safe_path(target_dir):
        return False

    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "SKILL.md"
    shutil.copy2(src, target)
    print(f"  Installed skill: {SKILL_NAME}")
    return True


def _run_first_audit(openclaw_path: Path) -> None:
    """Run the first security audit."""
    import asyncio

    from trent_mcp.openclaw.audit_prompt import build_audit_prompt
    from trent_mcp.openclaw.openclaw_config.collector import collect_openclaw_metadata
    from trent_mcp.openclaw.system_analyzer import collect_system_analysis

    print("\nRunning security audit on your OpenClaw configuration...\n")

    metadata = collect_openclaw_metadata(openclaw_path=openclaw_path)
    if metadata.get("error"):
        print(f"  Error: {metadata['message']}", file=sys.stderr)
        return

    system_info = collect_system_analysis(openclaw_path=openclaw_path)

    redacted_count = len(metadata.get("redacted_paths", []))
    skill_count = len(metadata.get("skills", []))
    print(f"  Collected metadata: {skill_count} skill(s), {redacted_count} secret(s) redacted")
    if system_info:
        os_type = system_info.get("os", {}).get("os_type", "unknown")
        hw_type = system_info.get("hardware", {}).get("type", "unknown")
        print(f"  System context: {os_type} / {hw_type}")
    print("  Sending to Trent AppSec Advisor (no secrets transmitted)...\n")

    message = build_audit_prompt(metadata, system_info=system_info)

    async def _do_audit():
        from trent_mcp.client.trent_api import TrentAPIClient

        client = TrentAPIClient()
        try:
            return await asyncio.wait_for(client.chat(message=message), timeout=180)
        finally:
            await client.close()

    try:
        response = asyncio.run(_do_audit())
    except asyncio.TimeoutError:
        print("\n  Audit timed out. Try again later with: trent-openclaw-audit", file=sys.stderr)
        return
    except KeyboardInterrupt:
        print("\n  Audit cancelled.", file=sys.stderr)
        return
    except Exception as e:
        print(f"\n  Audit failed: {e}", file=sys.stderr)
        return

    if response.get("error"):
        print(f"\n  Error: {response['content']}", file=sys.stderr)
        return

    print("--- OpenClaw Security Audit Results ---\n")
    print(response["content"])
    print("\n--- End of Audit ---")


def setup():
    """Entry point for openclaw-trent-setup CLI."""
    parser = argparse.ArgumentParser(
        prog="openclaw-trent-setup",
        description="Set up Trent security audit for your OpenClaw deployment.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="Trent API key (prompted interactively if not provided)",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to OpenClaw config directory (default: ~/.openclaw)",
    )
    parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompt",
    )
    parser.add_argument(
        "--skip-audit",
        action="store_true",
        help="Skip the initial security audit",
    )
    args = parser.parse_args()

    # Resolve OpenClaw path
    openclaw_path = Path(args.path) if args.path else DEFAULT_OPENCLAW_PATH
    if not openclaw_path.is_dir():
        print(f"Error: OpenClaw config not found at {openclaw_path}", file=sys.stderr)
        print("Install OpenClaw first, then re-run this command.", file=sys.stderr)
        sys.exit(1)

    workspace_path = openclaw_path / "workspace"

    # Get API key
    api_key = args.api_key
    if not api_key:
        api_key = os.environ.get("TRENT_API_KEY", "").strip()

    if not api_key:
        print("You need a Trent API key.")
        print("  Visit https://app.trent.ai to generate one.")
        print("  Log out if you don't see the 'Get OpenClaw Access' button.\n")
        try:
            api_key = input("Paste your API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            sys.exit(1)

    if not api_key:
        print("Error: No API key provided.", file=sys.stderr)
        sys.exit(1)

    if not api_key.startswith("trent_"):
        print(
            "Warning: API key doesn't start with 'trent_'. Are you sure it's correct?",
            file=sys.stderr,
        )

    # Preview
    print(f"\nopenclaw-trent-setup — {openclaw_path}\n")
    print("This will:")
    print(f"  Save API key to {TRENT_API_KEY_FILE}")
    print(f"  Install skill to {workspace_path}/skills/{SKILL_NAME}/")
    if not args.skip_audit:
        print("  Run a security audit on your configuration")
    print()

    if not args.yes:
        try:
            answer = input("Proceed? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            sys.exit(1)
        if answer in ("n", "no"):
            print("Aborted.")
            sys.exit(0)

    # Set TRENT_API_KEY env var so the audit can use it
    os.environ["TRENT_API_KEY"] = api_key

    # 1. Save API key
    if not _save_api_key(api_key):
        sys.exit(1)

    # 2. Install skill
    if not _install_skill(workspace_path):
        sys.exit(1)

    # 3. Run first audit (unless skipped)
    if not args.skip_audit:
        _run_first_audit(openclaw_path)

    print("\nSetup complete!")
    print("Ask your agent: 'Audit my OpenClaw setup for security risks'")
    print("Or run from the CLI: trent-openclaw-audit")
