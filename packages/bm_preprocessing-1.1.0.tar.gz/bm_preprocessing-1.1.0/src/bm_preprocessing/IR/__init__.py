"""IR subpackage - Information Retrieval source code."""

from .all import all
from .all_vis import all_vis

__all__ = ["all", "all_vis"]
