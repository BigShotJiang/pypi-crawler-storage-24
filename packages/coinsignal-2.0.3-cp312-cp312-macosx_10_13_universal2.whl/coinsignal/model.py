# --------------------------------------------------------------------------------
# Copyright (c) 2025 Zehao Yang
#
# Author: Zehao Yang
#
# This module implements the main model training and evaluation pipeline:
# • Handling data splitting, scaling, cross-validation,
# • Training and evaluating models with various metrics
# --------------------------------------------------------------------------------


import _ext.scaler as _scaler
import _ext.loss as _loss
import _ext.model as _model


DEFAULT_MODEL_PARAMS_DICT = {
    'existing_model_dir': '',
    'stats_percentiles': [0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975, 0.99],
    'group_count': 5,
    'train_ratio': 0.8,
    'valid_sub_ratio': 0.25,
    'test_isolate_time': 0,
    'is_random_start': False,
    'is_cv': True,
    'cv_split_count': 4,
    'cv_eval_train_metric': True,
    'num_boost_round': 1000,
    'log_evaluation_period': 50,
    'model_idxs': [],
    'num_iterations': [400, 700, 1000],
    'signal_idxs': [],
    'is_symbol_evaluated': False,
    'X_scaler_sub_params': {
        'name': '',
        'vlimits': None,
        'qlimits': [0, 1],
        'is_qlimits_shared': True,
        'inner_scale': 1,
        'outer_scale': 1
    },
    'y_scaler_sub_params': {
        'name': '',
        'vlimits': None,
        'qlimits': [0, 1],
        'is_qlimits_shared': True,
        'inner_scale': 1,
        'outer_scale': 1
    },
    'loss_sub_params': {
        'name': '',
        'init_method': '',
        'is_init_score_shared': True,
        'dof': 1,
        'fee': 0,
        'sensitivity': 1
    },
    'weight_sub_params': {
        'recency_method': '',
        'recency_limit': 1,
        'max_min_ratio': 1,
        'vlimits': None,
        'qlimits': [0, 1],
        'is_qlimits_shared': True,
        'is_clipped': False,
        'is_sign_balanced': False,
        'is_scale_adjusting': False,
        'is_pos_neg_shared': True
    },
    'training_sub_params': {
        'boosting_type': 'gbdt',
        'num_leaves': 25,
        'max_depth': 5,
        'learning_rate': 0.005,
        'reg_alpha': 1,
        'reg_lambda': 1,
        'min_gain_to_split': 0.1,
        'extra_trees': True,
        'objective': 'regression',
        'alpha': 0.9,
        'fair_c': 1,
        'verbose': -1
    }
}


def setup_scaler(scaler_sub_params):
    scale_data = _scaler.setup_scaler(scaler_sub_params)
    return scale_data

def setup_loss(training_sub_params, loss_sub_params):
    training_params, signal_count, calculate_init_score, get_init_scores, feval, calculate_loss, calculate_signals = _loss.setup_loss(training_sub_params, loss_sub_params)
    return training_params, signal_count, calculate_init_score, get_init_scores, feval, calculate_loss, calculate_signals

def run_model(full_features_df, is_dumping, model_params_dict):
    model_evaluations = _model.run_model(full_features_df, is_dumping, model_params_dict)
    return model_evaluations
