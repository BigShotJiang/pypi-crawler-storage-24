#ifndef _BITS_TOOLS_H
#define _BITS_TOOLS_H

#endif