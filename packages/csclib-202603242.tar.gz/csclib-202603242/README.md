# csclib
秘密分散に基づく秘匿計算ライブラリ

## ドキュメント

- [重要関数のドキュメント](docs/IMPORTANT_FUNCTIONS.md)
- [実行・通信ライフサイクル関数](docs/IMPORTANT_FUNCTIONS_RUNTIME.md)
- [主要演算関数](docs/IMPORTANT_FUNCTIONS_DATA_OPS.md)
- [ソート・伝播アルゴリズム関数](docs/IMPORTANT_FUNCTIONS_ALGORITHMS.md)
- [GF演算・前計算関数](docs/IMPORTANT_FUNCTIONS_FIELD_PRECOMP.md)
- [dshare・置換関数](docs/IMPORTANT_FUNCTIONS_DSHARE.md)

## 環境
3台のPCで計算を行います（1台でも可）．それぞれを server, party_1, party_2 とします．
server は入力データを平文で受け取って，それをシェアに変換し，party 1, 2 に送ります．また，相関乱数を生成し party 1, 2 に送ります．
現状では，server では答え合わせ用に全ての計算を平文で行っています．
party_１ と party_2 は相互に通信を行いながら計算をします． 

## コンパイル
C言語またはC++で #include "share.h" して使います．(LOUDSを使う場合は #include "LOUDS.h")
party の番号を -1 として実行すると，全ての計算を1台で（平文で）行います．アルゴリズムの確認や，MPCによる速度低下を評価する際に使えます．

## 実行
config.txt に3台のPCのIPアドレスとポートを設定します．
```config.txt
127.0.0.1 9800 # server
127.0.0.1 9810 # party 1
127.0.0.1 9820 # party 2
```
各行がPCのIPアドレスと使用するポートですが，ポートはここに書かれた値から3つ分を使います．
（この例ではサーバの場合，9800, 9801, 9802 を使います）
1台のPCで実行する場合，全てのIPアドレスを localhost (127.0.0.1) にします．ポート番号は全てが異なるようにします．
複数台ある場合にはそれぞれのIPアドレスを指定します．なお，他のPCと通信を行う場合にはPCのファイアーウォールの設定を変える必要があります．

実行ファイル名を share.out とすると，3台のPC（ターミナル）それぞれで実行します．
```
@server:$ ./share.out 0
@party_1:$ ./share.out 1
@party_2:$ ./share.out 2
```

## Python
コンパイルと実行方法．
```
@server:$ python3 -m venv env
@server:$ source env/bin/activate
@server:$ cd python/csclib
@server:$ python3 setup.py build
@server:$ pip3 install .
```

PyPIからのインストール
```
@server:$ sudo apt install gcc python3.10-dev python3.10-venv python3-pip
@server:$ python3 -m venv env
@server:$ source env/bin/activate
(env) @server:$ pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ csclib
```

setuptools に関するエラーが出るときは
```
pip install wheel
pip install --no-build-isolation csclib
```


pythonのソース内では
```
from csclib import *
```
とする．

## config.txt の書式
```
[options]
parties 3                   #パーティ数 (party 0, 1, 2)
channels 1                  #マルチスレッドを使う場合のチャンネル数
comm_no_delay 1             # 1 と 0 で通信が早い方を使う
warn_precomp 1              # 事前計算の表が存在しないときに警告する
[parties]
127.0.0.1 9800 # server      #party 0 のIPアドレスとポート番号
127.0.0.1 9810 # party 1     #party 1 のIPアドレスとポート番号
127.0.0.1 9820 # party 2     #party 2 のIPアドレスとポート番号
[mt_seeds] # party seed*5
0 123 456 789 0 0            #party 0 が使う乱数の種（整数5個）
1 234 567 890 0 1
2 345 678 234 0 2
3 456 789 345 0 3
[pre_bt]                    # Beaver tripe の相関乱数
0 PRE/PRE_BT.dat            # channel 0 で使う相関乱数を格納したファイル
[pre_of] # bits channel filename
1 0 PRE/PRE_OF1.dat         # 1 ビットの値でオーバーフローが発生するか（両パーティのビットが 1 かどうか）
[pre_b2a] # ビット拡張（1 ビットの値を log q ビットに変換）
0 PRE/PRE_B2A.dat
[pre_onehot] # bits xor channel filename
1 0 0 PRE/PRE_OHA1.dat
[pre_onehot_shamir] # bits channel filename
1 0 PRE/PRE_OHS1.dat
[pre_onehot_shamir3] # bits irr_poly channel filename
4 13 0 PRE/PRE_OHS3_0x13.dat
[pre_onehot_rss] # bits irr_poly channel filename
4 13 0 PRE/PRE_OHR_0x13.dat
[pre_ds] # n bs inverse channel filename      # 置換用のダブルシェア n = 置換長, bs = ブロックサイズ
2 1 0 0 PRE/PRE_DS_n1_w30.dat
4 1 0 0 PRE/PRE_DS_n2_w30.dat
8 1 0 0 PRE/PRE_DS_n3_w30.dat
2 1 1 0 PRE/PRE_DSi_n1_w30.dat
4 1 1 0 PRE/PRE_DSi_n2_w30.dat
8 1 1 0 PRE/PRE_DSi_n3_w30.dat
[pre_uv] #n old_q new_q channel fname         # unit vector を作る
2 32 4 0 PRE/PRE_UV_n2_oq32_nq4.dat
```

