import os
import unittest

from ooomutils import version


class TestAutoUpdate(unittest.TestCase):
    def test_parse_version(self):
        self.assertEqual(version._parse_version("1.2.3"), (1, 2, 3))
        self.assertEqual(version._parse_version(""), (0, 0, 0))

    def test_running_from_source_detects_repo(self):
        result = version._running_from_source()
        self.assertIsInstance(result, bool)
        if os.path.isdir(os.path.join(os.getcwd(), ".git")):
            self.assertTrue(result)
