import unittest

from ooomutils.colors import apply_colors, color


class TestColors(unittest.TestCase):
    def test_apply_colors_replaces_tokens(self):
        result = apply_colors("{BLUE}Hello{END}")
        self.assertIn(color.BLUE, result)
        self.assertTrue(result.endswith(color.END))
