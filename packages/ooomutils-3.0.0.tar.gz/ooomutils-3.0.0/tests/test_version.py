import unittest

import ooomutils
from ooomutils import version


class TestVersion(unittest.TestCase):
    def test_version_exists(self):
        self.assertTrue(hasattr(ooomutils, "__version__"))

    def test_version_matches(self):
        self.assertEqual(ooomutils.__version__, version.__version__)
