import ooomutils

ooomutils.auto_update(confirm=False, warn_on_breaking=True)
