import os
import re
import subprocess
import sys
import time
from .io_helpers import typingprint_nl

__version__ = "3.0.0"
_cache_file = os.path.join(os.path.dirname(__file__), "_version_cache.txt")
REPO_URL = "ooomutils"


def _parse_version(version_str):
    if not version_str:
        return (0, 0, 0)
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", version_str)
    if match:
        return tuple(int(x) for x in match.groups())
    return (0, 0, 0)


def _get_remote_version_pip():
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--dry-run", REPO_URL],
            capture_output=True,
            text=True,
            timeout=30
        )
        match = re.search(r"Would install .*?-(\d+\.\d+\.\d+)", result.stdout)
        if match:
            return match.group(1)
    except Exception:
        return None
    return None


def _running_from_source():
    package_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    return os.path.isdir(os.path.join(package_root, ".git"))


def _print_version_if_needed():
    """Prints version only if explicitly called, avoids printing on import."""
    try:
        last_version = None
        if os.path.exists(_cache_file):
            with open(_cache_file, "r") as f:
                last_version = f.read().strip()

        if last_version != __version__:
            print(f"ooomutils loaded — version {__version__}")
            with open(_cache_file, "w") as f:
                f.write(__version__)
    except Exception:
        pass


def check_version():
    """Call this to see if the version has changed."""
    _print_version_if_needed()


def auto_update(printcheck=True, confirm=True, warn_on_breaking=True):
    """Call this to auto-update the package."""

    def log(msg):
        if printcheck:
            print(msg)

    log("Checking for ooomutils updates...")

    if _running_from_source() and printcheck:
        print("WARNING: Running from source. Auto-update intended for pip installs.")

    latest_version_str = _get_remote_version_pip()

    if not latest_version_str:
        log(f"Could not detect newer version. Current: {__version__}")

        if printcheck:
            print("Exiting update check in 3 seconds")
            time.sleep(3)
            typingprint_nl("Exiting...")
            os.system("clear")
        return

    current_v = _parse_version(__version__)
    latest_v = _parse_version(latest_version_str)

    if latest_v > current_v:
        major_change = latest_v[0] > current_v[0]

        if major_change and warn_on_breaking:
            print(f"WARNING: Major update available {__version__} -> {latest_version_str}")

        do_update = True

        if confirm:
            answer = input(f"A new version ({latest_version_str}) is available. Update now? [y/n]: ")
            do_update = answer.lower() == "y"

        if do_update:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", REPO_URL])
            with open(_cache_file, "w") as f:
                f.write(latest_version_str)
            print(f"Update complete! Please restart to use version {latest_version_str}.")
            os._exit(0)
        else:
            log("Update skipped.")
            if printcheck:
                print("Exiting update check in 3 seconds")
                time.sleep(3)
                typingprint_nl("Exiting...")
                os.system("clear")
    else:
        log(f"ooomutils is up to date ({__version__}).")
        if printcheck:
            print("Exiting update check in 3 seconds")
            time.sleep(3)
            typingprint_nl("Exiting...")
            os.system("clear")