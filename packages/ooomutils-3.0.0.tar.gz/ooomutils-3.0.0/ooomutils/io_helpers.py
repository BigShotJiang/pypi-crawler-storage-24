# ooomutils/io_helpers.py
import sys
import time
from .colors import apply_colors, color

# Typing effect for text
def typingprint(text):
    text = apply_colors(text)
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)
    print()

# Typing effect for text without newline
def typingprint_nl(text):
    text = apply_colors(text)
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)

# Color printing functions
def colourprint(text):
    text = apply_colors(text)
    print(text)
    print()

# Color printing without newline
def colourprint_nl(text):
    text = apply_colors(text)
    print(text)

# Input with typing effect
def typinginput(text):
    text = apply_colors(text)
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.05)
    return input()

# Input with color support
def colourinput(text):
    text = apply_colors(text)
    return input(text)

# Typing effect for instructions
def typingintructions(text):
    text = apply_colors(text)
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(0.01)
    print()


def error(msg):
    print(f"{color.RED}ERROR: {msg}{color.END}")


def spinner(message="Loading", duration=2.0, interval=0.1):
    frames = "|/-\\"
    end_time = time.time() + duration
    frame_index = 0
    while time.time() < end_time:
        sys.stdout.write(f"\r{message} {frames[frame_index % len(frames)]}")
        sys.stdout.flush()
        time.sleep(interval)
        frame_index += 1
    sys.stdout.write("\r" + " " * (len(message) + 2) + "\r")
    sys.stdout.flush()


def progress_bar(current, total, width=30):
    if total <= 0:
        total = 1
    ratio = min(max(current / total, 0), 1)
    filled = int(ratio * width)
    bar = "█" * filled + "-" * (width - filled)
    percent = int(ratio * 100)
    sys.stdout.write(f"\r|{bar}| {percent}%")
    sys.stdout.flush()
    if current >= total:
        print()
