# ooomutils/timing.py
import time

def wait(seconds):
    time.sleep(seconds)
