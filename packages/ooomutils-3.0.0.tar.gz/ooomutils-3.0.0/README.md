# ooomutils


**Ocean-Onion-Ocean Man's Utils** — A lightweight Python utility library for terminal applications, providing typing effects, colorized output, timing helpers, and screen management with optional auto-update and version compatibility checks.

---

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Auto-Update](#auto-update)
- [Module Structure](#module-structure)
- [Functions](#functions)
  - [Colors](#colors)
  - [IO Helpers](#io-helpers)
  - [Timing](#timing)
  - [Screens](#screens)
- [Breaking Changes](#breaking-changes)

---

## Features

- Colorized output and text formatting (bold, underline, accent colors)
- Typing animation for prints and input prompts
- Custom input functions with color and typing effects
- Clear screen, loading screens, and countdown timers
- Automatic version printing and compatibility checks
- Optional auto-update support from GitHub

---

## Installation

Install from GitHub:

```bash
pip install ooomutils
```

If that does work use
```bash
pip install git+https://github.com/Ocean-Onion/ooomutils.git
```

After installation, import it in your project:

```python
import ooomutils
```

---

## Usage

```python
import ooomutils

# Typing effect
ooomutils.typingprint("Hello, world!")

# Colored print
ooomutils.colourprint("{BLUE}This text is blue{END}")

# Colored error messages
ooomutils.error("Something went wrong")

# Spinner
ooomutils.spinner("Working", duration=1.5)

# Progress bar
ooomutils.progress_bar(25, 100)

# Wait/pause
ooomutils.wait(2)

# Countdown timer
ooomutils.countdown(5)

# Clear screen
ooomutils.clear()

# Loading animation
ooomutils.loading_screen()
```

---

## Auto-Update

`ooomutils` includes optional auto-update support. This allows your project to ensure that the latest version of the library is installed.

```python
# Default: Prints status, clears screen, and prompts user if update found
ooomutils.auto_update()
```

### Silent / Background Check

You can run the check silently so it doesn't clutter the console or pause execution unless an update is actually performed.

```python
# Checks silently; only interrupts if an update occurs or a prompt is needed
ooomutils.auto_update(printcheck=False)
```

### Configuration Options

You can customize the behavior using the following arguments:

```python
# Example: Silent check, no user prompt, but warn on major versions
ooomutils.auto_update(printcheck=False, confirm=False, warn_on_breaking=True)
```

- **`printcheck`** (default: `True`):
  - `True`: Prints "Checking for updates...", "Up to date", etc., and includes a 3-second delay and screen clear on exit.
  - `False`: Suppresses general status messages and skips the delay/screen clear.
- **`confirm`** (default: `True`):
  - `True`: Prompts the user (`[y/n]`) before installing an update.
  - `False`: Installs the update immediately without asking.
- **`warn_on_breaking`** (default: `True`):
  - Logs a warning if the new version is a major update (e.g., `1.x.x` to `2.x.x`) which might break compatibility, even if `printcheck` is `False`.

 ### Technical Notes
- Auto-update uses `pip` to upgrade the package and will warn if you are running from a source checkout instead of a pip install.
- The version cache is stored inside the package at `ooomutils/_version_cache.txt`.


Current version: **3.0.0**

---



## Module Structure

```
ooomutils/
├── __init__.py       # Imports and exposes functions, calls version check
├── version.py        # __version__, check_version(), auto_update()
├── colors.py         # color class, apply_colors()
├── io_helpers.py     # typingprint, typinginput, colourprint, colourprint_nl, etc.
├── timing.py         # wait()
├── screens.py        # clear(), countdown(), loading_screen()
```

All functions are accessible from the top-level import:

```python
import ooomutils

ooomutils.wait(1)
ooomutils.typingprint("Message")
ooomutils.clear()
```

---

## Functions

### Colors

- `color` — ANSI color codes (BLUE, GREEN, RED, DARKCYAN, etc.)
- `apply_colors(text)` — Replace `{COLOR}` placeholders with terminal codes

### IO Helpers

- `typingprint(text)` — Prints text with typing effect
- `typingprint_nl(text)` — Prints text with typing effect without newline
- `colourprint(text)` — Prints colored text immediately
- `colourprint_nl(text)` — Prints colored text without newline
- `typinginput(prompt)` — Input with typing effect
- `colourinput(prompt)` — Input with colored prompt
- `typingintructions(text)` — Fast typing animation for instructions
- `error(msg)` — Red error message helper
- `spinner(message="Loading", duration=2.0, interval=0.1)` — Simple spinner animation
- `progress_bar(current, total, width=30)` — Simple progress bar

### Timing

- `wait(seconds)` — Pause execution for the given seconds

### Screens

- `clear()` — Clear the terminal screen
- `countdown(seconds)` — Countdown timer with ASCII numbers (1–25)
- `loading_screen()` — Animated "Loading Game..." screen

---

## Breaking Changes

ooomutils automatically tracks version changes:

- **Minor updates (1.x.x)** — backward compatible  
- **Major updates (2.x.x)** — may contain breaking changes  

The library will warn users if their version may be incompatible with the new release.


---
