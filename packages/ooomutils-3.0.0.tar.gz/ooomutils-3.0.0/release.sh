#!/bin/bash
set -euo pipefail

echo "=========================================="
echo "🚀 Production Release Script for ooomutils"
echo "=========================================="

# ---- 1) Ensure we are on main ----
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)

if [[ "$CURRENT_BRANCH" != "main" ]]; then
  echo "❌ ERROR: You must be on 'main' to release (you are on $CURRENT_BRANCH)."
  echo "Run: git checkout main"
  exit 1
fi

# ---- 2) Ensure repo is clean ----
if [[ -n "$(git status --porcelain)" ]]; then
  echo "❌ ERROR: You have uncommitted changes."
  echo "Run: git status"
  exit 1
fi

# ---- 3) Read version from your package ----
VERSION=$(python3 - << 'EOF'
from ooomutils.version import __version__
import sys
sys.stdout.write(__version__.strip())
EOF
)

TAG="v$VERSION"
echo "📌 Preparing release: $TAG"

# ---- 4) Prevent accidental re-release ----
if git rev-parse "$TAG" >/dev/null 2>&1; then
  echo "❌ ERROR: Tag $TAG already exists."
  echo "Bump version in ooomutils/version.py first."
  exit 1
fi

# ---- 5) Run tests ----
if [ -d "tests" ]; then
  echo "🧪 Running tests..."
  if ! command -v pytest &> /dev/null; then
    echo "⚠️ Pytest not found, installing..."
    pip install pytest
  fi
  pytest || { echo "❌ Tests failed — aborting release."; exit 1; }
else
  echo "ℹ️ No tests folder found — skipping tests."
fi

# ---- 6) Build package ----
echo "📦 Building package..."
rm -rf dist/*
pip install --upgrade build twine
python -m build

# ---- 7) Git tag & push ----
git tag "$TAG"
git push origin main
git push origin "$TAG"

# ---- 8) GitHub release ----
gh release create "$TAG" --title "ooomutils $TAG" --notes "Automated release for $TAG"

# ---- 9) Upload to PyPI ----
echo "⬆️ Uploading to PyPI..."
twine upload --skip-existing dist/*

echo "=========================================="
echo "✅ RELEASE COMPLETE: $TAG"
echo "=========================================="
