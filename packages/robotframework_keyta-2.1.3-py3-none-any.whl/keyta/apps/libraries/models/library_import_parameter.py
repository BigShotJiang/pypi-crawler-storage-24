from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from keyta.models.base_model import AbstractBaseModel


class LibraryImportParameter(AbstractBaseModel):
    library_import = models.ForeignKey(
        'libraries.LibraryImport',
        on_delete=models.CASCADE,
        related_name='kwargs'
    )
    library_parameter = models.ForeignKey(
        'libraries.LibraryParameter',
        on_delete=models.CASCADE
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        null=True
    )
    value = models.CharField(
        max_length=255,
        verbose_name=_('Wert')
    )

    def __str__(self):
        return self.library_parameter.name

    def reset_value(self):
        self.value = self.library_parameter.orig_default_value
        self.save()

    class Meta:
        verbose_name = _('Parameter')
        verbose_name_plural = _('Parameters')
