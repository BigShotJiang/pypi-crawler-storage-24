"""
Supervised Fine-Tuning (SFT) strategy implementation.
Uses TRL's SFTTrainer for standard supervised fine-tuning with LoRA.
"""
from typing import Any, Dict

try:
    from jinja2.exceptions import TemplateError
except ImportError:
    TemplateError = Exception

from peft import LoraConfig, TaskType, prepare_model_for_kbit_training

# Import unsloth first to prevent EOS token corruption
# This must come before transformers imports to ensure proper tokenizer initialization
try:
    import unsloth
except ImportError:
    pass

from trl import SFTTrainer, SFTConfig

from ..logging_config import logger


def _preprocess_logits_for_metrics(logits, labels):
    """
    Reduce logit tensors to scalar loss per batch before CPU accumulation.

    This prevents RAM exhaustion when the Trainer accumulates eval predictions.
    Instead of storing full logit tensors (batch × seq_len × vocab_size),
    we compute the loss on GPU and return only a scalar, reducing memory by
    orders of magnitude (e.g., 19.7 GB/batch → bytes/batch).

    Args:
        logits: Model logits (batch, seq_len, vocab_size)
        labels: Token labels (batch, seq_len)

    Returns:
        Scalar loss tensor for this batch, shape (1,)
    """
    import torch.nn.functional as F

    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = labels[..., 1:].contiguous()

    loss = F.cross_entropy(
        shift_logits.view(-1, shift_logits.size(-1)),
        shift_labels.view(-1).long(),
        ignore_index=-100,
        reduction="mean",
    )

    return loss.unsqueeze(0)


class SFTStrategy:
    """Supervised Fine-Tuning strategy using TRL's SFTTrainer."""

    def get_strategy_name(self) -> str:
        """Get the strategy name."""
        return "sft"

    def prepare_model(self, model: Any, config: Dict) -> Any:
        """
        Prepare model for SFT. When using SFTTrainer with peft_config,
        the trainer handles PEFT wrapping automatically. For the HuggingFace
        provider path, we just prepare for kbit training if quantized.

        Args:
            model: Base model instance
            config: Configuration with LoRA settings

        Returns:
            Model prepared for training
        """
        logger.info("Preparing model for SFT")

        # If quantized, prepare for kbit training
        if config.get("use_4bit") or config.get("use_8bit"):
            model = prepare_model_for_kbit_training(model)

        logger.info("Model prepared for SFT")
        return model

    def get_peft_config(self, config: Dict) -> LoraConfig:
        """
        Create the LoRA PEFT config for SFTTrainer.

        Args:
            config: Configuration dictionary

        Returns:
            LoraConfig instance
        """
        task_type_map = {
            "text-generation": TaskType.CAUSAL_LM,
            "summarization": TaskType.SEQ_2_SEQ_LM,
            "extractive-question-answering": TaskType.QUESTION_ANS,
        }
        task_type = task_type_map.get(config.get("task"), TaskType.CAUSAL_LM)

        peft_config = LoraConfig(
            r=config.get("lora_r", 16),
            lora_alpha=config.get("lora_alpha", 32),
            lora_dropout=config.get("lora_dropout", 0.1),
            bias="none",
            task_type=task_type,
            target_modules=config.get("target_modules", "all-linear"),
        )

        logger.info(f"LoRA config: r={peft_config.r}, alpha={peft_config.lora_alpha}")
        return peft_config

    def prepare_dataset(self, dataset: Any, tokenizer: Any, config: Dict) -> Any:
        """
        Prepare dataset for SFT. SFTTrainer handles tokenization automatically,
        so we just need to format the data into the expected structure.

        Args:
            dataset: Pre-formatted dataset with task-specific fields
            tokenizer: Tokenizer instance
            config: Configuration dictionary

        Returns:
            Dataset formatted for SFTTrainer (with 'text' field)
        """
        logger.info(f"Preparing dataset for SFT: {len(dataset)} examples")

        task = config.get("task", "text-generation")
        eos_token = tokenizer.eos_token or tokenizer.sep_token or ""

        use_chat_template = config.get("use_chat_template", False)

        def format_to_text(example):
            """Format each example into a single text field for SFTTrainer."""
            if task == "text-generation":
                prompt = example.get('prompt', '')
                completion = example.get('completion', '')

                if use_chat_template:
                    try:
                        messages = [
                            {"role": "user", "content": prompt},
                            {"role": "assistant", "content": completion},
                        ]
                        text = tokenizer.apply_chat_template(
                            messages, tokenize=False, add_generation_prompt=False
                        )
                    except (AttributeError, TemplateError, Exception) as e:
                        logger.warning(
                            f"Chat template unavailable ({e}), "
                            f"falling back to USER/ASSISTANT format"
                        )
                        text = f"USER: {prompt}\nASSISTANT: {completion}{eos_token}"
                else:
                    text = f"USER: {prompt}\nASSISTANT: {completion}{eos_token}"

            elif task == "summarization":
                input_text = example.get('input', '')
                output_text = example.get('output', '')
                text = f"Summarize the following document:\n{input_text}\n\nSummary:\n{output_text}{eos_token}"

            elif task == "extractive-question-answering":
                context = example.get('context', '')
                question = example.get('question', '')
                answers = example.get('answers', {})

                if isinstance(answers, dict):
                    answer_text = answers.get("text", [""])[0] if "text" in answers else ""
                else:
                    answer_text = str(answers)

                text = f"Context: {context}\n\nQuestion: {question}\n\nAnswer: {answer_text}{eos_token}"

            else:
                logger.warning(f"Unknown task type: {task}, using raw field concatenation")
                text = " ".join(str(v) for v in example.values() if isinstance(v, str))
                text += eos_token

            return {"text": text}

        # Format dataset - SFTTrainer will handle tokenization
        dataset = dataset.map(
            format_to_text,
            remove_columns=dataset.column_names,
            num_proc=1
        )

        logger.info(f"Dataset formatted for SFT: {len(dataset)} examples")
        return dataset

    def create_trainer(
        self,
        model: Any,
        train_dataset: Any,
        eval_dataset: Any,
        tokenizer: Any,
        config: Dict,
        callbacks: list = None,
        compute_metrics=None,
    ) -> Any:
        """
        Create SFTTrainer instance.

        SFTTrainer handles tokenization, data collation, and label creation
        automatically from the text field.

        Args:
            model: Prepared model
            train_dataset: Formatted training dataset (with 'text' field)
            eval_dataset: Formatted evaluation dataset
            tokenizer: Tokenizer instance
            config: Training configuration
            callbacks: Training callbacks

        Returns:
            SFTTrainer instance
        """
        logger.info("Creating SFTTrainer")

        max_seq_length = config.get("max_seq_length", 2048)
        if max_seq_length == -1:
            max_seq_length = 2048

        # Create SFTConfig with training arguments
        sft_kwargs = dict(
            output_dir=config.get("output_dir", "./checkpoints"),
            num_train_epochs=config.get("num_train_epochs", 1),
            per_device_train_batch_size=config.get("per_device_train_batch_size", 1),
            per_device_eval_batch_size=config.get("per_device_eval_batch_size", 1),
            gradient_accumulation_steps=config.get("gradient_accumulation_steps", 4),
            optim=config.get("optim", "paged_adamw_32bit"),
            save_steps=config.get("save_steps", 0),
            logging_steps=config.get("logging_steps", 25),
            learning_rate=config.get("learning_rate", 2e-4),
            warmup_ratio=config.get("warmup_ratio", 0.03),
            weight_decay=config.get("weight_decay", 0.001),
            fp16=config.get("fp16", False),
            bf16=config.get("bf16", False),
            max_grad_norm=config.get("max_grad_norm", 0.3),
            max_steps=config.get("max_steps", -1),
            lr_scheduler_type=config.get("lr_scheduler_type", "cosine"),
            report_to="tensorboard",
            logging_dir=config.get("logging_dir", "./training_logs"),
            # SFT-specific settings
            max_seq_length=max_seq_length,
            packing=config.get("packing", False),
            dataset_text_field="text",
            # Evaluation settings
            eval_strategy="steps" if eval_dataset else "no",
            eval_steps=config.get("eval_steps", 100),
            save_strategy="steps",
            load_best_model_at_end=True if eval_dataset else False,
            metric_for_best_model="eval_loss" if eval_dataset else None,
            ddp_find_unused_parameters=False,
            # Dataloader settings (MPS sets these to avoid multiprocessing issues)
            dataloader_num_workers=config.get("dataloader_num_workers", 0),
            dataloader_pin_memory=config.get("dataloader_pin_memory", True),
        )

        # Unsloth's patched SFTConfig doesn't support group_by_length
        if not config.get("_peft_already_applied"):
            sft_kwargs["group_by_length"] = config.get("group_by_length", True)

        training_args = SFTConfig(**sft_kwargs)

        # Build the PEFT config for SFTTrainer to apply LoRA
        # Skip if PEFT was already applied (e.g. by Unsloth provider)
        peft_config = None if config.get("_peft_already_applied") else self.get_peft_config(config)

        # Create SFTTrainer - it handles tokenization and data collation
        trainer = SFTTrainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            processing_class=tokenizer,
            peft_config=peft_config,
            callbacks=callbacks or [],
            compute_metrics=compute_metrics,
            preprocess_logits_for_metrics=_preprocess_logits_for_metrics,
        )

        logger.info("SFTTrainer created successfully")
        return trainer

    def get_required_dataset_fields(self, task: str = "text-generation") -> list:
        """
        Get required dataset fields for SFT.

        Returns:
            List of required fields (varies by task)
        """
        task_field_map = {
            "text-generation": ["prompt", "completion"],
            "summarization": ["input", "output"],
            "extractive-question-answering": ["context", "question", "answers"],
        }
        return task_field_map.get(task, ["input", "output"])
