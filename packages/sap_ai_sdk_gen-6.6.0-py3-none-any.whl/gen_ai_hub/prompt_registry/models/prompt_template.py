from typing import List, Optional, Dict, Any
from pydantic.config import ConfigDict

from pydantic import BaseModel, Field


class PromptTemplate(BaseModel):
    """
    Represents a prompt template.

    Args:
        role: The role of the prompt template.

        content: The content of the prompt template.
    """

    role: str
    """The role of the prompt template."""
    content: str
    """The content of the prompt template."""


class PromptTemplateSpec(BaseModel):
    """
    Represents a prompt template specification.

    Args:
        template: The list of prompt templates.

        defaults: The default values for the prompt template fields.

        additional_fields: Additional fields for the prompt template.
    """
    template: List[PromptTemplate]
    """The list of prompt templates."""
    defaults: Optional[Dict[Any, Any]] = Field(default_factory=dict)
    """The default values for the prompt template fields."""
    additional_fields: Optional[Dict[Any, Any]] = Field(default_factory=dict)
    """Additional fields for the prompt template."""


class PromptTemplatePostRequest(BaseModel):
    """
    Represents a request to create a prompt template.

    Args:
        name: The name of the prompt template.

        version: The version of the prompt template.

        scenario: The scenario of the prompt template.

        spec: The specification of the prompt template.
    """
    name: str
    """The name of the prompt template."""
    version: str
    """The version of the prompt template."""
    scenario: str
    """The scenario of the prompt template."""
    spec: PromptTemplateSpec
    """The specification of the prompt template."""


class PromptTemplatePostResponse(BaseModel):
    """
    Represents a response to a request to create a prompt template.

    Args:
        message: The message of the response.

        id: The ID of the prompt template.

        scenario: The scenario of the prompt template.

        name: The name of the prompt template.

        version: The version of the prompt template.
    """
    message: str
    """The message of the response."""
    id: str
    """The ID of the prompt template."""
    scenario: str
    """The scenario of the prompt template."""
    name: str
    """The name of the prompt template."""
    version: str
    """The version of the prompt template."""


class PromptTemplateGetResponse(BaseModel):
    """
    Represents a response to a request to get a prompt template.

    Args:
        id: The ID of the prompt template.

        name: The name of the prompt template.

        version: The version of the prompt template.

        scenario: The scenario of the prompt template.

        creation_timestamp: The creation timestamp of the prompt template.

        managed_by: The manager of the prompt template.

        is_version_head: Whether the version is the head version.

        spec: The specification of the prompt template.
    """
    id: str
    """The ID of the prompt template."""
    name: str
    """The name of the prompt template."""
    version: str
    """The version of the prompt template."""
    scenario: str
    """The scenario of the prompt template."""
    creation_timestamp: Optional[str] = None
    """The creation timestamp of the prompt template."""
    managed_by: Optional[str] = None
    """The manager of the prompt template."""
    is_version_head: Optional[bool] = None
    """Whether the version is the head version."""
    spec: Optional[PromptTemplateSpec] = None
    """The specification of the prompt template."""


class PromptTemplateListResponse(BaseModel):
    """
    Represents a response to a request to list prompt templates.

    Args:
        count: The number of prompt templates.

        resources: The list of PromptGetResponse objects.
    """
    count: int
    """The number of prompt templates."""
    resources: List[PromptTemplateGetResponse]
    """The list of PromptGetResponse objects."""


class PromptTemplateDeleteResponse(BaseModel):
    """
    Represents a response to a request to delete a prompt template.

    Args:
        message: The message of the response.
    """
    message: str
    """The message of the response."""


class PromptTemplateSubstitutionRequest(BaseModel):
    """
    Represents a request to substitute a prompt template.

    Args:
        input_params: User provided values to replace the placeholders of the prompt template.
    """
    model_config = ConfigDict(populate_by_name=True)
    """Pydantic configuration to allow population by field name."""
    input_params: Optional[Dict[Any, Any]] = Field(default_factory=dict, alias='inputParams')
    """User provided values to replace the placeholders of the prompt template."""


class PromptTemplateSubstitutionResponse(BaseModel):
    """
    Represents a response to a request to substitute a prompt template.

    Args:
        parsed_prompt: The parsed prompt.

        resource: List of TemplateGetResponse objects.
    """
    parsed_prompt: List[PromptTemplate]
    """The parsed prompt."""
    resource: Optional[PromptTemplateGetResponse] = None
    """List of TemplateGetResponse objects."""
