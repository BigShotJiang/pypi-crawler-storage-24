"""Models subpackage for Document Grounding API.

This subpackage contains Pydantic model definitions for all Document Grounding
API requests and responses. Models are organized by API domain:

- pipeline: Models for Pipeline API (document vectorization pipelines)
- retrieval: Models for Retrieval API (content retrieval from repositories)
- vector: Models for Vector API (vector collection management and search)

These models provide type-safe data structures for interacting with the
Document Grounding APIs and ensure proper validation of request/response data.
"""
