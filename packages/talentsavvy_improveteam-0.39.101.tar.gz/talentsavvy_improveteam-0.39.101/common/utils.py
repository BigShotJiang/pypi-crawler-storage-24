import datetime
import json
import os
import re
import logging

import pandas as pd
from dateutil.parser import isoparse

config = json.load(open(os.path.join(os.path.dirname(__file__), "config.json")))
EXPORT_PATH = config.get("EXPORT_PATH", os.path.join(os.path.dirname(__file__), "export"))

class Utils:
    DATE_FORMAT = "%Y-%m-%d"
    DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
    DATE_TIME_FORMAT_WITH_TZ = "%Y-%m-%dT%H:%M:%SZ"
    LOGGER = None

    @staticmethod
    def load_checkpoint(prefix, export_path=None) -> datetime:
        """
        This method loads the json checkpoint, exported last time

        :param prefix: filename prefix
        :param export_path: Optional export path, defaults to EXPORT_PATH
        :return: datetime (naive UTC)
        """
        if not prefix:
            return None
        try:
            # Use provided export_path or fall back to global EXPORT_PATH
            path_to_use = export_path if export_path is not None else EXPORT_PATH
            os.makedirs(path_to_use, exist_ok=True)
            filepath = os.path.join(path_to_use, f"{prefix}_checkpoint.json")
            if not os.path.exists(filepath):
                return None
            with open(filepath, "r") as f:
                ts_str = json.load(f).get(f"last_run")
                if ts_str:
                    return Utils.convert_to_utc(ts_str)
                return None
        except Exception as ex:
            print(ex)
            return None

    @staticmethod
    def save_checkpoint(prefix: str, last_dt: datetime, export_path=None):
        """
        This method saves the latest datetime to a checkpoint json file

        :param prefix: filename prefix
        :param last_dt: last date time (naive UTC)
        :param export_path: Optional export path, defaults to EXPORT_PATH
        :return: bool
        """
        if not last_dt or last_dt == '':
            Utils.LOGGER.warning("No last date found to save as checkpoint")
            return None
        try:
            # Use provided export_path or fall back to global EXPORT_PATH
            path_to_use = export_path if export_path is not None else EXPORT_PATH
            filepath = os.path.join(path_to_use, f"{prefix}_checkpoint.json")
            with open(filepath, "w") as f:
                if type(last_dt) == str:
                    last_dt = Utils.convert_to_utc(last_dt)
                else:
                    # Ensure datetime is naive UTC
                    if last_dt.tzinfo is not None:
                        last_dt = last_dt.astimezone(datetime.timezone.utc).replace(tzinfo=None)
                # Save as ISO format (naive datetime will be saved without timezone)
                json.dump({"last_run": last_dt.isoformat(sep='T', timespec='auto')}, f)
                return True
        except Exception as ex:
            Utils.LOGGER.error(ex)
        return None

    @staticmethod
    def convert_to_utc(timestamp):
        """
        Convert a timestamp string to a naive UTC datetime using dateutil.isoparse.
        Returns None if parsing fails or input is falsy.
        """
        if not timestamp:
            return None
        try:
            dt = isoparse(timestamp)
        except Exception:
            # Fallback: attempt common 'Z' replacement
            try:
                dt = datetime.datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
            except Exception:
                return None
        if dt.tzinfo is not None:
            return dt.astimezone(datetime.timezone.utc).replace(tzinfo=None)
        # Treat naive as UTC
        return dt

    @staticmethod
    def create_csv_file(csv_filename, export_path, logger=None):
        """
        Create a CSV file with timestamped filename.
        The header will be written when the first events are saved.
        
        :param csv_filename: Base CSV filename (e.g., "jira_events")
        :param export_path: Directory path where CSV file will be saved
        :param logger: Optional logger for info messages
        :return: Full path to the created CSV file
        """
        # Generate timestamped filename
        current_time = datetime.datetime.now()
        timestamp_str = current_time.strftime("%Y_%m_%d_%H_%M_%S")
        path_to_use = export_path if export_path is not None else EXPORT_PATH
        csv_file = os.path.join(path_to_use, f"{csv_filename}_{timestamp_str}.csv")
        
        # Create empty file - header will be written with first event
        with open(csv_file, 'w') as f:
            pass
        
        if logger:
            logger.info(f"Created CSV file: {csv_file}")
        
        return csv_file

    @staticmethod
    def save_events_to_csv(events, csv_file, logger=None):
        """
        Save events to CSV file by appending to existing file.
        Writes header if file is empty (first call).
        
        :param events: List of event dictionaries to save
        :param csv_file: Full path to the CSV file (created by create_csv_file())
        :param logger: Optional logger for info messages
        :return: Tuple of (total_events, inserted_events, duplicates, max_timestamp)
        """
        if not events:
            return 0, 0, 0, None

        # Find the maximum timestamp from events and convert extended_attributes to JSON strings
        max_ts = None
        processed_events = []
        for event in events:
            # Convert extended_attributes dict to JSON string if present
            if event.get('extended_attributes') and isinstance(event.get('extended_attributes'), dict):
                event = event.copy()  # Don't modify original event
                # Ensure JSON is properly formatted - parse and re-serialize to normalize
                try:
                    normalized_json = json.dumps(event['extended_attributes'], ensure_ascii=False)
                    event['extended_attributes'] = normalized_json
                except (TypeError, ValueError) as e:
                    # If JSON serialization fails, log and set to None
                    if logger:
                        logger.warning(f"Failed to serialize extended_attributes to JSON: {e}")
                    event['extended_attributes'] = None
            
            if event.get('timestamp_utc'):
                if not max_ts or event['timestamp_utc'] > max_ts:
                    max_ts = event['timestamp_utc']
            
            processed_events.append(event)

        # Convert events to DataFrame
        df = pd.DataFrame(processed_events)
        
        # Check if file is empty (first write) to determine if header should be written
        file_is_empty = os.path.getsize(csv_file) == 0
        
        # Append to CSV file (with header if file is empty, otherwise without)
        # Use default quoting (QUOTE_MINIMAL) which handles JSON strings correctly
        df.to_csv(csv_file, mode='a', header=file_is_empty, index=False)
        
        if logger:
            logger.info(f"Saved {len(events)} events to {csv_file}")

        return len(events), len(events), 0, max_ts

    @staticmethod
    def extract_release_version(version_name: str, regex_config: dict = None) -> str:
        """
        Extract the release version from a version name using release_version_pattern.
        
        Args:
            version_name: Version name from Jira (e.g., "R25.5.0.0")
            regex_config: Dictionary containing regex_configuration with release_version_pattern
            
        Returns:
            Extracted release version (e.g., "25.5.0.0") or empty string if not found
        """
        if not version_name or not regex_config:
            return ''
        
        release_version_pattern_str = regex_config.get('release_version_pattern')
        if not release_version_pattern_str:
            return ''
        
        try:
            # Unescape backslashes (pattern comes from JSON with escaped backslashes)
            pattern_str = release_version_pattern_str.replace("\\\\", "\\")
            # Compile pattern (case-insensitive)
            pattern = re.compile(pattern_str, re.IGNORECASE)
            # Search for pattern in version name
            match = pattern.search(version_name)
            if match:
                # Replace hyphens with dots for consistency
                extracted_version = match.group(0).replace('-', '.')
                return extracted_version
            return ''
        except Exception as e:
            logging.warning(f"Error extracting release version from '{version_name}': {e}")
            return ''

    @staticmethod
    def extract_is_major_release(version_name: str, regex_config: dict = None) -> bool:
        """
        Determine if a version is a major release based on regex pattern matching.
        
        First extracts the release version using release_version_pattern, then checks
        if it matches is_major_release_pattern. If release_version_pattern is not available,
        directly matches the version_name against is_major_release_pattern.
        
        Args:
            version_name: Version name from Jira (e.g., "R25.5.0.0")
            regex_config: Dictionary containing regex_configuration with is_major_release_pattern
                         and optionally release_version_pattern
            
        Returns:
            True if version matches major release pattern, False otherwise
        """
        if not version_name:
            return False
        
        if not regex_config:
            return False
        
        version_name = version_name.strip()
        if not version_name:
            return False
        
        is_major_release_pattern_str = regex_config.get('is_major_release_pattern')
        if not is_major_release_pattern_str:
            return False
        
        try:
            # First, try to extract the release version using release_version_pattern
            # This handles cases like "R25.5.0.0" -> "25.5.0.0"
            release_version = Utils.extract_release_version(version_name, regex_config)
            
            # Use extracted version if available, otherwise use original version_name
            version_to_check = release_version if release_version else version_name
            
            # If we extracted a version with multiple parts (e.g., "25.5.0.0"),
            # extract just the major.minor part (first two parts) for pattern matching
            if release_version and '.' in release_version:
                parts = release_version.split('.')
                if len(parts) >= 2:
                    # Take first two numeric parts
                    version_to_check = f"{parts[0]}.{parts[1]}"
            
            # Unescape backslashes (pattern comes from JSON with escaped backslashes)
            pattern_str = is_major_release_pattern_str.replace("\\\\", "\\")
            # Compile pattern (case-insensitive)
            pattern = re.compile(pattern_str, re.IGNORECASE)
            # Match version against pattern
            is_major_release = bool(pattern.match(version_to_check))
            return is_major_release
        except Exception as e:
            logging.warning(f"Error matching is_major_release pattern for version '{version_name}': {e}")
            return False