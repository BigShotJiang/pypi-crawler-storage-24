"""统一的命令检测工具模块。

仅使用标准库 shutil.which 进行命令检测。
"""

import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import TypedDict


class CommandCheckResult(TypedDict):
    """命令检查结果类型定义。"""

    installed: bool
    path: str | None
    version: str | None
    error: str | None


class CommandDetector:
    """统一的命令检测器，仅使用标准库 shutil.which。"""

    @staticmethod
    def find_command(command: str) -> str | None:
        """查找命令可执行文件路径。

        仅使用 shutil.which 检测 PATH 环境变量。

        Args:
            command: 命令名称（如 'go', 'pnpm', 'python'）

        Returns:
            可执行文件的绝对路径，如果未找到则返回 None
        """
        which_path = shutil.which(command)
        if which_path:
            return str(Path(which_path).resolve())
        return None

    @staticmethod
    def get_version(
        command_path: str,
        version_args: list[str] | None = None,
        version_extractor: Callable[[str], str] | None = None,
    ) -> str | None:
        """获取命令版本。

        Args:
            command_path: 命令可执行文件路径
            version_args: 版本参数（默认 ["--version"]）
            version_extractor: 自定义版本提取函数

        Returns:
            版本字符串，如果获取失败则返回 None
        """
        if not command_path or not Path(command_path).is_file():
            return None

        version_args = version_args or ["--version"]

        try:
            result = subprocess.run(
                [command_path, *version_args],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                output = result.stdout.strip()
                if version_extractor:
                    return version_extractor(output)
                return output
        except Exception:
            pass

        return None

    @staticmethod
    def check_command(
        command: str,
        version_args: list[str] | None = None,
        version_extractor: Callable[[str], str] | None = None,
    ) -> CommandCheckResult:
        """全面检查命令安装状态。

        Args:
            command: 命令名称
            version_args: 版本参数
            version_extractor: 版本提取函数

        Returns:
            包含检测结果的详细信息字典
        """
        result: CommandCheckResult = {
            "installed": False,
            "path": None,
            "version": None,
            "error": None,
        }

        # 查找命令 - 仅使用 shutil.which
        cmd_path = CommandDetector.find_command(command)

        if cmd_path is None:
            result["error"] = f"{command} not found in PATH."
            return result

        result["path"] = cmd_path
        result["installed"] = True

        # 获取版本
        version = CommandDetector.get_version(cmd_path, version_args, version_extractor)
        if version:
            result["version"] = version

        return result


# 常用命令的便捷函数


def find_go() -> str | None:
    """查找 Go 可执行文件。"""
    return CommandDetector.find_command("go")


def find_pnpm() -> str | None:
    """查找 pnpm 可执行文件。"""
    return CommandDetector.find_command("pnpm")


def find_python() -> str | None:
    """查找 Python 可执行文件。"""
    # 优先尝试 python3，然后 python
    for cmd in ["python3", "python"]:
        path = CommandDetector.find_command(cmd)
        if path:
            return path
    return None


def find_node() -> str | None:
    """查找 Node.js 可执行文件。"""
    return CommandDetector.find_command("node")


def find_npm() -> str | None:
    """查找 npm 可执行文件。"""
    return CommandDetector.find_command("npm")


def get_go_version(go_path: str | None = None) -> str | None:
    """获取 Go 版本（仅版本号，如 '1.21.0'）。"""
    if go_path is None:
        go_path = find_go()

    if go_path is None:
        return None

    def extractor(output: str) -> str:
        # 输入: "go version go1.21.0 windows/amd64"
        # 输出: "1.21.0"
        parts = output.split()
        if len(parts) >= 3:
            return parts[2].replace("go", "")
        return output

    return CommandDetector.get_version(go_path, ["version"], extractor)


def get_pnpm_version(pnpm_path: str | None = None) -> str | None:
    """获取 pnpm 版本。"""
    if pnpm_path is None:
        pnpm_path = find_pnpm()

    if pnpm_path is None:
        return None

    return CommandDetector.get_version(pnpm_path)


def get_python_version(python_path: str | None = None) -> str | None:
    """获取 Python 版本。"""
    if python_path is None:
        python_path = find_python()

    if python_path is None:
        return None

    def extractor(output: str) -> str:
        # 输入: "Python 3.11.0"
        # 输出: "3.11.0"
        if output.startswith("Python "):
            return output[7:].strip()
        return output

    return CommandDetector.get_version(python_path, ["--version"], extractor)
