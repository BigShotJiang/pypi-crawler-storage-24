"""PNPM 依赖检测模块 - 简化版本。

优化：仅使用标准库 shutil.which 检测 PATH 环境变量。
"""

import shutil
import subprocess
from pathlib import Path
from typing import TypedDict


class PnpmCheckResult(TypedDict):
    """PNPM 检查结果类型定义。"""

    installed: bool
    path: str | None
    version: str | None
    error: str | None


class GoCheckResult(TypedDict):
    """Go 检查结果类型定义。"""

    installed: bool
    path: str | None
    version: str | None


class DependenciesResult(TypedDict):
    """依赖检查结果类型定义。"""

    pnpm: PnpmCheckResult
    go: GoCheckResult


class GoDetector:
    """Go 检测器，仅使用标准库 shutil.which。"""

    @staticmethod
    def detect_go_path() -> str | None:
        """检测 Go 可执行文件路径。

        Returns:
            Go 可执行文件的路径，如果未找到则返回 None
        """
        go_path = shutil.which("go")
        if go_path:
            return str(Path(go_path).resolve())
        return None

    @staticmethod
    def get_go_version(go_path: str | None = None) -> str | None:
        """获取 Go 版本。

        Args:
            go_path: Go 可执行文件路径，如果不提供则自动检测

        Returns:
            版本字符串，如果获取失败则返回 None
        """
        if go_path is None:
            go_path = GoDetector.detect_go_path()

        if not go_path or not Path(go_path).is_file():
            return None

        try:
            result = subprocess.run(
                [go_path, "version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                version_line = result.stdout.strip()
                parts = version_line.split()
                if len(parts) >= 3:
                    return parts[2].replace("go", "")
        except Exception:
            pass
        return None

    @staticmethod
    def check_go() -> GoCheckResult:
        """全面检查 Go 安装状态。

        Returns:
            包含检测结果的详细信息字典
        """
        result: GoCheckResult = {
            "installed": False,
            "path": None,
            "version": None,
        }

        go_path = GoDetector.detect_go_path()

        if go_path:
            result["installed"] = True
            result["path"] = go_path
            version = GoDetector.get_go_version(go_path)
            if version:
                result["version"] = version

        return result


class PnpmDetector:
    """简化的 PNPM 检测器，仅使用标准库 shutil.which。"""

    @staticmethod
    def detect_pnpm_path() -> str | None:
        """检测 pnpm 可执行文件路径。

        仅使用标准库 shutil.which 检测 PATH 环境变量。

        Returns:
            pnpm 可执行文件的绝对路径，如果未找到则返回 None
        """
        which_path = shutil.which("pnpm")
        if which_path:
            return str(Path(which_path).resolve())
        return None

    @staticmethod
    def get_pnpm_version(pnpm_path: str | None = None) -> str | None:
        """获取 pnpm 版本。

        Args:
            pnpm_path: pnpm 可执行文件路径，如果不提供则自动检测

        Returns:
            版本字符串，如果获取失败则返回 None
        """
        if pnpm_path is None:
            pnpm_path = PnpmDetector.detect_pnpm_path()

        if not pnpm_path or not Path(pnpm_path).is_file():
            return None

        try:
            result = subprocess.run(
                [pnpm_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @staticmethod
    def check_pnpm() -> PnpmCheckResult:
        """全面检查 pnpm 安装状态。

        Returns:
            包含检测结果的详细信息字典
        """
        result: PnpmCheckResult = {
            "installed": False,
            "path": None,
            "version": None,
            "error": None,
        }

        pnpm_path = PnpmDetector.detect_pnpm_path()

        if pnpm_path is None:
            result["error"] = (
                "pnpm not found in PATH. Please install pnpm:\n"
                "  npm install -g pnpm\n"
                "Or ensure pnpm is in your PATH."
            )
            return result

        result["path"] = pnpm_path
        result["installed"] = True

        version = PnpmDetector.get_pnpm_version(pnpm_path)
        if version:
            result["version"] = version
        else:
            result["error"] = f"Found pnpm at {pnpm_path} but cannot get version"

        return result


def check_dependencies() -> DependenciesResult:
    """检查所有相关依赖。

    Returns:
        包含所有依赖检查结果的字典
    """
    return {
        "pnpm": PnpmDetector.check_pnpm(),
        "go": GoDetector.check_go(),
    }


def print_dependency_report(results: DependenciesResult | None = None) -> None:
    """打印依赖检查报告。

    Args:
        results: 依赖检查结果，如果为 None 则自动执行检查
    """
    from loguru import logger

    if results is None:
        results = check_dependencies()

    logger.info("🔍 检查全局依赖...")

    # PNPM 检查
    pnpm_result = results.get("pnpm", {})
    if pnpm_result.get("installed"):
        version = pnpm_result.get("version", "unknown")
        path = pnpm_result.get("path", "unknown")
        logger.success(f"✅ pnpm 已安装: {version} ({path})")
    else:
        error = pnpm_result.get("error", "未知错误")
        logger.error("❌ pnpm 未安装或不在 PATH 中")
        logger.info(f"💡 {error}")

    # Go 检查
    go_result = results.get("go", {})
    if go_result.get("installed"):
        version = go_result.get("version", "unknown")
        logger.success(f"✅ Go 已安装: {version}")
    else:
        logger.error("❌ Go 未安装或不在 PATH 中")
        logger.info("💡 请安装 Go: https://golang.org/dl/")


if __name__ == "__main__":
    print_dependency_report()
