"""Bun 依赖检测模块。

优化：仅使用标准库 shutil.which 检测 PATH 环境变量。
"""

import shutil
import subprocess
from pathlib import Path
from typing import TypedDict


class BunCheckResult(TypedDict):
    """Bun 检查结果类型定义。"""

    installed: bool
    path: str | None
    version: str | None
    error: str | None


class BunDetector:
    """简化的 Bun 检测器，仅使用标准库 shutil.which。"""

    @staticmethod
    def detect_bun_path() -> str | None:
        """检测 bun 可执行文件路径。

        仅使用标准库 shutil.which 检测 PATH 环境变量。

        Returns:
            bun 可执行文件的绝对路径，如果未找到则返回 None
        """
        which_path = shutil.which("bun")
        if which_path:
            return str(Path(which_path).resolve())
        return None

    @staticmethod
    def get_bun_version(bun_path: str | None = None) -> str | None:
        """获取 bun 版本。

        Args:
            bun_path: bun 可执行文件路径，如果不提供则自动检测

        Returns:
            版本字符串，如果获取失败则返回 None
        """
        if bun_path is None:
            bun_path = BunDetector.detect_bun_path()

        if not bun_path or not Path(bun_path).is_file():
            return None

        try:
            result = subprocess.run(
                [bun_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @staticmethod
    def check_bun() -> BunCheckResult:
        """全面检查 bun 安装状态。

        Returns:
            包含检测结果的详细信息字典
        """
        result: BunCheckResult = {
            "installed": False,
            "path": None,
            "version": None,
            "error": None,
        }

        bun_path = BunDetector.detect_bun_path()

        if bun_path is None:
            result["error"] = (
                "bun not found in PATH. Please install bun:\n"
                "  curl -fsSL https://bun.sh/install | bash\n"
                "Or ensure bun is in your PATH."
            )
            return result

        result["path"] = bun_path
        result["installed"] = True

        version = BunDetector.get_bun_version(bun_path)
        if version:
            result["version"] = version
        else:
            result["error"] = f"Found bun at {bun_path} but cannot get version"

        return result


def check_dependencies() -> dict[str, BunCheckResult]:
    """检查所有相关依赖。

    Returns:
        包含所有依赖检查结果的字典
    """
    return {
        "bun": BunDetector.check_bun(),
    }


def print_dependency_report(results: dict[str, BunCheckResult] | None = None) -> None:
    """打印依赖检查报告。

    Args:
        results: 依赖检查结果，如果为 None 则自动执行检查
    """
    from loguru import logger

    if results is None:
        results = check_dependencies()

    logger.info("🔍 检查全局依赖...")

    # Bun 检查
    bun_result = results.get("bun", {})
    if bun_result.get("installed"):
        version = bun_result.get("version", "unknown")
        path = bun_result.get("path", "unknown")
        logger.success(f"✅ bun 已安装: {version} ({path})")
    else:
        error = bun_result.get("error", "未知错误")
        logger.error("❌ bun 未安装或不在 PATH 中")
        logger.info(f"💡 {error}")


if __name__ == "__main__":
    print_dependency_report()
