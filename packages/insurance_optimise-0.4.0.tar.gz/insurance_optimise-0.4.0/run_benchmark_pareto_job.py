"""
Submit and poll the benchmark_pareto notebook on Databricks (serverless).
"""
from __future__ import annotations

import os
import sys
import time

env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, val = line.split("=", 1)
            os.environ[key.strip()] = val.strip()

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

w = WorkspaceClient()

print("Submitting benchmark_pareto notebook job to Databricks (serverless)...")

run_resp = w.jobs.submit(
    run_name="benchmark_pareto_v040",
    tasks=[
        jobs.SubmitTask(
            task_key="main",
            notebook_task=jobs.NotebookTask(
                notebook_path="/Workspace/benchmarks/benchmark_pareto_nb",
                source=jobs.Source.WORKSPACE,
            ),
        )
    ],
)

run_id = run_resp.response.run_id
print(f"Run ID: {run_id}")
print("Polling (20s intervals)...")

start = time.time()
while True:
    state = w.jobs.get_run(run_id=run_id)
    lc = state.state.life_cycle_state.value if state.state and state.state.life_cycle_state else "UNKNOWN"
    rs = state.state.result_state.value if state.state and state.state.result_state else ""
    elapsed = time.time() - start
    print(f"  [{elapsed:.0f}s] {lc} {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(20)

# Get output
for task in (state.tasks or []):
    try:
        output = w.jobs.get_run_output(run_id=task.run_id)
        if output.notebook_output and output.notebook_output.result:
            print("\n--- NOTEBOOK OUTPUT ---")
            print(output.notebook_output.result)
        if output.error:
            print(f"\n--- ERROR ---\n{output.error}")
        if output.error_trace:
            print(f"\n--- TRACEBACK ---\n{output.error_trace[:4000]}")
        if output.logs:
            print(f"\n--- LOGS ---\n{output.logs[-2000:]}")
    except Exception as exc:
        print(f"Could not fetch output: {exc}")

final = state.state.result_state.value if state.state and state.state.result_state else "UNKNOWN"
print(f"\nFinal result: {final}")
sys.exit(0 if final == "SUCCESS" else 1)
