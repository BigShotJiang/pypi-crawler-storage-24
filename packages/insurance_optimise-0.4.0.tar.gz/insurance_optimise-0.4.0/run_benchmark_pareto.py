"""
Submit and poll a Databricks job to run benchmark_pareto.py.
"""
from __future__ import annotations

import os
import sys
import time

# Load credentials
env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, val = line.split("=", 1)
            os.environ[key.strip()] = val.strip()

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import NotebookTask, Task, Source

w = WorkspaceClient()

print("Submitting benchmark_pareto job...")

run = w.jobs.submit(
    run_name="benchmark_pareto_insurance_optimise",
    tasks=[
        Task(
            task_key="benchmark_pareto",
            notebook_task=NotebookTask(
                notebook_path="/Workspace/benchmarks/benchmark_pareto",
                base_parameters={},
                source=Source.WORKSPACE,
            ),
            new_cluster={
                "spark_version": "15.4.x-scala2.12",
                "node_type_id": "m5d.large",
                "num_workers": 0,
                "spark_conf": {
                    "spark.master": "local[*, 4]",
                    "spark.databricks.cluster.profile": "singleNode",
                },
                "custom_tags": {"ResourceClass": "SingleNode"},
            },
        )
    ],
).result()

run_id = run.run_id
print(f"Run ID: {run_id}")

# Poll for completion
start = time.time()
while True:
    run_state = w.jobs.get_run(run_id=run_id)
    lc = run_state.state.life_cycle_state.value if run_state.state.life_cycle_state else "UNKNOWN"
    rs = run_state.state.result_state.value if run_state.state.result_state else ""
    print(f"  [{time.time()-start:.0f}s] {lc} {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(15)

# Fetch output
for task in (run_state.tasks or []):
    try:
        output = w.jobs.get_run_output(run_id=task.run_id)
        if output.notebook_output:
            print("\n--- NOTEBOOK OUTPUT ---")
            print(output.notebook_output.result)
        if output.error:
            print(f"\n--- ERROR ---\n{output.error}")
        if output.error_trace:
            print(f"\n--- TRACEBACK ---\n{output.error_trace}")
        if output.logs:
            print(f"\n--- LOGS ---\n{output.logs}")
    except Exception as e:
        print(f"Could not fetch output for task {task.task_key}: {e}")

result_state = run_state.state.result_state.value if run_state.state.result_state else "UNKNOWN"
print(f"\nFinal state: {result_state}")
sys.exit(0 if result_state == "SUCCESS" else 1)
