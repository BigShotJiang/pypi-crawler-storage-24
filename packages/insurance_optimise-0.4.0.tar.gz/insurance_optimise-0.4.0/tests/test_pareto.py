"""
Tests for the ParetoFrontier 3-objective Pareto surface module.

Coverage:
- Group 1: Objectives move in the expected direction
- Group 2: Non-dominated filtering correctness
- Group 3: TOPSIS selection
- Group 4: Fairness metrics (premium_disparity_ratio, loss_ratio_disparity)
- Group 5: ParetoResult serialisation
- Group 6: Integration smoke tests (N=50, 3x3 grid)
"""

from __future__ import annotations

import json
import os
import tempfile
from functools import partial

import numpy as np
import polars as pl
import pytest

from insurance_optimise import ConstraintConfig, PortfolioOptimiser, OptimisationResult
from insurance_optimise.pareto import (
    ParetoFrontier,
    ParetoResult,
    _filter_pareto_front,
    _topsis_select,
    premium_disparity_ratio,
    loss_ratio_disparity,
)


# ---------------------------------------------------------------------------
# Synthetic data fixture (matches spec section 6)
# ---------------------------------------------------------------------------

def make_synthetic_portfolio(n: int = 100, seed: int = 42):
    """Minimal synthetic insurance portfolio for tests."""
    rng = np.random.default_rng(seed)
    tc = rng.uniform(200, 800, n)
    cost = tc * rng.uniform(0.55, 0.75, n)
    p_demand = rng.uniform(0.70, 0.95, n)
    elasticity = rng.uniform(-2.5, -0.8, n)
    renewal_flag = rng.random(n) > 0.3
    enbp = np.where(renewal_flag, tc * rng.uniform(1.0, 1.3, n), tc)
    group_labels = rng.integers(1, 6, n)  # deprivation quintiles 1-5
    return tc, cost, p_demand, elasticity, renewal_flag, enbp, group_labels


def make_optimiser(n: int = 50, seed: int = 42) -> PortfolioOptimiser:
    """Build a small PortfolioOptimiser for tests."""
    tc, cost, p_demand, elasticity, renewal_flag, enbp, _ = make_synthetic_portfolio(n, seed)
    config = ConstraintConfig(lr_max=0.80, technical_floor=True)
    return PortfolioOptimiser(
        technical_price=tc,
        expected_loss_cost=cost,
        p_demand=p_demand,
        elasticity=elasticity,
        renewal_flag=renewal_flag,
        enbp=enbp,
        constraints=config,
    )


def make_fairness_fn(n: int = 50, seed: int = 42):
    """Build a fairness function bound to synthetic portfolio data."""
    tc, _, _, _, _, _, group_labels = make_synthetic_portfolio(n, seed)
    return partial(
        premium_disparity_ratio,
        technical_price=tc,
        group_labels=group_labels,
    )


# ---------------------------------------------------------------------------
# Helper: build a minimal ParetoResult from hand-crafted DataFrames
# ---------------------------------------------------------------------------

def _make_pareto_result(rows: list[dict], multipliers_n: int = 5) -> ParetoResult:
    """Build a ParetoResult from synthetic row dicts for unit-testing."""
    surface = pl.DataFrame(rows)
    converged_rows = [r for r in rows if r.get("converged", False)]
    if converged_rows:
        conv_df = pl.DataFrame(converged_rows)
        pareto_df = _filter_pareto_front(conv_df)
    else:
        pareto_df = pl.DataFrame(schema=surface.schema)

    grid_multipliers = {
        (int(r["grid_i"]), int(r["grid_j"])): np.ones(multipliers_n)
        for r in rows
    }

    return ParetoResult(
        surface=surface,
        pareto_df=pareto_df,
        metadata={"sweep_x": "volume_retention", "sweep_y": "fairness_max"},
        _grid_multipliers=grid_multipliers,
    )


def _make_surface_row(
    eps_x: float = 0.85,
    eps_y: float = 1.5,
    converged: bool = True,
    profit: float = 1000.0,
    gwp: float = 5000.0,
    loss_ratio: float = 0.65,
    retention: float = 0.87,
    fairness: float = 1.3,
    n_iter: int = 15,
    solver_message: str = "Optimisation successful",
    grid_i: int = 0,
    grid_j: int = 0,
) -> dict:
    return {
        "eps_x": eps_x,
        "eps_y": eps_y,
        "converged": converged,
        "profit": profit,
        "gwp": gwp,
        "loss_ratio": loss_ratio,
        "retention": retention,
        "fairness": fairness,
        "n_iter": n_iter,
        "solver_message": solver_message,
        "grid_i": grid_i,
        "grid_j": grid_j,
    }


# ===========================================================================
# Group 1 — Objectives move in the right direction
# ===========================================================================

class TestObjectiveDirections:

    def test_pf_runs_3x3_without_error(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.90),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=3,
            n_points_y=3,
        )
        result = pf.run()
        assert isinstance(result, ParetoResult)

    def test_surface_has_correct_row_count(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.88),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=3,
            n_points_y=3,
        )
        result = pf.run()
        assert len(result.surface) == 9

    def test_surface_has_required_columns(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.88),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        expected_cols = {
            "eps_x", "eps_y", "converged", "profit", "gwp",
            "loss_ratio", "retention", "fairness", "n_iter",
            "solver_message", "grid_i", "grid_j",
        }
        assert expected_cols <= set(result.surface.columns)

    def test_tighter_retention_constraint_does_not_increase_profit(self):
        """
        With tighter retention, profit should not be higher.

        We run two isolated solves: one with a loose retention floor and one
        with a tight one. The tight one cannot exceed the loose one's profit
        (since the loose problem is a relaxation of the tight one).
        """
        opt = make_optimiser(n=50, seed=1)
        fairness_fn = make_fairness_fn(n=50, seed=1)

        pf_loose = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.71),  # 1-point sweep at 0.70
            sweep_y="fairness_max",
            sweep_y_range=(2.0, 2.0),
            n_points_x=1,
            n_points_y=1,
        )
        pf_tight = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.90, 0.90),  # 1-point sweep at 0.90
            sweep_y="fairness_max",
            sweep_y_range=(2.0, 2.0),
            n_points_x=1,
            n_points_y=1,
        )
        r_loose = pf_loose.run()
        r_tight = pf_tight.run()

        # Get converged profits
        loose_converged = r_loose.surface.filter(pl.col("converged"))
        tight_converged = r_tight.surface.filter(pl.col("converged"))

        if len(loose_converged) > 0 and len(tight_converged) > 0:
            profit_loose = loose_converged["profit"][0]
            profit_tight = tight_converged["profit"][0]
            # Tight constraint cannot yield strictly higher profit than loose
            assert profit_tight <= profit_loose + 1e-3

    def test_profit_within_plausible_bounds(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.88),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        converged = result.surface.filter(pl.col("converged"))
        if len(converged) > 0:
            profits = converged["profit"].to_numpy()
            # Profits should be finite and positive for a feasible portfolio
            assert np.all(np.isfinite(profits))

    def test_retention_within_0_1(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.88),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        converged = result.surface.filter(pl.col("converged"))
        if len(converged) > 0:
            ret = converged["retention"].to_numpy()
            finite_ret = ret[np.isfinite(ret)]
            if len(finite_ret) > 0:
                assert np.all(finite_ret >= 0.0)
                assert np.all(finite_ret <= 1.0)

    def test_fairness_values_stored_in_surface(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        assert "fairness" in result.surface.columns

    def test_original_optimiser_not_mutated(self):
        opt = make_optimiser(n=50)
        original_lr_max = opt.config.lr_max
        original_retention = opt.config.retention_min

        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        pf.run()

        assert opt.config.lr_max == original_lr_max
        assert opt.config.retention_min == original_retention

    def test_invalid_sweep_x_raises(self):
        opt = make_optimiser(n=20)
        with pytest.raises(ValueError, match="sweep_x"):
            ParetoFrontier(
                optimiser=opt,
                sweep_x="invalid_param",
                sweep_y="fairness_max",
            )

    def test_invalid_sweep_y_raises(self):
        opt = make_optimiser(n=20)
        with pytest.raises(ValueError, match="sweep_y"):
            ParetoFrontier(
                optimiser=opt,
                sweep_x="volume_retention",
                sweep_y="invalid_param",
            )

    def test_same_sweep_x_y_raises(self):
        opt = make_optimiser(n=20)
        with pytest.raises(ValueError):
            ParetoFrontier(
                optimiser=opt,
                sweep_x="lr_max",
                sweep_y="lr_max",
            )

    def test_grid_multipliers_has_n_x_n_y_entries(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=3,
            n_points_y=3,
        )
        result = pf.run()
        assert len(result._grid_multipliers) == 9

    def test_multiplier_shape_matches_n_policies(self):
        n = 50
        opt = make_optimiser(n=n)
        fairness_fn = make_fairness_fn(n=n)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        for key, m in result._grid_multipliers.items():
            assert m.shape == (n,), f"Key {key}: expected shape ({n},), got {m.shape}"

    def test_eps_x_values_span_range(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        lo, hi = 0.70, 0.88
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(lo, hi),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=3,
            n_points_y=2,
        )
        result = pf.run()
        eps_x_vals = result.surface["eps_x"].to_numpy()
        assert eps_x_vals.min() >= lo - 1e-9
        assert eps_x_vals.max() <= hi + 1e-9

    def test_eps_y_values_span_range(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        lo, hi = 1.1, 2.5
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(lo, hi),
            n_points_x=2,
            n_points_y=3,
        )
        result = pf.run()
        eps_y_vals = result.surface["eps_y"].to_numpy()
        assert eps_y_vals.min() >= lo - 1e-9
        assert eps_y_vals.max() <= hi + 1e-9

    def test_loss_ratio_within_bounds(self):
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.85),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        converged = result.surface.filter(pl.col("converged"))
        if len(converged) > 0:
            lr = converged["loss_ratio"].to_numpy()
            assert np.all(lr >= 0.0)
            # LR should not exceed 1.0 with a properly set lr_max constraint
            assert np.all(lr <= 1.0 + 1e-4)


# ===========================================================================
# Group 2 — Non-dominated filtering
# ===========================================================================

class TestFilterParetoFront:

    def _make_df(self, rows: list[dict]) -> pl.DataFrame:
        return pl.DataFrame(rows)

    def test_three_point_case_one_dominated(self):
        """
        Three solutions: A is dominated by B (B is better on all three).
        """
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},  # A
            {"profit": 120.0, "retention": 0.88, "fairness": 1.3},  # B dominates A
            {"profit": 110.0, "retention": 0.80, "fairness": 1.2},  # C — non-dom
        ])
        result = _filter_pareto_front(df)
        assert len(result) == 2
        profits = set(result["profit"].to_list())
        assert 100.0 not in profits  # A should be filtered

    def test_single_solution_always_non_dominated(self):
        df = self._make_df([
            {"profit": 500.0, "retention": 0.90, "fairness": 1.2},
        ])
        result = _filter_pareto_front(df)
        assert len(result) == 1

    def test_all_equal_objectives_none_dominated(self):
        """When all solutions have identical objectives, none can dominate."""
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
        ])
        result = _filter_pareto_front(df)
        assert len(result) == 3

    def test_empty_dataframe_returns_empty(self):
        df = pl.DataFrame(
            {"profit": [], "retention": [], "fairness": []},
            schema={"profit": pl.Float64, "retention": pl.Float64, "fairness": pl.Float64},
        )
        result = _filter_pareto_front(df)
        assert len(result) == 0

    def test_near_ties_within_tolerance(self):
        """Solutions within tolerance should not be treated as dominated."""
        tol = 1e-6
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
            {"profit": 100.0 + tol * 0.5, "retention": 0.85, "fairness": 1.5},
        ])
        result = _filter_pareto_front(df, tol=tol)
        # Neither dominates strictly
        assert len(result) == 2

    def test_dominated_not_in_pareto_df(self):
        """Dominated solutions should appear in surface but not pareto_df."""
        # A is dominated by B
        rows = [
            _make_surface_row(profit=50.0,  retention=0.75, fairness=2.0, grid_i=0, grid_j=0),
            _make_surface_row(profit=100.0, retention=0.88, fairness=1.3, grid_i=0, grid_j=1),
        ]
        pr = _make_pareto_result(rows)
        assert len(pr.surface) == 2
        assert len(pr.pareto_df) == 1
        assert pr.pareto_df["profit"][0] == 100.0

    def test_two_non_dominated_trade_offs(self):
        """Two solutions trading off profit and fairness: both non-dominated."""
        df = self._make_df([
            {"profit": 200.0, "retention": 0.90, "fairness": 1.8},  # high profit
            {"profit": 150.0, "retention": 0.92, "fairness": 1.2},  # low disparity
        ])
        result = _filter_pareto_front(df)
        assert len(result) == 2

    def test_custom_column_names(self):
        """_filter_pareto_front accepts custom column name arguments."""
        # Row 0: high retention and low disparity, lower profit
        # Row 1: high profit, low retention, high disparity
        # Neither dominates: row 1 is worse on retention; row 0 is worse on profit
        df = self._make_df([
            {"p": 100.0, "r": 0.95, "f": 1.3},
            {"p": 150.0, "r": 0.82, "f": 1.8},
        ])
        result = _filter_pareto_front(df, profit_col="p", retention_col="r", fairness_col="f")
        assert len(result) == 2

    def test_clear_dominance_chain(self):
        """A -> B -> C dominance chain: only C survives."""
        df = self._make_df([
            {"profit": 100.0, "retention": 0.80, "fairness": 2.0},   # A: worst
            {"profit": 150.0, "retention": 0.85, "fairness": 1.6},   # B: dominates A
            {"profit": 200.0, "retention": 0.90, "fairness": 1.2},   # C: dominates B
        ])
        result = _filter_pareto_front(df)
        assert len(result) == 1
        assert result["profit"][0] == 200.0

    def test_pareto_df_is_subset_of_surface(self):
        """All pareto_df rows should appear in surface."""
        rows = [
            _make_surface_row(profit=50.0,  retention=0.75, fairness=2.0, grid_i=0, grid_j=0),
            _make_surface_row(profit=100.0, retention=0.88, fairness=1.3, grid_i=0, grid_j=1),
            _make_surface_row(profit=80.0,  retention=0.92, fairness=1.1, grid_i=1, grid_j=0),
        ]
        pr = _make_pareto_result(rows)
        # Every profit in pareto_df should be in surface
        surface_profits = set(pr.surface["profit"].to_list())
        pareto_profits = set(pr.pareto_df["profit"].to_list())
        assert pareto_profits <= surface_profits


# ===========================================================================
# Group 3 — TOPSIS selection
# ===========================================================================

class TestTopsisSelect:

    def _make_df(self, rows: list[dict]) -> pl.DataFrame:
        return pl.DataFrame(rows)

    def test_equal_weights_selects_closest_to_utopia(self):
        """With equal weights, TOPSIS should prefer the solution nearest the ideal."""
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
            {"profit": 200.0, "retention": 0.90, "fairness": 1.2},  # best overall
            {"profit": 50.0,  "retention": 0.95, "fairness": 2.0},
        ])
        idx = _topsis_select(df, weights=(1.0, 1.0, 1.0))
        # Solution 1 (index 1) should win: high profit, high retention, low disparity
        assert idx == 1

    def test_profit_only_weight_selects_max_profit(self):
        df = self._make_df([
            {"profit": 300.0, "retention": 0.80, "fairness": 2.0},  # max profit
            {"profit": 200.0, "retention": 0.90, "fairness": 1.2},
            {"profit": 100.0, "retention": 0.95, "fairness": 1.0},
        ])
        idx = _topsis_select(df, weights=(1.0, 0.0, 0.0))
        assert idx == 0

    def test_fairness_only_weight_selects_min_fairness(self):
        df = self._make_df([
            {"profit": 300.0, "retention": 0.80, "fairness": 2.0},
            {"profit": 200.0, "retention": 0.90, "fairness": 1.5},
            {"profit": 100.0, "retention": 0.95, "fairness": 1.0},  # min fairness
        ])
        idx = _topsis_select(df, weights=(0.0, 0.0, 1.0))
        assert idx == 2

    def test_raises_on_zero_weights(self):
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
        ])
        with pytest.raises(ValueError, match="sum to a positive"):
            _topsis_select(df, weights=(0.0, 0.0, 0.0))

    def test_raises_on_empty_dataframe(self):
        df = pl.DataFrame(
            {"profit": [], "retention": [], "fairness": []},
            schema={"profit": pl.Float64, "retention": pl.Float64, "fairness": pl.Float64},
        )
        with pytest.raises(ValueError, match="empty"):
            _topsis_select(df, weights=(1.0, 0.5, 0.2))

    def test_single_solution_always_selected(self):
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
        ])
        idx = _topsis_select(df, weights=(0.5, 0.3, 0.2))
        assert idx == 0

    def test_negative_weights_raise(self):
        df = self._make_df([
            {"profit": 100.0, "retention": 0.85, "fairness": 1.5},
        ])
        with pytest.raises(ValueError, match="non-negative"):
            _topsis_select(df, weights=(-1.0, 1.0, 0.5))

    def test_selected_index_in_valid_range(self):
        n_rows = 5
        rows = [
            {"profit": float(i * 10), "retention": 0.80 + i * 0.02, "fairness": 2.0 - i * 0.2}
            for i in range(n_rows)
        ]
        df = self._make_df(rows)
        idx = _topsis_select(df, weights=(0.5, 0.3, 0.2))
        assert 0 <= idx < n_rows


# ===========================================================================
# Group 4 — Fairness metrics
# ===========================================================================

class TestPremiumDisparityRatio:

    def test_two_equal_groups_returns_1(self):
        """When both groups have identical mean premiums, ratio is 1.0."""
        # Same technical price and same multiplier across both groups
        # → identical mean premiums → ratio must be 1.0
        tc = np.array([100.0, 100.0, 100.0, 100.0])
        m = np.array([1.0, 1.0, 1.0, 1.0])
        labels = np.array([1, 1, 2, 2])
        ratio = premium_disparity_ratio(m, tc, labels)
        assert abs(ratio - 1.0) < 1e-9

    def test_one_group_double_premium(self):
        """Group 2 has 2x the mean premium of group 1 — expect ratio 2.0."""
        tc = np.array([100.0, 100.0, 100.0, 100.0])
        # Group 1 multiplier = 1.0; group 2 multiplier = 2.0
        m = np.array([1.0, 1.0, 2.0, 2.0])
        labels = np.array([1, 1, 2, 2])
        ratio = premium_disparity_ratio(m, tc, labels)
        assert abs(ratio - 2.0) < 1e-9

    def test_single_group_returns_1(self):
        """With only one group, there is no disparity — return 1.0."""
        tc = np.ones(5) * 200.0
        m = np.ones(5) * 1.2
        labels = np.ones(5, dtype=int)
        ratio = premium_disparity_ratio(m, tc, labels)
        assert ratio == 1.0

    def test_five_quintile_groups(self):
        """Five groups with increasing multipliers: ratio > 1.0."""
        n = 50
        rng = np.random.default_rng(7)
        tc = np.ones(n) * 300.0
        m = np.linspace(1.0, 2.0, n)
        labels = np.repeat(np.arange(1, 6), 10)
        ratio = premium_disparity_ratio(m, tc, labels)
        assert ratio > 1.0

    def test_ratio_always_gte_1(self):
        """Ratio is always >= 1.0 by construction (max/min)."""
        rng = np.random.default_rng(99)
        for _ in range(10):
            tc = rng.uniform(200, 800, 20)
            m = rng.uniform(0.9, 1.5, 20)
            labels = rng.integers(1, 4, 20)
            ratio = premium_disparity_ratio(m, tc, labels)
            assert ratio >= 1.0 - 1e-9

    def test_single_policy_per_group(self):
        """Single-policy groups: ratio is straight premium ratio."""
        tc = np.array([100.0, 100.0])
        m = np.array([1.0, 2.0])
        labels = np.array([1, 2])
        ratio = premium_disparity_ratio(m, tc, labels)
        assert abs(ratio - 2.0) < 1e-9

    def test_returns_float(self):
        tc = np.ones(4) * 300.0
        m = np.ones(4)
        labels = np.array([1, 1, 2, 2])
        ratio = premium_disparity_ratio(m, tc, labels)
        assert isinstance(ratio, float)


class TestLossRatioDisparity:

    def test_equal_lr_across_groups(self):
        """When both groups have identical LR, disparity is 1.0."""
        from insurance_optimise._demand_model import make_demand_model

        n = 4
        tc = np.array([100.0, 100.0, 200.0, 200.0])
        cost = tc * 0.65
        p = np.array([0.85, 0.85, 0.85, 0.85])
        elasticity = np.full(n, -1.5)
        m = np.ones(n)
        labels = np.array([1, 1, 2, 2])

        demand = make_demand_model("log_linear", p, elasticity, tc)
        ratio = loss_ratio_disparity(m, tc, cost, demand, labels)
        assert abs(ratio - 1.0) < 1e-6

    def test_single_group_returns_1(self):
        from insurance_optimise._demand_model import make_demand_model

        n = 4
        tc = np.ones(n) * 200.0
        cost = tc * 0.65
        p = np.full(n, 0.85)
        elasticity = np.full(n, -1.5)
        m = np.ones(n)
        labels = np.ones(n, dtype=int)

        demand = make_demand_model("log_linear", p, elasticity, tc)
        ratio = loss_ratio_disparity(m, tc, cost, demand, labels)
        assert ratio == 1.0

    def test_ratio_always_gte_1(self):
        from insurance_optimise._demand_model import make_demand_model

        rng = np.random.default_rng(13)
        for _ in range(5):
            n = 20
            tc = rng.uniform(200, 800, n)
            cost = tc * rng.uniform(0.5, 0.8, n)
            p = rng.uniform(0.75, 0.95, n)
            elasticity = -rng.uniform(0.5, 2.0, n)
            m = rng.uniform(0.9, 1.5, n)
            labels = rng.integers(1, 4, n)

            demand = make_demand_model("log_linear", p, elasticity, tc)
            ratio = loss_ratio_disparity(m, tc, cost, demand, labels)
            assert ratio >= 1.0 - 1e-9


# ===========================================================================
# Group 5 — ParetoResult serialisation
# ===========================================================================

class TestParetoResultSerialisation:

    def _make_full_result(self) -> ParetoResult:
        rows = [
            _make_surface_row(profit=100.0, retention=0.82, fairness=1.8, grid_i=0, grid_j=0),
            _make_surface_row(profit=150.0, retention=0.86, fairness=1.5, grid_i=0, grid_j=1),
            _make_surface_row(profit=80.0,  retention=0.92, fairness=1.2, grid_i=1, grid_j=0),
            _make_surface_row(
                profit=0.0, retention=0.0, fairness=0.0,
                converged=False, grid_i=1, grid_j=1,
            ),
        ]
        return _make_pareto_result(rows)

    def test_to_json_produces_valid_json(self):
        pr = self._make_full_result()
        s = pr.to_json()
        parsed = json.loads(s)
        assert isinstance(parsed, dict)

    def test_to_json_contains_surface(self):
        pr = self._make_full_result()
        parsed = json.loads(pr.to_json())
        assert "surface" in parsed
        assert isinstance(parsed["surface"], list)

    def test_save_audit_writes_nonempty_file(self):
        pr = self._make_full_result()
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            pr.save_audit(path)
            with open(path) as f:
                content = f.read()
            assert len(content) > 0
            json.loads(content)  # must be valid JSON
        finally:
            os.unlink(path)

    def test_summary_returns_dataframe_with_expected_columns(self):
        pr = self._make_full_result()
        s = pr.summary()
        assert isinstance(s, pl.DataFrame)
        assert len(s) > 0
        assert "profit" in s.columns
        assert "retention" in s.columns
        assert "fairness" in s.columns

    def test_pareto_df_is_subset_of_surface(self):
        pr = self._make_full_result()
        surface_profits = set(pr.surface["profit"].to_list())
        pareto_profits = set(pr.pareto_df["profit"].to_list())
        assert pareto_profits <= surface_profits

    def test_grid_multipliers_has_correct_count(self):
        pr = self._make_full_result()
        assert len(pr._grid_multipliers) == 4  # 2x2 grid

    def test_to_dict_contains_all_metadata_fields(self):
        pr = self._make_full_result()
        d = pr.to_dict()
        assert "metadata" in d
        assert "sweep_x" in d["metadata"]
        assert "sweep_y" in d["metadata"]

    def test_to_json_round_trips_n_pareto(self):
        pr = self._make_full_result()
        d = pr.to_dict()
        assert d["n_pareto"] == len(pr.pareto_df)


# ===========================================================================
# Group 6 — Integration smoke tests (N=50, 3x3 grid)
# ===========================================================================

class TestIntegration:

    @pytest.fixture
    def pf_result(self) -> ParetoResult:
        """Run a 3x3 ParetoFrontier on N=50 synthetic data."""
        opt = make_optimiser(n=50)
        fairness_fn = make_fairness_fn(n=50)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=fairness_fn,
            sweep_x="volume_retention",
            sweep_x_range=(0.70, 0.88),
            sweep_y="fairness_max",
            sweep_y_range=(1.1, 2.5),
            n_points_x=3,
            n_points_y=3,
        )
        return pf.run()

    def test_surface_has_exactly_9_rows(self, pf_result):
        assert len(pf_result.surface) == 9

    def test_pareto_df_has_at_least_one_solution(self, pf_result):
        assert len(pf_result.pareto_df) >= 1

    def test_plot_does_not_raise(self, pf_result):
        pytest.importorskip("matplotlib")
        import matplotlib
        matplotlib.use("Agg")
        pf_result.plot()

    def test_plot_3d_does_not_raise(self, pf_result):
        pytest.importorskip("matplotlib")
        import matplotlib
        matplotlib.use("Agg")
        pf_result.plot_3d()

    def test_select_topsis_populates_selected(self, pf_result):
        result = pf_result.select(method="topsis", weights=(0.5, 0.3, 0.2))
        assert result.selected is not None

    def test_selected_is_optimisation_result(self, pf_result):
        result = pf_result.select(method="topsis")
        assert isinstance(result.selected, OptimisationResult)

    def test_selected_converged(self, pf_result):
        result = pf_result.select(method="topsis")
        assert result.selected.converged

    def test_selected_multipliers_shape(self, pf_result):
        result = pf_result.select(method="topsis")
        assert result.selected.multipliers.shape == (50,)

    def test_select_closest_to_utopia(self, pf_result):
        result = pf_result.select(method="closest_to_utopia")
        assert result.selected is not None

    def test_select_unknown_method_raises(self, pf_result):
        with pytest.raises(ValueError, match="Unknown selection method"):
            pf_result.select(method="unknown_method")

    def test_metadata_contains_sweep_params(self, pf_result):
        meta = pf_result.metadata
        assert meta["sweep_x"] == "volume_retention"
        assert meta["sweep_y"] == "fairness_max"
        assert meta["n_points_x"] == 3
        assert meta["n_points_y"] == 3

    def test_metadata_timestamp_is_iso_string(self, pf_result):
        ts = pf_result.metadata.get("timestamp", "")
        # Should be parseable as datetime
        import datetime
        dt = datetime.datetime.fromisoformat(ts)
        assert dt is not None

    def test_select_profit_weight_only(self, pf_result):
        """Profit-only weight selects the max-profit solution."""
        result = pf_result.select(method="topsis", weights=(1.0, 0.0, 0.0))
        assert result.selected is not None

    def test_pareto_df_all_converged(self, pf_result):
        """All solutions in pareto_df must be converged."""
        assert pf_result.pareto_df["converged"].all()

    def test_gwp_positive_for_converged(self, pf_result):
        """GWP must be positive at all converged solutions."""
        converged = pf_result.surface.filter(pl.col("converged"))
        if len(converged) > 0:
            assert (converged["gwp"] > 0).all()

    def test_lr_sweep_runs_without_error(self):
        """sweep_x='lr_max' should run without error."""
        opt = make_optimiser(n=30)
        pf = ParetoFrontier(
            optimiser=opt,
            fairness_metric=None,
            sweep_x="lr_max",
            sweep_x_range=(0.65, 0.80),
            sweep_y="gwp_min",
            sweep_y_range=(5000.0, 15000.0),
            n_points_x=2,
            n_points_y=2,
        )
        result = pf.run()
        assert len(result.surface) == 4
