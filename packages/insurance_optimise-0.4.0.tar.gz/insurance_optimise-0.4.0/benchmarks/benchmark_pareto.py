"""
Benchmark: ParetoFrontier (3-objective) vs EfficientFrontier (2-objective)
vs PortfolioOptimiser (single-objective).

The problem: UK pricing teams typically optimise for profit subject to a
retention floor. This ignores fairness (Consumer Duty, PS22/9) and hides the
explicit trade-off between profit and premium disparity. A single-objective
solution can produce a premium disparity ratio of 1.5+ without the team
realising — they never see that a 2% profit reduction could halve the
disparity.

This benchmark demonstrates what each approach reveals:

1. Single-objective (PortfolioOptimiser): maximises profit, enforces retention
   floor. Reports fairness post-hoc but does not optimise it.
2. Bi-objective EfficientFrontier: traces the profit-retention Pareto curve
   across 10 retention targets. Fairness is still not optimised — we just
   report what happens at each point.
3. Tri-objective ParetoFrontier: 8×8 grid sweep over (retention, fairness_max).
   Each point on the surface is certified non-dominated. TOPSIS selects the
   best compromise under user-specified weights.

Setup:
- 500 synthetic UK renewal policies
- Technical prices uniform(200, 800), loss ratios 0.55–0.75
- Demand: uniform p=0.70–0.95, elasticity uniform(-2.5, -0.8)
- Group labels: 5 deprivation quintiles (random assignment, seed=42)
- Constraints: lr_max=0.72, max_rate_change=0.25

Run:
    uv run python benchmarks/benchmark_pareto.py
"""

from __future__ import annotations

import sys
import time
import warnings
from functools import partial

warnings.filterwarnings("ignore")

BENCHMARK_START = time.time()

print("=" * 68)
print(f"=== ParetoFrontier Benchmark: insurance-optimise v0.4.0 ===")
print("=" * 68)
print()

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------

try:
    from insurance_optimise import (
        ConstraintConfig,
        EfficientFrontier,
        ParetoFrontier,
        PortfolioOptimiser,
        premium_disparity_ratio,
    )
    print("insurance_optimise imported OK")
except ImportError as e:
    print(f"ERROR: Could not import insurance_optimise: {e}")
    print("Install with: pip install insurance-optimise")
    sys.exit(1)

import numpy as np

# ---------------------------------------------------------------------------
# Synthetic portfolio
# ---------------------------------------------------------------------------

N = 500
SEED = 42
N_QUINTILES = 5

rng = np.random.default_rng(SEED)

tc = rng.uniform(200, 800, N)
cost = tc * rng.uniform(0.55, 0.75, N)
p_demand = rng.uniform(0.70, 0.95, N)
elasticity = rng.uniform(-2.5, -0.8, N)
renewal_flag = np.ones(N, dtype=bool)
enbp = tc * rng.uniform(1.0, 1.3, N)
group_labels = rng.integers(1, N_QUINTILES + 1, N)

print(f"Portfolio: {N} policies, {N_QUINTILES} deprivation quintiles, seed={SEED}")
print(f"  Technical price: £{tc.mean():.0f} mean (range £{tc.min():.0f}–£{tc.max():.0f})")
print(f"  Expected LR:     {(cost / tc).mean():.3f} mean")
print(f"  Demand:          {p_demand.mean():.3f} mean probability at technical price")
print(f"  Elasticity:      {elasticity.mean():.2f} mean")
print()

# Fairness metric bound to the portfolio data
fairness_fn = partial(
    premium_disparity_ratio,
    technical_price=tc,
    group_labels=group_labels,
)

# ---------------------------------------------------------------------------
# Constraints
# ---------------------------------------------------------------------------

BASE_CONFIG = ConstraintConfig(
    lr_max=0.72,
    retention_min=0.90,
    max_rate_change=0.25,
)

# ---------------------------------------------------------------------------
# 1. Single-objective: profit maximisation, retention >= 0.90
# ---------------------------------------------------------------------------

print("-" * 68)
print("--- Single-Objective (profit maximisation, retention >= 0.90) ---")
print("-" * 68)

t0 = time.time()

opt_single = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=BASE_CONFIG,
    seed=SEED,
)

result_single = opt_single.optimise()
t_single = time.time() - t0

# Compute fairness post-hoc using the optimal multipliers
fair_single = fairness_fn(result_single.multipliers)
ret_single = result_single.expected_retention or 0.0

print(f"Profit:    £{result_single.expected_profit:,.0f}")
print(f"Retention: {ret_single * 100:.1f}%")
print(f"Fairness:  {fair_single:.3f} (premium disparity ratio)")
print(f"Converged: {result_single.converged}")
print(f"Runtime:   {t_single:.1f}s")
print()

# ---------------------------------------------------------------------------
# 2. Bi-objective frontier: profit × retention (10 points)
# ---------------------------------------------------------------------------

print("-" * 68)
print("--- Bi-Objective Frontier (profit × retention, 10 points) ---")
print("-" * 68)

t0 = time.time()

# Use a config without a hard retention floor — the frontier sweeps it
config_no_ret = ConstraintConfig(
    lr_max=0.72,
    retention_min=None,
    max_rate_change=0.25,
)

opt_bi = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=config_no_ret,
    seed=SEED,
)

ef = EfficientFrontier(
    optimiser=opt_bi,
    sweep_param="volume_retention",
    sweep_range=(0.80, 0.98),
    n_points=10,
    n_jobs=1,
)

ef_result = ef.run()
t_bi = time.time() - t0

ef_data = ef_result.pareto_data()
n_bi_converged = len(ef_data)

if n_bi_converged > 0:
    profits_bi = ef_data["profit"].to_list()
    retentions_bi = ef_data["retention"].to_list()

    # Compute fairness at each converged point using stored multipliers
    # We don't have per-point multipliers in EfficientFrontierResult;
    # report the range from surface data only (fairness not stored)
    # Instead, note that fairness is not tracked by EfficientFrontier
    profit_bi_lo = min(p for p in profits_bi if p == p)  # exclude NaN
    profit_bi_hi = max(p for p in profits_bi if p == p)
    ret_bi_lo = min(r for r in retentions_bi if r is not None and r == r)
    ret_bi_hi = max(r for r in retentions_bi if r is not None and r == r)

    print(f"Profit range:    £{profit_bi_lo:,.0f} – £{profit_bi_hi:,.0f}")
    print(f"Retention range: {ret_bi_lo * 100:.1f}% – {ret_bi_hi * 100:.1f}%")
    print(f"Fairness:        not tracked by EfficientFrontier")
else:
    print("  No converged points.")
    profit_bi_lo = profit_bi_hi = float("nan")
    ret_bi_lo = ret_bi_hi = float("nan")

print(f"Converged:       {n_bi_converged}/10")
print(f"Runtime:         {t_bi:.1f}s")
print()

# ---------------------------------------------------------------------------
# 3. Tri-objective Pareto surface (8×8 grid)
# ---------------------------------------------------------------------------

print("-" * 68)
print("--- Tri-Objective Pareto Surface (profit × retention × fairness, 8×8 grid) ---")
print("-" * 68)

t0 = time.time()

opt_pareto = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=config_no_ret,
    seed=SEED,
)

pf = ParetoFrontier(
    optimiser=opt_pareto,
    fairness_metric=fairness_fn,
    sweep_x="volume_retention",
    sweep_x_range=(0.80, 0.98),
    sweep_y="fairness_max",
    sweep_y_range=(1.05, 2.50),
    n_points_x=8,
    n_points_y=8,
    n_jobs=1,
)

pareto_result = pf.run()
t_pareto = time.time() - t0

n_total = len(pareto_result.surface)
n_nondom = len(pareto_result.pareto_df)
n_converged = int(pareto_result.surface["converged"].sum())

if n_nondom > 0:
    profits_p = pareto_result.pareto_df["profit"].to_list()
    retentions_p = pareto_result.pareto_df["retention"].to_list()
    fairness_p = pareto_result.pareto_df["fairness"].to_list()

    profit_p_lo = min(p for p in profits_p if p == p)
    profit_p_hi = max(p for p in profits_p if p == p)
    ret_p_lo = min(r for r in retentions_p if r is not None and r == r)
    ret_p_hi = max(r for r in retentions_p if r is not None and r == r)
    fair_p_lo = min(f for f in fairness_p if f == f)
    fair_p_hi = max(f for f in fairness_p if f == f)

    print(f"Profit range:    £{profit_p_lo:,.0f} – £{profit_p_hi:,.0f}")
    print(f"Retention range: {ret_p_lo * 100:.1f}% – {ret_p_hi * 100:.1f}%")
    print(f"Fairness range:  {fair_p_lo:.3f} – {fair_p_hi:.3f}")
else:
    print("  No non-dominated solutions found.")
    profit_p_lo = profit_p_hi = float("nan")
    ret_p_lo = ret_p_hi = float("nan")
    fair_p_lo = fair_p_hi = float("nan")

print(f"Non-dominated:   {n_nondom}/{n_total} ({n_converged} converged)")
print(f"Runtime:         {t_pareto:.1f}s")
print()

# ---------------------------------------------------------------------------
# 4. TOPSIS selection
# ---------------------------------------------------------------------------

print("-" * 68)
print("--- TOPSIS Selection (weights: profit=0.5, retention=0.3, fairness=0.2) ---")
print("-" * 68)

if n_nondom > 0:
    pareto_result.select(method="topsis", weights=(0.5, 0.3, 0.2))
    sel = pareto_result.selected

    profit_topsis = sel.expected_profit
    ret_topsis = sel.expected_retention or 0.0
    fair_topsis = sel.audit_trail.get("fairness", float("nan"))

    # Compute relative differences vs single-objective
    if result_single.expected_profit and result_single.expected_profit != 0:
        profit_pct_diff = (profit_topsis - result_single.expected_profit) / abs(result_single.expected_profit) * 100
    else:
        profit_pct_diff = float("nan")

    ret_pp_diff = (ret_topsis - ret_single) * 100  # percentage points

    print(f"Profit:    £{profit_topsis:,.0f}  (vs single-objective: {profit_pct_diff:+.1f}%)")
    print(f"Retention: {ret_topsis * 100:.1f}%  (vs single-objective: {ret_pp_diff:+.1f}pp)")
    print(f"Fairness:  {fair_topsis:.3f}  (vs single-objective: {fair_single:.3f} → {fair_topsis:.3f})")
else:
    print("  Cannot select — no non-dominated solutions available.")
    profit_topsis = float("nan")
    ret_topsis = float("nan")
    fair_topsis = float("nan")
    profit_pct_diff = float("nan")
    ret_pp_diff = float("nan")

print()

# ---------------------------------------------------------------------------
# 5. Key finding
# ---------------------------------------------------------------------------

print("-" * 68)
print("--- Key Finding ---")
print("-" * 68)

if n_nondom > 0 and not (fair_topsis != fair_topsis):  # not NaN
    fair_improvement = fair_single - fair_topsis
    profit_cost = profit_pct_diff  # negative = profit reduction

    if abs(profit_cost) < 0.5 and fair_improvement > 0.05:
        finding = (
            f"The Pareto surface achieves a {fair_improvement:.2f}-point improvement "
            f"in premium disparity ratio (from {fair_single:.3f} to {fair_topsis:.3f}) "
            f"at a negligible profit cost ({profit_cost:+.1f}%), a trade-off invisible "
            f"to single-objective optimisation."
        )
    elif abs(profit_cost) < 2.0 and fair_improvement > 0.02:
        finding = (
            f"The Pareto surface reduces premium disparity ratio from {fair_single:.3f} "
            f"to {fair_topsis:.3f} ({fair_improvement:.2f} improvement) for a "
            f"{profit_cost:+.1f}% profit adjustment — the kind of explicit trade-off "
            f"a Consumer Duty board paper requires."
        )
    elif abs(profit_cost) >= 2.0:
        finding = (
            f"Meaningful fairness improvement (disparity {fair_single:.3f} → {fair_topsis:.3f}) "
            f"carries a real profit cost ({profit_cost:+.1f}%). At N=500 this trade-off "
            f"is material — pricing teams should see this surface before committing "
            f"to a single-objective solution."
        )
    else:
        finding = (
            f"At N=500, the single-objective solution already sits near the Pareto "
            f"surface for this synthetic portfolio. The three-objective approach adds "
            f"value primarily by making the fairness-profit trade-off explicit and "
            f"auditable (disparity: {fair_single:.3f} → {fair_topsis:.3f}, "
            f"profit: {profit_cost:+.1f}%)."
        )
else:
    finding = (
        "No non-dominated solutions were found — check constraint feasibility "
        "and consider widening sweep ranges."
    )

# Wrap at 68 chars
words = finding.split()
line = ""
lines = []
for word in words:
    if len(line) + len(word) + 1 <= 66:
        line = line + (" " if line else "") + word
    else:
        lines.append(line)
        line = word
if line:
    lines.append(line)

for l in lines:
    print(l)
print()

# ---------------------------------------------------------------------------
# Full summary table
# ---------------------------------------------------------------------------

print("=" * 68)
print("SUMMARY TABLE")
print("=" * 68)
print(f"{'Approach':<40} {'Profit':>10} {'Ret%':>7} {'Fairness':>9}")
print("-" * 68)
print(
    f"{'Single-objective (ret >= 90%)':<40} "
    f"£{result_single.expected_profit:>8,.0f} "
    f"{ret_single * 100:>6.1f}% "
    f"{fair_single:>9.3f}"
)
if n_bi_converged > 0:
    print(
        f"{'Bi-obj frontier best profit':<40} "
        f"£{profit_bi_hi:>8,.0f} "
        f"{ret_bi_lo * 100:>6.1f}% "
        f"{'n/a':>9}"
    )
    print(
        f"{'Bi-obj frontier best retention':<40} "
        f"£{profit_bi_lo:>8,.0f} "
        f"{ret_bi_hi * 100:>6.1f}% "
        f"{'n/a':>9}"
    )
if n_nondom > 0:
    print(
        f"{'Pareto surface best profit':<40} "
        f"£{profit_p_hi:>8,.0f} "
        f"{'—':>7} "
        f"{'—':>9}"
    )
    print(
        f"{'Pareto surface best fairness':<40} "
        f"{'—':>10} "
        f"{'—':>7} "
        f"{fair_p_lo:>9.3f}"
    )
    if not (profit_topsis != profit_topsis):
        print(
            f"{'TOPSIS selected (0.5/0.3/0.2)':<40} "
            f"£{profit_topsis:>8,.0f} "
            f"{ret_topsis * 100:>6.1f}% "
            f"{fair_topsis:>9.3f}"
        )
print()

elapsed = time.time() - BENCHMARK_START
print(f"Benchmark completed in {elapsed:.1f}s")
