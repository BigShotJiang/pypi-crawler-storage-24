# Databricks notebook source
# MAGIC %md
# MAGIC # insurance-optimise v0.4.0: 3-Objective Pareto Surface Demo
# MAGIC
# MAGIC This notebook demonstrates `ParetoFrontier` — the 3-objective Pareto surface
# MAGIC for insurance portfolio rate optimisation.
# MAGIC
# MAGIC **The problem:**
# MAGIC A UK personal lines pricing team needs to set renewal multipliers subject to
# MAGIC FCA constraints (ENBP, PS21/11). There are three competing objectives:
# MAGIC
# MAGIC - **Profit**: maximise expected underwriting contribution
# MAGIC - **Retention**: keep renewal customers (board KPI)
# MAGIC - **Fairness**: minimise premium disparity across deprivation quintiles (Consumer Duty PS22/9)
# MAGIC
# MAGIC The pricing team cannot pre-determine which fairness level is "acceptable" —
# MAGIC that is a governance decision. `ParetoFrontier` shows them the full
# MAGIC trade-off surface so the board can choose explicitly.
# MAGIC
# MAGIC **What we cover:**
# MAGIC 1. Synthetic portfolio generation (500 policies, 5 deprivation quintiles)
# MAGIC 2. Build the 3-objective Pareto surface (10x10 grid, parallel)
# MAGIC 3. Visualise: 2D scatter with profit colour axis, 3D scatter
# MAGIC 4. Select a solution via TOPSIS with business weights
# MAGIC 5. Save the FCA audit trail

# COMMAND ----------

# MAGIC %pip install "insurance-optimise>=0.4.0" joblib matplotlib --quiet

# COMMAND ----------

import numpy as np
import polars as pl
import matplotlib
matplotlib.use("Agg")  # Databricks: use non-interactive backend
import matplotlib.pyplot as plt
from functools import partial

from insurance_optimise import PortfolioOptimiser, ConstraintConfig
from insurance_optimise.pareto import ParetoFrontier, premium_disparity_ratio

print("insurance-optimise version:", __import__("insurance_optimise").__version__)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Synthetic Portfolio
# MAGIC
# MAGIC Generating a 500-policy UK personal lines renewal book. In production these
# MAGIC columns come from fitted GLM/GBM models. We assign each policy to a
# MAGIC deprivation quintile (1=least deprived, 5=most deprived) — this is the
# MAGIC grouping variable for the fairness metric.

# COMMAND ----------

rng = np.random.default_rng(42)
N = 500

# Technical premiums and expected loss costs
tc = rng.uniform(200, 900, N)
cost = tc * rng.uniform(0.55, 0.75, N)

# Demand: baseline renewal probability and price elasticity
p_demand = rng.uniform(0.70, 0.95, N)
elasticity = rng.uniform(-2.5, -0.8, N)

# Renewal book with ENBP (FCA PS21/11)
renewal_flag = np.ones(N, dtype=bool)  # all renewals
enbp = tc * rng.uniform(1.05, 1.25, N)

# Deprivation quintile (1-5): grouping for fairness metric
deprivation_quintile = rng.integers(1, 6, N)

df = pl.DataFrame({
    "tc": tc.tolist(),
    "cost": cost.tolist(),
    "p_renew": p_demand.tolist(),
    "elasticity": elasticity.tolist(),
    "is_renewal": renewal_flag.tolist(),
    "enbp": enbp.tolist(),
    "deprivation_quintile": deprivation_quintile.tolist(),
})

print(f"Portfolio: {N} policies")
print(f"Mean technical premium: £{tc.mean():,.0f}")
print(f"Technical loss ratio: {(cost.sum()/tc.sum()):.3f}")
print(f"Deprivation quintile distribution:")
print(df.group_by("deprivation_quintile").agg(pl.len().alias("n")).sort("deprivation_quintile"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Build the PortfolioOptimiser
# MAGIC
# MAGIC Standard FCA-compliant constraint setup. ENBP is enforced as a hard
# MAGIC constraint (required by PS21/11). LR cap and rate change guard-rail are
# MAGIC typical UK pricing team settings.

# COMMAND ----------

config = ConstraintConfig(
    lr_max=0.72,
    max_rate_change=0.25,
    enbp_buffer=0.005,
    technical_floor=True,
)

opt = PortfolioOptimiser(
    technical_price=df["tc"].to_numpy(),
    expected_loss_cost=df["cost"].to_numpy(),
    p_demand=df["p_renew"].to_numpy(),
    elasticity=df["elasticity"].to_numpy(),
    renewal_flag=df["is_renewal"].to_numpy(),
    enbp=df["enbp"].to_numpy(),
    constraints=config,
)

print(f"Optimiser built: {opt.n} policies, {opt.n_constraints} active constraints")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Define the Fairness Metric
# MAGIC
# MAGIC We use `premium_disparity_ratio` — the ratio of the highest-mean-premium
# MAGIC deprivation quintile to the lowest. A value of 1.0 means perfect equality;
# MAGIC 2.0 means the most expensive quintile pays double the cheapest.
# MAGIC
# MAGIC The metric is bound to the portfolio data using `functools.partial` so
# MAGIC `ParetoFrontier` only needs to pass `multipliers` at each grid point.

# COMMAND ----------

fairness_fn = partial(
    premium_disparity_ratio,
    technical_price=df["tc"].to_numpy(),
    group_labels=df["deprivation_quintile"].to_numpy(),
)

# Check the baseline (multipliers = 1.0)
baseline_fairness = fairness_fn(np.ones(N))
print(f"Baseline premium disparity ratio (at multiplier=1.0): {baseline_fairness:.3f}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Run the Pareto Surface
# MAGIC
# MAGIC **Grid setup:** 10x10 = 100 independent SLSQP solves.
# MAGIC - x-axis: retention floor swept from 0.80 to 0.96
# MAGIC - y-axis: fairness cap swept from 1.05 to 2.00
# MAGIC
# MAGIC Each grid point injects `eps_y - fairness_metric(m) >= 0` as an additional
# MAGIC SLSQP inequality constraint. Grid points where both constraints are jointly
# MAGIC infeasible converge to `converged=False` — expected behaviour in the
# MAGIC tight corner of the grid.
# MAGIC
# MAGIC `n_jobs=-1` uses all available Databricks cluster cores.

# COMMAND ----------

pf = ParetoFrontier(
    optimiser=opt,
    fairness_metric=fairness_fn,
    sweep_x="volume_retention",
    sweep_x_range=(0.80, 0.96),
    sweep_y="fairness_max",
    sweep_y_range=(1.05, 2.00),
    n_points_x=10,
    n_points_y=10,
    n_jobs=-1,
)

result = pf.run()

print(f"Surface: {len(result.surface)} grid points")
print(f"Converged: {int(result.surface['converged'].sum())}")
print(f"Non-dominated Pareto solutions: {len(result.pareto_df)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Inspect the Pareto Surface

# COMMAND ----------

print("Pareto surface summary (top 10 by profit):")
print(result.summary().head(10))

# COMMAND ----------

# Distribution of convergence across the grid
conv_by_eps = (
    result.surface
    .group_by("grid_i")
    .agg(
        pl.col("converged").sum().alias("n_converged"),
        pl.len().alias("n_total"),
    )
    .sort("grid_i")
)
print("Convergence by retention grid index:")
print(conv_by_eps)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Visualise Trade-offs

# COMMAND ----------

# 2D scatter: retention (x) vs fairness disparity (y), coloured by profit
result.plot(
    x_metric="retention",
    y_metric="fairness",
    color_metric="profit",
    title="Pareto Surface: Profit / Retention / Fairness (500-policy portfolio)",
    annotate_extremes=True,
)
plt.savefig("/tmp/pareto_surface_2d.png", dpi=150, bbox_inches="tight")
print("2D plot saved to /tmp/pareto_surface_2d.png")

# COMMAND ----------

# 3D scatter: profit, retention, fairness
result.plot_3d()
plt.savefig("/tmp/pareto_surface_3d.png", dpi=150, bbox_inches="tight")
print("3D plot saved to /tmp/pareto_surface_3d.png")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Select a Solution via TOPSIS
# MAGIC
# MAGIC Business weights reflect the team's priorities:
# MAGIC - 50% profit (primary commercial objective)
# MAGIC - 30% retention (board KPI)
# MAGIC - 20% fairness (Consumer Duty compliance headroom)
# MAGIC
# MAGIC TOPSIS scores each non-dominated solution by its proximity to the ideal
# MAGIC point (best on all objectives) relative to the anti-ideal point.

# COMMAND ----------

result = result.select(method="topsis", weights=(0.5, 0.3, 0.2))

sel = result.selected
print("Selected solution:")
print(f"  Expected profit:    £{sel.expected_profit:,.0f}")
print(f"  Expected GWP:       £{sel.expected_gwp:,.0f}")
print(f"  Expected LR:        {sel.expected_loss_ratio:.3f}")
print(f"  Expected retention: {sel.expected_retention:.3f}")
print(f"  Fairness disparity: {sel.audit_trail['fairness']:.3f}")
print(f"  Grid point:         ({sel.audit_trail['pareto_grid_i']}, {sel.audit_trail['pareto_grid_j']})")
print(f"  Retention floor:    {sel.audit_trail['eps_x']:.3f}")
print(f"  Fairness cap:       {sel.audit_trail['eps_y']:.3f}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Save FCA Audit Trail
# MAGIC
# MAGIC The audit trail is a JSON file containing the full surface DataFrame,
# MAGIC Pareto subset, and run metadata. Attach to your pricing committee pack
# MAGIC as evidence that (a) the ENBP constraint was enforced across all grid
# MAGIC points and (b) the fairness trade-off was presented explicitly rather
# MAGIC than swept under a pre-committed cap.

# COMMAND ----------

audit_path = "/tmp/pareto_audit.json"
result.save_audit(audit_path)
print(f"Audit trail saved to {audit_path}")

# Verify
import json
with open(audit_path) as f:
    audit = json.load(f)
print(f"Audit metadata: {audit['metadata']}")
print(f"Surface rows: {len(audit['surface'])}")
print(f"Pareto rows: {len(audit['pareto_df'])}")
