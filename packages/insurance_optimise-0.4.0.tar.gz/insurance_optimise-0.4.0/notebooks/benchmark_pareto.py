# Databricks notebook source
# MAGIC %md
# MAGIC # Benchmark: ParetoFrontier — 3-objective vs 2-objective vs single-objective
# MAGIC
# MAGIC **Library:** `insurance-optimise` v0.4.0
# MAGIC
# MAGIC **What this compares:**
# MAGIC
# MAGIC 1. `PortfolioOptimiser` — single-objective, maximise profit with retention >= 90%
# MAGIC 2. `EfficientFrontier` — bi-objective, trace profit-retention Pareto curve (10 points)
# MAGIC 3. `ParetoFrontier` — tri-objective, 8×8 grid over (retention, fairness_max)
# MAGIC
# MAGIC **Portfolio:** 500 synthetic UK renewal policies, 5 deprivation quintiles, seed=42.
# MAGIC
# MAGIC **Date:** 2026-03-20

# COMMAND ----------

%pip install "insurance-optimise>=0.4.0"

# COMMAND ----------

import warnings
import time
from functools import partial

import numpy as np
warnings.filterwarnings("ignore")

from insurance_optimise import (
    ConstraintConfig,
    EfficientFrontier,
    ParetoFrontier,
    PortfolioOptimiser,
    premium_disparity_ratio,
    __version__,
)

print(f"insurance-optimise {__version__}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Synthetic portfolio

# COMMAND ----------

N = 500
SEED = 42
N_QUINTILES = 5

rng = np.random.default_rng(SEED)

tc = rng.uniform(200, 800, N)
cost = tc * rng.uniform(0.55, 0.75, N)
p_demand = rng.uniform(0.70, 0.95, N)
elasticity = rng.uniform(-2.5, -0.8, N)
renewal_flag = np.ones(N, dtype=bool)
enbp = tc * rng.uniform(1.0, 1.3, N)
group_labels = rng.integers(1, N_QUINTILES + 1, N)

fairness_fn = partial(
    premium_disparity_ratio,
    technical_price=tc,
    group_labels=group_labels,
)

print(f"Portfolio: {N} policies, {N_QUINTILES} deprivation quintiles, seed={SEED}")
print(f"  Technical price: £{tc.mean():.0f} mean (£{tc.min():.0f}–£{tc.max():.0f})")
print(f"  Expected LR:     {(cost/tc).mean():.3f} mean")
print(f"  Demand:          {p_demand.mean():.3f} mean probability at technical price")
print(f"  Elasticity:      {elasticity.mean():.2f} mean")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Single-objective: profit maximisation, retention >= 90%

# COMMAND ----------

BASE_CONFIG = ConstraintConfig(
    lr_max=0.72,
    retention_min=0.90,
    max_rate_change=0.25,
)

t0 = time.time()

opt_single = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=BASE_CONFIG,
    seed=SEED,
)

result_single = opt_single.optimise()
t_single = time.time() - t0

fair_single = fairness_fn(result_single.multipliers)
ret_single = result_single.expected_retention or 0.0

print(f"Profit:    £{result_single.expected_profit:,.0f}")
print(f"Retention: {ret_single * 100:.1f}%")
print(f"Fairness:  {fair_single:.3f} (premium disparity ratio)")
print(f"Converged: {result_single.converged}")
print(f"Runtime:   {t_single:.1f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Bi-objective frontier: profit × retention (10 points)

# COMMAND ----------

config_no_ret = ConstraintConfig(
    lr_max=0.72,
    retention_min=None,
    max_rate_change=0.25,
)

t0 = time.time()

opt_bi = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=config_no_ret,
    seed=SEED,
)

ef = EfficientFrontier(
    optimiser=opt_bi,
    sweep_param="volume_retention",
    sweep_range=(0.80, 0.98),
    n_points=10,
    n_jobs=1,
)

ef_result = ef.run()
t_bi = time.time() - t0

ef_data = ef_result.pareto_data()
n_bi_converged = len(ef_data)

if n_bi_converged > 0:
    profits_bi = [p for p in ef_data["profit"].to_list() if p == p]
    retentions_bi = [r for r in ef_data["retention"].to_list() if r is not None and r == r]
    profit_bi_lo = min(profits_bi)
    profit_bi_hi = max(profits_bi)
    ret_bi_lo = min(retentions_bi)
    ret_bi_hi = max(retentions_bi)
    print(f"Profit range:    £{profit_bi_lo:,.0f} – £{profit_bi_hi:,.0f}")
    print(f"Retention range: {ret_bi_lo * 100:.1f}% – {ret_bi_hi * 100:.1f}%")
    print(f"Fairness:        not tracked by EfficientFrontier")
else:
    print("  No converged points.")
    profit_bi_lo = profit_bi_hi = float("nan")
    ret_bi_lo = ret_bi_hi = float("nan")

print(f"Converged:       {n_bi_converged}/10")
print(f"Runtime:         {t_bi:.1f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Tri-objective Pareto surface (8×8 grid)

# COMMAND ----------

t0 = time.time()

opt_pareto = PortfolioOptimiser(
    technical_price=tc,
    expected_loss_cost=cost,
    p_demand=p_demand,
    elasticity=elasticity,
    renewal_flag=renewal_flag,
    enbp=enbp,
    constraints=config_no_ret,
    seed=SEED,
)

pf = ParetoFrontier(
    optimiser=opt_pareto,
    fairness_metric=fairness_fn,
    sweep_x="volume_retention",
    sweep_x_range=(0.80, 0.98),
    sweep_y="fairness_max",
    sweep_y_range=(1.05, 2.50),
    n_points_x=8,
    n_points_y=8,
    n_jobs=1,
)

pareto_result = pf.run()
t_pareto = time.time() - t0

n_total = len(pareto_result.surface)
n_nondom = len(pareto_result.pareto_df)
n_converged = int(pareto_result.surface["converged"].sum())

if n_nondom > 0:
    profits_p = [p for p in pareto_result.pareto_df["profit"].to_list() if p == p]
    retentions_p = [r for r in pareto_result.pareto_df["retention"].to_list() if r is not None and r == r]
    fairness_p = [f for f in pareto_result.pareto_df["fairness"].to_list() if f == f]
    profit_p_lo = min(profits_p)
    profit_p_hi = max(profits_p)
    ret_p_lo = min(retentions_p)
    ret_p_hi = max(retentions_p)
    fair_p_lo = min(fairness_p)
    fair_p_hi = max(fairness_p)
    print(f"Profit range:    £{profit_p_lo:,.0f} – £{profit_p_hi:,.0f}")
    print(f"Retention range: {ret_p_lo * 100:.1f}% – {ret_p_hi * 100:.1f}%")
    print(f"Fairness range:  {fair_p_lo:.3f} – {fair_p_hi:.3f}")
else:
    print("  No non-dominated solutions found.")
    profit_p_lo = profit_p_hi = float("nan")
    ret_p_lo = ret_p_hi = float("nan")
    fair_p_lo = fair_p_hi = float("nan")

print(f"Non-dominated:   {n_nondom}/{n_total} ({n_converged} converged)")
print(f"Runtime:         {t_pareto:.1f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. TOPSIS selection

# COMMAND ----------

if n_nondom > 0:
    pareto_result.select(method="topsis", weights=(0.5, 0.3, 0.2))
    sel = pareto_result.selected

    profit_topsis = sel.expected_profit
    ret_topsis = sel.expected_retention or 0.0
    fair_topsis = sel.audit_trail.get("fairness", float("nan"))

    if result_single.expected_profit and result_single.expected_profit != 0:
        profit_pct_diff = (profit_topsis - result_single.expected_profit) / abs(result_single.expected_profit) * 100
    else:
        profit_pct_diff = float("nan")

    ret_pp_diff = (ret_topsis - ret_single) * 100

    print(f"Profit:    £{profit_topsis:,.0f}  (vs single-objective: {profit_pct_diff:+.1f}%)")
    print(f"Retention: {ret_topsis * 100:.1f}%  (vs single-objective: {ret_pp_diff:+.1f}pp)")
    print(f"Fairness:  {fair_topsis:.3f}  (vs single-objective: {fair_single:.3f} → {fair_topsis:.3f})")
else:
    print("Cannot select — no non-dominated solutions.")
    profit_topsis = ret_topsis = fair_topsis = float("nan")
    profit_pct_diff = ret_pp_diff = float("nan")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Summary table

# COMMAND ----------

print("=" * 68)
print("SUMMARY TABLE")
print("=" * 68)
print(f"{'Approach':<40} {'Profit':>10} {'Ret%':>7} {'Fairness':>9}")
print("-" * 68)
print(
    f"{'Single-objective (ret >= 90%)':<40} "
    f"£{result_single.expected_profit:>8,.0f} "
    f"{ret_single * 100:>6.1f}% "
    f"{fair_single:>9.3f}"
)
if n_bi_converged > 0:
    print(
        f"{'Bi-obj best profit':<40} "
        f"£{profit_bi_hi:>8,.0f} "
        f"{ret_bi_lo * 100:>6.1f}% "
        f"{'n/a':>9}"
    )
    print(
        f"{'Bi-obj best retention':<40} "
        f"£{profit_bi_lo:>8,.0f} "
        f"{ret_bi_hi * 100:>6.1f}% "
        f"{'n/a':>9}"
    )
if n_nondom > 0:
    print(
        f"{'Pareto best profit':<40} "
        f"£{profit_p_hi:>8,.0f} "
        f"{'—':>7} "
        f"{'—':>9}"
    )
    print(
        f"{'Pareto best fairness':<40} "
        f"{'—':>10} "
        f"{'—':>7} "
        f"{fair_p_lo:>9.3f}"
    )
    if not (profit_topsis != profit_topsis):
        print(
            f"{'TOPSIS selected (0.5/0.3/0.2)':<40} "
            f"£{profit_topsis:>8,.0f} "
            f"{ret_topsis * 100:>6.1f}% "
            f"{fair_topsis:>9.3f}"
        )
