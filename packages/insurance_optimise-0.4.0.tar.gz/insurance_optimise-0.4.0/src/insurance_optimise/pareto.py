"""
3-objective Pareto surface generation for insurance portfolio rate optimisation.

Extends the bi-objective epsilon-constraint EfficientFrontier to a 2D grid
sweep, optimising simultaneously:

    f1: expected profit          (maximise) — primary objective
    f2: retention rate           (maximise) — swept as epsilon constraint (x-axis)
    f3: fairness disparity ratio (minimise) — swept as epsilon constraint (y-axis)

Each point on the Pareto surface is an independent SLSQP solve. The 2D grid
(n_points_x * n_points_y solves) is embarrassingly parallel via joblib.

Why epsilon-constraint?
-----------------------
The decision space for a policy-level portfolio is R^N. NSGA-II cannot
meaningfully explore this space for N > ~200 (see spec research summary).
Epsilon-constraint reuses the existing SLSQP infrastructure with analytical
gradients, is deterministic (regulatory audit requirement), and every
returned solution is certified Pareto-optimal — not an approximation.

Why fairness as an objective, not a constraint?
-----------------------------------------------
The acceptable level of premium disparity is a governance decision that
cannot be pre-determined by the library. The board needs to see the explicit
trade-off: "accepting X% less profit reduces our premium disparity ratio
from 1.35 to 1.10." Users who want a hard floor can set ``fairness_max``
on ParetoFrontier — this restricts the feasible region across all grid points
before the Pareto search, separately from the objective space.

Reference: FCA Consumer Duty PS22/9 August 2023; Lindholm, Richman, Tsanakas,
Wuthrich (2022) arXiv:2209.00858; Boonen et al. (2025) arXiv:2512.24747.
"""

from __future__ import annotations

import copy
import datetime
import json
import warnings
from dataclasses import dataclass, field
from functools import partial
from typing import Any, Callable, TYPE_CHECKING

import numpy as np
import polars as pl

from insurance_optimise.constraints import ConstraintConfig
from insurance_optimise.result import OptimisationResult

if TYPE_CHECKING:
    from insurance_optimise.optimiser import PortfolioOptimiser


# ---------------------------------------------------------------------------
# Built-in fairness metrics
# ---------------------------------------------------------------------------

def premium_disparity_ratio(
    multipliers: np.ndarray,
    technical_price: np.ndarray,
    group_labels: np.ndarray,
) -> float:
    """
    Mean premium ratio between the highest-premium and lowest-premium group.

    Computes mean(premium[group_max]) / mean(premium[group_min]) where
    ``group_labels`` partitions the portfolio (e.g. postcode deprivation
    quintile, age band, or any categorical segmentation).

    Returns 1.0 for perfect equality; 2.0 means the highest-premium group
    pays double on average relative to the lowest. Lower is fairer.

    This is the primary fairness metric for FCA Consumer Duty compliance under
    PS22/9. For portfolios with no group variation the function returns 1.0
    without raising.

    Parameters
    ----------
    multipliers:
        Optimal price multipliers, shape (N,).
    technical_price:
        Technical premiums array, shape (N,).
    group_labels:
        Integer or string group membership array, shape (N,). Each unique
        value is treated as one group (e.g. 1–5 for deprivation quintiles).

    Returns
    -------
    float
        Ratio >= 1.0. Returns 1.0 when fewer than two distinct groups are
        present.

    Usage
    -----
    Bind the portfolio-level arrays with ``functools.partial`` before passing
    to ``ParetoFrontier``::

        fairness_fn = partial(
            premium_disparity_ratio,
            technical_price=df['tc'].to_numpy(),
            group_labels=df['deprivation_quintile'].to_numpy(),
        )
    """
    multipliers = np.asarray(multipliers, dtype=float)
    technical_price = np.asarray(technical_price, dtype=float)
    group_labels = np.asarray(group_labels)

    premiums = multipliers * technical_price
    unique_groups = np.unique(group_labels)

    if len(unique_groups) < 2:
        return 1.0

    group_means = np.array([
        premiums[group_labels == g].mean() for g in unique_groups
    ])
    return float(group_means.max() / max(group_means.min(), 1e-10))


def loss_ratio_disparity(
    multipliers: np.ndarray,
    technical_price: np.ndarray,
    expected_loss_cost: np.ndarray,
    demand_model: Any,
    group_labels: np.ndarray,
) -> float:
    """
    Loss ratio disparity ratio across groups at the optimal prices.

    Ratio of the highest-LR group mean to the lowest-LR group mean.
    A ratio greater than 1.5 indicates material cross-subsidy between
    segments — typically a consumer duty concern for personal lines.

    Parameters
    ----------
    multipliers:
        Optimal price multipliers, shape (N,).
    technical_price:
        Technical premiums array, shape (N,).
    expected_loss_cost:
        Expected claims cost per policy, shape (N,).
    demand_model:
        Demand model instance with a ``.demand(m)`` method.
    group_labels:
        Group membership array, shape (N,). Each unique value is one group.

    Returns
    -------
    float
        Ratio >= 1.0. Returns 1.0 when fewer than two distinct groups are
        present, or when any group has zero expected GWP.
    """
    multipliers = np.asarray(multipliers, dtype=float)
    technical_price = np.asarray(technical_price, dtype=float)
    expected_loss_cost = np.asarray(expected_loss_cost, dtype=float)
    group_labels = np.asarray(group_labels)

    premiums = multipliers * technical_price
    demand = demand_model.demand(multipliers)
    unique_groups = np.unique(group_labels)

    if len(unique_groups) < 2:
        return 1.0

    group_lrs = []
    for g in unique_groups:
        mask = group_labels == g
        gwp_g = float(np.dot(premiums[mask], demand[mask]))
        if gwp_g < 1e-10:
            return 1.0  # degenerate group — cannot compute LR
        lr_g = float(np.dot(expected_loss_cost[mask], demand[mask]) / gwp_g)
        group_lrs.append(lr_g)

    group_lrs_arr = np.array(group_lrs)
    return float(group_lrs_arr.max() / max(group_lrs_arr.min(), 1e-10))


# ---------------------------------------------------------------------------
# Non-dominated filtering
# ---------------------------------------------------------------------------

def _filter_pareto_front(
    df: pl.DataFrame,
    profit_col: str = "profit",
    retention_col: str = "retention",
    fairness_col: str = "fairness",
    tol: float = 1e-6,
) -> pl.DataFrame:
    """
    Filter a DataFrame of converged solutions to the non-dominated subset.

    A solution (p, r, f) is dominated if there exists another converged
    solution (p', r', f') satisfying:
        p' >= p - tol  (at least as profitable)
        r' >= r - tol  (at least as high retention)
        f' <= f + tol  (at least as fair — fairness is minimised)
    with at least one strict inequality.

    Runtime is O(n^2) where n = number of converged solutions. For a 10x10
    grid with ~80 converged points, this is 6,400 comparisons — trivial.

    Parameters
    ----------
    df:
        DataFrame of converged solutions only. Must contain profit_col,
        retention_col, and fairness_col.
    profit_col, retention_col, fairness_col:
        Column names for the three objectives.
    tol:
        Numerical tolerance for dominance comparisons.

    Returns
    -------
    pl.DataFrame
        Subset of ``df`` containing only non-dominated solutions.
    """
    if len(df) == 0:
        return df

    profit = df[profit_col].to_numpy()
    retention = df[retention_col].to_numpy()
    fairness = df[fairness_col].to_numpy()

    n = len(df)
    dominated = np.zeros(n, dtype=bool)

    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            # Does j dominate i?
            j_as_good = (
                profit[j] >= profit[i] - tol
                and retention[j] >= retention[i] - tol
                and fairness[j] <= fairness[i] + tol
            )
            j_strictly_better = (
                profit[j] > profit[i] + tol
                or retention[j] > retention[i] + tol
                or fairness[j] < fairness[i] - tol
            )
            if j_as_good and j_strictly_better:
                dominated[i] = True
                break

    return df.filter(~pl.Series("dominated", dominated))


# ---------------------------------------------------------------------------
# TOPSIS selection
# ---------------------------------------------------------------------------

def _topsis_select(
    pareto_df: pl.DataFrame,
    weights: tuple[float, float, float],
    objectives: tuple[str, str, str] = ("profit", "retention", "fairness"),
    directions: tuple[str, str, str] = ("max", "max", "min"),
) -> int:
    """
    TOPSIS multi-criteria selection from the Pareto surface.

    Returns the row index in ``pareto_df`` of the selected solution.

    Steps:
    1. Min-max normalise each objective to [0, 1], flipping 'min' objectives
       so that higher normalised values are always better.
    2. Apply weights element-wise.
    3. Compute Euclidean distance from weighted ideal (1, 1, 1) and
       weighted anti-ideal (0, 0, 0).
    4. Select the row maximising D_minus / (D_plus + D_minus).

    Parameters
    ----------
    pareto_df:
        Non-dominated solutions. Must contain all three objective columns.
    weights:
        Relative importance tuple (w_profit, w_retention, w_fairness).
        Must sum to a positive value; individual weights must be >= 0.
    objectives:
        Column names for the three objectives.
    directions:
        'max' = higher is better; 'min' = lower is better. Element order
        must match ``objectives``.

    Returns
    -------
    int
        Row index (0-based) in ``pareto_df`` of the selected solution.

    Raises
    ------
    ValueError
        If all weights are zero, or if ``pareto_df`` is empty.
    """
    if len(pareto_df) == 0:
        raise ValueError(
            "Cannot select from an empty Pareto surface. "
            "All grid points failed to converge."
        )

    weights_arr = np.array(weights, dtype=float)
    if weights_arr.sum() <= 0:
        raise ValueError(
            f"Weights must sum to a positive value, got {weights_arr.tolist()}."
        )
    if np.any(weights_arr < 0):
        raise ValueError(
            f"All weights must be non-negative, got {weights_arr.tolist()}."
        )

    # Extract objective matrix: shape (n_solutions, 3)
    matrix = np.column_stack([pareto_df[col].to_numpy() for col in objectives])

    # Normalise each column to [0, 1]; flip 'min' objectives
    normalised = np.zeros_like(matrix)
    for k, direction in enumerate(directions):
        col = matrix[:, k]
        col_min = col.min()
        col_max = col.max()
        if col_max - col_min < 1e-12:
            # All identical — arbitrary; set to 0.5
            normalised[:, k] = 0.5
        else:
            scaled = (col - col_min) / (col_max - col_min)
            if direction == "min":
                scaled = 1.0 - scaled  # flip so higher = better
            normalised[:, k] = scaled

    # Apply weights
    weighted = normalised * weights_arr

    # Ideal = all-ones (best in every objective); anti-ideal = all-zeros
    ideal = weights_arr.copy()
    anti_ideal = np.zeros_like(weights_arr)

    # Euclidean distances
    d_plus = np.sqrt(np.sum((weighted - ideal) ** 2, axis=1))
    d_minus = np.sqrt(np.sum((weighted - anti_ideal) ** 2, axis=1))

    denom = d_plus + d_minus
    # Avoid zero denominator (all solutions at the anti-ideal)
    denom = np.where(denom < 1e-12, 1e-12, denom)

    score = d_minus / denom
    return int(np.argmax(score))


# ---------------------------------------------------------------------------
# ParetoResult
# ---------------------------------------------------------------------------

@dataclass
class ParetoResult:
    """
    Output from ParetoFrontier.run().

    Attributes
    ----------
    surface:
        All grid points (n_points_x * n_points_y rows). Columns:
        ``eps_x``, ``eps_y``, ``converged``, ``profit``, ``gwp``,
        ``loss_ratio``, ``retention``, ``fairness``, ``n_iter``,
        ``solver_message``, ``grid_i``, ``grid_j``.
    pareto_df:
        Filtered to non-dominated converged solutions only.
    metadata:
        Run parameters: sweep_x, sweep_y, sweep_x_range, sweep_y_range,
        n_points_x, n_points_y, fairness_metric_name, timestamp.
    _grid_multipliers:
        Raw multiplier arrays keyed by (i_x, i_y). Stored outside the
        DataFrame to avoid embedding large arrays in Polars rows.
    selected:
        The automatically selected solution after ``select()`` is called.
        None until ``select()`` is called.
    """

    surface: pl.DataFrame
    pareto_df: pl.DataFrame
    metadata: dict[str, Any]
    _grid_multipliers: dict[tuple[int, int], np.ndarray]
    selected: OptimisationResult | None = field(default=None)

    def select(
        self,
        method: str = "topsis",
        weights: tuple[float, float, float] = (0.5, 0.3, 0.2),
    ) -> "ParetoResult":
        """
        Select a single solution from the Pareto surface.

        Populates ``.selected`` with an ``OptimisationResult`` corresponding
        to the chosen grid point.

        Parameters
        ----------
        method:
            Selection method. ``'topsis'`` (default) applies TOPSIS
            multi-criteria scoring. ``'closest_to_utopia'`` selects the
            solution with the minimum normalised distance to the ideal point
            under equal weights.
        weights:
            Relative importance of (profit, retention, fairness). Values
            must be non-negative and sum to a positive number.

        Returns
        -------
        ParetoResult
            Self, with ``.selected`` populated.

        Raises
        ------
        ValueError
            If the Pareto surface is empty (all grid points failed) or if
            weights are invalid.
        """
        if len(self.pareto_df) == 0:
            raise ValueError(
                "Cannot select from an empty Pareto surface. "
                "All grid points failed to converge."
            )

        if method == "topsis":
            row_idx = _topsis_select(
                self.pareto_df,
                weights=weights,
                objectives=("profit", "retention", "fairness"),
                directions=("max", "max", "min"),
            )
        elif method == "closest_to_utopia":
            # Equal weights TOPSIS is equivalent to closest-to-utopia
            row_idx = _topsis_select(
                self.pareto_df,
                weights=(1.0, 1.0, 1.0),
                objectives=("profit", "retention", "fairness"),
                directions=("max", "max", "min"),
            )
        else:
            raise ValueError(
                f"Unknown selection method '{method}'. "
                "Supported: 'topsis', 'closest_to_utopia'."
            )

        row = self.pareto_df.row(row_idx, named=True)
        i_x = int(row["grid_i"])
        i_j = int(row["grid_j"])
        key = (i_x, i_j)

        if key not in self._grid_multipliers:
            raise RuntimeError(
                f"Multipliers for grid point {key} not found in _grid_multipliers."
            )

        multipliers = self._grid_multipliers[key]

        # Reconstruct a minimal OptimisationResult from the stored surface row
        n = len(multipliers)
        self.selected = OptimisationResult(
            multipliers=multipliers,
            new_premiums=np.zeros(n),  # not available without re-running
            expected_demand=np.zeros(n),
            expected_profit=float(row["profit"]),
            expected_gwp=float(row["gwp"]),
            expected_loss_ratio=float(row["loss_ratio"]),
            expected_retention=float(row["retention"]) if row["retention"] is not None else None,
            shadow_prices={},
            converged=bool(row["converged"]),
            solver_message=str(row["solver_message"]),
            n_iter=int(row["n_iter"]),
            audit_trail={
                "pareto_grid_i": i_x,
                "pareto_grid_j": i_j,
                "eps_x": float(row["eps_x"]),
                "eps_y": float(row["eps_y"]),
                "fairness": float(row["fairness"]),
                "selection_method": method,
                "selection_weights": list(weights),
            },
            summary_df=pl.DataFrame(),
        )

        return self

    def summary(self) -> pl.DataFrame:
        """
        Return a concise summary of the Pareto surface.

        Includes all non-dominated solutions sorted by profit descending,
        with key metrics in a compact form.

        Returns
        -------
        pl.DataFrame
            Columns: profit, retention, fairness, loss_ratio, gwp,
            eps_x, eps_y, converged.
        """
        cols = [
            "profit", "retention", "fairness", "loss_ratio", "gwp",
            "eps_x", "eps_y", "converged",
        ]
        available = [c for c in cols if c in self.pareto_df.columns]
        df = self.pareto_df.select(available)
        if "profit" in df.columns:
            df = df.sort("profit", descending=True)
        return df

    def to_dict(self) -> dict[str, Any]:
        """
        Serialise to a JSON-compatible dict.

        The ``surface`` DataFrame is converted to a list of row dicts.
        Multiplier arrays are excluded (they may be very large).

        Returns
        -------
        dict
        """
        return {
            "metadata": self.metadata,
            "surface": self.surface.to_dicts(),
            "pareto_df": self.pareto_df.to_dicts(),
            "n_converged": int(self.surface["converged"].sum()),
            "n_pareto": len(self.pareto_df),
        }

    def to_json(self) -> str:
        """
        Serialise to a JSON string.

        Returns
        -------
        str
            Valid JSON.
        """
        return json.dumps(self.to_dict(), indent=2, default=_json_default)

    def save_audit(self, path: str) -> None:
        """
        Write JSON audit trail to path (creates or overwrites).

        The output file contains the full surface DataFrame, Pareto subset,
        and run metadata. Suitable as regulatory evidence under FCA Consumer
        Duty PS22/9.

        Parameters
        ----------
        path:
            File path. Parent directory must exist.
        """
        with open(path, "w") as fh:
            fh.write(self.to_json())

    def plot(
        self,
        x_metric: str = "retention",
        y_metric: str = "fairness",
        color_metric: str = "profit",
        figsize: tuple[float, float] = (9, 7),
        title: str | None = None,
        show_colorbar: bool = True,
        annotate_extremes: bool = True,
    ) -> None:
        """
        Scatter plot of the Pareto surface with a colour axis.

        Non-dominated solutions are plotted as solid markers; dominated
        (converged but non-Pareto) solutions are shown as faded crosses.
        The three extreme solutions — maximum profit, maximum retention,
        and minimum fairness disparity — are annotated by default.

        Parameters
        ----------
        x_metric:
            Column from ``surface`` to use as x-axis.
        y_metric:
            Column from ``surface`` to use as y-axis.
        color_metric:
            Column from ``surface`` used for the colour scale.
        figsize:
            Figure size tuple passed to ``plt.subplots``.
        title:
            Plot title. Auto-generated if None.
        show_colorbar:
            Whether to display the colour bar.
        annotate_extremes:
            Annotate the max-profit, max-retention, and min-fairness points.

        Raises
        ------
        ImportError
            If matplotlib is not installed.
        """
        try:
            import matplotlib.pyplot as plt
            import matplotlib.cm as cm
        except ImportError:
            raise ImportError(
                "matplotlib required for plotting. "
                "Install with: pip install matplotlib"
            )

        surface = self.surface.filter(pl.col("converged"))
        if len(surface) == 0:
            warnings.warn("No converged solutions to plot.", stacklevel=2)
            return

        # Pareto-surface indices
        pareto_keys = set(
            zip(
                self.pareto_df["grid_i"].to_list(),
                self.pareto_df["grid_j"].to_list(),
            )
        )
        is_pareto = np.array([
            (int(row["grid_i"]), int(row["grid_j"])) in pareto_keys
            for row in surface.iter_rows(named=True)
        ])

        x_vals = surface[x_metric].to_numpy()
        y_vals = surface[y_metric].to_numpy()
        c_vals = surface[color_metric].to_numpy()

        c_norm = plt.Normalize(vmin=c_vals.min(), vmax=c_vals.max())
        cmap = cm.viridis

        fig, ax = plt.subplots(figsize=figsize)

        # Dominated solutions: faded
        dominated_mask = ~is_pareto
        if dominated_mask.any():
            ax.scatter(
                x_vals[dominated_mask],
                y_vals[dominated_mask],
                c=c_vals[dominated_mask],
                cmap=cmap,
                norm=c_norm,
                marker="x",
                alpha=0.3,
                s=40,
                label="Dominated",
            )

        # Non-dominated solutions: solid
        pareto_mask = is_pareto
        if pareto_mask.any():
            sc = ax.scatter(
                x_vals[pareto_mask],
                y_vals[pareto_mask],
                c=c_vals[pareto_mask],
                cmap=cmap,
                norm=c_norm,
                marker="o",
                alpha=0.9,
                s=80,
                edgecolors="k",
                linewidths=0.5,
                label="Pareto",
                zorder=3,
            )
            if show_colorbar:
                plt.colorbar(sc, ax=ax, label=color_metric.replace("_", " ").title())

        if annotate_extremes and pareto_mask.any():
            pf_x = x_vals[pareto_mask]
            pf_y = y_vals[pareto_mask]
            pf_c = c_vals[pareto_mask]

            annotations = {
                "max profit": np.argmax(pf_c),
                "max retention": np.argmax(pf_x) if x_metric == "retention" else None,
                "min disparity": np.argmin(pf_y) if y_metric == "fairness" else None,
            }

            for label, idx in annotations.items():
                if idx is not None:
                    ax.annotate(
                        label,
                        (pf_x[idx], pf_y[idx]),
                        fontsize=8,
                        xytext=(5, 5),
                        textcoords="offset points",
                        arrowprops={"arrowstyle": "->", "lw": 0.8},
                    )

        ax.set_xlabel(x_metric.replace("_", " ").title())
        ax.set_ylabel(y_metric.replace("_", " ").title())
        ax.set_title(
            title
            or f"Pareto Surface: {y_metric} vs {x_metric} (colour = {color_metric})"
        )
        ax.legend(loc="best", fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

    def plot_3d(self, figsize: tuple[float, float] = (10, 8)) -> None:
        """
        3D scatter of (profit, retention, fairness) for all converged solutions.

        Non-dominated solutions are shown in a contrasting colour.
        Requires matplotlib with mpl_toolkits.mplot3d (standard with any
        recent matplotlib install).

        Parameters
        ----------
        figsize:
            Figure size tuple.

        Raises
        ------
        ImportError
            If matplotlib is not installed.
        """
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
        except ImportError:
            raise ImportError(
                "matplotlib required for 3D plotting. "
                "Install with: pip install matplotlib"
            )

        surface = self.surface.filter(pl.col("converged"))
        if len(surface) == 0:
            warnings.warn("No converged solutions to plot.", stacklevel=2)
            return

        pareto_keys = set(
            zip(
                self.pareto_df["grid_i"].to_list(),
                self.pareto_df["grid_j"].to_list(),
            )
        )
        is_pareto = np.array([
            (int(row["grid_i"]), int(row["grid_j"])) in pareto_keys
            for row in surface.iter_rows(named=True)
        ])

        profit = surface["profit"].to_numpy()
        retention = surface["retention"].to_numpy()
        fairness = surface["fairness"].to_numpy()

        fig = plt.figure(figsize=figsize)
        ax = fig.add_subplot(111, projection="3d")

        dominated_mask = ~is_pareto
        if dominated_mask.any():
            ax.scatter(
                profit[dominated_mask],
                retention[dominated_mask],
                fairness[dominated_mask],
                c="#aaaaaa",
                alpha=0.3,
                s=30,
                label="Dominated",
                marker="x",
            )

        pareto_mask = is_pareto
        if pareto_mask.any():
            ax.scatter(
                profit[pareto_mask],
                retention[pareto_mask],
                fairness[pareto_mask],
                c="#d62728",
                alpha=0.85,
                s=60,
                label="Pareto",
                marker="o",
                edgecolors="k",
                linewidths=0.5,
                zorder=3,
            )

        ax.set_xlabel("Profit")
        ax.set_ylabel("Retention")
        ax.set_zlabel("Fairness Disparity")
        ax.set_title("3D Pareto Surface: Profit / Retention / Fairness")
        ax.legend(loc="best", fontsize=8)
        plt.tight_layout()
        plt.show()


# ---------------------------------------------------------------------------
# ParetoFrontier
# ---------------------------------------------------------------------------

class ParetoFrontier:
    """
    3-objective Pareto surface for insurance portfolio rate optimisation.

    Extends the bi-objective epsilon-constraint EfficientFrontier to a
    2D epsilon grid sweep over two secondary objectives, simultaneously
    optimising:

        f1: expected profit (maximise) — primary objective
        f2: retention rate (maximise) — swept as epsilon constraint
        f3: fairness metric (minimise disparity) — swept as epsilon constraint

    Each point on the Pareto surface is an independent SLSQP solve with
    analytical gradients, guaranteeing Pareto-optimality at each point.
    The 2D grid (n_points_x * n_points_y solves) is embarrassingly parallel.

    Parameters
    ----------
    optimiser:
        Configured ``PortfolioOptimiser`` instance. A deep copy is made for
        each grid point with modified constraints. The original is never
        mutated.
    fairness_metric:
        Callable mapping ``(multipliers: np.ndarray) -> float``. Returns a
        scalar unfairness value — lower is more fair. Called once per grid
        point after the SLSQP solve completes, unless ``sweep_y='fairness_max'``
        in which case it is also injected as an SLSQP constraint during the
        solve. Must be pure (no side effects) and O(N) fast. Default:
        ``premium_disparity_ratio`` bound to the portfolio data (requires
        ``group_labels``).
    fairness_gradient:
        Optional analytical gradient of ``fairness_metric`` w.r.t. multipliers.
        Signature: ``(multipliers: np.ndarray) -> np.ndarray``. When provided,
        suppresses finite-difference gradient computation for the fairness
        constraint. Material performance improvement for N > 5,000.
    sweep_x:
        First epsilon-constraint axis. One of: ``'volume_retention'``
        (default), ``'lr_max'``, ``'gwp_min'``.
    sweep_x_range:
        (min, max) for the x-axis sweep. E.g. (0.80, 0.99) for retention.
    sweep_y:
        Second epsilon-constraint axis. One of: ``'fairness_max'`` (default),
        ``'lr_max'``, ``'gwp_min'``. When ``'fairness_max'``, adds a scipy
        inequality constraint ``eps_y - fairness_metric(m) >= 0`` to each
        SLSQP solve. For other options, ``fairness_metric`` is evaluated
        post-hoc as a diagnostic only.
    sweep_y_range:
        (min, max) for the y-axis. E.g. (1.05, 2.50) for disparity ratio cap.
    n_points_x:
        Grid resolution on the x-axis. Default 10.
    n_points_y:
        Grid resolution on the y-axis. Default 10. Total solves = n_x * n_y.
    fairness_max:
        Hard cap on ``fairness_metric(m)`` applied to every grid point.
        Adds a binding constraint to every SLSQP solve. This restricts the
        feasible region but does not replace the Pareto fairness objective.
        Setting this is equivalent to clamping ``sweep_y_range`` max to
        ``fairness_max`` for the ``'fairness_max'`` sweep mode.
    n_jobs:
        Parallel workers for the grid sweep. -1 = all CPUs. 1 = sequential
        (default). Requires joblib if n_jobs != 1.
    """

    _VALID_X = ("volume_retention", "lr_max", "gwp_min")
    _VALID_Y = ("fairness_max", "lr_max", "gwp_min")

    def __init__(
        self,
        optimiser: "PortfolioOptimiser",
        fairness_metric: Callable[[np.ndarray], float] | None = None,
        fairness_gradient: Callable[[np.ndarray], np.ndarray] | None = None,
        sweep_x: str = "volume_retention",
        sweep_x_range: tuple[float, float] = (0.80, 0.99),
        sweep_y: str = "fairness_max",
        sweep_y_range: tuple[float, float] = (1.05, 2.50),
        n_points_x: int = 10,
        n_points_y: int = 10,
        fairness_max: float | None = None,
        n_jobs: int = 1,
    ) -> None:
        if sweep_x not in self._VALID_X:
            raise ValueError(
                f"sweep_x '{sweep_x}' not supported. Choose from {self._VALID_X}."
            )
        if sweep_y not in self._VALID_Y:
            raise ValueError(
                f"sweep_y '{sweep_y}' not supported. Choose from {self._VALID_Y}."
            )
        if sweep_x == sweep_y:
            raise ValueError(
                f"sweep_x and sweep_y must be different objectives, both are '{sweep_x}'."
            )

        self.optimiser = optimiser
        self.fairness_metric = fairness_metric
        self.fairness_gradient = fairness_gradient
        self.sweep_x = sweep_x
        self.sweep_x_range = sweep_x_range
        self.sweep_y = sweep_y
        self.sweep_y_range = sweep_y_range
        self.n_points_x = n_points_x
        self.n_points_y = n_points_y
        self.fairness_max = fairness_max
        self.n_jobs = n_jobs

    def run(self) -> ParetoResult:
        """
        Run the full 2D grid sweep and return a ParetoResult.

        Each grid point is solved independently. Convergence failures are
        recorded as ``converged=False`` rows in the surface DataFrame — they
        do not raise. A warning is emitted if more than 20% of grid points
        fail to converge.

        Returns
        -------
        ParetoResult
            Contains ``.surface`` (all grid points), ``.pareto_df``
            (non-dominated subset), and ``._grid_multipliers``.
        """
        epsilons_x = np.linspace(
            self.sweep_x_range[0], self.sweep_x_range[1], self.n_points_x
        )
        epsilons_y = np.linspace(
            self.sweep_y_range[0], self.sweep_y_range[1], self.n_points_y
        )

        # Build list of (i_x, i_y, eps_x, eps_y) tasks
        tasks = [
            (i, j, float(epsilons_x[i]), float(epsilons_y[j]))
            for i in range(self.n_points_x)
            for j in range(self.n_points_y)
        ]

        if self.n_jobs == 1:
            records = [self._solve_grid_point(t) for t in tasks]
        else:
            records = self._run_parallel(tasks)

        # Collect into surface DataFrame and multiplier dict
        rows = []
        grid_multipliers: dict[tuple[int, int], np.ndarray] = {}

        for rec in records:
            i_x, i_j = rec["grid_i"], rec["grid_j"]
            grid_multipliers[(i_x, i_j)] = rec.pop("_multipliers")
            rows.append(rec)

        surface = pl.DataFrame(rows)

        # Non-dominated filtering on converged solutions
        converged_surface = surface.filter(pl.col("converged"))
        if len(converged_surface) > 0:
            pareto_df = _filter_pareto_front(converged_surface)
        else:
            pareto_df = converged_surface  # empty

        # Warn if > 20% non-convergence
        n_total = len(surface)
        n_failed = int(n_total - surface["converged"].sum())
        if n_total > 0 and n_failed / n_total > 0.20:
            warnings.warn(
                f"{n_failed}/{n_total} grid points ({100*n_failed/n_total:.0f}%) "
                "failed to converge. Consider relaxing sweep ranges or checking "
                "that the base constraint config is feasible.",
                stacklevel=2,
            )

        metric_name = (
            self.fairness_metric.__name__
            if hasattr(self.fairness_metric, "__name__")
            else (
                getattr(self.fairness_metric, "func", self.fairness_metric).__name__
                if hasattr(self.fairness_metric, "func")
                else "custom"
            )
        ) if self.fairness_metric is not None else "none"

        metadata: dict[str, Any] = {
            "sweep_x": self.sweep_x,
            "sweep_y": self.sweep_y,
            "sweep_x_range": list(self.sweep_x_range),
            "sweep_y_range": list(self.sweep_y_range),
            "n_points_x": self.n_points_x,
            "n_points_y": self.n_points_y,
            "fairness_metric_name": metric_name,
            "fairness_max": self.fairness_max,
            "n_jobs": self.n_jobs,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "n_converged": int(surface["converged"].sum()),
            "n_pareto": len(pareto_df),
        }

        return ParetoResult(
            surface=surface,
            pareto_df=pareto_df,
            metadata=metadata,
            _grid_multipliers=grid_multipliers,
        )

    def _solve_grid_point(
        self, task: tuple[int, int, float, float]
    ) -> dict[str, Any]:
        """
        Solve one grid point and return a row dict.

        The task tuple is (i_x, i_j, eps_x, eps_y). A fresh PortfolioOptimiser
        is constructed for each point by deep-copying the base config and
        injecting the epsilon constraints. Additional scipy inequality constraints
        (e.g. fairness cap) are appended after the base build.
        """
        i_x, i_j, eps_x, eps_y = task

        from insurance_optimise.optimiser import PortfolioOptimiser

        # Build modified config
        new_config = copy.deepcopy(self.optimiser.config)
        self._set_x_epsilon(new_config, eps_x)

        # For sweep_y that maps to config fields (lr_max / gwp_min),
        # set them here. fairness_max is handled as an extra scipy constraint.
        if self.sweep_y == "lr_max":
            new_config.lr_max = eps_y
        elif self.sweep_y == "gwp_min":
            new_config.gwp_min = eps_y
        # fairness_max handled below as extra constraint

        # Deterministic but varied seed per grid point
        seed = (int(eps_x * 1e4) * 1000 + int(eps_y * 1e4)) % (2**31)

        opt = PortfolioOptimiser(
            technical_price=self.optimiser.tc,
            expected_loss_cost=self.optimiser.cost,
            p_demand=self.optimiser.x0,
            elasticity=self.optimiser.elasticity,
            renewal_flag=self.optimiser.renewal_flag,
            enbp=self.optimiser.enbp,
            prior_multiplier=self.optimiser.prior_multiplier,
            claims_variance=self.optimiser.claims_variance,
            constraints=new_config,
            demand_model=self.optimiser.demand_model_name,
            solver=(
                "slsqp"
                if self.optimiser.solver_method == "SLSQP"
                else "trust_constr"
            ),
            n_restarts=self.optimiser.n_restarts,
            seed=seed,
            ftol=self.optimiser.ftol,
            maxiter=self.optimiser.maxiter,
        )

        # Inject fairness constraints as extra scipy constraints
        extra_constraints = self._build_fairness_constraints(eps_y)
        if extra_constraints:
            opt._scipy_constraints = opt._scipy_constraints + extra_constraints

        try:
            result = opt.optimise()
        except Exception as exc:
            warnings.warn(
                f"Grid point ({i_x}, {i_j}) eps_x={eps_x:.4f} eps_y={eps_y:.4f} "
                f"failed: {exc}",
                stacklevel=3,
            )
            dummy_m = np.ones(opt.n)
            return {
                "eps_x": eps_x,
                "eps_y": eps_y,
                "converged": False,
                "profit": float("nan"),
                "gwp": float("nan"),
                "loss_ratio": float("nan"),
                "retention": float("nan"),
                "fairness": float("nan"),
                "n_iter": 0,
                "solver_message": str(exc),
                "grid_i": i_x,
                "grid_j": i_j,
                "_multipliers": dummy_m,
            }

        # Evaluate fairness metric post-hoc
        if self.fairness_metric is not None:
            try:
                fairness_val = float(self.fairness_metric(result.multipliers))
            except Exception:
                fairness_val = float("nan")
        else:
            fairness_val = float("nan")

        return {
            "eps_x": eps_x,
            "eps_y": eps_y,
            "converged": result.converged,
            "profit": result.expected_profit,
            "gwp": result.expected_gwp,
            "loss_ratio": result.expected_loss_ratio,
            "retention": result.expected_retention if result.expected_retention is not None else float("nan"),
            "fairness": fairness_val,
            "n_iter": result.n_iter,
            "solver_message": result.solver_message,
            "grid_i": i_x,
            "grid_j": i_j,
            "_multipliers": result.multipliers,
        }

    def _set_x_epsilon(self, config: ConstraintConfig, epsilon: float) -> None:
        """Inject the x-axis epsilon constraint into a ConstraintConfig."""
        if self.sweep_x == "volume_retention":
            config.retention_min = epsilon
        elif self.sweep_x == "gwp_min":
            config.gwp_min = epsilon
        elif self.sweep_x == "lr_max":
            config.lr_max = epsilon

    def _build_fairness_constraints(self, eps_y: float) -> list[dict]:
        """
        Build additional scipy inequality constraints for the fairness axis.

        When ``sweep_y='fairness_max'``, injects ``eps_y - f(m) >= 0`` where
        f is the fairness metric. When a ``fairness_max`` hard cap is set, an
        additional ``fairness_max - f(m) >= 0`` constraint is always added.

        No analytical Jacobian is provided unless ``fairness_gradient`` was
        passed to ``ParetoFrontier``. Without it, scipy uses finite differences
        for this constraint. At N=1,000 the overhead is ~20ms per SLSQP
        iteration — acceptable. At N=10,000, provide ``fairness_gradient``.
        """
        if self.fairness_metric is None:
            return []

        extra: list[dict] = []

        if self.sweep_y == "fairness_max":
            cap = eps_y
            fm = self.fairness_metric
            fg = self.fairness_gradient

            def _fairness_con(m: np.ndarray, _cap: float = cap, _fm: Any = fm) -> float:
                return _cap - _fm(m)

            con: dict[str, Any] = {"type": "ineq", "fun": _fairness_con}
            if fg is not None:
                def _fairness_jac(m: np.ndarray, _fg: Any = fg) -> np.ndarray:
                    return -_fg(m)
                con["jac"] = _fairness_jac

            extra.append(con)

        # Hard fairness cap applied across all grid points
        if self.fairness_max is not None:
            hard_cap = self.fairness_max
            fm = self.fairness_metric
            fg = self.fairness_gradient

            def _hard_fairness_con(
                m: np.ndarray, _cap: float = hard_cap, _fm: Any = fm
            ) -> float:
                return _cap - _fm(m)

            hard_con: dict[str, Any] = {"type": "ineq", "fun": _hard_fairness_con}
            if fg is not None:
                def _hard_fairness_jac(m: np.ndarray, _fg: Any = fg) -> np.ndarray:
                    return -_fg(m)
                hard_con["jac"] = _hard_fairness_jac

            extra.append(hard_con)

        return extra

    def _run_parallel(
        self, tasks: list[tuple[int, int, float, float]]
    ) -> list[dict[str, Any]]:
        """Run the grid sweep in parallel using joblib."""
        try:
            from joblib import Parallel, delayed
        except ImportError:
            warnings.warn(
                "joblib not installed — falling back to sequential grid sweep. "
                "Install joblib for parallel execution: pip install joblib",
                stacklevel=2,
            )
            return [self._solve_grid_point(t) for t in tasks]

        results = Parallel(n_jobs=self.n_jobs)(
            delayed(self._solve_grid_point)(t) for t in tasks
        )
        return list(results)

    def plot(
        self,
        x_metric: str = "retention",
        y_metric: str = "fairness",
        color_metric: str = "profit",
        figsize: tuple[float, float] = (9, 7),
        title: str | None = None,
        show_colorbar: bool = True,
        annotate_extremes: bool = True,
    ) -> None:
        """
        Run the sweep and plot the resulting Pareto surface.

        Convenience wrapper that calls ``run()`` then ``ParetoResult.plot()``.
        If you want to inspect the result before plotting, call ``run()``
        separately and use the returned ``ParetoResult``.

        Parameters
        ----------
        x_metric, y_metric, color_metric:
            Column names for the plot axes.
        figsize:
            Figure size tuple.
        title:
            Plot title.
        show_colorbar:
            Whether to display the colour bar.
        annotate_extremes:
            Annotate extreme solutions.
        """
        result = self.run()
        result.plot(
            x_metric=x_metric,
            y_metric=y_metric,
            color_metric=color_metric,
            figsize=figsize,
            title=title,
            show_colorbar=show_colorbar,
            annotate_extremes=annotate_extremes,
        )

    def plot_3d(self, figsize: tuple[float, float] = (10, 8)) -> None:
        """
        Run the sweep and render a 3D Pareto surface scatter plot.

        Convenience wrapper around ``run()`` and ``ParetoResult.plot_3d()``.

        Parameters
        ----------
        figsize:
            Figure size tuple.
        """
        result = self.run()
        result.plot_3d(figsize=figsize)


# ---------------------------------------------------------------------------
# JSON serialisation helper
# ---------------------------------------------------------------------------

def _json_default(obj: Any) -> Any:
    """JSON serialiser for numpy types."""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serialisable")
