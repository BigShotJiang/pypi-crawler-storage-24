"""TypedDict types matching the Claiv Memory API contracts exactly."""

from __future__ import annotations

from typing import Any, Literal, TypedDict

# ---------------------------------------------------------------------------
# Literal unions
# ---------------------------------------------------------------------------

EventType = Literal["message", "tool_call", "app_event"]

EventRole = Literal["user", "assistant", "system", "tool"]

MemoryBlockType = Literal["open_loop", "fact", "claim", "episode", "chunk", "contradiction"]

MemoryScope = Literal["global", "project", "conversation"]

UsageRange = Literal["7d", "30d", "month", "today"]

# ---------------------------------------------------------------------------
# Ingest
# ---------------------------------------------------------------------------


class IngestRequest(TypedDict, total=False):
    user_id: str  # required – enforced at runtime
    type: EventType  # required
    content: str  # required
    conversation_id: str  # required
    project_id: str  # optional — groups facts under a project
    scope: MemoryScope  # 'global' (default), 'project', or 'conversation'
    document_id: str  # optional — tag facts with a document identifier
    document_name: str  # optional — human-readable document name for citations
    role: EventRole
    metadata: dict[str, Any]
    event_time: str
    idempotency_key: str


class IngestResponse(TypedDict):
    event_id: str
    deduped: bool


# ---------------------------------------------------------------------------
# Recall (V6)
# ---------------------------------------------------------------------------


class RecallLimits(TypedDict, total=False):
    answer_facts: int
    supporting_facts: int
    background_facts: int
    max_list_items: int
    document_chunks: int  # max chunks injected in semantic mode (default 5)


class RecallInclude(TypedDict, total=False):
    pending_plan: bool
    debug: bool


class RecallRequest(TypedDict, total=False):
    user_id: str  # required
    query: str  # required
    conversation_id: str  # required
    project_id: str  # optional — include project-scoped facts
    document_id: str  # optional — restrict recall to a specific document
    reference_time: str | None
    mode_hint: str | None
    limits: RecallLimits
    include: RecallInclude


class V6TemporalMatch(TypedDict, total=False):
    ts_start: str  # required
    ts_end: str | None  # required
    raw_expression: str | None
    anchor_time: str | None
    date_type: str  # required
    granularity: str  # required


class RecallFact(TypedDict, total=False):
    fact_id: str  # required
    subject: str  # required
    kind: str  # required
    predicate: str  # required
    object: Any  # required
    object_text: str  # required
    relation_phrase: str | None
    source_text: str | None
    confidence: float | None
    importance: float | None
    created_at: str  # required
    temporal_matches: list[V6TemporalMatch]  # required
    document_id: str | None
    document_name: str | None


class _ConversationMessage(TypedDict):
    role: str | None
    content: str
    event_time: str | None


class V6LLMContext(TypedDict):
    reference_time: str | None
    anchor_source: str  # "request" | "conversation_event" | "server_now"
    conversation_history: list[_ConversationMessage]
    fact_ids: list[str]
    text: str  # Pre-synthesized narrative ready to inject into your LLM system prompt


class _WorkingMemoryFocus(TypedDict):
    entities: list[str]
    last_subjects: list[str]
    last_constraints: dict[str, Any]


class _WorkingMemoryPendingConfirmation(TypedDict):
    plan_id: str
    detected_at: str


class _WorkingMemoryLastPlan(TypedDict, total=False):
    plan_id: str  # required
    status: str  # required
    expires_at: str | None  # required


class WorkingMemory(TypedDict, total=False):
    focus: _WorkingMemoryFocus  # required
    pending_confirmation: _WorkingMemoryPendingConfirmation | None  # required
    last_plan: _WorkingMemoryLastPlan | None  # required
    turn_summary: str | None  # required


class PendingPlan(TypedDict, total=False):
    plan_id: str  # required
    conversation_id: str  # required
    status: str  # required
    steps: list[Any]  # required
    requires_confirmation: bool  # required
    created_at: str  # required
    expires_at: str | None  # required


class _RecallRouting(TypedDict):
    mode: str
    kinds: list[str]
    predicates: list[str]
    temporal_intent: Any | None


class RecallResponse(TypedDict, total=False):
    answer_facts: list[RecallFact]  # required — facts directly answering the query
    supporting_facts: list[RecallFact]  # required — corroborating facts
    background_context: list[RecallFact]  # required — broader context
    llm_context: V6LLMContext  # required — use llm_context["text"] as your system prompt
    working_memory: WorkingMemory | None  # required — current conversation state returned by the API
    pending_plan: PendingPlan | None  # required
    routing: _RecallRouting  # required
    debug: dict[str, Any]


ContextPack = RecallResponse

# Deprecated: retained for legacy compatibility only
class MemoryBlock(TypedDict):
    type: MemoryBlockType
    content: str
    source_ids: list[str]
    score: float

# ---------------------------------------------------------------------------
# Forget
# ---------------------------------------------------------------------------


class ForgetRequest(TypedDict, total=False):
    user_id: str  # required
    conversation_id: str  # required in V6.2
    project_id: str
    document_id: str  # optional — delete memory tagged with this document
    from_time: str
    to_time: str
    thread_id: str  # deprecated — use conversation_id instead


class DeletedCounts(TypedDict):
    events: int
    chunks: int
    episodes: int
    facts: int
    claims: int
    open_loops: int


class ForgetResponse(TypedDict):
    receipt_id: str
    deleted_counts: DeletedCounts


# ---------------------------------------------------------------------------
# Deletion Receipts
# ---------------------------------------------------------------------------


class DeletionScope(TypedDict, total=False):
    user_id: str  # required
    conversation_id: str | None
    project_id: str | None
    thread_id: str | None
    from_time: str | None
    to_time: str | None


class DeletionReceipt(TypedDict):
    receipt_id: str
    scope: DeletionScope
    requested_at: str
    completed_at: str | None
    deleted_counts: DeletedCounts


class ListDeletionReceiptsResponse(TypedDict):
    receipts: list[DeletionReceipt]
    total: int
    limit: int
    offset: int


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------


class UsageTotals(TypedDict):
    requests: int
    ingest_requests: int
    recall_requests: int
    forget_requests: int
    ingest_events: int
    tokens: int
    work_units: int
    errors: int
    request_bytes: int
    response_bytes: int


class UsageDailyEntry(TypedDict):
    date: str
    requests: int
    ingest_events: int
    tokens: int
    work_units: int
    errors: int


class UsageSummaryResponse(TypedDict):
    range: str
    start_date: str
    end_date: str
    totals: UsageTotals
    daily: list[UsageDailyEntry]


class EndpointBreakdownEntry(TypedDict):
    endpoint: str
    requests: int
    errors: int
    error_rate: float
    avg_latency_ms: float


class UsageBreakdownResponse(TypedDict):
    range: str
    start_date: str
    end_date: str
    endpoints: list[EndpointBreakdownEntry]


class UsageLimitMetric(TypedDict):
    used: int
    limit: int | None
    remaining: int | None
    percentage_used: float


class _UsageLimits(TypedDict):
    requests: UsageLimitMetric
    tokens: UsageLimitMetric
    work_units: UsageLimitMetric
    ingest_events: UsageLimitMetric


class UsageLimitsResponse(TypedDict):
    plan: str
    billing_cycle_day: int
    reset_date: str
    is_within_quota: bool
    limits: _UsageLimits


# ---------------------------------------------------------------------------
# V2 Types (assertion-based memory)
# ---------------------------------------------------------------------------

V2MemoryBlockType = Literal["assertion", "episode", "conflict"]


class V2EvidenceRef(TypedDict):
    event_id: str
    quote: str


class V2MemoryBlock(TypedDict, total=False):
    type: V2MemoryBlockType  # required
    content: str  # required
    source_ids: list[str]  # required
    evidence: list[V2EvidenceRef]
    score: float  # required


class V2RecallRequest(TypedDict, total=False):
    user_id: str  # required
    task: str  # required
    token_budget: int  # required
    thread_id: str
    min_confidence: float


class V2RecallResponse(TypedDict):
    system_context: str
    memory_blocks: list[V2MemoryBlock]
    citations: list[str]
    token_estimate: int


class V2ForgetRequest(TypedDict, total=False):
    user_id: str  # required
    thread_id: str
    from_time: str
    to_time: str


class V2DeletedCounts(TypedDict):
    events: int
    assertions: int
    episodes: int
    entities: int
    conflicts: int
    extraction_failures: int


class V2ForgetResponse(TypedDict, total=False):
    receipt_id: str  # required
    deleted_counts: V2DeletedCounts  # required
    warnings: list[str]


# ---------------------------------------------------------------------------
# V2.1 Types (Production-Grade Memory Extensions)
# ---------------------------------------------------------------------------

IntentMode = Literal["state", "delta", "tasks", "audit", "compose", "conversation"]
EpistemicType = Literal["fact", "aspiration", "belief", "hypothetical", "proposal"]
Cardinality = Literal["single", "set", "task_keyed", "proposal"]
ConflictStrategy = Literal["supersede", "merge", "conflict", "ignore"]
ProposalStatus = Literal["pending", "accepted", "rejected", "expired"]
ChangeType = Literal["create", "update", "delete", "correct", "negate"]
LinkType = Literal["supersedes", "derived_from", "conflicts_with", "resolves", "corrects", "negates"]


class RelationPolicy(TypedDict):
    relation: str
    cardinality: Cardinality
    conflict_strategy: ConflictStrategy
    requires_confirmation: bool
    supports_negation: bool
    temporal_scoped: bool


class Proposal(TypedDict):
    proposal_id: str
    tenant_id: str
    user_id: str
    thread_id: str | None
    relation: str
    subject_entity_id: str | None
    subject_display: str
    proposed_object: Any
    qualifiers: dict[str, Any]
    confidence: float
    status: ProposalStatus
    source_event_id: str
    accepted_event_id: str | None
    expires_at: str | None
    created_at: str
    resolved_at: str | None


class ChangeEvent(TypedDict):
    change_id: str
    tenant_id: str
    user_id: str
    thread_id: str | None
    relation: str
    subject_entity_id: str | None
    subject_display: str
    old_assertion_id: str | None
    new_assertion_id: str | None
    change_type: ChangeType
    old_value: Any
    new_value: Any
    trigger_event_id: str
    created_at: str


class AssertionLink(TypedDict):
    link_id: str
    from_assertion_id: str
    to_assertion_id: str
    link_type: LinkType
    created_at: str


class V2RecallRequestExtended(TypedDict, total=False):
    user_id: str  # required
    task: str  # required
    token_budget: int  # required
    thread_id: str
    min_confidence: float
    # V2.1 extensions
    mode: IntentMode
    since: str  # ISO date for delta mode
    relations: list[str]  # Filter by specific relations
    status: Literal["open", "completed", "all"]  # For tasks mode


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class _ApiErrorDetail(TypedDict, total=False):
    code: str  # required
    message: str  # required
    request_id: str  # required
    details: Any


class ApiErrorBody(TypedDict):
    error: _ApiErrorDetail


# ---------------------------------------------------------------------------
# V3 Types (Priority Memory with Retention Policy + Feedback Loop)
# ---------------------------------------------------------------------------

RetentionPolicy = Literal["standard", "legal_hold", "ephemeral"]

EntityResolutionMode = Literal["merged", "probabilistic", "raw"]


class V3IngestRequest(TypedDict, total=False):
    user_id: str  # required
    type: EventType  # required
    content: str  # required
    thread_id: str
    role: EventRole
    metadata: dict[str, Any]
    event_time: str
    idempotency_key: str
    retention_policy: RetentionPolicy


V3MemoryBlockType = Literal["fact", "task", "change", "episode", "conflict", "raw_message"]


class V3ScoreBreakdown(TypedDict):
    type_weight: float
    relevance: float
    recency: float
    confidence: float
    frequency: float
    verified_boost: float
    intent_match: float
    thread_boost: float
    final_score: float


class V3MemoryBlock(TypedDict, total=False):
    type: V3MemoryBlockType  # required
    content: str  # required
    source_ids: list[str]  # required
    evidence: list[V2EvidenceRef]
    score: float  # required
    score_breakdown: V3ScoreBreakdown


class V3RecallRequest(TypedDict, total=False):
    user_id: str  # required
    task: str  # required
    token_budget: int  # required
    thread_id: str
    min_confidence: float
    entity_resolution: EntityResolutionMode


class V3RecallResponse(TypedDict, total=False):
    recall_id: str  # required
    as_of: str  # required — ISO datetime
    system_context: str  # required
    memory_blocks: list[V3MemoryBlock]  # required
    citations: list[str]  # required
    token_estimate: int  # required
    ingestion_lag_seconds: float  # required
    stale_warning: str


class V3ForgetRequest(TypedDict, total=False):
    user_id: str  # required
    thread_id: str
    from_time: str
    to_time: str
    immediate: bool


class V3ForgetResponse(TypedDict, total=False):
    receipt_id: str  # required
    audit_id: str  # required
    phase: str  # required
    events_tombstoned: int  # required
    grace_expires_at: str


class V3FeedbackRequest(TypedDict):
    fact_ids_used: list[str]


class V3FeedbackResponse(TypedDict):
    recall_id: str
    facts_recorded: int


# ---------------------------------------------------------------------------
# V5 Types (Clean-slate memory with tiered storage + temporal graph)
# ---------------------------------------------------------------------------

V5MemoryOperation = Literal["ADD", "UPDATE", "DELETE", "MERGE", "NOOP"]

V5MemoryTier = Literal["hot", "warm", "cold"]

V5MemoryStatus = Literal["active", "superseded", "deleted"]


class V5IngestRequest(TypedDict, total=False):
    user_id: str  # required
    type: EventType  # required
    content: str  # required
    thread_id: str
    role: EventRole
    metadata: dict[str, Any]
    event_time: str | int | float  # ISO datetime string or Unix timestamp
    idempotency_key: str


class V5IngestResponse(TypedDict):
    event_id: str
    deduped: bool


class V5RecallRequest(TypedDict, total=False):
    user_id: str  # required
    query: str  # required
    thread_id: str
    token_budget: int
    include_history: bool
    include_cold: bool
    raw_facts: bool


class V5TemporalEdge(TypedDict):
    edge_id: str
    from_fact_id: str
    to_fact_id: str | None
    change_type: Literal["update", "delete", "merge"]
    valid_from: str
    valid_to: str | None


class V5EvidenceRef(TypedDict):
    event_id: str
    source_text: str


class V5MemoryBlock(TypedDict, total=False):
    fact_id: str  # required
    subject: str  # required
    relation: str  # required
    object: Any  # required
    object_category: str | None  # required
    memory_type: str | None  # required
    importance_score: float  # required
    tier: V5MemoryTier  # required
    content: str  # required
    evidence: list[V5EvidenceRef]
    temporal_history: list[V5TemporalEdge]


class V5RecallResponse(TypedDict):
    recall_id: str
    answer: str
    selected_ids: list[str]
    memory_blocks: list[V5MemoryBlock]
    token_estimate: int
    as_of: str


class V5FeedbackRequest(TypedDict, total=False):
    selected_ids: list[str]  # required
    user_rating: int  # 1–5


class V5FeedbackResponse(TypedDict):
    recall_id: str
    facts_recorded: int


# ---------------------------------------------------------------------------
# Document Upload
# ---------------------------------------------------------------------------


class DocumentUploadRequest(TypedDict, total=False):
    user_id: str  # required
    content: str  # required — plain text or markdown content of the document
    document_name: str  # required — human-readable name (used in citations)
    document_id: str  # optional — stable ID; re-uploading replaces the document
    project_id: str  # required — project this document belongs to
    collection_id: str  # optional — add to a collection on upload
    position: int  # optional — position within the collection (ordered collections)


class DocumentUploadSection(TypedDict):
    node_id: str
    title: str | None


class DocumentUploadResponse(TypedDict):
    document_id: str
    document_name: str
    project_id: str
    collection_id: str | None
    sections: list[DocumentUploadSection]
    spans_created: int
    status: Literal["processing"]  # distillations complete asynchronously


# ---------------------------------------------------------------------------
# Document listing
# ---------------------------------------------------------------------------


class DocumentStatusInfo(TypedDict, total=False):
    status: Literal["processing", "ready", "error"]  # required
    spans_created: int  # required
    error_message: str | None  # required


class DocumentListItem(TypedDict, total=False):
    document_id: str  # required
    document_name: str  # required
    project_id: str  # required
    user_id: str  # required
    byte_size: int | None  # required
    created_at: str  # required
    collection_ids: list[str]  # required
    document_status: DocumentStatusInfo | None  # required


class DocumentListResponse(TypedDict):
    documents: list[DocumentListItem]
    total: int
    limit: int
    offset: int


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------


class CollectionCreateRequest(TypedDict, total=False):
    user_id: str  # required
    project_id: str  # required
    name: str  # required
    ordered: bool  # optional — default False
    collection_id: str  # optional — stable ID; generated if omitted


class CollectionRow(TypedDict):
    collection_id: str
    tenant_id: str
    user_id: str
    project_id: str | None
    name: str
    ordered: bool
    created_at: str
    document_count: int


class CollectionCreateResponse(TypedDict):
    collection: CollectionRow


class CollectionListResponse(TypedDict):
    collections: list[CollectionRow]


class CollectionDocument(TypedDict):
    document_id: str
    document_name: str
    position: int | None
    added_at: str


class CollectionGetResponse(TypedDict):
    collection: CollectionRow
    documents: list[CollectionDocument]


class CollectionAddDocumentRequest(TypedDict, total=False):
    document_id: str  # required
    user_id: str  # required
    position: int  # optional
