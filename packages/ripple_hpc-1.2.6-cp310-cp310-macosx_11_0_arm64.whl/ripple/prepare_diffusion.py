from __future__ import annotations

import os
import warnings
import itertools
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence

import numpy as np


# =========================
#  Fit utilities (OLS + block-covariance MCMC)
# =========================

def project_psd(A: np.ndarray, *, eps: float = 0.0) -> np.ndarray:
    """Project a symmetric matrix to PSD by eigenvalue clipping."""
    A = np.asarray(A, dtype=np.float64)
    A = 0.5 * (A + A.T)
    w, V = np.linalg.eigh(A)
    w = np.maximum(w, float(eps))
    return (V * w) @ V.T


def _ols_fit_tensor(t: np.ndarray, M: np.ndarray, *, psd: bool = False) -> tuple[np.ndarray, np.ndarray, float]:
    """OLS fit for tensor curve: M(t) = C + 2 D t.

    Parameters
    ----------
    t : (K,) float
    M : (K,3,3) float
    psd
        If True, project fitted D onto PSD cone.

    Returns
    -------
    D : (3,3)
    C : (3,3)
    r2_fro : float
        R^2 computed on Frobenius norm of residuals.
    """
    t = np.asarray(t, dtype=np.float64)
    M = np.asarray(M, dtype=np.float64)
    if t.ndim != 1 or M.ndim != 3 or M.shape[1:] != (3, 3) or M.shape[0] != t.shape[0]:
        raise ValueError("t must be (K,) and M must be (K,3,3) with matching K")
    K = int(t.shape[0])
    if K < 2:
        raise ValueError("Need at least 2 points for OLS")

    X = np.stack([np.ones_like(t), 2.0 * t], axis=1)  # (K,2)
    XtX = X.T @ X
    if np.linalg.cond(XtX) > 1e16:
        raise ValueError("Ill-conditioned OLS design; choose a wider fit window")
    beta = np.linalg.solve(XtX, X.T @ M.reshape(K, 9))  # (2,9)
    C = beta[0].reshape(3, 3)
    D = beta[1].reshape(3, 3)
    C = 0.5 * (C + C.T)
    D = 0.5 * (D + D.T)
    if psd:
        D = project_psd(D)

    M_hat = (X @ beta).reshape(K, 3, 3)
    resid = M - M_hat
    ss_res = float(np.sum(resid * resid))
    M_mean = M.mean(axis=0, keepdims=True)
    ss_tot = float(np.sum((M - M_mean) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0.0 else float("nan")
    return D, C, r2


def mcmc_fit_diffusion_tensor(
    t: np.ndarray,
    mean_curve: np.ndarray,
    block_curves: np.ndarray,
    D_init: np.ndarray,
    C_init: np.ndarray,
    *,
    n_samples: int = 1500,
    n_walkers: int = 32,
    n_burn: int = 400,
    n_thin: int = 10,
    cond_max: float = 1e16,
    seed: int = 42,
    progress: bool = False,
    return_chain: bool = False,
) -> dict:
    """Kinisi-style Bayesian regression via time-origin block covariance.

    Model:
        vec(M(t_k)) = vec(C) + 2 t_k vec(D) + noise
    The noise covariance is estimated from blocks over time origins.

    This function returns posterior summaries for D and C.
    """
    rng = np.random.default_rng(int(seed))
    t = np.asarray(t, dtype=np.float64)
    mean_curve = np.asarray(mean_curve, dtype=np.float64)
    block_curves = np.asarray(block_curves, dtype=np.float64)
    D_init = np.asarray(D_init, dtype=np.float64)
    C_init = np.asarray(C_init, dtype=np.float64)

    if t.ndim != 1:
        raise ValueError("t must be 1D")
    K = int(t.shape[0])
    if mean_curve.shape != (K, 3, 3):
        raise ValueError("mean_curve must be (K,3,3)")
    if block_curves.ndim != 4 or block_curves.shape[0] != K or block_curves.shape[2:] != (3, 3):
        raise ValueError("block_curves must be (K, n_block, 3, 3)")

    n_block = int(block_curves.shape[1])
    if n_block < 4:
        raise ValueError("Need at least 4 blocks for stable covariance")
    if n_walkers < 8:
        raise ValueError("n_walkers too small")

    # ---- flatten symmetric tensors to 6D (xx,yy,zz,xy,xz,yz) to enforce symmetry ----
    def pack6(A: np.ndarray) -> np.ndarray:
        return np.array([A[0, 0], A[1, 1], A[2, 2], A[0, 1], A[0, 2], A[1, 2]], dtype=np.float64)

    def unpack6(v: np.ndarray) -> np.ndarray:
        v = np.asarray(v, dtype=np.float64)
        A = np.zeros((3, 3), dtype=np.float64)
        A[0, 0] = v[0]; A[1, 1] = v[1]; A[2, 2] = v[2]
        A[0, 1] = A[1, 0] = v[3]
        A[0, 2] = A[2, 0] = v[4]
        A[1, 2] = A[2, 1] = v[5]
        return A

    # ---- build block covariance of y_k = pack6(M(t_k)) ----
    def pack6_many(A: np.ndarray) -> np.ndarray:
        """Vectorized pack: (...,3,3) -> (...,6) with symmetry convention (xx,yy,zz,xy,xz,yz)."""
        A = np.asarray(A, dtype=np.float64)
        out = np.empty(A.shape[:-2] + (6,), dtype=np.float64)
        out[..., 0] = A[..., 0, 0]
        out[..., 1] = A[..., 1, 1]
        out[..., 2] = A[..., 2, 2]
        out[..., 3] = A[..., 0, 1]
        out[..., 4] = A[..., 0, 2]
        out[..., 5] = A[..., 1, 2]
        return out

    # block_curves: (K, n_block, 3,3) -> (n_block, K*6)
    Yb = pack6_many(block_curves.transpose(1, 0, 2, 3)).reshape(n_block, K * 6)
    mu = pack6_many(mean_curve).reshape(K * 6)

    # Sample covariance of block means; covariance of the mean_curve is ~ Cov(block_means)/n_block
    # (independent-block approximation; improves posterior calibration vs using Cov(block_means) directly)
    Cyy = np.cov(Yb, rowvar=False, ddof=1) / float(n_block)
    Cyy = 0.5 * (Cyy + Cyy.T)
    # mild diagonal jitter / reconditioning if ill-conditioned
    w = np.linalg.eigvalsh(Cyy)
    if w[0] <= 0.0:
        Cyy = Cyy + (abs(w[0]) + 1e-12) * np.eye(Cyy.shape[0])
    if np.linalg.cond(Cyy) > float(cond_max):
        # recondition by eigenvalue floor
        w, V = np.linalg.eigh(Cyy)
        floor = w.max() / float(cond_max)
        w = np.maximum(w, floor)
        Cyy = (V * w) @ V.T

    # Cholesky and its inverse (one-time O(n^3)); loglike uses BLAS matvecs (O(n^2)).
    L = np.linalg.cholesky(Cyy)
    logdet = 2.0 * np.sum(np.log(np.diag(L)))
    Linv = np.linalg.solve(L, np.eye(L.shape[0], dtype=np.float64))
    t2 = 2.0 * t


    # ---- forward model mu(theta) in packed space ----
    # theta = [D6 (6), C6 (6)]
    def model(theta: np.ndarray) -> np.ndarray:
        D6 = theta[:6]
        C6 = theta[6:]
        out6 = C6[None, :] + t2[:, None] * D6[None, :]
        return out6.reshape(K * 6)


    def loglike(theta: np.ndarray) -> float:
        r = mu - model(theta)
        z = Linv @ r
        # -0.5*(||L^{-1} r||^2 + logdet); additive constants dropped.
        return -0.5 * (float(z @ z) + float(logdet))


    # weak priors: D PSD constraint is enforced by rejection at proposal time
    def is_valid(theta: np.ndarray) -> bool:
        D = unpack6(theta[:6])
        # PSD check (allow small negative due to noise)
        w = np.linalg.eigvalsh(D)
        return bool(w.min() > -1e-12)

    theta0 = np.concatenate([pack6(D_init), pack6(C_init)], axis=0)
    if theta0.shape != (12,):
        raise ValueError("bad init")

    # Initial walker cloud
    scale = np.array([1e-3] * 6 + [1e-3] * 6, dtype=np.float64)
    walkers = theta0[None, :] + rng.normal(size=(int(n_walkers), 12)) * scale[None, :]
    for i in range(walkers.shape[0]):
        if not is_valid(walkers[i]):
            walkers[i, :6] = pack6(project_psd(unpack6(walkers[i, :6]), eps=0.0))

    ll = np.array([loglike(w) for w in walkers], dtype=np.float64)

    # Simple random-walk Metropolis for each walker (independent) — good enough given block covariance is the main ingredient.
    n_total = int(n_burn + n_samples * n_thin)
    chain_keep = []
    prop_scale = np.array([5e-4] * 6 + [5e-4] * 6, dtype=np.float64)

    for step in range(n_total):
        for i in range(int(n_walkers)):
            prop = walkers[i] + rng.normal(size=(12,)) * prop_scale
            if not is_valid(prop):
                continue
            ll_prop = loglike(prop)
            if np.log(rng.random()) < (ll_prop - ll[i]):
                walkers[i] = prop
                ll[i] = ll_prop

        if step >= int(n_burn) and ((step - int(n_burn)) % int(n_thin) == 0):
            chain_keep.append(walkers.copy())
        if progress and (step % max(1, n_total // 10) == 0):
            pass

    chain = np.stack(chain_keep, axis=0)  # (n_draw, n_walkers, 12)
    flat = chain.reshape(-1, 12)

    D_s = np.stack([unpack6(th[:6]) for th in flat], axis=0)
    C_s = np.stack([unpack6(th[6:]) for th in flat], axis=0)

    def summary(A_s: np.ndarray):
        mean = A_s.mean(axis=0)
        std = A_s.std(axis=0, ddof=1)
        lo = np.quantile(A_s, 0.16, axis=0)
        hi = np.quantile(A_s, 0.84, axis=0)
        ci = np.stack([lo, hi], axis=0)
        return mean, std, ci

    D_mean, D_std, D_ci = summary(D_s)
    C_mean, C_std, C_ci = summary(C_s)

    out = {
        "D_mean": D_mean,
        "D_std": D_std,
        "D_ci": D_ci,
        "intercept_mean": C_mean,
        "intercept_std": C_std,
        "intercept_ci": C_ci,
        "n_draw": int(flat.shape[0]),
        "n_block": int(n_block),
    }
    if return_chain:
        out["theta_chain"] = chain
    return out


# =========================
#  User-facing result objects
# =========================


@dataclass(frozen=True, slots=True)
class DiffusionTensorFit:
    """Fit result for diffusion tensor estimation from MSD/cMSD tensor curve."""

    method: str
    D_tensor: np.ndarray
    intercept_tensor: np.ndarray
    lag_min: int
    lag_max: int
    time_min_ps: float
    time_max_ps: float
    r2_fro: float
    D_std: np.ndarray | None = None
    D_ci: np.ndarray | None = None
    intercept_std: np.ndarray | None = None
    intercept_ci: np.ndarray | None = None
    meta: dict | None = None


@dataclass(frozen=True, slots=True)
class MSDResult:
    msd_tensor: np.ndarray  # (T,3,3)
    lags: np.ndarray        # (T,)
    times_ps: np.ndarray    # (T,)
    timestep_ps: float
    n_frames: int
    n_sel: int
    pos_path: str
    sum_pos_path: str

    def diffusion_tensor(
        self,
        *,
        method: str = "ols",
        fit_lag_frac: tuple[float, float] = (0.20, 0.80),
        fit_n_lags: int = 120,
        psd: bool = False,
        # MCMC controls
        n_blocks: int = 50,
        min_block_len: int = 10,
        n_samples: int = 1500,
        n_walkers: int = 32,
        n_burn: int = 400,
        n_thin: int = 10,
        seed: int = 42,
        progress: bool = False,
        cond_max: float = 1e16,
        return_chain: bool = False,
    ) -> DiffusionTensorFit:
        method = str(method).lower().strip()
        if method not in ("ols", "mcmc"):
            raise ValueError("method must be 'ols' or 'mcmc'")

        max_lag = int(self.n_frames - 1)
        f0, f1 = float(fit_lag_frac[0]), float(fit_lag_frac[1])
        lag_min = max(1, int(f0 * max_lag))
        lag_max = min(max_lag, max(lag_min + 10, int(f1 * max_lag)))
        fit_lags = np.unique(np.linspace(lag_min, lag_max, int(fit_n_lags)).astype(np.int64))
        fit_lags = fit_lags[fit_lags > 0]
        if fit_lags.size < (2 if method == "ols" else 20):
            raise ValueError("Too few fit lags; adjust fit window or increase trajectory length")

        t = self.times_ps[fit_lags]
        M = self.msd_tensor[fit_lags]

        if method == "ols":
            D, C, r2 = _ols_fit_tensor(t, M, psd=psd)
            return DiffusionTensorFit(
                method="ols",
                D_tensor=D,
                intercept_tensor=C,
                lag_min=int(fit_lags.min()),
                lag_max=int(fit_lags.max()),
                time_min_ps=float(t.min()),
                time_max_ps=float(t.max()),
                r2_fro=float(r2),
                meta=None,
            )

        # ---- MCMC: block covariance over time origins (t0-blocks) ----
        tau_max = int(fit_lags.max())
        origin_count = int(self.n_frames - tau_max)
        if origin_count <= 0:
            raise ValueError("Trajectory too short for the requested tau_max")
        n_blocks_eff = int(max(4, min(int(n_blocks), origin_count // max(1, int(min_block_len)))))
        block_len = int(origin_count // n_blocks_eff)
        if block_len < int(min_block_len):
            raise ValueError("Trajectory too short for stable block covariance")
        usable = int(block_len * n_blocks_eff)
        edges = np.arange(0, usable + 1, block_len, dtype=np.int32)
        fit_lags_i32 = np.ascontiguousarray(fit_lags, dtype=np.int32)
        edges_i32 = np.ascontiguousarray(edges, dtype=np.int32)

        from ripple.kernel.block_mcmc_ext import msd_block_tensor as _msd_blk
        pos = np.lib.format.open_memmap(self.pos_path, mode="r")
        try:
            blk = _msd_blk(pos, fit_lags_i32, edges_i32)
        finally:
            del pos

        mean_tensor = blk.mean(axis=1)
        D0, C0, _ = _ols_fit_tensor(t, mean_tensor, psd=False)

        out = mcmc_fit_diffusion_tensor(
            t,
            mean_tensor,
            blk,
            D0,
            C0,
            n_samples=n_samples,
            n_walkers=n_walkers,
            n_burn=n_burn,
            n_thin=n_thin,
            cond_max=cond_max,
            seed=seed,
            progress=progress,
            return_chain=return_chain,
        )

        return DiffusionTensorFit(
            method="mcmc",
            D_tensor=out["D_mean"],
            intercept_tensor=out["intercept_mean"],
            D_std=out["D_std"],
            D_ci=out["D_ci"],
            intercept_std=out["intercept_std"],
            intercept_ci=out["intercept_ci"],
            lag_min=int(fit_lags.min()),
            lag_max=int(fit_lags.max()),
            time_min_ps=float(t.min()),
            time_max_ps=float(t.max()),
            r2_fro=float("nan"),
            meta={"n_block": out["n_block"], "n_draw": out["n_draw"]},
        )


@dataclass(frozen=True, slots=True)
class cMSDResult:
    cmsd_tensor: np.ndarray
    lags: np.ndarray
    times_ps: np.ndarray
    timestep_ps: float
    n_frames: int
    n_sel: int
    pos_path: str
    sum_pos_path: str

    def diffusion_tensor(self, **kwargs) -> DiffusionTensorFit:
        # identical interface; only block-kernel differs (sum_pos fast-path)
        method = str(kwargs.get("method", "ols")).lower().strip()
        if method == "ols":
            tmp = MSDResult(
                msd_tensor=self.cmsd_tensor,
                lags=self.lags,
                times_ps=self.times_ps,
                timestep_ps=self.timestep_ps,
                n_frames=self.n_frames,
                n_sel=self.n_sel,
                pos_path=self.pos_path,
                sum_pos_path=self.sum_pos_path,
            )
            return tmp.diffusion_tensor(**kwargs)

        # ---- MCMC: use sum_pos block kernel if available ----
        fit_lag_frac = kwargs.get("fit_lag_frac", (0.20, 0.80))
        fit_n_lags = int(kwargs.get("fit_n_lags", 120))
        n_blocks = int(kwargs.get("n_blocks", 50))
        min_block_len = int(kwargs.get("min_block_len", 10))

        n_samples = int(kwargs.get("n_samples", 1500))
        n_walkers = int(kwargs.get("n_walkers", 32))
        n_burn = int(kwargs.get("n_burn", 400))
        n_thin = int(kwargs.get("n_thin", 10))
        seed = int(kwargs.get("seed", 42))
        progress = bool(kwargs.get("progress", False))
        cond_max = float(kwargs.get("cond_max", 1e16))
        return_chain = bool(kwargs.get("return_chain", False))

        max_lag = int(self.n_frames - 1)
        f0, f1 = float(fit_lag_frac[0]), float(fit_lag_frac[1])
        lag_min = max(1, int(f0 * max_lag))
        lag_max = min(max_lag, max(lag_min + 10, int(f1 * max_lag)))
        fit_lags = np.unique(np.linspace(lag_min, lag_max, int(fit_n_lags)).astype(np.int64))
        fit_lags = fit_lags[fit_lags > 0]
        if fit_lags.size < 20:
            raise ValueError("Too few fit lags for MCMC")

        t = self.times_ps[fit_lags]

        tau_max = int(fit_lags.max())
        origin_count = int(self.n_frames - tau_max)
        if origin_count <= 0:
            raise ValueError("Trajectory too short for the requested tau_max")
        n_blocks_eff = int(max(4, min(int(n_blocks), origin_count // max(1, int(min_block_len)))))
        block_len = int(origin_count // n_blocks_eff)
        if block_len < int(min_block_len):
            raise ValueError("Trajectory too short for stable block covariance")
        usable = int(block_len * n_blocks_eff)
        edges = np.arange(0, usable + 1, block_len, dtype=np.int32)
        fit_lags_i32 = np.ascontiguousarray(fit_lags, dtype=np.int32)
        edges_i32 = np.ascontiguousarray(edges, dtype=np.int32)

        from ripple.kernel.block_mcmc_ext import cmsd_block_tensor_sumpos as _cmsd_blk_sum
        sum_pos = np.lib.format.open_memmap(self.sum_pos_path, mode="r")
        try:
            blk = _cmsd_blk_sum(sum_pos, int(self.n_sel), fit_lags_i32, edges_i32)
        finally:
            del sum_pos

        mean_tensor = blk.mean(axis=1)
        D0, C0, _ = _ols_fit_tensor(t, mean_tensor, psd=False)
        out = mcmc_fit_diffusion_tensor(
            t,
            mean_tensor,
            blk,
            D0,
            C0,
            n_samples=n_samples,
            n_walkers=n_walkers,
            n_burn=n_burn,
            n_thin=n_thin,
            cond_max=cond_max,
            seed=seed,
            progress=progress,
            return_chain=return_chain,
        )
        return DiffusionTensorFit(
            method="mcmc",
            D_tensor=out["D_mean"],
            intercept_tensor=out["intercept_mean"],
            D_std=out["D_std"],
            D_ci=out["D_ci"],
            intercept_std=out["intercept_std"],
            intercept_ci=out["intercept_ci"],
            lag_min=int(fit_lags.min()),
            lag_max=int(fit_lags.max()),
            time_min_ps=float(t.min()),
            time_max_ps=float(t.max()),
            r2_fro=float("nan"),
            meta={"n_block": out["n_block"], "n_draw": out["n_draw"]},
        )


# =========================
#  Internal execution helpers
# =========================


def _available_cpu_count() -> int:
    if hasattr(os, "sched_getaffinity"):
        try:
            return len(os.sched_getaffinity(0))
        except Exception:
            pass
    return int(os.cpu_count() or 1)


def _clamp_diffusion_workers(n_workers: int, n_frames: int) -> int:
    n_workers = int(n_workers)
    if n_workers < 1:
        raise ValueError("n_workers must be >= 1")

    avail = _available_cpu_count()
    if avail < n_workers:
        warnings.warn(
            f"Only {avail} CPUs are available, but n_workers={n_workers}. Clamping -> {avail}.",
            RuntimeWarning,
        )
        n_workers = avail
    if n_frames < n_workers:
        warnings.warn(
            f"Only {n_frames} frames cannot be assigned to n_workers={n_workers}. Clamping -> {n_frames}.",
            RuntimeWarning,
        )
        n_workers = n_frames
    return int(n_workers)


# =========================
#  Prepared trajectory object
# =========================


@dataclass(frozen=True, slots=True)
class PreparedDiffusionTrajectory:
    """Prepared diffusion trajectory returned by prepare_diffusion(...)."""

    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    target_atoms: str
    n_frames: int
    n_sel: int
    timestep_ps: float
    pos_dtype: str
    periodic_all: bool
    cell_static: bool
    pos_path: str
    sum_pos_path: str
    cell_path: str
    pbc_path: str
    meta_path: str

    def msd_cal(self, *, n_workers: int = 1) -> MSDResult:
        """Compute MSD tensor curve for all lags 0..T-1 via the threaded C++ kernel."""
        n_workers = _clamp_diffusion_workers(int(n_workers), int(self.n_frames))

        from ripple.kernel.msd_ext import msd_tensor_full as _msd_tensor_full

        pos = np.lib.format.open_memmap(self.pos_path, mode="r")
        try:
            out = _msd_tensor_full(pos, int(n_workers))
        finally:
            del pos

        T = int(self.n_frames)
        lags = np.arange(T, dtype=np.int64)
        times_ps = lags.astype(np.float64) * float(self.timestep_ps)
        return MSDResult(
            msd_tensor=out,
            lags=lags,
            times_ps=times_ps,
            timestep_ps=float(self.timestep_ps),
            n_frames=int(self.n_frames),
            n_sel=int(self.n_sel),
            pos_path=str(self.pos_path),
            sum_pos_path=str(self.sum_pos_path),
        )

    def cmsd_cal(self, *, n_workers: int = 1) -> cMSDResult:
        """Compute cMSD tensor curve for all lags 0..T-1 via the threaded C++ kernel."""
        n_workers = _clamp_diffusion_workers(int(n_workers), int(self.n_frames))

        from ripple.kernel.cmsd_ext import cmsd_tensor_sumpos as _cmsd_tensor_sumpos

        sum_pos = np.lib.format.open_memmap(self.sum_pos_path, mode="r")
        try:
            out = _cmsd_tensor_sumpos(sum_pos, int(self.n_sel), int(n_workers))
        finally:
            del sum_pos

        T = int(self.n_frames)
        lags = np.arange(T, dtype=np.int64)
        times_ps = lags.astype(np.float64) * float(self.timestep_ps)
        return cMSDResult(
            cmsd_tensor=out,
            lags=lags,
            times_ps=times_ps,
            timestep_ps=float(self.timestep_ps),
            n_frames=int(self.n_frames),
            n_sel=int(self.n_sel),
            pos_path=str(self.pos_path),
            sum_pos_path=str(self.sum_pos_path),
        )

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


# =========================
#  prepare_diffusion
# =========================


def prepare_diffusion(
    trajectory: Sequence | Iterable | Callable[[], Iterable],
    target_atoms: str,
    timestep_ps: float,
    n_frames: int | None = None,
    save_dir: str = ".",
    trajectory_tag: str = "notag",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
) -> PreparedDiffusionTrajectory:
    """Prepare memmaps for diffusion (MSD / cMSD) analysis.

    Stored arrays:
      - pos:      (T, N_sel, 3) Cartesian **unwrapped** positions
      - sum_pos:  (T, 3) float64, sum over selected atoms (fast cMSD)
      - cell:     (T, 3, 3) float64
      - pbc:      (T, 3) bool

    Notes
    -----
    - This pipeline always computes the full-lag curve: lag_max = T-1.
      Users are expected to crop/downsample the trajectory before calling prepare.
    - Unwrapping uses step-wise minimum-image correction.
      For triclinic cells, a strict 27-shift search is used.
    - periodic_all and cell_static are recorded as metadata hints (no hard constraints).
    - If you pass a single-pass iterator, you MUST pass n_frames.
    """

    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be bool")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings")
    if not isinstance(target_atoms, str):
        raise TypeError("target_atoms must be a string")
    timestep_ps = float(timestep_ps)
    if timestep_ps <= 0.0:
        raise ValueError("timestep_ps must be > 0")

    trajectory_tag = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in trajectory_tag)[:120]
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn("reuse_memmap=True but trajectory_tag='notag' may load wrong cache.", RuntimeWarning)

    cache_dir = Path(save_dir) / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    pos_dtype = np.dtype(pos_dtype).name
    pos_dt = np.dtype(pos_dtype)
    if pos_dt not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")

    # -------------------- resolve n_frames / iterator factory --------------------
    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = int(len(trajectory))
        if n_frames is not None and int(n_frames) != T:
            raise ValueError(f"n_frames={int(n_frames)} does not match len(trajectory)={T}.")

        reiterable = True

        def make_iter():
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter():
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_diffusion(): trajectory is a factory but n_frames is None. "
                "This will iterate the trajectory TWICE (count + write). "
                "Pass n_frames next time to avoid the extra pass.",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. "
                "Pass n_frames=..., or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter():
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    # -------------------- read first frame (define selection) --------------------
    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration:
        raise ValueError("Empty trajectory.")

    species = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_sel = (species == target_atoms)
    n_sel = int(is_sel.sum())
    if n_sel < 1:
        raise ValueError(f"No atoms found for target_atoms={target_atoms!r}")
    idx_sel = np.flatnonzero(is_sel).astype(np.int64)

    # -------------------- file paths --------------------
    feature = f"{material_name}_{target_atoms}_unwrap_{pos_dtype}"
    meta_path = cache_dir / f"meta_{target_atoms}_{feature}.npz"
    cell_path = cache_dir / f"cell_{target_atoms}_{feature}.cell.npy"
    pbc_path = cache_dir / f"pbc_{target_atoms}_{feature}.pbc.npy"
    pos_path = cache_dir / f"positions_{target_atoms}_{feature}.pos.npy"
    sum_pos_path = cache_dir / f"sumpos_{target_atoms}_{feature}.sum.npy"

    # -------------------- reuse_memmap check --------------------
    if reuse_memmap:
        def _ok(path: Path, shape, dtype) -> bool:
            if not path.exists():
                return False
            try:
                mm = np.lib.format.open_memmap(path, mode="r")
                ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
                del mm
                return ok
            except Exception:
                return False

        ok_pos = _ok(pos_path, (T, n_sel, 3), pos_dt)
        ok_sum = _ok(sum_pos_path, (T, 3), np.float64)
        ok_cell = _ok(cell_path, (T, 3, 3), np.float64)
        ok_pbc = _ok(pbc_path, (T, 3), np.bool_)
        ok_all = meta_path.exists() and ok_pos and ok_sum and ok_cell and ok_pbc
        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                if "timestep_ps" in meta:
                    if not np.isclose(float(meta["timestep_ps"]), float(timestep_ps), rtol=0.0, atol=0.0):
                        raise ValueError(
                            f"Cached timestep_ps={float(meta['timestep_ps'])} differs from requested timestep_ps={float(timestep_ps)}. "
                            "Use a different trajectory_tag or set reuse_memmap=False."
                        )
                periodic_all = bool(meta["periodic_all"])
                cell_static = bool(meta["cell_static"])
            return PreparedDiffusionTrajectory(
                cache_dir=str(cache_dir),
                trajectory_tag=str(trajectory_tag),
                save_dir=str(save_dir),
                feature=str(feature),
                material_name=str(material_name),
                target_atoms=str(target_atoms),
                n_frames=int(T),
                n_sel=int(n_sel),
                timestep_ps=float(timestep_ps),
                pos_dtype=str(pos_dtype),
                periodic_all=periodic_all,
                cell_static=cell_static,
                pos_path=str(pos_path),
                sum_pos_path=str(sum_pos_path),
                cell_path=str(cell_path),
                pbc_path=str(pbc_path),
                meta_path=str(meta_path),
            )

    # -------------------- build memmaps --------------------
    created_paths = [meta_path]
    pos_mm = sum_mm = cell_mm = pbc_mm = None
    try:
        pos_mm = np.lib.format.open_memmap(pos_path, mode="w+", dtype=pos_dt, shape=(T, n_sel, 3))
        created_paths.append(pos_path)
        sum_mm = np.lib.format.open_memmap(sum_pos_path, mode="w+", dtype=np.float64, shape=(T, 3))
        created_paths.append(sum_pos_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        pbc_mm = np.lib.format.open_memmap(pbc_path, mode="w+", dtype=np.bool_, shape=(T, 3))
        created_paths.append(pbc_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)

        periodic_all = True
        cell_static = True
        last_cell = None

        # Unwrapping state
        s_prev = None  # scaled wrapped (n_sel,3)
        r_prev = None  # cart unwrapped (n_sel,3)
        mic_pbc_pattern = None  # (bool,bool,bool)
        mic_nvec = None  # (K,3) int64 shifts for strict MIC in triclinic cells


        t_last = -1
        for t, at in enumerate(frames):
            if t >= T:
                raise RuntimeError(
                    f"Trajectory has more than T={T} frames (n_frames mismatch). "
                    "Pass the correct n_frames or omit it."
                )
            t_last = t

            cell = np.asarray(at.get_cell().array, dtype=np.float64)
            if cell.shape != (3, 3):
                raise ValueError("ASE cell must be (3,3)")
            pbc = np.asarray(at.get_pbc(), dtype=np.bool_)
            if pbc.shape != (3,):
                raise ValueError("ASE pbc must be (3,)")
            # strict MIC shift set depends only on the pbc pattern (not on cell)
            pbc_pat = (bool(pbc[0]), bool(pbc[1]), bool(pbc[2]))
            if mic_pbc_pattern != pbc_pat:
                mic_pbc_pattern = pbc_pat
                shifts = (-1, 0, 1)
                axes = [shifts if pbc_pat[i] else (0,) for i in range(3)]
                mic_nvec = np.array(list(itertools.product(*axes)), dtype=np.int64)


            cell_mm[t] = cell
            pbc_mm[t] = pbc
            periodic_all = periodic_all and bool(pbc.all())
            if last_cell is None:
                last_cell = cell.copy()
            else:
                if not np.allclose(cell, last_cell, rtol=0.0, atol=1e-4):
                    cell_static = False

            # scaled, wrapped positions
            s = np.asarray(at.get_scaled_positions(wrap=True), dtype=np.float64)
            s = s[idx_sel]

            if t == 0:
                r = s @ cell
            else:
                ds = s - s_prev
                if pbc.any():
                    # orthorhombic fast-path
                    off = cell - np.diag(np.diag(cell))
                    ortho = bool(np.all(np.abs(off) < 1e-12))
                    if ortho:
                        ds2 = ds.copy()
                        ds2[:, pbc] -= np.rint(ds2[:, pbc])
                        dr = ds2 @ cell
                    else:
                        # strict MIC by enumerating integer shifts in {-1,0,1}^d (d=periodic dims)
                        # (triclinic-safe: searches neighbouring lattice translations for true minimum image)
                        shift_cart = mic_nvec @ cell  # (K,3)
                        dr0 = ds @ cell  # (n_sel,3), without MIC
                        dr = dr0.copy()
                        d2_best = np.einsum("ij,ij->i", dr0, dr0)
                        for sh in shift_cart:
                            if sh[0] == 0.0 and sh[1] == 0.0 and sh[2] == 0.0:
                                continue
                            cand = dr0 - sh
                            d2 = np.einsum("ij,ij->i", cand, cand)
                            m = d2 < d2_best
                            if np.any(m):
                                dr[m] = cand[m]
                                d2_best[m] = d2[m]
                else:
                    dr = ds @ cell
                r = r_prev + dr

            pos_mm[t] = r.astype(pos_dt, copy=False)
            sum_mm[t] = r.sum(axis=0, dtype=np.float64)

            s_prev = s
            r_prev = r

        # ---- n_frames insurance ----
        if (t_last + 1) != int(T):
            raise RuntimeError(
                f"Trajectory ended early: wrote {t_last + 1} frames but expected T={T}. "
                "Pass the correct n_frames or provide a reiterable trajectory."
            )

        np.savez(
            meta_path,
            periodic_all=bool(periodic_all),
            cell_static=bool(cell_static),
            timestep_ps=float(timestep_ps),
            n_frames=int(T),
            n_sel=int(n_sel),
            pos_dtype=str(pos_dtype),
            target_atoms=str(target_atoms),
            material_name=str(material_name),
        )

    except Exception:
        try:
            del pos_mm, sum_mm, cell_mm, pbc_mm
        except Exception:
            pass
        for p in created_paths:
            try:
                Path(p).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del pos_mm, sum_mm, cell_mm, pbc_mm
        except Exception:
            pass

    return PreparedDiffusionTrajectory(
        cache_dir=str(cache_dir),
        trajectory_tag=str(trajectory_tag),
        save_dir=str(save_dir),
        feature=str(feature),
        material_name=str(material_name),
        target_atoms=str(target_atoms),
        n_frames=int(T),
        n_sel=int(n_sel),
        timestep_ps=float(timestep_ps),
        pos_dtype=str(pos_dtype),
        periodic_all=bool(periodic_all),
        cell_static=bool(cell_static),
        pos_path=str(pos_path),
        sum_pos_path=str(sum_pos_path),
        cell_path=str(cell_path),
        pbc_path=str(pbc_path),
        meta_path=str(meta_path),
    )
