from ._version import version as __version__
"""
                 +----------------+
                 |  MD trajectory |
                 +--------+-------+
                          |
                       ASE reader
                          |
                  prepare/cache
                          |
            threaded C++ kernels (RDF/SSF/VHF/...)
                          |
                       reduction
                          |
                      final result
"""
