#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

namespace py = pybind11;
using ssize = py::ssize_t;

#if defined(_MSC_VER)
  #define RIPPLE_RESTRICT __restrict
#else
  #define RIPPLE_RESTRICT __restrict__
#endif

template <typename T>
static inline bool dtype_is(const py::buffer_info& b) {
    // Strict dtype check (not itemsize) so float/int buffers never alias silently.
    return b.format == py::format_descriptor<T>::format();
}

static inline void require_c_contig_TN3(const py::buffer_info& b, ssize itemsize) {
    if (b.ndim != 3) throw std::invalid_argument("pos must be a 3D array (T,N,3)");
    const ssize T = b.shape[0];
    const ssize N = b.shape[1];
    const ssize C = b.shape[2];
    if (C != 3) throw std::invalid_argument("pos.shape[2] must be 3");
    if (T <= 0 || N <= 0) throw std::invalid_argument("pos has empty dimensions");
    const ssize s0 = b.strides[0];
    const ssize s1 = b.strides[1];
    const ssize s2 = b.strides[2];
    if (!(s2 == itemsize && s1 == 3 * itemsize && s0 == N * 3 * itemsize)) {
        throw std::invalid_argument("pos must be C-contiguous with shape (T,N,3)");
    }
}

static inline void symmetrize_3x3_upper_inplace(double* RIPPLE_RESTRICT m) {
    m[3] = m[1];
    m[6] = m[2];
    m[7] = m[5];
}

static inline std::size_t clamp_thread_count(std::int64_t requested, std::int64_t n_task) {
    if (requested < 1) throw std::invalid_argument("n_threads must be >= 1");
    const std::int64_t usable = std::max<std::int64_t>(1, std::min<std::int64_t>(requested, n_task));
    return (std::size_t)usable;
}

static std::vector<std::pair<std::int64_t, std::int64_t>>
balanced_lag_slices(std::int64_t T, std::size_t n_slice) {
    n_slice = std::max<std::size_t>(1, std::min<std::size_t>(n_slice, (std::size_t)std::max<std::int64_t>(1, T)));
    if (n_slice <= 1 || T <= 1) {
        return { { 0, T } };
    }

    const long double total = (long double)T * (long double)(T - 1) * 0.5L;
    const long double two_t_minus_one = 2.0L * (long double)T - 1.0L;

    std::vector<std::int64_t> edges;
    edges.reserve(n_slice + 1);
    edges.push_back(0);

    std::int64_t prev = 0;
    for (std::size_t k = 1; k < n_slice; ++k) {
        const long double target = total * (long double)k / (long double)n_slice;
        long double disc = two_t_minus_one * two_t_minus_one - 8.0L * target;
        if (disc < 0.0L) disc = 0.0L;

        // Solve cumulative work for exclusive lag edge e:
        // sum_{lag=1}^{e-1} (T - lag) = target.
        std::int64_t edge = (std::int64_t)std::floor((((two_t_minus_one - std::sqrt(disc)) * 0.5L) + 1.0L));
        edge = std::max<std::int64_t>(edge, prev + 1);
        edge = std::min<std::int64_t>(edge, T - (std::int64_t)(n_slice - k));
        prev = edge;
        edges.push_back(edge);
    }
    edges.push_back(T);

    std::vector<std::pair<std::int64_t, std::int64_t>> out;
    out.reserve(n_slice);
    for (std::size_t i = 0; i + 1 < edges.size(); ++i) {
        if (edges[i] < edges[i + 1]) out.emplace_back(edges[i], edges[i + 1]);
    }
    return out;
}

template <typename T>
static py::array_t<double> msd_tensor_impl(py::array pos_, std::int64_t start_lag, std::int64_t stop_lag) {
    auto b = pos_.request();
    require_c_contig_TN3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const ssize N = b.shape[1];

    const std::int64_t Tn_i = (std::int64_t)Tn;
    const size_t stride = (size_t)N * 3u;
    const size_t Nu = (size_t)N;

    if (start_lag < 0 || stop_lag < 0 || start_lag > stop_lag) {
        throw std::invalid_argument("invalid lag range");
    }
    if (stop_lag > Tn_i) stop_lag = Tn_i;
    if (start_lag >= stop_lag) {
        return py::array_t<double>({ (ssize)0, (ssize)3, (ssize)3 });
    }

    const std::int64_t n_lag = stop_lag - start_lag;
    py::array_t<double> out({ (ssize)n_lag, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)n_lag * 9u * sizeof(double));

    const T* RIPPLE_RESTRICT pos = static_cast<const T*>(b.ptr);
    double* RIPPLE_RESTRICT o = static_cast<double*>(outbuf.ptr);

    py::gil_scoped_release nogil;

    for (std::int64_t lag = start_lag; lag < stop_lag; ++lag) {
        if (lag == 0) continue;

        const std::int64_t n_origin = Tn_i - lag;
        if (n_origin <= 0) continue;

        double sxx = 0.0, syy = 0.0, szz = 0.0;
        double sxy = 0.0, sxz = 0.0, syz = 0.0;
        const size_t lag_stride = (size_t)lag * stride;

        for (std::int64_t t0 = 0; t0 < n_origin; ++t0) {
            const T* RIPPLE_RESTRICT a0 = pos + (size_t)t0 * stride;
            const T* RIPPLE_RESTRICT a1 = a0 + lag_stride;

            for (size_t i = 0; i < Nu; ++i) {
                const double dx = (double)a1[0] - (double)a0[0];
                const double dy = (double)a1[1] - (double)a0[1];
                const double dz = (double)a1[2] - (double)a0[2];
                sxx += dx * dx;
                syy += dy * dy;
                szz += dz * dz;
                sxy += dx * dy;
                sxz += dx * dz;
                syz += dy * dz;
                a0 += 3;
                a1 += 3;
            }
        }

        const double inv = 1.0 / ((double)N * (double)n_origin);
        const std::int64_t idx = lag - start_lag;
        double* RIPPLE_RESTRICT m = o + (size_t)idx * 9u;
        m[0] = sxx * inv;
        m[4] = syy * inv;
        m[8] = szz * inv;
        m[1] = sxy * inv;
        m[2] = sxz * inv;
        m[5] = syz * inv;
        symmetrize_3x3_upper_inplace(m);
    }

    return out;
}

template <typename T>
static py::array_t<double> msd_tensor_full_impl(py::array pos_, std::int64_t n_threads) {
    auto b = pos_.request();
    require_c_contig_TN3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const ssize N = b.shape[1];

    const std::int64_t Tn_i = (std::int64_t)Tn;
    if (Tn_i <= 1) {
        py::array_t<double> out({ Tn, (ssize)3, (ssize)3 });
        auto outbuf = out.request();
        std::memset(outbuf.ptr, 0, (size_t)Tn_i * 9u * sizeof(double));
        return out;
    }

    const std::size_t n_use = clamp_thread_count(n_threads, Tn_i - 1);
    if (n_use == 1) {
        return msd_tensor_impl<T>(pos_, 0, Tn_i);
    }

    const size_t stride = (size_t)N * 3u;
    const size_t Nu = (size_t)N;
    const T* RIPPLE_RESTRICT pos = static_cast<const T*>(b.ptr);

    py::array_t<double> out({ Tn, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)Tn_i * 9u * sizeof(double));
    double* RIPPLE_RESTRICT o = static_cast<double*>(outbuf.ptr);

    const auto slices = balanced_lag_slices(Tn_i, n_use);
    std::vector<std::thread> threads;
    std::vector<std::exception_ptr> eps(n_use);
    threads.reserve(n_use);

    py::gil_scoped_release nogil;

    for (std::size_t ti = 0; ti < n_use; ++ti) {
        threads.emplace_back([&, ti]() {
            try {
                const std::int64_t start_lag = slices[ti].first;
                const std::int64_t stop_lag = slices[ti].second;

                for (std::int64_t lag = start_lag; lag < stop_lag; ++lag) {
                    if (lag == 0) continue;

                    const std::int64_t n_origin = Tn_i - lag;
                    if (n_origin <= 0) continue;

                    double sxx = 0.0, syy = 0.0, szz = 0.0;
                    double sxy = 0.0, sxz = 0.0, syz = 0.0;
                    const size_t lag_stride = (size_t)lag * stride;

                    for (std::int64_t t0 = 0; t0 < n_origin; ++t0) {
                        const T* RIPPLE_RESTRICT a0 = pos + (size_t)t0 * stride;
                        const T* RIPPLE_RESTRICT a1 = a0 + lag_stride;

                        for (size_t i = 0; i < Nu; ++i) {
                            const double dx = (double)a1[0] - (double)a0[0];
                            const double dy = (double)a1[1] - (double)a0[1];
                            const double dz = (double)a1[2] - (double)a0[2];
                            sxx += dx * dx;
                            syy += dy * dy;
                            szz += dz * dz;
                            sxy += dx * dy;
                            sxz += dx * dz;
                            syz += dy * dz;
                            a0 += 3;
                            a1 += 3;
                        }
                    }

                    const double inv = 1.0 / ((double)N * (double)n_origin);
                    double* RIPPLE_RESTRICT m = o + (size_t)lag * 9u;
                    m[0] = sxx * inv;
                    m[4] = syy * inv;
                    m[8] = szz * inv;
                    m[1] = sxy * inv;
                    m[2] = sxz * inv;
                    m[5] = syz * inv;
                    symmetrize_3x3_upper_inplace(m);
                }
            } catch (...) {
                eps[ti] = std::current_exception();
            }
        });
    }

    for (auto& th : threads) th.join();
    for (const auto& ep : eps) {
        if (ep) std::rethrow_exception(ep);
    }

    return out;
}

template <typename T>
static py::array_t<double> msd_t1_partial_impl(py::array pos_, std::int64_t start_t1, std::int64_t stop_t1) {
    auto b = pos_.request();
    require_c_contig_TN3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const ssize N = b.shape[1];

    const std::int64_t Tn_i = (std::int64_t)Tn;
    const size_t stride = (size_t)N * 3u;
    const size_t Nu = (size_t)N;

    if (start_t1 < 0 || stop_t1 < 0 || start_t1 > stop_t1 || stop_t1 > Tn_i) {
        throw std::invalid_argument("invalid t1 range");
    }

    py::array_t<double> out({ (ssize)stop_t1, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)stop_t1 * 9u * sizeof(double));

    const T* RIPPLE_RESTRICT pos = static_cast<const T*>(b.ptr);
    double* RIPPLE_RESTRICT outp = static_cast<double*>(outbuf.ptr);

    py::gil_scoped_release nogil;

    for (std::int64_t t1 = start_t1; t1 < stop_t1; ++t1) {
        const T* RIPPLE_RESTRICT p1 = pos + (size_t)t1 * stride;

        for (std::int64_t t0 = 0; t0 < t1; ++t0) {
            const std::int64_t lag = t1 - t0;
            const T* RIPPLE_RESTRICT a0 = pos + (size_t)t0 * stride;
            const T* RIPPLE_RESTRICT a1 = p1;

            double sxx = 0.0, syy = 0.0, szz = 0.0;
            double sxy = 0.0, sxz = 0.0, syz = 0.0;

            for (size_t i = 0; i < Nu; ++i) {
                const double dx = (double)a1[0] - (double)a0[0];
                const double dy = (double)a1[1] - (double)a0[1];
                const double dz = (double)a1[2] - (double)a0[2];
                sxx += dx * dx;
                syy += dy * dy;
                szz += dz * dz;
                sxy += dx * dy;
                sxz += dx * dz;
                syz += dy * dz;
                a0 += 3;
                a1 += 3;
            }

            double* RIPPLE_RESTRICT m = outp + (size_t)lag * 9u;
            m[0] += sxx;
            m[4] += syy;
            m[8] += szz;
            m[1] += sxy;
            m[2] += sxz;
            m[5] += syz;
        }
    }

    for (std::int64_t lag = 1; lag < stop_t1; ++lag) {
        double* RIPPLE_RESTRICT m = outp + (size_t)lag * 9u;
        symmetrize_3x3_upper_inplace(m);
    }

    return out;
}

static py::array_t<double> msd_tensor(py::array pos, std::int64_t start_lag, std::int64_t stop_lag) {
    const auto b = pos.request();
    if (dtype_is<float>(b)) {
        return msd_tensor_impl<float>(pos, start_lag, stop_lag);
    }
    if (dtype_is<double>(b)) {
        return msd_tensor_impl<double>(pos, start_lag, stop_lag);
    }
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

static py::array_t<double> msd_tensor_full(py::array pos, std::int64_t n_threads) {
    const auto b = pos.request();
    if (dtype_is<float>(b)) {
        return msd_tensor_full_impl<float>(pos, n_threads);
    }
    if (dtype_is<double>(b)) {
        return msd_tensor_full_impl<double>(pos, n_threads);
    }
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

static py::array_t<double> msd_t1_partial(py::array pos, std::int64_t start_t1, std::int64_t stop_t1) {
    const auto b = pos.request();
    if (dtype_is<float>(b)) {
        return msd_t1_partial_impl<float>(pos, start_t1, stop_t1);
    }
    if (dtype_is<double>(b)) {
        return msd_t1_partial_impl<double>(pos, start_t1, stop_t1);
    }
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

PYBIND11_MODULE(msd_ext, m) {
    m.doc() = "MSD tensor kernels";
    m.def("msd_tensor", &msd_tensor, py::arg("pos"), py::arg("start_lag"), py::arg("stop_lag"),
          "Compute MSD tensor curve for lags in [start_lag, stop_lag). Returns (n_lag,3,3) float64.");
    m.def("msd_tensor_full", &msd_tensor_full, py::arg("pos"), py::arg("n_threads"),
          "Compute the full MSD tensor curve for lags 0..T-1 using C++ threads. Returns (T,3,3) float64.");
    m.def("msd_t1_partial", &msd_t1_partial, py::arg("pos"), py::arg("start_t1"), py::arg("stop_t1"),
          "Compute partial numerator sums over a slice of t1. Returns (stop_t1,3,3) float64.");
}
