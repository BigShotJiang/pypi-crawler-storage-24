# ripple/kernel/compile_setup.py
from __future__ import annotations
from pathlib import Path
import os
import warnings
import numpy as np
from setuptools import setup
from pybind11.setup_helpers import Pybind11Extension, build_ext

HERE = Path(__file__).resolve().parent          # .../ripple/kernel
PKG  = HERE.parent                              # .../ripple  (这里就是包目录，里面有 __init__.py)

if np.lib.NumpyVersion(np.__version__).major < 2:
    warnings.warn(
        "Building Ripple extensions with NumPy 1.x headers will not produce binaries that are "
        "simultaneously compatible with NumPy 1.26 and 2.x. Prefer building with NumPy >= 2.0 headers.",
        RuntimeWarning,
    )


def ext(modname: str, cpp: str) -> Pybind11Extension:
    return Pybind11Extension(
        modname,
        [str(HERE / cpp)],
        include_dirs=[np.get_include()],
        cxx_std=17,
        define_macros=[("NPY_NO_DEPRECATED_API", "NPY_1_7_API_VERSION")],
        extra_compile_args=["/O2", "/DNDEBUG", "/EHsc", "/bigobj", "/utf-8"] if os.name == "nt"
                          else ["-O3", "-DNDEBUG", "-fvisibility=hidden"],
    )

ext_modules = [
    ext("ripple.kernel.rdf_ext", "rdf_ext.cpp"),
    ext("ripple.kernel.ssf_ext", "ssf_ext.cpp"),
    ext("ripple.kernel.vhf_ext", "vhf_ext.cpp"),
    ext("ripple.kernel.isf_ext", "isf_ext.cpp"),
    ext("ripple.kernel.fpcf_ext", "fpcf_ext.cpp"),
    ext("ripple.kernel.msd_ext", "msd_ext.cpp"),
    ext("ripple.kernel.cmsd_ext", "cmsd_ext.cpp"),
    ext("ripple.kernel.block_mcmc_ext", "block_mcmc_ext.cpp"),
]

setup(
    name="ripple",
    version="1.3.0",
    # 关键：告诉 setuptools：包 ripple 的目录就是 PKG（父目录），不是 PKG/ripple
    packages=["ripple", "ripple.kernel"],
    package_dir={"ripple": str(PKG)},
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)
