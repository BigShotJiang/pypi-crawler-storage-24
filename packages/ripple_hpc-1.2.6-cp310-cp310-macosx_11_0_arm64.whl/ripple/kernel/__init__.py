"""
C++/pybind11 kernels for Ripple.

These extensions are built at install time (pip install .) or via:
    python setup.py build_ext --inplace
"""

from __future__ import annotations

def _missing_ext(name: str) -> None:
    raise ImportError(
        f"Missing compiled extension {name}. "
        "Build it first, e.g. `pip install -e .` or `python setup.py build_ext --inplace`."
    )

__all__ = [
    "rdf_ext", "ssf_ext", "vhf_ext", "isf_ext", "fpcf_ext", "msd_ext", "cmsd_ext", "block_mcmc_ext",
]
