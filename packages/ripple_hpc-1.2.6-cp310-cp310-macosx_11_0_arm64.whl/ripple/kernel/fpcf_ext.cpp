#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <exception>
#include <limits>
#include <stdexcept>
#include <thread>
#include <vector>

namespace py = pybind11;

static constexpr double TWO_PI = 6.283185307179586476925286766559;

static inline int checked_int_from_ssize(py::ssize_t x) {
    if (x < 0 || x > (py::ssize_t)std::numeric_limits<int>::max()) {
        throw std::invalid_argument("size exceeds int range");
    }
    return (int)x;
}

static inline void fast_sincos(double x, double* s, double* c) {
#if defined(__GLIBC__) && !defined(_MSC_VER)
    ::sincos(x, s, c);
#else
    *s = std::sin(x);
    *c = std::cos(x);
#endif
}

static inline double wrap01_for_index(double x) {
    x -= std::floor(x);
    if (x >= 1.0) x = std::nextafter(1.0, 0.0);
    return x;
}

static inline double det3x3(const double a[3][3]) {
    return
        a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1]) -
        a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0]) +
        a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
}

static inline bool invert3x3(const double a[3][3], double inva[3][3]) {
    const double a00 = a[0][0], a01 = a[0][1], a02 = a[0][2];
    const double a10 = a[1][0], a11 = a[1][1], a12 = a[1][2];
    const double a20 = a[2][0], a21 = a[2][1], a22 = a[2][2];

    const double c00 = (a11 * a22 - a12 * a21);
    const double c01 = -(a10 * a22 - a12 * a20);
    const double c02 = (a10 * a21 - a11 * a20);

    const double c10 = -(a01 * a22 - a02 * a21);
    const double c11 = (a00 * a22 - a02 * a20);
    const double c12 = -(a00 * a21 - a01 * a20);

    const double c20 = (a01 * a12 - a02 * a11);
    const double c21 = -(a00 * a12 - a02 * a10);
    const double c22 = (a00 * a11 - a01 * a10);

    const double det = a00 * c00 + a01 * c01 + a02 * c02;
    if (std::abs(det) < 1e-18) {
        return false;
    }

    const double invdet = 1.0 / det;
    inva[0][0] = c00 * invdet; inva[0][1] = c10 * invdet; inva[0][2] = c20 * invdet;
    inva[1][0] = c01 * invdet; inva[1][1] = c11 * invdet; inva[1][2] = c21 * invdet;
    inva[2][0] = c02 * invdet; inva[2][1] = c12 * invdet; inva[2][2] = c22 * invdet;
    return true;
}

static inline void copy_cell(const double* src9, double out[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            out[i][j] = src9[(size_t)i * 3 + (size_t)j];
        }
    }
}

static inline void mul3x3(const double A[3][3], const double B[3][3], double C[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            C[i][j] = A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j];
        }
    }
}

static inline void mul_rowvec3(const double v[3], const double M[3][3], double out[3]) {
    out[0] = v[0] * M[0][0] + v[1] * M[1][0] + v[2] * M[2][0];
    out[1] = v[0] * M[0][1] + v[1] * M[1][1] + v[2] * M[2][1];
    out[2] = v[0] * M[0][2] + v[1] * M[1][2] + v[2] * M[2][2];
}

static inline double phase_from_n_ds(const int32_t* n, const double ds[3]) {
    return TWO_PI * (
        (double)n[0] * ds[0] +
        (double)n[1] * ds[1] +
        (double)n[2] * ds[2]
    );
}

static inline void reciprocal_from_invcell(const double invcell[3][3], double rec[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            rec[i][j] = TWO_PI * invcell[j][i];
        }
    }
}

static inline int shell_id_from_q(
    const int32_t* n,
    const double rec[3][3],
    double qmin2,
    double qmax2,
    double inv_dq,
    int nbins
) {
    const double nx = (double)n[0];
    const double ny = (double)n[1];
    const double nz = (double)n[2];

    const double qx = nx * rec[0][0] + ny * rec[1][0] + nz * rec[2][0];
    const double qy = nx * rec[0][1] + ny * rec[1][1] + nz * rec[2][1];
    const double qz = nx * rec[0][2] + ny * rec[1][2] + nz * rec[2][2];
    const double qn2 = qx * qx + qy * qy + qz * qz;
    if (!(qn2 > qmin2 && qn2 <= qmax2)) {
        return -1;
    }

    const double qn = std::sqrt(qn2);
    const int sid = (int)(qn * inv_dq);
    if (sid < 0 || sid >= nbins) {
        return -1;
    }
    return sid;
}

static inline bool build_valid_q_list_varcell(
    const int32_t* Q,
    int NQ,
    const double cell1[3][3],
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    double inv_cell1[3][3],
    std::vector<int32_t>& idx,
    std::vector<int32_t>& sid,
    std::vector<int64_t>& shell_counts
) {
    idx.clear();
    sid.clear();
    shell_counts.assign((size_t)nbins, int64_t(0));

    if (!invert3x3(cell1, inv_cell1)) {
        return false;
    }

    double rec[3][3];
    reciprocal_from_invcell(inv_cell1, rec);

    const double eps = 1e-12;
    const double qmin2 = (q_min + eps) * (q_min + eps);
    const double qmax2 = (q_max + eps) * (q_max + eps);
    const double inv_dq = 1.0 / dq_shell;

    idx.reserve((size_t)NQ);
    sid.reserve((size_t)NQ);
    for (int qi = 0; qi < NQ; ++qi) {
        const int sid_i = shell_id_from_q(Q + (size_t)qi * 3, rec, qmin2, qmax2, inv_dq, nbins);
        if (sid_i >= 0) {
            idx.push_back((int32_t)qi);
            sid.push_back((int32_t)sid_i);
            shell_counts[(size_t)sid_i] += 1;
        }
    }
    return true;
}

static inline void validate_selected_lags(const int32_t* lags, int K, int T_i) {
    if (K < 1) {
        throw std::invalid_argument("lags must be non-empty");
    }
    int32_t prev = -1;
    for (int ki = 0; ki < K; ++ki) {
        const int32_t li = lags[(size_t)ki];
        if (li < 0 || li >= T_i) {
            throw std::invalid_argument("lags must satisfy 0 <= lag < T");
        }
        if (li <= prev) {
            throw std::invalid_argument("lags must be strictly increasing");
        }
        prev = li;
    }
}

static inline void build_shell_3d(int nbins, double dr, std::vector<double>& shell) {
    shell.resize((size_t)nbins);
    const double c = 4.0 * std::acos(-1.0) / 3.0;
    for (int k = 0; k < nbins; ++k) {
        const double r0 = (double)k * dr;
        const double r1 = r0 + dr;
        shell[(size_t)k] = c * (r1 * r1 * r1 - r0 * r0 * r0);
    }
}

struct Metric3 {
    double G[3][3];
    double Ginv[3][3];
    double b_len[3];
};

static inline Metric3 metric3_from_cell(const double cell[3][3]) {
    auto dot3 = [](const double* u, const double* v) -> double {
        return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
    };

    Metric3 M{};
    M.G[0][0] = dot3(cell[0], cell[0]); M.G[0][1] = dot3(cell[0], cell[1]); M.G[0][2] = dot3(cell[0], cell[2]);
    M.G[1][0] = M.G[0][1];              M.G[1][1] = dot3(cell[1], cell[1]); M.G[1][2] = dot3(cell[1], cell[2]);
    M.G[2][0] = M.G[0][2];              M.G[2][1] = M.G[1][2];              M.G[2][2] = dot3(cell[2], cell[2]);

    const double a = M.G[0][0], b = M.G[0][1], c = M.G[0][2];
    const double d = M.G[1][1], e = M.G[1][2];
    const double f = M.G[2][2];
    const double det = a * (d * f - e * e) - b * (b * f - c * e) + c * (b * e - c * d);
    if (det <= 0.0) {
        throw std::runtime_error("metric3: non-positive determinant");
    }
    const double invdet = 1.0 / det;

    M.Ginv[0][0] = (d * f - e * e) * invdet;
    M.Ginv[0][1] = (c * e - b * f) * invdet;
    M.Ginv[0][2] = (b * e - c * d) * invdet;
    M.Ginv[1][0] = M.Ginv[0][1];
    M.Ginv[1][1] = (a * f - c * c) * invdet;
    M.Ginv[1][2] = (b * c - a * e) * invdet;
    M.Ginv[2][0] = M.Ginv[0][2];
    M.Ginv[2][1] = M.Ginv[1][2];
    M.Ginv[2][2] = (a * d - b * b) * invdet;

    M.b_len[0] = std::sqrt(std::max(0.0, M.Ginv[0][0]));
    M.b_len[1] = std::sqrt(std::max(0.0, M.Ginv[1][1]));
    M.b_len[2] = std::sqrt(std::max(0.0, M.Ginv[2][2]));
    return M;
}

static inline int bound_m(double b_len, double r_max) {
    if (b_len <= 0.0) return 0;
    return (int)std::ceil(r_max * b_len + 1e-12);
}

static inline double r2_dim3(
    double d0,
    double d1,
    double d2,
    int m0,
    int m1,
    int m2,
    const Metric3& M
) {
    double best = std::numeric_limits<double>::infinity();
    for (int i0 = -m0; i0 <= m0; ++i0) {
        const double x0 = d0 + (double)i0;
        for (int i1 = -m1; i1 <= m1; ++i1) {
            const double x1 = d1 + (double)i1;
            for (int i2 = -m2; i2 <= m2; ++i2) {
                const double x2 = d2 + (double)i2;
                const double r2 =
                    x0 * (M.G[0][0] * x0 + M.G[0][1] * x1 + M.G[0][2] * x2) +
                    x1 * (M.G[1][0] * x0 + M.G[1][1] * x1 + M.G[1][2] * x2) +
                    x2 * (M.G[2][0] * x0 + M.G[2][1] * x1 + M.G[2][2] * x2);
                if (r2 < best) best = r2;
            }
        }
    }
    return best;
}

static inline double r_max_limit_metric3(const Metric3& M) {
    const double h0 = 1.0 / M.b_len[0];
    const double h1 = 1.0 / M.b_len[1];
    const double h2 = 1.0 / M.b_len[2];
    return 0.5 * std::min(h0, std::min(h1, h2));
}

struct Bins3 {
    int nx = 1, ny = 1, nz = 1;
    int kx = 0, ky = 0, kz = 0;
    std::vector<int> head;
    std::vector<int> next;

    void build(
        const double* s0,
        const double* s1,
        const double* s2,
        int npts,
        const Metric3& M,
        double rcut
    ) {
        const double bx = std::min(1.0, M.b_len[0] * rcut);
        const double by = std::min(1.0, M.b_len[1] * rcut);
        const double bz = std::min(1.0, M.b_len[2] * rcut);

        nx = std::max(1, (int)std::floor(1.0 / std::max(1e-16, bx)));
        ny = std::max(1, (int)std::floor(1.0 / std::max(1e-16, by)));
        nz = std::max(1, (int)std::floor(1.0 / std::max(1e-16, bz)));
        constexpr std::size_t MAX_TOTAL_BINS3 = (std::size_t)1 << 20;
        auto total_bins = [&]() -> std::size_t {
            return (std::size_t)nx * (std::size_t)ny * (std::size_t)nz;
        };
        while (total_bins() > MAX_TOTAL_BINS3) {
            if (nx >= ny && nx >= nz && nx > 1) {
                nx = std::max(1, (nx + 1) / 2);
            }
            else if (ny >= nx && ny >= nz && ny > 1) {
                ny = std::max(1, (ny + 1) / 2);
            }
            else if (nz > 1) {
                nz = std::max(1, (nz + 1) / 2);
            }
            else {
                break;
            }
        }

        kx = (nx == 1) ? 0 : std::min(nx - 1, std::max(0, (int)std::ceil(bx * nx) + 1));
        ky = (ny == 1) ? 0 : std::min(ny - 1, std::max(0, (int)std::ceil(by * ny) + 1));
        kz = (nz == 1) ? 0 : std::min(nz - 1, std::max(0, (int)std::ceil(bz * nz) + 1));

        const std::size_t nb = total_bins();
        head.assign(nb, -1);
        next.assign((size_t)npts, -1);

        for (int j = 0; j < npts; ++j) {
            int ix = (int)std::floor(s0[j] * nx);
            int iy = (int)std::floor(s1[j] * ny);
            int iz = (int)std::floor(s2[j] * nz);
            ix = std::min(nx - 1, std::max(0, ix));
            iy = std::min(ny - 1, std::max(0, iy));
            iz = std::min(nz - 1, std::max(0, iz));
            const std::size_t b = ((std::size_t)ix * (std::size_t)ny + (std::size_t)iy) * (std::size_t)nz + (std::size_t)iz;
            next[(size_t)j] = head[b];
            head[b] = j;
        }
    }
};

template <typename Tpos>
static void mobility_mean_by_lag(
    const Tpos* U,
    int T_i,
    int N_i,
    double a2,
    const int32_t* lag_ptr,
    int K_i,
    const int32_t* slices,
    int S_i,
    int n_threads,
    std::vector<double>& mean_p,
    std::vector<int64_t>& cnt
) {
    struct LocalBuf {
        std::vector<double> sum_p;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.sum_p.assign((size_t)K_i, 0.0);
            L.cnt.assign((size_t)K_i, int64_t(0));

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                const size_t base1 = ((size_t)t1 * (size_t)N_i) * 3;
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t base0 = ((size_t)t0 * (size_t)N_i) * 3;
                    int64_t n_active = 0;
                    for (int i = 0; i < N_i; ++i) {
                        const size_t o1 = base1 + (size_t)i * 3;
                        const size_t o0 = base0 + (size_t)i * 3;
                        const double dx = (double)U[o1 + 0] - (double)U[o0 + 0];
                        const double dy = (double)U[o1 + 1] - (double)U[o0 + 1];
                        const double dz = (double)U[o1 + 2] - (double)U[o0 + 2];
                        const double r2 = dx * dx + dy * dy + dz * dz;
                        if (r2 >= a2) {
                            n_active += 1;
                        }
                    }
                    L.sum_p[(size_t)ki] += (double)n_active / (double)N_i;
                    L.cnt[(size_t)ki] += 1;
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    mean_p.assign((size_t)K_i, std::numeric_limits<double>::quiet_NaN());
    cnt.assign((size_t)K_i, int64_t(0));

    py::gil_scoped_release release;

    const int n_use = std::max(1, std::min(n_threads, S_i));
    std::vector<std::thread> threads;
    std::vector<std::exception_ptr> eps((size_t)n_use);
    threads.reserve((size_t)n_use);
    for (int ti = 0; ti < n_use; ++ti) {
        threads.emplace_back([&, ti]() {
            for (int si = ti; si < S_i; si += n_use) {
                compute_slice(si, eps[(size_t)ti]);
            }
        });
    }
    for (auto& th : threads) th.join();
    for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

    for (int si = 0; si < S_i; ++si) {
        const LocalBuf& L = locals[(size_t)si];
        if (L.cnt.empty()) continue;
        for (int ki = 0; ki < K_i; ++ki) {
            mean_p[(size_t)ki] = std::isnan(mean_p[(size_t)ki]) ? 0.0 : mean_p[(size_t)ki];
            mean_p[(size_t)ki] += L.sum_p[(size_t)ki];
            cnt[(size_t)ki] += L.cnt[(size_t)ki];
        }
    }

    for (int ki = 0; ki < K_i; ++ki) {
        if (cnt[(size_t)ki] > 0) {
            mean_p[(size_t)ki] /= (double)cnt[(size_t)ki];
        }
    }
}

template <typename Tpos>
static py::tuple chi4_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> pos_unwrap,
    double a,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices
) {
    if (!(a > 0.0) || !std::isfinite(a)) {
        throw std::invalid_argument("a must be a finite positive float");
    }

    const auto bU = pos_unwrap.request();
    const auto bL = lags.request();
    const auto bS = t1_slices.request();

    if (bU.ndim != 3 || bU.shape[2] != 3) throw std::invalid_argument("pos_unwrap must be (T,N,3)");
    if (bL.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    if (bS.ndim != 2 || bS.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S,2)");

    const int T_i = checked_int_from_ssize(bU.shape[0]);
    const int N_i = checked_int_from_ssize(bU.shape[1]);
    const int K_i = checked_int_from_ssize(bL.shape[0]);
    const int S_i = checked_int_from_ssize(bS.shape[0]);
    if (T_i < 1 || N_i < 1 || K_i < 1) throw std::invalid_argument("empty input");

    const Tpos* U = static_cast<const Tpos*>(bU.ptr);
    const int32_t* lag_ptr = static_cast<const int32_t*>(bL.ptr);
    const int32_t* slices = static_cast<const int32_t*>(bS.ptr);
    validate_selected_lags(lag_ptr, K_i, T_i);

    py::array_t<double> chi4((py::ssize_t)K_i);
    py::array_t<double> mobile_fraction((py::ssize_t)K_i);
    py::array_t<int64_t> cnt((py::ssize_t)K_i);
    auto* Chi = chi4.mutable_data();
    auto* Mob = mobile_fraction.mutable_data();
    auto* Cnt = cnt.mutable_data();
    std::fill(Chi, Chi + (size_t)K_i, 0.0);
    std::fill(Mob, Mob + (size_t)K_i, 0.0);
    std::fill(Cnt, Cnt + (size_t)K_i, int64_t(0));

    struct LocalBuf {
        std::vector<double> sum_p;
        std::vector<double> sum_p2;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);
    const double a2 = a * a;

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.sum_p.assign((size_t)K_i, 0.0);
            L.sum_p2.assign((size_t)K_i, 0.0);
            L.cnt.assign((size_t)K_i, int64_t(0));

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                const size_t base1 = ((size_t)t1 * (size_t)N_i) * 3;
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t base0 = ((size_t)t0 * (size_t)N_i) * 3;
                    int64_t n_active = 0;
                    for (int i = 0; i < N_i; ++i) {
                        const size_t o1 = base1 + (size_t)i * 3;
                        const size_t o0 = base0 + (size_t)i * 3;
                        const double dx = (double)U[o1 + 0] - (double)U[o0 + 0];
                        const double dy = (double)U[o1 + 1] - (double)U[o0 + 1];
                        const double dz = (double)U[o1 + 2] - (double)U[o0 + 2];
                        const double r2 = dx * dx + dy * dy + dz * dz;
                        if (r2 >= a2) {
                            n_active += 1;
                        }
                    }
                    const double p = (double)n_active / (double)N_i;
                    L.sum_p[(size_t)ki] += p;
                    L.sum_p2[(size_t)ki] += p * p;
                    L.cnt[(size_t)ki] += 1;
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S_i));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ++ti) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S_i; si += n_use) {
                    compute_slice(si, eps[(size_t)ti]);
                }
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        std::vector<double> sum_p((size_t)K_i, 0.0);
        std::vector<double> sum_p2((size_t)K_i, 0.0);
        for (int si = 0; si < S_i; ++si) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;
            for (int ki = 0; ki < K_i; ++ki) {
                sum_p[(size_t)ki] += L.sum_p[(size_t)ki];
                sum_p2[(size_t)ki] += L.sum_p2[(size_t)ki];
                Cnt[(size_t)ki] += L.cnt[(size_t)ki];
            }
        }

        const double nanv = std::numeric_limits<double>::quiet_NaN();
        for (int ki = 0; ki < K_i; ++ki) {
            const int64_t c = Cnt[(size_t)ki];
            if (c > 0) {
                const double mp = sum_p[(size_t)ki] / (double)c;
                const double mp2 = sum_p2[(size_t)ki] / (double)c;
                Mob[(size_t)ki] = mp;
                Chi[(size_t)ki] = (double)N_i * (mp2 - mp * mp);
            }
            else {
                Mob[(size_t)ki] = nanv;
                Chi[(size_t)ki] = nanv;
            }
        }
    }

    return py::make_tuple(chi4, mobile_fraction, cnt);
}

template <typename Tpos>
static py::tuple g4_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> pos,
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> pos_unwrap,
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,
    double a,
    double r_max,
    double dr,
    int nbins,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices
) {
    if (!(a > 0.0) || !std::isfinite(a)) {
        throw std::invalid_argument("a must be a finite positive float");
    }
    if (nbins <= 0 || dr <= 0.0 || r_max <= 0.0) {
        throw std::invalid_argument("nbins, dr and r_max must be positive");
    }

    const auto bA = pos.request();
    const auto bU = pos_unwrap.request();
    const auto bC = cell.request();
    const auto bL = lags.request();
    const auto bS = t1_slices.request();

    if (bA.ndim != 3 || bA.shape[2] != 3) throw std::invalid_argument("pos must be (T,N,3)");
    if (bU.ndim != 3 || bU.shape[2] != 3) throw std::invalid_argument("pos_unwrap must be (T,N,3)");
    if (bC.ndim != 3 || bC.shape[1] != 3 || bC.shape[2] != 3) throw std::invalid_argument("cell must be (T,3,3)");
    if (bL.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    if (bS.ndim != 2 || bS.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S,2)");
    if (bA.shape[0] != bU.shape[0] || bA.shape[0] != bC.shape[0]) {
        throw std::invalid_argument("frame length mismatch");
    }
    if (bA.shape[1] != bU.shape[1]) {
        throw std::invalid_argument("pos and pos_unwrap must select the same atoms");
    }

    const int T_i = checked_int_from_ssize(bA.shape[0]);
    const int N_i = checked_int_from_ssize(bA.shape[1]);
    const int K_i = checked_int_from_ssize(bL.shape[0]);
    const int S_i = checked_int_from_ssize(bS.shape[0]);
    if (T_i < 1 || N_i < 1 || K_i < 1) throw std::invalid_argument("empty input");

    const Tpos* A = static_cast<const Tpos*>(bA.ptr);
    const Tpos* U = static_cast<const Tpos*>(bU.ptr);
    const double* C = static_cast<const double*>(bC.ptr);
    const int32_t* lag_ptr = static_cast<const int32_t*>(bL.ptr);
    const int32_t* slices = static_cast<const int32_t*>(bS.ptr);
    validate_selected_lags(lag_ptr, K_i, T_i);

    py::array_t<double> hist({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<double> sum_fac({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> pair_count({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> cnt((py::ssize_t)K_i);
    py::array_t<double> mobile_fraction((py::ssize_t)K_i);
    py::array_t<double> self_term((py::ssize_t)K_i);
    auto* H = hist.mutable_data();
    auto* F = sum_fac.mutable_data();
    auto* P = pair_count.mutable_data();
    auto* Cnt = cnt.mutable_data();
    auto* Mob = mobile_fraction.mutable_data();
    auto* Self = self_term.mutable_data();
    std::fill(H, H + (size_t)K_i * (size_t)nbins, 0.0);
    std::fill(F, F + (size_t)K_i * (size_t)nbins, 0.0);
    std::fill(P, P + (size_t)K_i * (size_t)nbins, int64_t(0));
    std::fill(Cnt, Cnt + (size_t)K_i, int64_t(0));
    std::fill(Mob, Mob + (size_t)K_i, 0.0);
    std::fill(Self, Self + (size_t)K_i, 0.0);

    std::vector<double> shell;
    build_shell_3d(nbins, dr, shell);
    const double a2 = a * a;
    const double r2_max = r_max * r_max;
    const double inv_dr = 1.0 / dr;
    std::vector<double> p_mean;
    std::vector<int64_t> p_cnt;
    mobility_mean_by_lag(U, T_i, N_i, a2, lag_ptr, K_i, slices, S_i, n_threads, p_mean, p_cnt);

    struct LocalBuf {
        std::vector<double> hist;
        std::vector<double> sum_fac;
        std::vector<int64_t> pair_count;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.hist.assign((size_t)K_i * (size_t)nbins, 0.0);
            L.sum_fac.assign((size_t)K_i * (size_t)nbins, 0.0);
            L.pair_count.assign((size_t)K_i * (size_t)nbins, int64_t(0));
            L.cnt.assign((size_t)K_i, int64_t(0));
            std::vector<double> delta((size_t)N_i, 0.0);
            std::vector<double> sx((size_t)N_i, 0.0);
            std::vector<double> sy((size_t)N_i, 0.0);
            std::vector<double> sz((size_t)N_i, 0.0);
            Bins3 bins;

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                const size_t base1 = ((size_t)t1 * (size_t)N_i) * 3;
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t base0 = ((size_t)t0 * (size_t)N_i) * 3;

                    for (int i = 0; i < N_i; ++i) {
                        const size_t o1 = base1 + (size_t)i * 3;
                        const size_t o0 = base0 + (size_t)i * 3;
                        const double dx = (double)U[o1 + 0] - (double)U[o0 + 0];
                        const double dy = (double)U[o1 + 1] - (double)U[o0 + 1];
                        const double dz = (double)U[o1 + 2] - (double)U[o0 + 2];
                        const double r2 = dx * dx + dy * dy + dz * dz;
                        const double ci = (r2 >= a2) ? 1.0 : 0.0;
                        delta[(size_t)i] = ci;
                    }

                    const double p = p_mean[(size_t)ki];
                    L.cnt[(size_t)ki] += 1;
                    for (int i = 0; i < N_i; ++i) {
                        delta[(size_t)i] -= p;
                    }

                    double cell0[3][3];
                    copy_cell(C + (size_t)t0 * 9, cell0);
                    const Metric3 M = metric3_from_cell(cell0);
                    const double r_lim = r_max_limit_metric3(M);
                    if (r_max > r_lim + 1e-12) {
                        throw std::runtime_error("r_max exceeds half the smallest periodic cell height for at least one frame.");
                    }
                    const double vol = std::abs(det3x3(cell0));
                    if (!(vol > 0.0) || !std::isfinite(vol)) {
                        throw std::runtime_error("Encountered singular/degenerate cell in G4 kernel.");
                    }
                    const double fac0 = ((double)N_i * (double)std::max(0, N_i - 1)) / vol;

                    double* row_hist = &L.hist[(size_t)ki * (size_t)nbins];
                    double* row_fac = &L.sum_fac[(size_t)ki * (size_t)nbins];
                    int64_t* row_pair = &L.pair_count[(size_t)ki * (size_t)nbins];
                    for (int b = 0; b < nbins; ++b) {
                        row_fac[(size_t)b] += fac0 * shell[(size_t)b];
                    }

                    for (int i = 0; i < N_i; ++i) {
                        const size_t oa = base0 + (size_t)i * 3;
                        sx[(size_t)i] = wrap01_for_index((double)A[oa + 0]);
                        sy[(size_t)i] = wrap01_for_index((double)A[oa + 1]);
                        sz[(size_t)i] = wrap01_for_index((double)A[oa + 2]);
                    }
                    bins.build(sx.data(), sy.data(), sz.data(), N_i, M, r_max);

                    const int mm0 = bound_m(M.b_len[0], r_max);
                    const int mm1 = bound_m(M.b_len[1], r_max);
                    const int mm2 = bound_m(M.b_len[2], r_max);
                    const bool full_x = bins.nx <= 2 * bins.kx + 1;
                    const bool full_y = bins.ny <= 2 * bins.ky + 1;
                    const bool full_z = bins.nz <= 2 * bins.kz + 1;

                    for (int i = 0; i < N_i; ++i) {
                        const double wi = delta[(size_t)i];
                        const double a0 = sx[(size_t)i];
                        const double a1 = sy[(size_t)i];
                        const double a2v = sz[(size_t)i];

                        const int ix = std::min(bins.nx - 1, std::max(0, (int)std::floor(a0 * bins.nx)));
                        const int iy = std::min(bins.ny - 1, std::max(0, (int)std::floor(a1 * bins.ny)));
                        const int iz = std::min(bins.nz - 1, std::max(0, (int)std::floor(a2v * bins.nz)));

                        const int dx0 = full_x ? 0 : -bins.kx;
                        const int dx1 = full_x ? bins.nx : (bins.kx + 1);
                        const int dy0 = full_y ? 0 : -bins.ky;
                        const int dy1 = full_y ? bins.ny : (bins.ky + 1);
                        const int dz0 = full_z ? 0 : -bins.kz;
                        const int dz1 = full_z ? bins.nz : (bins.kz + 1);

                        for (int dx = dx0; dx < dx1; ++dx) {
                            int jx = full_x ? dx : (ix + dx);
                            if (!full_x) jx = (jx % bins.nx + bins.nx) % bins.nx;
                            for (int dy = dy0; dy < dy1; ++dy) {
                                int jy = full_y ? dy : (iy + dy);
                                if (!full_y) jy = (jy % bins.ny + bins.ny) % bins.ny;
                                for (int dz = dz0; dz < dz1; ++dz) {
                                    int jz = full_z ? dz : (iz + dz);
                                    if (!full_z) jz = (jz % bins.nz + bins.nz) % bins.nz;
                                    const std::size_t bb = ((std::size_t)jx * (std::size_t)bins.ny + (std::size_t)jy) * (std::size_t)bins.nz + (std::size_t)jz;
                                    for (int j = bins.head[bb]; j != -1; j = bins.next[(size_t)j]) {
                                        if (j == i) continue;
                                        const double d0 = sx[(size_t)j] - a0;
                                        const double d1 = sy[(size_t)j] - a1;
                                        const double d2 = sz[(size_t)j] - a2v;
                                        const double r2 = r2_dim3(d0, d1, d2, mm0, mm1, mm2, M);
                                        if (r2 < r2_max) {
                                            const int k = (int)(std::sqrt(r2) * inv_dr);
                                            if (k < nbins) {
                                                row_hist[(size_t)k] += wi * delta[(size_t)j];
                                                row_pair[(size_t)k] += 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S_i));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ++ti) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S_i; si += n_use) {
                    compute_slice(si, eps[(size_t)ti]);
                }
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        for (int si = 0; si < S_i; ++si) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;
            for (int ki = 0; ki < K_i; ++ki) {
                Cnt[(size_t)ki] += L.cnt[(size_t)ki];
            }
            for (int ki = 0; ki < K_i; ++ki) {
                double* dst_h = H + (size_t)ki * (size_t)nbins;
                double* dst_f = F + (size_t)ki * (size_t)nbins;
                int64_t* dst_p = P + (size_t)ki * (size_t)nbins;
                const double* src_h = &L.hist[(size_t)ki * (size_t)nbins];
                const double* src_f = &L.sum_fac[(size_t)ki * (size_t)nbins];
                const int64_t* src_p = &L.pair_count[(size_t)ki * (size_t)nbins];
                for (int b = 0; b < nbins; ++b) {
                    dst_h[(size_t)b] += src_h[(size_t)b];
                    dst_f[(size_t)b] += src_f[(size_t)b];
                    dst_p[(size_t)b] += src_p[(size_t)b];
                }
            }
        }

        const double nanv = std::numeric_limits<double>::quiet_NaN();
        for (int ki = 0; ki < K_i; ++ki) {
            if (p_cnt[(size_t)ki] > 0) {
                Mob[(size_t)ki] = p_mean[(size_t)ki];
                Self[(size_t)ki] = p_mean[(size_t)ki] * (1.0 - p_mean[(size_t)ki]);
            }
            else {
                Mob[(size_t)ki] = nanv;
                Self[(size_t)ki] = nanv;
            }
        }
    }

    return py::make_tuple(hist, sum_fac, pair_count, cnt, mobile_fraction, self_term);
}

template <typename Tpos>
static py::tuple s4_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> pos,
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> pos_unwrap,
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> q_int,
    py::object shell_id_obj,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    double a,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices,
    bool cell_static
) {
    if (!(a > 0.0) || !std::isfinite(a)) {
        throw std::invalid_argument("a must be a finite positive float");
    }
    if (nbins <= 0 || dq_shell <= 0.0 || q_max <= 0.0) {
        throw std::invalid_argument("nbins, dq_shell and q_max must be positive");
    }

    const auto bA = pos.request();
    const auto bU = pos_unwrap.request();
    const auto bC = cell.request();
    const auto bQ = q_int.request();
    const auto bL = lags.request();
    const auto bS = t1_slices.request();

    if (bA.ndim != 3 || bA.shape[2] != 3) throw std::invalid_argument("pos must be (T,N,3)");
    if (bU.ndim != 3 || bU.shape[2] != 3) throw std::invalid_argument("pos_unwrap must be (T,N,3)");
    if (bC.ndim != 3 || bC.shape[1] != 3 || bC.shape[2] != 3) throw std::invalid_argument("cell must be (T,3,3)");
    if (bQ.ndim != 2 || bQ.shape[1] != 3) throw std::invalid_argument("q_int must be (NQ,3)");
    if (bL.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    if (bS.ndim != 2 || bS.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S,2)");
    if (bA.shape[0] != bU.shape[0] || bA.shape[0] != bC.shape[0]) {
        throw std::invalid_argument("frame length mismatch");
    }
    if (bA.shape[1] != bU.shape[1]) {
        throw std::invalid_argument("pos and pos_unwrap must select the same atoms");
    }

    const int T_i = checked_int_from_ssize(bA.shape[0]);
    const int N_i = checked_int_from_ssize(bA.shape[1]);
    const int NQ_i = checked_int_from_ssize(bQ.shape[0]);
    const int K_i = checked_int_from_ssize(bL.shape[0]);
    const int S_i = checked_int_from_ssize(bS.shape[0]);
    if (T_i < 1 || N_i < 1 || NQ_i < 1 || K_i < 1) throw std::invalid_argument("empty input");

    const Tpos* A = static_cast<const Tpos*>(bA.ptr);
    const Tpos* U = static_cast<const Tpos*>(bU.ptr);
    const double* C = static_cast<const double*>(bC.ptr);
    const int32_t* Q = static_cast<const int32_t*>(bQ.ptr);
    const int32_t* lag_ptr = static_cast<const int32_t*>(bL.ptr);
    const int32_t* slices = static_cast<const int32_t*>(bS.ptr);
    validate_selected_lags(lag_ptr, K_i, T_i);

    const int32_t* shell_id_ptr = nullptr;
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> shell_id;
    std::vector<int32_t> static_idx;
    std::vector<int64_t> static_shell_counts;
    double inv_cell_static[3][3];

    if (cell_static) {
        if (shell_id_obj.is_none()) {
            throw std::invalid_argument("shell_id must be provided when cell_static=True");
        }
        shell_id = shell_id_obj.cast<py::array_t<int32_t, py::array::c_style | py::array::forcecast>>();
        const auto bSid = shell_id.request();
        if (bSid.ndim != 1 || bSid.shape[0] != bQ.shape[0]) {
            throw std::invalid_argument("shell_id must be (NQ,) and match q_int");
        }
        shell_id_ptr = static_cast<const int32_t*>(bSid.ptr);

        double cell0[3][3];
        copy_cell(C, cell0);
        if (!invert3x3(cell0, inv_cell_static)) {
            throw std::runtime_error("Singular cell encountered in static S4 kernel.");
        }

        static_idx.resize((size_t)NQ_i);
        static_shell_counts.assign((size_t)nbins, int64_t(0));
        for (int qi = 0; qi < NQ_i; ++qi) {
            static_idx[(size_t)qi] = (int32_t)qi;
            const int sid_i = shell_id_ptr[(size_t)qi];
            if (sid_i < 0 || sid_i >= nbins) {
                throw std::invalid_argument("shell_id contains out-of-range values");
            }
            static_shell_counts[(size_t)sid_i] += 1;
        }
    }

    py::array_t<double> S4({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> q_count({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> cnt((py::ssize_t)K_i);
    py::array_t<double> mobile_fraction((py::ssize_t)K_i);
    auto* H = S4.mutable_data();
    auto* Qd = q_count.mutable_data();
    auto* Cnt = cnt.mutable_data();
    auto* Mob = mobile_fraction.mutable_data();
    std::fill(H, H + (size_t)K_i * (size_t)nbins, 0.0);
    std::fill(Qd, Qd + (size_t)K_i * (size_t)nbins, int64_t(0));
    std::fill(Cnt, Cnt + (size_t)K_i, int64_t(0));
    std::fill(Mob, Mob + (size_t)K_i, 0.0);

    const double a2 = a * a;
    std::vector<double> p_mean;
    std::vector<int64_t> p_cnt;
    mobility_mean_by_lag(U, T_i, N_i, a2, lag_ptr, K_i, slices, S_i, n_threads, p_mean, p_cnt);

    struct LocalBuf {
        std::vector<double> hist;
        std::vector<int64_t> qcnt;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.hist.assign((size_t)K_i * (size_t)nbins, 0.0);
            L.qcnt.assign((size_t)K_i * (size_t)nbins, int64_t(0));
            L.cnt.assign((size_t)K_i, int64_t(0));

            std::vector<int32_t> valid_idx;
            std::vector<int32_t> valid_sid;
            std::vector<int64_t> shell_counts((size_t)nbins, int64_t(0));
            std::vector<double> weights((size_t)N_i, 0.0);
            std::vector<double> coords((size_t)N_i * 3, 0.0);
            double inv_cell1[3][3];
            double T01[3][3];

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const std::vector<int32_t>* idx_ptr = nullptr;
                const std::vector<int32_t>* sid_ptr = nullptr;
                const std::vector<int64_t>* shell_ptr = nullptr;

                if (cell_static) {
                    for (int i = 0; i < 3; ++i) {
                        for (int j = 0; j < 3; ++j) {
                            inv_cell1[i][j] = inv_cell_static[i][j];
                        }
                    }
                    idx_ptr = &static_idx;
                    sid_ptr = nullptr;
                    shell_ptr = &static_shell_counts;
                }
                else {
                    double cell1[3][3];
                    copy_cell(C + (size_t)t1 * 9, cell1);
                    if (!build_valid_q_list_varcell(Q, NQ_i, cell1, q_min, q_max, dq_shell, nbins, inv_cell1, valid_idx, valid_sid, shell_counts)) {
                        continue;
                    }
                    idx_ptr = &valid_idx;
                    sid_ptr = &valid_sid;
                    shell_ptr = &shell_counts;
                }

                const size_t n_valid = idx_ptr->size();
                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                const size_t base1 = ((size_t)t1 * (size_t)N_i) * 3;
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t base0 = ((size_t)t0 * (size_t)N_i) * 3;

                    if (!cell_static) {
                        double cell0[3][3];
                        copy_cell(C + (size_t)t0 * 9, cell0);
                        mul3x3(cell0, inv_cell1, T01);
                    }

                    for (int i = 0; i < N_i; ++i) {
                        const size_t o1 = base1 + (size_t)i * 3;
                        const size_t o0 = base0 + (size_t)i * 3;
                        const double dx = (double)U[o1 + 0] - (double)U[o0 + 0];
                        const double dy = (double)U[o1 + 1] - (double)U[o0 + 1];
                        const double dz = (double)U[o1 + 2] - (double)U[o0 + 2];
                        const double r2 = dx * dx + dy * dy + dz * dz;
                        const double ci = (r2 >= a2) ? 1.0 : 0.0;
                        weights[(size_t)i] = ci;

                        const size_t oa = base0 + (size_t)i * 3;
                        const size_t off = (size_t)i * 3;
                        if (cell_static) {
                            coords[off + 0] = (double)A[oa + 0];
                            coords[off + 1] = (double)A[oa + 1];
                            coords[off + 2] = (double)A[oa + 2];
                        }
                        else {
                            const double s0[3] = {
                                (double)A[oa + 0],
                                (double)A[oa + 1],
                                (double)A[oa + 2],
                            };
                            double s1[3];
                            mul_rowvec3(s0, T01, s1);
                            coords[off + 0] = s1[0];
                            coords[off + 1] = s1[1];
                            coords[off + 2] = s1[2];
                        }
                    }

                    const double p = p_mean[(size_t)ki];
                    L.cnt[(size_t)ki] += 1;
                    for (int i = 0; i < N_i; ++i) {
                        weights[(size_t)i] -= p;
                    }

                    int64_t* qrow = &L.qcnt[(size_t)ki * (size_t)nbins];
                    for (int b = 0; b < nbins; ++b) {
                        qrow[(size_t)b] += (*shell_ptr)[(size_t)b];
                    }

                    double* row = &L.hist[(size_t)ki * (size_t)nbins];
                    for (size_t qv = 0; qv < n_valid; ++qv) {
                        const int qi = (int)(*idx_ptr)[qv];
                        const int sid_i = cell_static ? shell_id_ptr[(size_t)qi] : (int)(*sid_ptr)[qv];
                        const int32_t* nq = Q + (size_t)qi * 3;
                        double re = 0.0;
                        double im = 0.0;
                        for (int i = 0; i < N_i; ++i) {
                            const double w = weights[(size_t)i];
                            if (w == 0.0) continue;
                            const double sxyz[3] = {
                                coords[(size_t)i * 3 + 0],
                                coords[(size_t)i * 3 + 1],
                                coords[(size_t)i * 3 + 2],
                            };
                            const double phase = phase_from_n_ds(nq, sxyz);
                            double s, c;
                            fast_sincos(phase, &s, &c);
                            re += w * c;
                            im += w * s;
                        }
                        row[(size_t)sid_i] += re * re + im * im;
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S_i));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ++ti) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S_i; si += n_use) {
                    compute_slice(si, eps[(size_t)ti]);
                }
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        for (int si = 0; si < S_i; ++si) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;
            for (int ki = 0; ki < K_i; ++ki) {
                Cnt[(size_t)ki] += L.cnt[(size_t)ki];
            }
            for (int ki = 0; ki < K_i; ++ki) {
                double* dst_h = H + (size_t)ki * (size_t)nbins;
                int64_t* dst_q = Qd + (size_t)ki * (size_t)nbins;
                const double* src_h = &L.hist[(size_t)ki * (size_t)nbins];
                const int64_t* src_q = &L.qcnt[(size_t)ki * (size_t)nbins];
                for (int b = 0; b < nbins; ++b) {
                    dst_h[(size_t)b] += src_h[(size_t)b];
                    dst_q[(size_t)b] += src_q[(size_t)b];
                }
            }
        }

        const double nanv = std::numeric_limits<double>::quiet_NaN();
        for (int ki = 0; ki < K_i; ++ki) {
            if (p_cnt[(size_t)ki] > 0) {
                Mob[(size_t)ki] = p_mean[(size_t)ki];
            }
            else {
                Mob[(size_t)ki] = nanv;
            }

            double* row = H + (size_t)ki * (size_t)nbins;
            const int64_t* qrow = Qd + (size_t)ki * (size_t)nbins;
            for (int b = 0; b < nbins; ++b) {
                const int64_t qn = qrow[(size_t)b];
                if (qn > 0) {
                    row[(size_t)b] /= ((double)N_i * (double)qn);
                }
                else {
                    row[(size_t)b] = nanv;
                }
            }
        }
    }

    return py::make_tuple(S4, q_count, cnt, mobile_fraction);
}

static py::tuple chi4_dispatch(
    py::array pos_unwrap,
    double a,
    py::array lags,
    int n_threads,
    py::array t1_slices
) {
    const auto dtU = pos_unwrap.dtype();
    if (dtU.is(py::dtype::of<float>())) {
        return chi4_impl<float>(
            pos_unwrap.cast<py::array_t<float>>(),
            a,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>()
        );
    }
    if (dtU.is(py::dtype::of<double>())) {
        return chi4_impl<double>(
            pos_unwrap.cast<py::array_t<double>>(),
            a,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>()
        );
    }
    throw std::invalid_argument("pos_unwrap dtype must be float32 or float64");
}

static py::tuple g4_dispatch(
    py::array pos,
    py::array pos_unwrap,
    py::array cell,
    double a,
    double r_max,
    double dr,
    int nbins,
    py::array lags,
    int n_threads,
    py::array t1_slices
) {
    const auto dtA = pos.dtype();
    const auto dtU = pos_unwrap.dtype();
    if (!dtA.is(dtU)) {
        throw std::invalid_argument("pos and pos_unwrap must have the same dtype");
    }

    if (dtA.is(py::dtype::of<float>())) {
        return g4_impl<float>(
            pos.cast<py::array_t<float>>(),
            pos_unwrap.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            a,
            r_max,
            dr,
            nbins,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>()
        );
    }
    if (dtA.is(py::dtype::of<double>())) {
        return g4_impl<double>(
            pos.cast<py::array_t<double>>(),
            pos_unwrap.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            a,
            r_max,
            dr,
            nbins,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>()
        );
    }
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

static py::tuple s4_dispatch(
    py::array pos,
    py::array pos_unwrap,
    py::array cell,
    py::array q_int,
    py::object shell_id,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    double a,
    py::array lags,
    int n_threads,
    py::array t1_slices,
    bool cell_static
) {
    const auto dtA = pos.dtype();
    const auto dtU = pos_unwrap.dtype();
    if (!dtA.is(dtU)) {
        throw std::invalid_argument("pos and pos_unwrap must have the same dtype");
    }

    if (dtA.is(py::dtype::of<float>())) {
        return s4_impl<float>(
            pos.cast<py::array_t<float>>(),
            pos_unwrap.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min,
            q_max,
            dq_shell,
            nbins,
            a,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    if (dtA.is(py::dtype::of<double>())) {
        return s4_impl<double>(
            pos.cast<py::array_t<double>>(),
            pos_unwrap.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min,
            q_max,
            dq_shell,
            nbins,
            a,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

PYBIND11_MODULE(fpcf_ext, m) {
    m.doc() = "Mobility-based four-point correlation kernels for Ripple";

    m.def(
        "chi4",
        &chi4_dispatch,
        py::arg("pos_unwrap"),
        py::arg("a"),
        py::arg("lags"),
        py::arg("n_threads"),
        py::arg("t1_slices")
    );

    m.def(
        "g4",
        &g4_dispatch,
        py::arg("pos"),
        py::arg("pos_unwrap"),
        py::arg("cell"),
        py::arg("a"),
        py::arg("r_max"),
        py::arg("dr"),
        py::arg("nbins"),
        py::arg("lags"),
        py::arg("n_threads"),
        py::arg("t1_slices")
    );

    m.def(
        "s4",
        &s4_dispatch,
        py::arg("pos"),
        py::arg("pos_unwrap"),
        py::arg("cell"),
        py::arg("q_int"),
        py::arg("shell_id"),
        py::arg("q_min"),
        py::arg("q_max"),
        py::arg("dq_shell"),
        py::arg("nbins"),
        py::arg("a"),
        py::arg("lags"),
        py::arg("n_threads"),
        py::arg("t1_slices"),
        py::arg("cell_static")
    );
}
