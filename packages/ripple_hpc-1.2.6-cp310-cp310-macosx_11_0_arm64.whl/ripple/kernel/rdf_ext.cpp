// ripple/rdf.cpp
// Build module name: ripple._rdf_ext  ;  Python: from ripple.rdf_ext import rdf
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <cmath>
#include <vector>
#include <algorithm>
#include <exception>
#include <stdexcept>
#include <thread>
#include <cstdint>
#include <limits>
#include <string>
#include <utility>

namespace py = pybind11;

// -------------------------
// Mode: 2D projection for xy/xz/yz (as requested)
// mode_int: xyz=1, xy=2, xz=3, yz=4, x=5, y=6, z=7
// -------------------------
struct Mode {
    int dim;
    int ax[3];
};

static inline Mode parse_mode_int(int mode_int) {
    Mode m{};
    switch (mode_int) {
        case 1: m.dim=3; m.ax[0]=0; m.ax[1]=1; m.ax[2]=2; break; // xyz
        case 2: m.dim=2; m.ax[0]=0; m.ax[1]=1; break;            // xy (2D projection)
        case 3: m.dim=2; m.ax[0]=0; m.ax[1]=2; break;            // xz
        case 4: m.dim=2; m.ax[0]=1; m.ax[1]=2; break;            // yz
        case 5: m.dim=1; m.ax[0]=0; break;                       // x
        case 6: m.dim=1; m.ax[0]=1; break;                       // y
        case 7: m.dim=1; m.ax[0]=2; break;                       // z
        default: throw std::runtime_error("mode_int must be in {1..7}.");
    }
    return m;
}

static inline std::size_t clamp_thread_count(std::int64_t requested, std::int64_t n_task) {
    if (requested < 1) throw std::invalid_argument("n_threads must be >= 1");
    const std::int64_t usable = std::max<std::int64_t>(1, std::min<std::int64_t>(requested, std::max<std::int64_t>(1, n_task)));
    return (std::size_t)usable;
}

static inline std::vector<std::pair<py::ssize_t, py::ssize_t>>
split_frame_range(py::ssize_t start, py::ssize_t stop, std::size_t n_slice) {
    const py::ssize_t total = stop - start;
    if (total <= 0) return {};

    n_slice = std::max<std::size_t>(1, std::min<std::size_t>(n_slice, (std::size_t)total));
    std::vector<std::pair<py::ssize_t, py::ssize_t>> out;
    out.reserve(n_slice);

    const py::ssize_t base = total / (py::ssize_t)n_slice;
    const py::ssize_t rem = total % (py::ssize_t)n_slice;
    py::ssize_t cur = start;
    for (std::size_t i = 0; i < n_slice; ++i) {
        const py::ssize_t len = base + ((py::ssize_t)i < rem ? 1 : 0);
        const py::ssize_t nxt = cur + len;
        if (nxt > cur) out.emplace_back(cur, nxt);
        cur = nxt;
    }
    return out;
}

// -------------------------
// Small linear algebra
// Cell uses ASE convention: cell[t, i, :] is the i-th lattice vector (row vector)
// -------------------------
static inline double dot3(const double a[3], const double b[3]) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}
static inline void cross3(const double a[3], const double b[3], double out[3]) {
    out[0] = a[1]*b[2] - a[2]*b[1];
    out[1] = a[2]*b[0] - a[0]*b[2];
    out[2] = a[0]*b[1] - a[1]*b[0];
}
static inline double norm3(const double a[3]) { return std::sqrt(dot3(a,a)); }

struct Metric3 { double G[3][3]; double Ginv[3][3]; double b_len[3]; };
struct Metric2 { double G[2][2]; double Ginv[2][2]; double b_len[2]; };
struct Metric1 { double G; double Ginv; double b_len; };

static inline void load_cell_row(const double cell[3][3], int row, double v[3]) {
    v[0]=cell[row][0]; v[1]=cell[row][1]; v[2]=cell[row][2];
}

static inline Metric3 metric3(const double cell[3][3], const int ax[3]) {
    double a0[3], a1[3], a2[3];
    load_cell_row(cell, ax[0], a0);
    load_cell_row(cell, ax[1], a1);
    load_cell_row(cell, ax[2], a2);

    Metric3 M{};
    M.G[0][0]=dot3(a0,a0); M.G[0][1]=dot3(a0,a1); M.G[0][2]=dot3(a0,a2);
    M.G[1][0]=M.G[0][1];  M.G[1][1]=dot3(a1,a1); M.G[1][2]=dot3(a1,a2);
    M.G[2][0]=M.G[0][2];  M.G[2][1]=M.G[1][2];  M.G[2][2]=dot3(a2,a2);

    // invert symmetric 3x3
    const double a=M.G[0][0], b=M.G[0][1], c=M.G[0][2];
    const double d=M.G[1][1], e=M.G[1][2];
    const double f=M.G[2][2];

    const double A = d*f - e*e;
    const double B = c*e - b*f;
    const double C = b*e - c*d;
    const double D = a*f - c*c;
    const double E = b*c - a*e;
    const double F = a*d - b*b;

    const double det = a*A + b*B + c*C;
    if (!(det > 0.0)) throw std::runtime_error("Bad cell metric det<=0.");
    const double invdet = 1.0/det;

    M.Ginv[0][0]=A*invdet; M.Ginv[0][1]=B*invdet; M.Ginv[0][2]=C*invdet;
    M.Ginv[1][0]=B*invdet; M.Ginv[1][1]=D*invdet; M.Ginv[1][2]=E*invdet;
    M.Ginv[2][0]=C*invdet; M.Ginv[2][1]=E*invdet; M.Ginv[2][2]=F*invdet;

    // reciprocal basis vectors in Cartesian (no 2π): b_i = Σ_j Ginv[i,j] a_j
    // then b_len[i] = |b_i|
    for (int i=0;i<3;i++){
        double bi[3]={0,0,0};
        bi[0]=M.Ginv[i][0]*a0[0] + M.Ginv[i][1]*a1[0] + M.Ginv[i][2]*a2[0];
        bi[1]=M.Ginv[i][0]*a0[1] + M.Ginv[i][1]*a1[1] + M.Ginv[i][2]*a2[1];
        bi[2]=M.Ginv[i][0]*a0[2] + M.Ginv[i][1]*a1[2] + M.Ginv[i][2]*a2[2];
        M.b_len[i] = norm3(bi);
    }
    return M;
}

static inline Metric2 metric2(const double cell[3][3], int ax0, int ax1) {
    double u[3], v[3];
    load_cell_row(cell, ax0, u);
    load_cell_row(cell, ax1, v);

    Metric2 M{};
    M.G[0][0]=dot3(u,u);
    M.G[0][1]=dot3(u,v);
    M.G[1][0]=M.G[0][1];
    M.G[1][1]=dot3(v,v);

    const double det = M.G[0][0]*M.G[1][1] - M.G[0][1]*M.G[0][1];
    if (!(det > 0.0)) throw std::runtime_error("Bad 2D metric det<=0.");
    const double invdet = 1.0/det;

    M.Ginv[0][0]= M.G[1][1]*invdet;
    M.Ginv[1][1]= M.G[0][0]*invdet;
    M.Ginv[0][1]=-M.G[0][1]*invdet;
    M.Ginv[1][0]= M.Ginv[0][1];

    // reciprocal in-plane basis
    for (int i=0;i<2;i++){
        double bi[3]={0,0,0};
        bi[0]=M.Ginv[i][0]*u[0] + M.Ginv[i][1]*v[0];
        bi[1]=M.Ginv[i][0]*u[1] + M.Ginv[i][1]*v[1];
        bi[2]=M.Ginv[i][0]*u[2] + M.Ginv[i][1]*v[2];
        M.b_len[i] = norm3(bi);
    }
    return M;
}

static inline Metric1 metric1(const double cell[3][3], int ax0) {
    double u[3];
    load_cell_row(cell, ax0, u);
    Metric1 M{};
    M.G = dot3(u,u);
    if (!(M.G > 0.0)) throw std::runtime_error("Bad 1D metric <=0.");
    M.Ginv = 1.0 / M.G;
    // reciprocal length = |u|/|u|^2 = 1/|u|
    M.b_len = 1.0 / std::sqrt(M.G);
    return M;
}
// -------------------------
// Conservative r_max upper bound for fully periodic distances:
// r_max_limit is the inradius of the fundamental domain in the measurement subspace.
//
// 3D (abc / xyz): inradius of the triclinic parallelepiped = 0.5 * min_i h_i,
// where h_i is the distance between the two opposite faces normal to reciprocal basis b_i.
// Since (no 2π) b_len[i]=|b_i|, we have h_i = 1/|b_i|.
//
// 2D (ab/ac/bc): inradius of the parallelogram in that plane = 0.5 * min_i h_i (altitudes).
//
// 1D (a/b/c): inradius of the segment = 0.5 * |u|.
// -------------------------
static inline double r_max_limit_metric3(const Metric3& M){
    const double h0 = 1.0 / M.b_len[0];
    const double h1 = 1.0 / M.b_len[1];
    const double h2 = 1.0 / M.b_len[2];
    return 0.5 * std::min(h0, std::min(h1, h2));
}
static inline double r_max_limit_metric2(const Metric2& M){
    const double h0 = 1.0 / M.b_len[0];
    const double h1 = 1.0 / M.b_len[1];
    return 0.5 * std::min(h0, h1);
}
static inline double r_max_limit_metric1(const Metric1& M){
    // Metric1::b_len = 1/|u|
    return 0.5 / M.b_len;
}


// -------------------------
// Shell measure for denom
// 3D: 4π/3 (r2^3 - r1^3)
// 2D: π (r2^2 - r1^2)
// 1D amplitude (|x|): 2 dr   (IMPORTANT: factor 2 for two-sided line)
// -------------------------
static inline void fill_shell(std::vector<double>& shell, int nbins, double dr, int dim){
    shell.assign(nbins, 0.0);
    if (dim==3){
        const double c = 4.0*3.141592653589793238462643383279502884/3.0;
        for(int k=0;k<nbins;k++){
            double r1 = (double)k*dr;
            double r2 = (double)(k+1)*dr;
            shell[k] = c*(r2*r2*r2 - r1*r1*r1);
        }
    } else if (dim==2){
        const double c = 3.141592653589793238462643383279502884;
        for(int k=0;k<nbins;k++){
            double r1 = (double)k*dr;
            double r2 = (double)(k+1)*dr;
            shell[k] = c*(r2*r2 - r1*r1);
        }
    } else {
        for(int k=0;k<nbins;k++) shell[k] = 2.0*dr;  // two-sided
    }
}

// -------------------------
// Measure size per frame
// 3D: vol[t] (given)
// 2D: |u x v|
// 1D: |u|
// -------------------------
static inline double measure_2d(const double cell[3][3], int ax0, int ax1){
    double u[3], v[3], cr[3];
    load_cell_row(cell, ax0, u);
    load_cell_row(cell, ax1, v);
    cross3(u,v,cr);
    return norm3(cr);
}
static inline double measure_1d(const double cell[3][3], int ax0){
    double u[3]; load_cell_row(cell, ax0, u);
    return norm3(u);
}

// -------------------------
// Robust MIC (triclinic-safe) in measurement subspace
// We enumerate integer shifts n within bounds m_i = ceil(|b_i| * rcut)
// where b_i are reciprocal basis vectors of the measurement lattice.
// This avoids assuming {-1,0,1} is always sufficient.
// For typical reduced cells, m_i==1.
// -------------------------
static inline int bound_m(double b_len, double rcut){
    // For wrapped fractional differences d0 in (-1, 1), ceil(b_len * rcut)
    // is already sufficient to bound the needed image shifts.
    return (int)std::ceil(b_len * rcut + 1e-12);
}

static inline double r2_dim1(double d0, const Metric1& M, bool periodic, int m0){
    if (!periodic){
        return (d0*d0)*M.G;
    }
    double best = 1e300;
    for(int n=-m0; n<=m0; ++n){
        double x = d0 - (double)n;
        double r2 = (x*x)*M.G;
        if (r2 < best) best = r2;
    }
    return best;
}

static inline double r2_dim2(const double d0[2], const Metric2& M, const bool pwrap[2], const int m[2]){
    // if non-periodic along an axis -> only n=0
    const int m0 = pwrap[0] ? m[0] : 0;
    const int m1 = pwrap[1] ? m[1] : 0;

    double best = 1e300;
    for(int n0=-m0; n0<=m0; ++n0){
        double x0 = d0[0] - (double)n0;
        for(int n1=-m1; n1<=m1; ++n1){
            double x1 = d0[1] - (double)n1;
            double r2 = x0*x0*M.G[0][0] + 2.0*x0*x1*M.G[0][1] + x1*x1*M.G[1][1];
            if (r2 < best) best = r2;
        }
    }
    return best;
}

static inline double r2_dim3(const double d0[3], const Metric3& M, const bool pwrap[3], const int m[3]){
    const int m0 = pwrap[0] ? m[0] : 0;
    const int m1 = pwrap[1] ? m[1] : 0;
    const int m2 = pwrap[2] ? m[2] : 0;

    double best = 1e300;
    for(int n0=-m0; n0<=m0; ++n0){
        double x0 = d0[0] - (double)n0;
        for(int n1=-m1; n1<=m1; ++n1){
            double x1 = d0[1] - (double)n1;
            for(int n2=-m2; n2<=m2; ++n2){
                double x2 = d0[2] - (double)n2;
                double r2 =
                    x0*x0*M.G[0][0] + x1*x1*M.G[1][1] + x2*x2*M.G[2][2] +
                    2.0*x0*x1*M.G[0][1] + 2.0*x0*x2*M.G[0][2] + 2.0*x1*x2*M.G[1][2];
                if (r2 < best) best = r2;
            }
        }
    }
    return best;
}

// -------------------------
// Neighbor list cache (CSR)
// Built at a reference frame t_build with cutoff rcut = r_max + skin
// Reuse until (2*max_disp + cell_bound) > skin
// -------------------------
struct NL {
    bool built=false;
    bool bins_used=false;  // whether NL was built with modulo cell-list bins
    int NA=0, NB=0, dim=0;
    std::vector<int> offs;   // NA+1
    std::vector<int> nbr;    // concatenated neighbor indices
    std::vector<double> sA0, sA1, sA2; // reference included coords
    std::vector<double> sB0, sB1, sB2;
    double cell_ref[3][3];

        void reset(int NA_, int NB_, int dim_){
        built=false;
        bins_used=false; NA=NA_; NB=NB_; dim=dim_;
        offs.assign(NA+1, 0);
        nbr.clear();
        sA0.assign(NA,0.0); sB0.assign(NB,0.0);
        if (dim>=2){ sA1.assign(NA,0.0); sB1.assign(NB,0.0); }
        if (dim==3){ sA2.assign(NA,0.0); sB2.assign(NB,0.0); }
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) cell_ref[i][j]=0.0;
    }
};

static inline double frob_included_dcell(const double cell_ref[3][3], const double cell_now[3][3], const Mode& mode){
    double s=0.0;
    for(int i=0;i<mode.dim;i++){
        int ax = mode.ax[i];
        for(int k=0;k<3;k++){
            double d = cell_now[ax][k] - cell_ref[ax][k];
            s += d*d;
        }
    }
    return std::sqrt(s);
}

// conservative bound for relative-vector change due to cell deformation:
// || (ds) * ΔB || <= ||ds||2 * ||ΔB||2 <= sqrt(dim) * ||ΔB||F
static inline double cell_bound(double dcell_frob, int dim){
    return std::sqrt((double)dim) * dcell_frob;
}

// -------------------------
// Cell-list binning (only safe when MIC shift bounds are small, i.e. max(m)<=1 typically)
// Otherwise, fall back to brute force for correctness.
// -------------------------
struct Bins3 {
    int nx=1, ny=1, nz=1;
    int kx=0, ky=0, kz=0;
    std::vector<int> head;
    std::vector<int> next;

    inline int idx(int ix,int iy,int iz) const { return ix + nx*(iy + ny*iz); }

    void build(int NB, const double* s0, const double* s1, const double* s2,
               const Metric3& M, double rcut){
        // bound_i = rcut * sqrt(Ginv_ii)  (C-S inequality)
        double b0 = rcut * std::sqrt(M.Ginv[0][0]);
        double b1 = rcut * std::sqrt(M.Ginv[1][1]);
        double b2 = rcut * std::sqrt(M.Ginv[2][2]);

        nx = std::max(1, (int)std::floor(1.0 / b0));
        ny = std::max(1, (int)std::floor(1.0 / b1));
        nz = std::max(1, (int)std::floor(1.0 / b2));
        nx = std::min(nx, 512); ny = std::min(ny, 512); nz = std::min(nz, 512);

        kx = (nx==1)?0:(int)std::ceil(b0*nx);
        ky = (ny==1)?0:(int)std::ceil(b1*ny);
        kz = (nz==1)?0:(int)std::ceil(b2*nz);
        kx = std::min(kx, nx-1); ky = std::min(ky, ny-1); kz = std::min(kz, nz-1);

        head.assign(nx*ny*nz, -1);
        next.assign(NB, -1);

        for(int j=0;j<NB;j++){
            int ix = (int)std::floor(s0[j]*nx); ix = std::clamp(ix, 0, nx-1);
            int iy = (int)std::floor(s1[j]*ny); iy = std::clamp(iy, 0, ny-1);
            int iz = (int)std::floor(s2[j]*nz); iz = std::clamp(iz, 0, nz-1);
            int id = idx(ix,iy,iz);
            next[j]=head[id];
            head[id]=j;
        }
    }
};

struct Bins2 {
    int n0=1, n1=1;
    int k0=0, k1=0;
    std::vector<int> head;
    std::vector<int> next;

    inline int idx(int i0,int i1) const { return i0 + n0*i1; }

    void build(int NB, const double* s0, const double* s1,
               const Metric2& M, double rcut){
        double b0 = rcut * std::sqrt(M.Ginv[0][0]);
        double b1 = rcut * std::sqrt(M.Ginv[1][1]);

        n0 = std::max(1, (int)std::floor(1.0 / b0));
        n1 = std::max(1, (int)std::floor(1.0 / b1));
        n0 = std::min(n0, 1024); n1 = std::min(n1, 1024);

        k0 = (n0==1)?0:(int)std::ceil(b0*n0);
        k1 = (n1==1)?0:(int)std::ceil(b1*n1);
        k0 = std::min(k0, n0-1); k1 = std::min(k1, n1-1);

        head.assign(n0*n1, -1);
        next.assign(NB, -1);

        for(int j=0;j<NB;j++){
            int i0 = (int)std::floor(s0[j]*n0); i0 = std::clamp(i0, 0, n0-1);
            int i1 = (int)std::floor(s1[j]*n1); i1 = std::clamp(i1, 0, n1-1);
            int id = idx(i0,i1);
            next[j]=head[id];
            head[id]=j;
        }
    }
};

// -------------------------
// Main kernel
// Returns: (counts_sum, denom_sum)
// -------------------------
template <typename Tpos>
py::tuple rdf_impl(
    py::array_t<Tpos,   py::array::c_style | py::array::forcecast> posA,
    py::array_t<Tpos,   py::array::c_style | py::array::forcecast> posB,
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,
    py::array_t<bool,   py::array::c_style | py::array::forcecast> pbc,
    py::array_t<double, py::array::c_style | py::array::forcecast> vol,
    bool periodic_all,
    bool cell_static,
    bool same,
    py::ssize_t start, py::ssize_t stop,
    double r_max, double dr, int nbins,
    int mode_int,
    double skin
){
    auto A = posA.template unchecked<3>();  // (T, NA, 3)
    auto B = posB.template unchecked<3>();  // (T, NB, 3)
    auto C = cell.unchecked<3>();  // (T, 3, 3)
    auto P = pbc.unchecked<2>();   // (T, 3)
    auto V = vol.unchecked<1>();   // (T,)

    const py::ssize_t Tn = A.shape(0);
    const int NA = (int)A.shape(1);
    const int NB = (int)B.shape(1);

    if (B.shape(0)!=Tn || C.shape(0)!=Tn || P.shape(0)!=Tn || V.shape(0)!=Tn)
        throw std::runtime_error("T dimension mismatch.");
    if ((int)A.shape(2)!=3 || (int)B.shape(2)!=3 || (int)C.shape(1)!=3 || (int)C.shape(2)!=3 || (int)P.shape(1)!=3)
        throw std::runtime_error("Bad trailing dimensions.");

    if (start < 0) start = 0;
    if (stop > Tn) stop = Tn;
    if (stop <= start) throw std::runtime_error("Empty [start,stop).");

    if (!(r_max > 0.0 && dr > 0.0)) throw std::runtime_error("r_max/dr must be positive.");
    if (nbins < 1) throw std::runtime_error("nbins < 1.");

    // enforce binning consistency: kernel trusts nbins, uses r_max_eff = nbins*dr
    const double r_max_eff = (double)nbins * dr;
    const double r2_max = r_max_eff * r_max_eff;

    const double skin_eff = std::max(0.0, skin);
    const double rcut = r_max_eff + skin_eff;
    const double r2_cut = rcut * rcut;

    const Mode mode = parse_mode_int(mode_int);
    const int dim = mode.dim;

    // output arrays
    py::array_t<double> counts_arr(nbins);
    py::array_t<double> denom_arr(nbins);
    auto counts = counts_arr.mutable_unchecked<1>();
    auto denom  = denom_arr.mutable_unchecked<1>();
    for(int k=0;k<nbins;k++){ counts(k)=0.0; denom(k)=0.0; }

    // shell measures
    std::vector<double> shell;
    fill_shell(shell, nbins, dr, dim);

    // neighbor list cache
    NL nl;
    nl.reset(NA, NB, dim);

    auto load_cell_t = [&](py::ssize_t t, double cell_t[3][3]){
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) cell_t[i][j]=C(t,i,j);
    };

    // precompute (cell_static)
    double cell0[3][3];
    load_cell_t(start, cell0);

    Metric3 M3_0{};
    Metric2 M2_0{};
    Metric1 M1_0{};
    double meas0 = 0.0;
    int m_bound0_3[3]={0,0,0};
    int m_bound0_2[2]={0,0};
    int m_bound0_1=0;
    double rmax_limit0 = std::numeric_limits<double>::infinity();

    if (cell_static) {
        if (dim==3){
            M3_0 = metric3(cell0, mode.ax);
            meas0 = V(start);
            rmax_limit0 = r_max_limit_metric3(M3_0);
            if (!(meas0 > 0.0)) throw std::runtime_error("vol<=0 in cell_static.");
            for(int i=0;i<3;i++) m_bound0_3[i] = bound_m(M3_0.b_len[i], rcut);
        } else if (dim==2){
            M2_0 = metric2(cell0, mode.ax[0], mode.ax[1]);
            meas0 = measure_2d(cell0, mode.ax[0], mode.ax[1]);
            rmax_limit0 = r_max_limit_metric2(M2_0);
            if (!(meas0 > 0.0)) throw std::runtime_error("area<=0 in cell_static.");
            for(int i=0;i<2;i++) m_bound0_2[i] = bound_m(M2_0.b_len[i], rcut);
        } else {
            M1_0 = metric1(cell0, mode.ax[0]);
            meas0 = measure_1d(cell0, mode.ax[0]);
            rmax_limit0 = r_max_limit_metric1(M1_0);
            if (!(meas0 > 0.0)) throw std::runtime_error("len<=0 in cell_static.");
            m_bound0_1 = bound_m(M1_0.b_len, rcut);
        }

// r_max_limit check (fully periodic): reject r_max beyond the inradius of the fundamental domain.
if (periodic_all){
    if (!(rmax_limit0 > 0.0)) throw std::runtime_error("Bad r_max_limit (<=0).");
    if (r_max_eff > rmax_limit0){
        throw std::runtime_error(
            "r_max too large for periodic cell: r_max_eff=" + std::to_string(r_max_eff) +
            " exceeds r_max_limit=" + std::to_string(rmax_limit0) +
            " (mode_int=" + std::to_string(mode_int) + ", periodic_all=True)."
        );
    }
}
        const double NB_eff = std::max(0.0, (double)NB - (same ? 1.0 : 0.0));
        const double rho = NB_eff / meas0;
        const double fac = (double)NA * rho;
        const double nframe = (double)(stop - start);
        for(int k=0;k<nbins;k++){
            denom(k) = fac * shell[k] * nframe;
        }
    }

// r_max_limit check (periodic_all=True, cell_static=False):
// scan frames in [start, stop) to find a conservative minimum inradius.
if (periodic_all && !cell_static){
    double rmax_lim = std::numeric_limits<double>::infinity();
    double cell_t[3][3];
    for(py::ssize_t t=start; t<stop; ++t){
        load_cell_t(t, cell_t);
        if (dim==3){
            const Metric3 M = metric3(cell_t, mode.ax);
            rmax_lim = std::min(rmax_lim, r_max_limit_metric3(M));
        } else if (dim==2){
            const Metric2 M = metric2(cell_t, mode.ax[0], mode.ax[1]);
            rmax_lim = std::min(rmax_lim, r_max_limit_metric2(M));
        } else {
            const Metric1 M = metric1(cell_t, mode.ax[0]);
            rmax_lim = std::min(rmax_lim, r_max_limit_metric1(M));
        }
    }
    if (!(rmax_lim > 0.0) || !std::isfinite(rmax_lim)){
        throw std::runtime_error("Bad r_max_limit computed in scan (<=0 or non-finite).");
    }
    if (r_max_eff > rmax_lim){
        throw std::runtime_error(
            "r_max too large for periodic cell (scanned): r_max_eff=" + std::to_string(r_max_eff) +
            " exceeds r_max_limit(min over frames)=" + std::to_string(rmax_lim) +
            " (mode_int=" + std::to_string(mode_int) + ", periodic_all=True, cell_static=False)."
        );
    }
}
    // compute per-frame periodic flags for included axes
    auto pwrap_dim = [&](py::ssize_t t, bool pw[3]){
        for(int i=0;i<3;i++) pw[i]=false;
        if (periodic_all) {
            for(int i=0;i<dim;i++) pw[i]=true;
        } else {
            for(int i=0;i<dim;i++){
                pw[i] = (bool)P(t, mode.ax[i]);
            }
        }
    };

    // build neighbor list at frame t_build
    auto build_nl = [&](py::ssize_t t_build){
        bool pw[3]; pwrap_dim(t_build, pw);

        double cell_tb[3][3];
        load_cell_t(t_build, cell_tb);

        // store ref cell (included rows)
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) nl.cell_ref[i][j]=cell_tb[i][j];

        // store ref included coords
        for(int i=0;i<NA;i++){
            nl.sA0[i] = (double)A(t_build,i, mode.ax[0]);
            if (dim>=2) nl.sA1[i] = (double)A(t_build,i, mode.ax[1]);
            if (dim==3) nl.sA2[i] = (double)A(t_build,i, mode.ax[2]);
        }
        for(int j=0;j<NB;j++){
            nl.sB0[j] = (double)B(t_build,j, mode.ax[0]);
            if (dim>=2) nl.sB1[j] = (double)B(t_build,j, mode.ax[1]);
            if (dim==3) nl.sB2[j] = (double)B(t_build,j, mode.ax[2]);
        }

        nl.nbr.clear();
        nl.offs[0]=0;

        // metrics + MIC bounds at build frame
        bool use_bins = true; // if MIC bounds become >1, bins in modulo cell can be unsafe; fallback to brute-force
        int m3[3]={0,0,0};
        int m2[2]={0,0};
        int m1=0;

        Metric3 M3{};
        Metric2 M2{};
        Metric1 M1{};
        if (dim==3){
            M3 = cell_static ? M3_0 : metric3(cell_tb, mode.ax);
            for(int i=0;i<3;i++){
                m3[i] = cell_static ? m_bound0_3[i] : bound_m(M3.b_len[i], rcut);
                if (pw[i] && m3[i] > 1) use_bins = false;
            }
        } else if (dim==2){
            M2 = cell_static ? M2_0 : metric2(cell_tb, mode.ax[0], mode.ax[1]);
            for(int i=0;i<2;i++){
                m2[i] = cell_static ? m_bound0_2[i] : bound_m(M2.b_len[i], rcut);
                if (pw[i] && m2[i] > 1) use_bins = false;
            }
        } else {
            M1 = cell_static ? M1_0 : metric1(cell_tb, mode.ax[0]);
            m1 = cell_static ? m_bound0_1 : bound_m(M1.b_len, rcut);
            if (pw[0] && m1 > 1) use_bins = false;
        }

        // brute-force neighbor list (rare pathological cells)
        if (!use_bins) {
            for(int i=0;i<NA;i++){
                const double sa0 = (double)A(t_build,i, mode.ax[0]);
                const double sa1 = (dim>=2) ? (double)A(t_build,i, mode.ax[1]) : 0.0;
                const double sa2 = (dim==3) ? (double)A(t_build,i, mode.ax[2]) : 0.0;

                for(int j=0;j<NB;j++){
                    if (same && NA==NB && i==j) continue;

                    if (dim==3){
                        double d0[3] = { (double)B(t_build,j, mode.ax[0]) - sa0,
                                         (double)B(t_build,j, mode.ax[1]) - sa1,
                                         (double)B(t_build,j, mode.ax[2]) - sa2 };
                        const double r2 = r2_dim3(d0, M3, pw, m3);
                        if (r2 < r2_cut) nl.nbr.push_back(j);
                    } else if (dim==2){
                        bool pw2[2]={pw[0],pw[1]};
                        double d0[2] = { (double)B(t_build,j, mode.ax[0]) - sa0,
                                         (double)B(t_build,j, mode.ax[1]) - sa1 };
                        const double r2 = r2_dim2(d0, M2, pw2, m2);
                        if (r2 < r2_cut) nl.nbr.push_back(j);
                    } else {
                        const double d0 = (double)B(t_build,j, mode.ax[0]) - sa0;
                        const double r2 = r2_dim1(d0, M1, pw[0], m1);
                        if (r2 < r2_cut) nl.nbr.push_back(j);
                    }
                }
                nl.offs[i+1] = (int)nl.nbr.size();
            }
            nl.bins_used = false;
            nl.built = true;
            return;
        }

        // bins build arrays
        std::vector<double> sB0(nl.NB), sB1, sB2;
        if (dim>=2) sB1.resize(nl.NB);
        if (dim==3) sB2.resize(nl.NB);
        for(int j=0;j<NB;j++){
            sB0[j]=nl.sB0[j];
            if (dim>=2) sB1[j]=nl.sB1[j];
            if (dim==3) sB2[j]=nl.sB2[j];
        }

        if (dim==3){
            nl.bins_used = true;
            Bins3 bins;
            bins.build(NB, sB0.data(), sB1.data(), sB2.data(), M3, rcut);

            for(int i=0;i<NA;i++){
                const double sa0 = nl.sA0[i];
                const double sa1 = nl.sA1[i];
                const double sa2 = nl.sA2[i];

                int ix = std::clamp((int)std::floor(sa0*bins.nx), 0, bins.nx-1);
                int iy = std::clamp((int)std::floor(sa1*bins.ny), 0, bins.ny-1);
                int iz = std::clamp((int)std::floor(sa2*bins.nz), 0, bins.nz-1);

                for(int ox=-bins.kx; ox<=bins.kx; ++ox){
                    int jx = ix + ox;
                    if (pw[0]) jx = (jx % bins.nx + bins.nx) % bins.nx;
                    else if (jx<0 || jx>=bins.nx) continue;

                    for(int oy=-bins.ky; oy<=bins.ky; ++oy){
                        int jy = iy + oy;
                        if (pw[1]) jy = (jy % bins.ny + bins.ny) % bins.ny;
                        else if (jy<0 || jy>=bins.ny) continue;

                        for(int oz=-bins.kz; oz<=bins.kz; ++oz){
                            int jz = iz + oz;
                            if (pw[2]) jz = (jz % bins.nz + bins.nz) % bins.nz;
                            else if (jz<0 || jz>=bins.nz) continue;

                            int head = bins.head[bins.idx(jx,jy,jz)];
                            for(int j=head; j!=-1; j=bins.next[j]){
                                if (same && NA==NB && i==j) continue;
                                double d0[3] = { nl.sB0[j] - sa0, nl.sB1[j] - sa1, nl.sB2[j] - sa2 };
                                const double r2 = r2_dim3(d0, M3, pw, m3);
                                if (r2 < r2_cut) nl.nbr.push_back(j);
                            }
                        }
                    }
                }
                nl.offs[i+1] = (int)nl.nbr.size();
            }
        } else if (dim==2){
            nl.bins_used = true;
            Bins2 bins;
            bins.build(NB, sB0.data(), sB1.data(), M2, rcut);
            bool pw2[2]={pw[0], pw[1]};

            for(int i=0;i<NA;i++){
                const double sa0 = nl.sA0[i];
                const double sa1 = nl.sA1[i];

                int i0 = std::clamp((int)std::floor(sa0*bins.n0), 0, bins.n0-1);
                int i1 = std::clamp((int)std::floor(sa1*bins.n1), 0, bins.n1-1);

                for(int o0=-bins.k0; o0<=bins.k0; ++o0){
                    int j0 = i0 + o0;
                    if (pw2[0]) j0 = (j0 % bins.n0 + bins.n0) % bins.n0;
                    else if (j0<0 || j0>=bins.n0) continue;

                    for(int o1=-bins.k1; o1<=bins.k1; ++o1){
                        int j1 = i1 + o1;
                        if (pw2[1]) j1 = (j1 % bins.n1 + bins.n1) % bins.n1;
                        else if (j1<0 || j1>=bins.n1) continue;

                        int head = bins.head[bins.idx(j0,j1)];
                        for(int j=head; j!=-1; j=bins.next[j]){
                            if (same && NA==NB && i==j) continue;
                            double d0[2] = { nl.sB0[j] - sa0, nl.sB1[j] - sa1 };
                            const double r2 = r2_dim2(d0, M2, pw2, m2);
                            if (r2 < r2_cut) nl.nbr.push_back(j);
                        }
                    }
                }
                nl.offs[i+1] = (int)nl.nbr.size();
            }
        } else {
            nl.bins_used = false;
            // 1D: simple brute-force is usually fine because dim=1 NL build is cheap;
            // still keep it simple and correct with robust MIC bounds.
            for(int i=0;i<NA;i++){
                const double sa0 = nl.sA0[i];
                for(int j=0;j<NB;j++){
                    if (same && NA==NB && i==j) continue;
                    const double d0 = nl.sB0[j] - sa0;
                    const double r2 = r2_dim1(d0, M1, pw[0], m1);
                    if (r2 < r2_cut) nl.nbr.push_back(j);
                }
                nl.offs[i+1] = (int)nl.nbr.size();
            }
        }

        nl.built = true;
    };

    // check whether NL can be reused at frame t
    auto need_rebuild = [&](py::ssize_t t)->bool{
        if (!nl.built) return true;
        if (skin_eff <= 0.0) return true;

        bool pw[3]; pwrap_dim(t, pw);

        double cell_t[3][3];
        load_cell_t(t, cell_t);

        // cell deformation bound
        const double dF = frob_included_dcell(nl.cell_ref, cell_t, mode);
        const double cb = cell_bound(dF, dim);

        // threshold for 2*max_disp + cb <= skin  -> max_disp <= (skin - cb)/2
        const double thr = 0.5 * (skin_eff - cb);
        if (thr <= 0.0) return true;
        const double thr2 = thr * thr;

        // compute max displacement in measurement space since build (early exit)
        // use current-frame metric for exact cartesian displacement in subspace
        if (dim==3){
            const Metric3 M3 = cell_static ? M3_0 : metric3(cell_t, mode.ax);
            int m3[3]={ cell_static ? m_bound0_3[0] : bound_m(M3.b_len[0], rcut),
                      cell_static ? m_bound0_3[1] : bound_m(M3.b_len[1], rcut),
                      cell_static ? m_bound0_3[2] : bound_m(M3.b_len[2], rcut) };
            // if MIC bounds grow >1, bins may become unsafe -> force rebuild
            if (nl.bins_used){
                for(int i=0;i<3;i++) if (pw[i] && m3[i] > 1) return true;
            }

            // A
            for(int i=0;i<NA;i++){
                double d0[3] = {
                    (double)A(t,i, mode.ax[0]) - nl.sA0[i],
                    (double)A(t,i, mode.ax[1]) - nl.sA1[i],
                    (double)A(t,i, mode.ax[2]) - nl.sA2[i]
                };
                const double d2 = r2_dim3(d0, M3, pw, m3);
                if (d2 > thr2) return true;
            }
            // B
            for(int j=0;j<NB;j++){
                double d0[3] = {
                    (double)B(t,j, mode.ax[0]) - nl.sB0[j],
                    (double)B(t,j, mode.ax[1]) - nl.sB1[j],
                    (double)B(t,j, mode.ax[2]) - nl.sB2[j]
                };
                const double d2 = r2_dim3(d0, M3, pw, m3);
                if (d2 > thr2) return true;
            }
        } else if (dim==2){
            const Metric2 M2 = cell_static ? M2_0 : metric2(cell_t, mode.ax[0], mode.ax[1]);
            bool pw2[2]={pw[0],pw[1]};
            int m2[2]={ cell_static ? m_bound0_2[0] : bound_m(M2.b_len[0], rcut),
                      cell_static ? m_bound0_2[1] : bound_m(M2.b_len[1], rcut) };
            if (nl.bins_used){
                for(int i=0;i<2;i++) if (pw2[i] && m2[i] > 1) return true;
            }

            for(int i=0;i<NA;i++){
                double d0[2] = {
                    (double)A(t,i, mode.ax[0]) - nl.sA0[i],
                    (double)A(t,i, mode.ax[1]) - nl.sA1[i]
                };
                const double d2 = r2_dim2(d0, M2, pw2, m2);
                if (d2 > thr2) return true;
            }
            for(int j=0;j<NB;j++){
                double d0[2] = {
                    (double)B(t,j, mode.ax[0]) - nl.sB0[j],
                    (double)B(t,j, mode.ax[1]) - nl.sB1[j]
                };
                const double d2 = r2_dim2(d0, M2, pw2, m2);
                if (d2 > thr2) return true;
            }
        } else {
            const Metric1 M1 = cell_static ? M1_0 : metric1(cell_t, mode.ax[0]);
            int m1 = cell_static ? m_bound0_1 : bound_m(M1.b_len, rcut);
            if (nl.bins_used){
                if (pw[0] && m1 > 1) return true;
            }

            for(int i=0;i<NA;i++){
                const double d0 = (double)A(t,i, mode.ax[0]) - nl.sA0[i];
                const double d2 = r2_dim1(d0, M1, pw[0], m1);
                if (d2 > thr2) return true;
            }
            for(int j=0;j<NB;j++){
                const double d0 = (double)B(t,j, mode.ax[0]) - nl.sB0[j];
                const double d2 = r2_dim1(d0, M1, pw[0], m1);
                if (d2 > thr2) return true;
            }
        }

        return false;
    };

    // heavy work: release GIL
    {
		py::gil_scoped_release nogil;

		// main loop over frames
		for(py::ssize_t t=start; t<stop; ++t){
			// denom per frame (if not cell_static)
			if (!cell_static){
				double cell_t[3][3];
				load_cell_t(t, cell_t);
				double meas = 0.0;
				if (dim==3) meas = V(t);
				else if (dim==2) meas = measure_2d(cell_t, mode.ax[0], mode.ax[1]);
				else meas = measure_1d(cell_t, mode.ax[0]);
				if (!(meas > 0.0)) continue;

				const double NB_eff = std::max(0.0, (double)NB - (same ? 1.0 : 0.0));
				const double rho = NB_eff / meas;
				const double fac = (double)NA * rho;
				for(int k=0;k<nbins;k++){
					denom(k) += fac * shell[k];
				}
			}

			// rebuild NL if needed
			if (need_rebuild(t)) {
				build_nl(t);
			}

			// distance metric at this frame + MIC bounds
			bool pw[3]; pwrap_dim(t, pw);
			double cell_t[3][3];
			load_cell_t(t, cell_t);

			if (dim==3){
				const Metric3 M3 = cell_static ? M3_0 : metric3(cell_t, mode.ax);
				int m3[3]={ cell_static ? m_bound0_3[0] : bound_m(M3.b_len[0], rcut),
						  cell_static ? m_bound0_3[1] : bound_m(M3.b_len[1], rcut),
						  cell_static ? m_bound0_3[2] : bound_m(M3.b_len[2], rcut) };

				for(int i=0;i<NA;i++){
					const double sa0 = (double)A(t,i, mode.ax[0]);
					const double sa1 = (double)A(t,i, mode.ax[1]);
					const double sa2 = (double)A(t,i, mode.ax[2]);
					const int beg = nl.offs[i], end = nl.offs[i+1];

					for(int q=beg; q<end; ++q){
						const int j = nl.nbr[(size_t)q];
						if (same && NA==NB && i==j) continue;

						double d0[3] = {
							(double)B(t,j, mode.ax[0]) - sa0,
							(double)B(t,j, mode.ax[1]) - sa1,
							(double)B(t,j, mode.ax[2]) - sa2
						};
						const double r2 = r2_dim3(d0, M3, pw, m3);
						if (r2 >= r2_max) continue;

						const double r = std::sqrt(r2);
						const int bin = (int)std::floor(r / dr);
						if ((unsigned)bin < (unsigned)nbins) counts(bin) += 1.0;
					}
				}
			} else if (dim==2){
				const Metric2 M2 = cell_static ? M2_0 : metric2(cell_t, mode.ax[0], mode.ax[1]);
				bool pw2[2]={pw[0], pw[1]};
				int m2[2]={ cell_static ? m_bound0_2[0] : bound_m(M2.b_len[0], rcut),
						  cell_static ? m_bound0_2[1] : bound_m(M2.b_len[1], rcut) };

				for(int i=0;i<NA;i++){
					const double sa0 = (double)A(t,i, mode.ax[0]);
					const double sa1 = (double)A(t,i, mode.ax[1]);
					const int beg = nl.offs[i], end = nl.offs[i+1];

					for(int q=beg; q<end; ++q){
						const int j = nl.nbr[(size_t)q];
						if (same && NA==NB && i==j) continue;

						double d0[2] = {
							(double)B(t,j, mode.ax[0]) - sa0,
							(double)B(t,j, mode.ax[1]) - sa1
						};
						const double r2 = r2_dim2(d0, M2, pw2, m2);
						if (r2 >= r2_max) continue;

						const double r = std::sqrt(r2);
						const int bin = (int)std::floor(r / dr);
						if ((unsigned)bin < (unsigned)nbins) counts(bin) += 1.0;
					}
				}
			} else {
				const Metric1 M1 = cell_static ? M1_0 : metric1(cell_t, mode.ax[0]);
				const int m1 = cell_static ? m_bound0_1 : bound_m(M1.b_len, rcut);

				for(int i=0;i<NA;i++){
					const double sa0 = (double)A(t,i, mode.ax[0]);
					const int beg = nl.offs[i], end = nl.offs[i+1];

					for(int q=beg; q<end; ++q){
						const int j = nl.nbr[(size_t)q];
						if (same && NA==NB && i==j) continue;

						const double d0 = (double)B(t,j, mode.ax[0]) - sa0;
						const double r2 = r2_dim1(d0, M1, pw[0], m1);
						if (r2 >= r2_max) continue;

						const double r = std::sqrt(r2);
						const int bin = (int)std::floor(r / dr);
						if ((unsigned)bin < (unsigned)nbins) counts(bin) += 1.0;
					}
				}
			}
		}
	}// GIL reacquired here
    return py::make_tuple(counts_arr, denom_arr);
}

// -------------------------
// Pybind entry: rdf(...)
// Wrapper now runs the serial chunk kernel on contiguous frame slices in C++ threads.
// -------------------------
template <typename Tpos>
static py::tuple rdf_dispatch(
    py::array posA, py::array posB, py::array cell, py::array pbc, py::array vol,
    bool periodic_all,
    bool cell_static,
    bool same,
    py::ssize_t start, py::ssize_t stop,
    double r_max, double dr, int nbins,
    int mode_int,
    double skin,
    std::int64_t n_threads
) {
    auto posA_t = posA.cast<py::array_t<Tpos,   py::array::c_style | py::array::forcecast>>();
    auto posB_t = posB.cast<py::array_t<Tpos,   py::array::c_style | py::array::forcecast>>();
    auto cell_t = cell.cast<py::array_t<double, py::array::c_style | py::array::forcecast>>();
    auto pbc_t  = pbc.cast<py::array_t<bool,    py::array::c_style | py::array::forcecast>>();
    auto vol_t  = vol.cast<py::array_t<double,  py::array::c_style | py::array::forcecast>>();

    const py::ssize_t Tn = posA_t.shape(0);
    if (start < 0) start = 0;
    if (stop > Tn) stop = Tn;
    if (stop <= start) throw std::runtime_error("Empty [start,stop).");

    const std::size_t n_use = clamp_thread_count(n_threads, (std::int64_t)(stop - start));
    if (n_use <= 1) {
        return rdf_impl<Tpos>(
            posA_t, posB_t, cell_t, pbc_t, vol_t,
            periodic_all, cell_static, same,
            start, stop, r_max, dr, nbins, mode_int, skin
        );
    }

    auto frame_slices = split_frame_range(start, stop, n_use);
    std::vector<py::tuple> partial(frame_slices.size());
    std::vector<std::exception_ptr> eps(frame_slices.size());

    {
        py::gil_scoped_release release;
        std::vector<std::thread> threads;
        threads.reserve(frame_slices.size());

        for (std::size_t ti = 0; ti < frame_slices.size(); ++ti) {
            threads.emplace_back([&, ti]() {
                try {
                    py::gil_scoped_acquire acquire;
                    partial[ti] = rdf_impl<Tpos>(
                        posA_t, posB_t, cell_t, pbc_t, vol_t,
                        periodic_all, cell_static, same,
                        frame_slices[ti].first, frame_slices[ti].second,
                        r_max, dr, nbins, mode_int, skin
                    );
                } catch (...) {
                    eps[ti] = std::current_exception();
                }
            });
        }
        for (auto& th : threads) th.join();
    }

    for (const auto& ep : eps) {
        if (ep) std::rethrow_exception(ep);
    }

    py::array_t<double> counts_arr(nbins);
    py::array_t<double> denom_arr(nbins);
    auto counts = counts_arr.mutable_unchecked<1>();
    auto denom = denom_arr.mutable_unchecked<1>();
    for (int k = 0; k < nbins; ++k) {
        counts(k) = 0.0;
        denom(k) = 0.0;
    }

    for (const py::tuple& item : partial) {
        auto counts_part = item[0].cast<py::array_t<double, py::array::c_style | py::array::forcecast>>();
        auto denom_part = item[1].cast<py::array_t<double, py::array::c_style | py::array::forcecast>>();
        auto c = counts_part.unchecked<1>();
        auto d = denom_part.unchecked<1>();
        for (int k = 0; k < nbins; ++k) {
            counts(k) += c(k);
            denom(k) += d(k);
        }
    }

    return py::make_tuple(counts_arr, denom_arr);
}

py::tuple rdf(
    py::array posA, py::array posB, py::array cell, py::array pbc, py::array vol,
    bool periodic_all,
    bool cell_static,
    bool same,
    py::ssize_t start, py::ssize_t stop,
    double r_max, double dr, int nbins,
    int mode_int,
    double skin,
    std::int64_t n_threads
){
    if (py::isinstance<py::array_t<float>>(posA)) {
        return rdf_dispatch<float>(
            posA, posB, cell, pbc, vol,
            periodic_all, cell_static, same,
            start, stop, r_max, dr, nbins, mode_int, skin, n_threads
        );
    } else {
        return rdf_dispatch<double>(
            posA, posB, cell, pbc, vol,
            periodic_all, cell_static, same,
            start, stop, r_max, dr, nbins, mode_int, skin, n_threads
        );
    }
}

PYBIND11_MODULE(rdf_ext, m) {
    m.def("rdf", &rdf,
          py::arg("posA"), py::arg("posB"), py::arg("cell"), py::arg("pbc"), py::arg("vol"),
          py::arg("periodic_all"), py::arg("cell_static"), py::arg("same"),
          py::arg("start"), py::arg("stop"),
          py::arg("r_max"), py::arg("dr"), py::arg("nbins"),
          py::arg("mode_int"), py::arg("skin"), py::arg("n_threads") = 1,
          "RDF kernel: returns (counts_sum, denom_sum). "
          "mode_int: xyz=1, xy=2, xz=3, yz=4, x=5, y=6, z=7. "
          "xy/xz/yz are 2D projection distances. "
          "Uses threaded chunk reduction, neighbor list with skin reuse, and robust MIC for triclinic cells.");
}
