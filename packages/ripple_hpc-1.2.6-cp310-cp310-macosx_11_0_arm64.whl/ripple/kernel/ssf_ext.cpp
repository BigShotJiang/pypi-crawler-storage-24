#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <cmath>
#include <cstdint>
#include <exception>
#include <stdexcept>
#include <string>
#include <algorithm>
#include <thread>
#include <utility>
#include <vector>

namespace py = pybind11;

// ------------------------ helpers ------------------------

static inline void require_c_contiguous(const py::buffer_info& info, const std::string& name) {
    if (info.ndim < 1) return;
    if (info.strides[info.ndim - 1] != static_cast<py::ssize_t>(info.itemsize)) {
        throw std::runtime_error(name + " must be C-contiguous (last stride mismatch).");
    }
    for (int i = static_cast<int>(info.ndim) - 2; i >= 0; --i) {
        const py::ssize_t expected = info.strides[i + 1] * info.shape[i + 1];
        if (info.strides[i] != expected) {
            throw std::runtime_error(name + " must be C-contiguous (stride mismatch).");
        }
    }
}

static inline void fast_sincos(double x, double* s, double* c) {
#if defined(__GLIBC__) && !defined(_MSC_VER)
    ::sincos(x, s, c);
#else
    *s = std::sin(x);
    *c = std::cos(x);
#endif
}

// Invert a 3x3 matrix (row-major) using adjugate / determinant.
// Returns false if singular.
static inline bool invert_3x3(const double m[9], double inv_out[9]) {
    const double a00 = m[0], a01 = m[1], a02 = m[2];
    const double a10 = m[3], a11 = m[4], a12 = m[5];
    const double a20 = m[6], a21 = m[7], a22 = m[8];

    const double c00 =  (a11 * a22 - a12 * a21);
    const double c01 = -(a10 * a22 - a12 * a20);
    const double c02 =  (a10 * a21 - a11 * a20);

    const double c10 = -(a01 * a22 - a02 * a21);
    const double c11 =  (a00 * a22 - a02 * a20);
    const double c12 = -(a00 * a21 - a01 * a20);

    const double c20 =  (a01 * a12 - a02 * a11);
    const double c21 = -(a00 * a12 - a02 * a10);
    const double c22 =  (a00 * a11 - a01 * a10);

    const double det = a00 * c00 + a01 * c01 + a02 * c02;
    if (std::abs(det) < 1e-18) return false;
    const double inv_det = 1.0 / det;

    inv_out[0] = c00 * inv_det;
    inv_out[1] = c10 * inv_det;
    inv_out[2] = c20 * inv_det;

    inv_out[3] = c01 * inv_det;
    inv_out[4] = c11 * inv_det;
    inv_out[5] = c21 * inv_det;

    inv_out[6] = c02 * inv_det;
    inv_out[7] = c12 * inv_det;
    inv_out[8] = c22 * inv_det;

    return true;
}

static inline std::size_t clamp_thread_count(std::int64_t requested, std::int64_t n_task) {
    if (requested < 1) throw std::invalid_argument("n_threads must be >= 1");
    const std::int64_t usable = std::max<std::int64_t>(1, std::min<std::int64_t>(requested, std::max<std::int64_t>(1, n_task)));
    return (std::size_t)usable;
}

static inline std::vector<std::pair<py::ssize_t, py::ssize_t>>
split_frame_range(py::ssize_t start, py::ssize_t stop, std::size_t n_slice) {
    const py::ssize_t total = stop - start;
    if (total <= 0) return {};

    n_slice = std::max<std::size_t>(1, std::min<std::size_t>(n_slice, (std::size_t)total));
    std::vector<std::pair<py::ssize_t, py::ssize_t>> out;
    out.reserve(n_slice);

    const py::ssize_t base = total / (py::ssize_t)n_slice;
    const py::ssize_t rem = total % (py::ssize_t)n_slice;
    py::ssize_t cur = start;
    for (std::size_t i = 0; i < n_slice; ++i) {
        const py::ssize_t len = base + ((py::ssize_t)i < rem ? 1 : 0);
        const py::ssize_t nxt = cur + len;
        if (nxt > cur) out.emplace_back(cur, nxt);
        cur = nxt;
    }
    return out;
}

// ------------------------ kernels ------------------------

template <typename T>
static py::tuple ssf_shell_static_impl(
    const py::buffer_info& A,          // (T, NA, 3) scaled
    const py::buffer_info& B,          // (T, NB, 3) scaled
    const py::buffer_info& K,          // (NK, 3) int32 hkl
    const py::buffer_info& SH,         // (NK,) int32 shell id (precomputed, in-range)
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins
) {
    const int64_t n_frame = static_cast<int64_t>(A.shape[0]);
    const int64_t NA = static_cast<int64_t>(A.shape[1]);
    const int64_t NB = static_cast<int64_t>(B.shape[1]);
    const int64_t NK = static_cast<int64_t>(K.shape[0]);

    if (NA <= 0 || NB <= 0) throw std::runtime_error("NA/NB must be positive.");
    if (nbins <= 0) throw std::runtime_error("nbins must be >= 1.");
    if (start < 0) start = 0;
    if (stop > (py::ssize_t)n_frame) stop = (py::ssize_t)n_frame;
    if (stop <= start) throw std::runtime_error("Invalid frame range.");

    py::array_t<double> sum_shell(static_cast<py::ssize_t>(nbins));
    py::array_t<int64_t> count_shell(static_cast<py::ssize_t>(nbins));
    auto Sinfo = sum_shell.request();
    auto Cinfo = count_shell.request();
    double* Sp = static_cast<double*>(Sinfo.ptr);
    int64_t* Cp = static_cast<int64_t*>(Cinfo.ptr);
    std::fill(Sp, Sp + nbins, 0.0);
    std::fill(Cp, Cp + nbins, int64_t(0));

    const T* posA = static_cast<const T*>(A.ptr);
    const T* posB = static_cast<const T*>(B.ptr);
    const int32_t* hkl = static_cast<const int32_t*>(K.ptr);
    const int32_t* shell_id = static_cast<const int32_t*>(SH.ptr);

    // ---------- IMPORTANT OPTIMIZATION ----------
    // shell_id comes from prepare_ssf.ssf_cal() and is already filtered & binned.
    // Therefore count per shell does NOT depend on positions:
    // count_shell[sid] = (#q in shell sid) * (#frames in this chunk)
    for (int64_t q = 0; q < NK; ++q) {
        const int32_t sid = shell_id[q];
        if (sid < 0 || sid >= nbins) {
            throw std::runtime_error("shell_id contains out-of-range sid; expect [0, nbins).");
        }
        Cp[sid] += 1;
    }
    const int64_t nF = static_cast<int64_t>(stop - start);
    for (int b = 0; b < nbins; ++b) Cp[b] *= nF;

    constexpr double TWO_PI = 6.283185307179586476925286766559;
    const double inv_NA = 1.0 / static_cast<double>(NA);
    const double inv_sqrt_NaNb = 1.0 / std::sqrt(static_cast<double>(NA) * static_cast<double>(NB));

    {
        py::gil_scoped_release nogil;
        for (py::ssize_t t = start; t < stop; ++t) {
            const T* A_frame = posA + (static_cast<int64_t>(t) * NA * 3);
            const T* B_frame = posB + (static_cast<int64_t>(t) * NB * 3);

            for (int64_t q = 0; q < NK; ++q) {
                const int32_t sid = shell_id[q];

                const int32_t h = hkl[q * 3 + 0];
                const int32_t k = hkl[q * 3 + 1];
                const int32_t l = hkl[q * 3 + 2];

                // phase uses scaled coords only: 2*pi*n·s
                const double hh = TWO_PI * static_cast<double>(h);
                const double kk = TWO_PI * static_cast<double>(k);
                const double ll = TWO_PI * static_cast<double>(l);

                double a_re = 0.0, a_im = 0.0;
                {
                    const T* p = A_frame;
                    for (int64_t i = 0; i < NA; ++i) {
                        const double sx = static_cast<double>(p[0]);
                        const double sy = static_cast<double>(p[1]);
                        const double sz = static_cast<double>(p[2]);
                        p += 3;
                        const double phase = hh * sx + kk * sy + ll * sz;
                        double s, c;
                        fast_sincos(phase, &s, &c);
                        a_re += c;
                        a_im += s;
                    }
                }

                double val = 0.0;
                if (same) {
                    val = (a_re * a_re + a_im * a_im) * inv_NA;
                } else {
                    double b_re = 0.0, b_im = 0.0;
                    const T* p = B_frame;
                    for (int64_t j = 0; j < NB; ++j) {
                        const double sx = static_cast<double>(p[0]);
                        const double sy = static_cast<double>(p[1]);
                        const double sz = static_cast<double>(p[2]);
                        p += 3;
                        const double phase = hh * sx + kk * sy + ll * sz;
                        double s, c;
                        fast_sincos(phase, &s, &c);
                        b_re += c;
                        b_im += s;
                    }
                    val = (a_re * b_re + a_im * b_im) * inv_sqrt_NaNb;
                }

                Sp[sid] += val;
            }
        }
    }

    return py::make_tuple(sum_shell, count_shell);
}

template <typename T>
static py::tuple ssf_shell_varcell_impl(
    const py::buffer_info& A,          // (T, NA, 3) scaled
    const py::buffer_info& B,          // (T, NB, 3) scaled
    const py::buffer_info& CELL,       // (T, 3, 3) float64 row-vectors cell
    const py::buffer_info& K,          // (NK, 3) int32 hkl
    double k_min,
    double k_max,
    double dk_shell,
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins
) {
    const int64_t n_frame = static_cast<int64_t>(A.shape[0]);
    const int64_t NA = static_cast<int64_t>(A.shape[1]);
    const int64_t NB = static_cast<int64_t>(B.shape[1]);
    const int64_t NK = static_cast<int64_t>(K.shape[0]);

    if (NA <= 0 || NB <= 0) throw std::runtime_error("NA/NB must be positive.");
    if (nbins <= 0) throw std::runtime_error("nbins must be >= 1.");
    if (dk_shell <= 0.0) throw std::runtime_error("dk_shell must be > 0.");
    if (k_max <= 0.0 || k_min < 0.0 || k_min >= k_max) throw std::runtime_error("Invalid k_min/k_max.");
    if (start < 0) start = 0;
    if (stop > (py::ssize_t)n_frame) stop = (py::ssize_t)n_frame;
    if (stop <= start) throw std::runtime_error("Invalid frame range.");

    py::array_t<double> sum_shell(static_cast<py::ssize_t>(nbins));
    py::array_t<int64_t> count_shell(static_cast<py::ssize_t>(nbins));
    auto Sinfo = sum_shell.request();
    auto Cinfo = count_shell.request();
    double* Sp = static_cast<double*>(Sinfo.ptr);
    int64_t* Cp = static_cast<int64_t*>(Cinfo.ptr);
    std::fill(Sp, Sp + nbins, 0.0);
    std::fill(Cp, Cp + nbins, int64_t(0));

    const T* posA = static_cast<const T*>(A.ptr);
    const T* posB = static_cast<const T*>(B.ptr);
    const double* cell = static_cast<const double*>(CELL.ptr);
    const int32_t* hkl = static_cast<const int32_t*>(K.ptr);

    constexpr double TWO_PI = 6.283185307179586476925286766559;
    const double inv_NA = 1.0 / static_cast<double>(NA);
    const double inv_sqrt_NaNb = 1.0 / std::sqrt(static_cast<double>(NA) * static_cast<double>(NB));
    const double inv_dk = 1.0 / dk_shell;
    constexpr double eps = 1e-12;

    // ---------- IMPORTANT OPTIMIZATION ----------
    // Compare q^2 first; only sqrt() if inside range.
    const double kmin2 = (k_min + eps) * (k_min + eps);
    const double kmax2 = (k_max + eps) * (k_max + eps);

    {
        py::gil_scoped_release nogil;
    for (py::ssize_t t = start; t < stop; ++t) {
        const T* A_frame = posA + (static_cast<int64_t>(t) * NA * 3);
        const T* B_frame = posB + (static_cast<int64_t>(t) * NB * 3);

        const double* c = cell + (static_cast<int64_t>(t) * 9);

        // cell^T in row-major
        double ct[9] = {
            c[0], c[3], c[6],
            c[1], c[4], c[7],
            c[2], c[5], c[8]
        };
        double inv_ct[9];
        if (!invert_3x3(ct, inv_ct)) {
            throw std::runtime_error("Singular cell encountered in variable-cell SSF.");
        }

        // rec = 2*pi*inv(cell^T)
        double rec[9];
        for (int i = 0; i < 9; ++i) rec[i] = TWO_PI * inv_ct[i];

        for (int64_t q = 0; q < NK; ++q) {
            const int32_t h = hkl[q * 3 + 0];
            const int32_t k = hkl[q * 3 + 1];
            const int32_t l = hkl[q * 3 + 2];

            const double hd = static_cast<double>(h);
            const double kd = static_cast<double>(k);
            const double ld = static_cast<double>(l);

            // q = [h,k,l] * rec  (row vector times matrix)
            const double qx = hd * rec[0] + kd * rec[3] + ld * rec[6];
            const double qy = hd * rec[1] + kd * rec[4] + ld * rec[7];
            const double qz = hd * rec[2] + kd * rec[5] + ld * rec[8];
            const double qn2 = qx*qx + qy*qy + qz*qz;

            if (!(qn2 > kmin2 && qn2 <= kmax2)) continue;

            const double qn = std::sqrt(qn2);
            const int sid = static_cast<int>(qn * inv_dk);
            if (sid < 0 || sid >= nbins) continue;

            // phase uses scaled coords only: 2*pi*n·s
            const double hh = TWO_PI * hd;
            const double kk = TWO_PI * kd;
            const double ll = TWO_PI * ld;

            double a_re = 0.0, a_im = 0.0;
            {
                const T* p = A_frame;
                for (int64_t i = 0; i < NA; ++i) {
                    const double sx = static_cast<double>(p[0]);
                    const double sy = static_cast<double>(p[1]);
                    const double sz = static_cast<double>(p[2]);
                    p += 3;
                    const double phase = hh * sx + kk * sy + ll * sz;
                    double s, ccs;
                    fast_sincos(phase, &s, &ccs);
                    a_re += ccs;
                    a_im += s;
                }
            }

            double val = 0.0;
            if (same) {
                val = (a_re * a_re + a_im * a_im) * inv_NA;
            } else {
                double b_re = 0.0, b_im = 0.0;
                const T* p = B_frame;
                for (int64_t j = 0; j < NB; ++j) {
                    const double sx = static_cast<double>(p[0]);
                    const double sy = static_cast<double>(p[1]);
                    const double sz = static_cast<double>(p[2]);
                    p += 3;
                    const double phase = hh * sx + kk * sy + ll * sz;
                    double s, ccs;
                    fast_sincos(phase, &s, &ccs);
                    b_re += ccs;
                    b_im += s;
                }
                val = (a_re * b_re + a_im * b_im) * inv_sqrt_NaNb;
            }

            Sp[sid] += val;
            Cp[sid] += 1;
        }
    }
    }

    return py::make_tuple(sum_shell, count_shell);
}

// ------------------------ pybind wrappers ------------------------

template <typename T>
static py::tuple ssf_shell_static_dispatch(
    const py::buffer_info& A,
    const py::buffer_info& B,
    const py::buffer_info& K,
    const py::buffer_info& SH,
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins,
    std::int64_t n_threads
) {
    const py::ssize_t Tn = A.shape[0];
    if (start < 0) start = 0;
    if (stop > Tn) stop = Tn;
    if (stop <= start) throw std::runtime_error("Invalid frame range.");

    const std::size_t n_use = clamp_thread_count(n_threads, (std::int64_t)(stop - start));
    if (n_use <= 1) {
        return ssf_shell_static_impl<T>(A, B, K, SH, same, start, stop, nbins);
    }

    auto frame_slices = split_frame_range(start, stop, n_use);
    std::vector<py::tuple> partial(frame_slices.size());
    std::vector<std::exception_ptr> eps(frame_slices.size());

    {
        py::gil_scoped_release release;
        std::vector<std::thread> threads;
        threads.reserve(frame_slices.size());
        for (std::size_t ti = 0; ti < frame_slices.size(); ++ti) {
            threads.emplace_back([&, ti]() {
                try {
                    py::gil_scoped_acquire acquire;
                    partial[ti] = ssf_shell_static_impl<T>(
                        A, B, K, SH, same,
                        frame_slices[ti].first, frame_slices[ti].second,
                        nbins
                    );
                } catch (...) {
                    eps[ti] = std::current_exception();
                }
            });
        }
        for (auto& th : threads) th.join();
    }

    for (const auto& ep : eps) {
        if (ep) std::rethrow_exception(ep);
    }

    py::array_t<double> sum_shell(static_cast<py::ssize_t>(nbins));
    py::array_t<int64_t> count_shell(static_cast<py::ssize_t>(nbins));
    auto S = sum_shell.mutable_unchecked<1>();
    auto C = count_shell.mutable_unchecked<1>();
    for (int b = 0; b < nbins; ++b) {
        S(b) = 0.0;
        C(b) = int64_t(0);
    }

    for (const py::tuple& item : partial) {
        auto sum_part = item[0].cast<py::array_t<double, py::array::c_style | py::array::forcecast>>();
        auto cnt_part = item[1].cast<py::array_t<int64_t, py::array::c_style | py::array::forcecast>>();
        auto s = sum_part.unchecked<1>();
        auto c = cnt_part.unchecked<1>();
        for (int b = 0; b < nbins; ++b) {
            S(b) += s(b);
            C(b) += c(b);
        }
    }

    return py::make_tuple(sum_shell, count_shell);
}

template <typename T>
static py::tuple ssf_shell_varcell_dispatch(
    const py::buffer_info& A,
    const py::buffer_info& B,
    const py::buffer_info& CELL,
    const py::buffer_info& K,
    double k_min,
    double k_max,
    double dk_shell,
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins,
    std::int64_t n_threads
) {
    const py::ssize_t Tn = A.shape[0];
    if (start < 0) start = 0;
    if (stop > Tn) stop = Tn;
    if (stop <= start) throw std::runtime_error("Invalid frame range.");

    const std::size_t n_use = clamp_thread_count(n_threads, (std::int64_t)(stop - start));
    if (n_use <= 1) {
        return ssf_shell_varcell_impl<T>(A, B, CELL, K, k_min, k_max, dk_shell, same, start, stop, nbins);
    }

    auto frame_slices = split_frame_range(start, stop, n_use);
    std::vector<py::tuple> partial(frame_slices.size());
    std::vector<std::exception_ptr> eps(frame_slices.size());

    {
        py::gil_scoped_release release;
        std::vector<std::thread> threads;
        threads.reserve(frame_slices.size());
        for (std::size_t ti = 0; ti < frame_slices.size(); ++ti) {
            threads.emplace_back([&, ti]() {
                try {
                    py::gil_scoped_acquire acquire;
                    partial[ti] = ssf_shell_varcell_impl<T>(
                        A, B, CELL, K,
                        k_min, k_max, dk_shell, same,
                        frame_slices[ti].first, frame_slices[ti].second,
                        nbins
                    );
                } catch (...) {
                    eps[ti] = std::current_exception();
                }
            });
        }
        for (auto& th : threads) th.join();
    }

    for (const auto& ep : eps) {
        if (ep) std::rethrow_exception(ep);
    }

    py::array_t<double> sum_shell(static_cast<py::ssize_t>(nbins));
    py::array_t<int64_t> count_shell(static_cast<py::ssize_t>(nbins));
    auto S = sum_shell.mutable_unchecked<1>();
    auto C = count_shell.mutable_unchecked<1>();
    for (int b = 0; b < nbins; ++b) {
        S(b) = 0.0;
        C(b) = int64_t(0);
    }

    for (const py::tuple& item : partial) {
        auto sum_part = item[0].cast<py::array_t<double, py::array::c_style | py::array::forcecast>>();
        auto cnt_part = item[1].cast<py::array_t<int64_t, py::array::c_style | py::array::forcecast>>();
        auto s = sum_part.unchecked<1>();
        auto c = cnt_part.unchecked<1>();
        for (int b = 0; b < nbins; ++b) {
            S(b) += s(b);
            C(b) += c(b);
        }
    }

    return py::make_tuple(sum_shell, count_shell);
}

static py::tuple ssf_shell_static(
    py::array posA,
    py::array posB,
    py::array k_int,
    py::array shell_id,
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins,
    std::int64_t n_threads
) {
    auto A = posA.request();
    auto B = posB.request();
    auto K = k_int.request();
    auto SH = shell_id.request();

    if (A.ndim != 3 || A.shape[2] != 3) throw std::runtime_error("posA must have shape (T, NA, 3).");
    if (B.ndim != 3 || B.shape[2] != 3) throw std::runtime_error("posB must have shape (T, NB, 3).");
    if (K.ndim != 2 || K.shape[1] != 3) throw std::runtime_error("k_int must have shape (NK, 3).");
    if (SH.ndim != 1 || SH.shape[0] != K.shape[0]) throw std::runtime_error("shell_id must have shape (NK,) and match k_int.");
    if (A.shape[0] != B.shape[0]) throw std::runtime_error("posA and posB must have same number of frames.");

    const bool A_f32 = (posA.dtype().kind() == 'f' && posA.dtype().itemsize() == 4);
    const bool A_f64 = (posA.dtype().kind() == 'f' && posA.dtype().itemsize() == 8);
    const bool B_ok = (posB.dtype().kind() == 'f' && posB.dtype().itemsize() == posA.dtype().itemsize());
    if (!(A_f32 || A_f64)) throw std::runtime_error("posA dtype must be float32 or float64.");
    if (!B_ok) throw std::runtime_error("posB dtype must match posA dtype.");
    if (!(k_int.dtype().kind() == 'i' && k_int.dtype().itemsize() == 4)) throw std::runtime_error("k_int dtype must be int32.");
    if (!(shell_id.dtype().kind() == 'i' && shell_id.dtype().itemsize() == 4)) throw std::runtime_error("shell_id dtype must be int32.");

    require_c_contiguous(A, "posA");
    require_c_contiguous(B, "posB");
    require_c_contiguous(K, "k_int");
    require_c_contiguous(SH, "shell_id");

    if (A_f32) return ssf_shell_static_dispatch<float>(A, B, K, SH, same, start, stop, nbins, n_threads);
    else       return ssf_shell_static_dispatch<double>(A, B, K, SH, same, start, stop, nbins, n_threads);
}

static py::tuple ssf_shell_varcell(
    py::array posA,
    py::array posB,
    py::array cell,
    py::array k_int,
    double k_min,
    double k_max,
    double dk_shell,
    bool same,
    py::ssize_t start,
    py::ssize_t stop,
    int nbins,
    std::int64_t n_threads
) {
    auto A = posA.request();
    auto B = posB.request();
    auto CELL = cell.request();
    auto K = k_int.request();

    if (A.ndim != 3 || A.shape[2] != 3) throw std::runtime_error("posA must have shape (T, NA, 3).");
    if (B.ndim != 3 || B.shape[2] != 3) throw std::runtime_error("posB must have shape (T, NB, 3).");
    if (CELL.ndim != 3 || CELL.shape[1] != 3 || CELL.shape[2] != 3) throw std::runtime_error("cell must have shape (T, 3, 3).");
    if (K.ndim != 2 || K.shape[1] != 3) throw std::runtime_error("k_int must have shape (NK, 3).");
    if (A.shape[0] != B.shape[0] || A.shape[0] != CELL.shape[0]) throw std::runtime_error("posA/posB/cell must have same number of frames.");

    const bool A_f32 = (posA.dtype().kind() == 'f' && posA.dtype().itemsize() == 4);
    const bool A_f64 = (posA.dtype().kind() == 'f' && posA.dtype().itemsize() == 8);
    const bool B_ok = (posB.dtype().kind() == 'f' && posB.dtype().itemsize() == posA.dtype().itemsize());
    if (!(A_f32 || A_f64)) throw std::runtime_error("posA dtype must be float32 or float64.");
    if (!B_ok) throw std::runtime_error("posB dtype must match posA dtype.");
    if (!(cell.dtype().kind() == 'f' && cell.dtype().itemsize() == 8)) throw std::runtime_error("cell dtype must be float64.");
    if (!(k_int.dtype().kind() == 'i' && k_int.dtype().itemsize() == 4)) throw std::runtime_error("k_int dtype must be int32.");

    require_c_contiguous(A, "posA");
    require_c_contiguous(B, "posB");
    require_c_contiguous(CELL, "cell");
    require_c_contiguous(K, "k_int");

    if (A_f32) return ssf_shell_varcell_dispatch<float>(A, B, CELL, K, k_min, k_max, dk_shell, same, start, stop, nbins, n_threads);
    else       return ssf_shell_varcell_dispatch<double>(A, B, CELL, K, k_min, k_max, dk_shell, same, start, stop, nbins, n_threads);
}

PYBIND11_MODULE(ssf_ext, m) {
    m.doc() = "Ripple SSF extension: shell-accumulated partial SSF. Provides static-cell and variable-cell kernels.";
    m.def("ssf_shell_static", &ssf_shell_static,
          py::arg("posA"), py::arg("posB"),
          py::arg("k_int"), py::arg("shell_id"),
          py::arg("same"),
          py::arg("start"), py::arg("stop"),
          py::arg("nbins"),
          py::arg("n_threads") = 1);
    m.def("ssf_shell_varcell", &ssf_shell_varcell,
          py::arg("posA"), py::arg("posB"),
          py::arg("cell"),
          py::arg("k_int"),
          py::arg("k_min"), py::arg("k_max"), py::arg("dk_shell"),
          py::arg("same"),
          py::arg("start"), py::arg("stop"),
          py::arg("nbins"),
          py::arg("n_threads") = 1);
}
