#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

namespace py = pybind11;
using ssize = py::ssize_t;

#if defined(_MSC_VER)
  #define RIPPLE_RESTRICT __restrict
#else
  #define RIPPLE_RESTRICT __restrict__
#endif

template <typename T>
static inline bool dtype_is(const py::buffer_info& b) {
    return b.format == py::format_descriptor<T>::format();
}

static inline void require_c_contig_TN3(const py::buffer_info& b, ssize itemsize) {
    if (b.ndim != 3) throw std::invalid_argument("pos must be a 3D array (T,N,3)");
    const ssize T = b.shape[0];
    const ssize N = b.shape[1];
    const ssize C = b.shape[2];
    if (C != 3) throw std::invalid_argument("pos.shape[2] must be 3");
    if (T <= 0 || N <= 0) throw std::invalid_argument("pos has empty dimensions");
    const ssize s0 = b.strides[0];
    const ssize s1 = b.strides[1];
    const ssize s2 = b.strides[2];
    if (!(s2 == itemsize && s1 == 3 * itemsize && s0 == N * 3 * itemsize)) {
        throw std::invalid_argument("pos must be C-contiguous with shape (T,N,3)");
    }
}

static inline void require_c_contig_T3(const py::buffer_info& b, ssize itemsize) {
    if (b.ndim != 2) throw std::invalid_argument("sum_pos must be a 2D array (T,3)");
    const ssize T = b.shape[0];
    const ssize C = b.shape[1];
    if (C != 3) throw std::invalid_argument("sum_pos.shape[1] must be 3");
    if (T <= 0) throw std::invalid_argument("sum_pos has empty dimensions");
    const ssize s0 = b.strides[0];
    const ssize s1 = b.strides[1];
    if (!(s1 == itemsize && s0 == 3 * itemsize)) {
        throw std::invalid_argument("sum_pos must be C-contiguous with shape (T,3)");
    }
}

static inline void symmetrize_3x3_upper_inplace(double* RIPPLE_RESTRICT m) {
    m[3] = m[1];
    m[6] = m[2];
    m[7] = m[5];
}

static inline std::size_t clamp_thread_count(std::int64_t requested, std::int64_t n_task) {
    if (requested < 1) throw std::invalid_argument("n_threads must be >= 1");
    const std::int64_t usable = std::max<std::int64_t>(1, std::min<std::int64_t>(requested, n_task));
    return (std::size_t)usable;
}

static std::vector<std::pair<std::int64_t, std::int64_t>>
balanced_lag_slices(std::int64_t T, std::size_t n_slice) {
    n_slice = std::max<std::size_t>(1, std::min<std::size_t>(n_slice, (std::size_t)std::max<std::int64_t>(1, T)));
    if (n_slice <= 1 || T <= 1) {
        return { { 0, T } };
    }

    const long double total = (long double)T * (long double)(T - 1) * 0.5L;
    const long double two_t_minus_one = 2.0L * (long double)T - 1.0L;

    std::vector<std::int64_t> edges;
    edges.reserve(n_slice + 1);
    edges.push_back(0);

    std::int64_t prev = 0;
    for (std::size_t k = 1; k < n_slice; ++k) {
        const long double target = total * (long double)k / (long double)n_slice;
        long double disc = two_t_minus_one * two_t_minus_one - 8.0L * target;
        if (disc < 0.0L) disc = 0.0L;

        std::int64_t edge = (std::int64_t)std::floor((((two_t_minus_one - std::sqrt(disc)) * 0.5L) + 1.0L));
        edge = std::max<std::int64_t>(edge, prev + 1);
        edge = std::min<std::int64_t>(edge, T - (std::int64_t)(n_slice - k));
        prev = edge;
        edges.push_back(edge);
    }
    edges.push_back(T);

    std::vector<std::pair<std::int64_t, std::int64_t>> out;
    out.reserve(n_slice);
    for (std::size_t i = 0; i + 1 < edges.size(); ++i) {
        if (edges[i] < edges[i + 1]) out.emplace_back(edges[i], edges[i + 1]);
    }
    return out;
}

template <typename T>
static py::array_t<double> cmsd_tensor_impl(py::array pos_, std::int64_t start_lag, std::int64_t stop_lag) {
    auto b = pos_.request();
    require_c_contig_TN3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const ssize N = b.shape[1];
    const std::int64_t Tn_i = (std::int64_t)Tn;
    const size_t stride = (size_t)N * 3u;
    const size_t Nu = (size_t)N;

    if (start_lag < 0 || stop_lag < 0 || start_lag > stop_lag) {
        throw std::invalid_argument("invalid lag range");
    }
    if (stop_lag > Tn_i) stop_lag = Tn_i;
    if (start_lag >= stop_lag) {
        return py::array_t<double>({ (ssize)0, (ssize)3, (ssize)3 });
    }

    const std::int64_t n_lag = stop_lag - start_lag;
    py::array_t<double> out({ (ssize)n_lag, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)n_lag * 9u * sizeof(double));

    const T* RIPPLE_RESTRICT pos = static_cast<const T*>(b.ptr);
    double* RIPPLE_RESTRICT o = static_cast<double*>(outbuf.ptr);
    std::vector<double> sumpos((size_t)Tn * 3u, 0.0);

    py::gil_scoped_release nogil;

    for (std::int64_t t = 0; t < Tn_i; ++t) {
        const T* RIPPLE_RESTRICT a = pos + (size_t)t * stride;
        double sx = 0.0, sy = 0.0, sz = 0.0;
        for (size_t i = 0; i < Nu; ++i) {
            sx += (double)a[0];
            sy += (double)a[1];
            sz += (double)a[2];
            a += 3;
        }
        sumpos[(size_t)t * 3u + 0u] = sx;
        sumpos[(size_t)t * 3u + 1u] = sy;
        sumpos[(size_t)t * 3u + 2u] = sz;
    }

    for (std::int64_t lag = start_lag; lag < stop_lag; ++lag) {
        if (lag == 0) continue;

        const std::int64_t n_origin = Tn_i - lag;
        if (n_origin <= 0) continue;

        double sxx = 0.0, syy = 0.0, szz = 0.0;
        double sxy = 0.0, sxz = 0.0, syz = 0.0;

        for (std::int64_t t0 = 0; t0 < n_origin; ++t0) {
            const std::int64_t t1 = t0 + lag;
            const double dx = sumpos[(size_t)t1 * 3u + 0u] - sumpos[(size_t)t0 * 3u + 0u];
            const double dy = sumpos[(size_t)t1 * 3u + 1u] - sumpos[(size_t)t0 * 3u + 1u];
            const double dz = sumpos[(size_t)t1 * 3u + 2u] - sumpos[(size_t)t0 * 3u + 2u];
            sxx += dx * dx;
            syy += dy * dy;
            szz += dz * dz;
            sxy += dx * dy;
            sxz += dx * dz;
            syz += dy * dz;
        }

        const double inv = 1.0 / ((double)N * (double)n_origin);
        const std::int64_t idx = lag - start_lag;
        double* RIPPLE_RESTRICT m = o + (size_t)idx * 9u;
        m[0] = sxx * inv;
        m[4] = syy * inv;
        m[8] = szz * inv;
        m[1] = sxy * inv;
        m[2] = sxz * inv;
        m[5] = syz * inv;
        symmetrize_3x3_upper_inplace(m);
    }

    return out;
}

template <typename T>
static py::array_t<double> cmsd_tensor_sumpos_impl(py::array sum_pos_, std::int64_t N_sel, std::int64_t n_threads) {
    if (N_sel <= 0) throw std::invalid_argument("N_sel must be positive");

    auto b = sum_pos_.request();
    require_c_contig_T3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const std::int64_t Tn_i = (std::int64_t)Tn;

    py::array_t<double> out({ Tn, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)Tn_i * 9u * sizeof(double));

    if (Tn_i <= 1) {
        return out;
    }

    const std::size_t n_use = clamp_thread_count(n_threads, Tn_i - 1);
    const T* RIPPLE_RESTRICT sp = static_cast<const T*>(b.ptr);
    double* RIPPLE_RESTRICT o = static_cast<double*>(outbuf.ptr);
    const auto slices = balanced_lag_slices(Tn_i, n_use);

    py::gil_scoped_release nogil;

    if (n_use == 1) {
        for (std::int64_t lag = 1; lag < Tn_i; ++lag) {
            const std::int64_t n_origin = Tn_i - lag;
            double sxx = 0.0, syy = 0.0, szz = 0.0;
            double sxy = 0.0, sxz = 0.0, syz = 0.0;

            for (std::int64_t t0 = 0; t0 < n_origin; ++t0) {
                const std::int64_t t1 = t0 + lag;
                const double dx = (double)sp[(size_t)t1 * 3u + 0u] - (double)sp[(size_t)t0 * 3u + 0u];
                const double dy = (double)sp[(size_t)t1 * 3u + 1u] - (double)sp[(size_t)t0 * 3u + 1u];
                const double dz = (double)sp[(size_t)t1 * 3u + 2u] - (double)sp[(size_t)t0 * 3u + 2u];
                sxx += dx * dx;
                syy += dy * dy;
                szz += dz * dz;
                sxy += dx * dy;
                sxz += dx * dz;
                syz += dy * dz;
            }

            const double inv = 1.0 / ((double)N_sel * (double)n_origin);
            double* RIPPLE_RESTRICT m = o + (size_t)lag * 9u;
            m[0] = sxx * inv;
            m[4] = syy * inv;
            m[8] = szz * inv;
            m[1] = sxy * inv;
            m[2] = sxz * inv;
            m[5] = syz * inv;
            symmetrize_3x3_upper_inplace(m);
        }
        return out;
    }

    std::vector<std::thread> threads;
    std::vector<std::exception_ptr> eps(n_use);
    threads.reserve(n_use);

    for (std::size_t ti = 0; ti < n_use; ++ti) {
        threads.emplace_back([&, ti]() {
            try {
                const std::int64_t start_lag = slices[ti].first;
                const std::int64_t stop_lag = slices[ti].second;

                for (std::int64_t lag = start_lag; lag < stop_lag; ++lag) {
                    if (lag == 0) continue;

                    const std::int64_t n_origin = Tn_i - lag;
                    if (n_origin <= 0) continue;

                    double sxx = 0.0, syy = 0.0, szz = 0.0;
                    double sxy = 0.0, sxz = 0.0, syz = 0.0;

                    for (std::int64_t t0 = 0; t0 < n_origin; ++t0) {
                        const std::int64_t t1 = t0 + lag;
                        const double dx = (double)sp[(size_t)t1 * 3u + 0u] - (double)sp[(size_t)t0 * 3u + 0u];
                        const double dy = (double)sp[(size_t)t1 * 3u + 1u] - (double)sp[(size_t)t0 * 3u + 1u];
                        const double dz = (double)sp[(size_t)t1 * 3u + 2u] - (double)sp[(size_t)t0 * 3u + 2u];
                        sxx += dx * dx;
                        syy += dy * dy;
                        szz += dz * dz;
                        sxy += dx * dy;
                        sxz += dx * dz;
                        syz += dy * dz;
                    }

                    const double inv = 1.0 / ((double)N_sel * (double)n_origin);
                    double* RIPPLE_RESTRICT m = o + (size_t)lag * 9u;
                    m[0] = sxx * inv;
                    m[4] = syy * inv;
                    m[8] = szz * inv;
                    m[1] = sxy * inv;
                    m[2] = sxz * inv;
                    m[5] = syz * inv;
                    symmetrize_3x3_upper_inplace(m);
                }
            } catch (...) {
                eps[ti] = std::current_exception();
            }
        });
    }

    for (auto& th : threads) th.join();
    for (const auto& ep : eps) {
        if (ep) std::rethrow_exception(ep);
    }

    return out;
}

template <typename T>
static py::array_t<double> cmsd_t1_partial_sumpos_impl(py::array sum_pos_, std::int64_t start_t1, std::int64_t stop_t1) {
    auto b = sum_pos_.request();
    require_c_contig_T3(b, (ssize)sizeof(T));
    const ssize Tn = b.shape[0];
    const std::int64_t Tn_i = (std::int64_t)Tn;

    if (start_t1 < 0 || stop_t1 < 0 || start_t1 > stop_t1 || stop_t1 > Tn_i) {
        throw std::invalid_argument("invalid t1 range");
    }

    py::array_t<double> out({ (ssize)stop_t1, (ssize)3, (ssize)3 });
    auto outbuf = out.request();
    std::memset(outbuf.ptr, 0, (size_t)stop_t1 * 9u * sizeof(double));

    const T* RIPPLE_RESTRICT sp = static_cast<const T*>(b.ptr);
    double* RIPPLE_RESTRICT outp = static_cast<double*>(outbuf.ptr);

    py::gil_scoped_release nogil;

    for (std::int64_t t1 = start_t1; t1 < stop_t1; ++t1) {
        const double s1x = (double)sp[(size_t)t1 * 3u + 0u];
        const double s1y = (double)sp[(size_t)t1 * 3u + 1u];
        const double s1z = (double)sp[(size_t)t1 * 3u + 2u];
        for (std::int64_t t0 = 0; t0 < t1; ++t0) {
            const std::int64_t lag = t1 - t0;
            const double dx = s1x - (double)sp[(size_t)t0 * 3u + 0u];
            const double dy = s1y - (double)sp[(size_t)t0 * 3u + 1u];
            const double dz = s1z - (double)sp[(size_t)t0 * 3u + 2u];

            double* RIPPLE_RESTRICT m = outp + (size_t)lag * 9u;
            m[0] += dx * dx;
            m[4] += dy * dy;
            m[8] += dz * dz;
            m[1] += dx * dy;
            m[2] += dx * dz;
            m[5] += dy * dz;
        }
    }

    for (std::int64_t lag = 1; lag < stop_t1; ++lag) {
        double* RIPPLE_RESTRICT m = outp + (size_t)lag * 9u;
        symmetrize_3x3_upper_inplace(m);
    }

    return out;
}

static py::array_t<double> cmsd_tensor(py::array pos, std::int64_t start_lag, std::int64_t stop_lag) {
    const auto b = pos.request();
    if (dtype_is<float>(b)) return cmsd_tensor_impl<float>(pos, start_lag, stop_lag);
    if (dtype_is<double>(b)) return cmsd_tensor_impl<double>(pos, start_lag, stop_lag);
    throw std::invalid_argument("pos dtype must be float32 or float64");
}

static py::array_t<double> cmsd_tensor_sumpos(py::array sum_pos, std::int64_t N_sel, std::int64_t n_threads) {
    const auto b = sum_pos.request();
    if (dtype_is<float>(b)) return cmsd_tensor_sumpos_impl<float>(sum_pos, N_sel, n_threads);
    if (dtype_is<double>(b)) return cmsd_tensor_sumpos_impl<double>(sum_pos, N_sel, n_threads);
    throw std::invalid_argument("sum_pos dtype must be float32 or float64");
}

static py::array_t<double> cmsd_t1_partial_sumpos(py::array sum_pos, std::int64_t start_t1, std::int64_t stop_t1) {
    const auto b = sum_pos.request();
    if (dtype_is<float>(b)) return cmsd_t1_partial_sumpos_impl<float>(sum_pos, start_t1, stop_t1);
    if (dtype_is<double>(b)) return cmsd_t1_partial_sumpos_impl<double>(sum_pos, start_t1, stop_t1);
    throw std::invalid_argument("sum_pos dtype must be float32 or float64");
}

PYBIND11_MODULE(cmsd_ext, m) {
    m.doc() = "Collective MSD tensor kernels";
    m.def("cmsd_tensor", &cmsd_tensor, py::arg("pos"), py::arg("start_lag"), py::arg("stop_lag"),
          "Compute cMSD tensor curve for lags in [start_lag, stop_lag). Returns (n_lag,3,3) float64.");
    m.def("cmsd_tensor_sumpos", &cmsd_tensor_sumpos, py::arg("sum_pos"), py::arg("N_sel"), py::arg("n_threads"),
          "Compute the full cMSD tensor curve for lags 0..T-1 from precomputed sum_pos using C++ threads.");
    m.def("cmsd_t1_partial_sumpos", &cmsd_t1_partial_sumpos, py::arg("sum_pos"), py::arg("start_t1"), py::arg("stop_t1"),
          "Compute partial numerator sums over a slice of t1 for cMSD, given precomputed sum_pos (T,3). Returns (stop_t1,3,3) float64.");
}
