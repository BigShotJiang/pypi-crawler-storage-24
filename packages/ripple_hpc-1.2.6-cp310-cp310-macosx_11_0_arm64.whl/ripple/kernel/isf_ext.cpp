#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <exception>
#include <limits>
#include <stdexcept>
#include <thread>
#include <vector>

namespace py = pybind11;

static constexpr double TWO_PI = 6.283185307179586476925286766559;

static inline int checked_int_from_ssize(py::ssize_t x) {
    if (x < 0 || x > (py::ssize_t)std::numeric_limits<int>::max()) {
        throw std::invalid_argument("size exceeds int range");
    }
    return (int)x;
}

static inline void fast_sincos(double x, double* s, double* c) {
#if defined(__GLIBC__) && !defined(_MSC_VER)
    ::sincos(x, s, c);
#else
    *s = std::sin(x);
    *c = std::cos(x);
#endif
}

static inline bool invert3x3(const double a[3][3], double inva[3][3]) {
    const double a00 = a[0][0], a01 = a[0][1], a02 = a[0][2];
    const double a10 = a[1][0], a11 = a[1][1], a12 = a[1][2];
    const double a20 = a[2][0], a21 = a[2][1], a22 = a[2][2];

    const double c00 = (a11 * a22 - a12 * a21);
    const double c01 = -(a10 * a22 - a12 * a20);
    const double c02 = (a10 * a21 - a11 * a20);

    const double c10 = -(a01 * a22 - a02 * a21);
    const double c11 = (a00 * a22 - a02 * a20);
    const double c12 = -(a00 * a21 - a01 * a20);

    const double c20 = (a01 * a12 - a02 * a11);
    const double c21 = -(a00 * a12 - a02 * a10);
    const double c22 = (a00 * a11 - a01 * a10);

    const double det = a00 * c00 + a01 * c01 + a02 * c02;
    if (std::abs(det) < 1e-18) {
        return false;
    }

    const double invdet = 1.0 / det;
    inva[0][0] = c00 * invdet; inva[0][1] = c10 * invdet; inva[0][2] = c20 * invdet;
    inva[1][0] = c01 * invdet; inva[1][1] = c11 * invdet; inva[1][2] = c21 * invdet;
    inva[2][0] = c02 * invdet; inva[2][1] = c12 * invdet; inva[2][2] = c22 * invdet;
    return true;
}

static inline void mul3x3(const double A[3][3], const double B[3][3], double C[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            C[i][j] = A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j];
        }
    }
}

static inline void mul_rowvec3(const double v[3], const double M[3][3], double out[3]) {
    out[0] = v[0] * M[0][0] + v[1] * M[1][0] + v[2] * M[2][0];
    out[1] = v[0] * M[0][1] + v[1] * M[1][1] + v[2] * M[2][1];
    out[2] = v[0] * M[0][2] + v[1] * M[1][2] + v[2] * M[2][2];
}

static inline void copy_cell(const double* src9, double out[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            out[i][j] = src9[(size_t)i * 3 + (size_t)j];
        }
    }
}

static inline double phase_from_n_ds(const int32_t* n, const double ds[3]) {
    return TWO_PI * (
        (double)n[0] * ds[0] +
        (double)n[1] * ds[1] +
        (double)n[2] * ds[2]
    );
}

static inline void reciprocal_from_invcell(const double invcell[3][3], double rec[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            rec[i][j] = TWO_PI * invcell[j][i];
        }
    }
}

static inline int shell_id_from_q(
    const int32_t* n,
    const double rec[3][3],
    double qmin2,
    double qmax2,
    double inv_dq,
    int nbins
) {
    const double nx = (double)n[0];
    const double ny = (double)n[1];
    const double nz = (double)n[2];

    const double qx = nx * rec[0][0] + ny * rec[1][0] + nz * rec[2][0];
    const double qy = nx * rec[0][1] + ny * rec[1][1] + nz * rec[2][1];
    const double qz = nx * rec[0][2] + ny * rec[1][2] + nz * rec[2][2];
    const double qn2 = qx * qx + qy * qy + qz * qz;
    if (!(qn2 > qmin2 && qn2 <= qmax2)) {
        return -1;
    }

    const double qn = std::sqrt(qn2);
    const int sid = (int)(qn * inv_dq);
    if (sid < 0 || sid >= nbins) {
        return -1;
    }
    return sid;
}

static inline bool build_valid_q_list_varcell(
    const int32_t* Q,
    int NK,
    const double cell1[3][3],
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    double inv_cell1[3][3],
    std::vector<int32_t>& idx,
    std::vector<int32_t>& sid,
    std::vector<int64_t>& shell_counts
) {
    idx.clear();
    sid.clear();
    shell_counts.assign((size_t)nbins, int64_t(0));

    if (!invert3x3(cell1, inv_cell1)) {
        return false;
    }

    double rec[3][3];
    reciprocal_from_invcell(inv_cell1, rec);

    const double eps = 1e-12;
    const double qmin2 = (q_min + eps) * (q_min + eps);
    const double qmax2 = (q_max + eps) * (q_max + eps);
    const double inv_dq = 1.0 / dq_shell;

    idx.reserve((size_t)NK);
    sid.reserve((size_t)NK);
    for (int qi = 0; qi < NK; ++qi) {
        const int sid_i = shell_id_from_q(Q + (size_t)qi * 3, rec, qmin2, qmax2, inv_dq, nbins);
        if (sid_i >= 0) {
            idx.push_back((int32_t)qi);
            sid.push_back((int32_t)sid_i);
            shell_counts[(size_t)sid_i] += 1;
        }
    }
    return true;
}

static inline void validate_selected_lags(const int32_t* lags, int K, int T_i) {
    if (K < 1) {
        throw std::invalid_argument("lags must be non-empty");
    }
    int32_t prev = -1;
    for (int ki = 0; ki < K; ++ki) {
        const int32_t li = lags[(size_t)ki];
        if (li < 0 || li >= T_i) {
            throw std::invalid_argument("lags must satisfy 0 <= lag < T");
        }
        if (li <= prev) {
            throw std::invalid_argument("lags must be strictly increasing");
        }
        prev = li;
    }
}

template <typename Tpos>
static py::tuple isf_self_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posA_unwrap,
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> q_int,
    py::object shell_id_obj,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices,
    bool cell_static
) {
    if (nbins <= 0 || dq_shell <= 0.0 || q_max <= 0.0) {
        throw std::invalid_argument("nbins, dq_shell and q_max must be positive");
    }

    const auto bU = posA_unwrap.request();
    const auto bC = cell.request();
    const auto bQ = q_int.request();
    const auto bL = lags.request();
    const auto bS = t1_slices.request();

    if (bU.ndim != 3 || bU.shape[2] != 3) throw std::invalid_argument("posA_unwrap must be (T, NA, 3)");
    if (bC.ndim != 3 || bC.shape[1] != 3 || bC.shape[2] != 3) throw std::invalid_argument("cell must be (T, 3, 3)");
    if (bQ.ndim != 2 || bQ.shape[1] != 3) throw std::invalid_argument("q_int must be (NQ, 3)");
    if (bL.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    if (bS.ndim != 2 || bS.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S, 2)");
    if (bC.shape[0] != bU.shape[0]) throw std::invalid_argument("cell length mismatch");

    const int T_i = checked_int_from_ssize(bU.shape[0]);
    const int NA_i = checked_int_from_ssize(bU.shape[1]);
    const int NQ_i = checked_int_from_ssize(bQ.shape[0]);
    const int K_i = checked_int_from_ssize(bL.shape[0]);
    const int S_i = checked_int_from_ssize(bS.shape[0]);
    if (T_i < 1 || NA_i < 1 || NQ_i < 1 || K_i < 1) throw std::invalid_argument("empty input");

    const Tpos* U = static_cast<const Tpos*>(bU.ptr);
    const double* C = static_cast<const double*>(bC.ptr);
    const int32_t* Q = static_cast<const int32_t*>(bQ.ptr);
    const int32_t* lag_ptr = static_cast<const int32_t*>(bL.ptr);
    const int32_t* slices = static_cast<const int32_t*>(bS.ptr);
    validate_selected_lags(lag_ptr, K_i, T_i);

    const int32_t* shell_id_ptr = nullptr;
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> shell_id;
    std::vector<int32_t> static_idx;
    std::vector<int64_t> static_shell_counts;
    double inv_cell_static[3][3];

    if (cell_static) {
        if (shell_id_obj.is_none()) {
            throw std::invalid_argument("shell_id must be provided when cell_static=True");
        }
        shell_id = shell_id_obj.cast<py::array_t<int32_t, py::array::c_style | py::array::forcecast>>();
        const auto bSid = shell_id.request();
        if (bSid.ndim != 1 || bSid.shape[0] != bQ.shape[0]) {
            throw std::invalid_argument("shell_id must be (NQ,) and match q_int");
        }
        shell_id_ptr = static_cast<const int32_t*>(bSid.ptr);

        double cell0[3][3];
        copy_cell(C, cell0);
        if (!invert3x3(cell0, inv_cell_static)) {
            throw std::runtime_error("Singular cell encountered in static self ISF.");
        }

        static_idx.resize((size_t)NQ_i);
        static_shell_counts.assign((size_t)nbins, int64_t(0));
        for (int qi = 0; qi < NQ_i; ++qi) {
            static_idx[(size_t)qi] = (int32_t)qi;
            const int sid_i = shell_id_ptr[(size_t)qi];
            if (sid_i < 0 || sid_i >= nbins) {
                throw std::invalid_argument("shell_id contains out-of-range values");
            }
            static_shell_counts[(size_t)sid_i] += 1;
        }
    }

    py::array_t<double> Fs({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> q_count({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> cnt_s((py::ssize_t)K_i);
    auto* Hd = Fs.mutable_data();
    auto* Qd = q_count.mutable_data();
    auto* Nd = cnt_s.mutable_data();
    std::fill(Hd, Hd + (size_t)K_i * (size_t)nbins, 0.0);
    std::fill(Qd, Qd + (size_t)K_i * (size_t)nbins, int64_t(0));
    std::fill(Nd, Nd + (size_t)K_i, int64_t(0));

    struct LocalBuf {
        std::vector<double> hist;
        std::vector<int64_t> qcnt;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.hist.assign((size_t)K_i * (size_t)nbins, 0.0);
            L.qcnt.assign((size_t)K_i * (size_t)nbins, int64_t(0));
            L.cnt.assign((size_t)K_i, int64_t(0));

            std::vector<int32_t> valid_idx;
            std::vector<int32_t> valid_sid;
            std::vector<int64_t> shell_counts((size_t)nbins, int64_t(0));
            std::vector<double> ds_arr((size_t)NA_i * 3, 0.0);
            double inv_cell1[3][3];

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const std::vector<int32_t>* idx_ptr = nullptr;
                const std::vector<int32_t>* sid_ptr = nullptr;
                const std::vector<int64_t>* shell_ptr = nullptr;

                if (cell_static) {
                    for (int i = 0; i < 3; ++i) {
                        for (int j = 0; j < 3; ++j) {
                            inv_cell1[i][j] = inv_cell_static[i][j];
                        }
                    }
                    idx_ptr = &static_idx;
                    sid_ptr = nullptr;
                    shell_ptr = &static_shell_counts;
                }
                else {
                    double cell1[3][3];
                    copy_cell(C + (size_t)t1 * 9, cell1);
                    if (!build_valid_q_list_varcell(Q, NQ_i, cell1, q_min, q_max, dq_shell, nbins, inv_cell1, valid_idx, valid_sid, shell_counts)) {
                        continue;
                    }
                    idx_ptr = &valid_idx;
                    sid_ptr = &valid_sid;
                    shell_ptr = &shell_counts;
                }

                const size_t n_valid = idx_ptr->size();
                const size_t base1 = ((size_t)t1 * (size_t)NA_i) * 3;
                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t base0 = ((size_t)t0 * (size_t)NA_i) * 3;
                    L.cnt[(size_t)ki] += 1;

                    int64_t* qrow = &L.qcnt[(size_t)ki * (size_t)nbins];
                    for (int b = 0; b < nbins; ++b) {
                        qrow[(size_t)b] += (*shell_ptr)[(size_t)b];
                    }

                    double* row = &L.hist[(size_t)ki * (size_t)nbins];
                    for (int i = 0; i < NA_i; ++i) {
                        const size_t o1 = base1 + (size_t)i * 3;
                        const size_t o0 = base0 + (size_t)i * 3;
                        const double du[3] = {
                            (double)U[o1 + 0] - (double)U[o0 + 0],
                            (double)U[o1 + 1] - (double)U[o0 + 1],
                            (double)U[o1 + 2] - (double)U[o0 + 2],
                        };
                        const size_t off = (size_t)i * 3;
                        ds_arr[off + 0] = du[0] * inv_cell1[0][0] + du[1] * inv_cell1[1][0] + du[2] * inv_cell1[2][0];
                        ds_arr[off + 1] = du[0] * inv_cell1[0][1] + du[1] * inv_cell1[1][1] + du[2] * inv_cell1[2][1];
                        ds_arr[off + 2] = du[0] * inv_cell1[0][2] + du[1] * inv_cell1[1][2] + du[2] * inv_cell1[2][2];
                    }

                    for (size_t qv = 0; qv < n_valid; ++qv) {
                        const int qi = (int)(*idx_ptr)[qv];
                        const int sid_i = cell_static ? shell_id_ptr[(size_t)qi] : (int)(*sid_ptr)[qv];
                        const int32_t* nq = Q + (size_t)qi * 3;
                        double sum = 0.0;
                        for (int i = 0; i < NA_i; ++i) {
                            const double ds[3] = {
                                ds_arr[(size_t)i * 3 + 0],
                                ds_arr[(size_t)i * 3 + 1],
                                ds_arr[(size_t)i * 3 + 2],
                            };
                            sum += std::cos(phase_from_n_ds(nq, ds));
                        }
                        row[(size_t)sid_i] += sum;
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S_i));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ++ti) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S_i; si += n_use) {
                    compute_slice(si, eps[(size_t)ti]);
                }
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        for (int si = 0; si < S_i; ++si) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;

            for (int ki = 0; ki < K_i; ++ki) {
                Nd[(size_t)ki] += L.cnt[(size_t)ki];
            }

            for (int ki = 0; ki < K_i; ++ki) {
                const int64_t* src_q = &L.qcnt[(size_t)ki * (size_t)nbins];
                int64_t* dst_q = Qd + (size_t)ki * (size_t)nbins;
                for (int b = 0; b < nbins; ++b) {
                    dst_q[(size_t)b] += src_q[(size_t)b];
                }
            }

            for (int ki = 0; ki < K_i; ++ki) {
                const double* src_h = &L.hist[(size_t)ki * (size_t)nbins];
                double* dst_h = Hd + (size_t)ki * (size_t)nbins;
                for (int b = 0; b < nbins; ++b) {
                    dst_h[(size_t)b] += src_h[(size_t)b];
                }
            }
        }

        const double nanv = std::numeric_limits<double>::quiet_NaN();
        for (int ki = 0; ki < K_i; ++ki) {
            double* row = Hd + (size_t)ki * (size_t)nbins;
            const int64_t* qrow = Qd + (size_t)ki * (size_t)nbins;
            for (int b = 0; b < nbins; ++b) {
                const int64_t qn = qrow[(size_t)b];
                if (qn > 0) {
                    row[(size_t)b] /= ((double)NA_i * (double)qn);
                }
                else {
                    row[(size_t)b] = nanv;
                }
            }
        }
    }

    return py::make_tuple(Fs, q_count, cnt_s);
}

template <typename Tpos>
static py::tuple isf_distinct_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posA,
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posB,
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posA_unwrap,
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> q_int,
    py::object shell_id_obj,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    bool same,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices,
    bool cell_static
) {
    if (nbins <= 0 || dq_shell <= 0.0 || q_max <= 0.0) {
        throw std::invalid_argument("nbins, dq_shell and q_max must be positive");
    }

    const auto bA = posA.request();
    const auto bB = posB.request();
    const auto bU = posA_unwrap.request();
    const auto bC = cell.request();
    const auto bQ = q_int.request();
    const auto bL = lags.request();
    const auto bS = t1_slices.request();

    if (bA.ndim != 3 || bA.shape[2] != 3) throw std::invalid_argument("posA must be (T, NA, 3)");
    if (bB.ndim != 3 || bB.shape[2] != 3) throw std::invalid_argument("posB must be (T, NB, 3)");
    if (bU.ndim != 3 || bU.shape[2] != 3) throw std::invalid_argument("posA_unwrap must be (T, NA, 3)");
    if (bC.ndim != 3 || bC.shape[1] != 3 || bC.shape[2] != 3) throw std::invalid_argument("cell must be (T, 3, 3)");
    if (bQ.ndim != 2 || bQ.shape[1] != 3) throw std::invalid_argument("q_int must be (NQ, 3)");
    if (bL.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    if (bS.ndim != 2 || bS.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S, 2)");
    if (bA.shape[0] != bB.shape[0] || bA.shape[0] != bU.shape[0] || bA.shape[0] != bC.shape[0]) {
        throw std::invalid_argument("frame length mismatch");
    }
    if (bA.shape[1] != bU.shape[1]) {
        throw std::invalid_argument("posA and posA_unwrap must select the same atoms");
    }

    const int T_i = checked_int_from_ssize(bA.shape[0]);
    const int NA_i = checked_int_from_ssize(bA.shape[1]);
    const int NB_i = checked_int_from_ssize(bB.shape[1]);
    const int NQ_i = checked_int_from_ssize(bQ.shape[0]);
    const int K_i = checked_int_from_ssize(bL.shape[0]);
    const int S_i = checked_int_from_ssize(bS.shape[0]);
    if (T_i < 1 || NA_i < 1 || NB_i < 1 || NQ_i < 1 || K_i < 1) throw std::invalid_argument("empty input");
    if (same && NB_i != NA_i) {
        throw std::invalid_argument("same=True requires posA and posB to have the same atom count");
    }

    const Tpos* A = static_cast<const Tpos*>(bA.ptr);
    const Tpos* B = static_cast<const Tpos*>(bB.ptr);
    const Tpos* U = static_cast<const Tpos*>(bU.ptr);
    const double* C = static_cast<const double*>(bC.ptr);
    const int32_t* Q = static_cast<const int32_t*>(bQ.ptr);
    const int32_t* lag_ptr = static_cast<const int32_t*>(bL.ptr);
    const int32_t* slices = static_cast<const int32_t*>(bS.ptr);
    validate_selected_lags(lag_ptr, K_i, T_i);

    const int32_t* shell_id_ptr = nullptr;
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> shell_id;
    std::vector<int32_t> static_idx;
    std::vector<int64_t> static_shell_counts;
    double inv_cell_static[3][3];

    if (cell_static) {
        if (shell_id_obj.is_none()) {
            throw std::invalid_argument("shell_id must be provided when cell_static=True");
        }
        shell_id = shell_id_obj.cast<py::array_t<int32_t, py::array::c_style | py::array::forcecast>>();
        const auto bSid = shell_id.request();
        if (bSid.ndim != 1 || bSid.shape[0] != bQ.shape[0]) {
            throw std::invalid_argument("shell_id must be (NQ,) and match q_int");
        }
        shell_id_ptr = static_cast<const int32_t*>(bSid.ptr);

        double cell0[3][3];
        copy_cell(C, cell0);
        if (!invert3x3(cell0, inv_cell_static)) {
            throw std::runtime_error("Singular cell encountered in static distinct ISF.");
        }

        static_idx.resize((size_t)NQ_i);
        static_shell_counts.assign((size_t)nbins, int64_t(0));
        for (int qi = 0; qi < NQ_i; ++qi) {
            static_idx[(size_t)qi] = (int32_t)qi;
            const int sid_i = shell_id_ptr[(size_t)qi];
            if (sid_i < 0 || sid_i >= nbins) {
                throw std::invalid_argument("shell_id contains out-of-range values");
            }
            static_shell_counts[(size_t)sid_i] += 1;
        }
    }

    py::array_t<double> Fd({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> q_count({ (py::ssize_t)K_i, (py::ssize_t)nbins });
    py::array_t<int64_t> cnt_d((py::ssize_t)K_i);
    auto* Hd = Fd.mutable_data();
    auto* Qd = q_count.mutable_data();
    auto* Nd = cnt_d.mutable_data();
    std::fill(Hd, Hd + (size_t)K_i * (size_t)nbins, 0.0);
    std::fill(Qd, Qd + (size_t)K_i * (size_t)nbins, int64_t(0));
    std::fill(Nd, Nd + (size_t)K_i, int64_t(0));

    struct LocalBuf {
        std::vector<double> hist;
        std::vector<int64_t> qcnt;
        std::vector<int64_t> cnt;
    };
    std::vector<LocalBuf> locals((size_t)S_i);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;

            LocalBuf& L = locals[(size_t)si];
            L.hist.assign((size_t)K_i * (size_t)nbins, 0.0);
            L.qcnt.assign((size_t)K_i * (size_t)nbins, int64_t(0));
            L.cnt.assign((size_t)K_i, int64_t(0));

            std::vector<int32_t> valid_idx;
            std::vector<int32_t> valid_sid;
            std::vector<int64_t> shell_counts((size_t)nbins, int64_t(0));
            std::vector<double> rhoB_re;
            std::vector<double> rhoB_im;
            std::vector<double> sA_arr((size_t)NA_i * 3, 0.0);
            std::vector<double> ds_arr;
            if (same) {
                ds_arr.assign((size_t)NA_i * 3, 0.0);
            }
            double inv_cell1[3][3];
            double T01[3][3];

            for (int t1 = start_t1; t1 < stop_t1; ++t1) {
                const std::vector<int32_t>* idx_ptr = nullptr;
                const std::vector<int32_t>* sid_ptr = nullptr;
                const std::vector<int64_t>* shell_ptr = nullptr;

                if (cell_static) {
                    for (int i = 0; i < 3; ++i) {
                        for (int j = 0; j < 3; ++j) {
                            inv_cell1[i][j] = inv_cell_static[i][j];
                        }
                    }
                    idx_ptr = &static_idx;
                    sid_ptr = nullptr;
                    shell_ptr = &static_shell_counts;
                }
                else {
                    double cell1[3][3];
                    copy_cell(C + (size_t)t1 * 9, cell1);
                    if (!build_valid_q_list_varcell(Q, NQ_i, cell1, q_min, q_max, dq_shell, nbins, inv_cell1, valid_idx, valid_sid, shell_counts)) {
                        continue;
                    }
                    idx_ptr = &valid_idx;
                    sid_ptr = &valid_sid;
                    shell_ptr = &shell_counts;
                }

                const size_t n_valid = idx_ptr->size();
                rhoB_re.assign(n_valid, 0.0);
                rhoB_im.assign(n_valid, 0.0);

                const size_t baseB = ((size_t)t1 * (size_t)NB_i) * 3;
                for (size_t qv = 0; qv < n_valid; ++qv) {
                    const int qi = (int)(*idx_ptr)[qv];
                    const int32_t* nq = Q + (size_t)qi * 3;
                    double re = 0.0;
                    double im = 0.0;
                    for (int j = 0; j < NB_i; ++j) {
                        const size_t ob = baseB + (size_t)j * 3;
                        const double sxyz[3] = {
                            (double)B[ob + 0],
                            (double)B[ob + 1],
                            (double)B[ob + 2],
                        };
                        const double phase = phase_from_n_ds(nq, sxyz);
                        double s, c;
                        fast_sincos(phase, &s, &c);
                        re += c;
                        im += s;
                    }
                    rhoB_re[qv] = re;
                    rhoB_im[qv] = im;
                }

                const int k_stop = (int)(std::upper_bound(lag_ptr, lag_ptr + K_i, (int32_t)t1) - lag_ptr);
                for (int ki = 0; ki < k_stop; ++ki) {
                    const int li = (int)lag_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    const size_t baseA0 = ((size_t)t0 * (size_t)NA_i) * 3;
                    const size_t baseU0 = ((size_t)t0 * (size_t)NA_i) * 3;
                    const size_t baseU1 = ((size_t)t1 * (size_t)NA_i) * 3;

                    if (!cell_static) {
                        double cell0[3][3];
                        copy_cell(C + (size_t)t0 * 9, cell0);
                        mul3x3(cell0, inv_cell1, T01);
                    }

                    for (int i = 0; i < NA_i; ++i) {
                        const size_t oa = baseA0 + (size_t)i * 3;
                        const size_t off = (size_t)i * 3;
                        if (cell_static) {
                            sA_arr[off + 0] = (double)A[oa + 0];
                            sA_arr[off + 1] = (double)A[oa + 1];
                            sA_arr[off + 2] = (double)A[oa + 2];
                        }
                        else {
                            const double s0[3] = {
                                (double)A[oa + 0],
                                (double)A[oa + 1],
                                (double)A[oa + 2],
                            };
                            double s1[3];
                            mul_rowvec3(s0, T01, s1);
                            sA_arr[off + 0] = s1[0];
                            sA_arr[off + 1] = s1[1];
                            sA_arr[off + 2] = s1[2];
                        }

                        if (same) {
                            const size_t ou1 = baseU1 + (size_t)i * 3;
                            const size_t ou0 = baseU0 + (size_t)i * 3;
                            const double du[3] = {
                                (double)U[ou1 + 0] - (double)U[ou0 + 0],
                                (double)U[ou1 + 1] - (double)U[ou0 + 1],
                                (double)U[ou1 + 2] - (double)U[ou0 + 2],
                            };
                            ds_arr[off + 0] = du[0] * inv_cell1[0][0] + du[1] * inv_cell1[1][0] + du[2] * inv_cell1[2][0];
                            ds_arr[off + 1] = du[0] * inv_cell1[0][1] + du[1] * inv_cell1[1][1] + du[2] * inv_cell1[2][1];
                            ds_arr[off + 2] = du[0] * inv_cell1[0][2] + du[1] * inv_cell1[1][2] + du[2] * inv_cell1[2][2];
                        }
                    }

                    L.cnt[(size_t)ki] += 1;
                    int64_t* qrow = &L.qcnt[(size_t)ki * (size_t)nbins];
                    for (int b = 0; b < nbins; ++b) {
                        qrow[(size_t)b] += (*shell_ptr)[(size_t)b];
                    }

                    double* row = &L.hist[(size_t)ki * (size_t)nbins];
                    for (size_t qv = 0; qv < n_valid; ++qv) {
                        const int qi = (int)(*idx_ptr)[qv];
                        const int sid_i = cell_static ? shell_id_ptr[(size_t)qi] : (int)(*sid_ptr)[qv];
                        const int32_t* nq = Q + (size_t)qi * 3;
                        double a_re = 0.0;
                        double a_im = 0.0;
                        double self_sum = 0.0;
                        for (int i = 0; i < NA_i; ++i) {
                            const double sxyz[3] = {
                                sA_arr[(size_t)i * 3 + 0],
                                sA_arr[(size_t)i * 3 + 1],
                                sA_arr[(size_t)i * 3 + 2],
                            };
                            const double phaseA = phase_from_n_ds(nq, sxyz);
                            double s, c;
                            fast_sincos(phaseA, &s, &c);
                            a_re += c;
                            a_im += s;

                            if (same) {
                                const double ds[3] = {
                                    ds_arr[(size_t)i * 3 + 0],
                                    ds_arr[(size_t)i * 3 + 1],
                                    ds_arr[(size_t)i * 3 + 2],
                                };
                                self_sum += std::cos(phase_from_n_ds(nq, ds));
                            }
                        }

                        double val = a_re * rhoB_re[qv] + a_im * rhoB_im[qv];
                        if (same) {
                            val -= self_sum;
                        }
                        row[(size_t)sid_i] += val;
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S_i));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ++ti) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S_i; si += n_use) {
                    compute_slice(si, eps[(size_t)ti]);
                }
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        for (int si = 0; si < S_i; ++si) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;

            for (int ki = 0; ki < K_i; ++ki) {
                Nd[(size_t)ki] += L.cnt[(size_t)ki];
            }

            for (int ki = 0; ki < K_i; ++ki) {
                const int64_t* src_q = &L.qcnt[(size_t)ki * (size_t)nbins];
                int64_t* dst_q = Qd + (size_t)ki * (size_t)nbins;
                for (int b = 0; b < nbins; ++b) {
                    dst_q[(size_t)b] += src_q[(size_t)b];
                }
            }

            for (int ki = 0; ki < K_i; ++ki) {
                const double* src_h = &L.hist[(size_t)ki * (size_t)nbins];
                double* dst_h = Hd + (size_t)ki * (size_t)nbins;
                for (int b = 0; b < nbins; ++b) {
                    dst_h[(size_t)b] += src_h[(size_t)b];
                }
            }
        }

        const double nanv = std::numeric_limits<double>::quiet_NaN();
        for (int ki = 0; ki < K_i; ++ki) {
            double* row = Hd + (size_t)ki * (size_t)nbins;
            const int64_t* qrow = Qd + (size_t)ki * (size_t)nbins;
            for (int b = 0; b < nbins; ++b) {
                const int64_t qn = qrow[(size_t)b];
                if (qn > 0) {
                    row[(size_t)b] /= ((double)NA_i * (double)qn);
                }
                else {
                    row[(size_t)b] = nanv;
                }
            }
        }
    }

    return py::make_tuple(Fd, q_count, cnt_d);
}

static py::tuple isf_self_dispatch(
    py::array posA_unwrap,
    py::array cell,
    py::array q_int,
    py::object shell_id,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    py::array lags,
    int n_threads,
    py::array t1_slices,
    bool cell_static
) {
    const auto dtU = posA_unwrap.dtype();
    if (dtU.is(py::dtype::of<float>())) {
        return isf_self_impl<float>(
            posA_unwrap.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min, q_max, dq_shell, nbins,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    if (dtU.is(py::dtype::of<double>())) {
        return isf_self_impl<double>(
            posA_unwrap.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min, q_max, dq_shell, nbins,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    throw std::invalid_argument("posA_unwrap dtype must be float32 or float64");
}

static py::tuple isf_distinct_dispatch(
    py::array posA,
    py::array posB,
    py::array posA_unwrap,
    py::array cell,
    py::array q_int,
    py::object shell_id,
    double q_min,
    double q_max,
    double dq_shell,
    int nbins,
    bool same,
    py::array lags,
    int n_threads,
    py::array t1_slices,
    bool cell_static
) {
    const auto dtA = posA.dtype();
    const auto dtB = posB.dtype();
    const auto dtU = posA_unwrap.dtype();
    if (!dtA.is(dtB) || !dtA.is(dtU)) {
        throw std::invalid_argument("posA, posB and posA_unwrap must have the same dtype");
    }

    if (dtA.is(py::dtype::of<float>())) {
        return isf_distinct_impl<float>(
            posA.cast<py::array_t<float>>(),
            posB.cast<py::array_t<float>>(),
            posA_unwrap.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min, q_max, dq_shell, nbins, same,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    if (dtA.is(py::dtype::of<double>())) {
        return isf_distinct_impl<double>(
            posA.cast<py::array_t<double>>(),
            posB.cast<py::array_t<double>>(),
            posA_unwrap.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            q_int.cast<py::array_t<int32_t>>(),
            shell_id,
            q_min, q_max, dq_shell, nbins, same,
            lags.cast<py::array_t<int32_t>>(),
            n_threads,
            t1_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    throw std::invalid_argument("posA dtype must be float32 or float64");
}


PYBIND11_MODULE(isf_ext, m) {
    m.doc() = "Intermediate scattering function kernels for Ripple";
    m.def(
        "isf_self",
        &isf_self_dispatch,
        py::arg("posA_unwrap"),
        py::arg("cell"),
        py::arg("q_int"),
        py::arg("shell_id"),
        py::arg("q_min"),
        py::arg("q_max"),
        py::arg("dq_shell"),
        py::arg("nbins"),
        py::arg("lags"),
        py::arg("n_threads"),
        py::arg("t1_slices"),
        py::arg("cell_static")
    );
    m.def(
        "isf_distinct",
        &isf_distinct_dispatch,
        py::arg("posA"),
        py::arg("posB"),
        py::arg("posA_unwrap"),
        py::arg("cell"),
        py::arg("q_int"),
        py::arg("shell_id"),
        py::arg("q_min"),
        py::arg("q_max"),
        py::arg("dq_shell"),
        py::arg("nbins"),
        py::arg("same"),
        py::arg("lags"),
        py::arg("n_threads"),
        py::arg("t1_slices"),
        py::arg("cell_static")
    );
}
