#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include <algorithm>

namespace py = pybind11;
using ssize = py::ssize_t;

#if defined(_MSC_VER)
#  define RPL_RESTRICT __restrict
#elif defined(__GNUC__) || defined(__clang__)
#  define RPL_RESTRICT __restrict__
#else
#  define RPL_RESTRICT
#endif

static inline void require_c_contig_TN3(const py::buffer_info& b, ssize itemsize) {
    if (b.ndim != 3) throw std::invalid_argument("pos must be a 3D array (T,N,3)");
    if (b.shape[2] != 3) throw std::invalid_argument("pos last dim must be 3");
    // C-contiguous: stride[2]=itemsize, stride[1]=3*itemsize, stride[0]=N*3*itemsize
    if (b.strides[2] != itemsize) throw std::invalid_argument("pos must be C-contiguous");
    if (b.strides[1] != 3 * itemsize) throw std::invalid_argument("pos must be C-contiguous");
    if (b.strides[0] != b.shape[1] * 3 * itemsize) throw std::invalid_argument("pos must be C-contiguous");
}

static inline void require_c_contig_T3(const py::buffer_info& b, ssize itemsize) {
    if (b.ndim != 2) throw std::invalid_argument("sum_pos must be a 2D array (T,3)");
    if (b.shape[1] != 3) throw std::invalid_argument("sum_pos last dim must be 3");
    if (b.strides[1] != itemsize) throw std::invalid_argument("sum_pos must be C-contiguous");
    if (b.strides[0] != 3 * itemsize) throw std::invalid_argument("sum_pos must be C-contiguous");
}

template <class I>
static inline void require_int_1d_contig(const py::buffer_info& b, const char* name) {
    if (b.ndim != 1) throw std::invalid_argument(std::string(name) + " must be 1D");
    if (b.strides[0] != (ssize)sizeof(I)) throw std::invalid_argument(std::string(name) + " must be C-contiguous");
}

struct edges64_view {
    const std::int64_t* ptr = nullptr;
    ssize n_edge = 0;
    std::vector<std::int64_t> owned; // used only when input is int32
};

static inline edges64_view get_edges64_checked(const py::array& edges_, std::int64_t hi) {
    auto b = edges_.request();
    if (b.ndim != 1) throw std::invalid_argument("edges must be 1D");
    const ssize n_edge = b.shape[0];
    if (n_edge < 2) throw std::invalid_argument("edges must have length >= 2");

    edges64_view ev;
    ev.n_edge = n_edge;

    const bool edges_i64 =
        edges_.dtype().is(py::dtype::of<std::int64_t>()) &&
        b.strides[0] == (ssize)sizeof(std::int64_t);
    const bool edges_i32 =
        edges_.dtype().is(py::dtype::of<std::int32_t>()) &&
        b.strides[0] == (ssize)sizeof(std::int32_t);

    if (edges_i64) {
        ev.ptr = static_cast<const std::int64_t*>(b.ptr);
    } else if (edges_i32) {
        const auto* p32 = static_cast<const std::int32_t*>(b.ptr);
        ev.owned.resize((size_t)n_edge);
        for (ssize i = 0; i < n_edge; ++i) ev.owned[(size_t)i] = (std::int64_t)p32[(size_t)i];
        ev.ptr = ev.owned.data();
    } else {
        throw std::invalid_argument("edges must be int64 or int32 and 1D C-contiguous");
    }

    // validate: non-decreasing and within [0, hi]
    const std::int64_t* e = ev.ptr;
    std::int64_t prev = e[0];
    if (prev < 0 || prev > hi) throw std::invalid_argument("edges out of range [0, origin_count]");
    for (ssize i = 1; i < n_edge; ++i) {
        const std::int64_t v = e[(size_t)i];
        if (v < prev) throw std::invalid_argument("edges must be non-decreasing");
        if (v < 0 || v > hi) throw std::invalid_argument("edges out of range [0, origin_count]");
        prev = v;
    }
    return ev;
}

template <class I>
static inline std::int64_t compute_lag_max_checked(const I* lags, ssize n_lag, std::int64_t Tn) {
    std::int64_t lag_max = 0;
    for (ssize i = 0; i < n_lag; ++i) {
        const std::int64_t lag = (std::int64_t)lags[i];
        if (lag < 0) throw std::invalid_argument("lags must be non-negative");
        if (lag > lag_max) lag_max = lag;
    }
    if (lag_max >= Tn) throw std::invalid_argument("max(lags) must be < T");
    return lag_max;
}

template <class T, class I>
static py::array_t<double> msd_block_tensor_impl(py::array pos_, py::array lags_, py::array edges_) {
    const auto bp = pos_.request();
    const auto bl = lags_.request();

    require_c_contig_TN3(bp, (ssize)sizeof(T));
    require_int_1d_contig<I>(bl, "lags");

    const ssize Tn = bp.shape[0];
    const ssize N  = bp.shape[1];
    if (N <= 0) throw std::invalid_argument("N must be positive");

    const ssize n_lag = bl.shape[0];
    if (n_lag <= 0) throw std::invalid_argument("lags must be non-empty");

    const I* lags = static_cast<const I*>(bl.ptr);
    const std::int64_t lag_max = compute_lag_max_checked<I>(lags, n_lag, (std::int64_t)Tn);
    const std::int64_t origin_count64 = (std::int64_t)Tn - lag_max;
    if (origin_count64 < 0) throw std::invalid_argument("origin_count negative (check lags)");
    const auto ev = get_edges64_checked(edges_, origin_count64);

    const ssize n_block = ev.n_edge - 1;
    if (n_block <= 0) throw std::invalid_argument("edges must define at least one block");
    const std::int64_t* edges = ev.ptr;

    py::array_t<double> out({(ssize)n_lag, (ssize)n_block, (ssize)3, (ssize)3});
    auto bo = out.request();
    std::memset(bo.ptr, 0, (size_t)n_lag * (size_t)n_block * 9u * sizeof(double));

    const T* RPL_RESTRICT pos = static_cast<const T*>(bp.ptr);
    double* RPL_RESTRICT outp = static_cast<double*>(bo.ptr);

    const size_t stride_t = (size_t)N * 3u;

    py::gil_scoped_release nogil;
    for (ssize li = 0; li < n_lag; ++li) {
        const std::int64_t lag = (std::int64_t)lags[li];
        if (lag == 0) continue; // MSD(0)=0, keep zeros

        for (ssize bi = 0; bi < n_block; ++bi) {
            const std::int64_t t0_start = edges[bi];
            const std::int64_t t0_stop  = edges[bi + 1];
            const std::int64_t cnt = t0_stop - t0_start;
            if (cnt <= 0) throw std::invalid_argument("empty block in edges");

            double sxx = 0.0, syy = 0.0, szz = 0.0;
            double sxy = 0.0, sxz = 0.0, syz = 0.0;

            // Guaranteed by origin_count = T - lag_max and edges <= origin_count:
            // t0 < origin_count <= T - lag_max, lag <= lag_max  =>  t0+lag < T
            for (std::int64_t t0 = t0_start; t0 < t0_stop; ++t0) {
                const size_t base0 = (size_t)t0 * stride_t;
                const size_t base1 = (size_t)(t0 + lag) * stride_t;

                const T* RPL_RESTRICT p0 = pos + base0;
                const T* RPL_RESTRICT p1 = pos + base1;

                const T* RPL_RESTRICT q0 = p0;
                const T* RPL_RESTRICT q1 = p1;
                for (ssize i = 0; i < N; ++i, q0 += 3, q1 += 3) {
                    const double dx = (double)q1[0] - (double)q0[0];
                    const double dy = (double)q1[1] - (double)q0[1];
                    const double dz = (double)q1[2] - (double)q0[2];
                    sxx += dx * dx;
                    syy += dy * dy;
                    szz += dz * dz;
                    sxy += dx * dy;
                    sxz += dx * dz;
                    syz += dy * dz;
                }
            }

            const double inv = 1.0 / ((double)N * (double)cnt);
            const size_t o = ((size_t)li * (size_t)n_block + (size_t)bi) * 9u;

            outp[o + 0] = sxx * inv;
            outp[o + 1] = sxy * inv;
            outp[o + 2] = sxz * inv;
            outp[o + 3] = sxy * inv;
            outp[o + 4] = syy * inv;
            outp[o + 5] = syz * inv;
            outp[o + 6] = sxz * inv;
            outp[o + 7] = syz * inv;
            outp[o + 8] = szz * inv;
        }
    }
    return out;
}

static py::array_t<double> msd_block_tensor(py::array pos, py::array lags, py::array edges) {
    const auto b = pos.request();
    const auto bl = lags.request();
    const auto dt = pos.dtype();
    const auto lag_dt = lags.dtype();

    const bool lags_i32 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int32_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int32_t);
    const bool lags_i64 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int64_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int64_t);

    if (!lags_i32 && !lags_i64) throw std::invalid_argument("lags must be int32 or int64 and 1D C-contiguous");

    if (dt.is(py::dtype::of<float>())) {
        if (lags_i32) return msd_block_tensor_impl<float, std::int32_t>(pos, lags, edges);
        return msd_block_tensor_impl<float, std::int64_t>(pos, lags, edges);
    }
    if (dt.is(py::dtype::of<double>())) {
        if (lags_i32) return msd_block_tensor_impl<double, std::int32_t>(pos, lags, edges);
        return msd_block_tensor_impl<double, std::int64_t>(pos, lags, edges);
    }
    throw std::invalid_argument("pos must be float32 or float64");
}

template <class T, class I>
static py::array_t<double> cmsd_block_tensor_sumpos_impl(py::array sum_pos_, std::int64_t N_sel,
                                                         py::array lags_, py::array edges_) {
    if (N_sel <= 0) throw std::invalid_argument("N_sel must be positive");

    const auto bp = sum_pos_.request();
    const auto bl = lags_.request();

    require_c_contig_T3(bp, (ssize)sizeof(T));
    require_int_1d_contig<I>(bl, "lags");

    const ssize Tn = bp.shape[0];
    const ssize n_lag = bl.shape[0];
    if (n_lag <= 0) throw std::invalid_argument("lags must be non-empty");

    const I* lags = static_cast<const I*>(bl.ptr);
    const std::int64_t lag_max = compute_lag_max_checked<I>(lags, n_lag, (std::int64_t)Tn);
    const std::int64_t origin_count64 = (std::int64_t)Tn - lag_max;
    if (origin_count64 < 0) throw std::invalid_argument("origin_count negative (check lags)");
    const auto ev = get_edges64_checked(edges_, origin_count64);

    const ssize n_block = ev.n_edge - 1;
    if (n_block <= 0) throw std::invalid_argument("edges must define at least one block");
    const std::int64_t* edges = ev.ptr;

    py::array_t<double> out({(ssize)n_lag, (ssize)n_block, (ssize)3, (ssize)3});
    auto bo = out.request();
    std::memset(bo.ptr, 0, (size_t)n_lag * (size_t)n_block * 9u * sizeof(double));

    const T* RPL_RESTRICT sp = static_cast<const T*>(bp.ptr);
    double* RPL_RESTRICT outp = static_cast<double*>(bo.ptr);

    py::gil_scoped_release nogil;
    for (ssize li = 0; li < n_lag; ++li) {
        const std::int64_t lag = (std::int64_t)lags[li];
        if (lag == 0) continue;

        for (ssize bi = 0; bi < n_block; ++bi) {
            const std::int64_t t0_start = edges[bi];
            const std::int64_t t0_stop  = edges[bi + 1];
            const std::int64_t cnt = t0_stop - t0_start;
            if (cnt <= 0) throw std::invalid_argument("empty block in edges");

            double sxx = 0.0, syy = 0.0, szz = 0.0;
            double sxy = 0.0, sxz = 0.0, syz = 0.0;

            for (std::int64_t t0 = t0_start; t0 < t0_stop; ++t0) {
                const size_t base0 = (size_t)t0 * 3u;
                const size_t base1 = (size_t)(t0 + lag) * 3u;

                const double dx = (double)sp[base1 + 0] - (double)sp[base0 + 0];
                const double dy = (double)sp[base1 + 1] - (double)sp[base0 + 1];
                const double dz = (double)sp[base1 + 2] - (double)sp[base0 + 2];

                sxx += dx * dx;
                syy += dy * dy;
                szz += dz * dz;
                sxy += dx * dy;
                sxz += dx * dz;
                syz += dy * dz;
            }

            const double inv = 1.0 / ((double)N_sel * (double)cnt);
            const size_t o = ((size_t)li * (size_t)n_block + (size_t)bi) * 9u;

            outp[o + 0] = sxx * inv;
            outp[o + 1] = sxy * inv;
            outp[o + 2] = sxz * inv;
            outp[o + 3] = sxy * inv;
            outp[o + 4] = syy * inv;
            outp[o + 5] = syz * inv;
            outp[o + 6] = sxz * inv;
            outp[o + 7] = syz * inv;
            outp[o + 8] = szz * inv;
        }
    }

    return out;
}

static py::array_t<double> cmsd_block_tensor_sumpos(py::array sum_pos, std::int64_t N_sel,
                                                    py::array lags, py::array edges) {
    const auto b = sum_pos.request();
    const auto bl = lags.request();
    const auto dt = sum_pos.dtype();
    const auto lag_dt = lags.dtype();

    const bool lags_i32 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int32_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int32_t);
    const bool lags_i64 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int64_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int64_t);
    if (!lags_i32 && !lags_i64) throw std::invalid_argument("lags must be int32 or int64 and 1D C-contiguous");

    if (dt.is(py::dtype::of<float>())) {
        if (lags_i32) return cmsd_block_tensor_sumpos_impl<float, std::int32_t>(sum_pos, N_sel, lags, edges);
        return cmsd_block_tensor_sumpos_impl<float, std::int64_t>(sum_pos, N_sel, lags, edges);
    }
    if (dt.is(py::dtype::of<double>())) {
        if (lags_i32) return cmsd_block_tensor_sumpos_impl<double, std::int32_t>(sum_pos, N_sel, lags, edges);
        return cmsd_block_tensor_sumpos_impl<double, std::int64_t>(sum_pos, N_sel, lags, edges);
    }
    throw std::invalid_argument("sum_pos must be float32 or float64");
}

template <class T, class I>
static py::array_t<double> cmsd_block_tensor_from_pos_impl(py::array pos_, py::array lags_, py::array edges_) {
    const auto bp = pos_.request();
    const auto bl = lags_.request();

    require_c_contig_TN3(bp, (ssize)sizeof(T));
    require_int_1d_contig<I>(bl, "lags");

    const ssize Tn = bp.shape[0];
    const ssize N  = bp.shape[1];
    if (N <= 0) throw std::invalid_argument("N must be positive");

    // Build sum_pos in a Python-owned contiguous array (no extra memcpy)
    py::array_t<double> sum_view({(ssize)Tn, (ssize)3});
    auto bs = sum_view.request();
    double* RPL_RESTRICT sp_out = static_cast<double*>(bs.ptr);
    const T* RPL_RESTRICT pos = static_cast<const T*>(bp.ptr);

    const size_t stride_t = (size_t)N * 3u;

    {
        py::gil_scoped_release nogil;
        for (ssize t = 0; t < Tn; ++t) {
            const T* RPL_RESTRICT p = pos + (size_t)t * stride_t;
            double sx = 0.0, sy = 0.0, sz = 0.0;

            const T* RPL_RESTRICT q = p;
            for (ssize i = 0; i < N; ++i, q += 3) {
                sx += (double)q[0];
                sy += (double)q[1];
                sz += (double)q[2];
            }
            sp_out[(size_t)t * 3u + 0] = sx;
            sp_out[(size_t)t * 3u + 1] = sy;
            sp_out[(size_t)t * 3u + 2] = sz;
        }
    }

    return cmsd_block_tensor_sumpos_impl<double, I>(sum_view, (std::int64_t)N, lags_, edges_);
}

static py::array_t<double> cmsd_block_tensor(py::array pos, py::array lags, py::array edges) {
    const auto b = pos.request();
    const auto bl = lags.request();
    const auto dt = pos.dtype();
    const auto lag_dt = lags.dtype();

    const bool lags_i32 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int32_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int32_t);
    const bool lags_i64 =
        bl.ndim == 1 &&
        lag_dt.is(py::dtype::of<std::int64_t>()) &&
        bl.strides[0] == (ssize)sizeof(std::int64_t);
    if (!lags_i32 && !lags_i64) throw std::invalid_argument("lags must be int32 or int64 and 1D C-contiguous");

    if (dt.is(py::dtype::of<float>())) {
        if (lags_i32) return cmsd_block_tensor_from_pos_impl<float, std::int32_t>(pos, lags, edges);
        return cmsd_block_tensor_from_pos_impl<float, std::int64_t>(pos, lags, edges);
    }
    if (dt.is(py::dtype::of<double>())) {
        if (lags_i32) return cmsd_block_tensor_from_pos_impl<double, std::int32_t>(pos, lags, edges);
        return cmsd_block_tensor_from_pos_impl<double, std::int64_t>(pos, lags, edges);
    }
    throw std::invalid_argument("pos must be float32 or float64");
}

PYBIND11_MODULE(block_mcmc_ext, m) {
    m.doc() = "Block-averaged MSD/cMSD tensor curves for block covariance / MCMC (origin_count = T - lag_max).";

    m.def("msd_block_tensor", &msd_block_tensor, py::arg("pos"), py::arg("lags"), py::arg("edges"),
          "Return (n_lag, n_block, 3, 3) float64 block-averaged MSD tensor.\n"
          "Assumes edges are defined on origin_count = T - max(lags), so no tail-branching occurs.");

    m.def("cmsd_block_tensor", &cmsd_block_tensor, py::arg("pos"), py::arg("lags"), py::arg("edges"),
          "Return (n_lag, n_block, 3, 3) float64 block-averaged cMSD tensor.\n"
          "Computes sum_pos internally (O(T*N)); prefer cmsd_block_tensor_sumpos when available.");

    m.def("cmsd_block_tensor_sumpos", &cmsd_block_tensor_sumpos,
          py::arg("sum_pos"), py::arg("N_sel"), py::arg("lags"), py::arg("edges"),
          "Return (n_lag, n_block, 3, 3) float64 block-averaged cMSD tensor from precomputed sum_pos.\n"
          "sum_pos must be (T,3) C-contiguous, unwrapped sum of positions for selected atoms.");
}
