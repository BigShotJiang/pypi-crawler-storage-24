#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <exception>
#include <limits>
#include <stdexcept>
#include <thread>
#include <vector>

namespace py = pybind11;

// =====================================================================================
// Small utilities
// =====================================================================================

static inline int checked_int_from_ssize(py::ssize_t x) {
    if (x < 0 || x > (py::ssize_t)std::numeric_limits<int>::max()) {
        throw std::invalid_argument("size exceeds int range");
    }
    return (int)x;
}

static inline double wrap01_for_index(double x) {
    // strict fractional part in [0,1)
    x -= std::floor(x);
    if (x >= 1.0) x = std::nextafter(1.0, 0.0);
    return x;
}

static inline void invert3x3(const double a[3][3], double inva[3][3], bool& ok) {
    const double a00 = a[0][0], a01 = a[0][1], a02 = a[0][2];
    const double a10 = a[1][0], a11 = a[1][1], a12 = a[1][2];
    const double a20 = a[2][0], a21 = a[2][1], a22 = a[2][2];

    const double c00 = (a11 * a22 - a12 * a21);
    const double c01 = -(a10 * a22 - a12 * a20);
    const double c02 = (a10 * a21 - a11 * a20);

    const double c10 = -(a01 * a22 - a02 * a21);
    const double c11 = (a00 * a22 - a02 * a20);
    const double c12 = -(a00 * a21 - a01 * a20);

    const double c20 = (a01 * a12 - a02 * a11);
    const double c21 = -(a00 * a12 - a02 * a10);
    const double c22 = (a00 * a11 - a01 * a10);

    const double det = a00 * c00 + a01 * c01 + a02 * c02;
    if (std::abs(det) < 1e-18) {
        ok = false;
        return;
    }
    ok = true;
    const double invdet = 1.0 / det;

    inva[0][0] = c00 * invdet; inva[0][1] = c10 * invdet; inva[0][2] = c20 * invdet;
    inva[1][0] = c01 * invdet; inva[1][1] = c11 * invdet; inva[1][2] = c21 * invdet;
    inva[2][0] = c02 * invdet; inva[2][1] = c12 * invdet; inva[2][2] = c22 * invdet;
}

static inline void mul3x3(const double A[3][3], const double B[3][3], double C[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            C[i][j] = A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j];
        }
    }
}

static inline void mul_rowvec3(const double v[3], const double M[3][3], double out[3]) {
    // row-vector times matrix
    out[0] = v[0] * M[0][0] + v[1] * M[1][0] + v[2] * M[2][0];
    out[1] = v[0] * M[0][1] + v[1] * M[1][1] + v[2] * M[2][1];
    out[2] = v[0] * M[0][2] + v[1] * M[1][2] + v[2] * M[2][2];
}

// =====================================================================================
// Mode parsing
// =====================================================================================

struct ModeAxes { int dim; int ax0; int ax1; int ax2; };

static inline ModeAxes parse_mode_int(int mode_int) {
    switch (mode_int) {
    case 1: return { 3, 0, 1, 2 };   // abc
    case 2: return { 2, 0, 1, -1 };  // ab
    case 3: return { 2, 0, 2, -1 };  // ac
    case 4: return { 2, 1, 2, -1 };  // bc
    case 5: return { 1, 0, -1, -1 }; // a
    case 6: return { 1, 1, -1, -1 }; // b
    case 7: return { 1, 2, -1, -1 }; // c
    default: throw std::invalid_argument("mode_int must be in [1..7]");
    }
}

// =====================================================================================
// Shell measures for density normalization
// =====================================================================================

static inline void build_shell(int dim, int nbins, double dr, std::vector<double>& shell) {
    shell.resize((size_t)nbins);
    const double pi = std::acos(-1.0);
    if (dim == 3) {
        const double c = 4.0 * pi / 3.0;
        for (int k = 0; k < nbins; k++) {
            const double r0 = (double)k * dr;
            const double r1 = r0 + dr;
            shell[(size_t)k] = c * (r1 * r1 * r1 - r0 * r0 * r0);
        }
    }
    else if (dim == 2) {
        const double c = pi;
        for (int k = 0; k < nbins; k++) {
            const double r0 = (double)k * dr;
            const double r1 = r0 + dr;
            shell[(size_t)k] = c * (r1 * r1 - r0 * r0);
        }
    }
    else {
        for (int k = 0; k < nbins; k++) shell[(size_t)k] = 2.0 * dr;
    }
}

// =====================================================================================
// Metrics and MIC helpers for distinct part
// =====================================================================================

struct Metric3 { double G[3][3]; double Ginv[3][3]; double b_len[3]; };
struct Metric2 { double G[2][2]; double Ginv[2][2]; double b_len[2]; };
struct Metric1 { double G; double b_len; };

static inline Metric3 metric3_from_cell_axes(const double cell[3][3], int ax0, int ax1, int ax2) {
    const double* a0 = cell[ax0];
    const double* a1 = cell[ax1];
    const double* a2 = cell[ax2];
    auto dot3 = [](const double* u, const double* v) -> double {
        return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
    };

    Metric3 M{};
    M.G[0][0] = dot3(a0, a0); M.G[0][1] = dot3(a0, a1); M.G[0][2] = dot3(a0, a2);
    M.G[1][0] = M.G[0][1];   M.G[1][1] = dot3(a1, a1); M.G[1][2] = dot3(a1, a2);
    M.G[2][0] = M.G[0][2];   M.G[2][1] = M.G[1][2];   M.G[2][2] = dot3(a2, a2);

    const double a = M.G[0][0], b = M.G[0][1], c = M.G[0][2];
    const double d = M.G[1][1], e = M.G[1][2];
    const double f = M.G[2][2];
    const double det = a * (d * f - e * e) - b * (b * f - c * e) + c * (b * e - c * d);
    if (det <= 0.0) throw std::runtime_error("metric3: non-positive determinant");
    const double invdet = 1.0 / det;

    M.Ginv[0][0] = (d * f - e * e) * invdet;
    M.Ginv[0][1] = (c * e - b * f) * invdet;
    M.Ginv[0][2] = (b * e - c * d) * invdet;
    M.Ginv[1][0] = M.Ginv[0][1];
    M.Ginv[1][1] = (a * f - c * c) * invdet;
    M.Ginv[1][2] = (b * c - a * e) * invdet;
    M.Ginv[2][0] = M.Ginv[0][2];
    M.Ginv[2][1] = M.Ginv[1][2];
    M.Ginv[2][2] = (a * d - b * b) * invdet;

    M.b_len[0] = std::sqrt(std::max(0.0, M.Ginv[0][0]));
    M.b_len[1] = std::sqrt(std::max(0.0, M.Ginv[1][1]));
    M.b_len[2] = std::sqrt(std::max(0.0, M.Ginv[2][2]));
    return M;
}

static inline Metric2 metric2_from_cell_axes(const double cell[3][3], int ax0, int ax1) {
    const double* a0 = cell[ax0];
    const double* a1 = cell[ax1];
    auto dot3 = [](const double* u, const double* v) -> double {
        return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
    };
    Metric2 M{};
    M.G[0][0] = dot3(a0, a0); M.G[0][1] = dot3(a0, a1);
    M.G[1][0] = M.G[0][1];   M.G[1][1] = dot3(a1, a1);

    const double a = M.G[0][0], b = M.G[0][1], d = M.G[1][1];
    const double det = a * d - b * b;
    if (det <= 0.0) throw std::runtime_error("metric2: non-positive determinant");
    const double invdet = 1.0 / det;

    M.Ginv[0][0] = d * invdet;
    M.Ginv[0][1] = -b * invdet;
    M.Ginv[1][0] = M.Ginv[0][1];
    M.Ginv[1][1] = a * invdet;

    M.b_len[0] = std::sqrt(std::max(0.0, M.Ginv[0][0]));
    M.b_len[1] = std::sqrt(std::max(0.0, M.Ginv[1][1]));
    return M;
}

static inline Metric1 metric1_from_cell_axes(const double cell[3][3], int ax0) {
    const double* a0 = cell[ax0];
    const double G = a0[0] * a0[0] + a0[1] * a0[1] + a0[2] * a0[2];
    if (G <= 0.0) throw std::runtime_error("metric1: non-positive length");
    Metric1 M{};
    M.G = G;
    M.b_len = 1.0 / std::sqrt(G);
    return M;
}

static inline int bound_m(double b_len, double r_max) {
    if (b_len <= 0.0) return 0;
    return (int)std::ceil(r_max * b_len + 1e-12);
}

static inline double r2_dim3(double d0, double d1, double d2,
    bool pw0, bool pw1, bool pw2,
    int m0, int m1, int m2,
    const Metric3& M) {
    double best = std::numeric_limits<double>::infinity();
    const int a0 = pw0 ? -m0 : 0;
    const int b0 = pw0 ?  m0 : 0;
    const int a1 = pw1 ? -m1 : 0;
    const int b1 = pw1 ?  m1 : 0;
    const int a2 = pw2 ? -m2 : 0;
    const int b2 = pw2 ?  m2 : 0;

    for (int i0 = a0; i0 <= b0; i0++) {
        const double x0 = d0 + (double)i0;
        for (int i1 = a1; i1 <= b1; i1++) {
            const double x1 = d1 + (double)i1;
            for (int i2 = a2; i2 <= b2; i2++) {
                const double x2 = d2 + (double)i2;
                const double r2 =
                    x0 * (M.G[0][0] * x0 + M.G[0][1] * x1 + M.G[0][2] * x2) +
                    x1 * (M.G[1][0] * x0 + M.G[1][1] * x1 + M.G[1][2] * x2) +
                    x2 * (M.G[2][0] * x0 + M.G[2][1] * x1 + M.G[2][2] * x2);
                if (r2 < best) best = r2;
            }
        }
    }
    return best;
}

static inline double r2_dim2(double d0, double d1,
    bool pw0, bool pw1,
    int m0, int m1,
    const Metric2& M) {
    double best = std::numeric_limits<double>::infinity();
    const int a0 = pw0 ? -m0 : 0;
    const int b0 = pw0 ?  m0 : 0;
    const int a1 = pw1 ? -m1 : 0;
    const int b1 = pw1 ?  m1 : 0;
    for (int i0 = a0; i0 <= b0; i0++) {
        const double x0 = d0 + (double)i0;
        for (int i1 = a1; i1 <= b1; i1++) {
            const double x1 = d1 + (double)i1;
            const double r2 =
                x0 * (M.G[0][0] * x0 + M.G[0][1] * x1) +
                x1 * (M.G[1][0] * x0 + M.G[1][1] * x1);
            if (r2 < best) best = r2;
        }
    }
    return best;
}

static inline double r2_dim1(double d0,
    bool pw0,
    int m0,
    const Metric1& M) {
    double best = std::numeric_limits<double>::infinity();
    const int a0 = pw0 ? -m0 : 0;
    const int b0 = pw0 ?  m0 : 0;
    for (int i0 = a0; i0 <= b0; i0++) {
        const double x0 = d0 + (double)i0;
        const double r2 = x0 * (M.G * x0);
        if (r2 < best) best = r2;
    }
    return best;
}

static inline double measure_dim2_from_cell_axes(const double cell[3][3], int ax0, int ax1) {
    const double* a = cell[ax0];
    const double* b = cell[ax1];
    const double cx = a[1] * b[2] - a[2] * b[1];
    const double cy = a[2] * b[0] - a[0] * b[2];
    const double cz = a[0] * b[1] - a[1] * b[0];
    return std::sqrt(cx * cx + cy * cy + cz * cz);
}

static inline double measure_dim1_from_cell_axes(const double cell[3][3], int ax0) {
    const double* a = cell[ax0];
    return std::sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
}

// Conservative r_max upper bound for fully periodic distances in the measurement subspace.
static inline double r_max_limit_metric3(const Metric3& M) {
    const double h0 = 1.0 / M.b_len[0];
    const double h1 = 1.0 / M.b_len[1];
    const double h2 = 1.0 / M.b_len[2];
    return 0.5 * std::min(h0, std::min(h1, h2));
}

static inline double r_max_limit_metric2(const Metric2& M) {
    const double h0 = 1.0 / M.b_len[0];
    const double h1 = 1.0 / M.b_len[1];
    return 0.5 * std::min(h0, h1);
}

static inline double r_max_limit_metric1(const Metric1& M) {
    return 0.5 / M.b_len;
}

// =====================================================================================
// Cell-list for distinct part
// =====================================================================================

struct Bins3 {
    int nx = 1, ny = 1, nz = 1;
    int kx = 0, ky = 0, kz = 0;
    std::vector<int> head;
    std::vector<int> next;

    void build(const double* s0, const double* s1, const double* s2, int npts,
        const Metric3& M, double rcut) {
        const double b0 = std::sqrt(M.Ginv[0][0]);
        const double b1 = std::sqrt(M.Ginv[1][1]);
        const double b2 = std::sqrt(M.Ginv[2][2]);
        const double bx = std::min(1.0, b0 * rcut);
        const double by = std::min(1.0, b1 * rcut);
        const double bz = std::min(1.0, b2 * rcut);

        nx = std::max(1, (int)std::floor(1.0 / std::max(1e-16, bx)));
        ny = std::max(1, (int)std::floor(1.0 / std::max(1e-16, by)));
        nz = std::max(1, (int)std::floor(1.0 / std::max(1e-16, bz)));
        // Large vacuum cells or tiny cutoffs can make the nominal bin count explode.
        // Coarsening the grid preserves correctness; it only reduces cell-list selectivity.
        constexpr std::size_t MAX_TOTAL_BINS3 = (std::size_t)1 << 20;
        auto total_bins = [&]() -> std::size_t {
            return (std::size_t)nx * (std::size_t)ny * (std::size_t)nz;
        };
        while (total_bins() > MAX_TOTAL_BINS3) {
            if (nx >= ny && nx >= nz && nx > 1) {
                nx = std::max(1, (nx + 1) / 2);
            }
            else if (ny >= nx && ny >= nz && ny > 1) {
                ny = std::max(1, (ny + 1) / 2);
            }
            else if (nz > 1) {
                nz = std::max(1, (nz + 1) / 2);
            }
            else {
                break;
            }
        }

        kx = (nx == 1) ? 0 : std::min(nx - 1, std::max(0, (int)std::ceil(bx * nx) + 1));
        ky = (ny == 1) ? 0 : std::min(ny - 1, std::max(0, (int)std::ceil(by * ny) + 1));
        kz = (nz == 1) ? 0 : std::min(nz - 1, std::max(0, (int)std::ceil(bz * nz) + 1));

        const std::size_t nb = total_bins();
        head.assign(nb, -1);
        next.assign((size_t)npts, -1);

        for (int j = 0; j < npts; j++) {
            const double x = s0[j];
            const double y = s1[j];
            const double z = s2[j];
            int ix = (int)std::floor(x * nx);
            int iy = (int)std::floor(y * ny);
            int iz = (int)std::floor(z * nz);
            ix = std::min(nx - 1, std::max(0, ix));
            iy = std::min(ny - 1, std::max(0, iy));
            iz = std::min(nz - 1, std::max(0, iz));
            const std::size_t b = ((std::size_t)ix * (std::size_t)ny + (std::size_t)iy) * (std::size_t)nz + (std::size_t)iz;
            next[(size_t)j] = head[b];
            head[b] = j;
        }
    }
};

struct Bins2 {
    int nx = 1, ny = 1;
    int kx = 0, ky = 0;
    std::vector<int> head;
    std::vector<int> next;

    void build(const double* s0, const double* s1, int npts,
        const Metric2& M, double rcut) {
        const double b0 = std::sqrt(M.Ginv[0][0]);
        const double b1 = std::sqrt(M.Ginv[1][1]);
        const double bx = std::min(1.0, b0 * rcut);
        const double by = std::min(1.0, b1 * rcut);

        nx = std::max(1, (int)std::floor(1.0 / std::max(1e-16, bx)));
        ny = std::max(1, (int)std::floor(1.0 / std::max(1e-16, by)));
        constexpr std::size_t MAX_TOTAL_BINS2 = (std::size_t)1 << 20;
        auto total_bins = [&]() -> std::size_t {
            return (std::size_t)nx * (std::size_t)ny;
        };
        while (total_bins() > MAX_TOTAL_BINS2) {
            if (nx >= ny && nx > 1) {
                nx = std::max(1, (nx + 1) / 2);
            }
            else if (ny > 1) {
                ny = std::max(1, (ny + 1) / 2);
            }
            else {
                break;
            }
        }

        kx = (nx == 1) ? 0 : std::min(nx - 1, std::max(0, (int)std::ceil(bx * nx) + 1));
        ky = (ny == 1) ? 0 : std::min(ny - 1, std::max(0, (int)std::ceil(by * ny) + 1));

        const std::size_t nb = total_bins();
        head.assign(nb, -1);
        next.assign((size_t)npts, -1);

        for (int j = 0; j < npts; j++) {
            const double x = s0[j];
            const double y = s1[j];
            int ix = (int)std::floor(x * nx);
            int iy = (int)std::floor(y * ny);
            ix = std::min(nx - 1, std::max(0, ix));
            iy = std::min(ny - 1, std::max(0, iy));
            const std::size_t b = (std::size_t)ix * (std::size_t)ny + (std::size_t)iy;
            next[(size_t)j] = head[b];
            head[b] = j;
        }
    }
};

static inline void validate_selected_lags(const int32_t* lags, int K, int T_i) {
    if (K < 1) throw std::invalid_argument("lags must be non-empty");
    int32_t prev = -1;
    for (int ki = 0; ki < K; ++ki) {
        const int32_t li = lags[(size_t)ki];
        if (li < 0 || li >= T_i) {
            throw std::invalid_argument("lags must satisfy 0 <= lag < T");
        }
        if (li <= prev) {
            throw std::invalid_argument("lags must be strictly increasing");
        }
        prev = li;
    }
}

// =====================================================================================
// Self part kernel (parallel over lag; no reduction)
// =====================================================================================

template <typename Tpos>
static py::tuple vhf_self_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posA_unwrap, // (T, NA, 3)
    py::array_t<double, py::array::c_style | py::array::forcecast> cell,      // (T, 3, 3)
    double r_max,
    double dr,
    int nbins,
    int mode_int,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags, // (K,)
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lag_idx_slices, // (S,2)
    bool cell_static
) {
    const auto m = parse_mode_int(mode_int);
    if (nbins <= 0 || dr <= 0.0 || r_max <= 0.0) {
        throw std::invalid_argument("nbins, dr, r_max must be positive");
    }

    const py::buffer_info bu = posA_unwrap.request();
    const py::buffer_info bc = cell.request();
    if (bu.ndim != 3 || bu.shape[2] != 3) throw std::invalid_argument("posA_unwrap must be (T,NA,3)");
    if (bc.ndim != 3 || bc.shape[1] != 3 || bc.shape[2] != 3) throw std::invalid_argument("cell must be (T,3,3)");
    const py::ssize_t T = bu.shape[0];
    const py::ssize_t NA = bu.shape[1];
    if (bc.shape[0] != T) throw std::invalid_argument("cell length mismatch");
    if (T < 1 || NA < 1) throw std::invalid_argument("empty input");

    const int T_i = checked_int_from_ssize(T);
    const int NA_i = checked_int_from_ssize(NA);

    const auto bl = lags.request();
    if (bl.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    const int K = checked_int_from_ssize(bl.shape[0]);
    const int32_t* lags_ptr = static_cast<const int32_t*>(bl.ptr);
    validate_selected_lags(lags_ptr, K, T_i);

    const auto bs = lag_idx_slices.request();
    if (bs.ndim != 2 || bs.shape[1] != 2) throw std::invalid_argument("lag_idx_slices must be (S,2)");
    const int S = checked_int_from_ssize(bs.shape[0]);
    const int32_t* slices = static_cast<const int32_t*>(bs.ptr);

    // outputs
    py::array_t<double> Gs({ (py::ssize_t)K, (py::ssize_t)nbins });
    py::array_t<double> cnt_s((py::ssize_t)K);
    auto* G = Gs.mutable_data();
    auto* cnt = cnt_s.mutable_data();
    std::fill(G, G + (size_t)K * (size_t)nbins, 0.0);
    std::fill(cnt, cnt + (size_t)K, 0.0);
    if (mode_int == 1) {
        for (int ki = 0; ki < K; ki++) cnt[(size_t)ki] = (double)(T_i - lags_ptr[(size_t)ki]);
    }

    // shell
    std::vector<double> shell;
    build_shell(m.dim, nbins, dr, shell);
    const double r2_max = r_max * r_max;
    const double inv_dr = 1.0 / dr;

    // raw pointers
    const Tpos* Auw = static_cast<const Tpos*>(bu.ptr);
    const double* C = static_cast<const double*>(bc.ptr);

    // Precompute per-frame inverse cell and projected metrics if needed
    std::vector<double> inv_cells;           // (T,9)
    std::vector<uint8_t> inv_ok;             // (T,)
    std::vector<double> g2_00, g2_01, g2_11; // (T,) for dim2
    std::vector<double> g1;                  // (T,) for dim1
    double inv_cell_static[3][3];
    bool inv_static_ok = true;
    double g2s_00 = 0.0, g2s_01 = 0.0, g2s_11 = 0.0;
    double g1s = 0.0;

    if (mode_int != 1) {
        if (cell_static) {
            double cell0[3][3];
            for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) cell0[i][j] = C[(size_t)0 * 9 + (size_t)i * 3 + (size_t)j];
            invert3x3(cell0, inv_cell_static, inv_static_ok);
            if (m.dim == 2) {
                Metric2 M2 = metric2_from_cell_axes(cell0, m.ax0, m.ax1);
                g2s_00 = M2.G[0][0]; g2s_01 = M2.G[0][1]; g2s_11 = M2.G[1][1];
            }
            else {
                Metric1 M1 = metric1_from_cell_axes(cell0, m.ax0);
                g1s = M1.G;
            }
        }
        else {
            inv_cells.resize((size_t)T_i * 9);
            inv_ok.assign((size_t)T_i, (uint8_t)0);
            if (m.dim == 2) {
                g2_00.resize((size_t)T_i);
                g2_01.resize((size_t)T_i);
                g2_11.resize((size_t)T_i);
            }
            else {
                g1.resize((size_t)T_i);
            }
            for (int t = 0; t < T_i; t++) {
                double cellt[3][3];
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) cellt[i][j] = C[(size_t)t * 9 + (size_t)i * 3 + (size_t)j];
                double invt[3][3];
                bool ok = true;
                invert3x3(cellt, invt, ok);
                inv_ok[(size_t)t] = ok ? (uint8_t)1 : (uint8_t)0;
                if (ok) {
                    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) inv_cells[(size_t)t * 9 + (size_t)i * 3 + (size_t)j] = invt[i][j];
                }
                if (m.dim == 2) {
                    Metric2 M2 = metric2_from_cell_axes(cellt, m.ax0, m.ax1);
                    g2_00[(size_t)t] = M2.G[0][0];
                    g2_01[(size_t)t] = M2.G[0][1];
                    g2_11[(size_t)t] = M2.G[1][1];
                }
                else {
                    Metric1 M1 = metric1_from_cell_axes(cellt, m.ax0);
                    g1[(size_t)t] = M1.G;
                }
            }
        }
    }

    auto worker = [&](int si, std::exception_ptr& eptr) {
        try {
            const int32_t lag0 = slices[(size_t)si * 2 + 0];
            const int32_t lag1 = slices[(size_t)si * 2 + 1];
            const int k0 = std::max(0, (int)lag0);
            const int k1 = std::min(K, (int)lag1);
            for (int ki = k0; ki < k1; ki++) {
                const int li = lags_ptr[(size_t)ki];
                double* row = G + (size_t)ki * (size_t)nbins;
                const int n_origin = T_i - li;
                // For each origin, t1 = t0 + li
                for (int t0 = 0; t0 < n_origin; t0++) {
                    const int t1 = t0 + li;
                    if (mode_int == 1) {
                        const size_t base1 = ((size_t)t1 * (size_t)NA_i) * 3;
                        const size_t base0 = ((size_t)t0 * (size_t)NA_i) * 3;
                        for (int i = 0; i < NA_i; i++) {
                            const size_t o1 = base1 + (size_t)i * 3;
                            const size_t o0 = base0 + (size_t)i * 3;
                            const double dx = (double)Auw[o1 + 0] - (double)Auw[o0 + 0];
                            const double dy = (double)Auw[o1 + 1] - (double)Auw[o0 + 1];
                            const double dz = (double)Auw[o1 + 2] - (double)Auw[o0 + 2];
                            const double r2 = dx * dx + dy * dy + dz * dz;
                            if (r2 < r2_max) {
                                const int k = (int)(std::sqrt(r2) * inv_dr);
                                if (k < nbins) row[(size_t)k] += 1.0;
                            }
                        }
                    }
                    else {
                        bool ok = true;
                        const double* invp = nullptr;
                        if (cell_static) {
                            ok = inv_static_ok;
                            if (ok) invp = &inv_cell_static[0][0];
                        }
                        else {
                            ok = (inv_ok[(size_t)t1] != 0);
                            if (ok) invp = &inv_cells[(size_t)t1 * 9];
                        }
                        if (!ok) continue;
                        cnt[(size_t)ki] += 1.0;

                        const double gg00 = (m.dim == 2) ? (cell_static ? g2s_00 : g2_00[(size_t)t1]) : 0.0;
                        const double gg01 = (m.dim == 2) ? (cell_static ? g2s_01 : g2_01[(size_t)t1]) : 0.0;
                        const double gg11 = (m.dim == 2) ? (cell_static ? g2s_11 : g2_11[(size_t)t1]) : 0.0;
                        const double gg1 = (m.dim == 1) ? (cell_static ? g1s : g1[(size_t)t1]) : 0.0;

                        const size_t base1 = ((size_t)t1 * (size_t)NA_i) * 3;
                        const size_t base0 = ((size_t)t0 * (size_t)NA_i) * 3;
                        for (int i = 0; i < NA_i; i++) {
                            const size_t o1 = base1 + (size_t)i * 3;
                            const size_t o0 = base0 + (size_t)i * 3;
                            const double du[3] = {
                                (double)Auw[o1 + 0] - (double)Auw[o0 + 0],
                                (double)Auw[o1 + 1] - (double)Auw[o0 + 1],
                                (double)Auw[o1 + 2] - (double)Auw[o0 + 2]
                            };
                            // ds = du * inv_cell(t1)
                            const double ds0 = du[0] * invp[0] + du[1] * invp[3] + du[2] * invp[6];
                            const double ds1 = du[0] * invp[1] + du[1] * invp[4] + du[2] * invp[7];
                            const double ds2 = du[0] * invp[2] + du[1] * invp[5] + du[2] * invp[8];
                            double r2 = 0.0;
                            if (m.dim == 2) {
                                const double d0 = (m.ax0 == 0) ? ds0 : (m.ax0 == 1 ? ds1 : ds2);
                                const double d1 = (m.ax1 == 0) ? ds0 : (m.ax1 == 1 ? ds1 : ds2);
                                r2 = d0 * (gg00 * d0 + gg01 * d1) + d1 * (gg01 * d0 + gg11 * d1);
                            }
                            else {
                                const double d0 = (m.ax0 == 0) ? ds0 : (m.ax0 == 1 ? ds1 : ds2);
                                r2 = d0 * (gg1 * d0);
                            }
                            if (r2 < r2_max) {
                                const int k = (int)(std::sqrt(r2) * inv_dr);
                                if (k < nbins) row[(size_t)k] += 1.0;
                            }
                        }
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        // Release the GIL only around the native compute path.
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S));
        // schedule: one slice per thread, possibly multiple slices per thread if S>n_use
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ti++) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S; si += n_use) worker(si, eps[(size_t)ti]);
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        // normalize in-place according to the requested convention
        for (int ki = 0; ki < K; ki++) {
            const double denom0 = cnt[(size_t)ki] * (double)NA_i;
            if (denom0 <= 0.0) {
                std::fill(G + (size_t)ki * (size_t)nbins, G + (size_t)(ki + 1) * (size_t)nbins, 0.0);
                continue;
            }
            double* row = G + (size_t)ki * (size_t)nbins;
            for (int k = 0; k < nbins; k++) {
                const double den = denom0 * shell[(size_t)k];
                row[(size_t)k] = (den > 0.0) ? (row[(size_t)k] / den) : 0.0;
            }
        }
    }

    return py::make_tuple(Gs, cnt_s);
}

// =====================================================================================
// Distinct part kernel (parallel over t1-slices; reduction in C++)
// =====================================================================================

template <typename Tpos>
static py::tuple vhf_distinct_impl(
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posA, // (T, NA, 3) scaled
    py::array_t<Tpos, py::array::c_style | py::array::forcecast> posB, // (T, NB, 3) scaled
    py::array_t<double, py::array::c_style | py::array::forcecast> cell, // (T,3,3)
    py::array_t<bool, py::array::c_style | py::array::forcecast> pbc,    // (T,3)
    py::array_t<double, py::array::c_style | py::array::forcecast> vol,  // (T,)
    bool periodic_all,
    bool cell_static,
    bool same,
    double r_max,
    double dr,
    int nbins,
    int mode_int,
    int n_threads,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> lags,      // (K,)
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> t1_slices, // (S,2)
    bool normalize
) {
    const auto m = parse_mode_int(mode_int);
    if (nbins <= 0 || dr <= 0.0 || r_max <= 0.0) {
        throw std::invalid_argument("nbins, dr, r_max must be positive");
    }

    const py::buffer_info bA = posA.request();
    const py::buffer_info bB = posB.request();
    const py::buffer_info bC = cell.request();
    const py::buffer_info bP = pbc.request();
    const py::buffer_info bV = vol.request();

    if (bA.ndim != 3 || bA.shape[2] != 3) throw std::invalid_argument("posA must be (T,NA,3)");
    if (bB.ndim != 3 || bB.shape[2] != 3) throw std::invalid_argument("posB must be (T,NB,3)");
    if (bC.ndim != 3 || bC.shape[1] != 3 || bC.shape[2] != 3) throw std::invalid_argument("cell must be (T,3,3)");
    if (bP.ndim != 2 || bP.shape[1] != 3) throw std::invalid_argument("pbc must be (T,3)");
    if (bV.ndim != 1) throw std::invalid_argument("vol must be (T,)");
    if (bB.shape[0] != bA.shape[0]) throw std::invalid_argument("posA/posB length mismatch");
    if (bC.shape[0] != bA.shape[0] || bP.shape[0] != bA.shape[0] || bV.shape[0] != bA.shape[0]) {
        throw std::invalid_argument("cell/pbc/vol length mismatch");
    }

    const int T_i = checked_int_from_ssize(bA.shape[0]);
    const int NA_i = checked_int_from_ssize(bA.shape[1]);
    const int NB_i = checked_int_from_ssize(bB.shape[1]);
    if (T_i < 1 || NA_i < 1 || NB_i < 1) throw std::invalid_argument("empty input");
    if (same && NB_i != NA_i) {
        throw std::invalid_argument("same=True requires posA and posB to have the same atom count");
    }

    const auto bl = lags.request();
    if (bl.ndim != 1) throw std::invalid_argument("lags must be (K,)");
    const int K = checked_int_from_ssize(bl.shape[0]);
    const int32_t* lags_ptr = static_cast<const int32_t*>(bl.ptr);
    validate_selected_lags(lags_ptr, K, T_i);

    const auto bs = t1_slices.request();
    if (bs.ndim != 2 || bs.shape[1] != 2) throw std::invalid_argument("t1_slices must be (S,2)");
    const int S = checked_int_from_ssize(bs.shape[0]);
    const int32_t* slices = static_cast<const int32_t*>(bs.ptr);

    const double r2_max = r_max * r_max;
    const double inv_dr = 1.0 / dr;

    // shell
    std::vector<double> shell;
    build_shell(m.dim, nbins, dr, shell);

    // raw pointers
    const Tpos* A = static_cast<const Tpos*>(bA.ptr);
    const Tpos* B = static_cast<const Tpos*>(bB.ptr);
    const double* C = static_cast<const double*>(bC.ptr);
    const bool* P = static_cast<const bool*>(bP.ptr);
    const double* V = static_cast<const double*>(bV.ptr);

    if (periodic_all) {
        double rmax_lim = std::numeric_limits<double>::infinity();
        if (cell_static) {
            double cell0[3][3];
            for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) {
                cell0[i][j] = C[(size_t)i * 3 + (size_t)j];
            }
            if (m.dim == 3) {
                rmax_lim = r_max_limit_metric3(metric3_from_cell_axes(cell0, m.ax0, m.ax1, m.ax2));
            }
            else if (m.dim == 2) {
                rmax_lim = r_max_limit_metric2(metric2_from_cell_axes(cell0, m.ax0, m.ax1));
            }
            else {
                rmax_lim = r_max_limit_metric1(metric1_from_cell_axes(cell0, m.ax0));
            }
        }
        else {
            for (int t = 0; t < T_i; ++t) {
                double cellt[3][3];
                for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) {
                    cellt[i][j] = C[(size_t)t * 9 + (size_t)i * 3 + (size_t)j];
                }
                if (m.dim == 3) {
                    rmax_lim = std::min(rmax_lim, r_max_limit_metric3(metric3_from_cell_axes(cellt, m.ax0, m.ax1, m.ax2)));
                }
                else if (m.dim == 2) {
                    rmax_lim = std::min(rmax_lim, r_max_limit_metric2(metric2_from_cell_axes(cellt, m.ax0, m.ax1)));
                }
                else {
                    rmax_lim = std::min(rmax_lim, r_max_limit_metric1(metric1_from_cell_axes(cellt, m.ax0)));
                }
            }
        }
        if (!(rmax_lim > 0.0) || !std::isfinite(rmax_lim)) {
            throw std::runtime_error("Bad r_max_limit for distinct VHF (<=0 or non-finite).");
        }
        if (r_max > rmax_lim) {
            throw std::runtime_error(
                "r_max too large for periodic distinct VHF: r_max=" + std::to_string(r_max) +
                " exceeds r_max_limit=" + std::to_string(rmax_lim) +
                " (mode_int=" + std::to_string(mode_int) +
                ", periodic_all=True, cell_static=" + std::string(cell_static ? "True" : "False") + ")."
            );
        }
    }

    // global outputs (counts first, then normalize)
    py::array_t<double> Gd({ (py::ssize_t)K, (py::ssize_t)nbins });
    py::array_t<double> sum_fac_d((py::ssize_t)K);
    py::array_t<double> cnt_d((py::ssize_t)K);
    auto* Hd = Gd.mutable_data();
    auto* Sd = sum_fac_d.mutable_data();
    auto* Nd = cnt_d.mutable_data();
    std::fill(Hd, Hd + (size_t)K * (size_t)nbins, 0.0);
    std::fill(Sd, Sd + (size_t)K, 0.0);
    std::fill(Nd, Nd + (size_t)K, 0.0);

    struct LocalBuf {
        std::vector<double> hist;   // (K, nbins)
        std::vector<double> sumfac; // (K,)
        std::vector<double> cnt;    // (K,)
    };

    std::vector<LocalBuf> locals((size_t)S);

    auto compute_slice = [&](int si, std::exception_ptr& eptr) {
        try {
            const int start_t1 = std::max(0, (int)slices[(size_t)si * 2 + 0]);
            const int stop_t1 = std::min(T_i, (int)slices[(size_t)si * 2 + 1]);
            if (start_t1 >= stop_t1) return;
            LocalBuf& L = locals[(size_t)si];
            L.hist.assign((size_t)K * (size_t)nbins, 0.0);
            L.sumfac.assign((size_t)K, 0.0);
            L.cnt.assign((size_t)K, 0.0);

            Bins3 bins3;
            Bins2 bins2;
            std::vector<double> b0, b1, b2;

            for (int t1 = start_t1; t1 < stop_t1; t1++) {
                const int k_stop = (int)(std::upper_bound(lags_ptr, lags_ptr + K, (int32_t)t1) - lags_ptr);
                if (k_stop <= 0) continue;

                double cell1[3][3];
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) cell1[i][j] = C[(size_t)t1 * 9 + (size_t)i * 3 + (size_t)j];

                bool pw0 = false, pw1 = false, pw2 = false;
                if (m.dim >= 1) pw0 = periodic_all ? true : (bool)P[(size_t)t1 * 3 + (size_t)m.ax0];
                if (m.dim >= 2) pw1 = periodic_all ? true : (bool)P[(size_t)t1 * 3 + (size_t)m.ax1];
                if (m.dim == 3) pw2 = periodic_all ? true : (bool)P[(size_t)t1 * 3 + (size_t)m.ax2];

                Metric3 M3{}; Metric2 M2{}; Metric1 M1{};
                int mm0 = 0, mm1 = 0, mm2 = 0;
                if (m.dim == 3) {
                    M3 = metric3_from_cell_axes(cell1, m.ax0, m.ax1, m.ax2);
                    mm0 = bound_m(M3.b_len[0], r_max);
                    mm1 = bound_m(M3.b_len[1], r_max);
                    mm2 = bound_m(M3.b_len[2], r_max);
                }
                else if (m.dim == 2) {
                    M2 = metric2_from_cell_axes(cell1, m.ax0, m.ax1);
                    mm0 = bound_m(M2.b_len[0], r_max);
                    mm1 = bound_m(M2.b_len[1], r_max);
                }
                else {
                    M1 = metric1_from_cell_axes(cell1, m.ax0);
                    mm0 = bound_m(M1.b_len, r_max);
                }

                // rho_B in the selected subspace
                double rhoB = 0.0;
                {
                    const double measure =
                        (m.dim == 3) ? V[(size_t)t1] :
                        (m.dim == 2) ? measure_dim2_from_cell_axes(cell1, m.ax0, m.ax1) :
                        measure_dim1_from_cell_axes(cell1, m.ax0);
                    const double NB_eff = (same && NB_i > 0) ? double(NB_i - 1) : double(NB_i);
                    if (measure > 0.0 && NB_eff > 0.0) rhoB = NB_eff / measure;
                }

                // Build cell list for B(t1)
                if (m.dim == 3) {
                    b0.resize((size_t)NB_i);
                    b1.resize((size_t)NB_i);
                    b2.resize((size_t)NB_i);
                    const size_t baseB = ((size_t)t1 * (size_t)NB_i) * 3;
                    for (int j = 0; j < NB_i; j++) {
                        const size_t o = baseB + (size_t)j * 3;
                        const double x0 = (double)B[o + (size_t)m.ax0];
                        const double x1 = (double)B[o + (size_t)m.ax1];
                        const double x2 = (double)B[o + (size_t)m.ax2];
                        b0[(size_t)j] = pw0 ? wrap01_for_index(x0) : x0;
                        b1[(size_t)j] = pw1 ? wrap01_for_index(x1) : x1;
                        b2[(size_t)j] = pw2 ? wrap01_for_index(x2) : x2;
                    }
                    bins3.build(b0.data(), b1.data(), b2.data(), NB_i, M3, r_max);
                }
                else if (m.dim == 2) {
                    b0.resize((size_t)NB_i);
                    b1.resize((size_t)NB_i);
                    const size_t baseB = ((size_t)t1 * (size_t)NB_i) * 3;
                    for (int j = 0; j < NB_i; j++) {
                        const size_t o = baseB + (size_t)j * 3;
                        const double x0 = (double)B[o + (size_t)m.ax0];
                        const double x1 = (double)B[o + (size_t)m.ax1];
                        b0[(size_t)j] = pw0 ? wrap01_for_index(x0) : x0;
                        b1[(size_t)j] = pw1 ? wrap01_for_index(x1) : x1;
                    }
                    bins2.build(b0.data(), b1.data(), NB_i, M2, r_max);
                }
                else {
                    b0.resize((size_t)NB_i);
                    const size_t baseB = ((size_t)t1 * (size_t)NB_i) * 3;
                    for (int j = 0; j < NB_i; j++) {
                        const size_t o = baseB + (size_t)j * 3;
                        const double x0 = (double)B[o + (size_t)m.ax0];
                        b0[(size_t)j] = pw0 ? wrap01_for_index(x0) : x0;
                    }
                }

                const bool full_x3 = (m.dim == 3) && pw0 && (bins3.nx <= 2 * bins3.kx);
                const bool full_y3 = (m.dim == 3) && pw1 && (bins3.ny <= 2 * bins3.ky);
                const bool full_z3 = (m.dim == 3) && pw2 && (bins3.nz <= 2 * bins3.kz);
                const bool full_x2 = (m.dim == 2) && pw0 && (bins2.nx <= 2 * bins2.kx);
                const bool full_y2 = (m.dim == 2) && pw1 && (bins2.ny <= 2 * bins2.ky);

                // variable cell mapping: T01 = cell0 * inv(cell1)
                const bool need_map = !cell_static;
                double inv_cell1[3][3];
                bool inv_ok = true;
                if (need_map) {
                    invert3x3(cell1, inv_cell1, inv_ok);
                }
                if (need_map && !inv_ok) {
                    // skip both numerator and denominator for this origin frame
                    continue;
                }

                for (int ki = 0; ki < k_stop; ki++) {
                    const int li = lags_ptr[(size_t)ki];
                    const int t0 = t1 - li;
                    L.cnt[(size_t)ki] += 1.0;
                    L.sumfac[(size_t)ki] += (double)NA_i * rhoB;
                    double* row = &L.hist[(size_t)ki * (size_t)nbins];

                    double T01[3][3];
                    if (need_map) {
                        double cell0[3][3];
                        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) cell0[i][j] = C[(size_t)t0 * 9 + (size_t)i * 3 + (size_t)j];
                        mul3x3(cell0, inv_cell1, T01);
                    }

                    if (m.dim == 3) {
                        const size_t baseA0 = ((size_t)t0 * (size_t)NA_i) * 3;
                        for (int i = 0; i < NA_i; i++) {
                            double s0p0, s0p1, s0p2;
                            const size_t oa = baseA0 + (size_t)i * 3;
                            if (!need_map) {
                                s0p0 = (double)A[oa + 0];
                                s0p1 = (double)A[oa + 1];
                                s0p2 = (double)A[oa + 2];
                            }
                            else {
                                const double s0[3] = { (double)A[oa + 0], (double)A[oa + 1], (double)A[oa + 2] };
                                double s1[3];
                                mul_rowvec3(s0, T01, s1);
                                s0p0 = s1[0];
                                s0p1 = s1[1];
                                s0p2 = s1[2];
                            }
                            const double a0_raw = (m.ax0 == 0) ? s0p0 : (m.ax0 == 1 ? s0p1 : s0p2);
                            const double a1_raw = (m.ax1 == 0) ? s0p0 : (m.ax1 == 1 ? s0p1 : s0p2);
                            const double a2_raw = (m.ax2 == 0) ? s0p0 : (m.ax2 == 1 ? s0p1 : s0p2);
                            const double a0 = pw0 ? wrap01_for_index(a0_raw) : a0_raw;
                            const double a1 = pw1 ? wrap01_for_index(a1_raw) : a1_raw;
                            const double a2 = pw2 ? wrap01_for_index(a2_raw) : a2_raw;

                            const int ix = std::min(bins3.nx - 1, std::max(0, (int)std::floor(a0 * bins3.nx)));
                            const int iy = std::min(bins3.ny - 1, std::max(0, (int)std::floor(a1 * bins3.ny)));
                            const int iz = std::min(bins3.nz - 1, std::max(0, (int)std::floor(a2 * bins3.nz)));

                            const int dx0 = full_x3 ? 0 : -bins3.kx;
                            const int dx1 = full_x3 ? bins3.nx : (bins3.kx + 1);
                            const int dy0 = full_y3 ? 0 : -bins3.ky;
                            const int dy1 = full_y3 ? bins3.ny : (bins3.ky + 1);
                            const int dz0 = full_z3 ? 0 : -bins3.kz;
                            const int dz1 = full_z3 ? bins3.nz : (bins3.kz + 1);

                            for (int dx = dx0; dx < dx1; ++dx) {
                                int jx = full_x3 ? dx : (ix + dx);
                                if (!full_x3) {
                                    if (pw0) { jx = (jx % bins3.nx + bins3.nx) % bins3.nx; }
                                    else if (jx < 0 || jx >= bins3.nx) continue;
                                }
                                for (int dy = dy0; dy < dy1; ++dy) {
                                    int jy = full_y3 ? dy : (iy + dy);
                                    if (!full_y3) {
                                        if (pw1) { jy = (jy % bins3.ny + bins3.ny) % bins3.ny; }
                                        else if (jy < 0 || jy >= bins3.ny) continue;
                                    }
                                    for (int dz = dz0; dz < dz1; ++dz) {
                                        int jz = full_z3 ? dz : (iz + dz);
                                        if (!full_z3) {
                                            if (pw2) { jz = (jz % bins3.nz + bins3.nz) % bins3.nz; }
                                            else if (jz < 0 || jz >= bins3.nz) continue;
                                        }
                                        const std::size_t bb = ((std::size_t)jx * (std::size_t)bins3.ny + (std::size_t)jy) * (std::size_t)bins3.nz + (std::size_t)jz;
                                        for (int j = bins3.head[bb]; j != -1; j = bins3.next[(size_t)j]) {
                                            if (same && j == i) continue;
                                            const double d0 = b0[(size_t)j] - a0;
                                            const double d1 = b1[(size_t)j] - a1;
                                            const double d2 = b2[(size_t)j] - a2;
                                            const double r2 = r2_dim3(d0, d1, d2, pw0, pw1, pw2, mm0, mm1, mm2, M3);
                                            if (r2 < r2_max) {
                                                const int k = (int)(std::sqrt(r2) * inv_dr);
                                                if (k < nbins) row[(size_t)k] += 1.0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (m.dim == 2) {
                        const size_t baseA0 = ((size_t)t0 * (size_t)NA_i) * 3;
                        for (int i = 0; i < NA_i; i++) {
                            double s0p0, s0p1, s0p2;
                            const size_t oa = baseA0 + (size_t)i * 3;
                            if (!need_map) {
                                s0p0 = (double)A[oa + 0];
                                s0p1 = (double)A[oa + 1];
                                s0p2 = (double)A[oa + 2];
                            }
                            else {
                                const double s0[3] = { (double)A[oa + 0], (double)A[oa + 1], (double)A[oa + 2] };
                                double s1[3];
                                mul_rowvec3(s0, T01, s1);
                                s0p0 = s1[0];
                                s0p1 = s1[1];
                                s0p2 = s1[2];
                            }
                            const double a0_raw = (m.ax0 == 0) ? s0p0 : (m.ax0 == 1 ? s0p1 : s0p2);
                            const double a1_raw = (m.ax1 == 0) ? s0p0 : (m.ax1 == 1 ? s0p1 : s0p2);
                            const double a0 = pw0 ? wrap01_for_index(a0_raw) : a0_raw;
                            const double a1 = pw1 ? wrap01_for_index(a1_raw) : a1_raw;

                            const int ix = std::min(bins2.nx - 1, std::max(0, (int)std::floor(a0 * bins2.nx)));
                            const int iy = std::min(bins2.ny - 1, std::max(0, (int)std::floor(a1 * bins2.ny)));

                            const int dx0 = full_x2 ? 0 : -bins2.kx;
                            const int dx1 = full_x2 ? bins2.nx : (bins2.kx + 1);
                            const int dy0 = full_y2 ? 0 : -bins2.ky;
                            const int dy1 = full_y2 ? bins2.ny : (bins2.ky + 1);
                            for (int dx = dx0; dx < dx1; ++dx) {
                                int jx = full_x2 ? dx : (ix + dx);
                                if (!full_x2) {
                                    if (pw0) { jx = (jx % bins2.nx + bins2.nx) % bins2.nx; }
                                    else if (jx < 0 || jx >= bins2.nx) continue;
                                }
                                for (int dy = dy0; dy < dy1; ++dy) {
                                    int jy = full_y2 ? dy : (iy + dy);
                                    if (!full_y2) {
                                        if (pw1) { jy = (jy % bins2.ny + bins2.ny) % bins2.ny; }
                                        else if (jy < 0 || jy >= bins2.ny) continue;
                                    }
                                    const std::size_t bb = (std::size_t)jx * (std::size_t)bins2.ny + (std::size_t)jy;
                                    for (int j = bins2.head[bb]; j != -1; j = bins2.next[(size_t)j]) {
                                        if (same && j == i) continue;
                                        const double d0 = b0[(size_t)j] - a0;
                                        const double d1 = b1[(size_t)j] - a1;
                                        const double r2 = r2_dim2(d0, d1, pw0, pw1, mm0, mm1, M2);
                                        if (r2 < r2_max) {
                                            const int k = (int)(std::sqrt(r2) * inv_dr);
                                            if (k < nbins) row[(size_t)k] += 1.0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else {
                        const size_t baseA0 = ((size_t)t0 * (size_t)NA_i) * 3;
                        for (int i = 0; i < NA_i; i++) {
                            double s0p0, s0p1, s0p2;
                            const size_t oa = baseA0 + (size_t)i * 3;
                            if (!need_map) {
                                s0p0 = (double)A[oa + 0];
                                s0p1 = (double)A[oa + 1];
                                s0p2 = (double)A[oa + 2];
                            }
                            else {
                                const double s0[3] = { (double)A[oa + 0], (double)A[oa + 1], (double)A[oa + 2] };
                                double s1[3];
                                mul_rowvec3(s0, T01, s1);
                                s0p0 = s1[0];
                                s0p1 = s1[1];
                                s0p2 = s1[2];
                            }
                            const double a0_raw = (m.ax0 == 0) ? s0p0 : (m.ax0 == 1 ? s0p1 : s0p2);
                            const double a0 = pw0 ? wrap01_for_index(a0_raw) : a0_raw;
                            for (int j = 0; j < NB_i; j++) {
                                if (same && j == i) continue;
                                const double d0 = b0[(size_t)j] - a0;
                                const double r2 = r2_dim1(d0, pw0, mm0, M1);
                                if (r2 < r2_max) {
                                    const int k = (int)(std::sqrt(r2) * inv_dr);
                                    if (k < nbins) row[(size_t)k] += 1.0;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (...) {
            eptr = std::current_exception();
        }
    };

    {
        py::gil_scoped_release release;

        const int n_use = std::max(1, std::min(n_threads, S));
        std::vector<std::thread> threads;
        std::vector<std::exception_ptr> eps((size_t)n_use);
        threads.reserve((size_t)n_use);
        for (int ti = 0; ti < n_use; ti++) {
            threads.emplace_back([&, ti]() {
                for (int si = ti; si < S; si += n_use) compute_slice(si, eps[(size_t)ti]);
            });
        }
        for (auto& th : threads) th.join();
        for (const auto& ep : eps) if (ep) std::rethrow_exception(ep);

        // reduce
        for (int si = 0; si < S; si++) {
            const LocalBuf& L = locals[(size_t)si];
            if (L.cnt.empty()) continue;
            for (int ki = 0; ki < K; ki++) {
                Sd[(size_t)ki] += L.sumfac[(size_t)ki];
                Nd[(size_t)ki] += L.cnt[(size_t)ki];
            }
            const double* src = L.hist.data();
            for (int ki = 0; ki < K; ki++) {
                double* dst = Hd + (size_t)ki * (size_t)nbins;
                const double* src_row = src + (size_t)ki * (size_t)nbins;
                for (int k = 0; k < nbins; k++) dst[(size_t)k] += src_row[(size_t)k];
            }
        }

        // normalize in-place to density
        for (int ki = 0; ki < K; ki++) {
            const double fac = normalize ? Sd[(size_t)ki] : (Nd[(size_t)ki] * (double)NA_i);
            double* row = Hd + (size_t)ki * (size_t)nbins;
            if (fac <= 0.0) {
                std::fill(row, row + nbins, 0.0);
                continue;
            }
            for (int k = 0; k < nbins; k++) {
                const double den = fac * shell[(size_t)k];
                row[(size_t)k] = (den > 0.0) ? (row[(size_t)k] / den) : 0.0;
            }
        }
    }

    return py::make_tuple(Gd, sum_fac_d, cnt_d);
}

// =====================================================================================
// Dispatch + pybind
// =====================================================================================

static py::tuple vhf_self_dispatch(
    py::array posA_unwrap,
    py::array cell,
    double r_max,
    double dr,
    int nbins,
    int mode_int,
    int n_threads,
    py::array lags,
    py::array lag_idx_slices,
    bool cell_static
) {
    const auto dtU = posA_unwrap.dtype();
    if (dtU.is(py::dtype::of<float>())) {
        return vhf_self_impl<float>(
            posA_unwrap.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            r_max, dr, nbins, mode_int, n_threads,
            lags.cast<py::array_t<int32_t>>(),
            lag_idx_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    if (dtU.is(py::dtype::of<double>())) {
        return vhf_self_impl<double>(
            posA_unwrap.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            r_max, dr, nbins, mode_int, n_threads,
            lags.cast<py::array_t<int32_t>>(),
            lag_idx_slices.cast<py::array_t<int32_t>>(),
            cell_static
        );
    }
    throw std::invalid_argument("posA_unwrap dtype must be float32 or float64");
}

static py::tuple vhf_distinct_dispatch(
    py::array posA,
    py::array posB,
    py::array cell,
    py::array pbc,
    py::array vol,
    bool periodic_all,
    bool cell_static,
    bool same,
    double r_max,
    double dr,
    int nbins,
    int mode_int,
    int n_threads,
    py::array lags,
    py::array t1_slices,
    bool normalize
) {
    const auto dtA = posA.dtype();
    const auto dtB = posB.dtype();
    if (!dtA.is(dtB)) {
        throw std::invalid_argument("posA/posB must have the same dtype (float32 or float64)");
    }
    if (dtA.is(py::dtype::of<float>())) {
        return vhf_distinct_impl<float>(
            posA.cast<py::array_t<float>>(),
            posB.cast<py::array_t<float>>(),
            cell.cast<py::array_t<double>>(),
            pbc.cast<py::array_t<bool>>(),
            vol.cast<py::array_t<double>>(),
            periodic_all, cell_static, same,
            r_max, dr, nbins, mode_int, n_threads,
            lags.cast<py::array_t<int32_t>>(),
            t1_slices.cast<py::array_t<int32_t>>(),
            normalize
        );
    }
    if (dtA.is(py::dtype::of<double>())) {
        return vhf_distinct_impl<double>(
            posA.cast<py::array_t<double>>(),
            posB.cast<py::array_t<double>>(),
            cell.cast<py::array_t<double>>(),
            pbc.cast<py::array_t<bool>>(),
            vol.cast<py::array_t<double>>(),
            periodic_all, cell_static, same,
            r_max, dr, nbins, mode_int, n_threads,
            lags.cast<py::array_t<int32_t>>(),
            t1_slices.cast<py::array_t<int32_t>>(),
            normalize
        );
    }
    throw std::invalid_argument("posA dtype must be float32 or float64");
}


PYBIND11_MODULE(vhf_ext, m) {
    m.doc() = "Van Hove correlation function kernels for Ripple (self/distinct split)";
    m.def(
        "vhf_self",
        &vhf_self_dispatch,
        py::arg("posA_unwrap"),
        py::arg("cell"),
        py::arg("r_max"),
        py::arg("dr"),
        py::arg("nbins"),
        py::arg("mode_int"),
        py::arg("n_threads"),
        py::arg("lags"),
        py::arg("lag_idx_slices"),
        py::arg("cell_static")
    );

    m.def(
        "vhf_distinct",
        &vhf_distinct_dispatch,
        py::arg("posA"),
        py::arg("posB"),
        py::arg("cell"),
        py::arg("pbc"),
        py::arg("vol"),
        py::arg("periodic_all"),
        py::arg("cell_static"),
        py::arg("same"),
        py::arg("r_max"),
        py::arg("dr"),
        py::arg("nbins"),
        py::arg("mode_int"),
        py::arg("n_threads"),
        py::arg("lags"),
        py::arg("t1_slices"),
        py::arg("normalize") = true
    );
}
