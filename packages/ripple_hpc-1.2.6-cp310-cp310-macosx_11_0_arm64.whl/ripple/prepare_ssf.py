import os
import warnings
import itertools
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True, slots=True)
class SSFResult:
    ssf: np.ndarray
    shell: np.ndarray


@dataclass(frozen=True, slots=True)
class PreparedSSFTrajectory:
    """Prepared SSF trajectory object returned by prepare_ssf(...).

    Usage:
        traj = prepare_ssf(trajectory, "Li", "Li", trajectory_tag="750K_0v")
        ssf_res = traj.ssf_cal(k_max=20.0, dk_shell=0.2, n_workers=32)
        S, k = ssf_res.ssf, ssf_res.shell
        traj.clean()  # remove the cache directory (optional)
    """

    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_a: int
    n_b: int
    same: bool
    periodic_all: bool
    cell_static: bool
    wrap: bool
    scaled: bool
    pos_dtype: str
    cell_sigma_max: float
    target_atoms1: str
    target_atoms2: str
    cell_path: str
    posA_path: str
    posB_path: str
    meta_path: str

    def __post_init__(self) -> None:
        if not np.isfinite(self.cell_sigma_max) or self.cell_sigma_max <= 0.0:
            raise ValueError("cell_sigma_max must be finite and > 0.")

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")

    def ssf_cal(
        self,
        k_max: float = 20.0,
        dk_shell: float = 0.1,
        n_workers: int = 1,
        *,
        k_min: float = 0.0,
        half_sphere: bool = True,
        max_points: int | None = None,
        seed: int = 42,
    ) -> SSFResult:
        """Shell-averaged partial static structure factor S(|q|).

        Definitions (for q != 0):
          - same (A == B):   S_AA(q) = < |rho_A(q)|^2 / N_A >
          - cross (A != B):  S_AB(q) = < Re[rho_A(q) rho_B(q)^*] / sqrt(N_A N_B) >

        Notes:
          - SSF requires full 3D PBC for all frames; enforced in prepare_ssf().
          - cell_static=True: precompute shell_id once in Python and call the faster kernel.
          - cell_static=False: kernel bins on-the-fly using cell(t).
          - max_points is only supported when cell_static=True.
        """
        from ripple.kernel.ssf_ext import ssf_shell_static, ssf_shell_varcell

        if not self.periodic_all:
            raise ValueError("SSF requires full 3D PBC for all frames (pbc=True in all directions).")

        k_max = float(k_max)
        dk_shell = float(dk_shell)
        k_min = float(k_min)
        if k_max <= 0.0 or dk_shell <= 0.0:
            raise ValueError("k_max and dk_shell must be > 0.")
        if not (0.0 <= k_min < k_max):
            raise ValueError("k_min must satisfy 0 <= k_min < k_max.")
        if (not self.cell_static) and (max_points is not None):
            raise ValueError("max_points is only supported when cell_static=True (fixed cell).")

        # uniform bins; last bin may be partially filled
        nbins = int(np.ceil(k_max / dk_shell))
        if nbins < 1:
            raise ValueError("k_max/dk_shell too small: nbins < 1.")
        k_edges = np.arange(nbins + 1, dtype=np.float64) * dk_shell
        k_shell = 0.5 * (k_edges[:-1] + k_edges[1:])

        cache_dir = Path(self.cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)

        # --- 1) build a *safe* integer search box for n=(h,k,l) ---
        # We need a superset of all integer triplets that can possibly satisfy |q|<=k_max.
        # Using only per-axis bounds can miss cancellation in skew lattices; instead we bound ||n||
        # via the smallest singular value of the reciprocal matrix:
        #     |q| = |n B| >= sigma_min(B) |n|  =>  |n| <= k_max / sigma_min(B)
        # For B = 2pi * inv(cell^T), we have sigma_min(B) = 2pi / sigma_max(cell).
        TWO_PI = 2.0 * np.pi
        sigma_max_cell = self.cell_sigma_max
        sigma_min_rec = TWO_PI / sigma_max_cell
        n_box = int(np.ceil(k_max / sigma_min_rec)) + 1
        if n_box < 1:
            raise ValueError("k_max too small: no reciprocal points.")

        sig_grid = "".join(
            ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"n{n_box}_hs{int(bool(half_sphere))}"
        )[:140]
        k_int_raw_path = cache_dir / f"k_int_raw_{sig_grid}.npy"

        # raw integer triplets, excluding (0,0,0)
        # shape: (NK, 3) int32
        need_build = True
        if k_int_raw_path.exists():
            try:
                mm = np.lib.format.open_memmap(k_int_raw_path, mode="r")
                need_build = not (mm.ndim == 2 and mm.shape[1] == 3 and mm.dtype == np.int32)
                del mm
            except Exception:
                need_build = True

        if need_build:
            kk = np.arange(-n_box, n_box + 1, dtype=np.int32)
            ll = np.arange(-n_box, n_box + 1, dtype=np.int32)
            K, L = np.meshgrid(kk, ll, indexing="ij")
            k_flat = K.ravel()
            l_flat = L.ravel()

            blocks: list[np.ndarray] = []
            if half_sphere:
                h_iter = range(0, n_box + 1)
            else:
                h_iter = range(-n_box, n_box + 1)

            for h in h_iter:
                h_col = np.full_like(k_flat, int(h), dtype=np.int32)
                if h == 0:
                    if half_sphere:
                        mask = (k_flat > 0) | ((k_flat == 0) & (l_flat > 0))
                    else:
                        mask = ~((k_flat == 0) & (l_flat == 0))
                else:
                    mask = np.ones_like(k_flat, dtype=bool)
                if np.any(mask):
                    blocks.append(np.stack([h_col[mask], k_flat[mask], l_flat[mask]], axis=1))

            if not blocks:
                raise ValueError("No k-points generated (empty bounds).")
            n_int = np.concatenate(blocks, axis=0)
            if n_int.size == 0:
                raise ValueError("No k-points generated (check k_max).")
            np.save(k_int_raw_path, n_int.astype(np.int32, copy=False))

        n_int_raw = np.lib.format.open_memmap(k_int_raw_path, mode="r")

        # --- 2) choose k_int and (optional) shell_id for the kernel ---
        # For static cell we can pre-filter and pre-bin points once.
        if self.cell_static:
            sig_static = "".join(
                ch if (ch.isalnum() or ch in "._-") else "_"
                for ch in (
                    f"{sig_grid}_kmax{float(k_max):.6g}_kmin{float(k_min):.6g}_dk{float(dk_shell):.6g}_"
                    f"mp{max_points}_sd{(int(seed) if (max_points is not None) else 0)}"
                )
            )[:140]
            k_int_path = cache_dir / f"k_int_{sig_static}.npy"
            shell_id_path = cache_dir / f"shell_id_{sig_static}.npy"

            ok_static = False
            if k_int_path.exists() and shell_id_path.exists():
                try:
                    mm1 = np.lib.format.open_memmap(k_int_path, mode="r")
                    mm2 = np.lib.format.open_memmap(shell_id_path, mode="r")
                    ok_static = (
                        mm1.ndim == 2
                        and mm1.shape[1] == 3
                        and mm1.dtype == np.int32
                        and mm2.ndim == 1
                        and mm2.dtype == np.int32
                        and mm2.shape[0] == mm1.shape[0]
                    )
                    del mm1, mm2
                except Exception:
                    ok_static = False

            if not ok_static:
                # cell0 -> reciprocal
                cell_mm = np.lib.format.open_memmap(self.cell_path, mode="r")
                cell0 = np.array(cell_mm[0], dtype=np.float64, copy=True)
                del cell_mm
                if cell0.shape != (3, 3):
                    raise ValueError(f"cell must be shape (3,3), got {cell0.shape}")
                det = float(np.linalg.det(cell0))
                if not np.isfinite(det) or abs(det) < 1e-14:
                    raise ValueError("Singular/degenerate cell detected. SSF requires a full-rank 3D periodic cell.")
                rec0 = (TWO_PI) * np.linalg.inv(cell0.T)
                G = rec0 @ rec0.T  # metric for |q|^2 = n G n^T

                NK = int(n_int_raw.shape[0])
                keep_list: list[np.ndarray] = []
                sid_list: list[np.ndarray] = []
                eps = 1e-12

                # chunking avoids allocating a huge (NK,3) float64 in one go
                chunk = 1_000_000
                for i0 in range(0, NK, chunk):
                    i1 = min(i0 + chunk, NK)
                    n_block_i32 = n_int_raw[i0:i1]
                    n_block = np.asarray(n_block_i32, dtype=np.float64)
                    # qn^2 via quadratic form
                    qn2 = np.einsum("ni,ij,nj->n", n_block, G, n_block, optimize=True)
                    qn = np.sqrt(qn2)
                    sid = np.floor(qn / dk_shell).astype(np.int32)
                    valid = (qn > (k_min + eps)) & (qn <= (k_max + eps)) & (sid >= 0) & (sid < nbins)
                    if np.any(valid):
                        keep_list.append(n_block_i32[valid].astype(np.int32, copy=False))
                        sid_list.append(sid[valid].astype(np.int32, copy=False))

                if not keep_list:
                    raise ValueError("No valid q-points after k_min/k_max filtering.")

                n_keep = np.concatenate(keep_list, axis=0)
                sid_keep = np.concatenate(sid_list, axis=0)

                # optional per-shell subsampling (useful for huge NK)
                if max_points is not None:
                    mp = int(max_points)
                    if mp > 0 and n_keep.shape[0] > mp:
                        rng = np.random.default_rng(int(seed))
                        counts = np.bincount(sid_keep, minlength=nbins)
                        shells = np.flatnonzero(counts)
                        per_shell = max(1, mp // max(int(shells.size), 1))
                        mask = np.zeros(n_keep.shape[0], dtype=bool)
                        for sh in shells:
                            idx = np.flatnonzero(sid_keep == sh)
                            if idx.size <= per_shell:
                                mask[idx] = True
                            else:
                                pick = rng.choice(idx, size=per_shell, replace=False)
                                mask[pick] = True
                        n_keep = n_keep[mask]
                        sid_keep = sid_keep[mask]

                np.save(k_int_path, n_keep.astype(np.int32, copy=False))
                np.save(shell_id_path, sid_keep.astype(np.int32, copy=False))

            # finalized
            k_int_path_use = str(k_int_path)
            shell_id_path_use: str | None = str(shell_id_path)
        else:
            k_int_path_use = str(k_int_raw_path)
            shell_id_path_use = None

        # release the raw k-point memmap early to avoid Windows file-handle issues when calling clean()
        try:
            del n_int_raw
        except Exception:
            pass

        # --- 3) threaded kernel over frames ---
        n_workers = int(n_workers)
        if n_workers < 1:
            raise ValueError("n_workers must be >= 1.")
        # optional clamp to available cpus
        avail = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
        if avail < n_workers:
            warnings.warn(f"Only {avail} CPUs are available, but n_workers={n_workers}. Clamping -> {avail}.", RuntimeWarning)
            n_workers = avail
        if self.n_frames < n_workers:
            warnings.warn(
                f"Only {self.n_frames} frames available but requested n_workers={n_workers}. Clamping -> {self.n_frames}.",
                RuntimeWarning,
            )
            n_workers = self.n_frames

        posA = np.lib.format.open_memmap(self.posA_path, mode="r")
        posB = posA if self.same or (self.posB_path == self.posA_path) else np.lib.format.open_memmap(self.posB_path, mode="r")
        k_int = np.lib.format.open_memmap(k_int_path_use, mode="r")
        cell = None
        shell_id = None
        try:
            if self.cell_static:
                if shell_id_path_use is None:
                    raise ValueError("shell_id cache is missing for static-cell SSF.")
                shell_id = np.lib.format.open_memmap(shell_id_path_use, mode="r")
                sum_tot, cnt_tot = ssf_shell_static(
                    posA,
                    posB,
                    k_int,
                    shell_id,
                    bool(self.same),
                    0,
                    int(self.n_frames),
                    int(nbins),
                    int(n_workers),
                )
            else:
                cell = np.lib.format.open_memmap(self.cell_path, mode="r")
                sum_tot, cnt_tot = ssf_shell_varcell(
                    posA,
                    posB,
                    cell,
                    k_int,
                    float(k_min),
                    float(k_max),
                    float(dk_shell),
                    bool(self.same),
                    0,
                    int(self.n_frames),
                    int(nbins),
                    int(n_workers),
                )
        finally:
            del posA, posB, k_int
            if cell is not None:
                del cell
            if shell_id is not None:
                del shell_id

        ssf = np.full(nbins, np.nan, dtype=np.float64)
        mask = cnt_tot > 0
        ssf[mask] = sum_tot[mask] / cnt_tot[mask]
        return SSFResult(ssf, k_shell)


def prepare_ssf(
    trajectory,
    target_atoms1: str,
    target_atoms2: str,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> PreparedSSFTrajectory:
    """Cache an ASE trajectory into memmaps for SSF.

    Cached arrays:
      - positionsA: (T, N_A, 3) scaled coords (float32/float64)
      - positionsB: (T, N_B, 3) scaled coords (float32/float64) (same-species => reuse A)
      - cell:       (T, 3, 3)   float64 (ASE row-vectors)

    SSF is only well-defined for full 3D periodic boundary conditions (pbc=True in all directions)
    for all frames. Any non-periodic frame will raise.
    """
    scaled = True
    wrap = True

    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be a boolean.")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings.")
    if not isinstance(target_atoms1, str) or not isinstance(target_atoms2, str):
        raise TypeError("target_atoms1/2 must be strings.")
    if n_frames is not None and (not isinstance(n_frames, int) or n_frames < 1):
        raise ValueError("n_frames must be a positive int or None.")

    # sanitize tag (inline, like prepare_rdf)
    trajectory_tag = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in str(trajectory_tag))[:120]
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn(
            "Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!",
            RuntimeWarning,
        )

    save_dir_p = Path(save_dir)
    save_dir_p.mkdir(parents=True, exist_ok=True)
    cache_dir = save_dir_p / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")

    # -------------------- resolve n_frames / iterator factory --------------------
    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True

        def make_iter():
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter():
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_ssf(): trajectory is a factory but n_frames is None; "
                "this will iterate the trajectory twice (count + write).",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. "
                "Pass n_frames=..., or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter():
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    # -------------------- read first frame (define selections + validate shapes) --------------------
    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration:
        raise ValueError("Empty trajectory.")

    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_a_full = (species_list == target_atoms1)
    is_b_full = (species_list == target_atoms2)
    n_a = int(is_a_full.sum())
    n_b = int(is_b_full.sum())
    if n_a < 1:
        raise ValueError(f"No atoms found for target_atoms1={target_atoms1}")
    if n_b < 1:
        raise ValueError(f"No atoms found for target_atoms2={target_atoms2}")

    same = (target_atoms1 == target_atoms2)
    idx_a_full = np.flatnonzero(is_a_full).astype(np.int64)
    idx_b_full = idx_a_full if same else np.flatnonzero(is_b_full).astype(np.int64)

    # -------------------- file paths --------------------
    feature = f"{material_name}_sc{int(scaled)}_wr{int(wrap)}_{datatype.name}"
    meta_path = cache_dir / f"meta_{target_atoms1}_{target_atoms2}_{feature}.npz"
    cell_path = cache_dir / f"cell_{target_atoms1}_{target_atoms2}_{feature}.cell.npy"
    posA_path = cache_dir / f"positionsA_{target_atoms1}_{feature}.pos.npy"
    posB_path = posA_path if same else (cache_dir / f"positionsB_{target_atoms2}_{feature}.pos.npy")

    # -------------------- reuse_memmap check --------------------
    if reuse_memmap:
        ok_all = False
        try:
            if meta_path.exists() and cell_path.exists() and posA_path.exists() and (same or posB_path.exists()):
                mmA = np.lib.format.open_memmap(posA_path, mode="r")
                okA = (mmA.shape == (T, n_a, 3) and mmA.dtype == datatype)
                del mmA
                if same:
                    okB = okA
                else:
                    mmB = np.lib.format.open_memmap(posB_path, mode="r")
                    okB = (mmB.shape == (T, n_b, 3) and mmB.dtype == datatype)
                    del mmB
                mmC = np.lib.format.open_memmap(cell_path, mode="r")
                okC = (mmC.shape == (T, 3, 3) and mmC.dtype == np.float64)
                del mmC
                ok_all = bool(okA and okB and okC)
        except Exception:
            ok_all = False

        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                periodic_all = bool(meta["periodic_all"])
                if not periodic_all:
                    raise ValueError("Cached SSF trajectory is not fully periodic; SSF requires full PBC.")
                cell_static = bool(meta["cell_static"])
                if "cell_sigma_max" in meta.files:
                    cell_sigma_max = float(meta["cell_sigma_max"])
                else:
                    # backward-compat for older caches: compute from cell memmap (cheap: 9*T floats)
                    mmC = np.lib.format.open_memmap(cell_path, mode="r")
                    cell_sigma_max = 0.0
                    for t in range(int(mmC.shape[0])):
                        cell = np.asarray(mmC[t], dtype=np.float64)
                        eigs = np.linalg.eigvalsh(cell.T @ cell)
                        sigma_t = float(np.sqrt(np.max(eigs)))
                        if sigma_t > cell_sigma_max:
                            cell_sigma_max = sigma_t
                    del mmC
            return PreparedSSFTrajectory(
                cache_dir=str(cache_dir),
                trajectory_tag=trajectory_tag,
                save_dir=str(save_dir),
                feature=feature,
                material_name=material_name,
                n_frames=int(T),
                n_a=int(n_a),
                n_b=int(n_b),
                same=bool(same),
                periodic_all=True,
                cell_static=bool(cell_static),
                wrap=bool(wrap),
                scaled=bool(scaled),
                pos_dtype=str(datatype.name),
                cell_sigma_max=cell_sigma_max,
                target_atoms1=str(target_atoms1),
                target_atoms2=str(target_atoms2),
                cell_path=str(cell_path),
                posA_path=str(posA_path),
                posB_path=str(posB_path),
                meta_path=str(meta_path),
            )

    # -------------------- build memmaps --------------------
    created_paths: list[Path] = [meta_path]
    posA_mm = posB_mm = cell_mm = None
    try:
        posA_mm = np.lib.format.open_memmap(posA_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_path)
        if not same:
            posB_mm = np.lib.format.open_memmap(posB_path, mode="w+", dtype=datatype, shape=(T, n_b, 3))
            created_paths.append(posB_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)
        t_last = -1
        periodic_all = True
        cell_static = True
        cell0 = None

        cell_sigma_max = 0.0

        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t

            # scaled positions (periodic unwrap is meaningless for SSF; we want PBC wrapping)
            s = frame.get_scaled_positions(wrap=wrap)
            if s.ndim != 2 or s.shape[1] != 3:
                raise ValueError(f"Expected scaled positions (N,3) at t={t}. Got {s.shape}.")
            posA_mm[t] = s[idx_a_full]
            if not same:
                posB_mm[t] = s[idx_b_full]

            cell = np.asarray(frame.cell, dtype=np.float64)
            if cell.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell.shape}.")
            det = float(np.linalg.det(cell))
            if not np.isfinite(det) or abs(det) < 1e-14:
                raise ValueError(
                    "Singular/degenerate cell detected. SSF requires a full-rank 3D periodic cell."
                )
            cell_mm[t] = cell

            if t == 0:
                cell0 = cell.copy()
            elif cell_static:
                if np.max(np.abs(cell - cell0)) > 1e-10:
                    cell_static = False

            # sigma_max(cell) = sqrt(max_eig(cell^T cell))
            eigs = np.linalg.eigvalsh(cell.T @ cell)
            sigma_t = float(np.sqrt(np.max(eigs)))
            if sigma_t > cell_sigma_max:
                cell_sigma_max = sigma_t

            pbc = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc.shape}.")
            periodic_all &= bool(np.all(pbc))

        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last + 1} frames.")
        if not periodic_all:
            raise ValueError("Non-periodic frame detected. SSF requires full PBC in all directions for all frames.")

        # flush
        posA_mm.flush()
        cell_mm.flush()
        if posB_mm is not None:
            posB_mm.flush()

        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_a=np.int64(n_a),
            n_b=np.int64(n_b),
            same=np.bool_(same),
            scaled=np.bool_(scaled),
            wrap=np.bool_(wrap),
            pos_dtype=str(datatype.name),
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            cell_sigma_max=np.float64(cell_sigma_max),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
            trajectory_tag=str(trajectory_tag),
            material_name=str(material_name),
        )
    except Exception:
        try:
            del posA_mm, posB_mm, cell_mm
        except Exception:
            pass
        for p in created_paths:
            try:
                Path(p).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del posA_mm, posB_mm, cell_mm
        except Exception:
            pass

    return PreparedSSFTrajectory(
        cache_dir=str(cache_dir),
        trajectory_tag=trajectory_tag,
        save_dir=str(save_dir),
        feature=feature,
        material_name=material_name,
        n_frames=int(T),
        n_a=int(n_a),
        n_b=int(n_b),
        same=bool(same),
        periodic_all=True,
        cell_static=bool(cell_static),
        wrap=bool(wrap),
        scaled=bool(scaled),
        pos_dtype=str(datatype.name),
        cell_sigma_max=float(cell_sigma_max),
        target_atoms1=str(target_atoms1),
        target_atoms2=str(target_atoms2),
        cell_path=str(cell_path),
        posA_path=str(posA_path),
        posB_path=str(posB_path),
        meta_path=str(meta_path),
    )
