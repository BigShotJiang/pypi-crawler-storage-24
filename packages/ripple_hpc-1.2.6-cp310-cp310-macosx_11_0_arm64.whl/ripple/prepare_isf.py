from __future__ import annotations

import itertools
import os
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import numpy as np


@dataclass(frozen=True, slots=True)
class ISFResultSelf:
    """Shell-averaged self intermediate scattering function for selected lags."""

    Fs: np.ndarray
    q_count: np.ndarray
    cnt_s: np.ndarray
    q_shell: np.ndarray
    q_max: float
    dq_shell: float
    q_min: float
    mode: str
    lags: np.ndarray | None = None
    times_ps: np.ndarray | None = None
    timestep_ps: float | None = None


@dataclass(frozen=True, slots=True)
class ISFResultDistinct:
    """Shell-averaged distinct intermediate scattering function for selected lags."""

    Fd: np.ndarray
    q_count: np.ndarray
    cnt_d: np.ndarray
    q_shell: np.ndarray
    q_max: float
    dq_shell: float
    q_min: float
    mode: str
    same: bool
    lags: np.ndarray | None = None
    times_ps: np.ndarray | None = None
    timestep_ps: float | None = None


_MODE_MAP = {
    "abc": 1,
    "ab_lattice_project": 2,
    "ac_lattice_project": 3,
    "bc_lattice_project": 4,
    "a_lattice_project": 5,
    "b_lattice_project": 6,
    "c_lattice_project": 7,
}

_MODE_AXES = {
    1: (3, (0, 1, 2)),
    2: (2, (0, 1)),
    3: (2, (0, 2)),
    4: (2, (1, 2)),
    5: (1, (0,)),
    6: (1, (1,)),
    7: (1, (2,)),
}


@dataclass(frozen=True, slots=True)
class PreparedISF:
    """Prepared trajectory cache for shell-averaged intermediate scattering.

    The cache keeps both wrapped/scaled positions and unwrapped Cartesian
    positions because the two ISF variants use different reference data:
      - self ISF: displacement of the same atom between t0 and t1
      - distinct ISF: Fourier phases at t0/t1 with lattice mapping when cell(t)
        changes
    """

    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_a: int
    n_b: int
    same: bool
    periodic_all: bool
    cell_static: bool
    wrap: bool
    scaled: bool
    pos_dtype: str
    target_atoms1: str
    target_atoms2: str
    cell_path: str
    pbc_path: str
    posA_path: str
    posB_path: str
    posA_unwrap_path: str
    meta_path: str

    @staticmethod
    def _available_cpu_count() -> int:
        if hasattr(os, "sched_getaffinity"):
            try:
                return len(os.sched_getaffinity(0))
            except Exception:
                pass
        return int(os.cpu_count() or 1)

    @classmethod
    def _clamp_workers(cls, n_workers: int, n_frames: int) -> int:
        n_workers = int(n_workers)
        if n_workers < 1:
            raise ValueError("n_workers must be >= 1")

        avail = cls._available_cpu_count()
        if avail < n_workers:
            warnings.warn(
                f"Only {avail} CPUs are available, but n_workers={n_workers}. Clamping -> {avail}.",
                RuntimeWarning,
            )
            n_workers = avail
        if n_frames < n_workers:
            warnings.warn(
                f"Only {n_frames} frames cannot be assigned to n_workers={n_workers}. Clamping -> {n_frames}.",
                RuntimeWarning,
            )
            n_workers = n_frames
        return int(n_workers)

    @staticmethod
    def _mode_to_int(mode: str) -> int:
        mode = str(mode).lower().strip()
        if mode not in _MODE_MAP:
            raise ValueError(f"Unknown mode={mode!r}, allowed={list(_MODE_MAP)}")
        return int(_MODE_MAP[mode])

    @staticmethod
    def _mode_axes(mode_int: int) -> tuple[int, tuple[int, ...]]:
        try:
            return _MODE_AXES[int(mode_int)]
        except KeyError as exc:
            raise ValueError(f"mode_int must be one of {sorted(_MODE_AXES)}") from exc

    @staticmethod
    def _build_q_shell(q_max: float, dq_shell: float, q_min: float) -> tuple[np.ndarray, int]:
        q_max = float(q_max)
        dq_shell = float(dq_shell)
        q_min = float(q_min)
        if q_max <= 0.0 or dq_shell <= 0.0:
            raise ValueError("q_max and dq_shell must be > 0.")
        if not (0.0 <= q_min < q_max):
            raise ValueError("q_min must satisfy 0 <= q_min < q_max.")

        nbins = int(np.ceil(q_max / dq_shell))
        if nbins < 1:
            raise ValueError("q_max/dq_shell too small: nbins < 1.")
        q_edges = np.arange(nbins + 1, dtype=np.float64) * dq_shell
        q_shell = 0.5 * (q_edges[:-1] + q_edges[1:])
        return q_shell, nbins

    @staticmethod
    def _selected_lags(T: int, lag_max: int | None, lag_stride: int) -> np.ndarray:
        T = int(T)
        lag_stride = int(lag_stride)
        if lag_stride < 1:
            raise ValueError("lag_stride must be >= 1")
        if lag_max is None:
            lag_hi = T - 1
        else:
            lag_hi = int(lag_max)
            if lag_hi < 0:
                raise ValueError("lag_max must be >= 0")
            if lag_hi >= T:
                warnings.warn(
                    f"lag_max={lag_hi} exceeds the largest available lag {T - 1}. Clamping -> {T - 1}.",
                    RuntimeWarning,
                )
                lag_hi = T - 1

        out = np.arange(0, lag_hi + 1, lag_stride, dtype=np.int32)
        if out.ndim != 1 or out.size < 1:
            raise ValueError("Selected lags are empty")
        return np.ascontiguousarray(out)

    @staticmethod
    def _balanced_slices_t1(T: int, W: int) -> list[tuple[int, int]]:
        T = int(T)
        W = max(1, min(int(W), T))
        if W <= 1:
            return [(0, T)]

        total = T * (T + 1) // 2
        edges = [0]
        prev = 0
        for k in range(1, W):
            target = (total * k) / W
            bound = int(np.floor((np.sqrt(1.0 + 8.0 * target) - 1.0) * 0.5))
            bound = max(bound, prev + 1)
            bound = min(bound, T - (W - k))
            prev = bound
            edges.append(bound)
        edges.append(T)

        out: list[tuple[int, int]] = []
        for start, stop in zip(edges[:-1], edges[1:]):
            if start < stop:
                out.append((int(start), int(stop)))
        return out

    @staticmethod
    def _slices_to_i32(slices: list[tuple[int, int]]) -> np.ndarray:
        arr = np.asarray(slices, dtype=np.int32)
        if arr.ndim != 2 or arr.shape[1] != 2:
            raise ValueError("Invalid slices array")
        return np.ascontiguousarray(arr)

    @staticmethod
    def _times_ps_from_timestep(lags: np.ndarray, timestep_ps: float | None) -> np.ndarray | None:
        if timestep_ps is None:
            return None
        timestep_ps = float(timestep_ps)
        if (not np.isfinite(timestep_ps)) or timestep_ps <= 0.0:
            raise ValueError("timestep_ps must be a finite positive float")
        return lags.astype(np.float64, copy=False) * timestep_ps

    @staticmethod
    def _estimate_local_bytes(slices_i32: np.ndarray, n_lags: int, nbins: int) -> int:
        return int(slices_i32.shape[0]) * int(n_lags) * int(2 * nbins + 1) * np.dtype(np.float64).itemsize

    def _plan_t1_slices(
        self,
        *,
        n_workers: int,
        lags: np.ndarray,
        nbins: int,
        kernel_label: str,
    ) -> tuple[int, np.ndarray]:
        requested_workers = int(n_workers)
        t1_slices = self._slices_to_i32(self._balanced_slices_t1(self.n_frames, n_workers))
        max_local_bytes = 512 * 1024 * 1024
        est_local_bytes = self._estimate_local_bytes(t1_slices, int(lags.size), int(nbins))
        while est_local_bytes > max_local_bytes and n_workers > 1:
            n_workers -= 1
            t1_slices = self._slices_to_i32(self._balanced_slices_t1(self.n_frames, n_workers))
            est_local_bytes = self._estimate_local_bytes(t1_slices, int(lags.size), int(nbins))

        if est_local_bytes > max_local_bytes:
            raise MemoryError(
                f"{kernel_label} would allocate about "
                f"{est_local_bytes / (1024 ** 2):.1f} MiB of per-slice lag histograms even with n_workers=1. "
                "Reduce lag_max, increase lag_stride, increase dq_shell, or reduce q_max."
            )
        if n_workers != requested_workers:
            warnings.warn(
                f"{kernel_label} local buffers scale with n_workers * n_lags * nbins. "
                f"Clamping n_workers from {requested_workers} to {n_workers} "
                f"(estimated local buffers: {est_local_bytes / (1024 ** 2):.1f} MiB).",
                RuntimeWarning,
            )
        return int(n_workers), t1_slices

    def _active_periodic_axes_or_raise(self, mode_int: int) -> None:
        _, axes = self._mode_axes(mode_int)
        if self.periodic_all:
            return

        pbc = np.lib.format.open_memmap(self.pbc_path, mode="r")
        try:
            active = np.asarray(axes, dtype=np.int64)
            ok = bool(np.all(pbc[:, active]))
        finally:
            del pbc

        if not ok:
            labels = "".join("abc"[ax] for ax in axes)
            raise ValueError(
                f"ISF mode uses reciprocal sampling along lattice axis/axes {labels!r}, "
                "which requires periodic boundary conditions along those axes for every frame."
            )

    @classmethod
    def _subcell_sigma_max(cls, cell: np.ndarray, mode_int: int) -> float:
        dim, axes = cls._mode_axes(mode_int)
        sub = np.asarray(cell, dtype=np.float64)[list(axes), :]
        if dim == 1:
            sigma = float(np.linalg.norm(sub[0]))
        else:
            gram = sub @ sub.T
            eigs = np.linalg.eigvalsh(gram)
            sigma = float(np.sqrt(max(0.0, float(np.max(eigs)))))
        if (not np.isfinite(sigma)) or sigma <= 0.0:
            raise ValueError("Failed to build a valid reciprocal-space search bound from the cell.")
        return sigma

    @classmethod
    def _build_integer_grid(cls, mode_int: int, n_box: int, half_sphere: bool) -> np.ndarray:
        dim, axes = cls._mode_axes(mode_int)
        n_box = int(n_box)
        if n_box < 1:
            raise ValueError("n_box must be >= 1")

        if dim == 1:
            if half_sphere:
                vals = np.arange(1, n_box + 1, dtype=np.int32)
            else:
                vals = np.concatenate(
                    [
                        np.arange(-n_box, 0, dtype=np.int32),
                        np.arange(1, n_box + 1, dtype=np.int32),
                    ]
                )
            out = np.zeros((vals.size, 3), dtype=np.int32)
            out[:, axes[0]] = vals
            return out

        vals = np.arange(-n_box, n_box + 1, dtype=np.int32)
        if dim == 2:
            uu, vv = np.meshgrid(vals, vals, indexing="ij")
            u = uu.ravel()
            v = vv.ravel()
            if half_sphere:
                mask = (u > 0) | ((u == 0) & (v > 0))
            else:
                mask = ~((u == 0) & (v == 0))
            out = np.zeros((int(mask.sum()), 3), dtype=np.int32)
            out[:, axes[0]] = u[mask]
            out[:, axes[1]] = v[mask]
            return out

        kk, ll = np.meshgrid(vals, vals, indexing="ij")
        k_flat = kk.ravel()
        l_flat = ll.ravel()
        blocks: list[np.ndarray] = []
        h_iter = range(0, n_box + 1) if half_sphere else range(-n_box, n_box + 1)
        for h in h_iter:
            if half_sphere:
                mask = (k_flat > 0) | ((k_flat == 0) & (l_flat > 0)) if h == 0 else np.ones_like(k_flat, dtype=bool)
            else:
                mask = ~((k_flat == 0) & (l_flat == 0)) if h == 0 else np.ones_like(k_flat, dtype=bool)
            if not np.any(mask):
                continue
            block = np.zeros((int(mask.sum()), 3), dtype=np.int32)
            block[:, axes[0]] = int(h)
            block[:, axes[1]] = k_flat[mask]
            block[:, axes[2]] = l_flat[mask]
            blocks.append(block)

        if not blocks:
            raise ValueError("No q-points generated (empty bounds).")
        return np.concatenate(blocks, axis=0)

    def _prepare_q_cache(
        self,
        *,
        mode_int: int,
        q_max: float,
        dq_shell: float,
        q_min: float,
        half_sphere: bool,
        max_points: int | None,
        seed: int,
    ) -> tuple[np.ndarray, int, str, str | None]:
        # This mirrors prepare_ssf.py: build a safe reciprocal integer search box,
        # then cache shell ids when the cell is static so the C++ kernel can skip
        # repeated q-shell classification.
        if (not self.cell_static) and (max_points is not None):
            raise ValueError("max_points is only supported when cell_static=True (fixed cell).")

        q_shell, nbins = self._build_q_shell(q_max, dq_shell, q_min)
        self._active_periodic_axes_or_raise(mode_int)

        cache_dir = Path(self.cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)

        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        try:
            sigma_max = 0.0
            if self.cell_static:
                sigma_max = self._subcell_sigma_max(np.asarray(cell[0], dtype=np.float64), mode_int)
            else:
                for t in range(int(cell.shape[0])):
                    sigma_t = self._subcell_sigma_max(np.asarray(cell[t], dtype=np.float64), mode_int)
                    if sigma_t > sigma_max:
                        sigma_max = sigma_t
        finally:
            del cell

        sigma_min_rec = (2.0 * np.pi) / float(sigma_max)
        n_box = int(np.ceil(float(q_max) / sigma_min_rec)) + 1
        if n_box < 1:
            raise ValueError("q_max too small: no reciprocal points.")

        sig_grid = f"m{int(mode_int)}_n{int(n_box)}_hs{int(bool(half_sphere))}"
        q_int_raw_path = cache_dir / f"q_int_raw_{sig_grid}.npy"
        need_build_raw = True
        if q_int_raw_path.exists():
            try:
                mm = np.lib.format.open_memmap(q_int_raw_path, mode="r")
                need_build_raw = not (mm.ndim == 2 and mm.shape[1] == 3 and mm.dtype == np.int32)
                del mm
            except Exception:
                need_build_raw = True
        if need_build_raw:
            q_int = self._build_integer_grid(mode_int, n_box, bool(half_sphere))
            if q_int.size == 0:
                raise ValueError("No q-points generated.")
            np.save(q_int_raw_path, q_int.astype(np.int32, copy=False))

        if not self.cell_static:
            return q_shell, nbins, str(q_int_raw_path), None

        sig_static = "".join(
            ch if (ch.isalnum() or ch in "._-") else "_"
            for ch in (
                f"{sig_grid}_qmax{float(q_max):.6g}_qmin{float(q_min):.6g}_dq{float(dq_shell):.6g}_"
                f"mp{max_points}_sd{(int(seed) if (max_points is not None) else 0)}"
            )
        )[:160]
        q_int_path = cache_dir / f"q_int_{sig_static}.npy"
        shell_id_path = cache_dir / f"shell_id_{sig_static}.npy"

        ok_static = False
        if q_int_path.exists() and shell_id_path.exists():
            try:
                mm_q = np.lib.format.open_memmap(q_int_path, mode="r")
                mm_sid = np.lib.format.open_memmap(shell_id_path, mode="r")
                ok_static = (
                    mm_q.ndim == 2
                    and mm_q.shape[1] == 3
                    and mm_q.dtype == np.int32
                    and mm_sid.ndim == 1
                    and mm_sid.dtype == np.int32
                    and mm_sid.shape[0] == mm_q.shape[0]
                )
                del mm_q, mm_sid
            except Exception:
                ok_static = False
        if ok_static:
            return q_shell, nbins, str(q_int_path), str(shell_id_path)

        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        q_int_raw = np.lib.format.open_memmap(q_int_raw_path, mode="r")
        try:
            cell0 = np.asarray(cell[0], dtype=np.float64)
            det = float(np.linalg.det(cell0))
            if (not np.isfinite(det)) or abs(det) < 1e-14:
                raise ValueError("Singular/degenerate cell detected while preparing static q-grid.")
            rec0 = (2.0 * np.pi) * np.linalg.inv(cell0.T)
            metric = rec0 @ rec0.T

            keep_list: list[np.ndarray] = []
            sid_list: list[np.ndarray] = []
            eps = 1e-12
            chunk = 1_000_000
            for i0 in range(0, int(q_int_raw.shape[0]), chunk):
                i1 = min(i0 + chunk, int(q_int_raw.shape[0]))
                q_block_i32 = q_int_raw[i0:i1]
                q_block = np.asarray(q_block_i32, dtype=np.float64)
                qn2 = np.einsum("ni,ij,nj->n", q_block, metric, q_block, optimize=True)
                qn = np.sqrt(qn2)
                sid = np.floor(qn / float(dq_shell)).astype(np.int32)
                valid = (qn > (float(q_min) + eps)) & (qn <= (float(q_max) + eps)) & (sid >= 0) & (sid < nbins)
                if np.any(valid):
                    keep_list.append(q_block_i32[valid].astype(np.int32, copy=False))
                    sid_list.append(sid[valid].astype(np.int32, copy=False))

            if not keep_list:
                raise ValueError("No valid q-points after q_min/q_max filtering.")

            q_keep = np.concatenate(keep_list, axis=0)
            sid_keep = np.concatenate(sid_list, axis=0)

            if max_points is not None:
                mp = int(max_points)
                if mp > 0 and q_keep.shape[0] > mp:
                    rng = np.random.default_rng(int(seed))
                    counts = np.bincount(sid_keep, minlength=nbins)
                    shells = np.flatnonzero(counts)
                    per_shell = max(1, mp // max(int(shells.size), 1))
                    mask = np.zeros(q_keep.shape[0], dtype=bool)
                    for shell in shells:
                        idx = np.flatnonzero(sid_keep == shell)
                        if idx.size <= per_shell:
                            mask[idx] = True
                        else:
                            pick = rng.choice(idx, size=per_shell, replace=False)
                            mask[pick] = True
                    q_keep = q_keep[mask]
                    sid_keep = sid_keep[mask]

            np.save(q_int_path, q_keep.astype(np.int32, copy=False))
            np.save(shell_id_path, sid_keep.astype(np.int32, copy=False))
        finally:
            del cell, q_int_raw

        return q_shell, nbins, str(q_int_path), str(shell_id_path)

    def isf_self_cal(
        self,
        *,
        mode: str = "abc",
        q_max: float = 20.0,
        dq_shell: float = 0.1,
        n_workers: int = 1,
        q_min: float = 0.0,
        half_sphere: bool = True,
        max_points: int | None = None,
        seed: int = 42,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> ISFResultSelf:
        """Compute shell-averaged self ISF.

        Fs(q,t) = < exp[i q . (r_i(t1) - r_i(t0))] >, averaged over atoms, time
        origins and q-vectors that fall into the same |q| shell.
        """

        n_workers = self._clamp_workers(int(n_workers), int(self.n_frames))
        mode_int = self._mode_to_int(mode)
        q_shell, nbins, q_int_path, shell_id_path = self._prepare_q_cache(
            mode_int=mode_int,
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            half_sphere=bool(half_sphere),
            max_points=max_points,
            seed=int(seed),
        )
        lags = self._selected_lags(self.n_frames, lag_max, lag_stride)
        n_workers, t1_slices = self._plan_t1_slices(
            n_workers=n_workers,
            lags=lags,
            nbins=nbins,
            kernel_label="Self ISF kernel",
        )
        times_ps = self._times_ps_from_timestep(lags, timestep_ps)

        posA_unwrap = np.lib.format.open_memmap(self.posA_unwrap_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        q_int = np.lib.format.open_memmap(q_int_path, mode="r")
        shell_id = None if shell_id_path is None else np.lib.format.open_memmap(shell_id_path, mode="r")

        from ripple.kernel.isf_ext import isf_self as _isf_self

        try:
            Fs, q_count, cnt_s = _isf_self(
                posA_unwrap,
                cell,
                q_int,
                shell_id,
                float(q_min),
                float(q_max),
                float(dq_shell),
                int(nbins),
                lags,
                int(n_workers),
                t1_slices,
                bool(self.cell_static),
            )
        finally:
            del posA_unwrap, cell, q_int
            if shell_id is not None:
                del shell_id

        return ISFResultSelf(
            Fs=np.asarray(Fs),
            q_count=np.asarray(q_count),
            cnt_s=np.asarray(cnt_s),
            q_shell=q_shell,
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            mode=str(mode),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
        )

    def isf_distinct_cal(
        self,
        *,
        mode: str = "abc",
        q_max: float = 20.0,
        dq_shell: float = 0.1,
        n_workers: int = 1,
        q_min: float = 0.0,
        half_sphere: bool = True,
        max_points: int | None = None,
        seed: int = 42,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> ISFResultDistinct:
        """Compute shell-averaged distinct ISF.

        Fd(q,t) correlates density modes at t0 and t1 for two species selections.
        When the cell changes with time, wrapped coordinates at t0 are mapped into
        the reciprocal basis of cell(t1) before the Fourier phase is evaluated.
        """

        if self.same and (self.n_a < 2):
            raise ValueError("Need at least 2 atoms for same-species distinct ISF.")

        n_workers = self._clamp_workers(int(n_workers), int(self.n_frames))
        mode_int = self._mode_to_int(mode)
        q_shell, nbins, q_int_path, shell_id_path = self._prepare_q_cache(
            mode_int=mode_int,
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            half_sphere=bool(half_sphere),
            max_points=max_points,
            seed=int(seed),
        )
        lags = self._selected_lags(self.n_frames, lag_max, lag_stride)
        n_workers, t1_slices = self._plan_t1_slices(
            n_workers=n_workers,
            lags=lags,
            nbins=nbins,
            kernel_label="Distinct ISF kernel",
        )
        times_ps = self._times_ps_from_timestep(lags, timestep_ps)

        posA = np.lib.format.open_memmap(self.posA_path, mode="r")
        posB = posA if (self.same or (self.posB_path == self.posA_path)) else np.lib.format.open_memmap(self.posB_path, mode="r")
        posA_unwrap = np.lib.format.open_memmap(self.posA_unwrap_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        q_int = np.lib.format.open_memmap(q_int_path, mode="r")
        shell_id = None if shell_id_path is None else np.lib.format.open_memmap(shell_id_path, mode="r")

        from ripple.kernel.isf_ext import isf_distinct as _isf_distinct

        try:
            Fd, q_count, cnt_d = _isf_distinct(
                posA,
                posB,
                posA_unwrap,
                cell,
                q_int,
                shell_id,
                float(q_min),
                float(q_max),
                float(dq_shell),
                int(nbins),
                bool(self.same),
                lags,
                int(n_workers),
                t1_slices,
                bool(self.cell_static),
            )
        finally:
            if posB is not posA:
                del posB
            del posA, posA_unwrap, cell, q_int
            if shell_id is not None:
                del shell_id

        return ISFResultDistinct(
            Fd=np.asarray(Fd),
            q_count=np.asarray(q_count),
            cnt_d=np.asarray(cnt_d),
            q_shell=q_shell,
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            mode=str(mode),
            same=bool(self.same),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
        )

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


def prepare_isf(
    trajectory,
    target_atoms1: str,
    target_atoms2: str | None = None,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> PreparedISF:
    """Prepare memmaps for shell-averaged intermediate scattering functions.

    Cached arrays:
      - wrapped/scaled positions for Fourier phases at reference time t0
      - unwrapped Cartesian positions for self displacements
      - cell/pbc metadata for static-cell q caching and variable-cell mapping
    """

    def sanitize_tag(tag: str) -> str:
        tag = str(tag)
        return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in tag)[:120]

    def ok_memmap(path: Path, shape, dtype) -> bool:
        if not path.exists():
            return False
        try:
            mm = np.lib.format.open_memmap(path, mode="r")
            ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
            del mm
            return bool(ok)
        except Exception:
            return False

    def build_prepared(periodic_all: bool, cell_static: bool) -> PreparedISF:
        return PreparedISF(
            cache_dir=str(cache_dir),
            trajectory_tag=str(trajectory_tag),
            save_dir=str(save_dir),
            feature=str(feature),
            material_name=str(material_name),
            n_frames=int(T),
            n_a=int(n_a),
            n_b=int(n_b),
            same=bool(same),
            periodic_all=bool(periodic_all),
            cell_static=bool(cell_static),
            wrap=bool(wrap),
            scaled=bool(scaled),
            pos_dtype=str(pos_dtype_name),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
            cell_path=str(cell_path),
            pbc_path=str(pbc_path),
            posA_path=str(posA_path),
            posB_path=str(posB_path),
            posA_unwrap_path=str(posA_unwrap_path),
            meta_path=str(meta_path),
        )

    scaled = True
    wrap = True
    if target_atoms2 is None:
        target_atoms2 = str(target_atoms1)

    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be bool")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings")
    if (not isinstance(target_atoms1, str)) or (not isinstance(target_atoms2, str)):
        raise TypeError("target_atoms1/target_atoms2 must be strings")

    trajectory_tag = sanitize_tag(trajectory_tag)
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn(
            "Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!",
            RuntimeWarning,
        )

    cache_dir = Path(save_dir) / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")
    pos_dtype_name = str(datatype.name)

    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_isf(): trajectory is a factory but n_frames is None. "
                "This will iterate the trajectory TWICE (count + write). "
                "Next time, pass n_frames to avoid the extra pass.",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. Pass n_frames=..., "
                "or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter() -> Iterator:
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration as exc:
        raise ValueError("Empty trajectory.") from exc

    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_a_full = species_list == target_atoms1
    is_b_full = species_list == target_atoms2
    n_a = int(is_a_full.sum())
    n_b = int(is_b_full.sum())
    if n_a < 1:
        raise ValueError(f"No atoms found for target_atoms1={target_atoms1}")
    if n_b < 1:
        raise ValueError(f"No atoms found for target_atoms2={target_atoms2}")

    same = bool(target_atoms1 == target_atoms2)
    idx_a_full = np.flatnonzero(is_a_full).astype(np.int64)
    idx_b_full = idx_a_full if same else np.flatnonzero(is_b_full).astype(np.int64)

    feature = f"{material_name}_isf_{target_atoms1}_{target_atoms2}_sc{int(scaled)}_wr{int(wrap)}_uw1_{pos_dtype_name}"
    meta_path = cache_dir / f"meta_{feature}.npz"
    cell_path = cache_dir / f"cell_{feature}.cell.npy"
    pbc_path = cache_dir / f"pbc_{feature}.pbc.npy"
    posA_path = cache_dir / f"positionsA_{feature}.pos.npy"
    posB_path = posA_path if same else (cache_dir / f"positionsB_{feature}.pos.npy")
    posA_unwrap_path = cache_dir / f"positionsA_unwrap_{feature}.pos.npy"

    if reuse_memmap:
        ok_posA = ok_memmap(posA_path, (T, n_a, 3), datatype)
        ok_posB = ok_posA if same else ok_memmap(posB_path, (T, n_b, 3), datatype)
        ok_posA_uw = ok_memmap(posA_unwrap_path, (T, n_a, 3), datatype)
        ok_cell = ok_memmap(cell_path, (T, 3, 3), np.float64)
        ok_pbc = ok_memmap(pbc_path, (T, 3), np.bool_)
        ok_all = meta_path.exists() and ok_posA and ok_posB and ok_posA_uw and ok_cell and ok_pbc
        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                return build_prepared(bool(meta["periodic_all"]), bool(meta["cell_static"]))

    created_paths = [meta_path]
    posA_mm = posB_mm = posAuw_mm = cell_mm = pbc_mm = None
    try:
        posA_mm = np.lib.format.open_memmap(posA_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_path)
        if not same:
            posB_mm = np.lib.format.open_memmap(posB_path, mode="w+", dtype=datatype, shape=(T, n_b, 3))
            created_paths.append(posB_path)
        posAuw_mm = np.lib.format.open_memmap(posA_unwrap_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_unwrap_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        pbc_mm = np.lib.format.open_memmap(pbc_path, mode="w+", dtype=np.bool_, shape=(T, 3))
        created_paths.append(pbc_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)
        periodic_all = True
        cell_static = True
        last_cell = None
        cell_prev = None
        pbc_prev = None
        x_prev_raw = None
        x_unwrap_prev = None
        t_last = -1

        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t

            # Wrapped scaled coordinates are the natural representation for
            # reciprocal-space phase factors exp(i q.r).
            sp = np.asarray(frame.get_scaled_positions(wrap=wrap), dtype=np.float64)
            if sp.ndim != 2 or sp.shape[1] != 3:
                raise ValueError(f"Expected scaled positions (N,3) at t={t}.")
            posA_mm[t] = sp[idx_a_full].astype(datatype, copy=False)
            if not same:
                posB_mm[t] = sp[idx_b_full].astype(datatype, copy=False)

            cell_t = np.asarray(frame.cell, dtype=np.float64)
            if cell_t.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell_t.shape}.")
            cell_mm[t] = cell_t
            if t == 0:
                last_cell = np.array(cell_t, dtype=np.float64, copy=True)
            elif cell_static and (np.max(np.abs(cell_t - last_cell)) > 1e-10):
                cell_static = False

            pbc_t = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc_t.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc_t.shape}.")
            pbc_mm[t] = pbc_t
            periodic_all &= bool(np.all(pbc_t))

            # Self ISF needs real displacements, so the selected A trajectory is
            # also cached in unwrapped Cartesian coordinates.
            x_raw = np.asarray(frame.positions, dtype=np.float64)[idx_a_full]
            if x_raw.ndim != 2 or x_raw.shape[1] != 3:
                raise ValueError(f"Expected Cartesian positions (N,3) at t={t}.")
            if t == 0:
                x_prev_raw = x_raw
                x_unwrap_prev = x_raw.copy()
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)
                posAuw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
            else:
                try:
                    inv_cell_prev = np.linalg.inv(cell_prev)
                    inv_cell_curr = np.linalg.inv(cell_t)
                    s_prev = x_prev_raw @ inv_cell_prev
                    s_curr = x_raw @ inv_cell_curr
                    image = np.zeros_like(s_curr)
                    pbc_step = np.logical_and(pbc_prev, pbc_t)
                    image[:, pbc_step] = np.rint((s_curr - s_prev)[:, pbc_step])
                    dx = x_raw - x_prev_raw - (image @ cell_t)
                except Exception:
                    dx = x_raw - x_prev_raw
                x_unwrap_prev = x_unwrap_prev + dx
                posAuw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
                x_prev_raw = x_raw
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)

        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last + 1} frames.")

        posA_mm.flush()
        posAuw_mm.flush()
        cell_mm.flush()
        pbc_mm.flush()
        if posB_mm is not None:
            posB_mm.flush()

        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_a=np.int64(n_a),
            n_b=np.int64(n_b),
            same=np.bool_(same),
            scaled=np.bool_(scaled),
            wrap=np.bool_(wrap),
            pos_dtype=pos_dtype_name,
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
        )
    except Exception:
        try:
            del posA_mm, posB_mm, posAuw_mm, cell_mm, pbc_mm
        except Exception:
            pass
        for path in created_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del posA_mm, posB_mm, posAuw_mm, cell_mm, pbc_mm
        except Exception:
            pass

    return build_prepared(periodic_all, cell_static)
