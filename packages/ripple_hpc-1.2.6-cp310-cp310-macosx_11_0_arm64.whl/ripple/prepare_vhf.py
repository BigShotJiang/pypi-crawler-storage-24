from __future__ import annotations

import itertools
import os
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import numpy as np


# =====================================================================================
# Public results
# =====================================================================================


@dataclass(frozen=True, slots=True)
class VHFResultSelf:
    """Self part result.

    Gs has shape (n_lags, nbins) for the selected lag values.
    cnt_s has shape (n_lags,) and equals the number of valid origins per lag.
    """

    Gs: np.ndarray
    cnt_s: np.ndarray
    lags: np.ndarray
    times_ps: np.ndarray | None
    timestep_ps: float | None
    bins: np.ndarray
    r_max: float
    dr: float
    mode: str


@dataclass(frozen=True, slots=True)
class VHFResultDistinct:
    """Distinct part result.

    Gd has shape (n_lags, nbins) for the selected lag values.
    If normalize=True, Gd is the density-normalized distinct part g_d = G_d / rho_B
    and reduces to the RDF at lag=0.
    If normalize=False, Gd is the raw distinct van Hove part G_d.

    sum_fac_d has shape (n_lags,) and equals sum_over_origins(NA * rho_B(t1))
    in the selected subspace (3D volume / 2D area / 1D length); it is the
    normalization factor used when normalize=True.
    cnt_d has shape (n_lags,) and equals the number of valid origins per lag.
    """

    Gd: np.ndarray
    sum_fac_d: np.ndarray
    cnt_d: np.ndarray
    lags: np.ndarray
    times_ps: np.ndarray | None
    timestep_ps: float | None
    bins: np.ndarray
    r_max: float
    dr: float
    mode: str
    normalize: bool


# =====================================================================================
# Prepared objects
# =====================================================================================


@dataclass(frozen=True, slots=True)
class PreparedVHFSelf:
    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_a: int
    periodic_all: bool
    cell_static: bool
    pos_dtype: str
    target_atoms: str
    cell_path: str
    posA_unwrap_path: str
    meta_path: str

    def vhf_self_cal(
        self,
        *,
        mode: str = "abc",
        r_max: float = 12.0,
        dr: float = 0.02,
        n_workers: int = 1,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> VHFResultSelf:
        # ------------------------
        # local helpers (keep module namespace clean)
        # ------------------------
        def _avail_cpus() -> int:
            if hasattr(os, "sched_getaffinity"):
                try:
                    return len(os.sched_getaffinity(0))
                except Exception:
                    pass
            return int(os.cpu_count() or 1)

        def _clamp_workers(nw: int, n_frames: int) -> int:
            nw = int(nw)
            if nw < 1:
                raise ValueError("n_workers must be >= 1")
            avail = _avail_cpus()
            if avail < nw:
                warnings.warn(
                    f"Only {avail} CPUs are available, but n_workers={nw}. Clamping -> {avail}.",
                    RuntimeWarning,
                )
                nw = avail
            if n_frames < nw:
                warnings.warn(
                    f"Only {n_frames} frames cannot be assigned to n_workers={nw}. Clamping -> {n_frames}.",
                    RuntimeWarning,
                )
                nw = n_frames
            return int(nw)

        def _mode_to_int(m: str) -> int:
            m = str(m).lower().strip()
            mode_map = {
                "abc": 1,
                "ab_lattice_project": 2,
                "ac_lattice_project": 3,
                "bc_lattice_project": 4,
                "a_lattice_project": 5,
                "b_lattice_project": 6,
                "c_lattice_project": 7,
            }
            if m not in mode_map:
                raise ValueError(f"Unknown mode={m!r}, allowed={list(mode_map.keys())}")
            return int(mode_map[m])

        def _bins_and_rmax(rmax: float, dr_: float) -> tuple[np.ndarray, float, int]:
            rmax = float(rmax)
            dr_ = float(dr_)
            if rmax <= 0.0 or dr_ <= 0.0:
                raise ValueError("r_max and dr must be positive.")
            nb = int(np.floor(rmax / dr_))
            if nb < 1:
                raise ValueError("r_max or dr is too small: nbins < 1. Increase r_max or decrease dr.")
            rmax_eff = float(nb * dr_)
            bins = (np.arange(nb, dtype=np.float64) + 0.5) * dr_
            return bins, rmax_eff, nb

        def _balanced_slices_t1(T: int, W: int) -> list[tuple[int, int]]:
            """Equalize triangular work over t1, where work(t1) ~ (t1+1)."""
            T = int(T)
            W = max(1, min(int(W), T))
            if W <= 1:
                return [(0, T)]
            total = T * (T + 1) // 2
            edges = [0]
            prev = 0
            for k in range(1, W):
                target = (total * k) / W
                b = int(np.floor((np.sqrt(1.0 + 8.0 * target) - 1.0) * 0.5))
                b = max(b, prev + 1)
                b = min(b, T - (W - k))
                prev = b
                edges.append(b)
            edges.append(T)
            out: list[tuple[int, int]] = []
            for s, e in zip(edges[:-1], edges[1:]):
                if s < e:
                    out.append((int(s), int(e)))
            return out

        def _slices_to_i32(slices: list[tuple[int, int]]) -> np.ndarray:
            arr = np.asarray(slices, dtype=np.int32)
            if arr.ndim != 2 or arr.shape[1] != 2:
                raise ValueError("Invalid slices array")
            return np.ascontiguousarray(arr)

        def _selected_lags(T: int, lag_max_: int | None, lag_stride_: int) -> np.ndarray:
            if lag_stride_ < 1:
                raise ValueError("lag_stride must be >= 1")
            if lag_max_ is None:
                lag_hi = T - 1
            else:
                lag_hi = int(lag_max_)
                if lag_hi < 0:
                    raise ValueError("lag_max must be >= 0")
                if lag_hi >= T:
                    warnings.warn(
                        f"lag_max={lag_hi} exceeds the largest available lag {T - 1}. Clamping -> {T - 1}.",
                        RuntimeWarning,
                    )
                    lag_hi = T - 1
            out = np.arange(0, lag_hi + 1, int(lag_stride_), dtype=np.int32)
            if out.ndim != 1 or out.size < 1:
                raise ValueError("Selected lags are empty")
            return np.ascontiguousarray(out)

        def _balanced_lag_index_slices(lags_: np.ndarray, T: int, W: int) -> list[tuple[int, int]]:
            K = int(lags_.shape[0])
            W = max(1, min(int(W), K))
            if W <= 1:
                return [(0, K)]
            weights = T - lags_.astype(np.int64, copy=False)
            total = int(weights.sum())
            edges = [0]
            prev = 0
            csum = np.cumsum(weights, dtype=np.int64)
            for k in range(1, W):
                target = (total * k) / W
                b = int(np.searchsorted(csum, target, side="right"))
                b = max(b, prev + 1)
                b = min(b, K - (W - k))
                prev = b
                edges.append(b)
            edges.append(K)
            out: list[tuple[int, int]] = []
            for s, e in zip(edges[:-1], edges[1:]):
                if s < e:
                    out.append((int(s), int(e)))
            return out

        def _times_ps_from_timestep(lags_: np.ndarray, dt_ps: float | None) -> np.ndarray | None:
            if dt_ps is None:
                return None
            dt_ps = float(dt_ps)
            if (not np.isfinite(dt_ps)) or dt_ps <= 0.0:
                raise ValueError("timestep_ps must be a finite positive float")
            return lags_.astype(np.float64, copy=False) * dt_ps

        # ------------------------
        # compute
        # ------------------------
        n_workers = _clamp_workers(n_workers, self.n_frames)
        mode_int = _mode_to_int(mode)
        bins, r_max_eff, nbins = _bins_and_rmax(r_max, dr)
        lags = _selected_lags(self.n_frames, lag_max, int(lag_stride))
        lag_idx_slices = _slices_to_i32(_balanced_lag_index_slices(lags, self.n_frames, n_workers))
        times_ps = _times_ps_from_timestep(lags, timestep_ps)

        posA_unwrap = np.lib.format.open_memmap(self.posA_unwrap_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")

        from ripple.kernel.vhf_ext import vhf_self as _vhf_self

        try:
            Gs, cnt_s = _vhf_self(
                posA_unwrap,
                cell,
                float(r_max_eff),
                float(dr),
                int(nbins),
                int(mode_int),
                int(n_workers),
                lags,
                lag_idx_slices,
                bool(self.cell_static),
            )
        finally:
            del posA_unwrap, cell
        return VHFResultSelf(
            Gs=np.asarray(Gs),
            cnt_s=np.asarray(cnt_s),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
            bins=bins,
            r_max=float(r_max_eff),
            dr=float(dr),
            mode=str(mode),
        )

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


@dataclass(frozen=True, slots=True)
class PreparedVHFDistinct:
    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_a: int
    n_b: int
    same: bool
    periodic_all: bool
    cell_static: bool
    wrap: bool
    scaled: bool
    pos_dtype: str
    target_atoms1: str
    target_atoms2: str
    cell_path: str
    vol_path: str
    pbc_path: str
    posA_path: str
    posB_path: str
    meta_path: str

    def vhf_distinct_cal(
        self,
        *,
        mode: str = "abc",
        r_max: float = 12.0,
        dr: float = 0.02,
        n_workers: int = 1,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
        normalize: bool = True,
    ) -> VHFResultDistinct:
        if self.same and (self.n_a < 2):
            raise ValueError("Need at least 2 atoms for same-species distinct part.")
        if not isinstance(normalize, bool):
            raise TypeError("normalize must be bool")

        # ------------------------
        # local helpers (keep module namespace clean)
        # ------------------------
        def _avail_cpus() -> int:
            if hasattr(os, "sched_getaffinity"):
                try:
                    return len(os.sched_getaffinity(0))
                except Exception:
                    pass
            return int(os.cpu_count() or 1)

        def _clamp_workers(nw: int, n_frames: int) -> int:
            nw = int(nw)
            if nw < 1:
                raise ValueError("n_workers must be >= 1")
            avail = _avail_cpus()
            if avail < nw:
                warnings.warn(
                    f"Only {avail} CPUs are available, but n_workers={nw}. Clamping -> {avail}.",
                    RuntimeWarning,
                )
                nw = avail
            if n_frames < nw:
                warnings.warn(
                    f"Only {n_frames} frames cannot be assigned to n_workers={nw}. Clamping -> {n_frames}.",
                    RuntimeWarning,
                )
                nw = n_frames
            return int(nw)

        def _mode_to_int(m: str) -> int:
            m = str(m).lower().strip()
            mode_map = {
                "abc": 1,
                "ab_lattice_project": 2,
                "ac_lattice_project": 3,
                "bc_lattice_project": 4,
                "a_lattice_project": 5,
                "b_lattice_project": 6,
                "c_lattice_project": 7,
            }
            if m not in mode_map:
                raise ValueError(f"Unknown mode={m!r}, allowed={list(mode_map.keys())}")
            return int(mode_map[m])

        def _bins_and_rmax(rmax: float, dr_: float) -> tuple[np.ndarray, float, int]:
            rmax = float(rmax)
            dr_ = float(dr_)
            if rmax <= 0.0 or dr_ <= 0.0:
                raise ValueError("r_max and dr must be positive.")
            nb = int(np.floor(rmax / dr_))
            if nb < 1:
                raise ValueError("r_max or dr is too small: nbins < 1. Increase r_max or decrease dr.")
            rmax_eff = float(nb * dr_)
            bins = (np.arange(nb, dtype=np.float64) + 0.5) * dr_
            return bins, rmax_eff, nb

        def _balanced_slices_t1(T: int, W: int) -> list[tuple[int, int]]:
            """Equalize triangular work over t1, where work(t1) ~ (t1+1)."""
            T = int(T)
            W = max(1, min(int(W), T))
            if W <= 1:
                return [(0, T)]
            total = T * (T + 1) // 2
            edges = [0]
            prev = 0
            for k in range(1, W):
                target = (total * k) / W
                b = int(np.floor((np.sqrt(1.0 + 8.0 * target) - 1.0) * 0.5))
                b = max(b, prev + 1)
                b = min(b, T - (W - k))
                prev = b
                edges.append(b)
            edges.append(T)
            out: list[tuple[int, int]] = []
            for s, e in zip(edges[:-1], edges[1:]):
                if s < e:
                    out.append((int(s), int(e)))
            return out

        def _slices_to_i32(slices: list[tuple[int, int]]) -> np.ndarray:
            arr = np.asarray(slices, dtype=np.int32)
            if arr.ndim != 2 or arr.shape[1] != 2:
                raise ValueError("Invalid slices array")
            return np.ascontiguousarray(arr)

        def _selected_lags(T: int, lag_max_: int | None, lag_stride_: int) -> np.ndarray:
            if lag_stride_ < 1:
                raise ValueError("lag_stride must be >= 1")
            if lag_max_ is None:
                lag_hi = T - 1
            else:
                lag_hi = int(lag_max_)
                if lag_hi < 0:
                    raise ValueError("lag_max must be >= 0")
                if lag_hi >= T:
                    warnings.warn(
                        f"lag_max={lag_hi} exceeds the largest available lag {T - 1}. Clamping -> {T - 1}.",
                        RuntimeWarning,
                    )
                    lag_hi = T - 1
            out = np.arange(0, lag_hi + 1, int(lag_stride_), dtype=np.int32)
            if out.ndim != 1 or out.size < 1:
                raise ValueError("Selected lags are empty")
            return np.ascontiguousarray(out)

        def _times_ps_from_timestep(lags_: np.ndarray, dt_ps: float | None) -> np.ndarray | None:
            if dt_ps is None:
                return None
            dt_ps = float(dt_ps)
            if (not np.isfinite(dt_ps)) or dt_ps <= 0.0:
                raise ValueError("timestep_ps must be a finite positive float")
            return lags_.astype(np.float64, copy=False) * dt_ps

        def _estimate_distinct_local_bytes(slices_i32: np.ndarray, n_lags_: int, nbins_: int) -> int:
            # distinct kernel keeps one selected-lag histogram per t1-slice to avoid write races
            return int(slices_i32.shape[0]) * int(n_lags_) * int(nbins_ + 2) * np.dtype(np.float64).itemsize

        # ------------------------
        # compute
        # ------------------------
        n_workers = _clamp_workers(n_workers, self.n_frames)
        requested_workers = int(n_workers)
        mode_int = _mode_to_int(mode)
        bins, r_max_eff, nbins = _bins_and_rmax(r_max, dr)
        lags = _selected_lags(self.n_frames, lag_max, int(lag_stride))
        times_ps = _times_ps_from_timestep(lags, timestep_ps)
        t1_slices = _slices_to_i32(_balanced_slices_t1(self.n_frames, n_workers))
        max_local_bytes = 512 * 1024 * 1024
        est_local_bytes = _estimate_distinct_local_bytes(t1_slices, int(lags.size), nbins)
        while est_local_bytes > max_local_bytes and n_workers > 1:
            n_workers -= 1
            t1_slices = _slices_to_i32(_balanced_slices_t1(self.n_frames, n_workers))
            est_local_bytes = _estimate_distinct_local_bytes(t1_slices, int(lags.size), nbins)
        if est_local_bytes > max_local_bytes:
            raise MemoryError(
                "Distinct VHF kernel would allocate about "
                f"{est_local_bytes / (1024 ** 2):.1f} MiB of per-slice selected-lag histograms even with n_workers=1. "
                "Reduce the chunk size, increase dr, or reduce r_max."
            )
        if n_workers != requested_workers:
            warnings.warn(
                "Distinct VHF kernel local buffers scale with n_workers * n_lags * nbins. "
                f"Clamping n_workers from {requested_workers} to {n_workers} "
                f"(estimated local histogram buffers: {est_local_bytes / (1024 ** 2):.1f} MiB).",
                RuntimeWarning,
            )

        posA = np.lib.format.open_memmap(self.posA_path, mode="r")
        posB = posA if (self.same or (self.posB_path == self.posA_path)) else np.lib.format.open_memmap(self.posB_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        pbc = np.lib.format.open_memmap(self.pbc_path, mode="r")
        vol = np.lib.format.open_memmap(self.vol_path, mode="r")

        from ripple.kernel.vhf_ext import vhf_distinct as _vhf_distinct

        try:
            Gd, sum_fac_d, cnt_d = _vhf_distinct(
                posA,
                posB,
                cell,
                pbc,
                vol,
                bool(self.periodic_all),
                bool(self.cell_static),
                bool(self.same),
                float(r_max_eff),
                float(dr),
                int(nbins),
                int(mode_int),
                int(n_workers),
                lags,
                t1_slices,
                bool(normalize),
            )
        finally:
            if posB is not posA:
                del posB
            del posA, cell, pbc, vol
        return VHFResultDistinct(
            Gd=np.asarray(Gd),
            sum_fac_d=np.asarray(sum_fac_d),
            cnt_d=np.asarray(cnt_d),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
            bins=bins,
            r_max=float(r_max_eff),
            dr=float(dr),
            mode=str(mode),
            normalize=bool(normalize),
        )

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


# =====================================================================================
# prepare_vhf_self
# =====================================================================================


def prepare_vhf_self(
    trajectory,
    target_atoms: str,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> PreparedVHFSelf:
    """Prepare memmaps for self part van Hove correlation function."""

    # ------------------------
    # local helpers (keep module namespace clean)
    # ------------------------
    def _sanitize_tag(tag: str) -> str:
        tag = str(tag)
        return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in tag)[:120]

    def _ok_memmap(path: Path, shape, dtype) -> bool:
        if not path.exists():
            return False
        try:
            mm = np.lib.format.open_memmap(path, mode="r")
            ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
            del mm
            return bool(ok)
        except Exception:
            return False

    # ------------------------
    # validate
    # ------------------------
    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be bool")
    if not isinstance(target_atoms, str):
        raise TypeError("target_atoms must be a string")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings")

    trajectory_tag = _sanitize_tag(trajectory_tag)
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn(
            "Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!",
            RuntimeWarning,
        )

    cache_dir = Path(save_dir) / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    pos_dtype = np.dtype(pos_dtype).name
    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")

    # ---- resolve n_frames / iterator factory ----
    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_vhf_self(): trajectory is a factory but n_frames is None. "
                "This will iterate the trajectory TWICE (count + write). "
                "Next time, pass n_frames to avoid the extra pass.",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. Pass n_frames=..., "
                "or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter() -> Iterator:
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    # ---- read first frame ----
    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration:
        raise ValueError("Empty trajectory.")

    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_a_full = (species_list == target_atoms)
    n_a = int(is_a_full.sum())
    if n_a < 1:
        raise ValueError(f"No atoms found for target_atoms={target_atoms}")
    idx_a_full = np.flatnonzero(is_a_full).astype(np.int64)

    feature = f"{material_name}_vhf_self_{pos_dtype}"
    meta_path = cache_dir / f"meta_self_{target_atoms}_{feature}.npz"
    cell_path = cache_dir / f"cell_self_{target_atoms}_{feature}.cell.npy"
    posA_unwrap_path = cache_dir / f"positionsA_unwrap_{target_atoms}_{feature}.pos.npy"

    if reuse_memmap:
        ok_cell = _ok_memmap(cell_path, (T, 3, 3), np.float64)
        ok_uw = _ok_memmap(posA_unwrap_path, (T, n_a, 3), datatype)
        ok_all = meta_path.exists() and ok_cell and ok_uw
        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                return PreparedVHFSelf(
                    cache_dir=str(cache_dir),
                    trajectory_tag=str(trajectory_tag),
                    save_dir=str(save_dir),
                    feature=str(feature),
                    material_name=str(material_name),
                    n_frames=int(T),
                    n_a=int(n_a),
                    periodic_all=bool(meta["periodic_all"]),
                    cell_static=bool(meta["cell_static"]),
                    pos_dtype=str(pos_dtype),
                    target_atoms=str(target_atoms),
                    cell_path=str(cell_path),
                    posA_unwrap_path=str(posA_unwrap_path),
                    meta_path=str(meta_path),
                )

    created_paths = [meta_path]
    cell_mm = posAuw_mm = None
    try:
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        posAuw_mm = np.lib.format.open_memmap(posA_unwrap_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_unwrap_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)
        periodic_all = True
        cell_static = True
        last_cell = None
        cell_prev = None
        pbc_prev = None
        x_prev_raw = None
        x_unwrap_prev = None
        t_last = -1
        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t

            cell_t = np.asarray(frame.cell, dtype=np.float64)
            if cell_t.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell_t.shape}.")
            cell_mm[t] = cell_t
            if t == 0:
                last_cell = np.array(cell_t, dtype=np.float64, copy=True)
            elif cell_static and (np.max(np.abs(cell_t - last_cell)) > 1e-10):
                cell_static = False

            pbc_t = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc_t.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc_t.shape}.")
            periodic_all &= bool(np.all(pbc_t))

            x_raw = np.asarray(frame.positions, dtype=np.float64)[idx_a_full]
            if x_raw.ndim != 2 or x_raw.shape[1] != 3:
                raise ValueError(f"Expected Cartesian positions (N,3) at t={t}.")
            if t == 0:
                x_prev_raw = x_raw
                x_unwrap_prev = x_raw.copy()
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)
                posAuw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
            else:
                try:
                    inv_cell_prev = np.linalg.inv(cell_prev)
                    inv_cell_curr = np.linalg.inv(cell_t)
                    s_prev = x_prev_raw @ inv_cell_prev
                    s_curr = x_raw @ inv_cell_curr
                    image = np.zeros_like(s_curr)
                    pbc_step = np.logical_and(pbc_prev, pbc_t)
                    image[:, pbc_step] = np.rint((s_curr - s_prev)[:, pbc_step])
                    dx = x_raw - x_prev_raw - (image @ cell_t)
                except Exception:
                    dx = x_raw - x_prev_raw
                x_unwrap_prev = x_unwrap_prev + dx
                posAuw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
                x_prev_raw = x_raw
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)

        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last + 1} frames.")

        cell_mm.flush()
        posAuw_mm.flush()
        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_a=np.int64(n_a),
            pos_dtype=pos_dtype,
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            target_atoms=str(target_atoms),
        )
    except Exception:
        try:
            del cell_mm, posAuw_mm
        except Exception:
            pass
        for p in created_paths:
            try:
                Path(p).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del cell_mm, posAuw_mm
        except Exception:
            pass

    with np.load(meta_path, allow_pickle=False) as meta:
        return PreparedVHFSelf(
            cache_dir=str(cache_dir),
            trajectory_tag=str(trajectory_tag),
            save_dir=str(save_dir),
            feature=str(feature),
            material_name=str(material_name),
            n_frames=int(T),
            n_a=int(n_a),
            periodic_all=bool(meta["periodic_all"]),
            cell_static=bool(meta["cell_static"]),
            pos_dtype=str(pos_dtype),
            target_atoms=str(target_atoms),
            cell_path=str(cell_path),
            posA_unwrap_path=str(posA_unwrap_path),
            meta_path=str(meta_path),
        )


# =====================================================================================
# prepare_vhf_distinct
# =====================================================================================


def prepare_vhf_distinct(
    trajectory,
    target_atoms1: str,
    target_atoms2: str,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> PreparedVHFDistinct:
    """Prepare memmaps for distinct part van Hove correlation function."""

    scaled = True
    wrap = True

    # ------------------------
    # local helpers (keep module namespace clean)
    # ------------------------
    def _sanitize_tag(tag: str) -> str:
        tag = str(tag)
        return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in tag)[:120]

    def _ok_memmap(path: Path, shape, dtype) -> bool:
        if not path.exists():
            return False
        try:
            mm = np.lib.format.open_memmap(path, mode="r")
            ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
            del mm
            return bool(ok)
        except Exception:
            return False

    # ------------------------
    # validate
    # ------------------------
    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be bool")
    if (not isinstance(target_atoms1, str)) or (not isinstance(target_atoms2, str)):
        raise TypeError("target_atoms1/target_atoms2 must be strings")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings")

    trajectory_tag = _sanitize_tag(trajectory_tag)
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn(
            "Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!",
            RuntimeWarning,
        )

    cache_dir = Path(save_dir) / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    pos_dtype = np.dtype(pos_dtype).name
    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")

    # ---- resolve n_frames / iterator factory ----
    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_vhf_distinct(): trajectory is a factory but n_frames is None. "
                "This will iterate the trajectory TWICE (count + write). "
                "Next time, pass n_frames to avoid the extra pass.",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. Pass n_frames=..., "
                "or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter() -> Iterator:
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration:
        raise ValueError("Empty trajectory.")

    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_a_full = (species_list == target_atoms1)
    is_b_full = (species_list == target_atoms2)
    n_a = int(is_a_full.sum())
    n_b = int(is_b_full.sum())
    if n_a < 1:
        raise ValueError(f"No atoms found for target_atoms1={target_atoms1}")
    if n_b < 1:
        raise ValueError(f"No atoms found for target_atoms2={target_atoms2}")
    same = bool(target_atoms1 == target_atoms2)
    idx_a_full = np.flatnonzero(is_a_full).astype(np.int64)
    idx_b_full = idx_a_full if same else np.flatnonzero(is_b_full).astype(np.int64)

    feature = f"{material_name}_vhf_distinct_sc{int(scaled)}_wr{int(wrap)}_{pos_dtype}"
    meta_path = cache_dir / f"meta_distinct_{target_atoms1}_{target_atoms2}_{feature}.npz"
    cell_path = cache_dir / f"cell_{feature}.cell.npy"
    pbc_path = cache_dir / f"pbc_{feature}.pbc.npy"
    vol_path = cache_dir / f"volume_{feature}.vol.npy"
    posA_path = cache_dir / f"positionsA_{target_atoms1}_{feature}.pos.npy"
    posB_path = posA_path if same else (cache_dir / f"positionsB_{target_atoms2}_{feature}.pos.npy")

    if reuse_memmap:
        ok_posA = _ok_memmap(posA_path, (T, n_a, 3), datatype)
        ok_posB = ok_posA if same else _ok_memmap(posB_path, (T, n_b, 3), datatype)
        ok_cell = _ok_memmap(cell_path, (T, 3, 3), np.float64)
        ok_pbc = _ok_memmap(pbc_path, (T, 3), np.bool_)
        ok_vol = _ok_memmap(vol_path, (T,), np.float64)
        ok_all = meta_path.exists() and ok_posA and ok_posB and ok_cell and ok_pbc and ok_vol
        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                return PreparedVHFDistinct(
                    cache_dir=str(cache_dir),
                    trajectory_tag=str(trajectory_tag),
                    save_dir=str(save_dir),
                    feature=str(feature),
                    material_name=str(material_name),
                    n_frames=int(T),
                    n_a=int(n_a),
                    n_b=int(n_b),
                    same=bool(same),
                    periodic_all=bool(meta["periodic_all"]),
                    cell_static=bool(meta["cell_static"]),
                    wrap=bool(wrap),
                    scaled=bool(scaled),
                    pos_dtype=str(pos_dtype),
                    target_atoms1=str(target_atoms1),
                    target_atoms2=str(target_atoms2),
                    cell_path=str(cell_path),
                    vol_path=str(vol_path),
                    pbc_path=str(pbc_path),
                    posA_path=str(posA_path),
                    posB_path=str(posB_path),
                    meta_path=str(meta_path),
                )

    created_paths = [meta_path]
    posA_mm = posB_mm = cell_mm = pbc_mm = vol_mm = None
    try:
        posA_mm = np.lib.format.open_memmap(posA_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_path)
        if not same:
            posB_mm = np.lib.format.open_memmap(posB_path, mode="w+", dtype=datatype, shape=(T, n_b, 3))
            created_paths.append(posB_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        pbc_mm = np.lib.format.open_memmap(pbc_path, mode="w+", dtype=np.bool_, shape=(T, 3))
        created_paths.append(pbc_path)
        vol_mm = np.lib.format.open_memmap(vol_path, mode="w+", dtype=np.float64, shape=(T,))
        created_paths.append(vol_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)
        periodic_all = True
        cell_static = True
        last_cell = None
        t_last = -1
        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t

            sp = frame.get_scaled_positions(wrap=wrap)
            if sp.ndim != 2 or sp.shape[1] != 3:
                raise ValueError(f"Expected scaled positions (N,3) at t={t}. Got {sp.shape}.")
            posA_mm[t] = sp[idx_a_full]
            if not same:
                posB_mm[t] = sp[idx_b_full]

            cell_t = np.asarray(frame.cell, dtype=np.float64)
            if cell_t.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell_t.shape}.")
            cell_mm[t] = cell_t
            if t == 0:
                last_cell = np.array(cell_t, dtype=np.float64, copy=True)
            elif cell_static and (np.max(np.abs(cell_t - last_cell)) > 1e-10):
                cell_static = False

            pbc_t = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc_t.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc_t.shape}.")
            pbc_mm[t] = pbc_t
            periodic_all &= bool(np.all(pbc_t))
            vol_mm[t] = float(frame.get_volume())

        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last + 1} frames.")

        posA_mm.flush()
        cell_mm.flush()
        pbc_mm.flush()
        vol_mm.flush()
        if posB_mm is not None:
            posB_mm.flush()

        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_a=np.int64(n_a),
            n_b=np.int64(n_b),
            same=np.bool_(same),
            scaled=np.bool_(scaled),
            wrap=np.bool_(wrap),
            pos_dtype=pos_dtype,
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
        )
    except Exception:
        try:
            del posA_mm, posB_mm, cell_mm, pbc_mm, vol_mm
        except Exception:
            pass
        for p in created_paths:
            try:
                Path(p).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del posA_mm, posB_mm, cell_mm, pbc_mm, vol_mm
        except Exception:
            pass

    with np.load(meta_path, allow_pickle=False) as meta:
        return PreparedVHFDistinct(
            cache_dir=str(cache_dir),
            trajectory_tag=str(trajectory_tag),
            save_dir=str(save_dir),
            feature=str(feature),
            material_name=str(material_name),
            n_frames=int(T),
            n_a=int(n_a),
            n_b=int(n_b),
            same=bool(same),
            periodic_all=bool(meta["periodic_all"]),
            cell_static=bool(meta["cell_static"]),
            wrap=bool(wrap),
            scaled=bool(scaled),
            pos_dtype=str(pos_dtype),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
            cell_path=str(cell_path),
            vol_path=str(vol_path),
            pbc_path=str(pbc_path),
            posA_path=str(posA_path),
            posB_path=str(posB_path),
            meta_path=str(meta_path),
        )
