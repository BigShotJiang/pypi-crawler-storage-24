from __future__ import annotations
import os
import warnings
import itertools
from dataclasses import dataclass
from pathlib import Path
import numpy as np


@dataclass(frozen=True, slots=True)
class RDFResult:
    rdf: np.ndarray
    bins: np.ndarray


@dataclass(frozen=True, slots=True)
class PreparedRDFTrajectory:
    """Prepared RDF trajectory object returned by prepare_rdf(...).
    It stores the cached memmap paths (positionsA/positionsB/cell/pbc/volume + meta), and provides:  rdf_res = traj.rdf_cal(...)
    """
    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_a: int
    n_b: int
    same: bool
    periodic_all: bool
    cell_static: bool
    wrap: bool
    scaled: bool
    pos_dtype: str
    target_atoms1: str
    target_atoms2: str
    cell_path: str
    vol_path: str
    pbc_path: str
    posA_path: str
    posB_path: str
    meta_path: str

    def rdf_cal(self, *, mode: str = "abc", r_max: float = 12.0, dr: float = 0.02, n_workers: int = 1, skin: float = 2.0) -> RDFResult:
        """
        Compute RDF using the cached memmaps produced by prepare_rdf(...).
        Parameters:
         - mode : str, Same meaning as your original rdf.py mode map.
         - skin : float, Neighbor-list skin passed directly to the threaded C++ kernel.
        Returns: RDFResult with attributes {rdf, bins}.
        """
        from ripple.kernel.rdf_ext import rdf
        # n_workers validate
        n_workers = int(n_workers)
        if n_workers < 1:
            raise ValueError("n_workers must be >= 1.")
        avail = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else (os.cpu_count() or 1)
        if avail < n_workers:
            warnings.warn(f"Only {avail} CPUs are available, but n_workers={n_workers}. Clamping -> {avail}.", RuntimeWarning)
            n_workers = avail
        if self.n_frames < n_workers:
            warnings.warn(f"Only {self.n_frames} frames cannot be assigned to n_workers={n_workers}. Clamping -> {self.n_frames}.", RuntimeWarning)
            n_workers = self.n_frames
        # mode mapping
        mode = str(mode).lower().strip()
        mode_map = {
            "abc": 1,
            "ab_lattice_project": 2,
            "ac_lattice_project": 3,
            "bc_lattice_project": 4,
            "a_lattice_project": 5,
            "b_lattice_project": 6,
            "c_lattice_project": 7,
        }
        try:
            mode_int = mode_map[mode]
        except KeyError:
            raise ValueError(f"Unknown mode={mode!r}, allowed={list(mode_map.keys())}")
        # bins
        r_max = float(r_max)
        dr = float(dr)
        if r_max <= 0.0 or dr <= 0.0:
            raise ValueError("r_max or dr is not valid.")
        nbins = int(np.floor(r_max / dr))
        if nbins < 1:
            raise ValueError("r_max or dr is too small: nbins < 1. Increase r_max or decrease dr.")
        r_max = float(nbins * dr)
        r_mid = (np.arange(nbins, dtype=np.float64) + 0.5) * dr

        posA = np.lib.format.open_memmap(self.posA_path, mode="r")
        posB = posA if self.same or (self.posB_path == self.posA_path) else np.lib.format.open_memmap(self.posB_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        pbc = np.lib.format.open_memmap(self.pbc_path, mode="r")
        vol = np.lib.format.open_memmap(self.vol_path, mode="r")
        try:
            counts_tot, denom_tot = rdf(
                posA,
                posB,
                cell,
                pbc,
                vol,
                bool(self.periodic_all),
                bool(self.cell_static),
                bool(self.same),
                0,
                int(self.n_frames),
                float(r_max),
                float(dr),
                int(nbins),
                int(mode_int),
                float(skin),
                int(n_workers),
            )
        finally:
            del posA, posB, cell, pbc, vol

        g = counts_tot / np.maximum(denom_tot, 1e-16)
        return RDFResult(g, r_mid)

    def clean(self) -> None:
        import shutil
        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


def prepare_rdf(
    trajectory,
    target_atoms1: str,
    target_atoms2: str,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> PreparedRDFTrajectory:
    """
    Cache an ASE trajectory (Sequence / factory / iterable) into memmaps:
      - positionsA: (T, N_A, 3) scaled, wrap=True, dtype=pos_dtype
      - positionsB: (T, N_B, 3) scaled, wrap=True (aliases A if same species), dtype=pos_dtype
      - cell:       (T, 3, 3) float64   (ASE row-vectors a,b,c)
      - pbc:        (T, 3) bool
      - volume:     (T,) float64
    Returns: class-wrapped (cache_dir, T, n_a, n_b, same, periodic_all, cell_static, cell_path, vol_path, pbc_path, posA_path, posB_path)
    Notes:
      - If reuse_memmap is true, users should supply a stable trajectory_tag.
      - If you pass a single-pass iterator, you MUST pass n_frames (or a factory trajectory=...).
    """
    scaled = True; wrap = True
    if not isinstance(reuse_memmap, bool):
        raise TypeError("Wrong input! reuse_memmap must be bool.")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("Wrong input! save_dir/pos_dtype/trajectory_tag must be strings.")
    if (not isinstance(target_atoms1, str)) or (not isinstance(target_atoms2, str)):
        raise TypeError("Wrong input! target_atoms1/target_atoms2 must be strings.")
    trajectory_tag = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in trajectory_tag)[:120]
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn("Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!", RuntimeWarning)
    cache_dir = Path(save_dir) / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)
    pos_dtype = np.dtype(pos_dtype).name
    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("Wrong input! pos_dtype must be 'float32' or 'float64'.")

    # -------------------- resolve n_frames / iterator factory --------------------
    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True
        def make_iter():
            return iter(trajectory)
    elif is_factory:
        reiterable = True
        def make_iter():
            return iter(trajectory())
        if n_frames is None:
            warnings.warn("prepare_rdf(): trajectory is a factory but n_frames (the number of frames) is None. "
                          "This will iterate the trajectory TWICE (count + write). "
                          "Next time, please pass n_frames to avoid the extra pass.", RuntimeWarning)
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError("Iterable trajectory without known length. "
                            "Pass n_frames=..., or pass a factory: trajectory=lambda: ase.io.iread(...).")
        T = int(n_frames)
        it_single = iter(trajectory)
        def make_iter():
            return it_single
    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    # -------------------- read first frame (define selections + validate shapes) --------------------
    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration:
        raise ValueError("Empty trajectory.")
    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_a_full = (species_list == target_atoms1)
    is_b_full = (species_list == target_atoms2)
    n_a = int(is_a_full.sum())
    n_b = int(is_b_full.sum())
    if n_a < 1:
        raise ValueError(f"No atoms found for target_atoms1={target_atoms1}")
    if n_b < 1:
        raise ValueError(f"No atoms found for target_atoms2={target_atoms2}")
    same = (target_atoms1 == target_atoms2)
    if same and n_a < 2:
        raise ValueError("Need at least 2 atoms for same-species.")
    idx_a_full = np.flatnonzero(is_a_full).astype(np.int64)
    idx_b_full = idx_a_full if same else np.flatnonzero(is_b_full).astype(np.int64)

    # -------------------- file paths --------------------
    feature = f"{material_name}_sc{int(scaled)}_wr{int(wrap)}_{pos_dtype}"
    meta_path = cache_dir / f"meta_{target_atoms1}_{target_atoms2}_{feature}.npz"
    cell_path = cache_dir / f"cell_{target_atoms1}_{target_atoms2}_{feature}.cell.npy"
    pbc_path = cache_dir / f"pbc_{target_atoms1}_{target_atoms2}_{feature}.pbc.npy"
    vol_path = cache_dir / f"volume_{target_atoms1}_{target_atoms2}_{feature}.vol.npy"
    posA_path = cache_dir / f"positionsA_{target_atoms1}_{feature}.pos.npy"
    posB_path = posA_path if same else (cache_dir / f"positionsB_{target_atoms2}_{feature}.pos.npy")

    # -------------------- reuse_memmap check --------------------
    if reuse_memmap:
        def _ok(path: Path, shape, dtype) -> bool:
            if not path.exists():
                return False
            try:
                mm = np.lib.format.open_memmap(path, mode="r")
                ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
                del mm
                return ok
            except Exception:
                return False
        ok_posA = _ok(posA_path, (T, n_a, 3), datatype)
        ok_posB = ok_posA if same else _ok(posB_path, (T, n_b, 3), datatype)
        ok_cell = _ok(cell_path, (T, 3, 3), np.float64)
        ok_pbc = _ok(pbc_path, (T, 3), np.bool_)
        ok_vol = _ok(vol_path, (T,), np.float64)
        ok_all = meta_path.exists() and ok_posA and ok_posB and ok_cell and ok_pbc and ok_vol
        if ok_all and (not reiterable):
            raise ValueError("Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed)."
                             "Use a factory: trajectory=lambda: ase.io.iread(...).")
        if ok_all:  # if reusing
            with np.load(meta_path, allow_pickle=False) as meta:
                periodic_all = bool(meta["periodic_all"])
                cell_static = bool(meta["cell_static"])
            return PreparedRDFTrajectory(
                cache_dir=str(cache_dir),
                trajectory_tag=str(trajectory_tag),
                save_dir=str(save_dir),
                feature=str(feature),
                material_name=str(material_name),
                n_frames=int(T),
                n_a=int(n_a),
                n_b=int(n_b),
                same=bool(same),
                periodic_all=bool(periodic_all),
                cell_static=bool(cell_static),
                wrap=bool(wrap),
                scaled=bool(scaled),
                pos_dtype=str(pos_dtype),
                target_atoms1=str(target_atoms1),
                target_atoms2=str(target_atoms2),
                cell_path=str(cell_path),
                vol_path=str(vol_path),
                pbc_path=str(pbc_path),
                posA_path=str(posA_path),
                posB_path=str(posB_path),
                meta_path=str(meta_path),
            )
    # -------------------- build memmaps --------------------
    created_paths = [meta_path]
    posA_mm = posB_mm = cell_mm = pbc_mm = vol_mm = None
    try:
        posA_mm = np.lib.format.open_memmap(posA_path, mode="w+", dtype=datatype, shape=(T, n_a, 3))
        created_paths.append(posA_path)
        if not same:
            posB_mm = np.lib.format.open_memmap(posB_path, mode="w+", dtype=datatype, shape=(T, n_b, 3))
            created_paths.append(posB_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        pbc_mm = np.lib.format.open_memmap(pbc_path, mode="w+", dtype=np.bool_, shape=(T, 3))
        created_paths.append(pbc_path)
        vol_mm = np.lib.format.open_memmap(vol_path, mode="w+", dtype=np.float64, shape=(T,))
        created_paths.append(vol_path)
        frames = make_iter() if reiterable else itertools.chain([first], it0)
        t_last = -1
        periodic_all = True; cell_static = True; last_cell = None
        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t
            pos = frame.get_scaled_positions(wrap=wrap)
            if pos.ndim != 2 or pos.shape[1] != 3:
                raise ValueError(f"Expected 3D positions (N,3) at t={t}. Got {pos.shape}.")
            posA_mm[t] = pos[idx_a_full]
            if not same:
                posB_mm[t] = pos[idx_b_full]
            cell = np.asarray(frame.cell, dtype=np.float64)
            if cell.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell.shape}.")
            cell_mm[t] = cell
            if t == 0:
                last_cell = np.array(cell, dtype=np.float64, copy=True)
            elif cell_static:
                cur = np.asarray(cell, dtype=np.float64)
                if np.max(np.abs(cur - last_cell)) > 1e-10:
                    cell_static = False
            pbc = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc.shape}.")
            pbc_mm[t] = pbc
            periodic_all &= bool(np.all(pbc))
            vol_mm[t] = frame.get_volume()
        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last+1} frames.")
        # flush
        posA_mm.flush(); cell_mm.flush(); pbc_mm.flush(); vol_mm.flush()
        if posB_mm is not None:
            posB_mm.flush()
        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_a=np.int64(n_a),
            n_b=np.int64(n_b),
            same=np.bool_(same),
            scaled=np.bool_(scaled),
            wrap=np.bool_(wrap),
            pos_dtype=pos_dtype,
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            target_atoms1=str(target_atoms1),
            target_atoms2=str(target_atoms2),
        )
    except Exception:
        try:                    # 1) release memmap objects first
            del posA_mm, posB_mm, cell_mm, pbc_mm, vol_mm
        except Exception:
            pass
        for p in created_paths: # 2) remove partial files
            try:
                Path(p).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:                    # back to normal path: ensure references are released
        try:
            del posA_mm, posB_mm, cell_mm, pbc_mm, vol_mm
        except Exception:
            pass
    return PreparedRDFTrajectory(
        cache_dir=str(cache_dir),
        trajectory_tag=str(trajectory_tag),
        save_dir=str(save_dir),
        feature=str(feature),
        material_name=str(material_name),
        n_frames=int(T),
        n_a=int(n_a),
        n_b=int(n_b),
        same=bool(same),
        periodic_all=bool(periodic_all),
        cell_static=bool(cell_static),
        wrap=bool(wrap),
        scaled=bool(scaled),
        pos_dtype=str(pos_dtype),
        target_atoms1=str(target_atoms1),
        target_atoms2=str(target_atoms2),
        cell_path=str(cell_path),
        vol_path=str(vol_path),
        pbc_path=str(pbc_path),
        posA_path=str(posA_path),
        posB_path=str(posB_path),
        meta_path=str(meta_path),
    )
