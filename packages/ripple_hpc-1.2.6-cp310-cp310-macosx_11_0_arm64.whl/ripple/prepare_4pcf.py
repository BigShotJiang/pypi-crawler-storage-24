from __future__ import annotations

import itertools
import os
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import numpy as np


@dataclass(frozen=True, slots=True)
class Chi4Result:
    """Dynamic susceptibility for a binary self-mobility field.

    The underlying field is c_i(t0, t) = Theta(|r_i(t0+t) - r_i(t0)| - a).
    chi4(t) is computed as N * Var_t0(cbar), where cbar is the mobile fraction
    at fixed lag.
    """

    chi4: np.ndarray
    mobile_fraction: np.ndarray
    cnt: np.ndarray
    a: float
    lags: np.ndarray | None = None
    times_ps: np.ndarray | None = None
    timestep_ps: float | None = None


@dataclass(frozen=True, slots=True)
class G4Result:
    """Radial four-point correlator for the same mobility field.

    G4 stores the distinct real-space correlator of delta c_i delta c_j binned by
    r_ij(t0). The self contribution delta(r) * <(delta c)^2> is returned
    separately as self_term.
    """

    G4: np.ndarray
    sum_fac: np.ndarray
    pair_count: np.ndarray
    cnt: np.ndarray
    mobile_fraction: np.ndarray
    self_term: np.ndarray
    bins: np.ndarray
    r_max: float
    dr: float
    a: float
    lags: np.ndarray | None = None
    times_ps: np.ndarray | None = None
    timestep_ps: float | None = None


@dataclass(frozen=True, slots=True)
class S4Result:
    """Shell-averaged four-point structure factor for the mobility field."""

    S4: np.ndarray
    q_count: np.ndarray
    cnt: np.ndarray
    mobile_fraction: np.ndarray
    q_shell: np.ndarray
    q_max: float
    dq_shell: float
    q_min: float
    a: float
    lags: np.ndarray | None = None
    times_ps: np.ndarray | None = None
    timestep_ps: float | None = None


@dataclass(frozen=True, slots=True)
class Prepared4PCF:
    """Prepared trajectory cache for mobility-based four-point correlators.

    Cached arrays are shared by chi4(t), G4(r,t) and S4(q,t):
      - wrapped/scaled positions: reference coordinates at t0 for pair distances
        and Fourier phases
      - unwrapped Cartesian positions: displacements used in the mobility field
      - cell/pbc metadata: static-cell q caching and periodicity checks
    """

    cache_dir: str
    trajectory_tag: str
    save_dir: str
    feature: str
    material_name: str
    n_frames: int
    n_target: int
    periodic_all: bool
    cell_static: bool
    wrap: bool
    scaled: bool
    pos_dtype: str
    cell_sigma_max: float
    target_atoms: str
    cell_path: str
    pbc_path: str
    pos_path: str
    pos_unwrap_path: str
    meta_path: str

    def __post_init__(self) -> None:
        if (not np.isfinite(self.cell_sigma_max)) or self.cell_sigma_max <= 0.0:
            raise ValueError("cell_sigma_max must be finite and > 0.")

    @staticmethod
    def _available_cpu_count() -> int:
        if hasattr(os, "sched_getaffinity"):
            try:
                return len(os.sched_getaffinity(0))
            except Exception:
                pass
        return int(os.cpu_count() or 1)

    @classmethod
    def _clamp_workers(cls, n_workers: int, n_frames: int) -> int:
        n_workers = int(n_workers)
        if n_workers < 1:
            raise ValueError("n_workers must be >= 1")

        avail = cls._available_cpu_count()
        if avail < n_workers:
            warnings.warn(
                f"Only {avail} CPUs are available, but n_workers={n_workers}. Clamping -> {avail}.",
                RuntimeWarning,
            )
            n_workers = avail
        if n_frames < n_workers:
            warnings.warn(
                f"Only {n_frames} frames cannot be assigned to n_workers={n_workers}. Clamping -> {n_frames}.",
                RuntimeWarning,
            )
            n_workers = n_frames
        return int(n_workers)

    @staticmethod
    def _selected_lags(T: int, lag_max: int | None, lag_stride: int) -> np.ndarray:
        T = int(T)
        lag_stride = int(lag_stride)
        if lag_stride < 1:
            raise ValueError("lag_stride must be >= 1")
        if lag_max is None:
            lag_hi = T - 1
        else:
            lag_hi = int(lag_max)
            if lag_hi < 0:
                raise ValueError("lag_max must be >= 0")
            if lag_hi >= T:
                warnings.warn(
                    f"lag_max={lag_hi} exceeds the largest available lag {T - 1}. Clamping -> {T - 1}.",
                    RuntimeWarning,
                )
                lag_hi = T - 1

        out = np.arange(0, lag_hi + 1, lag_stride, dtype=np.int32)
        if out.ndim != 1 or out.size < 1:
            raise ValueError("Selected lags are empty")
        return np.ascontiguousarray(out)

    @staticmethod
    def _balanced_slices_t1(T: int, W: int) -> list[tuple[int, int]]:
        T = int(T)
        W = max(1, min(int(W), T))
        if W <= 1:
            return [(0, T)]

        total = T * (T + 1) // 2
        edges = [0]
        prev = 0
        for k in range(1, W):
            target = (total * k) / W
            bound = int(np.floor((np.sqrt(1.0 + 8.0 * target) - 1.0) * 0.5))
            bound = max(bound, prev + 1)
            bound = min(bound, T - (W - k))
            prev = bound
            edges.append(bound)
        edges.append(T)

        out: list[tuple[int, int]] = []
        for start, stop in zip(edges[:-1], edges[1:]):
            if start < stop:
                out.append((int(start), int(stop)))
        return out

    @staticmethod
    def _slices_to_i32(slices: list[tuple[int, int]]) -> np.ndarray:
        arr = np.asarray(slices, dtype=np.int32)
        if arr.ndim != 2 or arr.shape[1] != 2:
            raise ValueError("Invalid slices array")
        return np.ascontiguousarray(arr)

    @staticmethod
    def _times_ps_from_timestep(lags: np.ndarray, timestep_ps: float | None) -> np.ndarray | None:
        if timestep_ps is None:
            return None
        timestep_ps = float(timestep_ps)
        if (not np.isfinite(timestep_ps)) or timestep_ps <= 0.0:
            raise ValueError("timestep_ps must be a finite positive float")
        return lags.astype(np.float64, copy=False) * timestep_ps

    @staticmethod
    def _validate_a(a: float) -> float:
        a = float(a)
        if (not np.isfinite(a)) or a <= 0.0:
            raise ValueError("a must be a finite positive float")
        return a

    @staticmethod
    def _bins_and_rmax(r_max: float, dr: float) -> tuple[np.ndarray, float, int]:
        r_max = float(r_max)
        dr = float(dr)
        if r_max <= 0.0 or dr <= 0.0:
            raise ValueError("r_max and dr must be positive.")
        nbins = int(np.floor(r_max / dr))
        if nbins < 1:
            raise ValueError("r_max or dr is too small: nbins < 1.")
        r_max_eff = float(nbins * dr)
        bins = (np.arange(nbins, dtype=np.float64) + 0.5) * dr
        return bins, r_max_eff, nbins

    @staticmethod
    def _build_q_shell(q_max: float, dq_shell: float, q_min: float) -> tuple[np.ndarray, int]:
        q_max = float(q_max)
        dq_shell = float(dq_shell)
        q_min = float(q_min)
        if q_max <= 0.0 or dq_shell <= 0.0:
            raise ValueError("q_max and dq_shell must be > 0.")
        if not (0.0 <= q_min < q_max):
            raise ValueError("q_min must satisfy 0 <= q_min < q_max.")

        nbins = int(np.ceil(q_max / dq_shell))
        if nbins < 1:
            raise ValueError("q_max/dq_shell too small: nbins < 1.")
        q_edges = np.arange(nbins + 1, dtype=np.float64) * dq_shell
        q_shell = 0.5 * (q_edges[:-1] + q_edges[1:])
        return q_shell, nbins

    @staticmethod
    def _estimate_local_bytes(n_slices: int, n_lags: int, nbins: int, n_float_arrays: int, n_int_arrays: int) -> int:
        float_bytes = int(n_slices) * int(n_lags) * int(nbins) * int(n_float_arrays) * np.dtype(np.float64).itemsize
        int_bytes = int(n_slices) * int(n_lags) * int(nbins) * int(n_int_arrays) * np.dtype(np.int64).itemsize
        count_bytes = int(n_slices) * int(n_lags) * (np.dtype(np.float64).itemsize + np.dtype(np.int64).itemsize)
        return int(float_bytes + int_bytes + count_bytes)

    def _plan_t1_slices(
        self,
        *,
        n_workers: int,
        lags: np.ndarray,
        nbins: int,
        kernel_label: str,
        n_float_arrays: int,
        n_int_arrays: int,
    ) -> tuple[int, np.ndarray]:
        requested_workers = int(n_workers)
        t1_slices = self._slices_to_i32(self._balanced_slices_t1(self.n_frames, n_workers))
        max_local_bytes = 512 * 1024 * 1024
        est_local_bytes = self._estimate_local_bytes(
            int(t1_slices.shape[0]),
            int(lags.size),
            int(nbins),
            int(n_float_arrays),
            int(n_int_arrays),
        )
        while est_local_bytes > max_local_bytes and n_workers > 1:
            n_workers -= 1
            t1_slices = self._slices_to_i32(self._balanced_slices_t1(self.n_frames, n_workers))
            est_local_bytes = self._estimate_local_bytes(
                int(t1_slices.shape[0]),
                int(lags.size),
                int(nbins),
                int(n_float_arrays),
                int(n_int_arrays),
            )

        if est_local_bytes > max_local_bytes:
            raise MemoryError(
                f"{kernel_label} would allocate about "
                f"{est_local_bytes / (1024 ** 2):.1f} MiB of per-slice buffers even with n_workers=1. "
                "Reduce lag_max, increase lag_stride, increase dq_shell/dr, or reduce q_max/r_max."
            )
        if n_workers != requested_workers:
            warnings.warn(
                f"{kernel_label} local buffers scale with n_workers * n_lags * nbins. "
                f"Clamping n_workers from {requested_workers} to {n_workers} "
                f"(estimated local buffers: {est_local_bytes / (1024 ** 2):.1f} MiB).",
                RuntimeWarning,
            )
        return int(n_workers), t1_slices

    def _build_integer_grid(self, n_box: int, half_sphere: bool) -> np.ndarray:
        n_box = int(n_box)
        if n_box < 1:
            raise ValueError("n_box must be >= 1")

        vals = np.arange(-n_box, n_box + 1, dtype=np.int32)
        kk, ll = np.meshgrid(vals, vals, indexing="ij")
        k_flat = kk.ravel()
        l_flat = ll.ravel()
        blocks: list[np.ndarray] = []
        h_iter = range(0, n_box + 1) if half_sphere else range(-n_box, n_box + 1)
        for h in h_iter:
            if half_sphere:
                mask = (k_flat > 0) | ((k_flat == 0) & (l_flat > 0)) if h == 0 else np.ones_like(k_flat, dtype=bool)
            else:
                mask = ~((k_flat == 0) & (l_flat == 0)) if h == 0 else np.ones_like(k_flat, dtype=bool)
            if not np.any(mask):
                continue
            block = np.zeros((int(mask.sum()), 3), dtype=np.int32)
            block[:, 0] = int(h)
            block[:, 1] = k_flat[mask]
            block[:, 2] = l_flat[mask]
            blocks.append(block)

        if not blocks:
            raise ValueError("No q-points generated (empty bounds).")
        return np.concatenate(blocks, axis=0)

    def _prepare_q_cache(
        self,
        *,
        q_max: float,
        dq_shell: float,
        q_min: float,
        half_sphere: bool,
        max_points: int | None,
        seed: int,
    ) -> tuple[np.ndarray, int, str, str | None]:
        if not self.periodic_all:
            raise ValueError("S4 requires full 3D periodic boundary conditions for every frame.")
        if (not self.cell_static) and (max_points is not None):
            raise ValueError("max_points is only supported when cell_static=True (fixed cell).")

        q_shell, nbins = self._build_q_shell(q_max, dq_shell, q_min)
        cache_dir = Path(self.cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)

        sigma_min_rec = (2.0 * np.pi) / float(self.cell_sigma_max)
        n_box = int(np.ceil(float(q_max) / sigma_min_rec)) + 1
        if n_box < 1:
            raise ValueError("q_max too small: no reciprocal points.")

        sig_grid = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in f"n{n_box}_hs{int(bool(half_sphere))}")[:140]
        q_int_raw_path = cache_dir / f"q_int_raw_{sig_grid}.npy"

        need_build = True
        if q_int_raw_path.exists():
            try:
                mm = np.lib.format.open_memmap(q_int_raw_path, mode="r")
                need_build = not (mm.ndim == 2 and mm.shape[1] == 3 and mm.dtype == np.int32)
                del mm
            except Exception:
                need_build = True

        if need_build:
            q_int = self._build_integer_grid(n_box, bool(half_sphere))
            if q_int.size == 0:
                raise ValueError("No q-points generated.")
            np.save(q_int_raw_path, q_int.astype(np.int32, copy=False))

        q_int_raw = np.lib.format.open_memmap(q_int_raw_path, mode="r")

        if not self.cell_static:
            try:
                del q_int_raw
            except Exception:
                pass
            return q_shell, nbins, str(q_int_raw_path), None

        sig_static = "".join(
            ch if (ch.isalnum() or ch in "._-") else "_"
            for ch in (
                f"{sig_grid}_qmax{float(q_max):.6g}_qmin{float(q_min):.6g}_dq{float(dq_shell):.6g}_"
                f"mp{max_points}_sd{(int(seed) if (max_points is not None) else 0)}"
            )
        )[:140]
        q_int_path = cache_dir / f"q_int_{sig_static}.npy"
        shell_id_path = cache_dir / f"shell_id_{sig_static}.npy"

        ok_static = False
        if q_int_path.exists() and shell_id_path.exists():
            try:
                mm_q = np.lib.format.open_memmap(q_int_path, mode="r")
                mm_sid = np.lib.format.open_memmap(shell_id_path, mode="r")
                ok_static = (
                    mm_q.ndim == 2
                    and mm_q.shape[1] == 3
                    and mm_q.dtype == np.int32
                    and mm_sid.ndim == 1
                    and mm_sid.dtype == np.int32
                    and mm_sid.shape[0] == mm_q.shape[0]
                )
                del mm_q, mm_sid
            except Exception:
                ok_static = False
        if ok_static:
            try:
                del q_int_raw
            except Exception:
                pass
            return q_shell, nbins, str(q_int_path), str(shell_id_path)

        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        try:
            cell0 = np.asarray(cell[0], dtype=np.float64)
            det = float(np.linalg.det(cell0))
            if (not np.isfinite(det)) or abs(det) < 1e-14:
                raise ValueError("Singular/degenerate cell detected while preparing static q-grid.")
            rec0 = (2.0 * np.pi) * np.linalg.inv(cell0.T)
            metric = rec0 @ rec0.T

            keep_list: list[np.ndarray] = []
            sid_list: list[np.ndarray] = []
            eps = 1e-12
            chunk = 1_000_000
            for i0 in range(0, int(q_int_raw.shape[0]), chunk):
                i1 = min(i0 + chunk, int(q_int_raw.shape[0]))
                q_block_i32 = q_int_raw[i0:i1]
                q_block = np.asarray(q_block_i32, dtype=np.float64)
                qn2 = np.einsum("ni,ij,nj->n", q_block, metric, q_block, optimize=True)
                qn = np.sqrt(qn2)
                sid = np.floor(qn / float(dq_shell)).astype(np.int32)
                valid = (qn > (float(q_min) + eps)) & (qn <= (float(q_max) + eps)) & (sid >= 0) & (sid < nbins)
                if np.any(valid):
                    keep_list.append(q_block_i32[valid].astype(np.int32, copy=False))
                    sid_list.append(sid[valid].astype(np.int32, copy=False))

            if not keep_list:
                raise ValueError("No valid q-points after q_min/q_max filtering.")

            q_keep = np.concatenate(keep_list, axis=0)
            sid_keep = np.concatenate(sid_list, axis=0)

            if max_points is not None:
                mp = int(max_points)
                if mp > 0 and q_keep.shape[0] > mp:
                    rng = np.random.default_rng(int(seed))
                    counts = np.bincount(sid_keep, minlength=nbins)
                    shells = np.flatnonzero(counts)
                    per_shell = max(1, mp // max(int(shells.size), 1))
                    mask = np.zeros(q_keep.shape[0], dtype=bool)
                    for shell in shells:
                        idx = np.flatnonzero(sid_keep == shell)
                        if idx.size <= per_shell:
                            mask[idx] = True
                        else:
                            pick = rng.choice(idx, size=per_shell, replace=False)
                            mask[pick] = True
                    q_keep = q_keep[mask]
                    sid_keep = sid_keep[mask]

            np.save(q_int_path, q_keep.astype(np.int32, copy=False))
            np.save(shell_id_path, sid_keep.astype(np.int32, copy=False))
        finally:
            del cell
            try:
                del q_int_raw
            except Exception:
                pass

        return q_shell, nbins, str(q_int_path), str(shell_id_path)

    def chi4_cal(
        self,
        *,
        a: float = 2.0,
        n_workers: int = 1,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> Chi4Result:
        """Compute chi4(t) from the self-mobility field.

        c_i(t0, t) = Theta(|r_i(t0+t) - r_i(t0)| - a)
        chi4(t) = N * [ <cbar(t0,t)^2> - <cbar(t0,t)>^2 ].
        """

        a = self._validate_a(a)
        n_workers = self._clamp_workers(int(n_workers), int(self.n_frames))
        lags = self._selected_lags(self.n_frames, lag_max, lag_stride)
        t1_slices = self._slices_to_i32(self._balanced_slices_t1(self.n_frames, n_workers))
        times_ps = self._times_ps_from_timestep(lags, timestep_ps)

        pos_unwrap = np.lib.format.open_memmap(self.pos_unwrap_path, mode="r")

        from ripple.kernel.fpcf_ext import chi4 as _chi4

        try:
            chi4, mobile_fraction, cnt = _chi4(
                pos_unwrap,
                float(a),
                lags,
                int(n_workers),
                t1_slices,
            )
        finally:
            del pos_unwrap

        return Chi4Result(
            chi4=np.asarray(chi4),
            mobile_fraction=np.asarray(mobile_fraction),
            cnt=np.asarray(cnt),
            a=float(a),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
        )

    def G4_cal(
        self,
        *,
        a: float = 2.0,
        r_max: float = 12.0,
        dr: float = 0.05,
        n_workers: int = 1,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> G4Result:
        """Compute the distinct real-space four-point correlator G4(r,t).

        The kernel bins <delta c_i(t0,t) delta c_j(t0,t)> by r_ij(t0), where the
        fluctuation delta c is defined relative to the lag-dependent global mobile
        fraction <c(t)>.
        """

        if not self.periodic_all:
            raise ValueError("G4 requires full 3D periodic boundary conditions for every frame.")

        a = self._validate_a(a)
        bins, r_max_eff, nbins = self._bins_and_rmax(r_max, dr)
        n_workers = self._clamp_workers(int(n_workers), int(self.n_frames))
        lags = self._selected_lags(self.n_frames, lag_max, lag_stride)
        n_workers, t1_slices = self._plan_t1_slices(
            n_workers=n_workers,
            lags=lags,
            nbins=nbins,
            kernel_label="G4 kernel",
            n_float_arrays=2,
            n_int_arrays=1,
        )
        times_ps = self._times_ps_from_timestep(lags, timestep_ps)

        pos = np.lib.format.open_memmap(self.pos_path, mode="r")
        pos_unwrap = np.lib.format.open_memmap(self.pos_unwrap_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")

        from ripple.kernel.fpcf_ext import g4 as _g4

        try:
            hist, sum_fac, pair_count, cnt, mobile_fraction, self_term = _g4(
                pos,
                pos_unwrap,
                cell,
                float(a),
                float(r_max_eff),
                float(dr),
                int(nbins),
                lags,
                int(n_workers),
                t1_slices,
            )
        finally:
            del pos, pos_unwrap, cell

        hist = np.asarray(hist)
        sum_fac = np.asarray(sum_fac)
        pair_count = np.asarray(pair_count)
        cnt = np.asarray(cnt)
        mobile_fraction = np.asarray(mobile_fraction)
        self_term = np.asarray(self_term)

        G4 = np.full_like(hist, np.nan, dtype=np.float64)
        mask = sum_fac > 0.0
        G4[mask] = hist[mask] / sum_fac[mask]

        return G4Result(
            G4=G4,
            sum_fac=sum_fac,
            pair_count=pair_count,
            cnt=cnt,
            mobile_fraction=mobile_fraction,
            self_term=self_term,
            bins=bins,
            r_max=float(r_max_eff),
            dr=float(dr),
            a=float(a),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
        )

    def S4_cal(
        self,
        *,
        a: float = 2.0,
        q_max: float = 20.0,
        dq_shell: float = 0.1,
        n_workers: int = 1,
        q_min: float = 0.0,
        half_sphere: bool = True,
        max_points: int | None = None,
        seed: int = 42,
        timestep_ps: float | None = None,
        lag_max: int | None = None,
        lag_stride: int = 1,
    ) -> S4Result:
        """Compute the shell-averaged four-point structure factor S4(q,t).

        S4(q,t) = (1/N) < | sum_i delta c_i(t0,t) exp(i q.r_i(t0)) |^2 >,
        with delta c_i defined from the same mobility field as chi4/G4.
        """

        if not self.periodic_all:
            raise ValueError("S4 requires full 3D periodic boundary conditions for every frame.")

        a = self._validate_a(a)
        n_workers = self._clamp_workers(int(n_workers), int(self.n_frames))
        q_shell, nbins, q_int_path, shell_id_path = self._prepare_q_cache(
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            half_sphere=bool(half_sphere),
            max_points=max_points,
            seed=int(seed),
        )
        lags = self._selected_lags(self.n_frames, lag_max, lag_stride)
        n_workers, t1_slices = self._plan_t1_slices(
            n_workers=n_workers,
            lags=lags,
            nbins=nbins,
            kernel_label="S4 kernel",
            n_float_arrays=1,
            n_int_arrays=1,
        )
        times_ps = self._times_ps_from_timestep(lags, timestep_ps)

        pos = np.lib.format.open_memmap(self.pos_path, mode="r")
        pos_unwrap = np.lib.format.open_memmap(self.pos_unwrap_path, mode="r")
        cell = np.lib.format.open_memmap(self.cell_path, mode="r")
        q_int = np.lib.format.open_memmap(q_int_path, mode="r")
        shell_id = None if shell_id_path is None else np.lib.format.open_memmap(shell_id_path, mode="r")

        from ripple.kernel.fpcf_ext import s4 as _s4

        try:
            S4, q_count, cnt, mobile_fraction = _s4(
                pos,
                pos_unwrap,
                cell,
                q_int,
                shell_id,
                float(q_min),
                float(q_max),
                float(dq_shell),
                int(nbins),
                float(a),
                lags,
                int(n_workers),
                t1_slices,
                bool(self.cell_static),
            )
        finally:
            del pos, pos_unwrap, cell, q_int
            if shell_id is not None:
                del shell_id

        return S4Result(
            S4=np.asarray(S4),
            q_count=np.asarray(q_count),
            cnt=np.asarray(cnt),
            mobile_fraction=np.asarray(mobile_fraction),
            q_shell=q_shell,
            q_max=float(q_max),
            dq_shell=float(dq_shell),
            q_min=float(q_min),
            a=float(a),
            lags=lags.astype(np.int64, copy=False),
            times_ps=times_ps,
            timestep_ps=None if timestep_ps is None else float(timestep_ps),
        )

    def clean(self) -> None:
        import shutil

        cache = Path(self.cache_dir)
        if cache.exists() and cache.name.startswith(".ripple_prepare_cache_"):
            shutil.rmtree(cache)
        else:
            raise RuntimeError(f"Refuse to delete unexpected path: {cache}")


def prepare_4pcf(
    trajectory,
    target_atoms: str,
    n_frames: int | None = None,
    save_dir: str = ".",
    pos_dtype: str = "float64",
    reuse_memmap: bool = False,
    trajectory_tag: str = "notag",
) -> Prepared4PCF:
    """Prepare memmaps for mobility-based four-point correlation functions.

    One cache serves all three observables because they share the same underlying
    binary self-mobility field. G4/S4 additionally reuse the reference positions
    at t0, while chi4 only needs the unwrapped displacement history.
    """

    def sanitize_tag(tag: str) -> str:
        tag = str(tag)
        return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in tag)[:120]

    def ok_memmap(path: Path, shape, dtype) -> bool:
        if not path.exists():
            return False
        try:
            mm = np.lib.format.open_memmap(path, mode="r")
            ok = (tuple(mm.shape) == tuple(shape)) and (mm.dtype == np.dtype(dtype))
            del mm
            return bool(ok)
        except Exception:
            return False

    def cell_sigma(cell: np.ndarray) -> float:
        gram = np.asarray(cell, dtype=np.float64) @ np.asarray(cell, dtype=np.float64).T
        eigs = np.linalg.eigvalsh(gram)
        sigma = float(np.sqrt(max(0.0, float(np.max(eigs)))))
        if (not np.isfinite(sigma)) or sigma <= 0.0:
            raise ValueError("Failed to build a valid reciprocal-space search bound from the cell.")
        return sigma

    def build_prepared(periodic_all: bool, cell_static: bool, cell_sigma_max: float) -> Prepared4PCF:
        return Prepared4PCF(
            cache_dir=str(cache_dir),
            trajectory_tag=str(trajectory_tag),
            save_dir=str(save_dir),
            feature=str(feature),
            material_name=str(material_name),
            n_frames=int(T),
            n_target=int(n_target),
            periodic_all=bool(periodic_all),
            cell_static=bool(cell_static),
            wrap=bool(wrap),
            scaled=bool(scaled),
            pos_dtype=str(pos_dtype_name),
            cell_sigma_max=float(cell_sigma_max),
            target_atoms=str(target_atoms),
            cell_path=str(cell_path),
            pbc_path=str(pbc_path),
            pos_path=str(pos_path),
            pos_unwrap_path=str(pos_unwrap_path),
            meta_path=str(meta_path),
        )

    scaled = True
    wrap = True

    if not isinstance(reuse_memmap, bool):
        raise TypeError("reuse_memmap must be bool")
    if (not isinstance(save_dir, str)) or (not isinstance(pos_dtype, str)) or (not isinstance(trajectory_tag, str)):
        raise TypeError("save_dir/pos_dtype/trajectory_tag must be strings")
    if not isinstance(target_atoms, str):
        raise TypeError("target_atoms must be a string")

    trajectory_tag = sanitize_tag(trajectory_tag)
    if reuse_memmap and trajectory_tag == "notag":
        warnings.warn(
            "Caution: reuse_memmap=True but trajectory_tag='notag', which may cause wrong loading!",
            RuntimeWarning,
        )

    save_dir_p = Path(save_dir)
    save_dir_p.mkdir(parents=True, exist_ok=True)
    cache_dir = save_dir_p / f".ripple_prepare_cache_{trajectory_tag}"
    cache_dir.mkdir(parents=True, exist_ok=True)

    datatype = np.dtype(pos_dtype)
    if datatype not in (np.float32, np.float64):
        raise ValueError("pos_dtype must be 'float32' or 'float64'.")
    pos_dtype_name = str(datatype.name)

    is_sequence = hasattr(trajectory, "__len__") and hasattr(trajectory, "__getitem__")
    is_factory = callable(trajectory)
    if is_sequence:
        T = len(trajectory)
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory)

    elif is_factory:
        reiterable = True

        def make_iter() -> Iterator:
            return iter(trajectory())

        if n_frames is None:
            warnings.warn(
                "prepare_4pcf(): trajectory is a factory but n_frames is None. "
                "This will iterate the trajectory TWICE (count + write). "
                "Next time, pass n_frames to avoid the extra pass.",
                RuntimeWarning,
            )
            T = 0
            for _ in make_iter():
                T += 1
        else:
            T = int(n_frames)
    else:
        reiterable = False
        if n_frames is None:
            raise TypeError(
                "Iterable trajectory without known length. Pass n_frames=..., "
                "or pass a factory: trajectory=lambda: ase.io.iread(...)."
            )
        T = int(n_frames)
        it_single = iter(trajectory)

        def make_iter() -> Iterator:
            return it_single

    if T < 1:
        raise ValueError("Empty trajectory. n_frames must be >= 1.")

    it0 = make_iter()
    try:
        first = next(it0)
    except StopIteration as exc:
        raise ValueError("Empty trajectory.") from exc

    species_list = np.asarray(first.symbols)
    material_name = str(first.get_chemical_formula())
    is_target_full = species_list == target_atoms
    n_target = int(is_target_full.sum())
    if n_target < 1:
        raise ValueError(f"No atoms found for target_atoms={target_atoms}")
    idx_target_full = np.flatnonzero(is_target_full).astype(np.int64)

    feature = f"{material_name}_4pcf_{target_atoms}_sc{int(scaled)}_wr{int(wrap)}_uw1_{pos_dtype_name}"
    meta_path = cache_dir / f"meta_{feature}.npz"
    cell_path = cache_dir / f"cell_{feature}.cell.npy"
    pbc_path = cache_dir / f"pbc_{feature}.pbc.npy"
    pos_path = cache_dir / f"positions_{feature}.pos.npy"
    pos_unwrap_path = cache_dir / f"positions_unwrap_{feature}.pos.npy"

    if reuse_memmap:
        ok_pos = ok_memmap(pos_path, (T, n_target, 3), datatype)
        ok_pos_uw = ok_memmap(pos_unwrap_path, (T, n_target, 3), datatype)
        ok_cell = ok_memmap(cell_path, (T, 3, 3), np.float64)
        ok_pbc = ok_memmap(pbc_path, (T, 3), np.bool_)
        ok_all = meta_path.exists() and ok_pos and ok_pos_uw and ok_cell and ok_pbc
        if ok_all and (not reiterable):
            raise ValueError(
                "Cannot safely reuse existing memmaps with a single-pass Iterable (first frame already consumed). "
                "Use a factory: trajectory=lambda: ase.io.iread(...)."
            )
        if ok_all:
            with np.load(meta_path, allow_pickle=False) as meta:
                return build_prepared(
                    bool(meta["periodic_all"]),
                    bool(meta["cell_static"]),
                    float(meta["cell_sigma_max"]),
                )

    created_paths = [meta_path]
    pos_mm = pos_uw_mm = cell_mm = pbc_mm = None
    try:
        pos_mm = np.lib.format.open_memmap(pos_path, mode="w+", dtype=datatype, shape=(T, n_target, 3))
        created_paths.append(pos_path)
        pos_uw_mm = np.lib.format.open_memmap(pos_unwrap_path, mode="w+", dtype=datatype, shape=(T, n_target, 3))
        created_paths.append(pos_unwrap_path)
        cell_mm = np.lib.format.open_memmap(cell_path, mode="w+", dtype=np.float64, shape=(T, 3, 3))
        created_paths.append(cell_path)
        pbc_mm = np.lib.format.open_memmap(pbc_path, mode="w+", dtype=np.bool_, shape=(T, 3))
        created_paths.append(pbc_path)

        frames = make_iter() if reiterable else itertools.chain([first], it0)
        periodic_all = True
        cell_static = True
        cell_sigma_max = 0.0
        last_cell = None
        cell_prev = None
        pbc_prev = None
        x_prev_raw = None
        x_unwrap_prev = None
        t_last = -1

        for t, frame in enumerate(frames):
            if t >= T:
                break
            t_last = t

            # Wrapped scaled coordinates are reused by G4(r,t) and S4(q,t) at the
            # reference time t0.
            sp = np.asarray(frame.get_scaled_positions(wrap=wrap), dtype=np.float64)
            if sp.ndim != 2 or sp.shape[1] != 3:
                raise ValueError(f"Expected scaled positions (N,3) at t={t}.")
            pos_mm[t] = sp[idx_target_full].astype(datatype, copy=False)

            cell_t = np.asarray(frame.cell, dtype=np.float64)
            if cell_t.shape != (3, 3):
                raise ValueError(f"Expected 3x3 cell at t={t}. Got {cell_t.shape}.")
            cell_mm[t] = cell_t
            cell_sigma_max = max(cell_sigma_max, cell_sigma(cell_t))
            if t == 0:
                last_cell = np.array(cell_t, dtype=np.float64, copy=True)
            elif cell_static and (np.max(np.abs(cell_t - last_cell)) > 1e-10):
                cell_static = False

            pbc_t = np.asarray(frame.pbc, dtype=np.bool_)
            if pbc_t.shape != (3,):
                raise ValueError(f"Expected pbc shape (3,) at t={t}. Got {pbc_t.shape}.")
            pbc_mm[t] = pbc_t
            periodic_all &= bool(np.all(pbc_t))

            # The mobility field depends on real displacements, so we cache an
            # unwrapped Cartesian trajectory for the selected species as well.
            x_raw = np.asarray(frame.positions, dtype=np.float64)[idx_target_full]
            if x_raw.ndim != 2 or x_raw.shape[1] != 3:
                raise ValueError(f"Expected Cartesian positions (N,3) at t={t}.")
            if t == 0:
                x_prev_raw = x_raw
                x_unwrap_prev = x_raw.copy()
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)
                pos_uw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
            else:
                try:
                    inv_cell_prev = np.linalg.inv(cell_prev)
                    inv_cell_curr = np.linalg.inv(cell_t)
                    s_prev = x_prev_raw @ inv_cell_prev
                    s_curr = x_raw @ inv_cell_curr
                    image = np.zeros_like(s_curr)
                    pbc_step = np.logical_and(pbc_prev, pbc_t)
                    image[:, pbc_step] = np.rint((s_curr - s_prev)[:, pbc_step])
                    dx = x_raw - x_prev_raw - (image @ cell_t)
                except Exception:
                    dx = x_raw - x_prev_raw
                x_unwrap_prev = x_unwrap_prev + dx
                pos_uw_mm[t] = x_unwrap_prev.astype(datatype, copy=False)
                x_prev_raw = x_raw
                cell_prev = np.array(cell_t, dtype=np.float64, copy=True)
                pbc_prev = np.array(pbc_t, dtype=np.bool_, copy=True)

        if (t_last + 1) != T:
            raise ValueError(f"n_frames mismatch: expected {T}, got {t_last + 1} frames.")

        pos_mm.flush()
        pos_uw_mm.flush()
        cell_mm.flush()
        pbc_mm.flush()

        np.savez(
            meta_path,
            n_frames=np.int64(T),
            n_target=np.int64(n_target),
            scaled=np.bool_(scaled),
            wrap=np.bool_(wrap),
            pos_dtype=pos_dtype_name,
            cell_static=np.bool_(cell_static),
            periodic_all=np.bool_(periodic_all),
            cell_sigma_max=np.float64(cell_sigma_max),
            target_atoms=str(target_atoms),
        )
    except Exception:
        try:
            del pos_mm, pos_uw_mm, cell_mm, pbc_mm
        except Exception:
            pass
        for path in created_paths:
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass
        raise
    finally:
        try:
            del pos_mm, pos_uw_mm, cell_mm, pbc_mm
        except Exception:
            pass

    return build_prepared(periodic_all, cell_static, cell_sigma_max)
