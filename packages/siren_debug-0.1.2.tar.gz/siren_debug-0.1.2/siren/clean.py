# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import re


TOKEN_NAME = "siren"

# detecta siren(
CALL_RE = re.compile(r"\bsiren\s*\(")


def line_calls_siren(line):
    stripped = line.strip()

    # ignorar import
    if stripped.startswith("import ") or stripped.startswith("from "):
        return False

    # procurar chamada siren(
    if CALL_RE.search(line):
        return True

    return False


def clean_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except TypeError:
        with open(path, "r") as f:
            lines = f.readlines()

    new_lines = []
    removed = 0

    for line in lines:
        if line_calls_siren(line):
            removed += 1
            continue

        new_lines.append(line)

    if removed:
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
        except TypeError:
            with open(path, "w") as f:
                f.writelines(new_lines)

    return removed


def clean_directory(root):
    total_removed = 0

    for base, dirs, files in os.walk(root):

        # ignorar venv automaticamente
        if "venv" in base.lower():
            continue

        if "__pycache__" in base:
            continue

        for name in files:
            if name.endswith(".py"):
                path = os.path.join(base, name)
                total_removed += clean_file(path)

    return total_removed


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    removed = clean_directory(target)
    print("SIREN CLEAN: {} linhas removidas".format(removed))


if __name__ == "__main__":
    main()