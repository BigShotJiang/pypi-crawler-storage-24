//! # termichart-charts
//!
//! Chart implementations for the TermiChart terminal charting SDK.
//!
//! This crate provides:
//!
//! - [`LineChart`] -- line charts with area fill using half-block characters.
//! - [`CandlestickChart`] -- OHLCV candlestick charts with wick rendering.
//! - [`BarChart`] -- horizontal and vertical bar charts.
//! - [`Histogram`] -- distribution histograms.
//! - [`Dashboard`] -- multi-chart dashboard layouts.
//! - [`ChartBuilder`] -- fluent API for constructing and rendering charts.
//! - [`InteractiveChart`] -- keyboard-driven scroll and zoom.
//! - [`TuiApp`] -- full-screen terminal UI application.

pub mod bar;
pub mod builder;
pub mod candlestick;
pub mod dashboard;
pub mod histogram;
pub mod interactive;
pub mod line;
pub mod portfolio;
pub mod sparkline;
pub mod tui;
pub mod watch;

pub use bar::BarChart;
pub use builder::ChartBuilder;
pub use candlestick::CandlestickChart;
pub use dashboard::Dashboard;
pub use histogram::Histogram;
pub use interactive::InteractiveChart;
pub use line::LineChart;
pub use portfolio::{Holding, Portfolio};
pub use tui::TuiApp;
pub use watch::WatchMode;
