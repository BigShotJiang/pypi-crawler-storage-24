# termichart-charts

Chart implementations for the [TermiChart](https://github.com/HeyElsa/terminal-chart) terminal charting SDK.

## Overview

- **LineChart** — Line charts with area fill using half-block characters
- **CandlestickChart** — OHLCV candlestick charts with wick rendering
- **BarChart** — Horizontal/vertical bar charts
- **Histogram** — Distribution histograms
- **Sparkline** — Compact inline sparklines
- **Dashboard** — Multi-chart dashboard layouts
- **ChartBuilder** — Fluent API for constructing charts
- **InteractiveChart** — Keyboard-driven scroll and zoom
- **TuiApp** — Full-screen terminal UI application

## Usage

```rust
use termichart_charts::ChartBuilder;

let chart = ChartBuilder::line()
    .size(80, 24)
    .title("My Chart")
    .add_point(0.0, 1.0)
    .add_point(1.0, 4.0)
    .add_point(2.0, 2.0)
    .render()
    .unwrap();

println!("{chart}");
```

See the [main repository](https://github.com/HeyElsa/terminal-chart) for full documentation.

## License

MIT
