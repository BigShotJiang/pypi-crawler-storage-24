use termichart_core::Style;

use crate::cell::CellGrid;

/// Full block character used for candle bodies.
const FULL_BLOCK: char = '\u{2588}';
/// Box-drawing vertical line used for wicks.
const WICK_CHAR: char = '\u{2502}';
/// Upper half block.
const UPPER_HALF: char = '\u{2580}';
/// Lower half block.
const LOWER_HALF: char = '\u{2584}';

/// A stateless canvas that uses Unicode block elements for rendering
/// candlestick bodies and wicks.
#[derive(Debug, Clone, Copy)]
pub struct BlockCanvas {
    /// Width in character cells (informational).
    pub width: u16,
    /// Height in character cells (informational).
    pub height: u16,
}

impl BlockCanvas {
    /// Creates a new `BlockCanvas` with the given character-cell dimensions.
    pub fn new(width: u16, height: u16) -> Self {
        Self { width, height }
    }

    /// Draws a candle body as a column of full-block characters between
    /// `top_row` and `bottom_row` (inclusive).
    pub fn draw_candle_body(
        &self,
        grid: &mut CellGrid,
        col: u16,
        top_row: u16,
        bottom_row: u16,
        style: Style,
    ) {
        let start = top_row.min(bottom_row);
        let end = top_row.max(bottom_row);
        for row in start..=end {
            grid.set(col, row, FULL_BLOCK, style);
        }
    }

    /// Draws a wick (thin vertical line) between `top_row` and `bottom_row`
    /// (inclusive) using the box-drawing vertical character.
    pub fn draw_wick(
        &self,
        grid: &mut CellGrid,
        col: u16,
        top_row: u16,
        bottom_row: u16,
        style: Style,
    ) {
        let start = top_row.min(bottom_row);
        let end = top_row.max(bottom_row);
        for row in start..=end {
            grid.set(col, row, WICK_CHAR, style);
        }
    }

    /// Draws an upper half-block character at `(col, row)`.
    pub fn draw_half_block_top(
        &self,
        grid: &mut CellGrid,
        col: u16,
        row: u16,
        style: Style,
    ) {
        grid.set(col, row, UPPER_HALF, style);
    }

    /// Draws a lower half-block character at `(col, row)`.
    pub fn draw_half_block_bottom(
        &self,
        grid: &mut CellGrid,
        col: u16,
        row: u16,
        style: Style,
    ) {
        grid.set(col, row, LOWER_HALF, style);
    }
}
