//! # termichart-render
//!
//! Low-level rendering primitives for the termichart charting library.
//!
//! This crate provides:
//!
//! - [`CellGrid`] / [`StyledCell`] -- a 2-D character buffer with per-cell styling.
//! - [`BrailleCanvas`] -- sub-pixel rendering using Unicode braille characters.
//! - [`BlockCanvas`] -- candlestick body rendering using Unicode block elements.
//! - [`AxisRenderer`] -- Y and X axis lines, tick marks, and labels.
//! - [`Layout`] -- partitioning the terminal area into chart / axis / title regions.
//! - [`render_to_string`] -- converting a `CellGrid` to an ANSI-escaped string.
//! - Painter utilities -- helper functions for drawing text, lines, and rectangles.

pub mod ansi;
pub mod axis;
pub mod block;
pub mod braille;
pub mod cell;
pub mod export;
pub mod layout;
pub mod painter;

// Re-export key types at the crate root for convenience.
pub use ansi::render_to_string;
pub use export::{export_to_file, strip_ansi};
pub use axis::{nice_ticks, AxisRenderer};
pub use block::BlockCanvas;
pub use braille::BrailleCanvas;
pub use cell::{CellGrid, StyledCell};
pub use layout::Layout;
pub use painter::{draw_hline, draw_text, draw_vline, fill_rect};
