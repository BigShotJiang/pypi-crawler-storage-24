# termichart-render

Low-level terminal rendering primitives for the [TermiChart](https://github.com/HeyElsa/terminal-chart) terminal charting SDK.

## Overview

- **CellGrid / StyledCell** — 2D character buffer with per-cell styling
- **BrailleCanvas** — Sub-pixel rendering using Unicode braille characters
- **BlockCanvas** — Candlestick body rendering using Unicode block elements
- **AxisRenderer** — Y and X axis lines, tick marks, and labels
- **Layout** — Partitioning the terminal area into chart/axis/title regions
- **ANSI output** — Converting a CellGrid to an ANSI-escaped string

## Usage

```rust
use termichart_render::{CellGrid, Layout, render_to_string};

let grid = CellGrid::new(80, 24);
let output = render_to_string(&grid);
println!("{output}");
```

See the [main repository](https://github.com/HeyElsa/terminal-chart) for full documentation.

## License

MIT
