# termichart-data

Data adapters, technical indicators, and exchange clients for the [TermiChart](https://github.com/HeyElsa/terminal-chart) terminal charting SDK.

## Overview

- **Adapters** — `JsonAdapter`, `CsvAdapter`, `StreamAdapter` for loading chart data
- **Indicators** — SMA, EMA, VWAP, Bollinger Bands, RSI, MACD
- **Exchange clients** — Binance REST and WebSocket integration
- **Transforms** — Auto-range, Heikin-Ashi conversion, nice tick generation

## Usage

```rust
use termichart_core::Indicator;
use termichart_data::{SmaIndicator, JsonAdapter};

// Compute a 20-period SMA from candle data
let sma = SmaIndicator::new(20);
let overlay_points = sma.compute(&candles);
```

See the [main repository](https://github.com/HeyElsa/terminal-chart) for full documentation.

## License

MIT
