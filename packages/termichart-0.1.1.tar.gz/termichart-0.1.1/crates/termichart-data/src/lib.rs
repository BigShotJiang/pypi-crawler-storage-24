//! # termichart-data
//!
//! Data adapters, technical indicators, and exchange clients for TermiChart.
//!
//! This crate provides:
//!
//! - [`JsonAdapter`] / [`CsvAdapter`] / [`StreamAdapter`] -- data source adapters.
//! - [`SmaIndicator`] / [`EmaIndicator`] / [`VwapIndicator`] -- moving average indicators.
//! - [`BollingerBandsIndicator`] / [`RsiIndicator`] / [`MacdIndicator`] -- advanced indicators.
//! - [`ExchangeClient`] -- REST client for fetching candle data from exchanges.
//! - [`WsStream`] -- WebSocket streaming for real-time data.
//! - [`auto_range`] / [`to_heikin_ashi`] / [`nice_ticks`] -- data transforms.

pub mod csv_adapter;
pub mod exchange;
pub mod indicators;
pub mod json_adapter;
pub mod series;
pub mod stream_adapter;
pub mod transform;
pub mod ws_stream;

pub use csv_adapter::CsvAdapter;
pub use exchange::{Exchange, ExchangeClient};
pub use indicators::{
    BollingerBandsIndicator, EmaIndicator, MacdIndicator, RsiIndicator, SmaIndicator,
    VwapIndicator,
};
pub use json_adapter::JsonAdapter;
pub use series::DataSeries;
pub use stream_adapter::StreamAdapter;
pub use transform::{auto_range, auto_range_points, nice_ticks, to_heikin_ashi};
pub use ws_stream::WsStream;
