# termichart-core

Core types, traits, colors, and configuration for the [TermiChart](https://github.com/HeyElsa/terminal-chart) terminal charting SDK.

## Overview

This crate provides the foundational types shared across all TermiChart crates:

- **Types** — `Point`, `Candle`, `Viewport`, `Range`, `Rect`, `TimeFrame`
- **Traits** — `ChartRenderer`, `DataAdapter`, `Indicator`
- **Configuration** — `ChartConfig`, `ChartType`, `XAxisFormat`
- **Theming** — `Theme`, `Color`, `Style`, `ColorMode`
- **Errors** — `TermichartError`, `Result`

## Usage

```rust
use termichart_core::{Point, Candle, ChartConfig, ChartType};

let config = ChartConfig {
    chart_type: ChartType::Line,
    width: Some(80),
    height: Some(24),
    ..Default::default()
};
```

See the [main repository](https://github.com/HeyElsa/terminal-chart) for full documentation.

## License

MIT
