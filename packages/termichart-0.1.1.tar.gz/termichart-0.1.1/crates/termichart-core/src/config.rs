use serde::{Deserialize, Serialize};

use crate::color::{ColorMode, Theme};
use crate::types::OverlayKind;

/// The visual chart type to render.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum ChartType {
    /// A simple line chart connecting data points.
    Line,
    /// An OHLC candlestick chart.
    Candlestick,
    /// A vertical bar chart.
    Bar,
    /// A histogram chart that bins continuous data.
    Histogram,
}

/// How x-axis tick labels are formatted.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum XAxisFormat {
    /// Plain numeric labels (default).
    Numeric,
    /// Interpret x values as Unix-epoch seconds and format as `HH:MM:SS`.
    Time,
}

impl Default for ChartType {
    fn default() -> Self {
        ChartType::Line
    }
}

/// Top-level configuration for a chart.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ChartConfig {
    /// Which chart type to render.
    pub chart_type: ChartType,
    /// Explicit width in columns. `None` means auto-detect from terminal size.
    pub width: Option<u16>,
    /// Explicit height in rows. `None` means auto-detect from terminal size.
    pub height: Option<u16>,
    /// The colour theme.
    pub theme: Theme,
    /// The colour capability level.
    pub color_mode: ColorMode,
    /// Whether to draw the axis frame.
    pub show_axis: bool,
    /// Whether to draw background grid lines.
    pub show_grid: bool,
    /// An optional chart title rendered above the plot area.
    pub title: Option<String>,
    /// Overlays (indicators) to compute and draw on top of the chart.
    pub overlays: Vec<OverlayKind>,
    /// How x-axis labels are formatted.
    pub x_axis_format: XAxisFormat,
    /// Whether to apply Heikin-Ashi transformation to candlestick data.
    pub heikin_ashi: bool,
}

impl Default for ChartConfig {
    fn default() -> Self {
        Self {
            chart_type: ChartType::default(),
            width: None,
            height: None,
            theme: Theme::default(),
            color_mode: ColorMode::detect(),
            show_axis: true,
            show_grid: true,
            title: None,
            overlays: Vec::new(),
            x_axis_format: XAxisFormat::Numeric,
            heikin_ashi: false,
        }
    }
}
