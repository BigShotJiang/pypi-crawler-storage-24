use thiserror::Error;

/// The primary error type for the termichart library.
#[derive(Debug, Error)]
pub enum TermichartError {
    /// A parsing error with a descriptive message.
    #[error("parse error: {0}")]
    ParseError(String),

    /// An I/O error forwarded from `std::io`.
    #[error("io error: {0}")]
    IoError(#[from] std::io::Error),

    /// A data-related error (missing data, out-of-range, etc.).
    #[error("data error: {0}")]
    DataError(String),

    /// A rendering error.
    #[error("render error: {0}")]
    RenderError(String),

    /// A configuration error.
    #[error("config error: {0}")]
    ConfigError(String),
}

/// Convenience alias used throughout the crate.
pub type Result<T> = std::result::Result<T, TermichartError>;
