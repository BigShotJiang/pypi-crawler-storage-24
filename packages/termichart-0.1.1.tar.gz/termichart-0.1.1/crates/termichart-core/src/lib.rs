//! # termichart-core
//!
//! Core types, traits, colors, and configuration for the TermiChart charting SDK.
//!
//! This crate provides:
//!
//! - [`Point`] / [`Candle`] -- fundamental data types for chart rendering.
//! - [`ChartConfig`] -- chart configuration (type, dimensions, overlays, theme).
//! - [`Theme`] / [`Color`] / [`Style`] -- theming and color support.
//! - [`ChartRenderer`] / [`DataAdapter`] / [`Indicator`] -- core traits.
//! - [`Viewport`] / [`Range`] / [`Rect`] -- coordinate and layout primitives.

pub mod color;
pub mod config;
pub mod error;
pub mod traits;
pub mod types;

// Re-export the most commonly used items at the crate root for convenience.
pub use color::{Color, ColorMode, Style, Theme, ThemeName};
pub use config::{ChartConfig, ChartType, XAxisFormat};
pub use error::{Result, TermichartError};
pub use traits::{ChartRenderer, DataAdapter, Indicator};
pub use types::{Candle, OverlayKind, Point, Range, Rect, TimeFrame, Viewport};
