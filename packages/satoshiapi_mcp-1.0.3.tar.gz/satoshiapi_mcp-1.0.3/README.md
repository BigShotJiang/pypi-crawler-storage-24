mcp-name: io.satoshiapi/mcp

# SatoshiAPI MCP Server ⚡

Model Context Protocol server for [SatoshiAPI](https://api.satoshiapi.io) — Bitcoin intelligence via Lightning micropayments.

Pay-per-call Bitcoin data for AI agents: price, mempool fees, DCA signals, whale activity, market regime, risk score, and more. 10–200 sats per call via L402. No accounts, no API keys.

## Hosted MCP Server (recommended)

Connect directly — no installation needed:

```
https://api.satoshiapi.io/mcp
```

Any MCP client (Claude, Cursor, etc.) can connect instantly. Payments are handled per-call via L402 Lightning.

## Self-hosted (pip install)

```bash
pip install satoshiapi-mcp
```

Configure in Claude Desktop (`~/.config/claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "satoshiapi": {
      "command": "python3",
      "args": ["-m", "satoshiapi_mcp"],
      "env": {
        "SATOSHIAPI_LND_REST": "https://your-lnd:8079",
        "SATOSHIAPI_LND_MACAROON": "/path/to/invoice.macaroon",
        "SATOSHIAPI_LND_CERT": "/path/to/tls.cert"
      }
    }
  }
}
```

## Tools (15 total)

| Tool | Cost | Description |
|------|------|-------------|
| `get_btc_price` | 10 sats | BTC/USD + 24h change |
| `get_mempool_fees` | 10 sats | Fee estimates (sat/vB) |
| `get_block_height` | 10 sats | Block height + hashrate |
| `get_halving_info` | 10 sats | Halving countdown + supply |
| `get_tx_info` | 10 sats | Transaction details |
| `get_sentiment` | 25 sats | Fear & Greed index |
| `get_fees_forecast` | 25 sats | Optimal send timing |
| `get_lightning_stats` | 25 sats | LN capacity + node stats |
| `get_address_info` | 25 sats | Address balance + UTXOs |
| `get_dca_signal` | 50 sats | STRONG_BUY/BUY/HOLD/REDUCE |
| `get_market_summary` | 50 sats | Full market snapshot |
| `get_whale_activity` | 100 sats | Large tx + exchange flows |
| `get_market_regime` | 150 sats | Bull/bear/crab + confidence |
| `get_risk_score` | 200 sats | Composite risk 0–100 |
| `get_dca_plan` | 200 sats | Personalized DCA plan |

## Links

- Live API: [api.satoshiapi.io](https://api.satoshiapi.io/health)
- Source: [github.com/SatoshiAPI/satoshi-btc-api](https://github.com/SatoshiAPI/satoshi-btc-api) (MIT)
- Node: `03176f9948d333f9cc1d7d409353f995816e44b3c90a3300b5a08ceba811faf989`
