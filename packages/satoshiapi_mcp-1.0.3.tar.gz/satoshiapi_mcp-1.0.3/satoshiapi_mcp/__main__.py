from satoshiapi_mcp import mcp
mcp.run()
