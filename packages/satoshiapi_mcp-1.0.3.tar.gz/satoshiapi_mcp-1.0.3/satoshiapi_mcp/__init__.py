#!/usr/bin/env python3
"""
SatoshiAPI MCP Server — Lightning-powered Bitcoin data for AI agents

Exposes SatoshiAPI endpoints as MCP tools. When an agent calls a tool:
1. The MCP server hits the API endpoint
2. If a 402 is returned, it handles the L402 payment flow automatically
   (if an LND node is configured) or returns the invoice for manual payment
3. Returns the data to the agent

This makes SatoshiAPI discoverable by any MCP-compatible agent (Claude, GPT, Gemini, etc.)
"""

import json
import os
import ssl
import re
import base64
import hashlib
import urllib.request
import urllib.parse
from typing import Optional

from mcp.server import FastMCP

# ── Server setup ─────────────────────────────────────────────────────────────
mcp = FastMCP(
    "SatoshiAPI",
    instructions=(
        "Bitcoin intelligence API powered by Lightning micropayments. "
        "Get real-time BTC price, mempool fees, block height, sentiment, "
        "and DCA signals. Payments are 10-50 sats per call via L402."
    ),
)

# ── Config ───────────────────────────────────────────────────────────────────
API_BASE = os.environ.get("SATOSHIAPI_URL", "https://api.satoshiapi.io")

# Optional: LND connection for auto-payment
LND_REST = os.environ.get("SATOSHIAPI_LND_REST", "")
LND_MACAROON_PATH = os.environ.get("SATOSHIAPI_LND_MACAROON", "")
LND_CERT_PATH = os.environ.get("SATOSHIAPI_LND_CERT", "")

# Cache for paid tokens (macaroon:preimage pairs)
_token_cache: dict[str, str] = {}


# ── LND helpers (optional — for auto-payment) ───────────────────────────────
def _lnd_available() -> bool:
    return bool(LND_REST and LND_MACAROON_PATH and LND_CERT_PATH)


def _lnd_pay_invoice(invoice: str) -> Optional[str]:
    """Pay a Lightning invoice via LND REST. Returns preimage hex or None."""
    if not _lnd_available():
        return None
    try:
        with open(LND_MACAROON_PATH, "rb") as f:
            macaroon_hex = f.read().hex()
        ctx = ssl.create_default_context()
        ctx.load_verify_locations(LND_CERT_PATH)

        data = json.dumps({
            "payment_request": invoice,
            "timeout_seconds": 30,
            "fee_limit": {"fixed": 100},
        }).encode()
        req = urllib.request.Request(
            f"{LND_REST}/v2/router/send",
            data=data,
            method="POST",
        )
        req.add_header("Grpc-Metadata-macaroon", macaroon_hex)
        req.add_header("Content-Type", "application/json")

        with urllib.request.urlopen(req, context=ctx, timeout=35) as r:
            # Streaming response — read lines until we get a result
            for line in r:
                chunk = json.loads(line.decode().strip().strip(","))
                result = chunk.get("result", chunk)
                status = result.get("status", "")
                if status == "SUCCEEDED":
                    preimage_b64 = result.get("payment_preimage", "")
                    preimage_bytes = base64.b64decode(preimage_b64)
                    return preimage_bytes.hex()
                elif status in ("FAILED", "FAILED_TIMEOUT", "FAILED_NO_ROUTE"):
                    return None
        return None
    except Exception:
        return None


# ── API request with L402 handling ───────────────────────────────────────────
def _api_request(endpoint: str) -> dict:
    """
    Make an API request with automatic L402 handling.
    Returns the data on success, or payment instructions if auto-pay unavailable.
    """
    url = f"{API_BASE}{endpoint}"

    # Check if we have a cached token for this endpoint
    if endpoint in _token_cache:
        try:
            req = urllib.request.Request(url)
            req.add_header("Authorization", f"L402 {_token_cache[endpoint]}")
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError:
            del _token_cache[endpoint]

    # Make initial request
    try:
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "SatoshiAPI-MCP/1.0")
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code != 402:
            return {"error": f"API returned HTTP {e.code}"}

        # Extract L402 challenge
        www_auth = e.headers.get("WWW-Authenticate", "")
        macaroon_match = re.search(r'macaroon="([^"]+)"', www_auth)
        invoice_match = re.search(r'invoice="([^"]+)"', www_auth)
        price = e.headers.get("X-Price-Sats", "?")

        if not macaroon_match or not invoice_match:
            return {"error": "Invalid L402 challenge from server"}

        macaroon = macaroon_match.group(1)
        invoice = invoice_match.group(1)

        # Try auto-payment if LND is configured
        if _lnd_available():
            preimage = _lnd_pay_invoice(invoice)
            if preimage:
                token = f"{macaroon}:{preimage}"
                _token_cache[endpoint] = token
                # Retry with token
                try:
                    req = urllib.request.Request(url)
                    req.add_header("Authorization", f"L402 {token}")
                    with urllib.request.urlopen(req, timeout=15) as r:
                        return json.loads(r.read())
                except Exception as ex:
                    return {"error": f"Payment succeeded but data fetch failed: {ex}"}
            else:
                return {
                    "error": "Auto-payment failed (check LND balance and connectivity)",
                    "price_sats": price,
                    "invoice": invoice,
                }

        # No LND configured — return payment instructions
        return {
            "payment_required": True,
            "price_sats": price,
            "invoice": invoice,
            "macaroon": macaroon,
            "instructions": (
                f"This endpoint costs {price} sats. Pay the Lightning invoice "
                "and provide the preimage to complete the request. "
                "Or configure SATOSHIAPI_LND_REST, SATOSHIAPI_LND_MACAROON, "
                "and SATOSHIAPI_LND_CERT environment variables for auto-payment."
            ),
        }
    except Exception as e:
        return {"error": str(e)}


# ── MCP Tools ────────────────────────────────────────────────────────────────

@mcp.tool()
def get_btc_price() -> str:
    """Get current Bitcoin price in USD with 24-hour change percentage.
    Costs 10 sats via Lightning. Auto-pays if LND is configured."""
    result = _api_request("/price")
    return json.dumps(result, indent=2)


@mcp.tool()
def get_mempool_fees() -> str:
    """Get current Bitcoin mempool fee estimates in sat/vB for different confirmation targets.
    Costs 10 sats via Lightning. Auto-pays if LND is configured."""
    result = _api_request("/mempool")
    return json.dumps(result, indent=2)


@mcp.tool()
def get_block_height() -> str:
    """Get latest Bitcoin block height and network hashrate.
    Costs 10 sats via Lightning. Auto-pays if LND is configured."""
    result = _api_request("/blockheight")
    return json.dumps(result, indent=2)


@mcp.tool()
def get_sentiment() -> str:
    """Get Bitcoin Fear & Greed index (0-100) with classification.
    Costs 25 sats via Lightning. Auto-pays if LND is configured."""
    result = _api_request("/sentiment")
    return json.dumps(result, indent=2)


@mcp.tool()
def get_dca_signal() -> str:
    """Get DCA (Dollar Cost Averaging) signal for Bitcoin: STRONG_BUY, BUY, HOLD, REDUCE,
    or STRONG_REDUCE — with conviction percentage and reasoning based on Fear & Greed index,
    mempool fees, and price momentum.
    Costs 50 sats via Lightning. Auto-pays if LND is configured."""
    result = _api_request("/signal")
    return json.dumps(result, indent=2)


@mcp.tool()
def get_api_status() -> str:
    """Get SatoshiAPI service status, available endpoints, and pricing. Free — no payment required."""
    result = _api_request("/health")
    return json.dumps(result, indent=2)


@mcp.tool()
def pay_and_request(endpoint: str, macaroon: str, preimage: str) -> str:
    """Complete an L402 payment for a previously-requested endpoint.
    Use this after receiving a payment_required response and paying the invoice manually.

    Args:
        endpoint: The API endpoint path (e.g., "/price")
        macaroon: The base64 macaroon from the L402 challenge
        preimage: The 64-character hex preimage from paying the Lightning invoice
    """
    url = f"{API_BASE}{endpoint}"
    token = f"{macaroon}:{preimage}"
    try:
        req = urllib.request.Request(url)
        req.add_header("Authorization", f"L402 {token}")
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.loads(r.read())
            _token_cache[endpoint] = token
            return json.dumps(result, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# ── Resources ────────────────────────────────────────────────────────────────

@mcp.resource("satoshiapi://info")
def api_info() -> str:
    """SatoshiAPI service information and pricing."""
    return json.dumps({
        "service": "SatoshiAPI — Bitcoin Intelligence API",
        "base_url": API_BASE,
        "payment": "L402 Lightning micropayments",
        "endpoints": {
            "/price": {"cost": "10 sats", "desc": "BTC/USD price + 24h change"},
            "/mempool": {"cost": "10 sats", "desc": "Mempool fee estimates"},
            "/blockheight": {"cost": "10 sats", "desc": "Block height + hashrate"},
            "/sentiment": {"cost": "25 sats", "desc": "Fear & Greed index"},
            "/signal": {"cost": "50 sats", "desc": "DCA signal with reasoning"},
            "/health": {"cost": "Free", "desc": "Service status"},
        },
        "node": "03176f9948d333f9cc1d7d409353f995816e44b3c90a3300b5a08ceba811faf989",
        "github": "https://github.com/SatoshiAPI/satoshi-btc-api",
        "auto_payment": "Set SATOSHIAPI_LND_REST, SATOSHIAPI_LND_MACAROON, SATOSHIAPI_LND_CERT env vars",
    }, indent=2)


# ── Entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    mcp.run()
