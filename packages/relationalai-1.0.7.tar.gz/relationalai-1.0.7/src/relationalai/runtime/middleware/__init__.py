"""Execution middleware primitives (logging/metrics/retry/error mapping).

This package is intentionally backend-agnostic. Higher layers (client/services) are
responsible for choosing retry classification predicates and composing middleware.
"""

from __future__ import annotations

# Re-export the public surface so existing imports keep working:
# `from relationalai.runtime.middleware import LoggingMiddleware, RetryMiddleware, ...`

from .logging import LoggingMiddleware
from .base import Instrumentation, Policy
from .metrics import InMemoryMetricsSink, MetricsMiddleware, MetricsSink, NoOpMetricsSink
from .retry import RetryMiddleware, RetryPolicy
from .error_mapping import ErrorMappingMiddleware

__all__ = [
    "Instrumentation",
    "Policy",
    "LoggingMiddleware",
    "MetricsMiddleware",
    "MetricsSink",
    "NoOpMetricsSink",
    "InMemoryMetricsSink",
    "RetryPolicy",
    "RetryMiddleware",
    "ErrorMappingMiddleware",
]

