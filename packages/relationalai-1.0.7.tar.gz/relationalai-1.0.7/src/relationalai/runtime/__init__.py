"""Runtime-layer utilities (execution/session/middleware).

This layer is intentionally domain-agnostic: it provides reusable connection/session
and SQL execution primitives that domain modules (e.g. reasoners) can build on top of.
"""

from .errors import (
    RuntimeAuthError,
    RuntimeConnectionError,
    RuntimeError,
    RuntimeExecutionError,
    RuntimeUnknownError,
    RuntimeValidationError,
)
__all__ = [
    "RuntimeError",
    "RuntimeAuthError",
    "RuntimeConnectionError",
    "RuntimeExecutionError",
    "RuntimeValidationError",
    "RuntimeUnknownError",
]

