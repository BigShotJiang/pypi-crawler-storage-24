from __future__ import annotations


class RuntimeError(Exception):
    """Base error for runtime transport/session/execution operations."""


class RuntimeAuthError(RuntimeError):
    """Authentication/authorization error (transport-level)."""


class RuntimeConnectionError(RuntimeError):
    """Connection/session creation error (transport-level)."""


class RuntimeExecutionError(RuntimeError):
    """SQL execution error (transport-level)."""


class RuntimeValidationError(RuntimeExecutionError):
    """Invalid request / validation error returned by a remote service."""


class RuntimeUnknownError(RuntimeError):
    """Fallback when we cannot classify a runtime failure."""

