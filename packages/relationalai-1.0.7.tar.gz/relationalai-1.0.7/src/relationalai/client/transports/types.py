"""Structural typing shims for optional external dependencies.

This module intentionally avoids importing optional dependencies at runtime.
"""

from __future__ import annotations

from typing import Any, Protocol


class SnowparkDataFrameLike(Protocol):
    def collect(self, *args: Any, **kwargs: Any) -> Any: ...


class SnowparkSessionLike(Protocol):
    # Snowpark's type stubs include internal parameters/types that can break strict
    # structural typing checks in some environments (e.g. `Bind = None` on `_ast_stmt`).
    #
    # Middle-ground structural contract:
    # - session has a callable `sql(...)`
    # - it returns something with callable `collect(...)`
    # - we keep signatures permissive to avoid coupling to Snowpark version quirks
    def sql(self, query: str, *args: Any, **kwargs: Any) -> SnowparkDataFrameLike: ...

