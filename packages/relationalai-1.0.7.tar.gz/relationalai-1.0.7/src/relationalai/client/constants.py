"""Client-level constants (shared across services)."""

from __future__ import annotations

from typing import Final

DATABASE_ERRORS: Final[tuple[str, ...]] = ("database not found",)

