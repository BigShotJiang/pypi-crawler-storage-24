from __future__ import annotations

TIP_LABEL = "[yellow]Tip:[/yellow]"


def tip(message: str) -> str:
    msg = str(message or "").strip()
    return f"{TIP_LABEL} {msg}" if msg else TIP_LABEL

