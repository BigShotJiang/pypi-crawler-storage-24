"""Template for raiconfig.yaml.

A commented-out starting point showing all three connection types in one profile.
Uncomment and fill in the sections you need.
"""

CONFIG_TEMPLATE = """\
# raiconfig.yaml — RelationalAI configuration
# Uncomment and fill in the sections you need.

active_profile: dev

profile:                              # add more profiles (e.g. staging, prod) as needed
  dev:
    default_connection: snowflake   # change to: duckdb  or  local

    connections:

      # ── Snowflake ────────────────────────────────────────────────────────────
      snowflake:
        type: snowflake
        account: myorg-myaccount      # format: <org>-<account>, e.g. acme-prod123
        warehouse: compute_wh
        rai_app_name: relationalai    # name of the RAI app in your Snowflake account
        authenticator: username_password     # other options: username_password_mfa | externalbrowser | jwt | oauth | programmatic_access_token
        user: you@example.com
        password: "your_password"     # tip: use env var SNOWFLAKE_PASSWORD instead
        # role: MY_ROLE               # optional
        # database: MY_DATABASE       # optional
        # schema: PUBLIC              # optional

      # ── DuckDB ───────────────────────────────────────────────────────────────
      # duckdb:
      #   type: duckdb
      #   path: ":memory:"            # or a file path, e.g. /tmp/mydb.duckdb

      # ── Local RAI server ─────────────────────────────────────────────────────
      # local:
      #   type: local
      #   host: localhost
      #   port: 8010

    # ── Reasoners (optional) ─────────────────────────────────────────────────
    # reasoners:
    #   logic:
    #     name: my_reasoner           # reasoner instance name (Snowflake)
    #     size: HIGHMEM_X64_S         # reasoner size
"""
