"""
The RelationalAI Python SDK, also known as PyRel.
"""

import importlib.metadata
from typing import TYPE_CHECKING

__version__ = importlib.metadata.version(__package__ or __name__)

if TYPE_CHECKING:
    from . import client, config, semantics
    from .client import Client, connect, connect_sync, from_session, from_session_sync

__all__ = [
    "semantics",
    "config",
    "client",
    "Client",
    "connect",
    "connect_sync",
    "from_session",
    "from_session_sync",
    "__version__",
]

def __getattr__(name):
    """Lazy import submodules to avoid eager loading and side effects."""
    if name in ("semantics", "config", "client"):
        import importlib
        module = importlib.import_module(f".{name}", __name__)
        globals()[name] = module  # Cache for future access
        return module
    if name == "Client":
        import importlib

        client_mod = importlib.import_module(".client", __name__)
        val = getattr(client_mod, "Client")
        globals()[name] = val
        return val
    if name in ("connect", "connect_sync", "from_session", "from_session_sync"):
        import importlib

        client_mod = importlib.import_module(".client", __name__)
        val = getattr(client_mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    """Include lazy-loaded submodules in dir() output for discoverability."""
    return list(__all__) + list(globals().keys())
