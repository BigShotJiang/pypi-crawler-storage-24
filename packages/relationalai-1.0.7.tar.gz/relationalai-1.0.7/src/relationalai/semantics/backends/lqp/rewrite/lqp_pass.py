from dataclasses import dataclass
from ....metamodel.metamodel import Model, Task
from .....config import Config

@dataclass
class Pass():
    """
    A compiler rewrite pass.
    """
    @property
    def name(self):
        return self.__class__.__name__

    def rewrite_model(self, model: Model, config:Config) -> Model:
        new_root = self.rewrite_task(model.root, config)
        if new_root is model.root:
            return model
        return model.mut(root=new_root)

    def rewrite_task(self, node: Task, config:Config) -> Task:
        raise NotImplementedError(f"{self.name} rewrite_task not implemented")

    def reset(self):
        pass
