"""Backend execution system for RAI semantic queries.

This package provides database-agnostic execution through:
- Executor protocol: defines the interface for database executors
- DuckDBExecutor: DuckDB-specific executor implementation
- SnowflakeExecutor: Snowflake-specific executor implementation
"""

from .executor import Executor

__all__ = [
    "Executor",
]
