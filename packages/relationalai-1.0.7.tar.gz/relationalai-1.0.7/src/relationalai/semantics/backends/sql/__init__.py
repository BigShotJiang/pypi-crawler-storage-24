"""SQL backend implementation (SQL2)."""

from .analyzer import (
    SQL2Analysis,
    SQL2FragmentPlan,
    SQL2FragmentProjectionAssemblyPlan,
    SQL2FragmentProjectionJoinGroup,
    SQL2FragmentProjectionOutputColumn,
    SQL2FragmentProjectionSourceGroup,
    SQL2FragmentProjectionSpec,
    SQL2ModelAnalyzer,
)
from .coalesce import (
    SQL2CoalescedArtifacts,
    SQL2CoalescedGroup,
    SQL2Coalescer,
    SQL2WriteChannel,
)
from .compiler import SQL2Compiler
from .graph import (
    SQL2EdgeType,
    SQL2GraphArtifacts,
    SQL2GraphEdge,
    SQL2GraphNode,
    SQL2NonStratifiableGraphError,
)
from .ir import SQL2ExecutionPlan, SQL2ExecutionStep
from .model_analysis import ColumnInfo, ModelAnalysis, TableInfo, TableKind, determine_tables
from .normalize import (
    SQL2AggregateInstance,
    SQL2AggregateShape,
    SQL2NormalizedArtifacts,
    SQL2NormalizedChannel,
    SQL2NormalizedGroup,
    SQL2Normalizer,
)
from .optimize import SQL2ProgramOptimizer
from .table_shape import (
    SQL2ColumnShape,
    SQL2TableShape,
    SQL2TableShapeSidecar,
    build_sql2_table_shape_sidecar,
)

SQLCompiler = SQL2Compiler
SQLModelAnalyzer = SQL2ModelAnalyzer
ExecutionPlan = SQL2ExecutionPlan
ExecutionStep = SQL2ExecutionStep

__all__ = [
    "ExecutionPlan",
    "ExecutionStep",
    "ColumnInfo",
    "ModelAnalysis",
    "SQL2AggregateInstance",
    "SQL2AggregateShape",
    "SQL2Analysis",
    "SQL2CoalescedArtifacts",
    "SQL2CoalescedGroup",
    "SQL2Coalescer",
    "SQL2ColumnShape",
    "SQL2Compiler",
    "SQL2EdgeType",
    "SQL2FragmentPlan",
    "SQL2FragmentProjectionAssemblyPlan",
    "SQL2FragmentProjectionJoinGroup",
    "SQL2FragmentProjectionOutputColumn",
    "SQL2FragmentProjectionSourceGroup",
    "SQL2FragmentProjectionSpec",
    "SQL2GraphArtifacts",
    "SQL2GraphEdge",
    "SQL2GraphNode",
    "SQL2ModelAnalyzer",
    "SQL2NonStratifiableGraphError",
    "SQL2NormalizedArtifacts",
    "SQL2NormalizedChannel",
    "SQL2NormalizedGroup",
    "SQL2Normalizer",
    "SQL2ProgramOptimizer",
    "SQL2TableShape",
    "SQL2TableShapeSidecar",
    "SQL2WriteChannel",
    "SQLCompiler",
    "SQLModelAnalyzer",
    "TableInfo",
    "TableKind",
    "build_sql2_table_shape_sidecar",
    "determine_tables",
]
