"""
Paths library for relationalai.semantics.experimental.
"""

from relationalai.semantics.experimental.paths.core import hello as hello
