"""
Core functionality for the paths library.
"""


def hello() -> str:
    """Return a hello greeting."""
    return "Hello from paths!"
