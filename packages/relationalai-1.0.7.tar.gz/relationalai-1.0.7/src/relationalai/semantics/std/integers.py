"""
Integer manipulation functions.

.. deprecated:: 0.13.0
   This module is deprecated. Use `std.numbers` instead.

This module provides functions for working with integers including type coercion
and parsing from strings.
"""
from __future__ import annotations

from ..frontend.base import Expression, Variable
from ..frontend.core import Integer
from relationalai.util.docutils import include_in_docs

from . import StringValue, IntegerValue, numbers, _deprecated_library

__include_in_docs__ = True


@include_in_docs
def int64(value: IntegerValue) -> Variable:
    """
    Coerce a number to Int64.

    .. deprecated:: 0.13.0
       Use `std.numbers` functions instead.

    Parameters
    ----------
    value: IntegerValue
        The integer value to coerce.

    Returns
    -------
    Variable
        A Variable representing the Int64 value.
    """
    _warning()
    return Integer(value)

@include_in_docs
def int128(value: IntegerValue) -> Variable:
    """
    Coerce a number to Int128.

    .. deprecated:: 0.13.0
       Use `std.numbers` functions instead.

    Parameters
    ----------
    value: IntegerValue
        The integer value to coerce.

    Returns
    -------
    Variable
        A Variable representing the Int128 value.
    """
    _warning()
    return Integer(value)

@include_in_docs
def parse_int64(value: StringValue) -> Expression:
    """
    Parse a string into an Int64.

    .. deprecated:: 0.13.0
       Use `numbers.parse_number(value, 19, 0) <std.numbers.parse_number>` instead.

    Parameters
    ----------
    value: StringValue
        The string value to parse.

    Returns
    -------
    Expression
        An Expression computing the parsed Int64.
    """
    _warning(f"numbers.parse_number({value}, 19, 0)")
    return numbers.parse_number(value, 19, 0)

@include_in_docs
def parse_int128(value: StringValue) -> Expression:
    """
    Parse a string into an Int128.

    .. deprecated:: 0.13.0
       Use `numbers.parse_number(value, 38, 0) <std.numbers.parse_number>` instead.

    Parameters
    ----------
    value: StringValue
        The string value to parse.

    Returns
    -------
    Expression
        An Expression computing the parsed Int128.
    """
    _warning(f"numbers.parse_number({value}, 38, 0)")
    return numbers.parse_number(value, 38, 0)

@include_in_docs
def parse(value: StringValue) -> Expression:
    """
    Parse a string into an Int128 (alias for parse_int128).

    .. deprecated:: 0.13.0
       Use `numbers.parse_number(value, 38, 0) <std.numbers.parse_number>` instead.

    Parameters
    ----------
    value: StringValue
        The string value to parse.

    Returns
    -------
    Expression
        An Expression computing the parsed Int128.
    """
    return parse_int128(value)


#--------------------------------------------------
# Implementation
#--------------------------------------------------

def _warning(msg: str|None = None):
    _deprecated_library("std.integers", "std.numbers", msg)
