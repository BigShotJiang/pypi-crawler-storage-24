"""
RelationalAI Graph Library
"""

__version__ = "0.1.0"
# Mark this package's docstrings for inclusion
# in automatically generated web documentation.
__include_in_docs__ = True

from .core import Graph


# Finally make this package's core functionality publicly available.
__all__ = [
    "Graph",
]
