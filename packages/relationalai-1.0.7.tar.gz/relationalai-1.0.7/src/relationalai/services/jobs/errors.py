from __future__ import annotations

from relationalai.client.errors.exceptions import (
    ClientError,
    ClientInvalidRequestError,
    ClientNotFoundError,
    ClientNotReadyError,
    ClientServerError,
    ClientTimeoutError,
    ClientUnknownError,
)
from relationalai.client.errors.handlers import ErrorHandlerChain as ClientErrorHandlerChain


class JobError(ClientError):
    """Base error for jobs operations."""


class JobInvalidRequestError(ClientInvalidRequestError, JobError):
    """Raised when a Jobs API request is invalid."""


class JobCapabilityError(ClientInvalidRequestError, JobError):
    """Raised when an operation is not supported by the configured backend/capabilities."""


class JobConfigurationError(ClientInvalidRequestError, JobError):
    """Raised when the client/configuration is missing required setup for an operation."""


class JobNotFoundError(ClientNotFoundError, JobError):
    """Raised when a job is not found."""


class JobNotReadyError(ClientNotReadyError, JobError):
    """Raised when a job result/operation is not ready yet."""


class JobTimeoutError(ClientTimeoutError, JobError):
    """Raised when waiting for a job exceeds the deadline."""


class JobServerError(ClientServerError, JobError):
    """Raised when the backend fails processing a job request."""


class JobClientDisconnectedError(JobServerError):
    """Raised when a LOGIC transaction is aborted because the client disconnected."""

    def __init__(self) -> None:
        super().__init__(
            "\n".join(
                [
                    "The client disconnected before the operation could complete.",
                    "",
                    "This may occur due to network issues or if the client application was terminated unexpectedly.",
                    "Please ensure a stable connection and try again.",
                ]
            )
        )


class JobUnknownError(ClientUnknownError, JobError):
    """Raised for unexpected job failures."""


class ErrorHandlerChain(ClientErrorHandlerChain):
    """Jobs error handler chain.

    Currently uses the base client error mappings.
    Service-specific mappings can be added here later (similar to reasoners).
    """

    pass


__all__ = [
    "JobError",
    "JobInvalidRequestError",
    "JobCapabilityError",
    "JobConfigurationError",
    "JobClientDisconnectedError",
    "JobNotFoundError",
    "JobNotReadyError",
    "JobTimeoutError",
    "JobServerError",
    "JobUnknownError",
    "ErrorHandlerChain",
]

