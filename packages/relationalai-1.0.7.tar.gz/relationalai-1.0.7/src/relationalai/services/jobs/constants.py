from __future__ import annotations

from relationalai.services.constants import DEFAULT_EXPERIMENTAL_SCHEMA

DEFAULT_JOBS_SCHEMA = DEFAULT_EXPERIMENTAL_SCHEMA

# Direct Access API base path for jobs endpoints.
JOBS_DA_BASE_PATH = "/v1alpha1/jobs"

# Direct Access API base path for transaction endpoints (LOGIC jobs).
TRANSACTIONS_DA_BASE_PATH = "/v1alpha1/transactions"

JOB_ACTIVE_STATES = {"CREATED", "RUNNING", "PENDING"}
JOB_TERMINAL_STATES = {"COMPLETED", "FAILED", "CANCELED", "ABORTED"}

# Polling interval guardrail for `client.jobs.wait(...)`.
# Keep strictly >= 20s to ensure bounded responsiveness.
MAX_POLL_INTERVAL_S = 20.0

# Canonical job type discriminators used by the Jobs gateway (SQL + Direct Access).
# - LOGIC maps to transactions (surfaced through the jobs facade)
# - SOLVER maps to prescriptive jobs
# - ML maps to predictive jobs
JOB_TYPES = {"LOGIC", "SOLVER", "ML"}

__all__ = [
    "DEFAULT_JOBS_SCHEMA",
    "JOBS_DA_BASE_PATH",
    "TRANSACTIONS_DA_BASE_PATH",
    "JOB_ACTIVE_STATES",
    "JOB_TERMINAL_STATES",
    "MAX_POLL_INTERVAL_S",
    "JOB_TYPES",
]

