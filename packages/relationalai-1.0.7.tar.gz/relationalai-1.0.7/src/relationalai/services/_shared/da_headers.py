from __future__ import annotations

from typing import TYPE_CHECKING

from relationalai import __version__

if TYPE_CHECKING:
    from relationalai.config.config import Config


def mk_da_headers(cfg: "Config", *, gi_setup_skipped: bool) -> dict[str, str]:
    """Build stable Direct Access headers shared across SDK layers.

    Keep this consistent between:
    - high-level exec orchestration
    - jobs/transactions gateways
    """
    return {
        "Content-Type": "application/json",
        "gi_setup_skipped": str(gi_setup_skipped),
        "X-Enable-Guard-Rails": str(cfg.jobs.enable_guard_rails),
        "user-agent": f"pyrel/{__version__}",
        "Accept": "application/json",
    }


__all__ = ["mk_da_headers"]

