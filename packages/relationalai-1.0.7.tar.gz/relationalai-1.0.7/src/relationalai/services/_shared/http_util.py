from __future__ import annotations

from urllib.parse import quote, urlencode


def build_url(
    base_url: str,
    endpoint: str,
    *,
    path_params: dict[str, str] | None = None,
    query_params: dict[str, str] | None = None,
) -> str:
    """Build an endpoint URL with escaped path/query params."""
    url = f"{base_url}{endpoint}"
    if path_params:
        escaped = {k: quote(v, safe="") for k, v in path_params.items()}
        url = url.format(**escaped)
    if query_params:
        url += "?" + urlencode(query_params)
    return url


__all__ = ["build_url"]

