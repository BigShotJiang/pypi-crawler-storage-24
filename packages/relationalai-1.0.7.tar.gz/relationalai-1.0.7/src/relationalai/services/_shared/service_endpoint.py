from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from relationalai.client.transports.sql import SqlClient
from relationalai.services._shared.sql_rows import row_first_value, row_get, row_to_mapping
from relationalai.util.persistent_kv import PersistentKeyValueFile

SERVICE_ENDPOINT_CACHE_ENV_VAR = "RAI_ENDPOINT_FILE"
DEFAULT_SERVICE_ENDPOINT_CACHE_PATH = Path(os.path.expanduser("~/.rai/endpoints.json"))


def is_snowflake_notebook() -> bool:
    """Return whether we are running inside a Snowflake Notebook.

    Upstream distinguishes notebook vs local to choose http vs https and the
    boolean parameter passed to `app.service_endpoint(...)`. This repo does not
    have a reliable runtime signal for Snowflake Notebooks, so we conservatively
    treat all environments as non-notebook.
    """
    return False


def default_service_endpoint_cache_path() -> Path:
    return Path(os.environ.get(SERVICE_ENDPOINT_CACHE_ENV_VAR, str(DEFAULT_SERVICE_ENDPOINT_CACHE_PATH)))


def _quote_snowflake_identifier_path(name: str) -> str:
    # Normalize dotted app/object names into Snowflake-safe SQL identifiers while
    # preserving already-quoted or simple uppercase identifiers as-is.
    parts = [part.strip() for part in str(name or "").split(".") if part.strip()]
    quoted: list[str] = []
    for part in parts:
        if part.startswith('"') and part.endswith('"') and len(part) >= 2:
            quoted.append(part)
        elif part.replace("_", "").isalnum() and (part[0].isalpha() or part[0] == "_") and part.upper() == part:
            quoted.append(part)
        else:
            escaped = part.replace('"', '""')
            quoted.append(f'"{escaped}"')
    return ".".join(quoted)


class ServiceEndpointCache(PersistentKeyValueFile):
    """Persistent + in-memory cache for SPCS service endpoints."""

    def __init__(self, path: Path | None = None):
        super().__init__(path or default_service_endpoint_cache_path())

    def get(self, key: str, default: Any = None) -> Any:
        v = super().get(key, default)
        if isinstance(v, str) and v.strip():
            return v.strip()
        return default

    def set(self, key: str, value: str) -> None:
        v = (value or "").strip()
        if not v:
            return
        super().set(key, v)


def _extract_service_endpoint_host(row: Any) -> str | None:
    """Extract the service endpoint host from a Snowpark `CALL ...` result row.

    Snowpark returns `Row` objects for `.collect()`, but some integration layers
    (tests/mocks) may return plain dicts/tuples. Be liberal in what we accept.
    """
    v = row_get(row, "SERVICE_ENDPOINT", "service_endpoint", "Service_Endpoint", "serviceendpoint")
    if isinstance(v, str) and v.strip():
        return v.strip()
    if not row_to_mapping(row):
        v0 = row_first_value(row)
        if isinstance(v0, str) and v0.strip():
            return v0.strip()
    return None


def resolve_service_endpoint(
    *,
    sql: SqlClient,
    account: str,
    app_name: str,
    cache: ServiceEndpointCache | None = None,
    enforce_update: bool = False,
) -> str:
    """Resolve the Direct Access base URL for a Snowflake SPCS service.

    Matches upstream behavior:
    - Calls `CALL <app>.app.service_endpoint(<bool>)`
    - Uses `https://` for local execution, `http://` for notebook execution.
    - Caches results keyed by (account, app_name).
    """
    acct = (account or "").strip()
    app = (app_name or "").strip()
    if not acct or not app:
        raise ValueError("resolve_service_endpoint requires non-empty account and app_name.")

    cache = cache or ServiceEndpointCache()
    notebook = is_snowflake_notebook()
    # Upstream: `CALL <app>.app.service_endpoint(not is_snowflake_notebook);`
    external = not notebook
    key = f"{acct}.{app}.service_endpoint.external={'true' if external else 'false'}"
    if not enforce_update:
        cached = cache.get(key) if cache else None
        if cached:
            return cached

    arg = "TRUE" if external else "FALSE"
    stmt = f"CALL {_quote_snowflake_identifier_path(app)}.app.service_endpoint({arg});"
    rows = sql.collect(stmt, operation="service_endpoint", meta={"app": app, "account": acct})
    if not rows:
        raise RuntimeError(f"Could not retrieve service endpoint for app {app!r}.")

    row0 = rows[0]
    host = _extract_service_endpoint_host(row0)
    if not host:
        raise RuntimeError("Service endpoint result missing SERVICE_ENDPOINT field.")

    host_str = str(host).strip()
    if "://" in host_str:
        base = host_str
    else:
        base = f"{'http' if notebook else 'https'}://{host_str}"
    if cache:
        cache.set(key, base)
    return base


__all__ = ["ServiceEndpointCache", "resolve_service_endpoint", "is_snowflake_notebook"]
