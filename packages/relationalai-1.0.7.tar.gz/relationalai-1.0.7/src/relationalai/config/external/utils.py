import os


def find_dbt_profiles_file() -> str | None:
    paths = [
        "./profiles.yml",
        os.path.expanduser("~/.dbt/profiles.yml"),
    ]
    for path in paths:
        if os.path.exists(path):
            return path
    return None


def find_snowflake_config_file() -> str | None:
    path = os.path.expanduser("~/.snowflake/config.toml")
    if os.path.exists(path):
        return path
    return None


def find_raiconfig_toml_file() -> str | None:
    """
    Find raiconfig.toml file.

    Search order:
    1. Current directory upwards (project-level)
    2. ~/.rai/raiconfig.toml (user-level)

    Returns:
        Path to raiconfig.toml if found, None otherwise.
    """
    # Search upwards from current directory
    current_dir = os.path.abspath(os.getcwd())
    while True:
        file_path = os.path.join(current_dir, "raiconfig.toml")
        if os.path.exists(file_path):
            return file_path

        parent_dir = os.path.dirname(current_dir)
        if parent_dir == current_dir:  # Reached root
            break
        current_dir = parent_dir

    # Check user home directory
    user_config_path = os.path.expanduser("~/.rai/raiconfig.toml")
    if os.path.exists(user_config_path):
        return user_config_path

    return None
