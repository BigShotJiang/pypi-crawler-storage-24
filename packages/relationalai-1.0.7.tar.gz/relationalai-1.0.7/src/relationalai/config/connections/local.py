"""Internal-only local server connection configuration."""

from __future__ import annotations

from typing import Literal, TYPE_CHECKING
from pydantic import Field

if TYPE_CHECKING:
    import requests

from ...util.docutils import include_in_docs
from .base import BaseConnection

__include_in_docs__ = True


@include_in_docs
class LocalConnection(BaseConnection):
    """Internal-only connection to a local RAI server.

    Not intended for end users.
    """

    type: Literal["local"] = "local"

    host: str = Field(default="localhost", description="Local server host")
    port: int = Field(default=8010, description="Local server port")

    def get_session(self) -> requests.Session:
        """Return a requests.Session instance for the local server."""
        # Should we migrate to using LocalClient to PyRel V1?
        from v0.relationalai.clients.local import LocalClient  # type: ignore[import-not-found]

        if self._cached_session is None:
            self._cached_session = LocalClient(host=self.host, port=self.port).http_session

        return self._cached_session
