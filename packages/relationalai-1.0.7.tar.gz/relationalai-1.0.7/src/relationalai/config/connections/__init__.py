"""Connection configuration classes.

This package contains the connection configuration types used by the
:class:`relationalai.config.create_config` factory function. They are implemented as
Pydantic models, so connection configs (provided as dicts or as class instances)
are validated and converted into typed connection objects.

When you call :func:`~relationalai.config.create_config` without any arguments,
it tries to load configuration from config files (YAML/JSON) or other sources
and parse them into these connection config models. You can also create connection
configs programmatically by instantiating these models directly and passing
them to :func:`~relationalai.config.create_config` as part of the ``connections`` dict argument.

The key connection types exported here are:

- Snowflake authenticators (e.g. :class:`~relationalai.config.connections.snowflake.UsernamePasswordAuth`)
- :class:`~relationalai.config.connections.duckdb.DuckDBConnection`
"""

from __future__ import annotations

from typing import Annotated, Union
from pydantic import Field

from .base import BaseConnection
from .snowflake import (
    UsernamePasswordAuth,
    UsernamePasswordMFAAuth,
    ExternalBrowserAuth,
    JWTAuth,
    OAuthAuth,
    ProgrammaticAccessTokenAuth,
    SnowflakeConnection,
    SnowflakeAuthenticator,
)
from .duckdb import DuckDBConnection
from .local import LocalConnection

__include_in_docs__ = True

ConnectionConfig = Annotated[
    Union[SnowflakeAuthenticator, DuckDBConnection, LocalConnection],
    Field(discriminator="type"),
]
"""Top-level connection configuration type.

`ConnectionConfig` is a discriminated union used when parsing a config file.
The concrete model is selected from the ``type`` field (for example, a
Snowflake authenticator, a DuckDB connection, or a local RAI server).
"""

__all__ = [
    "BaseConnection",
    "UsernamePasswordAuth",
    "UsernamePasswordMFAAuth",
    "ExternalBrowserAuth",
    "JWTAuth",
    "OAuthAuth",
    "ProgrammaticAccessTokenAuth",
    "SnowflakeConnection",
    "DuckDBConnection",
    "LocalConnection",
    "ConnectionConfig",
]
