"""
CuiLian -- Agent refinement engine. Temper your AI through a thousand trials.
"""
__version__ = "0.0.1"
