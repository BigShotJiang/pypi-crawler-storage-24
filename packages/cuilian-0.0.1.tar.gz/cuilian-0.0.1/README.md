# cuilian

> CuiLian -- Agent refinement engine. Temper your AI through a thousand trials.

Part of the [TianGong](https://github.com/JinNing6/TianGong) ecosystem.

## Status

Planning -- This package is under active development. Stay tuned!

## License

MIT
