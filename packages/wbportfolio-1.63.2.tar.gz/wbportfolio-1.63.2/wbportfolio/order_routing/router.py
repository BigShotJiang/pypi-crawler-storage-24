from django.conf import settings

from wbportfolio.order_routing.adapters.base import BaseCustodianAdapter
from wbportfolio.order_routing.model import ExecutionStatus, Order, RebalancingResponse


class Router:
    def __init__(self, adapter: BaseCustodianAdapter):
        self.adapter = adapter

    @property
    def submit_as_draft(self):
        return getattr(settings, "DEBUG", True) or getattr(settings, "ORDER_ROUTING_AS_DRAFT", True)

    def submit_rebalancing(self, orders: list[Order]) -> RebalancingResponse:
        """
        Submit a rebalance order for the certificate.
        """
        items = [self.adapter.serialize_order(order) for order in orders]
        raw_items, message, execution_kwargs = self.adapter.submit_rebalancing(items, as_draft=self.submit_as_draft)
        status = ExecutionStatus.IN_DRAFT if self.submit_as_draft else ExecutionStatus.PENDING
        return RebalancingResponse(
            orders=[self.adapter.deserialize_item(item) for item in raw_items],
            message=message,
            execution_kwargs=execution_kwargs,
            status=status,
        )

    def get_rebalance_status(self) -> tuple[ExecutionStatus, str]:
        return self.adapter.get_rebalance_status()

    def cancel_rebalancing(self) -> bool:
        return self.adapter.cancel_current_rebalancing()

    def get_current_rebalancing_request(self) -> list[Order]:
        items = self.adapter.get_current_rebalancing()
        return self.adapter.deserialize_items(items)
