from .adapter import CustodianAdapter
