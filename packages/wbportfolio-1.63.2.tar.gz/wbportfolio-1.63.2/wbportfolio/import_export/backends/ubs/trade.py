import json
from datetime import date, datetime
from io import BytesIO
from typing import Optional

from django.db import models
from pandas.tseries.offsets import BDay
from wbcore.contrib.io.backends import AbstractDataBackend, register

from wbportfolio.api_clients.ubs import UBSNeoAPIClient

from ..mixin import BankDataBackendMixin


@register("Trade", provider_key="ubs", save_data_in_import_source=True, passive_only=True)
class DataBackend(BankDataBackendMixin, AbstractDataBackend):
    def __init__(
        self, import_credential: Optional[models.Model] = None, bank: Optional[models.Model] = None, **kwargs
    ):
        if not bank:
            raise ValueError("The ubs company objects needs to be passed to this backend")
        self.bank = bank
        if not import_credential or not import_credential.authentication_token:
            raise ValueError("UBS backend needs a valid import credential object")
        self.authentication_token = import_credential.authentication_token.replace("Bearer ", "")
        self.token_expiry_date = import_credential.validity_end

    def get_files(
        self,
        execution_time: datetime,
        start: date = None,
        obj_external_ids: list[str] = None,
        **kwargs,
    ) -> BytesIO:
        if not start:
            start = (execution_time - BDay(2)).date()
        end = execution_time.date()
        if obj_external_ids:
            client = UBSNeoAPIClient(self.authentication_token, self.token_expiry_date)
            for external_id in obj_external_ids:
                res_json = client.validate_response(
                    client.get_rebalance_reports(external_id, from_date=start, to_date=end)
                )
                if res_json:
                    content_file = BytesIO()
                    content_file.write(json.dumps(res_json).encode())
                    file_name = f"ubs_trades_{external_id}_{start:%Y-%m-%d}-{end:%Y-%m-%d}_{datetime.timestamp(execution_time)}.json"
                    yield file_name, content_file
