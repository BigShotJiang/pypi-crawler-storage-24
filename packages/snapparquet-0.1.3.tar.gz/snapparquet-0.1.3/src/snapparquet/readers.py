"""
Fast reads: column pruning, optional integer-column range filters, PyArrow predicate
pushdown, unified multi-file scans, and optional parallel per-file reads.
"""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional, Sequence, Tuple, Union

import pandas as pd

from snapparquet.schema import column_is_integer_type, intersect_columns, norm_col

PathLike = Union[str, Path]


def _arrow_table_to_pandas(table) -> pd.DataFrame:
    """Convert Arrow table to pandas with multi-threaded decode when supported."""
    try:
        return table.to_pandas(
            split_blocks=True,
            use_threads=True,
            self_destruct=True,
        )
    except TypeError:
        try:
            return table.to_pandas(split_blocks=True, use_threads=True)
        except TypeError:
            try:
                return table.to_pandas(use_threads=True)
            except TypeError:
                return table.to_pandas()


def _filter_dataframe_range(
    df: pd.DataFrame,
    column: str,
    low: int,
    high: int,
) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return df
    col = norm_col(column)
    if col not in df.columns:
        return df
    v = pd.to_numeric(df[col], errors="coerce")
    return df[(v >= low) & (v <= high)].copy()


def _ensure_filter_column_in_list(
    columns: Optional[List[str]], filter_column: str
) -> Optional[List[str]]:
    if columns is None:
        return None
    fc = norm_col(filter_column)
    if fc in columns:
        return columns
    out = list(columns)
    out.append(fc)
    return out


def _paths_are_all_parquet(paths: Sequence[str]) -> bool:
    for p in paths:
        low = str(p).strip().lower().rstrip("/")
        if not low.endswith(".parquet"):
            return False
    return bool(paths)


def _try_read_parquet_unified(
    paths: Sequence[str],
    *,
    columns: Optional[Sequence[str]],
    filter_column: Optional[str],
    range_start: Optional[int],
    range_end: Optional[int],
    use_pushdown: bool,
) -> Optional[pd.DataFrame]:
    """
    Single pyarrow.dataset scan over many Parquet files (or directories).
    Returns None on failure so callers can fall back to per-file reads.
    """
    plist = [str(p).strip() for p in paths if str(p).strip()]
    if not plist or not _paths_are_all_parquet(plist):
        return None
    try:
        import pyarrow.dataset as ds
    except Exception:
        return None

    cols = list(columns) if columns is not None else None
    lo = int(range_start) if range_start is not None else None
    hi = int(range_end) if range_end is not None else None
    range_ok = lo is not None and hi is not None and filter_column is not None
    fc = norm_col(filter_column) if filter_column else None

    if range_ok and fc:
        cols = _ensure_filter_column_in_list(cols, fc)

    use_filt = (
        bool(use_pushdown)
        and range_ok
        and fc is not None
        and (cols is None or fc in cols)
        and column_is_integer_type(plist[0], fc)
    )
    flt = None
    if use_filt:
        try:
            fld = ds.field(fc)
            flt = (fld >= lo) & (fld <= hi)
        except Exception:
            use_filt = False

    try:
        dataset = ds.dataset(plist, format="parquet")
        table = dataset.to_table(columns=cols, filter=flt)
        return _arrow_table_to_pandas(table)
    except Exception:
        return None


def _default_io_workers(num_paths: int) -> int:
    if num_paths <= 2:
        return 1
    cpu = os.cpu_count() or 4
    return min(16, num_paths, max(4, cpu * 2))


def read_parquet(
    path: PathLike,
    *,
    columns: Optional[Sequence[str]] = None,
    filter_column: Optional[str] = None,
    range_start: Optional[int] = None,
    range_end: Optional[int] = None,
    use_pushdown: bool = True,
) -> pd.DataFrame:
    """
    Read a Parquet file into a pandas DataFrame.

    * **Column pruning** — pass ``columns`` to decode only those fields.
    * **Range filter** — ``filter_column`` + ``range_start`` / ``range_end`` (inclusive).
      When the filter column is integer-typed in the file, uses ``pyarrow.dataset``
      predicate pushdown when possible; otherwise filters in pandas after read.
    * If *columns* is set but omits *filter_column*, the filter column is appended
      for the read so filtering can run.
    * Arrow → pandas uses threaded conversion when the installed PyArrow supports it.
    """
    p = str(path).strip()
    cols = list(columns) if columns is not None else None
    lo = int(range_start) if range_start is not None else None
    hi = int(range_end) if range_end is not None else None
    range_ok = lo is not None and hi is not None and filter_column is not None
    fc = norm_col(filter_column) if filter_column else None

    if range_ok and fc:
        cols = _ensure_filter_column_in_list(cols, fc)

    use_ds = (
        bool(use_pushdown)
        and range_ok
        and fc is not None
        and (cols is None or fc in cols)
        and column_is_integer_type(p, fc)
    )

    if use_ds:
        try:
            import pyarrow.dataset as ds

            fld = ds.field(fc)
            flt = (fld >= lo) & (fld <= hi)
            dataset = ds.dataset(p, format="parquet")
            table = dataset.to_table(columns=cols, filter=flt)
            return _arrow_table_to_pandas(table)
        except Exception:
            pass

    try:
        if cols is not None:
            df = pd.read_parquet(p, columns=cols)
            if range_ok and fc:
                df = _filter_dataframe_range(df, fc, lo, hi)
            return df
    except Exception:
        pass

    df = pd.read_parquet(p)
    if range_ok and fc:
        df = _filter_dataframe_range(df, fc, lo, hi)
    return df


def read_csv(
    path: PathLike,
    *,
    columns: Optional[Sequence[str]] = None,
    filter_column: Optional[str] = None,
    range_start: Optional[int] = None,
    range_end: Optional[int] = None,
) -> pd.DataFrame:
    """Read CSV with optional ``usecols`` and the same range filter semantics as Parquet."""
    p = str(path).strip()
    cols = list(columns) if columns else None
    if cols:
        try:
            df = pd.read_csv(p, usecols=cols)
        except (ValueError, KeyError, TypeError):
            df = pd.read_csv(p)
    else:
        df = pd.read_csv(p)

    lo = int(range_start) if range_start is not None else None
    hi = int(range_end) if range_end is not None else None
    if (
        filter_column is not None
        and lo is not None
        and hi is not None
    ):
        df = _filter_dataframe_range(df, norm_col(filter_column), lo, hi)
    return df


def read_tabular(
    path: PathLike,
    *,
    columns: Optional[Sequence[str]] = None,
    filter_column: Optional[str] = None,
    range_start: Optional[int] = None,
    range_end: Optional[int] = None,
    use_pushdown: bool = True,
    full_read_if_no_column_match: bool = True,
) -> pd.DataFrame:
    """
    Read ``.parquet`` or ``.csv`` from *path* (case-insensitive suffix).

    If *columns* is set, Parquet reads intersect file schema with *columns*; CSV reads
    header and uses overlapping names. When intersection is empty and
    *full_read_if_no_column_match* is True, reads all columns (then applies range filter).
    """
    p = str(path).strip()
    low = p.lower()

    if low.endswith(".parquet"):
        sub: Optional[List[str]] = None
        if columns is not None:
            sub = intersect_columns(p, columns)
            if sub is not None and len(sub) == 0 and full_read_if_no_column_match:
                sub = None
            elif sub is not None and len(sub) == 0:
                return pd.DataFrame()

        return read_parquet(
            p,
            columns=sub,
            filter_column=filter_column,
            range_start=range_start,
            range_end=range_end,
            use_pushdown=use_pushdown,
        )

    if low.endswith(".csv"):
        sub: Optional[List[str]] = None
        if columns is not None:
            try:
                h = pd.read_csv(p, nrows=0)
                cn = {norm_col(c) for c in h.columns}
                sub = [norm_col(c) for c in columns if norm_col(c) in cn]
            except Exception:
                sub = None
            if sub is not None and len(sub) == 0 and full_read_if_no_column_match:
                sub = None
            elif sub is not None and len(sub) == 0:
                return pd.DataFrame()
        return read_csv(
            p,
            columns=sub,
            filter_column=filter_column,
            range_start=range_start,
            range_end=range_end,
        )

    raise ValueError(
        "snapparquet.read_tabular: path must end with .parquet or .csv, got {!r}".format(
            p
        )
    )


def read_tabular_many(
    paths: Sequence[PathLike],
    *,
    columns: Optional[Sequence[str]] = None,
    filter_column: Optional[str] = None,
    range_start: Optional[int] = None,
    range_end: Optional[int] = None,
    use_pushdown: bool = True,
    ignore_errors: bool = False,
    unified_parquet: bool = True,
    parallel_workers: Optional[int] = None,
    full_read_if_no_column_match: bool = True,
) -> pd.DataFrame:
    """
    Read multiple ``.parquet`` / ``.csv`` paths and concatenate.

    * **unified_parquet** (default True): when all paths are Parquet, try one
      ``pyarrow.dataset`` scan over the whole list (often faster than opening each
      file separately; better pushdown across fragments). Falls back automatically.
    * **parallel_workers**: ``None`` = auto (parallel I/O when there are several paths),
      ``0`` or ``1`` = strict sequential single-threaded per file, or set an int cap.
    """
    raw_list = [str(raw).strip() for raw in paths if str(raw).strip()]
    if not raw_list:
        return pd.DataFrame()

    pq_only = _paths_are_all_parquet(raw_list)

    if unified_parquet and pq_only and len(raw_list) >= 1:
        uni = _try_read_parquet_unified(
            raw_list,
            columns=columns,
            filter_column=filter_column,
            range_start=range_start,
            range_end=range_end,
            use_pushdown=use_pushdown,
        )
        if uni is not None:
            return uni

    workers = parallel_workers
    if workers is None:
        workers = _default_io_workers(len(raw_list))
    else:
        workers = max(0, int(workers))

    def _one(idx_p: Tuple[int, str]) -> Tuple[int, pd.DataFrame]:
        i, p = idx_p
        df = read_tabular(
            p,
            columns=columns,
            filter_column=filter_column,
            range_start=range_start,
            range_end=range_end,
            use_pushdown=use_pushdown,
            full_read_if_no_column_match=full_read_if_no_column_match,
        )
        return i, df

    indexed = list(enumerate(raw_list))
    parts_ordered: List[Optional[pd.DataFrame]] = [None] * len(raw_list)

    if workers <= 1 or len(raw_list) == 1:
        for i, p in indexed:
            try:
                _, df = _one((i, p))
                parts_ordered[i] = df
            except Exception:
                if ignore_errors:
                    parts_ordered[i] = pd.DataFrame()
                else:
                    raise
    else:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(_one, ip): ip[0] for ip in indexed}
            for fut in as_completed(futures):
                i = futures[fut]
                try:
                    _, df = fut.result()
                    parts_ordered[i] = df
                except Exception:
                    if ignore_errors:
                        parts_ordered[i] = pd.DataFrame()
                    else:
                        raise

    merged = [df for df in parts_ordered if df is not None and len(df) > 0]
    if not merged:
        return pd.DataFrame()
    return pd.concat(merged, ignore_index=True)


def read_parquet_many(
    paths: Sequence[PathLike],
    **kwargs,
) -> pd.DataFrame:
    """Same as :func:`read_tabular_many` (name emphasizes Parquet-only workflows)."""
    return read_tabular_many(paths, **kwargs)
