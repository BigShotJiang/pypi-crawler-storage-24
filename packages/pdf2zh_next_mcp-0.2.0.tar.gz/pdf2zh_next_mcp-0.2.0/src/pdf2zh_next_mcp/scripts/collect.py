#!/usr/bin/env python3
"""Pass 1 스크립트: pdf2zh-next CLITranslator에서 호출됨.

stdin으로 세그먼트 텍스트를 받아 JSON 파일에 누적 저장하고,
stdout으로 원문을 그대로 반환한다.

Usage: echo "text" | python collect.py /tmp/session/segments.json
"""

import json
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("Usage: python collect.py <segments_json_path>", file=sys.stderr)
        sys.exit(1)

    segments_file = Path(sys.argv[1])
    text = sys.stdin.read()

    # 기존 세그먼트 로드 또는 빈 배열
    if segments_file.exists():
        segments = json.loads(segments_file.read_text(encoding="utf-8"))
    else:
        segments_file.parent.mkdir(parents=True, exist_ok=True)
        segments = []

    segments.append(text)
    segments_file.write_text(json.dumps(segments, ensure_ascii=False), encoding="utf-8")

    # 원문 그대로 반환 (Pass 1 출력물은 버림)
    print(text, end="")


if __name__ == "__main__":
    main()
