#!/usr/bin/env python3
"""Pass 2 스크립트: pdf2zh-next CLITranslator에서 호출됨.

stdin으로 세그먼트 텍스트를 받아 translations.json에서 조회하고,
stdout으로 번역문을 반환한다. 매칭 실패 시 원문 반환.

Usage: echo "text" | python lookup.py /tmp/session/translations.json
"""

import json
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("Usage: python lookup.py <translations_json_path>", file=sys.stderr)
        sys.exit(1)

    translations_file = Path(sys.argv[1])
    text = sys.stdin.read()

    if not translations_file.exists():
        print(text, end="")
        return

    translations = json.loads(translations_file.read_text(encoding="utf-8"))
    result = translations.get(text, text)
    print(result, end="")


if __name__ == "__main__":
    main()
