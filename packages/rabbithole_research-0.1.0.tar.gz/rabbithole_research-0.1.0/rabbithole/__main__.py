"""Module entrypoint for `python -m rabbithole`."""

from .cli import main


if __name__ == "__main__":
    main()
