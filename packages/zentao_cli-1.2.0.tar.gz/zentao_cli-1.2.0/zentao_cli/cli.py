"""禅道 CLI 核心实现"""

import argparse
import getpass
import json
import os
import sys
import logging
from datetime import date, datetime, timedelta
from io import StringIO
from pathlib import Path
import csv

import httpx

logging.basicConfig(level=logging.WARNING, format="%(message)s")
logger = logging.getLogger("zentao-cli")

CONFIG_PATH = Path.home() / ".config" / "zentao" / "config.json"


def load_config():
    """加载配置：环境变量 > 配置文件"""
    file_cfg = {}
    if CONFIG_PATH.exists():
        try:
            file_cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass

    def get(env_key, file_key=None):
        return os.environ.get(env_key, "") or file_cfg.get(file_key or env_key.lower(), "")

    return {
        "host": get("ZENTAO_HOST", "host").rstrip("/"),
        "account": get("ZENTAO_ACCOUNT", "account"),
        "password": get("ZENTAO_PASSWORD", "password"),
        "execution": get("ZENTAO_DEFAULT_EXECUTION_NAME", "execution"),
        "assignee": get("ZENTAO_DEFAULT_ASSIGNEE", "assignee"),
        "task_type": get("ZENTAO_DEFAULT_TASK_TYPE", "task_type") or "devel",
    }


# ─── 全局状态 ───
_cfg = {}
_token = None
_client = None


def get_client():
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.Client(timeout=30.0, verify=False)
    return _client


def api_base():
    return f"{_cfg['host']}/api.php/v1"


def login():
    global _token
    resp = get_client().post(
        f"{api_base()}/tokens",
        json={"account": _cfg["account"], "password": _cfg["password"]},
    )
    data = resp.json()
    _token = data.get("token")
    if not _token:
        print(f"错误: 登录失败 - {data}", file=sys.stderr)
        sys.exit(1)
    return _token


def api(method, endpoint, **kwargs):
    global _token
    if not _token:
        login()
    url = f"{api_base()}/{endpoint.lstrip('/')}"
    headers = kwargs.pop("headers", {})
    headers["Token"] = _token
    resp = get_client().request(method, url, headers=headers, **kwargs)
    if resp.status_code == 401:
        login()
        headers["Token"] = _token
        resp = get_client().request(method, url, headers=headers, **kwargs)
    if resp.status_code >= 400:
        print(f"错误: API {resp.status_code} - {resp.text[:300]}", file=sys.stderr)
        sys.exit(1)
    if not resp.text or resp.headers.get("content-length") == "0":
        return {}
    try:
        return resp.json()
    except Exception:
        return {}


_exec_cache = {}


def find_execution_id(name):
    if name in _exec_cache:
        return _exec_cache[name]
    data = api("GET", "executions?status=all&limit=1000")
    for ex in data.get("executions", []):
        if ex["name"] == name:
            _exec_cache[name] = ex["id"]
            return ex["id"]
    print(f"错误: 未找到执行 '{name}'", file=sys.stderr)
    sys.exit(1)


def check_config():
    """检查必要配置是否存在"""
    if not _cfg.get("host") or not _cfg.get("account") or not _cfg.get("password"):
        print("错误: 未配置禅道连接信息，请先运行 zentao setup", file=sys.stderr)
        sys.exit(1)


# ─── setup 命令 ───

def cmd_setup(args):
    """交互式配置禅道连接"""
    existing = {}
    if CONFIG_PATH.exists():
        try:
            existing = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass

    def prompt(label, key, secret=False):
        default = existing.get(key, "")
        hint = f" [{default}]" if default and not secret else ""
        hint = f" [****]" if default and secret else hint
        if secret:
            val = getpass.getpass(f"{label}{hint}: ")
        else:
            val = input(f"{label}{hint}: ")
        return val.strip() or default

    print("禅道 CLI 配置\n")
    host = prompt("禅道地址 (如 https://zentao.example.com)", "host")
    account = prompt("账号", "account")
    password = prompt("密码", "password", secret=True)
    execution = prompt("默认执行名称 (如 运维)", "execution")
    assignee = prompt("默认指派人 (留空则同账号)", "assignee")

    cfg = {
        "host": host.rstrip("/"),
        "account": account,
        "password": password,
        "execution": execution,
        "assignee": assignee or account,
        "task_type": existing.get("task_type", "devel"),
    }

    # 验证连接
    print("\n验证连接...", end=" ")
    try:
        client = httpx.Client(timeout=15.0, verify=False)
        resp = client.post(
            f"{cfg['host']}/api.php/v1/tokens",
            json={"account": cfg["account"], "password": cfg["password"]},
        )
        data = resp.json()
        if not data.get("token"):
            print(f"失败\n错误: {data}", file=sys.stderr)
            sys.exit(1)
        print("成功 ✓")
        client.close()
    except Exception as e:
        print(f"失败\n错误: {e}", file=sys.stderr)
        sys.exit(1)

    # 保存
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    CONFIG_PATH.chmod(0o600)
    print(f"\n配置已保存到 {CONFIG_PATH}")

    # 自动安装 OpenClaw Skill
    skill_dir = Path.home() / ".openclaw" / "skills" / "zentao-task-manager"
    skill_src = Path(__file__).parent / "SKILL.md"
    if skill_src.exists():
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(skill_src.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"OpenClaw Skill 已安装到 {skill_dir}")

    print("现在可以使用 zentao list 查询任务了")


# ─── 业务子命令 ───

def cmd_list(args):
    check_config()
    exec_name = args.execution or _cfg["execution"]
    exec_id = find_execution_id(exec_name)
    assigned = args.assigned_to or _cfg["account"]
    params = [f"limit=1000", f"assignedTo={assigned}"]
    if args.status:
        params.append(f"status={args.status}")
    data = api("GET", f"executions/{exec_id}/tasks?{'&'.join(params)}")
    tasks = data.get("tasks", [])
    if args.start_date or args.end_date:
        filtered = []
        for t in tasks:
            est = t.get("estStarted") or ""
            dl = t.get("deadline") or ""
            ts = est or dl
            te = dl or est
            if not ts:
                continue
            if args.start_date and te < args.start_date:
                continue
            if args.end_date and ts > args.end_date:
                continue
            filtered.append(t)
        tasks = filtered
    if not tasks:
        print("没有找到任务")
        return
    status_map = {"wait": "未开始", "doing": "进行中", "done": "已完成", "closed": "已关闭", "cancel": "已取消", "pause": "已暂停"}
    if args.json:
        print(json.dumps(tasks, ensure_ascii=False, indent=2))
        return
    print(f"共 {len(tasks)} 个任务:\n")
    for t in tasks:
        who = t.get("assignedTo", "")
        if isinstance(who, dict):
            who = who.get("realname") or who.get("account", "")
        st = status_map.get(t.get("status", ""), t.get("status", ""))
        print(f"- [{t.get('id', '')}] {t.get('name', '')}")
        print(f"  状态: {st} | 负责人: {who} | 时间: {t.get('estStarted', '')} ~ {t.get('deadline', '')}")


def cmd_get(args):
    check_config()
    t = api("GET", f"tasks/{args.task_id}")
    if args.json:
        print(json.dumps(t, ensure_ascii=False, indent=2))
        return
    status_map = {"wait": "未开始", "doing": "进行中", "done": "已完成", "closed": "已关闭", "cancel": "已取消", "pause": "已暂停"}
    who = t.get("assignedTo", "")
    if isinstance(who, dict):
        who = who.get("realname") or who.get("account", "")
    print(f"任务详情:")
    print(f"  ID: {t.get('id', '')}")
    print(f"  名称: {t.get('name', '')}")
    print(f"  状态: {status_map.get(t.get('status', ''), t.get('status', ''))}")
    print(f"  负责人: {who}")
    print(f"  开始日期: {t.get('estStarted', '')}")
    print(f"  截止日期: {t.get('deadline', '')}")
    print(f"  预计工时: {t.get('estimate', 0)} 小时")
    print(f"  已消耗: {t.get('consumed', 0)} 小时")
    if t.get("desc"):
        print(f"\n描述:\n{t['desc']}")


def cmd_create(args):
    check_config()
    exec_id = find_execution_id(_cfg["execution"])
    today = date.today().isoformat()
    assigned = args.assigned_to or _cfg["assignee"] or _cfg["account"]
    desc_parts = [f"【任务描述】\n{args.description}", f"【工作内容】\n{args.work_content}", f"【验收标准】\n{args.acceptance_criteria}"]
    if args.completion_note:
        desc_parts.append(f"【完成说明】\n{args.completion_note}")
    data = {
        "name": args.title, "type": _cfg["task_type"], "assignedTo": assigned,
        "estStarted": args.start_date or today, "deadline": args.end_date or today,
        "desc": "\n\n".join(desc_parts),
    }
    if args.est_hours and args.est_hours > 0:
        data["estimate"] = args.est_hours
    result = api("POST", f"executions/{exec_id}/tasks", json=data)
    task_id = result.get("id", "未知")
    status_text = "未开始"
    if not args.no_auto_finish and task_id != "未知":
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            est = args.est_hours or 0
            left = est if est > 0 else 1
            api("POST", f"tasks/{task_id}/start", json={"assignedTo": assigned, "realStarted": now, "left": left})
            api("POST", f"tasks/{task_id}/finish", json={"assignedTo": assigned, "currentConsumed": est, "realStarted": now, "finishedDate": now})
            status_text = "已完成"
        except Exception as e:
            status_text = f"已创建但自动完成失败: {e}"
    print(f"任务创建成功")
    print(f"  ID: {task_id}")
    print(f"  标题: {args.title}")
    print(f"  执行: {_cfg['execution']}")
    print(f"  负责人: {assigned}")
    print(f"  日期: {data['estStarted']} ~ {data['deadline']}")
    print(f"  状态: {status_text}")


def cmd_edit(args):
    check_config()
    task_id = args.task_id
    results = []
    if args.status:
        assigned = args.assigned_to or _cfg["assignee"] or _cfg["account"]
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if args.status == "doing":
            api("POST", f"tasks/{task_id}/start", json={"assignedTo": assigned, "realStarted": now, "left": args.est_hours or 1})
            results.append("状态 → 进行中")
        elif args.status == "done":
            task_info = api("GET", f"tasks/{task_id}")
            if task_info.get("status") == "wait":
                api("POST", f"tasks/{task_id}/start", json={"assignedTo": assigned, "realStarted": now, "left": 1})
            api("POST", f"tasks/{task_id}/finish", json={"assignedTo": assigned, "currentConsumed": args.est_hours or 0, "realStarted": now, "finishedDate": now})
            results.append("状态 → 已完成")
        elif args.status == "closed":
            api("POST", f"tasks/{task_id}/close", json={})
            results.append("状态 → 已关闭")
    data = {}
    if args.title:
        data["name"] = args.title
    if args.assigned_to:
        data["assignedTo"] = args.assigned_to
    if args.start_date:
        data["estStarted"] = args.start_date
    if args.end_date:
        data["deadline"] = args.end_date
    if args.est_hours is not None:
        data["estimate"] = args.est_hours
    if args.description:
        data["desc"] = args.description
    if data:
        api("PUT", f"tasks/{task_id}", json=data)
        results.append(f"字段更新: {', '.join(f'{k}={v}' for k, v in data.items())}")
    if not results:
        print("没有需要更新的字段")
        return
    print(f"任务更新成功")
    print(f"  ID: {task_id}")
    print(f"  {'; '.join(results)}")


def cmd_delete(args):
    check_config()
    api("DELETE", f"tasks/{args.task_id}")
    print(f"任务删除成功 ID: {args.task_id}")


def cmd_effort(args):
    check_config()
    effort_date = args.date or date.today().isoformat()
    api("POST", f"tasks/{args.task_id}/estimate", json={"consumed": args.hours, "work": args.work, "date": effort_date, "left": 0})
    print(f"工时记录成功")
    print(f"  任务 ID: {args.task_id}")
    print(f"  日期: {effort_date}")
    print(f"  工时: {args.hours} 小时")
    print(f"  内容: {args.work}")


def cmd_report(args):
    check_config()
    assigned = args.assigned_to or _cfg["account"]
    exec_id = find_execution_id(_cfg["execution"])
    data = api("GET", f"executions/{exec_id}/tasks?limit=1000&assignedTo={assigned}")
    tasks = [t for t in data.get("tasks", []) if args.start_date <= (t.get("estStarted") or "") <= args.end_date]
    start_dt = datetime.strptime(args.start_date, "%Y-%m-%d")
    end_dt = datetime.strptime(args.end_date, "%Y-%m-%d")
    wednesdays = []
    cur = start_dt
    while cur <= end_dt:
        if cur.weekday() == 2:
            wednesdays.append(cur.strftime("%Y-%m-%d"))
        cur += timedelta(days=1)
    wed1 = wednesdays[0] if wednesdays else ""
    wed2 = wednesdays[1] if len(wednesdays) > 1 else ""
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow([f"6R报表（{args.start_date} - {args.end_date}）"])
    writer.writerow([])
    writer.writerow(["部门/项目组", "责任人", "目标设定", "禅道链接", "开始日期", "完成日期", "第1个周三", "第2个周三", "主管检查", "完成结果", "上级核实", "未完成复盘"])
    for t in tasks:
        tid = t.get("id", "")
        who = t.get("assignedTo", "")
        if isinstance(who, dict):
            who = who.get("realname") or who.get("account", "")
        done = "Y" if t.get("status") in ("done", "closed") else "N"
        link = f"{_cfg['host']}/execution-task-view-{tid}.html" if tid else ""
        writer.writerow([args.department or "", who, t.get("name", ""), link, t.get("estStarted", ""), t.get("deadline", ""), wed1, wed2, "", done, "", "" if done == "Y" else "待复盘"])
    print(f"6R 报表（{args.start_date} ~ {args.end_date}，{len(tasks)} 个任务）:\n")
    print(output.getvalue())


# ─── 入口 ───

def main():
    global _cfg
    _cfg = load_config()

    parser = argparse.ArgumentParser(prog="zentao", description="禅道任务管理 CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup", help="配置禅道连接信息")

    p = sub.add_parser("list", help="查询任务列表")
    p.add_argument("--execution", help="执行名称")
    p.add_argument("--assigned-to", help="指派人")
    p.add_argument("--status", choices=["wait", "doing", "done", "closed"], help="状态筛选")
    p.add_argument("--start-date", help="开始日期 YYYY-MM-DD")
    p.add_argument("--end-date", help="结束日期 YYYY-MM-DD")
    p.add_argument("--json", action="store_true", help="JSON 输出")

    p = sub.add_parser("get", help="获取任务详情")
    p.add_argument("task_id", type=int, help="任务 ID")
    p.add_argument("--json", action="store_true", help="JSON 输出")

    p = sub.add_parser("create", help="创建任务")
    p.add_argument("--title", required=True, help="任务标题")
    p.add_argument("--description", required=True, help="任务描述")
    p.add_argument("--work-content", required=True, help="工作内容")
    p.add_argument("--acceptance-criteria", required=True, help="验收标准")
    p.add_argument("--completion-note", help="完成说明")
    p.add_argument("--est-hours", type=float, default=0, help="预计工时")
    p.add_argument("--start-date", help="开始日期")
    p.add_argument("--end-date", help="结束日期")
    p.add_argument("--assigned-to", help="指派给谁")
    p.add_argument("--no-auto-finish", action="store_true", help="不自动完成")

    p = sub.add_parser("edit", help="编辑任务")
    p.add_argument("task_id", type=int, help="任务 ID")
    p.add_argument("--title", help="标题")
    p.add_argument("--description", help="描述")
    p.add_argument("--assigned-to", help="指派给谁")
    p.add_argument("--start-date", help="开始日期")
    p.add_argument("--end-date", help="截止日期")
    p.add_argument("--est-hours", type=float, help="预计工时")
    p.add_argument("--status", choices=["wait", "doing", "done", "closed"], help="状态")

    p = sub.add_parser("delete", help="删除任务")
    p.add_argument("task_id", type=int, help="任务 ID")

    p = sub.add_parser("effort", help="记录工时")
    p.add_argument("task_id", type=int, help="任务 ID")
    p.add_argument("--hours", type=float, required=True, help="工时")
    p.add_argument("--work", required=True, help="工作内容")
    p.add_argument("--date", help="日期 YYYY-MM-DD")

    p = sub.add_parser("report", help="生成6R报表")
    p.add_argument("--start-date", required=True, help="开始日期")
    p.add_argument("--end-date", required=True, help="结束日期")
    p.add_argument("--assigned-to", help="指派人")
    p.add_argument("--department", help="部门名称")

    args = parser.parse_args()
    handlers = {
        "setup": cmd_setup, "list": cmd_list, "get": cmd_get, "create": cmd_create,
        "edit": cmd_edit, "delete": cmd_delete, "effort": cmd_effort, "report": cmd_report,
    }
    handlers[args.command](args)
