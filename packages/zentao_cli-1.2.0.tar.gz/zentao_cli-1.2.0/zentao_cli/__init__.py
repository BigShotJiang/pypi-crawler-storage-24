"""禅道 CLI - 任务管理、工时记录、6R报表"""

__version__ = "1.2.0"

from zentao_cli.cli import main

__all__ = ["main"]
