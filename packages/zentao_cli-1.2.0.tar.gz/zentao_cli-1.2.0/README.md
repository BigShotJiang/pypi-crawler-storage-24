# zentao-cli

禅道项目管理 CLI 工具，支持任务查询、创建、编辑、工时记录和 6R 报表生成。

可独立使用，也可作为 [OpenClaw](https://docs.openclaw.ai) Skill 集成到 AI agent 中。

## 安装

```bash
pip install zentao-cli
```

或通过 `pipx` / `uvx` 一次性运行：

```bash
uvx zentao-cli list --status done
```

## 配置

首次使用，运行交互式配置：

```bash
zentao setup
```

按提示输入禅道地址、账号、密码、默认执行名称即可。配置保存在 `~/.config/zentao/config.json`（权限 600）。

也可以通过环境变量配置（优先级高于配置文件，适合 CI/容器场景）：

```bash
export ZENTAO_HOST="https://zentao.example.com"
export ZENTAO_ACCOUNT="your_account"
export ZENTAO_PASSWORD="your_password"
export ZENTAO_DEFAULT_EXECUTION_NAME="运维"
```

## 使用

```bash
# 查询任务
zentao list
zentao list --status done
zentao list --start-date 2026-03-01 --end-date 2026-03-31
zentao list --json

# 任务详情
zentao get 123

# 创建任务（自动完成）
zentao create \
  --title "修复 Nginx 配置" \
  --description "生产环境配置错误" \
  --work-content "排查并修复 upstream 配置" \
  --acceptance-criteria "服务正常转发"

# 编辑任务
zentao edit 123 --status done
zentao edit 123 --title "新标题" --assigned-to someone

# 删除任务
zentao delete 123

# 记录工时
zentao effort 123 --hours 2 --work "排查并修复配置"

# 生成 6R 报表
zentao report --start-date 2026-03-01 --end-date 2026-03-15
```

## OpenClaw 集成

安装 CLI 并配置后，将 `SKILL.md` 复制到 OpenClaw skills 目录即可：

```bash
pip install zentao-cli
zentao setup
mkdir -p ~/.openclaw/skills/zentao-task-manager
cp SKILL.md ~/.openclaw/skills/zentao-task-manager/
```

重启 gateway 即可使用。无需在 `openclaw.json` 中配置环境变量，CLI 会自动读取 `~/.config/zentao/config.json`。

## License

MIT
