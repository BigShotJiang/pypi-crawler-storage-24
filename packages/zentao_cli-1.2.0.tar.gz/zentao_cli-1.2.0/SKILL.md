---
name: zentao-task-manager
description: 禅道项目管理 - 通过 zentao CLI 创建任务、记录工时、查询任务、生成6R报表
version: 2.1.0
homepage: https://pypi.org/project/zentao-cli/
metadata:
  {
    "openclaw":
      {
        "emoji": "📋",
        "requires": { "bins": ["zentao"] },
        "primaryEnv": "ZENTAO_HOST",
        "install":
          [
            {
              "id": "uv",
              "kind": "uv",
              "package": "zentao-cli",
              "bins": ["zentao"],
              "label": "Install zentao-cli (uv/pip)",
            },
          ],
      },
  }
---

# 禅道任务管理 Skill

通过 `zentao` CLI 连接禅道项目管理系统，支持任务全生命周期管理和工时记录。

## CLI 用法

所有操作通过 `zentao` 命令完成。环境变量已预配置，直接调用即可。

### 查询任务

```bash
# 查询所有任务
zentao list

# 按状态筛选
zentao list --status done
zentao list --status doing

# 按日期范围
zentao list --start-date 2026-03-01 --end-date 2026-03-31

# JSON 输出（适合程序处理）
zentao list --json
```

### 获取任务详情

```bash
zentao get 123
zentao get 123 --json
```

### 创建任务

将用户口语化描述整理为结构化格式后调用：

```bash
zentao create \
  --title "修复 Nginx 反向代理配置异常" \
  --description "生产环境 Nginx 配置错误导致请求转发失败" \
  --work-content "排查配置文件，修复 upstream 指向，重载并验证" \
  --acceptance-criteria "配置语法检查通过，服务请求转发正常"
```

可选参数：
- `--est-hours 2` — 预计工时
- `--start-date 2026-03-23` — 开始日期（默认今天）
- `--end-date 2026-03-23` — 结束日期（默认今天）
- `--assigned-to someone` — 指派给谁（默认当前用户）
- `--completion-note "已验证通过"` — 完成说明
- `--no-auto-finish` — 不自动完成（默认会自动完成任务）

### 编辑任务

```bash
# 修改标题
zentao edit 123 --title "新标题"

# 完成任务
zentao edit 123 --status done

# 修改多个字段
zentao edit 123 --assigned-to someone --end-date 2026-03-25
```

### 删除任务

```bash
zentao delete 123
```

### 记录工时

```bash
zentao effort 123 --hours 2 --work "排查并修复配置问题"
zentao effort 123 --hours 1.5 --work "代码审查" --date 2026-03-22
```

### 生成 6R 报表

```bash
zentao report --start-date 2026-03-01 --end-date 2026-03-15
zentao report --start-date 2026-03-01 --end-date 2026-03-15 --department "信息中心"
```

## 创建任务的整理原则

当用户要求创建禅道任务时，将口语化描述整理为结构化格式：

1. 语言专业、克制、偏事实描述，不使用口语
2. 明确区分：任务标题 / 任务描述 / 工作内容 / 验收标准 / 完成说明
3. 描述聚焦"做了什么 + 交付了什么"，避免空话
4. 不主动扩大范围，不替用户承诺时间或结果
5. 默认场景为企业运维/研发协作环境
6. 不指定日期默认使用今天

示例：用户说"帮我记一下今天修了 nginx 配置"，整理为：
- 标题：修复 Nginx 反向代理配置异常
- 描述：生产环境 Nginx 配置错误导致请求转发失败
- 工作内容：排查配置文件，修复 upstream 指向，重载并验证
- 验收标准：配置语法检查通过，服务请求转发正常
