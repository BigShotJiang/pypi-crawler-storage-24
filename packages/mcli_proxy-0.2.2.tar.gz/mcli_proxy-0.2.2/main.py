import os
from pathlib import Path

import httpx
import yaml
from fastapi import FastAPI, Request, Response, BackgroundTasks
from fastapi.responses import StreamingResponse

app = FastAPI(title="Anthropic API Proxy")

TARGET_BASE_URL = "https://mcli.sankuai.com"
CONFIG_PATH = Path.home() / ".config/mcopilot-cli/.config.yaml"


def get_api_key() -> str:
    # 1. 优先检查环境变量
        token = os.environ.get("MCTOKEN")
        if token:
            return token

        # 2. 回退到 YAML 配置文件
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
            return config.get("AUTHORIZATION", "") if config else ""
        except FileNotFoundError:
            return ""
        except yaml.YAMLError:
            return ""


def get_working_dir() -> str:
    """获取当前用户目录"""
    return str(Path.home())


@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "PATCH"])
async def proxy(request: Request, path: str):
    """代理所有请求到目标 API，自动添加必要的 headers"""

    # 构建目标 URL
    target_url = f"{TARGET_BASE_URL}/{path}"
    if request.query_params:
        target_url = f"{target_url}?{request.query_params}"

    # 准备 headers
    headers = dict(request.headers)

    # 移除 host 头，让 httpx 自动设置
    headers.pop("host", None)
    headers.pop("authorization", None)

    # 添加必要的认证 headers
    headers["x-api-key"] = get_api_key()
    headers["x-working-dir"] = get_working_dir()

    # 读取请求体
    body = await request.body()

    # 创建异步客户端
    client = httpx.AsyncClient(timeout=300.0, follow_redirects=True)

    try:
        # 构建请求并流式发送
        req = client.build_request(
            method=request.method,
            url=target_url,
            headers=headers,
            content=body,
        )
        response = await client.send(req, stream=True)

        # 直接流式返回，让字节第一时间传递给客户端
        background = BackgroundTasks()
        background.add_task(client.aclose)
        return StreamingResponse(
            content=response.aiter_raw(),
            status_code=response.status_code,
            headers=dict(response.headers),
            background=background,
        )

    except httpx.RequestError as e:
        await client.aclose()
        return Response(
            content=f'{{"error": "Proxy request failed: {str(e)}"}}'.encode(),
            status_code=502,
            media_type="application/json",
        )


def main():
    """CLI entry point for mcli"""
    import uvicorn

    print(f"Config path: {CONFIG_PATH}")
    print(f"Working dir: {get_working_dir()}")
    print(f"API Key loaded: {get_api_key()[:8]}...")
    print("\nStarting proxy server at http://localhost:2819")
    print("Use: curl http://localhost:2819/v1/messages -H 'Content-Type: application/json' -d '{...}'")

    uvicorn.run(app, host="127.0.0.1", port=2819)


if __name__ == "__main__":
    main()
