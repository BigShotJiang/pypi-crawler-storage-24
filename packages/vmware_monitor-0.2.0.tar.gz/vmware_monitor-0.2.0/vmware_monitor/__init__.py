"""VMware Monitor - Read-only vCenter/ESXi monitoring. No destructive operations."""

__version__ = "0.2.0"
