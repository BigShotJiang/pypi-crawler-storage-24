"""mlw: A grammar of machine learning. https://epagogy.ai"""

__version__ = "0.0.1"
