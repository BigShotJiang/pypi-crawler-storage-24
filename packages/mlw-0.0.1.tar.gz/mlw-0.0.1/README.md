# mlw

A grammar of machine learning. Split, fit, evaluate, assess.

Python, R, and Julia. Same Rust engine, same result.

https://epagogy.ai
