"""
Módulo Principal - PTEST
==============================================================================

Este arquivo inicializa a interface gráfica (GUI) do programa PTEST e gerencia
o fluxo de trabalho entre o usuário e a automação do sistema SIAFE.

Funcionalidades Principais:
    - Interface Gráfica moderna usando `customtkinter`.
    - Sistema de Login com validação de CPF.
    - Menu Principal para escolha de contabilização.
    - Orquestração da automação Selenium via classe `Siafe` (biblioteca externa).

"""
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import SessionNotCreatedException
from selenium.common.exceptions import InvalidSessionIdException
from tkinter import Menu, messagebox
import customtkinter as ctk
from pathlib import Path
from PIL import Image
import pandas as pd
import threading
import sqlite3
import time
import sys
import os

diretorio_atual = os.path.dirname(os.path.abspath(__file__))
diretorio_pai = os.path.dirname(diretorio_atual)
sys.path.append(diretorio_pai)

from siafelibrary import Siafe

# Configuração Global
ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("dark-blue")

PROJECT_BASE_PATH = Path(__file__).parent

class PTESTApp(ctk.CTk, Siafe):
    """
    Classe principal da aplicação PTEST.
    Gerencia a interface gráfica, navegação entre telas e threads de execução.
    """
    def __init__(self):
        """
        Inicializa a aplicação PTEST.

        Configura:
        - Caminhos de arquivos (ícones, banco de dados, manual).
        - Geometria e aparência da janela principal.
        - Variáveis de estado e dicionários de mapeamento contábil (`_inicializar_dicionarios`).
        - Renderiza a tela inicial de Login.
        """
        super().__init__()
        
        self.siafeVersao = 2  # Versão do SIAFE a ser utilizada (1 para SIAFE-Rio2 ou 2 para SIAFE-Rio2 BETA)
        
        # --- Paths ---
        self.DBPath = PROJECT_BASE_PATH / "base de dados/base.db"
        self.IconPath = PROJECT_BASE_PATH / "img/icon.ico"
        self.ImagePath = PROJECT_BASE_PATH / "img/tesouro.png"
        self.VoltarPath = PROJECT_BASE_PATH / "img/voltar.png"
        self.ManualPath = PROJECT_BASE_PATH / "Manual de Uso.pdf"
        
        # --- Configuração da Janela ---
        self.title(f"Contabilizações - SiafeLibrary v{self.siafeVersao}")
        self.geometry("500x650")
        self.resizable(False, False)
        self.configure(fg_color="white")
        
        # --- Posicionamento ---
        ws = self.winfo_screenwidth()
        hs = self.winfo_screenheight()
        x = (ws/2) - (500/2)
        y = (hs/2) - (650/2)
        self.geometry('%dx%d+%d+%d' % (500, 650, x, y))

        # --- Variáveis de Estado ---
        self.siafe = Siafe()
        self.usuario_siafe = ""
        self.senha_siafe = ""
        self.stop_event = False
        self.opcao_selecionada = None

        # --- Inicializa Dicionários para Contabilização ---
        self._inicializar_dicionarios()

        # --- Fontes ---
        self.font_header = ctk.CTkFont(family="Roboto", size=24, weight="bold")
        self.font_bold = ctk.CTkFont(family="Roboto", size=14, weight="bold")
        self.font_label = ctk.CTkFont(family="Roboto", size=14, weight="normal")

        # --- Container Principal ---
        self.main_container = ctk.CTkFrame(self, fg_color="transparent")
        self.main_container.pack(fill="both", expand=True, padx=20, pady=20)

        # Inicia na tela de Login
        self.show_login_frame()

    def clear_frame(self):
        """
        Remove todos os widgets presentes no container principal.
        Utilizado para limpar a tela antes de transitar entre Login, Menu e Execução.
        """
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def adicionar_btn_voltar(self, comando):
        """
        Adiciona um botão de "Voltar" (ícone de seta) no canto superior esquerdo da tela.

        Args:
            comando (callable): A função a ser executada ao clicar no botão.
        """
        if self.VoltarPath.exists():
            img_pil = Image.open(self.VoltarPath)
            ctk_img = ctk.CTkImage(img_pil, size=(30, 30))
            btn = ctk.CTkButton(self.main_container, image=ctk_img, text="", width=10, 
                                fg_color="#ffffff", hover_color="#eeeeee", command=comando)
            btn.place(x=0, y=0)
            
    def cancelar_e_voltar(self):
        """
        Interrompe a execução atual e retorna ao menu principal.

        Ações:
        1. Define `self.stop_event = True` para sinalizar a parada das threads.
        2. Tenta fechar o driver se estiver aberto.
        3. Retorna para a tela de configuração.
        """
        self.stop_event = True
        try: 
            if self.driver: self.siafe.fechar_driver()
        except: pass
        self.show_config_frame()
        
    def _create_main_menu(self):
        """
        Cria e configura a barra de menu superior e os atalhos de teclado.

        Atalhos definidos:
        - F1: Sobre.
        - F2: Manual de Uso.
        """
        menu_bar = Menu(self.main_container)
        self.configure(menu=menu_bar)
        menu_bar.add_cascade(label="Sobre (F1)", command=self.mostrar_sobre)
        self.bind("<F1>", lambda event: self.mostrar_sobre())
        menu_bar.add_cascade(label="Manual de Uso (F2)", command=self.mostrar_manual)
        self.bind("<F2>", lambda event: self.mostrar_manual())
        
    def mostrar_sobre(self):
        """
        Exibe uma caixa de diálogo com informações sobre a versão e autoria do software.
        """
        msg = "Programa PTEST\nVersão: 1.0.0 \nDesenvolvido por: EOP / SUPCONC"
        self.messagebox_info("Sobre", msg)

    def mostrar_manual(self):
        """
        Tenta abrir o arquivo PDF do Manual de Uso utilizando o visualizador padrão do sistema operacional (`os.startfile`).
        Exibe erro caso o arquivo não seja encontrado.
        """
        try: os.startfile(self.ManualPath)
        except: self.messagebox_error("Erro", "Manual não encontrado.")
        
    # =========================================================================
    # VALIDAÇÃO
    # =========================================================================
    def limitar_caracteres(self, P):
        """
        Validador para o campo de entrada de usuário.

        Args:
            P (str): O texto atual no campo de entrada.

        Returns:
            bool: True se a entrada for numérica e tiver no máximo 11 caracteres (ou vazia),
                  False caso contrário.
        """
        if (P.isdigit() and len(P) <= 11) or P == "":
            return True
        else:
            return False

    def verificar_campos(self, usuario_entry, senha_entry, login_button):
        """
        Monitora os campos de login em tempo real para habilitar/desabilitar o botão.

        Lógica:
            - Usuário deve ter exatamente 11 caracteres.
            - Senha não pode estar vazia.
        
        Args:
            usuario_entry (ctk.CTkEntry): Widget de entrada do usuário.
            senha_entry (ctk.CTkEntry): Widget de entrada da senha.
            login_button (ctk.CTkButton): O botão de login a ser atualizado.
        """
        usuario = usuario_entry.get()
        senha = senha_entry.get()
        is_ctk_button = isinstance(login_button, ctk.CTkButton)
        
        if len(usuario) == 11 and senha.strip():
            if is_ctk_button: login_button.configure(state="normal", fg_color="#1f6aa5")
            else: login_button.config(state="normal")
        else:
            if is_ctk_button: login_button.configure(state="disabled", fg_color="#555555")
            else: login_button.config(state="disabled")

    # =========================================================================
    # TELA 1: LOGIN
    # =========================================================================
    def show_login_frame(self):
        """
        Renderiza a tela de Login, contendo campos para usuário (CPF) e senha, 
        além de vincular a tecla <Return> à função de login.
        """
        self.clear_frame()
        self._create_main_menu()
        
        # Imagem
        if self.ImagePath.exists():
            try:
                pil_image = Image.open(self.ImagePath)
                img_ctk = ctk.CTkImage(pil_image, size=(105, 105))
                ctk.CTkLabel(self.main_container, text="", image=img_ctk).pack(pady=(10, 5))
            except: pass

        ctk.CTkLabel(self.main_container, text=f"SiafeLibrary v{self.siafeVersao}", font=self.font_header).pack(pady=5)
        ctk.CTkLabel(self.main_container, text="⚠️ Faça Login com os dados do Siafe-Rio2. ⚠️", text_color="red", font=("Roboto", 14)).pack(pady=(0, 20))

        # Inputs
        ctk.CTkLabel(self.main_container, text="Usuário (CPF):", font=self.font_label).pack(pady=(5, 0))
        val_cmd = self.register(self.limitar_caracteres)
        self.entry_user = ctk.CTkEntry(self.main_container, width=300, height=40, validate="key", validatecommand=(val_cmd, '%P'))
        self.entry_user.pack(pady=(2, 10))
        
        ctk.CTkLabel(self.main_container, text="Senha:", font=self.font_label).pack(pady=(5, 0))
        self.entry_pass = ctk.CTkEntry(self.main_container, width=300, height=40, show="*")
        self.entry_pass.pack(pady=(2, 20))
        
        # Botão
        self.btn_login = ctk.CTkButton(self.main_container, text="LOGIN", width=300, height=45,
                                       state="disabled", fg_color="#555555", command=self.processar_login)
        self.btn_login.pack(pady=20)
        
        # Footer        
        ctk.CTkLabel(self.main_container, text="EOP / SUPCONC - Tesouro Estadual", 
                     font=("Roboto", 10), text_color="gray").pack(side="bottom", pady=10)
        
        # Binds
        self.entry_user.bind("<KeyRelease>", lambda e: self.verificar_campos(self.entry_user, self.entry_pass, self.btn_login))
        self.entry_pass.bind("<KeyRelease>", lambda e: self.verificar_campos(self.entry_user, self.entry_pass, self.btn_login))
        self.bind('<Return>', lambda event: self.processar_login())

    def processar_login(self):
        """
        Armazena as credenciais inseridas nas variáveis da instância e avança para a tela de configuração.
        Verifica se o botão está ativo antes de prosseguir.
        """
        if self.btn_login.cget("state") == "disabled": return
        user = self.entry_user.get()
        pwd = self.entry_pass.get()
        self.usuario_siafe = user
        self.senha_siafe = pwd
        self.unbind('<Return>')
        self.show_config_frame()

    # =========================================================================
    # TELA 2: MENU PRINCIPAL (CONFIGURAÇÃO)
    # =========================================================================
    def show_config_frame(self):
        """
        Renderiza o Menu Principal com duas áreas de ação:
        2. Contabilização no SIAFE.
        """
        self.clear_frame()
        self._create_main_menu()
        self.adicionar_btn_voltar(self.show_login_frame)

        # Imagem pequena
        if self.ImagePath.exists():
            try:
                img_ctk = ctk.CTkImage(Image.open(self.ImagePath), size=(105, 105))
                ctk.CTkLabel(self.main_container, text="", image=img_ctk).pack(pady=(10, 5))
            except: pass
            
        ctk.CTkLabel(self.main_container, text=f"SiafeLibrary v{self.siafeVersao}", font=self.font_header).pack(pady=(10, 5))
        ctk.CTkLabel(self.main_container, text="Menu Principal", font=self.font_label).pack(pady=(0, 20))

        # --- ÁREA 2: CONTABILIZAÇÃO (SIAFE) ---
        frame_contab = ctk.CTkFrame(self.main_container, fg_color="transparent")
        frame_contab.pack(fill="x", pady=10)
        
        ctk.CTkLabel(frame_contab, text="Tipo de Contabilização:", font=self.font_bold).pack(pady=(5, 5))
        self.combo_opcoes = ctk.CTkComboBox(frame_contab, values=["Guia de Recolhimento (GR)", "PD de Transferência (PD)", "PD Extra-orçamentária (PD)", "Nota de Aplicação e Resgate (NA)", "Nota Patrimonial (NP)"], width=250, height=35)
        self.combo_opcoes.set("Selecione uma opção")
        self.combo_opcoes.pack(pady=5)

        self.btn_contab = ctk.CTkButton(frame_contab, text="CONTABILIZAR", width=250, height=50,
                                        font=self.font_bold, fg_color="#4CAF50", hover_color="#45a049",
                                        command=self.iniciar_execucao)
        self.btn_contab.pack(pady=20)
        
        # Footer        
        ctk.CTkLabel(self.main_container, text="EOP / SUPCONC - Tesouro Estadual", 
                     font=("Roboto", 10), text_color="gray").pack(side="bottom", pady=10)
        
        self.combo_opcoes.configure(command=self.validar_selecao)
        self.btn_contab.configure(state="disabled", fg_color="#555555")

    def validar_selecao(self, choice):
        """
        Callback de seleção de tipo de documento.
        Habilita o botão 'CONTABILIZAR' apenas se uma opção válida for selecionada.
        """
        if choice in ["Guia de Recolhimento (GR)", "PD de Transferência (PD)", "PD Extra-orçamentária (PD)", "Nota de Aplicação e Resgate (NA)", "Nota Patrimonial (NP)"]:
            self.btn_contab.configure(state="normal", fg_color="#4CAF50")
            self.opcao_selecionada = choice
        else:
            self.btn_contab.configure(state="disabled", fg_color="#555555")

    def iniciar_execucao(self):
        """
        Prepara a interface para execução (tela de progresso) e inicia a thread principal de automação (`self.execucao`).
        """
        self.show_execucao_frame()
        self.stop_event = False
        threading.Thread(target=self.execucao, daemon=True).start()
        
    def _finalizar_interface_ui(self, texto_label, titulo_msg=None, texto_msg=None, tipo_msg="info"):
        """
         Helper rodado na thread principal para atualizar a UI ao final do processamento.
        """
        try:
            if not hasattr(self, 'progress') or not self.progress.winfo_exists(): return
            self.label.set(texto_label)
            self.progress.stop()
            self.progress.configure(mode="determinate")
            self.progress.set(1)
        
            if titulo_msg and texto_msg:
                if tipo_msg == "erro":
                    self.messagebox_error(titulo_msg, texto_msg)
                else:
                    self.messagebox_info(titulo_msg, texto_msg)
        except: pass

    # =========================================================================
    # TELA 3: EXECUÇÃO
    # =========================================================================
    def show_execucao_frame(self):
        """
        Renderiza a tela de execução, contendo:
        - Barra de progresso.
        - Caixa de texto para logs em tempo real.
        - Botão de voltar que cancela a operação.
        """
        self.clear_frame()
        self._create_main_menu()
        self.adicionar_btn_voltar(self.cancelar_e_voltar)
        
        self.label = ctk.StringVar(value="Processando... (0%)")

        # Header
        ctk.CTkLabel(self.main_container, textvariable=self.label, font=self.font_header).pack(pady=10)
        self.progress = ctk.CTkProgressBar(self.main_container, width=400, mode="determinate")
        self.progress.pack(pady=10)
        self.progress.set(0)
        
        # Log Box
        self.log_box = ctk.CTkTextbox(self.main_container, width=450, height=350)
        self.log_box.pack(pady=10)
        self.log_box.insert("0.0", ">>> Iniciando processamento...\n")
        
        # Footer
        ctk.CTkLabel(self.main_container, text="EOP / SUPCONC - Tesouro Estadual", 
                     font=("Roboto", 10), text_color="gray").pack(side="bottom", pady=10)

    def log(self, msg):    
        """
        Insere uma mensagem com timestamp na caixa de logs da interface.
        Faz scroll automático para manter a mensagem mais recente visível.
        """    
        if not self.winfo_exists() or not hasattr(self, 'log_box'): return
        
        msg_formatada = f"[{time.strftime('%H:%M:%S')}] {msg}\n"
        
        def inserir_texto():
            if hasattr(self, 'log_box') and self.log_box.winfo_exists():
                try:
                    self.log_box.insert("end", msg_formatada)
                    self.log_box.see("end")
                except: 
                    pass
                    
        self.after(0, inserir_texto)
        
    def messagebox_info(self, title, message):
        """
        Exibe uma caixa de diálogo de Informação, forçando-a a ficar no topo (`topmost`) 
        para não ser escondida pelo navegador ou outras janelas.
        """
        self.attributes('-topmost', True)
        messagebox.showinfo(title, message)
        self.attributes('-topmost', False)
    
    def messagebox_warning(self, title, message):
        """
        Exibe uma caixa de diálogo de Aviso, forçando-a a ficar no topo (`topmost`).
        """
        self.attributes('-topmost', True)
        messagebox.showwarning(title, message)
        self.attributes('-topmost', False)
        
    def messagebox_error(self, title, message):
        """
        Exibe uma caixa de diálogo de Erro, forçando-a a ficar no topo (`topmost`).
        """
        self.attributes('-topmost', True)
        messagebox.showerror(title, message)
        self.attributes('-topmost', False)

    # =========================================================================
    # BACKEND (CONTABILIZAÇÃO)
    # =========================================================================
    def atualizar_banco(self, id, num_documento, tempo_contab=None):
        """
        Callback executado após o sucesso de cada operação no SIAFE.

        Atualiza o registro no banco de dados com:
        - O número do documento gerado (GR ou PD).
        - O usuário que executou a ação.
        - A data e hora da execução.
        - O tempo decorrido na operação.
        
        Também atualiza a barra de progresso na interface gráfica.

        Args:
            id (int): ID do registro no banco de dados.
            num_documento (str): Número do documento gerado pelo SIAFE.
            tempo_contab (float, optional): Tempo decorrido na operação.
        """
        try:
            with sqlite3.connect(self.DBPath) as con:
                cursor = con.cursor()
                query = '''UPDATE contabilizacoes SET num_documento = ?, tempo_contab = ?, usuario = ?, data_hora = ? WHERE id = ?'''
                cursor.execute(query, (num_documento, tempo_contab, os.getlogin(), str(pd.Timestamp.now()), id))
                con.commit()
                
            self.registros_processados += 1
            percentual_inteiro = int((self.registros_processados / self.total_registros) * 100)  
            valor_barra = self.registros_processados / self.total_registros   
            
            def atualizar_progresso():
                if hasattr(self, 'progress') and self.progress.winfo_exists():
                    self.label.set(f"Processando... ({percentual_inteiro}%)")
                    self.progress.set(valor_barra)
                    
            self.after(0, atualizar_progresso)
            
        except Exception as e:
            self.log(f"Erro ao atualizar banco ID {id}: {e}")

    def execucao(self):
        """
        Lógica central de automação (Backend) executada em uma Thread separada.

        Fluxo:
        1.  Conexão e Seleção: Conecta ao `base.db` e seleciona registros pendentes 
            (`num_documento IS NULL`) baseados na opção do usuário (GR).
        2.  Configuração: Seleciona o método de automação correto (`gerar_gr`)
            e o mapa de dicionários correspondente.
        3.  Automação: 
            - Inicia o WebDriver.
            - Realiza login no SIAFE.
            - Itera sobre os registros chamando a função da biblioteca `Siafe`.
        4.  Callback: Utiliza `atualizar_banco` para salvar o número do documento gerado
            assim que cada operação é concluída com sucesso.

        Tratamento de Erros:
        - Captura exceções de sessão do Selenium.
        - Garante o fechamento do driver no bloco `finally`.
        """
        try:
            # 1. Conexão com Banco
            self.log("Verificando banco de dados...")
            if not self.DBPath.exists():
                self.log("ERRO: Banco de dados não encontrado.")
                return

            # 2. Seleção de Dados
            with sqlite3.connect(self.DBPath) as con:
                if "Guia de Recolhimento (GR)" in self.opcao_selecionada:
                    df = pd.read_sql_query("SELECT * FROM contabilizacoes WHERE num_documento IS NULL AND tipo_id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17)", con)
                    dict_map = self.dict_map_gr
                    metodo_siafe = self.siafe.gerar_gr
                    tipo_doc = "Guia de Recolhimento"
                    
                elif "PD de Transferência (PD)" in self.opcao_selecionada:
                    df = pd.read_sql_query("SELECT * FROM contabilizacoes WHERE num_documento IS NULL AND tipo_id IN (18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32)", con)
                    dict_map = self.dict_map_pdt
                    metodo_siafe = self.siafe.gerar_pdt
                    tipo_doc = "PD de Transferência"
                
                elif "PD Extra-orçamentária (PD)" in self.opcao_selecionada:
                    df = pd.read_sql_query("SELECT * FROM contabilizacoes WHERE num_documento IS NULL AND tipo_id IN (33, 34)", con)
                    dict_map = self.dict_map_pde
                    metodo_siafe = self.siafe.gerar_pde
                    tipo_doc = "PD Extra-orçamentária"
                
                elif "Nota de Aplicação e Resgate (NA)" in self.opcao_selecionada:
                    df = pd.read_sql_query("SELECT * FROM contabilizacoes WHERE num_documento IS NULL AND tipo_id IN (35, 36, 37, 38)", con)
                    dict_map = self.dict_map_na
                    metodo_siafe = self.siafe.gerar_na
                    tipo_doc = "Nota de Aplicação e Resgate"  
                
                elif "Nota Patrimonial (NP)" in self.opcao_selecionada:
                    df = pd.read_sql_query("SELECT * FROM contabilizacoes WHERE num_documento IS NULL AND tipo_id IN (39, 40, 41, 42, 43, 44, 45, 46)", con)
                    dict_map = self.dict_map_np
                    metodo_siafe = self.siafe.gerar_np
                    tipo_doc = "Nota Patrimonial"   
                else:
                    self.log("Opção inválida.")
                    return

            if df.empty:
                self.log(f"Nenhum lançamento pendente encontrado para {tipo_doc}.")
                self.after(0, self._finalizar_interface_ui, "Processado... (100%)", "Aviso", "Não há lançamentos pendentes para processar.")
                self.stop_event = True
                return

            self.log(f"{len(df)} registros encontrados.")
            self.total_registros = len(df)
            self.registros_processados = 0
            
            def resetar_progresso():
                if hasattr(self, 'progress') and self.progress.winfo_exists():
                    self.progress.set(0)
            self.after(0, resetar_progresso)

            # 3. Contabilização
            self.siafe.abrir_driver(tempo_wait=20)
            self.log("Iniciando navegador...")
            
            if self.stop_event: return

            self.log("Iniciando Contabilização...")
            if self.siafe.logar_siafe(self.siafeVersao, self.usuario_siafe, self.senha_siafe):
                sucesso = metodo_siafe(df, dict_map, callback_sucesso=self.atualizar_banco)

                if sucesso:
                    self.log(">>> Processo concluído com Sucesso! <<<")
                    self.after(0, self._finalizar_interface_ui, "Processado... (100%)", "Sucesso", f"{tipo_doc} contabilizadas com sucesso!")
            else:
                self.log("Falha no login. Verifique suas credenciais.")
                self.stop_event = True
                self.siafe.fechar_driver()
                self.after(0, lambda: [self._finalizar_interface_ui("Falha no Login"), self.show_login_frame()])
                return

        except (NoSuchElementException, SessionNotCreatedException, InvalidSessionIdException) as e:
            if self.stop_event: return
            self.log(f"Ocorreu um erro crítico com o navegador.\nPor favor, reinicie o programa.")
            raise e

        except Exception as e:
            if self.stop_event: return
            self.log(f"Ocorreu um erro inesperado.")
            self.after(0, self.messagebox_error, "Erro", f"Ocorreu um erro inesperado: {e}")
        
        finally:
            if self.stop_event: return
            self.log("Fechando navegador...")
            if not df.empty:
                self.siafe.fechar_driver()
            self.after(0, self._finalizar_interface_ui, self.label.get())
            self.log("Programa Encerrado...")

    # =========================================================================
    # DADOS ESTRUTURAIS (DICIONÁRIOS)
    # =========================================================================
    def _inicializar_dicionarios(self):
        """
        Define as regras contábeis e códigos utilizados no preenchimento do SIAFE.

        Cria dicionários que mapeiam:
        - Unidade Gestora (UG) e Domicílios Bancários.
        - Fontes de Recursos.
        - Tipos, Itens e Operações Patrimoniais.
        
        Estes dicionários são agrupados em `self.dict_map_gr` 
        para uso dinâmico durante a execução.
        """
        
        self.dictGR_ANP7990 = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916347", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916347", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "704 - Transferência da União Referente a Royalties do Petróleo e Gás Natural", 
            "FonteRJ": "104 - Transferência da União Ref. a Comp. Financ. pela Exploração de Recursos Naturais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (704.104)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "4879 - COTA-PARTE DA COMP. FINANC. DOS ROYALTIES PELA PRODUÇÃO DO PETRÓLEO - ATÉ 5% - PÓS-SAL", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1399990103 - Out Rec Pat - Royalties pela Produção do Petróleo - Até 5%"
            }
        self.dictGR_ANP9478 = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916347", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916347", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "704 - Transferência da União Referente a Royalties do Petróleo e Gás Natural", 
            "FonteRJ": "104 - Transferência da União Ref. a Comp. Financ. pela Exploração de Recursos Naturais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (704.104)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "4881 - ROYALTIES PELA PRODUÇÃO DO PETRÓLEO - EXCEDENTE A 5%", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1399990105 - Out Rec Pat - Royalties pela Produção do Petróleo - Excedente a 5%"
            }
        self.dictGR_PEA = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916347", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916347", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "704 - Transferência da União Referente a Royalties do Petróleo e Gás Natural", 
            "FonteRJ": "104 - Transferência da União Ref. a Comp. Financ. pela Exploração de Recursos Naturais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (704.104)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "5686 - COTA PARTE PART. ESPECIAL EXP. PETR. E GAS NATURAL LEI 9.478/97", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1399990106 - Out Rec Pat - Participação Especial Exploração do Petróleo"
            }
        self.dictGR_FEP = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916347", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916347", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "704 - Transferência da União Referente a Royalties do Petróleo e Gás Natural", 
            "FonteRJ": "104 - Transferência da União Ref. a Comp. Financ. pela Exploração de Recursos Naturais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (704.104)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "5723 - COTA PARTE FUNDO ESPECIAL DO PETROLEO", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1399990107 - Out Rec Pat - Fundo Especial do Petróleo - FEP"
            }
        self.dictGR_FPE = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916339", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916339", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "107 - Recursos não Vinculados de Impostos - Transferência Constitucionais de Impostos", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.107)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "2038 - COTA-PARTE DO FUNDO DE PARTICIPAÇÃO DOS ESTADOS - FPE", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1711500101 - Cota-Parte FPE - Fundo de Participação dos Estados e do DF - Principal"
            }
        self.dictGR_IPI = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916363", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916363", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "107 - Recursos não Vinculados de Impostos - Transferência Constitucionais de Impostos", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.107)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "2040 - COTA-PARTE DO ESTADO - IPI", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1711530101 - Cota-Parte IPI Exportação - Principal - LC 61/89"
            }
        self.dictGR_CFM = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916371", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916371", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "708 - Transferência da União Referente à Compensação Financeira de Recursos Minerais", 
            "FonteRJ": "101 - Transferência da União - Compensação Financeira de Recursos Minerais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (708.101)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "5682 - Cota-Parte da Compensação Financeira de Recursos Minerais", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1344020101 - Compensação Financeira pela Exploração de Recursos Minerais - Principal"
            }
        self.dictGR_CFH = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "291638X", 
            "DomicilioBancarioCompleto": "001 - 2234 - 291638X", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "709 - Transferência da União referente à Compensação Financeira de Recursos Hídricos", 
            "FonteRJ": "101 - Transferência da União - Compensação Financeira de Recursos Hídricos", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (709.101)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "5722 - COTA PARTE DA COMPENSAÇÃO FINANCEIRA RECURSOS HIDRICOS", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1345032101 - Utilização de Recursos Hídricos - Demais Empresas - Principal"
            }
        self.dictGR_CIDE = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916509", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916509", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "750 - Recursos da Contribuição de Intervenção no Domínio Econômico - CIDE", 
            "FonteRJ": "126 - Recursos da Contribuição de Intervenção no Domínio Econômico - CIDE", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (750.126)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "2044 - COTA-PARTE DO ESTADO NA CONTRIBUIÇÃO DE INTERVENÇÃO NO DOMÍNIO ECONÔMICO - CIDE", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1711540101 - Cota-Parte Contribuição de Intervenção no Domínio Econômico - CIDE - Principal"
            }
        self.dictGR_ADO = {
            "TipoDocumento": "Orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916312", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916312", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "501 - Outros Recursos não Vinculados", 
            "FonteRJ": "101 - Outros Recursos não Vinculados - Ordinários Não Provenientes de Impostos-Tesouro", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (501.101)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferências Intergovernamentais Recebidas", 
            "ItemPatrimonial": "2055 - DEMAIS TRANSFERÊNCIAS DA UNIÃO", 
            "OperacaoPatrimonial": "2469 - Reconhecimento, Arrecadação e Recolhimento", 
            "NaturezaReceita": "1719990101 - Outras Transferências da União - Principal"
            }
        self.dictGRSART = {
            "ExtraOrcamentario": True,  
            "TipoDocumento": "Extra-orçamentário",
            "UG": "999900", 
            "DomicilioBancario": "0000000035",
            "DomicilioBancarioCompleto": "237 - 6898 - 0000000035",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "862 - Recursos de Depósitos de Terceiros",
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "4486 - DEPÓSITOS DE TERCEIROS", 
            "OperacaoPatrimonial": "233 - Depósito", 
            "Ano": "2026",
            "TipoCredor": "UG",
            "Credor": "999900",
            }
        self.dictFundoS = {
            "ExtraOrcamentario": False, 
            "TipoDocumento": "Orçamentário",
            "UG": "999900", 
            "DomicilioBancario": "0000000035",
            "DomicilioBancarioCompleto": "237 - 6898 - 0000000035", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Receita de Tributos - IRRF", 
            "ItemPatrimonial": "4776 - IRRF SOBRE OUTROS RENDIMENTOS", 
            "OperacaoPatrimonial": "197 - Reconhecimento, Arrecadação e Recolhimento",
            "NaturezaReceita": "1113034101 - Imposto sobre a Renda - Retido na Fonte - Outros Rendimentos - Principal",
            }
        self.dictGRPDD = {
            "ExtraOrcamentario": True,  
            "TipoDocumento": "Extra-orçamentário",
            "UG": "999900", 
            "DomicilioBancario": "0000000108",
            "DomicilioBancarioCompleto": "237 - 6898 - 0000000108",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "862 - Recursos de Depósitos de Terceiros",
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "5174 - VENCIMENTOS E SALARIOS NAO RECLAMADOS", 
            "OperacaoPatrimonial": "233 - Depósito", 
            "Ano": "2026",
            "TipoCredor": "CG",
            "Credor": "CG0005038"
            }
        self.dictGR30 = {
            "ExtraOrcamentario": True,
            "TipoDocumento": "Extra-orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2919214", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2919214", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Recursos da Lei Complementar nº 151/2015", 
            "ItemPatrimonial": "5659 - RECURSOS DA L.C. 151/2015 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "4896 - Ingresso dos recursos do Fundo de Reserva em conta do Tesouro Estadual", 
            "Credor": "00000000000191"
            }
        self.dictGR70 = {
            "ExtraOrcamentario": True,
            "TipoDocumento": "Extra-orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2919214", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2919214", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Recursos da Lei Complementar nº 151/2015", 
            "ItemPatrimonial": "5659 - RECURSOS DA L.C. 151/2015 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "9547 - Ingresso de recursos LC 151/15 - 70%", 
            "Credor": "CG0005470"
            }
        self.dictGR632 = {
            "ExtraOrcamentario": True,
            "TipoDocumento": "Extra-orçamentário", 
            "UG": "999900", 
            "DomicilioBancario": "2916320", 
            "DomicilioBancarioCompleto": "001 - 2234 - 2916320", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "862 - Recursos de Depósitos de Terceiros", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000028 - LC 151/2015 DECISÃO FAVORÁVEL AO ERJ À CONVERTER EM RECEITA - (862.081)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "4486 - DEPÓSITOS DE TERCEIROS", 
            "OperacaoPatrimonial": "233 - Depósito", 
            "Credor": "CG0014273"
            }
        self.dictResgate = {
            "ExtraOrcamentario": True,
            "TipoDocumento": "Extra-orçamentário", 
            "UG": "999900",
            "DomicilioBancario": "2916320",
            "DomicilioBancarioCompleto": "001 - 2234 - 2916320",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "862 - Recursos de Depósitos de Terceiros",
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)",
            "ItemPatrimonial": "4486 - DEPÓSITOS DE TERCEIROS", 
            "OperacaoPatrimonial": "233 - Depósito",
            "Credor": "CG0012798"
        }
        
        self.dictPD_PASEP_ROYALTIES = {
            "UG": "999900", 
            "UGFavorecida": "370200", 
            "Regularizacao": "OB Regularização Financeira", 
            "JustificativaRegularizacao": "RETENÇÃO-PASEP", 
            "DomicilioBancarioOrigem": "2916347", 
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916347", 
            "DomicilioBancarioDestino": "BCO AUTENT", 
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "704 - Transferência da União Referente a Royalties do Petróleo e Gás Natural", 
            "FonteRJ": "104 - Transferência da União Ref. a Comp. Financ. pela Exploração de Recursos Naturais", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (704.104)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Pagamentos a Regularizar", 
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO", 
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
            }
        self.dictPD_PASEP_FPE = {
            "UG": "999900", 
            "UGFavorecida": "370200",
            "Regularizacao": "OB Regularização Financeira",
            "JustificativaRegularizacao": "RETENÇÃO-PASEP",
            "DomicilioBancarioOrigem": "2916339",
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916339",
            "DomicilioBancarioDestino": "BCO AUTENT",
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT",
            "IEF": "1 - Recursos do Exercício Corrente",
            "Fonte": "500 - Recursos não Vinculados de Impostos",
            "FonteRJ": "107 - Recursos não Vinculados de Impostos - Transferência Constitucionais de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.107)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Pagamentos a Regularizar",
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO",
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        
        self.dictPD_PASEP_IPI = {
            "UG": "999900", 
            "UGFavorecida": "370200", 
            "Regularizacao": "OB Regularização Financeira", 
            "JustificativaRegularizacao": "RETENÇÃO-PASEP", 
            "DomicilioBancarioOrigem": "2916363", 
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916363", 
            "DomicilioBancarioDestino": "BCO AUTENT", 
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "107 - Recursos não Vinculados de Impostos - Transferência Constitucionais de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.107)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Pagamentos a Regularizar", 
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO", 
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        self.dictPD_PASEP_CFM = {
            "UG": "999900",
            "UGFavorecida": "370200",
            "Regularizacao": "OB Regularização Financeira",
            "JustificativaRegularizacao": "RETENÇÃO-PASEP",
            "DomicilioBancarioOrigem": "2916371",
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916371",
            "DomicilioBancarioDestino": "BCO AUTENT",
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT",
            "IEF": "1 - Recursos do Exercício Corrente",
            "Fonte": "708 - Transferência da União Referente à Compensação Financeira de Recursos Minerais",
            "FonteRJ": "101 - Transferência da União - Compensação Financeira de Recursos Minerais",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (708.101)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Pagamentos a Regularizar",
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO",
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        self.dictPD_PASEP_CFH = {
            "UG": "999900",
            "UGFavorecida": "370200",
            "Regularizacao": "OB Regularização Financeira",
            "JustificativaRegularizacao": "RETENÇÃO-PASEP",
            "DomicilioBancarioOrigem": "291638X",
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 291638X",
            "DomicilioBancarioDestino": "BCO AUTENT",
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT",
            "IEF": "1 - Recursos do Exercício Corrente",
            "Fonte": "709 - Transferência da União referente à Compensação Financeira de Recursos Hídricos",
            "FonteRJ": "101 - Transferência da União - Compensação Financeira de Recursos Hídricos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (709.101)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Pagamentos a Regularizar",
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO",
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        self.dictPD_PASEP_CIDE = {
            "UG": "999900",
            "UGFavorecida": "370200",
            "Regularizacao": "OB Regularização Financeira",
            "JustificativaRegularizacao": "RETENÇÃO-PASEP",
            "DomicilioBancarioOrigem": "2916509",
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916509",
            "DomicilioBancarioDestino": "BCO AUTENT",
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT",
            "IEF": "1 - Recursos do Exercício Corrente",
            "Fonte": "750 - Recursos da Contribuição de Intervenção no Domínio Econômico - CIDE",
            "FonteRJ": "126 - Recursos da Contribuição de Intervenção no Domínio Econômico - CIDE",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (750.126)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Pagamentos a Regularizar",
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO",
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        self.dictPD_PASEP_ADO = {
            "UG": "999900",
            "UGFavorecida": "370200",
            "Regularizacao": "OB Regularização Financeira",
            "JustificativaRegularizacao": "RETENÇÃO-PASEP",
            "DomicilioBancarioOrigem": "2916312",
            "DomicilioBancarioOrigemCompleto": "001 - 2234 - 2916312",
            "DomicilioBancarioDestino": "BCO AUTENT",
            "DomicilioBancarioDestinoCompleto": "001 - 2234 - BCO AUTENT",
            "IEF": "1 - Recursos do Exercício Corrente",
            "Fonte": "501 - Outros Recursos não Vinculados",
            "FonteRJ": "101 - Outros Recursos não Vinculados - Ordinários Não Provenientes de Impostos-Tesouro",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (501.101)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Pagamentos a Regularizar",
            "ItemPatrimonial": "5678 - Pagamentos (Por Ofício) a Regularizar - FONTES TESOURO",
            "OperacaoPatrimonial": "4962 - Pagamentos (Por Ofícios) a Regularizar - FONTES TESOURO"
        }
        self.dictPDSART = {
            "UG": "999900", 
            "DomicilioBancarioOrigem": "0000000035", 
            "DomicilioBancarioDestino": "0000000027", 
            "DomicilioBancarioOrigemCompleto": "237 - 6898 - 0000000035", 
            "DomicilioBancarioDestinoCompleto": "237 - 6898 - 0000000027",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "862 - Recursos de Depósitos de Terceiros", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (862.081)",
            "Convenio": "000000 - Convênio não identificado",
            "TipoPatrimonial": "Transferência Financeira entre UG's e na Própria UG", 
            "ItemPatrimonial": "4429 - TRANSFERÊNCIA FINANCEIRA", 
            "OperacaoPatrimonial": "4074 - Transferência financeira entre Contas Bancarias - Na UG"
            }
        self.dictPDFundoS100 = {
            "UG": "999900", 
            "DomicilioBancarioOrigem": "0000000035", 
            "DomicilioBancarioDestino": "0000000027",
            "DomicilioBancarioOrigemCompleto": "237 - 6898 - 0000000035", 
            "DomicilioBancarioDestinoCompleto": "237 - 6898 - 0000000027",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.100)",
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferência Financeira entre UG's e na Própria UG", 
            "ItemPatrimonial": "4429 - TRANSFERÊNCIA FINANCEIRA", 
            "OperacaoPatrimonial": "4074 - Transferência financeira entre Contas Bancarias - Na UG"
            }
        self.dictPDFundoS148 = {
            "UG": "999900", 
            "DomicilioBancarioOrigem": "0000000035", 
            "DomicilioBancarioDestino": "0000000027",
            "DomicilioBancarioOrigemCompleto": "237 - 6898 - 0000000035", 
            "DomicilioBancarioDestinoCompleto": "237 - 6898 - 0000000027",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos", 
            "FonteRJ": "148 - Recurs. não Vinculados de Imp .- Ordinários Proven. de Imp. - Emenda Impositiva", 
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento",
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.148)",
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferência Financeira entre UG's e na Própria UG", 
            "ItemPatrimonial": "4429 - TRANSFERÊNCIA FINANCEIRA", 
            "OperacaoPatrimonial": "4074 - Transferência financeira entre Contas Bancarias - Na UG"
            }
        self.dictPDT = {
            "UG": "999900", 
            "Regularizacao": "OB já encaminhada ao banco", 
            "DomicilioBancarioOrigem": "2919214", 
            "DomicilioBancarioDestino": "2919206", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferência Financeira entre UG's e na Própria UG", 
            "ItemPatrimonial": "4429 - TRANSFERÊNCIA FINANCEIRA", 
            "OperacaoPatrimonial": "9264 - Composição do Fundo de Reserva - LC nº 151/2015 - Depósitos Judiciais Tributários"
            }
        self.dictPDTRecom = {
            "UG": "999900", 
            "Regularizacao": "OB já encaminhada ao banco", 
            "DomicilioBancarioOrigem": "2919214", 
            "DomicilioBancarioDestino": "2919206", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Convenio": "000000 - Convênio não identificado", 
            "TipoPatrimonial": "Transferência Financeira entre UG's e na Própria UG", 
            "ItemPatrimonial": "4429 - TRANSFERÊNCIA FINANCEIRA", 
            "OperacaoPatrimonial": "9286 - Composição do Fundo de Reserva - Saldos anteriores - Lei Complementar nº 151/2015 - Depósi..."
            }
        
        self.dictPDEBaixa = {
            "UG": "999900", 
            "Regularizacao": "OB já encaminhada ao banco", 
            "DomicilioBancarioOrigem": "2919206", 
            "DomicilioBancarioDestino": "001 - 2234 - BCO AUTENT", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Credor": "00000000000191", 
            "TipoPatrimonial": "Recursos da Lei Complementar nº 151/2015", 
            "ItemPatrimonial": "5659 - RECURSOS DA L.C. 151/2015 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "4900 - Baixa de Recursos do Fundo de Reserva por Decisão Desfavorável", 
            "VinculacaoPagamento": "99 - Sem consumo de Limite de Saque"
            }
        self.dictPDEGanho = {
            "UG": "999900", 
            "Regularizacao": "OB já encaminhada ao banco", 
            "DomicilioBancarioOrigem": "2919206", 
            "DomicilioBancarioDestino": "001 - 2234 - BCO AUTENT", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "Credor": "00000000000191", 
            "TipoPatrimonial": "Recursos da Lei Complementar nº 151/2015", 
            "ItemPatrimonial": "5659 - RECURSOS DA L.C. 151/2015 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "4900 - Baixa de Recursos do Fundo de Reserva por Decisão Desfavorável", 
            "VinculacaoPagamento": "91 - DDO"
            }
        
        self.dictNA214 = {
            "UG": "999900", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "6387 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "9548 - Aplicação - Fundo de Investimento - Dep. Jud. 70%", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "DomicilioBancario": "001 - 2234 - 2919214 - ERJ DJT REPASSE (CONTA D)"
            }
        self.dictNAR214 = {
            "UG": "999900", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "6387 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "9550 - Resgate - Fundo de Investimento - Dep. Jud. 70%", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "DomicilioBancario": "001 - 2234 - 2919214 - ERJ DJT REPASSE (CONTA D)"
            }
        self.dictNAR206 = {
            "UG": "999900", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "6387 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "8703 - Resgate - Títulos Públicos", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "DomicilioBancario": "001 - 2234 - 2919206 - SECRETARIA DE ESTADO DE FAZENDA (CONTA D)"
            }
        self.dictNA206 = {
            "UG": "999900", 
            "TipoPatrimonial": "Valores Restituíveis (Cauções e Outros)", 
            "ItemPatrimonial": "6387 - DEPÓSITOS JUDICIAIS TRIBUTÁRIOS", 
            "OperacaoPatrimonial": "8698 - Aplicação - Títulos Públicos", 
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "861 - Recursos Extraorçamentários Vinculados a Depósitos Judiciais", 
            "FonteRJ": "081 - Recursos Não Orçamentários - Depósitos de Diversas Origens", 
            "TipoDetalhamentoFonte": "1 - CADASTRO", 
            "DetalhamentoFonte": "000151 - L.C.151/2015 - FUNDO DE RESERVA - (861.081)", 
            "DomicilioBancario": "001 - 2234 - 2919206 - SECRETARIA DE ESTADO DE FAZENDA (CONTA D)"
            }
        
        self.dictBloqueioCUTE = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "1",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos",
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.100)",
            "DomicilioBancario": "237 - 6898 - 0000000027 (CONTA ÚNICA)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582"
        }
        self.dictDesbloqueioCUTE = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "0",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos",
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.100)",
            "DomicilioBancario": "237 - 6898 - 0000000027 (CONTA ÚNICA)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582 - BLOQUEIOS NÃO IDENTIFICADOS - BRADESCO"
        }
        self.dictBloqueio36617 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "1",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos",
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.100)",
            "DomicilioBancario": "237 - 6898 - 0000036617 (ADMINISTRADA PELO TESOURO)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582"
        }
        self.dictDesbloqueio36617 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "0",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "500 - Recursos não Vinculados de Impostos",
            "FonteRJ": "100 - Recursos não Vinculados de Impostos - Ordinários Provenientes de Impostos",
            "TipoDetalhamentoFonte": "0 - Sem Detalhamento", 
            "DetalhamentoFonte": "000000 - Sem detalhamento - (500.100)",
            "DomicilioBancario": "237 - 6898 - 0000036617 (ADMINISTRADA PELO TESOURO)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582 - BLOQUEIOS NÃO IDENTIFICADOS - BRADESCO"
        }
        self.dictBloqueio7129 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "1",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "754 - Recursos de Operações de Crédito",
            "FonteRJ": "111 - Recursos de Operações de Crédito - Tesouro",
            "TipoDetalhamentoFonte": "3 - OPERAÇÃO DE CRÉDITO", 
            "DetalhamentoFonte": "211025 - PROG EST DE TRANSP II ADICIONAL - PET II ADIC - (754.111)",
            "DomicilioBancario": "237 - 6898 - 0000007129 (CONTA D)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582"
        }
        self.dictDesbloqueio7129 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "0",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "754 - Recursos de Operações de Crédito",
            "FonteRJ": "111 - Recursos de Operações de Crédito - Tesouro",
            "TipoDetalhamentoFonte": "3 - OPERAÇÃO DE CRÉDITO", 
            "DetalhamentoFonte": "211025 - PROG EST DE TRANSP II ADICIONAL - PET II ADIC - (754.111)",
            "DomicilioBancario": "237 - 6898 - 0000007129 (CONTA D)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582 - BLOQUEIOS NÃO IDENTIFICADOS - BRADESCO"
        }
        self.dictBloqueio3093 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "1",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "754 - Recursos de Operações de Crédito",
            "FonteRJ": "111 - Recursos de Operações de Crédito - Tesouro",
            "TipoDetalhamentoFonte": "3 - OPERAÇÃO DE CRÉDITO", 
            "DetalhamentoFonte": "211024 - PSAM - PROG SAN AMB MUN DO ENT BAIA GUANABARA - (754.111)",
            "DomicilioBancario": "237 - 6898 - 0000003093 (CONTA D)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582"
        }
        self.dictDesbloqueio3093 = {
            "UG": "999900", 
            "TipoPatrimonial": "Sentenças Judiciais - Mandados de Sequestro",
            "ItemPatrimonial": "6026 - BLOQUEIO E SEQUESTRO BANCÁRIO EM CONTAS DO TESOURO", 
            "OperacaoPatrimonial": "0",
            "IEF": "1 - Recursos do Exercício Corrente", 
            "Fonte": "754 - Recursos de Operações de Crédito",
            "FonteRJ": "111 - Recursos de Operações de Crédito - Tesouro",
            "TipoDetalhamentoFonte": "3 - OPERAÇÃO DE CRÉDITO", 
            "DetalhamentoFonte": "211024 - PSAM - PROG SAN AMB MUN DO ENT BAIA GUANABARA - (754.111)",
            "DomicilioBancario": "237 - 6898 - 0000003093 (CONTA D)",
            "TipoInscricaoGenerica": "BJ - BLOQUEIO JUDICIAL", 
            "InscricaoGenerica": "BJ0000582 - BLOQUEIOS NÃO IDENTIFICADOS - BRADESCO"
        }

        self.dict_map_gr = {
            1: self.dictGR_ANP7990, 
            2: self.dictGR_ANP9478, 
            3: self.dictGR_PEA, 
            4: self.dictGR_FEP, 
            5: self.dictGR_FPE, 
            6: self.dictGR_IPI, 
            7: self.dictGR_CFM, 
            8: self.dictGR_CFH, 
            9: self.dictGR_CIDE, 
            10: self.dictGR_ADO, 
            11: self.dictGRSART, 
            12: self.dictFundoS, 
            13: self.dictGRPDD,
            14: self.dictGR30,
            15: self.dictGR70,
            16: self.dictGR632,
            17: self.dictResgate
            }
        
        self.dict_map_pdt = {
            18: self.dictPD_PASEP_ROYALTIES,
            19: self.dictPD_PASEP_ROYALTIES,
            20: self.dictPD_PASEP_ROYALTIES,
            21: self.dictPD_PASEP_ROYALTIES,
            22: self.dictPD_PASEP_FPE,
            23: self.dictPD_PASEP_IPI,
            24: self.dictPD_PASEP_CFM,
            25: self.dictPD_PASEP_CFH,
            26: self.dictPD_PASEP_CIDE,
            27: self.dictPD_PASEP_ADO,
            28: self.dictPDSART,
            29: self.dictPDFundoS100,
            30: self.dictPDFundoS148,
            31: self.dictPDT,
            32: self.dictPDTRecom
        }
        
        self.dict_map_pde = {
            33: self.dictPDEBaixa,
            34: self.dictPDEGanho
        }
        
        self.dict_map_na = {
            35: self.dictNA214,
            36: self.dictNAR214,
            37: self.dictNAR206,
            38: self.dictNA206
        }
        
        self.dict_map_np = {
            39: self.dictBloqueioCUTE,
            40: self.dictDesbloqueioCUTE,
            41: self.dictBloqueio36617,
            42: self.dictDesbloqueio36617,
            43: self.dictBloqueio7129,
            44: self.dictDesbloqueio7129,
            45: self.dictBloqueio3093,
            46: self.dictDesbloqueio3093
        }

    def encerrar_app(self):
        """
        Encerra a aplicação de forma segura:
        1. Define flag de parada.
        2. Fecha o WebDriver.
        3. Limpa credenciais da memória.
        4. Destrói a janela e encerra o processo Python.
        """
        self.stop_event = True
        try:
            if self.driver: self.siafe.fechar_driver()
        except: pass
        self.usuario_siafe = ""
        self.senha_siafe = ""
        self.destroy()
        sys.exit()

if __name__ == "__main__":
    app = PTESTApp()
    app.protocol("WM_DELETE_WINDOW", app.encerrar_app)
    app.mainloop()