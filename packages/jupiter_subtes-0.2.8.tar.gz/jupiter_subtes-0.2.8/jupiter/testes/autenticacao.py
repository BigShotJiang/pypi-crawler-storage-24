import sys
import os

diretorio_atual = os.path.dirname(os.path.abspath(__file__))
diretorio_pai = os.path.dirname(diretorio_atual)
sys.path.append(diretorio_pai)

###

import automaweb
import apipoint

# arquivos = automaweb.listar_recursivo('/home/joaobraga/Downloads/teste_Uploads')
# for aqruivo in arquivos:
#     print(aqruivo)

# print('\n----------\n')

# pastas = os.scandir('/home/joaobraga/Downloads/teste_Uploads')
# for pasta in pastas:
#     print(pasta)

point = apipoint.SharePoint('https://sefazrj.sharepoint.com/sites/SUBTES')


# point.download_arquivo(
#     caminho_sharepoint='/sites/SUBTES/Shared Documents/SUPCONC/6 - Apoio Automações/02 - Demonstrativos DAF/CSV/DAF - 2000.01.csv'
# )

# point.upload_arquivo(
#     caminho_local='/home/joaobraga/Downloads/DAF - 2000.01.csv',
#     pasta_sharepoint='/sites/SUBTES/Shared Documents/SUPCONC/5 - Automação/00 - Testes'
# )

# point.download_pasta(
#     pasta_sharepoint='/sites/SUBTES/Shared Documents/SUPCONC/5 - Automação/00 - Testes_Downloads',
#     pasta_local='/home/joaobraga/Downloads/teste_Downloads'
# )

# point.upload_pasta(
#     pasta_local='/home/joaobraga/Downloads/teste_Uploads',
#     pasta_sharepoint='/sites/SUBTES/Shared Documents/SUPCONC/5 - Automação/00 - Testes_Uploads'
# )

point.excluir_pasta(
    caminho_pasta_sharepoint='/sites/SUBTES/Shared Documents/SUPCONC/5 - Automação/00 - Testes_Uploads'
)