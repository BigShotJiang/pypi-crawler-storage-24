"""
Hosted Checkout Example
"""

from pawapay import PawaPay

# Initialize client
pay = PawaPay(api_key="sk_test_your_key_here")

# Initialize checkout session
print("Creating checkout session...")
session = pay.checkout.initialize(
    amount=10000,  # GHS 100.00
    email="customer@example.com",
    callback_url="https://yoursite.com/payment/callback",
    metadata={
        "order_id": "ORD-67890",
        "product": "Premium Plan - Annual",
        "customer_id": "CUST-123"
    }
)

print(f"\n✅ Checkout session created!")
print(f"Access Code: {session['access_code']}")
print(f"Checkout URL: {session['checkout_url']}")
print(f"Reference: {session['reference']}")

print(f"\n📱 Next steps:")
print(f"1. Redirect customer to: {session['checkout_url']}")
print(f"2. Customer completes payment on hosted page")
print(f"3. Customer is redirected to your callback URL")
print(f"4. Verify payment using reference: {session['reference']}")

# Simulate verification after payment
print(f"\n\nVerifying payment (after customer completes checkout)...")
verification = pay.checkout.verify(session['reference'])

print(f"\n📊 Payment Result:")
print(f"Status: {verification['status']}")
print(f"Amount: GHS {verification['amount'] / 100:.2f}")
print(f"Customer: {verification['email']}")

if verification['status'] == 'success':
    print(f"\n✅ Payment successful! Deliver product/service.")
elif verification['status'] == 'pending':
    print(f"\n⏳ Payment pending. Check again later.")
else:
    print(f"\n❌ Payment failed.")
