"""
Flask Integration Example
"""

from flask import Flask, request, jsonify, redirect
from pawapay import PawaPay
from pawapay.exceptions import PawaPayError

app = Flask(__name__)

# Initialize PawaPay client
pay = PawaPay(api_key="sk_test_your_key_here")


@app.route('/api/payment/momo', methods=['POST'])
def charge_momo():
    """Charge mobile money"""
    try:
        data = request.get_json()
        
        result = pay.momo.charge(
            amount=data['amount'],
            phone=data['phone'],
            network=data['network'],
            email=data['email'],
            reference=data.get('reference'),
            metadata=data.get('metadata')
        )
        
        return jsonify(result), 200
        
    except PawaPayError as e:
        return jsonify({
            'error': e.message,
            'status': e.http_status
        }), e.http_status or 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/payment/checkout', methods=['POST'])
def create_checkout():
    """Create checkout session"""
    try:
        data = request.get_json()
        
        session = pay.checkout.initialize(
            amount=data['amount'],
            email=data['email'],
            callback_url=data.get('callback_url'),
            metadata=data.get('metadata')
        )
        
        return jsonify(session), 200
        
    except PawaPayError as e:
        return jsonify({
            'error': e.message,
            'status': e.http_status
        }), e.http_status or 400


@app.route('/api/payment/verify/<reference>', methods=['GET'])
def verify_payment(reference):
    """Verify payment"""
    try:
        result = pay.momo.verify(reference)
        return jsonify(result), 200
        
    except PawaPayError as e:
        return jsonify({
            'error': e.message,
            'status': e.http_status
        }), e.http_status or 400


@app.route('/api/transactions', methods=['GET'])
def list_transactions():
    """List transactions"""
    try:
        limit = request.args.get('limit', 10, type=int)
        status = request.args.get('status')
        
        transactions = pay.transactions.list(
            limit=limit,
            status=status
        )
        
        return jsonify({
            'transactions': transactions,
            'count': len(transactions)
        }), 200
        
    except PawaPayError as e:
        return jsonify({
            'error': e.message
        }), 400


@app.route('/payment/callback')
def payment_callback():
    """Handle payment callback"""
    reference = request.args.get('reference')
    
    if not reference:
        return "Missing reference", 400
    
    try:
        # Verify payment
        result = pay.checkout.verify(reference)
        
        if result['status'] == 'success':
            # Payment successful - update your database
            # Grant access to product/service
            return redirect(f'/payment/success?ref={reference}')
        else:
            return redirect(f'/payment/failed?ref={reference}')
            
    except PawaPayError as e:
        return f"Verification error: {e.message}", 400


@app.route('/payment/success')
def payment_success():
    """Payment success page"""
    reference = request.args.get('ref')
    return f"""
    <html>
        <body>
            <h1>✅ Payment Successful!</h1>
            <p>Reference: {reference}</p>
            <a href="/">Return to Home</a>
        </body>
    </html>
    """


@app.route('/payment/failed')
def payment_failed():
    """Payment failed page"""
    reference = request.args.get('ref')
    return f"""
    <html>
        <body>
            <h1>❌ Payment Failed</h1>
            <p>Reference: {reference}</p>
            <a href="/">Try Again</a>
        </body>
    </html>
    """


if __name__ == '__main__':
    app.run(debug=True, port=5000)
