"""
Error Handling Example
"""

from pawapay import PawaPay
from pawapay.exceptions import (
    AuthenticationError,
    InvalidRequestError,
    APIError,
    NetworkError,
    PawaPayError
)

# Initialize client
pay = PawaPay(api_key="sk_test_your_key_here")

def process_payment(amount, phone, network, email):
    """Process payment with comprehensive error handling"""
    try:
        print(f"Processing payment of GHS {amount/100:.2f}...")
        
        result = pay.momo.charge(
            amount=amount,
            phone=phone,
            network=network,
            email=email
        )
        
        print(f"✅ Payment successful!")
        print(f"Reference: {result['reference']}")
        return result
        
    except AuthenticationError as e:
        print(f"❌ Authentication Error: {e.message}")
        print(f"   Please check your API key")
        return None
        
    except InvalidRequestError as e:
        print(f"❌ Invalid Request: {e.message}")
        print(f"   HTTP Status: {e.http_status}")
        if e.response:
            print(f"   Details: {e.response}")
        return None
        
    except APIError as e:
        print(f"❌ API Error: {e.message}")
        print(f"   HTTP Status: {e.http_status}")
        print(f"   Please try again or contact support")
        return None
        
    except NetworkError as e:
        print(f"❌ Network Error: {e.message}")
        print(f"   Please check your internet connection")
        return None
        
    except PawaPayError as e:
        print(f"❌ PawaPay Error: {e.message}")
        return None
        
    except Exception as e:
        print(f"❌ Unexpected Error: {str(e)}")
        return None


# Example 1: Successful payment
print("Example 1: Successful Payment")
print("-" * 50)
result = process_payment(
    amount=5000,
    phone="0244123456",
    network="MTN",
    email="customer@example.com"
)
print()

# Example 2: Invalid network
print("Example 2: Invalid Network")
print("-" * 50)
result = process_payment(
    amount=5000,
    phone="0244123456",
    network="INVALID",  # Invalid network
    email="customer@example.com"
)
print()

# Example 3: Invalid phone number
print("Example 3: Invalid Phone")
print("-" * 50)
result = process_payment(
    amount=5000,
    phone="invalid",  # Invalid phone
    network="MTN",
    email="customer@example.com"
)
print()

# Example 4: Verify non-existent transaction
print("Example 4: Verify Non-existent Transaction")
print("-" * 50)
try:
    result = pay.momo.verify("INVALID-REF-123")
    print(f"Status: {result['status']}")
except APIError as e:
    print(f"❌ Transaction not found: {e.message}")
