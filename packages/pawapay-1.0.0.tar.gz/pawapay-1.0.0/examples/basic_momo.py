"""
Basic Mobile Money Payment Example
"""

from pawapay import PawaPay

# Initialize client with test API key
pay = PawaPay(api_key="sk_test_your_key_here")

# Charge MTN Mobile Money
print("Charging mobile money...")
result = pay.momo.charge(
    amount=5000,        # GHS 50.00 (amount in pesewas)
    phone="0244123456",
    network="MTN",
    email="customer@example.com",
    reference="ORDER-12345",
    metadata={
        "order_id": "12345",
        "customer_name": "John Doe",
        "product": "Premium Subscription"
    }
)

print(f"\n✅ Payment initiated successfully!")
print(f"Reference: {result['reference']}")
print(f"Status: {result['status']}")
print(f"Message: {result.get('message', 'N/A')}")

# Verify the payment
print(f"\nVerifying payment...")
verification = pay.momo.verify(result['reference'])

print(f"\n📊 Payment Status:")
print(f"Reference: {verification['reference']}")
print(f"Status: {verification['status']}")
print(f"Amount: GHS {verification['amount'] / 100:.2f}")
print(f"Network: {verification.get('network', 'N/A')}")
print(f"Customer: {verification['email']}")
