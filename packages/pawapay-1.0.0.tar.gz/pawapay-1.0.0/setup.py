from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pawapay",
    version="1.0.0",
    author="PawaPay",
    author_email="support@pawapay.com",
    description="Official Python SDK for PawaPay - African Payment Gateway",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pawapay/pawapay-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
    ],
    keywords="pawapay payment gateway africa mobile money momo payments api",
    project_urls={
        "Bug Reports": "https://github.com/pawapay/pawapay-python/issues",
        "Documentation": "https://docs.pawapay.com",
        "Source": "https://github.com/pawapay/pawapay-python",
    },
)
