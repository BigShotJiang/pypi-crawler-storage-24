"""
PawaPay Client
Main client class for interacting with the PawaPay API
"""

import requests
from typing import Optional, Dict, Any
from .exceptions import (
    AuthenticationError,
    InvalidRequestError,
    APIError,
    NetworkError,
)
from .resources.momo import MobileMoneyResource
from .resources.checkout import CheckoutResource
from .resources.transactions import TransactionResource


class PawaPay:
    """
    PawaPay API Client
    
    Args:
        api_key (str): Your PawaPay API key (starts with sk_test_ or sk_live_)
        base_url (str, optional): API base URL. Defaults to production URL.
    
    Example:
        >>> from pawapay import PawaPay
        >>> pay = PawaPay(api_key="sk_test_your_key_here")
        >>> result = pay.momo.charge(
        ...     amount=5000,
        ...     phone="0244123456",
        ...     network="MTN",
        ...     email="customer@example.com"
        ... )
    """
    
    DEFAULT_BASE_URL = "https://api.pawapay.com"
    DEFAULT_TIMEOUT = 30
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None
    ):
        if not api_key:
            raise AuthenticationError("API key is required")
        
        if not api_key.startswith(("sk_test_", "sk_live_")):
            raise AuthenticationError(
                "Invalid API key format. Key must start with 'sk_test_' or 'sk_live_'"
            )
        
        self.api_key = api_key
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.is_test_mode = api_key.startswith("sk_test_")
        
        # Initialize resources
        self.momo = MobileMoneyResource(self)
        self.checkout = CheckoutResource(self)
        self.transactions = TransactionResource(self)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get default headers for API requests"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"PawaPay-Python/1.0.0",
        }
    
    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make HTTP request to PawaPay API
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            data: Request body data
            params: URL query parameters
        
        Returns:
            Response data as dictionary
        
        Raises:
            AuthenticationError: If API key is invalid
            InvalidRequestError: If request parameters are invalid
            APIError: If API returns an error
            NetworkError: If network request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers()
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=data,
                params=params,
                timeout=self.timeout
            )
            
            # Handle different status codes
            if response.status_code == 401:
                raise AuthenticationError(
                    "Invalid API key",
                    http_status=401,
                    response=response.json() if response.content else None
                )
            
            if response.status_code == 400:
                error_data = response.json() if response.content else {}
                raise InvalidRequestError(
                    error_data.get("error", "Invalid request"),
                    http_status=400,
                    response=error_data
                )
            
            if response.status_code >= 500:
                raise APIError(
                    "PawaPay API error",
                    http_status=response.status_code,
                    response=response.json() if response.content else None
                )
            
            if not response.ok:
                error_data = response.json() if response.content else {}
                raise APIError(
                    error_data.get("error", "API request failed"),
                    http_status=response.status_code,
                    response=error_data
                )
            
            return response.json()
        
        except requests.exceptions.Timeout:
            raise NetworkError(f"Request timeout after {self.timeout} seconds")
        
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {str(e)}")
        
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error: {str(e)}")
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make GET request"""
        return self._request("GET", endpoint, params=params)
    
    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make POST request"""
        return self._request("POST", endpoint, data=data)
    
    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make PUT request"""
        return self._request("PUT", endpoint, data=data)
    
    def delete(self, endpoint: str) -> Dict[str, Any]:
        """Make DELETE request"""
        return self._request("DELETE", endpoint)
