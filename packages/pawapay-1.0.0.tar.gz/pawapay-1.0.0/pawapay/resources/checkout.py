"""
Checkout Resource
Handles hosted checkout page operations
"""

from typing import Optional, Dict, Any


class CheckoutResource:
    """
    Hosted checkout page operations
    
    Create payment links and initialize checkout sessions
    """
    
    def __init__(self, client):
        self.client = client
    
    def initialize(
        self,
        amount: int,
        email: str,
        currency: str = "GHS",
        callback_url: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Initialize a checkout session
        
        Creates a hosted checkout page where customers can pay with
        mobile money or card.
        
        Args:
            amount (int): Amount in pesewas (e.g., 5000 = GHS 50.00)
            email (str): Customer email address
            currency (str, optional): Currency code. Defaults to "GHS"
            callback_url (str, optional): URL to redirect after payment
            metadata (dict, optional): Additional data to store
        
        Returns:
            dict: Checkout session with access_code and checkout_url
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> session = pay.checkout.initialize(
            ...     amount=10000,
            ...     email="customer@example.com",
            ...     callback_url="https://yoursite.com/callback"
            ... )
            >>> print(session['checkout_url'])
            >>> # Redirect customer to checkout_url
        """
        data = {
            "amount": amount,
            "email": email,
            "currency": currency
        }
        
        if callback_url:
            data["callback_url"] = callback_url
        
        if metadata:
            data["metadata"] = metadata
        
        response = self.client.post("/api/v1/payments/initialize", data)
        
        return response
    
    def verify(self, reference: str) -> Dict[str, Any]:
        """
        Verify a checkout transaction
        
        Args:
            reference (str): Transaction reference from checkout
        
        Returns:
            dict: Transaction details including payment status
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> result = pay.checkout.verify("UPY-2024-123456-GH")
            >>> if result['status'] == 'success':
            ...     print("Payment successful!")
        """
        response = self.client.post(
            "/api/v1/payments/verify-transaction",
            {"reference": reference}
        )
        
        return response
