"""
Transaction Resource
Handles transaction listing and retrieval
"""

from typing import Optional, Dict, Any, List


class TransactionResource:
    """
    Transaction management operations
    
    List and retrieve transaction details
    """
    
    def __init__(self, client):
        self.client = client
    
    def list(
        self,
        limit: int = 10,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        List transactions
        
        Args:
            limit (int, optional): Number of transactions to return. Defaults to 10
            status (str, optional): Filter by status - "success", "pending", "failed"
            start_date (str, optional): Filter from date (ISO format)
            end_date (str, optional): Filter to date (ISO format)
        
        Returns:
            list: List of transaction objects
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> transactions = pay.transactions.list(limit=20, status="success")
            >>> for txn in transactions:
            ...     print(f"{txn['reference']}: {txn['amount']}")
        """
        params = {"limit": limit}
        
        if status:
            params["status"] = status
        
        if start_date:
            params["start_date"] = start_date
        
        if end_date:
            params["end_date"] = end_date
        
        response = self.client.get("/api/v1/transactions", params=params)
        
        return response.get("transactions", [])
    
    def get(self, reference: str) -> Dict[str, Any]:
        """
        Get transaction by reference
        
        Args:
            reference (str): Transaction reference
        
        Returns:
            dict: Transaction details
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> txn = pay.transactions.get("UPY-2024-123456-GH")
            >>> print(f"Status: {txn['status']}")
            >>> print(f"Amount: {txn['amount']}")
        """
        response = self.client.post(
            "/api/v1/payments/get-transaction",
            {"reference": reference}
        )
        
        return response.get("transaction", {})
