"""
Mobile Money Resource
Handles mobile money payment operations
"""

from typing import Optional, Dict, Any


class MobileMoneyResource:
    """
    Mobile Money payment operations
    
    Supports MTN, Vodafone, and AirtelTigo networks in Ghana
    """
    
    SUPPORTED_NETWORKS = ["MTN", "VODAFONE", "AIRTELTIGO"]
    
    def __init__(self, client):
        self.client = client
    
    def charge(
        self,
        amount: int,
        phone: str,
        network: str,
        email: str,
        currency: str = "GHS",
        reference: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Charge a mobile money account
        
        Args:
            amount (int): Amount in pesewas (e.g., 5000 = GHS 50.00)
            phone (str): Customer phone number (e.g., "0244123456")
            network (str): Mobile network - "MTN", "VODAFONE", or "AIRTELTIGO"
            email (str): Customer email address
            currency (str, optional): Currency code. Defaults to "GHS"
            reference (str, optional): Your unique transaction reference
            metadata (dict, optional): Additional data to store with transaction
        
        Returns:
            dict: Transaction response with status and reference
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> result = pay.momo.charge(
            ...     amount=5000,
            ...     phone="0244123456",
            ...     network="MTN",
            ...     email="customer@example.com"
            ... )
            >>> print(result['reference'])
        
        Raises:
            InvalidRequestError: If parameters are invalid
            APIError: If payment fails
        """
        # Validate network
        network = network.upper()
        if network not in self.SUPPORTED_NETWORKS:
            from ..exceptions import InvalidRequestError
            raise InvalidRequestError(
                f"Invalid network. Must be one of: {', '.join(self.SUPPORTED_NETWORKS)}"
            )
        
        # Prepare request data
        data = {
            "amount": amount,
            "currency": currency,
            "mobile_money": {
                "phone": phone,
                "network": network
            },
            "email": email
        }
        
        if reference:
            data["reference"] = reference
        
        if metadata:
            data["metadata"] = metadata
        
        # Make API request
        response = self.client.post("/api/v1/payments/momo", data)
        
        return response
    
    def verify(self, reference: str) -> Dict[str, Any]:
        """
        Verify a mobile money transaction
        
        Args:
            reference (str): Transaction reference to verify
        
        Returns:
            dict: Transaction details including status
        
        Example:
            >>> pay = PawaPay(api_key="sk_test_...")
            >>> result = pay.momo.verify("UPY-2024-123456-GH")
            >>> print(result['status'])  # 'success', 'pending', or 'failed'
        """
        response = self.client.post(
            "/api/v1/payments/verify-transaction",
            {"reference": reference}
        )
        
        return response
