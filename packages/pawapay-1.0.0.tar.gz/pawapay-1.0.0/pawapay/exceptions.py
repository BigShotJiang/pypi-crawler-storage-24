"""
PawaPay SDK Exceptions
"""


class PawaPayError(Exception):
    """Base exception for all PawaPay errors"""
    
    def __init__(self, message, http_status=None, response=None):
        super().__init__(message)
        self.message = message
        self.http_status = http_status
        self.response = response


class AuthenticationError(PawaPayError):
    """Raised when API key is invalid or missing"""
    pass


class InvalidRequestError(PawaPayError):
    """Raised when request parameters are invalid"""
    pass


class APIError(PawaPayError):
    """Raised when API returns an error"""
    pass


class NetworkError(PawaPayError):
    """Raised when network request fails"""
    pass
