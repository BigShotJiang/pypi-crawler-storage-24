# UHT Discovery

UHT Discovery is a protein discovery pipeline centered on three core steps:

1. `blaster`: retrieve homologous sequences from NCBI
2. `trim`: quality-control and length-filter FASTA sequences
3. `clust` (PLMCLUSTV2): cluster sequences using ESM2 embeddings and NLL scoring

## Installation

### From Source

```bash
git clone <repository-url>
cd uht-discovery-package
pip install -e .
```

### From PyPI

```bash
pip install uht-discovery
```

## Quick Start

### 1. BLASTER

Put one or more query FASTA files in:

```text
inputs/blaster/PROJECT/
```

Run:

```bash
uht-blast --project PROJECT --email your@email.com --hits 500
```

Key options:

- `--project`: project directory name (required)
- `--email`: email for NCBI API usage (required)
- `--hits`: number of hits to retrieve (default: `100`)
- `--db`: `nr`, `swissprot`, or `refseq_protein` (default: `nr`)
- `--evalue`: BLAST E-value cutoff (default: `1e-5`)

Outputs:

- `results/blaster/PROJECT/` with combined FASTA and BLAST report

### 2. TRIM

Put FASTA files in:

```text
inputs/trim/PROJECT/
```

Run (automatic thresholds):

```bash
uht-trim --project PROJECT --auto
```

Run (manual thresholds):

```bash
uht-trim --project PROJECT --low 100 --high 500
```

Key options:

- `--project`: project directory name (required)
- `--auto`: infer thresholds automatically
- `--low` / `--high`: manual inclusive length thresholds

Outputs:

- `results/trim/PROJECT/` with filtered FASTA files, removed-sequence logs, and QC plots

### 3. PLMCLUSTV2

Put FASTA files in:

```text
inputs/plmclustv2/PROJECT/
```

Run:

```bash
uht-clust --project PROJECT --clusters auto
```

Or fixed cluster count:

```bash
uht-clust --project PROJECT --clusters 6
```

Key options:

- `--project`: project directory name (required)
- `--clusters`: integer cluster count or `auto`
- `--sil-min` / `--sil-max`: silhouette search bounds for auto mode
- `--keep-separate`: process each FASTA file independently

Outputs:

- `results/plmclustv2/PROJECT/` including cluster FASTAs, metrics CSVs, representative sequences, and visualization files

## Recommended Workflow

Run the pipeline in this order:

1. `uht-blast`
2. `uht-trim`
3. `uht-clust`

## Help

```bash
uht-blast --help
uht-trim --help
uht-clust --help
```
