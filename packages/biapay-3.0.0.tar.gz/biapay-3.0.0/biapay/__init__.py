"""
BIAPAY Python SDK
~~~~~~~~~~~~~~~~~

A Python SDK for integrating BIAPAY payment gateway.

Basic usage::

    from biapay import BIAPay

    client = BIAPay(
        client_id="your-client-id",
        client_secret="your-client-secret"
    )

    session = client.create_payment_session(
        order_id="ORDER-001",
        amount=5000,
        currency_code="XAF",
        customer_email="customer@example.com",
        customer_phone="237600000000",
        transaction_id="TXN-001"
    )

    print(session.launch_url)

"""

from .client import BIAPay
from .models import (
    PaymentSession,
    OrderDetails,
    CustomerDetails,
    ClientDetails,
    CallbackPayload,
)
from .exceptions import (
    BIAPayError,
    BIAPayAuthError,
    BIAPayConnectionError,
    BIAPaySignatureError,
)

__version__ = "1.0.0"
__author__ = "BIAPAY"
__all__ = [
    "BIAPay",
    "PaymentSession",
    "OrderDetails",
    "CustomerDetails",
    "ClientDetails",
    "CallbackPayload",
    "BIAPayError",
    "BIAPayAuthError",
    "BIAPayConnectionError",
    "BIAPaySignatureError",
]
