"""Tests for model registry loading and content."""

from goodmem._registries import (
    EMBEDDER_MODEL_REGISTRY,
    LLM_MODEL_REGISTRY,
    RERANKER_MODEL_REGISTRY,
)


def test_embedder_registry_loads():
    assert isinstance(EMBEDDER_MODEL_REGISTRY, dict)
    assert len(EMBEDDER_MODEL_REGISTRY) > 0


def test_llm_registry_loads():
    assert isinstance(LLM_MODEL_REGISTRY, dict)
    assert len(LLM_MODEL_REGISTRY) > 0


def test_reranker_registry_loads():
    assert isinstance(RERANKER_MODEL_REGISTRY, dict)
    assert len(RERANKER_MODEL_REGISTRY) > 0


def test_known_embedder_has_expected_fields():
    entry = EMBEDDER_MODEL_REGISTRY["text-embedding-3-small"]
    assert entry["provider_type"] == "OPENAI"
    assert entry["dimensions"]["default"] == 1536
    assert "TEXT" in entry["supported_modalities"]


def test_known_llm_has_expected_fields():
    entry = LLM_MODEL_REGISTRY["gpt-4o"]
    assert entry["provider_type"] == "OPENAI"
    assert entry["max_context_length"] > 0
    assert "TEXT" in entry["supported_modalities"]


def test_known_reranker_has_expected_fields():
    entry = RERANKER_MODEL_REGISTRY["rerank-v3.5"]
    assert entry["provider_type"] == "COHERE"
    assert "TEXT" in entry["supported_modalities"]


def test_unknown_model_absent():
    assert "nonexistent-model-xyz" not in EMBEDDER_MODEL_REGISTRY
    assert "nonexistent-model-xyz" not in LLM_MODEL_REGISTRY
    assert "nonexistent-model-xyz" not in RERANKER_MODEL_REGISTRY


def test_embedder_default_dimensions_capped_at_1536():
    """All embedder default dimensions should be <= 1536."""
    for model_id, entry in EMBEDDER_MODEL_REGISTRY.items():
        dims = entry.get("dimensions")
        if dims and "default" in dims:
            assert dims["default"] <= 1536, (
                f"{model_id} default dimensions {dims['default']} exceeds 1536"
            )
