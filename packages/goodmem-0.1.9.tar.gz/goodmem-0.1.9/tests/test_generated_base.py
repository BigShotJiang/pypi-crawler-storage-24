"""Tests that generated _api_base/*.py files have correct structure."""

from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# CRUD bases
# ---------------------------------------------------------------------------

class TestEmbeddersBase:
    def test_is_plain_class(self):
        from goodmem._api_base.embedders import EmbeddersAPIBase, AsyncEmbeddersAPIBase
        # No CRUDNamespace base — plain class with inline __init__
        assert EmbeddersAPIBase.__bases__ == (object,)
        assert AsyncEmbeddersAPIBase.__bases__ == (object,)

    def test_has_init(self):
        from goodmem._api_base.embedders import EmbeddersAPIBase
        assert "__init__" in EmbeddersAPIBase.__dict__

    def test_create_model_attribute(self):
        from goodmem._api_base.embedders import EmbeddersAPIBase
        from goodmem.models.embedder_creation_request import EmbedderCreationRequest
        assert EmbeddersAPIBase._create_model is EmbedderCreationRequest


class TestRerankersBase:
    def test_is_plain_class(self):
        from goodmem._api_base.rerankers import RerankersAPIBase, AsyncRerankersAPIBase
        assert RerankersAPIBase.__bases__ == (object,)
        assert AsyncRerankersAPIBase.__bases__ == (object,)


class TestSpacesBase:
    def test_is_plain_class(self):
        from goodmem._api_base.spaces import SpacesAPIBase, AsyncSpacesAPIBase
        assert SpacesAPIBase.__bases__ == (object,)
        assert AsyncSpacesAPIBase.__bases__ == (object,)


class TestApikeysBase:
    def test_is_plain_class(self):
        from goodmem._api_base.apikeys import ApikeysAPIBase, AsyncApikeysAPIBase
        assert ApikeysAPIBase.__bases__ == (object,)
        assert AsyncApikeysAPIBase.__bases__ == (object,)

    def test_no_get_method(self):
        """ApiKeys has no GET-by-ID endpoint; get() must not exist."""
        from goodmem._api_base.apikeys import ApikeysAPIBase
        assert not hasattr(ApikeysAPIBase, "get")


class TestLlmsBase:
    def test_is_plain_class(self):
        from goodmem._api_base.llms import LlmsAPIBase, AsyncLlmsAPIBase
        assert LlmsAPIBase.__bases__ == (object,)
        assert AsyncLlmsAPIBase.__bases__ == (object,)

    def test_create_method_exists(self):
        from goodmem._api_base.llms import LlmsAPIBase
        assert hasattr(LlmsAPIBase, "create")
        assert "create" in LlmsAPIBase.__dict__


# ---------------------------------------------------------------------------
# Memories base — has extra methods
# ---------------------------------------------------------------------------

class TestMemoriesBase:
    def test_is_plain_class(self):
        from goodmem._api_base.memories import MemoriesAPIBase, AsyncMemoriesAPIBase
        assert MemoriesAPIBase.__bases__ == (object,)
        assert AsyncMemoriesAPIBase.__bases__ == (object,)

    def test_has_retrieve_with_body_helper(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert hasattr(MemoriesAPIBase, "_retrieve_with_body")

    def test_has_retrieve_method(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert hasattr(MemoriesAPIBase, "retrieve")

    def test_has_batch_methods(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert hasattr(MemoriesAPIBase, "batch_create")
        assert hasattr(MemoriesAPIBase, "batch_get")
        assert hasattr(MemoriesAPIBase, "batch_delete")

    def test_has_content(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert hasattr(MemoriesAPIBase, "content")

    def test_has_space_scoped_list(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        import inspect
        sig = inspect.signature(MemoriesAPIBase.list)
        assert "space_id" in sig.parameters


# ---------------------------------------------------------------------------
# Non-CRUD bases
# ---------------------------------------------------------------------------

class TestUsersBase:
    def test_importable(self):
        from goodmem._api_base.users import UsersAPIBase, AsyncUsersAPIBase
        assert UsersAPIBase is not None
        assert AsyncUsersAPIBase is not None

    def test_has_expected_methods(self):
        from goodmem._api_base.users import UsersAPIBase
        assert hasattr(UsersAPIBase, "me")
        assert hasattr(UsersAPIBase, "get")

    def test_is_plain_class(self):
        from goodmem._api_base.users import UsersAPIBase
        assert UsersAPIBase.__bases__ == (object,)

    def test_get_rejects_both_id_and_email(self):
        import httpx
        from goodmem._api_base.users import UsersAPIBase
        api = UsersAPIBase(httpx.Client(), {})
        with pytest.raises(ValueError, match="Exactly one of"):
            api.get(id="abc", email="x@example.com")
        api._http.close()

    def test_get_rejects_neither_id_nor_email(self):
        import httpx
        from goodmem._api_base.users import UsersAPIBase
        api = UsersAPIBase(httpx.Client(), {})
        with pytest.raises(ValueError, match="Exactly one of"):
            api.get()
        api._http.close()


class TestOcrBase:
    def test_has_document_method(self):
        from goodmem._api_base.ocr import OcrAPIBase
        assert hasattr(OcrAPIBase, "document")

    def test_is_plain_class(self):
        from goodmem._api_base.ocr import OcrAPIBase
        assert OcrAPIBase.__bases__ == (object,)


class TestSystemBase:
    def test_has_expected_methods(self):
        from goodmem._api_base.system import SystemAPIBase
        assert hasattr(SystemAPIBase, "info")
        assert hasattr(SystemAPIBase, "init")


class TestAdminBase:
    def test_has_expected_methods(self):
        from goodmem._api_base.admin import AdminAPIBase
        assert hasattr(AdminAPIBase, "drain")

    def test_has_sub_namespaces(self):
        import httpx
        from goodmem._api_base.admin import AdminAPIBase
        inst = AdminAPIBase(httpx.Client(), {})
        assert hasattr(inst, "background_jobs")
        assert hasattr(inst.background_jobs, "purge")
        assert hasattr(inst, "license")
        assert hasattr(inst.license, "reload")
        inst._http.close()


# ---------------------------------------------------------------------------
# _rest_metadata completeness & correctness
# ---------------------------------------------------------------------------

# (module_path, class_name, expected_method_keys)
_ALL_BASE_CLASSES = [
    ("goodmem._api_base.embedders", "EmbeddersAPIBase",
     ["create", "get", "list", "update", "delete"]),
    ("goodmem._api_base.rerankers", "RerankersAPIBase",
     ["create", "get", "list", "update", "delete"]),
    ("goodmem._api_base.llms", "LlmsAPIBase",
     ["create", "get", "list", "update", "delete"]),
    ("goodmem._api_base.spaces", "SpacesAPIBase",
     ["create", "get", "list", "update", "delete"]),
    ("goodmem._api_base.apikeys", "ApikeysAPIBase",
     ["create", "list", "update", "delete"]),
    ("goodmem._api_base.memories", "MemoriesAPIBase",
     ["create", "get", "list", "delete", "content", "batch_create",
      "batch_delete", "batch_get", "retrieve"]),
    ("goodmem._api_base.users", "UsersAPIBase",
     ["get", "me"]),
    ("goodmem._api_base.system", "SystemAPIBase",
     ["info", "init"]),
    ("goodmem._api_base.ocr", "OcrAPIBase",
     ["document"]),
    ("goodmem._api_base.admin", "AdminAPIBase",
     ["drain", "background_jobs.purge", "license.reload"]),
]


class TestRestMetadataCompleteness:
    """Every method on every base class must have a _rest_metadata entry."""

    @pytest.mark.parametrize(
        "module_path,class_name,expected_keys",
        _ALL_BASE_CLASSES,
        ids=[c[1] for c in _ALL_BASE_CLASSES],
    )
    def test_has_all_method_keys(self, module_path, class_name, expected_keys):
        import importlib
        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name)
        meta = cls._rest_metadata
        for key in expected_keys:
            assert key in meta, f"{class_name}._rest_metadata missing key {key!r}"

    @pytest.mark.parametrize(
        "module_path,class_name,expected_keys",
        _ALL_BASE_CLASSES,
        ids=[c[1] for c in _ALL_BASE_CLASSES],
    )
    def test_entries_have_http_method_and_path(self, module_path, class_name, expected_keys):
        import importlib
        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name)
        meta = cls._rest_metadata
        for key in expected_keys:
            entry = meta[key]
            assert "http_method" in entry, f"{class_name}.{key} missing http_method"
            assert "path" in entry, f"{class_name}.{key} missing path"


class TestRestMetadataCorrectness:
    """Spot-check specific fields for important methods."""

    def test_retrieve_has_accept_from(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert MemoriesAPIBase._rest_metadata["retrieve"]["accept_from"] == "format"

    def test_content_has_bytes_response(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert MemoriesAPIBase._rest_metadata["content"]["response"] == "bytes"

    def test_admin_sub_namespace_keys_are_dotted(self):
        from goodmem._api_base.admin import AdminAPIBase
        meta = AdminAPIBase._rest_metadata
        assert "background_jobs.purge" in meta
        assert "license.reload" in meta

    def test_batch_create_path(self):
        from goodmem._api_base.memories import MemoriesAPIBase
        assert MemoriesAPIBase._rest_metadata["batch_create"]["path"] == "/v1/memories:batchCreate"

    def test_system_info_is_get(self):
        from goodmem._api_base.system import SystemAPIBase
        assert SystemAPIBase._rest_metadata["info"]["http_method"] == "GET"

    def test_users_me_path(self):
        from goodmem._api_base.users import UsersAPIBase
        assert UsersAPIBase._rest_metadata["me"]["path"] == "/v1/users/me"


# ---------------------------------------------------------------------------
# Keyword-only guard — every named param (except self) must be KEYWORD_ONLY
# ---------------------------------------------------------------------------

class TestAllParamsKeywordOnly:
    """Regression guard: all generated Tier-2 method params must be keyword-only.

    **kwargs is naturally keyword-only and is excluded from this check.
    Methods with no named params (only self, or self + **kwargs) are skipped.
    """

    @pytest.mark.parametrize(
        "module_path,class_name,expected_keys",
        _ALL_BASE_CLASSES,
        ids=[c[1] for c in _ALL_BASE_CLASSES],
    )
    def test_named_params_are_keyword_only(self, module_path, class_name, expected_keys):
        import importlib
        import inspect

        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name)

        for method_key in expected_keys:
            # Resolve dotted keys (e.g. "background_jobs.purge") to the actual method
            parts = method_key.split(".")
            obj = cls
            for part in parts:
                obj = getattr(obj, part, None)
                if obj is None:
                    break
            if obj is None:
                continue

            fn = obj if callable(obj) else None
            if fn is None:
                continue

            sig = inspect.signature(fn)
            for pname, param in sig.parameters.items():
                if pname == "self":
                    continue
                if param.kind == inspect.Parameter.VAR_KEYWORD:
                    continue  # **kwargs is fine
                assert param.kind == inspect.Parameter.KEYWORD_ONLY, (
                    f"{class_name}.{method_key}() param {pname!r} is "
                    f"{param.kind.name}, expected KEYWORD_ONLY"
                )
