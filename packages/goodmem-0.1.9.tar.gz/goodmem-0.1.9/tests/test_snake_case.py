"""Tests for _snake() CamelCase → snake_case conversion."""

from __future__ import annotations

from _gen.spec import _snake


class TestStandardConversions:
    def test_simple_camel(self):
        assert _snake("camelCase") == "camel_case"

    def test_pascal(self):
        assert _snake("PostProcessor") == "post_processor"

    def test_multi_word(self):
        assert _snake("RetrieveMemoryEvent") == "retrieve_memory_event"

    def test_already_snake(self):
        assert _snake("already_snake") == "already_snake"

    def test_kebab(self):
        assert _snake("kebab-case") == "kebab_case"

    def test_single_word_lower(self):
        assert _snake("name") == "name"


class TestAcronyms:
    """Acronym handling — the primary edge-case area."""

    def test_trailing_acronym(self):
        assert _snake("APIKey") == "api_key"

    def test_leading_acronym(self):
        assert _snake("LLMResponse") == "llm_response"

    def test_solo_acronym(self):
        assert _snake("LLM") == "llm"

    def test_solo_short_acronym(self):
        assert _snake("OCR") == "ocr"

    def test_pluralised_acronym(self):
        assert _snake("ListLLMsResponse") == "list_llms_response"

    def test_acronym_mid_word(self):
        assert _snake("LLMCreationRequest") == "llm_creation_request"

    def test_consecutive_acronyms(self):
        assert _snake("HTTPSServer") == "https_server"

    def test_acronym_with_digits(self):
        assert _snake("IPv4CIDR") == "ipv4_cidr"

    def test_llm_capabilities(self):
        assert _snake("LLMCapabilities") == "llm_capabilities"

    def test_llm_sampling_params(self):
        assert _snake("LLMSamplingParams") == "llm_sampling_params"

    def test_create_llm_response(self):
        assert _snake("CreateLLMResponse") == "create_llm_response"


class TestRealModelNames:
    """Conversions actually used by the SDK for generated model paths."""

    def test_embedder_creation_request(self):
        assert _snake("EmbedderCreationRequest") == "embedder_creation_request"

    def test_retrieve_memory_request(self):
        assert _snake("RetrieveMemoryRequest") == "retrieve_memory_request"

    def test_space_creation_request(self):
        assert _snake("SpaceCreationRequest") == "space_creation_request"

    def test_chunking_configuration(self):
        assert _snake("ChunkingConfiguration") == "chunking_configuration"

    def test_endpoint_authentication(self):
        assert _snake("EndpointAuthentication") == "endpoint_authentication"
