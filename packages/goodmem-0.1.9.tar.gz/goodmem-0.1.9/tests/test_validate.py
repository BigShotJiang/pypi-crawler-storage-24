"""Wrap _gen/validate.py checks as pytest tests.

These checks verify that hand-written convenience patches (Tier 3) align
with the auto-generated models (Tier 1) and base classes (Tier 2).
Previously run only inside sdk_gen.sh; now part of the regular test suite.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import _gen.validate as v
from _gen.spec import SPEC_PATH

# Checks 8 and 9 need the compiled OpenAPI spec
_needs_spec = pytest.mark.skipif(
    not SPEC_PATH.exists(),
    reason=f"OpenAPI spec not found at {SPEC_PATH} — run ./sdk_gen.sh first",
)


def _collect_errors(fn):
    """Run a validation function and return any new errors."""
    before = len(v.errors)
    fn()
    return v.errors[before:]


def test_1_credential_structure():
    errs = _collect_errors(v.validate_bridge_credentials)
    assert not errs, errs


def test_2_enum_values():
    errs = _collect_errors(v.validate_enum_values)
    assert not errs, errs


def test_3_registry_field_names():
    errs = _collect_errors(v.validate_registry_fields)
    assert not errs, errs


def test_4_patch_field_names():
    errs = _collect_errors(v.validate_patch_field_names)
    assert not errs, errs


def test_5_post_processor_structure():
    errs = _collect_errors(v.validate_post_processor_structure)
    assert not errs, errs


def test_6_default_chunking_config():
    errs = _collect_errors(v.validate_chunking_config)
    assert not errs, errs


@_needs_spec
def test_8_openapi_endpoint_coverage():
    errs = _collect_errors(v.validate_openapi_endpoint_coverage)
    assert not errs, errs


@_needs_spec
def test_9_tier2_argument_alignment():
    errs = _collect_errors(v.validate_tier2_argument_name_alignment)
    assert not errs, errs


@_needs_spec
def test_11_convenience_registry_keys():
    errs = _collect_errors(v.validate_convenience_registry_keys)
    assert not errs, errs


@_needs_spec
def test_12_client_namespace_wiring():
    errs = _collect_errors(v.validate_client_namespace_wiring)
    assert not errs, errs


@_needs_spec
def test_13_route_merges():
    errs = _collect_errors(v.validate_route_merges)
    assert not errs, errs


@_needs_spec
def test_14_cross_namespace_lists():
    errs = _collect_errors(v.validate_cross_namespace_lists)
    assert not errs, errs


@_needs_spec
def test_15_emitter_shape_coverage():
    errs = _collect_errors(v.validate_emitter_shape_coverage)
    assert not errs, errs


@_needs_spec
def test_16_doc_snippet_coverage():
    errs = _collect_errors(v.validate_doc_snippet_coverage)
    assert not errs, errs
