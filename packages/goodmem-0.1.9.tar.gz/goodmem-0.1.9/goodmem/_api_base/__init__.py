# Generated API base classes — produced by _gen/. Do not edit.
