"""Model registries for auto-inferring provider_type, dimensions, etc.

Source of truth: goodmem/registries/embedders.json, llms.json, rerankers.json.
Edit those files directly to add or update models.
Run `python render.py` for a human-readable markdown view.

Dimensions are capped at 1536 (largest supported value <= 1536).
"""

import json
from pathlib import Path

_REG_DIR = Path(__file__).parent / "registries"


def _load_registry(name: str) -> dict[str, dict]:
    with open(_REG_DIR / f"{name}.json") as f:
        return json.load(f)


EMBEDDER_MODEL_REGISTRY: dict[str, dict] = _load_registry("embedders")
LLM_MODEL_REGISTRY: dict[str, dict] = _load_registry("llms")
RERANKER_MODEL_REGISTRY: dict[str, dict] = _load_registry("rerankers")

# Provider type → base endpoint URL.
# Used by convenience transforms to auto-infer endpoint_url from provider_type.
EMBEDDER_PROVIDER_ENDPOINTS: dict[str, str] = {
    "OPENAI": "https://api.openai.com/v1",
    "COHERE": "https://api.cohere.com",
    "JINA": "https://api.jina.ai",
    "VOYAGE": "https://api.voyageai.com/v1",
}

LLM_PROVIDER_ENDPOINTS: dict[str, str] = {
    "OPENAI": "https://api.openai.com/v1",
}

RERANKER_PROVIDER_ENDPOINTS: dict[str, str] = {
    "COHERE": "https://api.cohere.com",
    "JINA": "https://api.jina.ai",
    "VOYAGE": "https://api.voyageai.com/v1",
}
