from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.llm_response import LLMResponse
from goodmem.models.good_mem_status import GoodMemStatus


class CreateLLMResponse(BaseModel):
    """Response containing the created LLM and any informational status messages"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    llm: LLMResponse = Field(description='The created LLM configuration')
    statuses: Optional[list[GoodMemStatus]] = Field(default=None, description='Optional status messages providing information about server-side operations performed during creation, such as capability inference results')

