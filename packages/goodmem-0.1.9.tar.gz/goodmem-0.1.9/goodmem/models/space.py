from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.space_embedder import SpaceEmbedder
from goodmem.models.chunking_configuration import ChunkingConfiguration


class Space(BaseModel):
    """A Space is a container for organizing related memories with vector embeddings."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    space_id: str = Field(description='The unique identifier for this space.', alias="spaceId")
    name: str = Field(description='The name of the space.')
    labels: Optional[dict] = Field(default=None, description='Key-value pairs of metadata associated with the space.')
    space_embedders: list[SpaceEmbedder] = Field(description='The list of embedders associated with this space.', alias="spaceEmbedders")
    created_at: int = Field(description='Timestamp when this space was created (milliseconds since epoch).', alias="createdAt")
    updated_at: int = Field(description='Timestamp when this space was last updated (milliseconds since epoch).', alias="updatedAt")
    owner_id: str = Field(description='The ID of the user who owns this space.', alias="ownerId")
    created_by_id: str = Field(description='The ID of the user who created this space.', alias="createdById")
    updated_by_id: str = Field(description='The ID of the user who last updated this space.', alias="updatedById")
    public_read: bool = Field(description='Whether this space is publicly readable by all users.', alias="publicRead")
    default_chunking_config: Optional[ChunkingConfiguration] = Field(default=None, description='Default chunking strategy for memories in this space', alias="defaultChunkingConfig")

