from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.embedder_response import EmbedderResponse


class ListEmbeddersResponse(BaseModel):
    """Response containing a list of embedders"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    embedders: list[EmbedderResponse] = Field(description='List of embedder configurations')

