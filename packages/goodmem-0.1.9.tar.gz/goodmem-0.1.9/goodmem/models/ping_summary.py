from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_endpoint_info import PingEndpointInfo


class PingSummary(BaseModel):
    """Summary emitted at the end of a ping session"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    endpoint: PingEndpointInfo = Field(description='Endpoint metadata copied from the final probe')
    requests: int = Field(description='Total number of probes scheduled')
    responses: int = Field(description='Number of responses received (including timeouts/errors)')
    ok: int = Field(description='Count of probes that succeeded')
    timeouts: int = Field(description='Count of probes that exceeded the timeout')
    errors: int = Field(description='Count of probes that failed for other reasons')
    rtt_min_ms: float = Field(description='Minimum observed round-trip latency (ms)', alias="rttMinMs")
    rtt_avg_ms: float = Field(description='Average observed round-trip latency (ms)', alias="rttAvgMs")
    rtt_p50_ms: float = Field(description='Median (p50) round-trip latency (ms)', alias="rttP50Ms")
    rtt_p90_ms: float = Field(description='90th percentile round-trip latency (ms)', alias="rttP90Ms")
    rtt_p99_ms: float = Field(description='99th percentile round-trip latency (ms)', alias="rttP99Ms")
    rtt_max_ms: float = Field(description='Maximum observed round-trip latency (ms)', alias="rttMaxMs")
    requests_per_second: float = Field(description='Effective request throughput across the session', alias="requestsPerSecond")
    bytes_per_second: float = Field(description='Aggregate bytes per second (send + receive)', alias="bytesPerSecond")
    applied_limits: Optional[dict] = Field(default=None, description='Resource limits applied by the server', alias="appliedLimits")

