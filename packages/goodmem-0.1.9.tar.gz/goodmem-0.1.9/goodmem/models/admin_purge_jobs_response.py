from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class AdminPurgeJobsResponse(BaseModel):
    """AdminPurgeJobsResponse"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    jobs_purged: int = Field(description='Number of background job rows removed, or that would be removed during dry-run.', alias="jobsPurged")
    attempts_purged: int = Field(description='Number of background job attempt rows removed.', alias="attemptsPurged")
    references_purged: int = Field(description='Number of background job reference rows removed.', alias="referencesPurged")
    dry_run: bool = Field(description='Whether the purge executed in dry-run mode.', alias="dryRun")

