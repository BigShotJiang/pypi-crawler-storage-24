from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.llm_provider_type import LLMProviderType
from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication
from goodmem.models.llm_capabilities import LLMCapabilities
from goodmem.models.llm_sampling_params import LLMSamplingParams


class LLMCreationRequest(BaseModel):
    """Request body for creating a new LLM. An LLM represents a configuration for text generation services."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    display_name: str = Field(description='User-facing name of the LLM', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the LLM')
    provider_type: LLMProviderType = Field(description='Type of LLM provider', alias="providerType")
    endpoint_url: str = Field(description='API endpoint base URL (OpenAI-compatible base, typically ends with /v1)', alias="endpointUrl")
    api_path: Optional[str] = Field(default=None, description='API path for chat/completions request (defaults to /chat/completions if not provided)', alias="apiPath")
    model_identifier: str = Field(description='Model identifier', alias="modelIdentifier")
    supported_modalities: Optional[list[Modality]] = Field(default=None, description='Supported content modalities (defaults to TEXT if not provided)', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload describing how to authenticate with the provider. Omit for deployments that do not require credentials.')
    labels: Optional[dict] = Field(default=None, description='User-defined labels for categorization')
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")
    capabilities: Optional[LLMCapabilities] = Field(default=None, description='LLM capabilities defining supported features and modes. Optional - server infers capabilities from model identifier if not provided.')
    default_sampling_params: Optional[LLMSamplingParams] = Field(default=None, description='Default sampling parameters for generation requests', alias="defaultSamplingParams")
    max_context_length: Optional[int] = Field(default=None, description='Maximum context window size in tokens', alias="maxContextLength")
    client_config: Optional[dict] = Field(default=None, description='Provider-specific client configuration as flexible JSON structure', alias="clientConfig")
    owner_id: Optional[str] = Field(default=None, description='Optional owner ID. If not provided, derived from the authentication context. Requires CREATE_LLM_ANY permission if specified.', alias="ownerId")
    llm_id: Optional[str] = Field(default=None, description='Optional client-provided UUID for idempotent creation. If not provided, server generates a new UUID. Returns ALREADY_EXISTS if ID is already in use.', alias="llmId")

