from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.active_license_metadata import ActiveLicenseMetadata


class AdminReloadLicenseResponse(BaseModel):
    """AdminReloadLicenseResponse"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    status: Optional[str] = Field(default=None, description='Outcome of the reload attempt, such as LOADED, UNCHANGED, FAILED, or NOT_FOUND.')
    message: Optional[str] = Field(default=None, description='Human-readable message describing the reload result.')
    active_license: Optional[ActiveLicenseMetadata] = Field(default=None, description='Metadata for the currently active license after reload, or null if no license is active.', alias="activeLicense")

