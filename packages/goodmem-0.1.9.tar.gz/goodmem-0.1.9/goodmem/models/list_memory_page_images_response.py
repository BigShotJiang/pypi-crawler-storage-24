from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.memory_page_image import MemoryPageImage


class ListMemoryPageImagesResponse(BaseModel):
    """Page of memory page-image metadata"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    page_images: list[MemoryPageImage] = Field(description='Page-image metadata rows', alias="pageImages")
    next_token: Optional[str] = Field(default=None, description='Opaque token for retrieving the next page', alias="nextToken")

