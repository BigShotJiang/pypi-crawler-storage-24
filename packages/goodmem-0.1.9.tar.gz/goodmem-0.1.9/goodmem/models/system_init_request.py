from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class SystemInitRequest(BaseModel):
    """Request for initializing the system. No parameters required."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    pass

