from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class ActiveLicenseMetadata(BaseModel):
    """ActiveLicenseMetadata"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    filename: Optional[str] = Field(default=None, description='Filename of the active license on disk.')
    sha256: Optional[str] = Field(default=None, description='Hex-encoded SHA-256 hash of the active license file.')
    size_bytes: int = Field(description='Size of the active license file in bytes.', alias="sizeBytes")
    modified_at: Optional[str] = Field(default=None, description='Last modification timestamp of the active license file.', alias="modifiedAt")

