from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.memory_chunk_response import MemoryChunkResponse


class ChunkReference(BaseModel):
    """Reference to a memory chunk with pointer to its parent memory"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    result_set_id: str = Field(description='Result set ID that produced this chunk', alias="resultSetId")
    chunk: MemoryChunkResponse = Field(description='The memory chunk data')
    memory_index: int = Field(description="Index of the chunk's memory in the client's memories array", alias="memoryIndex")
    relevance_score: float = Field(description='Relevance score for this chunk (0.0 to 1.0)', alias="relevanceScore")

