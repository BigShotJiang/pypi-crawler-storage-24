from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.filtered_delete_memory_selector_request import FilteredDeleteMemorySelectorRequest


class BatchDeleteMemorySelectorRequest(BaseModel):
    """A single delete selector: either memoryId or filterSelector"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memory_id: Optional[str] = Field(default=None, description='Deletes one specific memory by UUID', alias="memoryId")
    filter_selector: Optional[FilteredDeleteMemorySelectorRequest] = Field(default=None, description='Deletes a filtered set of memories within a specific space', alias="filterSelector")

