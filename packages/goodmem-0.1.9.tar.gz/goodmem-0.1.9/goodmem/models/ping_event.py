from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_result import PingResult
from goodmem.models.ping_summary import PingSummary
from goodmem.models.ping_notice import PingNotice


class PingEvent(BaseModel):
    """Streaming event from a ping session"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    result: Optional[PingResult] = Field(default=None, description='Probe result event')
    summary: Optional[PingSummary] = Field(default=None, description='Summary emitted at session completion')
    notice: Optional[PingNotice] = Field(default=None, description='Non-fatal notice emitted during session')

