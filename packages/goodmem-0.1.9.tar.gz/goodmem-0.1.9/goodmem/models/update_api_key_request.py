from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class UpdateApiKeyRequest(BaseModel):
    """Request parameters for updating an API key."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    status: Optional[str] = Field(default=None, description='New status for the API key. Allowed values: ACTIVE, INACTIVE.')
    replace_labels: Optional[dict] = Field(default=None, description='Replace all existing labels with this set. Mutually exclusive with mergeLabels.', alias="replaceLabels")
    merge_labels: Optional[dict] = Field(default=None, description='Merge these labels with existing ones. Mutually exclusive with replaceLabels.', alias="mergeLabels")

