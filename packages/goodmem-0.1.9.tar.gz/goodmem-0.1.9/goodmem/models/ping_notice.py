from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class PingNotice(BaseModel):
    """Non-fatal notice emitted during a ping session"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    code: str = Field(description='Machine-readable notice identifier')
    message: str = Field(description='Human-readable notice message')
    details: Optional[dict] = Field(default=None, description='Additional contextual details')

