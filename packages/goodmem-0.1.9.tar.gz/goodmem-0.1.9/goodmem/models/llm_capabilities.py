from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class LLMCapabilities(BaseModel):
    """Capabilities and features supported by an LLM service"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    supports_chat: Optional[bool] = Field(default=None, description='Supports conversational/chat completion format with message roles', alias="supportsChat")
    supports_completion: Optional[bool] = Field(default=None, description='Supports raw text completion with prompt continuation', alias="supportsCompletion")
    supports_function_calling: Optional[bool] = Field(default=None, description='Supports function/tool calling with structured responses', alias="supportsFunctionCalling")
    supports_system_messages: Optional[bool] = Field(default=None, description='Supports system prompts to define model behavior and context', alias="supportsSystemMessages")
    supports_streaming: Optional[bool] = Field(default=None, description='Supports real-time token streaming during generation', alias="supportsStreaming")
    supports_sampling_parameters: Optional[bool] = Field(default=None, description='Supports sampling parameters like temperature, top_p, and top_k for generation control', alias="supportsSamplingParameters")

