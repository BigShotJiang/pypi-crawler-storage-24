from __future__ import annotations

from enum import Enum


class Modality(str, Enum):
    """Content modality types supported by embedders"""

    TEXT = 'TEXT'
    IMAGE = 'IMAGE'
    AUDIO = 'AUDIO'
    VIDEO = 'VIDEO'

