from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.reranker_response import RerankerResponse


class ListRerankersResponse(BaseModel):
    """Response containing a list of rerankers"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    rerankers: list[RerankerResponse] = Field(description='List of reranker configurations')

