from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_endpoint_info import PingEndpointInfo
from goodmem.models.ping_timing import PingTiming


class PingResult(BaseModel):
    """Result from an individual ping probe"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    endpoint: PingEndpointInfo = Field(description='Resolved endpoint metadata for the target')
    seq: int = Field(description='Sequential probe number (1-based)')
    bytes_sent: int = Field(description='Payload bytes transmitted', alias="bytesSent")
    bytes_received: int = Field(description='Payload bytes received', alias="bytesReceived")
    ok: bool = Field(description='True when the provider responded successfully within the timeout')
    http_status: int = Field(description='Provider HTTP status code or equivalent transport status', alias="httpStatus")
    error_message: Optional[str] = Field(default=None, description='Human-readable error message when ok=false', alias="errorMessage")
    rtt_ms: float = Field(description='Observed round-trip latency in milliseconds', alias="rttMs")
    timing: PingTiming = Field(description='Raw timing data recorded on the server')
    metadata: Optional[dict] = Field(default=None, description='Additional provider metadata (request IDs, throttling signals, etc.)')

