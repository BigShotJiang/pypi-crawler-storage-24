from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.binary_content import BinaryContent


class ContextItem(BaseModel):
    """Context item with either text or binary content."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    text: Optional[str] = Field(default=None, description='Text content for this context item.')
    binary: Optional[BinaryContent] = Field(default=None, description='Binary content for this context item.')

