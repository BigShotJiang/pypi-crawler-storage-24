from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class AbstractReply(BaseModel):
    """Generated abstractive reply with relevance information"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    text: str = Field(description='Generated abstractive reply text')
    relevance_score: float = Field(description='Relevance score for this reply (0.0 to 1.0)', alias="relevanceScore")
    result_set_id: Optional[str] = Field(default=None, description='Optional result set ID linking this abstract to a specific result set', alias="resultSetId")

