from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class BatchMemoryRetrievalRequest(BaseModel):
    """Request body for retrieving multiple memories by their IDs"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memory_ids: list[str] = Field(description='Array of memory IDs to retrieve', alias="memoryIds")
    include_content: Optional[bool] = Field(default=None, description='Whether to include the original content in the response', alias="includeContent")
    include_processing_history: Optional[bool] = Field(default=None, description='Whether to include background job processing history for each memory', alias="includeProcessingHistory")

