from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class LLMSamplingParams(BaseModel):
    """Sampling and generation parameters for controlling LLM text output"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    max_tokens: Optional[int] = Field(default=None, description='Maximum tokens to generate (>0 if set; provider-dependent limits apply)', alias="maxTokens")
    temperature: Optional[float] = Field(default=None, description='Sampling temperature 0.0-2.0 (0.0=deterministic, 2.0=highly random)')
    top_p: Optional[float] = Field(default=None, description='Nucleus sampling threshold 0.0-1.0 (smaller values focus on higher probability tokens)', alias="topP")
    top_k: Optional[int] = Field(default=None, description='Top-k sampling limit (>0 if set; primarily for local/open-source models)', alias="topK")
    frequency_penalty: Optional[float] = Field(default=None, description='Frequency penalty -2.0 to 2.0 (positive values reduce repetition based on frequency)', alias="frequencyPenalty")
    presence_penalty: Optional[float] = Field(default=None, description='Presence penalty -2.0 to 2.0 (positive values encourage topic diversity)', alias="presencePenalty")
    stop_sequences: Optional[list[str]] = Field(default=None, description='Generation stop sequences (≤10 sequences; each ≤100 chars; generation halts on exact match)', alias="stopSequences")

