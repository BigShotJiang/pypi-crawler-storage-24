from __future__ import annotations

from enum import Enum


class ProviderType(str, Enum):
    """Embedding provider types"""

    OPENAI = 'OPENAI'
    VLLM = 'VLLM'
    TEI = 'TEI'
    LLAMA_CPP = 'LLAMA_CPP'
    VOYAGE = 'VOYAGE'
    COHERE = 'COHERE'
    JINA = 'JINA'

