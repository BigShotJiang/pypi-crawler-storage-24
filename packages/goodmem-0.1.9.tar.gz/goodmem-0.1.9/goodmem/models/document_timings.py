from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class DocumentTimings(BaseModel):
    """Aggregate timing statistics for an OCR request."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    wall_time_ms: int = Field(description='End-to-end request time (ms)', alias="wallTimeMs")
    sum_queue_wait_ms: int = Field(description='Sum of per-page queue wait times (ms)', alias="sumQueueWaitMs")
    sum_render_ms: int = Field(description='Sum of per-page render times (ms)', alias="sumRenderMs")
    sum_ocr_ms: int = Field(description='Sum of per-page OCR times (ms)', alias="sumOcrMs")
    sum_page_total_ms: int = Field(description='Sum of per-page total times (ms)', alias="sumPageTotalMs")

