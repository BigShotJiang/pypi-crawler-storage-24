from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.secret_reference import SecretReference


class ApiKeyAuth(BaseModel):
    """Configuration for classic API-key authentication."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    inline_secret: Optional[str] = Field(default=None, description='Secret stored directly in GoodMem (mutually exclusive with secretRef)', alias="inlineSecret")
    secret_ref: Optional[SecretReference] = Field(default=None, description='Reference to an external secret manager entry (mutually exclusive with inlineSecret)', alias="secretRef")
    header_name: Optional[str] = Field(default=None, description='Desired HTTP header to carry the credential (defaults to Authorization)', alias="headerName")
    prefix: Optional[str] = Field(default=None, description='Optional prefix prepended to the secret (e.g., "Bearer ")')

