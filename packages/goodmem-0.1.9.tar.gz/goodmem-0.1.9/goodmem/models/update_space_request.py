from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class UpdateSpaceRequest(BaseModel):
    """Request parameters for updating a space."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    name: Optional[str] = Field(default=None, description='The new name for the space.')
    public_read: Optional[bool] = Field(default=None, description='Whether the space is publicly readable by all users.', alias="publicRead")
    replace_labels: Optional[dict] = Field(default=None, description='Labels to replace all existing labels. Mutually exclusive with mergeLabels.', alias="replaceLabels")
    merge_labels: Optional[dict] = Field(default=None, description='Labels to merge with existing labels. Mutually exclusive with replaceLabels.', alias="mergeLabels")

