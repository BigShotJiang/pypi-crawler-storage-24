from __future__ import annotations

from enum import Enum


class PingTargetType(str, Enum):
    """Target types for ping operations"""

    TARGET_TYPE_UNSPECIFIED = 'TARGET_TYPE_UNSPECIFIED'
    EMBEDDER = 'EMBEDDER'
    RERANKER = 'RERANKER'
    LLM = 'LLM'

