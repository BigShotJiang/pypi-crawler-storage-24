from __future__ import annotations

from enum import Enum


class OcrInputFormat(str, Enum):
    """OCR input format hint."""

    AUTO = 'AUTO'
    PDF = 'PDF'
    TIFF = 'TIFF'
    PNG = 'PNG'
    JPEG = 'JPEG'
    BMP = 'BMP'

