from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.separator_keep_strategy import SeparatorKeepStrategy
from goodmem.models.length_measurement import LengthMeasurement


class RecursiveChunkingConfiguration(BaseModel):
    """Recursive hierarchical chunking strategy with configurable separators and overlap"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    chunk_size: int = Field(description='Maximum size of a chunk (should be ≤ context window)', alias="chunkSize")
    chunk_overlap: int = Field(description='Sliding overlap between chunks', alias="chunkOverlap")
    separators: Optional[list[str]] = Field(default=None, description='Hierarchical separator list (order = preference)')
    keep_strategy: SeparatorKeepStrategy = Field(description='How to handle separators after splitting. KEEP_NONE is deprecated and behaves as KEEP_END.', alias="keepStrategy")
    separator_is_regex: Optional[bool] = Field(default=None, description='Whether separators are regex patterns', alias="separatorIsRegex")
    length_measurement: LengthMeasurement = Field(description='How to measure chunk length', alias="lengthMeasurement")

