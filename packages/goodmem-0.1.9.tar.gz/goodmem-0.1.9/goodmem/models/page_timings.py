from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class PageTimings(BaseModel):
    """Per-page timing breakdown for OCR processing."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    queue_wait_ms: int = Field(description='Time spent waiting in the render queue (ms)', alias="queueWaitMs")
    render_ms: int = Field(description='Time spent rendering the page image (ms)', alias="renderMs")
    ocr_ms: int = Field(description='Time spent running OCR (ms)', alias="ocrMs")
    total_ms: int = Field(description='Total page processing time (ms)', alias="totalMs")

