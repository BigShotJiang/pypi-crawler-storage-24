from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class BinaryContent(BaseModel):
    """Binary content with MIME type for context items."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    content_type: str = Field(description='MIME type of the binary content.', alias="contentType")
    data: str = Field(description='Base64-encoded binary data.')

