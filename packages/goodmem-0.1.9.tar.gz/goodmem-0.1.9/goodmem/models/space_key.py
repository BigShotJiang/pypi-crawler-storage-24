from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.embedder_weight import EmbedderWeight


class SpaceKey(BaseModel):
    """Space configuration for retrieval operations with optional embedder weight overrides."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    space_id: str = Field(description='The unique identifier for the space to search.', alias="spaceId")
    embedder_weights: Optional[list[EmbedderWeight]] = Field(default=None, description='Optional per-embedder weight overrides for this space. If not specified, database defaults are used.', alias="embedderWeights")
    filter: Optional[str] = Field(default=None, description='Optional filter expression that must evaluate to true for memories in this space.')

