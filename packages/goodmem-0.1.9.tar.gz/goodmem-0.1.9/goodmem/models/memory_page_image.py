from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class MemoryPageImage(BaseModel):
    """Metadata for one memory page-image rendition"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memory_id: str = Field(description='Memory UUID', alias="memoryId")
    page_index: int = Field(description='0-based page index', alias="pageIndex")
    dpi: int = Field(description='Render DPI')
    content_type: str = Field(description='Image MIME type', alias="contentType")
    image_content_length: Optional[int] = Field(default=None, description='Image byte length', alias="imageContentLength")
    image_content_sha256: Optional[str] = Field(default=None, description='Hex-encoded SHA-256 digest of image content', alias="imageContentSha256")
    created_at: int = Field(description='Creation timestamp (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Last update timestamp (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='Creator user UUID', alias="createdById")
    updated_by_id: str = Field(description='Last updater user UUID', alias="updatedById")

