from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.result_set_boundary import ResultSetBoundary
from goodmem.models.abstract_reply import AbstractReply
from goodmem.models.retrieved_item import RetrievedItem
from goodmem.models.memory import Memory
from goodmem.models.good_mem_status import GoodMemStatus


class RetrieveMemoryEvent(BaseModel):
    """Streaming event from memory retrieval operation"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    result_set_boundary: Optional[ResultSetBoundary] = Field(default=None, description='Result set boundary marker (BEGIN/END)', alias="resultSetBoundary")
    abstract_reply: Optional[AbstractReply] = Field(default=None, description='Generated abstractive reply', alias="abstractReply")
    retrieved_item: Optional[RetrievedItem] = Field(default=None, description='A retrieved memory or chunk', alias="retrievedItem")
    memory_definition: Optional[Memory] = Field(default=None, description="Memory object to add to client's memories array", alias="memoryDefinition")
    status: Optional[GoodMemStatus] = Field(default=None, description='Warning or non-fatal status with granular codes (operation continues)')

