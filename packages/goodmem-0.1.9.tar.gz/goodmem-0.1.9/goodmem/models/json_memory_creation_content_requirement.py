from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict



class JsonMemoryCreationContentRequirement(BaseModel):
    """Application/json memory creation requires exactly one of originalContent or originalContentB64."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    pass

