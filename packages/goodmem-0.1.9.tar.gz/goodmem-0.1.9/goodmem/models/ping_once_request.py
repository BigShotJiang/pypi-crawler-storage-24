from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_target_type import PingTargetType
from goodmem.models.ping_payload_type import PingPayloadType


class PingOnceRequest(BaseModel):
    """Request payload for a single ping probe"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    target_id: str = Field(description='Target resource ID (UUID)', alias="targetId")
    target_type_hint: Optional[PingTargetType] = Field(default=None, description='Optional hint for the target resource type', alias="targetTypeHint")
    payload_type: Optional[PingPayloadType] = Field(default=None, description='Desired payload type (defaults to provider-specific value)', alias="payloadType")
    payload: Optional[str] = Field(default=None, description='Explicit UTF-8 payload to send with the probe (mutually exclusive with payloadSizeBytes)')
    payload_size_bytes: Optional[int] = Field(default=None, description='Synthetic payload size in bytes (mutually exclusive with payload)', alias="payloadSizeBytes")
    timeout_ms: Optional[int] = Field(default=None, description='Per-probe timeout in milliseconds (0 uses server default)', alias="timeoutMs")

