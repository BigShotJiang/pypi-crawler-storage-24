from __future__ import annotations

from enum import Enum


class OcrCategory(str, Enum):
    """Normalized OCR layout category."""

    UNSPECIFIED = 'UNSPECIFIED'
    CAPTION = 'CAPTION'
    FOOTNOTE = 'FOOTNOTE'
    FORMULA = 'FORMULA'
    LIST_ITEM = 'LIST_ITEM'
    PAGE_FOOTER = 'PAGE_FOOTER'
    PAGE_HEADER = 'PAGE_HEADER'
    PICTURE = 'PICTURE'
    SECTION_HEADER = 'SECTION_HEADER'
    TABLE = 'TABLE'
    TEXT = 'TEXT'
    TITLE = 'TITLE'
    OTHER = 'OTHER'
    UNKNOWN = 'UNKNOWN'

