from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class BackgroundJobSummary(BaseModel):
    """Summary of the most recent background job execution for a resource"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    job_id: int = Field(description='Database identifier of the background job', alias="jobId")
    job_type: str = Field(description='Logical job type dispatched by the background job framework', alias="jobType")
    status: str = Field(description='Current status of the background job')
    attempts: int = Field(description='Number of attempts started so far')
    max_attempts: int = Field(description='Maximum number of attempts allowed for this job', alias="maxAttempts")
    run_at: Optional[int] = Field(default=None, description='Timestamp when the job becomes eligible to run (milliseconds since epoch)', alias="runAt")
    lease_until: Optional[int] = Field(default=None, description='Lease expiration timestamp if the job is currently running (milliseconds since epoch)', alias="leaseUntil")
    locked_by: Optional[str] = Field(default=None, description='Identifier of the worker currently holding the lease, if any', alias="lockedBy")
    last_error: Optional[str] = Field(default=None, description='Most recent short error message if the job failed', alias="lastError")
    updated_at: Optional[int] = Field(default=None, description='Timestamp when the job row was last updated (milliseconds since epoch)', alias="updatedAt")

