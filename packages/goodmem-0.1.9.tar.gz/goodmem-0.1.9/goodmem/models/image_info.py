from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class ImageInfo(BaseModel):
    """Rendered image metadata for an OCR page."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    width_px: int = Field(description='Rendered image width in pixels', alias="widthPx")
    height_px: int = Field(description='Rendered image height in pixels', alias="heightPx")
    dpi: int = Field(description='Rendering DPI')

