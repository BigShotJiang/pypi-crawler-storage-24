from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class AdminDrainResponse(BaseModel):
    """AdminDrainResponse"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    state: Optional[str] = Field(default=None, description='Lifecycle state reported after the drain request was processed.')
    quiesced: bool = Field(description='Whether the server has reached the QUIESCED lifecycle state.')
    message: Optional[str] = Field(default=None, description='Human-readable status message describing the drain outcome.')

