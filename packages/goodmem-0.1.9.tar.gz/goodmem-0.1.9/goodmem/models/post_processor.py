from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class PostProcessor(BaseModel):
    """Post-processor configuration for transforming retrieval results. Custom processors are discovered from installed extensions and must be referenced by their fully qualified factory class name. See https://docs.goodmem.ai/docs/reference/post-processors/chat-post-processor/ for the built-in ChatPostProcessor configuration."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    name: str = Field(description='Fully qualified factory class name of the post-processor to apply.')
    config: Optional[dict] = Field(default=None, description='Configuration parameters for the post-processor. Fields depend on the selected processor; see the linked documentation for the built-in ChatPostProcessor schema.')

