from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_target_type import PingTargetType


class PingEndpointInfo(BaseModel):
    """Resolved endpoint metadata for ping responses"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    target_type: PingTargetType = Field(description='Resolved resource type', alias="targetType")
    target_id: str = Field(description='Target resource ID (UUID)', alias="targetId")
    resolved_endpoint: str = Field(description='Fully resolved endpoint URL used for the probe', alias="resolvedEndpoint")
    provider: str = Field(description='Provider name backing the resource')
    model_identifier: str = Field(description='Provider-specific model identifier', alias="modelIdentifier")

