from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.memory import Memory
from goodmem.models.error_detail import ErrorDetail


class BatchMemoryResult(BaseModel):
    """Individual item result for a batch memories operation"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    success: bool = Field(description='Whether this individual operation succeeded')
    memory_id: Optional[str] = Field(default=None, description='Memory ID associated with this result (present for batchGet errors and batchDelete results)', alias="memoryId")
    memory: Optional[Memory] = Field(default=None, description='Created or retrieved memory (present when the operation returns a memory on success)')
    error: Optional[ErrorDetail] = Field(default=None, description='Error details when success is false')

