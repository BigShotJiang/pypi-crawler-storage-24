from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class RpcStatus(BaseModel):
    """Status payload for per-page OCR errors."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    code: int = Field(description='gRPC status code as defined by google.rpc.Code')
    message: Optional[str] = Field(default=None, description='Human-readable error message')

