from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class SystemInitResponse(BaseModel):
    """Response from the system initialization endpoint."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    already_initialized: bool = Field(description='Indicates whether the system was already initialized before this request.', alias="alreadyInitialized")
    message: str = Field(description='A human-readable message about the initialization status.')
    root_api_key: Optional[str] = Field(default=None, description='The API key for the root user. Only present if system was just initialized (not previously initialized).', alias="rootApiKey")
    user_id: Optional[str] = Field(default=None, description='The user ID of the root user. Only present if system was just initialized (not previously initialized).', alias="userId")

