from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class NoChunkingConfiguration(BaseModel):
    """No chunking strategy - preserves original content as a single unit"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    pass

