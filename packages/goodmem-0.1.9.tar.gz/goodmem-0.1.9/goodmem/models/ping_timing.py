from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class PingTiming(BaseModel):
    """Timing information captured during a ping probe"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    client_send_time_unix_nanos: int = Field(description='Client send time (Unix epoch nanoseconds)', alias="clientSendTimeUnixNanos")
    server_received_time_unix_nanos: int = Field(description='Server received time (Unix epoch nanoseconds)', alias="serverReceivedTimeUnixNanos")
    server_send_time_unix_nanos: int = Field(description='Server send time (Unix epoch nanoseconds)', alias="serverSendTimeUnixNanos")
    client_receive_time_unix_nanos: int = Field(description='Client receive time (Unix epoch nanoseconds)', alias="clientReceiveTimeUnixNanos")

