from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class SystemInfoResponse(BaseModel):
    """SystemInfoResponse"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    version: Optional[str] = Field(default=None, description='Semantic version string advertised by the running server.')
    major: int = Field(description='Major version component parsed from the advertised semantic version.')
    minor: int = Field(description='Minor version component parsed from the advertised semantic version.')
    patch: int = Field(description='Patch version component parsed from the advertised semantic version.')
    dirty: bool = Field(description='Whether the running build reports uncommitted workspace changes.')
    git_commit: Optional[str] = Field(default=None, description='Git commit SHA baked into the build, when available.', alias="gitCommit")
    git_describe: Optional[str] = Field(default=None, description='Git describe output baked into the build, when available.', alias="gitDescribe")
    build_time: Optional[str] = Field(default=None, description='Build timestamp recorded for this server binary, when available.', alias="buildTime")
    capabilities: Optional[dict] = Field(default=None, description='Optional capability flags or metadata advertised by the running server.')

