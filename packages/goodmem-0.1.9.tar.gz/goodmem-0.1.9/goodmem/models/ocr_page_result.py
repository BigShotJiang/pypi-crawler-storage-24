from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ocr_page import OcrPage
from goodmem.models.rpc_status import RpcStatus


class OcrPageResult(BaseModel):
    """Per-page OCR result containing output or error status."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    page_index: int = Field(description='0-based page index', alias="pageIndex")
    page: Optional[OcrPage] = Field(default=None, description='OCR output for the page')
    status: Optional[RpcStatus] = Field(default=None, description='Error status for the page')

