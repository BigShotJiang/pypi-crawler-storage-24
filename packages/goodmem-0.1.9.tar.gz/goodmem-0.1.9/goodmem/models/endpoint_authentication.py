from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.credential_kind import CredentialKind
from goodmem.models.api_key_auth import ApiKeyAuth
from goodmem.models.gcp_adc_auth import GcpAdcAuth


class EndpointAuthentication(BaseModel):
    """Structured credential payload describing how GoodMem should authenticate with an upstream provider."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    kind: CredentialKind = Field(description='Selected credential strategy')
    api_key: Optional[ApiKeyAuth] = Field(default=None, description='Configuration when kind is CREDENTIAL_KIND_API_KEY', alias="apiKey")
    gcp_adc: Optional[GcpAdcAuth] = Field(default=None, description='Configuration when kind is CREDENTIAL_KIND_GCP_ADC', alias="gcpAdc")
    labels: Optional[dict] = Field(default=None, description='Optional annotations to aid operators (e.g., "owner=vertex")')

