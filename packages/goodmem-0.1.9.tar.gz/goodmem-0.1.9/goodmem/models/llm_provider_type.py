from __future__ import annotations

from enum import Enum


class LLMProviderType(str, Enum):
    """LLM provider types"""

    OPENAI = 'OPENAI'
    LITELLM_PROXY = 'LITELLM_PROXY'
    OPEN_ROUTER = 'OPEN_ROUTER'
    VLLM = 'VLLM'
    OLLAMA = 'OLLAMA'
    LLAMA_CPP = 'LLAMA_CPP'
    CUSTOM_OPENAI_COMPATIBLE = 'CUSTOM_OPENAI_COMPATIBLE'

