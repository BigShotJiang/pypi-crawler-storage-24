from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.memory import Memory
from goodmem.models.chunk_reference import ChunkReference


class RetrievedItem(BaseModel):
    """A retrieved result that can be either a Memory or MemoryChunk"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    memory: Optional[Memory] = Field(default=None, description='Complete memory object (if retrieved)')
    chunk: Optional[ChunkReference] = Field(default=None, description='Reference to a memory chunk (if retrieved)')

