from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.provider_type import ProviderType
from goodmem.models.distribution_type import DistributionType
from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication


class EmbedderResponse(BaseModel):
    """Embedder configuration information"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    embedder_id: str = Field(description='Unique identifier of the embedder', alias="embedderId")
    display_name: str = Field(description='User-facing name of the embedder', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the embedder')
    provider_type: ProviderType = Field(description='Type of embedding provider', alias="providerType")
    endpoint_url: str = Field(description='API endpoint URL', alias="endpointUrl")
    api_path: str = Field(description='API path for embeddings request', alias="apiPath")
    model_identifier: str = Field(description='Model identifier', alias="modelIdentifier")
    dimensionality: int = Field(description='Output vector dimensions')
    distribution_type: DistributionType = Field(description='Type of embedding distribution (DENSE or SPARSE)', alias="distributionType")
    max_sequence_length: Optional[int] = Field(default=None, description='Maximum input sequence length', alias="maxSequenceLength")
    supported_modalities: Optional[list[Modality]] = Field(default=None, description='Supported content modalities', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload used for upstream authentication')
    labels: Optional[dict] = Field(default=None, description='User-defined labels for categorization')
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")
    owner_id: str = Field(description='Owner ID of the embedder', alias="ownerId")
    created_at: int = Field(description='Creation timestamp (milliseconds since epoch)', alias="createdAt")
    updated_at: int = Field(description='Last update timestamp (milliseconds since epoch)', alias="updatedAt")
    created_by_id: str = Field(description='ID of the user who created the embedder', alias="createdById")
    updated_by_id: str = Field(description='ID of the user who last updated the embedder', alias="updatedById")

