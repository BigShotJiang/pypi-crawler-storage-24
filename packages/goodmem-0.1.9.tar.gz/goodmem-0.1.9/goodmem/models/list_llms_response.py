from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.llm_response import LLMResponse


class ListLLMsResponse(BaseModel):
    """Response containing a list of LLM configurations"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())

    llms: list[LLMResponse] = Field(description='List of LLM configurations matching the request filters')

