from __future__ import annotations

from enum import Enum


class PingPayloadType(str, Enum):
    """Payload types supported by ping operations"""

    PAYLOAD_TYPE_UNSPECIFIED = 'PAYLOAD_TYPE_UNSPECIFIED'
    TEXT = 'TEXT'
    JSON = 'JSON'
    BINARY = 'BINARY'

