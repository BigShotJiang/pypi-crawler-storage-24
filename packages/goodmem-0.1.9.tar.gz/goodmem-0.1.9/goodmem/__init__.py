"""GoodMem Python SDK.

The main entry points are :class:`Goodmem` (synchronous) and
:class:`AsyncGoodmem` (async). Both expose the same namespace attributes
(``embedders``, ``memories``, ``spaces``, etc.) and raise typed exceptions
from :mod:`goodmem.errors` on non-2xx responses.

Quickstart::

    from goodmem import Goodmem

    with Goodmem(base_url="http://localhost:8080", api_key="gm_...") as client:
        space = client.spaces.create(display_name="My Space")
        client.memories.create(space_id=space.space_id, original_content="Hello world")
        results = client.memories.retrieve(message="hello", space_ids=[space.space_id])
"""

from goodmem.client import AsyncGoodmem, Goodmem
from goodmem.errors import (
    APIError,
    AuthenticationError,
    ConflictError,
    GoodMemError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
)

__all__ = [
    "Goodmem",
    "AsyncGoodmem",
    "GoodMemError",
    "APIError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
]
