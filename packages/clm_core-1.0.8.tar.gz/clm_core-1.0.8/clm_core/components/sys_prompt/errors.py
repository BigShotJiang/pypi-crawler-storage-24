class TemplateBindingError(Exception):
    pass
