__all__ = ["__version__", "__version_tuple__", "version", "version_tuple"]

__version__ = version = '0.16'
__version_tuple__ = version_tuple = (0, 16, 0)
