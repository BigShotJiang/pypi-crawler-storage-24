"""
Plugin to kill the TCP transport and force a reconnect.
Useful on bad connections when you want to discard a broken link and
connect a gain. Best used with ``enable_smacks`` set to true.

Usage
-----

.. glossary::

    /tcp-reconnect

        Close the TCP connection abruptly to force a reconnect.
"""

from poezio.plugin import BasePlugin


class Plugin(BasePlugin):
    def init(self):
        self.api.add_command(
            'tcp-reconnect',
            self.reconnect,
            help='Trigger a reconnection by killing the TCP link.',
        )

    def reconnect(self, arg=None):
        self.core.xmpp.transport.abort()
