from setuptools import setup, find_packages

setup(
    name="prompt_eng",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={"prompt_eng": ["data.txt"]},
)
