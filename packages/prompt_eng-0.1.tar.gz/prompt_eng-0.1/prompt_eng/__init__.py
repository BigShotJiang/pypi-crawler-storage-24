from importlib.resources import files
print(files("prompt_eng").joinpath("data.txt").read_text())
