# rye:signed:2026-03-17T01:41:08Z:c6f8f7f88b27ff48a79ca171332102e1a92985ebdc3aaf5777525b1aa3bdf445:AzTmpCY_myIPpGCY9fKHKgP9CZAlGOfIkWiUKNr1RzpWFjTU5BEfXaLwNAeZhUd3-Z3koDf-KxsN-ArhqbNhDQ==:6ea18199041a1ea8
"""Parser tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/parsers"
__tool_description__ = "Parser tools package"
