# doja_sdk/exceptions.py

class DojaSDKException(Exception):
    """Base exception for all DoJa SDK errors"""
    pass

class DojaAuthError(DojaSDKException):
    """Raised when the DoJa license validation fails (Invalid token, expired, etc.)"""
    pass

class DojaAPIError(DojaSDKException):
    """Raised when the WhatsApp Cloud API returns an error response"""
    def __init__(self, message, status_code=None, raw_response=None):
        super().__init__(message)
        self.status_code = status_code
        self.raw_response = raw_response
