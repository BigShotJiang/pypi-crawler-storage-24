<!-- AUTO-GENERATED FILE. EDIT ai/policy/* OR ai/agents/roles.yaml INSTEAD. -->
# Repo Policy: snapy

This file is generated for Claude.

## This Repo Owns
- climate_model
- orchestration
- coupled_workflows

## Inspect This Repo First When
- model integration
- workflow composition
- high-level simulation logic

## Guardrails
- Modify this repo only when it is the primary repo for the task.
- Read neighboring tests and examples before making changes.
- For behavior changes, add or update tests when feasible, run the relevant validation command, and explain if no automated test was possible.
- Summaries must include the exact validation command and result.
- Report cross-repo compatibility risks in your summary.
