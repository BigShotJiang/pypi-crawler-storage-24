from .api import merge_obj_to_atlas

__all__ = ["merge_obj_to_atlas"]
