import re

# ── Comment patterns ──────────────────────────────────────────────────────────
SINGLE_COMMENT = re.compile(rb"^\s*(#|//|--|<!--|%|;)")
MULTI_START    = re.compile(rb'(/\*|"""|\'\'\'|<!--)')
MULTI_END      = re.compile(rb'(\*/|"""|\'\'\'|-->)')

# ── Function / class patterns ─────────────────────────────────────────────────
PY_DEF       = re.compile(rb"^\s*def\s+(\w+)\s*\(")
PY_ASYNC_DEF = re.compile(rb"^\s*async\s+def\s+(\w+)\s*\(")
CLASS_DEF    = re.compile(rb"^\s*class\s+(\w+)")
JS_FUNC      = re.compile(rb"\bfunction\s+(\w+)\s*\(")
ARROW_FUNC   = re.compile(rb"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(.*?\)\s*=>")

# ── Endpoint patterns ─────────────────────────────────────────────────────────
ENDPOINT_DEC  = re.compile(
    rb"@\s*(app|router)\.(get|post|put|delete|patch|options|head)\s*\("
)
ADD_API_ROUTE = re.compile(rb"\.(add_api_route)\s*\(")
EXPRESS_ROUTE = re.compile(
    rb"\b(app|router)\.(get|post|put|delete|patch)\s*\(\s*['\"]([^'\"]+)['\"]"
)

# ── Annotation / import patterns ──────────────────────────────────────────────
TODO_COMMENT = re.compile(rb"#.*\b(TODO|FIXME|HACK|XXX|BUG|NOTE)\b", re.IGNORECASE)
IMPORT_PY    = re.compile(rb"^\s*(?:import|from)\s+([\w.]+)")
IMPORT_JS    = re.compile(rb"""^\s*import\s+.*?\s+from\s+['"]([^'"]+)['"]""")
REQUIRE_JS   = re.compile(rb"""require\s*\(\s*['"]([^'"]+)['"]\s*\)""")

# ── Thresholds ────────────────────────────────────────────────────────────────
LONG_LINE_LIMIT = 100

# ── Supported file extensions ─────────────────────────────────────────────────
TEXT_EXT: set[str] = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".go", ".rs",
    ".cs", ".php", ".rb", ".kt", ".swift", ".sql", ".sh",
    ".yml", ".yaml", ".toml", ".json", ".md", ".html", ".css",
    ".scss", ".sass", ".less", ".vue", ".svelte", ".c", ".cpp",
    ".h", ".hpp",
}

# ── Directories to skip ───────────────────────────────────────────────────────
IGNORE_DIRS: set[str] = {
    ".git", "__pycache__", ".venv", "venv", "env",
    "node_modules", "dist", "build", ".mypy_cache",
    ".pytest_cache", ".next", ".nuxt", "coverage",
    ".tox", "eggs", ".eggs",
}

# ── Extension → display language ─────────────────────────────────────────────
EXT_LANG: dict[str, str] = {
    ".py": "Python",           ".js": "JavaScript",      ".ts": "TypeScript",
    ".tsx": "TypeScript/React",".jsx": "JavaScript/React",".java": "Java",
    ".go": "Go",               ".rs": "Rust",             ".cs": "C#",
    ".php": "PHP",             ".rb": "Ruby",             ".kt": "Kotlin",
    ".swift": "Swift",         ".sql": "SQL",             ".sh": "Shell",
    ".yml": "YAML",            ".yaml": "YAML",           ".toml": "TOML",
    ".json": "JSON",           ".md": "Markdown",         ".html": "HTML",
    ".css": "CSS",             ".scss": "SCSS",           ".sass": "Sass",
    ".less": "Less",           ".vue": "Vue",             ".svelte": "Svelte",
    ".c": "C",                 ".cpp": "C++",             ".h": "C Header",
    ".hpp": "C++ Header",
}