from __future__ import annotations
import argparse
import os
import sys
import webbrowser

from . import __version__
from .analyser import count_code_stats
from .reporter import build_html


def _print_summary(s: dict) -> None:
    width = 62
    print()
    print("═" * width)
    print(f"  CODE REPORT — {os.path.basename(s['root'])}")
    print("═" * width)
    print(f"  {'Files analysed':<22}: {s['files']:>10,}")
    print(f"  {'Total lines (LOC)':<22}: {s['loc']:>10,}")
    print(f"  {'Code lines':<22}: {s['code']:>10,}")
    print(f"  {'Comment lines':<22}: {s['comments']:>10,}")
    print(f"  {'Blank lines':<22}: {s['blank']:>10,}")
    print(f"  {'Functions':<22}: {s['functions']:>10,}  ({s['async_functions']} async)")
    print(f"  {'Classes':<22}: {s['classes']:>10,}")
    print(f"  {'Endpoints':<22}: {s['endpoints']:>10,}")
    print(f"  {'TODOs / FIXMEs':<22}: {s['todos']:>10,}")
    print(f"  {'Long lines (>100ch)':<22}: {s['long_lines']:>10,}")
    print("═" * width)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="codereporter",
        description="Generate an HTML code-intelligence report for any repo.",
    )
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Root directory to analyse (default: current directory)",
    )
    parser.add_argument(
        "-o", "--output",
        default="code_report.html",
        metavar="FILE",
        help="Output HTML file name (default: code_report.html)",
    )
    parser.add_argument(
        "--no-open",
        action="store_true",
        help="Do not auto-open the report in the browser",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Also save raw JSON stats alongside the HTML report",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"codereporter {__version__}",
    )

    args = parser.parse_args(argv)
    root = os.path.abspath(args.path)

    if not os.path.isdir(root):
        print(f"[error] Not a directory: {root}", file=sys.stderr)
        return 1

    print(f"[codereporter] Analysing: {root}")

    data = count_code_stats(root)
    _print_summary(data["summary"])

    # ── Write HTML ─────────────────────────────────────────────────────────────
    html_path = os.path.join(root, args.output)
    html      = build_html(data)
    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(html)
    print(f"\n  HTML report  →  {html_path}")

    # ── Optionally write JSON ──────────────────────────────────────────────────
    if args.json:
        import json, datetime
        json_path = html_path.replace(".html", ".json")
        # endpoints / todos contain bytes keys — make serialisable
        with open(json_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=str)
        print(f"  JSON stats   →  {json_path}")

    # ── Auto-open ──────────────────────────────────────────────────────────────
    if not args.no_open:
        url = "file://" + html_path.replace("\\", "/")
        webbrowser.open(url)
        print(f"  Opened in browser.")

    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())