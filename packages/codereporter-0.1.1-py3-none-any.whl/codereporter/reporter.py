"""
HTML report builder — converts the stats dict from analyser into a
self-contained, single-file HTML dashboard.
"""

import json
import os

from .constants import LONG_LINE_LIMIT


def build_html(data: dict) -> str:
    """
    Render a complete, self-contained HTML report from *data*
    (as returned by ``count_code_stats``).
    """
    s         = data["summary"]
    langs     = data["by_language"]
    files     = data["file_details"]
    todos     = data["todos"]
    endpoints = data["endpoints"]
    imports   = data["top_imports"]

    total = s["loc"] or 1
    comment_pct = round(s["comments"] / total * 100, 1)
    blank_pct   = round(s["blank"]    / total * 100, 1)
    code_pct    = round(s["code"]     / total * 100, 1)

    # ── Language rows ──────────────────────────────────────────────────────────
    lang_rows = ""
    for lang, ls in sorted(langs.items(), key=lambda x: x[1]["loc"], reverse=True):
        bar = round(ls["loc"] / total * 100, 1)
        lang_rows += f"""
        <tr>
          <td class="lang-name">{lang}</td>
          <td>{ls['files']}</td>
          <td>{ls['loc']:,}</td>
          <td>{ls['code']:,}</td>
          <td>{ls['comments']:,}</td>
          <td>{ls['functions']:,}</td>
          <td>{ls['classes']:,}</td>
          <td>{ls['endpoints']:,}</td>
          <td>
            <div class="bar-wrap"><div class="bar" style="width:{bar}%"></div></div>
            <span class="bar-label">{bar}%</span>
          </td>
        </tr>"""

    # ── File rows (top 50) ─────────────────────────────────────────────────────
    file_rows = ""
    for f in files[:50]:
        ep_color = "var(--accent)" if f["endpoints"] else "inherit"
        file_rows += f"""
        <tr>
          <td class="file-path" title="{f['path']}">{f['path']}</td>
          <td><span class="lang-badge">{f['lang']}</span></td>
          <td>{f['loc']:,}</td>
          <td>{f['code']:,}</td>
          <td>{f['comments']:,}</td>
          <td>{f['comment_ratio']}%</td>
          <td>{f['functions']:,}</td>
          <td>{f['classes']:,}</td>
          <td style="color:{ep_color};font-weight:600">{f['endpoints']:,}</td>
          <td>{f['todos']:,}</td>
          <td>{f['long_lines']:,}</td>
        </tr>"""

    # ── Endpoint rows ──────────────────────────────────────────────────────────
    METHOD_COLORS = {
        "GET": "#22c55e", "POST": "#3b82f6", "PUT": "#f59e0b",
        "DELETE": "#ef4444", "PATCH": "#a855f7", "ROUTE": "#6b7280",
        "HEAD": "#06b6d4", "OPTIONS": "#ec4899",
    }
    ep_rows = ""
    for ep in endpoints:
        color = METHOD_COLORS.get(ep["method"], "#6b7280")
        ep_rows += f"""
        <tr>
          <td><span class="method-badge" style="background:{color}">{ep['method']}</span></td>
          <td class="file-path">{ep['file']}</td>
          <td class="ep-code">{ep['raw'][:90]}</td>
          <td>{ep['line']}</td>
        </tr>"""

    # ── TODO rows ──────────────────────────────────────────────────────────────
    TAG_COLORS = {
        "TODO": "#3b82f6", "FIXME": "#ef4444", "HACK": "#f59e0b",
        "BUG": "#ef4444", "XXX": "#f97316", "NOTE": "#22c55e",
    }
    todo_rows = ""
    for t in todos[:80]:
        color = TAG_COLORS.get(t["tag"].upper(), "#6b7280")
        todo_rows += f"""
        <tr>
          <td><span class="method-badge" style="background:{color}">{t['tag'].upper()}</span></td>
          <td class="file-path">{t['file']}</td>
          <td>{t['line']}</td>
          <td class="ep-code">{t['text'][:100]}</td>
        </tr>"""

    # ── Import bars ────────────────────────────────────────────────────────────
    max_imp  = imports[0][1] if imports else 1
    imp_items = ""
    for pkg, cnt in imports:
        w = round(cnt / max_imp * 100)
        imp_items += f"""
        <div class="imp-row">
          <span class="imp-name">{pkg}</span>
          <div class="imp-bar-wrap"><div class="imp-bar" style="width:{w}%"></div></div>
          <span class="imp-count">{cnt}</span>
        </div>"""

    # ── Chart data ─────────────────────────────────────────────────────────────
    lang_labels = json.dumps(list(langs.keys()))
    lang_data   = json.dumps([v["loc"] for v in langs.values()])
    donut_labels = json.dumps(["Code", "Comments", "Blank"])
    donut_data   = json.dumps([s["code"], s["comments"], s["blank"]])

    proj_name = os.path.basename(s["root"])

    # ── Conditional sections ───────────────────────────────────────────────────
    ep_section = (
        f"<div class='table-wrap'><table><thead><tr>"
        f"<th>Method</th><th>File</th><th>Source</th><th>Line</th>"
        f"</tr></thead><tbody>{ep_rows}</tbody></table></div>"
        if endpoints else
        "<div class='no-data'>No API endpoints detected in this codebase.</div>"
    )
    todo_section = (
        f"<div class='table-wrap'><table><thead><tr>"
        f"<th>Tag</th><th>File</th><th>Line</th><th>Text</th>"
        f"</tr></thead><tbody>{todo_rows}</tbody></table></div>"
        if todos else
        "<div class='no-data'>No TODOs or FIXMEs found — squeaky clean!</div>"
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Code Report — {proj_name}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Syne:wght@400;600;800&display=swap');
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
:root{{
  --bg:#0a0c0f;--panel:#111318;--border:#1e2330;
  --text:#c9d1e0;--muted:#4a5568;
  --accent:#38bdf8;--green:#34d399;--yellow:#fbbf24;
  --red:#f87171;--purple:#a78bfa;
  --fh:'Syne',sans-serif;--fm:'IBM Plex Mono',monospace;
}}
body{{background:var(--bg);color:var(--text);font-family:var(--fm);font-size:13px;line-height:1.6;min-height:100vh}}
/* HEADER */
header{{padding:48px 56px 36px;border-bottom:1px solid var(--border);background:linear-gradient(135deg,#0d1117,#0a0c14);position:relative;overflow:hidden}}
header::before{{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 60% 80% at 80% 50%,rgba(56,189,248,.06),transparent 70%)}}
.hl{{font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--accent);margin-bottom:10px}}
h1{{font-family:var(--fh);font-size:clamp(24px,4vw,44px);font-weight:800;color:#fff;letter-spacing:-.02em;line-height:1.1;margin-bottom:6px}}
.meta{{color:var(--muted);font-size:12px}}
/* LAYOUT */
.container{{padding:40px 56px;max-width:1600px}}
section{{margin-bottom:56px}}
.st{{font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--accent);margin-bottom:20px;display:flex;align-items:center;gap:10px}}
.st::after{{content:'';flex:1;height:1px;background:var(--border)}}
/* KPI */
.kpi-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;margin-bottom:36px}}
.kpi{{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:20px 18px;transition:border-color .2s}}
.kpi:hover{{border-color:var(--accent)}}
.kpi-label{{font-size:11px;color:var(--muted);letter-spacing:.05em;text-transform:uppercase;margin-bottom:8px}}
.kpi-value{{font-family:var(--fh);font-size:28px;font-weight:800;color:#fff;letter-spacing:-.02em}}
.kpi-sub{{font-size:11px;color:var(--muted);margin-top:4px}}
.ka{{border-top:2px solid var(--accent)}}.kg{{border-top:2px solid var(--green)}}
.ky{{border-top:2px solid var(--yellow)}}.kr{{border-top:2px solid var(--red)}}
.kp{{border-top:2px solid var(--purple)}}
/* CHARTS ROW */
.charts-row{{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:36px}}
@media(max-width:900px){{.charts-row{{grid-template-columns:1fr}}}}
.chart-card{{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:24px}}
.chart-title{{font-family:var(--fh);font-size:13px;font-weight:600;color:var(--text);margin-bottom:16px}}
/* COMP BAR */
.comp-bar{{display:flex;height:12px;border-radius:6px;overflow:hidden;margin:8px 0 16px;gap:2px}}
.comp-seg{{transition:opacity .2s}}.comp-seg:hover{{opacity:.8}}
.comp-legend{{display:flex;gap:20px;flex-wrap:wrap;font-size:12px;color:var(--muted)}}
.comp-dot{{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}}
/* TABLE */
.table-wrap{{overflow-x:auto;border:1px solid var(--border);border-radius:10px;background:var(--panel)}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
thead th{{background:#0d1017;color:var(--muted);font-size:10px;letter-spacing:.08em;text-transform:uppercase;padding:10px 14px;text-align:left;position:sticky;top:0;z-index:1;border-bottom:1px solid var(--border);white-space:nowrap}}
tbody tr{{border-bottom:1px solid #151820;transition:background .1s}}
tbody tr:last-child{{border-bottom:none}}
tbody tr:hover{{background:rgba(56,189,248,.04)}}
td{{padding:9px 14px;color:var(--text);vertical-align:middle;white-space:nowrap}}
.lang-name{{color:#fff;font-weight:600}}
.file-path{{max-width:320px;overflow:hidden;text-overflow:ellipsis;color:var(--accent)}}
.ep-code{{max-width:360px;overflow:hidden;text-overflow:ellipsis;color:var(--muted);font-size:11px}}
/* BARS */
.bar-wrap{{display:inline-flex;width:80px;height:5px;background:var(--border);border-radius:3px;vertical-align:middle;margin-right:6px}}
.bar{{height:100%;background:var(--accent);border-radius:3px}}
.bar-label{{font-size:11px;color:var(--muted)}}
/* BADGES */
.lang-badge{{background:rgba(56,189,248,.12);color:var(--accent);font-size:10px;padding:2px 7px;border-radius:4px}}
.method-badge{{display:inline-block;font-size:10px;font-weight:700;padding:2px 8px;border-radius:4px;color:#fff;letter-spacing:.04em}}
/* IMPORTS */
.imp-list{{display:flex;flex-direction:column;gap:8px}}
.imp-row{{display:flex;align-items:center;gap:10px}}
.imp-name{{width:160px;color:#fff;font-size:12px;flex-shrink:0;overflow:hidden;text-overflow:ellipsis}}
.imp-bar-wrap{{flex:1;height:6px;background:var(--border);border-radius:3px}}
.imp-bar{{height:100%;background:var(--purple);border-radius:3px}}
.imp-count{{width:36px;text-align:right;color:var(--muted);font-size:12px}}
/* MISC */
.no-data{{color:var(--muted);padding:24px;text-align:center;font-style:italic;background:var(--panel);border:1px solid var(--border);border-radius:10px}}
footer{{margin-top:80px;padding:28px 56px;border-top:1px solid var(--border);color:var(--muted);font-size:11px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px}}
</style>
</head>
<body>
<header>
  <div class="hl">Code Intelligence Report</div>
  <h1>{proj_name}</h1>
  <div class="meta">{s['root']} &nbsp;·&nbsp; Generated {s['generated_at']}</div>
</header>
<div class="container">

  <!-- KPIs -->
  <section>
    <div class="st">Overview</div>
    <div class="kpi-grid">
      <div class="kpi ka"><div class="kpi-label">Files Analysed</div><div class="kpi-value">{s['files']:,}</div></div>
      <div class="kpi ka"><div class="kpi-label">Total Lines</div><div class="kpi-value">{s['loc']:,}</div><div class="kpi-sub">{s['blank']:,} blank</div></div>
      <div class="kpi kg"><div class="kpi-label">Code Lines</div><div class="kpi-value">{s['code']:,}</div><div class="kpi-sub">{code_pct}% of total</div></div>
      <div class="kpi ky"><div class="kpi-label">Comment Lines</div><div class="kpi-value">{s['comments']:,}</div><div class="kpi-sub">{comment_pct}% of total</div></div>
      <div class="kpi kp"><div class="kpi-label">Functions</div><div class="kpi-value">{s['functions']:,}</div><div class="kpi-sub">{s['async_functions']:,} async</div></div>
      <div class="kpi kp"><div class="kpi-label">Classes</div><div class="kpi-value">{s['classes']:,}</div></div>
      <div class="kpi kg"><div class="kpi-label">Endpoints</div><div class="kpi-value">{s['endpoints']:,}</div></div>
      <div class="kpi kr"><div class="kpi-label">TODOs / FIXMEs</div><div class="kpi-value">{s['todos']:,}</div></div>
      <div class="kpi ky"><div class="kpi-label">Long Lines &gt;{LONG_LINE_LIMIT}</div><div class="kpi-value">{s['long_lines']:,}</div></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Line Composition</div>
      <div class="comp-bar">
        <div class="comp-seg" style="width:{code_pct}%;background:var(--green)" title="Code {code_pct}%"></div>
        <div class="comp-seg" style="width:{comment_pct}%;background:var(--yellow)" title="Comments {comment_pct}%"></div>
        <div class="comp-seg" style="width:{blank_pct}%;background:var(--border)" title="Blank {blank_pct}%"></div>
      </div>
      <div class="comp-legend">
        <span><span class="comp-dot" style="background:var(--green)"></span>Code {code_pct}%</span>
        <span><span class="comp-dot" style="background:var(--yellow)"></span>Comments {comment_pct}%</span>
        <span><span class="comp-dot" style="background:var(--muted)"></span>Blank {blank_pct}%</span>
      </div>
    </div>
  </section>

  <!-- Charts -->
  <section>
    <div class="st">Distribution</div>
    <div class="charts-row">
      <div class="chart-card">
        <div class="chart-title">Lines by Language</div>
        <canvas id="langChart" height="220"></canvas>
      </div>
      <div class="chart-card">
        <div class="chart-title">Code vs Comments vs Blank</div>
        <canvas id="donutChart" height="220"></canvas>
      </div>
    </div>
  </section>

  <!-- By Language -->
  <section>
    <div class="st">By Language</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Language</th><th>Files</th><th>Total LOC</th><th>Code</th><th>Comments</th><th>Functions</th><th>Classes</th><th>Endpoints</th><th>Share</th></tr></thead>
        <tbody>{lang_rows}</tbody>
      </table>
    </div>
  </section>

  <!-- Files -->
  <section>
    <div class="st">Top Files by Size (max 50 shown)</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>File</th><th>Lang</th><th>LOC</th><th>Code</th><th>Comments</th><th>Comment%</th><th>Fns</th><th>Classes</th><th>Endpoints</th><th>TODOs</th><th>Long Lines</th></tr></thead>
        <tbody>{file_rows or '<tr><td colspan="11" class="no-data">No files found</td></tr>'}</tbody>
      </table>
    </div>
  </section>

  <!-- Endpoints -->
  <section>
    <div class="st">API Endpoints ({len(endpoints)} total)</div>
    {ep_section}
  </section>

  <!-- TODOs -->
  <section>
    <div class="st">TODOs &amp; FIXMEs ({len(todos)} total)</div>
    {todo_section}
  </section>

  <!-- Imports -->
  <section>
    <div class="st">Most Used Packages / Imports</div>
    <div class="chart-card" style="max-width:600px">
      <div class="imp-list">{imp_items or '<div class="no-data">No imports detected</div>'}</div>
    </div>
  </section>

</div>
<footer>
  <span>Generated by codereporter v0.1.0</span>
  <span>{s['generated_at']}</span>
</footer>
<script>
const LL={lang_labels},LD={lang_data};
const DL={donut_labels},DD={donut_data};
const P=['#38bdf8','#34d399','#a78bfa','#fbbf24','#f87171','#fb923c','#22d3ee','#86efac','#c4b5fd','#fde68a','#f9a8d4','#6ee7b7','#93c5fd','#fca5a5','#d8b4fe'];
Chart.defaults.color='#4a5568';
Chart.defaults.font.family="'IBM Plex Mono',monospace";
Chart.defaults.font.size=11;
new Chart(document.getElementById('langChart'),{{type:'bar',data:{{labels:LL,datasets:[{{label:'LOC',data:LD,backgroundColor:P.slice(0,LD.length),borderRadius:4,borderSkipped:false}}]}},options:{{responsive:true,plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:c=>` ${{c.parsed.y.toLocaleString()}} lines`}}}}}},scales:{{x:{{grid:{{color:'#1e2330'}},ticks:{{maxRotation:45}}}},y:{{grid:{{color:'#1e2330'}},ticks:{{callback:v=>v>=1000?(v/1000).toFixed(1)+'k':v}}}}}}}}}});
new Chart(document.getElementById('donutChart'),{{type:'doughnut',data:{{labels:DL,datasets:[{{data:DD,backgroundColor:['#34d399','#fbbf24','#1e2330'],borderWidth:0,hoverOffset:6}}]}},options:{{responsive:true,cutout:'68%',plugins:{{legend:{{position:'bottom',labels:{{padding:16,usePointStyle:true}}}},tooltip:{{callbacks:{{label:c=>` ${{c.label}}: ${{c.parsed.toLocaleString()}} lines`}}}}}}}}}});
</script>
</body>
</html>"""