from __future__ import annotations

import hashlib
from typing import Any, Mapping, Sequence
from urllib.parse import quote as url_quote

import requests

__version__ = '1.3.3'

DEFAULT_CONFIG_BUCKET = 'G_AUTMAN'
DEFAULT_DAIDAI_CONFIG_KEY = 'daidai_config'
DEFAULT_DAIDAI_GROUP_KEY = 'daidai_group'
DEFAULT_ENV_NAME_KEY = 'ql_envname'
DEFAULT_QL_CONFIG_KEY = 'ql_config'
PAY_CONFIG_BUCKET = 'dd_sign_config'
REQUEST_TIMEOUT = 10
DAIDAI_TOKEN_PATHS = (
    '/api/open-api/token',
    '/api/auth/token',
)
PAY_CONFIG_KEYS = [
    'ma_pay_switch',
    'qr_pay_switch',
    'zsm',
    'pay_types',
]
MA_PAY_CONFIG_KEYS = [
    'ma_pay_gateway',
    'ma_pay_pid',
    'ma_pay_key',
    'ma_pay_notify_url',
    'ma_pay_return_url',
]
DEFAULT_PAY_TYPE_NAMES = {
    'alipay': '支付宝',
    'wxpay': '微信支付',
    'qqpay': 'QQ钱包',
}


def generate_qrcode_url(content: str) -> str:
    """生成二维码图片 URL。"""
    encoded = url_quote(content)
    return f'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={encoded}'


def get_bucket_value(bucket: str, key: str, default: str = '') -> str:
    """读取 middleware bucket 配置。"""
    try:
        import middleware
    except ImportError:
        return default

    try:
        value = middleware.bucketGet(bucket, key)
    except Exception:
        return default
    return str(value) if value is not None else default


def get_str_config_map(bucket: str, keys: Sequence[str]) -> dict[str, str]:
    """批量读取字符串配置。"""
    return {key: get_bucket_value(bucket, key, '') for key in keys}


def get_config_value(key: str, default: str = '', bucket: str = DEFAULT_CONFIG_BUCKET) -> str:
    """读取指定配置桶中的配置。"""
    return get_bucket_value(bucket, key, default)


def get_pay_config_map(keys: Sequence[str]) -> dict[str, str]:
    """读取支付配置桶。"""
    return get_str_config_map(PAY_CONFIG_BUCKET, keys)


def request_json(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str] | None = None,
    params: Mapping[str, Any] | None = None,
    data: Mapping[str, Any] | None = None,
    json: Any = None,
    timeout: int = REQUEST_TIMEOUT,
) -> Any:
    """发送请求并返回 JSON 响应。"""
    response = requests.request(
        method=method,
        url=url,
        headers=dict(headers or {}),
        params=dict(params or {}) or None,
        data=dict(data or {}) or None,
        json=json,
        timeout=timeout,
    )
    response.raise_for_status()
    return response.json()


def _request_result_json(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str] | None = None,
    params: Mapping[str, Any] | None = None,
    data: Mapping[str, Any] | None = None,
    json: Any = None,
    timeout: int = REQUEST_TIMEOUT,
) -> tuple[requests.Response | None, Any]:
    try:
        response = requests.request(
            method=method,
            url=url,
            headers=dict(headers or {}),
            params=dict(params or {}) or None,
            data=dict(data or {}) or None,
            json=json,
            timeout=timeout,
        )
    except Exception:
        return None, None

    try:
        result = response.json()
    except Exception:
        result = {}
    return response, result


def parse_ql_config(config_str: str | None) -> tuple[str, str, str]:
    """解析青龙配置串。"""
    if not config_str:
        return '', '', ''

    parts = [part.strip() for part in str(config_str).replace('|', '丨').split('丨')]
    if len(parts) < 3:
        return '', '', ''

    host = parts[0].rstrip('/')
    client_id = parts[1]
    client_secret = parts[2]
    return host, client_id, client_secret


def parse_daidai_config(config_str: str | None) -> tuple[str, str, str]:
    """解析呆呆面板配置串。"""
    return parse_ql_config(config_str)


def _is_success_response(response: Any, success_code: int = 200) -> bool:
    return isinstance(response, dict) and response.get('code') == success_code


def _is_daidai_success_code(code: Any) -> bool:
    return str(code).strip() in {'0', '200'}


def _get_result_message(result: Any, default_message: str) -> str:
    if not isinstance(result, dict):
        return default_message

    for key in ('msg', 'message', 'error', 'detail'):
        value = str(result.get(key) or '').strip()
        if value:
            return value
    return default_message


def _extract_daidai_env_list(result: Any) -> list[dict[str, Any]]:
    data = result.get('data') if isinstance(result, dict) else None
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ('items', 'list', 'records', 'rows'):
            value = data.get(key)
            if isinstance(value, list):
                return value
    return []


def _extract_daidai_token(result: Any) -> str:
    if not isinstance(result, dict):
        return ''

    data = result.get('data')
    if isinstance(data, dict):
        for key in ('access_token', 'token'):
            token = str(data.get(key) or '').strip()
            if token:
                return token

    token = str(result.get('access_token') or result.get('token') or '').strip()
    return token


def get_ql_token(host: str, client_id: str, client_secret: str) -> str | None:
    """获取青龙 token。"""
    if not host or not client_id or not client_secret:
        return None

    response = request_json(
        'get',
        f'{host}/open/auth/token',
        params={'client_id': client_id, 'client_secret': client_secret},
    )
    if not _is_success_response(response):
        return None

    data = response.get('data') or {}
    token = data.get('token')
    return str(token) if token else None


def get_daidai_token(host: str, app_key: str, app_secret: str) -> str | None:
    """获取呆呆面板 token。"""
    if not host or not app_key or not app_secret:
        return None

    payload = {'app_key': app_key, 'app_secret': app_secret}
    for path in DAIDAI_TOKEN_PATHS:
        response, result = _request_result_json(
            'post',
            f'{host}{path}',
            json=payload,
        )
        if response is None or response.status_code not in (200, 201):
            continue

        token = _extract_daidai_token(result)
        code = result.get('code') if isinstance(result, dict) else None
        if token and (code is None or _is_daidai_success_code(code)):
            return token
        if token:
            return token
    return None


def _get_auth_headers(token: str) -> dict[str, str]:
    return {'Authorization': f'Bearer {token}'}


def _get_env_identifier(env: Mapping[str, Any]) -> Any:
    return env.get('id') or env.get('_id')


def _get_env_identity_field(env: Mapping[str, Any]) -> str | None:
    if env.get('id'):
        return 'id'
    if env.get('_id'):
        return '_id'
    return None


def ql_list_envs(host: str, token: str, search_value: str = '') -> list[dict[str, Any]]:
    """查询青龙环境变量列表。"""
    response = request_json(
        'get',
        f'{host}/open/envs',
        headers=_get_auth_headers(token),
        params={'searchValue': search_value} if search_value else None,
    )
    if not _is_success_response(response):
        return []

    data = response.get('data')
    return data if isinstance(data, list) else []


def ql_add_env(host: str, token: str, env_data: Mapping[str, Any]) -> list[dict[str, Any]]:
    """新增青龙环境变量。"""
    response = request_json(
        'post',
        f'{host}/open/envs',
        headers=_get_auth_headers(token),
        json=[dict(env_data)],
    )
    if not _is_success_response(response):
        return []

    data = response.get('data')
    return data if isinstance(data, list) else []


def ql_update_env(host: str, token: str, env_data: Mapping[str, Any]) -> bool:
    """更新青龙环境变量。"""
    response = request_json(
        'put',
        f'{host}/open/envs',
        headers=_get_auth_headers(token),
        json=dict(env_data),
    )
    return _is_success_response(response)


def ql_enable_env(host: str, token: str, env_ids: list[Any]) -> bool:
    """启用青龙环境变量。"""
    if not env_ids:
        return False

    response = request_json(
        'put',
        f'{host}/open/envs/enable',
        headers=_get_auth_headers(token),
        json=env_ids,
    )
    return _is_success_response(response)


def ql_delete_env(host: str, token: str, env_ids: list[Any]) -> bool:
    """删除青龙环境变量。"""
    if not env_ids:
        return False

    response = request_json(
        'delete',
        f'{host}/open/envs',
        headers=_get_auth_headers(token),
        json=env_ids,
    )
    return _is_success_response(response)


def dadai_list_envs(
    host: str,
    token: str,
    keyword: str = '',
    *,
    page: int = 1,
    page_size: int = 100,
) -> list[dict[str, Any]]:
    """查询呆呆面板环境变量列表。"""
    params: dict[str, Any] = {}
    if keyword:
        params['keyword'] = keyword
    if page > 0:
        params['page'] = page
    if page_size > 0:
        params['page_size'] = page_size

    response, result = _request_result_json(
        'get',
        f'{host}/api/envs',
        headers=_get_auth_headers(token),
        params=params or None,
    )
    if response is None or response.status_code not in (200, 201):
        return []

    envs = _extract_daidai_env_list(result)
    code = result.get('code') if isinstance(result, dict) else None
    if envs or code is None or _is_daidai_success_code(code):
        return envs
    return []


def dadai_add_env(host: str, token: str, env_data: Mapping[str, Any]) -> bool:
    """新增呆呆面板环境变量。"""
    response, result = _request_result_json(
        'post',
        f'{host}/api/envs',
        headers=_get_auth_headers(token),
        json=dict(env_data),
    )
    if response is None or response.status_code not in (200, 201):
        return False

    code = result.get('code') if isinstance(result, dict) else None
    return code is None or _is_daidai_success_code(code)


def dadai_update_env(host: str, token: str, env_id: Any, env_data: Mapping[str, Any]) -> bool:
    """更新呆呆面板环境变量。"""
    if env_id is None:
        return False

    response, result = _request_result_json(
        'put',
        f'{host}/api/envs/{env_id}',
        headers=_get_auth_headers(token),
        json=dict(env_data),
    )
    if response is None or response.status_code not in (200, 201):
        return False

    code = result.get('code') if isinstance(result, dict) else None
    return code is None or _is_daidai_success_code(code)


def dadai_delete_env(host: str, token: str, env_id: Any) -> bool:
    """删除呆呆面板环境变量。"""
    if env_id is None:
        return False

    response, result = _request_result_json(
        'delete',
        f'{host}/api/envs/{env_id}',
        headers=_get_auth_headers(token),
    )
    if response is None or response.status_code not in (200, 204):
        return False

    code = result.get('code') if isinstance(result, dict) else None
    return response.status_code == 204 or code is None or _is_daidai_success_code(code)


def pick_existing_env(
    envs: list[dict[str, Any]],
    env_name: str,
    username: str = '',
) -> dict[str, Any] | None:
    """从环境变量列表中挑选已有记录。"""
    if not env_name:
        return None

    fallback_env: dict[str, Any] | None = None
    for env in envs:
        if env.get('name') != env_name:
            continue
        if fallback_env is None:
            fallback_env = env

        remarks = str(env.get('remarks') or '')
        if username and username in remarks:
            return env

    return fallback_env if not username else None


def _parse_pay_types(pay_types_str: str) -> dict[str, str]:
    pay_types: dict[str, str] = {}
    if not pay_types_str:
        return pay_types

    for item in pay_types_str.split(','):
        current_item = item.strip()
        if not current_item:
            continue
        if ':' in current_item:
            key, name = current_item.split(':', 1)
            pay_key = key.strip()
            if not pay_key:
                continue
            pay_name = name.strip() or DEFAULT_PAY_TYPE_NAMES.get(pay_key, pay_key)
            pay_types[pay_key] = pay_name
            continue
        pay_types[current_item] = DEFAULT_PAY_TYPE_NAMES.get(current_item, current_item)
    return pay_types


def get_pay_config() -> dict[str, Any]:
    """从 middleware 配参读取支付方式配置。"""
    config_map = get_pay_config_map(PAY_CONFIG_KEYS)
    ma_pay_switch = config_map.get('ma_pay_switch', 'false')
    qr_pay_switch = config_map.get('qr_pay_switch', 'false')
    zsm = config_map.get('zsm', '')
    pay_types_str = config_map.get('pay_types', '')

    return {
        'ma_pay_switch': ma_pay_switch.lower() == 'true',
        'qr_pay_switch': qr_pay_switch.lower() == 'true',
        'zsm': zsm,
        'pay_types': _parse_pay_types(pay_types_str),
    }


class QingLongClient:
    """青龙面板环境变量操作客户端。"""

    def __init__(
        self,
        os_var_name: str = '',
        ql_config_str: str | None = None,
        config_bucket: str = DEFAULT_CONFIG_BUCKET,
        config_key: str = DEFAULT_QL_CONFIG_KEY,
        env_name_key: str = DEFAULT_ENV_NAME_KEY,
    ) -> None:
        if ql_config_str is None:
            ql_config_str = get_config_value(config_key, '', bucket=config_bucket)

        resolved_os_var_name = str(os_var_name or '').strip()
        if not resolved_os_var_name and env_name_key:
            resolved_os_var_name = get_config_value(env_name_key, '', bucket=config_bucket).strip()

        self.os_var_name = resolved_os_var_name
        self.config_bucket = config_bucket
        self.config_key = config_key
        self.env_name_key = env_name_key
        self.host, self.client_id, self.client_secret = parse_ql_config(ql_config_str)

    def is_configured(self) -> bool:
        """检查青龙是否已配置。"""
        return bool(self.host and self.client_id and self.client_secret)

    def get_token(self) -> str | None:
        """获取青龙访问令牌。"""
        if not self.is_configured():
            return None

        try:
            return get_ql_token(self.host, self.client_id, self.client_secret)
        except Exception:
            return None

    def _find_existing_env(self, token: str, username: str) -> dict[str, Any] | None:
        search_value = username or self.os_var_name
        envs = ql_list_envs(self.host, token, search_value)
        return pick_existing_env(envs, self.os_var_name, username)

    def update_env(self, username: str, env_value: str, remark: str = '') -> bool:
        """更新或创建青龙环境变量。"""
        if not self.is_configured():
            return False

        token = self.get_token()
        if not token:
            return False

        env_payload = {'name': self.os_var_name, 'value': env_value, 'remarks': remark}
        try:
            existing_env = self._find_existing_env(token, username)
            if existing_env:
                env_id = _get_env_identifier(existing_env)
                identity_field = _get_env_identity_field(existing_env)
                if not env_id or not identity_field:
                    return False
                update_payload = {**env_payload, identity_field: env_id}
                if not ql_update_env(self.host, token, update_payload):
                    return False
                return ql_enable_env(self.host, token, [env_id])

            created_envs = ql_add_env(self.host, token, env_payload)
            if not created_envs:
                return False

            new_env_id = _get_env_identifier(created_envs[0])
            return True if not new_env_id else ql_enable_env(self.host, token, [new_env_id])
        except Exception:
            return False

    def delete_env(self, username: str) -> bool:
        """删除青龙环境变量。"""
        if not self.is_configured():
            return False

        token = self.get_token()
        if not token:
            return False

        try:
            existing_env = self._find_existing_env(token, username)
            if not existing_env:
                return False

            env_id = _get_env_identifier(existing_env)
            if not env_id:
                return False
            return ql_delete_env(self.host, token, [env_id])
        except Exception:
            return False


class DadaiPanelClient:
    """呆呆面板环境变量操作客户端。"""

    def __init__(
        self,
        os_var_name: str = '',
        daidai_config_str: str | None = None,
        config_bucket: str = DEFAULT_CONFIG_BUCKET,
        config_key: str = DEFAULT_DAIDAI_CONFIG_KEY,
        env_name_key: str = DEFAULT_ENV_NAME_KEY,
        group: str = '',
        group_key: str = DEFAULT_DAIDAI_GROUP_KEY,
        project_name: str = '',
    ) -> None:
        if daidai_config_str is None:
            daidai_config_str = get_config_value(config_key, '', bucket=config_bucket)

        resolved_os_var_name = str(os_var_name or '').strip()
        if not resolved_os_var_name and env_name_key:
            resolved_os_var_name = get_config_value(env_name_key, '', bucket=config_bucket).strip()

        self.os_var_name = resolved_os_var_name
        self.config_bucket = config_bucket
        self.config_key = config_key
        self.env_name_key = env_name_key
        self.group_key = str(group_key or '').strip()
        self.project_name = str(project_name or '').strip()
        resolved_group = str(group or '').strip()
        if not resolved_group and self.group_key:
            resolved_group = get_config_value(self.group_key, '', bucket=config_bucket).strip()
        self.default_group = str(resolved_group or self.project_name).strip()
        self.host, self.app_key, self.app_secret = parse_daidai_config(daidai_config_str)
        self._token: str | None = None
        self.last_error = ''

    def is_configured(self) -> bool:
        """检查呆呆面板是否已配置。"""
        return bool(self.host and self.app_key and self.app_secret)

    def _request_json(self, method: str, path: str, **kwargs: Any) -> tuple[requests.Response | None, Any]:
        try:
            response = requests.request(
                method,
                f'{self.host}{path}',
                timeout=kwargs.pop('timeout', REQUEST_TIMEOUT),
                **kwargs,
            )
        except Exception as exc:
            self.last_error = f'请求失败: {exc}'
            return None, None

        try:
            result = response.json()
        except Exception:
            result = {}
        return response, result

    def get_token(self) -> str | None:
        """获取呆呆面板访问令牌。"""
        if self._token:
            return self._token
        if not self.is_configured():
            self.last_error = '呆呆面板配置不完整'
            return None

        self.last_error = ''
        payload = {'app_key': self.app_key, 'app_secret': self.app_secret}
        for path in DAIDAI_TOKEN_PATHS:
            response, result = self._request_json('post', path, json=payload)
            if response is None:
                continue
            if response.status_code not in (200, 201):
                self.last_error = f'认证接口返回状态码 {response.status_code}'
                continue

            token = _extract_daidai_token(result)
            code = result.get('code') if isinstance(result, dict) else None
            if token and (code is None or _is_daidai_success_code(code)):
                self._token = token
                self.last_error = ''
                return token
            if token:
                self._token = token
                self.last_error = ''
                return token

            self.last_error = _get_result_message(result, '呆呆面板未返回 token')

        if not self.last_error:
            self.last_error = '呆呆面板认证失败'
        return None

    def _headers(self, token: str = '') -> dict[str, str]:
        current_token = token or self.get_token()
        if not current_token:
            return {}
        return {
            'Authorization': f'Bearer {current_token}',
            'accept': 'application/json',
            'Content-Type': 'application/json',
        }

    def _authorized_request(self, method: str, path: str, **kwargs: Any) -> tuple[requests.Response | None, Any]:
        token = self.get_token()
        if not token:
            return None, None

        request_kwargs = dict(kwargs)
        current_headers = dict(request_kwargs.pop('headers', {}) or {})
        response, result = self._request_json(
            method,
            path,
            headers={**self._headers(token), **current_headers},
            **request_kwargs,
        )
        if response is not None and response.status_code == 401:
            self._token = None
            refreshed_token = self.get_token()
            if not refreshed_token:
                return response, result
            response, result = self._request_json(
                method,
                path,
                headers={**self._headers(refreshed_token), **current_headers},
                **request_kwargs,
            )
        return response, result

    def _list_envs(self, params: Mapping[str, Any] | None = None) -> list[dict[str, Any]] | None:
        response, result = self._authorized_request(
            'get',
            '/api/envs',
            params=params or {},
        )
        if response is None:
            return None
        if response.status_code not in (200, 201):
            self.last_error = f'获取变量列表失败，状态码 {response.status_code}'
            return None

        envs = _extract_daidai_env_list(result)
        code = result.get('code') if isinstance(result, dict) else None
        if envs or code is None or _is_daidai_success_code(code):
            return envs

        self.last_error = _get_result_message(result, '获取变量列表失败')
        return None

    def _find_existing_env(self, username: str) -> dict[str, Any] | None:
        search_value = str(username or '').strip()
        search_params_list: list[dict[str, Any]] = []
        if search_value:
            search_params_list.append({'keyword': search_value, 'page_size': 100})
        search_params_list.extend(({'page_size': 100}, {}))

        for params in search_params_list:
            envs = self._list_envs(params)
            if envs is None:
                continue
            existing_env = pick_existing_env(envs, self.os_var_name, search_value)
            if existing_env:
                return existing_env

        if not self.last_error:
            self.last_error = f'未找到环境变量 {search_value or self.os_var_name}'
        return None

    def update_env(
        self,
        username: str,
        env_value: str,
        remark: str = '',
        group: str = '',
        project_name: str = '',
    ) -> bool:
        """更新或创建呆呆面板环境变量。"""
        if not self.get_token():
            return False

        self.last_error = ''
        current_group = str(group or '').strip()
        if not current_group and self.group_key:
            current_group = get_config_value(self.group_key, '', bucket=self.config_bucket).strip()
        if not current_group:
            current_group = str(project_name or self.default_group or self.project_name).strip()
        payload: dict[str, Any] = {
            'name': self.os_var_name,
            'value': env_value,
            'remarks': remark,
        }
        if current_group:
            payload['group'] = current_group

        existing_env = self._find_existing_env(username)
        if existing_env:
            env_id = _get_env_identifier(existing_env)
            if env_id is None:
                self.last_error = '找到旧变量但未获取到变量ID'
                return False
            response, result = self._authorized_request(
                'put',
                f'/api/envs/{env_id}',
                json=payload,
            )
        else:
            response, result = self._authorized_request(
                'post',
                '/api/envs',
                json=payload,
            )

        if response is None:
            return False
        if response.status_code not in (200, 201):
            self.last_error = f'同步变量失败，状态码 {response.status_code}'
            return False

        code = result.get('code') if isinstance(result, dict) else None
        if code is None or _is_daidai_success_code(code):
            self.last_error = ''
            return True

        self.last_error = _get_result_message(result, '呆呆面板同步失败')
        return False

    def delete_env(self, username: str) -> bool:
        """删除呆呆面板环境变量。"""
        if not self.get_token():
            return False

        self.last_error = ''
        existing_env = self._find_existing_env(username)
        if not existing_env:
            if not self.last_error:
                self.last_error = '未找到对应变量'
            return False

        env_id = _get_env_identifier(existing_env)
        if env_id is None:
            self.last_error = '找到旧变量但未获取到变量ID'
            return False

        response, result = self._authorized_request(
            'delete',
            f'/api/envs/{env_id}',
        )
        if response is None:
            return False
        if response.status_code not in (200, 204):
            self.last_error = f'删除变量失败，状态码 {response.status_code}'
            return False

        code = result.get('code') if isinstance(result, dict) else None
        if response.status_code == 204 or code is None or _is_daidai_success_code(code):
            self.last_error = ''
            return True

        self.last_error = _get_result_message(result, '呆呆面板删除失败')
        return False


class MaPayClient:
    """码支付客户端。"""

    def __init__(
        self,
        gateway: str | None = None,
        pid: str | None = None,
        key: str | None = None,
        notify_url: str | None = None,
        return_url: str | None = None,
    ) -> None:
        config_map = get_pay_config_map(MA_PAY_CONFIG_KEYS) if any(
            value is None for value in (gateway, pid, key, notify_url, return_url)
        ) else {}
        current_gateway = gateway if gateway is not None else config_map.get('ma_pay_gateway', '')
        self.gateway = current_gateway.rstrip('/')
        self.pid = pid if pid is not None else config_map.get('ma_pay_pid', '')
        self.key = key if key is not None else config_map.get('ma_pay_key', '')
        self.notify_url = notify_url if notify_url is not None else config_map.get('ma_pay_notify_url', '')
        self.return_url = return_url if return_url is not None else config_map.get('ma_pay_return_url', '')

    def is_configured(self) -> bool:
        """检查码支付是否已配置。"""
        return bool(self.gateway and self.pid and self.key)

    def _sign(self, params: Mapping[str, Any]) -> str:
        """生成 MD5 签名。"""
        filtered = {
            key: value
            for key, value in params.items()
            if key not in {'sign', 'sign_type'} and value is not None and value != ''
        }
        sign_str = '&'.join(f'{key}={value}' for key, value in sorted(filtered.items()))
        return hashlib.md5((sign_str + self.key).encode()).hexdigest().lower()

    def create_order(
        self,
        amount: float,
        pay_type: str,
        out_trade_no: str,
        subject: str,
        param: str = '',
    ) -> dict[str, Any]:
        """创建码支付订单。"""
        if not self.is_configured():
            return {'error': '码支付未配置'}

        try:
            money_value = round(float(amount), 2)
        except Exception as exc:
            return {'error': str(exc)}
        if money_value <= 0:
            return {'error': '金额必须大于0'}

        money = f'{money_value:.2f}'.rstrip('0').rstrip('.')
        params = {
            'pid': self.pid,
            'type': pay_type,
            'out_trade_no': out_trade_no,
            'notify_url': self.notify_url,
            'return_url': self.return_url,
            'name': subject,
            'money': money,
            'param': param,
        }
        params = {key: value for key, value in params.items() if value is not None and value != ''}
        params['sign'] = self._sign(params)
        params['sign_type'] = 'MD5'

        try:
            response = request_json('post', f'{self.gateway}/mapi.php', data=params)
        except Exception as exc:
            return {'error': str(exc)}

        if not isinstance(response, dict):
            return {'error': '创建订单失败', 'raw': response}
        if response.get('code') != 1:
            return {'error': response.get('msg', '创建订单失败'), 'raw': response}

        trade_no = response.get('trade_no')
        if not trade_no:
            return {'error': '创建订单失败', 'raw': response}
        pay_url = f'{self.gateway}/pay/{trade_no}'
        return {'trade_no': trade_no, 'pay_url': pay_url, 'raw': response}

    def check_order(self, out_trade_no: str) -> dict[str, Any]:
        """查询码支付订单状态。"""
        if not self.is_configured():
            return {'error': '码支付未配置'}

        try:
            response = request_json(
                'get',
                f'{self.gateway}/xpay/epay/api.php',
                params={
                    'act': 'order',
                    'pid': self.pid,
                    'key': self.key,
                    'out_trade_no': out_trade_no,
                },
            )
        except Exception as exc:
            return {'error': str(exc)}

        return response if isinstance(response, dict) else {'error': '查询订单失败', 'raw': response}

    def is_paid(self, out_trade_no: str) -> bool:
        """检查订单是否已支付。"""
        data = self.check_order(out_trade_no)
        return data.get('code') == 1 and data.get('status') == 1


__all__ = [
    'DEFAULT_CONFIG_BUCKET',
    'DEFAULT_DAIDAI_CONFIG_KEY',
    'DEFAULT_DAIDAI_GROUP_KEY',
    'DEFAULT_ENV_NAME_KEY',
    'DEFAULT_PAY_TYPE_NAMES',
    'DEFAULT_QL_CONFIG_KEY',
    'DAIDAI_TOKEN_PATHS',
    'DadaiPanelClient',
    'MA_PAY_CONFIG_KEYS',
    'PAY_CONFIG_BUCKET',
    'PAY_CONFIG_KEYS',
    'REQUEST_TIMEOUT',
    'dadai_add_env',
    'dadai_delete_env',
    'dadai_list_envs',
    'dadai_update_env',
    'MaPayClient',
    'QingLongClient',
    'generate_qrcode_url',
    'get_bucket_value',
    'get_config_value',
    'get_daidai_token',
    'get_pay_config',
    'get_pay_config_map',
    'get_ql_token',
    'get_str_config_map',
    'parse_daidai_config',
    'parse_ql_config',
    'pick_existing_env',
    'ql_add_env',
    'ql_delete_env',
    'ql_enable_env',
    'ql_list_envs',
    'ql_update_env',
    'request_json',
]
