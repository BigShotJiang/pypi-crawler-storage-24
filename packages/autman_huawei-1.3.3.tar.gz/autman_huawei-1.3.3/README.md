# autman-huawei

一个单文件 Python 工具模块，主要提供以下三类能力：

- 二维码链接生成
- 支付配置读取与码支付订单操作
- 青龙 / 呆呆面板环境变量管理

## 安装

```bash
pip install -U autman-huawei
```

## 导入方式

```python
import autman_huawei
```

或者：

```python
from autman_huawei import (
    DadaiPanelClient,
    MaPayClient,
    QingLongClient,
    generate_qrcode_url,
    get_pay_config,
)
```

## 功能概览

- 生成二维码图片链接
- 读取运行时支付配置
- 管理青龙环境变量
- 管理呆呆面板环境变量
- 创建码支付订单
- 查询码支付订单状态
- 在没有 `middleware` 时安全降级导入

## 使用说明

### 1. 生成二维码链接

```python
from autman_huawei import generate_qrcode_url

url = generate_qrcode_url("https://example.com")
print(url)
```

示例输出：

```text
https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https%3A//example.com
```

### 2. 读取支付配置

`get_pay_config()` 会从 `dd_sign_config` 数据桶读取支付相关配置，并返回整理后的字典。

```python
from autman_huawei import get_pay_config

config = get_pay_config()
print(config)
```

示例输出：

```python
{
    "ma_pay_switch": False,
    "qr_pay_switch": True,
    "zsm": "example text",
    "pay_types": {
        "alipay": "支付宝",
        "wxpay": "微信支付",
    },
}
```

### 3. 使用青龙客户端

`QingLongClient` 用于创建、更新、启用和删除青龙环境变量。

#### 3.1 默认初始化

```python
from autman_huawei import QingLongClient

client = QingLongClient("JD_COOKIE")
print(client.is_configured())
```

默认会从以下位置读取青龙配置：

- bucket：`G_AUTMAN`
- key：`ql_config`

如果第一个参数不传，模块还会继续尝试从以下位置读取变量名：

- bucket：同 `config_bucket`
- key：`ql_envname`

配置格式：

```text
host丨client_id丨client_secret
```

#### 3.2 自定义 bucket 和 key

这是 `1.3.0` 新增能力。

```python
from autman_huawei import QingLongClient

client = QingLongClient(
    config_bucket="MY_BUCKET",
    config_key="my_ql_config",
    env_name_key="ql_envname",
)
print(client.is_configured())
```

#### 3.3 直接传青龙配置字符串

```python
from autman_huawei import QingLongClient

client = QingLongClient(
    "JD_COOKIE",
    "http://127.0.0.1:5700丨client_id丨client_secret",
)
print(client.is_configured())
```

#### 3.4 更新或创建环境变量

```python
from autman_huawei import QingLongClient

client = QingLongClient("JD_COOKIE")
ok = client.update_env(
    username="demo_user",
    env_value="pt_key=xxx;pt_pin=demo;",
    remark="demo_user",
)
print(ok)
```

#### 3.5 删除环境变量

```python
from autman_huawei import QingLongClient

client = QingLongClient("JD_COOKIE")
ok = client.delete_env("demo_user")
print(ok)
```

### 4. 使用呆呆面板客户端

`DadaiPanelClient` 用于创建、更新和删除呆呆面板环境变量。

#### 4.1 默认初始化

```python
from autman_huawei import DadaiPanelClient

client = DadaiPanelClient("JD_COOKIE")
print(client.is_configured())
```

默认会从以下位置读取呆呆面板配置：

- bucket：`G_AUTMAN`
- key：`daidai_config`

如果变量名没传，模块还会继续尝试从以下位置读取变量名：

- bucket：同 `config_bucket`
- key：`ql_envname`

配置格式：

```text
host丨app_key丨app_secret
```

#### 4.2 自定义 bucket 和 key

```python
from autman_huawei import DadaiPanelClient

client = DadaiPanelClient(
    config_bucket="MY_BUCKET",
    config_key="my_daidai_config",
    env_name_key="ql_envname",
    group_key="daidai_group",
    project_name="示例项目",
)
print(client.is_configured())
```

#### 4.3 直接传呆呆面板配置字符串

```python
from autman_huawei import DadaiPanelClient

client = DadaiPanelClient(
    "JD_COOKIE",
    "http://127.0.0.1:8080丨app_key丨app_secret",
    project_name="示例项目",
)
print(client.is_configured())
```

#### 4.4 更新或创建环境变量

```python
from autman_huawei import DadaiPanelClient

client = DadaiPanelClient("JD_COOKIE", project_name="顺丰")
ok = client.update_env(
    username="demo_user",
    env_value="pt_key=xxx;pt_pin=demo;",
    remark="demo_user",
)
print(ok, client.last_error)
```

如果插件里已经有 `PROJECT_NAME = "项目名"` 这类常量，也可以直接这样传：

```python
client = DadaiPanelClient("JD_COOKIE", daidai_config, project_name=PROJECT_NAME)
```

如果想把分组也交给插件配置桶，可以这样：

```python
client = DadaiPanelClient(
    config_bucket="G_XMH",
    config_key="daidai_config",
    env_name_key="ql_envname",
)
```

不传 `group_key` 时，模块默认就会读取：

- key：`daidai_group`

#### 4.5 删除环境变量

```python
from autman_huawei import DadaiPanelClient

client = DadaiPanelClient("JD_COOKIE")
ok = client.delete_env("demo_user")
print(ok, client.last_error)
```

### 5. 使用码支付客户端

`MaPayClient` 可以创建订单并查询支付状态。

#### 5.1 默认初始化

```python
from autman_huawei import MaPayClient

client = MaPayClient()
print(client.is_configured())
```

#### 5.2 直接传配置

```python
from autman_huawei import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
    notify_url="https://example.com/notify",
    return_url="https://example.com/return",
)
print(client.is_configured())
```

#### 5.3 创建订单

```python
from autman_huawei import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
)

result = client.create_order(
    amount=10.5,
    pay_type="alipay",
    out_trade_no="order_10001",
    subject="测试订单",
    param="custom_data",
)
print(result)
```

示例成功输出：

```python
{
    "trade_no": "202603160001",
    "pay_url": "https://pay.example.com/pay/202603160001",
    "raw": {...},
}
```

#### 5.4 查询订单状态

```python
from autman_huawei import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
)

result = client.check_order("order_10001")
print(result)
print(client.is_paid("order_10001"))
```

## 配置说明

### middleware 数据桶

本模块通过宿主环境提供的 `middleware.bucketGet` API 读取运行时配置。

### 青龙配置默认位置

- bucket：`G_AUTMAN`
- key：`ql_config`

示例值：

```text
http://127.0.0.1:5700丨abcdef丨123456
```

### 呆呆面板配置默认位置

- bucket：`G_AUTMAN`
- key：`daidai_config`

示例值：

```text
http://127.0.0.1:8080丨app_key丨app_secret
```

### 支付配置数据桶

- bucket：`dd_sign_config`

支持的键：

- `ma_pay_switch`
- `qr_pay_switch`
- `zsm`
- `pay_types`
- `ma_pay_gateway`
- `ma_pay_pid`
- `ma_pay_key`
- `ma_pay_notify_url`
- `ma_pay_return_url`

`pay_types` 示例：

```text
alipay:支付宝,wxpay:微信支付,qqpay:QQ钱包
```

## 行为说明

- 如果 `middleware` 不存在，模块仍可安全导入
- 缺失的 bucket 配置会回退为空字符串或 `False` 风格结果
- `MaPayClient(...).is_configured()` 在支付配置不完整时返回 `False`
- `QingLongClient(...).is_configured()` 在青龙 host、client_id、client_secret 缺失时返回 `False`
- `QingLongClient("JD_COOKIE")` 老写法继续兼容
- `QingLongClient(..., config_bucket="MY_BUCKET", config_key="my_ql_config")` 支持自定义读取位置
- `DadaiPanelClient(...).is_configured()` 在呆呆面板 host、app_key、app_secret 缺失时返回 `False`
- `DadaiPanelClient("JD_COOKIE")` 默认读取 `G_AUTMAN.daidai_config`
- `DadaiPanelClient.update_env(..., group="项目名")` 会把 `group` 作为可选分组字段提交到 `/api/envs`
- `DadaiPanelClient(..., project_name=PROJECT_NAME)` 适合复用插件里的项目名常量，未显式传 `group` 时会回退为该项目名
- `QingLongClient(..., env_name_key="ql_envname")` 支持变量名按指定桶键自动读取
- `DadaiPanelClient(..., env_name_key="ql_envname")` 支持变量名按指定桶键自动读取
- `DadaiPanelClient(...)` 默认会按 `daidai_group` 读取分组桶键
- `DadaiPanelClient(..., group_key="xxx")` 支持把分组桶键改成别的名字

## 快速测试

```python
import autman_huawei

print(autman_huawei.__version__)
print(autman_huawei.generate_qrcode_url("https://example.com"))
print(autman_huawei.MaPayClient(gateway="", pid="", key="").is_configured())
print(autman_huawei.QingLongClient("JD_COOKIE", "").is_configured())
print(autman_huawei.DadaiPanelClient("JD_COOKIE", "").is_configured())
```

## License

MIT
