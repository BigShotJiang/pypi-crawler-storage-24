"""agent-trace: strace for AI agents."""

__version__ = "0.2.1"
