"""Integration tests for koubou."""
