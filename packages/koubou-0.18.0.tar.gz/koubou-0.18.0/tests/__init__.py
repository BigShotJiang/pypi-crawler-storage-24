"""Tests for ScreenshotGen."""
