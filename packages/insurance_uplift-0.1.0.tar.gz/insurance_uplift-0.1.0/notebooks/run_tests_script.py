#!/usr/bin/env python3
"""
Run insurance-uplift tests on Databricks.
This is a plain Python script (not a notebook) for the Databricks Jobs Python task.
"""
import subprocess
import sys
import os

print("=== insurance-uplift test runner ===")
print(f"Python: {sys.executable}")
print(f"Python version: {sys.version}")

# Install dependencies
deps = [
    "econml",
    "catboost",
    "polars",
    "pytest",
    "pytest-cov",
    "scipy",
    "scikit-learn",
    "matplotlib",
    "numpy",
]

print("\n--- Installing dependencies ---")
for dep in deps:
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet", dep],
        capture_output=True, text=True
    )
    status = "ok" if r.returncode == 0 else f"FAIL: {r.stderr[-200:]}"
    print(f"  {dep}: {status}")

# Add source to path
src_path = "/Workspace/Shared/insurance-uplift/src"
sys.path.insert(0, src_path)
os.environ["PYTHONPATH"] = src_path + ":" + os.environ.get("PYTHONPATH", "")

print("\n--- Verifying imports ---")
import insurance_uplift
print(f"  insurance-uplift {insurance_uplift.__version__} OK")
import polars as pl
print(f"  polars {pl.__version__} OK")
import econml
print(f"  econml OK")
import catboost
print(f"  catboost OK")

print("\n--- Running pytest ---")
result = subprocess.run(
    [sys.executable, "-m", "pytest",
     "/Workspace/Shared/insurance-uplift/tests/",
     "-v",
     "--tb=short",
     "--no-header",
     "-p", "no:cacheprovider",
    ],
    env={**os.environ, "PYTHONPATH": src_path},
)

print(f"\nReturn code: {result.returncode}")
sys.exit(result.returncode)
