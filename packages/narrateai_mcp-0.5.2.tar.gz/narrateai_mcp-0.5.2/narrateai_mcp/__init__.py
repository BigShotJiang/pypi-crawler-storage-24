"""NarrateAI MCP Server - Get timed transcript with workflow understanding from silent videos."""
