"""Client for NarrateAI backend API - handles upload, process, status, transcript."""

import asyncio
import os
import time
import logging
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)


def _error_msg_static(e: Exception) -> str:
    """Build a non-empty error message including the exception type."""
    msg = str(e)
    name = type(e).__name__
    return f"{name}: {msg}" if msg else name


VOICE_ALIAS_MAP = {"male1": "chatterbox"}


class NarrateAIClient:
    """Client for NarrateAI backend API."""

    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._headers = {"Authorization": f"Bearer {api_key}"}

    @staticmethod
    def _resolve_voice_type(voice_type: Optional[str]) -> Optional[str]:
        """Map user-facing voice names to backend values (e.g. male1 → chatterbox)."""
        if not voice_type or not voice_type.strip():
            return None
        v = voice_type.strip().lower()
        return VOICE_ALIAS_MAP.get(v, v)

    async def get_temp_upload_url(self, filename: str = "video.mp4") -> tuple[str, str]:
        """Get signed upload URL and temp_file_path. Returns (upload_url, temp_file_path)."""
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                f"{self.base_url}/api/temp-upload-url",
                data={"filename": filename, "content_type": "video/mp4"},
                headers=self._headers,
            )
            r.raise_for_status()
            data = r.json()
            return data["upload_url"], data["temp_file_path"]

    async def upload_video_to_temp(self, video_bytes: bytes, filename: str = "video.mp4") -> str:
        """Upload video bytes to temp storage. Returns temp_file_path."""
        upload_url, temp_file_path = await self.get_temp_upload_url(filename)
        async with httpx.AsyncClient(timeout=500.0) as client:
            r = await client.put(
                upload_url,
                content=video_bytes,
                headers={"Content-Type": "video/mp4"},
            )
            r.raise_for_status()
        return temp_file_path

    async def start_processing(
        self,
        temp_file_path: str,
        original_filename: str,
        video_duration: Optional[float] = None,
        language: str = "en",
        manual_context: Optional[str] = None,
        generate_document: bool = False,
        document_type: Optional[str] = None,
    ) -> dict[str, Any]:
        """Start video processing. Returns job info with job_id."""
        form = {
            "temp_file_path": temp_file_path,
            "original_filename": original_filename,
            "style": "professional",
            "speed": "1.0",
            "video_type": "demo",
            "narration_type": "demo",
            "language": language,
        }
        if video_duration is not None and video_duration > 0:
            form["video_duration"] = str(video_duration)
        if manual_context and manual_context.strip():
            form["manual_context"] = manual_context.strip()
        if generate_document:
            form["generate_document"] = "true"
            if document_type:
                form["document_type"] = document_type

        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/process/temp",
                data=form,
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def abandon_job(self, job_id: str) -> None:
        """Abandon an existing job so a fresh one can be started."""
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(
                f"{self.base_url}/api/abandon-job/{job_id}",
                headers=self._headers,
            )
            r.raise_for_status()

    async def cleanup_job(self, job_id: str) -> None:
        """Request cleanup of temp files for a completed job. Fire-and-forget."""
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                r = await client.post(
                    f"{self.base_url}/api/cleanup-job/{job_id}",
                    headers=self._headers,
                )
                if r.status_code == 200:
                    logger.info(f"Cleanup scheduled for job {job_id}")
                else:
                    logger.warning(f"Cleanup request for {job_id} returned {r.status_code}")
        except Exception as e:
            logger.warning(f"Cleanup request failed for {job_id} (non-fatal): {e}")

    async def upload_voice_sample(
        self,
        job_id: str,
        voice_sample_source: str,
    ) -> str:
        """Upload a voice sample for cloning. Returns the voice_sample_path to use in continue.
        voice_sample_source can be a URL (http/https) or a local file path."""
        source = voice_sample_source.strip()
        if source.startswith(("http://", "https://")):
            async with httpx.AsyncClient(follow_redirects=True, timeout=120.0) as client:
                r = await client.get(source)
                r.raise_for_status()
                audio_bytes = r.content
            filename = source.split("?")[0].rsplit("/", 1)[-1] or "voice_sample.wav"
        else:
            abs_path = os.path.abspath(source)
            if not os.path.exists(abs_path):
                raise FileNotFoundError(f"Voice sample not found: {abs_path}")
            loop = asyncio.get_event_loop()
            audio_bytes = await loop.run_in_executor(None, lambda: open(abs_path, "rb").read())
            filename = os.path.basename(abs_path)

        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/voice-clone/{job_id}",
                files={"voice_sample": (filename, audio_bytes)},
                headers=self._headers,
            )
            r.raise_for_status()
            data = r.json()
        voice_path = data.get("voice_sample_path", f"/api/voice-sample/{job_id}")
        logger.info(f"Voice sample uploaded for job {job_id}: {voice_path}")
        return voice_path

    async def get_status(self, job_id: str) -> dict[str, Any]:
        """Get processing status for a job."""
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/api/status/{job_id}",
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def get_document(self, job_id: str) -> dict[str, Any]:
        """Get generated document for a job. Returns document data + markdown."""
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/api/document/{job_id}",
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def get_transcript(self, job_id: str) -> dict[str, Any]:
        """Get transcript with timed segments. Requires transcript to be ready."""
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/api/transcript/{job_id}",
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def fetch_video_from_url(self, url: str) -> tuple[bytes, str]:
        """Download video from URL. Returns (bytes, filename)."""
        async with httpx.AsyncClient(follow_redirects=True, timeout=500.0) as client:
            r = await client.get(url)
            r.raise_for_status()
            content = r.content
        filename = "video.mp4"
        cd = r.headers.get("content-disposition")
        if cd and "filename=" in cd:
            for part in cd.split(";"):
                if "filename=" in part:
                    filename = part.split("=", 1)[-1].strip('"\'')
                    break
        elif "/" in url:
            path = url.split("?")[0]
            name = path.rsplit("/", 1)[-1]
            if name and "." in name:
                filename = name
        return content, filename

    async def read_video_from_path(self, path: str) -> tuple[bytes, str]:
        """Read video from local file. Returns (bytes, filename)."""
        abs_path = os.path.abspath(path.strip())
        if not os.path.exists(abs_path):
            raise FileNotFoundError(f"Video file not found: {abs_path}")
        if not os.path.isfile(abs_path):
            raise ValueError(f"Path is not a file: {abs_path}")
        loop = asyncio.get_event_loop()
        content = await loop.run_in_executor(None, lambda: open(abs_path, "rb").read())
        filename = os.path.basename(abs_path)
        return content, filename

    async def _resolve_video_source(self, video_source: str) -> tuple[str, str]:
        """Resolve video_source to (temp_file_path, filename).
        Handles three cases: pre-uploaded temp path, URL, or local file."""
        source = video_source.strip()
        if source.startswith("temp/"):
            filename = source.rsplit("/", 1)[-1]
            logger.info(f"Using pre-uploaded temp path: {source}")
            return source, filename
        if source.startswith(("http://", "https://")):
            logger.info("Downloading video from URL...")
            video_bytes, filename = await self.fetch_video_from_url(source)
        else:
            logger.info("Reading video from local path...")
            video_bytes, filename = await self.read_video_from_path(source)
        logger.info("Uploading to temporary storage...")
        temp_file_path = await self.upload_video_to_temp(video_bytes, filename)
        return temp_file_path, filename

    async def start_transcript_job(
        self,
        video_source: str,
        language: str = "en",
        manual_context: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Start transcript job: get video, upload, start processing. Returns immediately with job_id.
        Poll get_job_result(job_id) every 10-15 seconds until status is transcript_ready or completed.
        """
        temp_file_path, filename = await self._resolve_video_source(video_source)

        logger.info("Starting video processing...")
        job_info = await self.start_processing(
            temp_file_path, filename, language=language, manual_context=manual_context
        )
        if job_info.get("has_active_job"):
            logger.info("Abandoning existing job to start fresh...")
            await self.abandon_job(job_info["job_id"])
            job_info = await self.start_processing(
                temp_file_path, filename, language=language, manual_context=manual_context
            )
        job_id = job_info["job_id"]
        db_job_id = job_info.get("db_job_id") or job_id
        logger.info(
            f"Job started: job_id={job_id}, db_job_id={db_job_id}, "
            f"raw_db_job_id={job_info.get('db_job_id')}"
        )
        return {
            "job_id": job_id,
            "db_job_id": db_job_id,
            "status": "processing",
            "message": "Job started. Poll get_job_result(job_id) every 10-15 seconds.",
        }

    async def start_transcribe_job(
        self,
        video_source: str,
        source_language: str,
    ) -> dict[str, Any]:
        """
        Start transcription-only job: video with existing voice -> speech-to-text.
        Uses Whisper/Qwen (same as auto-dubbing). Returns original speech, NOT translated.
        source_language is REQUIRED - agent MUST ask user if not specified.
        Supported: en, zh, yue, fr, de, it, ja, ko, pt, ru, es (Qwen) + others via Whisper.
        """
        temp_file_path, filename = await self._resolve_video_source(video_source)

        form = {
            "temp_file_path": temp_file_path,
            "original_filename": filename,
            "source_language": source_language.strip().lower(),
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/process/transcribe",
                data=form,
                headers=self._headers,
            )
            r.raise_for_status()
            job_info = r.json()

        if job_info.get("has_active_job"):
            logger.info("Abandoning existing job to start fresh...")
            await self.abandon_job(job_info["job_id"])
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(
                    f"{self.base_url}/api/process/transcribe",
                    data=form,
                    headers=self._headers,
                )
                r.raise_for_status()
                job_info = r.json()

        job_id = job_info["job_id"]
        db_job_id = job_info.get("db_job_id") or job_id
        return {
            "job_id": job_id,
            "db_job_id": db_job_id,
            "status": "processing",
            "message": "Transcription started. Poll get_job_result(job_id) every 10-15 seconds.",
        }

    async def transcribe_video_and_wait(
        self,
        video_source: str,
        source_language: str,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """Transcription with built-in polling. Polls every 25s, max 15 min."""
        start_result = await self.start_transcribe_job(
            video_source=video_source,
            source_language=source_language,
        )
        job_id = start_result["job_id"]
        db_job_id = start_result.get("db_job_id") or job_id

        start = time.time()
        status = ""
        progress = 0
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            progress = result.get("progress", 0)

            if status == "transcript_ready":
                return {
                    "transcript": result.get("transcript", []),
                    "total_duration": result.get("total_duration"),
                    "total_words": result.get("total_words"),
                    "workflow_understanding": result.get("workflow_understanding"),
                    "visual_timeline": result.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "completed":
                data = await self.get_transcript(job_id)
                return {
                    "transcript": data.get("transcript", []),
                    "total_duration": data.get("total_duration"),
                    "total_words": data.get("total_words"),
                    "workflow_understanding": data.get("workflow_understanding"),
                    "visual_timeline": data.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "failed":
                raise RuntimeError(result.get("error_message", "Transcription failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Transcription not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": status,
            "progress": progress,
        }

    async def start_translate_job(
        self,
        video_source: str,
        source_language: str,
        target_language: str,
    ) -> dict[str, Any]:
        """
        Start translation job (new upload): video with voice -> transcribe -> translate.
        Returns translated transcript. Agent MUST ask for source_language and target_language if not specified.
        """
        temp_file_path, filename = await self._resolve_video_source(video_source)

        form = {
            "temp_file_path": temp_file_path,
            "original_filename": filename,
            "source_language": source_language.strip().lower(),
            "target_language": target_language.strip().lower(),
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/process/translate",
                data=form,
                headers=self._headers,
            )
            r.raise_for_status()
            job_info = r.json()

        if job_info.get("has_active_job"):
            logger.info("Abandoning existing job to start fresh...")
            await self.abandon_job(job_info["job_id"])
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(
                    f"{self.base_url}/api/process/translate",
                    data=form,
                    headers=self._headers,
                )
                r.raise_for_status()
                job_info = r.json()

        job_id = job_info["job_id"]
        db_job_id = job_info.get("db_job_id") or job_id
        return {
            "job_id": job_id,
            "db_job_id": db_job_id,
            "status": "processing",
            "message": "Translation started. Poll get_job_result(job_id) every 10-15 seconds.",
        }

    async def translate_video_and_wait(
        self,
        video_source: str,
        source_language: str,
        target_language: str,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """Translation with built-in polling. Polls every 25s, max 15 min."""
        start_result = await self.start_translate_job(
            video_source=video_source,
            source_language=source_language,
            target_language=target_language,
        )
        job_id = start_result["job_id"]
        db_job_id = start_result.get("db_job_id") or job_id

        start = time.time()
        status = ""
        progress = 0
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            progress = result.get("progress", 0)

            if status == "transcript_ready":
                return {
                    "transcript": result.get("transcript", []),
                    "total_duration": result.get("total_duration"),
                    "total_words": result.get("total_words"),
                    "workflow_understanding": result.get("workflow_understanding"),
                    "visual_timeline": result.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "completed":
                data = await self.get_transcript(job_id)
                return {
                    "transcript": data.get("transcript", []),
                    "total_duration": data.get("total_duration"),
                    "total_words": data.get("total_words"),
                    "workflow_understanding": data.get("workflow_understanding"),
                    "visual_timeline": data.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "failed":
                raise RuntimeError(result.get("error_message", "Translation failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Translation not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": status,
            "progress": progress,
        }

    async def start_dub_video_full_job(
        self,
        video_source: str,
        source_language: str,
        target_language: str,
        preserve_background_music: bool,
    ) -> dict[str, Any]:
        """
        Full auto-dubbing: transcribe -> translate -> extract voice -> TTS with cloned voice -> dubbed video.
        No refinement screen. Uses video's speaker voice. Agent MUST ask for preserve_background_music.
        """
        temp_file_path, filename = await self._resolve_video_source(video_source)

        form = {
            "temp_file_path": temp_file_path,
            "original_filename": filename,
            "source_language": source_language.strip().lower(),
            "target_language": target_language.strip().lower(),
            "preserve_background_music": "true" if preserve_background_music else "false",
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/process/dubbing-full",
                data=form,
                headers=self._headers,
            )
            r.raise_for_status()
            job_info = r.json()

        if job_info.get("has_active_job"):
            logger.info("Abandoning existing job to start fresh...")
            await self.abandon_job(job_info["job_id"])
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(
                    f"{self.base_url}/api/process/dubbing-full",
                    data=form,
                    headers=self._headers,
                )
                r.raise_for_status()
                job_info = r.json()

        job_id = job_info["job_id"]
        db_job_id = job_info.get("db_job_id") or job_id
        return {
            "job_id": job_id,
            "db_job_id": db_job_id,
            "status": "processing",
            "message": "Full auto-dubbing started. Poll get_job_result(job_id) every 10-15 seconds until completed.",
        }

    async def dub_video_full_and_wait(
        self,
        video_source: str,
        source_language: str,
        target_language: str,
        preserve_background_music: bool,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """
        Full auto-dubbing with built-in polling. Starts job, polls every 25s, returns when done or after 15 min.
        Reduces agent polling spam. Returns video_url when completed, or job_id + message when timeout.
        """
        start_result = await self.start_dub_video_full_job(
            video_source=video_source,
            source_language=source_language,
            target_language=target_language,
            preserve_background_music=preserve_background_music,
        )
        job_id = start_result["job_id"]
        db_job_id = start_result.get("db_job_id") or job_id

        start = time.time()
        last_status = ""
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            last_status = status

            if status == "completed":
                await self.cleanup_job(db_job_id)
                return {
                    "status": "completed",
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                    "video_url": result.get("video_url", ""),
                }
            if status == "failed":
                await self.cleanup_job(db_job_id)
                raise RuntimeError(result.get("error_message", "Dubbing failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Job still running after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": last_status,
        }

    async def translate_existing_transcript(
        self,
        job_id: str,
        source_language: str,
        target_language: str,
    ) -> dict[str, Any]:
        """
        Translate transcript of an existing narrated/dubbed video. Loads from cloud, translates, returns.
        Sync - no polling. job_id is the completed video's job ID from the user's library.
        """
        form = {
            "job_id": job_id,
            "source_language": source_language.strip().lower(),
            "target_language": target_language.strip().lower(),
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/translate-transcript",
                data=form,
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def get_job_result(self, job_id: str, db_job_id: Optional[str] = None) -> dict[str, Any]:
        """
        Get job status and result. Returns status: processing | transcript_ready | completed | failed.
        When transcript_ready: includes transcript. When completed: includes video_url.
        Use db_job_id for video_url when available (same as job_id in most cases).
        """
        status_data = await self.get_status(job_id)
        effective_db = db_job_id or status_data.get("db_job_id") or job_id
        status = status_data.get("status", "")
        progress = status_data.get("progress", 0)
        err_msg = status_data.get("error_message", "")

        if status in ("failed", "error") or (err_msg and isinstance(err_msg, str)):
            return {
                "status": "failed",
                "error_message": err_msg or "Processing failed",
            }

        transcript_ready_statuses = ("awaiting_refinement", "refinement", "awaiting_voice")
        if status in transcript_ready_statuses:
            data = await self.get_transcript(job_id)
            return {
                "status": "transcript_ready",
                "job_id": job_id,
                "db_job_id": effective_db,
                "transcript": data.get("transcript", []),
                "total_duration": data.get("total_duration"),
                "total_words": data.get("total_words"),
                "workflow_understanding": data.get("workflow_understanding"),
                "visual_timeline": data.get("visual_timeline"),
            }

        if status == "completed":
            video_url = None
            for vid_id in dict.fromkeys([effective_db, job_id]):
                try:
                    video_url = await self.get_video_url(vid_id)
                    break
                except httpx.HTTPStatusError as e:
                    if e.response.status_code == 404:
                        logger.warning(
                            f"video-url 404 for id={vid_id} "
                            f"(job_id={job_id}, db_job_id={db_job_id})"
                        )
                        continue
                    raise
            if not video_url:
                raise RuntimeError(
                    f"Video completed but URL not found for job_id={job_id}, db_job_id={db_job_id}"
                )
            await self.cleanup_job(effective_db)
            return {
                "status": "completed",
                "job_id": job_id,
                "db_job_id": effective_db,
                "video_url": video_url,
            }

        return {
            "status": "processing",
            "job_id": job_id,
            "db_job_id": effective_db,
            "progress": progress,
        }

    async def _poll_job_result(
        self, job_id: str, db_job_id: Optional[str] = None, max_retries: int = 3
    ) -> dict[str, Any]:
        """Resilient wrapper around get_job_result for polling loops.
        Retries transient errors (timeouts, connection issues) instead of crashing the tool.
        If all retries fail, returns a 'processing' status so the loop continues."""
        for attempt in range(max_retries):
            try:
                return await self.get_job_result(job_id, db_job_id)
            except Exception as e:
                error_type = type(e).__name__
                error_msg = str(e) or error_type
                logger.warning(
                    f"Poll attempt {attempt + 1}/{max_retries} failed ({error_type}: {error_msg})"
                )
                if attempt < max_retries - 1:
                    await asyncio.sleep(5)
                else:
                    logger.error(
                        f"All {max_retries} poll attempts failed, returning processing status"
                    )
                    return {
                        "status": "processing",
                        "job_id": job_id,
                        "db_job_id": db_job_id or job_id,
                        "progress": 0,
                    }
        return {"status": "processing", "job_id": job_id, "db_job_id": db_job_id or job_id, "progress": 0}

    async def generate_narration_script(
        self,
        video_source: str,
        language: str = "en",
        manual_context: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """
        Generate AI narration script for a silent video. Uploads, processes, polls until transcript ready.
        Returns transcript data with timed segments and workflow understanding.
        Polls every 25s, max 15 min. On timeout returns job_id for get_job_result.
        """
        start_result = await self.start_transcript_job(
            video_source=video_source,
            language=language,
            manual_context=manual_context,
        )
        job_id = start_result["job_id"]
        db_job_id = start_result.get("db_job_id") or job_id

        start = time.time()
        status = ""
        progress = 0
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            progress = result.get("progress", 0)

            if status == "transcript_ready":
                return {
                    "transcript": result.get("transcript", []),
                    "total_duration": result.get("total_duration"),
                    "total_words": result.get("total_words"),
                    "workflow_understanding": result.get("workflow_understanding"),
                    "visual_timeline": result.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "completed":
                data = await self.get_transcript(job_id)
                return {
                    "transcript": data.get("transcript", []),
                    "total_duration": data.get("total_duration"),
                    "total_words": data.get("total_words"),
                    "workflow_understanding": data.get("workflow_understanding"),
                    "visual_timeline": data.get("visual_timeline"),
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                }
            if status == "failed":
                raise RuntimeError(result.get("error_message", "Processing failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Transcript not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": status,
            "progress": progress,
        }

    async def continue_to_video(
        self,
        job_id: str,
        voice_type: Optional[str] = None,
        voice_sample_path: Optional[str] = None,
    ) -> None:
        """Continue processing from transcript to full narrated video.
        If voice_sample_path is set, uses cloned voice instead of a preset AI voice."""
        data: dict[str, str] = {}
        if voice_sample_path:
            data["voice_sample_path"] = voice_sample_path
        elif voice_type and voice_type.strip():
            data["voice_type"] = self._resolve_voice_type(voice_type) or voice_type.strip()
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                f"{self.base_url}/api/continue/{job_id}",
                data=data,
                headers=self._headers,
            )
            r.raise_for_status()

    async def get_video_url(self, job_id: str) -> str:
        """Get signed URL for completed narrated video."""
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(
                f"{self.base_url}/api/video-url/{job_id}",
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()["video_url"]

    async def start_full_video_job(
        self,
        video_source: str,
        language: str = "en",
        manual_context: Optional[str] = None,
        voice_type: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Start full video job: upload and start processing. Returns immediately with job_id.
        Poll get_job_result(job_id) until transcript_ready, then call continue_to_video(job_id, voice_type),
        then poll get_job_result until completed.
        """
        result = await self.start_transcript_job(
            video_source=video_source,
            language=language,
            manual_context=manual_context,
        )
        resolved = self._resolve_voice_type(voice_type)
        if resolved:
            result["voice_type"] = resolved
        return result

    async def continue_to_video_start(
        self,
        job_id: str,
        voice_type: Optional[str] = None,
        voice_sample_path: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Start continue-to-video: triggers TTS and video assembly. Returns immediately.
        Poll get_job_result(job_id) every 10-15 seconds until status is completed.
        """
        await self.continue_to_video(job_id, voice_type=voice_type, voice_sample_path=voice_sample_path)
        return {
            "job_id": job_id,
            "status": "processing",
            "message": "Video generation started. Poll get_job_result(job_id) every 10-15 seconds.",
        }

    async def continue_to_full_video_and_wait(
        self,
        job_id: str,
        voice_type: Optional[str] = None,
        voice_sample_path: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
        db_job_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Continue to video with built-in polling. Polls every 25s, max 15 min."""
        await self.continue_to_video(job_id, voice_type=voice_type, voice_sample_path=voice_sample_path)
        db_job_id = db_job_id or job_id

        start = time.time()
        last_status = ""
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            last_status = status

            if status == "completed":
                await self.cleanup_job(db_job_id)
                return {
                    "status": "completed",
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                    "video_url": result.get("video_url", ""),
                }
            if status == "failed":
                await self.cleanup_job(db_job_id)
                raise RuntimeError(result.get("error_message", "Video generation failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Video not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": last_status,
        }

    async def narrate_video_full(
        self,
        video_source: str,
        language: str = "en",
        manual_context: Optional[str] = None,
        voice_type: Optional[str] = None,
        voice_sample_source: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """
        Full flow: transcript + continue to video, poll until completed.
        Returns video_url and transcript. Polls every 25s, max 15 min. On timeout returns job_id.
        If voice_sample_source is provided, uploads it for cloning instead of using a preset voice.
        """
        transcript_data = await self.generate_narration_script(
            video_source=video_source,
            language=language,
            manual_context=manual_context,
            poll_interval=poll_interval,
            max_wait_seconds=max_wait_seconds,
        )
        if transcript_data.get("status") == "timeout":
            return transcript_data

        job_id = transcript_data.get("job_id")
        db_job_id = transcript_data.get("db_job_id") or job_id

        voice_sample_path = None
        if voice_sample_source:
            logger.info("Uploading voice sample for cloning...")
            voice_sample_path = await self.upload_voice_sample(job_id, voice_sample_source)

        logger.info("Continuing to full narrated video...")
        await self.continue_to_video(job_id, voice_type=voice_type, voice_sample_path=voice_sample_path)
        start = time.time()
        last_status = ""
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            last_status = status
            if status == "completed":
                await self.cleanup_job(db_job_id)
                return {
                    "video_url": result.get("video_url", ""),
                    "job_id": db_job_id,
                    "transcript": transcript_data.get("transcript", []),
                    "total_duration": transcript_data.get("total_duration"),
                    "total_words": transcript_data.get("total_words"),
                }
            if status == "failed":
                await self.cleanup_job(db_job_id)
                raise RuntimeError(result.get("error_message", "Processing failed"))
            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Video not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": last_status,
        }

    async def narrate_batch_and_wait(
        self,
        video_sources: list[str],
        language: str = "en",
        voice_type: Optional[str] = None,
        manual_context: Optional[str] = None,
        per_video_contexts: Optional[list[Optional[str]]] = None,
        max_concurrent: int = 5,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 1800.0,
    ) -> list[dict[str, Any]]:
        """
        Batch narration: process multiple videos in parallel.
        Each video runs the full narrate_video_full flow independently.
        Caps at max_concurrent (default 5). Timeout per video: 30 min.
        One failure does not affect other videos.
        per_video_contexts overrides manual_context on a per-video basis.
        """
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(
                f"Batch capped at {max_concurrent} videos "
                f"({len(video_sources)} requested)"
            )

        tasks = [
            self.narrate_video_full(
                video_source=src.strip(),
                language=language,
                voice_type=voice_type,
                manual_context=(
                    per_video_contexts[i]
                    if per_video_contexts and i < len(per_video_contexts) and per_video_contexts[i]
                    else manual_context
                ),
                poll_interval=poll_interval,
                max_wait_seconds=max_wait_seconds,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def start_batch_jobs(
        self,
        video_sources: list[str],
        language: str = "en",
        voice_type: Optional[str] = None,
        manual_context: Optional[str] = None,
        per_video_contexts: Optional[list[Optional[str]]] = None,
        max_concurrent: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Start multiple narration jobs in parallel without waiting.
        Returns list of job_ids for the agent to poll individually.
        per_video_contexts overrides manual_context on a per-video basis.
        """
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.start_full_video_job(
                video_source=src.strip(),
                language=language,
                manual_context=(
                    per_video_contexts[i]
                    if per_video_contexts and i < len(per_video_contexts) and per_video_contexts[i]
                    else manual_context
                ),
                voice_type=voice_type,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def _auto_continue_worker(
        self,
        job_id: str,
        voice_type: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 1800.0,
    ) -> None:
        """Background worker: polls a job until transcript_ready, then auto-calls continue_to_video.
        Fire-and-forget — the agent never sees this; it just polls get_job_result normally."""
        start = time.time()
        while time.time() - start < max_wait_seconds:
            try:
                result = await self._poll_job_result(job_id)
                status = result.get("status", "")
                if status == "transcript_ready":
                    logger.info(f"Auto-continue triggered for job {job_id}")
                    await self.continue_to_video(job_id, voice_type=voice_type)
                    return
                if status in ("completed", "failed"):
                    return
            except Exception:
                logger.warning(f"Auto-continue poll error for {job_id}, will retry")
            await asyncio.sleep(poll_interval)
        logger.warning(f"Auto-continue timed out for job {job_id} after {max_wait_seconds}s")

    async def start_batch_jobs_auto_continue(
        self,
        video_sources: list[str],
        language: str = "en",
        voice_type: Optional[str] = None,
        manual_context: Optional[str] = None,
        per_video_contexts: Optional[list[Optional[str]]] = None,
        max_concurrent: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Start batch jobs AND spawn background tasks that auto-continue each job
        when transcript_ready. The agent only needs to poll get_job_result for
        each returned job_id until completed — no continue_to_full_video needed.
        """
        results = await self.start_batch_jobs(
            video_sources=video_sources,
            language=language,
            voice_type=voice_type,
            manual_context=manual_context,
            per_video_contexts=per_video_contexts,
            max_concurrent=max_concurrent,
        )

        for item in results:
            job_id = item.get("job_id")
            if job_id and item.get("status") != "failed":
                asyncio.create_task(
                    self._auto_continue_worker(job_id, voice_type=voice_type)
                )

        return results

    async def batch_generate_scripts_and_wait(
        self,
        video_sources: list[str],
        language: str = "en",
        manual_context: Optional[str] = None,
        per_video_contexts: Optional[list[Optional[str]]] = None,
        max_concurrent: int = 5,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> list[dict[str, Any]]:
        """Batch script generation with polling. Each video gets generate_narration_script."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.generate_narration_script(
                video_source=src.strip(),
                language=language,
                manual_context=(
                    per_video_contexts[i]
                    if per_video_contexts and i < len(per_video_contexts) and per_video_contexts[i]
                    else manual_context
                ),
                poll_interval=poll_interval,
                max_wait_seconds=max_wait_seconds,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def start_batch_script_jobs(
        self,
        video_sources: list[str],
        language: str = "en",
        manual_context: Optional[str] = None,
        per_video_contexts: Optional[list[Optional[str]]] = None,
        max_concurrent: int = 5,
    ) -> list[dict[str, Any]]:
        """Start batch script jobs without waiting. Returns job_ids for polling."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.start_transcript_job(
                video_source=src.strip(),
                language=language,
                manual_context=(
                    per_video_contexts[i]
                    if per_video_contexts and i < len(per_video_contexts) and per_video_contexts[i]
                    else manual_context
                ),
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def batch_transcribe_and_wait(
        self,
        video_sources: list[str],
        source_language: str,
        max_concurrent: int = 5,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> list[dict[str, Any]]:
        """Batch transcription with polling. Each video gets transcribe_video_and_wait."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.transcribe_video_and_wait(
                video_source=src.strip(),
                source_language=source_language,
                poll_interval=poll_interval,
                max_wait_seconds=max_wait_seconds,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def start_batch_transcribe_jobs(
        self,
        video_sources: list[str],
        source_language: str,
        max_concurrent: int = 5,
    ) -> list[dict[str, Any]]:
        """Start batch transcription jobs without waiting. Returns job_ids for polling."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.start_transcribe_job(
                video_source=src.strip(),
                source_language=source_language,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def batch_dub_and_wait(
        self,
        video_sources: list[str],
        source_language: str,
        target_language: str,
        preserve_background_music: bool,
        max_concurrent: int = 5,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 1800.0,
    ) -> list[dict[str, Any]]:
        """Batch dubbing with polling. Each video gets dub_video_full_and_wait."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.dub_video_full_and_wait(
                video_source=src.strip(),
                source_language=source_language,
                target_language=target_language,
                preserve_background_music=preserve_background_music,
                poll_interval=poll_interval,
                max_wait_seconds=max_wait_seconds,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    async def start_batch_dub_jobs(
        self,
        video_sources: list[str],
        source_language: str,
        target_language: str,
        preserve_background_music: bool,
        max_concurrent: int = 5,
    ) -> list[dict[str, Any]]:
        """Start batch dubbing jobs without waiting. Returns job_ids for polling."""
        sources = video_sources[:max_concurrent]
        if len(video_sources) > max_concurrent:
            logger.warning(f"Batch capped at {max_concurrent} ({len(video_sources)} requested)")

        tasks = [
            self.start_dub_video_full_job(
                video_source=src.strip(),
                source_language=source_language,
                target_language=target_language,
                preserve_background_music=preserve_background_music,
            )
            for i, src in enumerate(sources)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._format_batch_results(sources, results)

    def _format_batch_results(
        self, sources: list[str], results: list
    ) -> list[dict[str, Any]]:
        """Format batch gather results into a consistent output list."""
        output: list[dict[str, Any]] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                output.append({
                    "video_source": sources[i],
                    "status": "failed",
                    "error": _error_msg_static(result),
                })
            else:
                if isinstance(result, dict):
                    result["video_source"] = sources[i]
                output.append(result)
        return output

    async def update_transcript(
        self,
        job_id: str,
        transcript: list[dict[str, Any]],
        reset_for_reprocessing: bool = False,
        target_language: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update transcript chunks for a job. Each chunk needs start_time, end_time, text.
        Optional: pause_duration, chunk_type. Used for editing before continue-to-video.
        Set reset_for_reprocessing=True to flip a completed job back to awaiting_refinement.
        When target_language is provided with reset_for_reprocessing, also updates the job's language."""
        payload: dict[str, Any] = {"transcript": transcript}
        if reset_for_reprocessing:
            payload["reset_for_reprocessing"] = True
            if target_language:
                payload["target_language"] = target_language.strip().lower()
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                f"{self.base_url}/api/update-transcript/{job_id}",
                json=payload,
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def list_videos(
        self,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """Get paginated list of user's processed videos from the library."""
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{self.base_url}/video/jobs",
                params={"page": page, "per_page": per_page},
                headers=self._headers,
            )
            r.raise_for_status()
            return r.json()

    async def start_document_job(
        self,
        video_source: str,
        document_type: str = "user_onboarding",
        language: str = "en",
        manual_context: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Start document generation job: upload video, process with generate_document=True.
        Returns immediately with job_id. Poll get_job_result until transcript_ready,
        then fetch document with get_document.
        """
        temp_file_path, filename = await self._resolve_video_source(video_source)

        logger.info("Starting video processing with document generation...")
        job_info = await self.start_processing(
            temp_file_path,
            filename,
            language=language,
            manual_context=manual_context,
            generate_document=True,
            document_type=document_type,
        )
        if job_info.get("has_active_job"):
            logger.info("Abandoning existing job to start fresh...")
            await self.abandon_job(job_info["job_id"])
            job_info = await self.start_processing(
                temp_file_path,
                filename,
                language=language,
                manual_context=manual_context,
                generate_document=True,
                document_type=document_type,
            )
        job_id = job_info["job_id"]
        db_job_id = job_info.get("db_job_id") or job_id
        return {
            "job_id": job_id,
            "db_job_id": db_job_id,
            "status": "processing",
            "message": "Document generation started. Poll get_job_result(job_id) every 10-15 seconds.",
        }

    async def generate_document_and_wait(
        self,
        video_source: str,
        document_type: str = "user_onboarding",
        language: str = "en",
        manual_context: Optional[str] = None,
        poll_interval: float = 25.0,
        max_wait_seconds: float = 900.0,
    ) -> dict[str, Any]:
        """
        Full document generation flow: upload, process with generate_document=True,
        poll until transcript_ready, then fetch both document and transcript.
        Document is generated during the transcription phase, so it's available
        when status reaches transcript_ready.
        """
        start_result = await self.start_document_job(
            video_source=video_source,
            document_type=document_type,
            language=language,
            manual_context=manual_context,
        )
        job_id = start_result["job_id"]
        db_job_id = start_result.get("db_job_id") or job_id

        start = time.time()
        status = ""
        progress = 0
        while time.time() - start < max_wait_seconds:
            result = await self._poll_job_result(job_id, db_job_id)
            status = result.get("status", "")
            progress = result.get("progress", 0)

            if status in ("transcript_ready", "completed"):
                doc_data = await self.get_document(db_job_id)
                return {
                    "status": "document_ready",
                    "job_id": job_id,
                    "db_job_id": db_job_id,
                    "document_type": document_type,
                    "document_markdown": doc_data.get("edited_markdown") or doc_data.get("markdown", ""),
                    "document_data": doc_data.get("document"),
                    "transcript": result.get("transcript", []),
                    "total_duration": result.get("total_duration"),
                    "total_words": result.get("total_words"),
                    "workflow_understanding": result.get("workflow_understanding"),
                    "has_synced_transcript": bool(result.get("transcript")),
                }
            if status == "failed":
                raise RuntimeError(result.get("error_message", "Document generation failed"))

            await asyncio.sleep(poll_interval)

        return {
            "status": "timeout",
            "job_id": job_id,
            "db_job_id": db_job_id,
            "message": f"Document not ready after {max_wait_seconds}s. Use get_job_result(job_id) to check status.",
            "last_status": status,
            "progress": progress,
        }
