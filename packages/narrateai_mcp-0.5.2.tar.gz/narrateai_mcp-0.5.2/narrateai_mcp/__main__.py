"""Allow running with: python -m narrateai_mcp"""

from .server import main

main()
