"""MCP server for NarrateAI - exposes video narration, transcription, dubbing, and document tools."""

import contextvars
import json
import logging
import os
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .client import NarrateAIClient

_header_api_key: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_header_api_key", default=None
)

_http_mode: bool = False

# MCP stdio: never write to stdout (reserved for JSON-RPC). Use stderr for logs.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("narrateai-mcp")

mcp = FastMCP(
    "narrateai",
    json_response=True,
)


def _error_msg(e: Exception) -> str:
    """Build a non-empty error message including the exception type."""
    msg = str(e)
    name = type(e).__name__
    return f"{name}: {msg}" if msg else name


def _get_client(api_key: Optional[str] = None) -> NarrateAIClient:
    """Get API client. Key priority: tool param > env var > HTTP header (Smithery)."""
    key = api_key or os.environ.get("NARRATEAI_API_KEY") or _header_api_key.get()
    if not key:
        raise ValueError(
            "API key required. Set NARRATEAI_API_KEY env var, pass api_key to the tool, "
            "or provide x-api-key header (Smithery/remote)."
        )
    base = os.environ.get("NARRATEAI_API_BASE_URL", "http://localhost:8000")
    return NarrateAIClient(base_url=base, api_key=key)


@mcp.tool()
async def get_job_result(
    job_id: str,
    api_key: str = "",
    db_job_id: str = "",
) -> str:
    """
    Get job status and result. Use when a tool returned status=timeout, or to check status of any job.

    Returns: status (processing | transcript_ready | completed | failed), plus transcript when transcript_ready,
    or video_url when completed.

    Args:
        job_id: The job_id from a start tool or from a timeout response.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        db_job_id: Optional. Use when different from job_id (e.g. for video_url). Usually same as job_id.
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        result = await client.get_job_result(
            job_id, db_job_id=db_job_id.strip() or None
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("get_job_result failed")
        return json.dumps({"status": "failed", "error_message": _error_msg(e)}, indent=2)


@mcp.tool()
async def get_upload_url(
    filename: str,
    api_key: str = "",
) -> str:
    """
    GET A SIGNED UPLOAD URL for uploading a local video to NarrateAI cloud storage.

    Use this ONLY when running in HTTP/remote mode and the user has a local video file.
    After getting the URL, upload the file with curl, then pass the returned temp_file_path
    to any processing tool as the video_source.

    For stdio/local mode this is NOT needed — tools can read local files directly.

    Args:
        filename: Original filename of the video (e.g. "demo.mp4").
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).

    Returns:
        JSON with upload_url, temp_file_path, and a ready-to-use curl command.
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        upload_url, temp_file_path = await client.get_temp_upload_url(filename)
        return json.dumps({
            "upload_url": upload_url,
            "temp_file_path": temp_file_path,
            "instructions": (
                f"Upload the file with: curl -X PUT -H 'Content-Type: video/mp4' "
                f"--upload-file '<LOCAL_FILE_PATH>' '{upload_url}' "
                f"Then pass '{temp_file_path}' as video_source to any processing tool."
            ),
        }, indent=2)
    except Exception as e:
        logger.exception("get_upload_url failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def generate_narration_script(
    video_source: str,
    api_key: str = "",
    language: str = "en",
    manual_context: str = "",
) -> str:
    """
    NARRATION SCRIPT – generates an AI-written timed script for a SILENT video. No audio output.

    Use when the user wants a timed narration script, text-only narration, or sync data for a silent video.
    This does NOT extract existing speech (use transcribe_video for that).
    This does NOT produce a video file (use narrate_video_full for that).

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with get_job_result.

    Args:
        video_source: Either a public URL (http/https) of the video, or a local file path.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        language: Language code for narration (en, es, fr, de, etc.). Default: en.
        manual_context: Optional description of the video for better narration.

    Returns:
        JSON with transcript, job_id, db_job_id. Or job_id for polling (HTTP mode).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_transcript_job(
                video_source=video_source,
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
            )
        else:
            result = await client.generate_narration_script(
                video_source=video_source,
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("generate_narration_script failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def narrate_video_full(
    video_source: str,
    api_key: str = "",
    language: str = "en",
    manual_context: str = "",
    voice_type: str = "",
    voice_sample: str = "",
) -> str:
    """
    FULL NARRATED VIDEO – produces a downloadable video with AI voiceover.

    Use when the user wants: "narrate this video", "add voiceover", "make a narrated video".

    VOICE OPTIONS — ask the user which they prefer:
    1. AI voice: male1 (default, fastest), female1 (default, fastest), female2, female3, female4, male2, male3
    2. Voice cloning: user provides an audio file (voice_sample) and their voice is cloned for the narration

    If voice_sample is provided, it takes priority over voice_type.

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with
    get_job_result every 25s. When transcript_ready, call continue_to_full_video. Then poll again until completed.

    Args:
        video_source: Either a public URL (http/https) or local file path.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        language: Language code (en, es, fr, de, etc.). Default: en.
        manual_context: Optional description of the video for better narration.
        voice_type: AI voice preset. Ask the user if not specified. Options: male1, female1, female2, female3, female4, male2, male3.
        voice_sample: Optional. Path to audio file (local path or URL) for voice cloning. When provided, the narration uses the cloned voice instead of an AI preset.

    Returns:
        JSON with video_url, transcript, job_id when done. Or job_id for polling (HTTP mode).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_full_video_job(
                video_source=video_source,
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
                voice_type=voice_type.strip() if voice_type else None,
            )
        else:
            result = await client.narrate_video_full(
                video_source=video_source,
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
                voice_type=voice_type.strip() if voice_type else None,
                voice_sample_source=voice_sample.strip() if voice_sample else None,
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("narrate_video_full failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def abandon_job(
    job_id: str,
    api_key: str = "",
) -> str:
    """
    Abandon/cancel a processing job. Call this when the user cancels on the agent side.

    Stops the backend from continuing audio generation and video assembly.
    Use after narrate_video_transcript or when continue_to_full_video was started but user cancelled.

    Args:
        job_id: The db_job_id or job_id from narrate_video_transcript.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).

    Returns:
        JSON with success or error.
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        await client.abandon_job(job_id)
        return json.dumps({"success": True, "message": "Job abandoned successfully"}, indent=2)
    except Exception as e:
        logger.exception("abandon_job failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def transcribe_video(
    video_source: str,
    source_language: str,
    api_key: str = "",
) -> str:
    """
    TRANSCRIPTION ONLY – video with existing voice -> speech-to-text -> timed transcript.
    No translation, no narrated video. Returns original speech as-is.

    Use when the user wants to transcribe a video that already has spoken audio
    (podcast, interview, meeting recording, etc.).

    CRITICAL: source_language is REQUIRED. If the user does not specify the language
    of the video, you MUST ask them concisely before calling. Supported: en, zh, yue,
    fr, de, it, ja, ko, pt, ru, es (Qwen) + others via Whisper.

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with get_job_result.

    Args:
        video_source: Either a public URL (http/https) of the video, or a local file path.
        source_language: Language of the speech in the video (REQUIRED). Ask user if not specified.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).

    Returns:
        JSON with transcript, job_id, db_job_id when done. Or job_id for polling (HTTP mode).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_transcribe_job(
                video_source=video_source,
                source_language=source_language.strip(),
            )
        else:
            result = await client.transcribe_video_and_wait(
                video_source=video_source,
                source_language=source_language.strip(),
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("transcribe_video failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def translate_video(
    video_source: str,
    source_language: str,
    target_language: str,
    api_key: str = "",
) -> str:
    """
    TRANSLATION (new upload) – video with voice -> transcribe -> translate -> translated transcript.
    No TTS, no video output. Returns translated timed transcript.

    Use when the user uploads a new video and wants a translated transcript
    (e.g. Spanish podcast -> English transcript).

    CRITICAL: source_language and target_language are REQUIRED. Ask user if not specified.

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with get_job_result.

    Args:
        video_source: Public URL or local file path of the video.
        source_language: Language of the speech in the video (REQUIRED).
        target_language: Language to translate to (REQUIRED).
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_translate_job(
                video_source=video_source,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
            )
        else:
            result = await client.translate_video_and_wait(
                video_source=video_source,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("translate_video failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def translate_existing_video(
    job_id: str,
    source_language: str,
    target_language: str,
    api_key: str = "",
) -> str:
    """
    TRANSLATION (existing video) – Translate transcript of a video already in the user's library.
    Loads transcript from cloud, translates, returns. No upload. Sync – returns immediately.

    Use when the user wants to translate a video they already narrated/dubbed with NarrateAI
    (e.g. "Translate my video X to French"). job_id is the completed video's job ID.

    CRITICAL: source_language and target_language are REQUIRED. For narrated videos, source is
    typically the narration language (e.g. en). For dubbed videos, source is the dubbed language.

    Args:
        job_id: The job_id of the completed video (from user's library).
        source_language: Language of the current transcript (REQUIRED).
        target_language: Language to translate to (REQUIRED).
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        result = await client.translate_existing_transcript(
            job_id=job_id,
            source_language=source_language.strip(),
            target_language=target_language.strip(),
        )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("translate_existing_video failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def dub_video_full(
    video_source: str,
    source_language: str,
    target_language: str,
    preserve_background_music: bool,
    api_key: str = "",
) -> str:
    """
    FULL AUTO-DUBBING – transcribe -> translate -> extract speaker voice -> TTS with cloned voice -> dubbed video.
    No refinement screen. Uses the video's own speaker voice for the dubbed audio.

    Use when the user wants a complete dubbed video (e.g. Spanish video -> English dubbed).

    CRITICAL: source_language, target_language, and preserve_background_music are REQUIRED.
    Agent MUST ask user for all three if not specified. For preserve_background_music: ask if the video
    has background music they want to keep (true) or replace with silence (false).

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with get_job_result.

    Args:
        video_source: Public URL or local file path of the video.
        source_language: Language of the speech in the video (REQUIRED).
        target_language: Language to dub into (REQUIRED).
        preserve_background_music: Whether to keep background music (REQUIRED - ask user).
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_dub_video_full_job(
                video_source=video_source,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
                preserve_background_music=preserve_background_music,
            )
        else:
            result = await client.dub_video_full_and_wait(
                video_source=video_source,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
                preserve_background_music=preserve_background_music,
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("dub_video_full failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def generate_document(
    video_source: str,
    document_type: str = "user_onboarding",
    api_key: str = "",
    language: str = "en",
    manual_context: str = "",
) -> str:
    """
    DOCUMENT GENERATION – produces a structured markdown document from a silent video.

    Use when the user wants: a document, article, guide, tutorial, or written content
    based on a video. NOT for narrated video or voiceover.

    The agent MUST ask which document type the user wants before calling:
    - user_onboarding: Step-by-step onboarding guide
    - tutorial_guide: Tutorial/how-to guide
    - feature_showcase: Feature showcase document
    - business_overview: Business overview document
    - product_documentation: Product documentation

    Also returns a synced transcript as a bonus – offer it to the user after the document
    is delivered ("I also have a synced transcript for this video, would you like it?").

    Stdio: waits for completion internally. HTTP/remote: returns job_id immediately – poll with get_job_result.

    Args:
        video_source: Either a public URL (http/https) of the video, or a local file path.
        document_type: Type of document to generate (REQUIRED - ask user). Default: user_onboarding.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        language: Language code (en, es, fr, de, etc.). Default: en.
        manual_context: Optional description of the video for better document generation.

    Returns:
        JSON with document_markdown, document_data, transcript, job_id, db_job_id. Or job_id for polling (HTTP mode).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            result = await client.start_document_job(
                video_source=video_source,
                document_type=document_type.strip() if document_type else "user_onboarding",
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
            )
        else:
            result = await client.generate_document_and_wait(
                video_source=video_source,
                document_type=document_type.strip() if document_type else "user_onboarding",
                language=language,
                manual_context=manual_context.strip() if manual_context else None,
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("generate_document failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def narrate_batch(
    video_sources_json: str,
    api_key: str = "",
    language: str = "en",
    voice_type: str = "",
    manual_context: str = "",
    contexts_json: str = "",
) -> str:
    """
    BATCH NARRATION – narrate multiple videos in parallel. Each gets a full narrated video with voiceover.

    Use when the user has multiple videos to narrate (e.g. "narrate these 3 videos").
    Maximum 5 videos per batch. Each video is processed independently – one failure does not affect others.

    If the user does not specify a voice, ask them ONCE (applies to all videos).
    Voice options: male1 (default, fastest), female1 (default, fastest), female2, female3, female4, male2, male3.
    All videos share the same voice and language.

    CRITICAL – Context handling: Before calling, you MUST ask the user about context:
    1. "Would you like to provide the same context for all videos, different context per video, or no context?"
    2. If same for all: use manual_context.
    3. If different per video: use contexts_json (JSON array matching video order). Use empty string for videos without context.
    4. If no context: leave both empty.

    Stdio: waits for all videos to complete and returns final results.
    HTTP/remote: returns job_ids immediately. The server auto-continues each video when
    transcript is ready — just poll get_job_result for each job_id until completed.
    No need to call continue_to_full_video.

    Args:
        video_sources_json: JSON array of video URLs or paths. Example: '["https://example.com/v1.mp4", "https://example.com/v2.mp4"]'
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        language: Language code (en, es, fr, de, etc.). Default: en. Applies to all videos.
        voice_type: AI voice. Ask the user if not specified. Applies to all videos.
        manual_context: Optional shared context for ALL videos. Ignored if contexts_json is provided.
        contexts_json: Optional JSON array of per-video contexts, matching video order. Example: '["onboarding flow", "", "settings walkthrough"]'. Empty string = no context for that video.

    Returns:
        Stdio: JSON array of results with video_url per video. HTTP: JSON array of job_ids — poll each with get_job_result (server auto-continues, no manual continue needed).
    """
    try:
        sources = json.loads(video_sources_json)
        if not isinstance(sources, list) or not all(isinstance(s, str) for s in sources):
            return json.dumps({"error": "video_sources_json must be a JSON array of strings"}, indent=2)
        if len(sources) == 0:
            return json.dumps({"error": "No video sources provided"}, indent=2)
        if len(sources) > 5:
            sources = sources[:5]

        per_video_contexts: list[Optional[str]] = []
        if contexts_json and contexts_json.strip():
            try:
                parsed = json.loads(contexts_json)
                if isinstance(parsed, list):
                    per_video_contexts = [
                        (c.strip() if isinstance(c, str) and c.strip() else None)
                        for c in parsed
                    ]
            except json.JSONDecodeError:
                pass

        shared_context = manual_context.strip() if manual_context else None

        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            results = await client.start_batch_jobs_auto_continue(
                video_sources=sources,
                language=language,
                voice_type=voice_type.strip() if voice_type else None,
                manual_context=shared_context,
                per_video_contexts=per_video_contexts or None,
            )
        else:
            results = await client.narrate_batch_and_wait(
                video_sources=sources,
                language=language,
                voice_type=voice_type.strip() if voice_type else None,
                manual_context=shared_context,
                per_video_contexts=per_video_contexts or None,
            )
        return json.dumps(results, indent=2)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON. Provide a JSON array: '[\"url1\", \"url2\"]'"}, indent=2)
    except Exception as e:
        logger.exception("narrate_batch failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def batch_generate_scripts(
    video_sources_json: str,
    api_key: str = "",
    language: str = "en",
    manual_context: str = "",
    contexts_json: str = "",
) -> str:
    """
    BATCH SCRIPT GENERATION – generate AI narration scripts for multiple silent videos in parallel.
    Each video gets a timed narration script (text only, no audio).

    Maximum 5 videos per batch. One failure does not affect others.

    CRITICAL – Context handling: Before calling, ask the user about context:
    1. Same for all → manual_context. 2. Different per video → contexts_json. 3. No context → leave both empty.

    Stdio: waits for all. HTTP/remote: returns job_ids – poll each with get_job_result.

    Args:
        video_sources_json: JSON array of video URLs or paths.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        language: Language code (default: en). Applies to all videos.
        manual_context: Optional shared context for ALL videos.
        contexts_json: Optional JSON array of per-video contexts.
    """
    try:
        sources = json.loads(video_sources_json)
        if not isinstance(sources, list) or not all(isinstance(s, str) for s in sources):
            return json.dumps({"error": "video_sources_json must be a JSON array of strings"}, indent=2)
        if len(sources) == 0:
            return json.dumps({"error": "No video sources provided"}, indent=2)
        if len(sources) > 5:
            sources = sources[:5]

        per_video_contexts: list[Optional[str]] = []
        if contexts_json and contexts_json.strip():
            try:
                parsed = json.loads(contexts_json)
                if isinstance(parsed, list):
                    per_video_contexts = [
                        (c.strip() if isinstance(c, str) and c.strip() else None) for c in parsed
                    ]
            except json.JSONDecodeError:
                pass

        shared_context = manual_context.strip() if manual_context else None
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            results = await client.start_batch_script_jobs(
                video_sources=sources,
                language=language,
                manual_context=shared_context,
                per_video_contexts=per_video_contexts or None,
            )
        else:
            results = await client.batch_generate_scripts_and_wait(
                video_sources=sources,
                language=language,
                manual_context=shared_context,
                per_video_contexts=per_video_contexts or None,
            )
        return json.dumps(results, indent=2)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON. Provide a JSON array: '[\"url1\", \"url2\"]'"}, indent=2)
    except Exception as e:
        logger.exception("batch_generate_scripts failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def batch_transcribe(
    video_sources_json: str,
    source_language: str,
    api_key: str = "",
) -> str:
    """
    BATCH TRANSCRIPTION – transcribe speech from multiple videos in parallel.
    Each video must have existing spoken audio. Returns timed transcript per video.

    CRITICAL: source_language is REQUIRED – ask user if not specified. Applies to all videos.
    Maximum 5 videos per batch. One failure does not affect others.

    Stdio: waits for all. HTTP/remote: returns job_ids – poll each with get_job_result.

    Args:
        video_sources_json: JSON array of video URLs or paths.
        source_language: Language of the speech in ALL videos (REQUIRED).
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
    """
    try:
        sources = json.loads(video_sources_json)
        if not isinstance(sources, list) or not all(isinstance(s, str) for s in sources):
            return json.dumps({"error": "video_sources_json must be a JSON array of strings"}, indent=2)
        if len(sources) == 0:
            return json.dumps({"error": "No video sources provided"}, indent=2)
        if len(sources) > 5:
            sources = sources[:5]

        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            results = await client.start_batch_transcribe_jobs(
                video_sources=sources,
                source_language=source_language.strip(),
            )
        else:
            results = await client.batch_transcribe_and_wait(
                video_sources=sources,
                source_language=source_language.strip(),
            )
        return json.dumps(results, indent=2)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON. Provide a JSON array: '[\"url1\", \"url2\"]'"}, indent=2)
    except Exception as e:
        logger.exception("batch_transcribe failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def batch_dub(
    video_sources_json: str,
    source_language: str,
    target_language: str,
    preserve_background_music: bool,
    api_key: str = "",
) -> str:
    """
    BATCH DUBBING – dub multiple videos into another language in parallel.
    Each video gets full auto-dubbing (transcribe → translate → voice clone → dubbed video).

    CRITICAL: source_language, target_language, preserve_background_music are REQUIRED – ask user.
    All videos share the same languages and music setting.
    Maximum 5 videos per batch. One failure does not affect others.

    Stdio: waits for all. HTTP/remote: returns job_ids – poll each with get_job_result.

    Args:
        video_sources_json: JSON array of video URLs or paths.
        source_language: Language of the speech in ALL videos (REQUIRED).
        target_language: Language to dub into (REQUIRED).
        preserve_background_music: Keep background music (REQUIRED – ask user).
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
    """
    try:
        sources = json.loads(video_sources_json)
        if not isinstance(sources, list) or not all(isinstance(s, str) for s in sources):
            return json.dumps({"error": "video_sources_json must be a JSON array of strings"}, indent=2)
        if len(sources) == 0:
            return json.dumps({"error": "No video sources provided"}, indent=2)
        if len(sources) > 5:
            sources = sources[:5]

        key = api_key.strip() if api_key else None
        client = _get_client(key)
        if _http_mode:
            results = await client.start_batch_dub_jobs(
                video_sources=sources,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
                preserve_background_music=preserve_background_music,
            )
        else:
            results = await client.batch_dub_and_wait(
                video_sources=sources,
                source_language=source_language.strip(),
                target_language=target_language.strip(),
                preserve_background_music=preserve_background_music,
            )
        return json.dumps(results, indent=2)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON. Provide a JSON array: '[\"url1\", \"url2\"]'"}, indent=2)
    except Exception as e:
        logger.exception("batch_dub failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def update_transcript(
    job_id: str,
    transcript_json: str,
    api_key: str = "",
    reset_for_reprocessing: bool = False,
    target_language: str = "",
) -> str:
    """
    UPDATE TRANSCRIPT – edit the narration script before continuing to full video.

    Use after generate_narration_script returns a transcript and the user wants to change
    wording, timing, or content of specific segments. The user describes changes naturally;
    you apply them and call this tool with the updated segments.

    Also used in the translate-then-re-narrate flow: after translate_existing_video returns
    a translated transcript, call this with the translated segments, reset_for_reprocessing=True,
    and target_language set to the translation language (e.g. "hi", "fr") to prepare the
    completed job for re-narration via continue_to_full_video.

    The transcript_json must include ALL segments (not just changed ones) — it replaces the
    full transcript. Each segment needs: start_time, end_time, text. Optionally: pause_duration, chunk_type.

    After updating, the user can call continue_to_full_video with the same job_id.

    Args:
        job_id: The job_id from generate_narration_script, list_videos, or translate_existing_video.
        transcript_json: Full updated transcript as JSON array. Example:
            '[{"start_time": 0.0, "end_time": 2.5, "text": "Welcome to the app"},
              {"start_time": 3.0, "end_time": 5.5, "text": "Click the settings icon"}]'
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        reset_for_reprocessing: Set True when updating a COMPLETED video's transcript for
            re-narration (e.g. after translation). Resets status to allow continue_to_full_video.
        target_language: REQUIRED when reset_for_reprocessing is True. The language of the new
            transcript (e.g. "hi", "fr", "es"). Ensures the correct TTS model is used.

    Returns:
        JSON with success status or error.
    """
    try:
        transcript = json.loads(transcript_json)
        if not isinstance(transcript, list):
            return json.dumps({"error": "transcript_json must be a JSON array of segment objects"}, indent=2)
        for seg in transcript:
            if not all(k in seg for k in ("start_time", "end_time", "text")):
                return json.dumps(
                    {"error": "Each segment must have start_time, end_time, and text"},
                    indent=2,
                )

        key = api_key.strip() if api_key else None
        client = _get_client(key)
        result = await client.update_transcript(
            job_id=job_id,
            transcript=transcript,
            reset_for_reprocessing=reset_for_reprocessing,
            target_language=target_language.strip() if target_language else None,
        )
        msg = "Transcript updated and job reset for reprocessing." if reset_for_reprocessing else "Transcript updated."
        msg += " You can now call continue_to_full_video."
        return json.dumps({"success": True, "message": msg, **result}, indent=2)
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid JSON. Provide a JSON array of transcript segments."}, indent=2)
    except Exception as e:
        logger.exception("update_transcript failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def list_videos(
    api_key: str = "",
    page: int = 1,
    per_page: int = 20,
) -> str:
    """
    LIST VIDEOS – get the user's video library (previously processed videos).

    Use when the user wants to see their existing videos, re-translate a previously narrated video,
    or work with videos they already processed. Returns paginated list with job IDs, filenames,
    status, and timestamps.

    The returned job IDs can be used with translate_existing_video to translate a completed video's
    transcript, or with get_job_result to check status.

    Args:
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        page: Page number (default: 1).
        per_page: Results per page (default: 20, max: 100).

    Returns:
        JSON with jobs array (id, filename, status, language, created_at, updated_at),
        total count, page, and per_page.
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)
        result = await client.list_videos(page=page, per_page=per_page)
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        logger.exception("list_videos failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


@mcp.tool()
async def continue_to_full_video(
    job_id: str,
    api_key: str = "",
    voice_type: str = "",
    voice_sample: str = "",
    db_job_id: str = "",
) -> str:
    """
    Continue from transcript to full narrated video. Use after get_job_result returns transcript_ready.

    Call when you have transcript_ready (from narrate_video_full or generate_narration_script) and
    the user wants the final video.

    VOICE OPTIONS — ask the user which they prefer:
    1. AI voice: male1 (default, fastest), female1 (default, fastest), female2, female3, female4, male2, male3
    2. Voice cloning: user provides an audio file (voice_sample) and their voice is cloned for the narration

    If voice_sample is provided, it takes priority over voice_type.

    Stdio: waits for completion internally. HTTP/remote: starts video generation and returns immediately –
    poll with get_job_result every 25s until completed.

    Args:
        job_id: The job_id from generate_narration_script or narrate_video_full.
        api_key: Your NarrateAI API key (or set NARRATEAI_API_KEY env var).
        voice_type: AI voice preset. Options: male1, female1, female2, female3, female4, male2, male3.
        voice_sample: Optional. Path to audio file (local path or URL) for voice cloning. When provided, uses the cloned voice instead of an AI preset.
        db_job_id: The db_job_id from the transcript step. Required for video URL retrieval.

    Returns:
        JSON with video_url, job_id when done. Or job_id for polling (HTTP mode).
    """
    try:
        key = api_key.strip() if api_key else None
        client = _get_client(key)

        voice_sample_path = None
        if voice_sample and voice_sample.strip():
            voice_sample_path = await client.upload_voice_sample(job_id, voice_sample.strip())

        if _http_mode:
            result = await client.continue_to_video_start(
                job_id,
                voice_type=voice_type.strip() if voice_type else None,
                voice_sample_path=voice_sample_path,
            )
            if db_job_id and db_job_id.strip():
                result["db_job_id"] = db_job_id.strip()
        else:
            result = await client.continue_to_full_video_and_wait(
                job_id,
                voice_type=voice_type.strip() if voice_type else None,
                voice_sample_path=voice_sample_path,
                db_job_id=db_job_id.strip() if db_job_id else None,
            )
        return json.dumps(result, indent=2)
    except Exception as e:
        logger.exception("continue_to_full_video failed")
        return json.dumps({"error": _error_msg(e)}, indent=2)


def main() -> None:
    """Run MCP server. Supports stdio (default) and HTTP transports."""
    import argparse

    parser = argparse.ArgumentParser(description="NarrateAI MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport type: stdio (default, for Cursor/Claude Code) or http (for remote/cloud)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port for HTTP transport (default: 8080)",
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host for HTTP transport (default: 0.0.0.0)",
    )
    args = parser.parse_args()

    if args.transport == "stdio":
        mcp.run(transport="stdio")
    else:
        import uvicorn

        global _http_mode
        _http_mode = True

        app = mcp.streamable_http_app()
        app = _wrap_with_api_key_middleware(app)
        logger.info(f"Starting NarrateAI MCP server (HTTP) on {args.host}:{args.port}")
        uvicorn.run(app, host=args.host, port=args.port)


class _ApiKeyHeaderMiddleware:
    """ASGI middleware that extracts x-api-key header and stores it in contextvars."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            headers = dict(scope.get("headers", []))
            raw_key = headers.get(b"x-api-key", b"").decode()
            token = _header_api_key.set(raw_key if raw_key else None)
            try:
                await self.app(scope, receive, send)
            finally:
                _header_api_key.reset(token)
        else:
            await self.app(scope, receive, send)


def _wrap_with_api_key_middleware(app):
    """Wrap ASGI app with API key header extraction middleware."""
    return _ApiKeyHeaderMiddleware(app)
