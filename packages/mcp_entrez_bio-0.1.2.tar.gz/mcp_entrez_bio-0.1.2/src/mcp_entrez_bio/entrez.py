import os
import time
import asyncio
from typing import List, Dict
from Bio import Entrez
from dotenv import load_dotenv

load_dotenv()

class RateLimiter:
    """Simple token bucket rate limiter for NCBI API."""
    def __init__(self, calls_per_second: float):
        self.interval = 1.0 / calls_per_second
        self.last_call = 0.0
        self.lock = asyncio.Lock()

    async def wait(self):
        async with self.lock:
            now = time.time()
            elapsed = now - self.last_call
            if elapsed < self.interval:
                await asyncio.sleep(self.interval - elapsed)
            self.last_call = time.time()

class EntrezClient:
    """Client for NCBI Entrez wrapper using Biopython with automatic rate limiting."""
    
    def __init__(self):
        self.email = os.environ.get("NCBI_EMAIL")
        self.api_key = os.environ.get("NCBI_API_KEY")
        
        if not self.email or not self.api_key:
            raise ValueError("NCBI_EMAIL and NCBI_API_KEY environment variables are required. Please set them in your .env file or environment.")
        
        Entrez.email = self.email
        Entrez.api_key = self.api_key
        # NCBI allows up to 10 requests / second with an API key
        self.rate_limiter = RateLimiter(9.0)  # slightly below 10 for safety

    async def esearch_pubmed(self, query: str, retmax: int = 10) -> List[str]:
        """
        Wrap Entrez.esearch for Boolean retrieval of PubMed IDs.
        """
        await self.rate_limiter.wait()
        
        def _search():
            with Entrez.esearch(db="pubmed", term=query, retmax=retmax) as handle:
                return Entrez.read(handle)
                
        record = await asyncio.to_thread(_search)
        return record.get("IdList", [])

    async def efetch_pubmed_abstracts(self, pmids: List[str]) -> Dict[str, str]:
        """
        Wrap Entrez.efetch to extract PubMed abstracts and convert to plain text.
        """
        if not pmids:
            return {}
            
        await self.rate_limiter.wait()
        
        def _fetch():
            id_list = ",".join(pmids)
            with Entrez.efetch(db="pubmed", id=id_list, retmode="xml") as handle:
                return Entrez.read(handle)
                
        records = await asyncio.to_thread(_fetch)
        
        abstracts = {}
        pubmed_articles = records.get("PubmedArticle", [])
        for article in pubmed_articles:
            try:
                medline = article["MedlineCitation"]
                pmid = str(medline["PMID"])
                
                article_data = medline.get("Article", {})
                abstract_data = article_data.get("Abstract", {})
                abstract_texts = abstract_data.get("AbstractText", [])
                
                if abstract_texts:
                    abstract_plain = " ".join([str(text) for text in abstract_texts])
                    abstracts[pmid] = abstract_plain
            except (KeyError, IndexError, TypeError):
                continue
                
        return abstracts
