import sys
sys.path.insert(0, './src')

import asyncio
from mcp_entrez_bio.server import pubmed_esearch, pubmed_efetch_abstracts, mcp_entrez_prompt

async def main():
    print("Testing MCP Entrez Bio...")
    
    # 1. Test Prompt
    print("\n--- Testing Prompt ---")
    prompt = mcp_entrez_prompt()
    print(f"Prompt Config:\n{prompt}")

    # 2. Test ESearch
    print("\n--- Testing ESearch ---")
    query = "(lung cancer[Title/Abstract]) AND immunotherapy"
    print(f"Query: {query}")
    pmids = await pubmed_esearch(query=query, retmax=3)
    print(f"Found PMIDs: {pmids}")
    
    # 3. Test EFetch
    if pmids:
        print("\n--- Testing EFetch Abstract Extract ---")
        abstracts = await pubmed_efetch_abstracts(pmids)
        for pmid, abstract in abstracts.items():
            print(f"PMID {pmid} Abstract Length: {len(abstract)}")
            print(f"Preview: {abstract[:200]}...\n")
    else:
        print("\nSkipping EFetch due to no PMIDs found.")

if __name__ == "__main__":
    asyncio.run(main())
