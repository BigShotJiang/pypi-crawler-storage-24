import os
import logging
import sys
import traceback
from os import PathLike
from dataclasses import asdict
from itertools import dropwhile
from typing import Any, Generator

import pytest
from _pytest._code.code import ExceptionChainRepr

from .env_vars import ENV_VAR_WHITELIST
from .results_reporter import ResultsReporter
from .noop_reporting_backend import NoopReportingBackend

_test_reporter: ResultsReporter | None = None

logger = logging.getLogger("testinel")


def _get_test_reporter() -> ResultsReporter:
    global _test_reporter
    if _test_reporter is None:
        dsn = os.environ.get("TESTINEL_DSN")
        if not dsn:
            _test_reporter = ResultsReporter(
                dsn="",
                backend=NoopReportingBackend(),
            )
        else:
            _test_reporter = ResultsReporter(dsn=dsn)
    return _test_reporter


def _safe_path(value: object) -> str:
    try:
        if isinstance(value, (str, bytes, PathLike)):
            path = os.fspath(value)
        else:
            return str(value)
    except TypeError:
        return str(value)
    if isinstance(path, bytes):
        try:
            return path.decode()
        except Exception:
            return str(path)
    return path


def _patch_selenium_save_screenshot() -> None:
    try:
        from selenium.webdriver.remote.webdriver import WebDriver  # type: ignore[import-not-found]
    except Exception:
        return

    original = getattr(WebDriver, "save_screenshot", None)
    if original is None or getattr(original, "_testinel_patched", False):
        return

    def patched(self: Any, filename: Any, *args: Any, **kwargs: Any) -> Any:
        result = original(self, filename, *args, **kwargs)
        try:
            _get_test_reporter().report_attachment(_safe_path(filename))
        except Exception:
            return result
        return result

    setattr(patched, "_testinel_patched", True)
    setattr(patched, "_testinel_original", original)
    WebDriver.save_screenshot = patched


def serialize_repr(long_repr: ExceptionChainRepr) -> dict:
    return asdict(long_repr)


def to_test_dict(item: Any) -> dict[str, Any]:
    test_cls_docstring = item.parent.obj.__doc__ or ""
    test_fn_docstring = item.obj.__doc__ or ""
    return {
        "test_id": item.nodeid,
        "location": item.location,
        "description": test_fn_docstring or test_cls_docstring,
    }


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(
    item: Any,
    call: Any,
) -> Generator[None, Any, None]:
    """Pytest hook that wraps the standard pytest_runtest_makereport
    function and grabs the results for the 'call' phase of each test.
    """
    outcome = yield
    report = outcome.get_result()

    report.exception = None
    ss = None
    exc_info = None
    repr_info = None
    if report.outcome == "failed":
        # driver = item.funcargs["driver"]
        # logs = driver.get_log('browser')
        # current_url = driver.current_url
        exc = call.excinfo.value

        tb_frames = traceback.extract_tb(call.excinfo.value.__traceback__)
        filtered_frames = dropwhile(
            lambda t: not item.location[0] in t.filename, tb_frames
        )
        ss = traceback.StackSummary.from_list(filtered_frames)

        exc_info = {
            "type": f"{exc.__class__.__module__}.{exc.__class__.__name__}",
            "message": str(exc),
            "notes": list(getattr(exc, "__notes__", []) or []),
        }

        repr_info = serialize_repr(report.longrepr)

    if output_path := item.funcargs.get("output_path"):
        # Probably, it is Playwright traces
        for dirpath, dirnames, filenames in os.walk(output_path):
            for filename in filenames:
                _get_test_reporter().report_attachment(os.path.join(dirpath, filename))

    _get_test_reporter().report_event(
        event=report.when,
        payload={
            "test": to_test_dict(item),
            "outcome": report.outcome,
            "duration": report.duration,
            "error_info": {
                "repr_info": repr_info,
                "traceback": [
                    {
                        "filename": f.filename,
                        "lineno": f.lineno,
                        "name": f.name,
                        "line": f.line,
                    }
                    for f in (ss or [])
                ],
                "exception": exc_info,
            }
            if report.outcome == "failed"
            else None,
        },
    )


@pytest.fixture(scope="session", autouse=True)
def reporter(request: pytest.FixtureRequest) -> Generator[None, None, None]:
    config = request.config
    _get_test_reporter().report_start(
        payload={
            "args": config.args,
            "options": vars(config.option),
            "environment": {
                key: os.environ[key] for key in os.environ if key in ENV_VAR_WHITELIST
            },
        }
    )
    yield


def pytest_sessionfinish(session, exitstatus):
    _get_test_reporter().report_end()
    logger.info("Testinel completed.")


def pytest_collection_finish(session: pytest.Session) -> None:
    tests = [to_test_dict(item) for item in session.items]
    _get_test_reporter().tests = tests


def pytest_addoption(parser):
    group = parser.getgroup("testinel")
    group.addoption(
        "--testinel-log-level",
        action="store",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Log level for Testinel plugin",
    )


def pytest_configure(config):
    level_name = config.getoption("--testinel-log-level")
    level = getattr(logging, level_name, logging.WARNING)

    logger.setLevel(level)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        formatter = logging.Formatter(
            "[%(asctime)s] %(levelname)s %(name)s [%(threadName)s] %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    logger.propagate = False


_patch_selenium_save_screenshot()
