# Python SDK

Refario Python ingestion SDK package: `refario-sdk`.

## Install

```bash
pip install refario-sdk
```

## Usage

```python
from refario_sdk import refario

client = refario.init(
    endpoint="http://localhost:3000",
    api_key="YOUR_API_KEY",
)

run = client.start_run(workflow="example-workflow", environment="prod")

run.llm_call(
    name="openai-call",
    provider="openai",
    model="gpt-4o",
    status="success",
    prompt_tokens=120,
    completion_tokens=80,
    latency_ms=900,
)

run.end(success=True)
```

## TS-Style Compatibility Helpers

- `refario.init({ "endpoint": "...", "apiKey": "..." })`
- `client.startRun({ "workflow": "...", "environment": "..." })`
- `run.llmCall({ ... })`, `run.toolCall({ ... })`, `run.chainCall({ ... })`

## Local tests

From `python-sdk/`:

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -p "test_*.py"
```

## Local package checks

From repo root:

```bash
python3 -m pip install --upgrade build twine
PYTHONPATH=python-sdk/src python3 -m unittest discover -s python-sdk/tests -p "test_*.py"
python3 -m build python-sdk
python3 -m twine check python-sdk/dist/*
```

## Release process

1. Bump version in `python-sdk/pyproject.toml`.
2. Commit and push to `main`.
3. Create and push a release tag matching the package version (for example `python-sdk-v0.1.0`):

```bash
git tag python-sdk-v<version>
git push origin python-sdk-v<version>
```

The `Release Python SDK` GitHub Action publishes to PyPI when the tag is pushed.
You can also run the workflow manually via `workflow_dispatch` to publish the current
`python-sdk/pyproject.toml` version.

## Required GitHub secret

- `PYPI_API_TOKEN` with publish access to the `refario-sdk` package on PyPI.
