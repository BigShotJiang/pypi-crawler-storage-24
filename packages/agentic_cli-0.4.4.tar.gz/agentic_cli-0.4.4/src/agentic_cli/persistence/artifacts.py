"""Artifact persistence for agentic CLI applications.

Manages saving and loading of artifacts (plans, code, documentation) to disk.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

from agentic_cli.logging import Loggers
from agentic_cli.persistence._utils import (
    atomic_write_json,
    atomic_write_text,
    file_lock,
    sanitize_filename,
)

logger = Loggers.persistence()

if TYPE_CHECKING:
    from agentic_cli.config import BaseSettings


class ArtifactType(Enum):
    """Types of artifacts that can be persisted."""

    PLAN = "plan"
    CODE = "code"
    DOCUMENTATION = "documentation"
    TEST = "test"
    REPORT = "report"


@dataclass
class Artifact:
    """Represents a persistable artifact."""

    name: str
    artifact_type: ArtifactType
    content: str
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert artifact to dictionary for serialization."""
        return {
            "name": self.name,
            "artifact_type": self.artifact_type.value,
            "content": self.content,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Artifact":
        """Create artifact from dictionary."""
        return cls(
            name=data["name"],
            artifact_type=ArtifactType(data["artifact_type"]),
            content=data["content"],
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
            metadata=data.get("metadata", {}),
        )


class ArtifactManager:
    """Manages artifact persistence to disk.

    Artifacts are stored in a workspace directory with the following structure:
        {workspace_dir}/artifacts/
        ├── plans/
        │   └── {plan_name}.md
        ├── code/
        │   └── {code_name}.py
        ├── docs/
        │   └── {doc_name}.md
        ├── tests/
        │   └── {test_name}.py
        └── .artifacts.json  # Metadata index
    """

    SUBDIRS = {
        ArtifactType.PLAN: "plans",
        ArtifactType.CODE: "code",
        ArtifactType.DOCUMENTATION: "docs",
        ArtifactType.TEST: "tests",
        ArtifactType.REPORT: "reports",
    }

    EXTENSIONS = {
        ArtifactType.PLAN: ".md",
        ArtifactType.CODE: ".py",
        ArtifactType.DOCUMENTATION: ".md",
        ArtifactType.TEST: ".py",
        ArtifactType.REPORT: ".md",
    }

    def __init__(self, settings: "BaseSettings"):
        """Initialize artifact manager.

        Args:
            settings: Application settings with workspace_dir
        """
        self.workspace_path = settings.artifacts_dir
        self._ensure_workspace_exists()

    def _ensure_workspace_exists(self) -> None:
        """Create workspace directory structure if it doesn't exist."""
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        for subdir in self.SUBDIRS.values():
            (self.workspace_path / subdir).mkdir(exist_ok=True)

    def _get_artifact_path(self, artifact: Artifact) -> Path:
        """Get the file path for an artifact."""
        subdir = self.SUBDIRS[artifact.artifact_type]
        extension = self.EXTENSIONS[artifact.artifact_type]
        safe_name = sanitize_filename(artifact.name)
        return self.workspace_path / subdir / f"{safe_name}{extension}"

    def _get_index_path(self) -> Path:
        """Get path to artifact index file."""
        return self.workspace_path / ".artifacts.json"

    @staticmethod
    def _make_key(name: str, artifact_type: str) -> str:
        """Create a dict key from artifact name and type."""
        return f"{name}:{artifact_type}"

    def _load_index(self) -> dict:
        """Load artifact index from disk.

        Returns dict-based index: {"artifacts": {"name:type": {...}}}.
        Migrates from legacy list format on the fly.
        """
        index_path = self._get_index_path()
        if index_path.exists():
            try:
                with open(index_path, "r") as f:
                    data = json.load(f)
                # Migrate from legacy list format if needed
                if isinstance(data.get("artifacts"), list):
                    migrated: dict[str, dict] = {}
                    for entry in data["artifacts"]:
                        key = self._make_key(entry["name"], entry["artifact_type"])
                        migrated[key] = entry
                    return {"artifacts": migrated}
                return data
            except (json.JSONDecodeError, KeyError) as exc:
                logger.warning("artifact_index_load_failed", error=str(exc))
        return {"artifacts": {}}

    def _save_index(self, index: dict) -> None:
        """Save artifact index to disk."""
        index_path = self._get_index_path()
        atomic_write_json(index_path, index)

    def save(self, artifact: Artifact) -> Path:
        """Save an artifact to disk.

        Args:
            artifact: The artifact to save

        Returns:
            Path to the saved artifact file
        """
        # Update timestamp
        artifact.updated_at = datetime.now()

        # Save content to file
        file_path = self._get_artifact_path(artifact)
        atomic_write_text(file_path, artifact.content)

        # Update index (lock to prevent TOCTOU race)
        with file_lock(self._get_index_path()):
            index = self._load_index()
            key = self._make_key(artifact.name, artifact.artifact_type.value)
            artifact_entry = artifact.to_dict()
            artifact_entry["file_path"] = str(file_path)
            index["artifacts"][key] = artifact_entry
            self._save_index(index)

        return file_path

    def _is_safe_path(self, file_path: Path) -> bool:
        """Check that a file path is within the workspace directory."""
        try:
            file_path.resolve().relative_to(self.workspace_path.resolve())
            return True
        except ValueError:
            logger.warning(
                "artifact_path_traversal_blocked",
                file_path=str(file_path),
                workspace=str(self.workspace_path),
            )
            return False

    def _load_artifact_from_entry(self, entry: dict) -> Artifact | None:
        """Load an artifact from an index entry, reading content from disk.

        Args:
            entry: Index entry dict with at least 'file_path'.

        Returns:
            Artifact with content loaded, or None if path is unsafe or missing.
        """
        file_path = Path(entry["file_path"])
        if not self._is_safe_path(file_path):
            return None
        if not file_path.exists():
            return None
        artifact = Artifact.from_dict(entry)
        artifact.content = file_path.read_text()
        return artifact

    def load(self, name: str, artifact_type: ArtifactType) -> Artifact | None:
        """Load an artifact from disk.

        Args:
            name: Artifact name
            artifact_type: Type of artifact

        Returns:
            Artifact if found, None otherwise
        """
        index = self._load_index()
        key = self._make_key(name, artifact_type.value)
        entry = index["artifacts"].get(key)
        if entry:
            return self._load_artifact_from_entry(entry)
        return None

    def list_artifacts(
        self, artifact_type: ArtifactType | None = None
    ) -> list[Artifact]:
        """List all artifacts, optionally filtered by type.

        Args:
            artifact_type: Filter by type (None for all)

        Returns:
            List of artifacts
        """
        index = self._load_index()
        artifacts = []
        for entry in index["artifacts"].values():
            if (
                artifact_type is None
                or entry["artifact_type"] == artifact_type.value
            ):
                artifact = self._load_artifact_from_entry(entry)
                if artifact is not None:
                    artifacts.append(artifact)
        return artifacts

    def delete(self, name: str, artifact_type: ArtifactType) -> bool:
        """Delete an artifact.

        Args:
            name: Artifact name
            artifact_type: Type of artifact

        Returns:
            True if deleted, False if not found
        """
        with file_lock(self._get_index_path()):
            index = self._load_index()
            key = self._make_key(name, artifact_type.value)
            entry = index["artifacts"].pop(key, None)
            if entry:
                file_path = Path(entry["file_path"])
                if self._is_safe_path(file_path) and file_path.exists():
                    file_path.unlink()
                self._save_index(index)
                return True
        return False

    def get_workspace_path(self) -> Path:
        """Get the workspace path."""
        return self.workspace_path
