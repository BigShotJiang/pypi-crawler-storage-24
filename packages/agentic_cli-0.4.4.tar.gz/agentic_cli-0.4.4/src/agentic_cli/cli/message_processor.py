"""Message processing for agentic CLI applications.

This module provides:
- MessageHistory: Tracks conversation history for persistence
- MessageProcessor: Handles user message processing through workflow
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, ClassVar

from agentic_cli.logging import Loggers, bind_context

if TYPE_CHECKING:
    from agentic_cli.cli.usage_tracker import UsageTracker
    from agentic_cli.config import BaseSettings
    from agentic_cli.cli.workflow_controller import WorkflowController
    from agentic_cli.workflow import WorkflowEvent
    from agentic_cli.workflow.events import UserInputRequest
    from thinking_prompt import ThinkingPromptSession


logger = Loggers.cli()


def _richify_task_display(plain: str) -> str:
    """Convert plain task checklist to ANSI-colored icons for the thinking box."""
    from thinking_prompt import rich_to_ansi

    lines = []
    for line in plain.splitlines():
        stripped = line.lstrip()
        indent = line[: len(line) - len(stripped)]
        if stripped.startswith("[✓]"):
            lines.append(f"{indent}[green]✓[/green] {stripped[4:]}")
        elif stripped.startswith("[▸]"):
            lines.append(f"{indent}[yellow]▸[/yellow] {stripped[4:]}")
        elif stripped.startswith("[ ]"):
            lines.append(f"{indent}[dim]○[/dim] {stripped[4:]}")
        elif stripped.startswith("[-]"):
            lines.append(f"{indent}[red dim]✗[/red dim] {stripped[4:]}")
        else:
            lines.append(line.replace("[", "\\["))
    return rich_to_ansi("\n".join(lines))


# === Message History for Persistence ===


class MessageType(Enum):
    """Types of messages in history."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    ERROR = "error"
    WARNING = "warning"
    SUCCESS = "success"
    THINKING = "thinking"


@dataclass
class Message:
    """A message stored in history for persistence."""

    content: str
    message_type: MessageType
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict = field(default_factory=dict)


class MessageHistory:
    """Simple message history for persistence."""

    def __init__(self) -> None:
        self._messages: list[Message] = []

    def add(
        self,
        content: str,
        message_type: MessageType | str,
        timestamp: datetime | None = None,
        **metadata: object,
    ) -> None:
        """Add a message to history."""
        if isinstance(message_type, str):
            message_type = MessageType(message_type)
        self._messages.append(
            Message(
                content=content,
                message_type=message_type,
                timestamp=timestamp or datetime.now(),
                metadata=dict(metadata),
            )
        )

    def get_all(self) -> list[Message]:
        """Get all messages."""
        return list(self._messages)

    def clear(self) -> None:
        """Clear all messages."""
        self._messages.clear()

    def __len__(self) -> int:
        return len(self._messages)


# === Event Processing State ===


@dataclass
class _EventProcessingState:
    """Mutable state shared across event handlers during process()."""

    usage_tracker: "UsageTracker | None" = field(default=None, repr=False)
    workflow_controller: "WorkflowController | None" = field(default=None, repr=False)
    status_line: str = "Processing..."
    task_progress_display: str | None = None
    _last_task_display_content: str | None = None
    thinking_started: bool = False
    thinking_content: list[str] = field(default_factory=list)
    response_content: list[str] = field(default_factory=list)
    # Prevents double-counting when LangGraph emits both CONTEXT_TRIMMED and LLM_USAGE
    _context_trimmed_this_invocation: bool = False

    def get_status(self) -> str:
        """Build status display with current action and task progress."""
        lines = [self.status_line]
        if self.task_progress_display:
            lines.append(self.task_progress_display)
        return "\n".join(lines)

    def reset_for_retry(self) -> None:
        """Reset state for retry after rate limit."""
        self.status_line = "Processing..."
        self.task_progress_display = None
        self._last_task_display_content = None
        self.thinking_content.clear()
        self.response_content.clear()


# === Message Processor ===


class MessageProcessor:
    """Processes user messages through the workflow.

    Handles:
    - Event stream processing from workflow
    - Thinking box state management
    - Tool result display
    - User input prompting during workflow
    - Message history tracking

    Example:
        processor = MessageProcessor()

        await processor.process(
            message="Hello",
            workflow_controller=controller,
            ui=session,
            settings=settings,
        )

        # Access history
        for msg in processor.history.get_all():
            print(f"{msg.message_type}: {msg.content}")
    """

    def __init__(self) -> None:
        """Initialize the message processor."""
        self._message_history = MessageHistory()
        self._last_task_progress: str | None = None

    @property
    def history(self) -> MessageHistory:
        """Get the message history."""
        return self._message_history

    def clear_history(self) -> None:
        """Clear message history."""
        self._message_history.clear()
        self._last_task_progress = None

    async def process(
        self,
        message: str,
        workflow_controller: "WorkflowController",
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        usage_tracker: "UsageTracker | None" = None,
    ) -> None:
        """Process a user message through the workflow.

        Args:
            message: User message to process
            workflow_controller: Controller managing workflow lifecycle
            ui: UI session for output
            settings: Application settings
            usage_tracker: Optional tracker for accumulating LLM token usage
        """
        # Wait for initialization if needed
        if not await workflow_controller.ensure_initialized(ui):
            ui.add_error(
                "Cannot process message - workflow not initialized. "
                "Please check your API keys (GOOGLE_API_KEY or ANTHROPIC_API_KEY)."
            )
            return

        # Import WorkflowEvent here (workflow module is now loaded)
        from agentic_cli.workflow import WorkflowEvent

        bind_context(user_id=settings.default_user)
        logger.info("handling_message", message_length=len(message))

        # Track message in history (if logging enabled)
        if settings.log_activity:
            self._message_history.add(message, MessageType.USER)

        state = _EventProcessingState(
            usage_tracker=usage_tracker,
            workflow_controller=workflow_controller,
        )
        # Restore task progress from previous turn so it shows immediately
        state.task_progress_display = self._last_task_progress
        workflow = workflow_controller.workflow
        dispatch = self._get_event_dispatch()

        # Set up direct callback so HITL tools can prompt the user without
        # deadlocking the workflow runner.
        async def _handle_input(request: "UserInputRequest") -> str:
            if state.thinking_started:
                ui.finish_thinking(add_to_history=False)
                state.thinking_started = False

            response = await self._prompt_user_input(request, ui)

            ui.start_thinking(state.get_status, content_format="ansi")
            state.thinking_started = True
            return response

        workflow.set_input_callback(_handle_input)
        try:
            while True:
                try:
                    ui.start_thinking(state.get_status, content_format="ansi")
                    state.thinking_started = True

                    async for event in workflow.process(
                        message=message,
                        user_id=settings.default_user,
                    ):
                        handler = dispatch.get(event.type)
                        if handler is not None:
                            await handler(self, event, state, ui, settings, workflow)

                    # Finish thinking box (don't add status to history)
                    if state.thinking_started:
                        ui.finish_thinking(add_to_history=False)

                    # Ensure final token counts are reflected in status bar
                    workflow_controller.update_status_bar(ui)

                    # Add accumulated content to message history (if logging enabled)
                    if settings.log_activity:
                        if state.thinking_content:
                            self._message_history.add(
                                "".join(state.thinking_content),
                                MessageType.THINKING,
                            )
                        if state.response_content:
                            self._message_history.add(
                                "".join(state.response_content),
                                MessageType.ASSISTANT,
                            )

                    logger.debug("message_handled_successfully")
                    break  # Success — exit retry loop

                except Exception as e:
                    if state.thinking_started:
                        ui.finish_thinking(add_to_history=False)
                        state.thinking_started = False

                    # Check for 429 rate limit errors — prompt user to wait and retry
                    from agentic_cli.workflow.retry import (
                        is_rate_limit_error,
                        parse_retry_delay,
                    )

                    if is_rate_limit_error(e):
                        delay = parse_retry_delay(e) or 60.0
                        retry = await ui.yes_no_dialog(
                            title="Rate Limited",
                            text=f"API rate limit reached. Retry in {delay:.0f}s?",
                        )
                        if retry:
                            ui.add_warning(f"Waiting {delay:.0f}s before retrying...")
                            await asyncio.sleep(delay)
                            state.reset_for_retry()
                            continue  # Retry the loop

                    # Non-429 or user chose cancel
                    ui.add_error(f"Workflow error: {e}")
                    if settings.log_activity:
                        self._message_history.add(str(e), MessageType.ERROR)
                    break
        finally:
            workflow.clear_input_callback()
            # Persist task progress so it shows immediately on the next turn
            self._last_task_progress = state.task_progress_display

    async def _prompt_user_input(
        self,
        request: "UserInputRequest",
        ui: "ThinkingPromptSession",
    ) -> str:
        """Prompt user for input requested by a tool.

        Args:
            request: The user input request from the tool.
            ui: UI session for prompting.

        Returns:
            User's response string.
        """
        from agentic_cli.workflow.events import InputType

        tool_name = request.tool_name or "Tool"

        if request.input_type == InputType.CHOICE and request.choices:
            result = await ui.dropdown_dialog(
                title=f"{tool_name} - Input Required",
                text=request.prompt,
                options=request.choices,
                default=request.default,
            )
            return result or (request.default or "")

        elif request.input_type == InputType.CONFIRM:
            result = await ui.yes_no_dialog(
                title=f"{tool_name} - Confirmation",
                text=request.prompt,
            )
            return "yes" if result else "no"

        else:
            result = await ui.input_dialog(
                title=f"{tool_name} - Input Required",
                text=request.prompt,
                default=request.default or "",
            )
            return result or ""

    # === Event handler methods ===

    async def _handle_text(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle TEXT events — stream response to console."""
        ui.add_response(event.content, markdown=True)
        state.response_content.append(event.content)

    async def _handle_thinking(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle THINKING events — update status, optionally display."""
        state.status_line = "Thinking..."
        if settings.verbose_thinking:
            ui.add_message("system", event.content)
        state.thinking_content.append(event.content)

    async def _handle_tool_call(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle TOOL_CALL events — update status line."""
        tool_name = event.metadata.get("tool_name", "unknown")
        state.status_line = f"Calling: {tool_name}"

    async def _handle_tool_result(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle TOOL_RESULT events — display result summary."""
        tool_name = event.metadata.get("tool_name", "unknown")
        success = event.metadata.get("success", True)
        duration = event.metadata.get("duration_ms")
        icon = "+" if success else "x"
        duration_str = f" ({duration}ms)" if duration else ""
        lines = event.content.split("\n")
        first_line = lines[0]
        state.status_line = f"{icon} {tool_name}: {first_line}{duration_str}"
        style = "green" if success else "red"
        display = f"[{style}]{icon}[/{style}] {tool_name}: {first_line}{duration_str}"
        if len(lines) > 1:
            display += "\n" + "\n".join(lines[1:])
        ui.add_rich(display)

    async def _handle_code_execution(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle CODE_EXECUTION events — update status with result preview."""
        result_preview = (
            event.content[:40] + "..."
            if len(event.content) > 40
            else event.content
        )
        state.status_line = f"Result: {result_preview}"

    async def _handle_executable_code(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle EXECUTABLE_CODE events — update status with language."""
        lang = event.metadata.get("language", "python")
        state.status_line = f"Running {lang} code..."

    async def _handle_file_data(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle FILE_DATA events — update status with filename."""
        state.status_line = f"File: {event.content}"

    async def _handle_task_progress(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle TASK_PROGRESS events — update progress display."""
        # Deduplicate: skip if content unchanged from last event
        if event.content and event.content == state._last_task_display_content:
            return
        state._last_task_display_content = event.content

        progress = event.metadata.get("progress", {})
        if progress.get("total", 0) > 0:
            completed = progress.get("completed", 0)
            total = progress["total"]
            from thinking_prompt import rich_to_ansi

            state.task_progress_display = rich_to_ansi(
                f"[bold]--- Tasks: {completed}/{total} ---[/bold]"
            )
            if event.content:
                state.task_progress_display += f"\n{_richify_task_display(event.content)}"
        else:
            state.task_progress_display = None

        current_task = event.metadata.get("current_task_description")
        if current_task:
            state.status_line = f"Working on: {current_task}"

    async def _handle_context_trimmed(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle CONTEXT_TRIMMED events — increment counter and warn user."""
        if state.usage_tracker is not None:
            state.usage_tracker.context_trimmed_count += 1
        state._context_trimmed_this_invocation = True

        removed = event.metadata.get("messages_removed")
        source = event.metadata.get("source", "unknown")
        if removed is not None:
            ui.add_warning(
                f"Context trimmed: {removed} messages removed ({source})"
            )
        else:
            ui.add_warning(f"Context window trimmed ({source})")

    async def _handle_llm_usage(
        self,
        event: "WorkflowEvent",
        state: _EventProcessingState,
        ui: "ThinkingPromptSession",
        settings: "BaseSettings",
        workflow: object,
    ) -> None:
        """Handle LLM_USAGE events — accumulate token counts and refresh status bar."""
        if state.usage_tracker is not None:
            tracker = state.usage_tracker
            prev_prompt = tracker.last_prompt_tokens
            heuristic_trimmed = tracker.record(
                event.metadata,
                context_trimmed_already=state._context_trimmed_this_invocation,
            )

            if heuristic_trimmed:
                from agentic_cli.cli.usage_tracker import format_tokens

                ui.add_warning(
                    f"Context window trimmed: {format_tokens(prev_prompt)}"
                    f" → {format_tokens(tracker.last_prompt_tokens)} tokens"
                    " (token_drop_heuristic)"
                )

            # Reset per-invocation flag for next LLM call
            state._context_trimmed_this_invocation = False

        if state.workflow_controller is not None:
            state.workflow_controller.update_status_bar(ui)

    # === Dispatch table ===

    _EVENT_DISPATCH: ClassVar[dict | None] = None

    @classmethod
    def _get_event_dispatch(cls) -> dict:
        """Get or build the EventType → handler dispatch table."""
        if cls._EVENT_DISPATCH is None:
            from agentic_cli.workflow import EventType

            cls._EVENT_DISPATCH = {
                EventType.TEXT: cls._handle_text,
                EventType.THINKING: cls._handle_thinking,
                EventType.TOOL_CALL: cls._handle_tool_call,
                EventType.TOOL_RESULT: cls._handle_tool_result,
                EventType.CODE_EXECUTION: cls._handle_code_execution,
                EventType.EXECUTABLE_CODE: cls._handle_executable_code,
                EventType.FILE_DATA: cls._handle_file_data,
                EventType.TASK_PROGRESS: cls._handle_task_progress,
                EventType.CONTEXT_TRIMMED: cls._handle_context_trimmed,
                EventType.LLM_USAGE: cls._handle_llm_usage,
            }
        return cls._EVENT_DISPATCH
