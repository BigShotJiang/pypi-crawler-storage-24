"""Abstract base class for workflow managers.

This module defines the interface that all workflow orchestration backends
must implement, enabling pluggable orchestrators (ADK, LangGraph, etc.).

The base class provides auto-detection of required managers (memory, planning,
HITL) based on tool requirements, creating them lazily when needed.

It also provides shared implementations for:
- User input handling (callback-based)
- Model resolution (lazy resolution from settings)
"""

from __future__ import annotations

import contextlib
from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Awaitable, Callable, Iterator, TYPE_CHECKING

from agentic_cli.workflow.events import WorkflowEvent, UserInputRequest
from agentic_cli.workflow.config import AgentConfig
from agentic_cli.workflow.models import ModelRegistry
from agentic_cli.config import set_context_settings
from agentic_cli.workflow.context import (
    set_context_workflow,
    set_context_memory_store,
    set_context_plan_store,
    set_context_task_store,
    set_context_kb_manager,
    set_context_user_kb_manager,
    set_context_approval_manager,
    set_context_llm_summarizer,
    set_context_sandbox_manager,
)
from agentic_cli.logging import Loggers

if TYPE_CHECKING:
    from agentic_cli.config import BaseSettings
    from agentic_cli.tools.memory_tools import MemoryStore
    from agentic_cli.tools.planning_tools import PlanStore
    from agentic_cli.tools.task_tools import TaskStore
    from agentic_cli.knowledge_base import KnowledgeBaseManager
    from agentic_cli.tools.hitl_tools import ApprovalManager
    from agentic_cli.tools.sandbox.manager import SandboxManager

logger = Loggers.workflow()


class BaseWorkflowManager(ABC):
    """Abstract base class for workflow managers.

    Defines the interface that all workflow orchestration backends must implement.
    This enables pluggable orchestrators like Google ADK, LangGraph, etc.

    Implementations must handle:
    - Agent orchestration based on AgentConfig definitions
    - Session management
    - Event streaming
    - User input request/response flow

    Example:
        class CustomWorkflowManager(BaseWorkflowManager):
            async def initialize_services(self) -> None:
                # Setup custom backend
                pass

            async def process(self, message, user_id, session_id=None):
                # Process through custom backend
                async for event in self._process_internal():
                    yield event
    """

    def __init__(
        self,
        agent_configs: list[AgentConfig],
        settings: "BaseSettings | None" = None,
        app_name: str | None = None,
        model: str | None = None,
        on_event: Callable[[WorkflowEvent], WorkflowEvent | None] | None = None,
    ) -> None:
        """Initialize the workflow manager base.

        Args:
            agent_configs: List of agent configurations defining the workflow.
            settings: Application settings (resolved via get_settings() if None).
            app_name: Application name for services.
            model: Model override (auto-detected from API keys if not provided).
            on_event: Optional hook to transform/filter events before yielding.
        """
        from agentic_cli.config import get_settings

        self._agent_configs = agent_configs
        self._settings = settings or get_settings()
        self._app_name = app_name or self._settings.app_name
        self._initialized = False
        self._on_event = on_event

        # Model resolution (lazy)
        self._model: str | None = model
        self._model_resolved: bool = model is not None

        # User input handling (callback-only)
        self._user_input_callback: Callable[[UserInputRequest], Awaitable[str]] | None = None

        # Model registry
        self._model_registry = ModelRegistry()

        # Auto-detect required managers from tools
        self._required_managers = self._detect_required_managers()

        # Manager slots (created lazily by _ensure_managers_initialized)
        self._memory_manager: "MemoryStore | None" = None
        self._plan_store: "PlanStore | None" = None
        self._task_store: "TaskStore | None" = None
        self._kb_manager: "KnowledgeBaseManager | None" = None
        self._user_kb_manager: "KnowledgeBaseManager | None" = None
        self._approval_manager: "ApprovalManager | None" = None
        self._llm_summarizer: Any | None = None
        self._sandbox_manager: "SandboxManager | None" = None

    def set_input_callback(
        self, callback: Callable[[UserInputRequest], Awaitable[str]]
    ) -> None:
        """Register a callback for handling user input requests from tools."""
        self._user_input_callback = callback

    def clear_input_callback(self) -> None:
        """Remove the registered user input callback."""
        self._user_input_callback = None

    @property
    def agent_configs(self) -> list[AgentConfig]:
        """Get the agent configurations."""
        return self._agent_configs

    @property
    def settings(self) -> "BaseSettings":
        """Get the settings instance."""
        return self._settings

    @property
    def app_name(self) -> str:
        """Get the application name."""
        return self._app_name

    @property
    def is_initialized(self) -> bool:
        """Check if services have been initialized."""
        return self._initialized

    @property
    def model_registry(self) -> ModelRegistry:
        """Get the model registry."""
        return self._model_registry

    @property
    def required_managers(self) -> set[str]:
        """Get the set of required manager types detected from tools."""
        return self._required_managers

    @property
    def memory_manager(self) -> "MemoryStore | None":
        """Get the memory manager (if required by tools)."""
        return self._memory_manager

    @property
    def plan_store(self) -> "PlanStore | None":
        """Get the plan store (if required by tools)."""
        return self._plan_store

    @property
    def task_store(self) -> "TaskStore | None":
        """Get the task store (if required by tools)."""
        return self._task_store

    @property
    def kb_manager(self) -> "KnowledgeBaseManager | None":
        """Get the project-scoped knowledge base manager (if required by tools)."""
        return self._kb_manager

    @property
    def user_kb_manager(self) -> "KnowledgeBaseManager | None":
        """Get the user-scoped knowledge base manager (if required by tools)."""
        return self._user_kb_manager

    @property
    def approval_manager(self) -> "ApprovalManager | None":
        """Get the approval manager (if required by tools)."""
        return self._approval_manager

    @property
    def llm_summarizer(self) -> Any | None:
        """Get the LLM summarizer (if required by tools)."""
        return self._llm_summarizer

    @property
    def sandbox_manager(self) -> "SandboxManager | None":
        """Get the sandbox manager (if required by tools)."""
        return self._sandbox_manager

    def _detect_required_managers(self) -> set[str]:
        """Scan all agent tools for 'requires' metadata.

        Tools decorated with @requires("memory_manager") etc. will have
        their requirements detected here.

        Returns:
            Set of required manager types.
        """
        required: set[str] = set()
        for config in self._agent_configs:
            for tool in config.tools or []:
                if hasattr(tool, "requires"):
                    required.update(tool.requires)
        return required

    def _ensure_managers_initialized(self) -> None:
        """Create managers based on detected requirements.

        Called during initialize_services() to lazily create only the
        managers that are actually needed by the configured tools.
        """
        if "memory_manager" in self._required_managers and self._memory_manager is None:
            from agentic_cli.tools.memory_tools import MemoryStore
            self._memory_manager = MemoryStore(self._settings)

        if "plan_store" in self._required_managers and self._plan_store is None:
            from agentic_cli.tools.planning_tools import PlanStore
            self._plan_store = PlanStore()

        if "task_store" in self._required_managers and self._task_store is None:
            from agentic_cli.tools.task_tools import TaskStore
            self._task_store = TaskStore(self._settings)

        if "kb_manager" in self._required_managers and self._kb_manager is None:
            from pathlib import Path
            from agentic_cli.knowledge_base import KnowledgeBaseManager

            use_mock = self._settings.knowledge_base_use_mock
            project_kb_dir = Path.cwd() / f".{self._settings.app_name}" / "knowledge_base"
            user_kb_dir = self._settings.knowledge_base_dir

            # Project KB (agent read-write)
            self._kb_manager = KnowledgeBaseManager(
                settings=self._settings,
                use_mock=use_mock,
                base_dir=project_kb_dir,
            )

            # User KB (agent read-only) — reuse project instance if paths overlap
            if project_kb_dir.resolve() != user_kb_dir.resolve():
                self._user_kb_manager = KnowledgeBaseManager(
                    settings=self._settings,
                    use_mock=use_mock,
                    base_dir=user_kb_dir,
                )
            else:
                self._user_kb_manager = self._kb_manager

        if "approval_manager" in self._required_managers and self._approval_manager is None:
            from agentic_cli.tools.hitl_tools import ApprovalManager
            self._approval_manager = ApprovalManager()

        if "llm_summarizer" in self._required_managers and self._llm_summarizer is None:
            self._llm_summarizer = self._create_summarizer()

        if "sandbox_manager" in self._required_managers and self._sandbox_manager is None:
            from agentic_cli.tools.sandbox.manager import SandboxManager
            self._sandbox_manager = SandboxManager(self._settings)

    def _create_summarizer(self) -> Any:
        """Create an LLM summarizer for webfetch.

        Subclasses should override this to return a framework-specific
        summarizer that implements the LLMSummarizer protocol.

        Returns:
            An LLMSummarizer implementation, or None.
        """
        return None

    @contextlib.contextmanager
    def _workflow_context(self) -> Iterator[None]:
        """Context manager for settings, workflow, and manager contexts.

        Sets context variables that allow tools to access settings,
        the workflow manager, and feature managers during execution.
        Uses token-based reset to correctly restore parent context.
        """
        tokens = [
            set_context_settings(self._settings),
            set_context_workflow(self),
            set_context_memory_store(self._memory_manager),
            set_context_plan_store(self._plan_store),
            set_context_task_store(self._task_store),
            set_context_kb_manager(self._kb_manager),
            set_context_user_kb_manager(self._user_kb_manager),
            set_context_approval_manager(self._approval_manager),
            set_context_llm_summarizer(self._llm_summarizer),
            set_context_sandbox_manager(self._sandbox_manager),
        ]
        try:
            yield
        finally:
            for token in tokens:
                token.var.reset(token)

    def _cleanup_managers(self) -> None:
        """Clean up all manager resources (call from subclass cleanup)."""
        if self._sandbox_manager is not None:
            self._sandbox_manager.cleanup()
            self._sandbox_manager = None
        self._memory_manager = None
        self._plan_store = None
        self._task_store = None
        self._kb_manager = None
        self._user_kb_manager = None
        self._approval_manager = None
        self._llm_summarizer = None

    @property
    @abstractmethod
    def backend_type(self) -> str:
        """Return the backend type identifier (e.g. 'adk', 'langgraph')."""
        ...

    def _apply_event_hook(self, event: WorkflowEvent) -> WorkflowEvent | None:
        """Apply the optional on_event transformation hook.

        Returns the (possibly transformed) event, or None if suppressed.
        """
        if self._on_event:
            return self._on_event(event)
        return event

    @property
    def model(self) -> str:
        """Get the model name, resolving from settings if needed.

        This is resolved lazily to allow startup without API keys.
        Subclasses can override if they need custom model resolution.
        """
        if not self._model_resolved:
            self._model = self._settings.get_model()
            self._model_resolved = True
            logger.info("model_resolved", model=self._model)
        return self._model  # type: ignore[return-value]

    async def initialize_services(self, validate: bool = True) -> None:
        """Initialize backend services asynchronously.

        Template method that handles shared scaffolding (guard, validation,
        key export, manager init, flag) and delegates backend-specific work
        to :meth:`_do_initialize`.

        Args:
            validate: If True, validate settings before initialization.

        Raises:
            SettingsValidationError: If settings validation fails.
        """
        if self._initialized:
            return

        from agentic_cli.config import validate_settings

        if validate:
            validate_settings(self._settings)

        self._settings.export_api_keys_to_env()

        # Refresh model registry from APIs
        await self._model_registry.refresh(
            google_api_key=self._settings.google_api_key,
            anthropic_api_key=self._settings.anthropic_api_key,
        )
        self._settings.set_model_registry(self._model_registry)

        await self._do_initialize()
        self._ensure_managers_initialized()
        self._initialized = True

    @abstractmethod
    async def _do_initialize(self) -> None:
        """Backend-specific initialization (create agents/graph).

        Subclasses implement this instead of ``initialize_services()``.
        """
        ...

    def _reset_model(self, model: str | None) -> None:
        """Reset model state for reinitialisation."""
        if model is not None:
            self._model = model
            self._model_resolved = True
        else:
            self._model = None
            self._model_resolved = False

    @abstractmethod
    async def process(
        self,
        message: str,
        user_id: str,
        session_id: str | None = None,
    ) -> AsyncGenerator[WorkflowEvent, None]:
        """Process user input through the agentic workflow.

        This is the main entry point for message processing. Implementations
        should:
        1. Ensure services are initialized
        2. Set up appropriate context for tools
        3. Process the message through the backend
        4. Yield WorkflowEvent objects for each step

        Args:
            message: User message to process.
            user_id: User identifier.
            session_id: Optional session identifier.

        Yields:
            WorkflowEvent objects representing workflow output.
        """
        # This is needed to make the method an async generator
        if False:  # pragma: no cover
            yield  # type: ignore[misc]

    @abstractmethod
    async def reinitialize(
        self,
        model: str | None = None,
        preserve_sessions: bool = True,
    ) -> None:
        """Reinitialize the workflow manager with new configuration.

        Use this method when settings change (e.g., model switch) to
        properly recreate agents and runners.

        Args:
            model: Optional new model to use.
            preserve_sessions: If True, keeps existing session data.
        """
        pass

    @abstractmethod
    async def cleanup(self) -> None:
        """Clean up workflow manager resources.

        Release resources and reset state. Should be called before
        shutting down or when reinitializing with new settings.
        """
        pass

    # User input handling — callback-only

    async def request_user_input(self, request: UserInputRequest) -> str:
        """Request user input from the CLI via callback.

        Called by tools that need user interaction. Requires
        ``set_input_callback()`` to be set by the consumer (e.g.
        MessageProcessor) before any tool invokes this method.

        Args:
            request: The user input request.

        Returns:
            User's response string.

        Raises:
            RuntimeError: If no callback is registered.
        """
        logger.debug(
            "user_input_requested",
            request_id=request.request_id,
            tool_name=request.tool_name,
        )

        if self._user_input_callback is None:
            raise RuntimeError(
                "No user input callback registered. "
                "Call set_input_callback() before invoking tools that require user input."
            )

        return await self._user_input_callback(request)

    # Async context manager support

    async def __aenter__(self) -> "BaseWorkflowManager":
        """Async context manager entry - initialize services."""
        await self.initialize_services()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit - cleanup resources."""
        await self.cleanup()

    # Optional methods with default implementations

    def update_settings(self, settings: "BaseSettings") -> None:
        """Update the settings instance.

        Note: This only updates the settings reference. To apply changes
        that affect agent behavior, call reinitialize().

        Args:
            settings: New settings instance.
        """
        self._settings = settings

    async def generate_simple(self, prompt: str, max_tokens: int = 500) -> str:
        """Generate a simple text response using the current model.

        Used for internal operations like summarization. Does not go through
        the full agent workflow.

        Args:
            prompt: The prompt to send.
            max_tokens: Maximum tokens in response.

        Returns:
            Generated text response.

        Note:
            Default implementation raises NotImplementedError.
            Subclasses should override if they support simple generation.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement generate_simple"
        )

    # -------------------------------------------------------------------------
    # Session save/resume
    # -------------------------------------------------------------------------

    async def save_session(self, session_id: str | None = None) -> dict:
        """Save current session state to disk.

        Extracts messages and current agent from the backend via abstract
        hooks, then persists via SessionPersistence.save_snapshot().

        Args:
            session_id: Session ID to save under. Uses backend session_id if None.

        Returns:
            Dict with success status and path.
        """
        from datetime import datetime
        from agentic_cli.persistence.session import SessionPersistence, SessionSnapshot

        sid = session_id or getattr(self, "session_id", "default_session")

        try:
            messages = await self._extract_session_messages(sid)
            current_agent = await self._extract_current_agent(sid)

            metadata: dict[str, Any] = {
                "model": self.model,
                "backend_type": self.backend_type,
                "app_name": self._app_name,
            }
            if current_agent:
                metadata["current_agent"] = current_agent

            now = datetime.now()
            snapshot = SessionSnapshot(
                session_id=sid,
                created_at=now,
                saved_at=now,
                messages=messages,
                metadata=metadata,
            )

            persistence = SessionPersistence(self._settings)
            path = persistence.save_snapshot(snapshot)

            logger.info("session_saved", session_id=sid, message_count=len(messages))
            return {"success": True, "session_id": sid, "path": str(path), "message_count": len(messages)}

        except Exception as exc:
            logger.error("session_save_failed", session_id=sid, error=str(exc))
            return {"success": False, "error": str(exc)}

    async def load_session(self, session_id: str) -> bool:
        """Load a saved session and inject it into the backend.

        Args:
            session_id: Session ID to load.

        Returns:
            True if session was loaded successfully, False otherwise.
        """
        from agentic_cli.persistence.session import SessionPersistence

        persistence = SessionPersistence(self._settings)
        snapshot = persistence.load_session(session_id)

        if snapshot is None:
            logger.debug("session_not_found_for_load", session_id=session_id)
            return False

        # Warn on backend mismatch (but still load — format is normalized)
        saved_backend = snapshot.metadata.get("backend_type")
        if saved_backend and saved_backend != self.backend_type:
            logger.warning(
                "session_backend_mismatch",
                saved_backend=saved_backend,
                current_backend=self.backend_type,
                session_id=session_id,
            )

        current_agent = snapshot.metadata.get("current_agent")

        try:
            await self._inject_session_messages(session_id, snapshot.messages, current_agent)
            if hasattr(self, "session_id"):
                self.session_id = session_id
            logger.info(
                "session_loaded",
                session_id=session_id,
                message_count=len(snapshot.messages),
            )
            return True
        except Exception as exc:
            logger.error("session_load_failed", session_id=session_id, error=str(exc))
            return False

    def list_sessions(self) -> list[dict]:
        """List all saved sessions.

        Returns:
            List of session summary dicts.
        """
        from agentic_cli.persistence.session import SessionPersistence

        persistence = SessionPersistence(self._settings)
        return persistence.list_sessions()

    @abstractmethod
    async def _extract_session_messages(self, session_id: str) -> list[dict]:
        """Extract normalized messages from the backend session.

        Returns list of dicts with structure:
        - {"role": "user", "content": "..."}
        - {"role": "assistant", "content": "...", "tool_calls": [...]}
        - {"role": "tool", "tool_call_id": "...", "name": "...", "content": "..."}
        """
        ...

    @abstractmethod
    async def _extract_current_agent(self, session_id: str) -> str | None:
        """Return the name of the currently active agent, or None."""
        ...

    @abstractmethod
    async def _inject_session_messages(
        self,
        session_id: str,
        messages: list[dict],
        current_agent: str | None = None,
    ) -> None:
        """Inject normalized messages into the backend session."""
        ...

    def _emit_task_progress_event(self) -> WorkflowEvent | None:
        """Build a TASK_PROGRESS event from TaskStore or PlanStore.

        Delegates to :func:`~agentic_cli.workflow.task_progress.build_task_progress_event`.
        """
        from agentic_cli.workflow.task_progress import build_task_progress_event

        return build_task_progress_event(self._task_store, self._plan_store)

