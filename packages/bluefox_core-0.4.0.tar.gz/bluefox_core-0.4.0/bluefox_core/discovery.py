"""Convention-based auto-discovery for models and routers.

Scans CWD for `models.py` and `api.py` files following these patterns:
  - models.py / api.py          (root level)
  - app/models.py / app/api.py  (app package)
  - */models.py / */api.py      (any top-level package)

Models are imported so they register in BluefoxBase.metadata.
Routers are imported and mounted on the FastAPI app with the directory name as prefix.
"""

from __future__ import annotations

import importlib
import inspect
import logging
import sys
from pathlib import Path

from fastapi import APIRouter, FastAPI
from sqlalchemy.orm import DeclarativeBase

from bluefox_core.database import BluefoxBase
from bluefox_core.settings import BluefoxSettings

logger = logging.getLogger("bluefox.discovery")

# Conventional file patterns to scan (relative to CWD).
_MODEL_PATTERNS = [
    "models.py",
    "app/models.py",
    "*/models.py",
]

_ROUTER_PATTERNS = [
    "api.py",
    "app/api.py",
    "*/api.py",
]


def _find_modules(patterns: list[str]) -> list[tuple[str, Path]]:
    """Find Python modules matching glob patterns in CWD.

    Returns list of (dotted_module_name, file_path) tuples.
    """
    cwd = Path.cwd()
    seen: set[Path] = set()
    modules: list[tuple[str, Path]] = []

    for pattern in patterns:
        for path in sorted(cwd.glob(pattern)):
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            relative = path.relative_to(cwd).with_suffix("")
            module_name = ".".join(relative.parts)
            modules.append((module_name, path))

    return modules


def _check_base_inheritance(module_name: str) -> None:
    """Warn about SQLAlchemy models that don't inherit from BluefoxBase."""
    module = sys.modules.get(module_name)
    if module is None:
        return

    for _name, obj in inspect.getmembers(module, inspect.isclass):
        if obj.__module__ != module_name:
            continue
        if issubclass(obj, DeclarativeBase) and not issubclass(obj, BluefoxBase):
            logger.warning(
                "Model %s.%s inherits from DeclarativeBase but not BluefoxBase. "
                "It won't be tracked by Bluefox migrations. "
                "Change it to inherit from BluefoxBase instead.",
                module_name,
                _name,
            )


def discover_models(settings: BluefoxSettings) -> None:
    """Import model modules to register tables in BluefoxBase.metadata.

    Discovery order:
    1. If MODELS_MODULE is set explicitly, import only that module.
    2. Otherwise, scan CWD for models.py files by convention.

    After import, warns about any SQLAlchemy model that doesn't inherit
    from BluefoxBase (the "lint" check).
    """
    if settings.MODELS_MODULE:
        importlib.import_module(settings.MODELS_MODULE)
        _check_base_inheritance(settings.MODELS_MODULE)
        return

    modules = _find_modules(_MODEL_PATTERNS)

    if not modules:
        logger.debug("No models.py files found in %s", Path.cwd())
        return

    for module_name, _path in modules:
        try:
            importlib.import_module(module_name)
            _check_base_inheritance(module_name)
        except ImportError as exc:
            logger.debug("Skipping %s: %s", module_name, exc)


def _prefix_from_path(path: Path, cwd: Path | None = None) -> str:
    """Derive a URL prefix from a file path.

    Examples:
        api.py         -> ""     (root-level, no prefix)
        app/api.py     -> ""     (app package, no prefix)
        items/api.py   -> "/items"
        users/api.py   -> "/users"
    """
    if cwd is None:
        cwd = Path.cwd()
    relative = path.relative_to(cwd)
    parts = relative.parent.parts

    # Root-level api.py or app/api.py — no prefix
    if not parts or parts == ("app",):
        return ""

    # Use the first directory as the prefix
    return f"/{parts[0]}"


def discover_routers(app: FastAPI) -> None:
    """Find and mount api.py routers by convention.

    Scans CWD for api.py files, imports them, and looks for a `router`
    attribute (an APIRouter instance). Mounts each router on the app
    with the directory name as the URL prefix.
    """
    modules = _find_modules(_ROUTER_PATTERNS)

    if not modules:
        logger.debug("No api.py files found in %s", Path.cwd())
        return

    for module_name, path in modules:
        try:
            module = importlib.import_module(module_name)
        except ImportError as exc:
            logger.debug("Skipping %s: %s", module_name, exc)
            continue

        router = getattr(module, "router", None)
        if not isinstance(router, APIRouter):
            logger.debug(
                "Module %s has no 'router' attribute (APIRouter), skipping",
                module_name,
            )
            continue

        prefix = _prefix_from_path(path)
        app.include_router(router, prefix=prefix)
        logger.info("Mounted router from %s at %s", module_name, prefix or "/")
