========================
PHANGS pipeline example
========================

tbw