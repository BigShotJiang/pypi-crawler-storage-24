"""
The content of this library is no longer used,
so I move the code to this 'old' folder just in
case, to be completely removed soon.

I need room for new code that I will use.
"""