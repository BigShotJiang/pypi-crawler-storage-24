"""
The module to include classes related to the
rendering context.
"""
from yta_validation.parameter import ParameterValidator


class RenderContext:
    """
    A context that will be used along a rendering
    process, to be able to access to different
    resources, providers, etc.
    """

    def __init__(
        self,
        render_config: 'RenderConfig',
        # TODO: Maybe rename to 'render_resources_hander'
        render_resources: 'RenderResources'
    ):
        ParameterValidator.validate_mandatory_instance_of('render_config', render_config, 'RenderConfig')
        ParameterValidator.validate_mandatory_instance_of('render_resources', render_resources, 'RenderResources')

        self.render_config: 'RenderConfig' = render_config
        """
        The configuration of the rendering process.
        """
        self.render_resources: 'RenderResources' = render_resources
        """
        The handler of the rendering process resources.
        """