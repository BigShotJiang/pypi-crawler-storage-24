"""
Marziel AI — Private Intelligence, Locally Powered.

pip install marziel
marziel serve
"""

__version__ = "1.4.0"
__author__ = "Marziel AI Team"
