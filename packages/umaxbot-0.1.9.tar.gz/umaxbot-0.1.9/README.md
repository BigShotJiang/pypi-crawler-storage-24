#maxbot

Асинхронный Python-фреймворк для создания ботов в мессенджере MAX
.

🎯 Синтаксис как у aiogram
🚀 Поддержка polling (с очередями и параллелизмом)
💬 Inline-кнопки
📦 Работа с файлами (image / video / audio / file)
⚡ Оптимизирован под нагрузку

⚠️ Важные изменения API (обязательно прочитать)
🔐 Авторизация

❌ access_token в query больше НЕ поддерживается
✅ Используется только заголовок:

Authorization: <token>
📎 Работа с файлами (новая логика)

Теперь ВСЕ типы файлов работают одинаково:

Получаем upload_url через /uploads
Загружаем файл
Получаем payload (JSON)
Передаём весь payload в attachments

❌ Старое:

"payload": { "token": "..." }

✅ Новое:

"payload": { ...весь JSON ответа upload... }
🎬 Видео / аудио

Раньше:

token брался из /uploads

Теперь:

token приходит после загрузки файла
используется через payload
💬 Reply (ответ на сообщение)

Добавлено поле link:

"link": {
  "type": "reply",
  "mid": "message_id"
}
Установка
pip install umaxbot
Пример
from maxbot.bot import Bot
from maxbot.dispatcher import Dispatcher
from maxbot.types import InlineKeyboardMarkup, InlineKeyboardButton, Message

bot = Bot("YourToken")
dp = Dispatcher(bot)

@dp.message()
async def on_message(message: Message):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👋 Поздороваться", callback_data="hello")]
    ])
    await bot.send_message(
        chat_id=message.sender.id,
        text="Привет! Нажми на кнопку ниже:",
        reply_markup=keyboard
    )

@dp.callback()
async def on_callback(cb):
    if cb.payload == "hello":
        await bot.send_message(cb.user.id, "Приятно познакомиться!")
🚀 Новое: reply (ответ на сообщение)
await bot.reply(
    message_id=message.mid,
    chat_id=message.chat_id,
    text="Ответ на сообщение"
)
🚀 Производительность (новый Dispatcher)

Теперь Dispatcher поддерживает:

✅ очередь (Queue)
✅ воркеры
✅ параллельную обработку
✅ ограничение нагрузки (Semaphore)
✅ защиту от падений
Пример настройки:
dp = Dispatcher(bot, workers=10, max_tasks=200)
Рекомендации:
Нагрузка	Настройки
Маленькая	workers=5, max_tasks=50
Средняя	workers=10, max_tasks=200
Высокая	workers=20+, max_tasks=500+
Класс Bot: основные методы
Метод	Описание
get_me()	Получить информацию о боте
send_message(...)	Отправить сообщение
reply(...)	Ответить на сообщение
send_file(...)	Отправить файл
update_message(...)	Изменить сообщение
delete_message(...)	Удалить сообщение
answer_callback(...)	Ответить на callback
download_media(...)	Скачать файл

Все методы асинхронные!

📎 Пример отправки файла
await bot.send_file(
    chat_id=message.chat_id,
    file_path="video.mp4",
    media_type="video",
    text="Вот видео"
)
📥 Работа с медиа
@dp.message()
async def on_message(msg: Message):
    audio = msg.get_attachment("audio")
    if audio:
        await audio.download(bot, "voice.ogg")

    for img in msg.get_attachments("image"):
        await img.download(bot)
FSM (Finite State Machine)
from maxbot.fsm import State, StatesGroup

class Form(StatesGroup):
    name = State()
    age = State()

@dp.message()
async def on_message(msg: Message):
    await msg.set_state(Form.name)
    await msg.update_data(name="Вова")
    await msg.reset_state()
Роутеры (Router)
from maxbot.router import Router

router = Router()

@router.message()
async def any_text(message):
    await message.reply("Любой текст!")

dp.include_router(router)
Фильтры
from maxbot.filters import F, StateFilter, TextStartsFilter

@dp.message(F.text == "привет")
async def on_hello(msg):
    await msg.reply("И тебе привет!")
Inline-клавиатуры
kb = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Сайт", url="https://max.ru")],
    [InlineKeyboardButton(text="Нажми", callback_data="click")]
])
Типы
Message
Callback
Attachment
InlineKeyboardMarkup
Dispatcher / Router
FSM
⚠️ Ограничения API MAX
До 30 запросов/сек
Файлы до 4 ГБ
Видео/аудио требуют времени на обработку
💡 Рекомендации для продакшена

Если планируешь масштаб:

Используй очередь (Redis / RabbitMQ)
Выноси тяжёлые задачи (AI, генерация) в отдельные воркеры
Кешируй upload payload (не загружай файлы повторно)
Делай retry с backoff
MAXBot

Быстрый старт, высокая производительность и архитектура, готовая к росту 🚀