"""
breach-intel-client — Python SDK for the Breach Intel Policy Agent

Zero stdlib dependencies. Drop into any Python AI agent.

    pip install breach-intel-client

Quick start:
    from breach_intel_client import PolicyAgentClient

    client = PolicyAgentClient("http://localhost:8080", agent_id="your-agent-id")
    result = client.emit_llm_response(llm_output, tenant_id="cust-001")
    if result.is_breach:
        print(f"BREACH: {result.breach_types}")

Passive mode (zero code — just set env vars):
    BREACH_INTEL_URL=http://localhost:8080 python your_agent.py
"""

from .client import (
    BreachRecord,
    EventResult,
    PolicyAgentClient,
    RegistrationResult,
)
from .auto import (
    monitor,
    auto_monitor,
    auto_attach,
    get_client,
    LangChainBreachHandler,
)

# AsyncPolicyAgentClient requires httpx — import conditionally
try:
    from .client import AsyncPolicyAgentClient  # type: ignore
except ImportError:
    AsyncPolicyAgentClient = None  # type: ignore

__version__ = "0.3.0"
__all__ = [
    "PolicyAgentClient",
    "AsyncPolicyAgentClient",
    "EventResult",
    "BreachRecord",
    "RegistrationResult",
    # Auto-instrumentation
    "monitor",
    "auto_monitor",
    "auto_attach",
    "get_client",
    "LangChainBreachHandler",
]

# ─── Import-time passive activation ──────────────────────────────────────────
# If BREACH_INTEL_URL is set, auto-attach on import. Silent by default —
# never breaks the importing application.

import os as _os
if _os.environ.get("BREACH_INTEL_URL"):
    auto_attach()
