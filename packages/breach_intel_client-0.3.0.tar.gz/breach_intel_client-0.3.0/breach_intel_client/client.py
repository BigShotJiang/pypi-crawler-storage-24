"""
Breach Intel Client — Python SDK

Zero-dependency (uses stdlib httpx or falls back to urllib).
Designed to be dropped into any Python agent with one import.

Usage:
    from breach_intel_client import PolicyAgentClient

    client = PolicyAgentClient(
        base_url="http://your-policy-agent:8080",
        agent_id="your-agent-id",          # from register()
        api_token="optional-bearer-token",
    )

    # Emit an event
    result = client.emit("llm_response", {"text": llm_output}, tenant_id="cust-001")
    if result.is_breach:
        print(f"BREACH: {result.breach_types} [{result.severity}]")
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4


# ─── Response types ────────────────────────────────────────────────────────────


@dataclass
class EventResult:
    event_id: str
    is_breach: bool
    breach_id: Optional[str] = None
    breach_types: List[str] = field(default_factory=list)
    severity: Optional[str] = None
    message: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "EventResult":
        return cls(
            event_id=d.get("event_id", ""),
            is_breach=d.get("is_breach", False),
            breach_id=d.get("breach_id"),
            breach_types=d.get("breach_types", []),
            severity=d.get("severity"),
            message=d.get("message", ""),
        )


@dataclass
class RegistrationResult:
    agent_id: str
    agent_name: str
    vertical: str
    declared_capabilities: List[str]
    approved_domains: List[str]
    registered_at: str

    @classmethod
    def from_dict(cls, d: dict) -> "RegistrationResult":
        return cls(
            agent_id=d.get("agent_id", ""),
            agent_name=d.get("agent_name", ""),
            vertical=d.get("vertical", ""),
            declared_capabilities=d.get("declared_capabilities", []),
            approved_domains=d.get("approved_domains", []),
            registered_at=d.get("registered_at", ""),
        )


@dataclass
class BreachRecord:
    breach_id: str
    event_id: str
    agent_id: str
    breach_types: List[str]
    severity: str
    rationale: str
    regulatory_scope: List[str]
    event_type: str
    logged_at: str
    tenant_id: Optional[str] = None
    agent_name: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "BreachRecord":
        return cls(
            breach_id=d["breach_id"],
            event_id=d["event_id"],
            agent_id=d["agent_id"],
            breach_types=d.get("breach_types", []),
            severity=d.get("severity", ""),
            rationale=d.get("rationale", ""),
            regulatory_scope=d.get("regulatory_scope", []),
            event_type=d.get("event_type", ""),
            logged_at=d.get("logged_at", ""),
            tenant_id=d.get("tenant_id"),
            agent_name=d.get("agent_name"),
        )


# ─── Client ────────────────────────────────────────────────────────────────────


class PolicyAgentClient:
    """
    Thread-safe, zero-dependency client for the Breach Intel Policy Agent.

    Parameters
    ----------
    base_url : str
        Base URL of the policy agent, e.g. "http://localhost:8080"
    agent_id : str
        The agent_id returned from register(). Required for emit().
    vertical : str
        Domain vertical. Default: "fintech".
    api_token : str
        Bearer token if the policy agent has auth enabled.
    timeout : float
        HTTP timeout in seconds. Default: 5.0.
    silent : bool
        If True, swallow all network errors (never raises). Useful when
        the policy agent is best-effort and shouldn't block your agent.
    """

    def __init__(
        self,
        base_url: str,
        agent_id: str = "",
        vertical: str = "fintech",
        api_token: str = "",
        timeout: float = 5.0,
        silent: bool = False,
    ):
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.vertical = vertical
        self.api_token = api_token
        self.timeout = timeout
        self.silent = silent

    # ─── Registration ──────────────────────────────────────────────────────────

    def register(
        self,
        agent_name: str,
        owner_id: str,
        declared_capabilities: List[str],
        approved_domains: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> RegistrationResult:
        """
        Register this agent with the policy agent.
        Call once at agent startup. Saves the returned agent_id.

        Example:
            result = client.register(
                agent_name="Portfolio Advisor",
                owner_id="acme-corp",
                declared_capabilities=["read_portfolio", "get_market_data"],
                approved_domains=["api.bloomberg.com"],
            )
            client.agent_id = result.agent_id
        """
        payload = {
            "agent_name": agent_name,
            "owner_id": owner_id,
            "vertical": self.vertical,
            "declared_capabilities": declared_capabilities,
            "approved_domains": approved_domains or [],
            "policy_agent_id": "primary",
            "metadata": metadata,
        }
        resp = self._post("/agents/register", payload)
        result = RegistrationResult.from_dict(resp)
        self.agent_id = result.agent_id
        return result

    # ─── Event emission ────────────────────────────────────────────────────────

    def emit(
        self,
        event_type: str,
        payload: Dict[str, Any],
        tenant_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        agent_name: Optional[str] = None,
    ) -> EventResult:
        """
        Emit any agent event for classification.

        event_type: "llm_response" | "tool_call" | "api_request" | "file_read" | "action"
        payload:    the actual event content (tool args, LLM output, HTTP request, etc.)

        Returns an EventResult. Check result.is_breach.
        """
        if not self.agent_id:
            raise ValueError(
                "agent_id not set. Call register() first or pass agent_id to constructor."
            )

        body = {
            "event_id": str(uuid4()),
            "agent_id": self.agent_id,
            "agent_name": agent_name,
            "tenant_id": tenant_id,
            "vertical": self.vertical,
            "event_type": event_type,
            "payload": payload,
            "context": context,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        try:
            resp = self._post("/events", body)
            return EventResult.from_dict(resp)
        except Exception as e:
            if self.silent:
                return EventResult(
                    event_id=body["event_id"], is_breach=False, message=f"error: {e}"
                )
            raise

    # ─── Convenience wrappers ─────────────────────────────────────────────────

    def emit_llm_response(
        self, text: str, tenant_id: Optional[str] = None, **kwargs
    ) -> EventResult:
        """Shorthand for emitting an LLM response."""
        return self.emit("llm_response", {"text": text}, tenant_id=tenant_id, **kwargs)

    def emit_tool_call(
        self,
        tool_name: str,
        args: Dict[str, Any],
        tenant_id: Optional[str] = None,
        **kwargs,
    ) -> EventResult:
        """Shorthand for emitting a tool call."""
        return self.emit(
            "tool_call",
            {"tool": tool_name, "args": args},
            tenant_id=tenant_id,
            **kwargs,
        )

    def emit_api_request(
        self,
        method: str,
        url: str,
        body: Optional[Any] = None,
        tenant_id: Optional[str] = None,
        **kwargs,
    ) -> EventResult:
        """Shorthand for emitting an outbound API request."""
        return self.emit(
            "api_request",
            {"method": method.upper(), "url": url, "body": body},
            tenant_id=tenant_id,
            **kwargs,
        )

    # ─── Query ────────────────────────────────────────────────────────────────

    def get_breaches(
        self,
        severity: Optional[str] = None,
        tenant_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[BreachRecord]:
        """List breach records for this agent."""
        params = f"agent_id={self.agent_id}&limit={limit}"
        if severity:
            params += f"&severity={severity}"
        if tenant_id:
            params += f"&tenant_id={tenant_id}"
        rows = self._get(f"/breaches?{params}")
        return [BreachRecord.from_dict(r) for r in rows]

    def get_breach(self, breach_id: str) -> BreachRecord:
        """Get a single breach record."""
        return BreachRecord.from_dict(self._get(f"/breaches/{breach_id}"))

    def verify_breach(self, breach_id: str) -> dict:
        """Check if a breach record has been tampered with."""
        return self._get(f"/breaches/{breach_id}/verify")

    def summary(self) -> dict:
        """High-level breach counts."""
        return self._get("/summary")

    def health(self) -> dict:
        return self._get("/health")

    # ─── HTTP primitives (stdlib only) ───────────────────────────────────────

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.api_token:
            h["Authorization"] = f"Bearer {self.api_token}"
        return h

    def _post(self, path: str, body: dict) -> dict:
        url = self.base_url + path
        data = json.dumps(body, default=str).encode()
        req = urllib.request.Request(
            url, data=data, headers=self._headers(), method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_text = e.read().decode(errors="replace")
            raise RuntimeError(f"Policy agent error {e.code}: {body_text}") from e

    def _get(self, path: str) -> Any:
        url = self.base_url + path
        req = urllib.request.Request(url, headers=self._headers(), method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_text = e.read().decode(errors="replace")
            raise RuntimeError(f"Policy agent error {e.code}: {body_text}") from e


# ─── Async client (optional — requires httpx) ─────────────────────────────────

try:
    import httpx

    class AsyncPolicyAgentClient(PolicyAgentClient):
        """
        Async variant using httpx. Install with: pip install httpx

        Usage:
            async with AsyncPolicyAgentClient(...) as client:
                result = await client.emit_async("llm_response", {"text": "..."})
        """

        async def __aenter__(self):
            self._http = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=self.timeout,
            )
            return self

        async def __aexit__(self, *args):
            await self._http.aclose()

        async def emit_async(
            self,
            event_type: str,
            payload: Dict[str, Any],
            tenant_id: Optional[str] = None,
            context: Optional[Dict[str, Any]] = None,
        ) -> EventResult:
            body = {
                "event_id": str(uuid4()),
                "agent_id": self.agent_id,
                "tenant_id": tenant_id,
                "vertical": self.vertical,
                "event_type": event_type,
                "payload": payload,
                "context": context,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            try:
                resp = await self._http.post("/events", json=body)
                resp.raise_for_status()
                return EventResult.from_dict(resp.json())
            except Exception as e:
                if self.silent:
                    return EventResult(
                        event_id=body["event_id"], is_breach=False, message=str(e)
                    )
                raise

        async def emit_llm_response_async(self, text: str, **kwargs) -> EventResult:
            return await self.emit_async("llm_response", {"text": text}, **kwargs)

        async def emit_tool_call_async(
            self, tool_name: str, args: dict, **kwargs
        ) -> EventResult:
            return await self.emit_async(
                "tool_call", {"tool": tool_name, "args": args}, **kwargs
            )

except ImportError:
    pass  # httpx not installed — AsyncPolicyAgentClient unavailable, sync client works fine
