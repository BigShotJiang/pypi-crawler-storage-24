"""
breach-intel CLI — wraps any Python command with automatic breach monitoring.

Usage:
    breach-intel run python your_agent.py
    breach-intel run -- python -m my_module --flag
    breach-intel install-hook              # persistent auto-instrumentation
    breach-intel uninstall-hook            # remove persistent hook
    breach-intel status                    # check policy agent health
    breach-intel version                   # print SDK version

The `run` subcommand:
  1. Sets BREACH_INTEL_URL from config/env (if not already set)
  2. Injects `import breach_intel_client` before the target script
  3. Auto-patches OpenAI/LangChain/Anthropic via the passive auto-attach
  4. Runs the command normally

The `install-hook` subcommand:
  Writes a persistent sitecustomize.py hook so ALL Python processes on this
  machine auto-instrument when BREACH_INTEL_URL is set. No code changes needed.

Configuration (env vars):
    BREACH_INTEL_URL    — policy agent URL (default: http://localhost:8080)
    BREACH_INTEL_TOKEN  — API token (optional)
"""

import os
import sys
import subprocess


# ─── Sitecustomize hook content ──────────────────────────────────────────────

_HOOK_START = "# --- breach-intel-start ---"
_HOOK_END = "# --- breach-intel-end ---"
_HOOK_CONTENT = """\
# --- breach-intel-start ---
# Auto-instrumentation: monitors LLM calls (OpenAI, Anthropic, LangChain)
# for compliance breaches when BREACH_INTEL_URL is set.
try:
    import os as _bi_os
    if _bi_os.environ.get("BREACH_INTEL_URL"):
        import breach_intel_client  # triggers auto_attach() on import
except Exception:
    pass
# --- breach-intel-end ---
"""


def main():
    if len(sys.argv) < 2:
        _usage()
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd in ("--help", "-h", "help"):
        _usage()
    elif cmd == "version":
        from . import __version__
        print(f"breach-intel-client {__version__}")
    elif cmd == "status":
        _status()
    elif cmd == "run":
        _run(sys.argv[2:])
    elif cmd == "install-hook":
        _install_hook()
    elif cmd == "uninstall-hook":
        _uninstall_hook()
    elif cmd == "doctor":
        _doctor()
    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        _usage()
        sys.exit(1)


def _usage():
    print("""Usage: breach-intel <command> [args...]

Commands:
  doctor            Diagnose your setup (hook, env vars, server, frameworks)
  run <cmd...>      Run a command with automatic breach monitoring
  install-hook      Install persistent Python hook (all processes auto-instrumented)
  uninstall-hook    Remove persistent Python hook
  status            Check if the policy agent is reachable
  version           Print SDK version
  help              Show this help

Examples:
  breach-intel run python your_agent.py
  breach-intel run -- python -m my_module --verbose
  breach-intel install-hook
  BREACH_INTEL_URL=http://prod:8080 breach-intel run python bot.py

Environment variables:
  BREACH_INTEL_URL    Policy agent URL (default: http://localhost:8080)
  BREACH_INTEL_TOKEN  API token (optional, if auth enabled)""")


def _status():
    import urllib.request
    import json

    url = os.environ.get("BREACH_INTEL_URL", "http://localhost:8080")
    token = os.environ.get("BREACH_INTEL_TOKEN", "")
    headers = {"Authorization": f"Bearer {token}"} if token else {}

    try:
        req = urllib.request.Request(f"{url}/health", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            print(f"Policy agent at {url}")
            print(f"  Status:   {data.get('status', 'unknown')}")
            print(f"  Instance: {data.get('instance', 'unknown')}")
            print(f"  Auth:     {'enabled' if data.get('auth_enabled') else 'disabled'}")
            print(f"  Vertical: {data.get('vertical', 'unknown')}")
    except Exception as e:
        print(f"Cannot reach policy agent at {url} — {e}", file=sys.stderr)
        sys.exit(1)

    # Try to get summary stats (needs auth)
    try:
        req = urllib.request.Request(f"{url}/summary?window_hours=24", method="GET", headers=headers)
        with urllib.request.urlopen(req, timeout=5) as resp:
            summary = json.loads(resp.read())
            total = summary.get("total_breaches", 0)
            by_sev = summary.get("by_severity", {})
            print(f"\n  Breaches (24h): {total}")
            for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                count = by_sev.get(sev, 0)
                if count > 0:
                    print(f"    {sev}: {count}")
    except Exception:
        pass  # summary requires auth — skip silently


def _run(args):
    if not args:
        print("Usage: breach-intel run <command> [args...]", file=sys.stderr)
        sys.exit(1)

    # Strip leading -- separator
    if args[0] == "--":
        args = args[1:]

    if not args:
        print("Usage: breach-intel run <command> [args...]", file=sys.stderr)
        sys.exit(1)

    # Set default URL if not configured
    if "BREACH_INTEL_URL" not in os.environ:
        os.environ["BREACH_INTEL_URL"] = "http://localhost:8080"

    # Detect if running a Python command — inject the SDK
    if _is_python_command(args):
        env = os.environ.copy()
        # Use PYTHONSTARTUP to inject the import before the script runs.
        # For `python -m module` and `python script.py`, we use sitecustomize.
        startup_code = "import breach_intel_client"

        # Prepend to PYTHONSTARTUP if running interactive,
        # or use -c wrapper for scripts
        if len(args) == 1 and args[0] in ("python", "python3"):
            # Interactive mode — use PYTHONSTARTUP
            _write_startup_file(startup_code)
            env["PYTHONSTARTUP"] = _startup_path()
            result = subprocess.run(args, env=env)
        else:
            # Script/module mode — wrap with sitecustomize
            site_dir = _write_sitecustomize(startup_code)
            # Prepend our site dir so sitecustomize.py runs on startup
            existing = env.get("PYTHONPATH", "")
            env["PYTHONPATH"] = f"{site_dir}:{existing}" if existing else site_dir
            result = subprocess.run(args, env=env)
            _cleanup_sitecustomize(site_dir)

        sys.exit(result.returncode)
    else:
        # Non-Python command — just set env vars and run
        result = subprocess.run(args, env=os.environ.copy())
        sys.exit(result.returncode)


def _is_python_command(args):
    cmd = os.path.basename(args[0])
    return cmd in ("python", "python3") or cmd.startswith("python3.")


def _startup_path():
    import tempfile
    return os.path.join(tempfile.gettempdir(), "breach_intel_startup.py")


def _write_startup_file(code):
    with open(_startup_path(), "w") as f:
        f.write(code + "\n")


def _write_sitecustomize(code):
    import tempfile
    site_dir = tempfile.mkdtemp(prefix="breach_intel_site_")
    with open(os.path.join(site_dir, "sitecustomize.py"), "w") as f:
        f.write(f"try:\n    {code}\nexcept Exception:\n    pass\n")
    return site_dir


def _cleanup_sitecustomize(site_dir):
    import shutil
    try:
        shutil.rmtree(site_dir, ignore_errors=True)
    except Exception:
        pass


# ─── Persistent hook install/uninstall ───────────────────────────────────────


def _get_user_site_dir() -> str:
    """Get the user site-packages directory where sitecustomize.py should live."""
    import site
    return site.getusersitepackages()


def _install_hook():
    """Install persistent sitecustomize.py hook for auto-instrumentation."""
    site_dir = _get_user_site_dir()
    site_customize_path = os.path.join(site_dir, "sitecustomize.py")

    # Create directory if needed
    os.makedirs(site_dir, exist_ok=True)

    # Check if already installed
    if os.path.exists(site_customize_path):
        with open(site_customize_path) as f:
            existing = f.read()
        if _HOOK_START in existing:
            print(f"breach-intel hook already installed in {site_customize_path}")
            return
        # Append to existing file
        with open(site_customize_path, "a") as f:
            f.write("\n" + _HOOK_CONTENT)
    else:
        with open(site_customize_path, "w") as f:
            f.write(_HOOK_CONTENT)

    print(f"breach-intel hook installed: {site_customize_path}")

    # Only print env var instructions if they're not already set
    if not os.environ.get("BREACH_INTEL_URL"):
        print()
        print("Set these environment variables (add to your shell profile):")
        print()
        print("  export BREACH_INTEL_URL=http://localhost:8080")
        print("  export BREACH_INTEL_TOKEN=<your-api-token>")
        print()
        print("To remove: breach-intel uninstall-hook")


def _uninstall_hook():
    """Remove the persistent sitecustomize.py hook."""
    site_dir = _get_user_site_dir()
    site_customize_path = os.path.join(site_dir, "sitecustomize.py")

    if not os.path.exists(site_customize_path):
        print("No sitecustomize.py found — nothing to remove.")
        return

    with open(site_customize_path) as f:
        content = f.read()

    if _HOOK_START not in content:
        print("breach-intel hook not found in sitecustomize.py — nothing to remove.")
        return

    # Remove the delimited block
    lines = content.split("\n")
    new_lines = []
    in_block = False
    for line in lines:
        if line.strip() == _HOOK_START.strip():
            in_block = True
            continue
        if line.strip() == _HOOK_END.strip():
            in_block = False
            continue
        if not in_block:
            new_lines.append(line)

    new_content = "\n".join(new_lines).strip()

    if new_content:
        with open(site_customize_path, "w") as f:
            f.write(new_content + "\n")
        print(f"breach-intel hook removed from {site_customize_path}")
    else:
        os.remove(site_customize_path)
        print(f"Removed {site_customize_path} (was breach-intel only)")

    print("Auto-instrumentation disabled.")


def _doctor():
    """Diagnose breach-intel setup — check everything end-to-end."""
    import urllib.request
    import json

    print("breach-intel doctor")
    print("=" * 50)
    issues = 0

    # 1. Check env vars
    print("\n[Environment]")
    url = os.environ.get("BREACH_INTEL_URL", "")
    token = os.environ.get("BREACH_INTEL_TOKEN", "")

    if url:
        print(f"  BREACH_INTEL_URL   = {url}")
    else:
        print("  BREACH_INTEL_URL   = (not set)")
        print("    -> Auto-instrumentation is INACTIVE in this shell.")
        print("    -> Run: export BREACH_INTEL_URL=http://localhost:8080")
        issues += 1

    if token:
        print(f"  BREACH_INTEL_TOKEN = {token[:16]}...")
    else:
        print("  BREACH_INTEL_TOKEN = (not set)")
        if url:
            print("    -> Auth may fail if the policy agent requires a key.")
            issues += 1

    # 2. Check persistent hook
    print("\n[Persistent Hook]")
    try:
        import site
        site_dir = site.getusersitepackages()
        sc_path = os.path.join(site_dir, "sitecustomize.py")
        if os.path.exists(sc_path):
            with open(sc_path) as f:
                content = f.read()
            if "breach-intel-start" in content:
                print(f"  Installed: {sc_path}")
            else:
                print("  sitecustomize.py exists but breach-intel hook NOT found")
                print("    -> Run: breach-intel install-hook")
                issues += 1
        else:
            print(f"  Not installed (no sitecustomize.py at {site_dir})")
            print("    -> Run: breach-intel install-hook")
            issues += 1
    except Exception as e:
        print(f"  Could not check: {e}")
        issues += 1

    # 3. Check frameworks
    print("\n[Detected Frameworks]")
    frameworks = []
    try:
        import openai  # type: ignore  # noqa: F401
        frameworks.append("OpenAI")
        print("  OpenAI       installed (will be auto-patched)")
    except ImportError:
        print("  OpenAI       not installed")

    try:
        import anthropic  # type: ignore  # noqa: F401
        frameworks.append("Anthropic")
        print("  Anthropic    installed (will be auto-patched)")
    except ImportError:
        print("  Anthropic    not installed")

    try:
        import langchain_core  # type: ignore  # noqa: F401
        frameworks.append("LangChain")
        print("  LangChain    installed (will be auto-patched)")
    except ImportError:
        print("  LangChain    not installed")

    if not frameworks:
        print("    -> No supported LLM frameworks found.")
        print("    -> Install one: pip install openai / anthropic / langchain")
        issues += 1

    # 4. Check policy agent
    print("\n[Policy Agent]")
    check_url = url or "http://localhost:8080"
    try:
        req = urllib.request.Request(f"{check_url}/health", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            print(f"  Reachable at {check_url}")
            print(f"  Status:   {data.get('status', 'unknown')}")
            print(f"  Auth:     {'enabled' if data.get('auth_enabled') else 'disabled'}")
            print(f"  Vertical: {data.get('vertical', 'unknown')}")
    except Exception:
        print(f"  NOT reachable at {check_url}")
        print("    -> Start the server: docker compose up -d")
        issues += 1

    # 5. Check credentials dir
    print("\n[Credentials]")
    creds_dir = os.path.expanduser("~/.breach-intel")
    for fname in ("admin_token", "agent_token", "agent_id"):
        fpath = os.path.join(creds_dir, fname)
        if os.path.exists(fpath):
            with open(fpath) as f:
                val = f.read().strip()
            display = val[:16] + "..." if len(val) > 16 else val
            print(f"  {fname:14s} {display}")
        else:
            print(f"  {fname:14s} (missing)")
            if fname == "agent_token":
                issues += 1

    # Summary
    print("\n" + "=" * 50)
    if issues == 0:
        print("All checks passed. Breach monitoring is fully active.")
    else:
        print(f"{issues} issue(s) found. Fix them above for full monitoring.")
    print()


if __name__ == "__main__":
    main()
