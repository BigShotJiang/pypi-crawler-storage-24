"""Persistent task state for directors — checkpoints, variables, and execution history.

Each director execution can store:
- Checkpoints: snapshots of intermediate state for resume-after-failure
- Variables: key-value store per director (persistent across runs)
- Execution history: log of all runs with inputs/outputs/costs
"""

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path

logger = logging.getLogger(__name__)

from .storage import _get_db, _ensure_dir


def _ensure_state_tables(conn: sqlite3.Connection) -> None:
    """Create state-related tables if they don't exist."""

    # Director variables — persistent key-value store per director
    conn.execute("""
        CREATE TABLE IF NOT EXISTS director_variables (
            id              TEXT PRIMARY KEY,
            director_id     TEXT NOT NULL,
            key             TEXT NOT NULL,
            value           TEXT NOT NULL DEFAULT '',
            value_type      TEXT NOT NULL DEFAULT 'string',
            created_at      REAL NOT NULL,
            updated_at      REAL NOT NULL,
            user_id         TEXT NOT NULL DEFAULT 'default',
            UNIQUE(director_id, key, user_id)
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_dvars_director
        ON director_variables(director_id, user_id)
    """)

    # Director checkpoints — snapshots for resume
    conn.execute("""
        CREATE TABLE IF NOT EXISTS director_checkpoints (
            id              TEXT PRIMARY KEY,
            director_id     TEXT NOT NULL,
            execution_id    TEXT NOT NULL,
            step_name       TEXT NOT NULL DEFAULT '',
            state_data      TEXT NOT NULL DEFAULT '{}',
            created_at      REAL NOT NULL,
            user_id         TEXT NOT NULL DEFAULT 'default'
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_dcheckpoints_exec
        ON director_checkpoints(director_id, execution_id)
    """)

    # Director execution history — log of all runs
    conn.execute("""
        CREATE TABLE IF NOT EXISTS director_executions (
            id              TEXT PRIMARY KEY,
            director_id     TEXT NOT NULL,
            trigger         TEXT NOT NULL DEFAULT 'schedule',
            status          TEXT NOT NULL DEFAULT 'running',
            input_data      TEXT NOT NULL DEFAULT '{}',
            output_summary  TEXT DEFAULT '',
            error_message   TEXT,
            cost_usd        REAL NOT NULL DEFAULT 0.0,
            tokens_used     INTEGER NOT NULL DEFAULT 0,
            duration_seconds REAL NOT NULL DEFAULT 0.0,
            started_at      REAL NOT NULL,
            completed_at    REAL,
            task_id         TEXT,
            trigger_id      TEXT,
            user_id         TEXT NOT NULL DEFAULT 'default',
            project_id      TEXT NOT NULL DEFAULT 'default'
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_dexec_director
        ON director_executions(director_id, user_id)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_dexec_time
        ON director_executions(started_at)
    """)

    conn.commit()


def _get_state_db() -> sqlite3.Connection:
    conn = _get_db()
    _ensure_state_tables(conn)
    return conn


# ---------------------------------------------------------------------------
# Variables — persistent key-value store per director
# ---------------------------------------------------------------------------

def set_variable(
    director_id: str,
    key: str,
    value: str,
    value_type: str = "string",
    user_id: str = "default",
) -> dict:
    """Set a variable for a director. Creates or updates."""
    now = time.time()
    var_id = str(uuid.uuid4())[:8]
    conn = _get_state_db()
    try:
        # Upsert
        conn.execute("""
            INSERT INTO director_variables (id, director_id, key, value, value_type, created_at, updated_at, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(director_id, key, user_id)
            DO UPDATE SET value = excluded.value, value_type = excluded.value_type, updated_at = excluded.updated_at
        """, (var_id, director_id, key, value, value_type, now, now, user_id))
        conn.commit()
        row = conn.execute(
            "SELECT * FROM director_variables WHERE director_id = ? AND key = ? AND user_id = ?",
            (director_id, key, user_id),
        ).fetchone()
        return dict(row) if row else {"director_id": director_id, "key": key, "value": value}
    finally:
        conn.close()


def get_variable(director_id: str, key: str, user_id: str = "default") -> str | None:
    """Get a variable value. Returns None if not found."""
    conn = _get_state_db()
    try:
        row = conn.execute(
            "SELECT value FROM director_variables WHERE director_id = ? AND key = ? AND user_id = ?",
            (director_id, key, user_id),
        ).fetchone()
        return row["value"] if row else None
    finally:
        conn.close()


def list_variables(director_id: str, user_id: str = "default") -> list[dict]:
    """List all variables for a director."""
    conn = _get_state_db()
    try:
        rows = conn.execute(
            "SELECT * FROM director_variables WHERE director_id = ? AND user_id = ? ORDER BY key",
            (director_id, user_id),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_variable(director_id: str, key: str, user_id: str = "default") -> bool:
    """Delete a variable."""
    conn = _get_state_db()
    try:
        cur = conn.execute(
            "DELETE FROM director_variables WHERE director_id = ? AND key = ? AND user_id = ?",
            (director_id, key, user_id),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def clear_variables(director_id: str, user_id: str = "default") -> int:
    """Clear all variables for a director. Returns count deleted."""
    conn = _get_state_db()
    try:
        cur = conn.execute(
            "DELETE FROM director_variables WHERE director_id = ? AND user_id = ?",
            (director_id, user_id),
        )
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Checkpoints — state snapshots for resume
# ---------------------------------------------------------------------------

def save_checkpoint(
    director_id: str,
    execution_id: str,
    step_name: str,
    state_data: dict,
    user_id: str = "default",
) -> dict:
    """Save a checkpoint for a running execution."""
    now = time.time()
    cp_id = str(uuid.uuid4())[:8]
    conn = _get_state_db()
    try:
        conn.execute("""
            INSERT INTO director_checkpoints (id, director_id, execution_id, step_name, state_data, created_at, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (cp_id, director_id, execution_id, step_name, json.dumps(state_data, ensure_ascii=False), now, user_id))
        conn.commit()
        row = conn.execute("SELECT * FROM director_checkpoints WHERE id = ?", (cp_id,)).fetchone()
        d = dict(row)
        d["state_data"] = json.loads(d.get("state_data", "{}"))
        return d
    finally:
        conn.close()


def get_latest_checkpoint(
    director_id: str,
    execution_id: str | None = None,
    user_id: str = "default",
) -> dict | None:
    """Get the most recent checkpoint for a director (optionally for a specific execution)."""
    conn = _get_state_db()
    try:
        if execution_id:
            row = conn.execute(
                "SELECT * FROM director_checkpoints WHERE director_id = ? AND execution_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 1",
                (director_id, execution_id, user_id),
            ).fetchone()
        else:
            row = conn.execute(
                "SELECT * FROM director_checkpoints WHERE director_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 1",
                (director_id, user_id),
            ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["state_data"] = json.loads(d.get("state_data", "{}"))
        return d
    finally:
        conn.close()


def list_checkpoints(
    director_id: str,
    execution_id: str | None = None,
    user_id: str = "default",
    limit: int = 20,
) -> list[dict]:
    """List checkpoints for a director."""
    conn = _get_state_db()
    try:
        if execution_id:
            rows = conn.execute(
                "SELECT * FROM director_checkpoints WHERE director_id = ? AND execution_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?",
                (director_id, execution_id, user_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM director_checkpoints WHERE director_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?",
                (director_id, user_id, limit),
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["state_data"] = json.loads(d.get("state_data", "{}"))
            result.append(d)
        return result
    finally:
        conn.close()


def cleanup_old_checkpoints(director_id: str, keep_last: int = 10, user_id: str = "default") -> int:
    """Remove old checkpoints, keeping only the most recent N."""
    conn = _get_state_db()
    try:
        # Get IDs to keep
        rows = conn.execute(
            "SELECT id FROM director_checkpoints WHERE director_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?",
            (director_id, user_id, keep_last),
        ).fetchall()
        keep_ids = {r["id"] for r in rows}

        if not keep_ids:
            return 0

        placeholders = ",".join("?" for _ in keep_ids)
        cur = conn.execute(
            f"DELETE FROM director_checkpoints WHERE director_id = ? AND user_id = ? AND id NOT IN ({placeholders})",
            [director_id, user_id] + list(keep_ids),
        )
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Execution History — log of all runs
# ---------------------------------------------------------------------------

def start_execution(
    director_id: str,
    trigger: str = "schedule",
    input_data: dict | None = None,
    task_id: str | None = None,
    trigger_id: str | None = None,
    user_id: str = "default",
    project_id: str = "default",
) -> str:
    """Record the start of a director execution. Returns execution_id."""
    now = time.time()
    exec_id = str(uuid.uuid4())[:8]
    conn = _get_state_db()
    try:
        conn.execute("""
            INSERT INTO director_executions
            (id, director_id, trigger, status, input_data, started_at, task_id, trigger_id, user_id, project_id)
            VALUES (?, ?, ?, 'running', ?, ?, ?, ?, ?, ?)
        """, (exec_id, director_id, trigger, json.dumps(input_data or {}, ensure_ascii=False),
              now, task_id, trigger_id, user_id, project_id))
        conn.commit()
        return exec_id
    finally:
        conn.close()


def complete_execution(
    execution_id: str,
    output_summary: str = "",
    cost_usd: float = 0.0,
    tokens_used: int = 0,
    error_message: str | None = None,
) -> dict | None:
    """Record the completion of a director execution."""
    now = time.time()
    conn = _get_state_db()
    try:
        # Get start time for duration calc
        row = conn.execute("SELECT started_at FROM director_executions WHERE id = ?", (execution_id,)).fetchone()
        if not row:
            return None
        duration = now - row["started_at"]

        status = "failed" if error_message else "completed"
        conn.execute("""
            UPDATE director_executions
            SET status = ?, output_summary = ?, error_message = ?,
                cost_usd = ?, tokens_used = ?, duration_seconds = ?, completed_at = ?
            WHERE id = ?
        """, (status, output_summary[:500], error_message, cost_usd, tokens_used, duration, now, execution_id))
        conn.commit()

        row = conn.execute("SELECT * FROM director_executions WHERE id = ?", (execution_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["input_data"] = json.loads(d.get("input_data", "{}"))
        return d
    finally:
        conn.close()


def get_execution_history(
    director_id: str,
    user_id: str = "default",
    limit: int = 20,
    status: str | None = None,
) -> list[dict]:
    """Get execution history for a director."""
    conn = _get_state_db()
    try:
        conditions = ["director_id = ?", "user_id = ?"]
        params: list = [director_id, user_id]
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " AND ".join(conditions)
        params.append(limit)
        rows = conn.execute(
            f"SELECT * FROM director_executions WHERE {where} ORDER BY started_at DESC LIMIT ?",
            params,
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["input_data"] = json.loads(d.get("input_data", "{}"))
            result.append(d)
        return result
    finally:
        conn.close()


def get_execution_stats(
    director_id: str | None = None,
    user_id: str = "default",
    days: int = 30,
) -> dict:
    """Get execution statistics."""
    conn = _get_state_db()
    try:
        cutoff = time.time() - (days * 86400)
        conditions = ["user_id = ?", "started_at >= ?"]
        params: list = [user_id, cutoff]
        if director_id:
            conditions.append("director_id = ?")
            params.append(director_id)

        where = " AND ".join(conditions)

        # Count by status
        rows = conn.execute(
            f"SELECT status, COUNT(*) as count FROM director_executions WHERE {where} GROUP BY status",
            params,
        ).fetchall()
        by_status = {r["status"]: r["count"] for r in rows}

        # Total cost
        row = conn.execute(
            f"SELECT SUM(cost_usd) as total_cost, SUM(tokens_used) as total_tokens, AVG(duration_seconds) as avg_duration FROM director_executions WHERE {where}",
            params,
        ).fetchone()

        return {
            "by_status": by_status,
            "total_runs": sum(by_status.values()),
            "total_cost_usd": row["total_cost"] or 0.0,
            "total_tokens": row["total_tokens"] or 0,
            "avg_duration_seconds": row["avg_duration"] or 0.0,
            "period_days": days,
        }
    finally:
        conn.close()


def cleanup_old_executions(days: int = 90) -> int:
    """Remove execution records older than N days."""
    cutoff = time.time() - (days * 86400)
    conn = _get_state_db()
    try:
        cur = conn.execute("DELETE FROM director_executions WHERE started_at < ?", (cutoff,))
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()
