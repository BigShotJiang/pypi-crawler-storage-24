"""Runtime governance routes: tracing, audit, policies, sandbox.

Phase 1 of Agent OS roadmap — exposes runtime state via REST API.
"""

import time

from fastapi import APIRouter, Request, Query
from fastapi.responses import JSONResponse, PlainTextResponse

from shared_state import verify_token, get_token

runtime_router = APIRouter(tags=["runtime"])


# ---------------------------------------------------------------------------
# Singleton references — set from server.py at startup
# ---------------------------------------------------------------------------

_tracing_storage = None
_audit_storage = None
_audit_logger = None
_policy_engine = None
_sandbox_manager = None


def init_runtime(tracing_storage=None, audit_storage=None, audit_logger=None,
                 policy_engine=None, sandbox_manager=None):
    """Called from server.py to wire up runtime singletons."""
    global _tracing_storage, _audit_storage, _audit_logger, _policy_engine, _sandbox_manager
    _tracing_storage = tracing_storage
    _audit_storage = audit_storage
    _audit_logger = audit_logger
    _policy_engine = policy_engine
    _sandbox_manager = sandbox_manager


# ---------------------------------------------------------------------------
# Auth helper
# ---------------------------------------------------------------------------

def _check_auth(request: Request) -> bool:
    token = get_token(request)
    return verify_token(token)


# ---------------------------------------------------------------------------
# Tracing endpoints
# ---------------------------------------------------------------------------

@runtime_router.get("/api/traces")
async def get_recent_traces(request: Request, limit: int = Query(50, le=200)):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _tracing_storage:
        return JSONResponse({"traces": [], "message": "Tracing not initialized"})
    traces = _tracing_storage.get_recent_traces(limit=limit)
    return JSONResponse({"traces": traces})


@runtime_router.get("/api/traces/{trace_id}")
async def get_trace_detail(request: Request, trace_id: str):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _tracing_storage:
        return JSONResponse({"spans": []})
    spans = _tracing_storage.get_spans_by_trace(trace_id)
    return JSONResponse({"trace_id": trace_id, "spans": spans})


@runtime_router.get("/api/traces/costs/summary")
async def get_cost_summary(request: Request, days: int = Query(30, le=365)):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _tracing_storage:
        return JSONResponse({"total_cost_usd": 0, "span_count": 0})
    summary = _tracing_storage.get_cost_summary(days=days)
    return JSONResponse(summary)


@runtime_router.get("/api/traces/export")
async def export_traces(request: Request, trace_id: str = None,
                        format: str = Query("json", regex="^(json|csv)$")):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _tracing_storage:
        return PlainTextResponse("[]")
    content = _tracing_storage.export_spans(trace_id=trace_id, format=format)
    media = "text/csv" if format == "csv" else "application/json"
    return PlainTextResponse(content, media_type=media)


# ---------------------------------------------------------------------------
# Audit endpoints
# ---------------------------------------------------------------------------

@runtime_router.get("/api/audit")
async def get_audit_events(request: Request,
                           limit: int = Query(100, le=500),
                           event_type: str = None,
                           since_hours: float = None):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _audit_storage:
        return JSONResponse({"events": [], "message": "Audit not initialized"})
    since = time.time() - (since_hours * 3600) if since_hours else None
    events = _audit_storage.get_events(limit=limit, event_type=event_type, since=since)
    return JSONResponse({"events": events})


@runtime_router.get("/api/audit/stats")
async def get_audit_stats(request: Request, days: int = Query(30, le=365)):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _audit_storage:
        return JSONResponse({"total_events": 0, "by_type": {}})
    stats = _audit_storage.get_stats(days=days)
    return JSONResponse(stats)


@runtime_router.get("/api/audit/verify")
async def verify_audit_chain(request: Request, limit: int = Query(100, le=1000)):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _audit_storage:
        return JSONResponse({"valid": True, "checked": 0, "errors": []})
    result = _audit_storage.verify_chain(limit=limit)
    return JSONResponse(result)


@runtime_router.get("/api/audit/export")
async def export_audit(request: Request,
                       format: str = Query("json", regex="^(json|csv)$"),
                       limit: int = Query(1000, le=5000)):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _audit_storage:
        return PlainTextResponse("[]")
    content = _audit_storage.export_events(format=format, limit=limit)
    media = "text/csv" if format == "csv" else "application/json"
    return PlainTextResponse(content, media_type=media)


# ---------------------------------------------------------------------------
# Policy endpoints
# ---------------------------------------------------------------------------

@runtime_router.get("/api/policies")
async def get_policies(request: Request):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _policy_engine:
        return JSONResponse({"enabled": False, "rules": []})
    status = _policy_engine.get_status()
    return JSONResponse(status)


@runtime_router.post("/api/policies/reload")
async def reload_policies(request: Request):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _policy_engine:
        return JSONResponse({"loaded": 0, "message": "Policy engine not initialized"})
    count = _policy_engine.load_policies()
    if _audit_logger:
        _audit_logger.log_config_changed("policies_reloaded")
    return JSONResponse({"loaded": count})


# ---------------------------------------------------------------------------
# Sandbox endpoints
# ---------------------------------------------------------------------------

@runtime_router.get("/api/sandbox")
async def get_sandbox_info(request: Request):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _sandbox_manager:
        return JSONResponse({"mode": "none", "message": "Sandbox not initialized"})
    return JSONResponse(_sandbox_manager.get_info())


@runtime_router.get("/api/sandbox/snapshots")
async def list_snapshots(request: Request):
    if not _check_auth(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    if not _sandbox_manager:
        return JSONResponse({"snapshots": []})
    return JSONResponse({"snapshots": _sandbox_manager.list_snapshots()})
