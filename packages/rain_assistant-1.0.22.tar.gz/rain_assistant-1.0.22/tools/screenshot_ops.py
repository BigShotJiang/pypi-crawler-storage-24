"""take_screenshot tool — capture a monitor screenshot without Computer Use API.

Returns the screenshot as a base64 PNG string via the ``_screenshot`` key.
The server layer detects this key and emits a ``computer_screenshot`` WS
message so the frontend displays it inline in the chat.
"""

import asyncio
import base64
import io
import logging

logger = logging.getLogger("rain.screenshot")

# Anthropic-like constraints (reasonable max for chat display)
MAX_LONG_EDGE = 1920
MAX_TOTAL_PIXELS = 2_100_000


def _scale_factor(width: int, height: int) -> float:
    """Calculate downscale factor to stay within size limits."""
    factor = 1.0
    long_edge = max(width, height)
    if long_edge > MAX_LONG_EDGE:
        factor = min(factor, MAX_LONG_EDGE / long_edge)
    total = width * height
    if total > MAX_TOTAL_PIXELS:
        import math
        factor = min(factor, math.sqrt(MAX_TOTAL_PIXELS / total))
    return factor


async def take_screenshot(args: dict, cwd: str) -> dict:
    """Capture a screenshot of the specified monitor.

    Returns a dict with:
      - content: text description for the LLM
      - is_error: False on success
      - _screenshot: base64 PNG data (consumed by server.py → WS)
      - _monitor_info: dict with width, height, monitor_index
    """
    monitor_index = args.get("monitor", 1)
    if not isinstance(monitor_index, int) or monitor_index < 0:
        monitor_index = 1

    def _capture():
        try:
            import mss
            from PIL import Image
        except ImportError as e:
            return None, f"Missing dependency: {e}. Install with: pip install mss Pillow"

        with mss.mss() as sct:
            monitors = sct.monitors
            if monitor_index >= len(monitors):
                avail = len(monitors) - 1
                return None, (
                    f"Monitor {monitor_index} not found. "
                    f"Available monitors: 0 (all) to {avail}."
                )

            monitor = monitors[monitor_index]
            raw = sct.grab(monitor)
            img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")

            # Downscale if too large
            w, h = img.size
            factor = _scale_factor(w, h)
            if factor < 1.0:
                new_w = int(w * factor)
                new_h = int(h * factor)
                img = img.resize((new_w, new_h), Image.LANCZOS)

            buf = io.BytesIO()
            img.save(buf, format="PNG", optimize=True)
            b64 = base64.standard_b64encode(buf.getvalue()).decode("utf-8")

            return {
                "b64": b64,
                "width": img.size[0],
                "height": img.size[1],
                "orig_width": w,
                "orig_height": h,
                "monitor_index": monitor_index,
                "monitor_left": monitor["left"],
                "monitor_top": monitor["top"],
            }, None

    try:
        result, error = await asyncio.to_thread(_capture)
    except Exception as e:
        logger.error("Screenshot capture failed: %s", e)
        return {"content": f"Screenshot failed: {e}", "is_error": True}

    if error:
        return {"content": error, "is_error": True}

    info = result
    description = (
        f"Screenshot captured from monitor {info['monitor_index']} "
        f"({info['orig_width']}x{info['orig_height']}"
    )
    if info["width"] != info["orig_width"]:
        description += f", scaled to {info['width']}x{info['height']}"
    description += ")"

    return {
        "content": description,
        "is_error": False,
        "_screenshot": info["b64"],
        "_monitor_info": {
            "width": info["width"],
            "height": info["height"],
            "monitor_index": info["monitor_index"],
        },
    }


TAKE_SCREENSHOT_DEFINITION = {
    "type": "function",
    "function": {
        "name": "take_screenshot",
        "description": (
            "Take a screenshot of a monitor and show it to the user in the chat. "
            "Use this when the user asks to see their screen, a specific window, "
            "or wants visual confirmation of something on their desktop. "
            "This is a lightweight capture — no Computer Use mode required."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "monitor": {
                    "type": "integer",
                    "description": (
                        "Monitor index to capture. "
                        "0 = all monitors combined, 1 = primary (default), "
                        "2 = secondary, etc."
                    ),
                },
            },
            "required": [],
        },
    },
}
