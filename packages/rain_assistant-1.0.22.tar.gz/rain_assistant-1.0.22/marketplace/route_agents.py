"""FastAPI routes for the Agent Marketplace."""

import logging

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

from .agents import AgentMarketplace

logger = logging.getLogger("rain.marketplace")

agent_marketplace_router = APIRouter(
    prefix="/api/marketplace/agents", tags=["agent-marketplace"]
)

# Singleton marketplace instance
_marketplace: AgentMarketplace | None = None


def _get_marketplace() -> AgentMarketplace:
    global _marketplace
    if _marketplace is None:
        _marketplace = AgentMarketplace()
    return _marketplace


# ---------------------------------------------------------------------------
# Browse / Search
# ---------------------------------------------------------------------------


@agent_marketplace_router.get("/")
async def route_list_agents(
    query: str = Query("", description="Search query"),
    category: str = Query("", description="Filter by category"),
    min_rating: float = Query(0.0, ge=0.0, le=5.0, description="Minimum rating"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Results per page"),
) -> JSONResponse:
    """List or search agent templates."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    result = mp.search_agents(
        query=query,
        category=category,
        min_rating=min_rating,
        page=page,
        per_page=per_page,
    )
    return JSONResponse(result)


@agent_marketplace_router.get("/installed")
async def route_installed_agents() -> JSONResponse:
    """List all installed agents."""
    mp = _get_marketplace()
    installed = mp.list_installed_agents()
    return JSONResponse({"agents": installed, "total": len(installed)})


@agent_marketplace_router.get("/updates")
async def route_check_updates() -> JSONResponse:
    """Check for available agent updates."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    updates = mp.check_agent_updates()
    return JSONResponse({"updates": updates, "total": len(updates)})


@agent_marketplace_router.get("/{name}")
async def route_agent_details(name: str) -> JSONResponse:
    """Get detailed info for a single agent template."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    info = mp.get_agent_info(name)
    if not info:
        return JSONResponse({"error": f"Agent '{name}' not found."}, status_code=404)

    result = info.__dict__.copy()
    result["installed"] = mp.is_agent_installed(name)
    result["installed_version"] = mp.get_installed_version(name)
    return JSONResponse(result)


@agent_marketplace_router.get("/{name}/reviews")
async def route_agent_reviews(
    name: str,
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
) -> JSONResponse:
    """Get reviews for an agent."""
    mp = _get_marketplace()
    result = mp.get_agent_reviews(name, page=page, per_page=per_page)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Install / Uninstall / Update
# ---------------------------------------------------------------------------


@agent_marketplace_router.post("/{name}/install")
async def route_install_agent(name: str) -> JSONResponse:
    """Install an agent template."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    result = await mp.install_agent(name)
    if result.get("error"):
        status = 404 if "not found" in result["error"] else 400
        return JSONResponse(result, status_code=status)
    return JSONResponse(result, status_code=201)


@agent_marketplace_router.post("/{name}/uninstall")
async def route_uninstall_agent(name: str) -> JSONResponse:
    """Uninstall an installed agent."""
    mp = _get_marketplace()
    result = await mp.uninstall_agent(name)
    if result.get("error"):
        status = 404 if "not installed" in result["error"] else 400
        return JSONResponse(result, status_code=status)
    return JSONResponse(result)


@agent_marketplace_router.post("/{name}/update")
async def route_update_agent(name: str) -> JSONResponse:
    """Update an installed agent to the latest version."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    result = await mp.update_agent(name)
    if result.get("error"):
        return JSONResponse(result, status_code=400)
    return JSONResponse(result)


# ---------------------------------------------------------------------------
# Reviews
# ---------------------------------------------------------------------------


@agent_marketplace_router.post("/{name}/review")
async def route_add_review(name: str, request: dict) -> JSONResponse:
    """Add a review for an agent."""
    rating = request.get("rating")
    title = request.get("title", "")
    body = request.get("body", "")

    if rating is None:
        return JSONResponse(
            {"error": "Rating is required."}, status_code=400
        )

    mp = _get_marketplace()
    result = mp.add_review(
        agent_name=name,
        rating=int(rating),
        title=title,
        body=body,
    )
    if result.get("error"):
        return JSONResponse(result, status_code=400)
    return JSONResponse(result, status_code=201)


# ---------------------------------------------------------------------------
# Publishing
# ---------------------------------------------------------------------------


@agent_marketplace_router.post("/publish")
async def route_publish_agent(request: dict) -> JSONResponse:
    """Publish an agent template (prepares submission)."""
    mp = _get_marketplace()

    # Validate first
    errors = mp.validate_agent_template(request)
    if errors:
        return JSONResponse(
            {"error": "Validation failed.", "validation_errors": errors},
            status_code=400,
        )

    result = await mp.publish_agent(request)
    if result.get("error"):
        return JSONResponse(result, status_code=400)
    return JSONResponse(result, status_code=201)


# ---------------------------------------------------------------------------
# Security
# ---------------------------------------------------------------------------


@agent_marketplace_router.post("/{name}/security-scan")
async def route_security_scan(name: str) -> JSONResponse:
    """Run a security scan on an agent template."""
    mp = _get_marketplace()
    await mp.refresh_agent_index()
    result = await mp.security_scan(name)
    if result.get("error"):
        return JSONResponse(result, status_code=404)
    return JSONResponse(result)
