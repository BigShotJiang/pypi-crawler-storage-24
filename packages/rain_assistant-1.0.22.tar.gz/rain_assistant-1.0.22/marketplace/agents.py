"""Agent Marketplace — browse, install, review, and publish agent templates.

Agent templates bundle director configs and optional team templates into
installable packages. They extend the skill marketplace (registry.py) to
support multi-director autonomous agent setups.
"""

import hashlib
import json
import logging
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("rain.marketplace")

CONFIG_DIR = Path.home() / ".rain-assistant"
MARKETPLACE_DIR = CONFIG_DIR / "marketplace"
MARKETPLACE_DB = MARKETPLACE_DIR / "marketplace.db"
AGENT_INDEX_CACHE = MARKETPLACE_DIR / "agent_index_cache.json"
AGENT_INDEX_CACHE_TTL = 3600  # 1 hour

DEFAULT_AGENT_REGISTRY_URL = (
    "https://raw.githubusercontent.com/camilo-gutierrez/rain-agents-registry/main"
)

# Valid agent categories
AGENT_CATEGORIES = [
    "productivity",
    "development",
    "marketing",
    "finance",
    "operations",
    "creative",
]


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class AgentTemplate:
    name: str
    display_name: str
    description: str
    description_es: str
    version: str
    author: str
    category: str  # productivity, development, marketing, finance, operations, creative
    tags: list[str]
    rating: float  # 0.0 - 5.0
    review_count: int
    downloads: int
    verified: bool
    license: str
    price: str  # "free", "$4.99/mo", etc.
    revenue_share_percent: float  # creator's cut
    # Agent-specific
    director_configs: list[dict]  # list of director YAML configs
    team_template: dict | None  # optional team template config
    required_tools: list[str]  # tools the agent needs
    required_env: list[str]  # env vars needed
    min_rain_version: str
    checksum_sha256: str
    homepage: str
    updated_at: str


@dataclass
class AgentReview:
    id: str
    agent_name: str
    reviewer: str  # anonymous hash
    rating: int  # 1-5
    title: str
    body: str
    created_at: float
    helpful_count: int


def _template_from_dict(d: dict) -> AgentTemplate:
    """Create an AgentTemplate from an index entry dict."""
    return AgentTemplate(
        name=d.get("name", ""),
        display_name=d.get("display_name", d.get("name", "")),
        description=d.get("description", ""),
        description_es=d.get("description_es", ""),
        version=d.get("version", "0.0.0"),
        author=d.get("author", "unknown"),
        category=d.get("category", "productivity"),
        tags=d.get("tags", []),
        rating=float(d.get("rating", 0.0)),
        review_count=int(d.get("review_count", 0)),
        downloads=int(d.get("downloads", 0)),
        verified=bool(d.get("verified", False)),
        license=d.get("license", ""),
        price=d.get("price", "free"),
        revenue_share_percent=float(d.get("revenue_share_percent", 70.0)),
        director_configs=d.get("director_configs", []),
        team_template=d.get("team_template"),
        required_tools=d.get("required_tools", []),
        required_env=d.get("required_env", []),
        min_rain_version=d.get("min_rain_version", "1.0.0"),
        checksum_sha256=d.get("checksum_sha256", ""),
        homepage=d.get("homepage", ""),
        updated_at=d.get("updated_at", ""),
    )


def _review_from_row(row: sqlite3.Row) -> AgentReview:
    """Create an AgentReview from a database row."""
    return AgentReview(
        id=row["id"],
        agent_name=row["agent_name"],
        reviewer=row["reviewer"],
        rating=row["rating"],
        title=row["title"],
        body=row["body"],
        created_at=row["created_at"],
        helpful_count=row["helpful_count"],
    )


# ---------------------------------------------------------------------------
# Agent Marketplace
# ---------------------------------------------------------------------------


class AgentMarketplace:
    """Manages agent templates: browse, install, review, publish."""

    def __init__(self, registry_url: str = DEFAULT_AGENT_REGISTRY_URL):
        self.registry_url = registry_url
        self._index: dict | None = None
        self._ensure_dirs()
        self._ensure_db()

    # ── Setup ────────────────────────────────────────────────────────

    def _ensure_dirs(self) -> None:
        MARKETPLACE_DIR.mkdir(parents=True, exist_ok=True)

    def _ensure_db(self) -> None:
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS installed_agents (
                    name          TEXT PRIMARY KEY,
                    version       TEXT NOT NULL,
                    display_name  TEXT NOT NULL DEFAULT '',
                    author        TEXT NOT NULL DEFAULT 'unknown',
                    category      TEXT NOT NULL DEFAULT 'productivity',
                    director_ids  TEXT NOT NULL DEFAULT '[]',
                    team_id       TEXT,
                    installed_at  REAL NOT NULL,
                    updated_at    REAL NOT NULL,
                    registry_url  TEXT NOT NULL,
                    checksum      TEXT NOT NULL DEFAULT ''
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS agent_reviews (
                    id             TEXT PRIMARY KEY,
                    agent_name     TEXT NOT NULL,
                    reviewer       TEXT NOT NULL,
                    rating         INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                    title          TEXT NOT NULL DEFAULT '',
                    body           TEXT NOT NULL DEFAULT '',
                    created_at     REAL NOT NULL,
                    helpful_count  INTEGER NOT NULL DEFAULT 0
                )
                """
            )
            # Index for faster lookups
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_reviews_agent ON agent_reviews(agent_name)"
            )
            conn.commit()

    # ── Index cache ──────────────────────────────────────────────────

    async def refresh_agent_index(self, force: bool = False) -> dict:
        """Fetch agent index from the registry. Uses local cache if fresh."""
        if not force and AGENT_INDEX_CACHE.exists():
            try:
                mtime = AGENT_INDEX_CACHE.stat().st_mtime
                if time.time() - mtime < AGENT_INDEX_CACHE_TTL:
                    cached = json.loads(
                        AGENT_INDEX_CACHE.read_text(encoding="utf-8")
                    )
                    self._index = cached
                    return cached
            except Exception:
                pass

        # Fetch from remote
        try:
            import httpx

            url = f"{self.registry_url}/agents_index.json"
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json()
        except ImportError:
            logger.warning("httpx not installed — using cached agent index if available")
            return self._get_cached_index() or {"agents": []}
        except Exception as e:
            logger.warning("Failed to fetch agent index: %s", e)
            return self._get_cached_index() or {"agents": []}

        # Save to cache
        try:
            AGENT_INDEX_CACHE.write_text(
                json.dumps(data, ensure_ascii=False), encoding="utf-8"
            )
        except Exception:
            pass

        self._index = data
        return data

    def _get_cached_index(self) -> dict | None:
        if AGENT_INDEX_CACHE.exists():
            try:
                data = json.loads(AGENT_INDEX_CACHE.read_text(encoding="utf-8"))
                self._index = data
                return data
            except Exception:
                pass
        return None

    def _get_index(self) -> dict:
        """Get the current index (cached in memory or from file)."""
        if self._index:
            return self._index
        cached = self._get_cached_index()
        return cached or {"agents": []}

    def set_index(self, index: dict) -> None:
        """Set the agent index directly (useful for testing)."""
        self._index = index

    # ── Browse / Search ──────────────────────────────────────────────

    def search_agents(
        self,
        query: str = "",
        category: str = "",
        min_rating: float = 0.0,
        page: int = 1,
        per_page: int = 20,
    ) -> dict:
        """Search agents in the cached index."""
        index = self._get_index()
        agents = index.get("agents", [])

        results = []
        q = query.lower()
        for a in agents:
            if category and a.get("category", "") != category:
                continue
            if min_rating > 0 and float(a.get("rating", 0)) < min_rating:
                continue
            if q:
                searchable = (
                    f"{a.get('name', '')} {a.get('description', '')} "
                    f"{a.get('display_name', '')} {' '.join(a.get('tags', []))}"
                ).lower()
                if q not in searchable:
                    continue
            results.append(a)

        # Sort: verified first, then by downloads
        results.sort(
            key=lambda a: (
                -int(a.get("verified", False)),
                -float(a.get("rating", 0)),
                -int(a.get("downloads", 0)),
            )
        )

        total = len(results)
        start = (page - 1) * per_page
        page_results = results[start : start + per_page]

        return {
            "agents": [_template_from_dict(a).__dict__ for a in page_results],
            "total": total,
            "page": page,
            "per_page": per_page,
        }

    def get_agent_info(self, name: str) -> AgentTemplate | None:
        """Get detailed info for a single agent template."""
        index = self._get_index()
        for a in index.get("agents", []):
            if a.get("name") == name:
                return _template_from_dict(a)
        return None

    def get_agent_reviews(self, name: str, page: int = 1, per_page: int = 20) -> dict:
        """Get reviews for an agent from local storage."""
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.row_factory = sqlite3.Row

            total_row = conn.execute(
                "SELECT COUNT(*) as cnt FROM agent_reviews WHERE agent_name = ?",
                (name,),
            ).fetchone()
            total = total_row["cnt"] if total_row else 0

            offset = (page - 1) * per_page
            rows = conn.execute(
                """SELECT * FROM agent_reviews
                   WHERE agent_name = ?
                   ORDER BY created_at DESC
                   LIMIT ? OFFSET ?""",
                (name, per_page, offset),
            ).fetchall()

        reviews = [_review_from_row(r).__dict__ for r in rows]

        # Calculate average rating
        avg_rating = 0.0
        if reviews:
            avg_rating = sum(r["rating"] for r in reviews) / len(reviews)

        return {
            "reviews": reviews,
            "total": total,
            "page": page,
            "per_page": per_page,
            "average_rating": round(avg_rating, 2),
        }

    # ── Install / Uninstall ──────────────────────────────────────────

    async def install_agent(self, name: str, user_id: str = "default") -> dict:
        """Download and install an agent template from the registry.

        Creates directors (and optionally a team template) from the agent config.
        """
        info = self.get_agent_info(name)
        if not info:
            return {"error": f"Agent '{name}' not found in registry."}

        if self.is_agent_installed(name):
            return {"error": f"Agent '{name}' is already installed. Uninstall first or use update."}

        # Download agent bundle
        try:
            import httpx

            url = f"{self.registry_url}/agents/{name}/agent.json"
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                bundle = resp.json()
        except ImportError:
            return {"error": "httpx not installed. Run: pip install httpx"}
        except Exception as e:
            return {"error": f"Failed to download agent bundle: {e}"}

        # Verify checksum
        if info.checksum_sha256:
            bundle_text = json.dumps(bundle, sort_keys=True, ensure_ascii=False)
            actual_hash = hashlib.sha256(bundle_text.encode("utf-8")).hexdigest()
            if actual_hash != info.checksum_sha256:
                return {
                    "error": f"Checksum mismatch for '{name}'. "
                    f"Expected {info.checksum_sha256[:16]}..., got {actual_hash[:16]}..."
                }

        # Run security scan before installing
        from .security_scanner import SecurityScanner

        scanner = SecurityScanner()
        scan_result = scanner.scan_agent_template(bundle)
        if not scan_result["passed"]:
            critical = [w for w in scan_result["warnings"] if w.get("severity") == "critical"]
            if critical:
                return {
                    "error": f"Security scan failed for '{name}': "
                    + "; ".join(w["message"] for w in critical),
                    "security_report": scan_result,
                }

        # Create directors from configs
        director_configs = bundle.get("director_configs", info.director_configs)
        created_ids = []
        errors = []

        from directors.storage import add_director

        for dc in director_configs:
            director_id = dc.get("id", f"{name}_{len(created_ids)}")
            result = add_director(
                id=director_id,
                name=dc.get("name", director_id),
                role_prompt=dc.get("role_prompt", ""),
                schedule=dc.get("schedule"),
                description=dc.get("description", ""),
                emoji=dc.get("emoji", "🤖"),
                tools_allowed=dc.get("tools_allowed"),
                plugins_allowed=dc.get("plugins_allowed"),
                permission_level=dc.get("permission_level", "green"),
                can_delegate=dc.get("can_delegate", False),
                user_id=user_id,
                template_id=f"agent:{name}",
            )
            if result:
                created_ids.append(director_id)
            else:
                errors.append(f"Failed to create director '{director_id}'")

        if not created_ids and director_configs:
            return {
                "error": f"Failed to create any directors for agent '{name}'.",
                "details": errors,
            }

        # Track installation
        now = time.time()
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO installed_agents
                    (name, version, display_name, author, category,
                     director_ids, team_id, installed_at, updated_at,
                     registry_url, checksum)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    info.version,
                    info.display_name,
                    info.author,
                    info.category,
                    json.dumps(created_ids),
                    bundle.get("team_template", {}).get("id") if bundle.get("team_template") else None,
                    now,
                    now,
                    self.registry_url,
                    info.checksum_sha256 or "",
                ),
            )
            conn.commit()

        result_dict: dict[str, Any] = {
            "installed": True,
            "name": name,
            "version": info.version,
            "directors_created": created_ids,
        }
        if errors:
            result_dict["warnings"] = errors
        if scan_result.get("warnings"):
            result_dict["security_warnings"] = [
                w["message"] for w in scan_result["warnings"]
            ]
        if info.required_env:
            result_dict["required_env"] = info.required_env
            result_dict["note"] = (
                f"This agent requires environment variables: {', '.join(info.required_env)}. "
                "Configure them before running the directors."
            )
        return result_dict

    async def uninstall_agent(self, name: str, user_id: str = "default") -> dict:
        """Remove an installed agent and its directors."""
        if not self.is_agent_installed(name):
            return {"error": f"Agent '{name}' is not installed."}

        # Get installed info to find director IDs
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM installed_agents WHERE name = ?", (name,)
            ).fetchone()

        if not row:
            return {"error": f"Agent '{name}' not found in installed agents table."}

        director_ids = json.loads(row["director_ids"])

        # Delete directors
        from directors.storage import delete_director

        deleted = []
        for did in director_ids:
            if delete_director(did, user_id=user_id):
                deleted.append(did)

        # Remove from tracking
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.execute("DELETE FROM installed_agents WHERE name = ?", (name,))
            conn.commit()

        return {
            "uninstalled": True,
            "name": name,
            "directors_removed": deleted,
        }

    def list_installed_agents(self) -> list[dict]:
        """List all agents installed via marketplace."""
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM installed_agents ORDER BY installed_at DESC"
            ).fetchall()

        return [
            {
                "name": r["name"],
                "version": r["version"],
                "display_name": r["display_name"],
                "author": r["author"],
                "category": r["category"],
                "director_ids": json.loads(r["director_ids"]),
                "team_id": r["team_id"],
                "installed_at": r["installed_at"],
                "updated_at": r["updated_at"],
            }
            for r in rows
        ]

    def is_agent_installed(self, name: str) -> bool:
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            row = conn.execute(
                "SELECT 1 FROM installed_agents WHERE name = ?", (name,)
            ).fetchone()
        return row is not None

    def get_installed_version(self, name: str) -> str | None:
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            row = conn.execute(
                "SELECT version FROM installed_agents WHERE name = ?", (name,)
            ).fetchone()
        return row[0] if row else None

    # ── Updates ──────────────────────────────────────────────────────

    def check_agent_updates(self) -> list[dict]:
        """Compare installed agent versions against the registry."""
        installed = self.list_installed_agents()
        updates = []
        for agent in installed:
            info = self.get_agent_info(agent["name"])
            if info and info.version != agent["version"]:
                updates.append(
                    {
                        "name": agent["name"],
                        "current_version": agent["version"],
                        "latest_version": info.version,
                        "display_name": info.display_name,
                    }
                )
        return updates

    async def update_agent(self, name: str, user_id: str = "default") -> dict:
        """Update an agent to the latest version (uninstall + reinstall)."""
        if not self.is_agent_installed(name):
            return {"error": f"Agent '{name}' is not installed."}

        # Uninstall old version
        uninstall_result = await self.uninstall_agent(name, user_id=user_id)
        if uninstall_result.get("error"):
            return {"error": f"Update failed during uninstall: {uninstall_result['error']}"}

        # Reinstall latest
        install_result = await self.install_agent(name, user_id=user_id)
        if install_result.get("error"):
            return {"error": f"Update failed during reinstall: {install_result['error']}"}

        install_result["updated"] = True
        return install_result

    # ── Reviews ──────────────────────────────────────────────────────

    def add_review(
        self,
        agent_name: str,
        rating: int,
        title: str,
        body: str,
        reviewer: str | None = None,
    ) -> dict:
        """Add a review for an agent.

        Args:
            agent_name: Agent to review.
            rating: 1-5 stars.
            title: Review title.
            body: Review body text.
            reviewer: Anonymous hash for the reviewer. Auto-generated if None.

        Returns:
            Dict with the created review or an error.
        """
        if not 1 <= rating <= 5:
            return {"error": "Rating must be between 1 and 5."}

        if not title.strip():
            return {"error": "Review title is required."}

        if not agent_name.strip():
            return {"error": "Agent name is required."}

        review_id = str(uuid.uuid4())[:12]
        if not reviewer:
            reviewer = hashlib.sha256(
                f"{agent_name}_{time.time()}_{review_id}".encode()
            ).hexdigest()[:16]

        now = time.time()

        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            conn.execute(
                """
                INSERT INTO agent_reviews (id, agent_name, reviewer, rating, title, body, created_at, helpful_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (review_id, agent_name, reviewer, rating, title.strip(), body.strip(), now),
            )
            conn.commit()

        return {
            "created": True,
            "review_id": review_id,
            "agent_name": agent_name,
            "rating": rating,
        }

    def mark_helpful(self, review_id: str) -> dict:
        """Increment the helpful count of a review."""
        with sqlite3.connect(str(MARKETPLACE_DB)) as conn:
            cur = conn.execute(
                "UPDATE agent_reviews SET helpful_count = helpful_count + 1 WHERE id = ?",
                (review_id,),
            )
            conn.commit()
            if cur.rowcount == 0:
                return {"error": f"Review '{review_id}' not found."}

            row = conn.execute(
                "SELECT helpful_count FROM agent_reviews WHERE id = ?",
                (review_id,),
            ).fetchone()

        return {
            "marked_helpful": True,
            "review_id": review_id,
            "helpful_count": row[0] if row else 0,
        }

    # ── Publishing ───────────────────────────────────────────────────

    async def publish_agent(self, agent_template: dict) -> dict:
        """Publish an agent template to the registry.

        In this version, publishing prepares the submission data and returns
        a URL for manual GitHub issue submission.
        """
        errors = self.validate_agent_template(agent_template)
        if errors:
            return {"error": "Validation failed.", "validation_errors": errors}

        # Compute checksum
        bundle_text = json.dumps(agent_template, sort_keys=True, ensure_ascii=False)
        checksum = hashlib.sha256(bundle_text.encode("utf-8")).hexdigest()

        from urllib.parse import quote

        name = agent_template.get("name", "unnamed")
        version = agent_template.get("version", "0.0.0")
        author = agent_template.get("author", "unknown")

        title = quote(f"[Agent Submission] {name} v{version}")
        body_lines = [
            f"## Agent: {name}",
            f"**Version:** {version}",
            f"**Author:** {author}",
            f"**Description:** {agent_template.get('description', '')}",
            f"**Category:** {agent_template.get('category', '')}",
            f"**Directors:** {len(agent_template.get('director_configs', []))}",
            f"**Checksum:** {checksum}",
            "",
            "### agent.json",
            "```json",
            json.dumps(agent_template, indent=2, ensure_ascii=False),
            "```",
        ]
        body = quote("\n".join(body_lines))

        repo = "camilo-gutierrez/rain-agents-registry"
        submit_url = (
            f"https://github.com/{repo}/issues/new?"
            f"title={title}&body={body}&labels=agent-submission"
        )

        return {
            "prepared": True,
            "name": name,
            "version": version,
            "checksum": checksum,
            "submit_url": submit_url,
            "instructions": (
                f"To publish agent '{name}':\n"
                f"1. Open: {submit_url}\n"
                "2. Review the pre-filled issue\n"
                "3. Submit for review\n"
                "The maintainer will review and merge your agent."
            ),
        }

    def validate_agent_template(self, template: dict) -> list[str]:
        """Validate an agent template dict. Returns a list of error messages (empty = valid)."""
        errors: list[str] = []

        # Required string fields
        for field_name in ["name", "description", "version", "author"]:
            val = template.get(field_name, "")
            if not val or not str(val).strip():
                errors.append(f"Missing required field: '{field_name}'.")

        # Name format
        name = template.get("name", "")
        if name and not all(c.isalnum() or c in ("_", "-") for c in name):
            errors.append(
                "Agent name must contain only alphanumeric characters, hyphens, and underscores."
            )

        # Category validation
        category = template.get("category", "")
        if category and category not in AGENT_CATEGORIES:
            errors.append(
                f"Invalid category '{category}'. Must be one of: {', '.join(AGENT_CATEGORIES)}."
            )

        # Director configs
        directors = template.get("director_configs", [])
        if not directors:
            errors.append("Agent must have at least one director_config.")
        else:
            seen_ids = set()
            for i, dc in enumerate(directors):
                dc_id = dc.get("id", "")
                if not dc_id:
                    errors.append(f"Director config [{i}] is missing 'id'.")
                elif dc_id in seen_ids:
                    errors.append(f"Duplicate director id: '{dc_id}'.")
                else:
                    seen_ids.add(dc_id)

                rp = dc.get("role_prompt", "")
                if not rp or len(rp) < 20:
                    errors.append(
                        f"Director '{dc_id or i}' role_prompt must be at least 20 characters."
                    )

                if not dc.get("name"):
                    errors.append(f"Director config [{i}] is missing 'name'.")

        # Team template validation
        tt = template.get("team_template")
        if tt is not None:
            if not isinstance(tt, dict):
                errors.append("team_template must be a dict.")
            else:
                if not tt.get("id"):
                    errors.append("team_template is missing 'id'.")
                if not tt.get("name"):
                    errors.append("team_template is missing 'name'.")
                tt_directors = tt.get("directors", [])
                if tt_directors:
                    dc_ids = {dc.get("id", "") for dc in directors}
                    for td in tt_directors:
                        if td not in dc_ids:
                            errors.append(
                                f"team_template references director '{td}' "
                                "not found in director_configs."
                            )

        # Version format (basic semver check)
        version = template.get("version", "")
        if version:
            parts = version.split(".")
            if len(parts) != 3 or not all(p.isdigit() for p in parts):
                errors.append(
                    f"Version '{version}' must be in semver format (e.g., '1.0.0')."
                )

        # Rating
        rating = template.get("rating", 0)
        try:
            r = float(rating)
            if not 0.0 <= r <= 5.0:
                errors.append("Rating must be between 0.0 and 5.0.")
        except (ValueError, TypeError):
            errors.append("Rating must be a number between 0.0 and 5.0.")

        return errors

    # ── Security ─────────────────────────────────────────────────────

    async def security_scan(self, name: str) -> dict:
        """Run a security scan on an agent template."""
        info = self.get_agent_info(name)
        if not info:
            return {"error": f"Agent '{name}' not found."}

        from .security_scanner import SecurityScanner

        scanner = SecurityScanner()

        # Build template dict from info
        template_dict = {
            "name": info.name,
            "director_configs": info.director_configs,
            "team_template": info.team_template,
            "required_tools": info.required_tools,
            "required_env": info.required_env,
        }

        return scanner.scan_agent_template(template_dict)
