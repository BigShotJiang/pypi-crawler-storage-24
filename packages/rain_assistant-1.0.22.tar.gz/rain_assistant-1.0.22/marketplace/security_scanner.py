"""Security scanner for agent templates before publishing/installing.

Checks for dangerous tools, suspicious patterns in role prompts,
validates director configs, and verifies permission levels.
"""

import hashlib
import json
import logging
import re
from typing import Any

logger = logging.getLogger("rain.marketplace")


# Dangerous shell patterns that could harm the system
DANGEROUS_SHELL_PATTERNS = [
    (r"\brm\s+-rf\s+/", "Destructive 'rm -rf /' pattern detected"),
    (r"\brm\s+-rf\s+~", "Destructive 'rm -rf ~' pattern detected"),
    (r"\bmkfs\b", "Filesystem format command detected"),
    (r"\bdd\s+if=.*of=/dev/", "Low-level disk write detected"),
    (r":\(\)\s*\{", "Fork bomb detected"),
    (r"\bchmod\s+-R\s+777\s+/", "Recursive 777 chmod on root detected"),
    (r"\bcurl\b.*\|\s*bash", "Piping curl to bash detected"),
    (r"\bwget\b.*\|\s*sh", "Piping wget to sh detected"),
    (r"\beval\b.*\$\(", "Eval with command substitution detected"),
    (r"\bnc\s+-[el]", "Netcat listener (potential reverse shell) detected"),
    (r"\b/dev/tcp/", "Bash /dev/tcp (potential reverse shell) detected"),
    (r"\bsudo\s+rm\b", "Sudo rm detected"),
    (r"\bshutdown\b", "Shutdown command detected"),
    (r"\breboot\b", "Reboot command detected"),
    (r"\bpasswd\b", "Password modification detected"),
    (r"\buseradd\b", "User creation detected"),
    (r"\bchown\s+-R\s+.*\s+/\s*$", "Recursive chown on root detected"),
]

# Suspicious prompt patterns
SUSPICIOUS_PROMPT_PATTERNS = [
    (r"ignore\s+(previous|prior|all)\s+(instructions|prompts)", "Prompt injection pattern detected"),
    (r"you\s+are\s+now\s+(jailbroken|DAN)", "Jailbreak attempt detected"),
    (r"pretend\s+you\s+(are|have)\s+no\s+(restrictions|rules)", "Prompt override attempt detected"),
    (r"bypass\s+(security|safety|filters)", "Security bypass language detected"),
    (r"exfiltrate|steal\s+(data|credentials|keys)", "Data exfiltration language detected"),
    (r"send\s+(data|info|credentials)\s+to\s+(http|ftp|tcp)", "Data exfiltration pattern detected"),
]

# Tools that require elevated scrutiny
HIGH_RISK_TOOLS = {
    "bash_tool",
    "computer_use",
    "str_replace_based_edit_tool",
}

# Maximum number of directors allowed per agent
MAX_DIRECTORS_PER_AGENT = 20

# Maximum role_prompt length
MAX_ROLE_PROMPT_LENGTH = 50_000


class SecurityScanner:
    """Validates agent templates for security issues before install/publish."""

    def scan_agent_template(self, template: dict) -> dict:
        """Run a comprehensive security scan on an agent template.

        Args:
            template: Agent template dict with director_configs, etc.

        Returns:
            Dict with:
                passed: bool (True if no critical issues)
                warnings: list of warning dicts (severity, message, location)
                summary: str human-readable summary
        """
        warnings: list[dict[str, Any]] = []

        self._check_director_configs(template, warnings)
        self._check_required_tools(template, warnings)
        self._check_role_prompts(template, warnings)
        self._check_team_template(template, warnings)
        self._check_env_requirements(template, warnings)

        # Determine pass/fail
        critical_count = sum(1 for w in warnings if w.get("severity") == "critical")
        high_count = sum(1 for w in warnings if w.get("severity") == "high")
        medium_count = sum(1 for w in warnings if w.get("severity") == "medium")
        low_count = sum(1 for w in warnings if w.get("severity") == "low")

        passed = critical_count == 0

        summary_parts = []
        if critical_count:
            summary_parts.append(f"{critical_count} critical")
        if high_count:
            summary_parts.append(f"{high_count} high")
        if medium_count:
            summary_parts.append(f"{medium_count} medium")
        if low_count:
            summary_parts.append(f"{low_count} low")

        if not summary_parts:
            summary = "No security issues found."
        else:
            status = "FAILED" if not passed else "PASSED with warnings"
            summary = f"Security scan {status}: {', '.join(summary_parts)} issue(s)."

        return {
            "passed": passed,
            "warnings": warnings,
            "summary": summary,
            "counts": {
                "critical": critical_count,
                "high": high_count,
                "medium": medium_count,
                "low": low_count,
            },
        }

    def _check_director_configs(
        self, template: dict, warnings: list[dict]
    ) -> None:
        """Validate director config structure and limits."""
        directors = template.get("director_configs", [])

        if len(directors) > MAX_DIRECTORS_PER_AGENT:
            warnings.append({
                "severity": "high",
                "message": (
                    f"Agent has {len(directors)} directors (max {MAX_DIRECTORS_PER_AGENT}). "
                    "Excessive directors can cause resource issues."
                ),
                "location": "director_configs",
            })

        for i, dc in enumerate(directors):
            loc = f"director_configs[{i}]"

            # Check for missing id
            if not dc.get("id"):
                warnings.append({
                    "severity": "high",
                    "message": f"Director at index {i} has no 'id' field.",
                    "location": loc,
                })

            # Check role_prompt length
            rp = dc.get("role_prompt", "")
            if len(rp) > MAX_ROLE_PROMPT_LENGTH:
                warnings.append({
                    "severity": "medium",
                    "message": (
                        f"Director '{dc.get('id', i)}' role_prompt is {len(rp)} chars "
                        f"(max {MAX_ROLE_PROMPT_LENGTH}). May indicate embedded data."
                    ),
                    "location": loc,
                })

            # Check permission level
            perm = dc.get("permission_level", "green")
            if perm == "red":
                warnings.append({
                    "severity": "high",
                    "message": (
                        f"Director '{dc.get('id', i)}' has 'red' permission level, "
                        "allowing unrestricted execution."
                    ),
                    "location": loc,
                })
            elif perm == "yellow":
                warnings.append({
                    "severity": "medium",
                    "message": (
                        f"Director '{dc.get('id', i)}' has 'yellow' permission level."
                    ),
                    "location": loc,
                })

            # Check can_delegate
            if dc.get("can_delegate"):
                warnings.append({
                    "severity": "low",
                    "message": (
                        f"Director '{dc.get('id', i)}' can delegate tasks to other directors."
                    ),
                    "location": loc,
                })

            # Check tools_allowed for wildcards
            tools = dc.get("tools_allowed", [])
            if tools == ["*"] or "*" in tools:
                warnings.append({
                    "severity": "medium",
                    "message": (
                        f"Director '{dc.get('id', i)}' has wildcard tool access (all tools)."
                    ),
                    "location": loc,
                })

            # Check plugins_allowed for wildcards
            plugins = dc.get("plugins_allowed", [])
            if plugins == ["*"] or "*" in plugins:
                warnings.append({
                    "severity": "low",
                    "message": (
                        f"Director '{dc.get('id', i)}' has wildcard plugin access (all plugins)."
                    ),
                    "location": loc,
                })

    def _check_required_tools(
        self, template: dict, warnings: list[dict]
    ) -> None:
        """Check if the agent requires high-risk tools."""
        required = template.get("required_tools", [])
        for tool in required:
            if tool in HIGH_RISK_TOOLS:
                warnings.append({
                    "severity": "high",
                    "message": (
                        f"Agent requires high-risk tool: '{tool}'. "
                        "This tool can execute arbitrary commands."
                    ),
                    "location": "required_tools",
                })

    def _check_role_prompts(
        self, template: dict, warnings: list[dict]
    ) -> None:
        """Scan role prompts for dangerous shell patterns and prompt injection."""
        directors = template.get("director_configs", [])

        for i, dc in enumerate(directors):
            rp = dc.get("role_prompt", "")
            loc = f"director_configs[{i}].role_prompt"
            dc_id = dc.get("id", f"index_{i}")

            # Check for dangerous shell patterns
            for pattern, description in DANGEROUS_SHELL_PATTERNS:
                if re.search(pattern, rp, re.IGNORECASE):
                    warnings.append({
                        "severity": "critical",
                        "message": f"Director '{dc_id}': {description}",
                        "location": loc,
                    })

            # Check for suspicious prompt patterns
            for pattern, description in SUSPICIOUS_PROMPT_PATTERNS:
                if re.search(pattern, rp, re.IGNORECASE):
                    warnings.append({
                        "severity": "critical",
                        "message": f"Director '{dc_id}': {description}",
                        "location": loc,
                    })

            # Check for hardcoded URLs (potential C2)
            urls = re.findall(r"https?://[^\s\"']+", rp)
            for url in urls:
                # Allow common known-safe domains
                safe_domains = [
                    "github.com", "linkedin.com", "indeed.com",
                    "glassdoor.com", "stackoverflow.com",
                    "docs.python.org", "developer.mozilla.org",
                ]
                is_safe = any(domain in url for domain in safe_domains)
                if not is_safe:
                    warnings.append({
                        "severity": "medium",
                        "message": (
                            f"Director '{dc_id}' references external URL: {url[:80]}..."
                            if len(url) > 80
                            else f"Director '{dc_id}' references external URL: {url}"
                        ),
                        "location": loc,
                    })

    def _check_team_template(
        self, template: dict, warnings: list[dict]
    ) -> None:
        """Validate team template if present."""
        tt = template.get("team_template")
        if not tt:
            return

        if not isinstance(tt, dict):
            warnings.append({
                "severity": "high",
                "message": "team_template is not a valid dict.",
                "location": "team_template",
            })
            return

        # Check for references to non-existent directors
        dc_ids = {dc.get("id", "") for dc in template.get("director_configs", [])}
        for d_ref in tt.get("directors", []):
            if d_ref not in dc_ids:
                warnings.append({
                    "severity": "medium",
                    "message": (
                        f"team_template references director '{d_ref}' "
                        "not found in director_configs."
                    ),
                    "location": "team_template.directors",
                })

    def _check_env_requirements(
        self, template: dict, warnings: list[dict]
    ) -> None:
        """Check environment variable requirements."""
        required_env = template.get("required_env", [])

        sensitive_patterns = [
            "password", "secret", "token", "key", "credential",
            "private", "auth",
        ]

        for env_var in required_env:
            env_lower = env_var.lower()
            for pat in sensitive_patterns:
                if pat in env_lower:
                    warnings.append({
                        "severity": "low",
                        "message": (
                            f"Agent requires sensitive environment variable: '{env_var}'. "
                            "Ensure this is legitimate."
                        ),
                        "location": "required_env",
                    })
                    break  # Only one warning per env var

    def verify_checksum(self, bundle_text: str, expected_checksum: str) -> dict:
        """Verify a bundle's SHA-256 checksum.

        Args:
            bundle_text: The JSON text of the bundle.
            expected_checksum: The expected SHA-256 hash.

        Returns:
            Dict with verified: bool and details.
        """
        actual = hashlib.sha256(bundle_text.encode("utf-8")).hexdigest()
        match = actual == expected_checksum

        return {
            "verified": match,
            "expected": expected_checksum,
            "actual": actual,
            "message": "Checksum verified." if match else "Checksum mismatch!",
        }
