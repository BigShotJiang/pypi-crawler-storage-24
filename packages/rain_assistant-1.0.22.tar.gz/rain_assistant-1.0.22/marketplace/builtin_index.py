"""Built-in skills index — bundled skills that are always available.

These skills ship with Rain and appear in the Marketplace even without
a remote registry connection. They use free, public APIs and require
no API keys.
"""

BUILTIN_CATEGORIES: list[dict] = [
    {
        "id": "utilities",
        "name": "Utilities",
        "name_es": "Utilidades",
        "emoji": "\ud83d\udee0\ufe0f",
    },
    {
        "id": "web",
        "name": "Web & APIs",
        "name_es": "Web y APIs",
        "emoji": "\ud83c\udf10",
    },
    {
        "id": "data",
        "name": "Data & Formatting",
        "name_es": "Datos y Formato",
        "emoji": "\ud83d\udcca",
    },
    {
        "id": "system",
        "name": "System",
        "name_es": "Sistema",
        "emoji": "\ud83d\udda5\ufe0f",
    },
    {
        "id": "language",
        "name": "Language & Translation",
        "name_es": "Idioma y Traducci\u00f3n",
        "emoji": "\ud83c\udf0d",
    },
]

BUILTIN_SKILLS: list[dict] = [
    {
        "name": "weather",
        "display_name": "Weather",
        "description": (
            "Get current weather information for any city using wttr.in. "
            "Returns temperature, conditions, humidity, wind speed, and forecast. "
            "No API key required."
        ),
        "description_es": (
            "Obt\u00e9n informaci\u00f3n del clima actual de cualquier ciudad usando wttr.in. "
            "Devuelve temperatura, condiciones, humedad, velocidad del viento y pron\u00f3stico. "
            "No requiere API key."
        ),
        "version": "1.0",
        "author": "rain-community",
        "category": "web",
        "tags": ["weather", "api", "free"],
        "permission_level": "green",
        "execution_type": "http",
        "requires_env": [],
        "downloads": 0,
        "verified": True,
        "license": "Apache-2.0",
        "homepage": "",
        "updated_at": "2026-03-01",
        "min_rain_version": "1.0.0",
        "checksum_sha256": "",
        "builtin": True,
    },
    {
        "name": "translator",
        "display_name": "Translator",
        "description": (
            "Translate text between languages using the MyMemory free translation API. "
            "Supports all major languages. No API key required. Specify target language "
            "as a two-letter ISO 639-1 code (e.g. en, es, fr, de, ja, zh)."
        ),
        "description_es": (
            "Traduce texto entre idiomas usando la API gratuita de MyMemory. "
            "Soporta los principales idiomas. No requiere API key. Especifica el idioma "
            "destino con c\u00f3digo ISO 639-1 (ej. en, es, fr, de, ja, zh)."
        ),
        "version": "1.0",
        "author": "rain-community",
        "category": "language",
        "tags": ["translation", "language", "free"],
        "permission_level": "green",
        "execution_type": "python",
        "requires_env": [],
        "downloads": 0,
        "verified": True,
        "license": "Apache-2.0",
        "homepage": "",
        "updated_at": "2026-03-01",
        "min_rain_version": "1.0.0",
        "checksum_sha256": "",
        "builtin": True,
    },
    {
        "name": "system_info",
        "display_name": "System Info",
        "description": (
            "Display detailed system information including operating system, CPU, "
            "memory (RAM) usage, and disk space. Works on Linux, macOS, and Windows. "
            "No parameters needed."
        ),
        "description_es": (
            "Muestra informaci\u00f3n detallada del sistema: sistema operativo, CPU, "
            "uso de memoria (RAM) y espacio en disco. Funciona en Linux, macOS y Windows. "
            "No requiere par\u00e1metros."
        ),
        "version": "1.0",
        "author": "rain-community",
        "category": "system",
        "tags": ["system", "diagnostics", "hardware"],
        "permission_level": "green",
        "execution_type": "bash",
        "requires_env": [],
        "downloads": 0,
        "verified": True,
        "license": "Apache-2.0",
        "homepage": "",
        "updated_at": "2026-03-01",
        "min_rain_version": "1.0.0",
        "checksum_sha256": "",
        "builtin": True,
    },
    {
        "name": "json_formatter",
        "display_name": "JSON Formatter",
        "description": (
            "Validate and pretty-print JSON text. Detects syntax errors with line "
            "and column information. Can also minify JSON or sort keys. Useful for "
            "debugging API responses and config files."
        ),
        "description_es": (
            "Valida y formatea texto JSON. Detecta errores de sintaxis con l\u00ednea "
            "y columna. Tambi\u00e9n puede minificar JSON u ordenar claves. \u00datil para "
            "depurar respuestas de API y archivos de configuraci\u00f3n."
        ),
        "version": "1.0",
        "author": "rain-community",
        "category": "data",
        "tags": ["json", "formatter", "validator"],
        "permission_level": "green",
        "execution_type": "python",
        "requires_env": [],
        "downloads": 0,
        "verified": True,
        "license": "Apache-2.0",
        "homepage": "",
        "updated_at": "2026-03-01",
        "min_rain_version": "1.0.0",
        "checksum_sha256": "",
        "builtin": True,
    },
    {
        "name": "url_shortener",
        "display_name": "URL Shortener",
        "description": (
            "Shorten long URLs using the is.gd free URL shortening service. "
            "Returns a short link that redirects to the original URL. "
            "No API key required."
        ),
        "description_es": (
            "Acorta URLs largas usando el servicio gratuito is.gd. "
            "Devuelve un enlace corto que redirige a la URL original. "
            "No requiere API key."
        ),
        "version": "1.0",
        "author": "rain-community",
        "category": "web",
        "tags": ["url", "shortener", "free"],
        "permission_level": "green",
        "execution_type": "http",
        "requires_env": [],
        "downloads": 0,
        "verified": True,
        "license": "Apache-2.0",
        "homepage": "",
        "updated_at": "2026-03-01",
        "min_rain_version": "1.0.0",
        "checksum_sha256": "",
        "builtin": True,
    },
]


def get_builtin_index() -> dict:
    """Return the built-in skills index (same shape as a remote index.json)."""
    return {
        "skills": list(BUILTIN_SKILLS),
        "categories": list(BUILTIN_CATEGORIES),
    }
