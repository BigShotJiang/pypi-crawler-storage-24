from .base import BaseProvider, NormalizedEvent
from .openai_compat_provider import PROVIDER_PRESETS

# OpenAI-compatible provider presets (Groq, xAI, DeepSeek, Together, Mistral, Cohere)
_OPENAI_COMPAT_PRESETS = set(PROVIDER_PRESETS.keys())


def get_provider(provider_name: str) -> BaseProvider:
    """Factory: create a provider instance by name."""
    if provider_name == "claude":
        from .claude_provider import ClaudeProvider
        return ClaudeProvider()
    elif provider_name == "openai":
        from .openai_provider import OpenAIProvider
        return OpenAIProvider()
    elif provider_name == "gemini":
        from .gemini_provider import GeminiProvider
        return GeminiProvider()
    elif provider_name == "ollama":
        from .ollama_provider import OllamaProvider
        return OllamaProvider()
    elif provider_name in _OPENAI_COMPAT_PRESETS:
        from .openai_compat_provider import OpenAICompatProvider
        return OpenAICompatProvider(preset=provider_name)
    else:
        raise ValueError(f"Unknown provider: {provider_name}")


__all__ = ["get_provider", "BaseProvider", "NormalizedEvent"]
