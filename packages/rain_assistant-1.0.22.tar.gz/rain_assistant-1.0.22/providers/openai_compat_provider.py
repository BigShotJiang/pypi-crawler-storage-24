"""OpenAI-compatible provider — unified agentic loop for all OpenAI-compatible APIs.

Supports: Groq, xAI (Grok), DeepSeek, Together AI, Mistral, Cohere
All of these services expose an OpenAI-compatible chat completions endpoint,
so we reuse a single implementation and just configure the base_url + defaults.

Usage:
    provider = OpenAICompatProvider(preset="groq")
    await provider.initialize(api_key="gsk_...", model="auto", ...)
"""

import asyncio
import json
import time
import uuid
from typing import AsyncIterator, Callable, Awaitable, Any

from .base import BaseProvider, NormalizedEvent, _sanitize_api_error
from tools import ToolExecutor
from tools.definitions import get_all_tool_definitions


# ── Provider presets ─────────────────────────────────────────────────────────
# Each preset configures: base_url, default_model, label, and pricing.
# Pricing is per 1M tokens (USD).  Update as needed.

PROVIDER_PRESETS: dict[str, dict] = {
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "default_model": "llama-4-scout-17b-16e-instruct",
        "label": "Groq",
        "pricing": {
            # Llama 4 series
            "llama-4-scout-17b-16e-instruct": {"input": 0.11, "output": 0.34},
            "llama-4-maverick-17b-128e-instruct": {"input": 0.50, "output": 0.77},
            # Llama 3.3
            "llama-3.3-70b-versatile": {"input": 0.59, "output": 0.79},
            # DeepSeek on Groq
            "deepseek-r1-distill-llama-70b": {"input": 0.75, "output": 0.99},
            # Qwen
            "qwen-qwq-32b": {"input": 0.29, "output": 0.39},
            # Gemma
            "gemma2-9b-it": {"input": 0.20, "output": 0.20},
            # Mistral
            "mistral-saba-24b": {"input": 0.29, "output": 0.39},
            # Compound models
            "compound-beta": {"input": 0.0, "output": 0.0},
            "compound-beta-mini": {"input": 0.0, "output": 0.0},
        },
    },
    "xai": {
        "base_url": "https://api.x.ai/v1",
        "default_model": "grok-3-fast",
        "label": "xAI (Grok)",
        "pricing": {
            "grok-4": {"input": 3.00, "output": 15.00},
            "grok-4-fast": {"input": 0.20, "output": 0.50},
            "grok-3": {"input": 3.00, "output": 15.00},
            "grok-3-fast": {"input": 0.30, "output": 1.50},
            "grok-3-mini": {"input": 0.30, "output": 0.50},
            "grok-3-mini-fast": {"input": 0.10, "output": 0.25},
            "grok-2": {"input": 2.00, "output": 10.00},
        },
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com",
        "default_model": "deepseek-chat",
        "label": "DeepSeek",
        "pricing": {
            "deepseek-chat": {"input": 0.28, "output": 0.42},
            "deepseek-reasoner": {"input": 0.28, "output": 0.42},
        },
    },
    "together": {
        "base_url": "https://api.together.xyz/v1",
        "default_model": "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8",
        "label": "Together AI",
        "pricing": {
            # Llama 4
            "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8": {"input": 0.27, "output": 0.85},
            "meta-llama/Llama-4-Scout-17B-16E-Instruct": {"input": 0.18, "output": 0.59},
            # Llama 3.3
            "meta-llama/Llama-3.3-70B-Instruct-Turbo": {"input": 0.88, "output": 0.88},
            # DeepSeek
            "deepseek-ai/DeepSeek-R1": {"input": 3.00, "output": 7.00},
            "deepseek-ai/DeepSeek-V3": {"input": 0.30, "output": 0.60},
            # Qwen
            "Qwen/Qwen2.5-72B-Instruct-Turbo": {"input": 0.60, "output": 0.60},
            "Qwen/QwQ-32B": {"input": 0.30, "output": 0.30},
            # Mistral
            "mistralai/Mistral-Small-24B-Instruct-2501": {"input": 0.20, "output": 0.20},
        },
    },
    "mistral": {
        "base_url": "https://api.mistral.ai/v1",
        "default_model": "mistral-small-latest",
        "label": "Mistral AI",
        "pricing": {
            "mistral-large-latest": {"input": 2.00, "output": 6.00},
            "mistral-medium-latest": {"input": 2.00, "output": 5.50},
            "mistral-small-latest": {"input": 0.10, "output": 0.30},
            "codestral-latest": {"input": 0.30, "output": 0.90},
            "mistral-embed": {"input": 0.10, "output": 0.0},
            "open-mistral-nemo": {"input": 0.15, "output": 0.15},
            "pixtral-large-latest": {"input": 2.00, "output": 6.00},
        },
    },
    "cohere": {
        "base_url": "https://api.cohere.ai/compatibility/v1",
        "default_model": "command-a-03-2025",
        "label": "Cohere",
        "pricing": {
            "command-a-03-2025": {"input": 2.50, "output": 10.00},
            "command-r-plus": {"input": 2.50, "output": 10.00},
            "command-r": {"input": 0.15, "output": 0.60},
            "command-r7b-12-2024": {"input": 0.0375, "output": 0.15},
        },
    },
}

MAX_ITERATIONS = 50
MAX_HISTORY_MESSAGES = 100
MAX_HISTORY_CHARS = 500_000


class OpenAICompatProvider(BaseProvider):
    """Unified provider for all OpenAI-compatible APIs.

    Instantiate with a preset name (e.g. "groq", "xai") to configure
    the base_url, default model, and pricing automatically.
    """

    def __init__(self, preset: str = "groq"):
        if preset not in PROVIDER_PRESETS:
            raise ValueError(
                f"Unknown preset '{preset}'. "
                f"Available: {', '.join(PROVIDER_PRESETS)}"
            )
        self._preset = preset
        self._config = PROVIDER_PRESETS[preset]
        self.provider_name = preset  # "groq", "xai", "deepseek", etc.

        self._client = None
        self._model = self._config["default_model"]
        self._system_prompt = ""
        self._messages: list[dict] = []
        self._tool_executor: ToolExecutor | None = None
        self._interrupted = False

    def _trim_history(self):
        """Trim conversation history to prevent unbounded memory growth."""
        if len(self._messages) > MAX_HISTORY_MESSAGES:
            if self._messages and self._messages[0].get("role") == "system":
                self._messages = [self._messages[0]] + self._messages[-(MAX_HISTORY_MESSAGES - 1):]
            else:
                self._messages = self._messages[-MAX_HISTORY_MESSAGES:]

        total_chars = sum(len(str(m.get("content", ""))) for m in self._messages)
        while total_chars > MAX_HISTORY_CHARS and len(self._messages) > 2:
            start = 1 if self._messages[0].get("role") == "system" else 0
            removed = self._messages.pop(start)
            total_chars -= len(str(removed.get("content", "")))

    async def initialize(
        self,
        api_key: str,
        model: str,
        cwd: str,
        system_prompt: str,
        can_use_tool: Callable[..., Awaitable[Any]] | None = None,
        resume_session_id: str | None = None,
        mcp_servers: dict | str | None = None,
        agent_id: str = "default",
        user_id: str = "default",
    ) -> None:
        from openai import AsyncOpenAI

        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=self._config["base_url"],
        )
        self._model = (
            model if model and model != "auto"
            else self._config["default_model"]
        )
        self._system_prompt = system_prompt
        self._messages = []
        self._tool_executor = ToolExecutor(
            cwd=cwd,
            permission_callback=can_use_tool,
            agent_id=agent_id,
            user_id=user_id,
        )
        self._interrupted = False

    async def send_message(self, text: str, images: list[dict] | None = None) -> None:
        if images:
            content_parts: list[dict] = []
            for img in images:
                media = img.get("mediaType", "image/png")
                content_parts.append({
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{media};base64,{img['base64']}",
                    },
                })
            content_parts.append({"type": "text", "text": text})
            self._messages.append({"role": "user", "content": content_parts})
        else:
            self._messages.append({"role": "user", "content": text})
        self._interrupted = False

    async def stream_response(self) -> AsyncIterator[NormalizedEvent]:
        if not self._client or not self._tool_executor:
            return

        label = self._config["label"]
        yield NormalizedEvent("model_info", {"model": self._model})

        iterations = 0
        total_input_tokens = 0
        total_output_tokens = 0
        start_time = time.time()
        last_text = ""
        tools_supported = True  # will be set to False if provider rejects tools

        while iterations < MAX_ITERATIONS and not self._interrupted:
            iterations += 1

            api_messages = [{"role": "system", "content": self._system_prompt}] + self._messages

            # Build kwargs — some providers don't support stream_options
            kwargs: dict[str, Any] = {
                "model": self._model,
                "messages": api_messages,
                "stream": True,
            }

            if tools_supported:
                try:
                    tool_defs = get_all_tool_definitions()
                    if tool_defs:
                        kwargs["tools"] = tool_defs
                except Exception:
                    tools_supported = False

            # Try to include usage in stream (not all providers support this)
            kwargs["stream_options"] = {"include_usage": True}

            try:
                stream = await self._client.chat.completions.create(**kwargs)
            except Exception as e:
                error_msg = str(e).lower()
                # Handle providers that don't support stream_options
                if "stream_options" in error_msg or "unrecognized" in error_msg:
                    kwargs.pop("stream_options", None)
                    try:
                        stream = await self._client.chat.completions.create(**kwargs)
                    except Exception as e2:
                        # Maybe tools aren't supported either
                        if tools_supported and ("tool" in str(e2).lower() or "function" in str(e2).lower()):
                            tools_supported = False
                            kwargs.pop("tools", None)
                            try:
                                stream = await self._client.chat.completions.create(**kwargs)
                            except Exception as e3:
                                yield NormalizedEvent("error", {"text": _sanitize_api_error(label, e3)})
                                break
                        else:
                            yield NormalizedEvent("error", {"text": _sanitize_api_error(label, e2)})
                            break
                elif tools_supported and ("tool" in error_msg or "function" in error_msg):
                    # Provider doesn't support tools — retry without
                    tools_supported = False
                    kwargs.pop("tools", None)
                    kwargs.pop("stream_options", None)
                    try:
                        stream = await self._client.chat.completions.create(**kwargs)
                    except Exception as e2:
                        yield NormalizedEvent("error", {"text": _sanitize_api_error(label, e2)})
                        break
                else:
                    yield NormalizedEvent("error", {"text": _sanitize_api_error(label, e)})
                    break

            # Accumulate streamed response
            full_content = ""
            tool_calls_map: dict[int, dict] = {}

            try:
                async for chunk in stream:
                    if self._interrupted:
                        break

                    # Usage in the final chunk (if supported)
                    if hasattr(chunk, "usage") and chunk.usage:
                        total_input_tokens += chunk.usage.prompt_tokens or 0
                        total_output_tokens += chunk.usage.completion_tokens or 0

                    if not chunk.choices:
                        continue

                    delta = chunk.choices[0].delta

                    if delta and delta.content:
                        full_content += delta.content
                        yield NormalizedEvent("assistant_text", {"text": delta.content})

                    if delta and delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in tool_calls_map:
                                tool_calls_map[idx] = {
                                    "id": tc_delta.id or f"call_{uuid.uuid4().hex[:24]}",
                                    "name": "",
                                    "arguments": "",
                                }
                            if tc_delta.id:
                                tool_calls_map[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    tool_calls_map[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    tool_calls_map[idx]["arguments"] += tc_delta.function.arguments
            except Exception as e:
                yield NormalizedEvent("error", {"text": _sanitize_api_error(label, e)})
                break

            if self._interrupted:
                break

            last_text = full_content

            tool_calls = [tool_calls_map[i] for i in sorted(tool_calls_map.keys())]

            assistant_msg: dict = {"role": "assistant", "content": full_content or None}
            if tool_calls:
                assistant_msg["tool_calls"] = [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": tc["arguments"],
                        },
                    }
                    for tc in tool_calls
                ]
            self._messages.append(assistant_msg)
            self._trim_history()

            if not tool_calls:
                break

            # Execute each tool call
            for tc in tool_calls:
                if self._interrupted:
                    break

                try:
                    args = json.loads(tc["arguments"])
                except json.JSONDecodeError:
                    args = {}

                yield NormalizedEvent("tool_use", {
                    "tool": tc["name"],
                    "id": tc["id"],
                    "input": args,
                })

                try:
                    result = await self._tool_executor.execute(tc["name"], args)
                except Exception as e:
                    result = {"content": _sanitize_api_error(f"{label}/tool", e), "is_error": True}

                yield NormalizedEvent("tool_result", {
                    "tool_use_id": tc["id"],
                    "content": result["content"],
                    "is_error": result.get("is_error", False),
                })

                self._messages.append({
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result["content"],
                })

            self._trim_history()

        # Emit final result
        elapsed_ms = int((time.time() - start_time) * 1000)
        cost = self._calculate_cost(total_input_tokens, total_output_tokens)

        yield NormalizedEvent("result", {
            "text": last_text,
            "session_id": None,
            "cost": round(cost, 6),
            "duration_ms": elapsed_ms,
            "num_turns": iterations,
            "is_error": False,
            "usage": {
                "input_tokens": total_input_tokens,
                "output_tokens": total_output_tokens,
            },
        })

    def _calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        pricing_table = self._config.get("pricing", {})
        pricing = pricing_table.get(self._model, {"input": 0.50, "output": 1.00})
        return (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

    async def interrupt(self) -> None:
        self._interrupted = True

    async def disconnect(self) -> None:
        self._client = None
        self._messages = []

    def supports_session_resumption(self) -> bool:
        return False

    def supports_computer_use(self) -> bool:
        return False
