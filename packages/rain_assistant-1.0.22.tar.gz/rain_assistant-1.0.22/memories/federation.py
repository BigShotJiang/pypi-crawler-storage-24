"""Federated memory layer for Rain Assistant.

Enables shared/federated memory across multiple agent instances via namespaces.
Namespaces can be private (single user), shared (all users), or team (specific users).

Storage uses the per-user memories.db SQLite database with dedicated tables
for namespaces, permissions, memory links, and sync logs.
"""

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Optional

from memories.embeddings import (
    CONFIG_DIR,
    _ensure_dir,
    cosine_similarity,
    get_embedding,
    _serialize_embedding,
    _deserialize_embedding,
)
from memories.storage import load_memories, search_memories
from utils.sanitize import sanitize_user_id, secure_chmod

logger = logging.getLogger(__name__)

NAMESPACE_TYPES = {"private", "shared", "team"}
ACCESS_LEVELS = {"read", "write"}


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def _get_federation_db() -> sqlite3.Connection:
    """Open (and initialize) the federation database.

    Uses a shared federation.db in the Rain config directory so that
    all users can see shared/team namespaces.
    """
    _ensure_dir()
    db_path = CONFIG_DIR / "federation.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")

    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memory_namespaces (
            id         TEXT PRIMARY KEY,
            name       TEXT NOT NULL UNIQUE,
            type       TEXT NOT NULL DEFAULT 'private',
            owner_id   TEXT NOT NULL,
            created_at REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS namespace_permissions (
            id           TEXT PRIMARY KEY,
            namespace_id TEXT NOT NULL,
            user_id      TEXT NOT NULL,
            access_level TEXT NOT NULL DEFAULT 'read',
            granted_at   REAL NOT NULL,
            granted_by   TEXT NOT NULL,
            FOREIGN KEY (namespace_id) REFERENCES memory_namespaces(id) ON DELETE CASCADE,
            UNIQUE(namespace_id, user_id)
        );

        CREATE TABLE IF NOT EXISTS namespace_memories (
            id           TEXT PRIMARY KEY,
            namespace_id TEXT NOT NULL,
            memory_id    TEXT NOT NULL,
            content      TEXT NOT NULL DEFAULT '',
            category     TEXT NOT NULL DEFAULT 'fact',
            created_at   REAL NOT NULL DEFAULT 0,
            updated_at   REAL NOT NULL DEFAULT 0,
            shared_by    TEXT NOT NULL,
            shared_at    REAL NOT NULL,
            FOREIGN KEY (namespace_id) REFERENCES memory_namespaces(id) ON DELETE CASCADE,
            UNIQUE(namespace_id, memory_id)
        );

        CREATE TABLE IF NOT EXISTS memory_sync_log (
            id         TEXT PRIMARY KEY,
            source_ns  TEXT NOT NULL,
            target_ns  TEXT NOT NULL,
            memory_id  TEXT NOT NULL,
            action     TEXT NOT NULL,
            synced_at  REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_ns_perm_ns
            ON namespace_permissions(namespace_id);
        CREATE INDEX IF NOT EXISTS idx_ns_perm_user
            ON namespace_permissions(user_id);
        CREATE INDEX IF NOT EXISTS idx_ns_mem_ns
            ON namespace_memories(namespace_id);
        CREATE INDEX IF NOT EXISTS idx_ns_mem_memory
            ON namespace_memories(memory_id);
        CREATE INDEX IF NOT EXISTS idx_sync_source
            ON memory_sync_log(source_ns);
        CREATE INDEX IF NOT EXISTS idx_sync_target
            ON memory_sync_log(target_ns);
    """)
    conn.commit()

    try:
        secure_chmod(db_path, 0o600)
    except Exception:
        pass

    return conn


# ---------------------------------------------------------------------------
# Namespace CRUD
# ---------------------------------------------------------------------------

def create_namespace(
    name: str,
    ns_type: str = "private",
    owner_id: str = "default",
) -> dict:
    """Create a new namespace.

    Args:
        name: Unique namespace name.
        ns_type: One of 'private', 'shared', 'team'.
        owner_id: User who owns the namespace.

    Returns:
        Dict with namespace details.

    Raises:
        ValueError: If ns_type is invalid or name is empty.
        sqlite3.IntegrityError: If name already exists.
    """
    if not name or not name.strip():
        raise ValueError("Namespace name cannot be empty")
    if ns_type not in NAMESPACE_TYPES:
        raise ValueError(f"Invalid namespace type: {ns_type}. Must be one of {NAMESPACE_TYPES}")

    ns_id = str(uuid.uuid4())[:8]
    now = time.time()
    owner_id = sanitize_user_id(owner_id)

    conn = _get_federation_db()
    try:
        conn.execute(
            "INSERT INTO memory_namespaces (id, name, type, owner_id, created_at) VALUES (?, ?, ?, ?, ?)",
            (ns_id, name.strip(), ns_type, owner_id, now),
        )
        # Owner always gets write access
        perm_id = str(uuid.uuid4())[:8]
        conn.execute(
            "INSERT INTO namespace_permissions (id, namespace_id, user_id, access_level, granted_at, granted_by) "
            "VALUES (?, ?, ?, 'write', ?, ?)",
            (perm_id, ns_id, owner_id, now, owner_id),
        )
        conn.commit()
        return {
            "id": ns_id,
            "name": name.strip(),
            "type": ns_type,
            "owner_id": owner_id,
            "created_at": now,
        }
    finally:
        conn.close()


def list_namespaces(user_id: str = "default") -> list[dict]:
    """List namespaces accessible to a user.

    Returns namespaces that are:
    - Owned by the user (any type)
    - Shared (type='shared')
    - Team namespaces where user has explicit permission
    """
    user_id = sanitize_user_id(user_id)
    conn = _get_federation_db()
    try:
        rows = conn.execute(
            """
            SELECT DISTINCT n.id, n.name, n.type, n.owner_id, n.created_at
            FROM memory_namespaces n
            LEFT JOIN namespace_permissions p ON n.id = p.namespace_id AND p.user_id = ?
            WHERE n.owner_id = ?
               OR n.type = 'shared'
               OR p.user_id IS NOT NULL
            ORDER BY n.created_at DESC
            """,
            (user_id, user_id),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_namespace(namespace_id: str, user_id: str = "default") -> bool:
    """Delete a namespace and all its associated data (cascade).

    Only the owner can delete a namespace.

    Returns:
        True if deleted, False if not found or not authorized.
    """
    user_id = sanitize_user_id(user_id)
    conn = _get_federation_db()
    try:
        # Check ownership
        row = conn.execute(
            "SELECT owner_id FROM memory_namespaces WHERE id = ?",
            (namespace_id,),
        ).fetchone()
        if not row or row["owner_id"] != user_id:
            return False

        # CASCADE will clean up permissions and namespace_memories
        conn.execute("DELETE FROM memory_namespaces WHERE id = ?", (namespace_id,))
        # Also clean up sync logs referencing this namespace
        conn.execute(
            "DELETE FROM memory_sync_log WHERE source_ns = ? OR target_ns = ?",
            (namespace_id, namespace_id),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def get_namespace(namespace_id: str) -> Optional[dict]:
    """Get a single namespace by ID."""
    conn = _get_federation_db()
    try:
        row = conn.execute(
            "SELECT id, name, type, owner_id, created_at FROM memory_namespaces WHERE id = ?",
            (namespace_id,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Permission management
# ---------------------------------------------------------------------------

def grant_access(
    namespace_id: str,
    target_user_id: str,
    access_level: str = "read",
    granted_by: str = "default",
) -> dict:
    """Grant a user access to a namespace.

    Args:
        namespace_id: The namespace to grant access to.
        target_user_id: The user to grant access.
        access_level: 'read' or 'write'.
        granted_by: The user granting access (must be owner or have write access).

    Returns:
        Dict with permission details.

    Raises:
        ValueError: If access_level is invalid.
        PermissionError: If granter doesn't have authority.
    """
    if access_level not in ACCESS_LEVELS:
        raise ValueError(f"Invalid access level: {access_level}. Must be one of {ACCESS_LEVELS}")

    target_user_id = sanitize_user_id(target_user_id)
    granted_by = sanitize_user_id(granted_by)

    conn = _get_federation_db()
    try:
        # Verify namespace exists and granter has authority
        ns = conn.execute(
            "SELECT owner_id, type FROM memory_namespaces WHERE id = ?",
            (namespace_id,),
        ).fetchone()
        if not ns:
            raise ValueError(f"Namespace {namespace_id} not found")

        # Only owner or users with write access can grant
        if ns["owner_id"] != granted_by:
            perm = conn.execute(
                "SELECT access_level FROM namespace_permissions WHERE namespace_id = ? AND user_id = ?",
                (namespace_id, granted_by),
            ).fetchone()
            if not perm or perm["access_level"] != "write":
                raise PermissionError("Only owner or users with write access can grant permissions")

        perm_id = str(uuid.uuid4())[:8]
        now = time.time()

        conn.execute(
            """INSERT OR REPLACE INTO namespace_permissions
               (id, namespace_id, user_id, access_level, granted_at, granted_by)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (perm_id, namespace_id, target_user_id, access_level, now, granted_by),
        )
        conn.commit()
        return {
            "id": perm_id,
            "namespace_id": namespace_id,
            "user_id": target_user_id,
            "access_level": access_level,
            "granted_at": now,
            "granted_by": granted_by,
        }
    finally:
        conn.close()


def revoke_access(
    namespace_id: str,
    target_user_id: str,
    revoked_by: str = "default",
) -> bool:
    """Revoke a user's access to a namespace.

    The owner's access cannot be revoked. Only the owner can revoke others.

    Returns:
        True if access was revoked, False otherwise.
    """
    target_user_id = sanitize_user_id(target_user_id)
    revoked_by = sanitize_user_id(revoked_by)

    conn = _get_federation_db()
    try:
        ns = conn.execute(
            "SELECT owner_id FROM memory_namespaces WHERE id = ?",
            (namespace_id,),
        ).fetchone()
        if not ns:
            return False

        # Cannot revoke owner's access
        if target_user_id == ns["owner_id"]:
            return False

        # Only owner can revoke
        if revoked_by != ns["owner_id"]:
            return False

        cursor = conn.execute(
            "DELETE FROM namespace_permissions WHERE namespace_id = ? AND user_id = ?",
            (namespace_id, target_user_id),
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def check_access(
    namespace_id: str,
    user_id: str,
    required_level: str = "read",
) -> bool:
    """Check if a user has the required access level to a namespace.

    For 'shared' namespaces, all users have at least read access.
    Write access to shared namespaces still requires explicit permission.

    Args:
        namespace_id: Namespace to check.
        user_id: User to check.
        required_level: 'read' or 'write'.

    Returns:
        True if user has the required access.
    """
    user_id = sanitize_user_id(user_id)
    conn = _get_federation_db()
    try:
        ns = conn.execute(
            "SELECT owner_id, type FROM memory_namespaces WHERE id = ?",
            (namespace_id,),
        ).fetchone()
        if not ns:
            return False

        # Owner always has full access
        if ns["owner_id"] == user_id:
            return True

        # Shared namespaces give everyone read access
        if ns["type"] == "shared" and required_level == "read":
            return True

        # Check explicit permission
        perm = conn.execute(
            "SELECT access_level FROM namespace_permissions WHERE namespace_id = ? AND user_id = ?",
            (namespace_id, user_id),
        ).fetchone()
        if not perm:
            return False

        if required_level == "read":
            return perm["access_level"] in ("read", "write")
        return perm["access_level"] == "write"
    finally:
        conn.close()


def list_permissions(namespace_id: str) -> list[dict]:
    """List all permissions for a namespace.

    Returns:
        List of permission dicts.
    """
    conn = _get_federation_db()
    try:
        rows = conn.execute(
            """SELECT id, namespace_id, user_id, access_level, granted_at, granted_by
               FROM namespace_permissions
               WHERE namespace_id = ?
               ORDER BY granted_at DESC""",
            (namespace_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Cross-namespace operations
# ---------------------------------------------------------------------------

def share_memory(
    memory_id: str,
    content: str,
    target_namespace_id: str,
    shared_by: str = "default",
    category: str = "fact",
    source_created_at: Optional[float] = None,
) -> dict:
    """Share (copy/link) a memory into a namespace.

    Args:
        memory_id: The original memory ID.
        content: Memory content text.
        target_namespace_id: Namespace to share into.
        shared_by: User performing the share.
        category: Memory category.
        source_created_at: Original creation timestamp.

    Returns:
        Dict with the namespace_memories entry.

    Raises:
        PermissionError: If user doesn't have write access.
        ValueError: If namespace not found.
    """
    shared_by = sanitize_user_id(shared_by)

    if not check_access(target_namespace_id, shared_by, "write"):
        raise PermissionError(f"User {shared_by} does not have write access to namespace {target_namespace_id}")

    link_id = str(uuid.uuid4())[:8]
    now = time.time()
    created_at = source_created_at or now

    conn = _get_federation_db()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO namespace_memories
               (id, namespace_id, memory_id, content, category, created_at, updated_at, shared_by, shared_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (link_id, target_namespace_id, memory_id, content, category, created_at, now, shared_by, now),
        )
        conn.commit()
        return {
            "id": link_id,
            "namespace_id": target_namespace_id,
            "memory_id": memory_id,
            "content": content,
            "category": category,
            "created_at": created_at,
            "updated_at": now,
            "shared_by": shared_by,
            "shared_at": now,
        }
    finally:
        conn.close()


def get_namespace_memories(namespace_id: str, user_id: str = "default") -> list[dict]:
    """Get all memories in a namespace.

    Args:
        namespace_id: Namespace to retrieve memories from.
        user_id: User requesting (access check).

    Returns:
        List of memory dicts in the namespace.

    Raises:
        PermissionError: If user doesn't have read access.
    """
    user_id = sanitize_user_id(user_id)

    if not check_access(namespace_id, user_id, "read"):
        raise PermissionError(f"User {user_id} does not have read access to namespace {namespace_id}")

    conn = _get_federation_db()
    try:
        rows = conn.execute(
            """SELECT id, namespace_id, memory_id, content, category,
                      created_at, updated_at, shared_by, shared_at
               FROM namespace_memories
               WHERE namespace_id = ?
               ORDER BY shared_at DESC""",
            (namespace_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def search_federated(
    query: str,
    user_id: str = "default",
    top_k: int = 10,
) -> list[dict]:
    """Search across all namespaces the user has access to.

    Performs substring matching across namespace memories.
    Results are sorted by relevance (exact matches first, then partial).

    Args:
        query: Search query string.
        user_id: User performing the search.
        top_k: Maximum results to return.

    Returns:
        List of memory dicts with namespace info, sorted by relevance.
    """
    user_id = sanitize_user_id(user_id)

    if not query or not query.strip():
        return []

    # Get all accessible namespaces
    namespaces = list_namespaces(user_id)
    if not namespaces:
        return []

    ns_ids = [ns["id"] for ns in namespaces]
    ns_name_map = {ns["id"]: ns["name"] for ns in namespaces}

    conn = _get_federation_db()
    try:
        placeholders = ",".join("?" * len(ns_ids))
        query_lower = query.strip().lower()

        rows = conn.execute(
            f"""SELECT nm.id, nm.namespace_id, nm.memory_id, nm.content,
                       nm.category, nm.created_at, nm.updated_at,
                       nm.shared_by, nm.shared_at
                FROM namespace_memories nm
                WHERE nm.namespace_id IN ({placeholders})
                  AND LOWER(nm.content) LIKE ?
                ORDER BY nm.updated_at DESC
                LIMIT ?""",
            (*ns_ids, f"%{query_lower}%", top_k),
        ).fetchall()

        results = []
        for r in rows:
            d = dict(r)
            d["namespace_name"] = ns_name_map.get(d["namespace_id"], "")
            results.append(d)
        return results
    finally:
        conn.close()


def sync_memories(
    source_ns_id: str,
    target_ns_id: str,
    user_id: str = "default",
) -> dict:
    """Sync memories from source namespace to target namespace.

    Uses last-write-wins conflict resolution: if a memory exists in both
    namespaces, the version with the newer updated_at wins.

    Args:
        source_ns_id: Source namespace ID.
        target_ns_id: Target namespace ID.
        user_id: User performing the sync (needs write on target, read on source).

    Returns:
        Dict with sync stats: added, updated, skipped counts.

    Raises:
        PermissionError: If user lacks required access.
        ValueError: If namespace not found.
    """
    user_id = sanitize_user_id(user_id)

    if not check_access(source_ns_id, user_id, "read"):
        raise PermissionError(f"User {user_id} does not have read access to source namespace")
    if not check_access(target_ns_id, user_id, "write"):
        raise PermissionError(f"User {user_id} does not have write access to target namespace")

    conn = _get_federation_db()
    try:
        # Get source memories
        source_mems = conn.execute(
            "SELECT memory_id, content, category, created_at, updated_at, shared_by "
            "FROM namespace_memories WHERE namespace_id = ?",
            (source_ns_id,),
        ).fetchall()

        # Get target memories indexed by memory_id
        target_rows = conn.execute(
            "SELECT id, memory_id, updated_at FROM namespace_memories WHERE namespace_id = ?",
            (target_ns_id,),
        ).fetchall()
        target_map = {r["memory_id"]: dict(r) for r in target_rows}

        stats = {"added": 0, "updated": 0, "skipped": 0}
        now = time.time()

        for src in source_mems:
            src = dict(src)
            mem_id = src["memory_id"]

            if mem_id not in target_map:
                # Add new
                link_id = str(uuid.uuid4())[:8]
                conn.execute(
                    """INSERT INTO namespace_memories
                       (id, namespace_id, memory_id, content, category, created_at, updated_at, shared_by, shared_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (link_id, target_ns_id, mem_id, src["content"], src["category"],
                     src["created_at"], src["updated_at"], user_id, now),
                )
                conn.execute(
                    "INSERT INTO memory_sync_log (id, source_ns, target_ns, memory_id, action, synced_at) "
                    "VALUES (?, ?, ?, ?, 'add', ?)",
                    (str(uuid.uuid4())[:8], source_ns_id, target_ns_id, mem_id, now),
                )
                stats["added"] += 1
            else:
                # Last-write-wins conflict resolution
                target_entry = target_map[mem_id]
                if src["updated_at"] > target_entry["updated_at"]:
                    conn.execute(
                        """UPDATE namespace_memories
                           SET content = ?, category = ?, updated_at = ?
                           WHERE id = ?""",
                        (src["content"], src["category"], src["updated_at"], target_entry["id"]),
                    )
                    conn.execute(
                        "INSERT INTO memory_sync_log (id, source_ns, target_ns, memory_id, action, synced_at) "
                        "VALUES (?, ?, ?, ?, 'update', ?)",
                        (str(uuid.uuid4())[:8], source_ns_id, target_ns_id, mem_id, now),
                    )
                    stats["updated"] += 1
                else:
                    stats["skipped"] += 1

        conn.commit()
        return stats
    finally:
        conn.close()


def get_sync_status(
    source_ns_id: str,
    target_ns_id: str,
) -> dict:
    """Check if two namespaces are in sync.

    Compares memories in both namespaces and reports differences.

    Returns:
        Dict with:
        - in_sync: bool
        - source_only: count of memories only in source
        - target_only: count of memories only in target
        - conflicts: count of memories with different updated_at
        - last_sync: timestamp of last sync operation (or None)
    """
    conn = _get_federation_db()
    try:
        source_rows = conn.execute(
            "SELECT memory_id, updated_at FROM namespace_memories WHERE namespace_id = ?",
            (source_ns_id,),
        ).fetchall()
        target_rows = conn.execute(
            "SELECT memory_id, updated_at FROM namespace_memories WHERE namespace_id = ?",
            (target_ns_id,),
        ).fetchall()

        source_map = {r["memory_id"]: r["updated_at"] for r in source_rows}
        target_map = {r["memory_id"]: r["updated_at"] for r in target_rows}

        source_ids = set(source_map.keys())
        target_ids = set(target_map.keys())

        source_only = len(source_ids - target_ids)
        target_only = len(target_ids - source_ids)
        conflicts = 0
        for mid in source_ids & target_ids:
            if source_map[mid] != target_map[mid]:
                conflicts += 1

        # Get last sync timestamp
        last_sync_row = conn.execute(
            """SELECT MAX(synced_at) as last_sync
               FROM memory_sync_log
               WHERE (source_ns = ? AND target_ns = ?)
                  OR (source_ns = ? AND target_ns = ?)""",
            (source_ns_id, target_ns_id, target_ns_id, source_ns_id),
        ).fetchone()
        last_sync = last_sync_row["last_sync"] if last_sync_row else None

        in_sync = source_only == 0 and target_only == 0 and conflicts == 0

        return {
            "in_sync": in_sync,
            "source_only": source_only,
            "target_only": target_only,
            "conflicts": conflicts,
            "last_sync": last_sync,
        }
    finally:
        conn.close()
