"""FastAPI routes for federated memory management."""

import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from shared_state import verify_token, get_token, _get_user_id_from_request

from memories.federation import (
    create_namespace,
    list_namespaces,
    delete_namespace,
    get_namespace,
    grant_access,
    revoke_access,
    list_permissions,
    share_memory,
    search_federated,
    sync_memories,
    get_sync_status,
    get_namespace_memories,
)

logger = logging.getLogger(__name__)

federation_router = APIRouter(tags=["federation"])


# ---------------------------------------------------------------------------
# Auth helper
# ---------------------------------------------------------------------------

def _auth_check(request: Request):
    """Verify token and return user_id, or None + error response."""
    if not verify_token(get_token(request)):
        return None, JSONResponse({"error": "Unauthorized"}, status_code=401)
    user_id = _get_user_id_from_request(request)
    return user_id, None


# ---------------------------------------------------------------------------
# Namespace CRUD
# ---------------------------------------------------------------------------

@federation_router.post("/api/memories/namespaces")
async def api_create_namespace(request: Request):
    """Create a new namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

    name = body.get("name", "").strip()
    ns_type = body.get("type", "private")

    if not name:
        return JSONResponse({"error": "name is required"}, status_code=400)

    try:
        ns = create_namespace(name=name, ns_type=ns_type, owner_id=user_id)
        return JSONResponse(ns, status_code=201)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except Exception as e:
        if "UNIQUE" in str(e):
            return JSONResponse({"error": f"Namespace '{name}' already exists"}, status_code=409)
        logger.exception("Failed to create namespace")
        return JSONResponse({"error": "Internal server error"}, status_code=500)


@federation_router.get("/api/memories/namespaces")
async def api_list_namespaces(request: Request):
    """List namespaces accessible to the current user."""
    user_id, err = _auth_check(request)
    if err:
        return err

    namespaces = list_namespaces(user_id=user_id)
    return {"namespaces": namespaces}


@federation_router.delete("/api/memories/namespaces/{namespace_id}")
async def api_delete_namespace(namespace_id: str, request: Request):
    """Delete a namespace (owner only)."""
    user_id, err = _auth_check(request)
    if err:
        return err

    deleted = delete_namespace(namespace_id, user_id=user_id)
    if not deleted:
        return JSONResponse({"error": "Namespace not found or not authorized"}, status_code=404)
    return {"deleted": True}


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------

@federation_router.post("/api/memories/namespaces/{namespace_id}/permissions")
async def api_grant_access(namespace_id: str, request: Request):
    """Grant a user access to a namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

    target_user = body.get("user_id", "").strip()
    access_level = body.get("access_level", "read")

    if not target_user:
        return JSONResponse({"error": "user_id is required"}, status_code=400)

    try:
        perm = grant_access(
            namespace_id=namespace_id,
            target_user_id=target_user,
            access_level=access_level,
            granted_by=user_id,
        )
        return JSONResponse(perm, status_code=201)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except PermissionError as e:
        return JSONResponse({"error": str(e)}, status_code=403)


@federation_router.delete("/api/memories/namespaces/{namespace_id}/permissions/{target_user_id}")
async def api_revoke_access(namespace_id: str, target_user_id: str, request: Request):
    """Revoke a user's access to a namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    revoked = revoke_access(
        namespace_id=namespace_id,
        target_user_id=target_user_id,
        revoked_by=user_id,
    )
    if not revoked:
        return JSONResponse({"error": "Permission not found or not authorized"}, status_code=404)
    return {"revoked": True}


@federation_router.get("/api/memories/namespaces/{namespace_id}/permissions")
async def api_list_permissions(namespace_id: str, request: Request):
    """List all permissions for a namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    perms = list_permissions(namespace_id)
    return {"permissions": perms}


# ---------------------------------------------------------------------------
# Memory sharing
# ---------------------------------------------------------------------------

@federation_router.post("/api/memories/namespaces/{namespace_id}/share")
async def api_share_memory(namespace_id: str, request: Request):
    """Share a memory into a namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

    memory_id = body.get("memory_id", "").strip()
    content = body.get("content", "").strip()
    category = body.get("category", "fact")

    if not memory_id or not content:
        return JSONResponse({"error": "memory_id and content are required"}, status_code=400)

    try:
        result = share_memory(
            memory_id=memory_id,
            content=content,
            target_namespace_id=namespace_id,
            shared_by=user_id,
            category=category,
        )
        return JSONResponse(result, status_code=201)
    except PermissionError as e:
        return JSONResponse({"error": str(e)}, status_code=403)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@federation_router.get("/api/memories/namespaces/{namespace_id}/memories")
async def api_get_namespace_memories(namespace_id: str, request: Request):
    """Get all memories in a namespace."""
    user_id, err = _auth_check(request)
    if err:
        return err

    try:
        memories = get_namespace_memories(namespace_id, user_id=user_id)
        return {"memories": memories}
    except PermissionError as e:
        return JSONResponse({"error": str(e)}, status_code=403)


# ---------------------------------------------------------------------------
# Federated search
# ---------------------------------------------------------------------------

@federation_router.get("/api/memories/federated/search")
async def api_search_federated(request: Request, q: str = "", top_k: int = 10):
    """Search across all accessible namespaces."""
    user_id, err = _auth_check(request)
    if err:
        return err

    if not q.strip():
        return JSONResponse({"error": "Query parameter 'q' is required"}, status_code=400)

    results = search_federated(query=q, user_id=user_id, top_k=top_k)
    return {"results": results, "count": len(results)}


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------

@federation_router.post("/api/memories/namespaces/sync")
async def api_sync_memories(request: Request):
    """Sync memories between two namespaces."""
    user_id, err = _auth_check(request)
    if err:
        return err

    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON body"}, status_code=400)

    source_ns = body.get("source_namespace_id", "").strip()
    target_ns = body.get("target_namespace_id", "").strip()

    if not source_ns or not target_ns:
        return JSONResponse(
            {"error": "source_namespace_id and target_namespace_id are required"},
            status_code=400,
        )

    try:
        stats = sync_memories(source_ns_id=source_ns, target_ns_id=target_ns, user_id=user_id)
        return stats
    except PermissionError as e:
        return JSONResponse({"error": str(e)}, status_code=403)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@federation_router.get("/api/memories/namespaces/sync/status")
async def api_sync_status(request: Request, source: str = "", target: str = ""):
    """Check sync status between two namespaces."""
    user_id, err = _auth_check(request)
    if err:
        return err

    if not source or not target:
        return JSONResponse(
            {"error": "source and target query parameters are required"},
            status_code=400,
        )

    status = get_sync_status(source_ns_id=source, target_ns_id=target)
    return status
