from typing import List, Any, Tuple

from typing import Optional


def async_write_profile(seconds: int, file_path: str, image_width: int = 1200) -> None:
    ...


def init_tracing_log(directives: str = '', directory: str = '',
                     file_name_prefix: str = '') -> None:
    ...

def init_tracing_logs(directory: str = '', common_log: str='', common_level: str = '',
                     audit_log: str = '', audit_level: str = '') -> None:
    ...


class TosError(object):
    message: str
    status_code: Optional[int]
    ec: str
    request_id: str


class TosException(Exception):
    args: List[TosError]


class TosBucket(object):
    name: str
    bucket_type: str
    az_redundancy: str
    project_name: str


class TosObject(object):
    bucket: str
    key: str
    size: int
    etag: str
    crc64: int
    last_modified: Optional[str]
    object_type: str
    storage_class: Optional[str]


class TosInode(object):
    bucket: str
    key: str
    size: int
    etag: str
    crc64: int
    is_file: bool
    last_modified: Optional[str]


class ListObjectsResult(object):
    contents: List[TosObject]
    common_prefixes: List[str]


class ListStream(object):
    bucket: str
    prefix: str
    delimiter: str
    delimiter_recursive: bool
    max_keys: int
    continuation_token: str
    start_after: str
    list_background_buffer_count: int
    prefetch_concurrency: int

    def __iter__(self) -> ListStream: ...

    def __next__(self) -> Optional[Tuple[ListObjectsResult, Optional[ReadStream]]]: ...

    def close(self) -> None: ...

    def current_prefix(self) -> Optional[str]: ...

    def current_continuation_token(self) -> Optional[str]: ...


class WalkStream(object):
    bucket: str
    prefix: str
    max_keys: int
    max_depth: Optional[int]

    def __iter__(self) -> WalkStream: ...

    def __next__(self) -> Optional[Tuple[str, ListObjectsResult]]: ...

    def close(self) -> None: ...


class IteratorStream(object):
    local_files: List[str]
    list_background_buffer_count: int
    prefetch_concurrency: int

    def __iter__(self) -> ListStream: ...

    def __next__(self) -> Optional[Tuple[ListObjectsResult, Optional[ReadStream]]]: ...

    def close(self) -> None: ...


class ReadStream(object):
    bucket: str
    key: str

    def read(self, offset: int, length: int) -> Optional[bytes]:
        ...

    def close(self) -> None:
        ...

    def is_closed(self) -> bool:
        ...

    def etag(self) -> str:
        ...

    def size(self) -> int:
        ...

    def crc64(self) -> int:
        ...

    def fetch_etag_size_err(self) -> Optional[str]:
        ...


class WriteStream(object):
    bucket: str
    key: str
    storage_class: Optional[str]
    content_type: Optional[str]
    forbid_overwrite: bool

    def write(self, data: bytes) -> int:
        ...

    def close(self) -> None:
        ...

    def is_closed(self) -> bool:
        ...

    def flush(self, flush_to_remote: bool) -> None:
        ...

    def abort(self) -> None:
        ...


class TosClient(object):
    region: str
    endpoint: str
    ak: str
    sk: str
    part_size: int
    max_retry_count: int
    max_prefetch_tasks: int
    shared_prefetch_tasks: int
    enable_crc: bool
    max_upload_part_tasks: int
    shared_upload_part_tasks: int
    max_upload_part_copy_tasks: int
    shared_upload_part_copy_tasks: int
    connection_timeout: int
    request_timeout: int
    user_agent_conf: Optional[Tuple[str, str]]
    security_token: Optional[str]

    def __init__(self, region: str, endpoint: str, ak: str = '', sk: str = '', part_size: int = 8388608,
                 max_retry_count: int = 3, max_prefetch_tasks: int = 3, shared_prefetch_tasks: int = 32,
                 enable_crc: bool = True, max_upload_part_tasks: int = 3, shared_upload_part_tasks: int = 32,
                 dns_cache_async_refresh: bool = False, use_global_runtime: bool = False,
                 max_upload_part_copy_tasks: int = 3, shared_upload_part_copy_tasks: int = 32,
                 connection_timeout: int = 10000, request_timeout: int = 120000,
                 user_agent_conf: Optional[Tuple[str, str]] = None, security_token: Optional[str] = None):
        ...

    def list_objects(self, bucket: str, prefix: str = '', max_keys: int = 1000, delimiter: str = '',
                     continuation_token: str = '', start_after: str = '',
                     list_background_buffer_count: int = 1, prefetch_concurrency: int = 0,
                     distributed_info: Optional[Tuple[int, int, int, int]] = None,
                     fixed_part_size: bool = False, delimiter_recursive: bool = False) -> ListStream:
        ...

    def list_objects_from_local_files(self, local_files: List[str], max_keys: int = 1000,
                                      list_background_buffer_count: int = 1, prefetch_concurrency: int = 0,
                                      distributed_info: Optional[Tuple[int, int, int, int]] = None,
                                      fixed_part_size: bool = False) -> IteratorStream:
        ...

    def walk(self, bucket: str, prefix: str, max_keys: int = 1000, max_depth: Optional[int] = None) -> WalkStream:
        ...

    def lookup(self, bucket: str, key: str) -> Optional[TosInode]:
        ...

    def touch(self, bucket: str, key: str, content_type: Optional[str] = None) -> str:
        ...

    def mkdir(self, bucket: str, key: str, content_type: Optional[str] = None, create_parents: bool = False,
              check_exists: bool = False) -> str:
        ...

    def delete(self, bucket: str, key: str, recursive: bool = False) -> None:
        ...

    def copy(self, bucket: str, key: str, src_key: str, recursive: bool = False,
             copy_metadata: bool = False, src_bucket: Optional[str] = None, max_depth: Optional[int] = None, with_src_parent:bool = False) -> None:
        ...

    def rename(self, bucket: str, key: str, src_key: str, recursive: bool = False,
               copy_metadata: bool = False, src_bucket: Optional[str] = None) -> None:
        ...

    def list_buckets(self, project_name: Optional[str] = None, bucket_type: Optional[str] = None) -> List[TosBucket]:
        ...

    def create_bucket(self, bucket: str, bucket_type: Optional[str] = None) -> None:
        ...

    def delete_bucket(self, bucket: str) -> None:
        ...

    def head_bucket(self, bucket: str) -> TosBucket:
        ...

    def get_bucket_type(self, bucket: str) -> str:
        ...

    def head_object(self, bucket: str, key: str) -> TosObject:
        ...

    def batch_get_objects(self, objects: List[Tuple[str, str, Optional[str], Optional[int], Optional[int]]],
                          prefetch_concurrency: int = 0, fetch_etag_size: bool = False,
                          fixed_part_size: bool = False, read_part_size: Optional[int] = None) -> List[
        ReadStream]:
        ...

    def get_object(self, bucket: str, key: str, etag: Optional[str] = None, size: Optional[int] = None,
                   crc64: Optional[int] = None, preload: bool = False, fixed_part_size: bool = False,
                   with_sliding_window: bool = False, read_part_size: Optional[int] = None) -> ReadStream:
        ...

    def put_object(self, bucket: str, key: str, storage_class: Optional[str] = None,
                   write_part_size: Optional[int] = None, content_type: Optional[str] = None,
                   forbid_overwrite: bool = False) -> WriteStream:
        ...

    def append_object(self, bucket: str, key: str, etag: str, size: int, crc64: int,
                      storage_class: Optional[str] = None,
                      write_part_size: Optional[int] = None, content_type: Optional[str] = None,
                      forbid_overwrite: bool = False) -> WriteStream:
        ...

    def put_object_directly(self, bucket: str, key: str, content_type: Optional[str] = None,
                            storage_class: Optional[str] = None, data: Optional[bytes] = None,
                            forbid_overwrite: bool = False) -> None:
        ...

    def delete_object(self, bucket: str, key: str) -> None:
        ...

    def delete_folder(self, bucket: str, folder: str, recursive: bool = False) -> None:
        ...

    def close(self) -> None:
        ...
