from argparse import ArgumentParser

from .entrypoint import AGENTCORE_HOST, AGENTCORE_PORT, app

if __name__ == "__main__":
    parser = ArgumentParser()

    parser.add_argument(
        "--run",
        help="Run the application in the target environment",
        action="store_true",
        default=False,
    )

    args = parser.parse_args()

    if args.run:
        print(f"Starting app on {AGENTCORE_HOST}:{AGENTCORE_PORT}")  # noqa
        app.run(port=AGENTCORE_PORT, host=AGENTCORE_HOST)
