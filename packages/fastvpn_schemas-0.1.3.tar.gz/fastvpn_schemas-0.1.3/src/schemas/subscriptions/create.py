from datetime import datetime
from typing import Annotated, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, ValidationInfo, field_validator

from .base import SubscriptionBase, SubscriptionStatus


class SubscriptionCreate(SubscriptionBase):
    telegram_charge_id: Optional[str] = None
    current_period_start: datetime
    current_period_end: datetime

    status: SubscriptionStatus = SubscriptionStatus.ACTIVE
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None

    @field_validator("current_period_end")
    @classmethod
    def end_after_start(cls, v: datetime, info: ValidationInfo):
        start = info.data.get("current_period_start")

        if start and v <= start:
            raise ValueError("current_period_end must be after current_period_start")

        return v

    model_config = ConfigDict(
        from_attributes=True,
    )


class SubscriptionTrialCreate(BaseModel):
    user_id: UUID
    plan_id: UUID
    days: Annotated[int, Field(gt=0)]
