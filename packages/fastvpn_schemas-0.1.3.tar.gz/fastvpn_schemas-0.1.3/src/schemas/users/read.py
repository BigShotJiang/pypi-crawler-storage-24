from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import ConfigDict

from ..vpn.read import VpnAccountRead
from .base import UserBase


class UserRead(UserBase):
    id: UUID
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        from_attributes=True,
    )


class UserWithVpnRead(UserRead):
    vpn_account: Optional[VpnAccountRead] = None

    model_config = {
        "arbitrary_types_allowed": True,
    }
