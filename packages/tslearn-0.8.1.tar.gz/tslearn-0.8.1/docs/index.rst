.. raw:: html

    <style type="text/css">

    .thumbnail {
        position: relative;
        float: left;
        margin: 10px;
        width: 160px;
        height: 160px;
    }

    .thumbnail img {
        position: absolute;
        display: inline;
        left: 0;
        width: 150px;
        height: 150px;
    }

    </style>

|logo| ``tslearn``'s documentation
==================================

.. |logo| image:: _static/tslearn_logo_white_background.png
   :height: 50px

.. raw:: html

    <div style="clear: both"></div>
    <div class="container-fluid hidden-xs hidden-sm">
      <div class="row">
        <div class="col-md-2 thumbnail">
          <a href="auto_examples/metrics/plot_dtw.html">
            <img src="_static/img/dtw_thumb.png">
          </a>
        </div>
        <div class="col-md-2 thumbnail">
          <a href="auto_examples/clustering/plot_barycenter_interpolate.html">
            <img src="_static/img/bary_interp_thumb.png">
          </a>
        </div>
        <div class="col-md-2 thumbnail">
          <a href="auto_examples/clustering/plot_kmeans.html">
            <img src="_static/img/kmeans_thumb.png">
          </a>
        </div>
        <div class="col-md-2 thumbnail">
          <a href="auto_examples/misc/plot_sax.html">
            <img src="_static/img/sax_thumb.png">
          </a>
        </div>
      </div>
    </div>

``tslearn`` is a Python package that provides machine learning tools for the
analysis of time series.
This package builds on (and hence depends on) ``scikit-learn``, ``numpy`` and
``scipy`` libraries.

This documentation contains :doc:`a quick-start guide <quickstart>` (including
:doc:`installation procedure <installation>` and
:doc:`basic usage of the toolkit <gettingstarted>`),
:doc:`a complete API Reference <reference>`, as well as a
:doc:`gallery of examples <auto_examples/index>`.

Finally, if you use ``tslearn`` in a scientific publication,
:doc:`we would appreciate citations <citing>`.


.. toctree::
    :hidden:
    :maxdepth: 2

    quickstart
    user_guide/userguide
    reference
    auto_examples/index
    citing
