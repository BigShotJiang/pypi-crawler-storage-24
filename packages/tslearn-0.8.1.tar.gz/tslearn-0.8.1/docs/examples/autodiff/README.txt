Automatic differentiation
-------------------------

