"""The generic backend."""

from tslearn.backend.numpy_backend import NumPyBackend
from tslearn.backend.pytorch_backend import PyTorchBackend


def instantiate_backend(*args):
    """Select backend.

    Parameter
    ---------
    *args : Input arguments can be Backend instance or string or array or None
        Arguments used to define the backend instance.

    Returns
    -------
    backend : Backend instance
        The backend instance.
    """
    for arg in args:
        if isinstance(arg, Backend):
            return arg
        arg_string = (str(type(arg)) + str(arg)).lower()
        if "numpy" in arg_string:
            return Backend("numpy")
        if "torch" in arg_string:
            return Backend("pytorch")
    return Backend("numpy")


def select_backend(data):
    """Select backend.

    Parameter
    ---------
    data : array-like or string or None
        Indicates the backend to choose.
        Optional, default equals None.

    Returns
    -------
    backend : class
        The backend class.
        If data is a Numpy array or data equals 'numpy' or data is None,
        backend equals NumpyBackend().
        If data is a PyTorch array or data equals 'pytorch',
        backend equals PytorchBackend().
    """
    arg_string = (str(type(data)) + str(data)).lower()
    if "torch" in arg_string:
        return PyTorchBackend()
    return NumPyBackend()


class Backend(object):
    """Class for the  backend.

    Parameter
    ---------
    data : array-like or string or None
        Indicates the backend to choose.
        If data is a Numpy array or data equals 'numpy' or data is None,
        self.backend is set to NumpyBackend().
        If data is a PyTorch array or data equals 'pytorch',
        self.backend is set to PytorchBackend().
        Optional, default equals None.
    """

    def __init__(self, data=None):
        self.backend = select_backend(data)

    def __getattr__(self, item):
        # Forwards missing attribute calls to backend
        return getattr(self.backend, item)

    @property
    def is_numpy(self):
        return self.backend_string == "numpy"

    @property
    def is_pytorch(self):
        return self.backend_string == "pytorch"

    def get_backend(self):
        return self.backend

    def set_backend(self, data=None):
        self.backend = select_backend(data)


def cast(data, array_type="numpy"):
    """Cast data to list or specific backend.

    Parameters
    ----------
    data: array-like,
        The input data should be a list or numpy array or torch array.
        The data to cast.
    array_type: string
        The type to cast the data. It can be "numpy", "pytorch" or "list".

    Returns
    --------
    data_cast: array-like
        Data cast to array_type.
    """
    data_type_string = str(type(data)).lower()
    array_type = array_type.lower()
    if array_type == "pytorch":
        array_type = "torch"
    if array_type in data_type_string:
        return data
    if array_type == "list":
        return data.tolist()
    be = Backend(array_type)
    return be.array(data)
