from brehon_mcp_server.server import main
