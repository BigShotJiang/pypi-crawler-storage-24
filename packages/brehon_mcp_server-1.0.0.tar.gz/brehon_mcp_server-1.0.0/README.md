# brehon-mcp-server

**Privacy and AI regulation data for your AI assistant.**

Stop your AI from hallucinating privacy law requirements. Brehon gives Claude, Codex, Cursor, VS Code, and Open Code structured access to 32 privacy and AI governance laws across 28 jurisdictions — grounded in real regulatory data, not training data.

## Why?

When you ask an AI assistant "what privacy laws apply to my app in Brazil?", it answers from training data that might be outdated, incomplete, or wrong. Getting privacy compliance wrong means fines — GDPR alone goes up to 4% of global revenue.

Brehon fixes this. Your AI calls the Brehon API in real time and gets structured, current regulatory data.

## Quick Start

### 1. Get a free API key

```bash
curl -X POST https://api.brehon.dev/api/v1/keys \
  -H "Content-Type: application/json" \
  -d '{"name": "My App", "owner_email": "you@example.com"}'
```

Or sign up at [dashboard.brehon.dev](https://dashboard.brehon.dev/sign-up)

### 2. Add to your MCP client

**Claude Code**

```bash
claude mcp add --scope user brehon -e BREHON_API_KEY=your-api-key -- uvx brehon-mcp-server
```

**Claude Desktop**

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "brehon": {
      "command": "uvx",
      "args": ["brehon-mcp-server"],
      "env": {
        "BREHON_API_KEY": "your-api-key"
      }
    }
  }
}
```

**Codex**

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.brehon]
command = "uvx"
args = ["brehon-mcp-server"]

[mcp_servers.brehon.env]
BREHON_API_KEY = "your-api-key"
```

**Cursor**

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "brehon": {
      "command": "uvx",
      "args": ["brehon-mcp-server"],
      "env": {
        "BREHON_API_KEY": "your-api-key"
      }
    }
  }
}
```

**VS Code**

Add to `.vscode/settings.json`:

```json
{
  "mcp": {
    "servers": {
      "brehon": {
        "command": "uvx",
        "args": ["brehon-mcp-server"],
        "env": {
          "BREHON_API_KEY": "your-api-key"
        }
      }
    }
  }
}
```

**Open Code**

Add to `~/.opencode/mcp.json`:

```json
{
  "mcpServers": {
    "brehon": {
      "command": "uvx",
      "args": ["brehon-mcp-server"],
      "env": {
        "BREHON_API_KEY": "your-api-key"
      }
    }
  }
}
```

### 3. Ask a question

> "What privacy laws apply if I have users in Brazil and the EU?"

> "Compare GDPR and CCPA breach notification requirements"

> "What are the penalties for LGPD violations?"

## Environment Variables

| Variable | Required | Default |
|---|---|---|
| `BREHON_API_KEY` | Yes | — |
| `BREHON_API_BASE_URL` | No | `https://api.brehon.dev/api/v1` |

## Available Tools

| Tool | Description |
|------|-------------|
| `search_privacy_laws` | Filter laws by type, jurisdiction, or scope |
| `get_privacy_law_details` | Full details for a specific law |
| `get_data_subject_rights` | Data subject rights for a law |
| `get_legal_bases` | Legal bases for processing |
| `get_penalties` | Penalty and enforcement info |
| `compare_privacy_laws` | Compare requirements across multiple laws |
| `search_law_content` | Keyword search across all law content |
| `get_applicable_laws` | Find laws applicable to given jurisdictions |

## Coverage

32 laws across 28 jurisdictions:

**EU & UK** — GDPR, UK GDPR, DPA 2018, EU AI Act, Age-Appropriate Design Code

**North America** — CCPA, CPRA, PIPEDA, plus 12 US state laws (Virginia, Colorado, Connecticut, Texas, and more) and 3 Canadian provincial laws

**Asia-Pacific** — PIPL (China), DPDPA (India), APPI (Japan), PIPA (South Korea), PDPA (Singapore & Thailand), Privacy Act (Australia)

**Latin America & Africa** — LGPD (Brazil), POPIA (South Africa)

## Requirements

- Python 3.10+
- A free Brehon API key ([get one here](https://dashboard.brehon.dev/sign-up))

## REST API

Don't need MCP? The same data is available via REST API:

```bash
curl https://api.brehon.dev/api/v1/privacy-laws \
  -H "Authorization: Bearer YOUR_API_KEY"
```

Full API docs at [api.brehon.dev/docs](https://api.brehon.dev/docs)

## License

MIT
