from django.contrib.admin import DateFieldListFilter


class PastDateListFilter(DateFieldListFilter):
    def __init__(self, field, request, params, model, model_admin, field_path):
        super().__init__(field, request, params, model, model_admin, field_path)
        self.links = [
            (label, {self.lookup_kwarg_until: filters[self.lookup_kwarg_since]} if self.lookup_kwarg_until in filters else filters)
            for label, filters in self.links
        ]


class PrefetchRelatedAdminMixin:
    list_prefetch_related = ()

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if self.list_prefetch_related:
            return qs.prefetch_related(*self.list_prefetch_related)
        else:
            return qs
