from typing import List, Dict
from .base import BaseProvider

class OpenAIProvider(BaseProvider):
    def __init__(self, api_key: str, model: str = "gpt-4o"):
        super().__init__(api_key, model)

    def complete(self, messages: List[Dict], system_prompt: str = "") -> str:
        from openai import OpenAI
        client = OpenAI(api_key=self.api_key)
        full = ([{"role": "system", "content": system_prompt}] if system_prompt else []) + messages
        r = client.chat.completions.create(model=self.model, max_tokens=2048, messages=full)
        return r.choices[0].message.content
