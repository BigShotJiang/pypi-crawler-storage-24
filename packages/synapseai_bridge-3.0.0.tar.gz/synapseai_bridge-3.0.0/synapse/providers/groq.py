from typing import List, Dict
from .base import BaseProvider

class GroqProvider(BaseProvider):
    def __init__(self, api_key: str, model: str = "llama-3.3-70b-versatile"):
        super().__init__(api_key, model)

    def complete(self, messages: List[Dict], system_prompt: str = "") -> str:
        from groq import Groq
        client = Groq(api_key=self.api_key)
        full = ([{"role": "system", "content": system_prompt}] if system_prompt else []) + messages
        r = client.chat.completions.create(model=self.model, max_tokens=2048, messages=full)
        return r.choices[0].message.content
