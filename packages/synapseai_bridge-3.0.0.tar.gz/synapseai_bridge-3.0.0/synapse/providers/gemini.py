from typing import List, Dict
from .base import BaseProvider

class GeminiProvider(BaseProvider):
    def __init__(self, api_key: str, model: str = "gemini-1.5-flash"):
        super().__init__(api_key, model)

    def complete(self, messages: List[Dict], system_prompt: str = "") -> str:
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)
        m = genai.GenerativeModel(model_name=self.model, system_instruction=system_prompt or "You are a helpful assistant.")
        history = [{"role": "user" if msg["role"] == "user" else "model", "parts": [msg["content"]]} for msg in messages[:-1]]
        chat = m.start_chat(history=history)
        r = chat.send_message(messages[-1]["content"])
        return r.text
