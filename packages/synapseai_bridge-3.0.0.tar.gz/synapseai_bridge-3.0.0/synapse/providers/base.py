from abc import ABC, abstractmethod
from typing import List, Dict

class BaseProvider(ABC):
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    @abstractmethod
    def complete(self, messages: List[Dict], system_prompt: str = "") -> str:
        pass
