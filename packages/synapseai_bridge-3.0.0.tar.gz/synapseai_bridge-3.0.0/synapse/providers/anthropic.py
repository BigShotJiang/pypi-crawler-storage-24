from typing import List, Dict
from .base import BaseProvider

class AnthropicProvider(BaseProvider):
    def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514"):
        super().__init__(api_key, model)

    def complete(self, messages: List[Dict], system_prompt: str = "") -> str:
        import anthropic
        client = anthropic.Anthropic(api_key=self.api_key)
        r = client.messages.create(model=self.model, max_tokens=2048,
            system=system_prompt or "You are a helpful assistant.", messages=messages)
        return r.content[0].text
