# Synapse v3.0 — 180 features, one SDK

# Core (1-20)
from synapse.core.agent import Agent
from synapse.core.bridge import Bridge, BridgeResult, TraceStep
from synapse.core.card import AgentCard
from synapse.core.registry import Registry
from synapse.core.pool import AgentPool
from synapse.core.network import AgentServer, AgentClient

# Memory (61-80)
from synapse.memory.memory import Memory, GlobalMemory

# Protocol (21-40)
from synapse.protocol.protocol import Message, MessageQueue, PubSub, Broadcaster, BatchProcessor

# Tools (41-60)
from synapse.tools.tools import WebSearch, FileSystem, SQLDatabase, RestAPI, CodeExecutor, CustomTool

# DevEx (81-100)
from synapse.devex.devex import (
    DryRunAgent, MockAgent, Profiler, AgentTest,
    estimate_cost, count_tokens, load_env, load_config, agents_from_config
)

# Security (101-120)
from synapse.security.security import (
    APIKeyManager, JWTAuth, RBAC, RateLimiter, IPWhitelist,
    RequestSigner, AuditLogger, GDPRCompliance, DataAnonymizer, SecretScanner
)

# Performance (121-140)
from synapse.performance.performance import (
    AsyncBridge, ResponseCache, BackgroundTaskRunner,
    JobScheduler, AgentMetrics, stream_response
)

# Observability (141-160)
from synapse.observability.observability import (
    Dashboard, UptimeTracker, ThroughputMonitor, PrometheusExporter,
    LogAggregator, AlertSystem, Benchmark, ABTest
)

# Integrations (161-180)
from synapse.integrations.integrations import (
    LangChainAdapter, AutoGenAdapter, CrewAIAdapter, WebhookBridge,
    aws_lambda_handler, gcp_function_handler, azure_function_handler,
    generate_dockerfile, generate_docker_compose, create_rest_app,
    generate_cli_script, generate_github_action, jupyter_quickstart
)

# Providers
from synapse.providers import GroqProvider, OpenAIProvider, AnthropicProvider, GeminiProvider

__version__ = "3.0.0"
__author__ = "Synapse"
