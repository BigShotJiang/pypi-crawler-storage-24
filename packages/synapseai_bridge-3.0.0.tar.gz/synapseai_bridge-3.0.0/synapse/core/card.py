from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class AgentCard:
    """
    Feature 6: AgentCard — identity and profile for every agent.
    Inspired by Google A2A agent cards.
    """
    name: str
    description: str = ""
    skills: List[str] = field(default_factory=list)
    tools: List[str] = field(default_factory=list)
    provider: str = ""
    model: str = ""
    endpoint: Optional[str] = None
    version: str = "1.0.0"
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "skills": self.skills,
            "tools": self.tools,
            "provider": self.provider,
            "model": self.model,
            "endpoint": self.endpoint,
            "version": self.version,
            "created_at": self.created_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AgentCard":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def __repr__(self):
        return f"AgentCard(name={self.name!r}, provider={self.provider!r}, skills={self.skills})"
