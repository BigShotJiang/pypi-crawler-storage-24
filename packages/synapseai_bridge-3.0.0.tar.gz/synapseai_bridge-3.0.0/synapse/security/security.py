"""
Feature 101: API key management
Feature 102: Agent authentication (JWT tokens)
Feature 103: Role-based access control (RBAC)
Feature 104: Rate limiting per agent
Feature 105: IP whitelisting
Feature 106: Request signing
Feature 107: Audit logging
Feature 108: GDPR compliance tools
Feature 109: Data anonymization
Feature 110: Secret scanning
"""
import os
import re
import time
import hmac
import json
import hashlib
import secrets
import logging
from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta
from functools import wraps


# ─── Feature 101: API Key Management ──────────────────────────────────────────
class APIKeyManager:
    """Manage and validate API keys for agents."""

    def __init__(self):
        self._keys: Dict[str, dict] = {}

    def generate(self, name: str, scopes: List[str] = None, expires_in_days: int = 30) -> str:
        key = f"syn-{secrets.token_urlsafe(32)}"
        self._keys[key] = {
            "name": name,
            "scopes": scopes or ["read", "write"],
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(days=expires_in_days)).isoformat(),
            "active": True,
        }
        return key

    def validate(self, key: str, required_scope: str = None) -> bool:
        entry = self._keys.get(key)
        if not entry or not entry["active"]:
            return False
        if datetime.utcnow().isoformat() > entry["expires_at"]:
            entry["active"] = False
            return False
        if required_scope and required_scope not in entry["scopes"]:
            return False
        return True

    def revoke(self, key: str):
        if key in self._keys:
            self._keys[key]["active"] = False

    def list_keys(self) -> List[dict]:
        return [{"key": k[:12] + "...", **v} for k, v in self._keys.items()]


# ─── Feature 102: JWT Authentication ──────────────────────────────────────────
class JWTAuth:
    """Simple JWT-style token auth for agent-to-agent communication."""

    def __init__(self, secret: str = None):
        self.secret = secret or secrets.token_hex(32)

    def create_token(self, agent_name: str, expires_in: int = 3600) -> str:
        payload = {
            "agent": agent_name,
            "iat": int(time.time()),
            "exp": int(time.time()) + expires_in,
        }
        payload_str = json.dumps(payload, sort_keys=True)
        payload_b64 = payload_str.encode().hex()
        sig = hmac.new(self.secret.encode(), payload_b64.encode(), hashlib.sha256).hexdigest()
        return f"{payload_b64}.{sig}"

    def verify_token(self, token: str) -> Optional[dict]:
        try:
            payload_b64, sig = token.rsplit(".", 1)
            expected = hmac.new(self.secret.encode(), payload_b64.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(sig, expected):
                return None
            payload = json.loads(bytes.fromhex(payload_b64).decode())
            if int(time.time()) > payload["exp"]:
                return None
            return payload
        except Exception:
            return None


# ─── Feature 103: Role-Based Access Control ───────────────────────────────────
class RBAC:
    """Control which agents can do what."""

    def __init__(self):
        self._roles: Dict[str, Set[str]] = {
            "admin":    {"read", "write", "execute", "delete", "manage"},
            "agent":    {"read", "write", "execute"},
            "readonly": {"read"},
        }
        self._assignments: Dict[str, str] = {}

    def assign_role(self, agent_name: str, role: str):
        if role not in self._roles:
            raise ValueError(f"Unknown role '{role}'. Available: {list(self._roles.keys())}")
        self._assignments[agent_name] = role

    def can(self, agent_name: str, permission: str) -> bool:
        role = self._assignments.get(agent_name, "agent")
        return permission in self._roles.get(role, set())

    def add_role(self, role: str, permissions: Set[str]):
        self._roles[role] = permissions

    def get_role(self, agent_name: str) -> str:
        return self._assignments.get(agent_name, "agent")


# ─── Feature 104: Rate Limiting ───────────────────────────────────────────────
class RateLimiter:
    """Token bucket rate limiter per agent."""

    def __init__(self, max_calls: int = 60, window_seconds: int = 60):
        self.max_calls = max_calls
        self.window = window_seconds
        self._buckets: Dict[str, List[float]] = {}

    def is_allowed(self, agent_name: str) -> bool:
        now = time.time()
        if agent_name not in self._buckets:
            self._buckets[agent_name] = []
        bucket = self._buckets[agent_name]
        # Remove old timestamps
        self._buckets[agent_name] = [t for t in bucket if now - t < self.window]
        if len(self._buckets[agent_name]) >= self.max_calls:
            return False
        self._buckets[agent_name].append(now)
        return True

    def remaining(self, agent_name: str) -> int:
        now = time.time()
        bucket = self._buckets.get(agent_name, [])
        recent = [t for t in bucket if now - t < self.window]
        return max(0, self.max_calls - len(recent))

    def reset(self, agent_name: str):
        self._buckets.pop(agent_name, None)


# ─── Feature 105: IP Whitelisting ─────────────────────────────────────────────
class IPWhitelist:
    """Allow only specific IPs to communicate."""

    def __init__(self, allowed_ips: List[str] = None):
        self._allowed: Set[str] = set(allowed_ips or ["127.0.0.1", "localhost"])

    def allow(self, ip: str):
        self._allowed.add(ip)

    def deny(self, ip: str):
        self._allowed.discard(ip)

    def is_allowed(self, ip: str) -> bool:
        return ip in self._allowed

    def list(self) -> List[str]:
        return list(self._allowed)


# ─── Feature 106: Request Signing ─────────────────────────────────────────────
class RequestSigner:
    """Sign requests between agents to prevent tampering."""

    def __init__(self, secret: str = None):
        self.secret = secret or secrets.token_hex(16)

    def sign(self, payload: dict) -> str:
        body = json.dumps(payload, sort_keys=True)
        return hmac.new(self.secret.encode(), body.encode(), hashlib.sha256).hexdigest()

    def verify(self, payload: dict, signature: str) -> bool:
        expected = self.sign(payload)
        return hmac.compare_digest(expected, signature)


# ─── Feature 107: Audit Logging ───────────────────────────────────────────────
class AuditLogger:
    """Log all agent actions for compliance and debugging."""

    def __init__(self, log_file: str = None):
        self._events: List[dict] = []
        self.log_file = log_file
        if log_file:
            logging.basicConfig(filename=log_file, level=logging.INFO)

    def log(self, agent: str, action: str, details: dict = None):
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": agent,
            "action": action,
            "details": details or {},
        }
        self._events.append(event)
        if self.log_file:
            logging.info(json.dumps(event))

    def get_events(self, agent: str = None, action: str = None) -> List[dict]:
        events = self._events
        if agent:
            events = [e for e in events if e["agent"] == agent]
        if action:
            events = [e for e in events if e["action"] == action]
        return events

    def export(self) -> str:
        return json.dumps(self._events, indent=2)

    def clear(self):
        self._events = []


# ─── Feature 108: GDPR Compliance ─────────────────────────────────────────────
class GDPRCompliance:
    """Tools for GDPR compliance — right to be forgotten, data export."""

    def __init__(self, memory=None):
        self.memory = memory

    def export_user_data(self, user_id: str) -> dict:
        """Right to data portability."""
        data = {"user_id": user_id, "exported_at": datetime.utcnow().isoformat(), "data": []}
        if self.memory:
            msgs = self.memory.search(user_id)
            data["data"] = msgs
        return data

    def forget_user(self, user_id: str) -> int:
        """Right to be forgotten — remove all data containing user_id."""
        if not self.memory:
            return 0
        before = len(self.memory._short_term)
        self.memory._short_term = [
            m for m in self.memory._short_term
            if user_id not in m.get("content", "")
        ]
        return before - len(self.memory._short_term)


# ─── Feature 109: Data Anonymization ──────────────────────────────────────────
class DataAnonymizer:
    """Anonymize PII in agent messages."""

    PATTERNS = {
        "email":   (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', "[EMAIL]"),
        "phone":   (r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', "[PHONE]"),
        "ssn":     (r'\b\d{3}-\d{2}-\d{4}\b', "[SSN]"),
        "credit":  (r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b', "[CREDIT_CARD]"),
        "ip":      (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', "[IP_ADDRESS]"),
    }

    def anonymize(self, text: str, types: List[str] = None) -> str:
        patterns = {k: v for k, v in self.PATTERNS.items() if not types or k in types}
        for _, (pattern, replacement) in patterns.items():
            text = re.sub(pattern, replacement, text)
        return text

    def anonymize_messages(self, messages: List[dict]) -> List[dict]:
        return [{"role": m["role"], "content": self.anonymize(m["content"])} for m in messages]


# ─── Feature 110: Secret Scanning ─────────────────────────────────────────────
class SecretScanner:
    """Detect leaked API keys and secrets in agent messages."""

    PATTERNS = {
        "openai_key":    r'sk-[A-Za-z0-9]{48}',
        "anthropic_key": r'sk-ant-[A-Za-z0-9\-_]{90,}',
        "groq_key":      r'gsk_[A-Za-z0-9]{52}',
        "generic_key":   r'[A-Za-z0-9]{32,}',
        "aws_key":       r'AKIA[0-9A-Z]{16}',
    }

    def scan(self, text: str) -> List[dict]:
        findings = []
        for name, pattern in self.PATTERNS.items():
            matches = re.findall(pattern, text)
            for match in matches:
                findings.append({
                    "type": name,
                    "value": match[:8] + "...",
                    "severity": "HIGH" if "key" in name else "MEDIUM",
                })
        return findings

    def has_secrets(self, text: str) -> bool:
        for pattern in self.PATTERNS.values():
            if re.search(pattern, text):
                return True
        return False

    def redact(self, text: str) -> str:
        for pattern in self.PATTERNS.values():
            text = re.sub(pattern, "[REDACTED]", text)
        return text
