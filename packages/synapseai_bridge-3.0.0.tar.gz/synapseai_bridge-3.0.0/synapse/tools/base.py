from abc import ABC, abstractmethod


class BaseTool(ABC):
    """Base class for all Synapse tools (MCP-style connectors)."""
    name: str = ""
    description: str = ""

    @abstractmethod
    def run(self, input: str) -> str:
        pass

    def __repr__(self):
        return f"Tool(name={self.name!r})"
