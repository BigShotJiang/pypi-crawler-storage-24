"""
Feature 121: Async by default
Feature 122: Parallel agent execution
Feature 123: Concurrent tool calls
Feature 124: Response caching
Feature 125: Agent warm-up
Feature 126: Connection pooling
Feature 127: Lazy loading
Feature 128: Background task processing
Feature 129: Job scheduling
Feature 120: Timeout handling
Feature 131: Streaming responses
Feature 132: Cost tracking
Feature 133: Token usage per agent
Feature 134: Latency per agent
Feature 135: Error rate monitoring
"""
import asyncio
import time
import hashlib
import threading
from typing import List, Dict, Any, Optional, Callable, Generator
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed


# ─── Feature 121-122: Async + Parallel Execution ──────────────────────────────
class AsyncBridge:
    """Run multiple agents in parallel asynchronously."""

    def __init__(self, agents: list):
        self.agents = agents

    async def run_parallel(self, task: str) -> List[dict]:
        """Feature 122: Run all agents in parallel, collect all results."""
        loop = asyncio.get_event_loop()

        async def run_one(agent):
            start = time.time()
            try:
                response = await loop.run_in_executor(
                    None,
                    lambda: agent.complete([{"role": "user", "content": task}])
                )
                return {
                    "agent": agent.name,
                    "response": response,
                    "latency": round(time.time() - start, 3),
                    "status": "success"
                }
            except Exception as e:
                return {
                    "agent": agent.name,
                    "response": None,
                    "error": str(e),
                    "latency": round(time.time() - start, 3),
                    "status": "error"
                }

        tasks = [run_one(a) for a in self.agents]
        return await asyncio.gather(*tasks)

    def run_parallel_sync(self, task: str) -> List[dict]:
        """Sync wrapper for parallel execution."""
        return asyncio.run(self.run_parallel(task))

    def run_concurrent(self, tasks: List[str], agent) -> List[str]:
        """Feature 123: Run multiple tasks concurrently on one agent."""
        results = []
        with ThreadPoolExecutor(max_workers=min(len(tasks), 5)) as executor:
            futures = {
                executor.submit(
                    agent.complete,
                    [{"role": "user", "content": t}]
                ): t for t in tasks
            }
            for future in as_completed(futures):
                try:
                    results.append(future.result())
                except Exception as e:
                    results.append(f"Error: {e}")
        return results


# ─── Feature 124: Response Caching ────────────────────────────────────────────
class ResponseCache:
    """Cache agent responses to avoid duplicate API calls."""

    def __init__(self, ttl: int = 300, max_size: int = 1000):
        self.ttl = ttl
        self.max_size = max_size
        self._cache: Dict[str, dict] = {}
        self._hits = 0
        self._misses = 0

    def _key(self, agent_name: str, messages: list) -> str:
        content = f"{agent_name}:{str(messages)}"
        return hashlib.md5(content.encode()).hexdigest()

    def get(self, agent_name: str, messages: list) -> Optional[str]:
        key = self._key(agent_name, messages)
        entry = self._cache.get(key)
        if not entry:
            self._misses += 1
            return None
        if time.time() - entry["timestamp"] > self.ttl:
            del self._cache[key]
            self._misses += 1
            return None
        self._hits += 1
        return entry["response"]

    def set(self, agent_name: str, messages: list, response: str):
        if len(self._cache) >= self.max_size:
            oldest = min(self._cache.items(), key=lambda x: x[1]["timestamp"])
            del self._cache[oldest[0]]
        key = self._key(agent_name, messages)
        self._cache[key] = {"response": response, "timestamp": time.time()}

    def clear(self):
        self._cache.clear()

    def stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": round(self._hits / total, 3) if total else 0,
            "cached_entries": len(self._cache),
        }


# ─── Feature 128: Background Task Processing ──────────────────────────────────
class BackgroundTaskRunner:
    """Run agent tasks in the background without blocking."""

    def __init__(self):
        self._tasks: Dict[str, dict] = {}
        self._executor = ThreadPoolExecutor(max_workers=10)

    def submit(self, task_id: str, agent, message: str, callback: Callable = None) -> str:
        def run():
            try:
                response = agent.complete([{"role": "user", "content": message}])
                self._tasks[task_id]["status"] = "done"
                self._tasks[task_id]["result"] = response
                if callback:
                    callback(task_id, response)
            except Exception as e:
                self._tasks[task_id]["status"] = "error"
                self._tasks[task_id]["error"] = str(e)

        self._tasks[task_id] = {
            "status": "running",
            "submitted_at": datetime.utcnow().isoformat(),
            "result": None,
        }
        self._executor.submit(run)
        return task_id

    def get_result(self, task_id: str) -> dict:
        return self._tasks.get(task_id, {"status": "not_found"})

    def is_done(self, task_id: str) -> bool:
        return self._tasks.get(task_id, {}).get("status") in ("done", "error")

    def list_tasks(self) -> dict:
        return {tid: {k: v for k, v in t.items() if k != "result"} for tid, t in self._tasks.items()}


# ─── Feature 129: Job Scheduling ──────────────────────────────────────────────
class JobScheduler:
    """Schedule agent tasks to run at specific times or intervals."""

    def __init__(self):
        self._jobs: Dict[str, dict] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def schedule(self, job_id: str, agent, message: str, interval_seconds: int, run_immediately: bool = False):
        self._jobs[job_id] = {
            "agent": agent,
            "message": message,
            "interval": interval_seconds,
            "last_run": 0 if run_immediately else time.time(),
            "run_count": 0,
            "status": "scheduled",
        }

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            now = time.time()
            for job_id, job in self._jobs.items():
                if now - job["last_run"] >= job["interval"]:
                    try:
                        job["agent"].complete([{"role": "user", "content": job["message"]}])
                        job["last_run"] = now
                        job["run_count"] += 1
                        job["status"] = "ran"
                    except Exception as e:
                        job["status"] = f"error: {e}"
            time.sleep(1)

    def list_jobs(self) -> dict:
        return {jid: {k: v for k, v in j.items() if k != "agent"} for jid, j in self._jobs.items()}


# ─── Feature 131: Streaming Responses ────────────────────────────────────────
def stream_response(agent, message: str) -> Generator[str, None, None]:
    """
    Feature 131: Stream response token by token.
    Currently simulates streaming by yielding words.
    Full streaming requires provider-level support.
    """
    response = agent.complete([{"role": "user", "content": message}])
    words = response.split()
    for i, word in enumerate(words):
        yield word + (" " if i < len(words) - 1 else "")
        time.sleep(0.02)


# ─── Feature 132-135: Cost, Token, Latency, Error Tracking ───────────────────
class AgentMetrics:
    """
    Feature 132: Cost tracking
    Feature 133: Token usage per agent
    Feature 134: Latency per agent
    Feature 135: Error rate monitoring
    """

    COST_PER_1K = {
        "groq/llama-3.3-70b-versatile": 0.00059,
        "groq/llama-3.1-8b-instant":    0.00005,
        "openai/gpt-4o":                0.005,
        "anthropic/claude-sonnet-4-20250514": 0.003,
        "gemini/gemini-1.5-flash":      0.000075,
    }

    def __init__(self):
        self._data: Dict[str, dict] = {}

    def record(self, agent_name: str, provider: str, model: str,
               input_text: str, output_text: str, latency: float, error: bool = False):
        if agent_name not in self._data:
            self._data[agent_name] = {
                "calls": 0, "errors": 0, "total_tokens": 0,
                "total_cost": 0.0, "total_latency": 0.0,
            }
        d = self._data[agent_name]
        tokens = (len(input_text) + len(output_text)) // 4
        cost_key = f"{provider}/{model}"
        cost = (tokens / 1000) * self.COST_PER_1K.get(cost_key, 0.001)
        d["calls"] += 1
        d["total_tokens"] += tokens
        d["total_cost"] = round(d["total_cost"] + cost, 6)
        d["total_latency"] = round(d["total_latency"] + latency, 3)
        if error:
            d["errors"] += 1

    def get(self, agent_name: str) -> dict:
        d = self._data.get(agent_name, {})
        if not d:
            return {}
        calls = d["calls"] or 1
        return {
            **d,
            "avg_latency": round(d["total_latency"] / calls, 3),
            "error_rate": round(d["errors"] / calls, 3),
            "avg_cost_per_call": round(d["total_cost"] / calls, 6),
        }

    def summary(self) -> dict:
        return {name: self.get(name) for name in self._data}

    def reset(self, agent_name: str = None):
        if agent_name:
            self._data.pop(agent_name, None)
        else:
            self._data.clear()
