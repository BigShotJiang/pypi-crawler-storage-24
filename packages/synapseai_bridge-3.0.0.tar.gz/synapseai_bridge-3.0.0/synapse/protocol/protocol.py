import uuid, time, json, zlib, asyncio
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime
from queue import PriorityQueue, Empty

class Message:
    def __init__(self, content, from_agent="user", to_agent="auto", msg_type="task", priority=5, ttl=None, metadata=None):
        self.id = str(uuid.uuid4())
        self.content = content
        self.from_agent = from_agent
        self.to_agent = to_agent
        self.msg_type = msg_type
        self.priority = priority
        self.ttl = ttl
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow().isoformat()
        self._created_at = time.time()
        self.acknowledged = False
        self.retry_count = 0
    def is_expired(self):
        return bool(self.ttl) and time.time() - self._created_at > self.ttl
    def acknowledge(self): self.acknowledged = True
    def compress(self): return zlib.compress(self.content.encode("utf-8"))
    @staticmethod
    def decompress(data): return zlib.decompress(data).decode("utf-8")
    def to_dict(self):
        return {"id":self.id,"content":self.content,"from":self.from_agent,"to":self.to_agent,"type":self.msg_type,"priority":self.priority,"timestamp":self.timestamp}
    def __lt__(self, other): return self.priority < other.priority
    def __repr__(self): return f"Message(id={self.id[:8]}, from={self.from_agent!r})"

class MessageQueue:
    def __init__(self, max_size=1000):
        self._queue = PriorityQueue(maxsize=max_size)
        self._seen_ids = set()
        self._dead_letter = []
    def put(self, message):
        if message.id in self._seen_ids: return False
        self._seen_ids.add(message.id)
        if message.is_expired(): self._dead_letter.append(message); return False
        self._queue.put((message.priority, message)); return True
    def get(self, timeout=1.0):
        try:
            _, msg = self._queue.get(timeout=timeout)
            if msg.is_expired(): self._dead_letter.append(msg); return None
            return msg
        except Empty: return None
    def dead_letters(self): return self._dead_letter.copy()
    def size(self): return self._queue.qsize()

class PubSub:
    def __init__(self): self._subscribers = {}
    def subscribe(self, topic, callback):
        self._subscribers.setdefault(topic, []).append(callback)
    def unsubscribe(self, topic, callback):
        if topic in self._subscribers: self._subscribers[topic].remove(callback)
    def publish(self, topic, message):
        return [cb(message) for cb in self._subscribers.get(topic, [])]
    def broadcast(self, message):
        results = []
        for topic in self._subscribers: results.extend(self.publish(topic, message))
        return results
    def topics(self): return list(self._subscribers.keys())

class Broadcaster:
    def __init__(self): self._handlers = {}
    def register(self, agent_name, handler): self._handlers[agent_name] = handler
    async def send(self, message):
        handler = self._handlers.get(message.to_agent)
        if not handler: raise ValueError(f"No handler for '{message.to_agent}'")
        if asyncio.iscoroutinefunction(handler): return await handler(message)
        return handler(message)
    async def batch_send(self, messages):
        return await asyncio.gather(*[self.send(m) for m in messages], return_exceptions=True)


class BatchProcessor:
    """Process multiple messages in batches."""
    def __init__(self, agent, batch_size: int = 5):
        self.agent = agent
        self.batch_size = batch_size

    def process_batch(self, messages):
        responses = []
        for i in range(0, len(messages), self.batch_size):
            batch = messages[i:i + self.batch_size]
            for msg in batch:
                try:
                    responses.append(self.agent.complete([{"role": "user", "content": msg}]))
                except Exception as e:
                    responses.append(f"Error: {e}")
        return responses
