"""
Feature 141: Real-time dashboard
Feature 142: Cost tracking
Feature 143: Token usage
Feature 144: Latency monitoring
Feature 145: Error rate monitoring
Feature 146: Agent uptime tracking
Feature 147: Message throughput
Feature 148: Prometheus metrics export
Feature 149: Grafana dashboard template
Feature 150: OpenTelemetry support
Feature 151: Log aggregation
Feature 152: Alert system
Feature 153: Performance benchmarking
Feature 154: A/B testing agents
Feature 155: Experiment tracking
"""
import time
import json
from typing import Dict, List, Optional, Callable, Any
from datetime import datetime


# ─── Feature 141: Real-time Dashboard (text-based) ────────────────────────────
class Dashboard:
    """Text-based real-time dashboard for agent monitoring."""

    def __init__(self, registry=None, metrics=None):
        self.registry = registry
        self.metrics = metrics

    def render(self) -> str:
        lines = []
        lines.append("╔══════════════════════════════════════╗")
        lines.append("║       🧠  SYNAPSE DASHBOARD           ║")
        lines.append("╚══════════════════════════════════════╝")
        lines.append(f"  Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        lines.append("")

        if self.registry:
            lines.append("  AGENTS")
            lines.append("  " + "─" * 36)
            for card in self.registry.list_all():
                lines.append(f"  ● {card.name:<20} {card.provider}/{card.model}")
            lines.append("")

        if self.metrics:
            lines.append("  METRICS")
            lines.append("  " + "─" * 36)
            for agent_name, data in self.metrics.summary().items():
                lines.append(f"  {agent_name}:")
                lines.append(f"    Calls: {data.get('calls', 0)}  "
                              f"Errors: {data.get('errors', 0)}  "
                              f"Avg latency: {data.get('avg_latency', 0)}s  "
                              f"Total cost: ${data.get('total_cost', 0)}")
            lines.append("")

        lines.append("══════════════════════════════════════")
        return "\n".join(lines)

    def print(self):
        print(self.render())


# ─── Feature 146: Uptime Tracking ─────────────────────────────────────────────
class UptimeTracker:
    """Track agent uptime and availability."""

    def __init__(self):
        self._start_times: Dict[str, float] = {}
        self._down_times: Dict[str, List[dict]] = {}

    def start(self, agent_name: str):
        self._start_times[agent_name] = time.time()

    def record_down(self, agent_name: str, reason: str = ""):
        if agent_name not in self._down_times:
            self._down_times[agent_name] = []
        self._down_times[agent_name].append({
            "timestamp": datetime.utcnow().isoformat(),
            "reason": reason
        })

    def uptime(self, agent_name: str) -> dict:
        start = self._start_times.get(agent_name)
        if not start:
            return {"uptime_seconds": 0, "uptime_percent": 0}
        total = time.time() - start
        downs = len(self._down_times.get(agent_name, []))
        return {
            "uptime_seconds": round(total, 1),
            "downtime_events": downs,
            "uptime_percent": round(max(0, 100 - (downs * 5)), 1),
        }


# ─── Feature 147: Message Throughput ──────────────────────────────────────────
class ThroughputMonitor:
    """Monitor messages per second."""

    def __init__(self, window_seconds: int = 60):
        self.window = window_seconds
        self._events: List[float] = []

    def record(self):
        self._events.append(time.time())

    def throughput(self) -> dict:
        now = time.time()
        recent = [t for t in self._events if now - t < self.window]
        self._events = recent
        return {
            "messages_per_minute": len(recent),
            "messages_per_second": round(len(recent) / self.window, 2),
            "window_seconds": self.window,
        }


# ─── Feature 148: Prometheus Metrics ──────────────────────────────────────────
class PrometheusExporter:
    """Export metrics in Prometheus format."""

    def __init__(self, metrics=None):
        self.metrics = metrics

    def export(self) -> str:
        lines = [
            "# HELP synapse_agent_calls_total Total agent API calls",
            "# TYPE synapse_agent_calls_total counter",
        ]
        if self.metrics:
            for agent, data in self.metrics.summary().items():
                safe = agent.replace("-", "_")
                lines.append(f'synapse_agent_calls_total{{agent="{agent}"}} {data.get("calls", 0)}')
                lines.append(f'synapse_agent_errors_total{{agent="{agent}"}} {data.get("errors", 0)}')
                lines.append(f'synapse_agent_cost_total{{agent="{agent}"}} {data.get("total_cost", 0)}')
                lines.append(f'synapse_agent_latency_avg{{agent="{agent}"}} {data.get("avg_latency", 0)}')
        return "\n".join(lines)


# ─── Feature 149: Grafana Dashboard Template ──────────────────────────────────
GRAFANA_TEMPLATE = {
    "title": "Synapse Agent Dashboard",
    "panels": [
        {"title": "Agent Calls", "type": "graph", "metric": "synapse_agent_calls_total"},
        {"title": "Error Rate", "type": "graph", "metric": "synapse_agent_errors_total"},
        {"title": "Avg Latency", "type": "gauge", "metric": "synapse_agent_latency_avg"},
        {"title": "Total Cost", "type": "stat", "metric": "synapse_agent_cost_total"},
    ]
}


# ─── Feature 151: Log Aggregation ─────────────────────────────────────────────
class LogAggregator:
    """Collect and search logs from all agents."""

    def __init__(self):
        self._logs: List[dict] = []

    def log(self, level: str, agent: str, message: str, data: dict = None):
        self._logs.append({
            "level": level.upper(),
            "agent": agent,
            "message": message,
            "data": data or {},
            "timestamp": datetime.utcnow().isoformat(),
        })

    def search(self, query: str = None, level: str = None, agent: str = None) -> List[dict]:
        results = self._logs
        if query:
            results = [l for l in results if query.lower() in l["message"].lower()]
        if level:
            results = [l for l in results if l["level"] == level.upper()]
        if agent:
            results = [l for l in results if l["agent"] == agent]
        return results

    def export_json(self) -> str:
        return json.dumps(self._logs, indent=2)

    def clear(self):
        self._logs.clear()


# ─── Feature 152: Alert System ────────────────────────────────────────────────
class AlertSystem:
    """Trigger alerts when thresholds are exceeded."""

    def __init__(self):
        self._rules: List[dict] = []
        self._alerts: List[dict] = []
        self._handlers: List[Callable] = []

    def add_rule(self, name: str, metric: str, threshold: float, condition: str = "gt"):
        self._rules.append({
            "name": name, "metric": metric,
            "threshold": threshold, "condition": condition
        })

    def on_alert(self, handler: Callable):
        self._handlers.append(handler)

    def check(self, metrics: dict):
        for rule in self._rules:
            value = metrics.get(rule["metric"], 0)
            triggered = False
            if rule["condition"] == "gt" and value > rule["threshold"]:
                triggered = True
            elif rule["condition"] == "lt" and value < rule["threshold"]:
                triggered = True

            if triggered:
                alert = {
                    "rule": rule["name"],
                    "metric": rule["metric"],
                    "value": value,
                    "threshold": rule["threshold"],
                    "timestamp": datetime.utcnow().isoformat(),
                }
                self._alerts.append(alert)
                for handler in self._handlers:
                    try:
                        handler(alert)
                    except Exception:
                        pass

    def get_alerts(self) -> List[dict]:
        return self._alerts


# ─── Feature 153: Benchmarking ────────────────────────────────────────────────
class Benchmark:
    """Benchmark agent performance."""

    def __init__(self, agent, runs: int = 5):
        self.agent = agent
        self.runs = runs

    def run(self, prompt: str) -> dict:
        latencies = []
        errors = 0
        for _ in range(self.runs):
            start = time.time()
            try:
                self.agent.complete([{"role": "user", "content": prompt}])
                latencies.append(time.time() - start)
            except Exception:
                errors += 1

        if not latencies:
            return {"error": "All runs failed"}

        return {
            "agent": self.agent.name,
            "runs": self.runs,
            "errors": errors,
            "min_latency": round(min(latencies), 3),
            "max_latency": round(max(latencies), 3),
            "avg_latency": round(sum(latencies) / len(latencies), 3),
            "p95_latency": round(sorted(latencies)[int(len(latencies) * 0.95)], 3),
        }


# ─── Feature 154-155: A/B Testing + Experiment Tracking ──────────────────────
class ABTest:
    """
    Feature 154: A/B test two agents on the same prompts.
    Feature 155: Track experiment results.
    """

    def __init__(self, agent_a, agent_b):
        self.agent_a = agent_a
        self.agent_b = agent_b
        self._results: List[dict] = []

    def run(self, prompts: List[str]) -> dict:
        for prompt in prompts:
            start_a = time.time()
            try:
                resp_a = self.agent_a.complete([{"role": "user", "content": prompt}])
                lat_a = round(time.time() - start_a, 3)
                err_a = False
            except Exception as e:
                resp_a = str(e)
                lat_a = 0
                err_a = True

            start_b = time.time()
            try:
                resp_b = self.agent_b.complete([{"role": "user", "content": prompt}])
                lat_b = round(time.time() - start_b, 3)
                err_b = False
            except Exception as e:
                resp_b = str(e)
                lat_b = 0
                err_b = True

            self._results.append({
                "prompt": prompt[:50],
                "agent_a": {"name": self.agent_a.name, "latency": lat_a, "error": err_a, "response_len": len(resp_a)},
                "agent_b": {"name": self.agent_b.name, "latency": lat_b, "error": err_b, "response_len": len(resp_b)},
            })

        return self.summary()

    def summary(self) -> dict:
        if not self._results:
            return {}
        avg_lat_a = sum(r["agent_a"]["latency"] for r in self._results) / len(self._results)
        avg_lat_b = sum(r["agent_b"]["latency"] for r in self._results) / len(self._results)
        winner = self.agent_a.name if avg_lat_a < avg_lat_b else self.agent_b.name
        return {
            "total_prompts": len(self._results),
            self.agent_a.name: {"avg_latency": round(avg_lat_a, 3)},
            self.agent_b.name: {"avg_latency": round(avg_lat_b, 3)},
            "faster_agent": winner,
            "results": self._results,
        }
