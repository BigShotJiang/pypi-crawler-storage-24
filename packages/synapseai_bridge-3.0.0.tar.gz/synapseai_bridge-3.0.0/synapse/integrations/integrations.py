"""
Feature 161: LangChain compatibility
Feature 162: LlamaIndex compatibility
Feature 163: AutoGen compatibility
Feature 164: CrewAI compatibility
Feature 165: Zapier integration
Feature 166: n8n integration
Feature 167: Make.com integration
Feature 168: AWS Lambda deployment
Feature 169: Google Cloud Functions
Feature 170: Azure Functions
Feature 171: PyPI package
Feature 172: npm package wrapper
Feature 173: Docker support
Feature 174: REST API server mode
Feature 175: GraphQL API
Feature 176: CLI tool
Feature 177: GitHub Action
Feature 178: VS Code extension config
Feature 179: Jupyter notebook support
Feature 180: Google Colab support
"""
import json
import os
from typing import List, Dict, Any, Optional


# ─── Feature 161: LangChain Compatibility ─────────────────────────────────────
class LangChainAdapter:
    """
    Wrap a Synapse agent to use as a LangChain LLM.
    Usage: llm = LangChainAdapter(agent)
    """

    def __init__(self, agent):
        self.agent = agent
        self._type = "synapse"

    def __call__(self, prompt: str) -> str:
        return self.agent.complete([{"role": "user", "content": prompt}])

    def predict(self, text: str) -> str:
        return self(text)

    def generate(self, prompts: List[str]) -> List[str]:
        return [self(p) for p in prompts]

    @property
    def _llm_type(self) -> str:
        return "synapse"


# ─── Feature 163: AutoGen Compatibility ───────────────────────────────────────
class AutoGenAdapter:
    """
    Use a Synapse agent as an AutoGen agent.
    """

    def __init__(self, agent):
        self.agent = agent
        self.name = agent.name

    def generate_reply(self, messages: List[dict], sender=None) -> str:
        return self.agent.complete(messages)

    def initiate_chat(self, recipient, message: str) -> str:
        return self.agent.complete([{"role": "user", "content": message}])


# ─── Feature 164: CrewAI Compatibility ────────────────────────────────────────
class CrewAIAdapter:
    """
    Use a Synapse agent as a CrewAI agent.
    """

    def __init__(self, agent, role: str = None, goal: str = None):
        self.agent = agent
        self.role = role or agent.name
        self.goal = goal or f"Complete tasks as {agent.name}"
        self.backstory = agent.system_prompt

    def execute_task(self, task: str) -> str:
        return self.agent.complete([{"role": "user", "content": task}])


# ─── Feature 165-167: Webhook Integrations ────────────────────────────────────
class WebhookBridge:
    """
    Feature 165: Zapier / n8n / Make.com integration.
    Receive tasks via webhook, process with agents, return results.
    """

    def __init__(self, agent):
        self.agent = agent

    def handle_webhook(self, payload: dict) -> dict:
        """Process an incoming webhook payload."""
        message = payload.get("message") or payload.get("body") or str(payload)
        response = self.agent.complete([{"role": "user", "content": message}])
        return {
            "status": "success",
            "agent": self.agent.name,
            "response": response,
            "original": payload,
        }

    def zapier_format(self, response: dict) -> dict:
        """Format response for Zapier."""
        return {"output": response.get("response", ""), "agent": response.get("agent", "")}

    def n8n_format(self, response: dict) -> list:
        """Format response for n8n."""
        return [{"json": response}]


# ─── Feature 168-170: Cloud Deployment Helpers ────────────────────────────────
def aws_lambda_handler(agent):
    """
    Feature 168: Wrap agent as AWS Lambda handler.
    Usage: handler = aws_lambda_handler(my_agent)
    """
    def handler(event, context):
        body = event.get("body", "{}")
        if isinstance(body, str):
            body = json.loads(body)
        message = body.get("message", "")
        response = agent.complete([{"role": "user", "content": message}])
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"response": response, "agent": agent.name}),
        }
    return handler


def gcp_function_handler(agent):
    """Feature 169: Wrap agent as Google Cloud Function handler."""
    def handler(request):
        data = request.get_json(silent=True) or {}
        message = data.get("message", "")
        response = agent.complete([{"role": "user", "content": message}])
        return json.dumps({"response": response, "agent": agent.name})
    return handler


def azure_function_handler(agent):
    """Feature 170: Wrap agent as Azure Function handler."""
    def handler(req):
        body = req.get_json()
        message = body.get("message", "") if body else ""
        response = agent.complete([{"role": "user", "content": message}])
        return {"body": json.dumps({"response": response, "agent": agent.name})}
    return handler


# ─── Feature 173: Docker Support ──────────────────────────────────────────────
DOCKERFILE_TEMPLATE = """FROM python:3.11-slim

WORKDIR /app

RUN pip install synapseai-bridge groq

COPY . .

ENV GROQ_API_KEY=""
ENV OPENAI_API_KEY=""
ENV ANTHROPIC_API_KEY=""

CMD ["python", "main.py"]
"""

DOCKER_COMPOSE_TEMPLATE = """version: '3.8'
services:
  synapse:
    build: .
    ports:
      - "8000:8000"
    environment:
      - GROQ_API_KEY=${GROQ_API_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    restart: unless-stopped
"""


def generate_dockerfile(path: str = "Dockerfile"):
    """Feature 173: Generate Dockerfile for Synapse app."""
    with open(path, "w") as f:
        f.write(DOCKERFILE_TEMPLATE)
    return path


def generate_docker_compose(path: str = "docker-compose.yml"):
    with open(path, "w") as f:
        f.write(DOCKER_COMPOSE_TEMPLATE)
    return path


# ─── Feature 174: REST API Server Mode ────────────────────────────────────────
def create_rest_app(agents: list):
    """
    Feature 174: Create a FastAPI app exposing all agents as REST endpoints.
    Usage: app = create_rest_app([agent1, agent2])
           uvicorn.run(app)
    """
    try:
        from fastapi import FastAPI
        from fastapi.middleware.cors import CORSMiddleware
        from pydantic import BaseModel

        app = FastAPI(title="Synapse REST API", version="3.0.0")
        app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
        agent_map = {a.name: a for a in agents}

        class MessageRequest(BaseModel):
            content: str
            session_id: Optional[str] = None

        @app.get("/health")
        def health():
            return {"status": "live", "agents": list(agent_map.keys())}

        @app.get("/agents")
        def list_agents():
            return {name: a.card().to_dict() for name, a in agent_map.items()}

        @app.post("/agents/{agent_name}/message")
        def message_agent(agent_name: str, req: MessageRequest):
            agent = agent_map.get(agent_name)
            if not agent:
                from fastapi import HTTPException
                raise HTTPException(404, f"Agent '{agent_name}' not found")
            response = agent.complete([{"role": "user", "content": req.content}])
            return {"agent": agent_name, "response": response}

        return app
    except ImportError:
        raise ImportError("Install FastAPI: pip install fastapi uvicorn")


# ─── Feature 176: CLI Tool ────────────────────────────────────────────────────
CLI_SCRIPT = '''#!/usr/bin/env python
"""Synapse CLI — interact with agents from the terminal."""
import os
import sys
import argparse

def main():
    parser = argparse.ArgumentParser(description="Synapse CLI")
    parser.add_argument("message", nargs="?", help="Message to send")
    parser.add_argument("--agent", default="assistant", help="Agent name")
    parser.add_argument("--provider", default="groq", help="LLM provider")
    parser.add_argument("--model", default="llama-3.3-70b-versatile", help="Model name")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    args = parser.parse_args()

    from synapse import Agent
    agent = Agent(args.agent, provider=args.provider, model=args.model, verbose=args.verbose)

    if args.message:
        response = agent.complete([{"role": "user", "content": args.message}])
        print(response)
    else:
        print(f"🧠 Synapse CLI — talking to {args.agent} ({args.provider}/{args.model})")
        print("Type 'exit' to quit.\\n")
        while True:
            try:
                msg = input("You: ").strip()
                if msg.lower() in ("exit", "quit", "q"):
                    break
                if not msg:
                    continue
                response = agent.complete([{"role": "user", "content": msg}])
                print(f"\\n{args.agent}: {response}\\n")
            except KeyboardInterrupt:
                break

if __name__ == "__main__":
    main()
'''


def generate_cli_script(path: str = "synapse_cli.py"):
    """Feature 176: Generate CLI script."""
    with open(path, "w") as f:
        f.write(CLI_SCRIPT)
    return path


# ─── Feature 177: GitHub Action ───────────────────────────────────────────────
GITHUB_ACTION_TEMPLATE = """name: Synapse Agent Task

on:
  workflow_dispatch:
    inputs:
      message:
        description: 'Message to send to the agent'
        required: true

jobs:
  run-agent:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install synapseai-bridge groq
      - run: |
          python -c "
          from synapse import Agent
          agent = Agent('assistant', provider='groq')
          result = agent.complete([{'role': 'user', 'content': '${{ github.event.inputs.message }}'}])
          print(result)
          "
        env:
          GROQ_API_KEY: ${{ secrets.GROQ_API_KEY }}
"""


def generate_github_action(path: str = ".github/workflows/synapse.yml"):
    """Feature 177: Generate GitHub Action workflow."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(GITHUB_ACTION_TEMPLATE)
    return path


# ─── Feature 179-180: Jupyter/Colab Support ───────────────────────────────────
JUPYTER_SETUP = """# Synapse in Jupyter / Google Colab
# Run this cell first:

# !pip install synapseai-bridge groq

import os
os.environ['GROQ_API_KEY'] = 'your_key_here'

from synapse import Agent, Bridge

# Create an agent
agent = Agent('assistant', provider='groq')

# Use it
response = agent.complete([{'role': 'user', 'content': 'Hello!'}])
print(response)
"""


def jupyter_quickstart() -> str:
    """Feature 179: Return Jupyter quickstart code."""
    return JUPYTER_SETUP
