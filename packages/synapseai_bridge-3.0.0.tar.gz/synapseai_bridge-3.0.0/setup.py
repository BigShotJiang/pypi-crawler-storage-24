from setuptools import setup, find_packages

setup(
    name="synapseai-bridge",
    version="3.0.0",
    description="Multi-Agent Bridge SDK — 180 features to connect AI agents",
    long_description="Synapse connects AI agents together. Supports Groq, OpenAI, Anthropic, Gemini. Features: agent routing, shared memory, tools (web search, code execution, file system), security, observability, and integrations.",
    author="Synapse",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=["groq>=0.9.0"],
    extras_require={
        "openai":    ["openai>=1.30.0"],
        "anthropic": ["anthropic>=0.40.0"],
        "gemini":    ["google-generativeai>=0.5.0"],
        "server":    ["fastapi>=0.115.0", "uvicorn>=0.30.0"],
        "yaml":      ["pyyaml>=6.0"],
        "all":       ["openai>=1.30.0", "anthropic>=0.40.0", "google-generativeai>=0.5.0", "fastapi>=0.115.0", "uvicorn>=0.30.0", "pyyaml>=6.0"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
