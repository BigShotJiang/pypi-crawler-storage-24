"""
Gmail MCP Server — FastMCP instance with all tools registered.

This is the core server module. Tools are organized by domain
in the tools/ subpackage and registered here.
"""

import logging
import sys

from fastmcp import FastMCP

from gmail_mcp_server.config import GmailConfig
from gmail_mcp_server.tools.messages import register_message_tools
from gmail_mcp_server.tools.drafts import register_draft_tools
from gmail_mcp_server.tools.labels import register_label_tools
from gmail_mcp_server.tools.threads import register_thread_tools

# Ensure logging goes to stderr (required for stdio MCP transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger("gmail_mcp_server")


def create_server() -> FastMCP:
    """Create and configure the Gmail MCP server.

    Validates environment configuration on startup and registers
    all Gmail tools with the FastMCP instance.
    """
    # Validate config on startup
    config = GmailConfig()
    config.validate_or_exit()

    app = FastMCP(
        name="gmail-mcp-server",
        instructions=(
            "MCP server for Gmail operations. "
            "Send emails, read and search messages, manage drafts, "
            "organize with labels, and view email threads."
        ),
        version="2.0.0",
    )

    # Register all tool groups
    register_message_tools(app, config)
    register_draft_tools(app, config)
    register_label_tools(app, config)
    register_thread_tools(app, config)

    logger.info("Gmail MCP server configured with all tool groups")
    return app
