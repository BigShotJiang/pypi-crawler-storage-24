"""
Gmail API Client.

Production-quality client with:
- Google API Python client (google-api-python-client)
- Refresh-token-based OAuth2 (no browser flow needed)
- Automatic token refresh via google-auth
- Structured error types
- MIME message construction
- Improved multipart email parsing
"""

import base64
import logging
import re
import sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Any, Optional

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

logger = logging.getLogger("gmail_mcp_server.client")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.compose",
]


# --- Error Types ---

class GmailAPIError(Exception):
    """Base error for Gmail API failures."""

    def __init__(self, error: str, message: str = ""):
        self.error = error
        self.message = message or error
        super().__init__(self.message)


class GmailAuthError(GmailAPIError):
    """Authentication/authorization failure."""
    pass


class GmailNotFoundError(GmailAPIError):
    """Resource not found (message, thread, label)."""
    pass


# --- Client ---

class GmailClient:
    """Gmail API client using refresh-token-based OAuth2."""

    def __init__(self, client_id: str, client_secret: str, refresh_token: str):
        self._creds = Credentials(
            token=None,
            refresh_token=refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=client_id,
            client_secret=client_secret,
            scopes=SCOPES,
        )
        self._service = build("gmail", "v1", credentials=self._creds)

    def _build_mime_message(
        self, to: str, subject: str, body: str, cc: str = ""
    ) -> dict:
        """Build a base64url-encoded MIME message for the Gmail API."""
        message = MIMEText(body)
        message["to"] = to
        message["subject"] = subject
        if cc:
            message["cc"] = cc
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        return {"raw": raw}

    def _strip_html(self, html: str) -> str:
        """Simple HTML to plain text conversion."""
        text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
        text = re.sub(r"<p[^>]*>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"</p>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", "", text)
        text = re.sub(r"&nbsp;", " ", text)
        text = re.sub(r"&amp;", "&", text)
        text = re.sub(r"&lt;", "<", text)
        text = re.sub(r"&gt;", ">", text)
        text = re.sub(r"&quot;", '"', text)
        text = re.sub(r"&#39;", "'", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _extract_body_from_parts(self, parts: list[dict]) -> tuple[str, str]:
        """Recursively extract text/plain and text/html bodies from MIME parts.
        
        Returns (plain_text, html_text).
        """
        plain = ""
        html = ""
        for part in parts:
            mime_type = part.get("mimeType", "")
            data = part.get("body", {}).get("data", "")

            if mime_type == "text/plain" and data and not plain:
                plain = base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
            elif mime_type == "text/html" and data and not html:
                html = base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
            elif mime_type.startswith("multipart/") and part.get("parts"):
                sub_plain, sub_html = self._extract_body_from_parts(part["parts"])
                if sub_plain and not plain:
                    plain = sub_plain
                if sub_html and not html:
                    html = sub_html

        return plain, html

    def _extract_attachments(self, parts: list[dict]) -> list[dict]:
        """Extract attachment metadata from MIME parts."""
        attachments = []
        for part in parts:
            filename = part.get("filename", "")
            if filename:
                attachments.append({
                    "filename": filename,
                    "mimeType": part.get("mimeType", ""),
                    "size": part.get("body", {}).get("size", 0),
                    "attachmentId": part.get("body", {}).get("attachmentId", ""),
                })
            if part.get("parts"):
                attachments.extend(self._extract_attachments(part["parts"]))
        return attachments

    def _parse_message(self, msg: dict) -> dict:
        """Extract useful fields from a raw Gmail API message."""
        headers = {
            h["name"].lower(): h["value"]
            for h in msg.get("payload", {}).get("headers", [])
        }

        payload = msg.get("payload", {})
        body = ""
        html_body = ""

        if payload.get("body", {}).get("data"):
            body = base64.urlsafe_b64decode(
                payload["body"]["data"]
            ).decode("utf-8", errors="replace")
        elif payload.get("parts"):
            plain, html = self._extract_body_from_parts(payload["parts"])
            body = plain
            html_body = html

        # If no plain text but we have HTML, convert HTML to text
        if not body and html_body:
            body = self._strip_html(html_body)

        # Extract attachments
        attachments = []
        if payload.get("parts"):
            attachments = self._extract_attachments(payload["parts"])

        result = {
            "id": msg.get("id", ""),
            "threadId": msg.get("threadId", ""),
            "subject": headers.get("subject", ""),
            "from": headers.get("from", ""),
            "to": headers.get("to", ""),
            "date": headers.get("date", ""),
            "snippet": msg.get("snippet", ""),
            "body": body,
            "labelIds": msg.get("labelIds", []),
        }

        if attachments:
            result["attachments"] = attachments

        return result

    # --- Messages ---

    def send_email(self, to: str, subject: str, body: str, cc: str = "") -> dict:
        """Send an email."""
        try:
            mime = self._build_mime_message(to, subject, body, cc)
            result = (
                self._service.users()
                .messages()
                .send(userId="me", body=mime)
                .execute()
            )
            return {
                "id": result.get("id", ""),
                "threadId": result.get("threadId", ""),
                "labelIds": result.get("labelIds", []),
            }
        except HttpError as e:
            self._handle_http_error(e)

    def reply_email(self, message_id: str, body: str) -> dict:
        """Reply to an email in the same thread."""
        try:
            original = (
                self._service.users()
                .messages()
                .get(userId="me", id=message_id, format="full")
                .execute()
            )
            headers = {
                h["name"].lower(): h["value"]
                for h in original.get("payload", {}).get("headers", [])
            }
            thread_id = original.get("threadId", "")
            subject = headers.get("subject", "")
            if not subject.lower().startswith("re:"):
                subject = f"Re: {subject}"
            reply_to = headers.get("reply-to", headers.get("from", ""))

            msg = MIMEText(body)
            msg["to"] = reply_to
            msg["subject"] = subject
            msg["In-Reply-To"] = headers.get("message-id", "")
            msg["References"] = headers.get("message-id", "")
            raw = base64.urlsafe_b64encode(msg.as_bytes()).decode("utf-8")

            result = (
                self._service.users()
                .messages()
                .send(userId="me", body={"raw": raw, "threadId": thread_id})
                .execute()
            )
            return {
                "id": result.get("id", ""),
                "threadId": result.get("threadId", ""),
                "labelIds": result.get("labelIds", []),
            }
        except HttpError as e:
            self._handle_http_error(e)

    def list_messages(
        self,
        max_results: int = 10,
        label: str = "INBOX",
        page_token: str = "",
    ) -> dict:
        """List recent messages from a label with pagination support."""
        try:
            kwargs: dict[str, Any] = {
                "userId": "me",
                "labelIds": [label],
                "maxResults": max_results,
            }
            if page_token:
                kwargs["pageToken"] = page_token

            results = self._service.users().messages().list(**kwargs).execute()
            messages = []
            for msg_ref in results.get("messages", []):
                msg = (
                    self._service.users()
                    .messages()
                    .get(userId="me", id=msg_ref["id"], format="full")
                    .execute()
                )
                messages.append(self._parse_message(msg))

            return {
                "messages": messages,
                "nextPageToken": results.get("nextPageToken", ""),
                "resultSizeEstimate": results.get("resultSizeEstimate", 0),
            }
        except HttpError as e:
            self._handle_http_error(e)

    def get_message(self, message_id: str) -> dict:
        """Get a single message by ID."""
        try:
            msg = (
                self._service.users()
                .messages()
                .get(userId="me", id=message_id, format="full")
                .execute()
            )
            return self._parse_message(msg)
        except HttpError as e:
            self._handle_http_error(e)

    def search_messages(
        self,
        query: str,
        max_results: int = 10,
        page_token: str = "",
    ) -> dict:
        """Search messages using Gmail query syntax with pagination support."""
        try:
            kwargs: dict[str, Any] = {
                "userId": "me",
                "q": query,
                "maxResults": max_results,
            }
            if page_token:
                kwargs["pageToken"] = page_token

            results = self._service.users().messages().list(**kwargs).execute()
            messages = []
            for msg_ref in results.get("messages", []):
                msg = (
                    self._service.users()
                    .messages()
                    .get(userId="me", id=msg_ref["id"], format="full")
                    .execute()
                )
                messages.append(self._parse_message(msg))

            return {
                "messages": messages,
                "nextPageToken": results.get("nextPageToken", ""),
                "resultSizeEstimate": results.get("resultSizeEstimate", 0),
            }
        except HttpError as e:
            self._handle_http_error(e)

    def mark_read(self, message_id: str) -> dict:
        """Mark a message as read by removing UNREAD label."""
        try:
            self._service.users().messages().modify(
                userId="me",
                id=message_id,
                body={"removeLabelIds": ["UNREAD"]},
            ).execute()
            return {"id": message_id, "markedRead": True}
        except HttpError as e:
            self._handle_http_error(e)

    def mark_unread(self, message_id: str) -> dict:
        """Mark a message as unread by adding UNREAD label."""
        try:
            self._service.users().messages().modify(
                userId="me",
                id=message_id,
                body={"addLabelIds": ["UNREAD"]},
            ).execute()
            return {"id": message_id, "markedUnread": True}
        except HttpError as e:
            self._handle_http_error(e)

    # --- Labels ---

    def list_labels(self) -> list[dict]:
        """List all labels."""
        try:
            results = self._service.users().labels().list(userId="me").execute()
            return [
                {
                    "id": label.get("id", ""),
                    "name": label.get("name", ""),
                    "type": label.get("type", ""),
                }
                for label in results.get("labels", [])
            ]
        except HttpError as e:
            self._handle_http_error(e)

    def add_label(self, message_id: str, label_id: str) -> dict:
        """Add a label to a message."""
        try:
            result = (
                self._service.users()
                .messages()
                .modify(
                    userId="me",
                    id=message_id,
                    body={"addLabelIds": [label_id]},
                )
                .execute()
            )
            return {"id": message_id, "labelIds": result.get("labelIds", [])}
        except HttpError as e:
            self._handle_http_error(e)

    def remove_label(self, message_id: str, label_id: str) -> dict:
        """Remove a label from a message."""
        try:
            result = (
                self._service.users()
                .messages()
                .modify(
                    userId="me",
                    id=message_id,
                    body={"removeLabelIds": [label_id]},
                )
                .execute()
            )
            return {"id": message_id, "labelIds": result.get("labelIds", [])}
        except HttpError as e:
            self._handle_http_error(e)

    # --- Drafts ---

    def create_draft(self, to: str, subject: str, body: str, cc: str = "") -> dict:
        """Create a draft email."""
        try:
            mime = self._build_mime_message(to, subject, body, cc)
            result = (
                self._service.users()
                .drafts()
                .create(userId="me", body={"message": mime})
                .execute()
            )
            return {
                "id": result.get("id", ""),
                "messageId": result.get("message", {}).get("id", ""),
            }
        except HttpError as e:
            self._handle_http_error(e)

    def list_drafts(self, max_results: int = 20) -> list[dict]:
        """List draft emails."""
        try:
            results = (
                self._service.users()
                .drafts()
                .list(userId="me", maxResults=max_results)
                .execute()
            )
            drafts = []
            for draft_ref in results.get("drafts", []):
                draft = (
                    self._service.users()
                    .drafts()
                    .get(userId="me", id=draft_ref["id"])
                    .execute()
                )
                msg = draft.get("message", {})
                headers = {
                    h["name"].lower(): h["value"]
                    for h in msg.get("payload", {}).get("headers", [])
                }
                drafts.append({
                    "id": draft.get("id", ""),
                    "messageId": msg.get("id", ""),
                    "subject": headers.get("subject", ""),
                    "to": headers.get("to", ""),
                    "snippet": msg.get("snippet", ""),
                })
            return drafts
        except HttpError as e:
            self._handle_http_error(e)

    def send_draft(self, draft_id: str) -> dict:
        """Send an existing draft."""
        try:
            result = (
                self._service.users()
                .drafts()
                .send(userId="me", body={"id": draft_id})
                .execute()
            )
            return {
                "id": result.get("id", ""),
                "threadId": result.get("threadId", ""),
                "labelIds": result.get("labelIds", []),
            }
        except HttpError as e:
            self._handle_http_error(e)

    # --- Threads ---

    def get_thread(self, thread_id: str) -> dict:
        """Get a full thread by ID."""
        try:
            thread = (
                self._service.users()
                .threads()
                .get(userId="me", id=thread_id, format="full")
                .execute()
            )
            messages = [
                self._parse_message(msg) for msg in thread.get("messages", [])
            ]
            return {
                "id": thread.get("id", ""),
                "snippet": thread.get("snippet", ""),
                "messageCount": len(messages),
                "messages": messages,
            }
        except HttpError as e:
            self._handle_http_error(e)

    # --- Error Handling ---

    def _handle_http_error(self, error: HttpError):
        """Convert HttpError to typed Gmail errors."""
        status = error.resp.status if hasattr(error, "resp") else 0
        reason = str(error)

        if status in (401, 403):
            raise GmailAuthError("auth_error", reason)
        elif status == 404:
            raise GmailNotFoundError("not_found", reason)
        else:
            raise GmailAPIError("api_error", reason)
