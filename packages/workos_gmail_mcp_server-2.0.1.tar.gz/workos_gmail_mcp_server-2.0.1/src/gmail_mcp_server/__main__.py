"""Allow running as: python -m gmail_mcp_server"""
from gmail_mcp_server import main

main()
