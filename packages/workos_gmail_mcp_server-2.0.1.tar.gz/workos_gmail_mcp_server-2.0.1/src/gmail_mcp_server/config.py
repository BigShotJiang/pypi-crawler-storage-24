"""
Environment variable validation for Gmail MCP Server.

Required environment variables:
    GOOGLE_CLIENT_ID:       Google OAuth2 client ID
    GOOGLE_CLIENT_SECRET:   Google OAuth2 client secret
    GOOGLE_REFRESH_TOKEN:   Google OAuth2 refresh token
"""

import os
import sys
import logging

logger = logging.getLogger("gmail_mcp_server.config")


class GmailConfig:
    """Validated Gmail configuration from environment variables."""

    def __init__(self):
        self.client_id: str = ""
        self.client_secret: str = ""
        self.refresh_token: str = ""
        self.log_level: str = "INFO"
        self._load()

    def _load(self):
        self.client_id = os.environ.get("GOOGLE_CLIENT_ID", "")
        self.client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "")
        self.refresh_token = os.environ.get("GOOGLE_REFRESH_TOKEN", "")
        self.log_level = os.environ.get("GMAIL_LOG_LEVEL", "INFO")

    def validate(self) -> list[str]:
        """Validate configuration. Returns list of error messages (empty = valid)."""
        errors = []

        if not self.client_id:
            errors.append("GOOGLE_CLIENT_ID is required")
        if not self.client_secret:
            errors.append("GOOGLE_CLIENT_SECRET is required")
        if not self.refresh_token:
            errors.append(
                "GOOGLE_REFRESH_TOKEN is required"
                " (generate via OAuth Playground or helper script)"
            )

        return errors

    def validate_or_exit(self):
        """Validate configuration, exit with clear error if invalid."""
        errors = self.validate()
        if errors:
            print("Gmail MCP Server — Configuration errors:", file=sys.stderr)
            for err in errors:
                print(f"  ✗ {err}", file=sys.stderr)
            print(
                "\nSet the required environment variables and try again.",
                file=sys.stderr,
            )
            sys.exit(1)
        logger.info("Gmail configuration validated successfully")
