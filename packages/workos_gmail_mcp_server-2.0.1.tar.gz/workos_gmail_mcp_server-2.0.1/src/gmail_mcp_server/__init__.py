"""
Gmail MCP Server — Model Context Protocol server for Gmail operations.

An independent, generalized MCP server that can connect to any AI agent
supporting the Model Context Protocol. Not tied to any specific project.

Quick start:
    pip install workos-gmail-mcp-server
    GOOGLE_CLIENT_ID=... \
    GOOGLE_CLIENT_SECRET=... \
    GOOGLE_REFRESH_TOKEN=... \
    gmail-mcp-server

Or run as a module:
    python -m gmail_mcp_server
"""

__version__ = "2.0.0"

from gmail_mcp_server.server import create_server


def main():
    """Entry point for the gmail-mcp-server CLI command."""
    server = create_server()
    server.run()


__all__ = ["main", "create_server", "__version__"]
