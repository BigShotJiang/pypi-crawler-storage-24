"""Gmail MCP Server tools — organized by domain."""
