"""Gmail label tools — list, add, remove labels."""

from gmail_mcp_server.client import GmailClient, GmailAPIError, GmailAuthError
from gmail_mcp_server.config import GmailConfig


def register_label_tools(app, config: GmailConfig):
    """Register label tools with the FastMCP app."""

    @app.tool()
    async def gmail_list_labels() -> dict:
        """List all Gmail labels.

        Returns all system and user-created labels with their IDs, names, and types.
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            labels = client.list_labels()
            return {"success": True, "count": len(labels), "labels": labels}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_add_label(message_id: str, label_id: str) -> dict:
        """Add a label to an email message.

        Args:
            message_id: Gmail message ID
            label_id: Label ID to add (e.g., 'STARRED', 'IMPORTANT', or custom label ID)
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.add_label(message_id=message_id, label_id=label_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_remove_label(message_id: str, label_id: str) -> dict:
        """Remove a label from an email message.

        Args:
            message_id: Gmail message ID
            label_id: Label ID to remove (e.g., 'STARRED', 'IMPORTANT', or custom label ID)
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.remove_label(message_id=message_id, label_id=label_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}
