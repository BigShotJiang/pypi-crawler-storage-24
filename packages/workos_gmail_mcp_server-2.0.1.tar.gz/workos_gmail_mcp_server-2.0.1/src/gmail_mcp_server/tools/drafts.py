"""Gmail draft tools — create, list, and send drafts."""

from gmail_mcp_server.client import GmailClient, GmailAPIError, GmailAuthError
from gmail_mcp_server.config import GmailConfig


def register_draft_tools(app, config: GmailConfig):
    """Register draft tools with the FastMCP app."""

    @app.tool()
    async def gmail_create_draft(to: str, subject: str, body: str, cc: str = "") -> dict:
        """Create a draft email in Gmail.

        Args:
            to: Recipient email address
            subject: Email subject line
            body: Email body text
            cc: CC recipients (comma-separated, optional)
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.create_draft(to=to, subject=subject, body=body, cc=cc)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_list_drafts(max_results: int = 20) -> dict:
        """List draft emails.

        Args:
            max_results: Maximum number of drafts to return (default 20)
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            drafts = client.list_drafts(max_results=max_results)
            return {"success": True, "count": len(drafts), "drafts": drafts}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_send_draft(draft_id: str) -> dict:
        """Send an existing draft email.

        Args:
            draft_id: Gmail draft ID to send
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.send_draft(draft_id=draft_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}
