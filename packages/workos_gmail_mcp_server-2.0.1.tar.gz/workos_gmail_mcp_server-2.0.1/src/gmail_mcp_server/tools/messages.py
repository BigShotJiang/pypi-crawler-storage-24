"""Gmail message tools — send, read, search, reply, mark read/unread."""

from gmail_mcp_server.client import GmailClient, GmailAPIError, GmailAuthError
from gmail_mcp_server.config import GmailConfig


def register_message_tools(app, config: GmailConfig):
    """Register message tools with the FastMCP app."""

    @app.tool()
    async def gmail_send_email(to: str, subject: str, body: str, cc: str = "") -> dict:
        """Send an email via Gmail.

        Args:
            to: Recipient email address
            subject: Email subject line
            body: Email body text
            cc: CC recipients (comma-separated, optional)
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.send_email(to=to, subject=subject, body=body, cc=cc)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_reply_email(message_id: str, body: str) -> dict:
        """Reply to an email in the same thread.

        Args:
            message_id: The ID of the message to reply to
            body: The reply text
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.reply_email(message_id=message_id, body=body)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_read_emails(
        max_results: int = 10,
        label: str = "INBOX",
        page_token: str = "",
    ) -> dict:
        """Read recent emails from a Gmail label.

        Args:
            max_results: Number of emails to return (1-50, default: 10)
            label: Gmail label to read from (default: INBOX)
            page_token: Pagination token from previous response (optional)
        """
        max_results = min(max(max_results, 1), 50)
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.list_messages(
                max_results=max_results, label=label, page_token=page_token
            )
            return {
                "success": True,
                "label": label,
                "count": len(result["messages"]),
                "messages": result["messages"],
                "nextPageToken": result.get("nextPageToken", ""),
                "resultSizeEstimate": result.get("resultSizeEstimate", 0),
            }
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_get_email(message_id: str) -> dict:
        """Get a single email by its message ID.

        Args:
            message_id: Gmail message ID
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            message = client.get_message(message_id=message_id)
            return {"success": True, **message}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_search_emails(
        query: str,
        max_results: int = 10,
        page_token: str = "",
    ) -> dict:
        """Search emails using Gmail query syntax.

        Args:
            query: Gmail search query (e.g., 'from:user@example.com', 'subject:meeting', 'is:unread')
            max_results: Maximum number of results (1-50, default: 10)
            page_token: Pagination token from previous response (optional)
        """
        max_results = min(max(max_results, 1), 50)
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.search_messages(
                query=query, max_results=max_results, page_token=page_token
            )
            return {
                "success": True,
                "query": query,
                "count": len(result["messages"]),
                "messages": result["messages"],
                "nextPageToken": result.get("nextPageToken", ""),
                "resultSizeEstimate": result.get("resultSizeEstimate", 0),
            }
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_mark_read(message_id: str) -> dict:
        """Mark an email as read.

        Args:
            message_id: Gmail message ID to mark as read
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.mark_read(message_id=message_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}

    @app.tool()
    async def gmail_mark_unread(message_id: str) -> dict:
        """Mark an email as unread.

        Args:
            message_id: Gmail message ID to mark as unread
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.mark_unread(message_id=message_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}
