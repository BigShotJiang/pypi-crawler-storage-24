"""Gmail thread tools — view email threads."""

from gmail_mcp_server.client import GmailClient, GmailAPIError, GmailAuthError
from gmail_mcp_server.config import GmailConfig


def register_thread_tools(app, config: GmailConfig):
    """Register thread tools with the FastMCP app."""

    @app.tool()
    async def gmail_get_thread(thread_id: str) -> dict:
        """Get a full email thread with all messages.

        Args:
            thread_id: Gmail thread ID
        """
        try:
            client = GmailClient(
                client_id=config.client_id,
                client_secret=config.client_secret,
                refresh_token=config.refresh_token,
            )
            result = client.get_thread(thread_id=thread_id)
            return {"success": True, **result}
        except GmailAuthError as e:
            return {"success": False, "error": "auth_error", "message": str(e)}
        except GmailAPIError as e:
            return {"success": False, "error": e.error, "message": str(e)}
