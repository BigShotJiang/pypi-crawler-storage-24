"""Tests for Gmail MCP server client."""

import pytest
from unittest.mock import MagicMock, patch
from gmail_mcp_server.client import GmailClient, GmailAuthError, GmailNotFoundError, GmailAPIError


class TestClientInit:
    def test_creates_with_credentials(self, mock_config):
        with patch("gmail_mcp_server.client.Credentials") as mock_creds_cls, \
             patch("gmail_mcp_server.client.build") as mock_build:
            mock_creds = MagicMock()
            mock_creds_cls.return_value = mock_creds
            mock_build.return_value = MagicMock()

            client = GmailClient(
                client_id=mock_config.client_id,
                client_secret=mock_config.client_secret,
                refresh_token=mock_config.refresh_token,
            )
            assert client._service is not None

    def test_credentials_built_with_refresh_token(self, mock_config):
        with patch("gmail_mcp_server.client.Credentials") as mock_creds_cls, \
             patch("gmail_mcp_server.client.build"):
            mock_creds = MagicMock()
            mock_creds_cls.return_value = mock_creds

            GmailClient(
                client_id=mock_config.client_id,
                client_secret=mock_config.client_secret,
                refresh_token=mock_config.refresh_token,
            )
            mock_creds_cls.assert_called_once_with(
                token=None,
                refresh_token=mock_config.refresh_token,
                token_uri="https://oauth2.googleapis.com/token",
                client_id=mock_config.client_id,
                client_secret=mock_config.client_secret,
                scopes=[
                    "https://www.googleapis.com/auth/gmail.modify",
                    "https://www.googleapis.com/auth/gmail.compose",
                ],
            )


class TestSendEmail:
    def test_send_email_success(self, mock_gmail_client):
        client, service = mock_gmail_client
        service.users().messages().send().execute.return_value = {
            "id": "msg123",
            "threadId": "thread456",
            "labelIds": ["SENT"],
        }
        result = client.send_email(to="test@example.com", subject="Test", body="Hello")
        assert result["id"] == "msg123"
        assert result["threadId"] == "thread456"


class TestListMessages:
    def test_list_messages_success(self, mock_gmail_client):
        client, service = mock_gmail_client
        service.users().messages().list().execute.return_value = {
            "messages": [{"id": "msg1"}, {"id": "msg2"}]
        }
        service.users().messages().get().execute.return_value = {
            "id": "msg1",
            "threadId": "t1",
            "snippet": "Hello",
            "labelIds": ["INBOX"],
            "payload": {
                "headers": [
                    {"name": "Subject", "value": "Test Subject"},
                    {"name": "From", "value": "sender@example.com"},
                    {"name": "To", "value": "me@example.com"},
                    {"name": "Date", "value": "Mon, 1 Jan 2026 00:00:00 +0000"},
                ],
                "body": {"data": ""},
            },
        }
        result = client.list_messages(max_results=2, label="INBOX")
        assert len(result["messages"]) == 2
        assert result["messages"][0]["id"] == "msg1"


class TestGetMessage:
    def test_get_message_success(self, mock_gmail_client):
        client, service = mock_gmail_client
        service.users().messages().get().execute.return_value = {
            "id": "msg123",
            "threadId": "t1",
            "snippet": "Hello world",
            "labelIds": ["INBOX"],
            "payload": {
                "headers": [
                    {"name": "Subject", "value": "Test"},
                    {"name": "From", "value": "sender@example.com"},
                ],
                "body": {"data": ""},
            },
        }
        result = client.get_message(message_id="msg123")
        assert result["id"] == "msg123"
        assert result["subject"] == "Test"


class TestSearchMessages:
    def test_search_messages_success(self, mock_gmail_client):
        client, service = mock_gmail_client
        service.users().messages().list().execute.return_value = {
            "messages": [{"id": "msg1"}]
        }
        service.users().messages().get().execute.return_value = {
            "id": "msg1",
            "threadId": "t1",
            "snippet": "Match",
            "labelIds": ["INBOX"],
            "payload": {"headers": [], "body": {"data": ""}},
        }
        result = client.search_messages(query="from:test@example.com", max_results=5)
        assert len(result["messages"]) == 1


class TestLabels:
    def test_list_labels_success(self, mock_gmail_client):
        client, service = mock_gmail_client
        service.users().labels().list().execute.return_value = {
            "labels": [
                {"id": "INBOX", "name": "INBOX", "type": "system"},
                {"id": "Label_1", "name": "Work", "type": "user"},
            ]
        }
        result = client.list_labels()
        assert len(result) == 2
        assert result[0]["name"] == "INBOX"


class TestConfigValidation:
    def test_valid_config(self, mock_config):
        errors = mock_config.validate()
        assert len(errors) == 0

    def test_missing_client_id(self):
        import os
        from gmail_mcp_server.config import GmailConfig
        with patch.dict(os.environ, {}, clear=True):
            config = GmailConfig()
            errors = config.validate()
            assert any("GOOGLE_CLIENT_ID" in e for e in errors)

    def test_missing_client_secret(self):
        import os
        from gmail_mcp_server.config import GmailConfig
        with patch.dict(os.environ, {"GOOGLE_CLIENT_ID": "test"}, clear=True):
            config = GmailConfig()
            errors = config.validate()
            assert any("GOOGLE_CLIENT_SECRET" in e for e in errors)

    def test_missing_refresh_token(self):
        import os
        from gmail_mcp_server.config import GmailConfig
        with patch.dict(
            os.environ,
            {"GOOGLE_CLIENT_ID": "test", "GOOGLE_CLIENT_SECRET": "test"},
            clear=True,
        ):
            config = GmailConfig()
            errors = config.validate()
            assert any("GOOGLE_REFRESH_TOKEN" in e for e in errors)

    def test_all_present_no_errors(self):
        import os
        from gmail_mcp_server.config import GmailConfig
        with patch.dict(
            os.environ,
            {
                "GOOGLE_CLIENT_ID": "test-id",
                "GOOGLE_CLIENT_SECRET": "test-secret",
                "GOOGLE_REFRESH_TOKEN": "test-token",
            },
            clear=True,
        ):
            config = GmailConfig()
            errors = config.validate()
            assert len(errors) == 0
