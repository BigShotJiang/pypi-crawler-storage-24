"""Tests for Gmail MCP message tools."""

import pytest
from unittest.mock import MagicMock, patch
from fastmcp import FastMCP
from gmail_mcp_server.tools.messages import register_message_tools


@pytest.fixture
def app_with_tools(mock_config):
    app = FastMCP(name="test", version="0.1.0")
    register_message_tools(app, mock_config)
    return app


class TestMessageTools:
    def test_tools_registered(self, app_with_tools):
        """Verify all message tools are registered."""
        import asyncio
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "gmail_send_email" in tool_names
        assert "gmail_reply_email" in tool_names
        assert "gmail_read_emails" in tool_names
        assert "gmail_get_email" in tool_names
        assert "gmail_search_emails" in tool_names
        assert "gmail_mark_read" in tool_names
        assert "gmail_mark_unread" in tool_names
