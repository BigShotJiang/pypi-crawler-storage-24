## A simple calc pakage


pip install euron_calc