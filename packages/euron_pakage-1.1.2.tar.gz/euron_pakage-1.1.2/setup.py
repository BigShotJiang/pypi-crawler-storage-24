from setuptools import setup, find_packages

setup(
    name='EURON_PAKAGE',
    version='1.1.2',
    packages=find_packages(),  # Use find_packages() to automatically find packages based on __init__.py
    description='A basic calculator package for performing arithmetic operations.',
    author='Bibhas D',
    author_email='bibhas1115@gmail.com',
    long_description=open('README.md').read(),  # Ensure README.md exists in the same directory
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',  # Specify the Python version compatibility
)
