# Ingestible Documentation

A multi-format document ingestion pipeline that transforms documents into a queryable knowledge store optimized for AI context retrieval.

## Contents

- [Architecture Overview](architecture.md) — Pipeline stages, data flow, project structure
- [How Search Works](search.md) — Vector search, BM25, concept index, corpus search, RRF fusion
- [Usage Guide](usage.md) — Installation, CLI commands, configuration, Docker
- [REST API Reference](api.md) — All HTTP endpoints
- [Token Economics](token-economics.md) — Why hierarchical retrieval matters, real-world numbers
- [CognitiveVault Integration](cv-integration.md) — Export adapter for CognitiveVault
- [Roadmap](roadmap.md) — Feature expansion phases and status
