# Commercial License

IngestionTool is source-available under the [PolyForm Small Business License 1.0.0](LICENSE).

## Who can use it for free?

- **Individuals** — personal projects, research, learning, hobby use
- **Small businesses** — fewer than 100 people AND less than €1M annual revenue
- **Noncommercial organizations** — nonprofits, governments, education
- **Open-source projects** — anything under an OSI-approved license

## Who needs a commercial license?

Companies that exceed **both** thresholds (≥100 people or ≥€1M revenue) and are using IngestionTool in a commercial product or internal tool need a commercial license.

## Pricing

| Plan | Price | Details |
|------|-------|---------|
| Free | €0 | Small business, personal, nonprofit, open source |
| Commercial | €9/month | Per organization, unlimited users |

## How to get a commercial license

Contact us at **[INSERT EMAIL]** or visit **[INSERT URL]** to start your commercial license.

## FAQ

**Can I evaluate IngestionTool before buying?**
Yes. The PolyForm Small Business license allows use for research, testing, and experimentation regardless of company size.

**What if my company grows past the thresholds?**
You have 30 days after being notified to obtain a commercial license.

**Can I use IngestionTool in a SaaS product?**
Yes, with the appropriate license for your organization size.
