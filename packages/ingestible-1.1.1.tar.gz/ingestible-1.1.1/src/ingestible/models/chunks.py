from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    pass

from ingestible.models.enrichment import Citation, KGTriple


class ChunkPosition(BaseModel):
    chapter: str = ""
    section: str = ""
    index: int = 0


class L3Chunk(BaseModel):
    """Passage-level chunk (~250-500 tokens). Primary retrieval unit for semantic search."""

    chunk_id: str
    content: str
    content_hash: str = ""
    page_start: int | None = Field(default=None, ge=0)
    page_end: int | None = Field(default=None, ge=0)
    position: ChunkPosition = Field(default_factory=ChunkPosition)
    parent_section_id: str = ""
    position_in_section: Literal["first", "middle", "last", "only"] = "only"

    # Content tier (populated by Stage 1c when content classification is enabled)
    content_tier: Literal["T0", "T1", "T2", "T3"] = "T3"

    # Timestamps (audio/video sources only, in seconds)
    timestamp_start: float | None = Field(default=None, ge=0.0)
    timestamp_end: float | None = Field(default=None, ge=0.0)

    # Context prefix (populated by Stage 3c — contextual chunking)
    context_prefix: str = ""

    # Enrichment fields (populated by Stage 4)
    summary: str = ""
    concepts: list[str] = Field(default_factory=list, max_length=200)
    hypothetical_questions: list[str] = Field(default_factory=list, max_length=50)
    keywords: list[str] = Field(default_factory=list, max_length=200)
    difficulty_level: str = ""
    depends_on: list[str] = Field(default_factory=list, max_length=200)
    cross_references: list[str] = Field(default_factory=list)
    cited_references: list[str] = Field(default_factory=list)

    # Knowledge graph triples (populated by Stage 4 when enabled)
    kg_triples: list[KGTriple] = Field(default_factory=list)

    # Version tracking (set automatically during re-ingestion)
    version_status: Literal["current", "superseded"] = "current"


class L2Chunk(BaseModel):
    """Section-level chunk (~200-400 tokens)."""

    chunk_id: str
    title: str
    content: str
    page_start: int | None = None
    page_end: int | None = None
    parent_chapter_id: str = ""
    children_ids: list[str] = Field(default_factory=list)

    # Enrichment fields
    section_summary: str = ""
    key_points: list[str] = Field(default_factory=list)
    concepts_introduced: list[str] = Field(default_factory=list)


class L1Chunk(BaseModel):
    """Chapter-level chunk (~300-500 tokens)."""

    chunk_id: str
    title: str
    content: str
    page_start: int | None = None
    page_end: int | None = None
    children_ids: list[str] = Field(default_factory=list)

    # Enrichment fields
    chapter_summary: str = ""
    main_topics: list[str] = Field(default_factory=list)
    learning_objectives: list[str] = Field(default_factory=list)
    prerequisite_chapters: list[str] = Field(default_factory=list)
    key_takeaways: list[str] = Field(default_factory=list)


class L0Chunk(BaseModel):
    """Document-level chunk (~500 tokens). Always returned as context."""

    chunk_id: str
    title: str
    author: str = ""
    domain: str = ""
    creation_date: str = ""
    source_language: str = ""
    toc_summary: str = ""
    key_concepts: list[str] = Field(default_factory=list, max_length=200)
    total_pages: int = Field(default=0, ge=0)
    total_chapters: int = Field(default=0, ge=0)
    total_sections: int = Field(default=0, ge=0)
    total_passages: int = Field(default=0, ge=0)

    # Digest fields (populated by Stage 4)
    executive_summary: str = ""
    key_findings: list[str] = Field(default_factory=list, max_length=100)
    methodology: str = ""
    limitations: str = ""
    document_type: str = ""
    target_audience: str = ""


class ChunkSet(BaseModel):
    """Complete set of chunks for a document (output of Stage 3)."""

    doc_id: str
    l0: L0Chunk
    l1_chunks: list[L1Chunk] = Field(default_factory=list)
    l2_chunks: list[L2Chunk] = Field(default_factory=list)
    l3_chunks: list[L3Chunk] = Field(default_factory=list)

    # Structured citations (populated by Stage 4 when profile enables it)
    citations: list[Citation] = Field(default_factory=list)

    # Knowledge graph triples (populated by Stage 4 when enabled)
    knowledge_graph: list[KGTriple] = Field(default_factory=list)
