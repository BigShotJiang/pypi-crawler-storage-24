"""Document ingestion pipeline — transforms documents into a queryable knowledge store."""
