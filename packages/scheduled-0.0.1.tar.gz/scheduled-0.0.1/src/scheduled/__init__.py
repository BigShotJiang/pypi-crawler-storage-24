def main() -> None:
    print("Hello from scheduled!")
