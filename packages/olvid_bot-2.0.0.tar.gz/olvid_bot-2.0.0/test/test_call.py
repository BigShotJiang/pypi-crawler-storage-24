import logging

from olvid import datatypes, listeners

from ClientHolder import ClientWrapper, ClientHolder


async def test_start_discussion_call(c1: ClientWrapper, c2: ClientWrapper):
	discussion_1, discussion_2 = await c1.get_discussion_associated_to_another_client(c2), await c2.get_discussion_associated_to_another_client(c1)
	contact_1, contact_2 = await c1.get_contact_associated_to_another_client(c2), await c2.get_contact_associated_to_another_client(c1)

	call_id: str = await c1.call_start_discussion_call(discussion_id=discussion_1.id)
	bots = [
		# when you can a bot, he does not send the ringing message
		# c1.create_notification_bot(listeners.CallRingingListener(handler=c1.get_check_content_handler(call_id, notification_type=listeners.NOTIFICATIONS.CALL_RINGING), count=1)),
		c1.create_notification_bot(listeners.CallBusyListener(handler=c1.get_check_content_handler(call_id, datatypes.CallParticipantId(contact_id=contact_1.id), notification_type=listeners.NOTIFICATIONS.CALL_BUSY), count=1)),
		c1.create_notification_bot(listeners.CallEndedListener(handler=c1.get_check_content_handler(call_id, notification_type=listeners.NOTIFICATIONS.CALL_ENDED), count=1)),

		c2.create_notification_bot(listeners.CallIncomingCallListener(handler=c2.get_check_content_handler(call_id, discussion_2.id, datatypes.CallParticipantId(contact_id=contact_2.id), contact_2.display_name, 1, notification_type=listeners.NOTIFICATIONS.CALL_INCOMING_CALL), count=1)),
	]

	for bot in bots:
		await bot.wait_for_listeners_end()

async def test_start_custom_call(c1: ClientWrapper, clients: list[ClientWrapper]):
	contacts_1: list[datatypes.Contact] = [await c1.get_contact_associated_to_another_client(c) for c in clients]
	contacts_2: list[datatypes.Contact] = [await c.get_contact_associated_to_another_client(c1) for c in clients]
	discussions_2: list[datatypes.Discussion] = [await c.get_discussion_associated_to_another_client(c1) for c in clients]

	call_id: str = await c1.call_start_custom_call(contact_ids=[c.id for c in contacts_1])
	bots = [
		# when you can a bot, he does not send the ringing message
		# c1.create_notification_bot(listeners.CallRingingListener(handler=c1.get_check_content_handler(call_id, notification_type=listeners.NOTIFICATIONS.CALL_RINGING), count=1)),
		c1.create_notification_bot(listeners.CallEndedListener(handler=c1.get_check_content_handler(call_id, notification_type=listeners.NOTIFICATIONS.CALL_ENDED), count=1)),
	]
	for contact_1, contact_2, discussion_2, client in zip(contacts_1, contacts_2, discussions_2, clients):
		bots.append(c1.create_notification_bot(listeners.CallBusyListener(handler=c1.get_check_content_handler(call_id, datatypes.CallParticipantId(), notification_type=listeners.NOTIFICATIONS.CALL_BUSY), count=len(clients))))
		bots.append(client.create_notification_bot(listeners.CallIncomingCallListener(handler=client.get_check_content_handler(call_id, discussion_2.id, datatypes.CallParticipantId(contact_id=contact_2.id), contact_2.display_name, len(clients), notification_type=listeners.NOTIFICATIONS.CALL_INCOMING_CALL), count=1)))

	for bot in bots:
		await bot.wait_for_listeners_end()


async def test_call(client_holder: ClientHolder):
	for c1, c2 in client_holder.get_one_client_pair_and_reverse():
		logging.info(f"{c1.identity.id} <-> {c2.identity.id}: discussion call")
		await test_start_discussion_call(c1, c2)
	logging.info(f"custom call")
	await test_start_custom_call(client_holder.clients[0], client_holder.clients[1:])


