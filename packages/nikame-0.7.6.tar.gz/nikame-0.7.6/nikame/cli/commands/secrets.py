"""nikame secrets — Manage project credentials.

Regenerates and rotates secrets for infrastructure services,
updates .env.generated, and restarts affected containers.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from nikame.codegen.credential_vault import CredentialVault
from nikame.utils.logger import console, get_logger

_log = get_logger("cli.secrets")


@click.group("secrets")
def secrets_group() -> None:
    """Manage project secrets and credentials."""


@secrets_group.command("rotate")
@click.argument("service", required=False, default=None)
@click.option("--all", "rotate_all", is_flag=True, help="Rotate all service credentials")
@click.option("--dir", "project_dir", default=".", help="Project directory")
def rotate_secrets(
    service: str | None,
    rotate_all: bool,
    project_dir: str,
) -> None:
    """Rotate credentials for a service (or all services).

    Examples:
        nikame secrets rotate postgres
        nikame secrets rotate jwt
        nikame secrets rotate --all
    """
    project_path = Path(project_dir).resolve()
    env_generated = project_path / ".env.generated"

    if not env_generated.exists():
        console.print("[red]✗ No .env.generated found in this project.[/red]")
        console.print("  Run [bold]nikame init[/bold] first.")
        raise SystemExit(1)

    # Detect project name from env
    project_name = _detect_project_name(env_generated)

    vault = CredentialVault(project_name)

    if rotate_all:
        services_to_rotate = _detect_active_services(env_generated)
    elif service:
        services_to_rotate = [service]
    else:
        console.print("[red]✗ Specify a service name or use --all[/red]")
        console.print("  Example: [bold]nikame secrets rotate postgres[/bold]")
        raise SystemExit(1)

    console.print(f"\n[bold]🔄 Rotating credentials...[/bold]\n")

    all_updates: dict[str, str] = {}
    all_affected: set[str] = set()

    for svc in services_to_rotate:
        try:
            rotated = vault.rotate(svc)
            all_updates.update(rotated)
            affected = vault.affected_services(svc)
            all_affected.update(affected)

            for var_name, var_value in rotated.items():
                # Mask the value for display
                masked = var_value[:4] + "****" if len(var_value) > 8 else "****"
                console.print(f"  ✓ {var_name} = {masked}")

        except ValueError as exc:
            console.print(f"  [yellow]⚠ {exc}[/yellow]")

    if not all_updates:
        console.print("[yellow]No credentials rotated.[/yellow]")
        return

    # Update .env.generated
    vault.update_env_file(env_generated, all_updates)
    console.print(f"\n[green]✓ Updated {env_generated}[/green]")

    # Also update .env if it exists
    env_file = project_path / ".env"
    if env_file.exists():
        vault.update_env_file(env_file, all_updates)
        console.print(f"[green]✓ Updated {env_file}[/green]")

    # Restart affected services
    _restart_services(project_path, list(all_affected), project_name)


@secrets_group.command("show")
@click.option("--dir", "project_dir", default=".", help="Project directory")
@click.option("--reveal", is_flag=True, help="Show actual values (not masked)")
def show_secrets(project_dir: str, reveal: bool) -> None:
    """Show current project credentials (masked by default)."""
    project_path = Path(project_dir).resolve()
    env_generated = project_path / ".env.generated"

    if not env_generated.exists():
        console.print("[red]✗ No .env.generated found.[/red]")
        raise SystemExit(1)

    content = env_generated.read_text(encoding="utf-8")
    sensitive_keywords = {"PASSWORD", "SECRET", "TOKEN", "KEY"}

    console.print(f"\n[bold]🔐 Credentials in {env_generated.name}[/bold]\n")

    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            console.print(f"  [dim]{line}[/dim]")
            continue

        if "=" in stripped:
            key, _, value = stripped.partition("=")
            is_sensitive = any(kw in key.upper() for kw in sensitive_keywords)

            if is_sensitive and not reveal:
                masked = value[:4] + "****" if len(value) > 8 else "****"
                console.print(f"  {key}=[dim]{masked}[/dim]")
            else:
                console.print(f"  {key}={value}")

    if not reveal:
        console.print(f"\n  [dim]Use --reveal to see full values[/dim]")


# ──────────────────── Helpers ────────────────────


def _detect_project_name(env_path: Path) -> str:
    """Extract project name from .env.generated."""
    content = env_path.read_text(encoding="utf-8")
    for line in content.splitlines():
        if line.startswith("APP_NAME="):
            return line.split("=", 1)[1].strip()
        if line.startswith("POSTGRES_DB="):
            return line.split("=", 1)[1].strip()
    return "project"


def _detect_active_services(env_path: Path) -> list[str]:
    """Detect which services have credentials in .env.generated."""
    content = env_path.read_text(encoding="utf-8")
    services: set[str] = set()

    service_indicators = {
        "POSTGRES_PASSWORD": "postgres",
        "REDIS_PASSWORD": "dragonfly",
        "JWT_SECRET_KEY": "jwt",
        "MINIO_ROOT_PASSWORD": "minio",
        "KEYCLOAK_ADMIN_PASSWORD": "keycloak",
        "GRAFANA_ADMIN_PASSWORD": "grafana",
    }

    for line in content.splitlines():
        stripped = line.strip()
        if "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
            if key in service_indicators:
                services.add(service_indicators[key])

    return sorted(services)


def _restart_services(
    project_path: Path,
    services: list[str],
    project_name: str,
) -> None:
    """Restart affected Docker Compose services."""
    import subprocess

    compose_file = project_path / "infra" / "docker-compose.yml"
    if not compose_file.exists():
        console.print("[yellow]⚠ No docker-compose.yml found — restart manually.[/yellow]")
        return

    if not services:
        return

    console.print(f"\n[bold]♻ Restarting affected services...[/bold]")
    service_list = ", ".join(services)
    console.print(f"  Services: {service_list}")

    try:
        result = subprocess.run(  # noqa: S603
            [
                "docker", "compose",
                "-f", str(compose_file),
                "-p", project_name,
                "restart",
                *services,
            ],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            console.print(f"  [green]✓ {len(services)} service(s) restarted[/green]")
        else:
            console.print(f"  [yellow]⚠ Restart returned code {result.returncode}[/yellow]")
            if result.stderr:
                console.print(f"  {result.stderr.strip()}")
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        console.print(f"  [yellow]⚠ Could not restart: {exc}[/yellow]")
        console.print(f"  Run manually: docker compose -f {compose_file} restart {' '.join(services)}")
