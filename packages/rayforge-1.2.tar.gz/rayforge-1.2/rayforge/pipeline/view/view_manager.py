from __future__ import annotations
import logging
import numpy as np
import threading
import time
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING, Dict, Optional, Set, cast, Tuple

from blinker import Signal

from ..artifact import (
    BaseArtifactHandle,
    WorkPieceArtifactHandle,
)
from ..artifact.key import ArtifactKey
from ..artifact.workpiece_view import (
    RenderContext,
    WorkPieceViewArtifact,
    WorkPieceViewArtifactHandle,
)
from .view_compute import calculate_render_dimensions
from .view_runner import (
    make_workpiece_view_artifact_in_subprocess,
    render_chunk_to_view,
)

if TYPE_CHECKING:
    from ...core.doc import Doc
    from ...core.step import Step
    from ...core.workpiece import WorkPiece
    from ...machine.models.machine import Machine
    from ...shared.tasker.task import Task
    from ..artifact.store import ArtifactStore
    from ..pipeline import Pipeline


logger = logging.getLogger(__name__)

THROTTLE_INTERVAL = 0.033


@dataclass
class ViewEntry:
    """Holds state for a single view artifact."""

    handle: Optional[WorkPieceViewArtifactHandle] = None
    render_context: Optional[RenderContext] = None
    source_handle: Optional[WorkPieceArtifactHandle] = None


class ViewManager:
    """
    Manages view rendering for workpieces, decoupled from the data pipeline.

    The ViewManager is responsible for:
    - Maintaining the current RenderContext (from UI events like zoom/pan)
    - Tracking source WorkPieceArtifact handles it is displaying
    - Triggering rendering tasks when source data or render context changes
    - Managing view artifact lifecycle (retain/release handles)

    It indexes views by (workpiece_uid, step_uid) to support visualizing
    intermediate states of a workpiece across multiple steps.

    Shared Memory Lifecycle
    -----------------------
    The ViewManager retains handles for two purposes:

    1. Source artifact tracking: Handles in _source_artifact_handles are
       retained when stored and released in shutdown() or reconcile().

    2. Async task execution: Handles are retained before launching a task
       and released in the task's completion callback (e.g., when_done).

    Every retain() is paired with a release() to prevent memory leaks.
    """

    def __init__(
        self,
        pipeline: "Pipeline",
        artifact_store: "ArtifactStore",
        machine: Optional["Machine"],
    ):
        self._pipeline = pipeline
        self._store = artifact_store
        self._task_manager = pipeline.task_manager
        self._machine = machine
        self._current_view_context: Optional[RenderContext] = None
        self._view_generation_id = 0
        self._is_shutdown = False

        # Keys are (workpiece_uid, step_uid)
        self._source_artifact_handles: Dict[
            Tuple[str, str], WorkPieceArtifactHandle
        ] = {}
        self._view_entries: Dict[Tuple[str, str], ViewEntry] = {}

        # Mapping from (workpiece_uid, step_uid) to a stable ArtifactKey
        # used for task management (deduplication/cancellation).
        self._view_task_keys: Dict[Tuple[str, str], ArtifactKey] = {}

        # Throttling state keyed by the composite key (workpiece_uid, step_uid)
        self._pending_updates: Dict[Tuple[str, str], bool] = {}
        self._last_update_time: Dict[Tuple[str, str], float] = {}
        self._throttle_timers: Dict[Tuple[str, str], threading.Timer] = {}

        # Track in-flight chunk handles for cleanup during shutdown
        self._inflight_chunk_handles: Set[BaseArtifactHandle] = set()

        self.view_artifact_ready = Signal()
        self.view_artifact_created = Signal()
        self.view_artifact_updated = Signal()
        self.generation_finished = Signal()
        self.source_artifact_ready = Signal()

        self._connect_pipeline_signals()

    def _connect_pipeline_signals(self):
        """Connect to pipeline signals."""
        self._pipeline.workpiece_artifact_ready.connect(
            self.on_workpiece_artifact_ready
        )
        self._pipeline.workpiece_starting.connect(self.on_generation_starting)
        self._pipeline.step_assembly_starting.connect(
            self.on_workpiece_artifact_ready
        )
        self._pipeline.visual_chunk_available.connect(self.on_chunk_available)

        if self._pipeline.doc:
            self._pipeline.doc.descendant_removed.connect(
                self._on_doc_item_removed
            )

    def _disconnect_pipeline_signals(self):
        """Disconnect from pipeline signals."""
        self._pipeline.workpiece_artifact_ready.disconnect(
            self.on_workpiece_artifact_ready
        )
        self._pipeline.workpiece_starting.disconnect(
            self.on_generation_starting
        )
        self._pipeline.step_assembly_starting.disconnect(
            self.on_workpiece_artifact_ready
        )
        self._pipeline.visual_chunk_available.disconnect(
            self.on_chunk_available
        )

        if self._pipeline.doc:
            self._pipeline.doc.descendant_removed.disconnect(
                self._on_doc_item_removed
            )

    def _on_doc_item_removed(self, sender, *, origin, parent_of_origin):
        """Handle removal of workpieces and steps from the document."""
        from ...core.step import Step
        from ...core.workpiece import WorkPiece

        if isinstance(origin, WorkPiece):
            self._cleanup_views_for_workpiece(origin.uid)
        elif isinstance(origin, Step):
            self._cleanup_views_for_step(origin.uid)

    def _cleanup_views_for_workpiece(self, workpiece_uid: str):
        """Remove all view entries for a workpiece."""
        # Collect keys from both _view_entries and _source_artifact_handles
        all_keys = set(self._view_entries.keys()) | set(
            self._source_artifact_handles.keys()
        )
        keys_to_remove = [
            composite_id
            for composite_id in all_keys
            if composite_id[0] == workpiece_uid
        ]
        for composite_id in keys_to_remove:
            self._remove_view_entry(composite_id)

        # Release any inflight chunk handles for this workpiece.
        # These are chunks that were being stitched to views when the
        # workpiece was deleted.
        handles_to_release = list(self._inflight_chunk_handles)
        for handle in handles_to_release:
            self._inflight_chunk_handles.discard(handle)
            self._store.release(handle)
        if handles_to_release:
            logger.debug(
                f"Released {len(handles_to_release)} inflight chunk handles "
                f"for deleted workpiece {workpiece_uid}"
            )

        if keys_to_remove:
            logger.debug(
                f"Cleaned up {len(keys_to_remove)} view entries for "
                f"workpiece {workpiece_uid}"
            )

    def _cleanup_views_for_step(self, step_uid: str):
        """Remove all view entries for a step."""
        # Collect keys from both _view_entries and _source_artifact_handles
        all_keys = set(self._view_entries.keys()) | set(
            self._source_artifact_handles.keys()
        )
        keys_to_remove = [
            composite_id
            for composite_id in all_keys
            if composite_id[1] == step_uid
        ]
        for composite_id in keys_to_remove:
            self._remove_view_entry(composite_id)

        # Release any inflight chunk handles for this step.
        handles_to_release = list(self._inflight_chunk_handles)
        for handle in handles_to_release:
            self._inflight_chunk_handles.discard(handle)
            self._store.release(handle)
        if handles_to_release:
            logger.debug(
                f"Released {len(handles_to_release)} inflight chunk handles "
                f"for deleted step {step_uid}"
            )

        if keys_to_remove:
            logger.debug(
                f"Cleaned up {len(keys_to_remove)} view entries for "
                f"step {step_uid}"
            )

    def _remove_view_entry(self, composite_id: tuple):
        """Remove a view entry and release its resources."""
        entry = self._view_entries.pop(composite_id, None)
        if entry:
            if entry.handle:
                self._store.release(entry.handle)

        source_handle = self._source_artifact_handles.pop(composite_id, None)
        if source_handle:
            self._store.release(source_handle)

        task_key = self._view_task_keys.pop(composite_id, None)
        if task_key:
            self._task_manager.cancel_task(task_key)

        timer = self._throttle_timers.pop(composite_id, None)
        if timer:
            timer.cancel()
        self._pending_updates.pop(composite_id, None)
        self._last_update_time.pop(composite_id, None)

    @property
    def current_view_context(self) -> Optional[RenderContext]:
        """Returns the current render context."""
        return self._current_view_context

    @property
    def view_generation_id(self) -> int:
        """Returns the current view generation ID."""
        return self._view_generation_id

    @property
    def store(self) -> "ArtifactStore":
        """Returns the artifact store."""
        return self._store

    def _get_task_key(self, workpiece_uid: str, step_uid: str) -> ArtifactKey:
        """
        Retrieves or creates a stable ArtifactKey for managing tasks associated
        with a specific (workpiece, step) view.
        """
        composite_id = (workpiece_uid, step_uid)
        if composite_id not in self._view_task_keys:
            self._view_task_keys[composite_id] = ArtifactKey(
                id=str(uuid.uuid4()), group="view"
            )
        return self._view_task_keys[composite_id]

    def _get_laser_uid_for_step(self, step_uid: str) -> Optional[str]:
        """
        Look up the laser_uid for a step by its UID.

        Args:
            step_uid: The unique identifier of the step.

        Returns:
            The laser_uid for the step, or None if not found.
        """
        doc = self._pipeline.doc
        if doc is None:
            return None

        for layer in doc.layers:
            if layer.workflow:
                for step in layer.workflow.steps:
                    if step.uid == step_uid:
                        return step.selected_laser_uid
        return None

    def _is_view_stale(
        self,
        workpiece_uid: str,
        step_uid: str,
        new_context: Optional[RenderContext],
        source_handle: Optional[WorkPieceArtifactHandle],
    ) -> bool:
        """Check if a view needs re-rendering."""
        composite_id = (workpiece_uid, step_uid)
        entry = self._view_entries.get(composite_id)

        if entry is None or entry.handle is None:
            logger.debug(f"_is_view_stale[{composite_id}]: no entry -> STALE")
            return True

        if new_context is not None:
            if entry.render_context is None:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: no context -> STALE"
                )
                return True
            if entry.render_context != new_context:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: context changed -> STALE"
                )
                return True

        if source_handle is not None:
            if entry.source_handle is None:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: no src handle -> STALE"
                )
                return True
            if entry.source_handle.shm_name != source_handle.shm_name:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: "
                    f"shm_name changed -> STALE"
                )
                return True
            entry_gen_size = entry.source_handle.generation_size
            new_gen_size = source_handle.generation_size
            if entry_gen_size != new_gen_size:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: "
                    f"gen_size {entry_gen_size} -> {new_gen_size} -> STALE"
                )
                return True
            entry_src_dims = entry.source_handle.source_dimensions
            new_src_dims = source_handle.source_dimensions
            if entry_src_dims != new_src_dims:
                logger.debug(
                    f"_is_view_stale[{composite_id}]: "
                    f"src_dims {entry_src_dims} -> {new_src_dims} -> STALE"
                )
                return True

        return False

    def update_render_context(
        self,
        context: RenderContext,
    ) -> None:
        """
        Updates the view context and triggers re-rendering for tracked
        workpieces if the context has changed significantly.

        Args:
            context: The new render context to apply.
        """
        if self._current_view_context == context:
            logger.debug("update_render_context: Context unchanged, skipping")
            return

        new_ppm = context.pixels_per_mm[0]

        logger.debug(
            f"update_render_context called with context "
            f"ppm={context.pixels_per_mm}, "
            f"show_travel_moves={context.show_travel_moves}"
        )

        self._current_view_context = context
        self._view_generation_id += 1

        # Re-render each view only if its rendered ppm differs from the
        # requested ppm by more than 25%. This avoids frequent re-renders
        # during small zoom adjustments.
        for key, entry in self._view_entries.items():
            old_ppm = 0.0
            old_show_travel = False
            if entry.render_context is not None:
                old_ppm = entry.render_context.pixels_per_mm[0]
                old_show_travel = entry.render_context.show_travel_moves

            ppm_changed = (
                old_ppm <= 0 or abs(new_ppm - old_ppm) / old_ppm > 0.25
            )
            travel_changed = old_show_travel != context.show_travel_moves
            logger.debug(
                f"update_render_context: key={key}, old_ppm={old_ppm:.2f}, "
                f"new_ppm={new_ppm:.2f}, ppm_changed={ppm_changed}, "
                f"travel_changed={travel_changed}"
            )
            if ppm_changed or travel_changed:
                self.request_view_render(key[0], key[1])

    def _handles_represent_same_artifact(
        self,
        handle1: Optional[WorkPieceArtifactHandle],
        handle2: Optional[WorkPieceArtifactHandle],
    ) -> bool:
        """
        Check if two handles represent the same artifact.

        Two handles represent the same artifact if they point to the same
        shared memory (shm_name), have the same generation_size, and the
        same source_dimensions.

        Returns True if both handles are None, or if they represent the
        same artifact.
        """
        if handle1 is None and handle2 is None:
            return True
        if handle1 is None or handle2 is None:
            return False
        return (
            handle1.shm_name == handle2.shm_name
            and handle1.generation_size == handle2.generation_size
            and handle1.source_dimensions == handle2.source_dimensions
        )

    def on_workpiece_artifact_ready(
        self,
        sender,
        *,
        step: "Step",
        workpiece: "WorkPiece",
        handle: BaseArtifactHandle,
        **kwargs,
    ) -> None:
        """
        Handler for the pipeline.workpiece_artifact_ready signal.

        This method manages the source artifact handles:
        - Releases any old handle for this workpiece (if not in use by tasks)
        - Retains the new handle
        - Triggers a view render

        If the handle represents the same artifact as the existing one
        (e.g., when step_assembly_starting is emitted during a
        position-only transform change), no signal is emitted to avoid
        unnecessary UI redraws.

        Args:
            sender: The signal sender.
            step: The step for which the artifact is ready.
            workpiece: The workpiece whose artifact is ready.
            handle: The artifact handle.
            **kwargs: Additional keyword arguments.
        """
        if self._is_shutdown:
            return

        doc = self._pipeline.doc
        if not doc:
            return

        workpiece_exists = any(
            wp.uid == workpiece.uid for wp in doc.all_workpieces
        )
        if not workpiece_exists:
            return

        step_exists = any(
            s.uid == step.uid
            for layer in doc.layers
            if layer.workflow
            for s in layer.workflow.steps
        )
        if not step_exists:
            return

        if not isinstance(handle, WorkPieceArtifactHandle):
            logger.warning(
                f"Expected WorkPieceArtifactHandle, got {type(handle)}"
            )
            return

        composite_id = (workpiece.uid, step.uid)

        old_handle = self._source_artifact_handles.get(composite_id)
        wp_handle = cast(WorkPieceArtifactHandle, handle)

        same_artifact = self._handles_represent_same_artifact(
            old_handle, wp_handle
        )

        logger.debug(
            f"on_workpiece_artifact_ready: composite_id={composite_id}, "
            f"old_handle={old_handle.shm_name if old_handle else None}, "
            f"new_handle={wp_handle.shm_name}, "
            f"same_artifact={same_artifact}"
        )

        if not same_artifact:
            if old_handle is not None:
                logger.debug(
                    f"Releasing old source artifact handle for {composite_id}"
                )
                self._store.release(old_handle)

            self._source_artifact_handles[composite_id] = wp_handle
            self._store.retain(wp_handle)
            logger.debug(
                f"Retained new source artifact handle for {composite_id}"
            )

            self.request_view_render(workpiece.uid, step_uid=step.uid)

            self.source_artifact_ready.send(
                self,
                step=step,
                workpiece=workpiece,
                handle=wp_handle,
            )
        else:
            logger.debug(
                f"Same artifact already tracked for {composite_id}, "
                "skipping signal emission"
            )

    def request_view_render(
        self,
        workpiece_uid: str,
        step_uid: str,
    ) -> None:
        """
        Requests an asynchronous render of a workpiece view for a specific
        step.

        Args:
            workpiece_uid: The unique identifier of the workpiece.
            step_uid: The unique identifier of the step (optional).
        """
        if self._current_view_context is None:
            logger.debug(
                f"Cannot render view for ({workpiece_uid}, {step_uid}): "
                "No render context set."
            )
            return

        context = self._current_view_context
        view_id = self._view_generation_id

        # Get the unique task key for this specific view slot
        task_key = self._get_task_key(workpiece_uid, step_uid)

        source_handle = self._source_artifact_handles.get(
            (workpiece_uid, step_uid)
        )
        if source_handle is None:
            logger.warning(
                f"Cannot render view for ({workpiece_uid}, {step_uid}): "
                "No source artifact handle tracked."
            )
            return

        self._request_view_render_internal(
            task_key,
            context,
            view_id,
            source_handle,
            step_uid,
            workpiece_uid,
        )

    def _request_view_render_internal(
        self,
        key: ArtifactKey,
        context: RenderContext,
        view_id: int,
        source_handle: WorkPieceArtifactHandle,
        step_uid: str,
        workpiece_uid: str,
    ):
        """
        Internal method to request a view render.

        Args:
            key: The ArtifactKey for the workpiece view.
            context: The render context to use.
            view_id: The view generation ID for this render.
            source_handle: The source WorkPieceArtifact handle.
            step_uid: The unique identifier of the step (optional).
            workpiece_uid: The unique identifier of the workpiece.
        """
        logger.debug(
            f"_request_view_render_internal: workpiece_uid={workpiece_uid}, "
            f"step_uid={step_uid}, source_shm={source_handle.shm_name}"
        )
        if not self._is_view_stale(
            workpiece_uid, step_uid, context, source_handle
        ):
            logger.debug(f"View for ({workpiece_uid}, {step_uid}) is valid.")
            return

        self._current_view_context = context

        task = self._task_manager.get_task(key)
        if task and not task.is_final():
            logger.debug(
                f"[{key}] View render already in progress. Cancelling."
            )
            self._task_manager.cancel_task(key)

        composite_id = (workpiece_uid, step_uid)
        entry = self._view_entries.get(composite_id)
        if entry is None:
            entry = ViewEntry()
            self._view_entries[composite_id] = entry
        entry.render_context = context
        entry.source_handle = source_handle

        # Retain source handle for the duration of this task
        self._store.retain(source_handle)
        task_source_handle = source_handle

        def when_done_callback(task: "Task"):
            logger.debug(
                f"[{key}] when_done_callback called, "
                f"task_status={task.get_status()}"
            )
            if task.get_status() == "canceled":
                logger.debug(
                    f"[{key}] Task was cancelled, skipping "
                    "_on_render_complete signal."
                )
            else:
                self._on_render_complete(
                    task, key, view_id, workpiece_uid, step_uid
                )
            self._store.release(task_source_handle)

        laser_uid = self._get_laser_uid_for_step(step_uid)

        self._task_manager.run_process(
            make_workpiece_view_artifact_in_subprocess,
            self._store,
            workpiece_artifact_handle_dict=source_handle.to_dict(),
            render_context_dict=context.to_dict(),
            creator_tag="wp_view",
            key=key,
            generation_id=view_id,
            step_uid=step_uid,
            workpiece_uid=workpiece_uid,
            laser_uid=laser_uid,
            when_done=when_done_callback,
            when_event=self._on_render_event_received,
        )

    def shutdown(self):
        """Cancels any active rendering tasks and releases held handles."""
        logger.debug("ViewManager shutting down.")
        self._is_shutdown = True

        self._disconnect_pipeline_signals()

        # Cancel all managed tasks
        for key in self._view_task_keys.values():
            self._task_manager.cancel_task(key)
        self._view_task_keys.clear()

        for entry in self._view_entries.values():
            if entry.handle is not None:
                self._store.release(entry.handle)
        self._view_entries.clear()

        for timer in self._throttle_timers.values():
            if timer:
                timer.cancel()
        self._throttle_timers.clear()
        self._pending_updates.clear()
        self._last_update_time.clear()

        for handle in self._source_artifact_handles.values():
            self._store.release(handle)
        self._source_artifact_handles.clear()

        # Release any in-flight chunk handles that weren't cleaned up
        for handle in self._inflight_chunk_handles:
            self._store.release(handle)
        self._inflight_chunk_handles.clear()

    def _on_render_event_received(
        self, task: "Task", event_name: str, data: dict
    ):
        """Handles progressive rendering events from the worker process."""
        step_uid = task.kwargs.get("step_uid")
        workpiece_uid = task.kwargs.get("workpiece_uid")

        if step_uid is None or workpiece_uid is None:
            logger.warning("Missing uids in _on_render_event_received")
            return

        key = task.key
        view_id = task.kwargs.get("generation_id", 0)

        if event_name == "view_artifact_created":
            self._handle_view_artifact_created(
                task, key, step_uid, workpiece_uid, data, view_id
            )
        elif event_name == "view_artifact_updated":
            self._handle_view_artifact_updated(
                key, step_uid, workpiece_uid, view_id
            )

    def _handle_view_artifact_created(
        self,
        task: "Task",
        key: ArtifactKey,
        step_uid: str,
        workpiece_uid: str,
        data: dict,
        view_id: int,
    ):
        """
        Handles the view_artifact_created event from a worker process.

        Adopts the handle from the worker and stores it in the view entry.
        The safe_adoption context manager ensures the handle is released
        if any validation fails.

        Args:
            task: The task that produced this event.
            key: The artifact key for the task.
            step_uid: The step UID for this view.
            workpiece_uid: The workpiece UID for this view.
            data: Event data containing handle_dict.
            view_id: The view generation ID.
        """
        handle_dict = data.get("handle_dict")
        if handle_dict is None:
            logger.warning(
                f"_handle_view_artifact_created: Missing handle_dict in "
                f"event data for {key}"
            )
            return

        try:
            with self._store.safe_adoption(handle_dict) as handle:
                self._validate_and_store_view_handle(
                    handle, step_uid, workpiece_uid
                )
        except ValueError as e:
            logger.debug(
                f"_handle_view_artifact_created: Validation failed for "
                f"{key}: {e}"
            )
        except Exception as e:
            logger.error(
                f"Failed to process view_artifact_created for {key}: {e}",
                exc_info=True,
            )

    def _validate_and_store_view_handle(
        self,
        handle: BaseArtifactHandle,
        step_uid: str,
        workpiece_uid: str,
    ) -> None:
        """
        Validate and store a view handle in the appropriate entry.

        This method is called within the safe_adoption context, so any
        exception will cause the handle to be released automatically.

        Args:
            handle: The handle to validate and store.
            step_uid: The step UID for this view.
            workpiece_uid: The workpiece UID for this view.

        Raises:
            ValueError: If validation fails.
            TypeError: If handle type is incorrect.
        """
        if self._is_shutdown:
            raise ValueError("ViewManager is shutdown")

        doc = self._pipeline.doc
        if doc is None:
            raise ValueError("No document")

        workpiece_exists = any(
            wp.uid == workpiece_uid for wp in doc.all_workpieces
        )
        step_exists = any(
            step.uid == step_uid
            for layer in doc.layers
            if layer.workflow
            for step in layer.workflow.steps
        )

        if not workpiece_exists or not step_exists:
            raise ValueError("Workpiece or Step deleted")

        if not isinstance(handle, WorkPieceViewArtifactHandle):
            raise TypeError(
                f"Expected WorkPieceViewArtifactHandle, got {type(handle)}"
            )

        composite_id = (workpiece_uid, step_uid)
        entry = self._view_entries.get(composite_id)
        if entry is None:
            entry = ViewEntry()
            self._view_entries[composite_id] = entry

        # Release old handle before storing new one
        if entry.handle is not None:
            self._store.release(entry.handle)

        # Store the handle - safe_adoption already gave us ownership
        # with refcount=1, so no retain() needed here
        entry.handle = handle

        self._send_view_artifact_created_signals(
            step_uid, workpiece_uid, handle
        )

    def _send_view_artifact_created_signals(
        self,
        step_uid: str,
        workpiece_uid: str,
        handle: WorkPieceViewArtifactHandle,
    ):
        """Sends signals when a view artifact is created."""
        logger.debug(
            f"_send_view_artifact_created_signals: step_uid={step_uid}, "
            f"workpiece_uid={workpiece_uid}"
        )
        self.view_artifact_created.send(
            self,
            step_uid=step_uid,
            workpiece_uid=workpiece_uid,
            handle=handle,
        )
        self.view_artifact_ready.send(
            self,
            step_uid=step_uid,
            workpiece_uid=workpiece_uid,
            handle=handle,
        )

    def _handle_view_artifact_updated(
        self, key: ArtifactKey, step_uid: str, workpiece_uid: str, view_id: int
    ):
        """Handles the view_artifact_updated event."""
        logger.debug(
            f"_handle_view_artifact_updated: step_uid={step_uid}, "
            f"workpiece_uid={workpiece_uid}, view_id={view_id}"
        )
        composite_id = (workpiece_uid, step_uid)
        entry = self._view_entries.get(composite_id)
        handle = entry.handle if entry else None
        self.view_artifact_updated.send(
            self,
            step_uid=step_uid,
            workpiece_uid=workpiece_uid,
            handle=handle,
        )

    def _on_render_complete(
        self,
        task: "Task",
        key: ArtifactKey,
        view_id: int,
        workpiece_uid: str,
        step_uid: str,
    ):
        """Callback for when a rendering task finishes."""
        self.generation_finished.send(
            self,
            key=key,
            workpiece_uid=workpiece_uid,
            step_uid=step_uid,
        )

    def on_chunk_available(
        self,
        sender,
        *,
        key: ArtifactKey,
        chunk_handle: BaseArtifactHandle,
        generation_id: int,
        step_uid: Optional[str] = None,
        **kwargs,
    ):
        """
        Receives chunk data from the pipeline.

        Implements incremental rendering by drawing the chunk onto
        the live view artifact bitmap. The chunk_handle is passed
        directly from the signal emitter and must be retained if we
        want to keep it.

        Args:
            sender: The signal sender.
            key: The artifact key containing workpiece identifier.
            chunk_handle: Handle to the chunk artifact to render.
            generation_id: The generation ID for staleness checking.
            step_uid: The step UID, required for processing.
            **kwargs: Additional keyword arguments.
        """
        if step_uid is None:
            logger.debug(
                f"on_chunk_available: Missing step_uid for key {key.id}, "
                "skipping"
            )
            return

        workpiece_uid = self._extract_workpiece_uid_from_key(key.id)
        composite_id = (workpiece_uid, step_uid)

        entry = self._view_entries.get(composite_id)
        if entry is None:
            logger.debug(
                f"on_chunk_available: No view entry for {composite_id}, "
                "skipping chunk"
            )
            return

        view_handle, render_context = self._get_render_components(
            composite_id, entry
        )
        if view_handle is None or render_context is None:
            logger.debug(
                f"on_chunk_available: Missing render components for "
                f"{composite_id}, skipping chunk"
            )
            return

        self._process_chunk_async(
            composite_id, chunk_handle, view_handle, render_context
        )

    def _extract_workpiece_uid_from_key(self, key_id: str) -> str:
        """
        Extract the workpiece UID from a key ID string.

        The key ID format may be "workpiece_uid:extra" or just "workpiece_uid".
        In either case, we extract and return the workpiece_uid portion.

        Args:
            key_id: The key ID string to parse.

        Returns:
            The workpiece_uid portion of the key.
        """
        if ":" in key_id:
            return key_id.split(":", 1)[0]
        return key_id

    def _process_chunk_async(
        self,
        composite_id: Tuple[str, str],
        chunk_handle: BaseArtifactHandle,
        view_handle: BaseArtifactHandle,
        render_context: RenderContext,
    ) -> None:
        """
        Process a chunk asynchronously in a background thread.

        Both handles are retained for the duration of the thread operation
        and released in the completion callback.

        Args:
            composite_id: The (workpiece_uid, step_uid) identifier.
            chunk_handle: Handle to the chunk to render.
            view_handle: Handle to the view to render onto.
            render_context: The render context for the operation.
        """
        _, step_uid = composite_id
        laser_uid = self._get_laser_uid_for_step(step_uid)

        try:
            self._store.retain(view_handle)
            self._store.retain(chunk_handle)
            self._inflight_chunk_handles.add(chunk_handle)

            def _cleanup_chunk_handle(task):
                self._on_stitch_complete(
                    task, composite_id, chunk_handle, view_handle
                )

            self._task_manager.run_thread(
                render_chunk_to_view,
                self._store,
                chunk_handle.to_dict(),
                view_handle.to_dict(),
                render_context.to_dict(),
                laser_uid,
                when_done=_cleanup_chunk_handle,
            )
        except Exception as e:
            logger.error(
                f"Error starting chunk processing thread for "
                f"{composite_id}: {e}"
            )
            self._inflight_chunk_handles.discard(chunk_handle)
            self._store.release(chunk_handle)
            self._store.release(view_handle)

    def _on_stitch_complete(
        self,
        task: "Task",
        composite_id: Tuple[str, str],
        chunk_handle: BaseArtifactHandle,
        view_handle: BaseArtifactHandle,
    ):
        """Callback for when stitching completes."""
        # Remove from tracking first
        self._inflight_chunk_handles.discard(chunk_handle)

        if self._is_shutdown:
            # If shutdown occurred while task was running, force clean up
            self._store.release(chunk_handle)
            self._store.release(view_handle)
            return

        try:
            if task.get_status() == "completed" and task.result():
                view_id = self._view_generation_id
                self._schedule_throttled_update(composite_id, view_id)
            else:
                logger.warning(f"Stitching failed for {composite_id}")
        finally:
            self._store.release(chunk_handle)
            self._store.release(view_handle)

    def _get_render_components(
        self,
        composite_id: Tuple[str, str],
        entry: ViewEntry,
    ) -> tuple[WorkPieceViewArtifactHandle | None, RenderContext | None]:
        """Gets the view handle and render context."""
        if entry.handle is None:
            return None, None

        if not isinstance(entry.handle, WorkPieceViewArtifactHandle):
            return None, None

        render_context = entry.render_context or self._current_view_context
        if render_context is None:
            return None, None

        return entry.handle, render_context

    def _schedule_throttled_update(
        self, composite_id: Tuple[str, str], view_id: int
    ):
        """Schedules a throttled update notification."""
        current_time = time.time()
        last_update = self._last_update_time.get(composite_id, 0)

        existing_timer = self._throttle_timers.pop(composite_id, None)
        if existing_timer:
            existing_timer.cancel()

        self._pending_updates[composite_id] = True

        time_since_last = current_time - last_update
        time_until_next = max(0, THROTTLE_INTERVAL - time_since_last)

        def send_update():
            self._send_throttled_update(composite_id, view_id)

        if time_until_next <= 0:
            send_update()
        else:
            timer = threading.Timer(time_until_next, send_update)
            self._throttle_timers[composite_id] = timer
            timer.start()

    def _send_throttled_update(
        self, composite_id: Tuple[str, str], view_id: int
    ):
        """Sends the view_artifact_updated signal."""
        self._pending_updates.pop(composite_id, None)
        self._throttle_timers.pop(composite_id, None)
        self._last_update_time[composite_id] = time.time()

        workpiece_uid, step_uid = composite_id
        entry = self._view_entries.get(composite_id)
        handle = entry.handle if entry else None

        if not handle:
            return

        self.view_artifact_updated.send(
            self,
            step_uid=step_uid,
            workpiece_uid=workpiece_uid,
            handle=handle,
        )

    def allocate_live_buffer(
        self,
        workpiece: "WorkPiece",
        step_uid: str,
        view_id: int,
        generation_id: int,
        context: RenderContext,
    ) -> None:
        """
        Allocates a new blank view artifact based on the workpiece size and
        registers it as the live buffer for this generation.
        """
        workpiece_uid = workpiece.uid
        composite_id = (workpiece_uid, step_uid)

        w_mm, h_mm = workpiece.size
        bbox = (0.0, 0.0, w_mm, h_mm)

        dims = calculate_render_dimensions(bbox, context)
        if dims is None:
            return

        width_px, height_px, _, _ = dims
        logger.debug(
            f"[{composite_id}] Allocating live buffer: "
            f"{width_px}x{height_px} px"
        )

        try:
            bitmap = np.zeros(shape=(height_px, width_px, 4), dtype=np.uint8)
            view_artifact = WorkPieceViewArtifact(
                bitmap_data=bitmap,
                bbox_mm=bbox,
                workpiece_size_mm=(w_mm, h_mm),
                generation_id=generation_id,
            )

            handle = self._store.put(view_artifact, creator_tag="view_live")
            view_handle = cast(WorkPieceViewArtifactHandle, handle)

            entry = self._view_entries.get(composite_id)
            if entry is None:
                entry = ViewEntry()
                self._view_entries[composite_id] = entry
            if entry.handle is not None:
                self._store.release(entry.handle)
            entry.handle = view_handle
            entry.render_context = context

            self._send_view_artifact_created_signals(
                step_uid, workpiece_uid, view_handle
            )

        except Exception as e:
            logger.error(
                f"[{composite_id}] Failed to allocate live buffer: {e}",
                exc_info=True,
            )

    def on_generation_starting(
        self,
        sender,
        *,
        step: "Step",
        workpiece: "WorkPiece",
        generation_id: int,
    ):
        """
        Called when workpiece generation starts.
        Pre-allocates the view buffer to enable progressive rendering.
        """
        composite_id = (workpiece.uid, step.uid)
        entry = self._view_entries.get(composite_id)
        existing_handle = entry.handle if entry else None

        task_key = self._get_task_key(workpiece.uid, step.uid)
        task = self._task_manager.get_task(task_key)
        if task and not task.is_final():
            self._task_manager.cancel_task(task_key)

        context = self._current_view_context
        if not context:
            return

        need_new_buffer = False
        if existing_handle is None:
            need_new_buffer = True
        elif entry is not None and entry.render_context != context:
            need_new_buffer = True
        else:
            w_mm, h_mm = workpiece.size
            if existing_handle.workpiece_size_mm != (w_mm, h_mm):
                need_new_buffer = True

        if need_new_buffer:
            self.allocate_live_buffer(
                workpiece=workpiece,
                step_uid=step.uid,
                view_id=self._view_generation_id,
                generation_id=self._view_generation_id,
                context=context,
            )

    def reconcile(self, doc: "Doc", generation_id: int):
        """
        Synchronizes the cache with the document, cleaning up obsolete
        entries and syncing the ledger.
        """
        logger.debug("ViewManager reconciling...")

        all_current_pairs = set()
        for layer in doc.layers:
            if layer.workflow and layer.workflow.steps:
                for step in layer.workflow.steps:
                    for workpiece in layer.all_workpieces:
                        all_current_pairs.add((workpiece.uid, step.uid))

        tracked_pairs = set(self._source_artifact_handles.keys())
        obsolete_pairs = tracked_pairs - all_current_pairs

        for composite_id in obsolete_pairs:
            logger.debug(f"Cleaning up obsolete view pair: {composite_id}")
            handle = self._source_artifact_handles.pop(composite_id, None)
            if handle:
                self._store.release(handle)

            task_key = self._view_task_keys.pop(composite_id, None)
            if task_key:
                self._task_manager.cancel_task(task_key)

            entry = self._view_entries.pop(composite_id, None)
            if entry and entry.handle:
                self._store.release(entry.handle)

            self._pending_updates.pop(composite_id, None)
            timer = self._throttle_timers.pop(composite_id, None)
            if timer:
                timer.cancel()
            self._last_update_time.pop(composite_id, None)

    def get_view_handle(
        self, workpiece_uid: str, step_uid: str
    ) -> Optional[WorkPieceViewArtifactHandle]:
        """Get the view handle for a specific workpiece and step."""
        composite_id = (workpiece_uid, step_uid)
        entry = self._view_entries.get(composite_id)
        return entry.handle if entry else None
