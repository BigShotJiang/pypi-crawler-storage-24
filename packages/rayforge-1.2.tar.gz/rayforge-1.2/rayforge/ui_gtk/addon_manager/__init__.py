"""Addon manager UI components."""
