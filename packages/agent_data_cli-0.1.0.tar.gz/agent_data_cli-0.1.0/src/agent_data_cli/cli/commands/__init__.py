from __future__ import annotations

from agent_data_cli.cli.commands.channel import CHANNEL_COMMAND
from agent_data_cli.cli.commands.config import CONFIG_COMMAND
from agent_data_cli.cli.commands.content import CONTENT_COMMAND
from agent_data_cli.cli.commands.dashboard import DASHBOARD_COMMAND
from agent_data_cli.cli.commands.group import GROUP_COMMAND
from agent_data_cli.cli.commands.help import make_help_command
from agent_data_cli.cli.commands.hub import HUB_COMMAND
from agent_data_cli.cli.commands.init import INIT_COMMAND
from agent_data_cli.cli.commands.source import SOURCE_COMMAND
from agent_data_cli.cli.commands.specs import (
    CommandContext,
    CommandNodeSpec,
    build_command_help_doc as _build_command_help_doc,
    build_global_help_doc as _build_global_help_doc,
    build_root_parser,
    dispatch_command,
    parse_command_argv,
)
from agent_data_cli.cli.commands.sub import SUB_COMMAND
from agent_data_cli.core.help import HelpSection


_BASE_COMMANDS: tuple[CommandNodeSpec, ...] = (
    INIT_COMMAND,
    HUB_COMMAND,
    SOURCE_COMMAND,
    CHANNEL_COMMAND,
    CONTENT_COMMAND,
    SUB_COMMAND,
    GROUP_COMMAND,
    CONFIG_COMMAND,
    DASHBOARD_COMMAND,
)

GLOBAL_HELP_SECTIONS = (
    HelpSection(
        title="Examples",
        lines=[
            "init --defaults",
            "hub search --query <query>",
            "help content search",
            "source list",
            "channel search --source <source> --query <query>",
            "content update --group <group> --dry-run",
            "dashboard --daemon",
        ],
    ),
)

HELP_COMMAND = make_help_command(
    build_global_help_doc=lambda: build_global_help_doc(),
    build_command_help_doc=lambda topic: build_command_help_doc(topic),
)

ROOT_COMMANDS: tuple[CommandNodeSpec, ...] = (*_BASE_COMMANDS, HELP_COMMAND)


def build_parser():
    return build_root_parser(ROOT_COMMANDS)


def build_global_help_doc():
    return _build_global_help_doc(
        title="agent-data-cli",
        summary="Unified multi-source content CLI.",
        commands=ROOT_COMMANDS,
        sections=GLOBAL_HELP_SECTIONS,
    )


def build_command_help_doc(topic: str):
    return _build_command_help_doc(ROOT_COMMANDS, topic)


__all__ = [
    "CommandContext",
    "ROOT_COMMANDS",
    "build_command_help_doc",
    "build_global_help_doc",
    "build_parser",
    "dispatch_command",
    "parse_command_argv",
]
