from __future__ import annotations

from typing import Callable

from agent_data_cli.cli.commands.specs import CommandArgSpec, CommandContext, CommandNodeSpec
from agent_data_cli.cli.help import build_source_help_doc, print_help_doc
from agent_data_cli.core.help import HelpDoc, HelpSection


def make_help_command(
    *,
    build_global_help_doc: Callable[[], HelpDoc],
    build_command_help_doc: Callable[[str], HelpDoc],
) -> CommandNodeSpec:
    def _run_help(args, extras: list[str], ctx: CommandContext) -> int:
        _ = extras
        topic = " ".join(args.topic or []).strip()
        if not topic:
            print_help_doc(build_global_help_doc())
            return 0
        if topic in ctx.registry.list_names():
            print_help_doc(build_source_help_doc(ctx.registry, topic))
            return 0
        print_help_doc(build_command_help_doc(topic))
        return 0

    return CommandNodeSpec(
        name="help",
        summary="Show global, command, or source help.",
        sections=(
            HelpSection(
                title="Examples",
                lines=[
                    "help",
                    "help source",
                    "help channel search",
                    "help content query",
                    "help <source>",
                ],
            ),
        ),
        arg_specs=(CommandArgSpec(names=("topic",), nargs="*", dest="topic"),),
        run=_run_help,
    )
