from __future__ import annotations

from .main import console_main


if __name__ == "__main__":
    console_main()
