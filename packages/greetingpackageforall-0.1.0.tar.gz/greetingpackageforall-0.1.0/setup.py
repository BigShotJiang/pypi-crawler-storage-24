from setuptools import setup, find_packages

setup(
    name="GreetingPackageForAll",
    version="0.1.0",
    author="Subhash Relangi",
    description="Simple greeting module",
    packages=find_packages(),
    python_requires=">=3.7",
)