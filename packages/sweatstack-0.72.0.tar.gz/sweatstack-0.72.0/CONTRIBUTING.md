# Contributing

Thank you for your interest in the SweatStack Python client library!

This repository is open-sourced primarily to make it easier for developers and AI coding agents to understand and work with the library. At this time, we are **not accepting external contributions** such as pull requests or feature requests.

If you've found a bug or have a question about using the library, feel free to [open an issue](https://github.com/SweatStack/sweatstack-python/issues).

For general questions about SweatStack, please refer to the [developer documentation](https://developer.sweatstack.no/getting-started/).
