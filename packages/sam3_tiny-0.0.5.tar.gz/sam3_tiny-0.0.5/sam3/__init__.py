# Copyright (c) Meta Platforms, Inc. and affiliates. All Rights Reserved

from .model_builder import build_sam3_image_model

__all__ = ["build_sam3_image_model"]
