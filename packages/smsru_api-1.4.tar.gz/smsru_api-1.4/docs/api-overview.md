# Обзор API

Пакет экспортирует шесть имен:

- `Client` — синхронный клиент
- `AsyncClient` — асинхронный клиент
- `SmsRu` — алиас `Client` для обратной совместимости
- `AsyncSmsRu` — алиас `AsyncClient` для обратной совместимости
- `OutOfPhoneNumbers` — ошибка превышения лимита получателей
- `OutOfTimestamp` — ошибка некорректных временных параметров

Оба клиента работают с одним и тем же набором методов. У `AsyncClient` все
методы являются coroutine и должны вызываться через `await`.

Публичные исключения тоже импортируются из корня пакета:

```python
from smsru_api import OutOfPhoneNumbers, OutOfTimestamp
```

## Группы методов

### Сообщения

- `send(*numbers, message=None, multi=None, from_name=None, ip_address=None, timestamp=None, ttl=None, day_time=False, translit=False, test=None, debug=False, partner_id=None)` — отправить SMS
- `cost(*numbers, message=...)` — рассчитать стоимость
- `status(sms_id)` — получить статус отправленного сообщения

### Авторизация по звонку

- `callcheck_add(phone)` — создать проверку по звонку
- `callcheck_status(check_id)` — получить статус проверки

### Информация об аккаунте

- `balance()` — баланс
- `limit()` — лимиты
- `free()` — бесплатный лимит
- `senders()` — одобренные имена отправителя

### Стоп-лист

- `stop_list()` — список номеров
- `add_stop_list(number, comment="")` — добавить номер
- `del_stop_list(number)` — удалить номер

### Callback URL

- `callbacks()` — список webhook URL
- `add_callback(url)` — добавить webhook URL
- `del_callback(url)` — удалить webhook URL

## Общие правила

- Все методы возвращают JSON-ответ `sms.ru`, преобразованный в словарь Python.
- Клиент автоматически добавляет `api_id`, `json=1` и партнерский
  идентификатор по умолчанию.
- При превышении лимита получателей библиотека выбрасывает
  `OutOfPhoneNumbers`.
- При некорректных параметрах `timestamp` или `ttl` библиотека выбрасывает
  `OutOfTimestamp`.
