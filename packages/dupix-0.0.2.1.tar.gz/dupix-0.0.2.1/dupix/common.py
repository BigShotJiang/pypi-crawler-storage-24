import sys


def abort(msg: str):
    print(f"ERROR: {msg}")
    sys.exit(2)


