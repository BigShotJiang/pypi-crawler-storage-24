import logging
import os
import argparse
import sqlite3
import sys
from contextlib import closing, AbstractContextManager
from dataclasses import dataclass, field
from datetime import timedelta, datetime
from pathlib import Path
from textwrap import dedent
from typing import Callable, Iterable, List, Tuple
from uuid import uuid4, UUID


class SqliteDatabase(AbstractContextManager):
    """Base class for working with sqlite databases"""

    def __init__(self, path: Path):
        self.path = path
        self.db = sqlite3.connect(str(path))
        self.db.execute("PRAGMA foreign_keys = ON")


    @classmethod
    def execute_ddl(cls, path: Path, sql: str):
        with closing(sqlite3.connect(str(path))) as db:
            for sql in sql.split(";"):
                try:
                    db.execute(f"{sql};")
                except sqlite3.DatabaseError as e:
                    print(f"\nERROR: Failed to init database at {path}")
                    print("="*80)
                    print(dedent(sql))
                    print("=" * 80)
                    try:
                        db.close()
                        path.unlink()
                    except:
                        pass
                    raise
            db.commit()


    def close(self):
        if self.db:
            self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def select(self, sql, *parms):
        if parms:
            return self.db.execute(sql, parms)
        else:
            return self.db.execute(sql)

    def select_value(self, sql, *parms):
        if parms:
            for row in self.db.execute(sql, parms):
                return row[0]
        else:
            for row in self.db.execute(sql):
                return row[0]
        return None

    def execute(self, sql, *parms, commit: bool = True):
        if parms:
            self.db.execute(sql, parms)
        else:
            self.db.execute(sql)
        if commit:
            self.db.commit()

    def executemany(self, sql: str, parms: List[Tuple], commit: bool = True):
        with closing(self.db.cursor()) as curs:
            if parms:
                curs.executemany(sql, parms)
        if commit:
            self.db.commit()



class ScannedFileIndex(SqliteDatabase):


    @property
    def cursor(self):
        return self.db.cursor()

    def commit(self):
        self.db.commit()

    def close(self):
        self.db.commit()
        self.db.close()


#
#     def add_indexed_path(self, path: Path) -> IndexedFolder:
#         """Add a path to use for detecting duplicates within"""
#         path = path.absolute()
#         with closing(self.cursor) as cursor:
#             cursor.execute(
#                 'insert into indexed (path) values (?)',
#                 (str(path), )
#             )
#             return IndexedFolder(path=path, indexed_folder_id=cursor.lastrowid)
#
#     def indexed_paths(self) -> Iterable[IndexedFolder]:
#         with closing(self.cursor) as cursor:
#             for row in cursor.execute("select path, indexed_path_id from indexed"):
#                 yield IndexedFolder(path=Path(row[0]), indexed_folder_id=row[1])
#
#
#     def indexed_path(self, path: Path) -> IndexedFolder:
#         for indexed in self.indexed_paths():
#             if indexed.path.samefile(path):
#                 return indexed
#         raise KeyError(f"Path {path} is not indexed")
#
#
#     # def _get_indexed_path_id(self, cursor, path: Path) -> int:
#     #     sql = 'select indexed_path_id from indexed where path = ?'
#     #     for row in cursor.execute(sql, (str(path), )):
#     #         return row[0]
#     #     raise KeyError(f"{path} is not a known reference folder")
#     #
#     #
#     # def delete_reference_folder(self, path: Path):
#     #     """Remove a folder from the set of indexed"""
#     #     with closing(self.cursor) as c:
#     #         ref_id = self._get_indexed_path_id(c, path)
#     #         c.execute('delete from indexed_files where indexed_path_id = ?', (ref_id, ))
#     #         c.execute('delete from indexed where indexed_path_id = ?', (ref_id, ))
#     #
#     #
#     # def add_file(self, file: FileMetadata):
#     #
#     #     # Check already known
#     #     try:
#     #         known = self.get(file.path)
#     #         if file == known:
#     #             return
#     #         else:
#     #             sql = 'delete from files where path = ?'
#     #             self.cursor.execute(sql, (str(file.path), ))
#     #     except KeyError:
#     #         pass
#     #
#     #     # Record
#     #     self.cursor.execute(
#     #         "INSERT OR REPLACE INTO files (path, file_size, file_mtime_ns, sha256_hash) VALUES (?, ?, ?, ?)",
#     #         (str(file.path), file.file_size, file.file_mtime_ns, file.file_hash)
#     #     )
#     #
#     #
#     # def get(self, path: Path) -> FileMetadata:
#     #     path = path.absolute()
#     #     sql = "select file_mtime_ns, file_size, sha256_hash from files where path = ?"
#     #     for row in self.cursor.execute(sql, (str(path), )):
#     #         file_mtime_ns, file_size, file_hash = row
#     #         return FileMetadata(
#     #             path=path,
#     #             file_mtime_ns=file_mtime_ns,
#     #             file_size=file_size,
#     #             file_hash=file_hash
#     #         )
#     #     raise KeyError(f"No entry for path {path}")
#
#
# # class FileIndexDatabase:
# #     """Collection of pre-scanned file indexes used to find duplicate files"""
# #
# #     def __init__(self, path: Path):
# #         if path.exists() and not path.is_dir():
# #             raise ValueError("File index must be a folder")
# #         if not path.exists():
# #             try:
# #                 path.mkdir()
# #             except Exception as e:
# #                 raise Exception(f"Failed to create file index at {path}: {e.__class__.__name__}: {e}") from e
# #
# #         self.path = path
# #
# #
# #     @staticmethod
# #     def as_arg(path: str) -> "FileIndexDatabase":
# #         """Load database from arg path"""
# #
# #         path = Path(path)
# #         path = path.expanduser()
# #         if path.exists() and not path.is_dir():
# #             raise argparse.ArgumentParser("File index db must be a folder")
# #
# #         return ScannedFileIndex(path)
#
#
#
#
