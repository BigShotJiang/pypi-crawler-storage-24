from pathlib import Path
import argparse
from tempfile import TemporaryDirectory

from .database import SqliteDatabase
from .models import normalize_path
from .index import IndexStore


class ScanDatabase(SqliteDatabase):
    """Folder where we store indexes of scanned folders"""

    SCAN_DB_SCHEMA = """\
            create table files
            (
                file_set      INTEGER not null default 0,
                file_id       INTEGER PRIMARY KEY AUTOINCREMENT,
                path          TEXT    not null,
                file_size     INTEGER,
                file_mtime    INTEGER, -- in ns
                sha256_hash   BLOB
            );
            create unique index path_uk on files (file_set, path);
            create index files_sha256_hash_file_size_index on files (sha256_hash, file_size);        
            """


    def __init__(self, index: IndexStore):
        self.tmp_folder = TemporaryDirectory(prefix='dupix.scan.')
        db_path = Path(self.tmp_folder.name) / 'scan.sqlite3'
        self.execute_ddl(db_path, self.SCAN_DB_SCHEMA)
        super().__init__(path=db_path)
        self.db.execute(f"ATTACH DATABASE '{index.path}' AS index_link;")


    def close(self):
        super().close()
        if self.tmp_folder:
            self.tmp_folder.cleanup()
            self.tmp_folder = None

