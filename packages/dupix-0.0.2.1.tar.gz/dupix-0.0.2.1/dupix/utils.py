from contextlib import AbstractContextManager
from datetime import datetime, timedelta
from dataclasses import dataclass, field


def format_timedelta(td: timedelta) -> str:

    if td is None:
        return '-'

    ts = abs(td.total_seconds())
    if ts < 1:
        return f"{int(ts * 1000):,} ms"
    elif ts < 60:
        return "%d sec" % (ts)
    elif ts < 2 * 60 * 60:
        return "%d min" % (ts / 60)
    else:
        return "%d hours" % (ts / (60 * 60))


@dataclass
class Stopwatch(AbstractContextManager):
    started: datetime = None
    ended: datetime = None

    def start(self):
        self.started = datetime.now()

    def stop(self):
        self.ended = datetime.now()

    @property
    def duration(self) -> timedelta:
        if self.started and self.ended:
            return self.ended - self.started
        return None

    def __str__(self):
        return format_timedelta(self.duration)

    def __enter__(self) -> "Stopwatch":
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback, /):
        self.stop()


def format_file_size(num: int) -> str:
    """Human-readable byte size."""
    n = float(num)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024.0:
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"
