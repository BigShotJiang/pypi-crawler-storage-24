from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import argparse
import sqlite3
from contextlib import closing
from tempfile import TemporaryDirectory
from time import sleep

from .database import SqliteDatabase
from .models import normalize_path


@dataclass(frozen=True)
class SqliteDatetime:
    value: datetime = field(default_factory=datetime.now)

    def __str__(self):
        return self.value.isoformat()

    @staticmethod
    def from_db(value: str) -> "SqliteDatetime":
        return SqliteDatetime(datetime.fromisoformat(value))


@dataclass
class MigrationSQL:
    sql: str
    args: list = None


class IndexStore(SqliteDatabase):
    """Folder where we store indexes of scanned folders"""

    DEFAULT_PATH = Path('~').expanduser() / '.dupix.db'
    VERSION = 3

    SCHEMA = f"""\
        create table metadata
        (
            dedup_db_version INTEGER,
            singleton        INTEGER PRIMARY KEY CHECK (singleton = 1)
        );
        insert into metadata (dedup_db_version) values ({VERSION});

        create table indexed_paths
        (
            index_id         INTEGER PRIMARY KEY AUTOINCREMENT,
            path             TEXT not null,
            is_reference     INTEGER NOT NULL CHECK (is_reference IN (0,1)) default 1,
            last_updated     TEXT
        );
        create unique index indexed_paths_uk on indexed_paths (path);

        create table exclusions
        (
            pattern_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            index_id         INTEGER, -- Can be null
            pattern          TEXT not null,
            pattern_type     TEXT not null
        );

        create table files
        (
            index_id      INTEGER not null,
            path          TEXT    not null,
            file_size     INTEGER not null,
            file_mtime    INTEGER not null, -- in ns
            sha256_hash   BLOB,

            constraint files_root_fk
                FOREIGN KEY (index_id)
                REFERENCES indexed_paths(index_id)
        );
        create unique index files_path_uk on files (path);
        create index files_sha256_hash_file_size_index on files (sha256_hash, file_size);
        """


    @classmethod
    def migrate_db_file(cls, path: Path):
        """Perform data migration"""
        from_version = cls.check_database_file_version(path)
        print(f"Upgrading {path} from version {from_version}")
        statements = {}

        if from_version == 1:
            statements['copy_indexed_paths'] = MigrationSQL(
                """\
                    insert into main.indexed_paths (index_id, path, last_updated)
                    select index_id, path, ?
                    from prior.indexed_paths
                """,
                args = [str(SqliteDatetime())]
            )
        elif from_version == 2:
            statements['copy_indexed_paths'] = MigrationSQL(
                """\
                    insert into main.indexed_paths (index_id, path, is_reference, last_updated)
                    select index_id, path, is_reference, ?
                    from prior.indexed_paths
                """,
                args = [str(SqliteDatetime())]
            )
        else:
            raise NotImplementedError

        if from_version in (1, 2):
            statements['copy_files'] = MigrationSQL(
                """\
                    insert into main.files (index_id, path, file_size, file_mtime, sha256_hash)
                    select index_id, path, file_size, file_mtime, sha256_hash from prior.files
                """
            )
        else:
            raise NotImplementedError

        with TemporaryDirectory(prefix='dedupe-migrate') as tmp:
            new_path = Path(tmp) / 'new.sqlite3'
            with IndexStore(new_path) as new:
                new.db.execute(f"ATTACH DATABASE '{str(path)}' AS prior;")
                for name, statement in statements.items():
                    print(f" ... {name}")
                    if statement.args:
                        new.db.execute(statement.sql, statement.args)
                    else:
                        new.db.execute(statement.sql)
                new.db.commit()

            # Place migrated database
            sleep(5)
            try:
                path.unlink()
            except Exception as e:
                raise Exception(f"Unable to remove {path} to place migrated DB: {e}") from e
            new_path.rename(path)


    def __init__(self, path: Path):

        # Check for existing, but outdated database
        if path.exists() and self.check_database_file_version(path) != self.VERSION:
            self.migrate_db_file(path)

        # Open Main Index Database
        if not path.exists():
            self.execute_ddl(path, self.SCHEMA)
        super().__init__(path)


    def get_index_id(self, path: Path, create: bool = True) -> int:
        path = normalize_path(path)

        self.execute("BEGIN IMMEDIATE")
        index_id = self.select_value("select index_id from indexed_paths where path = ?", path)

        if index_id is None and create:
            self.execute("insert into indexed_paths (path) values (?)", path)
            index_id = self.select_value("select index_id from indexed_paths where path = ?", path)

        self.db.commit()

        return index_id


    @property
    def database_version(self) -> int:
        return self.select_value("select dedup_db_version from metadata")


    @staticmethod
    def check_database_file_version(path: Path) -> int:
        try:
            with closing(sqlite3.connect(path)) as conn:
                for row in conn.execute("select dedup_db_version from metadata"):
                    return row[0]
        except Exception as e:
            raise ValueError(f"Unable to read database file {path}: {e.__class__.__name__}: {e}") from e
        raise ValueError(f"Missing metadata row in {path}")


    @staticmethod
    def load_default_database():
        if not IndexStore.DEFAULT_PATH.exists():
            IndexStore.DEFAULT_PATH.mkdir()
        return IndexStore(IndexStore.DEFAULT_PATH)


    @staticmethod
    def as_argument(value: str) -> "IndexStore":
        path = Path(value)
        try:
            return IndexStore(path)
        except Exception as e:
            raise argparse.ArgumentTypeError(f"Failed to open index store: {path}: {e.__class__.__name__}: {e}") from e


    def list_indexes(self) -> tuple[int, Path]:
        sql = """\
            select index_id, path
            from indexed_paths
        """
        return [
            (row[0], Path(row[1])) for row in self.select("""\
                select index_id, path
                from indexed_paths
            """)
        ]