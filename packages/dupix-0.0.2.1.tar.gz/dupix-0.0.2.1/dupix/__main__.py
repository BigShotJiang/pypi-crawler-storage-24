from .cmdline import CommandLine


if __name__ == "__main__":
    CommandLine.main()
