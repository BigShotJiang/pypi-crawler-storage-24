import logging
import os
import hashlib
import argparse
import sqlite3
import sys
from contextlib import closing
from dataclasses import dataclass, field
from datetime import timedelta, datetime
from pathlib import Path
from textwrap import dedent
from typing import Callable, Iterable, List, Tuple
from uuid import uuid4, UUID

from tqdm import tqdm
from rich.console import Console
from rich.table import Table

from .index import IndexStore, SqliteDatetime
from .operations import scan_and_index, find_index_duplicates
from .utils import format_file_size, format_timedelta

VERSION = '0.0.2.1' # setversion


def existing_path(path: str) -> Path:
    path = Path(path)
    if not path.exists():
        raise argparse.ArgumentTypeError(f"Path does not exist: {path}")
    return path


def existing_file(path: str) -> Path:
    path = existing_path(path)
    if not path.is_file():
        raise argparse.ArgumentTypeError(f"Path is not a file: {path}")
    return path


def existing_folder(path: str) -> Path:
    path = existing_path(path)
    if not path.is_dir():
        raise argparse.ArgumentTypeError(f"Path is not a folder: {path}")
    return path


# -- Command Line ----------------------------------------------------------------------------------------------------

class TqdmLoggingHandler(logging.Handler):
    def __init__(self, level=logging.NOTSET):
        super().__init__(level)

    def emit(self, record):
        try:
            msg = self.format(record)
            tqdm.write(msg)
        except Exception:
            self.handleError(record)


@dataclass
class CommandLine:
    args: argparse.Namespace

    command: str

    db_path: Path
    index: IndexStore

    folders: list[Path] = field(default_factory=list)

    verbose: bool = False
    no_update: bool = False

    what: str = None

    limit: int = None
    no_limit: bool = False


    @classmethod
    def build_parser(cls) -> argparse.ArgumentParser:

        parser = argparse.ArgumentParser(
            prog="dupix",
            description="Duplicate file detection toolbox",
            epilog=f'Version {VERSION}'
        )

        subparsers = parser.add_subparsers(dest="command", required=True)
        all_cmds = []

        def _make_cmd(cmd_func: Callable):
            _name = cmd_func.__name__
            if _name.endswith('_cmd'):
                _name = _name[:-1*len('_cmd')]
            _made_cmd = subparsers.add_parser(
                name = _name,
                help=[line.strip() for line in cmd_func.__doc__.split("\n") if line.strip()][0]
            )
            _made_cmd.set_defaults(func=cmd_func)
            all_cmds.append(_made_cmd)
            return _made_cmd

        index = _make_cmd(cls.index_cmd)
        update = _make_cmd(cls.update_cmd)
        list_cmd = _make_cmd(cls.list_cmd)
        stats = _make_cmd(cls.stats_cmd)
        dupes = _make_cmd(cls.dupes_cmd)

        for cmd in all_cmds:
            cmd.add_argument("--db-path", type=Path, default=IndexStore.DEFAULT_PATH,
                help="Location to store reference index scans")
            cmd.add_argument('--verbose', '-v', action='store_true')
            cmd.add_argument('--no-update', action='store_true',
                help="Don't update now")

        for cmd in [index]:
            cmd.add_argument("folders", type=existing_folder, nargs='+',
                help="Target folder to scan")

        # TODO: probably make sub-commands under list
        #       So I can do: dupix list duplicates --limit 100

        list_cmd.add_argument('what', choices=['indexes', 'exclusions', 'duplicates'],
            help="What to list")

        dupes.add_argument('--limit', type=int, default=10,
            help="Limit how many duplicates are shown")
        dupes.add_argument('--no-limit', action='store_true',
            help="List all duplicates")

        return parser


    @staticmethod
    def usage_error(msg: str):
        CommandLine.build_parser().error(msg)


    # @staticmethod
    # def configure_logging(debug: bool = False):
    #     handler = TqdmLoggingHandler()
    #     handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    #
    #     logger = logging.getLogger()
    #     if debug:
    #         logger.setLevel(logging.DEBUG)
    #     else:
    #         logger.setLevel(logging.INFO)
    #     logger.addHandler(handler)
    #
    #     # Optional: prevent duplication if other handlers exist
    #     logger.propagate = False


    @staticmethod
    def main():
        parser = CommandLine.build_parser()
        args = parser.parse_args()
        if args.db_path:
            args.index = IndexStore(args.db_path)
        kwargs = {k: v for (k, v) in vars(args).items() if k not in ('func', )}
        cmd = CommandLine(args=args, **kwargs)

        # Get bound method
        try:
            cmd_func = getattr(cmd, cmd.args.func.__name__)
        except AttributeError:
            CommandLine.usage_error("Sub-command is required")

        cmd_func()

        cmd.index.close()

        print("Finished")


    # -- Commands ----------------------------------------------------------------------------------------------------

    def index_cmd(self):
        """Add a folder to the reference set of folders to use for duplicate file detection"""
        for folder in self.folders:
            scan_and_index(folder, index=self.index)


    def update_cmd(self):
        """Scan reference folders and store data in SQLite."""
        for index_id, folder in self.index.list_indexes():
            scan_and_index(folder, index=self.index)


    def list_cmd(self):
        """List some items from the index db"""

        if self.what == 'indexes':

            table = Table(title="Indexes")
            table.add_column("ID")
            table.add_column("Path")
            table.add_column("Last Updated", justify='right', no_wrap=True)


            sql = """\
                select index_id, path, last_updated
                from indexed_paths
                order by index_id
                """
            for row in self.index.select(sql):
                table.add_row(
                    str(row[0]),
                    row[1],
                    format_timedelta(datetime.now() - SqliteDatetime.from_db(row[2]).value)
                )

        elif self.what == 'exclusions':

            table = Table(title="Indexes")
            table.add_column("ID")
            table.add_column("Ignore")
            table.add_column("Index")

            sql = """\
                select
                    e.pattern_id,
                    e.pattern,
                    i.path
                from exclusions e
                left join indexed_paths i using (index_id)
                order by e.pattern_id
                """
            for row in self.index.select(sql):
                table.add_row(str(row[0]), row[1], row[2] or '')

        else:
            raise NotImplementedError

        if table.rows:
            Console().print(table)
        else:
            print(f"No {self.what} in index")


    def dupes_cmd(self):
        """List duplicate files found under indexed paths"""
        fs = format_file_size
        for i, duplicates in enumerate(find_index_duplicates(self.index)):

            if not self.no_limit and i >= self.limit:
                print("More duplicates exist")
                return

            print(
                f"{duplicates.paths[0].name}: "+
                f"{duplicates.cnt:,}x {fs(duplicates.file_size)} = {fs(duplicates.extra_bytes)} extra"
            )
            # TODO: Check file still exists w/mtime + size?
            for path in duplicates.paths:
                print(f" - {path}")
            print()


    def stats_cmd(self):
        """List indexes with file count data"""

        table = Table(title="Indexed Stats")
        table.add_column("")
        table.add_column("Indexed Files", justify="right", no_wrap=True)
        table.add_column("Indexed Bytes", justify="right", no_wrap=True)
        table.add_column("Duplicate Files", justify="right", no_wrap=True)
        table.add_column("Duplicate Bytes", justify="right", no_wrap=True)
        table.add_column("", justify="right", no_wrap=True)

        total_cnt = 0
        total_bytes = 0

        sql = """\
            with index_total_file_counts as (
                select
                    index_id,
                    count(*) as file_count,
                    sum(file_size) as size_bytes
                from files
                group by index_id
            ),

            intra_index_duplicates as (
                select
                    index_id,
                    sha256_hash,
                    file_size,
                    count(*) as copy_count
                from files
                group by index_id, sha256_hash, file_size
                having count(*) > 1
            ),

            intra_index_duplicate_sums as (
                select
                    index_id,
                    sum(copy_count-1) as duplicate_file_cnt,
                    sum(file_size * (copy_count-1)) as duplicate_bytes
                from intra_index_duplicates
                group by index_id
            )

            select
                i.path,
                index_total_file_counts.file_count,
                index_total_file_counts.size_bytes,
                intra_index_duplicate_sums.duplicate_file_cnt,
                intra_index_duplicate_sums.duplicate_bytes
            from indexed_paths i
            left join index_total_file_counts using (index_id)
            left join intra_index_duplicate_sums using (index_id)
            where i.is_reference = 1
            order by i.path
            """

        for path, indexed_files, indexed_bytes, dupe_cnt, dupe_bytes in self.index.select(sql):

            if indexed_bytes:
                pct = (100 * dupe_bytes) / indexed_bytes
            else:
                pct = 0

            table.add_row(
                path,
                f"{indexed_files:,}",
                format_file_size(indexed_bytes),
                f"{dupe_cnt:,}",
                format_file_size(dupe_bytes),
                f"{pct:.0f}%",
            )

            total_cnt += indexed_files
            total_bytes += indexed_bytes


        sql = """\
            with duplicate_files as (
                select
                    f.sha256_hash,
                    f.file_size,
                    count(*) as file_count
                from files f
                left join indexed_paths i using (index_id)
                where i.is_reference = 1
                group by sha256_hash, file_size
                having count(*) > 1
            )
                
            select
                sum(file_count-1) as copy_count,
                sum(file_size * (file_count-1)) as duplicate_bytes
            from duplicate_files
            """
        for dupe_cnt, duplicate_bytes in self.index.select(sql):

            if total_bytes:
                pct = (100 * duplicate_bytes) / total_bytes
            else:
                pct = 0

            table.add_row(
                "ALL INDEXED FILES",
                f"{total_cnt:,}",
                format_file_size(total_bytes),
                f"{dupe_cnt:,}",
                format_file_size(duplicate_bytes),
                f"{pct:.0f}%",
            )


        if table.rows:
            Console().print(table)
        else:
            print(f"No paths indexed yet.  Use dupix index ...")




def main():
    CommandLine.main()

if __name__ == "__main__":
    CommandLine.main()
