import logging
import os
import hashlib
import argparse
import sqlite3
import sys
from contextlib import closing
from dataclasses import dataclass, field
from datetime import timedelta, datetime
from pathlib import Path
from textwrap import dedent
from typing import Callable, Iterable, List, Tuple
from uuid import uuid4, UUID
from tempfile import TemporaryDirectory

from tqdm import tqdm

from .common import abort
from .scan import ScanDatabase
from .utils import Stopwatch
from .database import SqliteDatabase
from .index import IndexStore, SqliteDatetime
from .models import normalize_path


def ngroup(items: Iterable, group_size: int = 100) -> Iterable[List]:
    group = []
    for item in items:
        group.append(item)
        if len(group) >= group_size:
            yield group
            group = []
    if group:
        yield group


def sql_ngroup(db: SqliteDatabase, query: str, group_size: int = 100) -> Iterable[List]:
    while True:
        with closing(db.db.cursor()) as curs:
            group = [row for row in curs.execute(query + f" limit {group_size}")]
        if group:
            yield group
        else:
            return


def get_file_hash(file_path: Path) -> bytes:
    """Generate SHA256 hash for a file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        # Read in chunks to handle large files efficiently
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.digest()


def find_files_under(root: Path) -> Iterable[Path]:
    """Discover all files under a folder"""
    for path in root.iterdir():
        if not path.is_symlink():
            if path.is_file():
                yield path
            if path.is_dir():
                yield from find_files_under(path)


def discover_files(root: Path, scan: ScanDatabase, progress: bool, file_set: int = 0):

    # Discover files
    print(f"Scanning {root}")
    file_count = 0
    with Stopwatch() as timer:
        for paths in ngroup(find_files_under(root), group_size=1000):
            scan.executemany(
                "INSERT INTO files (file_set, path) VALUES (?, ?)",
                [(file_set, normalize_path(path),) for path in paths]
            )
            file_count += len(paths)
    if progress:
        print(f"Discovered {file_count:,} files in {timer}")


def scan_file_stats(scan: ScanDatabase, progress: bool, file_set: int = 0):
    """Scan size and mtime for files"""
    file_count = scan.select_value(
        "select count(*) from files where file_set = ? and file_mtime is null",
        file_set
    )
    with tqdm(desc=f"Scanning file stats", total=file_count, unit='fl', disable=not progress, leave=False) as pbar:
        sql = "select file_id, path from files where file_size is null"
        for group in sql_ngroup(scan, sql, 1000):
            updates = []
            for file_id, path in group:
                try:
                    stat = Path(path).stat()
                    updates.append((stat.st_size, stat.st_mtime_ns, file_id))
                except Exception as e:
                    tqdm.write(f"WARNING: Failed to stat {path}: {e.__class__.__name__}: {e}")
                    scan.execute("delete from scan.files where file_id = ?", file_id, commit=False)
                pbar.update(1)
            scan.executemany(
                sql="update files set file_size=?, file_mtime=? where file_id=?",
                parms=updates
            )


def copy_known_file_hashes(scan: ScanDatabase):
    """Copy any known file hashes from the index into the scan"""

    scan.execute("""\
        update files as scanned_files
        set sha256_hash = known_files.sha256_hash
        from index_link.files as known_files
        where known_files.path = scanned_files.path
          and known_files.file_size = scanned_files.file_size
          and known_files.file_mtime = scanned_files.file_mtime
          and scanned_files.sha256_hash is null;        
        """, commit=True)


def hash_new_files(scan: ScanDatabase, progress: bool, file_set: int = 0):
    """Populate file hashes by computing from files"""
    cnt = 0
    with Stopwatch() as timer:
        total_size = scan.select_value("select sum(file_size) from files where sha256_hash is null")
        if not total_size:
            return
        with tqdm(desc=f"Hashing file contents", total=total_size, unit='b', unit_scale=True, disable=not progress,
                  leave=False) as pbar:
            sql = "select file_id, path, file_size from files where sha256_hash is null"
            for group in sql_ngroup(scan, sql, 500):
                updates = []
                for file_id, path, file_size in group:
                    try:
                        file_hash = get_file_hash(Path(path))
                        updates.append((file_hash, file_id))
                    except Exception as e:
                        tqdm.write(f"WARNING: Failed to read {path}: {e.__class__.__name__}: {e}")
                        scan.execute("delete from files where file_id = ?", file_id, commit=False)
                    pbar.update(file_size)
                    cnt += 1
                scan.executemany(
                    sql="update files set sha256_hash=? where file_id=?",
                    parms=updates
                )
    if progress:
        if cnt:
            print(f"Hashed {cnt:,} files in {timer}")
        else:
            print("No new files found")


def update_index_from_scan(scan: ScanDatabase, index_id: int, progress: bool):
    """Copy scan results into index"""
    print("Updating index")
    scan.execute("delete from index_link.files where index_id = ?", index_id, commit=False)
    sql = """
          insert into index_link.files (index_id, path, file_size, file_mtime, sha256_hash)
          select ? as index_id,
                 path,
                 file_size,
                 file_mtime,
                 sha256_hash
          from main.files
          """
    scan.execute(sql, index_id, commit=True)

    scan.execute(
        "update index_link.indexed_paths set last_updated = ? where index_id = ?",
        str(SqliteDatetime(datetime.now())), index_id
    )


def scan_folder(folder: Path, scan: ScanDatabase, file_set: int = 0, progress: bool = True):
    """
    Scan a folder on the disk to discover all files and their state

    :param folder: Folder to scan
    :param scan: Scan Database to store results in
    :param file_set: Which file set to store scan under
    :param progress: Show progress while scanning
    """
    discover_files(root=folder, scan=scan, progress=progress)
    scan_file_stats(scan=scan, progress=progress)
    copy_known_file_hashes(scan=scan)
    hash_new_files(scan=scan, progress=progress)


def scan_and_index(folder: Path, index: IndexStore, progress: bool = True):
    """
    Scan a file tree, and create or update an index with discovered files at the folder

    :param folder: Folder to scan
    :param index: Index Database to update
    :param progress: Show progress while scanning
    """
    with ScanDatabase(index=index) as scan:
        scan_folder(folder=folder, scan=scan, progress=progress)

        # Check for path collisions
        index_id = index.get_index_id(folder)

        sql = """\
            select scanned_files.path, indexed_paths.path as indexed_path
            from files "scanned_files"
            left join index_link.files "known_files" using (path)
            left join indexed_paths using (index_id)
            where index_id != ?
            limit 1
            """
        for row in scan.select(sql, index_id):
            abort(f"Duplicate path {row[0]} found from index of {row[1]}.  Check for index overlap")

        update_index_from_scan(scan=scan, index_id=index_id, progress=progress)


@dataclass
class Duplicate:
    paths: list[Path]
    file_size: int
    _group_id: int

    @property
    def cnt(self) -> int:
        return len(self.paths)

    @property
    def extra_bytes(self) -> int:
        return self.file_size * (self.cnt-1)


def find_index_duplicates(index: IndexStore, where: str = '1 = 1') -> Iterable[Duplicate]:
    sql = f"""
        with dupes as (
            select
                sha256_hash,
                file_size
            from files
            group by sha256_hash, file_size
            having count(*) > 1
        ),
        
        dupe_groups as (
            select
                ROW_NUMBER() OVER (order by file_size desc) AS dupe_group,
                sha256_hash,
                file_size
            from dupes
        )
        
        select
            dupe_groups.dupe_group,
            dupe_groups.file_size,
            files.path
        from dupe_groups
        left join files using (sha256_hash, file_size)
        left join indexed_paths using (index_id)
        where indexed_paths.is_reference = 1
            and {where}
        order by dupe_groups.dupe_group
    """

    group: Duplicate|None = None

    for dupe_group, file_size, path in index.select(sql):

        if group is not None and group._group_id != dupe_group:
            yield group
            group = None

        if group is None:
            group = Duplicate(paths=[Path(path)], file_size=file_size, _group_id=dupe_group)
        else:
            group.paths.append(path)

    if group:
        yield group
