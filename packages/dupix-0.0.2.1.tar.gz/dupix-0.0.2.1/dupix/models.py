import os
from dataclasses import dataclass
from pathlib import Path
import sys


def normalize_path(path: Path) -> str:
    path = str(path.resolve())
    if sys.platform in {'win32'}:
        path = os.path.normcase(path)
    return path


@dataclass
class FileMetadata:
    path: Path
    file_mtime_ns: int
    file_size: int
    file_hash: str

    def __eq__(self, other: "FileMetadata") -> bool:
        try:
            return self.path.samefile(other.path) and self.same_signature(other)
        except AttributeError:
            return NotImplemented

    def same_signature(self, other: "FileMetadata") -> bool:
        if self.file_mtime_ns == other.file_mtime_ns and self.file_size == other.file_size:
            if self.file_hash == other.file_hash:
                return True
        return False

    def __hash__(self):
        return hash(self.path)



@dataclass
class IndexedFolder:
    path: Path
    indexed_folder_id: int


