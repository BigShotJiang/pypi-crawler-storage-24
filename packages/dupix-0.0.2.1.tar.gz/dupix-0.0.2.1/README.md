DUPIX
======

File indexing and deduplication tool

I don't have too many files... you do!


Usage
-----

    usage: dupix [-h] {index,update,list,stats,dupes} ...
    
    Duplicate file detection toolbox
    
    positional arguments:
      {index,update,list,stats,dupes}
        index               Add a folder to the reference set of folders to use for duplicate file detection
        update              Scan reference folders and store data in SQLite.
        list                List some items from the index db
        stats               List indexes with file count data
        dupes               List duplicate files found under indexed paths
    
    options:
      -h, --help            show this help message and exit
    
    Version 0.0.2


Change Log
==========

## [0.0.2] - 2026-03-18
### Added:
 - update command
 - list command to list a few common items such as index roots
 - stats command
 - Basic dupes command to list indexed duplicates
 - last_updated timestamp for indexed_paths
### Changes:
 - Reversed linkage of scan DB to index DB



## [0.0.1] - 2026-03-05
### Added:
 - First draft with indexing into common DB
 - Attached temporary scan DB
