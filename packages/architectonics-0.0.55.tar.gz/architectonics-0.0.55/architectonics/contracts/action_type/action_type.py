from enum import Enum


class ActionType(int, Enum):
    CREATE = 1
    READ = 2
    UPDATE = 3
    DELETE = 4
