from pydantic import BaseModel


class UserModelContract(BaseModel):
    id: str
    first_name: str
    last_name: str
