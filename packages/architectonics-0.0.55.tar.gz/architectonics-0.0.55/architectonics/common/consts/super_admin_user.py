class SuperAdminUser:
    ID = "fb0c95e7-8608-4722-a7e4-04e11f9f1be8"
    FIRST_NAME = "Super"
    LAST_NAME = "User"
