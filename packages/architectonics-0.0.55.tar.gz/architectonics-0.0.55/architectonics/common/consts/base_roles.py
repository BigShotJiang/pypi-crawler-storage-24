from enum import Enum


class BaseRoleIdList(str, Enum):
    SUPER_ADMIN = "c3adaef8-71ff-4f5c-8041-5d68a43a0a36"
    TEACHER = "8c104c97-3b3b-4002-bbdb-198b07594db4"
    STUDENT = "2224be7c-7b63-4f5a-ad4c-42733b247b28"


class BaseRoleTitleList(str, Enum):
    SUPER_ADMIN = "Администратор"
    TEACHER = "Учитель"
    STUDENT = "Студент"


class BaseRoleCodeList(str, Enum):
    SUPER_ADMIN = "SuperAdmin"
    TEACHER = "Teacher"
    STUDENT = "Student"


class BaseRoleDescriptionList(str, Enum):
    SUPER_ADMIN = "Администратор. Максимальные права доступа"
    TEACHER = "Преподаватель. Права доступа к управлению учебными материалами и студентами"
    STUDENT = "Студент. Ограниченные права доступа"