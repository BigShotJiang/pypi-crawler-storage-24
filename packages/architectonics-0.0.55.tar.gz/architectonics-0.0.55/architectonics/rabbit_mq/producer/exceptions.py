class RabbitMQException(Exception):
    """Base class for RabbitMQ exceptions"""
