# MEMORY_SPEC v1.0

Structured memory notation for LLM agents.
Language-agnostic. Zero infrastructure. SQLite-backed.

---

## Notation

```
C[target]: constraint   — immutable project law, never override
D[target]: decision     — technical choice, validated and active
V[target]: value        — IP, port, key, URL, variable
?[target]: unknown      — open question, needs resolution
✓[target]: done         — feature/scope ready, archivable
~[target]: obsolete     — explicitly replaces a previous fact
```

Operators inside content:

```
->    flow or dependency      C[api]: req -> val -> store
!     critical / do not skip  C[config.js]: NO-TOUCH !
+     combination             D[db]: Postgres+PostGIS
```

---

## Writing rules

- No articles (the, a, an), no politeness
- Target always in English or technical terms
- Content in the session language
- Group facts by key: `D[auth]: JWT+Redis` not two lines
- Use abbreviations from the dictionary below

---

## Abbreviation dictionary

Inject this block once in the system prompt (~60 tokens).
After 12 facts written, it is fully amortized.

```
cfg   = configuration      impl  = implementation
msg   = message            req   = requirement
usr   = user               resp  = response
prod  = production         feat  = feature
dev   = development        deps  = dependencies
auth  = authentication     err   = error
db    = database           btn   = button
env   = environment        doc   = documentation
perf  = performance        init  = initialization
mgmt  = management         refct = refactor
mvmt  = movement           notif = notification
perms = permissions        val   = validation
async = asynchronous       sync  = synchronization
mndtry= mandatory          nvr   = never
alw   = always             tmp   = temporary
idx   = index              tbl   = table
svc   = service            pkg   = package
repo  = repository         api   = API endpoint
clt   = client             srv   = server
```

---

## Token savings

| Before (raw) | After (MEMORY_SPEC) | Gain |
|---|---|---|
| "We decided to use PostgreSQL with PostGIS for geolocation" | `D[db]: Postgres+PostGIS (geo)` | -72% |
| "Never modify config.js, managed by auto-deploy" | `C[config.js]: NO-TOUCH, auto-deploy !` | -68% |
| "Test server IP is 192.168.1.45 on port 3000" | `V[srv.test]: 192.168.1.45:3000` | -74% |
| "Always use UUID, never autoincrement for IDs" | `C[db.id]: UUID mndtry, nvr autoincrement` | -65% |
| "Auth feature is done and deployed to prod" | `✓[auth]: deployed prod` | -78% |

---

## Fact lifecycle

```
active      injected automatically at session start
cold        scope closed or cooled; retrieved on demand by search
superseded  replaced by a newer fact on same target; kept for traceability
archived    deep storage; never surfaces without explicit request
```

Scope auto-cooling triggers:

1. Explicit signal in message: "merged", "deployed", "it works", "phase X done"
2. Silence: 6 turns without any reference to the scope
3. Topic shift: 3+ consecutive turns writing facts for a different scope

---

## Gauge levels

```
< 70%   normal write, no action
70-85%  merge: deduplicate facts sharing same target+scope
85-95%  archive: push cold-scope facts from cold to archived
> 95%   synthesis: LLM consolidation (last resort) or push oldest to cold
```

Hot tier (injected in context) targets ~2500 tokens max (10k chars) for active facts.
Cold tier has no size limit (SQLite, local disk).
A search on cold returns max 20 facts, typically 5.

---

## System prompt injection block

Include this at session start (via `memory_status` tool output):

```
[MEMORY_SPEC v1.0]

NOTATION
C[t]: constraint  D[t]: decision  V[t]: value
?[t]: unknown     ✓[t]: done      ~[t]: obsolete
-> flows  ! critical  group by key

ABBREVS
cfg impl msg req usr resp prod feat dev deps auth err db btn
env doc perf init mgmt refct mvmt notif perms val async sync
mndtry nvr alw tmp idx tbl svc pkg repo api clt srv

RULES
- call memory_write() for any C/D/V/? detected in the conversation
- call memory_search() before answering on a topic that may have history
- call memory_tick(turn, message) on every user message
- target always English or technical; content in session language
- no articles, no politeness

[MEMORY 42% (4.2k/10k)]

C[db.id]: UUID mndtry, nvr autoincrement
D[auth]: JWT 7j refresh 6j
V[srv.prod]: api.example.com:3005
C[mobile]: nvr touch desktop

active scopes: auth-refactor
```

Total: ~180 tokens regardless of session length.

---

## MCP tools reference

| Tool | When to call |
|---|---|
| `memory_write(content, scope?)` | Any constraint, decision, or value established |
| `memory_search(query, scope?, limit?)` | Before answering on a topic with history |
| `memory_tick(turn, message?)` | Every user message |
| `memory_status()` | Session start — injects full MEMORY_SPEC block + hot facts |
| `memory_reflect(topic, limit?)` | User asks about history on a topic |
| `memory_export(scope?, status?)` | Snapshot all facts as plain notation (debug, transfer) |
| `memory_purge(scope?, older_than_days?)` | After closing a major scope or periodic GC |

---

## Contradiction handling

When a new fact targets the same key as an existing active fact,
the old fact is automatically set to `superseded` and linked to the new one.

```
existing  D[auth]: sessions Redis 30j
new write D[auth]: JWT 7j refresh 6j

result:
  D[auth]: JWT 7j refresh 6j       status=active
  D[auth]: sessions Redis 30j      status=superseded, superseded_by=<new_id>
```

The superseded fact is kept for traceability but never injected into context.

---

## Multilingual support

- Targets between `[]` always in English or technical terms
- Content after `:` in the session language
- Abbreviation dictionary delivered in the session language at start
- FTS5 is Unicode-aware; search works across all languages

Translations of MEMORY_SPEC are in:
- `MEMORY_SPEC.fr.md`
- `MEMORY_SPEC.es.md`
- (add more as needed)
