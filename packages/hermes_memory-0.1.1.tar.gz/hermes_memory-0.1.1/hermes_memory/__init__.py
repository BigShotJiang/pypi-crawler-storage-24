"""
hermes-memory — persistent structured memory for LLM agents.

Quick start:

    from hermes_memory.core.db import get_connection
    from hermes_memory.core import facts, scopes, gauge

    conn = get_connection()
    facts.write(conn, "C[db.id]: UUID mndtry, nvr autoincrement")
    results = facts.search(conn, "UUID")

Run the MCP server:

    hermes-memory
"""

__version__ = "0.1.1"
