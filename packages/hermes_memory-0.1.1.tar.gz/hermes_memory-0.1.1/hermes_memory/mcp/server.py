"""
hermes-memory MCP server.

Exposes 7 tools:
    memory_write    store a new fact
    memory_search   query hot + cold facts by FTS5
    memory_tick     advance turn counter, trigger scope cooling
    memory_status   session injection payload (hot facts + gauge)
    memory_reflect  on-demand synthesis grouped by type
    memory_export   dump all facts as plain notation
    memory_purge    hard-delete superseded / archived facts
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from ..core import db, facts, gauge, scopes
from ..core.db import ABBREV_DICT
from ..core.facts import TYPE_DISPLAY

# ------------------------------------------------------------------ setup ---

_DB_PATH = Path(os.getenv("HERMES_MEMORY_DB", str(db.DEFAULT_DB_PATH)))

# One connection per thread — safe for asyncio (single-thread event loop)
# and for any future multi-threaded use.
import threading
_local = threading.local()

def _conn() -> db.sqlite3.Connection:
    """Return a per-thread SQLite connection (lazy init, thread-safe)."""
    if not getattr(_local, "conn", None):
        _local.conn = db.get_connection(_DB_PATH)
    return _local.conn


# Ensure a default session row exists
def _ensure_session(session_id: str) -> None:
    c = _conn()
    existing = c.execute("SELECT id FROM sessions WHERE id=?", (session_id,)).fetchone()
    if not existing:
        c.execute(
            "INSERT INTO sessions (id, started_at, last_turn) VALUES (?,?,0)",
            (session_id, db.now()),
        )
        c.commit()


# One session per server process (agents can override via tool arg)
_SESSION_ID = str(uuid.uuid4())

# ------------------------------------------------------------------ server --

app = Server("hermes-memory")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="memory_write",
            description=(
                "Store a structured fact using MEMORY_SPEC notation.\n"
                "Format: TYPE[target]: content\n"
                "Types: C=constraint  D=decision  V=value  ?=unknown  ✓=done  ~=obsolete\n"
                "Examples:\n"
                "  C[db.id]: UUID mndtry, nvr autoincrement\n"
                "  D[auth]: JWT 7j refresh 6j\n"
                "  V[srv.prod]: api.example.com:3005\n"
                "  ✓[auth]: deployed prod\n"
                "Call this whenever a constraint, decision, or value is established."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "Fact in MEMORY_SPEC notation, e.g. C[db.id]: UUID mndtry",
                    },
                    "scope": {
                        "type": "string",
                        "description": "Scope label (e.g. 'auth-refactor', 'phase-b'). Inherits active scope if omitted.",
                    },
                    "session_id": {
                        "type": "string",
                        "description": "Session identifier. Uses server default if omitted.",
                    },
                },
                "required": ["content"],
            },
        ),
        Tool(
            name="memory_search",
            description=(
                "Search active and cold facts by keyword or phrase.\n"
                "Call this before answering on any topic that may have been discussed before.\n"
                "Returns up to `limit` facts (default 5, max 20) sorted by relevance."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query, e.g. 'UUID database' or 'auth JWT'",
                    },
                    "scope": {
                        "type": "string",
                        "description": "Restrict search to a specific scope label.",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results to return (1-20, default 5).",
                        "default": 5,
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="memory_tick",
            description=(
                "Advance the session turn counter and trigger scope auto-cooling.\n"
                "Call this on every incoming user message, passing the turn number."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "turn": {
                        "type": "integer",
                        "description": "Current turn number (increments each user message).",
                    },
                    "message": {
                        "type": "string",
                        "description": "User message text (used for closing-signal detection).",
                    },
                    "session_id": {"type": "string"},
                },
                "required": ["turn"],
            },
        ),
        Tool(
            name="memory_status",
            description=(
                "Return the full session injection payload: gauge state, active scopes, "
                "and all hot facts. Call this at session start to populate context."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "session_id": {"type": "string"},
                },
            },
        ),
        Tool(
            name="memory_reflect",
            description=(
                "Synthesize all facts (hot + cold) related to a topic into a concise summary.\n"
                "Use this when the user asks 'what did we decide about X?' or before making\n"
                "a decision on a topic with long history. Does not write to memory.\n"
                "Returns a structured synthesis grouped by fact type."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "Topic to reflect on, e.g. 'auth' or 'database schema'",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max facts to include in reflection (default 20).",
                        "default": 20,
                    },
                },
                "required": ["topic"],
            },
        ),
        Tool(
            name="memory_export",
            description=(
                "Export all facts (hot + cold) as plain MEMORY_SPEC notation, one per line.\n"
                "Use for: context snapshot before a long session, transferring memory between\n"
                "agents or sessions, debugging what is stored. Read-only, no writes."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "scope": {
                        "type": "string",
                        "description": "Export only facts belonging to this scope label.",
                    },
                    "status": {
                        "type": "string",
                        "enum": ["active", "cold", "all"],
                        "description": "Which facts to include. Default: all (active + cold).",
                        "default": "all",
                    },
                },
            },
        ),
        Tool(
            name="memory_purge",
            description=(
                "Hard-delete superseded and archived facts. "
                "Use to reclaim space after a scope is fully closed, "
                "or as periodic garbage collection."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "scope": {
                        "type": "string",
                        "description": "Purge only facts belonging to this scope label.",
                    },
                    "older_than_days": {
                        "type": "integer",
                        "description": "Only purge facts older than N days with no recent access.",
                    },
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    c = _conn()
    session_id = arguments.get("session_id", _SESSION_ID)
    _ensure_session(session_id)

    # -------------------------------------------------------- memory_write ---
    if name == "memory_write":
        raw_content = arguments["content"]
        scope_label = arguments.get("scope")
        scope_id = None

        if scope_label:
            scope_id = scopes.get_or_create(c, scope_label, session_id)
        else:
            # Inherit active scope from session
            row = c.execute(
                "SELECT active_scope_id FROM sessions WHERE id=?", (session_id,)
            ).fetchone()
            if row:
                scope_id = row["active_scope_id"]

        result = facts.write(c, raw_content, scope_id=scope_id)

        # Touch scope with current turn so silence cooling tracks real activity
        if scope_id and result["status"] == "created":
            current_turn = c.execute(
                "SELECT last_turn FROM sessions WHERE id=?", (session_id,)
            ).fetchone()
            turn_val = current_turn["last_turn"] if current_turn else 0
            scopes.touch(c, scope_id, turn_val)

        # Auto-close scope if a ✓ fact was written
        if result["status"] == "created" and raw_content.strip().startswith("✓"):
            if scope_id:
                scopes.close(c, scope_id)

        # Check gauge and act
        gauge_result = gauge.check_and_act(c)

        lines = [
            f"stored: {result['id'][:8]}",
            f"gauge:  {gauge_result['pct']}%",
        ]
        if result.get("conflict_resolved"):
            lines.append(f"superseded: {result['conflict_resolved'][:8]}")
        if gauge_result.get("actions"):
            lines.append("pressure: " + ", ".join(gauge_result["actions"]))

        return [TextContent(type="text", text="\n".join(lines))]

    # ------------------------------------------------------- memory_search ---
    if name == "memory_search":
        query = arguments["query"]
        scope_label = arguments.get("scope")
        limit = min(int(arguments.get("limit", 5)), 20)

        scope_id = None
        if scope_label:
            # Prefer active scope, fall back to most recent
            row = c.execute(
                "SELECT id FROM scopes WHERE label=? ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END, created_at DESC LIMIT 1",
                (scope_label,)
            ).fetchone()
            if row:
                scope_id = row["id"]

        results = facts.search(c, query, scope_id=scope_id, limit=limit)

        if not results:
            return [TextContent(type="text", text="no results")]

        lines = []
        for r in results:
            status_tag = "" if r["status"] == "active" else f" [{r['status']}]"
            sym = TYPE_DISPLAY.get(r["type"], r["type"])
            lines.append(f"{sym}[{r['target']}]: {r['content']}{status_tag}")

        return [TextContent(type="text", text="\n".join(lines))]

    # --------------------------------------------------------- memory_tick ---
    if name == "memory_tick":
        turn = int(arguments["turn"])
        if turn < 0:
            return [TextContent(type="text", text="error: turn must be >= 0")]
        message = arguments.get("message", "")

        cooled = scopes.tick(c, turn, message_text=message, session_id=session_id)
        g = gauge.read(c)

        lines = [f"turn: {turn}", f"gauge: {g['pct']}%"]
        if cooled:
            # Resolve scope ids -> labels for actionable output
            cooled_labels = []
            for sid in cooled:
                row = c.execute("SELECT label FROM scopes WHERE id=?", (sid,)).fetchone()
                cooled_labels.append(row["label"] if row else sid[:8])
            lines.append(f"cooled: {', '.join(cooled_labels)}")

        return [TextContent(type="text", text="\n".join(lines))]

    # ------------------------------------------------------- memory_status ---
    if name == "memory_status":
        g = gauge.read(c)
        hot = facts.get_hot(c)
        active_scopes = scopes.get_active(c)

        # Build abbrev line — compact, one line, fits in ~60 tokens
        abbrev_line = " ".join(ABBREV_DICT.keys())

        lines = [
            "[MEMORY_SPEC v1.0]",
            "",
            "NOTATION",
            "C[t]: constraint  D[t]: decision  V[t]: value",
            "?[t]: unknown     ✓[t]: done      ~[t]: obsolete",
            "-> flows  ! critical  group by key",
            "",
            "ABBREVS",
            abbrev_line,
            "",
            "RULES",
            "- call memory_write() for any C/D/V/? detected",
            "- call memory_search() before answering on known topics",
            "- call memory_tick(turn, message) on every user message",
            "- call memory_reflect(topic) when user asks about history",
            "",
            f"[MEMORY {g['pct']}% ({g['used_chars']}/{g['max_chars']})]",
            "",
        ]

        if hot:
            for f in hot:
                type_sym = TYPE_DISPLAY.get(f["type"], f["type"])
                lines.append(f"{type_sym}[{f['target']}]: {f['content']}")
        else:
            lines.append("(no active facts)")

        if active_scopes:
            lines.append("")
            scope_labels = [s["label"] for s in active_scopes]
            lines.append(f"active scopes: {', '.join(scope_labels)}")

        return [TextContent(type="text", text="\n".join(lines))]

    # ----------------------------------------------------- memory_reflect ---
    if name == "memory_reflect":
        topic = arguments["topic"]
        limit = min(int(arguments.get("limit", 20)), 20)

        results = facts.search(c, topic, limit=limit)

        if not results:
            return [TextContent(type="text", text=f"no facts found for topic: {topic}")]

        # Group by type for structured output
        groups: dict[str, list[str]] = {}
        for r in results:
            sym = TYPE_DISPLAY.get(r["type"], r["type"])
            groups.setdefault(sym, []).append(
                f"  [{r['target']}]: {r['content']}"
                + ("" if r["status"] == "active" else f"  ({r['status']})")
            )

        type_order = ["C", "D", "V", "✓", "~", "?"]
        lines = [f"reflection: {topic}  ({len(results)} facts)", ""]
        for sym in type_order:
            if sym not in groups:
                continue
            label = {
                "C": "Constraints", "D": "Decisions", "V": "Values",
                "✓": "Resolved",   "~": "Obsolete",  "?": "Open questions",
            }.get(sym, sym)
            lines.append(f"{label}:")
            lines.extend(groups[sym])
            lines.append("")

        return [TextContent(type="text", text="\n".join(lines).rstrip())]

    # ------------------------------------------------------ memory_export ---
    if name == "memory_export":
        scope_label  = arguments.get("scope")
        status_filter = arguments.get("status", "all")

        scope_id = None
        if scope_label:
            row = c.execute(
                "SELECT id FROM scopes WHERE label=?", (scope_label,)
            ).fetchone()
            if row:
                scope_id = row["id"]

        if status_filter == "active":
            statuses = ("active",)
        elif status_filter == "cold":
            statuses = ("cold",)
        else:
            statuses = ("active", "cold")

        conditions = [f"status IN ({','.join('?' * len(statuses))})"]
        params: list = list(statuses)

        if scope_id:
            conditions.append("scope_id = ?")
            params.append(scope_id)

        rows = c.execute(
            f"SELECT type, target, content FROM facts WHERE {' AND '.join(conditions)} "
            f"ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END, updated_at DESC",
            params,
        ).fetchall()

        if not rows:
            return [TextContent(type="text", text="(no facts to export)")]

        lines = []
        for r_ in rows:
            sym = TYPE_DISPLAY.get(r_["type"], r_["type"])
            lines.append(f"{sym}[{r_['target']}]: {r_['content']}")

        return [TextContent(type="text", text="\n".join(lines))]

    # ------------------------------------------------------- memory_purge ---
    if name == "memory_purge":
        scope_label = arguments.get("scope")
        older_than  = arguments.get("older_than_days")

        scope_id = None
        if scope_label:
            row = c.execute(
                "SELECT id FROM scopes WHERE label=?", (scope_label,)
            ).fetchone()
            if row:
                scope_id = row["id"]

        count = facts.purge(
            c,
            scope_id=scope_id,
            older_than_days=int(older_than) if older_than is not None else None,
        )
        g = gauge.read(c)

        return [TextContent(
            type="text",
            text=f"purged: {count} fact(s)\ngauge: {g['pct']}%",
        )]

    return [TextContent(type="text", text=f"unknown tool: {name}")]


# -------------------------------------------------------------------- main ---

def main() -> None:
    """Entry point: run the MCP server over stdio."""
    import asyncio

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await app.run(read_stream, write_stream, app.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    main()
