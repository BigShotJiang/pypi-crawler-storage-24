"""MCP server entry point."""
