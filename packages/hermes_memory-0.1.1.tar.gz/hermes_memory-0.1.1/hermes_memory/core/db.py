"""
SQLite connection, schema migrations, and shared constants.
Zero external dependencies beyond stdlib sqlite3.
"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

# Default storage path — overridable via env HERMES_MEMORY_DB
DEFAULT_DB_PATH = Path.home() / ".hermes" / "memory.db"

# Gauge thresholds (percentage of max_chars used by active facts)
GAUGE_MERGE    = 70   # deduplicate facts with same target+scope
GAUGE_ARCHIVE  = 85   # push closed-scope facts to cold
GAUGE_SYNTHESIS = 95  # last resort: LLM-assisted consolidation

# Max chars stored in active facts before we start pushing to cold
MAX_ACTIVE_CHARS = 10_000

# Scope auto-cooling: turns of silence before a scope goes cold
SCOPE_COOL_TURNS = 6

# Max facts returned by memory_search
SEARCH_DEFAULT_LIMIT = 5
SEARCH_MAX_LIMIT     = 20

# Abbreviation dictionary injected into system prompt (see spec/)
ABBREV_DICT = {
    "cfg": "configuration",   "impl": "implementation",
    "msg": "message",         "req":  "requirement",
    "usr": "user",            "resp": "response",
    "prod": "production",     "feat": "feature",
    "dev": "development",     "deps": "dependencies",
    "auth": "authentication", "err":  "error",
    "db":  "database",        "btn":  "button",
    "env": "environment",     "doc":  "documentation",
    "perf": "performance",    "init": "initialization",
    "mgmt": "management",     "refct": "refactor",
    "mvmt": "movement",       "notif": "notification",
    "perms": "permissions",   "val":  "validation",
    "async": "asynchronous",  "sync": "synchronization",
    "mndtry": "mandatory",    "nvr":  "never",
    "alw": "always",          "tmp":  "temporary",
    "idx": "index",           "tbl":  "table",
    "svc": "service",         "pkg":  "package",
    "repo": "repository",     "api":  "API endpoint",
    "clt": "client",          "srv":  "server",
}

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA cache_size=-4096;
PRAGMA foreign_keys=ON;

-- ------------------------------------------------------------------ facts ---
CREATE TABLE IF NOT EXISTS facts (
    id            TEXT    PRIMARY KEY,
    content       TEXT    NOT NULL,
    type          TEXT    NOT NULL CHECK(type IN ('C','D','V','?','done','obs')),
    target        TEXT    NOT NULL,
    scope_id      TEXT    REFERENCES scopes(id),
    status        TEXT    NOT NULL DEFAULT 'active'
                          CHECK(status IN ('active','cold','superseded','archived')),
    superseded_by TEXT    REFERENCES facts(id),
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL,
    last_accessed INTEGER,
    access_count  INTEGER NOT NULL DEFAULT 0,
    source_hash   TEXT
);

CREATE INDEX IF NOT EXISTS idx_facts_target      ON facts(target);
CREATE INDEX IF NOT EXISTS idx_facts_scope       ON facts(scope_id);
CREATE INDEX IF NOT EXISTS idx_facts_status      ON facts(status);
CREATE INDEX IF NOT EXISTS idx_facts_updated_at  ON facts(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_facts_source_hash ON facts(source_hash);

-- --------------------------------------------------------- facts FTS5 index ---
CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
    content,
    target,
    content='facts',
    content_rowid='rowid'
);

CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts BEGIN
    INSERT INTO facts_fts(rowid, content, target)
    VALUES (new.rowid, new.content, new.target);
END;

CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, content, target)
    VALUES ('delete', old.rowid, old.content, old.target);
END;

CREATE TRIGGER IF NOT EXISTS facts_au AFTER UPDATE ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, content, target)
    VALUES ('delete', old.rowid, old.content, old.target);
    INSERT INTO facts_fts(rowid, content, target)
    VALUES (new.rowid, new.content, new.target);
END;

-- ----------------------------------------------------------------- scopes ---
CREATE TABLE IF NOT EXISTS scopes (
    id              TEXT    PRIMARY KEY,
    label           TEXT    NOT NULL,
    status          TEXT    NOT NULL DEFAULT 'active'
                            CHECK(status IN ('active','cold','closed')),
    last_referenced INTEGER NOT NULL,
    current_turn    INTEGER NOT NULL DEFAULT 0,
    created_at      INTEGER NOT NULL,
    closed_at       INTEGER
);

-- Prevent duplicate active scopes with the same label (race condition guard)
CREATE UNIQUE INDEX IF NOT EXISTS idx_scopes_active_label
    ON scopes(label) WHERE status = 'active';

-- --------------------------------------------------------------- sessions ---
CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT    PRIMARY KEY,
    started_at      INTEGER NOT NULL,
    last_turn       INTEGER NOT NULL DEFAULT 0,
    active_scope_id TEXT    REFERENCES scopes(id)
);

-- --------------------------------------------------------------- views ---
CREATE VIEW IF NOT EXISTS hot_facts AS
    SELECT f.*
    FROM facts f
    LEFT JOIN scopes s ON f.scope_id = s.id
    WHERE f.status = 'active'
      AND (s.id IS NULL OR s.status = 'active')
    ORDER BY f.updated_at DESC;

"""


def get_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """
    Open (or create) the SQLite database and apply schema migrations.
    Returns a connection with row_factory set to sqlite3.Row.
    """
    path = Path(db_path) if db_path else DEFAULT_DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)

    # Recreate gauge view so MAX_ACTIVE_CHARS changes take effect immediately.
    # CREATE VIEW IF NOT EXISTS is sticky — DROP + CREATE ensures it's current.
    conn.executescript(f"""
    DROP VIEW IF EXISTS gauge;
    CREATE VIEW gauge AS
        SELECT
            COALESCE(SUM(
                LENGTH(type) + 1 + LENGTH(target) + 3 + LENGTH(content)
            ), 0)                                                    AS used_chars,
            {MAX_ACTIVE_CHARS}                                       AS max_chars,
            ROUND(COALESCE(SUM(
                LENGTH(type) + 1 + LENGTH(target) + 3 + LENGTH(content)
            ), 0) * 100.0
                  / {MAX_ACTIVE_CHARS}, 1)                          AS pct
        FROM facts
        WHERE status = 'active';
    """)
    conn.commit()
    return conn


def now() -> int:
    """Current Unix timestamp in seconds."""
    return int(time.time())
