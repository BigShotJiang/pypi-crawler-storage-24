"""Tests for core/facts.py — CRUD, contradiction detection, dedup."""

import pytest
from hermes_memory.core.db import get_connection
from hermes_memory.core import facts


@pytest.fixture
def conn():
    c = get_connection(":memory:")
    yield c
    c.close()


def test_parse_notation_constraint(conn):
    t, target, content = facts.parse_notation("C[db.id]: UUID mndtry, nvr autoincrement")
    assert t == "C"
    assert target == "db.id"
    assert content == "UUID mndtry, nvr autoincrement"


def test_parse_notation_done(conn):
    t, target, content = facts.parse_notation("✓[auth]: deployed prod")
    assert t == "done"
    assert target == "auth"


def test_parse_notation_invalid(conn):
    with pytest.raises(ValueError):
        facts.parse_notation("not a valid fact")


def test_write_creates_fact(conn):
    result = facts.write(conn, "C[db.id]: UUID mndtry")
    assert result["status"] == "created"
    assert result["id"]
    row = conn.execute("SELECT * FROM facts WHERE id=?", (result["id"],)).fetchone()
    assert row["type"] == "C"
    assert row["target"] == "db.id"
    assert row["status"] == "active"


def test_write_dedup(conn):
    r1 = facts.write(conn, "C[db.id]: UUID mndtry")
    r2 = facts.write(conn, "C[db.id]: UUID mndtry")
    assert r1["id"] == r2["id"]
    assert r2["status"] == "dedup"
    count = conn.execute("SELECT COUNT(*) FROM facts WHERE target='db.id'").fetchone()[0]
    assert count == 1


def test_write_contradiction_supersedes(conn):
    r1 = facts.write(conn, "D[auth]: sessions Redis 30j")
    r2 = facts.write(conn, "D[auth]: JWT 7j refresh 6j")

    assert r2["conflict_resolved"] == r1["id"]

    old = conn.execute("SELECT status FROM facts WHERE id=?", (r1["id"],)).fetchone()
    assert old["status"] == "superseded"

    new = conn.execute("SELECT status FROM facts WHERE id=?", (r2["id"],)).fetchone()
    assert new["status"] == "active"


def test_search_finds_fact(conn):
    facts.write(conn, "C[db.id]: UUID mndtry, nvr autoincrement")
    results = facts.search(conn, "UUID")
    assert len(results) == 1
    assert results[0]["target"] == "db.id"


def test_search_excludes_superseded(conn):
    facts.write(conn, "D[auth]: sessions Redis 30j")
    facts.write(conn, "D[auth]: JWT 7j refresh 6j")
    results = facts.search(conn, "auth")
    assert all(r["status"] != "superseded" for r in results)


def test_search_updates_access_count(conn):
    facts.write(conn, "V[srv.prod]: 1.2.3.4:3005")
    facts.search(conn, "srv.prod")
    row = conn.execute("SELECT access_count FROM facts WHERE target='srv.prod'").fetchone()
    assert row["access_count"] == 1


def test_purge_removes_superseded(conn):
    facts.write(conn, "D[auth]: old")
    facts.write(conn, "D[auth]: new")
    count = facts.purge(conn)
    assert count == 1
    remaining = conn.execute("SELECT COUNT(*) FROM facts WHERE status='superseded'").fetchone()[0]
    assert remaining == 0
