# Show HN: AgentLock – Open authorization standard for AI agent tool calls

Every major AI agent framework — LangChain, CrewAI, AutoGen — treats tool calls as trusted function invocations. No identity verification, no scope constraints, no access control. A `send_email` tool will send email to anyone, with any content, initiated by any user or attacker who can talk to the agent. This is the equivalent of giving every application root access and hoping it behaves.

AgentLock adds a `permissions` block to tool definitions. Each tool declares its risk level, required authentication, allowed roles, rate limits, data boundaries, and audit requirements. An authorization gate enforces these at the infrastructure layer — not the content layer — using single-use execution tokens that the agent never sees. Deny by default: no permissions defined means denied.

This is an open standard, not a product. The core library is framework-agnostic (zero dependencies beyond Pydantic), with optional integrations for LangChain, CrewAI, AutoGen, MCP, FastAPI, and Flask. The design is informed by 187 multi-turn adversarial attack tests across 35 categories and 6 frontier models. The central finding: adversarial and legitimate tool requests are semantically identical — content-based detection cannot reliably distinguish them. The correct defense is architectural access control.

- Spec and docs: https://agentlock.dev
- Code: https://github.com/webpro255/agentlock
- Install: `pip install agentlock`
- License: Apache 2.0

Looking for feedback on the schema design and enforcement model. Happy to answer questions.
