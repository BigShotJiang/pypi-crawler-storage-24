# CrewAI Discord

I built AgentLock, an open-source authorization library that wraps CrewAI tools with permissions — role-based access, rate limiting, audit logging, and deny-by-default enforcement. It can protect all tools across all agents in a Crew with one call. Feedback welcome: https://github.com/webpro255/agentlock
