# LangChain Discord

I built AgentLock, an open-source authorization library for AI agent tool calls. It wraps LangChain `BaseTool` instances with identity verification, role-based access, rate limiting, and audit logging — enforced at the infrastructure layer, not the prompt layer. Looking for feedback on the integration pattern: https://github.com/webpro255/agentlock
