# Adding authorization to LangChain tool calls with AgentLock

**Subreddit:** r/LangChain

---

I built an authorization library for AI agent tool calls and wanted to share the LangChain integration specifically.

The problem: LangChain tools execute as trusted function calls with no identity check, role enforcement, or rate limiting. If your agent has access to a tool, anyone who can talk to the agent can invoke it with any parameters.

AgentLock wraps `BaseTool` instances with an authorization gate that enforces permissions on every call.

## Setup

```bash
pip install agentlock[langchain]
```

## Wrapping a single tool

```python
from langchain_core.tools import StructuredTool
from agentlock import AuthorizationGate, AgentLockPermissions
from agentlock.integrations.langchain import wrap_tool

gate = AuthorizationGate()

# Your existing tool
my_tool = StructuredTool.from_function(
    func=my_func,
    name="send_email",
    description="Sends an email",
)

# Wrap it — returns a new BaseTool with authorization enforced
protected = wrap_tool(my_tool, gate, AgentLockPermissions(
    risk_level="high",
    requires_auth=True,
    allowed_roles=["admin", "account_owner"],
    rate_limit={"max_calls": 10, "window_seconds": 3600},
))

# Use `protected` in your agent instead of `my_tool`
```

## Wrapping multiple tools at once

```python
from agentlock.integrations.langchain import AgentLockToolkit

toolkit = AgentLockToolkit(
    tools=[tool_a, tool_b, tool_c],
    gate=gate,
    permissions=AgentLockPermissions(
        risk_level="medium",
        requires_auth=True,
        allowed_roles=["user", "admin"],
    ),
    default_user_id="alice",
    default_role="user",
)

# Get the wrapped tools
agent_tools = toolkit.get_tools()
```

## Passing auth context

Auth context flows through three mechanisms (in priority order):

1. Explicit kwargs: `_agentlock_user_id`, `_agentlock_role` in tool input
2. LangChain `run_manager` metadata: `agentlock_user_id`, `agentlock_role`
3. Defaults set on the wrapper

## What happens on denial

If a call is denied (wrong role, rate limit exceeded, no auth), the tool raises a `DeniedError` with structured info:

```python
from agentlock.exceptions import DeniedError

try:
    result = protected.invoke({"to": "someone@example.com"})
except DeniedError as e:
    print(e.to_dict())
    # {"status": "denied", "reason": "insufficient_role",
    #  "required_role": "admin", "current_role": "viewer"}
```

## What it enforces

- Identity verification (user_id, role)
- Role-based access (allowed_roles)
- Rate limiting (per-user, sliding window)
- Data boundary (authenticated_user_only, team, organization)
- PII redaction in outputs (SSN, credit card, etc.)
- Full audit logging on every call

The core library has no LangChain dependency — `langchain-core` is only imported when you use the integration.

GitHub: https://github.com/webpro255/agentlock
Docs: https://github.com/webpro255/agentlock/blob/main/docs/integrations.md

Feedback welcome — this is a v1.0 release and I'd like to hear what patterns work or don't in real LangChain deployments.
