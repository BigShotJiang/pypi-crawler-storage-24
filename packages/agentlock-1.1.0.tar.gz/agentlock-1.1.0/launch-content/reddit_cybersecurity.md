# AI agent tools have no permission model — here's an open standard to fix it

**Subreddit:** r/cybersecurity

---

If you haven't looked at how AI agent frameworks handle tool authorization, you should. It's worse than you'd expect.

Every major framework — LangChain, CrewAI, AutoGen — defines tools like this:

```json
{
  "name": "send_email",
  "description": "Sends an email to a recipient",
  "parameters": { "to": "string", "subject": "string", "body": "string" }
}
```

No identity check. No role enforcement. No rate limiting. No scope constraint. No audit trail. If the agent has access to the tool, it executes. Period. Any user — or attacker — who can communicate with the agent can invoke any tool with any parameters.

## The attack surface

The threat model for AI agents is fundamentally different from traditional applications. The conversational interface is the attack surface. Social engineering, prompt injection, and indirect prompt injection all produce tool calls that are **semantically identical** to legitimate requests at the content layer.

I ran 187 multi-turn adversarial attack tests across 35 categories against 6 frontier models. The core finding: you cannot distinguish a social engineering attack from a legitimate request by looking at the content. A manipulated agent calling `send_email` produces the exact same function call as a legitimate user asking to send an email.

This means content-based defenses — guardrails, output filtering, prompt hardening — are fundamentally insufficient. They reduce attack probability but cannot eliminate it.

## The fix: architectural access control

The solution is what every other system already does. Unix has rwx. Databases have GRANT/REVOKE. APIs have OAuth. AI tools need the same thing.

AgentLock is an open standard that adds authorization to tool calls:

- **Deny by default** — no permissions = denied
- **Identity-bound** — every call tied to verified identity, authenticated out-of-band (agent never sees credentials)
- **Role-based access** — allowed_roles per tool
- **Scope constraints** — data_boundary (user-only, team, org), max_records per call
- **Rate limiting** — sliding window per user per tool
- **Single-use execution tokens** — operation-bound, time-limited, parameter-hash-verified, never exposed to the agent
- **Mandatory audit** — every call logged, configurable retention
- **PII redaction** — pattern-based output filtering (SSN, credit card, etc.)
- **Human approval gates** — for critical/financial/bulk operations

The enforcement is three-layered: the agent (conversation layer) decides which tool to call, the authorization gate (infrastructure layer) validates permissions and issues a token, the tool execution layer validates the token and runs within scoped boundaries. The agent never touches the token.

## Standards alignment

The spec aligns with:

- OWASP Top 10 for LLM Applications (2025) — LLM01, LLM05, LLM06
- OWASP Top 10 for Agentic Applications (2026)
- NIST AI RMF (AI 100-1)
- NIST SP 800-53 Rev. 5 (AC, AU, IA, SI)
- MITRE ATLAS (AML.T0051, AML.T0054)
- EU AI Act transparency and oversight requirements

## Links

- GitHub: https://github.com/webpro255/agentlock
- Full spec: https://github.com/webpro255/agentlock/blob/main/docs/specification.md
- Install: `pip install agentlock`
- License: Apache 2.0

This is a v1.0 release. The library is tested (267 tests) and the spec is complete, but it's new. Feedback from the security community on the threat model and enforcement architecture is what I'm looking for.
