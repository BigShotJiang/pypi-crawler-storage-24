# AgentLock: An open standard for AI agent tool permissions

**Subreddit:** r/MachineLearning

**Flair:** [Project]

---

I've been working on the authorization problem in AI agent systems — specifically, the fact that tool calls in every major framework (LangChain, CrewAI, AutoGen) have no permission model at all. A `send_email` tool executes for any user, any input, with no identity check, no scope constraint, and no audit trail.

AgentLock is an open standard and Python library that adds authorization to agent tool calls. It defines a permissions schema (risk level, required auth, allowed roles, rate limits, data boundaries, redaction, audit) enforced at the infrastructure layer through single-use execution tokens.

The design is informed by adversarial testing — 187 multi-turn attack scenarios across 35 categories, tested against 6 frontier models (GPT-4o, Claude 3.5/3, Gemini 1.5 Pro, Llama 3 70B). The key finding: adversarial and legitimate tool requests are semantically identical at the content layer. A social engineering attack that gets an agent to send an email is indistinguishable from a legitimate email request. Content-based detection (guardrails, output filtering, prompt engineering) cannot reliably solve this.

The alternative is what every other programmable system already does: architectural access control. Unix has rwx, databases have GRANT/REVOKE, APIs have OAuth — AI tools have nothing. AgentLock fills that gap.

- Three-layer enforcement: agent (conversation) → authorization gate → tool execution
- Deny by default — no permissions = denied
- Agent never sees credentials or execution tokens
- Full audit logging on every call
- 267 tests, zero external dependencies in core, Apache 2.0

GitHub: https://github.com/webpro255/agentlock
Spec: https://github.com/webpro255/agentlock/blob/main/docs/specification.md
Install: `pip install agentlock`

Looking for feedback on the schema design and whether the enforcement model holds up. This is a new standard, not an established project — honest criticism is useful.
