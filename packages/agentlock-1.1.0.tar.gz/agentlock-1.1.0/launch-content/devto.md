---
title: AI Agent Tools Have No Permissions. That's Insane.
published: false
tags: ai, security, python, opensource
---

## The Problem

Every programmable system in modern computing has an access control model. Except one.

| System | Permission Model |
|--------|-----------------|
| Unix filesystems | rwx per user/group/other |
| Databases | GRANT / REVOKE per table, per role |
| APIs | OAuth scopes, API keys, RBAC |
| Cloud infrastructure | IAM policies, service accounts |
| AI agent tools | **Nothing** |

Here's what a typical tool definition looks like in every major agent framework:

```json
{
  "name": "send_email",
  "description": "Sends an email to a recipient",
  "parameters": { "to": "string", "subject": "string", "body": "string" }
}
```

This tool will send an email to **anyone**, with **any content**, at **any time**, initiated by **any user** — or attacker — who can communicate with the agent. There's no identity check, no scope constraint, no rate limit, no audit trail.

This is the equivalent of giving every application on a computer full root access and hoping it behaves.

## AgentLock

AgentLock is an open standard that adds authorization to AI agent tool calls. It defines a `permissions` block that any tool can implement, any framework can enforce, and any security team can audit.

### Quick Start

```bash
pip install agentlock
```

```python
from agentlock import AuthorizationGate, AgentLockPermissions

gate = AuthorizationGate()

# Define permissions — deny by default
gate.register_tool("send_email", AgentLockPermissions(
    risk_level="high",
    requires_auth=True,
    allowed_roles=["account_owner", "admin"],
    rate_limit={"max_calls": 5, "window_seconds": 3600},
    data_policy={
        "output_classification": "contains_pii",
        "prohibited_in_output": ["ssn", "credit_card"],
        "redaction": "auto",
    },
))

# Every call goes through the gate
result = gate.authorize(
    "send_email",
    user_id="alice",
    role="account_owner",
    parameters={"to": "bob@company.com", "subject": "Q3 Report"},
)

if result.allowed:
    output = gate.execute(
        "send_email", my_send_func,
        token=result.token,
        parameters={"to": "bob@company.com", "subject": "Q3 Report"},
    )
else:
    print(result.denial)
    # {"status": "denied", "reason": "insufficient_role", ...}
```

### Or Use the Decorator

```python
from agentlock import AuthorizationGate, agentlock

gate = AuthorizationGate()

@agentlock(gate, risk_level="high", allowed_roles=["admin"])
def send_email(to: str, subject: str, body: str) -> str:
    return f"Email sent to {to}"

# Call with auth context
send_email(
    to="bob@co.com", subject="Hi", body="Hello",
    _user_id="alice", _role="admin",
)
```

## Three-Layer Enforcement

AgentLock enforces permissions at the infrastructure layer, not the content layer. The architecture has three layers:

```
┌──────────────────────────────────────────────┐
│  Layer 1: Agent (Conversation)               │
│  - Reads/writes messages                     │
│  - Decides which tool to call                │
│  - CANNOT authenticate, see credentials,     │
│    or access backends                        │
├──────────────────────────────────────────────┤
│  Layer 2: Authorization Gate (AgentLock)      │
│  - Validates permissions                     │
│  - Verifies identity, role, scope            │
│  - Enforces rate limits                      │
│  - Issues single-use execution tokens        │
│  - Generates audit records                   │
├──────────────────────────────────────────────┤
│  Layer 3: Tool Execution (Infrastructure)     │
│  - Validates token                           │
│  - Executes within scoped boundaries         │
│  - Enforces data policy / redaction          │
│  - Token is single-use, time-limited         │
└──────────────────────────────────────────────┘
```

The key constraint: the agent never receives execution tokens. Layer 2 passes them directly to Layer 3. The agent gets only the result.

## Why Not Content Detection?

This design is informed by empirical research — 187 multi-turn adversarial attack tests across 35 categories, tested against 6 frontier AI models.

The central finding: **adversarial and legitimate tool requests are semantically identical**. A social engineering attack that convinces an agent to send an email looks exactly like a legitimate request to send an email. Content-based detection — guardrails, prompt engineering, output filtering — cannot reliably distinguish them.

The correct defense is architectural: enforce access control at the infrastructure layer, the same way databases, filesystems, and APIs do.

## The Schema

An AgentLock-compliant tool extends the standard definition:

```json
{
  "name": "send_email",
  "description": "Sends an email to a recipient",
  "parameters": { "to": "string", "subject": "string", "body": "string" },
  "agentlock": {
    "version": "1.0",
    "risk_level": "high",
    "requires_auth": true,
    "allowed_roles": ["account_owner", "admin"],
    "scope": {
      "data_boundary": "authenticated_user_only",
      "max_records": 1,
      "allowed_recipients": "known_contacts_only"
    },
    "rate_limit": { "max_calls": 5, "window_seconds": 3600 },
    "data_policy": {
      "output_classification": "contains_pii",
      "prohibited_in_output": ["ssn", "credit_card"],
      "redaction": "auto"
    },
    "audit": { "log_level": "full", "retention_days": 90 },
    "human_approval": { "required": false }
  }
}
```

## Framework Integrations

The core library has zero framework dependencies. Optional integrations exist for:

- **LangChain** — wraps `BaseTool` instances
- **CrewAI** — wraps crew tools across all agents
- **AutoGen** — wraps function maps
- **MCP** — wraps Model Context Protocol tool dispatch
- **FastAPI** — middleware + dependency injection
- **Flask** — decorator + extension

```bash
pip install agentlock[langchain]
pip install agentlock[crewai]
pip install agentlock[all]
```

## What It Is and Isn't

AgentLock is an open standard and reference implementation. Apache 2.0 licensed. It's not a SaaS product, not a startup, not a wrapper around another API. It's infrastructure — the same way OAuth is infrastructure for API authorization.

This is a v1.0 release. The spec and library are complete and tested (267 unit tests, zero lint errors, zero type errors), but it's new. Feedback on the schema design, enforcement model, and integration patterns is welcome.

- **GitHub**: [github.com/webpro255/agentlock](https://github.com/webpro255/agentlock)
- **Docs**: [agentlock.dev](https://agentlock.dev)
- **Install**: `pip install agentlock`
- **Spec**: [docs/specification.md](https://github.com/webpro255/agentlock/blob/main/docs/specification.md)
