"""Tests for v0.5 cross-session user-scoped memory."""
import time
import pytest
from engram import Engram, EngramConfig, RecallOptions, UserMemoryEntry


@pytest.fixture
def memory():
    eng = Engram(EngramConfig(db_path=":memory:", semantic_search=False))
    yield eng
    eng.close()


# ── Schema ──────────────────────────────────────────────────────────────────

def test_user_memories_table_created(memory):
    memory._init()
    tables = [
        row[0] for row in
        memory._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    ]
    assert "user_memories" in tables


# ── remember_user / recall_user ──────────────────────────────────────────────

def test_remember_user_returns_entry(memory):
    entry = memory.remember_user("user_jeff", "Prefers TypeScript over JavaScript")
    assert isinstance(entry, UserMemoryEntry)
    assert entry.user_id == "user_jeff"
    assert entry.content == "Prefers TypeScript over JavaScript"
    assert entry.tier == "working"
    assert entry.consolidated_from is None


def test_recall_user_returns_stored(memory):
    memory.remember_user("user_jeff", "Prefers TypeScript")
    results = memory.recall_user("user_jeff")
    assert len(results) == 1
    assert results[0].content == "Prefers TypeScript"
    assert results[0].user_id == "user_jeff"


def test_user_memories_isolated_by_user(memory):
    memory.remember_user("user_a", "A's fact")
    memory.remember_user("user_b", "B's fact")

    a = memory.recall_user("user_a")
    b = memory.recall_user("user_b")

    assert len(a) == 1
    assert "user_a" not in a[0].content or "A's" in a[0].content
    assert len(b) == 1
    assert "B's" in b[0].content


def test_user_memories_isolated_from_sessions(memory):
    memory.remember("session_1", "Session content", "user")
    memory.remember_user("user_jeff", "User content")

    session_results = memory.recall("session_1")
    user_results = memory.recall_user("user_jeff")

    assert len(session_results) == 1
    assert session_results[0].content == "Session content"
    assert len(user_results) == 1
    assert user_results[0].content == "User content"


def test_user_memories_persist_across_sessions(memory):
    memory.remember_user("user_jeff", "Prefers concise answers")

    from_any_context = memory.recall_user("user_jeff")
    assert len(from_any_context) == 1
    assert from_any_context[0].content == "Prefers concise answers"


def test_recall_user_keyword(memory):
    memory.remember_user("user_jeff", "Prefers TypeScript")
    memory.remember_user("user_jeff", "Works on GovScout")

    results = memory.recall_user("user_jeff", "TypeScript")
    assert len(results) == 1
    assert "TypeScript" in results[0].content


def test_recall_user_empty(memory):
    results = memory.recall_user("unknown_user")
    assert results == []


# ── recall() with user_id blending ──────────────────────────────────────────

def test_recall_blends_user_memories_when_user_id_set(memory):
    memory.remember("session_1", "Session fact: deployed to prod", "user")
    memory.remember_user("user_jeff", "User fact: prefers TypeScript")

    opts = RecallOptions(user_id="user_jeff")
    results = memory.recall("session_1", options=opts)

    contents = [r.content for r in results]
    assert "Session fact: deployed to prod" in contents
    assert "User fact: prefers TypeScript" in contents


def test_recall_without_user_id_excludes_user_memories(memory):
    memory.remember("session_1", "Session content", "user")
    memory.remember_user("user_jeff", "User content")

    results = memory.recall("session_1")
    assert len(results) == 1
    assert results[0].content == "Session content"


def test_blended_user_entries_marked(memory):
    memory.remember("session_1", "Session content", "user")
    memory.remember_user("user_jeff", "User content")

    opts = RecallOptions(user_id="user_jeff")
    results = memory.recall("session_1", options=opts)
    user_entry = next((r for r in results if r.content == "User content"), None)

    assert user_entry is not None
    assert user_entry.metadata is not None
    assert user_entry.metadata.get("_user_memory") is True
    assert user_entry.metadata.get("user_id") == "user_jeff"
    assert user_entry.session_id == "user:user_jeff"


def test_blend_deduplicates_content(memory):
    shared = "This content exists in both scopes"
    memory.remember("session_1", shared, "user")
    memory.remember_user("user_jeff", shared)

    opts = RecallOptions(user_id="user_jeff")
    results = memory.recall("session_1", options=opts)
    matches = [r for r in results if r.content == shared]
    assert len(matches) == 1


# ── forget_user ──────────────────────────────────────────────────────────────

def test_forget_user_all(memory):
    memory.remember_user("user_jeff", "Fact 1")
    memory.remember_user("user_jeff", "Fact 2")

    deleted = memory.forget_user("user_jeff")
    assert deleted == 2
    assert memory.recall_user("user_jeff") == []


def test_forget_user_by_id(memory):
    entry = memory.remember_user("user_jeff", "To delete")
    memory.remember_user("user_jeff", "To keep")

    deleted = memory.forget_user("user_jeff", id=entry.id)
    assert deleted == 1
    results = memory.recall_user("user_jeff")
    assert len(results) == 1
    assert results[0].content == "To keep"


def test_forget_user_does_not_affect_other_users(memory):
    memory.remember_user("user_a", "A fact")
    memory.remember_user("user_b", "B fact")

    memory.forget_user("user_a")
    b = memory.recall_user("user_b")
    assert len(b) == 1


# ── user_stats ────────────────────────────────────────────────────────────────

def test_user_stats_counts(memory):
    memory.remember_user("user_jeff", "Fact 1", "user")
    memory.remember_user("user_jeff", "Fact 2", "assistant")
    memory.remember_user("user_jeff", "Fact 3", "user")

    stats = memory.user_stats("user_jeff")
    assert stats["total"] == 3
    assert stats["by_role"]["user"] == 2
    assert stats["by_role"]["assistant"] == 1
    assert stats["by_tier"]["working"] == 3
    assert stats["by_tier"]["long_term"] == 0
    assert stats["oldest"] is not None
    assert stats["newest"] is not None


def test_user_stats_empty(memory):
    stats = memory.user_stats("nobody")
    assert stats["total"] == 0
    assert stats["by_tier"]["working"] == 0


# ── consolidate_user ─────────────────────────────────────────────────────────

def test_consolidate_user_empty(memory):
    from engram import ConsolidateOptions
    result = memory.consolidate_user("nobody")
    assert result.summarized == 0
    assert result.created == 0
    assert result.archived == 0


def test_consolidate_user_fewer_than_keep(memory):
    from engram import ConsolidateOptions
    memory.remember_user("user_jeff", "Only fact")
    result = memory.consolidate_user("user_jeff", ConsolidateOptions(keep=5))
    assert result.summarized == 0


def test_consolidate_user_archives_and_creates_summaries(memory):
    from engram import ConsolidateOptions

    class MockEngram(Engram):
        def _summarize_memories(self, entries, model):
            return ["User summary: " + " | ".join(e.content[:15] for e in entries[:3])]

    m = MockEngram(EngramConfig(db_path=":memory:", semantic_search=False))
    for i in range(15):
        m.remember_user("user_jeff", f"User fact {i}", "user")
        time.sleep(0.001)

    result = m.consolidate_user("user_jeff", ConsolidateOptions(batch=10, keep=3))

    assert result.summarized == 10
    assert result.created == 1
    assert result.archived == 10

    stats = m.user_stats("user_jeff")
    assert stats["by_tier"]["archived"] == 10
    assert stats["by_tier"]["long_term"] == 1
    assert stats["by_tier"]["working"] == 5  # 3 kept + 2 that didn't fit batch
    m.close()


# ── UserMemoryEntry fields ────────────────────────────────────────────────────

def test_user_memory_entry_fields(memory):
    entry = memory.remember_user("user_jeff", "Test fact", "user", metadata={"source": "test"})
    assert entry.id
    assert entry.user_id == "user_jeff"
    assert entry.content == "Test fact"
    assert entry.role == "user"
    assert entry.tier == "working"
    assert entry.metadata == {"source": "test"}
    assert entry.consolidated_from is None
    assert entry.similarity is None


def test_recall_user_entries_have_all_fields(memory):
    memory.remember_user("user_jeff", "Test fact")
    results = memory.recall_user("user_jeff")
    e = results[0]
    assert e.user_id == "user_jeff"
    assert e.tier == "working"
    assert e.id
    assert e.timestamp
