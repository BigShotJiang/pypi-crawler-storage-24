"""
cartisien-engram — Persistent semantic memory for AI agents.
Python SDK. SQLite-backed, local-first, zero config.
"""

from .engram import (
    Engram,
    MemoryEntry,
    EngramConfig,
    RecallOptions,
    ConsolidateOptions,
    ConsolidationResult,
    GraphEdge,
    GraphResult,
    MemoryTier,
    UserMemoryEntry,
)

__version__ = "0.5.0"
__all__ = [
    "Engram",
    "MemoryEntry",
    "EngramConfig",
    "RecallOptions",
    "ConsolidateOptions",
    "ConsolidationResult",
    "GraphEdge",
    "GraphResult",
    "MemoryTier",
    "UserMemoryEntry",
]
