"""
Engram — Persistent semantic memory for AI agents.
v0.4: memory consolidation + long-term summarization.
"""

import sqlite3
import hashlib
import json
import math
import re
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Any, Literal
from pathlib import Path


MemoryTier = Literal["working", "long_term", "archived"]


@dataclass
class EngramConfig:
    db_path: str = ":memory:"
    max_context_length: int = 4000
    embedding_url: str = "http://localhost:11434"
    embedding_model: str = "nomic-embed-text"
    semantic_search: bool = True
    graph_memory: bool = False
    graph_model: str = "qwen2.5:32b"
    # v0.4: consolidation
    auto_consolidate: bool = False
    consolidate_threshold: int = 100
    consolidate_keep: int = 20
    consolidate_batch: int = 50
    consolidate_model: str = "qwen2.5:32b"


@dataclass
class RecallOptions:
    limit: int = 10
    role: Optional[str] = None
    before: Optional[datetime] = None
    after: Optional[datetime] = None
    include_graph: bool = True
    tiers: list[MemoryTier] = field(default_factory=lambda: ["working", "long_term"])
    user_id: Optional[str] = None  # v0.5: also blend in user-scoped memories


@dataclass
class UserMemoryEntry:
    """v0.5: A memory entry scoped to a user rather than a session."""
    id: str
    user_id: str
    content: str
    role: str
    timestamp: datetime
    tier: MemoryTier = "working"
    consolidated_from: Optional[list[str]] = None
    metadata: Optional[dict] = None
    similarity: Optional[float] = None


@dataclass
class ConsolidateOptions:
    batch: Optional[int] = None
    keep: Optional[int] = None
    model: Optional[str] = None
    dry_run: bool = False


@dataclass
class ConsolidationResult:
    summarized: int
    created: int
    archived: int
    previews: Optional[list[str]] = None


@dataclass
class MemoryEntry:
    id: str
    session_id: str
    content: str
    role: str
    timestamp: datetime
    tier: MemoryTier = "working"
    consolidated_from: Optional[list[str]] = None
    metadata: Optional[dict] = None
    similarity: Optional[float] = None


@dataclass
class GraphEdge:
    from_entity: str
    relation: str
    to_entity: str
    confidence: float = 1.0


@dataclass
class GraphResult:
    entity: str
    relationships: list[dict]
    related_memories: list[MemoryEntry]


class Engram:
    """
    Persistent semantic memory for AI agents.

    v0.4 adds memory consolidation — working memories are periodically
    summarized into long-term memories by a local LLM, keeping context
    dense and relevant as conversations grow.

    Example:
        memory = Engram(EngramConfig(
            db_path="./memory.db",
            auto_consolidate=True,
            consolidate_threshold=100,
        ))

        # Manual consolidation
        result = memory.consolidate("session_1")
        # ConsolidationResult(summarized=50, created=4, archived=50)

        # Preview without writing
        preview = memory.consolidate("session_1", ConsolidateOptions(dry_run=True))
        # ConsolidationResult(summarized=50, created=0, archived=0, previews=[...])
    """

    def __init__(self, config: Optional[EngramConfig] = None):
        self.config = config or EngramConfig()
        self._conn: Optional[sqlite3.Connection] = None
        self._initialized = False

    def _init(self):
        if self._initialized:
            return

        db_path = self.config.db_path
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row

        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                content TEXT NOT NULL,
                role TEXT CHECK(role IN ('user', 'assistant', 'system')),
                timestamp INTEGER NOT NULL,
                metadata TEXT,
                content_hash TEXT NOT NULL,
                embedding TEXT,
                tier TEXT NOT NULL DEFAULT 'working',
                consolidated_from TEXT
            )
        """)

        # Migrations for existing databases
        for col, defn in [
            ("embedding", "TEXT"),
            ("tier", "TEXT NOT NULL DEFAULT 'working'"),
            ("consolidated_from", "TEXT"),
        ]:
            try:
                self._conn.execute(f"ALTER TABLE memories ADD COLUMN {col} {defn}")
            except sqlite3.OperationalError:
                pass

        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_session_timestamp
            ON memories(session_id, timestamp DESC)
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_session_tier
            ON memories(session_id, tier)
        """)

        # Graph tables
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS graph_nodes (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                entity TEXT NOT NULL,
                type TEXT,
                created_at INTEGER NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_node_entity
            ON graph_nodes(session_id, entity)
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS graph_edges (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                from_entity TEXT NOT NULL,
                relation TEXT NOT NULL,
                to_entity TEXT NOT NULL,
                confidence REAL DEFAULT 1.0,
                memory_id TEXT,
                created_at INTEGER NOT NULL
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_edge_from
            ON graph_edges(session_id, from_entity)
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_edge_to
            ON graph_edges(session_id, to_entity)
        """)

        # v0.5: User-scoped memories (cross-session)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS user_memories (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                content TEXT NOT NULL,
                role TEXT CHECK(role IN ('user', 'assistant', 'system')),
                timestamp INTEGER NOT NULL,
                metadata TEXT,
                content_hash TEXT NOT NULL,
                embedding TEXT,
                tier TEXT NOT NULL DEFAULT 'working',
                consolidated_from TEXT
            )
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_timestamp
            ON user_memories(user_id, timestamp DESC)
        """)
        self._conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_tier
            ON user_memories(user_id, tier)
        """)

        self._conn.commit()
        self._initialized = True

    def _ollama_post(self, endpoint: str, payload: dict, timeout: int = 5) -> Optional[dict]:
        try:
            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                f"{self.config.embedding_url}/{endpoint}",
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.load(resp)
        except Exception:
            return None

    def _embed(self, text: str) -> Optional[list[float]]:
        result = self._ollama_post("api/embeddings", {
            "model": self.config.embedding_model,
            "prompt": text
        })
        return result.get("embedding") if result else None

    def _extract_graph(self, text: str) -> list[GraphEdge]:
        prompt = (
            'Extract entity-relationship triples from this text. '
            'Return ONLY a JSON array of objects with keys: "from", "relation", "to". '
            'Be concise. Max 5 triples. If nothing to extract, return [].\n\n'
            f'Text: "{text}"\n\nJSON array:'
        )
        result = self._ollama_post("api/generate", {
            "model": self.config.graph_model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0, "num_predict": 200}
        }, timeout=15)

        if not result:
            return []

        raw = result.get("response", "").strip()
        match = re.search(r'\[[\s\S]*\]', raw)
        if not match:
            return []

        try:
            triples = json.loads(match.group(0))
            return [
                GraphEdge(
                    from_entity=str(t["from"]).lower().strip(),
                    relation=str(t["relation"]).lower().strip(),
                    to_entity=str(t["to"]).lower().strip(),
                    confidence=0.9
                )
                for t in triples
                if t.get("from") and t.get("relation") and t.get("to")
            ]
        except Exception:
            return []

    def _upsert_node(self, session_id: str, entity: str, type_: Optional[str] = None):
        node_id = hashlib.sha256(f"{session_id}:{entity}".encode()).hexdigest()[:16]
        self._conn.execute(
            """INSERT OR IGNORE INTO graph_nodes (id, session_id, entity, type, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (node_id, session_id, entity, type_, int(time.time() * 1000))
        )

    def _store_edge(self, session_id: str, edge: GraphEdge, memory_id: str):
        edge_id = hashlib.sha256(
            f"{session_id}:{edge.from_entity}:{edge.relation}:{edge.to_entity}".encode()
        ).hexdigest()[:16]
        self._upsert_node(session_id, edge.from_entity)
        self._upsert_node(session_id, edge.to_entity)
        self._conn.execute(
            """INSERT OR REPLACE INTO graph_edges
               (id, session_id, from_entity, relation, to_entity, confidence, memory_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (edge_id, session_id, edge.from_entity, edge.relation,
             edge.to_entity, edge.confidence, memory_id, int(time.time() * 1000))
        )

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        mag_a = math.sqrt(sum(x * x for x in a))
        mag_b = math.sqrt(sum(x * x for x in b))
        denom = mag_a * mag_b
        return dot / denom if denom != 0 else 0.0

    def _row_to_entry(self, row, similarity: Optional[float] = None) -> MemoryEntry:
        return MemoryEntry(
            id=row["id"],
            session_id=row["session_id"],
            content=row["content"],
            role=row["role"],
            timestamp=datetime.fromtimestamp(row["timestamp"] / 1000),
            tier=row["tier"] if row["tier"] else "working",
            consolidated_from=json.loads(row["consolidated_from"]) if row["consolidated_from"] else None,
            metadata=json.loads(row["metadata"]) if row["metadata"] else None,
            similarity=similarity
        )

    def _summarize_memories(self, entries: list[MemoryEntry], model: str) -> list[str]:
        """
        Call LLM to summarize a batch of memories into consolidated entries.
        Returns a list of summary strings.
        """
        numbered = "\n".join(
            f"[{i + 1}] ({e.role}) {e.content}"
            for i, e in enumerate(entries)
        )
        prompt = (
            "You are a memory consolidation system. Given these conversation memories, "
            "produce 2-5 concise summary entries that preserve all important facts: "
            "names, dates, decisions, preferences, and technical details. "
            "Each summary should be a single dense sentence or short paragraph. "
            "Return ONLY a JSON array of strings.\n\n"
            f"Memories:\n{numbered}\n\nJSON array of summary strings:"
        )

        result = self._ollama_post("api/generate", {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.2, "num_predict": 800}
        }, timeout=60)

        if not result:
            return []

        raw = result.get("response", "").strip()
        match = re.search(r'\[[\s\S]*\]', raw)
        if not match:
            return []

        try:
            summaries = json.loads(match.group(0))
            return [s for s in summaries if isinstance(s, str) and s.strip()]
        except Exception:
            return []

    def consolidate(
        self,
        session_id: str,
        options: Optional[ConsolidateOptions] = None
    ) -> ConsolidationResult:
        """
        v0.4: Consolidate working memories into long-term summaries.

        Takes the oldest `batch` working memories (excluding the `keep` most recent),
        summarizes them via LLM, stores summaries as long_term tier, and archives
        the originals.

        Args:
            session_id: Session to consolidate.
            options: ConsolidateOptions(batch, keep, model, dry_run)

        Returns:
            ConsolidationResult with counts of summarized/created/archived entries.

        Example:
            result = memory.consolidate("session_1")
            # ConsolidationResult(summarized=50, created=4, archived=50)

            preview = memory.consolidate("session_1", ConsolidateOptions(dry_run=True))
            # ConsolidationResult(summarized=50, created=0, archived=0, previews=[...])
        """
        self._init()
        opts = options or ConsolidateOptions()

        batch = opts.batch if opts.batch is not None else self.config.consolidate_batch
        keep = opts.keep if opts.keep is not None else self.config.consolidate_keep
        model = opts.model or self.config.consolidate_model

        # Fetch oldest working memories, enough to drop the `keep` most recent
        rows = self._conn.execute(
            """SELECT * FROM memories
               WHERE session_id = ? AND tier = 'working'
               ORDER BY timestamp ASC
               LIMIT ?""",
            (session_id, batch + keep)
        ).fetchall()

        # Drop the most recent `keep` — leave them as working memory
        candidates = list(rows)[:max(0, len(rows) - keep)]

        if not candidates:
            return ConsolidationResult(summarized=0, created=0, archived=0)

        entries = [self._row_to_entry(row) for row in candidates]
        summaries = self._summarize_memories(entries, model)

        if not summaries:
            return ConsolidationResult(summarized=len(entries), created=0, archived=0)

        if opts.dry_run:
            return ConsolidationResult(
                summarized=len(entries),
                created=0,
                archived=0,
                previews=summaries
            )

        source_ids = [e.id for e in entries]
        consolidated_from_json = json.dumps(source_ids)
        now = int(time.time() * 1000)

        for summary in summaries:
            summary_id = hashlib.sha256(
                f"{session_id}:lt:{summary}:{now}".encode()
            ).hexdigest()[:16]
            content_hash = hashlib.sha256(summary.encode()).hexdigest()[:16]
            truncated = summary[:self.config.max_context_length]

            embedding_json = None
            if self.config.semantic_search:
                vec = self._embed(truncated)
                if vec:
                    embedding_json = json.dumps(vec)

            self._conn.execute(
                """INSERT INTO memories
                   (id, session_id, content, role, timestamp, metadata,
                    content_hash, embedding, tier, consolidated_from)
                   VALUES (?, ?, ?, 'system', ?, NULL, ?, ?, 'long_term', ?)""",
                (summary_id, session_id, truncated, now,
                 content_hash, embedding_json, consolidated_from_json)
            )

        # Archive originals
        placeholders = ",".join("?" * len(source_ids))
        self._conn.execute(
            f"UPDATE memories SET tier = 'archived' WHERE id IN ({placeholders})",
            source_ids
        )
        self._conn.commit()

        return ConsolidationResult(
            summarized=len(entries),
            created=len(summaries),
            archived=len(entries)
        )

    def remember(
        self,
        session_id: str,
        content: str,
        role: str = "user",
        metadata: Optional[dict] = None
    ) -> MemoryEntry:
        """
        Store a memory. Embedding + graph extraction happen automatically.
        With auto_consolidate=True, triggers consolidation when working memory
        count exceeds consolidate_threshold.
        """
        self._init()

        truncated = content[:self.config.max_context_length]
        ts = int(time.time() * 1000)
        id_ = hashlib.sha256(f"{session_id}:{content}:{ts}".encode()).hexdigest()[:16]
        content_hash = hashlib.sha256(truncated.encode()).hexdigest()[:16]

        embedding_json = None
        if self.config.semantic_search:
            vec = self._embed(truncated)
            if vec:
                embedding_json = json.dumps(vec)

        self._conn.execute(
            """INSERT INTO memories
               (id, session_id, content, role, timestamp, metadata,
                content_hash, embedding, tier)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'working')""",
            (id_, session_id, truncated, role, ts,
             json.dumps(metadata) if metadata else None,
             content_hash, embedding_json)
        )

        if self.config.graph_memory:
            edges = self._extract_graph(truncated)
            for edge in edges:
                self._store_edge(session_id, edge, id_)

        self._conn.commit()

        # v0.4: auto-consolidate if threshold exceeded
        if self.config.auto_consolidate:
            count = self._conn.execute(
                "SELECT COUNT(*) FROM memories WHERE session_id = ? AND tier = 'working'",
                (session_id,)
            ).fetchone()[0]
            if count > self.config.consolidate_threshold:
                try:
                    self.consolidate(session_id)
                except Exception:
                    pass

        return MemoryEntry(
            id=id_, session_id=session_id, content=truncated, role=role,
            timestamp=datetime.fromtimestamp(ts / 1000), tier="working",
            metadata=metadata
        )

    def _augment_with_graph(
        self, session_id: str, results: list[MemoryEntry], limit: int
    ) -> list[MemoryEntry]:
        seen_ids = {r.id for r in results}
        graph_ids = set()

        for result in results[:3]:
            rows = self._conn.execute(
                """SELECT DISTINCT memory_id FROM graph_edges
                   WHERE session_id = ? AND memory_id IS NOT NULL
                   AND (from_entity IN (
                       SELECT from_entity FROM graph_edges WHERE memory_id = ?
                       UNION SELECT to_entity FROM graph_edges WHERE memory_id = ?
                   ))
                   LIMIT 5""",
                (session_id, result.id, result.id)
            ).fetchall()
            for row in rows:
                mid = row["memory_id"]
                if mid and mid not in seen_ids:
                    graph_ids.add(mid)

        if not graph_ids:
            return results

        placeholders = ",".join("?" * len(graph_ids))
        rows = self._conn.execute(
            f"SELECT * FROM memories WHERE id IN ({placeholders})",
            list(graph_ids)
        ).fetchall()

        connected = [self._row_to_entry(row, similarity=0.0) for row in rows]
        return (results + connected)[:limit]

    def recall(
        self,
        session_id: str,
        query: Optional[str] = None,
        limit: int = 10,
        options: Optional[RecallOptions] = None
    ) -> list[MemoryEntry]:
        """
        Recall memories. Searches working and long_term tiers by default.
        Archived memories are excluded unless explicitly requested via options.tiers.
        Semantic search when Ollama available, keyword fallback otherwise.
        Graph traversal augments top results when graph_memory=True.
        """
        self._init()
        opts = options or RecallOptions(limit=limit)

        tiers = opts.tiers
        tier_placeholders = ",".join("?" * len(tiers))

        sql = f"SELECT * FROM memories WHERE session_id = ? AND tier IN ({tier_placeholders})"
        params: list[Any] = [session_id, *tiers]

        if opts.role:
            sql += " AND role = ?"
            params.append(opts.role)
        if opts.after:
            sql += " AND timestamp >= ?"
            params.append(int(opts.after.timestamp() * 1000))
        if opts.before:
            sql += " AND timestamp <= ?"
            params.append(int(opts.before.timestamp() * 1000))

        # Semantic search
        if query and query.strip() and self.config.semantic_search:
            query_vec = self._embed(query)
            if query_vec:
                rows = self._conn.execute(sql + " ORDER BY timestamp DESC", params).fetchall()

                scored = []
                for row in rows:
                    similarity = 0.0
                    if row["embedding"]:
                        try:
                            vec = json.loads(row["embedding"])
                            similarity = self._cosine_similarity(query_vec, vec)
                        except Exception:
                            pass
                    scored.append((row, similarity))

                scored.sort(key=lambda x: x[1], reverse=True)
                scored = scored[:limit]
                results = [self._row_to_entry(row, sim) for row, sim in scored]

                if self.config.graph_memory and opts.include_graph:
                    results = self._augment_with_graph(session_id, results, limit)

                return results

        # Keyword fallback
        if query and query.strip():
            keywords = [k for k in query.lower().split() if len(k) > 2]
            if keywords:
                sql += " AND (" + " OR ".join("LOWER(content) LIKE ?" for _ in keywords) + ")"
                params.extend(f"%{k}%" for k in keywords)

        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(sql, params).fetchall()
        results = [self._row_to_entry(row) for row in rows]
        return self._blend_user_memories(results, opts.user_id, query, opts.limit)

    def _blend_user_memories(
        self,
        session_results: list[MemoryEntry],
        user_id: Optional[str],
        query: Optional[str],
        limit: int
    ) -> list[MemoryEntry]:
        """Blend user-scoped memories into session recall results."""
        if not user_id:
            return session_results

        user_entries = self.recall_user(user_id, query, max(1, limit // 2))
        seen_content = {r.content for r in session_results}
        blended = list(session_results)

        for u in user_entries:
            if u.content not in seen_content:
                blended.append(MemoryEntry(
                    id=u.id,
                    session_id=f"user:{u.user_id}",
                    content=u.content,
                    role=u.role,
                    timestamp=u.timestamp,
                    tier=u.tier,
                    consolidated_from=u.consolidated_from,
                    metadata={**(u.metadata or {}), "_user_memory": True, "user_id": u.user_id},
                    similarity=u.similarity,
                ))

        return blended[:limit]

    def history(self, session_id: str, limit: int = 20) -> list[MemoryEntry]:
        """Recent working + long_term memories in chronological order."""
        self._init()
        rows = self._conn.execute(
            """SELECT * FROM (
                   SELECT * FROM memories
                   WHERE session_id = ? AND tier IN ('working', 'long_term')
                   ORDER BY timestamp DESC LIMIT ?
               ) ORDER BY timestamp ASC""",
            (session_id, limit)
        ).fetchall()
        return [self._row_to_entry(row) for row in rows]

    def graph(self, session_id: str, entity: str) -> GraphResult:
        """
        Query the knowledge graph for an entity.
        Returns relationships and source memories.
        """
        self._init()
        ent = entity.lower().strip()

        outgoing = self._conn.execute(
            """SELECT relation, to_entity, confidence, memory_id FROM graph_edges
               WHERE session_id = ? AND from_entity = ?""",
            (session_id, ent)
        ).fetchall()

        incoming = self._conn.execute(
            """SELECT relation, from_entity, confidence, memory_id FROM graph_edges
               WHERE session_id = ? AND to_entity = ?""",
            (session_id, ent)
        ).fetchall()

        relationships = [
            {"type": "outgoing", "relation": r["relation"],
             "target": r["to_entity"], "confidence": r["confidence"]}
            for r in outgoing
        ] + [
            {"type": "incoming", "relation": r["relation"],
             "target": r["from_entity"], "confidence": r["confidence"]}
            for r in incoming
        ]

        memory_ids = list({
            r["memory_id"] for r in list(outgoing) + list(incoming)
            if r["memory_id"]
        })

        related_memories = []
        if memory_ids:
            placeholders = ",".join("?" * len(memory_ids))
            rows = self._conn.execute(
                f"SELECT * FROM memories WHERE id IN ({placeholders})", memory_ids
            ).fetchall()
            related_memories = [self._row_to_entry(row) for row in rows]

        return GraphResult(
            entity=ent,
            relationships=relationships,
            related_memories=related_memories
        )

    def forget(
        self,
        session_id: str,
        id: Optional[str] = None,
        before: Optional[datetime] = None,
        include_long_term: bool = False
    ) -> int:
        """Delete memories. Returns count deleted. Archived memories excluded by default."""
        self._init()

        tiers = "('working', 'long_term', 'archived')" if include_long_term else "('working', 'long_term')"

        if id:
            result = self._conn.execute(
                "DELETE FROM memories WHERE session_id = ? AND id = ?",
                (session_id, id)
            )
            self._conn.commit()
            return result.rowcount

        sql = f"DELETE FROM memories WHERE session_id = ? AND tier IN {tiers}"
        params: list[Any] = [session_id]

        if before:
            sql += " AND timestamp < ?"
            params.append(int(before.timestamp() * 1000))

        result = self._conn.execute(sql, params)
        self._conn.commit()
        return result.rowcount

    def stats(self, session_id: str) -> dict:
        """Memory statistics for a session."""
        self._init()

        total = self._conn.execute(
            "SELECT COUNT(*) FROM memories WHERE session_id = ? AND tier != 'archived'",
            (session_id,)
        ).fetchone()[0]

        role_rows = self._conn.execute(
            """SELECT role, COUNT(*) as cnt FROM memories
               WHERE session_id = ? AND tier != 'archived' GROUP BY role""",
            (session_id,)
        ).fetchall()
        by_role = {row[0]: row[1] for row in role_rows}

        tier_rows = self._conn.execute(
            "SELECT tier, COUNT(*) as cnt FROM memories WHERE session_id = ? GROUP BY tier",
            (session_id,)
        ).fetchall()
        by_tier: dict[str, int] = {"working": 0, "long_term": 0, "archived": 0}
        for row in tier_rows:
            by_tier[row[0]] = row[1]

        range_row = self._conn.execute(
            """SELECT MIN(timestamp), MAX(timestamp) FROM memories
               WHERE session_id = ? AND tier != 'archived'""",
            (session_id,)
        ).fetchone()

        with_embeddings = self._conn.execute(
            """SELECT COUNT(*) FROM memories
               WHERE session_id = ? AND tier != 'archived' AND embedding IS NOT NULL""",
            (session_id,)
        ).fetchone()[0]

        stats: dict[str, Any] = {
            "total": total,
            "by_role": by_role,
            "by_tier": by_tier,
            "oldest": datetime.fromtimestamp(range_row[0] / 1000) if range_row[0] else None,
            "newest": datetime.fromtimestamp(range_row[1] / 1000) if range_row[1] else None,
            "with_embeddings": with_embeddings,
        }

        if self.config.graph_memory:
            stats["graph_nodes"] = self._conn.execute(
                "SELECT COUNT(*) FROM graph_nodes WHERE session_id = ?", (session_id,)
            ).fetchone()[0]
            stats["graph_edges"] = self._conn.execute(
                "SELECT COUNT(*) FROM graph_edges WHERE session_id = ?", (session_id,)
            ).fetchone()[0]

        return stats

    # ── v0.5: User-scoped memory (cross-session) ──────────────────────────────

    def _row_to_user_entry(self, row, similarity: Optional[float] = None) -> UserMemoryEntry:
        return UserMemoryEntry(
            id=row["id"],
            user_id=row["user_id"],
            content=row["content"],
            role=row["role"],
            timestamp=datetime.fromtimestamp(row["timestamp"] / 1000),
            tier=row["tier"] if row["tier"] else "working",
            consolidated_from=json.loads(row["consolidated_from"]) if row["consolidated_from"] else None,
            metadata=json.loads(row["metadata"]) if row["metadata"] else None,
            similarity=similarity
        )

    def remember_user(
        self,
        user_id: str,
        content: str,
        role: str = "user",
        metadata: Optional[dict] = None
    ) -> UserMemoryEntry:
        """
        v0.5: Store a user-scoped memory that persists across all sessions.

        Use for facts about the user that should always be available regardless
        of which session is active — preferences, identity, long-term goals.

        Example:
            memory.remember_user("user_jeff", "Prefers TypeScript over JavaScript")
            memory.remember_user("user_jeff", "Building GovScout, a federal contracting app")

            # Available in any session
            facts = memory.recall_user("user_jeff", "what does the user prefer?")
        """
        self._init()

        truncated = content[:self.config.max_context_length]
        ts = int(time.time() * 1000)
        id_ = hashlib.sha256(f"{user_id}:{content}:{ts}".encode()).hexdigest()[:16]
        content_hash = hashlib.sha256(truncated.encode()).hexdigest()[:16]

        embedding_json = None
        if self.config.semantic_search:
            vec = self._embed(truncated)
            if vec:
                embedding_json = json.dumps(vec)

        self._conn.execute(
            """INSERT INTO user_memories
               (id, user_id, content, role, timestamp, metadata,
                content_hash, embedding, tier)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'working')""",
            (id_, user_id, truncated, role, ts,
             json.dumps(metadata) if metadata else None,
             content_hash, embedding_json)
        )
        self._conn.commit()

        return UserMemoryEntry(
            id=id_, user_id=user_id, content=truncated, role=role,
            timestamp=datetime.fromtimestamp(ts / 1000), tier="working",
            metadata=metadata
        )

    def recall_user(
        self,
        user_id: str,
        query: Optional[str] = None,
        limit: int = 10,
        tiers: Optional[list[MemoryTier]] = None,
        role: Optional[str] = None
    ) -> list[UserMemoryEntry]:
        """
        v0.5: Recall user-scoped memories. Works independently of any session.
        Semantic search when available, keyword fallback otherwise.
        """
        self._init()
        active_tiers = tiers or ["working", "long_term"]
        tier_placeholders = ",".join("?" * len(active_tiers))

        sql = f"SELECT * FROM user_memories WHERE user_id = ? AND tier IN ({tier_placeholders})"
        params: list[Any] = [user_id, *active_tiers]

        if role:
            sql += " AND role = ?"
            params.append(role)

        if query and query.strip() and self.config.semantic_search:
            query_vec = self._embed(query)
            if query_vec:
                rows = self._conn.execute(sql + " ORDER BY timestamp DESC", params).fetchall()
                scored = []
                for row in rows:
                    similarity = 0.0
                    if row["embedding"]:
                        try:
                            vec = json.loads(row["embedding"])
                            similarity = self._cosine_similarity(query_vec, vec)
                        except Exception:
                            pass
                    scored.append((row, similarity))
                scored.sort(key=lambda x: x[1], reverse=True)
                return [self._row_to_user_entry(row, sim) for row, sim in scored[:limit]]

        if query and query.strip():
            keywords = [k for k in query.lower().split() if len(k) > 2]
            if keywords:
                sql += " AND (" + " OR ".join("LOWER(content) LIKE ?" for _ in keywords) + ")"
                params.extend(f"%{k}%" for k in keywords)

        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_user_entry(row) for row in rows]

    def forget_user(
        self,
        user_id: str,
        id: Optional[str] = None,
        before: Optional[datetime] = None,
        include_long_term: bool = False
    ) -> int:
        """Delete user-scoped memories. Returns count deleted."""
        self._init()
        tiers = "('working', 'long_term', 'archived')" if include_long_term else "('working', 'long_term')"

        if id:
            result = self._conn.execute(
                "DELETE FROM user_memories WHERE user_id = ? AND id = ?", (user_id, id)
            )
            self._conn.commit()
            return result.rowcount

        sql = f"DELETE FROM user_memories WHERE user_id = ? AND tier IN {tiers}"
        params: list[Any] = [user_id]
        if before:
            sql += " AND timestamp < ?"
            params.append(int(before.timestamp() * 1000))

        result = self._conn.execute(sql, params)
        self._conn.commit()
        return result.rowcount

    def consolidate_user(
        self,
        user_id: str,
        options: Optional[ConsolidateOptions] = None
    ) -> ConsolidationResult:
        """v0.5: Consolidate user-scoped memories into long-term summaries."""
        self._init()
        opts = options or ConsolidateOptions()

        batch = opts.batch if opts.batch is not None else self.config.consolidate_batch
        keep = opts.keep if opts.keep is not None else self.config.consolidate_keep
        model = opts.model or self.config.consolidate_model

        rows = self._conn.execute(
            """SELECT * FROM user_memories
               WHERE user_id = ? AND tier = 'working'
               ORDER BY timestamp ASC LIMIT ?""",
            (user_id, batch + keep)
        ).fetchall()

        candidates = list(rows)[:max(0, len(rows) - keep)]
        if not candidates:
            return ConsolidationResult(summarized=0, created=0, archived=0)

        entries = [self._row_to_user_entry(row) for row in candidates]

        # Reuse _summarize_memories by adapting UserMemoryEntry to MemoryEntry-like objects
        mem_entries = [
            MemoryEntry(
                id=e.id, session_id=e.user_id, content=e.content,
                role=e.role, timestamp=e.timestamp, tier=e.tier
            )
            for e in entries
        ]
        summaries = self._summarize_memories(mem_entries, model)

        if not summaries:
            return ConsolidationResult(summarized=len(entries), created=0, archived=0)

        if opts.dry_run:
            return ConsolidationResult(
                summarized=len(entries), created=0, archived=0, previews=summaries
            )

        source_ids = [e.id for e in entries]
        consolidated_from_json = json.dumps(source_ids)
        now = int(time.time() * 1000)

        for summary in summaries:
            summary_id = hashlib.sha256(
                f"{user_id}:lt:{summary}:{now}".encode()
            ).hexdigest()[:16]
            content_hash = hashlib.sha256(summary.encode()).hexdigest()[:16]
            truncated = summary[:self.config.max_context_length]

            embedding_json = None
            if self.config.semantic_search:
                vec = self._embed(truncated)
                if vec:
                    embedding_json = json.dumps(vec)

            self._conn.execute(
                """INSERT INTO user_memories
                   (id, user_id, content, role, timestamp, metadata,
                    content_hash, embedding, tier, consolidated_from)
                   VALUES (?, ?, ?, 'system', ?, NULL, ?, ?, 'long_term', ?)""",
                (summary_id, user_id, truncated, now,
                 content_hash, embedding_json, consolidated_from_json)
            )

        placeholders = ",".join("?" * len(source_ids))
        self._conn.execute(
            f"UPDATE user_memories SET tier = 'archived' WHERE id IN ({placeholders})",
            source_ids
        )
        self._conn.commit()

        return ConsolidationResult(
            summarized=len(entries), created=len(summaries), archived=len(entries)
        )

    def user_stats(self, user_id: str) -> dict:
        """v0.5: Memory statistics for a user."""
        self._init()

        total = self._conn.execute(
            "SELECT COUNT(*) FROM user_memories WHERE user_id = ? AND tier != 'archived'",
            (user_id,)
        ).fetchone()[0]

        role_rows = self._conn.execute(
            """SELECT role, COUNT(*) as cnt FROM user_memories
               WHERE user_id = ? AND tier != 'archived' GROUP BY role""",
            (user_id,)
        ).fetchall()
        by_role = {row[0]: row[1] for row in role_rows}

        tier_rows = self._conn.execute(
            "SELECT tier, COUNT(*) as cnt FROM user_memories WHERE user_id = ? GROUP BY tier",
            (user_id,)
        ).fetchall()
        by_tier: dict[str, int] = {"working": 0, "long_term": 0, "archived": 0}
        for row in tier_rows:
            by_tier[row[0]] = row[1]

        range_row = self._conn.execute(
            """SELECT MIN(timestamp), MAX(timestamp) FROM user_memories
               WHERE user_id = ? AND tier != 'archived'""",
            (user_id,)
        ).fetchone()

        with_embeddings = self._conn.execute(
            """SELECT COUNT(*) FROM user_memories
               WHERE user_id = ? AND tier != 'archived' AND embedding IS NOT NULL""",
            (user_id,)
        ).fetchone()[0]

        return {
            "total": total,
            "by_role": by_role,
            "by_tier": by_tier,
            "oldest": datetime.fromtimestamp(range_row[0] / 1000) if range_row[0] else None,
            "newest": datetime.fromtimestamp(range_row[1] / 1000) if range_row[1] else None,
            "with_embeddings": with_embeddings,
        }

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None
            self._initialized = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
