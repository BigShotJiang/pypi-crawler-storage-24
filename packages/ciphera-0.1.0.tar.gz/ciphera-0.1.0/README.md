# ciphera

**Zero-Knowledge KYC for Algorand** — verify KYC status on-chain without exposing personal data.

[![PyPI version](https://img.shields.io/pypi/v/ciphera)](https://pypi.org/project/ciphera)
[![Python](https://img.shields.io/pypi/pyversions/ciphera)](https://pypi.org/project/ciphera)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Install

```bash
pip install ciphera
```

## What is Ciphera?

Ciphera is a privacy-preserving zero-knowledge KYC system on Algorand. Users prove they are KYC-verified Indian adults **without revealing any personal data**. ZK proofs are generated in the browser — private inputs never leave the device.

## Quick Start

### Check KYC Status (any dApp)

```python
from ciphera import CipheraClient

client = CipheraClient()  # connects to Algorand Testnet by default

# Check total registered credentials on-chain
status = client.verify_kyc()
print(status.is_verified)        # True if any credentials registered
print(status.total_registered)   # e.g. 42
print(status.app_id)             # 756272073
```

### Check a Specific Nullifier

```python
client = CipheraClient()

# Check if a specific nullifier is registered
is_verified = client.is_nullifier_registered("3b1f8a2c" + "0" * 56)
print(is_verified)  # True / False
```

### Verify a ZK Proof (Issuer Backend)

```python
import json
from ciphera import verify_proof

vk = json.load(open("verification_key.json"))

result = verify_proof(
    verification_key=vk,
    proof=proof_dict,           # from browser SDK
    public_signals=signals_list,
    expected_app_id=756272073   # prevents cross-app attacks
)

if result.valid:
    print(result.nullifier_hex)    # 32-byte hex to register on-chain
    print(result.public_signals.is_adult)   # "1"
else:
    print(result.error)
```

### Connect to Different Networks

```python
from ciphera import CipheraClient

# Testnet (default)
client = CipheraClient()

# Mainnet
client = CipheraClient(network="mainnet")

# LocalNet (development)
client = CipheraClient(network="localnet")

# Custom endpoint
client = CipheraClient(
    algod_url="https://my-algod.example.com",
    algod_token="my-token"
)
```

---

## API Reference

### `CipheraClient`

```python
CipheraClient(
    network="testnet",   # "testnet" | "mainnet" | "localnet"
    algod_url=None,      # Override endpoint
    algod_token="",      # Override token
    contract_ids=None,   # Override deployed contract IDs (dict)
)
```

| Method | Returns | Description |
|---|---|---|
| `verify_kyc(wallet_address=None)` | `KYCStatus` | Check on-chain KYC registry |
| `is_nullifier_registered(hex)` | `bool` | Direct nullifier box check |
| `get_credential_asa_id()` | `int` | KYCRED ASA ID |
| `CipheraClient.explorer_tx_url(txid)` | `str` | Allo.info TX URL |
| `CipheraClient.explorer_app_url(app_id)` | `str` | Allo.info app URL |

### `verify_proof(vk, proof, public_signals, expected_app_id=None)`

Verify a Groth16 ZK proof off-chain.

> **Requires Node.js** (`node` must be in PATH) as it delegates to snarkjs.

Returns `ProofResult` with `.valid`, `.nullifier_hex`, `.public_signals`, `.error`.

---

## Models

```python
@dataclass
class KYCStatus:
    is_verified: bool
    app_id: int
    total_registered: Optional[int]
    nullifier: Optional[str]
    error: Optional[str]

@dataclass
class ProofResult:
    valid: bool
    nullifier_hex: Optional[str]
    public_signals: Optional[PublicSignals]
    error: Optional[str]
```

---

## Deployed Contracts (Algorand Testnet)

| Contract | App ID |
|---|---|
| NullifierRegistry | 756272073 |
| SMTRegistry | 756272075 |
| KYCBoxStorage | 756272299 |
| CredentialManager | 756281076 |
| KYCRED ASA | 756281102 |

---

## Requirements

- Python 3.9+
- `py-algorand-sdk` (installed automatically)
- Node.js (only required for `verify_proof()`)

---

## License

MIT © [Aditya Pandey](https://github.com/Aditya060806)
