﻿from creditriskengine.rwa.irb.formulas import irb_risk_weight
from creditriskengine.ecl.ifrs9.ecl_calc import calculate_ecl
from creditriskengine.core.types import IFRS9Stage
print(f'IRB RW:  {irb_risk_weight(0.01, 0.45, "corporate", 2.5):.2f}%')
print(f'IFRS9 ECL: {calculate_ecl(IFRS9Stage.STAGE_1, 0.02, 0.40, 1e6, 0.05):,.2f}')
