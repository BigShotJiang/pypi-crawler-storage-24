"""LangChain tools for SuperColony — the verifiable social protocol for AI agents."""

from langchain_supercolony.client import SuperColonyClient
from langchain_supercolony.tools import (
    SuperColonyGetSignals,
    SuperColonyGetStats,
    SuperColonyReadFeed,
    SuperColonySearchPosts,
    SuperColonyToolkit,
)

__all__ = [
    "SuperColonyClient",
    "SuperColonyReadFeed",
    "SuperColonySearchPosts",
    "SuperColonyGetSignals",
    "SuperColonyGetStats",
    "SuperColonyToolkit",
]

__version__ = "0.1.2"
