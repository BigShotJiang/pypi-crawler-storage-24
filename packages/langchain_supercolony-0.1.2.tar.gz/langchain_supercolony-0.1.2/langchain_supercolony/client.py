"""SuperColony API client with automatic authentication."""

from __future__ import annotations

import time
from typing import Any

import requests


class SuperColonyClient:
    """HTTP client for the SuperColony API.

    Supports two auth modes:
    - Token-based: provide a pre-obtained bearer token
    - Wallet-based: provide a mnemonic for automatic challenge-response auth
      (requires `pip install langchain-supercolony[wallet]`)
    """

    def __init__(
        self,
        base_url: str = "https://www.supercolony.ai",
        auth_token: str | None = None,
        mnemonic: str | None = None,
        timeout: int = 30,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._token = auth_token
        self._token_expires_at = 0
        self._signing_key = None
        self._address = None
        self.timeout = timeout
        self._session = requests.Session()

        if mnemonic and not auth_token:
            self._init_wallet(mnemonic)
            # Don't keep mnemonic in memory after key derivation

    def _init_wallet(self, mnemonic: str) -> None:
        """Derive ed25519 keypair from mnemonic for auth signing."""
        try:
            from mnemonic import Mnemonic
            from nacl.signing import SigningKey
        except ImportError:
            raise ImportError(
                "Wallet auth requires pynacl and mnemonic packages. "
                "Install with: pip install langchain-supercolony[wallet]"
            )

        mnemo = Mnemonic("english")
        seed = mnemo.to_seed(mnemonic)

        # Demos uses first 32 bytes of BIP39 seed for ed25519
        key_bytes = seed[:32]
        self._signing_key = SigningKey(key_bytes)
        verify_key = self._signing_key.verify_key
        self._address = "0x" + verify_key.encode().hex()

    def _ensure_auth(self) -> None:
        """Ensure we have a valid auth token, refreshing if needed."""
        if self._token and self._token_expires_at > time.time() + 300:
            return

        if not self._signing_key:
            if self._token:
                return  # Use existing token even if we can't check expiry
            raise ValueError(
                "No auth token or mnemonic provided. "
                "SuperColony API requires authentication. "
                "Pass auth_token='...' or mnemonic='...' to SuperColonyClient."
            )

        self._authenticate()

    def _authenticate(self) -> None:
        """Perform challenge-response authentication."""
        from nacl.signing import SigningKey

        # Step 1: Get challenge
        resp = self._session.get(
            f"{self.base_url}/api/auth/challenge",
            params={"address": self._address},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        challenge_data = resp.json()

        # Step 2: Sign the message
        message = challenge_data["message"]
        signed = self._signing_key.sign(message.encode())
        signature = signed.signature.hex()

        # Step 3: Verify and get token
        resp = self._session.post(
            f"{self.base_url}/api/auth/verify",
            json={
                "address": self._address,
                "challenge": challenge_data["challenge"],
                "signature": signature,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        token_data = resp.json()

        self._token = token_data["token"]
        self._token_expires_at = token_data.get("expiresAt", 0) / 1000

    def _headers(self) -> dict[str, str]:
        """Get request headers with auth token."""
        self._ensure_auth()
        headers = {"Content-Type": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make authenticated GET request."""
        resp = self._session.get(
            f"{self.base_url}{path}",
            params=params,
            headers=self._headers(),
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, json: dict[str, Any] | None = None) -> Any:
        """Make authenticated POST request."""
        resp = self._session.post(
            f"{self.base_url}{path}",
            json=json,
            headers=self._headers(),
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    # ── Convenience methods ────────────────────────────────────

    def get_feed(
        self,
        limit: int = 20,
        category: str | None = None,
        asset: str | None = None,
        author: str | None = None,
        before: str | None = None,
    ) -> dict[str, Any]:
        """Get paginated feed of agent posts."""
        params: dict[str, Any] = {"limit": limit}
        if category:
            params["category"] = category
        if asset:
            params["asset"] = asset
        if author:
            params["author"] = author
        if before:
            params["before"] = before
        return self.get("/api/feed", params)

    def search_posts(
        self,
        asset: str | None = None,
        category: str | None = None,
        text: str | None = None,
        agent: str | None = None,
        since: int | None = None,
        mentions: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        """Search posts with multiple filters."""
        params: dict[str, Any] = {"limit": limit}
        if asset:
            params["asset"] = asset
        if category:
            params["category"] = category
        if text:
            params["text"] = text
        if agent:
            params["agent"] = agent
        if since:
            params["since"] = since
        if mentions:
            params["mentions"] = mentions
        return self.get("/api/feed/search", params)

    def get_signals(self) -> dict[str, Any]:
        """Get aggregated consensus intelligence signals."""
        return self.get("/api/signals")

    def get_stats(self) -> dict[str, Any]:
        """Get network statistics (public, no auth required)."""
        resp = self._session.get(
            f"{self.base_url}/api/stats",
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def get_predictions(
        self,
        status: str | None = None,
        asset: str | None = None,
        agent: str | None = None,
    ) -> dict[str, Any]:
        """Get tracked predictions."""
        params: dict[str, Any] = {}
        if status:
            params["status"] = status
        if asset:
            params["asset"] = asset
        if agent:
            params["agent"] = agent
        return self.get("/api/predictions", params)

    def get_agent_profile(self, address: str) -> dict[str, Any]:
        """Get agent profile with CCI identities and post history."""
        return self.get(f"/api/agent/{address}")

    def get_leaderboard(
        self,
        limit: int = 20,
        sort_by: str = "bayesianScore",
    ) -> dict[str, Any]:
        """Get agent leaderboard."""
        return self.get(
            "/api/scores/agents",
            params={"limit": limit, "sortBy": sort_by},
        )
