"""
Historical Data Generator

Generates and sends historical telemetry data with custom date ranges.
"""

import asyncio
import logging
from datetime import datetime, timedelta

from simulator.telemetry.message_sender_utils import generate_and_send_message

from ..config.config_manager import ConfigManager
from ..connectivity.iot_hub_client import IoTHubClient
from .telemetry_generator import TelemetryGenerator

logger = logging.getLogger(__name__)


class HistoricalDataGenerator:
    """Generates historical telemetry data for a specified time range."""

    def __init__(
        self,
        iot_client: IoTHubClient,
        config_manager: ConfigManager,
        start_date: str,
        end_date: str,
        message_count: int,
    ):
        """
        Initialize the historical data generator.

        Args:
            iot_client: IoT Hub client for sending messages
            config_manager: Configuration manager
            start_date: Start date (YYYY-MM-DD or DD.MM.YYYY)
            end_date: End date (YYYY-MM-DD or DD.MM.YYYY)
            message_count: Total number of messages to generate
        """
        self.iot_client = iot_client
        self.config_manager = config_manager
        self.telemetry_generator = TelemetryGenerator(config_manager)
        self.message_count = message_count

        # Load device schema
        device_type = config_manager.device_config.device_type
        self.device_schema = config_manager.load_schema(device_type)

        # Parse dates
        self.start_datetime = datetime.fromisoformat(start_date)
        self.end_datetime = datetime.fromisoformat(end_date)

        # Validate dates
        if self.start_datetime >= self.end_datetime:
            raise ValueError("Start date must be before end date")

        # Calculate time interval between messages if not specified
        total_seconds = (self.end_datetime - self.start_datetime).total_seconds()
        self.calculated_interval = (
            total_seconds / (message_count - 1) if message_count > 1 else 0
        )

        logger.info(
            f"Historical generator initialized: {message_count} messages "
            f"from {self.start_datetime} to {self.end_datetime}, "
            f"interval: {self.calculated_interval:.2f}s"
        )

    async def generate_and_send(self) -> None:
        """Generate and send all historical messages."""
        print(f"\n🔄 Starting to send {self.message_count} message sets...")
        print(
            f"⏱️  Interval: {self.calculated_interval:.2f} seconds between message sets"
        )
        print("📦 Each message set includes all enabled message types\n")

        sent_count = 0
        failed_count = 0
        current_time = self.start_datetime

        # Message types to generate (like regular flow)
        message_types = ["measurement", "state", "events"]
        if not message_types:
            logger.warning("No message types enabled in configuration")
            print("⚠️  No message types are enabled in configuration")
            return

        for i in range(self.message_count):
            try:
                # Historical timestamp for this iteration
                timestamp = current_time.isoformat() + "Z"

                # Generate and send all message types for this timestamp
                for message_type in message_types:
                    count = await generate_and_send_message(
                        generator=self.telemetry_generator,
                        iot_client=self.iot_client,
                        message_type=message_type,
                        device_schema=self.device_schema,
                        timestamp_override=timestamp,
                    )
                    sent_count += count

                # Increment timestamp
                current_time += timedelta(seconds=self.calculated_interval)

            except Exception as e:
                failed_count += 1
                logger.error(f"Error sending message set #{i + 1}: {e}")

            # Small delay to avoid overwhelming the client
            await asyncio.sleep(0.01)  # Batch send throttle

        print(
            f"\n✅ Completed: {sent_count} messages sent ({self.message_count} sets), {failed_count} failed"
        )
        logger.info(
            f"Historical data generation completed: {sent_count} sent, {failed_count} failed"
        )
