"""Main coordinator for device setup orchestration."""

import logging
from typing import Optional

from rich.console import Console
from rich.panel import Panel

from simulator.api import FirmwareVersionApi
from simulator.api.device_creation_metadata_api import DeviceCreationMetadataApi
from simulator.auth.oauth2_client import OAuth2Client
from simulator.auth.oauth_flow import OAuthFlow
from simulator.config.config_manager import ConfigManager, DeviceConfig
from simulator.provisioning.device_provisioner import DeviceProvisioner

from .configuration_ui import ConfigurationUI
from .device_selector import DeviceSelector


class SetupCoordinator:
    """Coordinates the complete device setup process for one or many devices."""

    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
        self.logger = logging.getLogger(__name__)
        self.console = Console()

        # Initialize OAuth2 client
        oauth2_config = config_manager.app_config.iot_platform.oauth2
        self.oauth_client = OAuth2Client(
            client_id=oauth2_config.client_id,
            authorization_endpoint=oauth2_config.authorization_endpoint,
            token_endpoint=oauth2_config.token_endpoint,
            scope=oauth2_config.scope,
            redirect_uri=oauth2_config.redirect_uri,
        )

        # Initialize platform API
        self.device_metadata_api = DeviceCreationMetadataApi(
            base_url=config_manager.app_config.iot_platform.base_url,
            oauth_client=self.oauth_client,
        )

        # Initialize Device Provisioner
        self.device_provisioner = DeviceProvisioner(
            config_manager=config_manager, oauth_client=self.oauth_client
        )

        # Initialize Firmware Version API
        self.firmware_version_api = FirmwareVersionApi(
            oauth_client=self.oauth_client, config_manager=config_manager
        )

        # Initialize UI components
        self.oauth_flow = OAuthFlow(self.oauth_client, self.console)
        self.device_selector = DeviceSelector(self.console)
        self.configuration_ui = ConfigurationUI(
            config_manager=config_manager,
            device_metadata_api=self.device_metadata_api,
            device_provisioner=self.device_provisioner,
            device_selector=self.device_selector,
            firmware_version_api=self.firmware_version_api,
            console=self.console,
        )

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def run_multi_device_setup(
        self, device_ids: Optional[list[str]] = None
    ) -> list[DeviceConfig]:
        """Set up one or more devices and return their :class:`DeviceConfig` list.

        Flow
        ----
        1. Authenticate once via OAuth.
        2. Resolve the list of device IDs:
           - If *device_ids* is supplied, use that list.
           - Otherwise ask the user to enter IDs interactively.
        3. For every device ID:
           - If it already appears in the saved config file → reuse it.
           - Otherwise → provision it (full setup UI) and persist the new config.
        4. Return the complete list of :class:`DeviceConfig` objects.
        """
        self._show_welcome_message()

        try:
            # Step 1: Authenticate once
            await self.oauth_flow.authenticate()

            # Step 2: Resolve device IDs
            if device_ids is None:
                device_ids = self._collect_device_ids_interactively()

            # Step 3: Load already-saved configs for quick lookup
            existing_configs = self._load_saved_configs()

            # Step 4: Ensure every device is configured
            final_configs: list[DeviceConfig] = []
            for device_id in device_ids:
                cfg = await self._ensure_device_configured(device_id, existing_configs)
                final_configs.append(cfg)

            # Step 5: Persist the (possibly updated) full list
            self.config_manager.save_device_configs(final_configs)

            self._show_success_message(final_configs)
            return final_configs

        except Exception as e:
            self.logger.error(f"Setup failed: {e}")
            self.console.print(f"[bold red]❌ Setup failed: {e}[/bold red]")
            raise

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _collect_device_ids_interactively(self) -> list[str]:
        """Ask the user to enter device IDs one by one until done."""
        self.console.print("\n[bold]Step 2: Device IDs[/bold]")
        return self.device_selector.get_multiple_device_ids()

    def _load_saved_configs(self) -> list[DeviceConfig]:
        """Return already-persisted device configs (empty list if none saved yet)."""
        if self.config_manager.has_device_configs():
            return self.config_manager.load_device_configs()
        return []

    def _find_existing_config(
        self, device_id: str, existing_configs: list[DeviceConfig]
    ) -> Optional[DeviceConfig]:
        """Return the saved :class:`DeviceConfig` for *device_id*, or ``None``."""
        for cfg in existing_configs:
            if cfg.device_id == device_id:
                return cfg
        return None

    def _is_device_provisioned(self, device_id: str) -> bool:
        """Return True if X.509 certificates already exist for *device_id*."""
        return self.device_provisioner.has_certificates(device_id)

    async def _ensure_device_configured(
        self, device_id: str, existing_configs: list[DeviceConfig]
    ) -> DeviceConfig:
        """Return the :class:`DeviceConfig` for *device_id*.

        Decision tree
        ~~~~~~~~~~~~~
        * Saved config exists         → reuse without re-provisioning.
        * No saved config + certs exist  → treat as already provisioned but
          unknown config → run full setup (certs overwritten with
          ``override_if_exists=True``).
        * No saved config + no certs  → run full setup and provision.
        """
        existing = self._find_existing_config(device_id, existing_configs)
        if existing is not None:
            self.console.print(
                f"[green]✅ Using existing config for device '{device_id}'[/green]"
            )
            return existing

        if self._is_device_provisioned(device_id):
            self.console.print(
                f"[yellow]⚠️  Device '{device_id}' has certificates but no saved config. "
                "Running setup to (re-)register configuration…[/yellow]"
            )
        else:
            self.console.print(
                f"[blue]🔧 Device '{device_id}' not found – provisioning…[/blue]"
            )

        return await self._run_full_setup_for_device(device_id)

    async def _run_full_setup_for_device(self, device_id: str) -> DeviceConfig:
        """Run the full configuration UI flow for a single device and return its config."""
        device_config = await self.configuration_ui.setup_device(device_id)
        return device_config

    def _show_welcome_message(self) -> None:
        """Display welcome message."""
        self.console.print(
            Panel.fit(
                "[bold blue]Device Simulator Setup[/bold blue]\n"
                "Welcome to the Device Simulator configuration wizard.",
                title="🚀 Setup Wizard",
            )
        )

    def _show_success_message(self, configs: list[DeviceConfig]) -> None:
        """Display success message listing all configured devices."""
        device_list = "\n".join(f"  • {c.device_id}" for c in configs)
        self.console.print(
            Panel.fit(
                f"[bold green]✅ Setup completed successfully![/bold green]\n"
                f"{len(configs)} device(s) ready to simulate:\n{device_list}",
                title="🎉 Success",
            )
        )
