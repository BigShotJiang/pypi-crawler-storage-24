class IDevice:
    pass