class IStore:
    pass