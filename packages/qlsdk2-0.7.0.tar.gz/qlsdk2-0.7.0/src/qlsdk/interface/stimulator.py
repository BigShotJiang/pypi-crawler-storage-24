class IStimulator:
    pass