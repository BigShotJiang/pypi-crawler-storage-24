import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import uvicorn
from amsdal.contrib.auth.errors import AuthenticationError
from amsdal_models.errors import AmsdalValidationError
from amsdal_utils.config.manager import AmsdalConfigManager
from amsdal_utils.events import EventBus
from fastapi import Depends
from fastapi import FastAPI
from fastapi import responses
from fastapi.security.api_key import APIKeyHeader
from pydantic import ValidationError

from amsdal_server.apps.classes.errors import ClassNotFoundError
from amsdal_server.apps.classes.errors import TransactionNotFoundError
from amsdal_server.apps.common.error_handlers.authorization_error import authorization_error_handler
from amsdal_server.apps.common.error_handlers.class_not_found import class_not_found_handler
from amsdal_server.apps.common.error_handlers.invalid_auth import auth_error_handler
from amsdal_server.apps.common.error_handlers.validation_error_handler import validation_error_handler
from amsdal_server.apps.common.error_handlers.validation_error_handler import value_error_handler
from amsdal_server.apps.common.errors import AmsdalAuthorizationError
from amsdal_server.apps.common.errors import AmsdalTransactionError
from amsdal_server.apps.common.event_utils import emit_event
from amsdal_server.apps.common.events import ServerShutdownContext
from amsdal_server.apps.common.events import ServerShutdownEvent
from amsdal_server.apps.common.events import ServerStartupContext
from amsdal_server.apps.common.events import ServerStartupEvent
from amsdal_server.apps.common.middlewares.utils import init_middlewares
from amsdal_server.apps.common.otel import setting_otlp
from amsdal_server.apps.common.utils import async_build_missing_models
from amsdal_server.apps.common.utils import build_missing_models
from amsdal_server.apps.router import init_routers
from amsdal_server.configs.constants import APP_DESCRIPTION

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    from amsdal_server.apps.common.thumbnail import memory
    from amsdal_server.configs.main import settings

    async_mode = AmsdalConfigManager().get_config().async_mode

    startup_context = ServerStartupContext(app=app)
    await emit_event(ServerStartupEvent, startup_context)

    memory.reduce_size(
        bytes_limit=settings.THUMBNAIL_CACHE_BITES_LIMIT,
        age_limit=settings.THUMBNAIL_CACHE_AGE_LIMIT,
    )

    if async_mode:
        missed_models = await async_build_missing_models()
    else:
        missed_models = build_missing_models()

    if missed_models:
        logger.warning(f'Missed models: {", ".join(missed_models)}')

    yield

    shutdown_context = ServerShutdownContext(app=app)
    await emit_event(ServerShutdownEvent, shutdown_context)


def build_app() -> FastAPI:
    from amsdal_server.apps.common.events.server import MiddlewareSetupContext
    from amsdal_server.apps.common.events.server import MiddlewareSetupEvent
    from amsdal_server.apps.common.events.server import RouterSetupContext
    from amsdal_server.apps.common.events.server import RouterSetupEvent
    from amsdal_server.configs.main import settings

    # Create FastAPI application
    app = FastAPI(
        debug=settings.DEBUG,
        title=settings.APP_NAME,
        description=APP_DESCRIPTION,
        docs_url='/docs' if settings.IS_DOCS_ENABLED else None,
        default_response_class=responses.ORJSONResponse,
        lifespan=lifespan,
        dependencies=[
            Depends(
                APIKeyHeader(
                    name=settings.AUTHORIZATION_HEADER,
                    auto_error=False,
                    scheme_name='AmsdalAuth',
                )
            )
        ],
    )

    # Register standard application routes from INSTALLED_APPS
    init_routers(app)

    # Emit RouterSetupEvent to allow plugins to add custom routes
    # Note: Always emitted synchronously as we're not in async context yet
    router_context = RouterSetupContext(app=app)
    EventBus.emit(RouterSetupEvent, router_context)

    # Initialize middlewares
    init_middlewares(app)

    # Emit MiddlewareSetupEvent to allow plugins to add custom middlewares
    middleware_context = MiddlewareSetupContext(app=app)
    EventBus.emit(MiddlewareSetupEvent, middleware_context)

    # Setup OTLP if configured
    if settings.OTLP_ENDPOINT:
        setting_otlp(app, settings.APP_NAME, settings.OTLP_ENDPOINT)

    # Register exception handlers
    app.exception_handler(ValidationError)(validation_error_handler)
    app.exception_handler(ValueError)(value_error_handler)
    app.exception_handler(AmsdalTransactionError)(value_error_handler)
    app.exception_handler(AmsdalValidationError)(value_error_handler)
    app.exception_handler(ClassNotFoundError)(class_not_found_handler)
    app.exception_handler(TransactionNotFoundError)(class_not_found_handler)
    app.exception_handler(AuthenticationError)(auth_error_handler)
    app.exception_handler(AmsdalAuthorizationError)(authorization_error_handler)

    return app


def start(
    *,
    port: int | None = None,
    host: str | None = None,
    **kwargs: Any,
) -> None:
    """Start the AMSDAL server.

    This function creates and configures the FastAPI application, registers routes,
    emits setup events, and starts the uvicorn server.

    For production deployment, use: amsdal serve --host 0.0.0.0 --port 8000
    For development with auto-reload, use: amsdal serve --auto-reload

    Note: Direct uvicorn access (uvicorn amsdal_server.server:app) is not supported
    as it bypasses AMSDAL initialization and user app loading.
    """
    from amsdal_server.configs.main import settings

    # Start the server
    uvicorn.run(
        build_app(),
        host=host or settings.HOST,
        port=port or settings.PORT,
        # We already log in LoggerMiddleware
        # no need to duplicate these logs with uvicorn
        access_log=False,
        **kwargs,
    )


if __name__ == '__main__':
    start()
