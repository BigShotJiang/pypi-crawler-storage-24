## [v0.8.1](https://pypi.org/project/amsdal_server/0.8.1/) - 2026-03-19

### Changed

- Enhance transaction API with scope filtering and add description field to transaction items
