# src/orgo/__init__.py
"""Orgo SDK: Desktop infrastructure for AI agents"""

from .project import Project
from .computer import Computer
from .template import Template

# Aliases
Workspace = Project  # Workspace is an alias for Project
Forge = Template     # Forge is deprecated, use Template instead

__all__ = ["Project", "Workspace", "Computer", "Template", "Forge"]
