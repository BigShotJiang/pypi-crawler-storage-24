#
# SPDX-License-Identifier: BSD-2-Clause
# SPDX-FileCopyrightText: Copyright (c) 2026 -- Lars Heuer
#
"""\
Pygments lexer for scfg.
"""
from pygments.lexer import RegexLexer, bygroups
from pygments.token import Whitespace, Punctuation, Name, Comment, String

__all__ = ['ScfgLexer']

__version__ = '0.1.0'


class ScfgLexer(RegexLexer):
    """\
    `scfg` is a simple configuration file format.
    """
    name = 'scfg'
    url = 'https://codeberg.org/emersion/scfg'
    aliases = ['scfg']
    filenames = ['*.scfg']
    tokens = {
        'root': [
            (r'^(\s*)(#.+)(\n)', bygroups(Whitespace, Comment.Single, Whitespace)),
            (r'\s+', Whitespace),
            (r'\}', Punctuation),
            (r'"(?:[^"\\]|\\.)*"', Name.Tag, 'params'),
            (r"'(?:[^'\\]|\\.)*'", Name.Tag, 'params'),
            (r'(?:[^\s\\]|\\.)+',  Name.Tag, 'params'),
        ],
        'params': [
            (r'\n', Whitespace, '#pop'),
            (r'\{', Punctuation),
            (r'"(?:[^"\\]|\\.)*"', String.Double),
            (r"'(?:[^'\\]|\\.)*'", String.Single),
            (r'(?:[^\s\\]|\\.)+',  Name.Attribute),
            (r'\s+', Whitespace),
        ]
    }

