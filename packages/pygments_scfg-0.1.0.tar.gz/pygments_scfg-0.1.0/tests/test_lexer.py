#
# SPDX-License-Identifier: BSD-2-Clause
# SPDX-FileCopyrightText: Copyright (c) 2026 -- Lars Heuer
#
"""\
Tests against the lexer.
"""
from pygments.lexers import get_lexer_for_filename, find_lexer_class_by_name
from pygments.token import Whitespace, Punctuation, Name, Comment, String
from pygments_scfg import ScfgLexer


WS = Whitespace
Param = Name.Attribute
Name = Name.Tag
Comment = Comment.Single


def test_by_filename():
    lexer = get_lexer_for_filename('test.scfg')
    assert isinstance(lexer, ScfgLexer)


def test_by_alias():
    lexer = find_lexer_class_by_name('scfg')
    assert lexer is ScfgLexer


def _tokens(s):
    lexer = ScfgLexer()
    res = tuple(t for t, v in lexer.get_tokens(s))
    if res[-1] == WS:
        return res[:-1]
    return res


def test_simple():
    s = """test"""
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_comment():
    s = "# comment"
    tokens = (Comment,)
    assert tokens == _tokens(s)


def test_comment_indent():
    s = "                    # comment"
    tokens = (WS, Comment)
    assert tokens == _tokens(s)


def test_param():
    s = "name param"
    tokens = (Name, WS, Param)
    assert tokens == _tokens(s)


def test_param_multiple():
    s = "name param 'param2' another-param"
    tokens = (Name, WS, Param, WS, String.Single, WS, Param)
    assert tokens == _tokens(s)


def test_param_hash():
    s = "name #param"
    tokens = (Name, WS, Param)
    assert tokens == _tokens(s)


def test_block():
    s = """name param {
x 123
}
"""
    tokens = (Name, WS, Param, WS, Punctuation, WS, Name, WS, Param, WS, Punctuation)
    assert tokens == _tokens(s)


def test_block_string_val_single():
    s = """name param {
x '123'
}
"""
    tokens = (Name, WS, Param, WS, Punctuation, WS, Name, WS, String.Single, WS, Punctuation)
    assert tokens == _tokens(s)


def test_block_string_val_double():
    s = """name param {
x "123"
}
"""
    tokens = (Name, WS, Param, WS, Punctuation, WS, Name, WS, String.Double, WS, Punctuation)
    assert tokens == _tokens(s)


def test_string_single_quote():
    s = "name 'param'"
    tokens = (Name, WS, String.Single)
    assert tokens == _tokens(s)


def test_string_double_quote():
    s = 'name "param"'
    tokens = (Name, WS, String.Double)
    assert tokens == _tokens(s)


def test_name_double_quotes():
    s = '"name"'
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_name_double_quotes_ws():
    s = '"name here"'
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_name_single_quotes():
    s = "'name'"
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_name_single_quotes_ws():
    s = "'name here'"
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_escaped_name():
    s = r'dir\ ecti\"v\'e\{'
    tokens = (Name,)
    assert tokens == _tokens(s)


def test_comment_in_block():
    s = """parent {
    # comment
    child
}
    """
    tokens = (Name, WS, Punctuation, WS, WS, Comment, WS, WS, Name, WS, Punctuation)
    assert tokens == _tokens(s)


def test_curly_brace_names():
    s = '''"{" {
"}" {
}
}'''
    tokens = (Name, WS, Punctuation, WS, Name, WS, Punctuation, WS, Punctuation, WS, Punctuation)
    assert tokens == _tokens(s)


def test_curly_brace_names2():
    s = r'''\{ {
    \}
}'''
    tokens = (Name, WS, Punctuation, WS, WS, Name, WS, Punctuation)
    assert tokens == _tokens(s)


def test_curly_brace_names3():
    s = r'''\{ param1 {
}'''
    tokens = (Name, WS, Param, WS, Punctuation, WS, Punctuation)
    assert tokens == _tokens(s)


def test_hash_as_param():
    s = "directive # param2"
    tokens = (Name, WS, Param, WS, Param)
    assert tokens == _tokens(s)


def test_param_with_spaces():
    s = r"directive param\ with\ spaces"
    tokens = (Name, WS, Param)
    assert tokens == _tokens(s)


def test_unicode_name():
    s = "😳"
    tokens = (Name,)
    assert tokens == _tokens(s)

