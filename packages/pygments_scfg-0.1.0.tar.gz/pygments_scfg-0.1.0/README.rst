scfg lexer for Pygments
=======================

Pygments lexer for `scfg <https://codeberg.org/emersion/scfg>`_

