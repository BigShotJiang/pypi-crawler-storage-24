from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.collection_schema import CollectionSchema
from ...models.get_collections_response_401 import GetCollectionsResponse401
from ...models.get_collections_response_403 import GetCollectionsResponse403
from ...models.get_collections_response_404 import GetCollectionsResponse404
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["page"] = page

    params["per_page"] = per_page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/collections/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
    | None
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = CollectionSchema.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 401:
        response_401 = GetCollectionsResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = GetCollectionsResponse403.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = GetCollectionsResponse404.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
]:
    """Get list of the latest collections

    Args:
        page (int | Unset):  Example: 1.
        per_page (int | Unset):  Example: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCollectionsResponse401 | GetCollectionsResponse403 | GetCollectionsResponse404 | list[CollectionSchema]]
    """

    kwargs = _get_kwargs(
        page=page,
        per_page=per_page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> (
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
    | None
):
    """Get list of the latest collections

    Args:
        page (int | Unset):  Example: 1.
        per_page (int | Unset):  Example: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCollectionsResponse401 | GetCollectionsResponse403 | GetCollectionsResponse404 | list[CollectionSchema]
    """

    return sync_detailed(
        client=client,
        page=page,
        per_page=per_page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> Response[
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
]:
    """Get list of the latest collections

    Args:
        page (int | Unset):  Example: 1.
        per_page (int | Unset):  Example: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCollectionsResponse401 | GetCollectionsResponse403 | GetCollectionsResponse404 | list[CollectionSchema]]
    """

    kwargs = _get_kwargs(
        page=page,
        per_page=per_page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    page: int | Unset = UNSET,
    per_page: int | Unset = UNSET,
) -> (
    GetCollectionsResponse401
    | GetCollectionsResponse403
    | GetCollectionsResponse404
    | list[CollectionSchema]
    | None
):
    """Get list of the latest collections

    Args:
        page (int | Unset):  Example: 1.
        per_page (int | Unset):  Example: 30.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCollectionsResponse401 | GetCollectionsResponse403 | GetCollectionsResponse404 | list[CollectionSchema]
    """

    return (
        await asyncio_detailed(
            client=client,
            page=page,
            per_page=per_page,
        )
    ).parsed
