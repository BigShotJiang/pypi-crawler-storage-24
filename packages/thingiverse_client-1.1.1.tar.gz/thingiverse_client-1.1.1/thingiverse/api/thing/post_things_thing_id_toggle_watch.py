from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_things_thing_id_toggle_watch_response_200 import (
    PostThingsThingIdToggleWatchResponse200,
)
from ...models.post_things_thing_id_toggle_watch_response_400 import (
    PostThingsThingIdToggleWatchResponse400,
)
from ...models.post_things_thing_id_toggle_watch_response_401 import (
    PostThingsThingIdToggleWatchResponse401,
)
from ...models.post_things_thing_id_toggle_watch_response_403 import (
    PostThingsThingIdToggleWatchResponse403,
)
from ...models.post_things_thing_id_toggle_watch_response_404 import (
    PostThingsThingIdToggleWatchResponse404,
)
from ...types import Response


def _get_kwargs(
    thing_id: int,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/things/{thing_id}/toggle-watch".format(
            thing_id=quote(str(thing_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
    | None
):
    if response.status_code == 200:
        response_200 = PostThingsThingIdToggleWatchResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = PostThingsThingIdToggleWatchResponse400.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = PostThingsThingIdToggleWatchResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = PostThingsThingIdToggleWatchResponse403.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = PostThingsThingIdToggleWatchResponse404.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    thing_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
]:
    """Watch/unwatch a Thing

     If currently watching the specified Thing, the current user will unwatch the Thing, and vice versa.
    Only works in user context.

    Args:
        thing_id (int):  Example: 1004996.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostThingsThingIdToggleWatchResponse200 | PostThingsThingIdToggleWatchResponse400 | PostThingsThingIdToggleWatchResponse401 | PostThingsThingIdToggleWatchResponse403 | PostThingsThingIdToggleWatchResponse404]
    """

    kwargs = _get_kwargs(
        thing_id=thing_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    thing_id: int,
    *,
    client: AuthenticatedClient,
) -> (
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
    | None
):
    """Watch/unwatch a Thing

     If currently watching the specified Thing, the current user will unwatch the Thing, and vice versa.
    Only works in user context.

    Args:
        thing_id (int):  Example: 1004996.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostThingsThingIdToggleWatchResponse200 | PostThingsThingIdToggleWatchResponse400 | PostThingsThingIdToggleWatchResponse401 | PostThingsThingIdToggleWatchResponse403 | PostThingsThingIdToggleWatchResponse404
    """

    return sync_detailed(
        thing_id=thing_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    thing_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
]:
    """Watch/unwatch a Thing

     If currently watching the specified Thing, the current user will unwatch the Thing, and vice versa.
    Only works in user context.

    Args:
        thing_id (int):  Example: 1004996.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PostThingsThingIdToggleWatchResponse200 | PostThingsThingIdToggleWatchResponse400 | PostThingsThingIdToggleWatchResponse401 | PostThingsThingIdToggleWatchResponse403 | PostThingsThingIdToggleWatchResponse404]
    """

    kwargs = _get_kwargs(
        thing_id=thing_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    thing_id: int,
    *,
    client: AuthenticatedClient,
) -> (
    PostThingsThingIdToggleWatchResponse200
    | PostThingsThingIdToggleWatchResponse400
    | PostThingsThingIdToggleWatchResponse401
    | PostThingsThingIdToggleWatchResponse403
    | PostThingsThingIdToggleWatchResponse404
    | None
):
    """Watch/unwatch a Thing

     If currently watching the specified Thing, the current user will unwatch the Thing, and vice versa.
    Only works in user context.

    Args:
        thing_id (int):  Example: 1004996.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PostThingsThingIdToggleWatchResponse200 | PostThingsThingIdToggleWatchResponse400 | PostThingsThingIdToggleWatchResponse401 | PostThingsThingIdToggleWatchResponse403 | PostThingsThingIdToggleWatchResponse404
    """

    return (
        await asyncio_detailed(
            thing_id=thing_id,
            client=client,
        )
    ).parsed
