from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.email_schema_body import EmailSchemaBody


T = TypeVar("T", bound="EmailSchema")


@_attrs_define
class EmailSchema:
    """
    Attributes:
        body (EmailSchemaBody | Unset):
    """

    body: EmailSchemaBody | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        body: dict[str, Any] | Unset = UNSET
        if not isinstance(self.body, Unset):
            body = self.body.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if body is not UNSET:
            field_dict["body"] = body

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.email_schema_body import EmailSchemaBody

        d = dict(src_dict)
        _body = d.pop("body", UNSET)
        body: EmailSchemaBody | Unset
        if isinstance(_body, Unset):
            body = UNSET
        else:
            body = EmailSchemaBody.from_dict(_body)

        email_schema = cls(
            body=body,
        )

        email_schema.additional_properties = d
        return email_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
