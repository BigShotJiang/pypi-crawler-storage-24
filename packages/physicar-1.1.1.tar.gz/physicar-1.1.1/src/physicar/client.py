from typing import Optional

import httpx

from .chat import ChatAPI
from .auth import AuthAPI
from .exceptions import PhysicarError, AuthenticationError, CreditError, NotFoundError

BASE_URL = "https://api.physicar.ai"


class PhysicarClient:
    def __init__(
        self,
        email: Optional[str] = None,
        password: Optional[str] = None,
        *,
        token: Optional[str] = None,
        base_url: str = BASE_URL,
    ):
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(timeout=30.0)
        self._token: Optional[str] = None

        if token:
            self._token = token
        elif email and password:
            self._login(email, password)
        else:
            raise ValueError("Provide either (email, password) or token")

        self.chat = ChatAPI(self)
        self.auth = AuthAPI(self)

    def _login(self, email: str, password: str):
        resp = self._http.post(
            f"{self._base_url}/auth/login",
            json={"email": email, "password": password},
            headers={"Content-Type": "application/json"},
        )
        if resp.status_code != 200:
            data = resp.json()
            raise AuthenticationError(
                data.get("error", "Login failed"),
                status_code=resp.status_code,
                code=data.get("code"),
            )
        data = resp.json()
        self._token = data["token"]

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def _request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._http.request(
            method,
            f"{self._base_url}{path}",
            headers=self._headers(),
            **kwargs,
        )
        self._handle_error(resp)
        return resp.json()

    @staticmethod
    def _handle_error(resp: httpx.Response):
        if resp.status_code < 400:
            return
        try:
            data = resp.json()
        except Exception:
            raise PhysicarError(resp.text, status_code=resp.status_code)
        msg = data.get("error", resp.text)
        code = data.get("code")
        if resp.status_code == 401:
            raise AuthenticationError(msg, status_code=resp.status_code, code=code)
        elif resp.status_code == 402:
            raise CreditError(msg, status_code=resp.status_code, code=code)
        elif resp.status_code == 404:
            raise NotFoundError(msg, status_code=resp.status_code, code=code)
        else:
            raise PhysicarError(msg, status_code=resp.status_code, code=code)

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
