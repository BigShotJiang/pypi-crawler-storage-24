from ..types import User


class AuthAPI:
    def __init__(self, client):
        self._client = client

    def me(self) -> User:
        data = self._client._request("GET", "/auth/me")
        u = data["user"]
        return User(
            user_id=u["user_id"],
            email=u["email"],
            display_name=u.get("display_name"),
            email_verified=u.get("email_verified"),
            role=u.get("role"),
            created_at=u.get("created_at"),
        )

    def logout(self) -> dict:
        return self._client._request("POST", "/auth/logout")

    def change_password(self, current_password: str, new_password: str) -> dict:
        return self._client._request("PUT", "/auth/password", json={
            "current_password": current_password,
            "new_password": new_password,
        })

    def update_profile(self, **kwargs) -> dict:
        return self._client._request("PUT", "/auth/profile", json=kwargs)
