class PhysicarError(Exception):
    def __init__(self, message: str, status_code: int = None, code: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class AuthenticationError(PhysicarError):
    pass


class CreditError(PhysicarError):
    pass


class NotFoundError(PhysicarError):
    pass
