from typing import Optional

from ..types import Prompt


class PromptAPI:
    def __init__(self, client):
        self._client = client

    def create(self, prompt: Prompt, *, id: Optional[str] = None) -> dict:
        body = prompt.to_dict()
        if id:
            body["id"] = id
        return self._client._request("POST", "/chat/prompt", json=body)

    def get(self, prompt_id: str) -> dict:
        return self._client._request("GET", f"/chat/prompt/{prompt_id}")

    def list(self) -> dict:
        return self._client._request("GET", "/chat/prompt")

    def update(self, prompt_id: str, **kwargs) -> dict:
        return self._client._request("PUT", f"/chat/prompt/{prompt_id}", json=kwargs)

    def delete(self, prompt_id: str) -> dict:
        return self._client._request("DELETE", f"/chat/prompt/{prompt_id}")
