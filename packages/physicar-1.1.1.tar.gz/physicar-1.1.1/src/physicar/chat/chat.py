import json
from typing import Optional, Iterator, Dict, Any

from ..types import (
    UserMessage, ChatResponse, StreamEvent, ToolCall, Prompt,
)
from .prompt import PromptAPI


class ChatAPI:
    def __init__(self, client):
        self._client = client
        self.prompt = PromptAPI(client)

    def __call__(
        self,
        user_message: UserMessage,
        *,
        prompt_id: Optional[str] = None,
        prompt: Optional[Prompt] = None,
        stream: bool = False,
        audio: bool = False,
        chat_id: Optional[str] = None,
        turn: Optional[int] = None,
    ):
        body: Dict[str, Any] = {
            "user_message": user_message.to_dict(),
            "stream": stream,
            "audio": audio,
        }
        if prompt_id:
            body["prompt_id"] = prompt_id
        if prompt:
            body["prompt"] = prompt.to_dict()
        if chat_id:
            body["chat_id"] = chat_id
        if turn is not None:
            body["turn"] = turn

        if stream:
            return self._stream(body)
        else:
            data = self._client._request("POST", "/chat", json=body)
            return ChatResponse.from_dict(data)

    def _stream(self, body: dict) -> Iterator[StreamEvent]:
        with self._client._http.stream(
            "POST",
            f"{self._client._base_url}/chat",
            json=body,
            headers=self._client._headers(),
            timeout=120.0,
        ) as response:
            if response.status_code != 200:
                response.read()
                self._client._handle_error(response)

            buffer = ""
            chat_id = None
            turn = None

            for chunk in response.iter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    event_str, buffer = buffer.split("\n\n", 1)
                    for line in event_str.strip().split("\n"):
                        if line.startswith("data: "):
                            data_str = line[6:]
                            try:
                                event_data = json.loads(data_str)
                            except json.JSONDecodeError:
                                continue

                            event_type = event_data.get("type", "")

                            if event_type == "text":
                                yield StreamEvent(type="text", content=event_data.get("content"))
                            elif event_type == "tool_call":
                                yield StreamEvent(
                                    type="tool_call",
                                    call_id=event_data.get("call_id"),
                                    name=event_data.get("name"),
                                    arguments=event_data.get("arguments"),
                                )
                            elif event_type == "done":
                                tc = [
                                    ToolCall(call_id=t["call_id"], name=t["name"], arguments=t["arguments"])
                                    for t in event_data.get("tool_calls", [])
                                ]
                                chat_id = event_data.get("chat_id", chat_id)
                                turn = event_data.get("turn", turn)
                                yield StreamEvent(
                                    type="done",
                                    usage=event_data.get("usage"),
                                    full_text=event_data.get("full_text"),
                                    tool_calls=tc,
                                    chat_id=chat_id,
                                    turn=turn,
                                )
                            elif event_type == "context":
                                chat_id = event_data.get("chat_id", chat_id)
                                turn = event_data.get("turn", turn)
