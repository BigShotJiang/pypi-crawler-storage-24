# ============ 구버전 postAttach.sh 호환============
import os
from pathlib import Path
_postattach = Path.home() / "scripts" / "postAttach.sh"
_cmd = "(env | grep -E '^(VSCODE_|BROWSER=|PATH=)' > /tmp/vscode-env)&"
if _postattach.exists() and _cmd not in _postattach.read_text():
    with open(_postattach, "a") as f:
        f.write(f"\n{_cmd}\n")
del _postattach, _cmd
# ================================================================

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional
import asyncio
import hashlib
import io
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import yaml
import json
from fastapi import FastAPI, Request, Response, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse, HTMLResponse, RedirectResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
import aiohttp

# 설정
from physicar.codespaces.deepracer.config import (
    SECRET_KEY,
    TRACKS_INFO_PATH, CUSTOM_TRACKS_INFO_PATH,
    SIMAPP_MOUNT_DIR, SIMAPP_SHARE_DIR,
    USER_INPUT_LIMITS, 
    get_max_sub_simulation_count,
    STREAM_QUALITY,
)

# 스키마
from physicar.codespaces.deepracer import schemas
from physicar.codespaces.deepracer.schemas import CreateModelRequest, CloneModelRequest

# 파일 생성
from physicar.codespaces.deepracer.drfc_writer import create_model_files, validate_model_name_available

# 작업 관리
from physicar.codespaces.deepracer import jobs

# 경로 설정
BASE_DIR = Path(__file__).parent
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

# MinIO 설정
MINIO_ENDPOINT = "localhost:9000"
MINIO_ACCESS_KEY = "physicar"
MINIO_SECRET_KEY = "physicar"
MINIO_BUCKET = "bucket"


def _get_minio_client():
    """MinIO 클라이언트 생성"""
    from minio import Minio
    return Minio(MINIO_ENDPOINT, access_key=MINIO_ACCESS_KEY, secret_key=MINIO_SECRET_KEY, secure=False)


def minio_object_exists(key: str) -> bool:
    """MinIO에서 객체 존재 여부 확인"""
    try:
        client = _get_minio_client()
        client.stat_object(MINIO_BUCKET, key)
        return True
    except Exception:
        return False


def minio_prefix_exists(prefix: str) -> bool:
    """MinIO에서 prefix로 시작하는 객체가 있는지 확인"""
    try:
        client = _get_minio_client()
        # list_objects는 iterator 반환, 첫 번째 항목만 확인
        for _ in client.list_objects(MINIO_BUCKET, prefix=prefix, recursive=False):
            return True
        return False
    except Exception:
        return False


def minio_read_text(key: str) -> Optional[str]:
    """MinIO에서 텍스트 파일 읽기"""
    try:
        client = _get_minio_client()
        response = client.get_object(MINIO_BUCKET, key)
        content = response.read().decode('utf-8')
        response.close()
        response.release_conn()
        return content
    except Exception:
        return None


def minio_read_json(key: str) -> Optional[dict]:
    """MinIO에서 JSON 파일 읽기"""
    content = minio_read_text(key)
    if content is None:
        return None
    try:
        return json.loads(content)
    except Exception:
        return None


def minio_read_yaml(key: str) -> Optional[dict]:
    """MinIO에서 YAML 파일 읽기"""
    content = minio_read_text(key)
    if content is None:
        return None
    try:
        return yaml.safe_load(content)
    except Exception:
        return None

# static 폴더 없으면 생성
STATIC_DIR.mkdir(exist_ok=True)

# aiohttp 세션
http_session: aiohttp.ClientSession = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global http_session
    timeout = aiohttp.ClientTimeout(total=None, connect=5)
    http_session = aiohttp.ClientSession(timeout=timeout)
    
    # MinIO 모니터 시작
    from physicar.codespaces.deepracer.settings_manager import start_minio_monitor, stop_minio_monitor
    await start_minio_monitor()
    
    # 백그라운드 훈련 모니터 시작
    from physicar.codespaces.deepracer.jobs import start_monitor, stop_monitor
    start_monitor()
    
    yield
    
    # 정리
    stop_monitor()
    stop_minio_monitor()
    await http_session.close()

app = FastAPI(lifespan=lifespan, redirect_slashes=False)

# Session Middleware (쿠키 기반 세션)
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

# Static files & Templates
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATES_DIR)


# ============ Helper Functions ============

def get_common_context(request: Request) -> dict:
    """모든 페이지에 공통으로 전달할 컨텍스트"""
    from physicar import __version__
    return {
        "request": request,
        "version": __version__,  # 캐시 버스팅용
        "codespace_name": os.environ.get("CODESPACE_NAME", ""),
    }


# ============ Utility Functions ============


def get_base_url(request: Request) -> str:
    """현재 요청에서 base URL 추출 (Codespaces 대응)"""
    # X-Forwarded-Host 헤더 확인 (프록시 환경)
    forwarded_host = request.headers.get("x-forwarded-host")
    forwarded_proto = request.headers.get("x-forwarded-proto", "https")
    
    if forwarded_host:
        return f"{forwarded_proto}://{forwarded_host}"
    
    # 일반 환경
    return str(request.base_url).rstrip("/")


def _load_vscode_env() -> dict:
    """postAttach.sh에서 저장한 VS Code 환경변수 로드"""
    env = os.environ.copy()
    vscode_env_file = Path("/tmp/vscode-env")
    if vscode_env_file.exists():
        for line in vscode_env_file.read_text().splitlines():
            if "=" in line:
                key, _, value = line.partition("=")
                env[key] = value
    return env


@app.post("/api/open-url", name="api_open_url")
async def api_open_url(request: Request):
    """호스트 브라우저에서 URL 열기 (Codespace/iframe용)"""
    try:
        body = await request.json()
        url = body.get("url")
        if not url:
            return JSONResponse({"success": False, "error": "URL required"}, status_code=400)
        
        # 보안: 허용된 도메인만
        allowed_domains = ["github.com"]
        from urllib.parse import urlparse
        parsed = urlparse(url)
        if not any(parsed.netloc.endswith(d) for d in allowed_domains):
            return JSONResponse({"success": False, "error": "Domain not allowed"}, status_code=400)
        
        env = _load_vscode_env()
        browser = env.get("BROWSER")
        
        if not browser or not os.path.exists(browser):
            return JSONResponse({"success": False, "error": "Browser not available"}, status_code=400)
        
        subprocess.Popen([browser, url], env=env)
        return JSONResponse({"success": True, "message": "Browser opened"})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=500)


# ============ Pages ============

@app.get("/", name="home")
async def home(request: Request):
    """Home page - 바로 Models 페이지로 리다이렉트"""
    return RedirectResponse(url="/pages/models/list", status_code=302)


@app.get("/pages/{name:path}", response_class=HTMLResponse, name="pages")
async def pages(request: Request, name: str):
    """Dynamic page routing"""
    # 협력자 체크는 프론트엔드에서 (_base.html의 폴링)
    
    template_path = f"pages/{name}.html"
    context = get_common_context(request)
    
    # 페이지별 제목 매핑
    page_titles = {
        "storage": "Uploaded Models",
        "tracks": "Tracks",
    }
    title = page_titles.get(name, name.replace("_", " ").title())
    
    context.update({
        "title": title,
        "user": None,
        "current_page": name,
    })
    
    # tracks 페이지 전용 컨텍스트
    if name == "tracks":
        if TRACKS_INFO_PATH.exists():
            with open(TRACKS_INFO_PATH, "r") as f:
                tracks_info = yaml.safe_load(f) or {}
        else:
            tracks_info = {}
        context.update({
            "tracks_info": tracks_info,
            "custom_tracks_info": _load_custom_tracks_info(),
        })
    
    # models/create 페이지 전용 컨텍스트
    if name == "models/create":
        # tracks_info 로드
        if TRACKS_INFO_PATH.exists():
            with open(TRACKS_INFO_PATH, "r") as f:
                tracks_info = yaml.safe_load(f) or {}
        else:
            tracks_info = {}
        
        context.update({
            "tracks_info": tracks_info,
            "custom_tracks_info": _load_custom_tracks_info(),
            "max_sub_simulation_count": get_max_sub_simulation_count(),
        })
    
    # models/clone 페이지 전용 컨텍스트 (모델 복제)
    if name == "models/clone":
        from physicar.codespaces.deepracer.settings_manager import is_model_clonable
        from physicar.codespaces.deepracer.jobs import active_jobs
        
        pretrained_model_name = request.query_params.get("model_name", "")
        
        # model_name 파라미터 필수 체크
        if not pretrained_model_name:
            raise HTTPException(status_code=400, detail="model_name query parameter is required")
        
        # Clone 가능 여부 확인 (존재 + 상태 + 체크포인트)
        clonable, reason = is_model_clonable(pretrained_model_name, active_jobs)
        if not clonable:
            raise HTTPException(status_code=400, detail=reason)
        
        # tracks_info 로드 (create와 동일)
        if TRACKS_INFO_PATH.exists():
            with open(TRACKS_INFO_PATH, "r") as f:
                tracks_info = yaml.safe_load(f) or {}
        else:
            tracks_info = {}
        
        context.update({
            "tracks_info": tracks_info,
            "custom_tracks_info": _load_custom_tracks_info(),
            "max_sub_simulation_count": get_max_sub_simulation_count(),
            "pretrained_model_name": pretrained_model_name,
            "is_clone": True,
            "title": f"Clone Model - {pretrained_model_name}",
        })
    
    # models/model 페이지 전용 컨텍스트 (모델 상세/모니터링)
    if name == "models/model":
        model_name = request.query_params.get("model_name", "")
        context.update({
            "model_name": model_name,
            "title": model_name or "Model",
        })
    
    # models/evaluation 페이지 전용 컨텍스트 (평가 시작)
    if name == "models/evaluation":
        from physicar.codespaces.deepracer.settings_manager import get_model_status, get_model_main_simulation_config
        
        model_name = request.query_params.get("model_name", "")
        
        # model_name 파라미터 필수 체크
        if not model_name:
            raise HTTPException(status_code=400, detail="model_name query parameter is required")
        
        # 모델 상태 확인 - ready 상태만 평가 가능
        model_status = get_model_status(model_name)
        if model_status != "ready":
            raise HTTPException(
                status_code=400, 
                detail=f"Model '{model_name}' is not ready for evaluation. Current status: {model_status}"
            )
        
        # tracks_info 로드
        if TRACKS_INFO_PATH.exists():
            with open(TRACKS_INFO_PATH, "r") as f:
                tracks_info = yaml.safe_load(f) or {}
        else:
            tracks_info = {}
        
        # 모델의 main 시뮬레이션 설정 가져오기 (기본값으로 사용)
        main_sim_config = get_model_main_simulation_config(model_name)
        
        context.update({
            "model_name": model_name,
            "tracks_info": tracks_info,
            "custom_tracks_info": _load_custom_tracks_info(),
            "main_simulation": main_sim_config,
            "title": f"Evaluate Model - {model_name}",
        })
    
    return templates.TemplateResponse(template_path, context)


# ============ API Endpoints ============

@app.get("/api/tracks", name="api_tracks")
async def api_tracks():
    """트랙 목록 API (공식 + 커스텀)"""
    # 공식 트랙
    if TRACKS_INFO_PATH.exists():
        with open(TRACKS_INFO_PATH, "r") as f:
            official_info = yaml.safe_load(f) or {}
    else:
        official_info = {}
    
    official = []
    for track_id, info in official_info.items():
        official.append({
            "id": track_id,
            "length": info.get("track_length"),
            "width": info.get("track_width"),
            "thumbnail": f"/static/tracks/thumbnail/{track_id}.svg",
            "custom": False,
        })
    
    # 커스텀 트랙
    custom = _get_custom_tracks_list()
    
    return JSONResponse({"tracks": official, "custom_tracks": custom})


def _load_custom_tracks_info() -> dict:
    """커스텀 트랙 정보 로드"""
    if CUSTOM_TRACKS_INFO_PATH.exists():
        with open(CUSTOM_TRACKS_INFO_PATH, "r") as f:
            return yaml.safe_load(f) or {}
    return {}


def _save_custom_tracks_info(data: dict):
    """커스텀 트랙 정보 저장"""
    CUSTOM_TRACKS_INFO_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CUSTOM_TRACKS_INFO_PATH, "w") as f:
        yaml.dump(data, f, default_flow_style=False)


def _get_custom_tracks_list() -> list:
    """커스텀 트랙 목록 반환"""
    custom_info = _load_custom_tracks_info()
    tracks = []
    for track_id, info in custom_info.items():
        tracks.append({
            "id": track_id,
            "length": info.get("track_length"),
            "width": info.get("track_width"),
            "thumbnail": f"/api/tracks/custom/{track_id}/thumbnail",
            "custom": True,
        })
    return tracks


@app.get("/api/tracks/custom", name="api_custom_tracks")
async def api_custom_tracks():
    """커스텀 트랙 목록 API"""
    return JSONResponse({"custom_tracks": _get_custom_tracks_list()})


@app.post("/api/tracks/custom/upload", name="api_custom_track_upload")
async def api_custom_track_upload(file: UploadFile = File(...)):
    """커스텀 트랙 업로드 API (tar.gz)"""
    if not file.filename or not file.filename.endswith(".tar.gz"):
        raise HTTPException(status_code=400, detail="Only .tar.gz files are accepted")
    
    # 파일 크기 제한 (100MB)
    contents = await file.read()
    if len(contents) > 100 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 100MB)")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        tar_path = Path(tmpdir) / file.filename
        tar_path.write_bytes(contents)
        
        # tar.gz 추출
        try:
            with tarfile.open(tar_path, "r:gz") as tar:
                # 보안: path traversal 방지
                for member in tar.getmembers():
                    if member.name.startswith("/") or ".." in member.name:
                        raise HTTPException(status_code=400, detail=f"Invalid path in archive: {member.name}")
                tar.extractall(tmpdir, filter="data")
        except tarfile.TarError:
            raise HTTPException(status_code=400, detail="Invalid tar.gz file")
        
        extract_dir = Path(tmpdir)
        
        # 루트 디렉토리 탐지 (routes/*.npy 기반)
        root_dir = _find_track_root(extract_dir)
        if root_dir is None:
            raise HTTPException(status_code=400, detail="No route file (.npy) found in archive")
        
        # npy에서 트랙 이름 추출
        npy_files = list((root_dir / "routes").glob("*.npy"))
        if not npy_files:
            raise HTTPException(status_code=400, detail="No route file (.npy) found in archive")
        
        track_name = npy_files[0].stem
        
        # 필수 파일 검증
        missing = []
        required_checks = [
            ("routes", f"{track_name}.npy"),
            ("worlds", f"{track_name}.world"),
            ("info", f"{track_name}.yml"),
            ("meshes/{tn}", f"{track_name}.dae"),
            ("models/{tn}", f"{track_name}.sdf"),
            ("models/{tn}", "model.config"),
            ("thumbnail", f"{track_name}.svg"),
            ("track_iconography", f"{track_name}.png"),
        ]
        
        for subdir, filename in required_checks:
            subdir_resolved = subdir.replace("{tn}", track_name)
            check_path = root_dir / subdir_resolved / filename
            if not check_path.exists():
                missing.append(f"{subdir_resolved}/{filename}")
        
        if missing:
            raise HTTPException(
                status_code=400, 
                detail=f"Missing required files: {', '.join(missing)}"
            )
        
        # 중복 이름 체크 (worlds 폴더 기반)
        for target in [SIMAPP_MOUNT_DIR, SIMAPP_SHARE_DIR]:
            if (target / "worlds" / f"{track_name}.world").exists():
                # 커스텀 트랙 레지스트리에 있으면 중복 커스텀, 없으면 공식 트랙 충돌
                custom_info = _load_custom_tracks_info()
                if track_name in custom_info:
                    raise HTTPException(
                        status_code=409,
                        detail=f"Custom track '{track_name}' already exists. Delete it first to re-upload."
                    )
                else:
                    raise HTTPException(
                        status_code=409,
                        detail=f"Track name '{track_name}' conflicts with an existing track"
                    )
        
        # 파일 배치 - simapp 양쪽 경로에 복사
        _deploy_track_files(root_dir, track_name)
        
        # info yml에서 트랙 정보 읽기
        info_yml_path = root_dir / "info" / f"{track_name}.yml"
        track_length = 0
        track_width = 0
        with open(info_yml_path, "r") as f:
            info_data = yaml.safe_load(f) or {}
        if track_name in info_data:
            track_length = info_data[track_name].get("track_length", 0)
            track_width = info_data[track_name].get("track_width", 0)
        
        # 커스텀 트랙 정보 저장
        custom_info = _load_custom_tracks_info()
        custom_info[track_name] = {
            "track_length": round(track_length, 2),
            "track_width": round(track_width, 2),
        }
        _save_custom_tracks_info(custom_info)
    
    return JSONResponse({
        "success": True,
        "track_id": track_name,
        "track_length": round(track_length, 2),
        "track_width": round(track_width, 2),
    })


def _find_track_root(extract_dir: Path) -> Path | None:
    """추출된 디렉토리에서 트랙 루트 찾기 (routes/*.npy 기반)"""
    # 직접 하위에 routes/ 있는지
    if (extract_dir / "routes").is_dir() and list((extract_dir / "routes").glob("*.npy")):
        return extract_dir
    
    # 한 단계 하위 디렉토리 탐색
    for sd in extract_dir.iterdir():
        if sd.is_dir() and sd.name != "__MACOSX":
            if (sd / "routes").is_dir() and list((sd / "routes").glob("*.npy")):
                return sd
    
    return None


def _deploy_track_files(root_dir: Path, track_name: str):
    """트랙 파일을 simapp 양쪽 경로에 배치"""
    targets = [SIMAPP_MOUNT_DIR, SIMAPP_SHARE_DIR]
    
    for target in targets:
        # routes
        dst = target / "routes" / f"{track_name}.npy"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_dir / "routes" / f"{track_name}.npy", dst)
        
        # worlds
        dst = target / "worlds" / f"{track_name}.world"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_dir / "worlds" / f"{track_name}.world", dst)
        
        # info
        dst = target / "info" / f"{track_name}.yml"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_dir / "info" / f"{track_name}.yml", dst)
        
        # thumbnail
        dst = target / "thumbnail" / f"{track_name}.svg"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_dir / "thumbnail" / f"{track_name}.svg", dst)
        
        # track_iconography
        dst = target / "track_iconography" / f"{track_name}.png"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_dir / "track_iconography" / f"{track_name}.png", dst)
        
        # meshes (전체 디렉토리)
        src_meshes = root_dir / "meshes" / track_name
        dst_meshes = target / "meshes" / track_name
        if dst_meshes.exists():
            shutil.rmtree(dst_meshes)
        shutil.copytree(src_meshes, dst_meshes)
        
        # models (전체 디렉토리)
        src_models = root_dir / "models" / track_name
        dst_models = target / "models" / track_name
        if dst_models.exists():
            shutil.rmtree(dst_models)
        shutil.copytree(src_models, dst_models)


def _remove_track_files(track_name: str):
    """트랙 파일을 simapp 양쪽 경로에서 제거"""
    targets = [SIMAPP_MOUNT_DIR, SIMAPP_SHARE_DIR]
    
    for target in targets:
        # 단일 파일들
        for rel in [
            f"routes/{track_name}.npy",
            f"worlds/{track_name}.world",
            f"info/{track_name}.yml",
            f"thumbnail/{track_name}.svg",
            f"track_iconography/{track_name}.png",
        ]:
            p = target / rel
            if p.exists():
                p.unlink()
        
        # 디렉토리들
        for rel in [f"meshes/{track_name}", f"models/{track_name}"]:
            d = target / rel
            if d.exists():
                shutil.rmtree(d)


@app.delete("/api/tracks/custom/{track_id}", name="api_custom_track_delete")
async def api_custom_track_delete(track_id: str):
    """커스텀 트랙 삭제 API"""
    custom_info = _load_custom_tracks_info()
    if track_id not in custom_info:
        raise HTTPException(status_code=404, detail=f"Custom track '{track_id}' not found")
    
    # simapp 파일 제거 (routes, worlds, info, thumbnail, track_iconography, meshes, models)
    _remove_track_files(track_id)
    
    # 커스텀 트랙 정보에서 제거
    del custom_info[track_id]
    _save_custom_tracks_info(custom_info)
    
    return JSONResponse({"success": True, "track_id": track_id})


@app.get("/api/tracks/custom/{track_id}/thumbnail", name="api_custom_track_thumbnail")
async def api_custom_track_thumbnail(track_id: str):
    """커스텀 트랙 SVG 썸네일 서빙"""
    # SIMAPP_MOUNT_DIR에서 찾기
    svg_path = SIMAPP_MOUNT_DIR / "thumbnail" / f"{track_id}.svg"
    if not svg_path.exists():
        svg_path = SIMAPP_SHARE_DIR / "thumbnail" / f"{track_id}.svg"
    if not svg_path.exists():
        raise HTTPException(status_code=404, detail="Thumbnail not found")
    return FileResponse(svg_path, media_type="image/svg+xml")


@app.get("/api/tracks/{track_id}/waypoints", name="api_track_waypoints")
async def api_track_waypoints(track_id: str):
    """트랙 waypoints 다운로드 (.npy)"""
    npy_path = SIMAPP_SHARE_DIR / "routes" / f"{track_id}.npy"
    if not npy_path.exists():
        npy_path = SIMAPP_MOUNT_DIR / "routes" / f"{track_id}.npy"
    if not npy_path.exists():
        raise HTTPException(status_code=404, detail=f"Route file for '{track_id}' not found")
    
    return FileResponse(
        path=str(npy_path),
        filename=f"{track_id}_waypoints.npy",
        media_type="application/octet-stream",
    )


@app.get("/api/models", name="api_models_list")
async def api_models_list():
    """모델 목록 API"""
    from physicar.codespaces.deepracer.settings_manager import get_model_list
    from physicar.codespaces.deepracer.jobs import active_jobs
    
    models = get_model_list(active_jobs)
    return JSONResponse({
        "models": models,
        "total": len(models),
    })


@app.get("/api/config/limits", name="api_config_limits")
async def api_config_limits():
    """사용자 입력 제한 및 옵션 API"""
    return JSONResponse({
        "limits": USER_INPUT_LIMITS,
        "max_sub_simulations": get_max_sub_simulation_count(),
    })


# ============ 설정 로드/저장 API ============

@app.get("/api/settings", name="api_settings_load")
async def api_settings_load():
    """모든 설정 로드 API"""
    from physicar.codespaces.deepracer.settings_manager import load_settings
    settings = load_settings()
    return JSONResponse(settings)


@app.post("/api/settings/simulation/main", name="api_settings_simulation_main")
async def api_settings_simulation_main(request: Request):
    """메인 시뮬레이션 설정 저장 API"""
    from physicar.codespaces.deepracer.settings_manager import save_simulation_main
    data = await request.json()
    save_simulation_main(data)
    return JSONResponse({"status": "ok"})


@app.post("/api/settings/simulation/sub/{index}", name="api_settings_simulation_sub")
async def api_settings_simulation_sub(index: int, request: Request):
    """서브 시뮬레이션 설정 저장 API"""
    from physicar.codespaces.deepracer.settings_manager import save_simulation_sub
    data = await request.json()
    save_simulation_sub(index, data)
    return JSONResponse({"status": "ok"})


@app.post("/api/settings/simulation/count", name="api_settings_simulation_count")
async def api_settings_simulation_count(request: Request):
    """서브 시뮬레이션 수 설정 API"""
    from physicar.codespaces.deepracer.settings_manager import save_sub_simulation_count
    data = await request.json()
    count = data.get("count", 0)
    save_sub_simulation_count(count)
    return JSONResponse({"status": "ok"})


@app.post("/api/settings/model-name", name="api_settings_model_name")
async def api_settings_model_name(request: Request):
    """모델명 저장 API (run.env에 저장)"""
    from physicar.codespaces.deepracer.settings_manager import save_model_name
    data = await request.json()
    model_name = data.get("model_name", "").strip()
    if model_name:
        save_model_name(model_name)
    return JSONResponse({"status": "ok"})


@app.get("/api/settings/model-name", name="api_get_model_name")
async def api_get_model_name():
    """모델명 조회 API"""
    from physicar.codespaces.deepracer.settings_manager import load_model_name
    model_name = load_model_name()
    return JSONResponse({"model_name": model_name})


@app.post("/api/settings/vehicles", name="api_settings_vehicles")
async def api_settings_vehicles(request: Request):
    """차량/액션 스페이스 설정 저장 API"""
    from physicar.codespaces.deepracer.settings_manager import save_vehicles_settings
    data = await request.json()
    save_vehicles_settings(data)
    return JSONResponse({"status": "ok"})


@app.post("/api/settings/hyperparameters", name="api_settings_hyperparameters")
async def api_settings_hyperparameters(request: Request):
    """하이퍼파라미터 저장 API"""
    from physicar.codespaces.deepracer.settings_manager import save_hyperparameters, load_simulation_settings
    data = await request.json()
    sim_settings = load_simulation_settings()
    sub_sim_count = sim_settings.get("sub_simulation_count", 0)
    save_hyperparameters(data, sub_sim_count)
    return JSONResponse({"status": "ok"})


@app.post("/api/settings/reward-function", name="api_settings_reward_function")
async def api_settings_reward_function(request: Request):
    """보상 함수 저장 API"""
    from physicar.codespaces.deepracer.settings_manager import save_reward_function
    data = await request.json()
    code = data.get("code", "")
    save_reward_function(code)
    return JSONResponse({"status": "ok"})


@app.post("/api/reward-function/generate", name="api_generate_reward_function")
async def api_generate_reward_function(request: Request):
    """AI를 사용하여 보상 함수 생성 API (GitHub Models)"""
    import os
    import requests as req
    from physicar.codespaces.deepracer.config import REWARD_FUNCTION_SYSTEM_PROMPT
    
    data = await request.json()
    prompt = data.get("prompt", "").strip()
    
    if not prompt:
        return JSONResponse({
            "status": "error",
            "error": "Prompt is empty."
        }, status_code=400)
    
    # GitHub Models API 호출
    github_token = os.environ.get("GITHUB_TOKEN")
    if not github_token:
        return JSONResponse({
            "status": "error",
            "error": "GITHUB_TOKEN is not configured."
        }, status_code=500)
    
    user_message = f"User request: {prompt}\n\nGenerate a simple reward function that does exactly what the user asks. Nothing more, nothing less."
    
    try:
        url = "https://models.inference.ai.azure.com/chat/completions"
        headers = {
            "Authorization": f"Bearer {github_token}",
            "Content-Type": "application/json"
        }
        
        # 요청에서 모델 가져오기 (기본값: gpt-4o)
        ai_model = data.get("model", "gpt-4o")
        # 허용된 모델만 사용
        allowed_models = ["gpt-4o", "gpt-4o-mini"]
        if ai_model not in allowed_models:
            ai_model = "gpt-4o"
        
        payload = {
            "model": ai_model,
            "messages": [
                {"role": "system", "content": REWARD_FUNCTION_SYSTEM_PROMPT},
                {"role": "user", "content": user_message}
            ],
            "max_tokens": 16000,
            "temperature": 0.7
        }
        
        resp = req.post(url, headers=headers, json=payload, timeout=30)
        
        if resp.status_code != 200:
            return JSONResponse({
                "status": "error",
                "error": f"GitHub Models API error: {resp.status_code}"
            }, status_code=500)
        
        result = resp.json()
        content = result["choices"][0]["message"]["content"]
        
        # 코드 블록 추출 (```python ... ``` 형식일 경우)
        if "```python" in content:
            code = content.split("```python")[1].split("```")[0].strip()
        elif "```" in content:
            code = content.split("```")[1].split("```")[0].strip()
        else:
            code = content.strip()
        
        return JSONResponse({
            "status": "success",
            "code": code
        })
        
    except req.exceptions.Timeout:
        return JSONResponse({
            "status": "error",
            "error": "API request timed out"
        }, status_code=504)
    except Exception as e:
        return JSONResponse({
            "status": "error",
            "error": f"Error occurred: {str(e)}"
        }, status_code=500)


@app.post("/api/reward-function/validate", name="api_run_debug_reward_function")
async def api_run_debug_reward_function(request: Request):
    """Reward Function 검증 API - Docker 컨테이너에서 실제 실행하여 검증"""
    from physicar.codespaces.deepracer.debug_reward import (
        run_debug_reward_function,
        DebugRewardFunctionError,
    )
    
    try:
        data = await request.json()
        code = data.get("reward_function", "")
        race_type = data.get("race_type", "TT")
        action_space_type = data.get("action_space_type", "discrete")
        
        if not code.strip():
            return JSONResponse({
                "status": "error",
                "error": {
                    "error_type": "EmptyCode",
                    "error_message": "Reward function code is empty",
                    "error_line": None,
                }
            }, status_code=400)
        
        # Docker 컨테이너에서 실행하여 검증
        run_debug_reward_function(
            reward_function_script=code,
            race_type=race_type,
            action_space_type=action_space_type,
        )
        
        return JSONResponse({
            "status": "success",
            "reward_function": code,
        })
    
    except DebugRewardFunctionError as e:
        return JSONResponse({
            "status": "error",
            "error": {
                "error_type": "DebugRewardFunctionError",
                "error_message": str(e).strip(),
                "error_line": e.error_line,
            }
        }, status_code=400)
    
    except Exception as e:
        return JSONResponse({
            "status": "error",
            "error": {
                "error_type": type(e).__name__,
                "error_message": str(e).strip(),
                "error_line": None,
            }
        }, status_code=400)


@app.get("/api/models/{model_name}/check", name="api_model_check")
async def api_model_check(model_name: str):
    """모델명 중복 체크 API"""
    available, suggestion = validate_model_name_available(model_name)
    return JSONResponse({
        "available": available,
        "model_name": model_name,
        "suggestion": suggestion if not available else None,
    })


@app.get("/api/models/{model_name}/info", name="api_model_info")
async def api_model_info(model_name: str):
    """모델 정보 API - 모델 설정 정보 반환 (MinIO API 사용)"""
    
    # models/ prefix 처리
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    result = {"model_name": model_name}
    
    # 트랙 정보 로드 (track_id -> track_name 변환용) - 로컬 파일 (변경 드묾)
    tracks_info = {}
    if TRACKS_INFO_PATH.exists():
        with open(TRACKS_INFO_PATH) as f:
            tracks_info = yaml.safe_load(f) or {}
    
    def get_track_display_info(world_name: str):
        """WORLD_NAME에서 track display info 추출"""
        track_id = world_name
        track_info = tracks_info.get(track_id, {})
        return {
            "track_id": track_id,
            "thumbnail": f"{track_id}.svg",
        }
    
    def parse_simulation_from_params(params: dict):
        """training-params에서 simulation 정보 추출"""
        world_name = params.get("WORLD_NAME", "")
        track_info = get_track_display_info(world_name)
        
        # randomize 여부
        randomize = params.get("RANDOMIZE_OBSTACLE_LOCATIONS", "False") == "True"
        
        # OBJECT_POSITIONS 파싱 (randomize가 false일 때만)
        object_positions = []
        if not randomize:
            raw_positions = params.get("OBJECT_POSITIONS", [])
            if isinstance(raw_positions, list):
                for pos in raw_positions:
                    if isinstance(pos, str) and ',' in pos:
                        parts = pos.split(',')
                        if len(parts) == 2:
                            progress = float(parts[0])  # 0.2 그대로 (JS에서 * 100)
                            lane = 1 if parts[1].strip() == "1" else -1
                            object_positions.append({"progress": progress, "lane": lane})
        
        return {
            "track_id": track_info["track_id"],
            "thumbnail": track_info["thumbnail"],
            "alternate_direction": params.get("ALTERNATE_DRIVING_DIRECTION", "False") == "True",
            "race_type": params.get("RACE_TYPE", "TIME_TRIAL"),
            "obstacle_type": params.get("OBSTACLE_TYPE", ""),
            "number_of_obstacles": int(params.get("NUMBER_OF_OBSTACLES", 0)),
            "randomize_obstacles": randomize,
            "object_positions": object_positions,
        }
    
    # 모든 시뮬레이션 정보 로드 (main + sub1~6) - MinIO API 사용
    # 파일명 패턴:
    #   - training-params/main.yaml (main)
    #   - training-params/sub1.yaml ~ training-params/sub6.yaml (sub)
    simulations = {}
    
    # Main simulation - training-params/main.yaml
    main_params = minio_read_yaml(f"models/{model_name}/training-params/main.yaml")
    
    if main_params:
        simulations["main"] = parse_simulation_from_params(main_params)
        result["best_model_metric"] = main_params.get("BEST_MODEL_METRIC", "reward")
        result["vehicle"] = {
            "body_shell_type": main_params.get("BODY_SHELL_TYPE", "deepracer"),
        }
    
    # Sub simulations - training-params/sub1.yaml ~ training-params/sub6.yaml
    for i in range(1, 7):
        sub_params = minio_read_yaml(f"models/{model_name}/training-params/sub{i}.yaml")
        if sub_params:
            simulations[f"sub{i}"] = parse_simulation_from_params(sub_params)
    
    result["simulations"] = simulations
    result["sub_simulation_count"] = len(simulations) - 1 if "main" in simulations else 0
    
    # models/{model}/model/model_metadata.json - vehicle, action_space (MinIO API)
    # 없으면 custom_files/model_metadata.json fallback
    mm_key = f"models/{model_name}/model/model_metadata.json"
    model_metadata = minio_read_json(mm_key)
    if not model_metadata:
        model_metadata = minio_read_json("custom_files/model_metadata.json")
    
    if model_metadata:
        # Vehicle 정보 업데이트
        if "vehicle" not in result:
            result["vehicle"] = {}
        # vehicle_type은 training-params.yaml의 BODY_SHELL_TYPE에서 이미 읽음 (body_shell_type)
        # metadata.json에서는 저장하지 않으므로 읽지 않음
        if "body_shell_type" in result.get("vehicle", {}):
            result["vehicle"]["vehicle_type"] = result["vehicle"]["body_shell_type"]
        result["vehicle"]["sensor"] = model_metadata.get("sensor", ["FRONT_FACING_CAMERA"])
        result["vehicle"]["action_space_type"] = model_metadata.get("action_space_type", "discrete")
        result["vehicle"]["action_space"] = model_metadata.get("action_space", [])
        result["max_training_time"] = model_metadata.get("max_training_time")
    
    # models/{model}/ip/hyperparameters.json (MinIO API)
    # 없으면 custom_files/hyperparameters.json fallback
    hp_key = f"models/{model_name}/ip/hyperparameters.json"
    hyperparameters = minio_read_json(hp_key)
    if not hyperparameters:
        hyperparameters = minio_read_json("custom_files/hyperparameters.json")
    if hyperparameters:
        result["hyperparameters"] = hyperparameters
    
    # reward_function.py (MinIO API)
    rf_key = f"models/{model_name}/reward_function.py"
    reward_function = minio_read_text(rf_key)
    if reward_function:
        result["reward_function"] = reward_function
    
    return JSONResponse(result)


# ============ Model Monitoring APIs ============

def get_training_time_from_minio(model_name: str) -> Optional[dict]:
    """
    MinIO에서 훈련 시간 계산
    - 시작: reward_function.py (모델 생성 시점)
    - 종료: training-metrics/의 마지막 파일 (훈련 종료 시점)
    
    evaluation/, inference-model/, training-logs/rl_coach.log 등은 
    훈련 후에도 업데이트될 수 있으므로 제외
    
    Returns: {"start_time": datetime, "end_time": datetime, "elapsed_seconds": float} or None
    """
    try:
        from datetime import datetime, timezone
        
        client = _get_minio_client()
        prefix = f'models/{model_name}/'
        
        # 모든 파일 조회
        all_objects = list(client.list_objects(MINIO_BUCKET, prefix=prefix, recursive=True))
        if not all_objects:
            return None
        
        # 시작 시점: reward_function.py
        reward_files = [o for o in all_objects if o.object_name.endswith('reward_function.py')]
        if not reward_files:
            return None
        start_obj = reward_files[0]
        
        # 종료 시점: training-metrics/의 마지막 파일 (훈련 종료 직후 업로드됨)
        metrics_objects = [
            o for o in all_objects 
            if o.object_name.startswith(f'{prefix}training-metrics/')
        ]
        
        if not metrics_objects:
            # training-metrics가 없으면 training-simtrace로 fallback
            simtrace_objects = [
                o for o in all_objects 
                if o.object_name.startswith(f'{prefix}training-simtrace/')
            ]
            if not simtrace_objects:
                return None
            end_obj = max(simtrace_objects, key=lambda x: x.last_modified)
        else:
            end_obj = max(metrics_objects, key=lambda x: x.last_modified)
        
        elapsed = (end_obj.last_modified - start_obj.last_modified).total_seconds()
        
        return {
            "start_time": start_obj.last_modified,
            "end_time": end_obj.last_modified,
            "elapsed_seconds": elapsed
        }
    except Exception as e:
        print(f"MinIO training time error: {e}")
        return None

def get_max_training_time_from_metadata(model_name: str) -> int | None:
    """model_metadata.json에서 max_training_time(분) 가져오기 (MinIO API)
    
    1. models/{model}/model/model_metadata.json 확인 (훈련 후)
    2. custom_files/model_metadata.json 확인 (훈련 전)
    3. 둘 다 없으면 None 반환
    """
    # 먼저 모델별 metadata 확인
    key = f"models/{model_name}/model/model_metadata.json"
    data = minio_read_json(key)
    if data and "max_training_time" in data:
        return data["max_training_time"]
    
    # 없으면 custom_files 확인
    data = minio_read_json("custom_files/model_metadata.json")
    if data and "max_training_time" in data:
        return data["max_training_time"]
    
    return None

@app.get("/api/models/{model_name}/status", name="api_model_status")
async def api_model_status(model_name: str):
    """
    모델 상태 API - Docker 기반 훈련/평가 상태 확인 (MinIO API 사용)
    
    status 값:
    - training: 훈련 중
    - evaluating: 평가 중
    - stopping: 정지 중
    - ready: 준비됨 (체크포인트 있음)
    - failed: 실패 (체크포인트 없음)
    """
    from physicar.codespaces.deepracer.jobs import (
        get_training_status, get_run_id_by_model_name, get_job, JobType
    )
    
    # models/ prefix가 있으면 제거
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    # MinIO에서 훈련 시간 정보 가져오기
    minio_time = get_training_time_from_minio(model_name)
    training_time_seconds = minio_time["elapsed_seconds"] if minio_time else None
    max_training_time_minutes = get_max_training_time_from_metadata(model_name)
    
    # Docker에서 훈련 상태 확인
    run_id = get_run_id_by_model_name(model_name)
    
    if run_id is not None:
        status_info = get_training_status(run_id)
        docker_status = status_info.get("status", "unknown")
        
        # 작업 유형 확인 (training vs evaluation)
        job = get_job(run_id)
        job_type = job.job_type if job else None
        
        # status 매핑: docker_status → 우리 status
        if docker_status == "running":
            if job_type == JobType.EVALUATION:
                status = "evaluating"
            else:
                status = "training"
        else:
            # failed, stopped, stopping, error 등 → training (정지 중에도 training 유지)
            if job_type == JobType.EVALUATION:
                status = "evaluating"
            else:
                status = "training"
        
        # 훈련 중: MinIO에서 실시간 경과 시간 계산
        should_stop = False
        elapsed_seconds = None
        started_at = None
        
        if minio_time:
            from datetime import datetime, timezone
            started_at = minio_time["start_time"].isoformat()
            # 현재 시간과 시작 시간으로 경과 시간 계산
            now_dt = datetime.now(timezone.utc)
            elapsed_seconds = (now_dt - minio_time["start_time"]).total_seconds()
            
            # 자동 중지 필요 여부만 반환 (훈련 중일 때만)
            if status == "training" and max_training_time_minutes:
                elapsed_minutes = elapsed_seconds / 60
                if elapsed_minutes >= max_training_time_minutes:
                    should_stop = True
        
        return JSONResponse({
            "model_name": model_name,
            "status": status,
            "run_id": run_id,
            "is_training": status == "training",
            "is_evaluating": status == "evaluating",
            "robomaker_running": status_info.get("robomaker_running", 0),
            "containers": status_info.get("containers", []),
            "started_at": started_at,
            "elapsed_seconds": elapsed_seconds,
            "training_time_seconds": training_time_seconds,
            "max_training_time_minutes": max_training_time_minutes,
            "should_stop": should_stop,
        })
    else:
        # 훈련 중이 아님 - 체크포인트 존재 여부로 ready/failed 판단
        checkpoints = minio_read_json(f"models/{model_name}/model/deepracer_checkpoints.json")
        has_checkpoints = bool(checkpoints and checkpoints.get("best_checkpoint"))
        
        return JSONResponse({
            "model_name": model_name,
            "status": "ready" if has_checkpoints else "failed",
            "run_id": None,
            "is_training": False,
            "is_evaluating": False,
            "training_time_seconds": training_time_seconds,
            "max_training_time_minutes": max_training_time_minutes,
        })


@app.get("/api/models/{model_name}/training/metrics", name="api_model_training_metrics")
async def api_model_training_metrics(model_name: str, worker: int = 0):
    """
    훈련 메트릭 API - TrainingMetrics.json 반환 (MinIO API 사용)
    
    Args:
        model_name: 모델 이름
        worker: 워커 번호 (0=main, 1=sub1, ...)
    """
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    # training-metrics/main.json or training-metrics/sub1.json (MinIO API)
    worker_name = 'main' if worker == 0 else f'sub{worker}'
    metrics_key = f"models/{model_name}/training-metrics/{worker_name}.json"
    
    data = minio_read_json(metrics_key)
    if not data:
        return JSONResponse({
            "model_name": model_name,
            "worker": worker,
            "metrics": [],
            "exists": False,
            "best_model_metric": "reward",
            "num_episodes_between_training": 10,
        })
    
    try:
        # config.training.yml에서 num_episodes_between_training 가져오기 (MinIO API)
        num_episodes_between_training = 10
        config_key = f"models/{model_name}/config.training.yml"
        config_data = minio_read_yaml(config_key)
        if config_data and 'training' in config_data:
            num_episodes_between_training = config_data['training'].get('num_episodes_between_training', 10)
        
        return JSONResponse({
            "model_name": model_name,
            "worker": worker,
            "metrics": data.get("metrics", []),
            "exists": True,
            "best_model_metric": data.get("best_model_metric", "reward"),
            "num_episodes_between_training": num_episodes_between_training,
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read metrics: {str(e)}")


@app.get("/api/models/{model_name}/training/config", name="api_model_training_config")
async def api_model_training_config(model_name: str, worker: int = 1):
    """
    훈련 설정 API - training-params/{worker}.yaml 반환 (MinIO API 사용)
    """
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    # training-params/{worker_name}.yaml (MinIO API)
    worker_name = 'main' if worker == 1 else f'sub{worker-1}'
    config_key = f"models/{model_name}/training-params/{worker_name}.yaml"
    config = minio_read_yaml(config_key)
    
    if not config:
        return JSONResponse({
            "model_name": model_name,
            "worker": worker,
            "config": {},
            "exists": False,
        })
    
    return JSONResponse({
        "model_name": model_name,
        "worker": worker,
        "config": config,
        "exists": True,
    })


@app.get("/api/models/{model_name}/reward_function", name="api_model_reward_function")
async def api_model_reward_function(model_name: str):
    """보상 함수 API (MinIO API 사용)"""
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    rf_key = f"models/{model_name}/reward_function.py"
    content = minio_read_text(rf_key)
    
    if not content:
        return JSONResponse({
            "model_name": model_name,
            "content": "",
            "exists": False,
        })
    
    return JSONResponse({
        "model_name": model_name,
        "content": content,
        "exists": True,
    })


@app.get("/api/models/{model_name}/clone-config", name="api_model_clone_config")
async def api_model_clone_config(model_name: str):
    """
    Clone 설정 API - 기존 모델 설정을 CreateModelRequest 형태로 반환
    
    training-params/*.yaml, model/model_metadata.json, reward_function.py 조합
    """
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    # 1. main 훈련 설정 로드
    main_config = minio_read_yaml(f"models/{model_name}/training-params/main.yaml") or {}
    
    # 2. sub 시뮬레이션 설정 로드 (sub1~sub6)
    sub_configs = []
    for i in range(1, 7):
        sub_config = minio_read_yaml(f"models/{model_name}/training-params/sub{i}.yaml")
        if sub_config:
            sub_configs.append(sub_config)
    
    # 3. model_metadata.json 로드
    model_metadata = minio_read_json(f"models/{model_name}/model/model_metadata.json") or {}
    
    # 4. hyperparameters.json 로드 (모델 전용 → custom_files 폴백)
    hyperparams = minio_read_json(f"models/{model_name}/ip/hyperparameters.json") or minio_read_json(f"custom_files/hyperparameters.json") or {}
    
    # 5. reward_function.py 로드
    reward_function = minio_read_text(f"models/{model_name}/reward_function.py") or ""
    
    # 6. 응답 구성
    def parse_bool(value, default: bool = False) -> bool:
        """YAML에서 읽은 값을 boolean으로 변환 (문자열 'True'/'False' 처리)"""
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes')
        return default
    
    def parse_int(value, default: int = 0) -> int:
        """YAML에서 읽은 값을 int로 변환"""
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    
    def extract_simulation(config: dict) -> dict:
        """training-params/*.yaml에서 시뮬레이션 설정 추출"""
        sim = {
            "track_id": config.get("WORLD_NAME", "reInvent2019_wide"),
            "alternate_direction": parse_bool(config.get("ALTERNATE_DRIVING_DIRECTION"), False),
            "race_type": config.get("RACE_TYPE", "TIME_TRIAL"),
        }
        
        # Object Avoidance 설정
        if sim["race_type"] == "OBJECT_AVOIDANCE":
            sim["object_avoidance"] = {
                "object_type": config.get("OBJECT_TYPE", "box_obstacle"),
                "number_of_obstacles": parse_int(config.get("NUMBER_OF_OBSTACLES"), 3),
                "randomize_locations": parse_bool(config.get("RANDOMIZE_OBSTACLE_LOCATIONS"), True),
            }
            # 고정 위치가 있으면 추가
            object_positions = config.get("OBJECT_POSITIONS")
            if object_positions and not sim["object_avoidance"]["randomize_locations"]:
                positions = []
                # OBJECT_POSITIONS는 리스트 ['0.25,1', '0.5,-1'] 또는 문자열 '0.25,1;0.5,-1' 형태
                pos_items = object_positions if isinstance(object_positions, list) else object_positions.split(";")
                for pos in pos_items:
                    pos_str = str(pos).strip()
                    if "," in pos_str:
                        progress, lane = pos_str.split(",")
                        positions.append({
                            "progress": float(progress) * 100,
                            "lane": "inside" if int(float(lane)) == 1 else "outside"
                        })
                sim["object_avoidance"]["object_positions"] = positions
        
        return sim
    
    # 메인 시뮬레이션
    main_sim = extract_simulation(main_config)
    
    # 서브 시뮬레이션
    sub_sims = [extract_simulation(sc) for sc in sub_configs]
    
    # 차량 설정
    sensors = model_metadata.get("sensor", ["FRONT_FACING_CAMERA"])
    action_space = model_metadata.get("action_space", [])
    
    vehicle = {
        "vehicle_type": "deepracer",  # TODO: 메타데이터에서 추출
        "lidar": "SECTOR_LIDAR" in sensors,
        "action_space": [
            {"steering_angle": int(a.get("steering_angle", 0)), "speed": float(a.get("speed", 1.0))}
            for a in action_space
        ] if action_space else None,
    }
    
    # 하이퍼파라미터
    hyperparameters = {
        "batch_size": hyperparams.get("batch_size", 64),
        "discount_factor": hyperparams.get("discount_factor", 0.999),
        "learning_rate": hyperparams.get("lr", 0.0003),
        "loss_type": hyperparams.get("loss_type", "huber"),
        "entropy": hyperparams.get("beta_entropy", 0.01),
    }
    
    # 훈련 설정
    training = {
        "best_model_metric": main_config.get("BEST_MODEL_METRIC", "progress"),
        "hyperparameters": hyperparameters,
    }
    
    return JSONResponse({
        "model_name": model_name,
        "simulation": main_sim,
        "sub_simulations": sub_sims,
        "sub_simulation_count": len(sub_configs),
        "vehicle": vehicle,
        "training": training,
        "reward_function": reward_function,
    })


# 최소 Inference Model 크기 (20 MiB)
MIN_INFERENCE_MODEL_SIZE = 20 * 1024 * 1024


def _generate_inference_model_tar(model_name: str, model_type: str) -> tuple:
    """
    S3 체크포인트에서 Inference Model tar.gz 직접 생성
    
    Args:
        model_name: 모델 이름
        model_type: 'best' 또는 'last'
    
    Returns:
        (tar_bytes, checkpoint_num) 튜플
    """
    import json
    import io
    import tarfile
    
    client = _get_minio_client()
    
    # 1. deepracer_checkpoints.json 읽기
    checkpoints_key = f"models/{model_name}/model/deepracer_checkpoints.json"
    try:
        response = client.get_object(MINIO_BUCKET, checkpoints_key)
        checkpoints_data = json.loads(response.read().decode('utf-8'))
        response.close()
        response.release_conn()
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Checkpoints file not found: {e}")
    
    # 2. best/last checkpoint 번호 추출
    checkpoint_key = f"{model_type}_checkpoint"
    checkpoint_info = checkpoints_data.get(checkpoint_key, {})
    checkpoint_name = checkpoint_info.get("name", "")
    
    if not checkpoint_name:
        raise HTTPException(status_code=404, detail=f"No {model_type} checkpoint found")
    
    # 예: "2_Step-726.ckpt" -> 2
    checkpoint_num = checkpoint_name.split("_")[0]
    
    # 3. model_{num}.pb 다운로드
    pb_key = f"models/{model_name}/model/model_{checkpoint_num}.pb"
    try:
        response = client.get_object(MINIO_BUCKET, pb_key)
        pb_data = response.read()
        response.close()
        response.release_conn()
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Model file not found: model_{checkpoint_num}.pb")
    
    # 4. model_metadata.json 다운로드
    metadata_key = f"models/{model_name}/model/model_metadata.json"
    try:
        response = client.get_object(MINIO_BUCKET, metadata_key)
        metadata_data = response.read()
        response.close()
        response.release_conn()
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Model metadata not found")
    
    # 5. tar.gz 생성 (메모리 내)
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w:gz') as tar:
        # agent/model.pb 추가
        pb_info = tarfile.TarInfo(name='agent/model.pb')
        pb_info.size = len(pb_data)
        tar.addfile(pb_info, io.BytesIO(pb_data))
        
        # model_metadata.json 추가
        meta_info = tarfile.TarInfo(name='model_metadata.json')
        meta_info.size = len(metadata_data)
        tar.addfile(meta_info, io.BytesIO(metadata_data))
    
    tar_bytes = tar_buffer.getvalue()
    return tar_bytes, checkpoint_num


@app.get("/api/models/{model_name}/download/inference-model/{model_type}", name="api_model_download_inference_model")
async def api_model_download_inference_model(model_name: str, model_type: str):
    """
    Inference Model 다운로드 API
    
    S3 체크포인트에서 직접 tar.gz를 생성하여 반환합니다.
    - agent/model.pb: 해당 체크포인트의 frozen graph
    - model_metadata.json: 모델 메타데이터
    
    Args:
        model_name: 모델 이름
        model_type: 'best' 또는 'last'
    
    Returns:
        StreamingResponse로 tar.gz 파일 스트리밍
        파일명: {model_name}-{model_type}.tar.gz
    """
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    # model_type 유효성 검사
    if model_type not in ("best", "last"):
        raise HTTPException(status_code=400, detail="model_type must be 'best' or 'last'")
    
    try:
        # S3 체크포인트에서 직접 tar.gz 생성
        tar_bytes, checkpoint_num = _generate_inference_model_tar(model_name, model_type)
        
        # 크기 검증
        if len(tar_bytes) < MIN_INFERENCE_MODEL_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"Generated model file too small ({len(tar_bytes) / 1024 / 1024:.2f} MB)"
            )
        
        # 다운로드 파일명 생성
        download_filename = f"{model_name}-{model_type}.tar.gz"
        
        return StreamingResponse(
            io.BytesIO(tar_bytes),
            media_type="application/gzip",
            headers={
                "Content-Disposition": f'attachment; filename="{download_filename}"',
                "Content-Length": str(len(tar_bytes)),
                "X-Checkpoint-Number": str(checkpoint_num),
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate model: {str(e)}")


@app.get("/api/models/{model_name}/inference-model/status", name="api_model_inference_model_status")
async def api_model_inference_model_status(model_name: str):
    """
    Inference Model 상태 확인 API
    
    Returns:
        best와 last checkpoint의 존재 여부, model_{N}.pb 사이즈 등
    """
    import json
    
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    result = {
        "model_name": model_name,
        "codespace_name": os.environ.get("CODESPACE_NAME", "unknown"),
        "best_exists": False,
        "best_checkpoint": None,
        "best_pb_size": 0,
        "best_valid": False,
        "last_exists": False,
        "last_checkpoint": None,
        "last_pb_size": 0,
        "last_valid": False,
    }
    
    client = _get_minio_client()
    
    # deepracer_checkpoints.json 읽기
    checkpoints_key = f"models/{model_name}/model/deepracer_checkpoints.json"
    try:
        response = client.get_object(MINIO_BUCKET, checkpoints_key)
        checkpoints_data = json.loads(response.read().decode('utf-8'))
        response.close()
        response.release_conn()
    except Exception:
        # 체크포인트 파일이 없으면 빈 결과 반환
        return JSONResponse(result)
    
    # best checkpoint 확인
    best_info = checkpoints_data.get("best_checkpoint", {})
    if best_info.get("name"):
        best_num = best_info["name"].split("_")[0]
        result["best_checkpoint"] = best_info["name"]
        
        # model_{N}.pb 존재 확인
        pb_key = f"models/{model_name}/model/model_{best_num}.pb"
        try:
            stat = client.stat_object(MINIO_BUCKET, pb_key)
            result["best_exists"] = True
            result["best_pb_size"] = stat.size
            result["best_valid"] = stat.size >= MIN_INFERENCE_MODEL_SIZE
        except Exception:
            pass
    
    # last checkpoint 확인
    last_info = checkpoints_data.get("last_checkpoint", {})
    if last_info.get("name"):
        last_num = last_info["name"].split("_")[0]
        result["last_checkpoint"] = last_info["name"]
        
        # model_{N}.pb 존재 확인
        pb_key = f"models/{model_name}/model/model_{last_num}.pb"
        try:
            stat = client.stat_object(MINIO_BUCKET, pb_key)
            result["last_exists"] = True
            result["last_pb_size"] = stat.size
            result["last_valid"] = stat.size >= MIN_INFERENCE_MODEL_SIZE
        except Exception:
            pass
    
    return JSONResponse(result)


@app.get("/api/models/{model_name}/download/logs", name="api_model_download_logs")
async def api_model_download_logs(model_name: str):
    """
    모델 로그 다운로드 API
    training-logs, training-metrics, training-simtrace, evaluation 폴더를 tar.gz로 압축
    MinIO API 사용 (s3fs 마운트 의존 X)
    """
    import tarfile
    from io import BytesIO
    
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # 압축할 폴더 목록
    folders_to_include = ["training-logs/", "training-metrics/", "training-simtrace/", "evaluation/"]
    
    # MinIO에서 파일 목록 가져오기
    client = _get_minio_client()
    files_to_download = []
    
    for folder in folders_to_include:
        prefix = model_prefix + folder
        try:
            for obj in client.list_objects(MINIO_BUCKET, prefix=prefix, recursive=True):
                key = obj.object_name
                # mp4 파일은 용량이 크므로 제외
                if not key.lower().endswith('.mp4'):
                    files_to_download.append(key)
        except Exception:
            pass
    
    if not files_to_download:
        raise HTTPException(status_code=404, detail="No log files found for this model")
    
    # tar.gz 생성 (메모리 효율적으로)
    tar_buffer = BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode='w:gz') as tar:
        for s3_key in files_to_download:
            try:
                response = client.get_object(MINIO_BUCKET, s3_key)
                file_data = response.read()
                response.close()
                response.release_conn()
                
                # 상대 경로 계산 (models/{model_name}/ 제거)
                arcname = s3_key[len(model_prefix):]
                
                # tarfile에 추가 (BytesIO 재사용하여 메모리 절약)
                tarinfo = tarfile.TarInfo(name=arcname)
                tarinfo.size = len(file_data)
                tar.addfile(tarinfo, BytesIO(file_data))
                
                # 명시적으로 메모리 해제
                del file_data
            except Exception as e:
                logger.warning(f"Failed to add {s3_key} to archive: {e}")
    
    download_filename = f"{model_name}-logs.tar.gz"
    
    # getbuffer() 사용하여 복사 없이 전송
    tar_buffer.seek(0)
    content = tar_buffer.getvalue()
    content_length = len(content)
    tar_buffer.close()  # 원본 버퍼 해제
    
    # StreamingResponse로 청크 단위 전송 (VSCode Simple Browser 호환)
    def iter_content():
        chunk_size = 32 * 1024  # 32KB
        for i in range(0, content_length, chunk_size):
            yield content[i:i + chunk_size]
    
    return StreamingResponse(
        iter_content(),
        media_type="application/gzip",
        headers={
            "Content-Disposition": f'attachment; filename="{download_filename}"',
            "Content-Length": str(content_length),
        }
    )


@app.delete("/api/models/{model_name}", name="api_model_delete")
async def api_model_delete(model_name: str):
    """
    모델 삭제 API
    - 훈련/평가 중인 모델은 삭제 불가
    - S3(MinIO)에서 모델 폴더 전체 삭제
    """
    from minio.deleteobjects import DeleteObject
    from physicar.codespaces.deepracer.jobs import get_run_id_by_model_name, get_active_jobs
    
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    model_prefix = f"models/{model_name}/"
    
    # MinIO에서 모델 존재 여부 확인
    if not minio_prefix_exists(model_prefix):
        raise HTTPException(status_code=404, detail=f"Model '{model_name}' not found")
    
    # 훈련/평가 중인지 확인
    run_id = get_run_id_by_model_name(model_name)
    if run_id is not None:
        raise HTTPException(status_code=400, detail="Cannot delete model while training/evaluation is running")
    
    # 활성 작업 중 해당 모델이 있는지 확인
    active_jobs = get_active_jobs()
    for job in active_jobs:
        if job.model_name == model_name:
            raise HTTPException(status_code=400, detail="Cannot delete model while training/evaluation is running")
    
    try:
        # MinIO에서 모든 객체 삭제
        client = _get_minio_client()
        objects_to_delete = [DeleteObject(obj.object_name) for obj in client.list_objects(MINIO_BUCKET, prefix=model_prefix, recursive=True)]
        
        if objects_to_delete:
            errors = list(client.remove_objects(MINIO_BUCKET, objects_to_delete))
            if errors:
                raise Exception(f"Failed to delete some objects: {errors}")
        
        return JSONResponse({
            "success": True,
            "model_name": model_name,
            "message": f"Model '{model_name}' deleted successfully"
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete model: {str(e)}")


@app.get("/api/models/{model_name}/training/view", name="api_model_training_view")
async def api_model_training_view(model_name: str, quality: int = STREAM_QUALITY):
    """
    훈련 뷰 URL API - 실시간 훈련 영상 스트림 URL 반환
    
    프록시를 통해 로컬 ROS 스트림에 접근
    - /proxy/{port}/stream?topic=... 형식으로 제공
    
    Returns:
        - is_training: 컨테이너가 실행 중인지 (Docker 기준)
        - is_complete: 훈련이 확실히 완료되었는지 (run_id 없고 메트릭 있음)
        - streams_ready: 실제 스트림이 준비되었는지 (포트가 할당됨)
        - view_urls: 스트림 URL (streams_ready=true일 때만 유효)
    """
    from physicar.codespaces.deepracer.jobs import (
        get_run_id_by_model_name, get_training_status,
        get_robomaker_containers_with_rollout
    )
    
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    # 훈련 중인지 확인 - 해당 모델로 실행 중인 컨테이너가 있으면 training
    run_id = get_run_id_by_model_name(model_name)
    
    if run_id is None:
        # 컨테이너 없음 - 완료 여부는 메트릭 존재 여부로 판단
        # 메트릭이 있으면 완료, 없으면 아직 시작 전이거나 데이터 없음
        metrics_key = f"models/{model_name}/training-metrics/main.json"
        has_metrics = minio_object_exists(metrics_key)
        
        return JSONResponse(
            {
                "model_name": model_name,
                "is_training": False,
                "is_complete": has_metrics,  # 메트릭 있어야 진정한 완료
                "streams_ready": False,
                "view_urls": None,
            },
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )
    
    # 훈련 상태 상세 확인
    training_status = get_training_status(run_id)
    
    # Docker에서 robomaker 컨테이너 포트 찾기 (ROLLOUT_IDX 기준 정렬됨)
    view_urls = {}
    streams_ready = False
    
    try:
        # robomaker 컨테이너 목록 조회 (ROLLOUT_IDX 기준 정렬)
        # ⚠️ 컨테이너 이름의 번호(robomaker-1, robomaker-2)는 ROLLOUT_IDX와 무관함!
        containers = get_robomaker_containers_with_rollout(run_id)
        
        for container in containers:
            container_name = container["name"]
            ports_str = container["ports"]
            rollout_idx = container["rollout_idx"]
            
            # 8083, 8084 등 포트 추출
            # 예: "0.0.0.0:8083->8080/tcp"
            import re
            port_match = re.search(r'0\.0\.0\.0:(\d+)->8080/tcp', ports_str)
            if port_match:
                port = int(port_match.group(1))
            else:
                # 포트를 찾지 못하면 스킵
                continue
            
            # main / sub 키 결정 (ROLLOUT_IDX 기반)
            # ROLLOUT_IDX=0 → main, ROLLOUT_IDX=1 → sub1, ROLLOUT_IDX=2 → sub2
            if rollout_idx == 0:
                sim_key = 'main'
            elif rollout_idx == 999:
                # ROLLOUT_IDX를 확인하지 못한 경우 스킵
                continue
            else:
                sim_key = f'sub{rollout_idx}'
            
            # 프록시 URL 생성
            view_urls[sim_key] = {
                'front': f'/proxy/{port}/stream?topic=/racecar/camera/zed/rgb/image_rect_color&quality={quality}',
                'chase': f'/proxy/{port}/stream?topic=/racecar/main_camera/zed/rgb/image_rect_color&quality={quality}',
                'chase_overlay': f'/proxy/{port}/stream?topic=/racecar/deepracer/kvs_stream&quality={quality}',
            }
            streams_ready = True  # 최소 하나의 스트림이 준비됨
        
    except Exception as e:
        print(f"Error getting training view ports: {e}")
    
    return JSONResponse(
        {
            "model_name": model_name,
            "is_training": True,
            "is_complete": False,
            "streams_ready": streams_ready,
            "training_status": training_status.get("status", "unknown"),
            "run_id": run_id,
            "view_urls": view_urls if view_urls else None,
        },
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )


@app.post("/api/models/create", name="api_models_create")
async def api_models_create(request: CreateModelRequest):
    """모델 생성 API"""
    try:
        # 모델명 중복 체크
        available, suggestion = validate_model_name_available(request.model_name)
        if not available:
            raise HTTPException(
                status_code=400,
                detail=f"Model name '{request.model_name}' already exists. Suggestion: {suggestion}"
            )
        
        # 파일 생성
        files = create_model_files(request)
        
        return JSONResponse({
            "success": True,
            "model_name": request.model_name,
            "files": {name: str(path) for name, path in files.items()},
            "message": f"Model '{request.model_name}' created successfully",
        })
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============ Jobs API (Training/Evaluation) ============


@app.get("/api/system/cpu", name="api_system_cpu")
async def api_system_cpu():
    """CPU 상태 API"""
    return JSONResponse(jobs.get_cpu_status())


@app.get("/api/system/storage", name="api_system_storage")
async def api_system_storage():
    """Storage 상태 API (하드디스크 기준)"""
    import shutil
    try:
        # 홈 디렉토리 기준 디스크 사용량
        total, used, free = shutil.disk_usage("/home")
        return JSONResponse({
            "total_gb": round(total / (1024 ** 3)),
            "used_gb": round(used / (1024 ** 3)),
            "free_gb": round(free / (1024 ** 3)),
        })
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/system/machines", name="api_system_machines")
async def api_system_machines():
    """변경 가능한 머신 타입 목록 조회"""
    codespace_name = os.environ.get("CODESPACE_NAME")
    if not codespace_name:
        return JSONResponse({"error": "Not running in Codespace"}, status_code=400)
    
    try:
        result = subprocess.run(
            ["gh", "api", f"user/codespaces/{codespace_name}/machines",
             "--jq", '.machines[] | {name, cpus, storage_gb: (.storage_in_bytes/1024/1024/1024)}'],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return JSONResponse({"error": result.stderr}, status_code=500)
        
        # JSON 라인들을 파싱
        machines = []
        for line in result.stdout.strip().split('\n'):
            if line:
                machines.append(json.loads(line))
        
        # 현재 머신 타입 조회
        current_result = subprocess.run(
            ["gh", "codespace", "list", "--json", "name,machineName",
             "--jq", f'.[] | select(.name == "{codespace_name}") | .machineName'],
            capture_output=True, text=True, timeout=30
        )
        current_machine = current_result.stdout.strip() if current_result.returncode == 0 else None
        
        return JSONResponse({
            "machines": machines,
            "current": current_machine
        })
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Timeout"}, status_code=504)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/system/machine", name="api_system_machine_change")
async def api_system_machine_change(request: Request):
    """머신 타입 변경"""
    codespace_name = os.environ.get("CODESPACE_NAME")
    if not codespace_name:
        return JSONResponse({"error": "Not running in Codespace"}, status_code=400)
    
    try:
        data = await request.json()
        machine_name = data.get("machine")
        if not machine_name:
            return JSONResponse({"error": "machine required"}, status_code=400)
        
        # 1. 머신 변경
        edit_result = subprocess.run(
            ["gh", "codespace", "edit", "-c", codespace_name, "-m", machine_name],
            capture_output=True, text=True, timeout=60
        )
        if edit_result.returncode != 0:
            return JSONResponse({"error": edit_result.stderr}, status_code=500)
        
        # 2. 코드스페이스 시작 (머신 변경 후 자동 시작 안됨)
        start_result = subprocess.run(
            ["gh", "api", "--method", "POST", f"user/codespaces/{codespace_name}/start"],
            capture_output=True, text=True, timeout=60
        )
        
        return JSONResponse({
            "success": True,
            "message": f"Machine changed to {machine_name}. Codespace is restarting.",
            "machine": machine_name
        })
    except subprocess.TimeoutExpired:
        return JSONResponse({"error": "Timeout"}, status_code=504)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/jobs", name="api_jobs")
async def api_jobs():
    """활성 작업 목록 API"""
    return JSONResponse(jobs.get_jobs_summary())


@app.post("/api/training/quick-start", name="api_training_quick_start")
async def api_training_quick_start():
    """
    간단한 훈련 시작 API
    - 파라미터 없음
    - 모델명, worker_count, training_minutes 모두 저장된 파일에서 읽음
    """
    from physicar.codespaces.deepracer.settings_manager import (
        load_simulation_settings,
        load_vehicles_settings,
        parse_env_file,
        RUN_ENV_PATH,
        SYSTEM_ENV_PATH,
    )
    
    try:
        # 1. run.env에서 모델명 읽기
        run_env = parse_env_file(RUN_ENV_PATH)
        model_prefix = run_env.get("DR_LOCAL_S3_MODEL_PREFIX", "")
        
        # "models/model-name" 형식에서 모델명 추출
        if model_prefix.startswith("models/"):
            model_name = model_prefix[7:]  # "models/" 제거
        else:
            model_name = model_prefix
        
        # 2. 모델명 유효성 검사
        pattern = r"^[a-zA-Z0-9_.-]+$"
        if not model_name or not re.match(pattern, model_name):
            raise HTTPException(
                status_code=400,
                detail="Invalid model name in run.env. Please set a valid model name first."
            )
        
        # 3. 모델명 중복 체크
        available, suggestion = validate_model_name_available(model_name)
        if not available:
            raise HTTPException(
                status_code=400,
                detail=f"Model name '{model_name}' already exists. Suggestion: {suggestion}"
            )
        
        # 4. 저장된 설정에서 worker_count, training_minutes 읽기
        system_env = parse_env_file(SYSTEM_ENV_PATH)
        dr_workers = int(system_env.get("DR_WORKERS", "1"))
        worker_count = dr_workers  # DR_WORKERS = main + sub
        
        vehicle_settings = load_vehicles_settings()
        training_minutes = vehicle_settings.get("max_training_time", 60)
        
        # 5. CPU 사전 체크
        can_start, message, required_cpu = jobs.can_start_job(jobs.JobType.TRAINING, worker_count)
        if not can_start:
            cpu_status = jobs.get_cpu_status()
            raise HTTPException(
                status_code=503,
                detail={
                    "message": message,
                    "required_cpu": required_cpu,
                    "available_cpu": cpu_status["available"],
                    "total_cpu": cpu_status["total"],
                }
            )
        
        # 6. 훈련 시작
        success, message, job_info = await jobs.start_training(
            model_name=model_name,
            worker_count=worker_count,
            training_minutes=training_minutes,
        )
        
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "model_name": model_name,
            "run_id": job_info.run_id,
            "worker_count": worker_count,
            "training_minutes": training_minutes,
            "cpu_usage": job_info.cpu_usage,
            "message": message,
            "redirect_url": f"/pages/models/model?model_name={model_name}",
        })
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/training/start", name="api_training_start")
async def api_training_start(request: CreateModelRequest):
    """훈련 시작 API (모델 생성 + 훈련 시작)"""
    from physicar.codespaces.deepracer.debug_reward import (
        run_debug_reward_function,
        DebugRewardFunctionError,
    )
    
    # DEBUG: API가 받은 데이터 로그
    print("=== API RECEIVED DATA ===")
    print(f"model_name: {request.model_name}")
    print(f"action_space: {[{'steering_angle': a.steering_angle, 'speed': a.speed} for a in request.vehicle.action_space]}")
    print(f"hyperparameters: batch_size={request.training.hyperparameters.batch_size}, "
          f"discount_factor={request.training.hyperparameters.discount_factor}, "
          f"learning_rate={request.training.hyperparameters.learning_rate}, "
          f"loss_type={request.training.hyperparameters.loss_type}, "
          f"entropy={request.training.hyperparameters.entropy}")
    print("=========================")
    
    try:
        # 1. 모델명 중복 체크
        available, suggestion = validate_model_name_available(request.model_name)
        if not available:
            raise HTTPException(
                status_code=400,
                detail=f"Model name '{request.model_name}' already exists. Suggestion: {suggestion}"
            )
        
        # 2. 보상함수 검증 (Docker 기반)
        try:
            race_type = request.simulation.race_type or "TIME_TRIAL"
            # race_type 변환: TIME_TRIAL -> TT, OBJECT_AVOIDANCE -> OA
            race_type_short = "TT" if race_type == "TIME_TRIAL" else "OA" if race_type == "OBJECT_AVOIDANCE" else "TT"
            run_debug_reward_function(
                reward_function_script=request.reward_function,
                race_type=race_type_short,
                action_space_type="discrete",  # 기본값
            )
        except DebugRewardFunctionError as e:
            raise HTTPException(
                status_code=400,
                detail=f"Reward function validation failed: {str(e)}"
            )
        
        # 3. CPU 사전 체크
        worker_count = request.get_worker_count()
        can_start, message, required_cpu = jobs.can_start_job(jobs.JobType.TRAINING, worker_count)
        if not can_start:
            raise HTTPException(status_code=503, detail=message)
        
        # 4. 파일 생성
        files = create_model_files(request)
        
        # 5. 훈련 시작
        training_minutes = request.training.training_time_minutes
        success, message, job_info = await jobs.start_training(
            model_name=request.model_name,
            worker_count=worker_count,
            training_minutes=training_minutes,
        )
        
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "model_name": request.model_name,
            "run_id": job_info.run_id,
            "worker_count": worker_count,
            "training_minutes": training_minutes,
            "cpu_usage": job_info.cpu_usage,
            "message": message,
            "redirect_url": f"/pages/models/model?model_name={request.model_name}",
        })
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/training/clone", name="api_training_clone")
async def api_training_clone(request: CloneModelRequest):
    """Clone 훈련 시작 API (전체 설정 + pretrained)"""
    from physicar.codespaces.deepracer.settings_manager import is_model_clonable
    from physicar.codespaces.deepracer.debug_reward import (
        run_debug_reward_function,
        DebugRewardFunctionError,
    )
    
    try:
        # 1. 모델명 중복 체크
        available, suggestion = validate_model_name_available(request.model_name)
        if not available:
            raise HTTPException(
                status_code=400,
                detail=f"Model name '{request.model_name}' already exists. Suggestion: {suggestion}"
            )
        
        # 2. pretrained 모델 Clone 가능 여부 확인
        clonable, reason = is_model_clonable(request.pretrained_model_name, jobs.active_jobs)
        if not clonable:
            raise HTTPException(status_code=400, detail=reason)
        
        # 3. 보상함수 검증 (Docker 기반)
        try:
            race_type = request.simulation.race_type or "TIME_TRIAL"
            race_type_short = "TT" if race_type == "TIME_TRIAL" else "OA" if race_type == "OBJECT_AVOIDANCE" else "TT"
            run_debug_reward_function(
                reward_function_script=request.reward_function,
                race_type=race_type_short,
                action_space_type="discrete",
            )
        except DebugRewardFunctionError as e:
            raise HTTPException(
                status_code=400,
                detail=f"Reward function validation failed: {str(e)}"
            )
        
        # 4. CPU 사전 체크
        worker_count = request.get_worker_count()
        can_start, message, required_cpu = jobs.can_start_job(jobs.JobType.TRAINING, worker_count)
        if not can_start:
            raise HTTPException(status_code=503, detail=message)
        
        # 5. 파일 생성 (CreateModelRequest와 동일)
        files = create_model_files(request)
        
        # 6. 훈련 시작 (pretrained 설정 포함)
        training_minutes = request.training.training_time_minutes
        success, message, job_info = await jobs.start_training(
            model_name=request.model_name,
            worker_count=worker_count,
            training_minutes=training_minutes,
            pretrained_model_name=request.pretrained_model_name,
            pretrained_checkpoint=request.pretrained_checkpoint,
        )
        
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "model_name": request.model_name,
            "pretrained_model_name": request.pretrained_model_name,
            "pretrained_checkpoint": request.pretrained_checkpoint,
            "run_id": job_info.run_id,
            "worker_count": worker_count,
            "training_minutes": training_minutes,
            "cpu_usage": job_info.cpu_usage,
            "message": message,
            "redirect_url": f"/pages/models/model?model_name={request.model_name}",
        })
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/models/{model_name}/stop", name="api_model_stop")
async def api_model_stop(model_name: str):
    """모델 이름으로 훈련 중지 API"""
    from physicar.codespaces.deepracer.jobs import get_run_id_by_model_name
    
    if model_name.startswith("models/"):
        model_name = model_name[7:]
    
    run_id = get_run_id_by_model_name(model_name)
    if run_id is None:
        raise HTTPException(status_code=404, detail=f"No running training found for model '{model_name}'")
    
    try:
        success, message = await jobs.stop_training(run_id)
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "model_name": model_name,
            "run_id": run_id,
            "message": message,
        })
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/training/{run_id}/stop", name="api_training_stop")
async def api_training_stop(run_id: int):
    """훈련 중지 API"""
    try:
        success, message = await jobs.stop_training(run_id)
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "run_id": run_id,
            "message": message,
        })
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/evaluation/start", name="api_evaluation_start")
async def api_evaluation_start(request: schemas.StartEvaluationRequest):
    """평가 시작 API
    
    Request Body:
        model_name: 모델 이름
        simulation: 시뮬레이션 설정 (트랙, 방향, 레이스 타입 등)
        evaluation: 평가 설정 (시도 횟수, 체크포인트, 패널티)
    """
    from physicar.codespaces.deepracer.settings_manager import get_model_status
    
    try:
        model_name = request.model_name
        sim = request.simulation
        eval_cfg = request.evaluation
        
        # 모델 상태 확인 - ready 상태만 평가 가능
        model_status = get_model_status(model_name)
        if model_status != "ready":
            raise HTTPException(
                status_code=400,
                detail=f"Model '{model_name}' is not ready for evaluation. Current status: {model_status}"
            )
        
        # CPU 사전 체크
        can_start, message, _ = jobs.can_start_job(jobs.JobType.EVALUATION)
        if not can_start:
            raise HTTPException(status_code=503, detail=message)
        
        success, message, job_info = await jobs.start_evaluation(
            model_name=model_name,
            track_name=sim.track_id,
            race_type=sim.race_type,
            object_avoidance=sim.object_avoidance.model_dump() if sim.object_avoidance else None,
            number_of_trials=eval_cfg.number_of_trials,
            checkpoint=eval_cfg.checkpoint,
            offtrack_penalty=eval_cfg.offtrack_penalty,
            collision_penalty=eval_cfg.collision_penalty,
        )
        
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "model_name": model_name,
            "run_id": job_info.run_id,
            "redirect_url": f"/pages/models/model?model_name={model_name}#evaluation",
            "message": message,
        })
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/evaluation/{run_id}/stop", name="api_evaluation_stop")
async def api_evaluation_stop(run_id: int):
    """평가 중지 API"""
    try:
        success, message = await jobs.stop_evaluation(run_id)
        if not success:
            raise HTTPException(status_code=500, detail=message)
        
        return JSONResponse({
            "success": True,
            "run_id": run_id,
            "message": message,
        })
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/models/{model_name}/evaluation/status", name="api_evaluation_status")
async def api_evaluation_status(model_name: str, quality: int = STREAM_QUALITY):
    """평가 상태 조회 API - 현재 진행 중인 평가 정보 + 스트림 URL (training/view와 동일 구조)"""
    import re
    import subprocess
    
    try:
        # 1. 먼저 활성 작업에서 찾기
        active_jobs = jobs.get_active_jobs()
        eval_job = None
        for job in active_jobs:
            if job.job_type == jobs.JobType.EVALUATION and job.model_name == model_name:
                eval_job = job
                break
        
        # 2. 활성 작업에 없으면 실행 중인 eval 컨테이너 직접 확인
        run_id = None
        container_name = None
        if eval_job:
            run_id = eval_job.run_id
            container_name = f"deepracer-eval-{run_id}-robomaker-1"
        else:
            # 존재하는 eval 컨테이너 검색 (종료된 것 포함 - docker ps -a)
            # 컨테이너가 완전히 삭제될 때까지 "진행 중"으로 간주
            try:
                result = subprocess.run(
                    ["docker", "ps", "-a", "--format", "{{.Names}}"],
                    capture_output=True, text=True, timeout=5
                )
                for name in result.stdout.strip().split('\n'):
                    if name.startswith('deepracer-eval-') and name.endswith('-robomaker-1'):
                        # 컨테이너의 MODEL_S3_PREFIX로 모델명 확인
                        inspect_result = subprocess.run(
                            ["docker", "inspect", name, "--format", "{{range .Config.Env}}{{println .}}{{end}}"],
                            capture_output=True, text=True, timeout=5
                        )
                        for line in inspect_result.stdout.strip().split('\n'):
                            if line.startswith('MODEL_S3_PREFIX='):
                                prefix = line.split('=', 1)[1]
                                # models/test1 -> test1
                                container_model = prefix.split('/')[-1] if '/' in prefix else prefix
                                if container_model == model_name:
                                    container_name = name
                                    # deepracer-eval-0-robomaker-1 -> 0
                                    match = re.match(r'deepracer-eval-(\d+)-robomaker-1', name)
                                    if match:
                                        run_id = int(match.group(1))
                                    break
                    if container_name:
                        break
            except Exception:
                pass
        
        if not container_name or run_id is None:
            return JSONResponse({
                "running": False,
                "model_name": model_name,
            })
        
        # 컨테이너가 실행 중인지 확인 (스트림 가능 여부)
        container_running = False
        try:
            result = subprocess.run(
                ["docker", "ps", "--format", "{{.Names}}", "--filter", f"name={container_name}"],
                capture_output=True, text=True, timeout=5
            )
            container_running = container_name in result.stdout
        except Exception:
            pass
        
        # 평가 컨테이너에서 포트 조회
        stream_url = None
        try:
            result = subprocess.run(
                ["docker", "ps", "--format", "{{.Ports}}", "--filter", f"name={container_name}"],
                capture_output=True, text=True, timeout=5
            )
            ports_str = result.stdout.strip()
            
            # 포트 추출: "0.0.0.0:8085->8080/tcp"
            port_match = re.search(r'0\.0\.0\.0:(\d+)->8080/tcp', ports_str)
            if port_match:
                port = int(port_match.group(1))
                stream_url = f'/proxy/{port}/stream?topic=/racecar/deepracer/kvs_stream&quality={quality}'
        except Exception:
            pass
        
        return JSONResponse({
            "running": True,
            "model_name": model_name,
            "run_id": run_id,
            "eval_id": eval_job.eval_id if eval_job else None,
            "started_at": eval_job.started_at.isoformat() if eval_job and eval_job.started_at else None,
            "stream_url": stream_url,
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/models/{model_name}/evaluations", name="api_evaluation_list")
async def api_evaluation_list(model_name: str):
    """평가 히스토리 목록 API (MinIO API 사용)"""
    try:
        eval_prefix = f"models/{model_name}/evaluation/"
        client = _get_minio_client()
        
        # 평가 폴더 목록 가져오기 (timestamp 폴더들)
        eval_folders = set()
        for obj in client.list_objects(MINIO_BUCKET, prefix=eval_prefix, recursive=True):
            # models/{model}/evaluation/20260125071646/metrics.json -> 20260125071646
            rel_path = obj.object_name[len(eval_prefix):]
            parts = rel_path.split('/')
            if parts and parts[0].isdigit():
                eval_folders.add(parts[0])
        
        if not eval_folders:
            return JSONResponse({
                "model_name": model_name,
                "evaluations": [],
            })
        
        evaluations = []
        for eval_id in sorted(eval_folders, reverse=True):
            eval_info = {
                "eval_id": eval_id,
                "timestamp": f"{eval_id[:4]}-{eval_id[4:6]}-{eval_id[6:8]} {eval_id[8:10]}:{eval_id[10:12]}:{eval_id[12:14]}",
                "has_params": minio_object_exists(f"{eval_prefix}{eval_id}/evaluation_params.yaml"),
                "has_metrics": minio_object_exists(f"{eval_prefix}{eval_id}/metrics.json"),
                "has_video": minio_object_exists(f"{eval_prefix}{eval_id}/video.mp4"),
                "has_simtrace": minio_object_exists(f"{eval_prefix}{eval_id}/simtrace.csv"),
            }
            
            # 메트릭 상세 정보 포함 (구버전 호환)
            if eval_info["has_metrics"]:
                try:
                    response = client.get_object(MINIO_BUCKET, f"{eval_prefix}{eval_id}/metrics.json")
                    metrics_data = json.loads(response.read().decode('utf-8'))
                    response.close()
                    response.release_conn()
                    
                    if "metrics" in metrics_data and len(metrics_data["metrics"]) > 0:
                        trials = metrics_data["metrics"]
                        eval_info["trial_count"] = len(trials)
                        
                        # 상세 metrics (구버전 호환 형태로 변환)
                        metrics_detail = {
                            "trial": {},
                            "total_lap_time": {},
                            "lap_time": {},
                            "off_track_count": {},
                            "crash_count": {},
                            "trial_status": {},
                        }
                        
                        cumulative_time = 0
                        for i, trial in enumerate(trials):
                            lap_time = trial.get("elapsed_time_in_milliseconds", 0) / 1000
                            cumulative_time += lap_time
                            
                            metrics_detail["trial"][str(i)] = i + 1
                            metrics_detail["lap_time"][str(i)] = lap_time
                            metrics_detail["total_lap_time"][str(i)] = cumulative_time
                            metrics_detail["off_track_count"][str(i)] = trial.get("off_track_count", 0)
                            metrics_detail["crash_count"][str(i)] = trial.get("crash_count", 0)
                            # episode_status: "Lap complete", "In progress", "Off_track", etc.
                            episode_status = trial.get("episode_status", "Unknown")
                            # "Lap complete" -> "Complete" 로 변환
                            if episode_status == "Lap complete":
                                episode_status = "Complete"
                            metrics_detail["trial_status"][str(i)] = episode_status
                        
                        eval_info["metrics"] = metrics_detail
                        
                        # 완주 시간들 계산 (요약용)
                        completion_times = [
                            t.get("elapsed_time_in_milliseconds", 0) / 1000 
                            for t in trials 
                            if t.get("trial_status") == "Complete"
                        ]
                        if completion_times:
                            eval_info["best_time"] = min(completion_times)
                            eval_info["avg_time"] = sum(completion_times) / len(completion_times)
                except:
                    pass
            
            evaluations.append(eval_info)
        
        return JSONResponse({
            "model_name": model_name,
            "evaluations": evaluations,
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/models/{model_name}/evaluation/{eval_id}", name="api_evaluation_detail")
async def api_evaluation_detail(model_name: str, eval_id: str):
    """특정 평가 결과 상세 조회 API (MinIO API 사용)"""
    try:
        eval_prefix = f"models/{model_name}/evaluation/{eval_id}/"
        client = _get_minio_client()
        
        # 평가 폴더 존재 여부 확인
        if not minio_prefix_exists(eval_prefix):
            raise HTTPException(status_code=404, detail=f"Evaluation {eval_id} not found")
        
        result = {
            "model_name": model_name,
            "eval_id": eval_id,
            "timestamp": f"{eval_id[:4]}-{eval_id[4:6]}-{eval_id[6:8]} {eval_id[8:10]}:{eval_id[10:12]}:{eval_id[12:14]}",
        }
        
        # 메트릭 로드
        metrics_key = f"{eval_prefix}metrics.json"
        if minio_object_exists(metrics_key):
            try:
                response = client.get_object(MINIO_BUCKET, metrics_key)
                result["metrics"] = json.loads(response.read().decode('utf-8'))
                response.close()
                response.release_conn()
            except:
                pass
        
        # simtrace 파일 확인 (단순화된 구조: simtrace.csv)
        if minio_object_exists(f"{eval_prefix}simtrace.csv"):
            result["simtrace_files"] = ["simtrace.csv"]
        
        # video 파일 확인 (단순화된 구조: video.mp4)
        if minio_object_exists(f"{eval_prefix}video.mp4"):
            result["video_files"] = ["video.mp4"]
        
        return JSONResponse(result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/jobs/stop-all", name="api_stop_all_jobs")
async def api_stop_all_jobs():
    """모든 작업 중지 API"""
    try:
        results = await jobs.stop_all_jobs()
        return JSONResponse({
            "status": "success",
            "results": results,
        })
    except Exception as e:
        return JSONResponse({
            "status": "error",
            "error": str(e),
        }, status_code=500)


@app.post("/api/system/cleanup", name="api_cleanup_containers")
async def api_cleanup_containers():
    """고아 컨테이너 수동 정리 API"""
    try:
        count = await jobs.cleanup_orphaned_containers()
        return JSONResponse({
            "status": "success",
            "cleaned": count,
            "message": f"{count} orphaned containers removed",
        })
    except Exception as e:
        return JSONResponse({
            "status": "error",
            "error": str(e),
        }, status_code=500)


# ============ Proxy ============


async def stream_proxy(url: str, method: str, headers: dict, body: bytes):
    """스트리밍 프록시 - upstream 끊기면 자동 재연결.
    
    MJPEG 스트림에서 upstream(web_video_server)이 데이터를 보내지 않으면
    (장면 전환 등) 프록시가 자동으로 재연결을 시도한다.
    브라우저에는 하나의 연속 스트림으로 보이므로 끊김/깜빡임 없음.
    """
    import asyncio
    max_reconnects = 30
    reconnect_delay = 1.0
    
    for attempt in range(max_reconnects):
        try:
            timeout = aiohttp.ClientTimeout(total=None, sock_read=3)
            async with http_session.request(
                method=method,
                url=url,
                headers=headers,
                data=body if body else None,
                timeout=timeout,
            ) as response:
                async for chunk in response.content.iter_chunked(8192):
                    if chunk:
                        yield chunk
        except asyncio.TimeoutError:
            # upstream에서 3초간 데이터 없음 → 재연결 시도
            await asyncio.sleep(reconnect_delay)
            continue
        except (aiohttp.ClientConnectorError, aiohttp.ClientError):
            # upstream 연결 실패 → 잠시 대기 후 재연결
            await asyncio.sleep(reconnect_delay)
            continue
        except asyncio.CancelledError:
            # 클라이언트가 연결 끊음 (탭 닫기 등)
            return
        except Exception:
            return
        else:
            # 정상 종료 (upstream이 연결을 깨끗하게 닫음) → 재연결
            await asyncio.sleep(reconnect_delay)
            continue


@app.api_route("/proxy/{port:int}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
@app.api_route("/proxy/{port:int}/", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
@app.api_route("/proxy/{port:int}/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
async def proxy(port: int, request: Request, path: str = ""):
    """
    /proxy/8080/stream?topic=xxx 
    → http://localhost:8080/stream?topic=xxx 로 프록시
    """
    # 대상 URL 구성
    target_url = f"http://localhost:{port}/{path}"
    if request.query_params:
        target_url += f"?{request.query_params}"
    
    # 요청 헤더 필터링
    headers = {}
    skip_headers = {"host", "content-length", "transfer-encoding", "connection"}
    for key, value in request.headers.items():
        if key.lower() not in skip_headers:
            headers[key] = value
    
    body = await request.body()
    
    try:
        # HEAD 요청인 경우 - 원본 서버의 헤더를 그대로 전달
        if request.method == "HEAD":
            async with http_session.request(
                method="HEAD",
                url=target_url,
                headers=headers,
            ) as resp:
                # 중요한 헤더들 전달 (비디오 재생에 필요)
                response_headers = {}
                for h in ["content-length", "content-type", "accept-ranges", "etag", "last-modified"]:
                    if h in resp.headers:
                        response_headers[h] = resp.headers[h]
                response_headers["Access-Control-Allow-Origin"] = "*"
                
                return Response(
                    content=b"",
                    status_code=resp.status,
                    headers=response_headers,
                )
        
        # GET 요청 - 먼저 content-type 확인 (MJPEG 스트림 여부)
        if request.method == "GET":
            async with http_session.request(
                method="HEAD",
                url=target_url,
                headers=headers,
            ) as head_resp:
                content_type = head_resp.headers.get("content-type", "")
            
            # MJPEG 스트림인 경우 - 스트리밍 응답
            if "multipart/x-mixed-replace" in content_type:
                return StreamingResponse(
                    stream_proxy(target_url, request.method, headers, body),
                    status_code=200,
                    media_type=content_type,
                    headers={
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        "Pragma": "no-cache",
                        "Access-Control-Allow-Origin": "*",
                    },
                )
        
        # 일반 응답
        async with http_session.request(
            method=request.method,
            url=target_url,
            headers=headers,
            data=body if body else None,
        ) as resp:
            content = await resp.read()
            resp_content_type = resp.headers.get("content-type", "")
            
            # 응답 헤더 구성 (비디오 재생에 필요한 헤더 포함)
            response_headers = {"Access-Control-Allow-Origin": "*"}
            for h in ["accept-ranges", "content-range", "etag", "last-modified"]:
                if h in resp.headers:
                    response_headers[h] = resp.headers[h]
            
            # HTML 응답인 경우 링크 경로 rewrite
            if "text/html" in resp_content_type:
                try:
                    html = content.decode("utf-8")
                    # 절대 경로를 /proxy/{port}/... 로 변환
                    import re
                    base_path = f"/proxy/{port}"
                    # href="/" src="/" action="/"
                    html = re.sub(r'(href|src|action)="/', rf'\1="{base_path}/', html)
                    html = re.sub(r"(href|src|action)='/", rf"\1='{base_path}/", html)
                    content = html.encode("utf-8")
                except:
                    pass
            
            return Response(
                content=content,
                status_code=resp.status,
                media_type=resp_content_type,
                headers=response_headers,
            )
            
    except aiohttp.ClientConnectorError:
        return Response(
            content=f"Cannot connect to localhost:{port}",
            status_code=502,
        )
    except Exception as e:
        return Response(
            content=f"Proxy error: {str(e)}",
            status_code=500,
        )