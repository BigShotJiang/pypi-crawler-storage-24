from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class TextContent:
    text: str
    type: str = "text"


@dataclass
class ImageContent:
    mime: str
    base64: str
    type: str = "image"


@dataclass
class ToolCall:
    call_id: str
    name: str
    arguments: Dict[str, Any]


@dataclass
class ToolCallOutput:
    call_id: str
    contents: List[Any]


@dataclass
class UserMessage:
    contents: List[Any] = field(default_factory=list)
    tool_call_outputs: Optional[List[ToolCallOutput]] = None

    def to_dict(self) -> dict:
        d: dict = {"contents": []}
        for c in self.contents:
            if isinstance(c, (TextContent, ImageContent)):
                d["contents"].append({"type": c.type, **({"text": c.text} if isinstance(c, TextContent) else {"mime": c.mime, "base64": c.base64})})
            elif isinstance(c, dict):
                d["contents"].append(c)
        if self.tool_call_outputs:
            d["tool_call_outputs"] = [
                {"call_id": o.call_id, "contents": o.contents} if isinstance(o, ToolCallOutput) else o
                for o in self.tool_call_outputs
            ]
        return d


@dataclass
class ChatResponse:
    chat_id: str
    turn: int
    text: Optional[str]
    tool_calls: List[ToolCall]
    usage: Any  # number (credits) or dict (token counts)

    @classmethod
    def from_dict(cls, data: dict) -> "ChatResponse":
        tool_calls = [
            ToolCall(call_id=tc["call_id"], name=tc["name"], arguments=tc["arguments"])
            for tc in data.get("tool_calls", [])
        ]
        return cls(
            chat_id=data["chat_id"],
            turn=data["turn"],
            text=data.get("text"),
            tool_calls=tool_calls,
            usage=data.get("usage"),
        )


@dataclass
class StreamEvent:
    type: str
    content: Optional[str] = None
    call_id: Optional[str] = None
    name: Optional[str] = None
    arguments: Optional[Dict[str, Any]] = None
    # done event fields
    usage: Optional[Any] = None
    full_text: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    chat_id: Optional[str] = None
    turn: Optional[int] = None


@dataclass
class Prompt:
    instructions: Optional[str] = None
    tools: Optional[List[dict]] = None
    model: Optional[str] = None
    reasoning_effort: Optional[str] = None
    temperature: Optional[float] = None
    max_completion_tokens: Optional[int] = None
    high_resolution_last_n: Optional[int] = None

    def to_dict(self) -> dict:
        d = {}
        for k in ("instructions", "tools", "model", "reasoning_effort", "temperature", "max_completion_tokens", "high_resolution_last_n"):
            v = getattr(self, k)
            if v is not None:
                d[k] = v
        return d


@dataclass
class User:
    user_id: int
    email: str
    display_name: Optional[str]
    email_verified: Optional[bool] = None
    role: Optional[str] = None
    created_at: Optional[str] = None
