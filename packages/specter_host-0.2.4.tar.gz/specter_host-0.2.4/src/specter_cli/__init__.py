"""specter-host: Transparent remote GPU execution.

Run ``python train.py`` on cloud GPUs as if they were local.

Programmatic API::

    import specter_cli as specter

    specter.install("h100")      # provision GPU, no-op if already active
    specter.uninstall()          # terminate session
    info = specter.status()      # session info or None

    with specter.gpu("h100"):    # context manager for auto-cleanup
        ...
"""

__version__ = "0.2.4"

# Re-export programmatic API at package level so users can write:
#   import specter_cli as specter; specter.install("h100")
# or via the "specter" alias if they set one up.
from specter_cli.api import (
    AuthError,
    ProvisionError,
    SpecterError,
    gpu,
    install,
    status,
    uninstall,
)

__all__ = [
    "AuthError",
    "ProvisionError",
    "SpecterError",
    "__version__",
    "gpu",
    "install",
    "status",
    "uninstall",
]
