"""Client-facing helpers for validating Authlix keys."""

from __future__ import annotations

from typing import Any, Dict, Optional

import requests

from .crypto import encrypt_hwid, make_anti_replay_params, verify_signature
from .environment import collect_environment_metadata, get_machine_fingerprint, get_public_ip
from .exceptions import ApiError, OfflineTokenError, SignatureVerificationError


class LicenseClient:
    """Simple wrapper for the public validation endpoint.

    Parameters
    ----------
    base_url:
        Base URL of the Authlix API (e.g. ``"https://authlix.io"``).
    project_id:
        Owning project id, required by ``POST /api/validate_license`` to scope
        licenses per product.
    timeout:
        Optional HTTP timeout in seconds.
    public_key:
        Hex-encoded Ed25519 public key for the project. When provided, HWID is
        encrypted with SealedBox and responses are signature-verified. Can also
        be fetched at runtime with :meth:`fetch_public_key`.
    auto_verify:
        When ``True`` (default) and a public key is available, automatically
        verify the Ed25519 signature on every validation response.
    anti_replay:
        When ``True`` (default) and a public key is available, outgoing
        validation requests include a ``timestamp`` + ``nonce`` pair for
        anti-replay protection.
    """

    def __init__(
        self,
        base_url: str,
        project_id: int,
        timeout: float = 5.0,
        public_key: Optional[str] = None,
        auto_verify: bool = True,
        anti_replay: bool = True,
    ):
        self.base_url = base_url.rstrip('/')
        self.project_id = project_id
        self.timeout = timeout
        self.public_key = public_key
        self.auto_verify = auto_verify
        self.anti_replay = anti_replay

    def _handle_response(self, response: requests.Response) -> Dict:
        if response.status_code >= 400:
            payload: Optional[Dict[str, Any]] = None
            if response.content:
                try:
                    payload = response.json()
                except ValueError:
                    payload = None
            message = (
                payload.get("msg")
                if isinstance(payload, dict) and payload.get("msg")
                else response.text
            )
            raise ApiError(response.status_code, message, payload)
        if response.content:
            try:
                return response.json()
            except ValueError as exc:
                raise ApiError(response.status_code, f"Invalid JSON response: {exc}", None)
        return {}

    def fetch_public_key(self) -> Optional[str]:
        """Fetch and cache the project's Ed25519 public key from the server.

        Returns the hex-encoded public key, or ``None`` if crypto is not
        enabled for the project.
        """
        try:
            response = requests.get(
                f"{self.base_url}/api/projects/{self.project_id}/public_key",
                timeout=self.timeout,
            )
            if response.status_code == 404:
                return None
            data = self._handle_response(response)
            self.public_key = data.get("public_key")
            return self.public_key
        except ApiError:
            return None

    def validate_license(
        self,
        key: str,
        hwid: Optional[str] = None,
        ip: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict:
        """Validate a license key against the public endpoint.

        The request payload matches the backend contract::

            {
                "project_id": 1,
                "key": "XXXX-XXXX-XXXX-XXXX",
                "hwid": "unique-hardware-id"
            }

        ``metadata`` can be supplied to share additional key-value pairs, but it
        must only contain fields flagged as ``client_editable`` in the project
        metadata schema configured by the project manager.
        """

        payload: Dict[str, Any] = {
            "project_id": self.project_id,
            "key": key,
        }
        if hwid:
            if self.public_key:
                payload["hwid_encrypted"] = encrypt_hwid(self.public_key, hwid)
            else:
                payload["hwid"] = hwid
        if ip:
            payload["ip"] = ip
        if metadata:
            payload["metadata"] = metadata
        if self.public_key and self.anti_replay:
            payload.update(make_anti_replay_params())

        response = requests.post(
            f"{self.base_url}/api/validate_license",
            json=payload,
            timeout=self.timeout,
        )
        result = self._handle_response(response)

        if self.public_key and self.auto_verify and result.get("signature"):
            verify_signature(self.public_key, result)

        return result

    def validate_with_environment(self, key: str, extra_metadata: Optional[Dict[str, Any]] = None) -> Dict:
        """Validate a key while auto-populating the machine fingerprint as HWID.

        The public IP is captured automatically server-side, no need to send it.
        Only extra_metadata with client_editable fields can be provided.
        """

        hwid = get_machine_fingerprint()

        return self.validate_license(
            key=key,
            hwid=hwid,
            metadata=extra_metadata if extra_metadata else None,
        )

    def update_client_metadata(self, key: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Update client-editable metadata fields for a specific key.

        Parameters
        ----------
        key:
            License key to mutate.
        metadata:
            Non-empty dictionary of ``client_editable`` fields to update.
        """

        if not isinstance(self.project_id, int):
            raise ValueError("project_id must be an integer")
        if not isinstance(metadata, dict) or not metadata:
            raise ValueError("metadata must be a non-empty dictionary")

        payload = {
            "project_id": self.project_id,
            "key": key,
            "metadata": metadata,
        }
        response = requests.post(
            f"{self.base_url}/api/client_metadata",
            json=payload,
            timeout=self.timeout,
        )
        return self._handle_response(response)

    @staticmethod
    def get_default_hwid() -> str:
        return get_machine_fingerprint()

    @staticmethod
    def get_default_ip() -> Optional[str]:
        return get_public_ip()

    @staticmethod
    def verify_offline_token_locally(
        token: Dict[str, Any],
        public_key_hex: str,
    ) -> bool:
        """Verify a signed offline activation token without a server call.

        Uses the project's Ed25519 public key to verify the token signature,
        then checks the expiry date. This is the recommended approach for
        offline environments where no network call is possible.

        Parameters
        ----------
        token:
            The token dict as returned by
            :meth:`~authlix.manager.ManagerClient.issue_offline_token`
            (the ``token`` key in the response).
        public_key_hex:
            Hex-encoded Ed25519 public key for the project. Obtain once via
            :meth:`fetch_public_key` and cache it in your application.

        Returns
        -------
        ``True`` if the signature is valid and the token has not expired.

        Raises
        ------
        OfflineTokenError:
            If the token is missing required fields, has an invalid signature,
            or has expired.
        """
        from datetime import datetime, timezone as _tz

        required = {
            "token_id", "license_id", "license_key", "project_id",
            "machine_hash", "issued_at", "expires_at", "signature",
        }
        missing = required - set(token.keys())
        if missing:
            raise OfflineTokenError(f"Token missing required fields: {missing}")

        try:
            verify_signature(public_key_hex, token)
        except SignatureVerificationError as exc:
            raise OfflineTokenError(f"Invalid token signature: {exc}") from exc

        expires_raw = token["expires_at"]
        try:
            expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
        except (ValueError, AttributeError) as exc:
            raise OfflineTokenError(f"Invalid expires_at format: {expires_raw!r}") from exc

        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=_tz.utc)

        if datetime.now(_tz.utc) > expires_at:
            raise OfflineTokenError("Offline token has expired")

        return True
