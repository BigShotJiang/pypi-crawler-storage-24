"""Manager-side client for Authlix operations."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import requests

from .exceptions import ApiError, AuthenticationError, BadRequestError, ForbiddenError, NotFoundError, QuotaExceededError, OfflineTokenError


class ManagerClient:
    def __init__(self, base_url: str, token: Optional[str] = None, timeout: float = 5.0):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.token = token

    # --- Auth helpers ---
    def authenticate(
        self,
        username: str,
        *,
        password: Optional[str] = None,
        api_key: Optional[str] = None,
        hcaptcha_token: Optional[str] = None,
    ) -> str:
        if not username:
            raise AuthenticationError("username is required")
        if (password is None and api_key is None) or (password is not None and api_key is not None):
            raise AuthenticationError("Provide exactly one of password or api_key")

        payload: Dict[str, Any] = {"username": username}
        if password is not None:
            payload["password"] = password
            if hcaptcha_token is not None:
                payload["hcaptcha_token"] = hcaptcha_token
        else:
            payload["api_key"] = api_key

        response = requests.post(
            f"{self.base_url}/api/login",
            json=payload,
            timeout=self.timeout,
        )
        if response.status_code != 200:
            message = "Invalid credentials"
            try:
                data = response.json()
            except ValueError:
                data = None
            if isinstance(data, dict) and data.get("msg"):
                message = data["msg"]
            raise AuthenticationError(message)
        token = response.json().get("access_token")
        if not token:
            raise AuthenticationError("Unable to retrieve access token")
        self.token = token
        return token

    def _headers(self) -> Dict[str, str]:
        if not self.token:
            raise AuthenticationError("JWT token missing. Call authenticate() first or set token.")
        return {"Authorization": f"Bearer {self.token}"}

    def _request(self, method: str, path: str, require_auth: bool = True, **kwargs):
        headers = kwargs.pop('headers', {})
        if require_auth:
            headers.update(self._headers())
        response = requests.request(
            method,
            f"{self.base_url}{path}",
            headers=headers,
            timeout=self.timeout,
            **kwargs,
        )
        if response.status_code >= 400:
            payload = None
            if response.content:
                try:
                    payload = response.json()
                except ValueError:
                    payload = None
            message = (
                payload.get("msg")
                if isinstance(payload, dict) and payload.get("msg")
                else response.text
            )
            # Raise specific exceptions for common error codes
            if response.status_code == 400:
                raise BadRequestError(message, payload)
            elif response.status_code == 403:
                raise ForbiddenError(message, payload)
            elif response.status_code == 404:
                raise NotFoundError(message, payload)
            elif response.status_code == 429:
                raise QuotaExceededError(message, payload)
            else:
                raise ApiError(response.status_code, message, payload)
        if response.content:
            return response.json()
        return None

    # --- Project helpers ---
    def list_projects(self) -> List[Dict]:
        return self._request('GET', '/api/projects')

    def create_project(self, name: str, description: Optional[str] = None) -> Dict:
        payload: Dict[str, Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        return self._request('POST', '/api/projects', json=payload)

    def add_project_manager(self, project_id: int, username: str) -> Dict:
        payload = {"username": username}
        return self._request('POST', f'/api/projects/{project_id}/add_manager', json=payload)

    def update_metadata_schema(self, project_id: int, fields: List[Dict[str, Any]]) -> Dict:
        return self._request('PUT', f'/api/projects/{project_id}/metadata_fields', json={"fields": fields})

    def list_licenses(self, project_id: int) -> List[Dict]:
        """List licenses for a project.

        The backend returns paginated payloads in the form
        ``{"items": [...], ...}``. This helper keeps backward compatibility by
        returning only the list of licenses.
        """
        data = self._request('GET', f'/api/projects/{project_id}/licenses')
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and isinstance(data.get('items'), list):
            return data['items']
        raise ApiError(500, "Unexpected licenses payload format", {"payload": data})

    def get_license_by_key(self, project_id: int, license_key: str) -> Dict:
        """Retrieve a single license by its key.

        This is more efficient than fetching all licenses when you only need
        to look up one license by its key. The key is automatically converted
        to uppercase to avoid case mismatches.

        Parameters
        ----------
        project_id:
            The project ID that owns the license.
        license_key:
            The license key to look up (e.g., "CL-XXXX-XXXX").

        Returns
        -------
        Dict containing the license data.

        Raises
        ------
        BadRequestError:
            If the key parameter is missing or invalid (HTTP 400).
        ForbiddenError:
            If the token doesn't have access to this project (HTTP 403).
        NotFoundError:
            If the license key doesn't exist in the project (HTTP 404).
        """
        # Convert key to uppercase to avoid case mismatches
        normalized_key = license_key.upper()
        return self._request('GET', f'/api/projects/{project_id}/licenses/by_key?key={normalized_key}')

    def create_license(
        self,
        project_id: int,
        days_valid: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        *,
        max_activations: Optional[int] = None,
        max_devices: Optional[int] = None,
    ) -> Dict:
        payload: Dict[str, object] = {}
        if days_valid is not None:
            payload['days_valid'] = days_valid
        if metadata is not None:
            payload['metadata'] = metadata
        if max_activations is not None:
            payload['max_activations'] = max_activations
        if max_devices is not None:
            payload['max_devices'] = max_devices
            payload['metadata'] = metadata
        return self._request('POST', f'/api/projects/{project_id}/licenses', json=payload)

    def update_license(
        self,
        license_id: int,
        *,
        is_active: Optional[bool] = None,
        expires_at: Optional[str] = None,
        reset_hwid: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
        max_activations: Optional[int] = None,
        max_devices: Optional[int] = None,
        grace_until: Optional[str] = None,
    ) -> Dict:
        payload: Dict[str, object] = {}
        if is_active is not None:
            payload['is_active'] = is_active
        if expires_at is not None:
            payload['expires_at'] = expires_at
        if reset_hwid:
            payload['reset_hwid'] = True
        if metadata is not None:
            payload['metadata'] = metadata
        if max_activations is not None:
            payload['max_activations'] = max_activations
        if max_devices is not None:
            payload['max_devices'] = max_devices
        if grace_until is not None:
            payload['grace_until'] = grace_until
        return self._request('PUT', f'/api/licenses/{license_id}', json=payload)

    def extend_license(self, project_id: int, license_id: int, days: int) -> Dict:
        """Convenience helper to push expiration forward by *days*."""

        licenses = self.list_licenses(project_id)
        license_data = next((lic for lic in licenses if lic['id'] == license_id), None)
        if not license_data:
            raise ApiError(404, f"License {license_id} not found in project {project_id}", {})

        expires_at = license_data.get('expires_at')
        if not expires_at:
            raise ApiError(400, "License is lifetime; set an explicit expiration first", {})

        try:
            current_exp = datetime.fromisoformat(expires_at)
        except ValueError as exc:
            raise ApiError(500, f"Invalid expiration format: {expires_at}", {"error": str(exc)})

        new_expiration = (current_exp + timedelta(days=days)).date().isoformat()
        return self.update_license(license_id, expires_at=new_expiration)

    def delete_license(self, license_id: int) -> Dict:
        return self._request('DELETE', f'/api/licenses/{license_id}')

    # --- API key helpers ---
    def list_api_keys(self) -> List[Dict[str, Any]]:
        return self._request('GET', '/api/api_keys')

    def create_api_key(
        self,
        label: str,
        *,
        project_ids: Optional[List[int]] = None,
        allow_all_projects: bool = False,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create an API key.

        Parameters
        ----------
        label:
            Human-readable name for the key.
        project_ids:
            Restrict the key to these project IDs. Mutually exclusive with
            ``allow_all_projects=True``.
        allow_all_projects:
            When ``True`` the key has access to all projects owned by the user.
        scopes:
            List of scope strings that limit what the key may do. Use
            :class:`~authlix.scopes.Scopes` constants to avoid typos.
            When omitted the key inherits legacy full-access behaviour.
        """
        payload: Dict[str, Any] = {
            "label": label,
            "allow_all_projects": allow_all_projects,
        }
        if project_ids is not None:
            payload["project_ids"] = project_ids
        if scopes is not None:
            payload["scopes"] = scopes
        return self._request('POST', '/api/api_keys', json=payload)

    def update_api_key(
        self,
        api_key_id: int,
        *,
        label: Optional[str] = None,
        project_ids: Optional[List[int]] = None,
        allow_all_projects: Optional[bool] = None,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if label is not None:
            payload["label"] = label
        if project_ids is not None:
            payload["project_ids"] = project_ids
        if allow_all_projects is not None:
            payload["allow_all_projects"] = allow_all_projects
        if scopes is not None:
            payload["scopes"] = scopes
        if not payload:
            raise ValueError("At least one field must be provided to update an API key")
        return self._request('PUT', f'/api/api_keys/{api_key_id}', json=payload)

    def delete_api_key(self, api_key_id: int) -> Dict[str, Any]:
        return self._request('DELETE', f'/api/api_keys/{api_key_id}')

    def list_project_api_keys(self, project_id: int) -> List[Dict[str, Any]]:
        return self._request('GET', f'/api/projects/{project_id}/api_keys')

    # --- Crypto helpers ---
    def get_public_key(self, project_id: int) -> Dict[str, Any]:
        """Retrieve the project's Ed25519 public key (public endpoint, no auth)."""
        return self._request('GET', f'/api/projects/{project_id}/public_key', require_auth=False)

    def toggle_crypto(self, project_id: int, enabled: bool) -> Dict[str, Any]:
        """Enable or disable cryptographic signing for a project (owner only)."""
        return self._request('PATCH', f'/api/projects/{project_id}/crypto', json={"enabled": enabled})

    def rotate_signing_key(self, project_id: int) -> Dict[str, Any]:
        """Regenerate the project's Ed25519 key pair (owner only).

        WARNING: This invalidates all SDK clients using the old public key.
        """
        return self._request(
            'POST', f'/api/projects/{project_id}/rotate_signing_key',
            json={"confirm": "ROTATE"},
        )

    # --- Webhook helpers ---

    def list_webhooks(self, project_id: int) -> List[Dict[str, Any]]:
        """List all webhook endpoints registered for a project."""
        return self._request('GET', f'/api/projects/{project_id}/webhooks')

    def create_webhook(
        self,
        project_id: int,
        url: str,
        *,
        enabled: bool = True,
    ) -> Dict[str, Any]:
        """Register a new webhook endpoint for a project.

        Parameters
        ----------
        url:
            HTTPS URL to receive event payloads. HTTP is only accepted on
            localhost when the server runs in DEBUG mode.
        enabled:
            Whether the endpoint is active immediately. Defaults to ``True``.

        Returns
        -------
        Dict containing the new webhook record. Includes a one-time ``secret``
        field — store it securely for HMAC-SHA256 signature verification.
        """
        return self._request(
            'POST', f'/api/projects/{project_id}/webhooks',
            json={"url": url, "enabled": enabled},
        )

    def update_webhook(
        self,
        project_id: int,
        webhook_id: int,
        *,
        url: Optional[str] = None,
        enabled: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Update an existing webhook endpoint (URL and/or enabled flag)."""
        payload: Dict[str, Any] = {}
        if url is not None:
            payload["url"] = url
        if enabled is not None:
            payload["enabled"] = enabled
        return self._request('PUT', f'/api/projects/{project_id}/webhooks/{webhook_id}', json=payload)

    def delete_webhook(self, project_id: int, webhook_id: int) -> Dict[str, Any]:
        """Delete a webhook endpoint and all its delivery history."""
        return self._request('DELETE', f'/api/projects/{project_id}/webhooks/{webhook_id}')

    def test_webhook(self, project_id: int, webhook_id: int) -> Dict[str, Any]:
        """Fire a test event to verify the webhook endpoint is reachable."""
        return self._request('POST', f'/api/projects/{project_id}/webhooks/{webhook_id}/test')

    def list_webhook_deliveries(
        self,
        project_id: int,
        webhook_id: int,
    ) -> List[Dict[str, Any]]:
        """Retrieve recent delivery attempts for a webhook endpoint."""
        return self._request('GET', f'/api/projects/{project_id}/webhooks/{webhook_id}/deliveries')

    # --- Audit log helpers ---

    def list_audit_logs(
        self,
        project_id: int,
        *,
        action: Optional[str] = None,
        actor_user_id: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """List audit log entries for a project.

        Parameters
        ----------
        action:
            Filter by event action string (e.g. ``"license.created"``).
        actor_user_id:
            Filter entries to a specific user.
        limit:
            Maximum number of entries to return (server default applies when omitted).
        """
        params: Dict[str, Any] = {}
        if action is not None:
            params["action"] = action
        if actor_user_id is not None:
            params["actor_user_id"] = actor_user_id
        if limit is not None:
            params["limit"] = limit
        return self._request('GET', f'/api/projects/{project_id}/audit_logs', params=params)

    def export_audit_logs(
        self,
        project_id: int,
        fmt: str = 'csv',
    ) -> bytes:
        """Export audit logs as a file download.

        Parameters
        ----------
        fmt:
            Export format — ``"csv"`` (default) or ``"json"``.

        Returns
        -------
        Raw bytes of the exported file. Write them to a ``.csv`` or ``.json``
        file as appropriate::

            data = mgr.export_audit_logs(project_id, fmt='csv')
            Path('audit.csv').write_bytes(data)
        """
        if not self.token:
            from .exceptions import AuthenticationError
            raise AuthenticationError("JWT token missing. Call authenticate() first or set token.")
        import requests as _requests
        response = _requests.get(
            f"{self.base_url}/api/projects/{project_id}/audit_logs/export",
            params={"format": fmt},
            headers=self._headers(),
            timeout=self.timeout,
        )
        if response.status_code >= 400:
            payload = None
            if response.content:
                try:
                    payload = response.json()
                except ValueError:
                    payload = None
            message = (
                payload.get("msg")
                if isinstance(payload, dict) and payload.get("msg")
                else response.text
            )
            raise ApiError(response.status_code, message, payload)
        return response.content

    # --- Quota / Usage helpers ---

    def get_quota_policy(self, project_id: int) -> Dict[str, Any]:
        """Retrieve the project-level default quota policy.

        Returns a dict with keys: ``max_activations``, ``max_devices``,
        ``rate_limit_per_hour``, ``grace_period_days``.
        """
        return self._request('GET', f'/api/projects/{project_id}/quota_policy')

    def set_quota_policy(
        self,
        project_id: int,
        *,
        max_activations: Optional[int] = None,
        max_devices: Optional[int] = None,
        rate_limit_per_hour: Optional[int] = None,
        grace_period_days: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Set or update the project-level default quota policy.

        New licenses created in this project will inherit these limits.
        Pass ``None`` to remove a limit.
        """
        payload: Dict[str, Any] = {
            'max_activations': max_activations,
            'max_devices': max_devices,
            'rate_limit_per_hour': rate_limit_per_hour,
            'grace_period_days': grace_period_days,
        }
        return self._request('PUT', f'/api/projects/{project_id}/quota_policy', json=payload)

    def set_license_quota(
        self,
        license_id: int,
        *,
        max_activations: Optional[int] = None,
        max_devices: Optional[int] = None,
        rate_limit_per_hour: Optional[int] = None,
        grace_until: Optional[str] = None,
        reset_activation_count: bool = False,
    ) -> Dict[str, Any]:
        """Override quota limits for a specific license.

        Pass ``None`` to remove a limit (inherit from project default).
        """
        payload: Dict[str, Any] = {}
        payload['max_activations'] = max_activations
        payload['max_devices'] = max_devices
        payload['rate_limit_per_hour'] = rate_limit_per_hour
        if grace_until is not None:
            payload['grace_until'] = grace_until
        if reset_activation_count:
            payload['reset_activation_count'] = True
        return self._request('PUT', f'/api/licenses/{license_id}/quota', json=payload)

    def get_usage_summary(self, license_id: int) -> Dict[str, Any]:
        """Retrieve quota and activation usage data for a license.

        Returns a dict with keys: ``activation_count``, ``max_activations``,
        ``device_count``, ``max_devices``, ``rate_limit_per_hour``,
        ``grace_until``, ``last_quota_violation_at``, and ``devices`` (list).
        """
        return self._request('GET', f'/api/licenses/{license_id}/usage_summary')

    def list_devices(self, license_id: int) -> Dict[str, Any]:
        """List all registered devices (HWIDs) for a license.

        Returns a dict with ``devices`` list, ``device_count``, and ``max_devices``.
        Each device has ``id``, ``hwid_hash``, ``hwid_label``, ``first_seen_at``,
        ``last_seen_at``, ``last_ip``.
        """
        return self._request('GET', f'/api/licenses/{license_id}/devices')

    def revoke_device(self, license_id: int, device_id: int) -> Dict[str, Any]:
        """Remove a device from a license, freeing a device slot.

        The device will need to re-activate on next validation.
        """
        return self._request('DELETE', f'/api/licenses/{license_id}/devices/{device_id}')

    # --- Offline activation helpers ---

    def issue_offline_token(
        self,
        license_id: int,
        machine_hash: str,
        *,
        ttl_days: int = 30,
    ) -> Dict[str, Any]:
        """Issue a signed offline activation token for a license.

        The project must have crypto enabled. The returned token dict is
        signed with the project's Ed25519 key and can be verified locally
        using :meth:`~authlix.client.LicenseClient.verify_offline_token_locally`.

        Parameters
        ----------
        machine_hash:
            Stable fingerprint of the target machine (e.g. UUID or hash of
            hardware identifiers).
        ttl_days:
            How long the token remains valid. Defaults to 30 days.
        """
        return self._request(
            'POST', f'/api/licenses/{license_id}/offline/issue',
            json={"machine_hash": machine_hash, "ttl_days": ttl_days},
        )

    def list_offline_tokens(self, license_id: int) -> List[Dict[str, Any]]:
        """List all offline activation tokens issued for a license."""
        return self._request('GET', f'/api/licenses/{license_id}/offline/tokens')

    def revoke_offline_token(
        self,
        license_id: int,
        token_id: str,
        *,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Revoke a previously issued offline token.

        Parameters
        ----------
        token_id:
            UUID of the token as returned in the ``token_id`` field.
        reason:
            Optional human-readable reason for the revocation (max 255 chars).
        """
        payload: Dict[str, Any] = {"token_id": token_id}
        if reason is not None:
            payload["reason"] = reason
        return self._request(
            'POST', f'/api/licenses/{license_id}/offline/revoke',
            json=payload,
        )
