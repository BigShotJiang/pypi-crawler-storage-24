"""Official Authlix helper library.

This package exposes two primary interfaces:

- :class:`authlix.client.LicenseClient` for end-users validating licenses
- :class:`authlix.manager.ManagerClient` for operators managing projects

Utility helpers live in :mod:`authlix.environment` for gathering HWID/IP metadata.
API key scope constants are available via :class:`authlix.scopes.Scopes`.
"""

from .client import LicenseClient
from .manager import ManagerClient
from .scopes import Scopes
from .environment import (
    get_machine_fingerprint,
    get_public_ip,
    collect_environment_metadata,
)
from .crypto import (
    encrypt_hwid,
    verify_signature,
    make_anti_replay_params,
)
from .exceptions import (
    AuthlixError,
    AuthenticationError,
    ApiError,
    BadRequestError,
    ForbiddenError,
    NotFoundError,
    QuotaExceededError,
    OfflineTokenError,
    SignatureVerificationError,
)

__all__ = [
    "LicenseClient",
    "ManagerClient",
    "Scopes",
    "get_machine_fingerprint",
    "get_public_ip",
    "collect_environment_metadata",
    "encrypt_hwid",
    "verify_signature",
    "make_anti_replay_params",
    "AuthlixError",
    "AuthenticationError",
    "ApiError",
    "BadRequestError",
    "ForbiddenError",
    "NotFoundError",
    "QuotaExceededError",
    "OfflineTokenError",
    "SignatureVerificationError",
]
