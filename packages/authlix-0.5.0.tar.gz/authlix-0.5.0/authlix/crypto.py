"""Cryptographic helpers for response verification and HWID encryption."""

from __future__ import annotations

import base64
import json
import secrets
import time
from typing import Any, Dict, Optional

from nacl.public import PublicKey as Curve25519PublicKey, SealedBox
from nacl.signing import VerifyKey

from .exceptions import SignatureVerificationError


def encrypt_hwid(public_key_hex: str, hwid: str) -> str:
    """Encrypt a HWID using the project's Curve25519 public key (derived from Ed25519).

    The server expects a base64-encoded SealedBox ciphertext in ``hwid_encrypted``.
    """
    verify_key = VerifyKey(bytes.fromhex(public_key_hex))
    curve_public = verify_key.to_curve25519_public_key()
    sealed_box = SealedBox(curve_public)
    ciphertext = sealed_box.encrypt(hwid.encode("utf-8"))
    return base64.b64encode(ciphertext).decode("ascii")


def verify_signature(public_key_hex: str, response_payload: Dict[str, Any]) -> bool:
    """Verify an Ed25519 signature on a validation response.

    Returns ``True`` if valid, raises ``SignatureVerificationError`` otherwise.
    """
    signature_hex = response_payload.get("signature")
    if not signature_hex:
        raise SignatureVerificationError("Response does not contain a signature")

    data_to_verify = {k: v for k, v in response_payload.items() if k != "signature"}
    canonical = json.dumps(data_to_verify, sort_keys=True, separators=(",", ":"))

    verify_key = VerifyKey(bytes.fromhex(public_key_hex))
    try:
        verify_key.verify(canonical.encode("utf-8"), bytes.fromhex(signature_hex))
    except Exception as exc:
        raise SignatureVerificationError(f"Invalid signature: {exc}") from exc
    return True


def make_anti_replay_params() -> Dict[str, Any]:
    """Generate timestamp + nonce for anti-replay protection."""
    return {
        "timestamp": int(time.time()),
        "nonce": secrets.token_hex(16),
    }
