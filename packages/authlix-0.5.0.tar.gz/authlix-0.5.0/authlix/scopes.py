"""API key scope constants for Authlix.

Use :class:`Scopes` when creating or updating API keys via :class:`~authlix.manager.ManagerClient`
to take advantage of IDE auto-complete and avoid typos::

    from authlix import ManagerClient, Scopes

    mgr = ManagerClient("https://authlix.io", token="...")
    mgr.create_api_key("ci-key", scopes=[Scopes.LICENSES_READ, Scopes.LICENSES_WRITE])
"""

from __future__ import annotations


class Scopes:
    """Namespace of valid API key scope strings.

    Each attribute maps to a capability that can be granted to an API key.
    Pass a list of these strings to ``create_api_key`` or ``update_api_key``.

    Scope reference
    ---------------
    PROJECTS_READ
        Read project metadata and settings.
    LICENSES_READ
        List and retrieve license records.
    LICENSES_WRITE
        Create, update, and delete licenses.
    LICENSES_VALIDATE
        Call the public validation endpoint on behalf of a key.
    METADATA_WRITE_CLIENT
        Update client-editable metadata fields via ``/api/client_metadata``.
    API_KEYS_READ
        List API keys.
    API_KEYS_WRITE
        Create, update, and revoke API keys.
    WEBHOOKS_READ
        List webhook endpoints and delivery logs.
    WEBHOOKS_WRITE
        Create, update, and delete webhook endpoints.
    AUDIT_READ
        Read audit log entries.
    AUDIT_EXPORT
        Export audit logs as CSV or JSON.
    """

    PROJECTS_READ = "projects:read"
    LICENSES_READ = "licenses:read"
    LICENSES_WRITE = "licenses:write"
    LICENSES_VALIDATE = "licenses:validate"
    METADATA_WRITE_CLIENT = "metadata:write_client"
    API_KEYS_READ = "api_keys:read"
    API_KEYS_WRITE = "api_keys:write"
    WEBHOOKS_READ = "webhooks:read"
    WEBHOOKS_WRITE = "webhooks:write"
    AUDIT_READ = "audit:read"
    AUDIT_EXPORT = "audit:export"

    #: Frozenset of all valid scope strings — useful for validation.
    ALL: frozenset = frozenset({
        PROJECTS_READ,
        LICENSES_READ,
        LICENSES_WRITE,
        LICENSES_VALIDATE,
        METADATA_WRITE_CLIENT,
        API_KEYS_READ,
        API_KEYS_WRITE,
        WEBHOOKS_READ,
        WEBHOOKS_WRITE,
        AUDIT_READ,
        AUDIT_EXPORT,
    })
