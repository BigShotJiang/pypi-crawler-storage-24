"""Tests for crypto module — encrypt_hwid, verify_signature, anti-replay."""

import json
import time

import pytest
from nacl.public import SealedBox
from nacl.signing import SigningKey

from authlix.crypto import encrypt_hwid, make_anti_replay_params, verify_signature
from authlix.exceptions import SignatureVerificationError


@pytest.fixture()
def keypair():
    """Generate a fresh Ed25519 keypair and return (private_hex, public_hex)."""
    sk = SigningKey.generate()
    private_hex = sk.encode().hex()
    public_hex = sk.verify_key.encode().hex()
    return private_hex, public_hex


# --- encrypt_hwid ---

def test_encrypt_hwid_roundtrip(keypair):
    private_hex, public_hex = keypair
    hwid = "test-machine-fingerprint-abc123"
    encrypted_b64 = encrypt_hwid(public_hex, hwid)

    # Decrypt server-side (same logic as the backend)
    import base64
    sk = SigningKey(bytes.fromhex(private_hex))
    curve_private = sk.to_curve25519_private_key()
    sealed_box = SealedBox(curve_private)
    plaintext = sealed_box.decrypt(base64.b64decode(encrypted_b64))
    assert plaintext.decode("utf-8") == hwid


def test_encrypt_hwid_different_each_call(keypair):
    _, public_hex = keypair
    a = encrypt_hwid(public_hex, "same")
    b = encrypt_hwid(public_hex, "same")
    # SealedBox is non-deterministic (ephemeral key)
    assert a != b


# --- verify_signature ---

def _sign_payload(private_hex: str, payload: dict) -> str:
    """Reproduce the server's signing logic."""
    sk = SigningKey(bytes.fromhex(private_hex))
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    signed = sk.sign(canonical.encode("utf-8"))
    return signed.signature.hex()


def test_verify_signature_valid(keypair):
    private_hex, public_hex = keypair
    payload = {"valid": True, "expires_at": "2026-12-31", "metadata": {}, "nonce": "abc", "timestamp": 1234}
    sig = _sign_payload(private_hex, payload)
    payload["signature"] = sig
    assert verify_signature(public_hex, payload) is True


def test_verify_signature_tampered(keypair):
    private_hex, public_hex = keypair
    payload = {"valid": True, "expires_at": "2026-12-31", "metadata": {}, "nonce": "abc", "timestamp": 1234}
    sig = _sign_payload(private_hex, payload)
    payload["signature"] = sig
    payload["valid"] = False  # tamper
    with pytest.raises(SignatureVerificationError, match="Invalid signature"):
        verify_signature(public_hex, payload)


def test_verify_signature_missing(keypair):
    _, public_hex = keypair
    with pytest.raises(SignatureVerificationError, match="does not contain a signature"):
        verify_signature(public_hex, {"valid": True})


def test_verify_signature_wrong_key(keypair):
    private_hex, _ = keypair
    other_pk = SigningKey.generate().verify_key.encode().hex()
    payload = {"valid": True, "nonce": "x", "timestamp": 0}
    sig = _sign_payload(private_hex, payload)
    payload["signature"] = sig
    with pytest.raises(SignatureVerificationError):
        verify_signature(other_pk, payload)


# --- make_anti_replay_params ---

def test_anti_replay_params_structure():
    params = make_anti_replay_params()
    assert "timestamp" in params
    assert "nonce" in params
    assert isinstance(params["timestamp"], int)
    assert isinstance(params["nonce"], str)
    assert len(params["nonce"]) == 32  # 16 bytes hex


def test_anti_replay_timestamp_recent():
    params = make_anti_replay_params()
    assert abs(params["timestamp"] - int(time.time())) <= 2


def test_anti_replay_nonces_unique():
    a = make_anti_replay_params()["nonce"]
    b = make_anti_replay_params()["nonce"]
    assert a != b
