"""Tests for LicenseClient crypto integration and ManagerClient crypto endpoints."""

import json
from unittest.mock import MagicMock, patch

import pytest
from nacl.signing import SigningKey

from authlix.client import LicenseClient
from authlix.manager import ManagerClient
from authlix.exceptions import SignatureVerificationError


@pytest.fixture()
def keypair():
    sk = SigningKey.generate()
    return sk.encode().hex(), sk.verify_key.encode().hex()


def _make_signed_response(private_hex, payload_without_sig):
    """Build a response dict with a valid signature."""
    sk = SigningKey(bytes.fromhex(private_hex))
    canonical = json.dumps(payload_without_sig, sort_keys=True, separators=(",", ":"))
    sig = sk.sign(canonical.encode("utf-8")).signature.hex()
    return {**payload_without_sig, "signature": sig}


# --- LicenseClient tests ---

class TestLicenseClientCrypto:
    def test_validate_encrypts_hwid_when_public_key_set(self, keypair):
        private_hex, public_hex = keypair
        client = LicenseClient("https://example.com", project_id=1, public_key=public_hex)

        body = _make_signed_response(private_hex, {
            "valid": True, "expires_at": "2026-12-31",
            "metadata": {}, "nonce": "abc", "timestamp": 1234,
        })

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = body

        with patch("authlix.client.requests.post", return_value=mock_resp) as mock_post:
            result = client.validate_license("KEY-123", hwid="my-hwid")

        call_payload = mock_post.call_args.kwargs["json"]
        assert "hwid_encrypted" in call_payload
        assert "hwid" not in call_payload
        assert "timestamp" in call_payload
        assert "nonce" in call_payload
        assert result["valid"] is True

    def test_validate_sends_plaintext_hwid_without_key(self):
        client = LicenseClient("https://example.com", project_id=1)

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"valid": True}

        with patch("authlix.client.requests.post", return_value=mock_resp) as mock_post:
            client.validate_license("KEY-123", hwid="my-hwid")

        call_payload = mock_post.call_args.kwargs["json"]
        assert call_payload["hwid"] == "my-hwid"
        assert "hwid_encrypted" not in call_payload
        assert "timestamp" not in call_payload

    def test_validate_raises_on_bad_signature(self, keypair):
        _, public_hex = keypair
        other_sk = SigningKey.generate()
        other_private = other_sk.encode().hex()

        client = LicenseClient("https://example.com", project_id=1, public_key=public_hex)

        body = _make_signed_response(other_private, {
            "valid": True, "expires_at": "2026-12-31",
            "metadata": {}, "nonce": "abc", "timestamp": 1234,
        })

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = body

        with patch("authlix.client.requests.post", return_value=mock_resp):
            with pytest.raises(SignatureVerificationError):
                client.validate_license("KEY-123")

    def test_validate_skips_verify_when_auto_verify_off(self, keypair):
        _, public_hex = keypair
        other_sk = SigningKey.generate()

        client = LicenseClient("https://example.com", project_id=1, public_key=public_hex, auto_verify=False)

        body = _make_signed_response(other_sk.encode().hex(), {
            "valid": True, "metadata": {}, "nonce": "x", "timestamp": 0,
        })

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = body

        with patch("authlix.client.requests.post", return_value=mock_resp):
            result = client.validate_license("KEY-123")
        assert result["valid"] is True

    def test_validate_no_anti_replay_when_disabled(self, keypair):
        _, public_hex = keypair
        client = LicenseClient("https://example.com", project_id=1, public_key=public_hex, anti_replay=False)

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"valid": True}

        with patch("authlix.client.requests.post", return_value=mock_resp) as mock_post:
            client.validate_license("KEY-123")

        call_payload = mock_post.call_args.kwargs["json"]
        assert "timestamp" not in call_payload
        assert "nonce" not in call_payload

    def test_fetch_public_key_success(self, keypair):
        _, public_hex = keypair
        client = LicenseClient("https://example.com", project_id=1)

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"public_key": public_hex, "project_id": 1}

        with patch("authlix.client.requests.get", return_value=mock_resp):
            key = client.fetch_public_key()

        assert key == public_hex
        assert client.public_key == public_hex

    def test_fetch_public_key_not_enabled(self):
        client = LicenseClient("https://example.com", project_id=1)

        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"msg": "not enabled"}

        with patch("authlix.client.requests.get", return_value=mock_resp):
            key = client.fetch_public_key()

        assert key is None
        assert client.public_key is None


# --- ManagerClient tests ---

class TestManagerClientCrypto:
    def test_authenticate_password_includes_hcaptcha_token(self):
        manager = ManagerClient("https://example.com")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"access_token": "jwt-token"}

        with patch("authlix.manager.requests.post", return_value=mock_resp) as mock_post:
            token = manager.authenticate("alice", password="secret", hcaptcha_token="captcha-token")

        assert token == "jwt-token"
        call_payload = mock_post.call_args.kwargs.get("json", {})
        assert call_payload["username"] == "alice"
        assert call_payload["password"] == "secret"
        assert call_payload["hcaptcha_token"] == "captcha-token"

    def test_list_licenses_returns_items_from_paginated_payload(self):
        manager = ManagerClient("https://example.com", token="tok")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {
            "items": [{"id": 1, "key": "ABCD"}],
            "total": 1,
            "pages": 1,
            "current_page": 1,
        }

        with patch("authlix.manager.requests.request", return_value=mock_resp):
            items = manager.list_licenses(42)

        assert isinstance(items, list)
        assert items[0]["id"] == 1

    def test_get_public_key(self, keypair):
        _, public_hex = keypair
        manager = ManagerClient("https://example.com", token="tok")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"public_key": public_hex, "project_id": 1}

        with patch("authlix.manager.requests.request", return_value=mock_resp) as mock_req:
            result = manager.get_public_key(1)

        assert result["public_key"] == public_hex
        # Should NOT send auth header (public endpoint)
        call_headers = mock_req.call_args.kwargs.get("headers", {})
        assert "Authorization" not in call_headers

    def test_toggle_crypto(self):
        manager = ManagerClient("https://example.com", token="tok")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"msg": "Cryptographic signing enabled", "crypto_enabled": True}

        with patch("authlix.manager.requests.request", return_value=mock_resp) as mock_req:
            result = manager.toggle_crypto(1, True)

        assert result["crypto_enabled"] is True
        _, call_args = mock_req.call_args
        assert mock_req.call_args[0][0] == "PATCH"

    def test_rotate_signing_key(self):
        manager = ManagerClient("https://example.com", token="tok")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.content = b'x'
        mock_resp.json.return_value = {"msg": "Signing key rotated successfully", "signing_public_key": "abc123"}

        with patch("authlix.manager.requests.request", return_value=mock_resp) as mock_req:
            result = manager.rotate_signing_key(1)

        assert result["signing_public_key"] == "abc123"
        call_payload = mock_req.call_args.kwargs.get("json", {})
        assert call_payload == {"confirm": "ROTATE"}
