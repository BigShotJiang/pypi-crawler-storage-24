"""
r_bridge example script — run with: uv run python example.py
"""

import numpy as np
import pandas as pd
from r_bridge import RBridge

with RBridge(verbose=True) as r:
    # ------------------------------------------------------------------
    # 1. Basic scalars and vectors
    # ------------------------------------------------------------------
    print("\n=== Scalars & vectors ===")

    r.x = 42
    r.y = 3.14
    print("x =", r.x)
    print("y =", r.y)

    r.nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    print("sum(nums) =", r.sum(r.nums))
    print("mean(nums) =", r.mean(r.nums))
    print("sd(nums)   =", r.sd(r.nums))

    # ------------------------------------------------------------------
    # 2. Calling R functions with keyword arguments
    # ------------------------------------------------------------------
    print("\n=== Function calls with kwargs ===")

    evens = r.seq(2, 20, by=2)
    print("seq(2, 20, by=2) =", evens)

    pasted = r.paste("hello", "from", "R", sep="-")
    print("paste(..., sep='-') =", pasted)

    # ------------------------------------------------------------------
    # 3. eval() — send arbitrary R expressions
    # ------------------------------------------------------------------
    print("\n=== eval() ===")

    result = r.eval("2 ^ 10")
    print("2 ^ 10 =", result)

    r.eval("greeting <- paste('hi', 'there')")
    print("greeting =", r.get("greeting"))

    # ------------------------------------------------------------------
    # 4. numpy arrays round-trip
    # ------------------------------------------------------------------
    print("\n=== numpy arrays ===")

    arr = np.linspace(0, 1, 6)
    r.arr = arr
    back = r.arr
    print("sent:     ", arr)
    print("received: ", back)

    r.mat = np.array([[1, 2, 3], [4, 5, 6]], dtype=float)
    print("matrix sum =", r.sum(r.mat))

    # ------------------------------------------------------------------
    # 5. pandas DataFrames
    # ------------------------------------------------------------------
    print("\n=== pandas DataFrame ===")

    df = pd.DataFrame(
        {
            "name": ["Alice", "Bob", "Carol"],
            "score": [88.5, 72.0, 95.5],
            "passed": [True, True, True],
        }
    )
    r.df = df
    back_df = r.df
    print(back_df)
    print("R nrow:", r.eval("nrow(df)", result_type_hint="scalar"))
    print("R colnames:", r.eval("colnames(df)", result_type_hint="list"))

    # ------------------------------------------------------------------
    # 6. R stdout and stderr are visible with verbose=True
    # ------------------------------------------------------------------
    print("\n=== R output (see [R stdout] / [R stderr] above) ===")

    r.eval('cat("hello from cat()\\n")')
    r.eval('message("hello from message()")')

    # ------------------------------------------------------------------
    # 7. Capture R warnings
    # ------------------------------------------------------------------
    print("\n=== R warnings ===")

    import math

    val = r.log(-1.0)  # produces NaN + a warning
    print("log(-1) =", val, "(nan:", math.isnan(val), ")")

    # ------------------------------------------------------------------
    # 8. R error handling
    # ------------------------------------------------------------------
    print("\n=== Error handling ===")

    from r_bridge.exceptions import RError

    try:
        r.eval("stop('something went wrong in R')")
    except RError as e:
        print("Caught RError:", e.message)

    print("\nBridge still alive after error:", r.is_alive())

    # ------------------------------------------------------------------
    # 9. execute() — run a multi-line R script, discard return value
    # ------------------------------------------------------------------
    print("\n=== execute() ===")

    r.execute("""
        square <- function(x) x ^ 2
        cubed  <- function(x) x ^ 3
        squares <- sapply(1:5, square)
        cubes   <- sapply(1:5, cubed)
    """)
    print("squares:", r.squares)
    print("cubes:  ", r.cubes)

    # execute() is ideal for defining helpers you then call via r.call()
    r.execute("""
        normalize <- function(v) (v - min(v)) / (max(v) - min(v))
    """)
    print("normalize(1:5):", r.call("normalize", list(range(1, 6))))

    # ------------------------------------------------------------------
    # 10. List R global environment
    # ------------------------------------------------------------------
    print("\n=== Variables in R global env ===")
    print(r.ls())
