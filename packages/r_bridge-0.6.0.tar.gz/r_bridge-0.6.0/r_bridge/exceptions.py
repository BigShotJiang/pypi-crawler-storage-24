class RBridgeError(Exception):
    """Base exception for all r_bridge errors."""


class RStartupError(RBridgeError):
    """R process failed to start or did not send the ready signal in time."""


class RTimeoutError(RBridgeError):
    """A call to R did not complete within the allowed timeout."""


class RProtocolError(RBridgeError):
    """A message from R did not conform to the expected envelope format."""


class RError(RBridgeError):
    """An error was raised on the R side during execution."""

    def __init__(
        self,
        message: str,
        call: str | None = None,
        traceback: list[str] | None = None,
        warnings: list[str] | None = None,
        stderr: str = "",
    ) -> None:
        super().__init__(message)
        self.message = message
        self.call = call
        self.traceback = traceback or []
        self.warnings = warnings or []
        self.stderr = stderr
