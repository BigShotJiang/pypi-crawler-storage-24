from enum import Enum


class TypeHint(Enum):
    SCALAR = "scalar"
    NUMPY = "numpy"
    PANDAS = "pandas"
    LIST = "list"
    RAW = "raw"


def resolve_hint(hint: "str | TypeHint | None") -> "TypeHint | None":
    if hint is None:
        return None
    if isinstance(hint, TypeHint):
        return hint
    try:
        return TypeHint(hint.lower())
    except ValueError:
        raise ValueError(f"Unknown type hint {hint!r}. Valid values: {[h.value for h in TypeHint]}")
