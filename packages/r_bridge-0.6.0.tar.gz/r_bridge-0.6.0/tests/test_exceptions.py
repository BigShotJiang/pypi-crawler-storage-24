from r_bridge.exceptions import (
    RBridgeError,
    RStartupError,
    RTimeoutError,
    RError,
    RProtocolError,
)


def test_hierarchy():
    assert issubclass(RStartupError, RBridgeError)
    assert issubclass(RTimeoutError, RBridgeError)
    assert issubclass(RError, RBridgeError)
    assert issubclass(RProtocolError, RBridgeError)


def test_rerror_fields():
    err = RError(message="object 'x' not found", call="eval(x)", traceback=["line 1"], warnings=["w1"], stderr="some stderr")
    assert err.message == "object 'x' not found"
    assert err.call == "eval(x)"
    assert err.traceback == ["line 1"]
    assert err.warnings == ["w1"]
    assert err.stderr == "some stderr"
    assert "object 'x' not found" in str(err)


def test_rerror_defaults():
    err = RError(message="oops")
    assert err.call is None
    assert err.traceback == []
    assert err.warnings == []
    assert err.stderr == ""


def test_catchable_as_base():
    with __import__("pytest").raises(RBridgeError):
        raise RError(message="boom")
