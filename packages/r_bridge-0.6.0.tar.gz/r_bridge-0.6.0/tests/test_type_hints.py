import pytest
from r_bridge.type_hints import TypeHint, resolve_hint


def test_enum_members():
    for name in ("SCALAR", "NUMPY", "PANDAS", "LIST", "RAW"):
        assert hasattr(TypeHint, name)


def test_resolve_from_string():
    assert resolve_hint("scalar") == TypeHint.SCALAR
    assert resolve_hint("numpy") == TypeHint.NUMPY
    assert resolve_hint("pandas") == TypeHint.PANDAS
    assert resolve_hint("list") == TypeHint.LIST
    assert resolve_hint("raw") == TypeHint.RAW


def test_resolve_from_enum():
    assert resolve_hint(TypeHint.NUMPY) == TypeHint.NUMPY


def test_resolve_none():
    assert resolve_hint(None) is None


def test_resolve_invalid():
    with pytest.raises(ValueError):
        resolve_hint("bogus")
