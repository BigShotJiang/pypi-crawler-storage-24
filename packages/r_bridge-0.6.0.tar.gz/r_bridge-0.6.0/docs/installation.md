# Installation

## Requirements

- Python ≥ 3.11
- R installed and `Rscript` on your `PATH`

!!! note "Windows"
    R 4.2+ (UCRT build) is required on Windows for correct UTF-8 handling.
    Older MSVCRT builds lack system-level UTF-8 support.

## Install r_bridge

```bash
pip install r-bridge
```

## R dependency: jsonlite

r_bridge requires the `jsonlite` R package for JSON serialisation. It is
pre-installed in most R distributions. If it is missing, r_bridge will attempt
to install it automatically on first startup. You can also install it manually:

```r
install.packages("jsonlite")
```

## Verify the installation

```python
from r_bridge import RBridge

with RBridge() as r:
    print(r.ping())   # prints round-trip latency in seconds
```
