def main() -> None:
    print("Hello from opencodexproxy!")
