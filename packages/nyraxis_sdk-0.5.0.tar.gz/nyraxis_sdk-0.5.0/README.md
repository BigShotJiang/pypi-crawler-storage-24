# Nyraxis Python SDK

Universal AI agent observability — trace every LLM provider, framework, and vector DB automatically.

## Installation

```bash
pip install nyraxis-sdk
```

## Quick Start (Recommended)

```python
import nyraxis_sdk

nyraxis_sdk.init(
    api_key="nyx_your_api_key",
    base_url="https://your-nyraxis-backend.com",
    agent_name="my-agent",
)

# That's it. All LLM calls are now auto-traced.
# No code changes needed — works with any provider or framework below.

# Before process exit:
nyraxis_sdk.shutdown()
```

## Trace Grouping

```python
from nyraxis_sdk import workflow, task

@workflow(name="research-agent")
def run_agent(query):
    summary = summarize(query)
    return summary

@task(name="summarize")
def summarize(text):
    # LLM calls inside here are grouped under this task
    return openai.chat.completions.create(...)
```

## Auto-Instrumented

### LLM Providers (20+)
OpenAI, Anthropic, Google (Gemini/PaLM/VertexAI), Cohere, Mistral,
AWS Bedrock, Azure OpenAI, Ollama, Together AI, Groq, Replicate,
HuggingFace, AI21, Aleph Alpha, DeepSeek, Fireworks, Perplexity,
WatsonX, SageMaker

### Frameworks (10+)
LangChain, LlamaIndex, CrewAI, Haystack, AutoGen, Semantic Kernel,
DSPy, Marvin, Instructor, Guidance, Letta

### Vector Databases (9+)
Pinecone, Chroma, Weaviate, Qdrant, Milvus, PGVector, Redis, LanceDB, Marqo

### Span Types Captured
| Type | Description |
|------|-------------|
| `llm` | LLM chat/completion calls |
| `embedding` | Embedding generation |
| `tool` | Tool/function calls |
| `retrieval` | Vector DB queries |
| `reranker` | Reranking operations |
| `agent` | Agent orchestration |
| `workflow` | Workflow grouping |
| `task` | Task execution |
| `guardrail` | Guardrail checks |
| `memory` | Memory read/write |
| `generic` | Other operations |

## Legacy Mode (Removed)

Framework-specific handlers (`framework="langchain"` etc.) have been removed in v0.4.0.
Auto mode covers everything they did and more. Migration:

```python
# Before (v0.3):
handler = nyraxis_sdk.init(api_key="nyx_...", framework="langchain")
llm = ChatOpenAI(callbacks=[handler])

# After (v0.4):
nyraxis_sdk.init(api_key="nyx_...")
llm = ChatOpenAI()  # auto-traced, no callbacks needed
```

## Direct API Client

```python
from nyraxis_sdk import NyraxisClient

async with NyraxisClient(api_key="nyx_your_api_key") as client:
    await client.ingest_trace(
        trace_id="trace-123",
        spans=[...],
        resource_attributes={"service.name": "my-agent"},
    )
```

## Generic OTLP Endpoint

Any OpenTelemetry-instrumented app can send traces directly:

```
POST /api/v1/ingest/otel/v1/traces
Header: X-API-Key: nyx_...
Content-Type: application/json
Body: Standard OTLP ExportTraceServiceRequest (JSON or Protobuf)
```

This means frameworks with native OTEL support (AutoGen, Semantic Kernel, DSPy, etc.)
can send traces to Nyraxis without using this SDK at all.

## License

MIT
