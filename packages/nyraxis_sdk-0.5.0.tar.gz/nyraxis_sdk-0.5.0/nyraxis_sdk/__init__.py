"""Nyraxis Python SDK — universal AI agent observability.

Traces every LLM provider, framework, and vector DB automatically.

  Quick start:
    pip install nyraxis-sdk

    import nyraxis_sdk
    nyraxis_sdk.init(api_key="nyx_...", agent_name="my-agent")
    # All LLM calls auto-captured: OpenAI, Anthropic, Google, Cohere, Mistral,
    # Bedrock, Azure OpenAI, Ollama, Together, Groq, Replicate, HuggingFace, etc.
    # All frameworks auto-captured: LangChain, LlamaIndex, CrewAI, Haystack, etc.
    # All vector DBs auto-captured: Pinecone, Chroma, Weaviate, Qdrant, Milvus, etc.

Call shutdown() before exit to flush remaining traces.
"""
from __future__ import annotations

from .client import NyraxisClient, GovernanceBlocked

__version__ = "0.5.0"
__all__ = [
    "init", "shutdown", "flush", "NyraxisClient", "GovernanceBlocked",
    "workflow", "task", "agent_decorator", "tool_decorator",
    "SUPPORTED_PROVIDERS", "SUPPORTED_FRAMEWORKS", "SUPPORTED_VECTOR_DBS",
]

_active_client: NyraxisClient | None = None
_instrumentation_initialized = False

# ---------------------------------------------------------------------------
# Supported integrations — auto-instrumented
# ---------------------------------------------------------------------------

SUPPORTED_PROVIDERS = [
    "openai", "anthropic", "google-generativeai", "google-vertexai",
    "cohere", "mistral", "aws-bedrock", "azure-openai",
    "ollama", "together", "groq", "replicate", "huggingface",
    "ai21", "aleph-alpha", "deepseek", "fireworks",
    "perplexity", "watsonx", "sagemaker",
]

SUPPORTED_FRAMEWORKS = [
    "langchain", "llamaindex", "crewai", "haystack",
    "autogen", "semantic-kernel", "dspy", "marvin",
    "instructor", "guidance", "letta",
]

SUPPORTED_VECTOR_DBS = [
    "pinecone", "chroma", "weaviate", "qdrant", "milvus",
    "pgvector", "redis", "lancedb", "marqo",
]


def _has_instrumentation() -> bool:
    """Check if the instrumentation backend is installed."""
    try:
        from traceloop.sdk import Traceloop  # noqa: F401
        return True
    except ImportError:
        return False


def init(
    api_key: str,
    base_url: str = "http://localhost:8000",
    agent_name: str = "nyraxis-agent",
    agent_version: str | None = None,
    framework: str = "auto",
    disable_batch: bool = False,
    capture_content: bool = True,
):
    """Initialize Nyraxis observability.

    Args:
        api_key: Your Nyraxis API key (nyx_...)
        base_url: Nyraxis backend URL
        agent_name: Name for this agent in the dashboard
        agent_version: Optional version string
        framework: Must be "auto" (default). Legacy values raise ValueError.
        disable_batch: If True, send spans immediately (useful for debugging)
        capture_content: If True, capture prompts and completions (default True)

    Auto-traces all of these:
        LLM Providers: OpenAI, Anthropic, Google, Cohere, Mistral, Bedrock,
                       Azure OpenAI, Ollama, Together, Groq, Replicate, HuggingFace,
                       AI21, Aleph Alpha, DeepSeek, Fireworks, Perplexity, WatsonX
        Frameworks:    LangChain, LlamaIndex, CrewAI, Haystack, AutoGen,
                       Semantic Kernel, DSPy, Marvin, Instructor, Guidance
        Vector DBs:    Pinecone, Chroma, Weaviate, Qdrant, Milvus, PGVector,
                       Redis, LanceDB, Marqo
    """
    global _active_client, _instrumentation_initialized

    _active_client = NyraxisClient(api_key=api_key, base_url=base_url)

    if framework == "auto":
        if not _has_instrumentation():
            raise ImportError(
                "Instrumentation backend not installed. Install with:\n"
                "  pip install nyraxis-sdk"
            )

        from traceloop.sdk import Traceloop

        otlp_endpoint = base_url.rstrip("/") + "/api/v1/ingest/otel"

        resource_attrs = {
            "service.name": agent_name,
            "nyraxis.agent.name": agent_name,
        }
        if agent_version:
            resource_attrs["service.version"] = agent_version
            resource_attrs["nyraxis.agent.version"] = agent_version

        Traceloop.init(
            app_name=agent_name,
            api_endpoint=otlp_endpoint,
            headers={"X-API-Key": api_key},
            resource_attributes=resource_attrs,
            disable_batch=disable_batch,
            should_enrich_metrics=capture_content,
        )
        _instrumentation_initialized = True
        return None

    raise ValueError(
        f"Legacy framework='{framework}' mode has been removed. "
        "Use framework='auto' (the default) instead — it traces LangChain, "
        "LlamaIndex, CrewAI, and 20+ more providers automatically.\n\n"
        "Migration:\n"
        "  # Before (deprecated):\n"
        "  handler = nyraxis_sdk.init(api_key=..., framework='langchain')\n"
        "  llm = ChatOpenAI(callbacks=[handler])\n\n"
        "  # After (recommended):\n"
        "  nyraxis_sdk.init(api_key=...)\n"
        "  llm = ChatOpenAI()  # auto-traced, no callbacks needed"
    )


def shutdown():
    """Send remaining traces and clean up. Call before process exit."""
    global _instrumentation_initialized, _active_client
    if _instrumentation_initialized:
        try:
            from traceloop.sdk import Traceloop
            Traceloop.flush()
        except Exception:
            pass
    if _active_client:
        try:
            _active_client.flush()
        except Exception:
            pass


def flush():
    """Flush all pending traces without full teardown."""
    shutdown()


# ---------------------------------------------------------------------------
# Decorator re-exports — for trace grouping
#
# Usage:
#   from nyraxis_sdk import workflow, task
#
#   @workflow(name="my_agent_run")
#   def run_agent():
#       # All LLM calls inside here share a single trace
#       ...
#
#   @task(name="summarize")
#   def summarize(text):
#       ...
# ---------------------------------------------------------------------------

def _lazy_decorator(decorator_name: str):
    """Create a lazy wrapper that imports the decorator only when called."""
    def wrapper(*args, **kwargs):
        try:
            from traceloop.sdk import decorators
            return getattr(decorators, decorator_name)(*args, **kwargs)
        except ImportError:
            raise ImportError(
                f"Instrumentation backend required for @{decorator_name}. "
                "Install with: pip install nyraxis-sdk"
            )
    return wrapper


workflow = _lazy_decorator("workflow")
task = _lazy_decorator("task")
agent_decorator = _lazy_decorator("agent")
tool_decorator = _lazy_decorator("tool")
