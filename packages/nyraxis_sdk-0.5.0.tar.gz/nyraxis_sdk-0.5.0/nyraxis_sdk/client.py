"""Nyraxis API client with batch buffering and auto-flush."""
import atexit
import httpx
import logging
import threading
import time
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


class GovernanceBlocked(Exception):
    """Raised when a blocking governance policy rejects the trace."""
    def __init__(self, detail: str, status_code: int = 403):
        self.detail = detail
        self.status_code = status_code
        super().__init__(detail)


class NyraxisClient:
    """Client for Nyraxis API with batch buffering, auto-flush, and retry."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        timeout: float = 30.0,
        batch_size: int = 10,
        flush_interval: float = 5.0,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_retries = max_retries

        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )
        self._sync_client = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )

        self._buffer: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._timer: Optional[threading.Timer] = None
        self._resource_attrs: Dict[str, Any] = {}

        atexit.register(self._atexit_flush)
        self._schedule_flush()

    def set_resource_attributes(self, attrs: Dict[str, Any]):
        """Set resource-level attributes (agent name, framework, etc.)."""
        self._resource_attrs = attrs

    def add_span(self, span: Dict[str, Any]):
        """Add a span to the buffer. Auto-flushes when batch_size is reached."""
        flush_spans = None
        with self._lock:
            self._buffer.append(span)
            if len(self._buffer) >= self.batch_size:
                flush_spans = list(self._buffer)
                self._buffer.clear()
        if flush_spans:
            self._send_with_retry(flush_spans)

    def flush(self):
        """Flush all buffered spans immediately."""
        with self._lock:
            if not self._buffer:
                return
            spans = list(self._buffer)
            self._buffer.clear()
        self._send_with_retry(spans)

    def _schedule_flush(self):
        """Schedule periodic flush via timer."""
        self._timer = threading.Timer(self.flush_interval, self._timer_flush)
        self._timer.daemon = True
        self._timer.start()

    def _timer_flush(self):
        """Timer callback — flush and reschedule."""
        try:
            self.flush()
        except Exception as e:
            logger.warning(f"Timer flush failed: {e}")
        self._schedule_flush()

    def _send_with_retry(self, spans: List[Dict[str, Any]]):
        """Send spans with exponential backoff retry. Never retries 4xx errors."""
        payload = {
            "resource_spans": [{
                "resource": {
                    "attributes": [
                        {"key": k, "value": {"stringValue": str(v)}}
                        for k, v in self._resource_attrs.items()
                    ]
                },
                "scope_spans": [{"spans": spans}],
            }]
        }
        for attempt in range(self.max_retries):
            try:
                resp = self._sync_client.post("/api/v1/ingest/otlp", json=payload)
                if resp.status_code == 403:
                    detail = resp.json().get("detail", "Blocked by governance policy")
                    raise GovernanceBlocked(detail, status_code=403)
                if 400 <= resp.status_code < 500:
                    resp.raise_for_status()  # Don't retry client errors
                resp.raise_for_status()
                return resp.json()
            except (GovernanceBlocked, httpx.HTTPStatusError):
                raise  # Never retry 4xx
            except Exception as e:
                if attempt < self.max_retries - 1:
                    time.sleep(min(2 ** attempt, 10))
                    logger.debug(f"Retry {attempt + 1}/{self.max_retries}: {e}")
                else:
                    logger.error(f"Failed to send spans after {self.max_retries} attempts: {e}")
                    raise

    def _atexit_flush(self):
        """Flush remaining buffer on process exit."""
        if self._timer:
            self._timer.cancel()
        try:
            self.flush()
        except Exception as e:
            logger.warning(f"Atexit flush failed: {e}")

    async def ingest_trace(
        self,
        trace_id: str,
        spans: List[Dict[str, Any]],
        resource_attributes: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Ingest a trace via OTLP format (async, direct — no buffering).
        Raises GovernanceBlocked if a blocking policy rejects the trace."""
        resource_spans = [{
            "resource": {
                "attributes": [
                    {"key": k, "value": {"stringValue": str(v)}}
                    for k, v in (resource_attributes or {}).items()
                ]
            },
            "scope_spans": [{"spans": spans}],
        }]
        response = await self.client.post("/api/v1/ingest/otlp", json={"resource_spans": resource_spans})
        if response.status_code == 403:
            detail = response.json().get("detail", "Blocked by governance policy")
            raise GovernanceBlocked(detail, status_code=403)
        response.raise_for_status()
        return response.json()

    async def close(self):
        """Close HTTP clients and flush remaining buffer."""
        if self._timer:
            self._timer.cancel()
        self.flush()
        await self.client.aclose()
        self._sync_client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
