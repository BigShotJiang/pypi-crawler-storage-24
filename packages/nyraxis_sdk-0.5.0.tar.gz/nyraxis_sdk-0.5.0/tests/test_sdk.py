"""Tests for nyraxis_sdk — init, shutdown, client, decorators."""
from __future__ import annotations

import threading
import time
import pytest
from unittest.mock import patch, MagicMock

import nyraxis_sdk
from nyraxis_sdk import NyraxisClient


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_sdk():
    """Reset global SDK state between tests."""
    nyraxis_sdk._active_client = None
    nyraxis_sdk._instrumentation_initialized = False
    yield
    nyraxis_sdk._active_client = None
    nyraxis_sdk._instrumentation_initialized = False


# ---------------------------------------------------------------------------
# Version / exports
# ---------------------------------------------------------------------------

def test_version_is_string():
    assert isinstance(nyraxis_sdk.__version__, str)
    parts = nyraxis_sdk.__version__.split(".")
    assert len(parts) == 3


def test_public_api_exports():
    for name in ["init", "shutdown", "flush", "NyraxisClient",
                  "workflow", "task", "agent_decorator", "tool_decorator",
                  "SUPPORTED_PROVIDERS", "SUPPORTED_FRAMEWORKS", "SUPPORTED_VECTOR_DBS"]:
        assert hasattr(nyraxis_sdk, name), f"Missing export: {name}"


def test_supported_lists_non_empty():
    assert len(nyraxis_sdk.SUPPORTED_PROVIDERS) >= 15
    assert len(nyraxis_sdk.SUPPORTED_FRAMEWORKS) >= 8
    assert len(nyraxis_sdk.SUPPORTED_VECTOR_DBS) >= 5


# ---------------------------------------------------------------------------
# init()
# ---------------------------------------------------------------------------

@patch("nyraxis_sdk._has_instrumentation", return_value=True)
@patch("nyraxis_sdk.NyraxisClient")
def test_init_auto_mode(mock_client_cls, mock_has):
    mock_traceloop = MagicMock()
    with patch.dict("sys.modules", {"traceloop.sdk": mock_traceloop, "traceloop": MagicMock()}):
        mock_traceloop.Traceloop = MagicMock()
        nyraxis_sdk.init(api_key="nyx_test", base_url="http://test:8000", agent_name="agent-1")

    assert nyraxis_sdk._instrumentation_initialized is True
    mock_client_cls.assert_called_once_with(api_key="nyx_test", base_url="http://test:8000")
    mock_traceloop.Traceloop.init.assert_called_once()
    call_kwargs = mock_traceloop.Traceloop.init.call_args[1]
    assert call_kwargs["app_name"] == "agent-1"
    assert call_kwargs["headers"] == {"X-API-Key": "nyx_test"}
    assert "api_endpoint" in call_kwargs
    assert "/api/v1/ingest/otel" in call_kwargs["api_endpoint"]


@patch("nyraxis_sdk._has_instrumentation", return_value=False)
def test_init_raises_when_no_instrumentation(mock_has):
    with pytest.raises(ImportError, match="Instrumentation backend not installed"):
        nyraxis_sdk.init(api_key="nyx_test")


def test_init_legacy_framework_raises():
    with pytest.raises(ValueError, match="Legacy framework="):
        nyraxis_sdk.init(api_key="nyx_test", framework="langchain")


# ---------------------------------------------------------------------------
# shutdown() / flush()
# ---------------------------------------------------------------------------

@patch("nyraxis_sdk._has_instrumentation", return_value=True)
@patch("nyraxis_sdk.NyraxisClient")
def test_shutdown_flushes_both(mock_client_cls, mock_has):
    mock_client = MagicMock()
    mock_client_cls.return_value = mock_client
    mock_traceloop = MagicMock()

    with patch.dict("sys.modules", {"traceloop.sdk": mock_traceloop, "traceloop": MagicMock()}):
        mock_traceloop.Traceloop = MagicMock()
        nyraxis_sdk.init(api_key="nyx_test")
        nyraxis_sdk.shutdown()

    mock_traceloop.Traceloop.flush.assert_called_once()
    mock_client.flush.assert_called_once()


def test_shutdown_noop_when_not_initialized():
    # Should not raise
    nyraxis_sdk.shutdown()


def test_flush_calls_shutdown():
    with patch.object(nyraxis_sdk, "shutdown") as mock_sd:
        # flush is just an alias
        nyraxis_sdk.flush()
    # flush() calls shutdown() internally — both are sync now


# ---------------------------------------------------------------------------
# NyraxisClient
# ---------------------------------------------------------------------------

class TestNyraxisClient:
    def _make_client(self, **kwargs) -> NyraxisClient:
        return NyraxisClient(api_key="nyx_test", base_url="http://test:8000", **kwargs)

    def test_init_sets_fields(self):
        c = self._make_client(batch_size=5, flush_interval=1.0, max_retries=2)
        assert c.api_key == "nyx_test"
        assert c.base_url == "http://test:8000"
        assert c.batch_size == 5
        assert c.max_retries == 2
        # Cleanup timer
        if c._timer:
            c._timer.cancel()

    def test_add_span_buffers(self):
        c = self._make_client(batch_size=100)
        c.add_span({"name": "test-span"})
        with c._lock:
            assert len(c._buffer) == 1
        if c._timer:
            c._timer.cancel()

    def test_add_span_auto_flushes_at_batch_size(self):
        c = self._make_client(batch_size=2)
        with patch.object(c, "_send_with_retry") as mock_send:
            c.add_span({"name": "span-1"})
            assert mock_send.call_count == 0
            c.add_span({"name": "span-2"})
            assert mock_send.call_count == 1
            sent_spans = mock_send.call_args[0][0]
            assert len(sent_spans) == 2
        with c._lock:
            assert len(c._buffer) == 0
        if c._timer:
            c._timer.cancel()

    def test_flush_empties_buffer(self):
        c = self._make_client(batch_size=100)
        with patch.object(c, "_send_with_retry") as mock_send:
            c.add_span({"name": "span-1"})
            c.add_span({"name": "span-2"})
            c.flush()
            assert mock_send.call_count == 1
            assert len(mock_send.call_args[0][0]) == 2
        with c._lock:
            assert len(c._buffer) == 0
        if c._timer:
            c._timer.cancel()

    def test_flush_noop_when_empty(self):
        c = self._make_client()
        with patch.object(c, "_send_with_retry") as mock_send:
            c.flush()
            mock_send.assert_not_called()
        if c._timer:
            c._timer.cancel()

    def test_set_resource_attributes(self):
        c = self._make_client()
        c.set_resource_attributes({"service.name": "my-agent"})
        assert c._resource_attrs == {"service.name": "my-agent"}
        if c._timer:
            c._timer.cancel()

    def test_send_with_retry_builds_otlp_payload(self):
        c = self._make_client()
        c.set_resource_attributes({"service.name": "agent-1"})
        with patch.object(c._sync_client, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"status": "ok"}
            mock_post.return_value = mock_resp

            c._send_with_retry([{"name": "span-1"}])

            mock_post.assert_called_once()
            payload = mock_post.call_args[1]["json"]
            assert "resource_spans" in payload
            rs = payload["resource_spans"][0]
            assert "resource" in rs
            assert "scope_spans" in rs
        if c._timer:
            c._timer.cancel()

    def test_send_with_retry_retries_on_failure(self):
        c = self._make_client(max_retries=3)
        with patch.object(c._sync_client, "post", side_effect=Exception("network error")) as mock_post:
            with patch("time.sleep"):
                with pytest.raises(Exception, match="network error"):
                    c._send_with_retry([{"name": "span-1"}])
            assert mock_post.call_count == 3
        if c._timer:
            c._timer.cancel()

    @pytest.mark.asyncio
    async def test_ingest_trace_async(self):
        c = self._make_client()
        with patch.object(c.client, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"traces_created": 1}
            mock_post.return_value = mock_resp

            result = await c.ingest_trace(
                trace_id="trace-123",
                spans=[{"name": "span-1"}],
                resource_attributes={"service.name": "agent-1"},
            )
            assert result["traces_created"] == 1
            mock_post.assert_called_once()
            payload = mock_post.call_args[1]["json"]
            assert payload["resource_spans"][0]["scope_spans"][0]["spans"] == [{"name": "span-1"}]
        if c._timer:
            c._timer.cancel()

    @pytest.mark.asyncio
    async def test_context_manager(self):
        c = self._make_client()
        with patch.object(c, "flush"):
            with patch.object(c.client, "aclose") as mock_aclose:
                with patch.object(c._sync_client, "close") as mock_close:
                    async with c:
                        pass
                    mock_aclose.assert_called_once()
                    mock_close.assert_called_once()

    def test_atexit_flush_cancels_timer(self):
        c = self._make_client()
        timer = c._timer
        with patch.object(c, "flush"):
            c._atexit_flush()
        assert timer is not None
        # Timer should be cancelled
        assert timer.finished.is_set() or not timer.is_alive()


# ---------------------------------------------------------------------------
# No backend leaks in public surface
# ---------------------------------------------------------------------------

def test_no_backend_leaks_in_module_docstring():
    """Ensure SDK doesn't reveal backend implementation details."""
    doc = nyraxis_sdk.__doc__ or ""
    for term in ["FastAPI", "SQLAlchemy", "PostgreSQL", "Alembic", "langfuse", "Redis"]:
        assert term.lower() not in doc.lower(), f"Backend leak: {term} found in module docstring"


def test_no_backend_leaks_in_error_messages():
    """Legacy framework error should not mention backend tech."""
    try:
        nyraxis_sdk.init(api_key="nyx_test", framework="langchain")
    except ValueError as e:
        msg = str(e)
        for term in ["FastAPI", "SQLAlchemy", "PostgreSQL", "langfuse", "Redis"]:
            assert term.lower() not in msg.lower(), f"Backend leak: {term} in error message"
