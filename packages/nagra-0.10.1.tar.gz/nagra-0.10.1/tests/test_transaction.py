import pytest

from nagra.transaction import dummy_transaction, Transaction
from nagra.exceptions import NoActiveTransaction, TransactionReenterError
from nagra.schema import Schema


def test_dummy_transaction():
    with pytest.raises(NoActiveTransaction):
        dummy_transaction.execute("SELECT 1")

    with pytest.raises(NoActiveTransaction):
        dummy_transaction.executemany("SELECT 1")


def test_transaction_reuse():
    with pytest.raises(TransactionReenterError):
        trn = Transaction("postgresql:///nagra")
        with trn:
            with trn:
                pass


def test_concurrent_transaction(person, schema: Schema):
    uri = "postgresql:///nagra"

    with Transaction(uri):
        schema.create_tables()
        # Cleanup
        person.delete()

    trn_a = Transaction(uri)
    trn_b = Transaction(uri)

    person.upsert("name", trn=trn_a).execute("Romeo")
    person.upsert("name", trn=trn_b).execute("Sierra")

    trn_a.commit()
    trn_b.rollback()

    with Transaction(uri) as tr:
        records = list(person.select("name"))
        assert records == [("Romeo",)]

        # Cleanup
        for tbl in schema.tables.values():
            if tbl.is_view:
                continue
            tr.execute(f"DROP TABLE {tbl.name} CASCADE")
