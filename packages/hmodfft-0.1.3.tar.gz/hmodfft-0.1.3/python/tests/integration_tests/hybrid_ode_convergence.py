import numpy as np
import pytest
import hmod.standard_matrices as sm
import hmod.hilbert_matrices as hm
import hmod.matrix_tools as mat_tools
import hmod.polynomial_bases as pb

mu = 5.0

def u_analytical(t):
    return np.sin(np.pi*t)

def dt_u_analytical(t):
    return np.pi * np.cos(np.pi*t)

def f_analytical(t):
    return dt_u_analytical(t)+ mu * u_analytical(t)

def csr_to_linear_operator(csr_matrix):
    """Convert a CSR matrix to a linear operator.

    Args:
        csr_matrix (scipy.sparse.csr_matrix): The input CSR matrix.

    Returns:
        scipy.sparse.linalg.LinearOperator: The resulting linear operator.
    """
    from scipy.sparse.linalg import LinearOperator

    def matvec(x):
        return csr_matrix.dot(x)

    return LinearOperator(csr_matrix.shape, matvec=matvec)

def solve_ode_hybrid_directly(nt : int, polynomial_degree : int, number_of_modes : int, T : float):
    """Solve a simple ODE problem $u'(t) + \mu u(t) = f(t), u(0) = 0$ using only the Hilbert transformation as partial isometry.
        Mainly for testing purposes of the FFT implementation against L.

    Args:
        f_analytical (callable): The analytical right-hand side function.
        nt (int): Number of time intervals.
        polynomial_degree (int): Degree of the polynomial basis.
        number_of_modes (int): Number of modes in the Hilbert basis.
        T (float): Total time.

    Returns:
        np.ndarray: The solution vector.
    """
    #for rhs use the same polynomial degree
    polynomial_degree_rhs = polynomial_degree
    #project to piecewise polynomial space
    f_vec = sm.project_rhs_onto_legendre_basis(f_analytical, nt, polynomial_degree_rhs, T)
    #get the hilbert matrices
    Ah = hm.Operator_dt_H_Lagrange_Lagrange(number_of_modes, nt, polynomial_degree, polynomial_degree)
    Mh = hm.Operator_I_H_Lagrange_Lagrange(number_of_modes, nt, polynomial_degree_rhs, polynomial_degree)
    Fh = hm.Operator_I_H_Legendre_Lagrange(number_of_modes, nt, polynomial_degree_rhs, polynomial_degree)
    #get the standard matrices
    Ab = sm.get_lagrange_lagrange_matrix_for_derivatives(polynomial_degree_trial=polynomial_degree, polynomial_degree_test=polynomial_degree,
                                                        derivatives_trial=1, derivatives_test=0, nt=nt, T=T)
    Ab = csr_to_linear_operator(Ab)
    Mb = sm.get_lagrange_lagrange_matrix_for_derivatives(polynomial_degree_trial=polynomial_degree, polynomial_degree_test=polynomial_degree,
                                                        derivatives_trial=0, derivatives_test=0, nt=nt, T=T)
    Mb = csr_to_linear_operator(Mb)
    Fb = sm.get_legendre_lagrange_matrix_for_derivatives(polynomial_degree_trial=polynomial_degree_rhs, polynomial_degree_test=polynomial_degree,
                                                        derivatives_trial=0, derivatives_test=0, nt=nt, T=T)
    Fb = csr_to_linear_operator(Fb)
    #combine
    A = Ah + Ab + mu * (Mh + Mb)
    F = Fh + Fb

    rhs_vec = np.array(F @ f_vec)
    #transfer the system to a dense matrix for direct solving
    Kd = mat_tools.linear_operator_to_matrix(A)
    #homogenize
    K0 = Kd[1:,1:]
    rhs0 = rhs_vec[1:]
    #solve the system
    u0 = np.linalg.solve(K0, rhs0)
    # add the initial condition back
    u_vec = np.zeros(Kd.shape[0])
    u_vec[1:] = u0
    #compute errors
    legendre_trans = pb.get_lagrange_to_legendre_matrix(polynomial_degree, nt)
    u_vec_legendre = legendre_trans @ u_vec
    legendre_sol = pb.LegendreBasisEvaluator(u_vec_legendre, polynomial_degree, nt, T)

    from hmod.norms import compute_l2_norm, compute_h12_seminorm

    error_integrand = lambda t: (legendre_sol.evaluate(t) - u_analytical(t))

    L2_error = compute_l2_norm(error_integrand, nt, T)
    H1_2_error = compute_h12_seminorm(error_integrand, T, quad_tol = 1e-8)

    return L2_error, H1_2_error


def test_hybrid_ode_convergence():
    T = 1.0
    polynomial_degrees = [1,2,3,4]
    nt_values = [512, 256, 128, 64, 32]
    nt_values = [int(n/2) for n in nt_values]  #we will double nt in the convergence test
    number_of_modes = int(1e5)
    for (p,n) in zip(polynomial_degrees, nt_values):
        l2e0, h12e_0 = solve_ode_hybrid_directly(n, p, number_of_modes, T)
        l2e1, h12e_1 = solve_ode_hybrid_directly(n*2, p, number_of_modes, T)
        eocl2 = np.log2(l2e0/l2e1)
        eoch12 = np.log2(h12e_0/h12e_1)
        #check that eocl2 is approximately p+1
        expected_eocl2 = p + 1
        expected_eoch12 = p + 0.5
        tol = 0.1
        assert abs(eocl2 - expected_eocl2) < tol, f"L2 EOC {eocl2} deviates from expected {expected_eocl2} for p={p}"
        assert abs(eoch12 - expected_eoch12) < tol, f"H1/2 EOC {eoch12} deviates from expected {expected_eoch12} for p={p}"


if __name__ == "__main__":
    pytest.main([__file__])