# mcpzoo-random

> 随机数生成 — 生成指定范围内的随机数

## Installation

```bash
uvx mcpzoo-random
```

## uvx JSON

```json
{
  "mcpServers": {
    "random": {
      "args": ["mcpzoo-random"],
      "command": "uvx"
    }
  }
}
```
