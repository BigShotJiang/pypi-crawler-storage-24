import random
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("random")


@mcp.tool()
def gen_random(min_val: float = 0, max_val: float = 100, is_float: bool = False, count: int = 1) -> str:
    """生成指定范围内的随机数。"""
    if count < 1 or count > 1000:
        return "一次最多生成 1-1000 个随机数"
        
    results = []
    for _ in range(count):
        if is_float:
            results.append(str(random.uniform(min_val, max_val)))
        else:
            results.append(str(random.randint(int(min_val), int(max_val))))
            
    return "\n".join(results)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
