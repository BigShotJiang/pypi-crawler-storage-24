from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone

import httpx
from pydantic import BaseModel

from worktick.models import DATA_DIR

CONFIG_FILE = DATA_DIR / "config.json"

KNOWN_KEYS = {"webhook_url"}


class WebhookError(Exception):
    """Raised when webhook push fails."""


class Config(BaseModel):
    webhook_url: str = ""


def load_config() -> Config:
    if not CONFIG_FILE.exists():
        return Config()
    try:
        data = json.loads(CONFIG_FILE.read_text())
        return Config(**data)
    except (json.JSONDecodeError, OSError, TypeError):
        return Config()


def save_config(config: Config) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    data = config.model_dump()
    fd, tmp_path = tempfile.mkstemp(dir=DATA_DIR, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, CONFIG_FILE)
    except BaseException:
        os.unlink(tmp_path)
        raise


def push_to_webhook(markdown: str, period: str, command: str) -> None:
    """POST markdown to the configured webhook URL."""
    config = load_config()
    if not config.webhook_url:
        raise WebhookError("No webhook URL configured. Run: wt config set webhook_url <URL>")

    payload = {
        "markdown": markdown,
        "period": period,
        "command": command,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    try:
        resp = httpx.post(config.webhook_url, json=payload, timeout=30)
        resp.raise_for_status()
    except httpx.TimeoutException:
        raise WebhookError(f"Webhook request timed out: {config.webhook_url}")
    except httpx.HTTPStatusError as e:
        raise WebhookError(f"Webhook returned HTTP {e.response.status_code}: {e.response.text[:200]}")
    except (httpx.ConnectError, OSError) as e:
        raise WebhookError(f"Cannot connect to webhook: {e}")
