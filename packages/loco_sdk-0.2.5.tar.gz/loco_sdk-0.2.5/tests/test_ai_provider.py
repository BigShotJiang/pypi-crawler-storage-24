"""Tests for AI Provider plugin base class."""

import pytest

from loco_sdk.plugin.ai_provider import AIProviderPlugin
from loco_sdk.types import (
    EmbedResult,
    LLMResult,
    RerankItem,
    RerankResult,
    Usage,
)

# ── Concrete test implementations ──────────────────────────


class FakeLLMProvider(AIProviderPlugin):
    provider_name = "fake_llm"
    supported_model_types = ["llm"]
    supported_models = ["model-a", "model-b"]

    async def invoke(self, model, messages, **kwargs):
        return LLMResult(
            content=f"response from {model}",
            usage=Usage(
                prompt_tokens=1,
                completion_tokens=2,
                total_tokens=3,
            ),
            finish_reason="stop",
            model=model,
        )


class FakeEmbeddingProvider(AIProviderPlugin):
    provider_name = "fake_embed"
    supported_model_types = ["embedding"]
    supported_models = ["embed-v1"]

    async def embed(self, model, texts, **kwargs):
        return EmbedResult(embeddings=[[0.1, 0.2] for _ in texts])


class FakeRerankProvider(AIProviderPlugin):
    provider_name = "fake_rerank"
    supported_model_types = ["rerank"]
    supported_models = ["rerank-v1"]

    async def rerank(self, model, query, documents, **kwargs):
        return RerankResult(
            results=[RerankItem(index=i, score=1.0 / (i + 1)) for i in range(len(documents))]
        )


class FakeMultiProvider(AIProviderPlugin):
    provider_name = "fake_multi"
    supported_model_types = ["llm", "embedding"]
    supported_models = ["multi-1"]

    async def invoke(self, model, messages, **kwargs):
        return LLMResult(
            content="multi",
            usage=Usage(),
            finish_reason="stop",
            model=model,
        )

    async def embed(self, model, texts, **kwargs):
        return EmbedResult(embeddings=[[0.5] for _ in texts])


# ── AIProviderPlugin base tests ───────────────────────────


class TestAIProviderPlugin:
    def test_set_credentials(self):
        provider = FakeLLMProvider()
        provider.set_credentials({"api_key": "sk-test"})
        assert provider._credentials == {"api_key": "sk-test"}

    @pytest.mark.asyncio
    async def test_validate_credentials_default(self):
        provider = FakeLLMProvider()
        assert await provider.validate_credentials({"key": "val"}) is True

    @pytest.mark.asyncio
    async def test_list_models_default(self):
        provider = FakeLLMProvider()
        models = await provider.list_models()
        assert models == ["model-a", "model-b"]

    def test_get_model_info(self):
        provider = FakeLLMProvider()
        info = provider.get_model_info("model-a")
        assert info == {"model": "model-a", "provider": "fake_llm"}


# ── LLM capability tests ──────────────────────────────────


class TestLLMCapability:
    @pytest.mark.asyncio
    async def test_invoke(self):
        provider = FakeLLMProvider()
        result = await provider.invoke("model-a", [{"role": "user", "content": "hi"}])
        assert result.content == "response from model-a"
        assert result.finish_reason == "stop"
        assert result.usage.total_tokens == 3

    @pytest.mark.asyncio
    async def test_stream_default_fallback(self):
        """Default stream() falls back to invoke() and yields a single chunk."""
        provider = FakeLLMProvider()
        chunks = []
        async for chunk in provider.stream("model-a", [{"role": "user", "content": "hi"}]):
            chunks.append(chunk)
        assert len(chunks) == 1
        assert chunks[0].delta.content == "response from model-a"
        assert chunks[0].finish_reason == "stop"


# ── Embedding capability tests ─────────────────────────────


class TestEmbeddingCapability:
    @pytest.mark.asyncio
    async def test_embed(self):
        provider = FakeEmbeddingProvider()
        result = await provider.embed("embed-v1", ["hello", "world"])
        assert len(result.embeddings) == 2
        assert result.embeddings[0] == [0.1, 0.2]

    def test_get_max_chunks_default(self):
        provider = FakeEmbeddingProvider()
        assert provider.get_max_chunks("embed-v1") == 96


# ── Rerank capability tests ───────────────────────────────


class TestRerankCapability:
    @pytest.mark.asyncio
    async def test_rerank(self):
        provider = FakeRerankProvider()
        result = await provider.rerank("rerank-v1", "query", ["doc1", "doc2", "doc3"])
        assert len(result.results) == 3
        assert result.results[0].score == 1.0


# ── Capability checks ─────────────────────────────────────


class TestCapabilityChecks:
    def test_llm_supports_llm(self):
        provider = FakeLLMProvider()
        assert provider.supports_llm() is True
        assert provider.supports_embedding() is False
        assert provider.supports_rerank() is False

    def test_embedding_supports_embedding(self):
        provider = FakeEmbeddingProvider()
        assert provider.supports_llm() is False
        assert provider.supports_embedding() is True
        assert provider.supports_rerank() is False

    def test_rerank_supports_rerank(self):
        provider = FakeRerankProvider()
        assert provider.supports_llm() is False
        assert provider.supports_embedding() is False
        assert provider.supports_rerank() is True

    def test_multi_provider_supports_multiple(self):
        provider = FakeMultiProvider()
        assert provider.supports_llm() is True
        assert provider.supports_embedding() is True
        assert provider.supports_rerank() is False

    def test_concrete_instance(self):
        provider = FakeLLMProvider()
        assert isinstance(provider, AIProviderPlugin)


# ── NotImplementedError for unimplemented methods ──────────


class TestNotImplemented:
    @pytest.mark.asyncio
    async def test_invoke_not_implemented_on_embedding(self):
        provider = FakeEmbeddingProvider()
        with pytest.raises(NotImplementedError):
            await provider.invoke("embed-v1", [])

    @pytest.mark.asyncio
    async def test_embed_not_implemented_on_llm(self):
        provider = FakeLLMProvider()
        with pytest.raises(NotImplementedError):
            await provider.embed("model-a", ["text"])

    @pytest.mark.asyncio
    async def test_rerank_not_implemented_on_llm(self):
        provider = FakeLLMProvider()
        with pytest.raises(NotImplementedError):
            await provider.rerank("model-a", "q", ["d"])
