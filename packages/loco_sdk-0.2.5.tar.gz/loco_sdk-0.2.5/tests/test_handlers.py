"""Tests for NodeHandler and AIHandler."""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import pytest

from loco_sdk.plugin.ai_provider import AIProviderPlugin
from loco_sdk.plugin.base import NodePlugin
from loco_sdk.plugin.server.handlers.ai_handler import AIHandler
from loco_sdk.plugin.server.handlers.node_handler import NodeHandler
from loco_sdk.types import (
    EmbedResult,
    LLMResult,
    RerankItem,
    RerankResult,
    Usage,
)

# ── Fake plugins ───────────────────────────────────────────


class EchoNode(NodePlugin):
    async def execute(self, inputs, context):
        return {"echo": inputs, "ctx": context}


class FakeLLM(AIProviderPlugin):
    provider_name = "fake_llm"
    supported_model_types = ["llm"]
    supported_models = ["m1"]

    async def invoke(self, model, messages, **kwargs):
        return LLMResult(
            content="ok",
            model=model,
            usage=Usage(),
            finish_reason="stop",
        )


class FakeEmbedding(AIProviderPlugin):
    provider_name = "fake_embed"
    supported_model_types = ["embedding"]
    supported_models = ["e1"]

    async def embed(self, model, texts, **kwargs):
        return EmbedResult(embeddings=[[0.0] for _ in texts])


class FakeRerank(AIProviderPlugin):
    provider_name = "fake_rerank"
    supported_model_types = ["rerank"]
    supported_models = ["r1"]

    async def rerank(self, model, query, documents, **kwargs):
        return RerankResult(results=[RerankItem(index=0, score=1.0)])


# ── NodeHandler tests ──────────────────────────────────────


class TestNodeHandler:
    @pytest.fixture
    def handler(self):
        return NodeHandler(
            nodes={"echo": EchoNode},
            executor=ThreadPoolExecutor(max_workers=2),
        )

    @pytest.mark.asyncio
    async def test_execute_node(self, handler):
        result = await handler.handle(
            "execute_node",
            {"node_name": "echo", "inputs": {"x": 1}, "context": {"k": "v"}},
        )
        assert result["echo"] == {"x": 1}
        assert result["ctx"] == {"k": "v"}

    @pytest.mark.asyncio
    async def test_missing_node_name(self, handler):
        with pytest.raises(ValueError, match="Missing required parameter"):
            await handler.handle("execute_node", {})

    @pytest.mark.asyncio
    async def test_unknown_node(self, handler):
        with pytest.raises(ValueError, match="Node not found"):
            await handler.handle("execute_node", {"node_name": "nonexistent"})


# ── AIHandler tests ────────────────────────────────────────


class TestAIHandler:
    @pytest.fixture
    def handler(self):
        return AIHandler(
            providers={
                "fake_llm": FakeLLM,
                "fake_embed": FakeEmbedding,
                "fake_rerank": FakeRerank,
            }
        )

    @pytest.mark.asyncio
    async def test_invoke(self, handler):
        result = await handler.handle(
            "ai_provider:invoke",
            {
                "provider_name": "fake_llm",
                "credentials": {"key": "val"},
                "params": {
                    "model": "m1",
                    "messages": [{"role": "user", "content": "hi"}],
                },
            },
        )
        assert result["content"] == "ok"
        assert result["model"] == "m1"

    @pytest.mark.asyncio
    async def test_stream(self, handler):
        result = await handler.handle(
            "ai_provider:stream",
            {
                "provider_name": "fake_llm",
                "credentials": {},
                "params": {"model": "m1", "messages": []},
            },
        )
        assert "chunks" in result
        assert len(result["chunks"]) >= 1

    @pytest.mark.asyncio
    async def test_embed(self, handler):
        result = await handler.handle(
            "ai_provider:embed",
            {
                "provider_name": "fake_embed",
                "credentials": {},
                "params": {"model": "e1", "texts": ["hello"]},
            },
        )
        assert len(result["embeddings"]) == 1

    @pytest.mark.asyncio
    async def test_rerank(self, handler):
        result = await handler.handle(
            "ai_provider:rerank",
            {
                "provider_name": "fake_rerank",
                "credentials": {},
                "params": {"model": "r1", "query": "q", "documents": ["d1"]},
            },
        )
        assert result["results"][0]["score"] == 1.0

    @pytest.mark.asyncio
    async def test_validate_credentials(self, handler):
        result = await handler.handle(
            "ai_provider:validate_credentials",
            {"provider_name": "fake_llm", "credentials": {"key": "val"}},
        )
        assert result["valid"] is True

    @pytest.mark.asyncio
    async def test_list_models(self, handler):
        result = await handler.handle(
            "ai_provider:list_models",
            {"provider_name": "fake_llm", "credentials": {}},
        )
        assert result["models"] == ["m1"]

    @pytest.mark.asyncio
    async def test_missing_provider_name(self, handler):
        with pytest.raises(ValueError, match="Missing required parameter"):
            await handler.handle("ai_provider:invoke", {})

    @pytest.mark.asyncio
    async def test_unknown_provider(self, handler):
        with pytest.raises(ValueError, match="AI provider not found"):
            await handler.handle(
                "ai_provider:invoke",
                {"provider_name": "nope", "credentials": {}},
            )

    @pytest.mark.asyncio
    async def test_unknown_action(self, handler):
        with pytest.raises(ValueError, match="Unknown ai_provider action"):
            await handler.handle(
                "ai_provider:bogus",
                {"provider_name": "fake_llm", "credentials": {}},
            )

    @pytest.mark.asyncio
    async def test_invalid_method_format(self, handler):
        with pytest.raises(ValueError, match="Invalid ai_provider method"):
            await handler.handle("ai_provider", {"provider_name": "fake_llm", "credentials": {}})

    @pytest.mark.asyncio
    async def test_type_mismatch_invoke_on_embedding(self, handler):
        with pytest.raises(ValueError, match="does not support invoke"):
            await handler.handle(
                "ai_provider:invoke",
                {
                    "provider_name": "fake_embed",
                    "credentials": {},
                    "params": {"model": "e1", "messages": []},
                },
            )
