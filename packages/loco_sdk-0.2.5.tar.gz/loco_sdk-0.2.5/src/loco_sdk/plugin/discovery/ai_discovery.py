"""AI provider component discovery.

Scans ``ai/`` directory for :class:`AIProviderPlugin` subclasses.
"""

import logging
import sys
import traceback
from importlib import import_module

from loco_sdk.plugin.ai_provider import AIProviderPlugin
from loco_sdk.plugin.discovery.base import ComponentDiscovery

logger = logging.getLogger(__name__)


class AIProviderDiscovery(ComponentDiscovery):
    """Discover :class:`AIProviderPlugin` subclasses in ``ai/`` directory.

    For each ``*.py`` file (excluding ``_``-prefixed), imports the module
    and collects every concrete ``AIProviderPlugin`` subclass found.

    Returns:
        Mapping of ``{provider_name: AIProviderPluginSubclass}``.
        Uses ``cls.provider_name`` as the key.
    """

    def discover(self) -> dict[str, type[AIProviderPlugin]]:
        providers_dir = self.plugin_dir / "ai"
        if not providers_dir.exists():
            # ai/ is optional — only plugins with AI providers have it
            logger.debug(f"No ai/ directory in {self.plugin_dir}")
            return {}

        providers: dict[str, type[AIProviderPlugin]] = {}
        sys.path.insert(0, str(self.plugin_dir))

        try:
            for py_file in providers_dir.glob("*.py"):
                if py_file.name.startswith("_"):
                    continue

                module_name = f"ai.{py_file.stem}"
                try:
                    module = import_module(module_name)

                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (
                            isinstance(attr, type)
                            and issubclass(attr, AIProviderPlugin)
                            and attr is not AIProviderPlugin
                            and getattr(attr, "provider_name", None)
                        ):
                            name = attr.provider_name
                            providers[name] = attr
                            logger.info(f"Loaded AI provider: {name} ({attr.__name__})")

                except Exception as e:
                    logger.error(f"Failed to load provider {py_file.name}: {e}")
                    traceback.print_exc()
        finally:
            sys.path.pop(0)

        return providers
