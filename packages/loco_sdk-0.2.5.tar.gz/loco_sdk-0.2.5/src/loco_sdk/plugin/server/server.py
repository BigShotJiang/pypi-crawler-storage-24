"""Plugin server for executing nodes and AI providers via JSON-RPC 2.0.

Slim orchestrator that delegates component discovery to ``discovery/``
and request handling to ``router`` + ``handlers/``.

Key features:
- Auto-discovery of NodePlugin and AIProviderPlugin classes
- ThreadPool for concurrent execution
- JSON-RPC 2.0 protocol support
- Health check (ping) endpoint
- Graceful shutdown
"""

import asyncio
import json
import logging
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from loco_sdk.plugin.discovery.ai_discovery import AIProviderDiscovery
from loco_sdk.plugin.discovery.node_discovery import NodeDiscovery
from loco_sdk.plugin.server.handlers import AIHandler, NodeHandler
from loco_sdk.plugin.server.router import RequestRouter

logger = logging.getLogger(__name__)


class PluginServer:
    """
    Persistent plugin server for warm execution.

    Discovers NodePlugin and AIProviderPlugin classes and executes them
    via JSON-RPC 2.0 protocol over stdin/stdout.

    Protocol:
        Request: {"jsonrpc": "2.0", "method": "execute_node", "params": {...}, "id": 1}
        Response: {"jsonrpc": "2.0", "result": {...}, "id": 1}
        Error: {"jsonrpc": "2.0", "error": {"code": -32000, "message": "..."}, "id": 1}

    Methods:
        - execute_node: Execute a plugin node
        - ai_provider:invoke: Invoke LLM completion
        - ai_provider:stream: Stream LLM responses
        - ai_provider:embed: Generate embeddings
        - ai_provider:rerank: Rerank documents
        - ai_provider:validate_credentials: Validate provider credentials
        - ai_provider:list_models: List available models
        - ping: Health check
        - shutdown: Graceful shutdown

    Args:
        plugin_dir: Path to plugin directory
        max_workers: ThreadPool size for concurrent execution
    """

    def __init__(self, plugin_dir: Path, max_workers: int = 10):
        self.plugin_dir = plugin_dir
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.router = RequestRouter()
        self._write_lock = asyncio.Lock()
        self.running = False

    async def _write_line(self, data: dict[str, Any]) -> None:
        """Thread-safe NDJSON write to stdout."""
        async with self._write_lock:
            print(json.dumps(data, separators=(",", ":")), flush=True)

    def _discover_and_register(self) -> dict[str, list[str]]:
        """Discover all components and register handlers.

        Returns:
            Summary dict with discovered component names.
        """
        summary: dict[str, list[str]] = {"nodes": [], "ai_providers": []}

        # Nodes
        try:
            node_discovery = NodeDiscovery(self.plugin_dir)
            nodes = node_discovery.discover()
            if nodes:
                self.router.register("execute_node", NodeHandler(nodes, self.executor))
                summary["nodes"] = list(nodes.keys())
        except FileNotFoundError:
            logger.debug("No nodes/ directory — skipping node discovery")

        # AI Providers
        ai_discovery = AIProviderDiscovery(self.plugin_dir)
        ai_providers = ai_discovery.discover()
        if ai_providers:
            ai_handler = AIHandler(ai_providers)
            self.router.register("ai_provider", ai_handler, stream_handler=ai_handler)
            summary["ai_providers"] = list(ai_providers.keys())

        return summary

    async def handle_request(self, request: dict[str, Any]) -> dict[str, Any]:
        """Process a single request and return the response dict.

        Useful for testing or direct invocation without stdout.
        """
        request_id = request.get("id")
        method = request.get("method")
        params = request.get("params", {})

        try:
            if method == "ping":
                return {
                    "jsonrpc": "2.0",
                    "result": {"status": "ok"},
                    "id": request_id,
                }

            if method == "shutdown":
                self.running = False
                return {
                    "jsonrpc": "2.0",
                    "result": {"status": "shutting_down"},
                    "id": request_id,
                }

            if not method:
                return {
                    "jsonrpc": "2.0",
                    "error": {"code": -32600, "message": "Missing method"},
                    "id": request_id,
                }

            try:
                result = await self.router.route(method, params)
                return {"jsonrpc": "2.0", "result": result, "id": request_id}
            except ValueError as e:
                return {
                    "jsonrpc": "2.0",
                    "error": {"code": -32601, "message": str(e)},
                    "id": request_id,
                }
        except Exception as e:
            return {
                "jsonrpc": "2.0",
                "error": {"code": -32000, "message": str(e)},
                "id": request_id,
            }

    async def _process_request(self, request: dict[str, Any]) -> None:
        """Process one request — fire-and-forget as asyncio task."""
        request_id = request.get("id")
        method = request.get("method")
        params = request.get("params", {})

        try:
            # Built-in methods
            if method == "ping":
                await self._write_line(
                    {
                        "jsonrpc": "2.0",
                        "result": {"status": "ok"},
                        "id": request_id,
                    }
                )
                return

            if method == "shutdown":
                self.running = False
                await self._write_line(
                    {
                        "jsonrpc": "2.0",
                        "result": {"status": "shutting_down"},
                        "id": request_id,
                    }
                )
                return

            # Delegate to router
            if not method:
                await self._write_line(
                    {
                        "jsonrpc": "2.0",
                        "error": {"code": -32600, "message": "Missing method"},
                        "id": request_id,
                    }
                )
                return

            try:
                if self.router.is_streaming(method):
                    # Stream: yield chunks as NDJSON lines
                    async for chunk in self.router.route_stream(method, params):
                        await self._write_line({"jsonrpc": "2.0", "id": request_id, "chunk": chunk})
                    await self._write_line({"jsonrpc": "2.0", "id": request_id, "result": "done"})
                else:
                    # Normal: single response
                    result = await self.router.route(method, params)
                    await self._write_line({"jsonrpc": "2.0", "result": result, "id": request_id})
            except ValueError as e:
                await self._write_line(
                    {
                        "jsonrpc": "2.0",
                        "error": {"code": -32601, "message": str(e)},
                        "id": request_id,
                    }
                )

        except Exception as e:
            logger.error(f"Request handling error: {e}")
            traceback.print_exc()
            await self._write_line(
                {
                    "jsonrpc": "2.0",
                    "error": {"code": -32000, "message": str(e)},
                    "id": request_id,
                }
            )

    async def run(self):
        """
        Run plugin server main loop.

        Discovers components, then listens for JSON-RPC requests on stdin
        and sends responses to stdout.
        """
        self.running = True

        # Discover and register handlers
        logger.info(f"Discovering components in {self.plugin_dir}")
        summary = self._discover_and_register()
        logger.info(
            f"Loaded {len(summary['nodes'])} nodes, " f"{len(summary['ai_providers'])} AI providers"
        )

        # Signal ready
        ready_message = json.dumps({"status": "ready", **summary})
        async with self._write_lock:
            print(ready_message, flush=True)

        # Main loop: read stdin, dispatch as concurrent tasks
        logger.info("Plugin server ready, listening for requests...")

        try:
            while self.running:
                line = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)

                if not line:
                    logger.info("EOF received, shutting down")
                    break

                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    # Fire-and-forget: each request runs in its own task
                    asyncio.create_task(self._process_request(request))

                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON: {e}")
                    await self._write_line(
                        {
                            "jsonrpc": "2.0",
                            "error": {"code": -32700, "message": "Parse error"},
                            "id": None,
                        }
                    )

        except KeyboardInterrupt:
            logger.info("Received interrupt signal")

        finally:
            logger.info("Shutting down plugin server")
            self.executor.shutdown(wait=True)


async def main(plugin_dir: Path | None = None):
    """
    Main entry point for plugin server.

    Args:
        plugin_dir: Path to plugin directory. If None, uses current directory.
    """
    if plugin_dir is None:
        plugin_dir = Path.cwd()

    server = PluginServer(plugin_dir)
    await server.run()


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Parse plugin directory from args
    plugin_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    asyncio.run(main(plugin_dir))
