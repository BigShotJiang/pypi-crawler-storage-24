"""AI provider handler.

Handles ``ai_provider:*`` JSON-RPC requests by dispatching to the
appropriate :class:`AIProviderPlugin` subclass.

Supports both normal request/response and streaming.

Supported sub-methods:
    - ``ai_provider:invoke``
    - ``ai_provider:stream`` (streaming via handle_stream)
    - ``ai_provider:embed``
    - ``ai_provider:rerank``
    - ``ai_provider:validate_credentials``
    - ``ai_provider:list_models``
"""

import logging
from collections.abc import AsyncGenerator
from typing import Any

from loco_sdk.plugin.ai_provider import AIProviderPlugin
from loco_sdk.types import Message, StreamChunk, ToolDefinition

logger = logging.getLogger(__name__)


class AIHandler:
    """Handle ``ai_provider:*`` JSON-RPC requests.

    Implements both ``RequestHandler`` and ``StreamHandler`` protocols.

    Args:
        providers: Mapping of ``{provider_name: AIProviderPluginClass}``
                   from :class:`AIProviderDiscovery`.
    """

    def __init__(self, providers: dict[str, type[AIProviderPlugin]]):
        self.providers = providers

    def _get_provider(self, params: dict[str, Any]) -> AIProviderPlugin:
        """Shared provider instantiation logic.

        Args:
            params: Request parameters containing provider_name and credentials.

        Returns:
            Instantiated provider with credentials set.

        Raises:
            ValueError: If provider_name is missing or not found.
        """
        provider_name = params.get("provider_name")
        if not provider_name:
            raise ValueError("Missing required parameter: provider_name")

        provider_cls = self.providers.get(provider_name)
        if not provider_cls:
            raise ValueError(f"AI provider not found: {provider_name}")

        provider = provider_cls()
        provider.set_credentials(params.get("credentials", {}))
        return provider

    async def handle(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        """Dispatch to the correct sub-handler based on *method*.

        Args:
            method: Full method name (e.g. ``"ai_provider:invoke"``).
            params: Request parameters.

        Returns:
            Result dict.

        Raises:
            ValueError: If provider or sub-method is invalid.
        """
        _, _, action = method.partition(":")
        if not action:
            raise ValueError(f"Invalid ai_provider method: {method}")

        provider = self._get_provider(params)

        dispatch = {
            "invoke": self._handle_invoke,
            "stream": self._handle_stream,
            "embed": self._handle_embed,
            "rerank": self._handle_rerank,
            "validate_credentials": self._handle_validate,
            "list_models": self._handle_list_models,
        }

        handler_fn = dispatch.get(action)
        if handler_fn is None:
            raise ValueError(f"Unknown ai_provider action: {action}")

        return await handler_fn(provider, params)

    async def handle_stream(
        self, method: str, params: dict[str, Any]
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Yield chunks directly from provider.stream() — NO collection.

        Used by the server's NDJSON streaming path.

        Args:
            method: Full method name (e.g. ``"ai_provider:stream"``).
            params: Request parameters.

        Yields:
            Chunk dicts (serialized StreamChunk).
        """
        provider = self._get_provider(params)
        if not provider.supports_llm():
            raise ValueError(
                f"Provider '{provider.provider_name}' does not support stream (not an LLM)"
            )
        inner = params.get("params", {})

        messages = [Message.model_validate(m) for m in inner.get("messages", [])]
        tools = (
            [ToolDefinition.model_validate(t) for t in inner["tools"]]
            if inner.get("tools")
            else None
        )
        kwargs = {k: v for k, v in inner.items() if k not in ("model", "messages", "tools")}
        if tools is not None:
            kwargs["tools"] = tools

        async for chunk in provider.stream(
            model=inner["model"],
            messages=messages,
            **kwargs,
        ):
            if isinstance(chunk, StreamChunk):
                yield chunk.model_dump(exclude_none=True)
            else:
                yield chunk

    # ── Sub-handlers ─────────────────────────────────────────

    @staticmethod
    async def _handle_invoke(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_llm():
            raise ValueError(
                f"Provider '{provider.provider_name}' does not support invoke (not an LLM)"
            )
        inner = params.get("params", {})
        messages = [Message.model_validate(m) for m in inner.get("messages", [])]
        tools = (
            [ToolDefinition.model_validate(t) for t in inner["tools"]]
            if inner.get("tools")
            else None
        )
        result = await provider.invoke(
            model=inner["model"],
            messages=messages,
            temperature=inner.get("temperature", 0.7),
            max_tokens=inner.get("max_tokens"),
            tools=tools,
            stream=inner.get("stream", False),
        )
        return result.model_dump(exclude_none=True)

    @staticmethod
    async def _handle_stream(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        """Fallback for non-streaming path — collects all chunks."""
        if not provider.supports_llm():
            raise ValueError(
                f"Provider '{provider.provider_name}' does not support stream (not an LLM)"
            )
        inner = params.get("params", {})
        messages = [Message.model_validate(m) for m in inner.get("messages", [])]
        kwargs = {k: v for k, v in inner.items() if k not in ("model", "messages")}

        chunks: list[dict[str, Any]] = []
        async for chunk in provider.stream(
            model=inner["model"],
            messages=messages,
            **kwargs,
        ):
            if isinstance(chunk, StreamChunk):
                chunks.append(chunk.model_dump(exclude_none=True))
            else:
                chunks.append(chunk)
        return {"chunks": chunks}

    @staticmethod
    async def _handle_embed(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_embedding():
            raise ValueError(f"Provider '{provider.provider_name}' does not support embed")
        inner = params.get("params", {})
        result = await provider.embed(
            model=inner["model"],
            texts=inner["texts"],
            dimensions=inner.get("dimensions"),
        )
        return result.model_dump(exclude_none=True)

    @staticmethod
    async def _handle_rerank(provider: AIProviderPlugin, params: dict[str, Any]) -> dict[str, Any]:
        if not provider.supports_rerank():
            raise ValueError(f"Provider '{provider.provider_name}' does not support rerank")
        inner = params.get("params", {})
        result = await provider.rerank(
            model=inner["model"],
            query=inner["query"],
            documents=inner["documents"],
            top_n=inner.get("top_n"),
        )
        return result.model_dump(exclude_none=True)

    @staticmethod
    async def _handle_validate(
        provider: AIProviderPlugin, params: dict[str, Any]
    ) -> dict[str, Any]:
        credentials = params.get("credentials", {})
        valid = await provider.validate_credentials(credentials)
        return {"valid": valid}

    @staticmethod
    async def _handle_list_models(
        provider: AIProviderPlugin, params: dict[str, Any]
    ) -> dict[str, Any]:
        models = await provider.list_models()
        return {"models": models}
