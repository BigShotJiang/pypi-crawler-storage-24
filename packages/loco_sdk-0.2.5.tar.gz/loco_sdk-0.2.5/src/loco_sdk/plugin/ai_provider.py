"""AI Provider plugin base class.

Provides a single unified base class for AI provider plugins.
Plugin developers inherit from :class:`AIProviderPlugin` and implement
the methods for their supported capabilities (LLM, embedding, rerank).

Example:
    from loco_sdk import AIProviderPlugin

    class OllamaProvider(AIProviderPlugin):
        provider_name = "ollama"
        supported_model_types = ["llm"]
        supported_models = ["llama3", "mistral"]

        async def invoke(self, model, messages, **kwargs):
            ...
"""

from collections.abc import AsyncGenerator
from typing import Any

from loco_sdk.plugin.base import PluginBase
from loco_sdk.types import (
    EmbedResult,
    LLMResult,
    Message,
    RerankResult,
    StreamChunk,
    ToolDefinition,
)


class AIProviderPlugin(PluginBase):
    """Unified base class for all AI provider plugins.

    Subclasses declare which capabilities they support via
    ``supported_model_types`` (e.g. ``["llm"]``, ``["llm", "embedding"]``).
    Then implement the corresponding methods.

    Attributes:
        provider_name: Unique name identifying this provider (e.g. "ollama").
        supported_model_types: List of capability types: "llm", "embedding", "rerank".
        supported_models: Static list of model identifiers.
    """

    provider_name: str = ""
    supported_model_types: list[str] = []
    supported_models: list[str] = []

    # ── Capability checks ────────────────────────────────────

    def supports_llm(self) -> bool:
        return "llm" in self.supported_model_types

    def supports_embedding(self) -> bool:
        return "embedding" in self.supported_model_types

    def supports_rerank(self) -> bool:
        return "rerank" in self.supported_model_types

    # ── Credentials ──────────────────────────────────────────

    def set_credentials(self, credentials: dict[str, Any]) -> None:
        """Set credentials obtained from the auth provider.

        Called by the server handler before each request so the plugin
        can use ``self._credentials`` inside ``invoke`` / ``embed`` / etc.
        """
        self._credentials = credentials

    async def validate_credentials(self, credentials: dict[str, Any]) -> bool:
        """Validate credentials. Override for custom validation logic.

        Returns:
            ``True`` if the credentials are usable.
        """
        return True

    # ── Model discovery ──────────────────────────────────────

    async def list_models(self) -> list[str]:
        """List available models (supports runtime discovery).

        Default implementation returns ``supported_models``.
        Override to fetch models dynamically.
        """
        return self.supported_models

    def get_model_info(self, model: str) -> dict[str, Any]:
        """Return metadata for a single model.

        Override for richer information (context window, pricing, etc.).
        """
        return {"model": model, "provider": self.provider_name}

    # ── LLM capabilities ─────────────────────────────────────

    async def invoke(
        self,
        model: str,
        messages: list[Message],
        *,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        tools: list[ToolDefinition] | None = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> LLMResult:
        """Invoke LLM completion.

        Override this if ``"llm"`` is in ``supported_model_types``.

        Args:
            model: Model identifier (e.g. ``"llama3"``).
            messages: ``[{"role": "user", "content": "..."}]``
            temperature: Sampling temperature.
            max_tokens: Maximum output tokens.
            tools: Tool/function definitions (optional).
            stream: Whether streaming was requested (hint).

        Returns:
            ``{"content": "...", "tool_calls": [...] | None,
              "usage": {"prompt_tokens": N, "completion_tokens": N, "total_tokens": N},
              "finish_reason": "stop", "model": "llama3"}``
        """
        raise NotImplementedError(f"Provider '{self.provider_name}' does not implement invoke()")

    async def stream(
        self,
        model: str,
        messages: list[Message],
        **kwargs: Any,
    ) -> AsyncGenerator[StreamChunk, None]:
        """Stream LLM responses chunk-by-chunk.

        Default implementation falls back to :meth:`invoke` and yields a
        single chunk.  Override for real streaming.

        Yields:
            :class:`StreamChunk` with delta content, usage, finish_reason.
        """
        result = await self.invoke(model, messages, **kwargs)
        from loco_sdk.types import Delta

        yield StreamChunk(
            delta=Delta(content=result.content),
            usage=result.usage,
            finish_reason=result.finish_reason,
        )

    # ── Embedding capabilities ───────────────────────────────

    async def embed(
        self,
        model: str,
        texts: list[str],
        *,
        dimensions: int | None = None,
        **kwargs: Any,
    ) -> EmbedResult:
        """Generate embeddings for a batch of texts.

        Override this if ``"embedding"`` is in ``supported_model_types``.

        Args:
            model: Model identifier.
            texts: Input texts.
            dimensions: Desired embedding dimensionality (optional).

        Returns:
            ``{"embeddings": [[0.1, 0.2, ...], ...]}``
        """
        raise NotImplementedError(f"Provider '{self.provider_name}' does not implement embed()")

    def get_max_chunks(self, model: str) -> int:
        """Maximum number of texts per batch.  Override if needed."""
        return 96

    # ── Rerank capabilities ──────────────────────────────────

    async def rerank(
        self,
        model: str,
        query: str,
        documents: list[str],
        *,
        top_n: int | None = None,
        **kwargs: Any,
    ) -> RerankResult:
        """Rerank documents by relevance to a query.

        Override this if ``"rerank"`` is in ``supported_model_types``.

        Args:
            model: Model identifier.
            query: Query string.
            documents: Documents to rank.
            top_n: Return only top-N results (optional).

        Returns:
            ``{"results": [{"index": 0, "score": 0.95}, ...]}``
        """
        raise NotImplementedError(f"Provider '{self.provider_name}' does not implement rerank()")


__all__ = [
    "AIProviderPlugin",
]
