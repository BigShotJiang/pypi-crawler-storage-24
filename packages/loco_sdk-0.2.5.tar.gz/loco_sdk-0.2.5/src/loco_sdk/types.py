"""Shared types for Loco SDK plugin development.

All AI provider input/output types are defined here as Pydantic models.
Plugin developers use these for type-safe invoke/stream/embed/rerank.
Transport layer uses .model_dump() / .model_validate() at boundaries.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# ── Messages ─────────────────────────────────────────────


class FunctionCall(BaseModel):
    name: str
    arguments: str = ""  # JSON string


class ToolCall(BaseModel):
    id: str
    type: str = "function"
    function: FunctionCall = Field(default_factory=lambda: FunctionCall(name=""))


class Message(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str | list[dict[str, Any]] | None = None
    tool_calls: list[ToolCall] | None = None
    tool_call_id: str | None = None
    name: str | None = None


# ── Tools ────────────────────────────────────────────────


class ToolParameter(BaseModel):
    type: str = "object"
    properties: dict[str, Any] = Field(default_factory=dict)
    required: list[str] = Field(default_factory=list)


class ToolFunction(BaseModel):
    name: str
    description: str = ""
    parameters: ToolParameter | None = None


class ToolDefinition(BaseModel):
    type: str = "function"
    function: ToolFunction = Field(default_factory=lambda: ToolFunction(name=""))


# ── LLM Results ─────────────────────────────────────────


class Usage(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class LLMResult(BaseModel):
    content: str = ""
    tool_calls: list[ToolCall] | None = None
    usage: Usage = Field(default_factory=Usage)
    finish_reason: str = "stop"
    model: str = ""


# ── Streaming ───────────────────────────────────────────


class Delta(BaseModel):
    content: str | None = None
    reasoning_content: str | None = None
    tool_calls: list[ToolCall] | None = None


class StreamChunk(BaseModel):
    delta: Delta = Field(default_factory=Delta)
    usage: Usage | None = None
    finish_reason: str | None = None


# ── Embedding ───────────────────────────────────────────


class EmbedResult(BaseModel):
    embeddings: list[list[float]] = Field(default_factory=list)


# ── Rerank ──────────────────────────────────────────────


class RerankItem(BaseModel):
    index: int
    score: float


class RerankResult(BaseModel):
    results: list[RerankItem] = Field(default_factory=list)


__all__ = [
    "Delta",
    "EmbedResult",
    "FunctionCall",
    "LLMResult",
    "Message",
    "RerankItem",
    "RerankResult",
    "StreamChunk",
    "ToolCall",
    "ToolDefinition",
    "ToolFunction",
    "ToolParameter",
    "Usage",
]
