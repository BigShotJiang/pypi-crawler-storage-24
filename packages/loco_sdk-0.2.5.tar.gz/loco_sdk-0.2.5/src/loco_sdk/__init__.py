"""
Loco SDK

Public API for plugin development.

This module provides a compatibility layer for existing plugins.
New code should import from loco_sdk.plugin instead.
"""

# NEW: Import from unified plugin module
from loco_sdk.plugin import (
    AIProviderPlugin,
    AuthContext,
    AuthenticationError,
    ExtensionPlugin,
    ManifestLoadError,
    NodePlugin,
    OAuthError,
    OAuthProviderError,
    OAuthRefreshError,
    PluginBase,
    PluginError,
    TriggerPlugin,
    ValidationError,
)
from loco_sdk.types import (
    Delta,
    EmbedResult,
    FunctionCall,
    LLMResult,
    Message,
    RerankItem,
    RerankResult,
    StreamChunk,
    ToolCall,
    ToolDefinition,
    ToolFunction,
    ToolParameter,
    Usage,
)
from loco_sdk.version import __version__

__all__ = [
    # Version
    "__version__",
    # Core classes
    "PluginBase",
    "NodePlugin",
    "ExtensionPlugin",
    "TriggerPlugin",
    "AIProviderPlugin",
    # Types
    "Message",
    "FunctionCall",
    "ToolCall",
    "ToolDefinition",
    "ToolFunction",
    "ToolParameter",
    "Usage",
    "LLMResult",
    "Delta",
    "StreamChunk",
    "EmbedResult",
    "RerankItem",
    "RerankResult",
    # Exceptions
    "PluginError",
    "AuthenticationError",
    "ValidationError",
    "ManifestLoadError",
    "OAuthError",
    "OAuthProviderError",
    "OAuthRefreshError",
    # Auth
    "AuthContext",
]
