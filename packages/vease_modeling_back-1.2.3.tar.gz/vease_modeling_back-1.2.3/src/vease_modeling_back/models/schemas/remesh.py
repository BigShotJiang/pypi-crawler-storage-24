from dataclasses import dataclass, field
from typing import List, Optional
from dataclasses_json import DataClassJsonMixin


@dataclass
class RemeshComponentConstraint(DataClassJsonMixin):
    id: str
    metric: float


@dataclass
class Remesh(DataClassJsonMixin):
    id: str
    default: float
    name: str
    gradation: Optional[float] = None
    corners: Optional[List[RemeshComponentConstraint]] = field(default=None)
    lines: Optional[List[RemeshComponentConstraint]] = field(default=None)
    surfaces: Optional[List[RemeshComponentConstraint]] = field(default=None)
    blocks: Optional[List[RemeshComponentConstraint]] = field(default=None)
