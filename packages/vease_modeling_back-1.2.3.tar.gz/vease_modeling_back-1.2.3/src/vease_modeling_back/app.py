# Standard library imports

# Third party imports
import flask
from opengeodeweb_back.app import create_app, run_server, register_ogw_back_blueprints

# Local application imports
import vease_modeling_back.routes.blueprint_create as blueprint_create
import vease_modeling_back.models.blueprint_models as blueprint_models

url_prefix = "/vease_modeling_back"


def run_vease_modeling_back() -> flask.Flask:
    app = create_app(__name__)
    register_ogw_back_blueprints(app)
    app.register_blueprint(
        blueprint_create.routes,
        url_prefix=url_prefix,
        name="create",
    )
    app.register_blueprint(
        blueprint_models.routes,
        url_prefix=url_prefix,
        name="models",
    )
    run_server(app)
    return app


if __name__ == "__main__":
    run_vease_modeling_back()
