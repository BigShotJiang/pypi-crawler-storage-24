def get_env(key):

  defaults = {
    "LANGFUSE_SECRET_KEY": "sk-lf-ccea8a1f-d572-4dcd-af4c-d73e1dbc2eb3",
    "LANGFUSE_PUBLIC_KEY": "pk-lf-a9178954-2e7f-43cc-9045-21d544f12231",
    "LANGFUSE_HOST": "https://us.cloud.langfuse.com",

    "LANGCHAIN_TRACING_V2": "true",
    "LANGCHAIN_API_KEY": "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",


    "SENTRY_DSN": "https://f515b78b435ab35b5e068e36c6f87fed@o4511019423105024.ingest.us.sentry.io/4511075166257152",
    "PHOENIX_ENDPOINT": "http://127.0.0.1:6006/v1/traces"
  }

  return defaults.get(key)