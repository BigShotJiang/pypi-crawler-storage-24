import sentry_sdk
from .base import BaseTool
from obs.utils.config import get_env

class SentryTool(BaseTool):
  def init(self):
    sentry_sdk.init(dsn=get_env("SENTRY_DSN"))

  def push(self, trace_id, name, input, output, start_time, end_time, error):
    if error:
      sentry_sdk.capture_exception(Exception(error))