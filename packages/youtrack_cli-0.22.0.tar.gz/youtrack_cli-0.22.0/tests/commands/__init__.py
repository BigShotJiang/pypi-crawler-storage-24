"""Tests for commands module."""
