`castlabs-evs` is a package that provides a client for the [EVS service](https://github.com/castlabs/electron-releases/wiki/EVS) for [Electron for Content Security](https://github.com/castlabs/electron-releases). EVS provides production Widevine/VMP signing of application packages derived from official releases of Electron for Content Security. It is a free service, but requires signup to use.

As part of the Widevine 3PL program castLabs also offers [commercial VMP certification](https://github.com/castlabs/electron-releases/wiki/EVS#3pl) of custom Chromium/Electron adaptations, which enables the use of EVS for signing custom builds.

`castlabs-evs` supports Python 3.7+ and can be installed with:
```
% python3 -m pip install castlabs-evs
```

This installs the EVS client which provides Python and CLI interfaces for account handling and VMP signing. If the pip module binary directory is in your `PATH` the two convenience scripts `evs-account` and `evs-vmp` can be used in place of `python3 -m <module>` in the examples below.

The CLI interfaces are interactive by default, asking for any information they cannot load from its configuration, unless they are provided through CLI arguments or environment variables. This behaviour can be overridden by not providing a TTY on STDIN, or by passing the `--no-ask` option or setting EVS_NO_ASK in the environment, in which case any missing required information will trigger a runtime error instead, making them more suitable for automation.

The Python interfaces are not currently documented, but the CLI provides help sections that can be accessed:
```
% python3 -m castlabs_evs.account --help
usage: account.py [-h] [-v] [-n]
                  {signup,sup,resend,rs,confirm-signup,csup,update,up,reset,res,confirm-reset,cres,refresh,r,deauth,da,reauth,ra,delete,del}
                  ...

optional arguments:
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -n, --no-ask          enable non-interactive mode

commands:
  {signup,sup,resend,rs,confirm-signup,csup,update,up,reset,res,confirm-reset,cres,refresh,r,deauth,da,reauth,ra,delete,del}
    signup (sup)        sign up for EVS account
    resend (rs)         resend EVS account confirmation code
    confirm-signup (csup)
                        confirm account signup
    update (up)         update account details
    reset (res)         reset account password
    confirm-reset (cres)
                        confirm account password reset
    refresh (r)         refresh authorization tokens
    deauth (da)         discard any authorization tokens
    reauth (ra)         discard any authorization tokens & refresh
    delete (del)        delete EVS account
```
```
% python3 -m castlabs_evs.vmp --help
usage: vmp.py [-h] [-v] [-n] [-a] {verify,v,sign,s,verify-pkg,vp,sign-pkg,sp} ...

optional arguments:
  -h, --help            show this help message and exit
  -v, --version         show program's version number and exit
  -n, --no-ask          enable non-interactive mode
  -a, --any-ski         verify any subject key identifier

commands:
  {verify,v,sign,s,verify-pkg,vp,sign-pkg,sp}
    verify (v)          verify signature
    sign (s)            refresh signature
    verify-pkg (vp)     verify electron package signature
    sign-pkg (sp)       refresh electron package signature
```

# Legal notice / Disclaimer

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. UPDATES, INCLUDING SECURITY UPDATES, WILL BE PROVIDED ON A BEST-EFFORT BASIS.
