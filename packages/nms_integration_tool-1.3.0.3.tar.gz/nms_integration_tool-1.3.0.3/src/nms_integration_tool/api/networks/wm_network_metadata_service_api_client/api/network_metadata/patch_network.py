from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.network import Network
from ...models.patch_network_body import PatchNetworkBody
from ...types import Response


def _get_kwargs(
    network_uuid: UUID,
    *,
    body: PatchNetworkBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/metadata/networks/{network_uuid}".format(
            network_uuid=quote(str(network_uuid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | Network | str:
    if response.status_code == 200:
        response_200 = Network.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = response.text
        return response_401

    if response.status_code == 403:
        response_403 = response.text
        return response_403

    if response.status_code == 404:
        response_404 = response.text
        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    response_default = response.text
    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | Network | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    network_uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: PatchNetworkBody,
) -> Response[ErrorResponse | Network | str]:
    """Partially/patch update the network

     Update the given fields in a specific network identified by UUID.

    **NOTE:** The item given in the body may not be a complete network object, thus only those fields
    that are given are updated.

    Args:
        network_uuid (UUID):
        body (PatchNetworkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | Network | str]
    """

    kwargs = _get_kwargs(
        network_uuid=network_uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    network_uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: PatchNetworkBody,
) -> ErrorResponse | Network | str | None:
    """Partially/patch update the network

     Update the given fields in a specific network identified by UUID.

    **NOTE:** The item given in the body may not be a complete network object, thus only those fields
    that are given are updated.

    Args:
        network_uuid (UUID):
        body (PatchNetworkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | Network | str
    """

    return sync_detailed(
        network_uuid=network_uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    network_uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: PatchNetworkBody,
) -> Response[ErrorResponse | Network | str]:
    """Partially/patch update the network

     Update the given fields in a specific network identified by UUID.

    **NOTE:** The item given in the body may not be a complete network object, thus only those fields
    that are given are updated.

    Args:
        network_uuid (UUID):
        body (PatchNetworkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | Network | str]
    """

    kwargs = _get_kwargs(
        network_uuid=network_uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    network_uuid: UUID,
    *,
    client: AuthenticatedClient,
    body: PatchNetworkBody,
) -> ErrorResponse | Network | str | None:
    """Partially/patch update the network

     Update the given fields in a specific network identified by UUID.

    **NOTE:** The item given in the body may not be a complete network object, thus only those fields
    that are given are updated.

    Args:
        network_uuid (UUID):
        body (PatchNetworkBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | Network | str
    """

    return (
        await asyncio_detailed(
            network_uuid=network_uuid,
            client=client,
            body=body,
        )
    ).parsed
