from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.node import Node
from ...types import Response


def _get_kwargs(
    node_uuid: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/metadata/nodes/{node_uuid}".format(
            node_uuid=quote(str(node_uuid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | Node | str:
    if response.status_code == 200:
        response_200 = Node.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = response.text
        return response_401

    if response.status_code == 403:
        response_403 = response.text
        return response_403

    if response.status_code == 404:
        response_404 = response.text
        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    response_default = response.text
    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | Node | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    node_uuid: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | Node | str]:
    """Obtain information about a node

     Obtain information about a specific node identified by the UUID

    Args:
        node_uuid (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | Node | str]
    """

    kwargs = _get_kwargs(
        node_uuid=node_uuid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    node_uuid: UUID,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | Node | str | None:
    """Obtain information about a node

     Obtain information about a specific node identified by the UUID

    Args:
        node_uuid (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | Node | str
    """

    return sync_detailed(
        node_uuid=node_uuid,
        client=client,
    ).parsed


async def asyncio_detailed(
    node_uuid: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | Node | str]:
    """Obtain information about a node

     Obtain information about a specific node identified by the UUID

    Args:
        node_uuid (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | Node | str]
    """

    kwargs = _get_kwargs(
        node_uuid=node_uuid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    node_uuid: UUID,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | Node | str | None:
    """Obtain information about a node

     Obtain information about a specific node identified by the UUID

    Args:
        node_uuid (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | Node | str
    """

    return (
        await asyncio_detailed(
            node_uuid=node_uuid,
            client=client,
        )
    ).parsed
