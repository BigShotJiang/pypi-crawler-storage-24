"""Unit tests for Workflow classes (no API required)."""
import sys
import os

# Add parent to path for local development
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from meter_sdk import Workflow, Filter


def test_workflow_init():
    """Test Workflow initialization."""
    workflow = Workflow("Test Workflow", description="A test")
    assert workflow.name == "Test Workflow"
    assert workflow.description == "A test"
    assert workflow._nodes == []
    assert workflow._edges == []


def test_workflow_start():
    """Test creating a start node."""
    workflow = Workflow("Test")
    node = workflow.start("index", "strategy-123", urls=["https://example.com"])

    assert node.name == "index"
    assert node.strategy_id == "strategy-123"
    assert node.urls == ["https://example.com"]
    assert node.url_field is None
    assert node.workflow is workflow
    assert len(workflow._nodes) == 1


def test_workflow_then():
    """Test chaining a downstream node."""
    workflow = Workflow("Test")
    start = workflow.start("index", "strategy-1", urls=["https://example.com"])
    detail = start.then("detail", "strategy-2", url_field="link")

    assert detail.name == "detail"
    assert detail.strategy_id == "strategy-2"
    assert detail.urls is None
    assert detail.url_field == "link"
    assert len(workflow._nodes) == 2
    assert len(workflow._edges) == 1
    assert workflow._edges[0] == {
        "source_node_key": "index",
        "target_node_key": "detail"
    }


def test_workflow_to_dict():
    """Test workflow serialization."""
    workflow = Workflow("Job Scraper", description="Scrapes jobs")
    index = workflow.start("index", "strategy-1", urls=["https://jobs.com"])
    details = index.then("details", "strategy-2", url_field="job_link")

    result = workflow.to_dict()

    assert result["name"] == "Job Scraper"
    assert result["description"] == "Scrapes jobs"
    assert len(result["nodes"]) == 2
    assert len(result["edges"]) == 1

    # Check start node
    assert result["nodes"][0] == {
        "node_key": "index",
        "strategy_id": "strategy-1",
        "input_type": "static_urls",
        "static_urls": ["https://jobs.com"]
    }

    # Check downstream node
    assert result["nodes"][1] == {
        "node_key": "details",
        "strategy_id": "strategy-2",
        "input_type": "upstream_urls",
        "url_field": "job_link"
    }

    # Check edge
    assert result["edges"][0] == {
        "source_node_key": "index",
        "target_node_key": "details"
    }


def test_fan_out_pattern():
    """Test fan-out: one source, multiple downstream nodes."""
    workflow = Workflow("Fan-Out")
    products = workflow.start("products", "list-strategy", urls=["https://shop.com"])
    products.then("reviews", "review-strategy", url_field="review_url")
    products.then("specs", "spec-strategy", url_field="spec_url")
    products.then("pricing", "price-strategy", url_field="price_url")

    result = workflow.to_dict()

    assert len(result["nodes"]) == 4
    assert len(result["edges"]) == 3

    # All edges should start from "products"
    for edge in result["edges"]:
        assert edge["source_node_key"] == "products"

    # Check targets
    targets = {e["target_node_key"] for e in result["edges"]}
    assert targets == {"reviews", "specs", "pricing"}


def test_chained_pattern():
    """Test chain: A -> B -> C."""
    workflow = Workflow("Chain")
    a = workflow.start("a", "strategy-a", urls=["https://example.com"])
    b = a.then("b", "strategy-b", url_field="link_b")
    c = b.then("c", "strategy-c", url_field="link_c")

    result = workflow.to_dict()

    assert len(result["nodes"]) == 3
    assert len(result["edges"]) == 2

    edges = {e["source_node_key"]: e["target_node_key"] for e in result["edges"]}
    assert edges == {"a": "b", "b": "c"}


def test_multiple_start_nodes():
    """Test workflow with multiple independent start nodes."""
    workflow = Workflow("Multi-Start")
    start1 = workflow.start("site_a", "strategy-1", urls=["https://a.com"])
    start2 = workflow.start("site_b", "strategy-2", urls=["https://b.com"])
    start1.then("details_a", "strategy-3", url_field="link")
    start2.then("details_b", "strategy-3", url_field="link")

    result = workflow.to_dict()

    assert len(result["nodes"]) == 4
    assert len(result["edges"]) == 2

    edges = {e["source_node_key"]: e["target_node_key"] for e in result["edges"]}
    assert edges == {"site_a": "details_a", "site_b": "details_b"}


def test_filter_contains():
    """Test Filter.contains creates correct structure."""
    f = Filter.contains("link", "article")
    assert f == {
        "field": "link",
        "operator": "contains",
        "value": "article",
        "case_sensitive": False
    }


def test_filter_with_case_sensitive():
    """Test Filter methods with case_sensitive=True."""
    f = Filter.equals("title", "BREAKING", case_sensitive=True)
    assert f["case_sensitive"] is True


def test_filter_exists():
    """Test Filter.exists creates correct structure."""
    f = Filter.exists("author")
    assert f == {"field": "author", "operator": "exists"}
    assert "value" not in f


def test_filter_all():
    """Test Filter.all combines conditions."""
    f = Filter.all(
        Filter.contains("link", "article"),
        Filter.not_contains("link", "video")
    )
    assert f["mode"] == "all"
    assert len(f["conditions"]) == 2
    assert f["conditions"][0]["operator"] == "contains"
    assert f["conditions"][1]["operator"] == "not_contains"


def test_filter_any():
    """Test Filter.any combines conditions."""
    f = Filter.any(
        Filter.contains("link", "ice"),
        Filter.contains("link", "trump")
    )
    assert f["mode"] == "any"
    assert len(f["conditions"]) == 2


def test_workflow_then_with_filter():
    """Test chaining with a filter."""
    workflow = Workflow("Test")
    start = workflow.start("index", "strategy-1", urls=["https://example.com"])
    detail = start.then("detail", "strategy-2", url_field="link",
                        filter=Filter.contains("link", "article"))

    assert len(workflow._edges) == 1
    edge = workflow._edges[0]
    assert "filter_config" in edge
    assert edge["filter_config"]["mode"] == "all"
    assert len(edge["filter_config"]["conditions"]) == 1
    assert edge["filter_config"]["conditions"][0]["operator"] == "contains"


def test_workflow_then_with_compound_filter():
    """Test chaining with Filter.all/any."""
    workflow = Workflow("Test")
    start = workflow.start("index", "strategy-1", urls=["https://example.com"])
    detail = start.then("detail", "strategy-2", url_field="link",
                        filter=Filter.all(
                            Filter.contains("link", "article"),
                            Filter.not_contains("link", "video")
                        ))

    edge = workflow._edges[0]
    assert edge["filter_config"]["mode"] == "all"
    assert len(edge["filter_config"]["conditions"]) == 2


def test_workflow_to_dict_with_filter():
    """Test workflow serialization includes filter_config."""
    workflow = Workflow("Filtered", description="Test")
    index = workflow.start("index", "strategy-1", urls=["https://example.com"])
    details = index.then("details", "strategy-2", url_field="link",
                         filter=Filter.contains("link", "ice"))

    result = workflow.to_dict()

    assert len(result["edges"]) == 1
    edge = result["edges"][0]
    assert edge["filter_config"] == {
        "mode": "all",
        "conditions": [{
            "field": "link",
            "operator": "contains",
            "value": "ice",
            "case_sensitive": False
        }]
    }


def test_workflow_to_dict_with_parameter_config():
    """Test workflow serialization includes parameter_config on nodes."""
    workflow = Workflow("Parameterized")
    index = workflow.start("index", "strategy-1", urls=["https://example.com"])
    param_config = {
        "mappings": [{"source_field": "id", "target_param": "item_id"}],
        "execution_mode": "per_result"
    }
    details = index.then("details", "strategy-2", url_field="link",
                         parameter_config=param_config)

    result = workflow.to_dict()

    # Second node should have parameter_config
    assert result["nodes"][1]["parameter_config"] == param_config


if __name__ == "__main__":
    print("Running unit tests...\n")

    tests = [
        test_workflow_init,
        test_workflow_start,
        test_workflow_then,
        test_workflow_to_dict,
        test_fan_out_pattern,
        test_chained_pattern,
        test_multiple_start_nodes,
        test_filter_contains,
        test_filter_with_case_sensitive,
        test_filter_exists,
        test_filter_all,
        test_filter_any,
        test_workflow_then_with_filter,
        test_workflow_then_with_compound_filter,
        test_workflow_to_dict_with_filter,
        test_workflow_to_dict_with_parameter_config,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            print(f"  PASS: {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {test.__name__} - {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {test.__name__} - {e}")
            failed += 1

    print(f"\nResults: {passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
