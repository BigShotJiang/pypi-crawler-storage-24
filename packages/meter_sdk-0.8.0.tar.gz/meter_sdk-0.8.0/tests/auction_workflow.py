#!/usr/bin/env python3
"""
Rich Demo: Auction Pipeline Workflow

An educational demo showcasing Meter's workflow capabilities with
beautiful terminal output using the rich library.

Usage:
    export METER_API_KEY=your_api_key
    python tests/auction_workflow.py
"""
import json
import os
import sys
import time

# Add parent to path for local development
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.syntax import Syntax
from rich.text import Text
from rich.rule import Rule
from rich import box

from meter_sdk import MeterClient, Workflow

# Configuration
API_KEY = os.getenv("METER_API_KEY")
API_BASE = os.getenv("API_BASE", "http://localhost:8000")

# Strategy IDs
LIVE_AUCTION_ID = "908725ee-b668-4d69-a291-cbe32bb8493f"
AUCTION_ITEMS_ID = "eb71a690-137c-4d25-963d-1e70993045f8"

# Workflow name for reuse
WORKFLOW_NAME = "Auction Pipeline"

# Start URL
START_URL = "https://bid.claytonauction.com/ui"

console = Console()


# =============================================================================
# Helper Functions
# =============================================================================

def status_badge(status: str) -> Text:
    """Return a colored status badge."""
    colors = {
        "pending": "dim white",
        "running": "bold yellow",
        "completed": "bold green",
        "failed": "bold red",
        "partial": "bold orange3"
    }
    return Text(f" {status.upper()} ", style=f"{colors.get(status, 'white')} reverse")


def explain_concept(title: str, explanation: str):
    """Display an educational panel explaining a Meter concept."""
    console.print()
    console.print(Panel(
        Text(explanation, style="white"),
        title=f"[bold cyan]{title}[/]",
        border_style="cyan",
        padding=(1, 2)
    ))


def find_workflow_by_name(workflows, name):
    """Find a workflow by exact name."""
    for w in workflows:
        if w.get("name") == name:
            return w
    return None


def visualize_dag(name: str, description: str):
    """Create a tree visualization of the workflow DAG."""
    tree = Tree(f"[bold blue]{name}[/]")
    tree.add(f"[dim]{description}[/]")

    first_node = tree.add("[cyan]first[/] [dim](start node)[/]")
    first_node.add("[dim]Strategy:[/] Live Auction Extractor")
    first_node.add("[dim]Input:[/] static_urls")
    first_node.add(f"[dim]URL:[/] {START_URL}")

    second_node = first_node.add("[cyan]second[/] [dim](downstream node)[/]")
    second_node.add("[dim]Strategy:[/] Auction Items Extractor")
    second_node.add("[dim]Input:[/] parameter_mapping")
    second_node.add("[dim]Maps:[/] past.results[*].id → auction_id")

    return tree


def create_results_table(results: list, title: str = "Extracted Data", max_rows: int = 8) -> Table:
    """Create a table showing extracted results."""
    if not results:
        return Panel("[dim]No results[/]", title=title)

    # Get columns from first result, limit to readable amount
    sample = results[0]
    columns = list(sample.keys())[:5]

    table = Table(title=title, box=box.ROUNDED, show_lines=True)
    for col in columns:
        table.add_column(col, overflow="fold", max_width=40)

    for item in results[:max_rows]:
        row = []
        for col in columns:
            val = str(item.get(col, ""))
            if len(val) > 40:
                val = val[:37] + "..."
            row.append(val)
        table.add_row(*row)

    if len(results) > max_rows:
        table.add_row(*[f"[dim]... +{len(results) - max_rows} more[/]"] + [""] * (len(columns) - 1))

    return table


def create_node_status_table(node_executions: list) -> Table:
    """Create a table showing node execution status."""
    table = Table(box=box.SIMPLE)
    table.add_column("Node", style="cyan")
    table.add_column("Status")
    table.add_column("Results", justify="right")

    for ex in node_executions:
        node_key = ex.get("node_key", ex.get("node_id", "?")[:8])
        status = ex.get("status", "unknown")
        results = ex.get("results")
        result_count = str(len(results)) if results else "-"

        table.add_row(node_key, status_badge(status), result_count)

    return table


# =============================================================================
# Main Demo
# =============================================================================

def main():
    if not API_KEY:
        console.print("[red bold]Error:[/] METER_API_KEY environment variable not set")
        console.print("Export it with: [cyan]export METER_API_KEY=your_key_here[/]")
        sys.exit(1)

    # =========================================================================
    # Phase 1: Introduction
    # =========================================================================
    console.print()
    console.rule("[bold blue]Meter Workflow Demo: Auction Pipeline[/]", style="blue")

    explain_concept(
        "What are Meter Workflows?",
        "Workflows are DAG-based pipelines that chain scraping strategies together.\n"
        "The output of one node feeds into the next, enabling complex multi-step\n"
        "extractions. This demo scrapes auction listings, then fetches details for each."
    )

    # Configuration table
    config_table = Table(title="Configuration", box=box.ROUNDED)
    config_table.add_column("Setting", style="cyan")
    config_table.add_column("Value")
    config_table.add_row("API Base", API_BASE)
    config_table.add_row("Start URL", START_URL)
    config_table.add_row("Strategy 1", f"Live Auction ({LIVE_AUCTION_ID[:8]}...)")
    config_table.add_row("Strategy 2", f"Auction Items ({AUCTION_ITEMS_ID[:8]}...)")
    console.print()
    console.print(config_table)

    client = MeterClient(api_key=API_KEY, base_url=API_BASE)

    try:
        # =====================================================================
        # Phase 2: Workflow Discovery
        # =====================================================================
        console.print()
        console.rule("[bold]Phase 2: Workflow Discovery[/]")

        explain_concept(
            "Workflow Reuse",
            "Workflows are persisted server-side. If a workflow with the same name\n"
            "already exists, we can reuse it instead of creating a new one."
        )

        with console.status("[bold yellow]Checking for existing workflows...[/]"):
            workflows = client.list_workflows(limit=100)

        if workflows:
            wf_table = Table(title=f"Found {len(workflows)} Workflow(s)", box=box.ROUNDED)
            wf_table.add_column("Name", style="cyan")
            wf_table.add_column("ID")
            wf_table.add_column("Nodes", justify="right")
            for wf in workflows[:5]:
                wf_table.add_row(
                    wf.get("name", "?"),
                    wf.get("id", wf.get("workflow_id", "?"))[:12] + "...",
                    str(wf.get("node_count", len(wf.get("nodes", []))))
                )
            console.print()
            console.print(wf_table)

        existing_workflow = find_workflow_by_name(workflows, WORKFLOW_NAME)

        if existing_workflow:
            workflow_id = existing_workflow.get("id") or existing_workflow.get("workflow_id")
            console.print()
            console.print(f"[green]Found existing workflow:[/] {WORKFLOW_NAME}")
            console.print(f"[dim]Reusing workflow ID: {workflow_id}[/]")
        else:
            # =================================================================
            # Phase 3: Building the DAG
            # =================================================================
            console.print()
            console.print(f"[yellow]No existing workflow named '{WORKFLOW_NAME}'[/]")
            console.print()
            console.rule("[bold]Phase 3: Building the Workflow DAG[/]")

            explain_concept(
                "Nodes & Edges",
                "A workflow consists of nodes (scraping steps) connected by edges.\n"
                "Each node uses a strategy to extract data. Edges define how data\n"
                "flows from one node to the next."
            )

            explain_concept(
                "Parameter Mapping",
                "Parameter mapping allows downstream nodes to receive values extracted\n"
                "from upstream results. JSONPath expressions specify which fields to\n"
                "extract. In this demo:\n\n"
                "  source_field: 'past.results[*].id'  (extract all auction IDs)\n"
                "  target_param: 'auction_id'          (pass to downstream strategy)\n"
                "  execution_mode: 'per_result'        (run once per ID)"
            )

            # Build the workflow
            workflow = Workflow(WORKFLOW_NAME, description="Extracts auction IDs and fetches details")
            first = workflow.start("first", LIVE_AUCTION_ID, urls=[START_URL])
            second = first.then("second", AUCTION_ITEMS_ID,
                                parameter_config={
                                    "mappings": [
                                        {"source_field": "past.results[*].id", "target_param": "auction_id"}
                                    ],
                                    "execution_mode": "per_result"
                                })

            # Visualize the DAG
            console.print()
            dag_tree = visualize_dag(WORKFLOW_NAME, workflow.description)
            console.print(Panel(dag_tree, title="[bold]Workflow DAG[/]", border_style="green"))

            # =================================================================
            # Phase 4: Creating Workflow
            # =================================================================
            console.print()
            console.rule("[bold]Phase 4: Creating Workflow via API[/]")

            # Show the payload
            payload = workflow.to_dict()
            console.print()
            console.print("[dim]API Request Payload:[/]")
            console.print(Syntax(json.dumps(payload, indent=2), "json", theme="monokai"))

            with console.status("[bold yellow]Creating workflow...[/]"):
                created = client.create_workflow(workflow)

            workflow_id = created.get("id") or created.get("workflow_id")
            console.print()
            console.print(f"[green]Workflow created![/] ID: [cyan]{workflow_id}[/]")

        # =====================================================================
        # Phase 5: Execution & Live Monitoring
        # =====================================================================
        console.print()
        console.rule("[bold]Phase 5: Running & Monitoring[/]")

        explain_concept(
            "Workflow Execution",
            "When a workflow runs, each node executes in order. The first node\n"
            "scrapes the start URL. When complete, its results feed into the\n"
            "second node via parameter mapping. Results appear as nodes complete."
        )

        # Start the run
        with console.status("[bold yellow]Starting workflow run...[/]"):
            run = client.run_workflow(workflow_id, force=True, wait=False)

        run_id = run.get("id") or run.get("run_id")
        console.print()
        console.print(f"[green]Run started![/] ID: [cyan]{run_id}[/]")

        # Poll with progressive results
        console.print()
        console.print("[bold]Monitoring execution...[/]")
        console.print()

        seen_nodes = set()

        for i in range(24):  # Poll for up to 2 minutes
            time.sleep(5)
            run = client.get_workflow_run(workflow_id, run_id)
            elapsed = (i + 1) * 5

            # Show current status
            status = run.get("status", "unknown")
            console.print(f"[dim][{elapsed:3d}s][/] Status: ", end="")
            console.print(status_badge(status))

            # Show node execution status
            node_executions = run.get("node_executions", [])
            if node_executions:
                console.print(create_node_status_table(node_executions))

                # Progressive results - show as each node completes
                for ex in node_executions:
                    node_key = ex.get("node_key", ex.get("node_id", "?")[:8])
                    node_status = ex.get("status")
                    results = ex.get("results")

                    if node_status == "completed" and node_key not in seen_nodes and results:
                        seen_nodes.add(node_key)
                        console.print()
                        console.print(create_results_table(
                            results,
                            title=f"Results from node: [cyan]{node_key}[/]"
                        ))

            console.print()

            if status in ("completed", "failed", "partial"):
                break

        # =====================================================================
        # Phase 6: Final Results
        # =====================================================================
        console.print()
        console.rule("[bold]Phase 6: Final Results[/]")
        console.print()

        final_status = run.get("status", "unknown")

        if final_status == "completed":
            console.print(Panel(
                "[bold green]WORKFLOW COMPLETED SUCCESSFULLY[/]",
                border_style="green"
            ))

            final_results = run.get("final_results", [])

            # Summary stats
            stats_table = Table(box=box.ROUNDED)
            stats_table.add_column("Metric", style="cyan")
            stats_table.add_column("Value", justify="right")
            stats_table.add_row("Workflow ID", workflow_id)
            stats_table.add_row("Run ID", run_id)
            stats_table.add_row("Total Items Extracted", str(len(final_results)))
            stats_table.add_row("Nodes Executed", str(len(run.get("node_executions", []))))
            console.print(stats_table)

            # Final results (if not already shown progressively)
            if final_results and "second" not in seen_nodes:
                console.print()
                console.print(create_results_table(final_results, title="Final Extracted Data"))
        else:
            console.print(Panel(
                f"[bold red]WORKFLOW {final_status.upper()}[/]",
                border_style="red"
            ))

            if run.get("error"):
                console.print(f"[red]Error:[/] {run['error']}")

        console.print()

    except Exception as e:
        console.print(f"[red bold]Error:[/] {e}")
        import traceback
        console.print(traceback.format_exc())
        sys.exit(1)
    finally:
        client.close()


if __name__ == "__main__":
    main()
