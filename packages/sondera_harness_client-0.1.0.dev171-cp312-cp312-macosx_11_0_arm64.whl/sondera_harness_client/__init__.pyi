"""Type stubs for sondera_harness_client.

Python bindings for the Sondera harness client, providing a clean,
Pydantic-style data model for constructing, inspecting, and serializing
trajectory events used in AI agent governance.

Example::

    from sondera_harness_client import Event, Agent, ToolCall, Actor

    agent = Agent(id="claude-1", provider="anthropic")
    tc = ToolCall(tool="Bash", arguments={"command": "ls"})
    event = Event(agent=agent, trajectory_id="traj-001", event=tc)

    print(event.category)    # "action"
    print(event.event_type)  # "tool_call"
    print(event.to_json())
"""

from collections.abc import Coroutine
from typing import Any, Self

# ============================================================================
# Enums
# ============================================================================

class Decision:
    """Policy evaluation decision returned by the governance engine.

    Variants:
        Allow: The action is permitted.
        Deny: The action is blocked.
        Escalate: The action requires human review before proceeding.

    Can be constructed from a string::

        Decision("allow")  # Decision.Allow
    """

    Allow: Decision
    Deny: Decision
    Escalate: Decision
    def __init__(self, value: str) -> None:
        """Create a Decision from a string value.

        Args:
            value: One of ``"allow"``, ``"deny"``, or ``"escalate"`` (case-insensitive).

        Raises:
            ValueError: If the value is not a valid decision string.
        """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class ActorType:
    """Type of actor performing an action within a trajectory.

    Variants:
        Human: A human user.
        Agent: An AI agent.
        System: An automated system or infrastructure component.
        Policy: The governance policy engine itself.
    """

    Human: ActorType
    Agent: ActorType
    System: ActorType
    Policy: ActorType
    def __init__(self, value: str) -> None:
        """Create an ActorType from a string value.

        Args:
            value: One of ``"human"``, ``"agent"``, ``"system"``, or ``"policy"``
                (case-insensitive).

        Raises:
            ValueError: If the value is not a valid actor type string.
        """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class FileOpType:
    """Type of file system operation.

    Variants:
        Read: Reading file contents.
        Write: Creating or overwriting a file.
        Edit: Modifying part of an existing file.
        Delete: Removing a file.
    """

    Read: FileOpType
    Write: FileOpType
    Edit: FileOpType
    Delete: FileOpType
    def __init__(self, value: str) -> None:
        """Create a FileOpType from a string value.

        Args:
            value: One of ``"read"``, ``"write"``, ``"edit"``, or ``"delete"``
                (case-insensitive).

        Raises:
            ValueError: If the value is not a valid file operation type string.
        """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class PromptRole:
    """Role of a prompt message in a conversation.

    Variants:
        User: A message from the user.
        System: A system-level instruction or context.
        Assistant: A message from the assistant.
    """

    User: PromptRole
    System: PromptRole
    Assistant: PromptRole
    def __init__(self, value: str) -> None:
        """Create a PromptRole from a string value.

        Args:
            value: One of ``"user"``, ``"system"``, or ``"assistant"`` (case-insensitive).

        Raises:
            ValueError: If the value is not a valid prompt role string.
        """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class TrajectoryStatus:
    """Lifecycle status of a trajectory, derived from control events.

    Variants:
        Pending: No control events yet.
        Running: After a Started or Resumed event.
        Completed: After a Completed event.
        Failed: After a Failed event.
        Terminated: After a Terminated event.
        Suspended: After a Suspended event.

    Can be constructed from a string::

        TrajectoryStatus("running")  # TrajectoryStatus.Running
    """

    Pending: TrajectoryStatus
    Running: TrajectoryStatus
    Completed: TrajectoryStatus
    Failed: TrajectoryStatus
    Terminated: TrajectoryStatus
    Suspended: TrajectoryStatus
    def __init__(self, value: str) -> None:
        """Create a TrajectoryStatus from a string value.

        Args:
            value: One of ``"pending"``, ``"running"``, ``"completed"``,
                ``"failed"``, ``"terminated"``, or ``"suspended"`` (case-insensitive).

        Raises:
            ValueError: If the value is not a valid trajectory status string.
        """
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

# ============================================================================
# Core Types
# ============================================================================

class Parameter:
    """A tool parameter definition.

    Example::

        param = Parameter(name="command", description="The command to run", param_type="string")
    """

    @property
    def name(self) -> str:
        """Name of the parameter."""
    @property
    def description(self) -> str:
        """Description of the parameter."""
    @property
    def param_type(self) -> str:
        """Type of the parameter (JSON Schema types: "string", "number", "boolean", "object", "array")."""
    def __init__(self, name: str, description: str, param_type: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Parameter: ...

class SourceCode:
    """Source code attached to a tool."""

    @property
    def language(self) -> str:
        """Programming language of the source code."""
    @property
    def code(self) -> str:
        """The source code content."""
    def __init__(self, language: str, code: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> SourceCode: ...

class Tool:
    """A tool exposed by an agent.

    Example::

        tool = Tool(
            name="Bash",
            description="Execute bash commands",
            parameters=[Parameter("command", "The command", "string")],
        )
    """

    @property
    def id(self) -> str | None:
        """Optional unique identifier for the tool."""
    @property
    def name(self) -> str:
        """Name of the tool."""
    @property
    def description(self) -> str:
        """Description of the tool."""
    @property
    def parameters(self) -> list[Parameter]:
        """The parameters used by the tool."""
    @property
    def parameters_json_schema(self) -> str | None:
        """JSON schema for the tool parameters."""
    @property
    def response(self) -> str | None:
        """The type returned by the tool."""
    @property
    def response_json_schema(self) -> str | None:
        """JSON schema for the tool response."""
    @property
    def source(self) -> SourceCode | None:
        """Source code of the tool if available."""
    def __init__(
        self,
        name: str,
        description: str,
        parameters: list[Parameter],
        *,
        id: str | None = None,
        parameters_json_schema: str | None = None,
        response: str | None = None,
        response_json_schema: str | None = None,
        source: SourceCode | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Tool: ...

class ReActAgentCard:
    """A lightweight agent card for ReAct-style agents.

    Example::

        card = ReActAgentCard(model="claude-sonnet-4-20250514")
    """

    @property
    def model(self) -> str | None:
        """Model identifier for the runtime."""
    @property
    def system_instruction(self) -> str:
        """System instruction / prompt for the agent."""
    @property
    def tools(self) -> list[Tool]:
        """Tools available to the agent."""
    def __init__(
        self,
        *,
        model: str | None = None,
        system_instruction: str | None = None,
        tools: list[Tool] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> ReActAgentCard: ...

class AgentCardMetadata:
    """Metadata for a CodingAgentCard (schema and hook versions).

    Example::

        meta = AgentCardMetadata(schema_version="1", hook_version="0.1.0")
    """

    @property
    def schema_version(self) -> str:
        """AgentCard schema version."""
    @property
    def hook_version(self) -> str:
        """Runtime version that emitted this card."""
    def __init__(self, *, schema_version: str, hook_version: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> AgentCardMetadata: ...

class CodingAgentCardCapabilities:
    """Capability sections of a CodingAgentCard.

    Example::

        caps = CodingAgentCardCapabilities(tools=[tool1, tool2], slash_commands=["review"])
    """

    @property
    def tools(self) -> list[Tool]:
        """Tool-level capabilities."""
    @property
    def hook_commands(self) -> list[str]:
        """Built-in hook command names."""
    @property
    def slash_commands(self) -> list[str]:
        """Slash commands discovered from assets."""
    @property
    def named_agents(self) -> list[str]:
        """Named agents discovered from assets."""
    @property
    def skills(self) -> list[str]:
        """Skills discovered from assets."""
    def __init__(
        self,
        *,
        tools: list[Tool] | None = None,
        hook_commands: list[str] | None = None,
        slash_commands: list[str] | None = None,
        named_agents: list[str] | None = None,
        skills: list[str] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> CodingAgentCardCapabilities: ...

class CodingAgentCardAsset:
    """A capability-bearing artifact discovered during agent introspection.

    Example::

        asset = CodingAgentCardAsset(
            scope="project", kind="command", name="build",
            path="/workspace/.claude/commands/build.md", content_sha256="abc123",
        )
    """

    @property
    def scope(self) -> str:
        """Source scope (e.g., ``"project"``, ``"user"``)."""
    @property
    def kind(self) -> str:
        """Normalized asset kind (e.g., ``"command"``, ``"agent"``, ``"skill"``)."""
    @property
    def name(self) -> str:
        """Human identifier for the asset."""
    @property
    def path(self) -> str:
        """Absolute filesystem path."""
    @property
    def content_sha256(self) -> str:
        """SHA256 digest of the artifact content."""
    def __init__(
        self,
        *,
        scope: str,
        kind: str,
        name: str,
        path: str,
        content_sha256: str,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> CodingAgentCardAsset: ...

class CodingAgentCardSettingsSnapshot:
    """A settings snapshot from an agent runtime configuration.

    Example::

        snap = CodingAgentCardSettingsSnapshot(
            scope="project", path="/workspace/.claude/settings.json",
            content_sha256="abc123",
        )
    """

    @property
    def scope(self) -> str:
        """Source scope (e.g., ``"project-local"``, ``"project"``, ``"user"``)."""
    @property
    def path(self) -> str:
        """Absolute filesystem path."""
    @property
    def content_sha256(self) -> str:
        """SHA256 digest of the full settings file."""
    @property
    def allow_permissions(self) -> list[str]:
        """Allowed permissions list after normalization."""
    @property
    def deny_permissions(self) -> list[str]:
        """Denied permissions list after normalization."""
    @property
    def hook_commands(self) -> list[str]:
        """Hook command definitions extracted from settings."""
    def __init__(
        self,
        *,
        scope: str,
        path: str,
        content_sha256: str,
        allow_permissions: list[str] | None = None,
        deny_permissions: list[str] | None = None,
        hook_commands: list[str] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> CodingAgentCardSettingsSnapshot: ...

class CodingAgentCard:
    """Universal capability document for a coding agent runtime (SBOM-like).

    Example::

        card = CodingAgentCard(
            metadata=AgentCardMetadata(schema_version="1", hook_version="0.1.0"),
            workspace_root="/workspace",
            execution_mode="autonomous",
            capabilities=CodingAgentCardCapabilities(tools=[tool]),
        )
    """

    @property
    def metadata(self) -> AgentCardMetadata:
        """Card metadata (schema and hook versions)."""
    @property
    def model(self) -> str | None:
        """Model identifier for the runtime."""
    @property
    def workspace_root(self) -> str:
        """Workspace root used for this session."""
    @property
    def execution_mode(self) -> str:
        """Provider-agnostic execution mode label."""
    @property
    def system_instruction(self) -> str:
        """System instruction / prompt for the agent runtime."""
    @property
    def capabilities(self) -> CodingAgentCardCapabilities:
        """Normalized capability inventory."""
    @property
    def assets(self) -> list[CodingAgentCardAsset]:
        """Raw capability-bearing artifacts discovered during introspection."""
    @property
    def settings(self) -> list[CodingAgentCardSettingsSnapshot]:
        """Relevant runtime settings snapshots."""
    @property
    def normalized_context(self) -> dict[str, str]:
        """Additional normalized context from provider-specific adapters."""
    def __init__(
        self,
        *,
        metadata: AgentCardMetadata,
        workspace_root: str,
        execution_mode: str,
        capabilities: CodingAgentCardCapabilities,
        model: str | None = None,
        system_instruction: str | None = None,
        assets: list[CodingAgentCardAsset] | None = None,
        settings: list[CodingAgentCardSettingsSnapshot] | None = None,
        normalized_context: dict[str, str] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> CodingAgentCard: ...

class AgentCard:
    """Agent card enum wrapping the card variant attached to an Agent.

    Use the ``react`` or ``coding`` constructor to create a card::

        card = AgentCard.react(ReActAgentCard(model="claude-sonnet-4-20250514"))
        card = AgentCard.coding(CodingAgentCard(...))
    """

    @property
    def variant(self) -> str:
        """Variant name: ``"ReActAgentCard"`` or ``"CodingAgentCard"``."""
    @property
    def react_card(self) -> ReActAgentCard | None:
        """The inner ReActAgentCard, or None if this is a different variant."""
    @property
    def coding_card(self) -> CodingAgentCard | None:
        """The inner CodingAgentCard, or None if this is a different variant."""
    @staticmethod
    def react(card: ReActAgentCard) -> AgentCard:
        """Create an AgentCard from a ReActAgentCard."""
    @staticmethod
    def coding(card: CodingAgentCard) -> AgentCard:
        """Create an AgentCard from a CodingAgentCard."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> AgentCard: ...

class Agent:
    """An AI agent identity within the governance system.

    Represents the agent that is executing a trajectory, identified by a
    unique ID and the provider that hosts it.

    Example::

        agent = Agent(id="claude-1", provider="anthropic")
    """

    @property
    def id(self) -> str:
        """Unique identifier for the agent."""
    @property
    def provider(self) -> str:
        """Identifier of the provider hosting this agent (e.g., ``"anthropic"``)."""
    @property
    def platform(self) -> str:
        """Platform identifier (e.g., ``"claude-code"``)."""
    @property
    def card(self) -> AgentCard:
        """The agent's card describing its capabilities."""
    def __init__(
        self,
        id: str,
        provider: str,
        *,
        platform: str | None = None,
        card: AgentCard | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Agent: ...

class Actor:
    """An entity (human, agent, system, or policy) performing actions in a trajectory.

    Use the convenience constructors for common actor types::

        user = Actor.human("user-123")
        ai = Actor.agent("claude-1")
    """

    @property
    def id(self) -> str:
        """Unique identifier for the actor."""
    @property
    def actor_type(self) -> ActorType:
        """The type of this actor."""
    def __init__(self, id: str, actor_type: ActorType) -> None: ...
    @staticmethod
    def human(id: str) -> Actor:
        """Create a human actor."""
    @staticmethod
    def agent(id: str) -> Actor:
        """Create an AI agent actor."""
    @staticmethod
    def system(id: str) -> Actor:
        """Create a system actor."""
    @staticmethod
    def policy(id: str) -> Actor:
        """Create a policy engine actor."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Actor: ...

class Causality:
    """Causal linkage metadata for correlating and ordering events.

    Tracks the causal chain of events within a trajectory, enabling
    reconstruction of the execution graph.
    """

    @property
    def correlation_id(self) -> str:
        """Correlation ID grouping related events together."""
    @property
    def causation_id(self) -> str | None:
        """ID of the event that directly caused this one."""
    @property
    def parent_id(self) -> str | None:
        """ID of the logical parent event."""
    def __init__(
        self,
        *,
        correlation_id: str | None = None,
        causation_id: str | None = None,
        parent_id: str | None = None,
    ) -> None:
        """Create a new Causality.

        Args:
            correlation_id: Correlation ID (auto-generated UUID if not provided).
            causation_id: ID of the direct causal predecessor event.
            parent_id: ID of the logical parent event.
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Causality: ...

class PolicyMetadata:
    """Metadata attached to adjudication results from matching policies.

    Can optionally carry policy context—an associated policy ID,
    a human-readable description, escalation info, and arbitrary key-value
    metadata. Used by both :class:`Adjudicated` (trajectory event) and
    :class:`Adjudication` (standalone result).

    Example::

        pm = PolicyMetadata(
            policy_id="policy-001",
            description="Blocked by secret detection rule",
            escalate=True,
            escalate_arg="security-team",
            metadata={"severity": "high"},
        )
    """

    @property
    def policy_id(self) -> str | None:
        """ID of the policy that produced this metadata."""
    @property
    def description(self) -> str | None:
        """Human-readable description of the metadata."""
    @property
    def escalate(self) -> bool:
        """Whether this policy requires escalation to a human or other oracle."""
    @property
    def escalate_arg(self) -> str | None:
        """The argument passed to @escalate, if any."""
    @property
    def metadata(self) -> dict[str, str]:
        """Arbitrary key-value metadata."""
    def __init__(
        self,
        *,
        policy_id: str | None = None,
        description: str | None = None,
        escalate: bool = False,
        escalate_arg: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> PolicyMetadata: ...

# ============================================================================
# Action Types
# ============================================================================

class ToolCall:
    """An agent's invocation of a tool.

    Represents a request from the agent to execute a named tool with
    the given arguments. This is an *action* event—the corresponding
    result is a :class:`ToolOutput`.

    Example::

        tc = ToolCall(tool="Bash", arguments={"command": "ls -la"})
    """

    @property
    def call_id(self) -> str:
        """Unique identifier for this tool call (auto-generated if not provided)."""
    @property
    def tool(self) -> str:
        """Name of the tool being invoked."""
    @property
    def arguments(self) -> Any:
        """Arguments passed to the tool (typically a dict)."""
    def __init__(
        self, tool: str, arguments: Any, *, call_id: str | None = None
    ) -> None:
        """Create a new ToolCall.

        Args:
            tool: Name of the tool to invoke.
            arguments: Arguments for the tool (any JSON-serializable value).
            call_id: Unique call identifier (auto-generated UUID if not provided).
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> ToolCall: ...

class ShellCommand:
    """An agent's execution of a shell command.

    Represents a request to run a command in a shell. The corresponding
    result is a :class:`ShellCommandOutput`.

    Example::

        cmd = ShellCommand("git status", working_dir="/repo")
    """

    @property
    def call_id(self) -> str:
        """Unique identifier for this call (auto-generated if not provided)."""
    @property
    def command(self) -> str:
        """The shell command string to execute."""
    @property
    def working_dir(self) -> str | None:
        """Working directory for command execution, if specified."""
    def __init__(
        self,
        command: str,
        *,
        working_dir: str | None = None,
        call_id: str | None = None,
    ) -> None:
        """Create a new ShellCommand.

        Args:
            command: The shell command to execute.
            working_dir: Working directory for execution.
            call_id: Unique call identifier (auto-generated UUID if not provided).
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> ShellCommand: ...

class WebFetch:
    """An agent's request to fetch content from a URL.

    Represents a web fetch action with an associated prompt describing
    the intent. The corresponding result is a :class:`WebFetchOutput`.

    Example::

        fetch = WebFetch(url="https://example.com/api", prompt="Get the status")
    """

    @property
    def call_id(self) -> str:
        """Unique identifier for this call (auto-generated if not provided)."""
    @property
    def url(self) -> str:
        """The URL to fetch."""
    @property
    def prompt(self) -> str:
        """Description of what to extract or why the fetch is being made."""
    def __init__(self, url: str, prompt: str, *, call_id: str | None = None) -> None:
        """Create a new WebFetch.

        Args:
            url: The URL to fetch content from.
            prompt: Description of the fetch intent.
            call_id: Unique call identifier (auto-generated UUID if not provided).
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> WebFetch: ...

class FileOperation:
    """An agent's file system operation.

    Represents a read, write, edit, or delete on a file. The corresponding
    result is a :class:`FileOperationResult`. Use the convenience constructors
    for common operations::

        FileOperation.read("/etc/hosts")
        FileOperation.write("/tmp/out.txt", "hello")
        FileOperation.edit("file.py", old_content="foo", new_content="bar")
        FileOperation.delete("/tmp/out.txt")
    """

    @property
    def call_id(self) -> str:
        """Unique identifier for this call (auto-generated if not provided)."""
    @property
    def operation(self) -> FileOpType:
        """The type of file operation."""
    @property
    def path(self) -> str:
        """Path to the target file."""
    @property
    def content(self) -> str | None:
        """New file content (for write operations, or the replacement content for edits)."""
    @property
    def old_content(self) -> str | None:
        """Previous file content being replaced (for edit operations)."""
    def __init__(
        self,
        operation: FileOpType,
        path: str,
        *,
        content: str | None = None,
        old_content: str | None = None,
        call_id: str | None = None,
    ) -> None:
        """Create a new FileOperation.

        Args:
            operation: The type of file operation.
            path: Path to the target file.
            content: New file content (for write, or replacement content for edit).
            old_content: Previous content being replaced (for edit operations).
            call_id: Unique call identifier (auto-generated UUID if not provided).
        """
    @staticmethod
    def read(path: str) -> FileOperation:
        """Create a file read operation."""
    @staticmethod
    def write(path: str, content: str) -> FileOperation:
        """Create a file write operation."""
    @staticmethod
    def edit(path: str, old_content: str, new_content: str) -> FileOperation:
        """Create a file edit operation."""
    @staticmethod
    def delete(path: str) -> FileOperation:
        """Create a file delete operation."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> FileOperation: ...

# ============================================================================
# Observation Types
# ============================================================================

class Prompt:
    """A prompt message observed in the agent's conversation.

    Represents a user or system message that the agent receives as input.

    Example::

        Prompt.user("What files are in this directory?")
        Prompt.system("You are a helpful assistant.")
    """

    @property
    def content(self) -> str:
        """The text content of the prompt message."""
    @property
    def role(self) -> PromptRole:
        """The role of the message sender (user or system)."""
    def __init__(self, content: str, role: PromptRole) -> None: ...
    @staticmethod
    def user(content: str) -> Prompt:
        """Create a user prompt."""
    @staticmethod
    def system(content: str) -> Prompt:
        """Create a system prompt."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Prompt: ...

class Thought:
    """An agent's internal reasoning step.

    Captures the agent's chain-of-thought or internal monologue before
    taking an action.

    Example::

        Thought("I should check the file permissions before editing.")
    """

    @property
    def thought(self) -> str:
        """The agent's internal reasoning text."""
    def __init__(self, thought: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Thought: ...

class ToolOutput:
    """The result of a tool invocation.

    Corresponds to a preceding :class:`ToolCall`, linked by ``call_id``.

    Example::

        ToolOutput.from_success("call-123", {"files": ["a.py", "b.py"]})
        ToolOutput.from_error("call-123", "Permission denied")
    """

    @property
    def call_id(self) -> str:
        """ID of the corresponding tool call."""
    @property
    def success(self) -> bool:
        """Whether the tool call succeeded."""
    @property
    def output(self) -> Any:
        """The tool's output value (any JSON-serializable type)."""
    @property
    def error(self) -> str | None:
        """Error message if the tool call failed."""
    def __init__(
        self,
        call_id: str,
        success: bool,
        output: Any,
        *,
        error: str | None = None,
    ) -> None:
        """Create a new ToolOutput.

        Args:
            call_id: ID of the corresponding tool call.
            success: Whether the tool call succeeded.
            output: The tool's output value.
            error: Error message if the call failed.
        """
    @staticmethod
    def from_success(call_id: str, output: Any) -> ToolOutput:
        """Create a successful tool output."""
    @staticmethod
    def from_error(call_id: str, error: str) -> ToolOutput:
        """Create a failed tool output."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> ToolOutput: ...

class ShellCommandOutput:
    """The result of a shell command execution.

    Corresponds to a preceding :class:`ShellCommand`, linked by ``call_id``.
    """

    @property
    def call_id(self) -> str:
        """ID of the corresponding shell command."""
    @property
    def exit_code(self) -> int:
        """Process exit code (0 typically indicates success)."""
    @property
    def stdout(self) -> str:
        """Standard output from the command."""
    @property
    def stderr(self) -> str:
        """Standard error from the command."""
    def __init__(
        self, call_id: str, exit_code: int, stdout: str, stderr: str
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> ShellCommandOutput: ...

class WebFetchOutput:
    """The result of a web fetch operation.

    Corresponds to a preceding :class:`WebFetch`, linked by ``call_id``.
    """

    @property
    def call_id(self) -> str:
        """ID of the corresponding web fetch."""
    @property
    def url(self) -> str:
        """The URL that was fetched."""
    @property
    def code(self) -> int:
        """HTTP status code of the response."""
    @property
    def result(self) -> str:
        """The fetched content."""
    def __init__(self, call_id: str, url: str, code: int, result: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> WebFetchOutput: ...

class FileOperationResult:
    """The result of a file system operation.

    Corresponds to a preceding :class:`FileOperation`, linked by ``call_id``.

    Example::

        FileOperationResult.from_success("call-123")
        FileOperationResult.from_error("call-123", "File not found")
    """

    @property
    def call_id(self) -> str:
        """ID of the corresponding file operation."""
    @property
    def success(self) -> bool:
        """Whether the file operation succeeded."""
    @property
    def content(self) -> str | None:
        """File content returned by read operations."""
    @property
    def error(self) -> str | None:
        """Error message if the operation failed."""
    def __init__(
        self,
        call_id: str,
        success: bool,
        *,
        content: str | None = None,
        error: str | None = None,
    ) -> None:
        """Create a new FileOperationResult.

        Args:
            call_id: ID of the corresponding file operation.
            success: Whether the operation succeeded.
            content: File content (for successful read operations).
            error: Error message if the operation failed.
        """
    @staticmethod
    def from_success(call_id: str) -> FileOperationResult:
        """Create a successful file operation result."""
    @staticmethod
    def from_error(call_id: str, error: str) -> FileOperationResult:
        """Create a failed file operation result."""
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> FileOperationResult: ...

# ============================================================================
# Control Types
# ============================================================================

class Started:
    """Signals that an agent trajectory has begun.

    Emitted as the first event in a trajectory.

    Example::

        agent = Agent(id="claude-1", provider="anthropic")
        Started(agent=agent, task="Refactor the auth module")
    """

    @property
    def agent(self) -> Agent:
        """The agent that started."""
    @property
    def task(self) -> str | None:
        """Description of the task the agent is performing."""
    def __init__(self, agent: Agent, *, task: str | None = None) -> None:
        """Create a new Started event.

        Args:
            agent: The agent starting the trajectory.
            task: Optional description of the task.
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Started: ...

class Completed:
    """Signals that an agent trajectory completed successfully.

    Emitted as the final event when the agent finishes its task.
    """

    @property
    def summary(self) -> str | None:
        """Optional summary of what the agent accomplished."""
    def __init__(self, *, summary: str | None = None) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Completed: ...

class Failed:
    """Signals that an agent trajectory failed due to an error."""

    @property
    def reason(self) -> str:
        """Description of why the trajectory failed."""
    def __init__(self, reason: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Failed: ...

class Terminated:
    """Signals that an agent trajectory was externally terminated.

    Unlike :class:`Failed`, termination is an intentional stop by an
    external actor (e.g., a user or policy).
    """

    @property
    def reason(self) -> str:
        """Description of why the trajectory was terminated."""
    @property
    def terminated_by(self) -> str:
        """Identifier of the actor who terminated the trajectory."""
    def __init__(self, reason: str, terminated_by: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Terminated: ...

class Suspended:
    """Signals that an agent trajectory has been paused.

    The trajectory can be resumed later with a :class:`Resumed` event.
    """

    @property
    def reason(self) -> str:
        """Description of why the trajectory was suspended."""
    def __init__(self, reason: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Suspended: ...

class Resumed:
    """Signals that a previously :class:`Suspended` trajectory has been resumed."""

    @property
    def resumed_by(self) -> str:
        """Identifier of the actor who resumed the trajectory."""
    def __init__(self, resumed_by: str) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Resumed: ...

class Adjudicated:
    """Records a governance decision made on an action within the trajectory.

    Emitted when the policy engine evaluates an action and produces a
    decision (allow, deny, or escalate) along with optional metadata.
    See also :class:`Adjudication` for the standalone return-value variant.

    Example::

        Adjudicated.allow()
        Adjudicated.deny()
        Adjudicated.escalate()
        Adjudicated(Decision.Escalate, reason="Requires human approval")
    """

    @property
    def decision(self) -> Decision:
        """The governance decision."""
    @property
    def reason(self) -> str | None:
        """Human-readable explanation of the decision."""
    @property
    def metadata(self) -> list[PolicyMetadata]:
        """Policy metadata providing additional context."""
    def __init__(
        self,
        decision: Decision,
        *,
        reason: str | None = None,
        metadata: list[PolicyMetadata] | None = None,
    ) -> None: ...
    @staticmethod
    def allow() -> Adjudicated:
        """Create an allow adjudication."""
    @staticmethod
    def deny() -> Adjudicated:
        """Create a deny adjudication."""
    @staticmethod
    def escalate() -> Adjudicated:
        """Create an escalate adjudication."""
    def format_policy_context(self) -> str | None:
        """Format metadata into a human-readable policy context string.

        Returns:
            A formatted string describing which policies matched, or ``None``
            if there are no metadata entries.
        """
    def deny_message(self, default_reason: str) -> str:
        """Build a denial message from the reason and metadata.

        Args:
            default_reason: Fallback message if no reason is set.

        Returns:
            A formatted denial message including policy context if available.
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Adjudicated: ...

# ============================================================================
# State Types
# ============================================================================

class Snapshot:
    """A point-in-time snapshot of the agent's working environment.

    Captures contextual state such as the working directory, open files,
    git branch, and arbitrary variables for governance evaluation.

    Example::

        Snapshot(working_dir="/repo", git_branch="main", open_files=["src/main.py"])
    """

    @property
    def snapshot_id(self) -> str:
        """Unique identifier for this snapshot (auto-generated if not provided)."""
    @property
    def working_dir(self) -> str | None:
        """Current working directory."""
    @property
    def open_files(self) -> list[str]:
        """List of currently open file paths."""
    @property
    def git_branch(self) -> str | None:
        """Current git branch name."""
    @property
    def variables(self) -> dict[str, Any]:
        """Arbitrary key-value state variables."""
    def __init__(
        self,
        *,
        working_dir: str | None = None,
        git_branch: str | None = None,
        open_files: list[str] | None = None,
        variables: dict[str, Any] | None = None,
        snapshot_id: str | None = None,
    ) -> None:
        """Create a new Snapshot.

        Args:
            working_dir: Current working directory.
            git_branch: Current git branch name.
            open_files: List of open file paths.
            variables: Arbitrary key-value state variables.
            snapshot_id: Unique identifier (auto-generated UUID if not provided).
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Snapshot: ...

# ============================================================================
# Adjudication Result
# ============================================================================

class Adjudication:
    """A standalone governance decision result.

    Similar to :class:`Adjudicated` but used as a return value from
    policy evaluation rather than as a trajectory event payload.
    """

    @property
    def decision(self) -> Decision:
        """The governance decision."""
    @property
    def reason(self) -> str | None:
        """Human-readable explanation of the decision."""
    @property
    def metadata(self) -> list[PolicyMetadata]:
        """Policy metadata providing additional context."""
    def __init__(
        self,
        decision: Decision,
        *,
        reason: str | None = None,
        metadata: list[PolicyMetadata] | None = None,
    ) -> None: ...
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Adjudication: ...

# ============================================================================
# Event Envelope
# ============================================================================

# Union of all event payload types accepted by Event.__init__
type EventPayload = (
    ToolCall
    | ShellCommand
    | WebFetch
    | FileOperation
    | Prompt
    | Thought
    | ToolOutput
    | ShellCommandOutput
    | WebFetchOutput
    | FileOperationResult
    | Started
    | Completed
    | Failed
    | Terminated
    | Suspended
    | Resumed
    | Adjudicated
    | Snapshot
)

class Event:
    """The top-level envelope for all trajectory events.

    Every event in a trajectory is wrapped in an ``Event`` that provides
    a consistent structure with metadata (agent, actor, causality, timestamps)
    and the typed payload.

    The ``category`` (e.g., ``"action"``, ``"observation"``, ``"control"``,
    ``"state"``) and ``event_type`` (e.g., ``"tool_call"``, ``"prompt"``)
    properties are derived automatically from the payload type.

    Example::

        agent = Agent(id="claude-1", provider="anthropic")
        tc = ToolCall(tool="Bash", arguments={"command": "ls"})
        event = Event(agent=agent, trajectory_id="traj-001", event=tc)

        assert event.category == "action"
        assert event.event_type == "tool_call"
    """

    @property
    def event_id(self) -> str:
        """Unique identifier for this event (auto-generated if not provided)."""
    @property
    def trajectory_id(self) -> str:
        """ID of the trajectory this event belongs to."""
    @property
    def agent(self) -> Agent:
        """The agent associated with this event."""
    @property
    def timestamp(self) -> str:
        """ISO 8601 timestamp of when the event occurred (auto-generated if not provided)."""
    @property
    def event(self) -> EventPayload:
        """The typed event payload."""
    @property
    def category(self) -> str:
        """Event category derived from the payload type (e.g., ``"action"``, ``"observation"``)."""
    @property
    def event_type(self) -> str:
        """Event type derived from the payload type (e.g., ``"tool_call"``, ``"prompt"``)."""
    @property
    def actor(self) -> Actor:
        """The actor who produced this event."""
    @property
    def causality(self) -> Causality:
        """Causal linkage metadata for event correlation."""
    @property
    def raw(self) -> Any:
        """Optional raw/original data attached to the event."""
    def __init__(
        self,
        agent: Agent,
        trajectory_id: str,
        event: EventPayload,
        *,
        actor: Actor | None = None,
        causality: Causality | None = None,
        raw: Any | None = None,
        event_id: str | None = None,
        timestamp: str | None = None,
    ) -> None:
        """Create a new Event.

        Args:
            agent: The agent associated with this event.
            trajectory_id: ID of the trajectory this event belongs to.
            event: The typed event payload.
            actor: The actor who produced this event (defaults to an agent actor).
            causality: Causal linkage metadata (auto-generated if not provided).
            raw: Optional raw/original data to attach.
            event_id: Unique event identifier (auto-generated UUID if not provided).
            timestamp: ISO 8601 timestamp (auto-generated if not provided).
        """
    def __repr__(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def to_dict(self) -> dict[str, Any]: ...
    def to_json(self) -> str: ...
    @staticmethod
    def from_dict(data: dict[str, Any]) -> Event: ...
    @staticmethod
    def from_json(json_str: str) -> Event: ...

# ============================================================================
# gRPC Response Types
# ============================================================================

class Trajectory:
    """Trajectory metadata and events returned from the harness service.

    Can be constructed directly::

        Trajectory(
            name="trajectories/abc-123",
            agent="agents/claude",
            status=TrajectoryStatus.Running,
        )
    """

    def __init__(
        self,
        name: str,
        agent: str,
        status: TrajectoryStatus,
        event_count: int = 0,
        create_time: str | None = None,
        update_time: str | None = None,
        events: list[Event] | None = None,
    ) -> None:
        """Create a Trajectory.

        Args:
            name: Trajectory resource name (e.g. ``"trajectories/<id>"``).
            agent: Agent resource name (e.g. ``"agents/<id>"``).
            status: Lifecycle status of the trajectory.
            event_count: Number of events in this trajectory.
            create_time: Creation timestamp (ISO 8601), or ``None``.
            update_time: Last update timestamp (ISO 8601), or ``None``.
            events: Events in this trajectory, or ``None`` for an empty list.
        """
    @property
    def name(self) -> str:
        """Trajectory resource name."""
    @property
    def agent(self) -> str:
        """Agent resource name."""
    @property
    def status(self) -> TrajectoryStatus:
        """Trajectory lifecycle status."""
    @property
    def event_count(self) -> int:
        """Number of events in this trajectory."""
    @property
    def create_time(self) -> str | None:
        """Creation timestamp (ISO 8601)."""
    @property
    def update_time(self) -> str | None:
        """Last update timestamp (ISO 8601)."""
    @property
    def events(self) -> list[Event]:
        """Trajectory events."""
    def __repr__(self) -> str: ...

class TrajectoryList:
    """Paginated list of trajectories."""

    @property
    def trajectories(self) -> list[Trajectory]:
        """Trajectories in the current page."""
    @property
    def next_page_token(self) -> str:
        """Token for the next page, or empty string if no more pages."""
    def __repr__(self) -> str: ...
    def __len__(self) -> int: ...

class AgentList:
    """Paginated list of agents."""

    @property
    def agents(self) -> list[Agent]:
        """Agents in the current page."""
    @property
    def next_page_token(self) -> str:
        """Token for the next page, or empty string if no more pages."""
    def __repr__(self) -> str: ...
    def __len__(self) -> int: ...

class EventList:
    """Paginated list of events."""

    @property
    def events(self) -> list[Event]:
        """Events in the current page."""
    @property
    def next_page_token(self) -> str:
        """Token for the next page, or empty string if no more pages."""
    def __repr__(self) -> str: ...
    def __len__(self) -> int: ...

class Analytics:
    """Analytics result from trajectory analysis."""

    @property
    def metrics(self) -> dict[str, Any]:
        """Computed metrics."""
    @property
    def trajectory_count(self) -> int:
        """Number of trajectories analyzed."""
    @property
    def compute_time(self) -> str | None:
        """Computation timestamp (ISO 8601)."""
    def __repr__(self) -> str: ...

class TrajectoryEventNotification:
    """Single notification from a trajectory event stream.

    Contains the IDs of the newly inserted event and, when available,
    the full event payload fetched from storage.
    """

    @property
    def event_id(self) -> str:
        """Unique identifier of the newly inserted trajectory event."""
    @property
    def trajectory_id(self) -> str:
        """Trajectory resource name (e.g., ``"trajectories/<id>"``)."""
    @property
    def organization_id(self) -> str:
        """Organization that owns this event."""
    @property
    def event(self) -> Event | None:
        """Full event payload, or ``None`` if it could not be fetched."""
    def __repr__(self) -> str: ...

class TrajectoryEventStream:
    """Async iterator over trajectory event notifications.

    Returned by :meth:`HarnessClient.stream_trajectories`. Use
    ``async for`` to consume notifications as they arrive::

        stream = await client.stream_trajectories(filter='agent = "agents/claude-code"')
        async for notification in stream:
            print(notification.event_id, notification.event)
    """

    def __aiter__(self) -> TrajectoryEventStream: ...
    async def __anext__(self) -> TrajectoryEventNotification | None: ...
    def __repr__(self) -> str: ...

# ============================================================================
# gRPC Client
# ============================================================================

class HarnessClient:
    """gRPC client for the Sondera Harness Service.

    Wraps the Rust ``HarnessGrpcClient`` with Bearer-token authentication.
    All operation methods are native async—they return Python coroutines
    that can be awaited with ``asyncio``.

    Example::

        import asyncio
        from sondera_harness_client import HarnessClient, Event, Agent, ToolCall

        async def main():
            client = await HarnessClient.connect(
                "https://harness.example.com", "my-api-token"
            )
            agent = Agent(id="claude-1", provider="anthropic")
            tc = ToolCall(tool="Bash", arguments={"command": "ls"})
            event = Event(agent=agent, trajectory_id="traj-001", event=tc)

            result = await client.adjudicate(event)
            print(result.decision)  # Decision.Allow / .Deny / .Escalate

        asyncio.run(main())
    """

    def __init__(
        self,
        endpoint: str | None = None,
        token: str | None = None,
    ) -> None:
        """Connect to a Harness gRPC endpoint (blocks until connected).

        For a fully async alternative, use :meth:`connect`.

        When ``endpoint`` and ``token`` are omitted, defaults are resolved from
        ``~/.sondera/env`` and environment variables (``SONDERA_HARNESS_ENDPOINT``,
        ``SONDERA_API_TOKEN``).

        Args:
            endpoint: The gRPC endpoint URL (e.g., ``"https://harness.example.com"``).
            token: Bearer token for authentication.

        Raises:
            RuntimeError: If the connection fails or no token can be resolved.
        """
    @staticmethod
    def connect(endpoint: str, token: str) -> Coroutine[Any, Any, HarnessClient]:
        """Connect to a Harness gRPC endpoint asynchronously.

        Args:
            endpoint: The gRPC endpoint URL.
            token: Bearer token for authentication.

        Returns:
            A new HarnessClient instance.

        Raises:
            RuntimeError: If the connection fails.
        """
    @staticmethod
    def connect_default() -> Coroutine[Any, Any, HarnessClient]:
        """Connect using default settings from ``~/.sondera/env`` and environment variables.

        Resolution order for configuration:
          1. ``SONDERA_API_TOKEN`` / ``SONDERA_TOKEN`` environment variables
          2. ``~/.sondera/env`` file

        Raises:
            RuntimeError: If no API token is configured or connection fails.
        """

    # ── Adjudication ────────────────────────────────────────────────

    def adjudicate(self, event: Event) -> Coroutine[Any, Any, Adjudicated]:
        """Adjudicate a single event against configured policies.

        Args:
            event: An Event to evaluate.

        Returns:
            An Adjudicated result with decision, reason, and policy metadata.

        Raises:
            RuntimeError: If adjudication fails.
        """
    def adjudicates(
        self, events: list[Event]
    ) -> Coroutine[Any, Any, list[Adjudicated]]:
        """Adjudicate a batch of events against configured policies.

        Args:
            events: A list of Event objects to evaluate.

        Returns:
            A list of Adjudicated results, one per input event.

        Raises:
            RuntimeError: If adjudication fails.
        """

    # ── Agents ──────────────────────────────────────────────────────

    def get_agent(self, name: str) -> Coroutine[Any, Any, Agent]:
        """Get an agent by resource name.

        Args:
            name: Agent resource name (e.g., ``"agents/anthropic/claude-code"``).

        Returns:
            An Agent object.

        Raises:
            RuntimeError: If the request fails.
        """
    def create_agent(self, agent: Agent) -> Coroutine[Any, Any, Agent]:
        """Create (register) a new agent.

        Args:
            agent: An Agent to register.

        Returns:
            The created Agent (may include a server-assigned resource name).

        Raises:
            RuntimeError: If the request fails.
        """
    def list_agents(
        self,
        *,
        page_size: int = 50,
        page_token: str = "",
        filter: str = "",
    ) -> Coroutine[Any, Any, AgentList]:
        """List agents with optional filtering.

        Args:
            page_size: Maximum agents per page (default 50).
            page_token: Pagination token (empty for first page).
            filter: Optional filter expression.

        Returns:
            An AgentList with agents and pagination token.

        Raises:
            RuntimeError: If the request fails.
        """

    # ── Trajectories ────────────────────────────────────────────────

    def get_trajectory(self, name: str) -> Coroutine[Any, Any, Trajectory]:
        """Get a trajectory by resource name, including its events.

        Args:
            name: Trajectory resource name (e.g., ``"trajectories/<id>"``).

        Returns:
            A Trajectory with metadata and events.

        Raises:
            RuntimeError: If the request fails.
        """
    def list_trajectories(
        self,
        *,
        page_size: int = 50,
        page_token: str = "",
        filter: str = "",
        order_by: str = "",
    ) -> Coroutine[Any, Any, TrajectoryList]:
        """List trajectories with optional filtering.

        Args:
            page_size: Maximum trajectories per page (default 50).
            page_token: Pagination token (empty for first page).
            filter: Optional filter expression.
            order_by: Optional ordering expression.

        Returns:
            A TrajectoryList with trajectories and pagination token.

        Raises:
            RuntimeError: If the request fails.
        """

    # ── Streaming ──────────────────────────────────────────────────

    def stream_trajectories(
        self,
        *,
        filter: str = "",
    ) -> Coroutine[Any, Any, TrajectoryEventStream]:
        """Open a server-streaming subscription for new trajectory events.

        Returns a :class:`TrajectoryEventStream` async iterator. Use
        ``async for`` to consume notifications as they arrive::

            stream = await client.stream_trajectories(
                filter='agent = "agents/claude-code"'
            )
            async for notification in stream:
                print(notification.event_id, notification.event)

        Args:
            filter: Optional filter expression.

        Returns:
            A TrajectoryEventStream async iterator.

        Raises:
            RuntimeError: If the stream cannot be opened.
        """

    # ── Analytics ───────────────────────────────────────────────────

    def analyze_trajectories(
        self,
        filter: str,
        metrics: list[str] = [],
    ) -> Coroutine[Any, Any, Analytics]:
        """Compute analytics over trajectories.

        Args:
            filter: Filter expression scoping which trajectories to analyze.
            metrics: List of metric names to compute (empty for all).

        Returns:
            An Analytics result with metrics, trajectory count, and compute time.

        Raises:
            RuntimeError: If the request fails.
        """

    # ── Adjudication Records ────────────────────────────────────────

    def list_adjudications(
        self,
        *,
        page_size: int = 50,
        page_token: str = "",
        filter: str = "",
        order_by: str = "",
    ) -> Coroutine[Any, Any, EventList]:
        """List adjudication records with optional filtering.

        Args:
            page_size: Maximum records per page (default 50).
            page_token: Pagination token (empty for first page).
            filter: Optional filter expression.
            order_by: Optional ordering expression.

        Returns:
            An EventList with adjudication events and pagination token.

        Raises:
            RuntimeError: If the request fails.
        """
    def __repr__(self) -> str: ...
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> bool: ...
