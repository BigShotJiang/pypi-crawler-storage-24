"""AnomalyArmor MCP Server."""

__version__ = "0.6.0"
