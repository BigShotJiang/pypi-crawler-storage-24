"""Tests for armor-mcp."""
