# nse-orchestrator

The nervous system for sovereign entities. Orchestrates the five pillars of the NSE platform.

**Import:** `pip install nse-orchestrator` → `from nse_orchestrator import SovereignEntity`

## Build & Test

```bash
pip install -e ".[dev]"
pytest -v
```

## Structure

- `src/nse_orchestrator/` — package source
  - `types.py` — Pillar, PillarStatus, Signal, SignalKind, ScoreCard, EntityConfig
  - `entity.py` — SovereignEntity orchestrator (main entry point, auto-detects pillars)
  - `nerve.py` — NerveCenter (signal routing, scoring, cross-pillar awareness)
  - `models.py` — ModelRegistry, ModelProfile, ModelScore (LLM trust profiles)
  - `checks.py` — CrossPillarCheck, CheckVerdict (cross-pillar consistency checks)
- `tests/` — pytest suite
- `clawhub/` — OpenClaw skill metadata

## Conventions

- Python 3.10+, hatchling build, ruff linter (100 char line length)
- Zero required dependencies — all five pillars are optional
- The nerve center is a signal router, not a decision maker
- Cross-pillar checks catch things no single pillar would flag
- LLM trust profiles are like NostrSocial trust tiers but for models
- ModelScore weights: quality 30%, coherence 25%, relevance 25%, safety 20%
- Pillar detection uses try/except import — graceful when packages aren't installed
- Signal buffer is capped (default 10000) and rolls automatically
