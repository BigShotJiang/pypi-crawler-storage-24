"""Core types for the NSE nervous system.

Every signal that passes through the entity gets a type.
Every pillar gets a status. Every interaction gets scored.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Optional


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp a float to [lo, hi]. Reject NaN and Inf."""
    if not isinstance(value, (int, float)) or math.isnan(value) or math.isinf(value):
        return lo
    return max(lo, min(hi, float(value)))


class Pillar(Enum):
    """The five pillars of a sovereign entity."""
    IDENTITY = "identity"       # nostrkey
    FINANCE = "finance"         # nostrwalletconnect
    TIME = "time"               # nostrcalendar
    SOCIAL = "social"           # nostrsocial
    ALIGNMENT = "alignment"     # social-alignment


class PillarStatus(Enum):
    """Runtime status of a pillar."""
    ABSENT = "absent"           # Not installed
    AVAILABLE = "available"     # Installed but not initialized
    ACTIVE = "active"           # Initialized and running
    DEGRADED = "degraded"       # Running but reporting issues
    FAILED = "failed"           # Was active, now broken


class SignalKind(Enum):
    """What kind of signal is flowing through the nerve center."""
    ACTION = "action"           # Entity wants to do something
    RESPONSE = "response"       # An LLM produced output
    INTERACTION = "interaction" # Human or agent interacted
    HEALTH = "health"           # Pillar health report
    ESCALATION = "escalation"   # Something needs human attention
    WISDOM = "wisdom"           # Pattern or insight detected
    COHERENCE = "coherence"     # Cross-model consistency check


@dataclass(frozen=True)
class Signal:
    """A signal passing through the nervous system.

    Everything that happens becomes a signal. The nerve center
    routes it to the relevant pillars, scores it, and records it.
    """
    kind: SignalKind
    source: str                         # Who/what produced this signal
    content: str                        # What happened
    model_id: Optional[str] = None      # Which LLM, if any
    pillar: Optional[Pillar] = None     # Which pillar, if relevant
    confidence: float = 0.5             # How confident is the source
    metadata: MappingProxyType = field(default_factory=lambda: MappingProxyType({}))
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        # Clamp confidence to [0, 1], reject NaN/Inf
        object.__setattr__(self, "confidence", _clamp(self.confidence))
        # Truncate content to prevent memory abuse
        if len(self.content) > 2000:
            object.__setattr__(self, "content", self.content[:2000])
        # Ensure metadata is immutable
        if isinstance(self.metadata, dict):
            object.__setattr__(self, "metadata", MappingProxyType(dict(self.metadata)))

    def to_dict(self) -> dict:
        return {
            "kind": self.kind.value,
            "source": self.source,
            "content": self.content,
            "model_id": self.model_id,
            "pillar": self.pillar.value if self.pillar else None,
            "confidence": round(self.confidence, 3),
            "metadata": dict(self.metadata),
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Signal:
        return cls(
            kind=SignalKind(data["kind"]),
            source=data["source"],
            content=data["content"],
            model_id=data.get("model_id"),
            pillar=Pillar(data["pillar"]) if data.get("pillar") else None,
            confidence=data.get("confidence", 0.5),
            metadata=data.get("metadata", {}),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass(frozen=True)
class ScoreCard:
    """Quality score for a response or interaction.

    The nerve center scores every LLM response. Over time,
    this builds a picture of which models are reliable for what.
    """
    signal: Signal
    quality: float              # 0.0 - 1.0 overall quality
    coherence: float            # Does this match prior context?
    relevance: float            # Did it address the actual need?
    safety: float               # Did alignment flag anything?
    rationale: str = ""         # Why this score
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        object.__setattr__(self, "quality", _clamp(self.quality))
        object.__setattr__(self, "coherence", _clamp(self.coherence))
        object.__setattr__(self, "relevance", _clamp(self.relevance))
        object.__setattr__(self, "safety", _clamp(self.safety))

    def to_dict(self) -> dict:
        return {
            "signal": self.signal.to_dict(),
            "quality": round(self.quality, 3),
            "coherence": round(self.coherence, 3),
            "relevance": round(self.relevance, 3),
            "safety": round(self.safety, 3),
            "rationale": self.rationale,
            "timestamp": self.timestamp,
        }


@dataclass(frozen=True)
class EntityConfig:
    """Configuration for a sovereign entity.

    The owner is the human. The entity is the agent.
    Both are sovereign. The config defines the relationship.
    """
    owner_npub: str = ""
    owner_name: str = ""
    entity_name: str = ""
    max_signals: int = 10000            # Rolling signal buffer
    score_window: int = 100             # How many scores to keep per model
    coherence_threshold: float = 0.6    # Below this, flag contradictions
    auto_escalate_on_incoherence: bool = True

    def __post_init__(self) -> None:
        if self.max_signals < 1:
            object.__setattr__(self, "max_signals", 1)
        if self.score_window < 1:
            object.__setattr__(self, "score_window", 1)
        object.__setattr__(self, "coherence_threshold", _clamp(self.coherence_threshold))

    def to_dict(self) -> dict:
        return {
            "owner_npub": self.owner_npub,
            "owner_name": self.owner_name,
            "entity_name": self.entity_name,
            "max_signals": self.max_signals,
            "score_window": self.score_window,
            "coherence_threshold": self.coherence_threshold,
            "auto_escalate_on_incoherence": self.auto_escalate_on_incoherence,
        }

    @classmethod
    def from_dict(cls, data: dict) -> EntityConfig:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
