"""Model registry — tracking which LLMs are doing what.

Not a replacement for OpenClaw. OpenClaw is discovery and installation.
This is the runtime layer — watching models run, scoring their output,
building trust profiles over time.

Like NostrSocial's trust tiers but for LLMs.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from .types import _clamp


@dataclass
class ModelScore:
    """A single scored interaction with a model."""
    quality: float
    coherence: float
    relevance: float
    safety: float
    task_type: str = ""         # What kind of task (code, reasoning, conversation, voice)
    latency_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        self.quality = _clamp(self.quality)
        self.coherence = _clamp(self.coherence)
        self.relevance = _clamp(self.relevance)
        self.safety = _clamp(self.safety)
        self.latency_ms = max(0.0, float(self.latency_ms) if isinstance(self.latency_ms, (int, float)) else 0.0)

    @property
    def overall(self) -> float:
        """Weighted overall score."""
        return (
            self.quality * 0.3
            + self.coherence * 0.25
            + self.relevance * 0.25
            + self.safety * 0.2
        )

    def to_dict(self) -> dict:
        return {
            "quality": round(self.quality, 3),
            "coherence": round(self.coherence, 3),
            "relevance": round(self.relevance, 3),
            "safety": round(self.safety, 3),
            "task_type": self.task_type,
            "latency_ms": round(self.latency_ms, 1),
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ModelScore:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ModelProfile:
    """Trust profile for an LLM — built from scored interactions over time.

    Like a contact in NostrSocial, but for models. The entity learns
    which models are reliable for which tasks, which ones drift,
    which ones contradict each other.
    """
    model_id: str                       # e.g. "claude-opus-4-6", "local-llama", "whisper-large"
    display_name: str = ""
    provider: str = ""                  # e.g. "anthropic", "local", "openai"
    scores: list[ModelScore] = field(default_factory=list)
    total_interactions: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    task_strengths: dict[str, float] = field(default_factory=dict)  # task_type → avg quality
    notes: list[str] = field(default_factory=list)  # Human or agent observations

    def record(self, score: ModelScore, max_scores: int = 100) -> None:
        """Record a scored interaction."""
        self.scores.append(score)
        self.total_interactions += 1
        self.last_seen = score.timestamp
        if len(self.scores) > max_scores:
            self.scores = self.scores[-max_scores:]
        self._update_strengths()

    def _update_strengths(self) -> None:
        """Recalculate task strengths from recent scores."""
        task_scores: dict[str, list[float]] = {}
        for s in self.scores[-50:]:
            if s.task_type:
                task_scores.setdefault(s.task_type, []).append(s.overall)
        self.task_strengths = {
            task: sum(scores) / len(scores)
            for task, scores in task_scores.items()
        }

    @property
    def avg_quality(self) -> float:
        """Average quality across recent interactions."""
        recent = self.scores[-50:]
        if not recent:
            return 0.5
        return sum(s.quality for s in recent) / len(recent)

    @property
    def avg_coherence(self) -> float:
        """Average coherence — does this model stay consistent?"""
        recent = self.scores[-50:]
        if not recent:
            return 0.5
        return sum(s.coherence for s in recent) / len(recent)

    @property
    def avg_safety(self) -> float:
        """Average safety — does alignment ever flag this model?"""
        recent = self.scores[-50:]
        if not recent:
            return 1.0
        return sum(s.safety for s in recent) / len(recent)

    @property
    def trust_level(self) -> str:
        """Qualitative trust level based on scores.

        Like NostrSocial's tiers but for models.
        """
        avg = self.avg_quality
        if self.total_interactions < 5:
            return "unknown"
        if avg >= 0.85:
            return "trusted"
        if avg >= 0.7:
            return "reliable"
        if avg >= 0.5:
            return "cautious"
        return "unreliable"

    def best_for(self, task_type: str) -> float:
        """How good is this model for a specific task type?"""
        return self.task_strengths.get(task_type, 0.5)

    def summary(self) -> str:
        """One-line summary of this model's profile."""
        strengths = ", ".join(
            f"{t} ({s:.0%})" for t, s in sorted(
                self.task_strengths.items(), key=lambda x: -x[1]
            )[:3]
        )
        return (
            f"{self.display_name or self.model_id} [{self.trust_level}] "
            f"— {self.total_interactions} interactions"
            + (f", strengths: {strengths}" if strengths else "")
        )

    def to_dict(self) -> dict:
        return {
            "model_id": self.model_id,
            "display_name": self.display_name,
            "provider": self.provider,
            "scores": [s.to_dict() for s in self.scores],
            "total_interactions": self.total_interactions,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "task_strengths": {k: round(v, 3) for k, v in self.task_strengths.items()},
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ModelProfile:
        profile = cls(
            model_id=data["model_id"],
            display_name=data.get("display_name", ""),
            provider=data.get("provider", ""),
            total_interactions=data.get("total_interactions", 0),
            first_seen=data.get("first_seen", time.time()),
            last_seen=data.get("last_seen", time.time()),
            task_strengths=data.get("task_strengths", {}),
            notes=data.get("notes", []),
        )
        profile.scores = [ModelScore.from_dict(s) for s in data.get("scores", [])]
        return profile


class ModelRegistry:
    """Registry of all LLMs the entity has interacted with.

    The central nervous system's awareness of who's talking.
    Which models are active, which are reliable, which contradict each other.
    """

    MAX_MODELS = 500

    def __init__(self) -> None:
        self._models: dict[str, ModelProfile] = {}

    def register(
        self,
        model_id: str,
        display_name: str = "",
        provider: str = "",
    ) -> ModelProfile:
        """Register a model or return existing profile."""
        if model_id not in self._models:
            if len(self._models) >= self.MAX_MODELS:
                # Evict the model with fewest interactions
                weakest = min(self._models.values(), key=lambda m: m.total_interactions)
                del self._models[weakest.model_id]
            self._models[model_id] = ModelProfile(
                model_id=model_id,
                display_name=display_name or model_id,
                provider=provider,
            )
        return self._models[model_id]

    def get(self, model_id: str) -> Optional[ModelProfile]:
        """Get a model's profile, if known."""
        return self._models.get(model_id)

    def score(self, model_id: str, score: ModelScore) -> ModelProfile:
        """Record a scored interaction for a model."""
        profile = self.register(model_id)
        profile.record(score)
        return profile

    def best_model_for(self, task_type: str) -> Optional[ModelProfile]:
        """Which registered model is best for this task type?"""
        candidates = [
            (m, m.best_for(task_type))
            for m in self._models.values()
            if m.total_interactions >= 3
        ]
        if not candidates:
            return None
        return max(candidates, key=lambda x: x[1])[0]

    def check_coherence(self, model_a: str, model_b: str, window: int = 10) -> float:
        """How coherent are two models' recent outputs?

        Returns 0.0-1.0. Low scores mean they're contradicting each other.
        This is a placeholder — real coherence checking needs semantic comparison.
        For now, we use the average of both models' coherence scores as a proxy.
        """
        a = self._models.get(model_a)
        b = self._models.get(model_b)
        if not a or not b:
            return 0.5  # Unknown
        return (a.avg_coherence + b.avg_coherence) / 2

    @property
    def active_models(self) -> list[ModelProfile]:
        """Models seen in the last hour."""
        cutoff = time.time() - 3600
        return [m for m in self._models.values() if m.last_seen > cutoff]

    @property
    def all_models(self) -> list[ModelProfile]:
        return list(self._models.values())

    def leaderboard(self, task_type: str = "") -> list[ModelProfile]:
        """Ranked list of models, optionally filtered by task type."""
        models = [m for m in self._models.values() if m.total_interactions >= 3]
        if task_type:
            return sorted(models, key=lambda m: -m.best_for(task_type))
        return sorted(models, key=lambda m: -m.avg_quality)

    def to_dict(self) -> dict:
        return {"models": {k: v.to_dict() for k, v in self._models.items()}}

    @classmethod
    def from_dict(cls, data: dict) -> ModelRegistry:
        reg = cls()
        for k, v in data.get("models", {}).items():
            reg._models[k] = ModelProfile.from_dict(v)
        return reg
