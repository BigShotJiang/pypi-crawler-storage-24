"""NerveCenter — the central nervous system.

Every signal flows through here. The nerve center routes signals
to the right pillars, scores LLM responses, checks cross-pillar
consistency, and maintains the entity's memory of what happened.

This is the lymph node system — not making decisions, but making
sure every decision has full context. When something looks wrong,
it flags it. When models contradict each other, it catches it.
When trust is mismatched to action, it escalates.
"""

from __future__ import annotations

import time
from typing import Optional

import re

from .types import (
    EntityConfig,
    Pillar,
    PillarStatus,
    Signal,
    SignalKind,
    ScoreCard,
)
from .models import ModelRegistry, ModelScore
from .checks import CrossPillarCheck, CheckVerdict, Verdict

# Patterns that should never be stored in signal content
_SECRET_PATTERNS = re.compile(
    r"(nsec1[a-z0-9]{10,}|"            # Nostr nsec keys (bech32)
    r"sk-[a-zA-Z0-9]{20,}|"            # API keys (OpenAI-style)
    r"Bearer\s+[a-zA-Z0-9._\-]{20,}|"  # Bearer tokens
    r"(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9]))",  # Raw 256-bit hex keys (exact 64)
    re.IGNORECASE,
)


def _sanitize_content(content: str) -> str:
    """Redact secret patterns from content before storage."""
    return _SECRET_PATTERNS.sub("[REDACTED]", content)


class NerveCenter:
    """The entity's central nervous system.

    Not a decision maker. A signal router, scorer, and consistency checker.
    The brain of the entity is the alignment enclave + the human.
    The nervous system makes sure they have what they need to decide.
    """

    def __init__(self, config: EntityConfig) -> None:
        self._config = config
        self._pillar_status: dict[Pillar, PillarStatus] = {
            p: PillarStatus.ABSENT for p in Pillar
        }
        self._signals: list[Signal] = []
        self._scores: list[ScoreCard] = []
        self._models = ModelRegistry()
        self._checks = CrossPillarCheck()

    @property
    def config(self) -> EntityConfig:
        return self._config

    @property
    def models(self) -> ModelRegistry:
        return self._models

    @property
    def checks(self) -> CrossPillarCheck:
        return self._checks

    # --- Pillar management ---

    def activate_pillar(self, pillar: Pillar) -> None:
        """Mark a pillar as active."""
        self._pillar_status[pillar] = PillarStatus.ACTIVE

    def degrade_pillar(self, pillar: Pillar, reason: str = "") -> None:
        """Mark a pillar as degraded."""
        self._pillar_status[pillar] = PillarStatus.DEGRADED
        self.ingest(Signal(
            kind=SignalKind.HEALTH,
            source=f"pillar.{pillar.value}",
            content=f"Pillar {pillar.value} degraded: {reason}",
            pillar=pillar,
        ))

    def pillar_status(self, pillar: Pillar) -> PillarStatus:
        return self._pillar_status[pillar]

    @property
    def active_pillars(self) -> list[Pillar]:
        return [p for p, s in self._pillar_status.items() if s == PillarStatus.ACTIVE]

    @property
    def available_pillars(self) -> list[Pillar]:
        return [
            p for p, s in self._pillar_status.items()
            if s in (PillarStatus.ACTIVE, PillarStatus.AVAILABLE, PillarStatus.DEGRADED)
        ]

    @property
    def health_summary(self) -> dict[str, str]:
        return {p.value: s.value for p, s in self._pillar_status.items()}

    # --- Signal flow ---

    def ingest(self, signal: Signal) -> None:
        """Every signal passes through here.

        The nerve center records it, routes it to relevant pillars,
        and trims the buffer if needed.
        """
        self._signals.append(signal)
        if len(self._signals) > self._config.max_signals:
            self._signals = self._signals[-self._config.max_signals:]

    def recent_signals(self, kind: Optional[SignalKind] = None, limit: int = 20) -> list[Signal]:
        """Recent signals, optionally filtered by kind."""
        if kind is None:
            return self._signals[-limit:]
        return [s for s in self._signals if s.kind == kind][-limit:]

    # --- LLM scoring ---

    def score_response(
        self,
        model_id: str,
        content: str,
        quality: float,
        coherence: float = 0.5,
        relevance: float = 0.5,
        safety: float = 1.0,
        task_type: str = "",
        latency_ms: float = 0.0,
        rationale: str = "",
    ) -> ScoreCard:
        """Score an LLM response and record it.

        This is how the entity builds trust profiles for models over time.
        """
        signal = Signal(
            kind=SignalKind.RESPONSE,
            source=model_id,
            content=_sanitize_content(content[:200]),
            model_id=model_id,
            confidence=quality,
        )
        self.ingest(signal)

        model_score = ModelScore(
            quality=quality,
            coherence=coherence,
            relevance=relevance,
            safety=safety,
            task_type=task_type,
            latency_ms=latency_ms,
        )
        self._models.score(model_id, model_score)

        card = ScoreCard(
            signal=signal,
            quality=quality,
            coherence=coherence,
            relevance=relevance,
            safety=safety,
            rationale=rationale,
        )
        self._scores.append(card)
        if len(self._scores) > self._config.score_window * 10:
            self._scores = self._scores[-(self._config.score_window * 10):]

        return card

    # --- Cross-pillar awareness ---

    def check_action(
        self,
        description: str,
        involves_money: bool = False,
        money_amount_sats: int = 0,
        recipient_id: str = "",
        social_known: bool = False,
        social_tier: Optional[str] = None,
        involves_secrets: bool = False,
        involves_scheduling: bool = False,
        is_reversible: bool = True,
        owner_recently_active: bool = False,
        owner_absent_hours: float = 0.0,
    ) -> list[CheckVerdict]:
        """Run all relevant cross-pillar checks for a proposed action.

        This is the main entry point for the nervous system's awareness.
        It doesn't replace the alignment enclave's yellow line check —
        it adds cross-pillar context that the alignment enclave alone can't see.

        Safe defaults: social_known=False, owner_recently_active=False.
        Assume the worst until told otherwise.
        """
        verdicts: list[CheckVerdict] = []

        # Finance + Social — run whenever money is involved
        if involves_money:
            verdicts.append(self._checks.check_payment_to_stranger(
                recipient_id=recipient_id,
                amount_sats=money_amount_sats,
                social_known=social_known,
                social_tier=social_tier,
                owner_recently_active=owner_recently_active,
            ))

        # Time + Alignment
        if involves_scheduling:
            verdicts.append(self._checks.check_schedule_without_owner(
                event_description=description,
                owner_absent_hours=owner_absent_hours,
                is_reversible=is_reversible,
            ))

        # Social + Alignment + Identity
        if involves_secrets:
            verdicts.append(self._checks.check_disclosure_to_untrusted(
                content_type="sensitive data",
                recipient_id=recipient_id,
                social_tier=social_tier,
                involves_secrets=True,
            ))

        # Record the action signal
        self.ingest(Signal(
            kind=SignalKind.ACTION,
            source="entity",
            content=description,
            metadata={
                "verdicts": [v.verdict.value for v in verdicts],
                "pillars": list({p.value for v in verdicts for p in v.pillars_involved}),
            },
        ))

        return verdicts

    def should_escalate(self, verdicts: list[CheckVerdict]) -> bool:
        """Given a set of verdicts, should the entity escalate to the human?"""
        return any(v.verdict in (Verdict.ESCALATE, Verdict.CONFLICT) for v in verdicts)

    # --- Persistence ---

    def to_dict(self) -> dict:
        return {
            "config": self._config.to_dict(),
            "pillar_status": {p.value: s.value for p, s in self._pillar_status.items()},
            "signals": [s.to_dict() for s in self._signals[-500:]],  # Last 500 for persistence
            "models": self._models.to_dict(),
            "checks": self._checks.to_dict(),
            "version": "0.1.0",
        }

    @classmethod
    def from_dict(cls, data: dict) -> NerveCenter:
        config = EntityConfig.from_dict(data.get("config", {}))
        nerve = cls(config)
        for p_str, s_str in data.get("pillar_status", {}).items():
            try:
                nerve._pillar_status[Pillar(p_str)] = PillarStatus(s_str)
            except (ValueError, KeyError):
                pass
        nerve._signals = [Signal.from_dict(s) for s in data.get("signals", [])]
        nerve._models = ModelRegistry.from_dict(data.get("models", {}))
        return nerve
