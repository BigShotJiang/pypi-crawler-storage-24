"""Cross-pillar checks — where the pillars become aware of each other.

This is the real value of the orchestrator. Each pillar alone sees
its own domain. The nerve center sees across all five and catches
things no single pillar would flag:

  "I'm about to pay someone who isn't in my contacts."
  "I'm scheduling a meeting but my owner hasn't been around in hours."
  "Two models just contradicted each other about what to do."

The lymph node — checking everything, flagging what matters.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .types import Pillar, Signal, SignalKind


class Verdict(Enum):
    """Cross-pillar check outcome."""
    CLEAR = "clear"             # All pillars agree, proceed
    CAUTION = "caution"         # Minor mismatch, note it
    CONFLICT = "conflict"       # Pillars disagree — needs resolution
    ESCALATE = "escalate"       # Human needs to decide


@dataclass(frozen=True)
class CheckVerdict:
    """The result of a cross-pillar check."""
    verdict: Verdict
    pillars_involved: tuple[Pillar, ...]
    description: str
    suggestion: str = ""
    signal: Optional[Signal] = None
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict.value,
            "pillars_involved": [p.value for p in self.pillars_involved],
            "description": self.description,
            "suggestion": self.suggestion,
            "timestamp": self.timestamp,
        }


class CrossPillarCheck:
    """Engine that runs cross-pillar consistency checks.

    Given the state of all active pillars, it looks for mismatches,
    gaps, and contradictions that no single pillar would catch.
    """

    MAX_VERDICTS = 200

    def __init__(self) -> None:
        self._verdicts: list[CheckVerdict] = []

    def _record(self, verdict: CheckVerdict) -> CheckVerdict:
        """Record a verdict and enforce rolling cap."""
        self._verdicts.append(verdict)
        if len(self._verdicts) > self.MAX_VERDICTS:
            self._verdicts = self._verdicts[-self.MAX_VERDICTS:]
        return verdict

    def check_payment_to_stranger(
        self,
        recipient_id: str,
        amount_sats: int,
        social_known: bool,
        social_tier: Optional[str] = None,
        owner_recently_active: bool = True,
    ) -> CheckVerdict:
        """Finance + Social: paying someone who isn't in the social graph."""
        if not social_known:
            verdict = CheckVerdict(
                verdict=Verdict.ESCALATE if amount_sats > 1000 else Verdict.CAUTION,
                pillars_involved=(Pillar.FINANCE, Pillar.SOCIAL),
                description=(
                    f"Payment of {amount_sats} sats to {recipient_id} "
                    f"who is not in the social graph."
                ),
                suggestion=(
                    "Add this contact to the social graph before transacting, "
                    "or ask the owner to approve."
                ),
            )
        elif social_tier in ("gray", "blocked"):
            verdict = CheckVerdict(
                verdict=Verdict.ESCALATE,
                pillars_involved=(Pillar.FINANCE, Pillar.SOCIAL),
                description=(
                    f"Payment of {amount_sats} sats to {recipient_id} "
                    f"who is in the {social_tier} list."
                ),
                suggestion="This contact has low or negative trust. Escalate to owner.",
            )
        elif not owner_recently_active and amount_sats > 500:
            verdict = CheckVerdict(
                verdict=Verdict.CAUTION,
                pillars_involved=(Pillar.FINANCE, Pillar.SOCIAL, Pillar.ALIGNMENT),
                description=(
                    f"Payment of {amount_sats} sats while owner is absent. "
                    f"Contact is {social_tier}."
                ),
                suggestion="Owner hasn't been active recently. Consider waiting.",
            )
        else:
            verdict = CheckVerdict(
                verdict=Verdict.CLEAR,
                pillars_involved=(Pillar.FINANCE, Pillar.SOCIAL),
                description=f"Payment of {amount_sats} sats to known {social_tier} contact.",
            )
        return self._record(verdict)

    def check_schedule_without_owner(
        self,
        event_description: str,
        owner_absent_hours: float,
        is_reversible: bool = True,
    ) -> CheckVerdict:
        """Time + Alignment: scheduling when owner hasn't been around."""
        if owner_absent_hours > 24 and not is_reversible:
            verdict = CheckVerdict(
                verdict=Verdict.ESCALATE,
                pillars_involved=(Pillar.TIME, Pillar.ALIGNMENT),
                description=(
                    f"Irreversible scheduling action '{event_description}' "
                    f"while owner has been absent for {owner_absent_hours:.0f} hours."
                ),
                suggestion="Wait for owner interaction before committing to irreversible events.",
            )
        elif owner_absent_hours > 12:
            verdict = CheckVerdict(
                verdict=Verdict.CAUTION,
                pillars_involved=(Pillar.TIME, Pillar.ALIGNMENT),
                description=(
                    f"Scheduling '{event_description}' while owner absent "
                    f"for {owner_absent_hours:.0f} hours."
                ),
                suggestion="Proceed but inform owner when they return.",
            )
        else:
            verdict = CheckVerdict(
                verdict=Verdict.CLEAR,
                pillars_involved=(Pillar.TIME,),
                description=f"Scheduling '{event_description}' — owner recently active.",
            )
        return self._record(verdict)

    def check_model_coherence(
        self,
        model_a_id: str,
        model_b_id: str,
        coherence_score: float,
        threshold: float = 0.6,
    ) -> CheckVerdict:
        """Cross-model: two LLMs contradicting each other."""
        if coherence_score < threshold * 0.5:
            verdict = CheckVerdict(
                verdict=Verdict.ESCALATE,
                pillars_involved=(Pillar.ALIGNMENT,),
                description=(
                    f"Models {model_a_id} and {model_b_id} show severe incoherence "
                    f"(score: {coherence_score:.2f}). Outputs may be contradictory."
                ),
                suggestion=(
                    "Pause multi-model operations. Review recent outputs from both models. "
                    "Consider using a single trusted model until resolved."
                ),
            )
        elif coherence_score < threshold:
            verdict = CheckVerdict(
                verdict=Verdict.CONFLICT,
                pillars_involved=(Pillar.ALIGNMENT,),
                description=(
                    f"Models {model_a_id} and {model_b_id} show low coherence "
                    f"(score: {coherence_score:.2f})."
                ),
                suggestion="Flag outputs from both models for human review.",
            )
        else:
            verdict = CheckVerdict(
                verdict=Verdict.CLEAR,
                pillars_involved=(Pillar.ALIGNMENT,),
                description=(
                    f"Models {model_a_id} and {model_b_id} are coherent "
                    f"(score: {coherence_score:.2f})."
                ),
            )
        return self._record(verdict)

    def check_disclosure_to_untrusted(
        self,
        content_type: str,
        recipient_id: str,
        social_tier: Optional[str] = None,
        involves_secrets: bool = False,
    ) -> CheckVerdict:
        """Social + Alignment: sharing sensitive content with low-trust contacts."""
        if involves_secrets and social_tier in (None, "gray", "known"):
            verdict = CheckVerdict(
                verdict=Verdict.ESCALATE,
                pillars_involved=(Pillar.SOCIAL, Pillar.ALIGNMENT, Pillar.IDENTITY),
                description=(
                    f"Attempting to share {content_type} (contains secrets) "
                    f"with {recipient_id} (trust: {social_tier or 'unknown'})."
                ),
                suggestion="Never share secrets with unverified or low-trust contacts.",
            )
        elif social_tier in (None, "gray"):
            verdict = CheckVerdict(
                verdict=Verdict.CAUTION,
                pillars_involved=(Pillar.SOCIAL, Pillar.ALIGNMENT),
                description=(
                    f"Sharing {content_type} with {recipient_id} "
                    f"(trust: {social_tier or 'unknown'})."
                ),
                suggestion="Consider the sensitivity of what you're sharing.",
            )
        else:
            verdict = CheckVerdict(
                verdict=Verdict.CLEAR,
                pillars_involved=(Pillar.SOCIAL,),
                description=f"Sharing {content_type} with trusted contact {recipient_id}.",
            )
        return self._record(verdict)

    @property
    def recent_verdicts(self) -> list[CheckVerdict]:
        """Last 20 verdicts."""
        return self._verdicts[-20:]

    @property
    def escalation_count(self) -> int:
        """How many recent checks required escalation."""
        return sum(
            1 for v in self._verdicts[-50:]
            if v.verdict in (Verdict.ESCALATE, Verdict.CONFLICT)
        )

    def to_dict(self) -> dict:
        return {"verdicts": [v.to_dict() for v in self._verdicts]}
