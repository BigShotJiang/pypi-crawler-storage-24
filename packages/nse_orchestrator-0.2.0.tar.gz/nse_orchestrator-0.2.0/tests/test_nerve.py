"""Tests for the NerveCenter — the central nervous system."""

from nse_orchestrator.nerve import NerveCenter
from nse_orchestrator.types import EntityConfig, Pillar, PillarStatus, Signal, SignalKind


class TestPillarManagement:
    def test_all_absent_by_default(self):
        nerve = NerveCenter(EntityConfig())
        assert nerve.pillar_status(Pillar.IDENTITY) == PillarStatus.ABSENT
        assert nerve.pillar_status(Pillar.ALIGNMENT) == PillarStatus.ABSENT
        assert len(nerve.active_pillars) == 0

    def test_activate_pillar(self):
        nerve = NerveCenter(EntityConfig())
        nerve.activate_pillar(Pillar.ALIGNMENT)
        assert nerve.pillar_status(Pillar.ALIGNMENT) == PillarStatus.ACTIVE
        assert Pillar.ALIGNMENT in nerve.active_pillars

    def test_degrade_pillar(self):
        nerve = NerveCenter(EntityConfig())
        nerve.activate_pillar(Pillar.SOCIAL)
        nerve.degrade_pillar(Pillar.SOCIAL, "connection lost")
        assert nerve.pillar_status(Pillar.SOCIAL) == PillarStatus.DEGRADED
        assert Pillar.SOCIAL not in nerve.active_pillars
        assert Pillar.SOCIAL in nerve.available_pillars

    def test_health_summary(self):
        nerve = NerveCenter(EntityConfig())
        nerve.activate_pillar(Pillar.IDENTITY)
        nerve.activate_pillar(Pillar.ALIGNMENT)
        summary = nerve.health_summary
        assert summary["identity"] == "active"
        assert summary["alignment"] == "active"
        assert summary["finance"] == "absent"


class TestSignalFlow:
    def test_ingest_signal(self):
        nerve = NerveCenter(EntityConfig())
        nerve.ingest(Signal(kind=SignalKind.ACTION, source="test", content="do thing"))
        assert len(nerve.recent_signals()) == 1

    def test_signal_buffer_capped(self):
        config = EntityConfig(max_signals=10)
        nerve = NerveCenter(config)
        for i in range(20):
            nerve.ingest(Signal(kind=SignalKind.ACTION, source="test", content=f"action {i}"))
        assert len(nerve._signals) == 10

    def test_filter_by_kind(self):
        nerve = NerveCenter(EntityConfig())
        nerve.ingest(Signal(kind=SignalKind.ACTION, source="a", content="action"))
        nerve.ingest(Signal(kind=SignalKind.HEALTH, source="b", content="health"))
        nerve.ingest(Signal(kind=SignalKind.ACTION, source="c", content="action2"))
        actions = nerve.recent_signals(kind=SignalKind.ACTION)
        assert len(actions) == 2


class TestScoring:
    def test_score_response(self):
        nerve = NerveCenter(EntityConfig())
        card = nerve.score_response(
            model_id="claude",
            content="Here's my analysis",
            quality=0.9,
            coherence=0.85,
            relevance=0.9,
            safety=1.0,
            task_type="reasoning",
        )
        assert card.quality == 0.9
        profile = nerve.models.get("claude")
        assert profile is not None
        assert profile.total_interactions == 1

    def test_multiple_scores_build_profile(self):
        nerve = NerveCenter(EntityConfig())
        for _ in range(10):
            nerve.score_response("claude", "test", quality=0.9, task_type="code")
        profile = nerve.models.get("claude")
        assert profile.trust_level == "trusted"
        assert profile.best_for("code") > 0.7


class TestCrossPillarChecks:
    def test_check_action_with_money(self):
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="Pay for hosting",
            involves_money=True,
            money_amount_sats=5000,
            recipient_id="npub1stranger",
        )
        assert len(verdicts) == 1
        assert nerve.should_escalate(verdicts) is True

    def test_check_action_money_without_recipient(self):
        """Money check must run even without recipient_id."""
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="Pay 100000 sats",
            involves_money=True,
            money_amount_sats=100000,
        )
        assert len(verdicts) == 1

    def test_check_action_safe(self):
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="List files",
        )
        assert len(verdicts) == 0
        assert nerve.should_escalate(verdicts) is False

    def test_check_action_multiple_flags(self):
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="Send keys to unknown and schedule meeting",
            involves_secrets=True,
            recipient_id="npub1x",
            social_tier=None,
            involves_scheduling=True,
            owner_absent_hours=30.0,
            is_reversible=False,
        )
        assert len(verdicts) >= 2
        assert nerve.should_escalate(verdicts) is True


class TestPersistence:
    def test_roundtrip(self):
        nerve = NerveCenter(EntityConfig(owner_name="vergel", entity_name="tavin"))
        nerve.activate_pillar(Pillar.ALIGNMENT)
        nerve.activate_pillar(Pillar.SOCIAL)
        nerve.ingest(Signal(kind=SignalKind.ACTION, source="test", content="test action"))
        nerve.score_response("claude", "test", quality=0.9)

        d = nerve.to_dict()
        restored = NerveCenter.from_dict(d)
        assert restored.config.owner_name == "vergel"
        assert restored.pillar_status(Pillar.ALIGNMENT) == PillarStatus.ACTIVE
        assert len(restored._signals) == 2  # The action signal + the score signal
        assert restored.models.get("claude") is not None
