"""Tests for SovereignEntity — the whole thing wired together."""

from nse_orchestrator.entity import SovereignEntity
from nse_orchestrator.types import Pillar, PillarStatus


class TestEntityCreation:
    def test_create_basic(self):
        entity = SovereignEntity.create(owner_name="vergel")
        assert entity.nerve.config.owner_name == "vergel"

    def test_create_with_entity_name(self):
        entity = SovereignEntity.create(owner_name="vergel", entity_name="tavin")
        assert entity.nerve.config.entity_name == "tavin"

    def test_pillars_absent_without_packages(self):
        """Without the pillar packages installed, all should be absent."""
        entity = SovereignEntity.create()
        # We can't guarantee which packages are installed in test env,
        # but the entity should still create successfully
        assert entity.nerve is not None
        assert isinstance(entity.health, dict)


class TestCrossPillarChecks:
    def test_check_safe_action(self):
        entity = SovereignEntity.create(owner_name="vergel")
        verdicts = entity.check("List files in workspace")
        assert len(verdicts) == 0
        assert entity.should_escalate(verdicts) is False

    def test_check_risky_payment(self):
        entity = SovereignEntity.create(owner_name="vergel")
        verdicts = entity.check(
            "Pay 10000 sats to unknown",
            involves_money=True,
            money_amount_sats=10000,
            recipient_id="npub1unknown",
            social_known=False,
        )
        assert len(verdicts) > 0
        assert entity.should_escalate(verdicts) is True

    def test_check_secrets_to_stranger(self):
        entity = SovereignEntity.create(owner_name="vergel")
        verdicts = entity.check(
            "Send nsec to contact",
            involves_secrets=True,
            recipient_id="npub1x",
            social_tier="gray",
        )
        assert entity.should_escalate(verdicts) is True


class TestModelManagement:
    def test_register_and_score(self):
        entity = SovereignEntity.create(owner_name="vergel")
        entity.register_model("claude-opus-4-6", display_name="Claude Opus", provider="anthropic")
        entity.score_response(
            model_id="claude-opus-4-6",
            content="Here's my analysis",
            quality=0.9,
            task_type="reasoning",
        )
        profile = entity.nerve.models.get("claude-opus-4-6")
        assert profile is not None
        assert profile.total_interactions == 1

    def test_best_model_for(self):
        entity = SovereignEntity.create()
        for _ in range(5):
            entity.score_response("code-llm", "code output", quality=0.95, task_type="code")
            entity.score_response("chat-llm", "chat output", quality=0.6, task_type="code")
        assert entity.best_model_for("code") == "code-llm"

    def test_leaderboard(self):
        entity = SovereignEntity.create()
        for _ in range(5):
            entity.score_response("good", "x", quality=0.9)
            entity.score_response("ok", "x", quality=0.6)
        board = entity.model_leaderboard()
        assert board[0] == "good"


class TestStatus:
    def test_status_report(self):
        entity = SovereignEntity.create(owner_name="vergel", entity_name="tavin")
        entity.register_model("claude", display_name="Claude")
        status = entity.status()
        assert status["owner"] == "vergel"
        assert status["entity"] == "tavin"
        assert "pillars" in status
        assert "active_models" in status
