"""Tests for LLM model registry and trust profiles."""

from nse_orchestrator.models import ModelRegistry, ModelProfile, ModelScore


class TestModelScore:
    def test_overall_score(self):
        score = ModelScore(quality=0.9, coherence=0.8, relevance=0.7, safety=1.0)
        # 0.9*0.3 + 0.8*0.25 + 0.7*0.25 + 1.0*0.2 = 0.27 + 0.20 + 0.175 + 0.20 = 0.845
        assert 0.84 < score.overall < 0.85

    def test_roundtrip(self):
        score = ModelScore(
            quality=0.8, coherence=0.7, relevance=0.9, safety=1.0,
            task_type="code", latency_ms=150.5,
        )
        d = score.to_dict()
        restored = ModelScore.from_dict(d)
        assert restored.quality == 0.8
        assert restored.task_type == "code"
        assert restored.latency_ms == 150.5


class TestModelProfile:
    def test_starts_unknown(self):
        profile = ModelProfile(model_id="test-model")
        assert profile.trust_level == "unknown"
        assert profile.total_interactions == 0

    def test_builds_trust(self):
        profile = ModelProfile(model_id="good-model")
        for _ in range(10):
            profile.record(ModelScore(quality=0.9, coherence=0.9, relevance=0.9, safety=1.0))
        assert profile.trust_level == "trusted"
        assert profile.total_interactions == 10

    def test_tracks_task_strengths(self):
        profile = ModelProfile(model_id="specialist")
        for _ in range(5):
            profile.record(ModelScore(
                quality=0.95, coherence=0.9, relevance=0.9, safety=1.0, task_type="code",
            ))
        for _ in range(5):
            profile.record(ModelScore(
                quality=0.5, coherence=0.5, relevance=0.5, safety=1.0, task_type="conversation",
            ))
        assert profile.best_for("code") > profile.best_for("conversation")

    def test_max_scores_enforced(self):
        profile = ModelProfile(model_id="chatty")
        for i in range(200):
            profile.record(ModelScore(quality=0.5, coherence=0.5, relevance=0.5, safety=1.0))
        assert len(profile.scores) == 100  # Default max
        assert profile.total_interactions == 200

    def test_summary(self):
        profile = ModelProfile(model_id="claude", display_name="Claude Opus")
        for _ in range(5):
            profile.record(ModelScore(
                quality=0.9, coherence=0.9, relevance=0.9, safety=1.0, task_type="reasoning",
            ))
        summary = profile.summary()
        assert "Claude Opus" in summary
        assert "trusted" in summary
        assert "reasoning" in summary

    def test_roundtrip(self):
        profile = ModelProfile(model_id="test", display_name="Test Model", provider="local")
        profile.record(ModelScore(quality=0.8, coherence=0.7, relevance=0.9, safety=1.0))
        d = profile.to_dict()
        restored = ModelProfile.from_dict(d)
        assert restored.model_id == "test"
        assert restored.total_interactions == 1
        assert len(restored.scores) == 1


class TestModelRegistry:
    def test_register_and_get(self):
        reg = ModelRegistry()
        reg.register("claude", display_name="Claude", provider="anthropic")
        profile = reg.get("claude")
        assert profile is not None
        assert profile.display_name == "Claude"

    def test_score_creates_profile(self):
        reg = ModelRegistry()
        reg.score("new-model", ModelScore(quality=0.8, coherence=0.8, relevance=0.8, safety=1.0))
        profile = reg.get("new-model")
        assert profile is not None
        assert profile.total_interactions == 1

    def test_best_model_for(self):
        reg = ModelRegistry()
        for _ in range(5):
            reg.score("code-model", ModelScore(
                quality=0.95, coherence=0.9, relevance=0.9, safety=1.0, task_type="code",
            ))
            reg.score("chat-model", ModelScore(
                quality=0.6, coherence=0.8, relevance=0.8, safety=1.0, task_type="code",
            ))
        best = reg.best_model_for("code")
        assert best is not None
        assert best.model_id == "code-model"

    def test_best_model_needs_minimum_interactions(self):
        reg = ModelRegistry()
        reg.score("newbie", ModelScore(quality=1.0, coherence=1.0, relevance=1.0, safety=1.0))
        assert reg.best_model_for("anything") is None

    def test_leaderboard(self):
        reg = ModelRegistry()
        for _ in range(5):
            reg.score("good", ModelScore(quality=0.9, coherence=0.9, relevance=0.9, safety=1.0))
            reg.score("ok", ModelScore(quality=0.6, coherence=0.6, relevance=0.6, safety=1.0))
            reg.score("bad", ModelScore(quality=0.3, coherence=0.3, relevance=0.3, safety=1.0))
        board = reg.leaderboard()
        assert board[0].model_id == "good"
        assert board[-1].model_id == "bad"

    def test_roundtrip(self):
        reg = ModelRegistry()
        reg.register("claude", display_name="Claude", provider="anthropic")
        reg.score("claude", ModelScore(quality=0.9, coherence=0.9, relevance=0.9, safety=1.0))
        d = reg.to_dict()
        restored = ModelRegistry.from_dict(d)
        assert restored.get("claude") is not None
        assert restored.get("claude").total_interactions == 1
