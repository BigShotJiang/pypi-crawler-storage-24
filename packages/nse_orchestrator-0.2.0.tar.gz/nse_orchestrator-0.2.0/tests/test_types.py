"""Tests for NSE core types."""

from nse_orchestrator.types import (
    EntityConfig,
    Pillar,
    PillarStatus,
    Signal,
    SignalKind,
    ScoreCard,
)


def test_pillar_values():
    assert Pillar.IDENTITY.value == "identity"
    assert Pillar.ALIGNMENT.value == "alignment"
    assert len(Pillar) == 5


def test_pillar_status_values():
    assert PillarStatus.ABSENT.value == "absent"
    assert PillarStatus.ACTIVE.value == "active"
    assert PillarStatus.DEGRADED.value == "degraded"


def test_signal_kind_values():
    assert SignalKind.ACTION.value == "action"
    assert SignalKind.COHERENCE.value == "coherence"
    assert len(SignalKind) == 7


def test_signal_roundtrip():
    signal = Signal(
        kind=SignalKind.ACTION,
        source="entity",
        content="test action",
        model_id="claude",
        pillar=Pillar.ALIGNMENT,
        confidence=0.8,
    )
    d = signal.to_dict()
    restored = Signal.from_dict(d)
    assert restored.kind == SignalKind.ACTION
    assert restored.source == "entity"
    assert restored.model_id == "claude"
    assert restored.pillar == Pillar.ALIGNMENT
    assert restored.confidence == 0.8


def test_signal_without_optional_fields():
    signal = Signal(kind=SignalKind.HEALTH, source="test", content="ok")
    d = signal.to_dict()
    assert d["model_id"] is None
    assert d["pillar"] is None
    restored = Signal.from_dict(d)
    assert restored.model_id is None
    assert restored.pillar is None


def test_score_card():
    signal = Signal(kind=SignalKind.RESPONSE, source="claude", content="test")
    card = ScoreCard(
        signal=signal,
        quality=0.9,
        coherence=0.8,
        relevance=0.85,
        safety=1.0,
        rationale="good response",
    )
    d = card.to_dict()
    assert d["quality"] == 0.9
    assert d["rationale"] == "good response"


def test_entity_config_defaults():
    config = EntityConfig()
    assert config.max_signals == 10000
    assert config.score_window == 100
    assert config.coherence_threshold == 0.6


def test_entity_config_roundtrip():
    config = EntityConfig(owner_npub="npub1test", owner_name="vergel", entity_name="tavin")
    d = config.to_dict()
    restored = EntityConfig.from_dict(d)
    assert restored.owner_npub == "npub1test"
    assert restored.owner_name == "vergel"
    assert restored.entity_name == "tavin"
