"""Security tests — verifying red team findings are properly fixed.

Each test maps to a specific finding from the security review.
"""

import math
from types import MappingProxyType

from nse_orchestrator.types import Signal, SignalKind, ScoreCard, EntityConfig, _clamp
from nse_orchestrator.models import ModelScore, ModelProfile, ModelRegistry
from nse_orchestrator.checks import CrossPillarCheck
from nse_orchestrator.nerve import NerveCenter, _sanitize_content
from nse_orchestrator.entity import SovereignEntity


class TestInputValidation:
    """Finding 1a: Numeric score validation."""

    def test_clamp_rejects_nan(self):
        assert _clamp(float("nan")) == 0.0

    def test_clamp_rejects_inf(self):
        assert _clamp(float("inf")) == 0.0
        assert _clamp(float("-inf")) == 0.0

    def test_clamp_rejects_negative(self):
        assert _clamp(-0.5) == 0.0

    def test_clamp_rejects_over_one(self):
        assert _clamp(999.0) == 1.0

    def test_model_score_clamps_quality(self):
        score = ModelScore(quality=2.0, coherence=-1.0, relevance=float("nan"), safety=float("inf"))
        assert score.quality == 1.0
        assert score.coherence == 0.0
        assert score.relevance == 0.0
        assert score.safety == 0.0

    def test_signal_clamps_confidence(self):
        signal = Signal(kind=SignalKind.ACTION, source="test", content="x", confidence=5.0)
        assert signal.confidence == 1.0

    def test_signal_nan_confidence(self):
        signal = Signal(kind=SignalKind.ACTION, source="test", content="x", confidence=float("nan"))
        assert signal.confidence == 0.0

    def test_scorecard_clamps_values(self):
        signal = Signal(kind=SignalKind.ACTION, source="test", content="x")
        card = ScoreCard(signal=signal, quality=2.0, coherence=-1.0, relevance=float("nan"), safety=1.5)
        assert card.quality == 1.0
        assert card.coherence == 0.0
        assert card.relevance == 0.0
        assert card.safety == 1.0


class TestEntityConfigValidation:
    """Finding 1b: Config numeric validation."""

    def test_min_signals_enforced(self):
        config = EntityConfig(max_signals=0)
        assert config.max_signals >= 1

    def test_negative_signals_enforced(self):
        config = EntityConfig(max_signals=-100)
        assert config.max_signals >= 1

    def test_min_score_window_enforced(self):
        config = EntityConfig(score_window=0)
        assert config.score_window >= 1

    def test_config_is_frozen(self):
        config = EntityConfig(owner_name="vergel")
        try:
            config.owner_name = "hacked"
            assert False, "Should have raised FrozenInstanceError"
        except AttributeError:
            pass


class TestMemoryExhaustion:
    """Finding 2a: Verdict list must be bounded."""

    def test_verdict_list_capped(self):
        checks = CrossPillarCheck()
        for i in range(300):
            checks.check_payment_to_stranger(f"npub{i}", 100, social_known=True, social_tier="known")
        assert len(checks._verdicts) <= CrossPillarCheck.MAX_VERDICTS

    def test_model_registry_capped(self):
        reg = ModelRegistry()
        for i in range(600):
            reg.register(f"model-{i}")
        assert len(reg._models) <= ModelRegistry.MAX_MODELS


class TestFrozenDataclassBypass:
    """Finding 8a: Signal.metadata must be truly immutable."""

    def test_metadata_is_immutable(self):
        signal = Signal(
            kind=SignalKind.ACTION,
            source="test",
            content="test",
            metadata={"key": "value"},
        )
        assert isinstance(signal.metadata, MappingProxyType)
        try:
            signal.metadata["key"] = "hacked"
            assert False, "Should have raised TypeError"
        except TypeError:
            pass

    def test_metadata_injection_blocked(self):
        signal = Signal(
            kind=SignalKind.ACTION,
            source="test",
            content="test",
            metadata={"safe": True},
        )
        try:
            signal.metadata["injected"] = "payload"
            assert False, "Should have raised TypeError"
        except TypeError:
            pass


class TestInformationLeakage:
    """Finding 6a: Secret content must be redacted."""

    def test_nsec_redacted(self):
        cleaned = _sanitize_content("Your key is nsec1abc123def456ghi789jkl012mno345pqr678stu901vwx234yz567ab")
        assert "nsec1" not in cleaned
        assert "[REDACTED]" in cleaned

    def test_api_key_redacted(self):
        cleaned = _sanitize_content("API key: sk-abc123def456ghi789jkl012mno345pqr")
        assert "sk-" not in cleaned
        assert "[REDACTED]" in cleaned

    def test_bearer_token_redacted(self):
        cleaned = _sanitize_content("Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0")
        assert "Bearer" not in cleaned or "eyJ" not in cleaned

    def test_nerve_sanitizes_score_content(self):
        nerve = NerveCenter(EntityConfig())
        nerve.score_response(
            model_id="test",
            content="Here's the nsec1abc123def456ghi789jkl012mno345pqr678stu901vwx234yz567ab key",
            quality=0.5,
        )
        signals = nerve.recent_signals()
        for s in signals:
            assert "nsec1" not in s.content


class TestMoneyCheckBypass:
    """Finding 4a: Money check must run even without recipient_id."""

    def test_money_check_without_recipient(self):
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="Pay 100000 sats",
            involves_money=True,
            money_amount_sats=100000,
        )
        assert len(verdicts) >= 1

    def test_safe_defaults_assume_worst(self):
        """social_known=False, owner_recently_active=False by default."""
        nerve = NerveCenter(EntityConfig())
        verdicts = nerve.check_action(
            description="Pay 5000 sats",
            involves_money=True,
            money_amount_sats=5000,
            recipient_id="npub1x",
        )
        assert len(verdicts) >= 1
        assert any(v.verdict.value in ("escalate", "caution") for v in verdicts)


class TestTrustManipulation:
    """Finding 3a: Trust inflation resistance."""

    def test_scores_are_clamped(self):
        """Cannot submit quality > 1.0 to inflate trust."""
        reg = ModelRegistry()
        for _ in range(10):
            reg.score("evil", ModelScore(quality=999.0, coherence=999.0, relevance=999.0, safety=999.0))
        profile = reg.get("evil")
        assert profile.avg_quality <= 1.0

    def test_signal_content_truncated(self):
        """Cannot store multi-megabyte strings."""
        signal = Signal(kind=SignalKind.ACTION, source="test", content="x" * 100000)
        assert len(signal.content) <= 2000
