function plotConnectivity3D(injectionSummary, allenAtlasPath, regionToPlot, color, plotPatch, atlasType, atlasResolution)

% Handle optional atlas parameters
if nargin < 6 || isempty(atlasType)
    atlasType = 'allen'; % Default to Allen atlas
end
if nargin < 7 || isempty(atlasResolution)
    atlasResolution = 10; % Default to 10um resolution
end

% Construct atlas filenames based on type and resolution
switch lower(atlasType)
    case 'allen'
        if atlasResolution == 10
            annotationFile = 'annotation_volume_10um_by_index.npy';
            structureFile = 'structure_tree_safe_2017.csv';
        elseif atlasResolution == 20
            annotationFile = 'annotation_volume_v2_20um_by_index.npy';
            structureFile = 'UnifiedAtlas_Label_ontology_v2.csv';
        else
            error('Unsupported Allen atlas resolution: %d. Supported resolutions are 10 and 20 um.', atlasResolution);
        end
    otherwise
        % For custom atlases, construct filename from type and resolution
        annotationFile = sprintf('%s_annotation_%dum.npy', atlasType, atlasResolution);
        structureFile = sprintf('%s_structure_tree.csv', atlasType);
end

% load atlas 
av = readNPY([allenAtlasPath, filesep, annotationFile]); % the number at each pixel labels the area, see note below
st = loadStructureTree([allenAtlasPath, filesep, structureFile]); % a table of what all the labels mean

% plot brain outline/volume 
if plotPatch
    [h1, patchHandle] = ya_plotBrainSurface(allenAtlasPath, 'w');
else
    [~, brain_outline] = plotBrainGrid([], []);
end
hold on;

% plot region 
curr_plot_structure_idx = find(contains(st.acronym, regionToPlot));
region_to_plot_structure_color = hex2dec(reshape(st.color_hex_triplet{curr_plot_structure_idx(1)}, 2, [])') ./ 255;
slice_spacing = atlasResolution;
structure_3d = isosurface(permute(ismember(av(1:slice_spacing:end, ...
    1:slice_spacing:end, 1:slice_spacing:end), curr_plot_structure_idx), [3, 1, 2]), 0);
structure_alpha = 0.3;
hold on;
patch('Vertices', structure_3d.vertices*slice_spacing, ...
    'Faces', structure_3d.faces, ...
    'FaceColor', region_to_plot_structure_color, 'EdgeColor', 'none', 'FaceAlpha', structure_alpha);

% plot injections 
iView = 1;
axis equal

max_voxel_x = injectionSummary.max_voxel_x / atlasResolution;
max_voxel_y = injectionSummary.max_voxel_y / atlasResolution;
max_voxel_z = injectionSummary.max_voxel_z / atlasResolution;

% remove any missing data 
keepMe = max_voxel_x ~= 0;

injection_structure_idx = arrayfun(@(x) find(st.id == injectionSummary.structure_id(x)), 1:size(injectionSummary,1));

plotAllColors = false; %leave false for now
if plotAllColors
    hex_triplets = st.color_hex_triplet(injection_structure_idx(keepMe));
    rgbMatrix = cell2mat(arrayfun(@(x) hex2dec(reshape(x{1}, 2, 3)')', hex_triplets, 'UniformOutput', false)) ./ 255;
else
    rgbMatrix = hex2dec(reshape(st.color_hex_triplet{injection_structure_idx(1)}, 2, [])')' ./ 255;
end
% projection_volume is in mm^ 3, atlas is in 10um x 10um x 10um -> multiply
% by 10^6 - but that looks really odd. QQ leave as 10^3 for now. scatter is
% also the wrong tool for this - it doesn't scale with the plot
dotSize = 10^3;
scatter3(max_voxel_x(keepMe), max_voxel_z(keepMe), max_voxel_y(keepMe), ...
    [injectionSummary.projection_volume(keepMe)].*dotSize , rgbMatrix, 'filled', ...
    'MarkerFaceAlpha', 0.5, 'MarkerEdgeAlpha', ...
    1)

set(gcf, 'Color', 'w')
hold off;

% make a movie 
%save as .avi rotating vid
% view([0, 0])
% OptionZ.FrameRate = 5;
% OptionZ.Duration = 15.5;
% OptionZ.Periodic = true;
% CaptureFigVid([-20, 10; -110, 10; -190, 80; -290, 10; -380, 10], 'WellMadeVid', OptionZ)


end
