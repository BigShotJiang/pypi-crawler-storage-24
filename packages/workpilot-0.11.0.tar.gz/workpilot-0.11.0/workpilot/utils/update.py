"""Shared update-check logic — used by heartbeat tool and CLI (PyPI path)."""

from __future__ import annotations

import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from workpilot import __version__


@dataclass
class UpdateStatus:
    """Result of an update check."""

    up_to_date: bool
    current: str = __version__
    latest: str | None = None
    commit_count: int = 0
    commit_log: str = ""  # oneline summaries (git only)
    install_mode: str = "unknown"  # "git" | "pypi"
    error: str | None = None

    @property
    def summary(self) -> str:
        if self.error:
            return f"Update check failed: {self.error}"
        if self.up_to_date:
            if self.install_mode == "git":
                return f"WorkPilot v{self.current} is up to date (git)."
            return (
                f"WorkPilot v{self.current} is up to date (latest: v{self.latest or self.current})."
            )
        if self.install_mode == "git":
            msg = f"WorkPilot update available: {self.commit_count} new commit(s).\nCurrent: v{self.current}"
            if self.commit_log:
                msg += f"\nLatest commits:\n{self.commit_log}"
            return msg + "\nRun `workpilot update` to install."
        return (
            f"WorkPilot update available: v{self.current} -> v{self.latest}\n"
            f"Run `workpilot update` to install."
        )


def is_git_install() -> Path | None:
    """Return repo root if editable git install, else None."""
    repo_root = Path(__file__).resolve().parent.parent.parent
    return repo_root if (repo_root / ".git").exists() else None


def parse_version(v: str) -> tuple[int, ...]:
    """Parse version string to comparable tuple (e.g. '0.7.0' -> (0, 7, 0))."""
    return tuple(int(x) for x in re.findall(r"\d+", v))


def check_git(repo: Path) -> UpdateStatus:
    """Fetch and compare with upstream. Does NOT pull."""
    if _run(["git", "fetch"], cwd=repo) is None:
        return UpdateStatus(up_to_date=False, install_mode="git", error="git fetch failed")

    local = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    remote = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if not local or not remote:
        return UpdateStatus(
            up_to_date=False, install_mode="git", error="could not compare local/remote"
        )

    if local == remote:
        return UpdateStatus(up_to_date=True, install_mode="git")

    # Detect ahead/behind/diverged
    lr_out = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    behind = 0
    if lr_out:
        parts = lr_out.split()
        if len(parts) == 2:
            behind = int(parts[1])

    if behind == 0:
        # Ahead only or diverged with no upstream commits — no update available
        return UpdateStatus(up_to_date=True, install_mode="git")

    log_out = _run(["git", "log", "--oneline", "-5", f"{local}..{remote}"], cwd=repo) or ""

    return UpdateStatus(
        up_to_date=False,
        install_mode="git",
        commit_count=behind,
        commit_log=log_out,
    )


def check_pypi() -> UpdateStatus:
    """Check PyPI for a newer version."""
    latest = _fetch_pypi_version()
    if latest is None:
        return UpdateStatus(
            up_to_date=False, install_mode="pypi", error="could not determine latest PyPI version"
        )

    if parse_version(__version__) >= parse_version(latest):
        return UpdateStatus(up_to_date=True, install_mode="pypi", latest=latest)

    return UpdateStatus(up_to_date=False, install_mode="pypi", latest=latest)


def check_update() -> UpdateStatus:
    """Auto-detect install mode and check for updates."""
    repo = is_git_install()
    return check_git(repo) if repo else check_pypi()


# ── Internal helpers ─────────────────────────────────────────────────────────


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 30) -> str | None:
    """Run a command, return stdout or None on failure."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def _fetch_pypi_version() -> str | None:
    """Get latest version from PyPI (httpx -> pip fallback)."""
    try:
        import httpx

        resp = httpx.get("https://pypi.org/pypi/workpilot/json", timeout=10)
        resp.raise_for_status()
        return str(resp.json()["info"]["version"])
    except Exception:
        pass
    out = _run([sys.executable, "-m", "pip", "index", "versions", "workpilot"], timeout=30)
    if out:
        m = re.search(r"\(([^)]+)\)", out.splitlines()[0])
        return m.group(1).split(",")[0].strip() if m else None
    return None
