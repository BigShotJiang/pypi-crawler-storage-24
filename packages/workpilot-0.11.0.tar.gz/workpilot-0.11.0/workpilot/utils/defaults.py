"""Bundled defaults loader.

Loads packaged default files (identity, config) via importlib.resources.
Works both from source checkouts and pip-installed wheels.
"""

from __future__ import annotations

from importlib.resources import files

_DEFAULT_NAMES = {
    "SOUL.md",
    "AGENTS.md",
    "TOOLS.md",
    "HEARTBEAT.md",
    "COMPACTION.md",
    "CONSOLIDATION.md",
    "GROUPING.md",
    "MERGE_SUMMARY.md",
    "RECOMPRESSION.md",
    "SECURITY.md",  # bundled only — not user-overridable
    "USER.md",
    "MEMORY.md",
}


def load_builtin_default(name: str) -> str:
    """Return bundled default content for a known file name.

    Raises:
        ValueError: if the name is not in the allowlist.
        FileNotFoundError: if packaged data is missing.
    """
    if name not in _DEFAULT_NAMES:
        raise ValueError(f"Unsupported default: {name}")
    resource = files("workpilot.defaults").joinpath(name)
    return resource.read_text(encoding="utf-8").strip()


def load_prompt_pair(
    name: str,
    **kwargs: str,
) -> list[dict[str, str]]:
    """Load a prompt template and return ``[system, user]`` messages.

    Template files use ``---`` on a line by itself to separate
    the system portion (instructions) from the user portion (data).
    If no separator is found, the entire template becomes the user message.

    Placeholders in the template (``{key}``) are filled from *kwargs*
    using :func:`safe_format` (safe against user content with braces).

    User-overridable: ``~/.workpilot/<name>`` takes precedence over
    the bundled default.
    """
    from pathlib import Path

    user_path = Path.home() / ".workpilot" / name
    if user_path.is_file():
        raw = user_path.read_text(encoding="utf-8").strip()
    else:
        raw = load_builtin_default(name)

    filled = safe_format(raw, **kwargs)

    # Split on first "---" line
    separator = "\n---\n"
    if separator in filled:
        system_part, user_part = filled.split(separator, 1)
        return [
            {"role": "system", "content": system_part.strip()},
            {"role": "user", "content": user_part.strip()},
        ]

    # No separator — entire content is user message
    return [{"role": "user", "content": filled}]


def safe_format(template: str, **kwargs: str) -> str:
    """Format a prompt template safely.

    Escapes ``{`` and ``}`` in *values* before calling ``str.format()``,
    so user content containing Python format strings (e.g. ``{key}``,
    ``dict.format({})`` ) won't cause ``KeyError`` / ``IndexError``.

    The *template* placeholders (``{messages}``, ``{conversation}``, etc.)
    are filled normally.
    """
    escaped = {k: v.replace("{", "{{").replace("}", "}}") for k, v in kwargs.items()}
    return template.format(**escaped)
