"""workpilot serve — web server command and PID management helpers."""

from __future__ import annotations

import asyncio
import json as _json
import os
import socket
import subprocess
from pathlib import Path

import typer
from rich.panel import Panel

from workpilot import __version__
from workpilot.runtime import Runtime

# ── Web server PID helpers ────────────────────────────────────────────────────


def _web_pid_file() -> Path:
    from workpilot.utils.helpers import get_data_dir

    data_dir = get_data_dir()
    new_path = data_dir / "web.pid"
    old_path = data_dir / "gateway.pid"
    # Migrate legacy pid file
    if old_path.exists() and not new_path.exists():
        try:
            old_path.rename(new_path)
        except OSError:
            pass
    return new_path


def _try_unlink(path: Path) -> None:
    """Remove *path* ignoring FileNotFoundError and PermissionError/OSError.

    plain unlink(missing_ok=True) still raises on PermissionError (e.g. a
    locked pid file held by antivirus), which would bubble up and block
    web server startup or the single-instance check.
    """
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def _is_port_listening(port: int) -> bool:
    """Return True if *port* is currently bound on localhost.

    Uses socket.create_connection so both IPv4 (127.0.0.1) and IPv6 (::1)
    listeners are detected — create_connection iterates all resolved addresses
    for "localhost" and succeeds as soon as any of them connect.
    """
    try:
        with socket.create_connection(("localhost", port), timeout=1.0):
            return True
    except OSError:
        return False


def _check_web_running() -> tuple[int, int] | None:
    """Return (pid, port) if a web server instance is running, else None.

    Uses port-listening check as the primary liveness signal — this is
    cross-platform reliable and avoids Windows PID-reuse false positives
    that made stale pid files block startup permanently.
    """
    pid_file = _web_pid_file()
    if not pid_file.exists():
        return None
    try:
        data = _json.loads(pid_file.read_text(encoding="utf-8"))
        pid: int = int(data["pid"])
        port: int = int(data["port"])
    except Exception:
        _try_unlink(pid_file)
        return None

    # Sanity-check parsed values before using them in os.kill / socket calls.
    # os.kill(-1, 0) on POSIX signals all processes; negative/zero ports and
    # ports > 65535 are invalid and create_connection would raise immediately.
    if not (pid >= 1 and 1 <= port <= 65535):
        _try_unlink(pid_file)
        return None

    # Primary check: is anything listening on the recorded port?
    if not _is_port_listening(port):
        _try_unlink(pid_file)
        return None

    # Port is occupied — verify the PID is still alive.
    # On Windows, os.kill(pid, 0) is unreliable: it can raise PermissionError
    # for both "process exists but owned by another user" and "process doesn't
    # exist" (PID-reuse). So we only trust ProcessLookupError (definitive no)
    # and treat everything else as "probably ours" — if someone else stole
    # our port, the web server startup will fail with a clear bind-error anyway.
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        # Process definitely gone — port is taken by something else
        _try_unlink(pid_file)
        return None
    except (PermissionError, OSError):
        if os.name == "nt":
            # On Windows, verify process existence via tasklist
            try:
                result = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if "python" not in result.stdout.lower():
                    _try_unlink(pid_file)
                    return None
            except Exception:
                # tasklist failed — don't block startup
                _try_unlink(pid_file)
                return None

    return pid, port


def _write_web_pid(pid: int, port: int) -> None:
    _web_pid_file().write_text(_json.dumps({"pid": pid, "port": port}), encoding="utf-8")


def _remove_web_pid() -> None:
    _try_unlink(_web_pid_file())


# ── serve command ─────────────────────────────────────────────────────────────


def serve(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    host: str | None = typer.Option(None, "--host", help="Override bind host"),
    port: int | None = typer.Option(None, "--port", help="Override bind port"),
) -> None:
    """Start the multi-channel web server (FastAPI + uvicorn). Alias: s"""
    from workpilot.cli.commands import _load_config_safe, console

    try:
        from workpilot.web.server import WebServer  # noqa: F401
    except ImportError:
        console.print(
            "[red]Error:[/red] FastAPI and uvicorn are required for the web server.\n"
            "  Install with: [bold]pip install fastapi uvicorn[/bold]"
        )
        raise typer.Exit(1)

    # Single-instance guard
    running = _check_web_running()
    if running:
        existing_pid, existing_port = running
        console.print(
            Panel(
                f"[yellow]Web server already running[/yellow]\n\n"
                f"  PID  : [bold]{existing_pid}[/bold]\n"
                f"  Port : [bold]{existing_port}[/bold]\n"
                f"  URL  : [cyan]http://localhost:{existing_port}[/cyan]\n\n"
                f"To stop it: [bold]kill {existing_pid}[/bold]",
                title="Already Running",
                border_style="yellow",
            )
        )
        raise typer.Exit(1)

    cfg = _load_config_safe(config, profile)
    web_cfg = cfg.channels.web

    # Allow CLI overrides for host / port
    if host is not None:
        web_cfg.host = host
    if port is not None:
        web_cfg.port = port

    rt = Runtime(cfg)

    _pid = os.getpid()

    console.print(
        Panel(
            f"[bold]WorkPilot Web Server[/bold]  v{__version__}\n"
            f"Listening on [cyan]http://{web_cfg.host}:{web_cfg.port}[/cyan]\n\n"
            f"  GET  /                     — web chat UI\n"
            f"  GET  /health               — health check\n"
            f"  POST /api/chat             — send prompt\n"
            f"  POST /api/chat/stream      — SSE streaming\n"
            f"  WS   /api/ws               — WebSocket chat\n"
            f"  GET  /api/sessions          — list sessions\n"
            f"  GET  /api/tools             — list tools\n"
            f"  GET  /api/health            — detailed health\n"
            f"  POST /api/estop             — emergency stop\n"
            f"  POST /api/reset             — reset E-stop\n"
            f"  POST /v1/chat/completions  — OpenAI-compatible",
            title="Web Server",
            border_style="green",
        )
    )

    try:
        asyncio.run(rt.run_web_server(on_started=lambda port: _write_web_pid(_pid, port)))
    except KeyboardInterrupt:
        console.print("\nShutting down web server...")
    finally:
        _remove_web_pid()


# Backward compatibility aliases
_gateway_pid_file = _web_pid_file
_check_gateway_running = _check_web_running
