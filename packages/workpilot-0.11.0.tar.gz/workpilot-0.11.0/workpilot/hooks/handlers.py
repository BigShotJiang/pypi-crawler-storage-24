"""
Built-in hook handlers — the 8 safety handlers always registered.

on_message_received:
  - InjectionScanner (priority 10)

pre_tool_use:
  - EStopGate (priority 1)
  - PolicyGate (priority 10)
  - ApprovalGate (priority 20) — allowlist check, classifier, human-in-the-loop

post_tool_use:
  - LeakScanner (priority 10)
  - Auditor (priority 30)

on_message_sent:
  - OutboundLeakScanner (priority 10)
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.config.schema import ChannelType
from workpilot.hooks.manager import (
    HookManager,
    HookResult,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from workpilot.security.leak import detect_credentials, redact_credentials
from workpilot.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from workpilot.bus.queue import EventBus
    from workpilot.channels.manager import ChannelManager
    from workpilot.security.allowlist import AllowlistManager
    from workpilot.security.approval import ApprovalManager
    from workpilot.security.audit import AuditLogger
    from workpilot.security.rbac import PolicyEngine
    from workpilot.security.scorer import RiskScorer


# ── on_message_received handlers ─────────────────────────────────────────────


class InjectionScanner:
    """Detect prompt injection patterns in inbound messages."""

    def __init__(self, *, block: bool = False) -> None:
        self._block = block

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        findings = Sanitizer.check_prompt_injection(ctx.content)
        if findings:
            logger.warning(
                "Injection patterns detected from {}: {}",
                ctx.sender_id or "unknown",
                findings,
            )
            if self._block:
                return HookResult.reject(f"Prompt injection detected: {findings[0]}")
        return HookResult.allow()


# ── pre_tool_use handlers ────────────────────────────────────────────────────


class EStopGate:
    """Reject all tool calls when E-stop is active."""

    def __init__(self, estop: object | None = None) -> None:
        self._estop = estop

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._estop is not None and getattr(self._estop, "is_halted", False):
            return HookResult.reject("E-stop is active — all tool execution halted")
        return HookResult.allow()


class PolicyGate:
    """Check RBAC permissions before tool execution."""

    def __init__(self, policy_engine: PolicyEngine | None = None) -> None:
        self._engine = policy_engine

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._engine is None:
            return HookResult.allow()
        # check_permission returns (allowed: bool, level: AutonomyLevel)
        # operation defaults to "write" for tools that modify state
        operation = (
            "read" if ctx.tool_name in ("read_file", "list_dir", "search_files") else "write"
        )
        allowed, _level = self._engine.check_permission(
            ctx.tool_name, operation, agent_name=ctx.agent_name
        )
        if not allowed:
            return HookResult.reject(
                f"Tool '{ctx.tool_name}' denied by policy for agent '{ctx.agent_name}'"
            )
        return HookResult.allow()


# ── Score-aware timeout calculation ───────────────────────────────────────────

_T_BASE: dict[int, int] = {1: 45, 2: 90, 3: 120, 4: 150, 5: 180, 6: 240, 7: 300, 8: 360}
_T_FACTOR: dict[str, float] = {"open": 0.75, "standard": 1.0, "controlled": 1.25, "restricted": 1.5}
_H_FACTOR: dict[str, float] = {"open": 1.5, "standard": 1.0, "controlled": 0.75, "restricted": 0.5}


def _score_aware_timeout(
    score: int | None,
    is_auto_approve: bool,
    profile: str = "standard",
) -> int | None:
    """Compute score × profile aware timeout.

    Timeout-auto (auto-approve): higher score → longer timeout (more intervention time).
    Human (reject): higher score → shorter timeout (reject dangerous ops faster).
    Null score → None (wait forever for human decision).

    Returns timeout in seconds, or None for infinite wait.
    """
    if score is None:
        return None  # null score: always wait for human

    if is_auto_approve:
        base = _T_BASE.get(score, 180)
        factor = _T_FACTOR.get(profile, 1.0)
        raw = base * factor
    else:
        factor = _H_FACTOR.get(profile, 1.0)
        raw = (10 - score) * 60 * factor

    # Clamp to [30, 600] and round to nearest 30s
    clamped = max(30, min(600, raw))
    return round(clamped / 30) * 30


class ApprovalGate:
    """Risk scorer approval gate for tool calls with human-in-the-loop (v2).

    Flow:
    1. Allowlist check -> allow (both scorer and no-scorer paths)
    2. No scorer wired -> fall back to deterministic assess_risk + policy;
       RiskPrompt without scorer -> reject (fail closed)
    3. Score tool call via scorer (assess_risk → LLM if needed) -> RiskScore
    4. Policy table lookup: score x profile -> Auto/Timeout-auto/Human/Reject
    5. On Human/Timeout-auto: request approval, send prompt, await resolution.

    CLI special case: uses ``run_in_executor`` for inline ``input()`` prompt
    (y/n/always). "always" adds the tool to the allowlist.
    """

    def __init__(
        self,
        scorer: RiskScorer | None = None,
        *,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        bus: EventBus | None = None,
        channel_manager: ChannelManager | None = None,
        session_manager: Any = None,
        auto_approve_timeout: int = 180,
        security_profile: str = "standard",
    ) -> None:
        self._scorer = scorer
        self._security_profile = security_profile
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._bus = bus
        self._channel_manager = channel_manager
        self._session_manager = session_manager
        self._auto_approve_timeout = auto_approve_timeout

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        from workpilot.security.risk import PolicyAction, lookup_policy

        # 1. Allowlist check — skip scoring entirely (checked for both paths)
        if self._allowlist and self._allowlist.check(ctx.tool_name, ctx.args):
            logger.debug("Allowlist hit for tool '{}' -- skipping scorer", ctx.tool_name)
            return HookResult.allow()

        # 2. No scorer wired -> fall back to deterministic assess_risk + policy
        if not self._scorer:
            if ctx.tool_ref is not None and hasattr(ctx.tool_ref, "assess_risk"):
                from workpilot.security.risk import RiskScore

                assessment = ctx.tool_ref.assess_risk(ctx.args)
                if isinstance(assessment, RiskScore):
                    profile = self._security_profile
                    action, always_allow = lookup_policy(assessment.score, profile)
                    if action == PolicyAction.AUTO:
                        return HookResult.allow()
                    if action == PolicyAction.REJECT:
                        return HookResult.reject(
                            f"[score {assessment.score} / 10] {assessment.reason}"
                        )
                    # Human / Timeout-auto — route to approval if available
                    if not self._approval_manager:
                        return HookResult.reject(f"Requires approval: {assessment.reason}")
                    return await self._route_to_approval(ctx, assessment, action, always_allow)
                # RiskPrompt but no scorer → fail closed
                return HookResult.reject("No risk scorer available for LLM evaluation")
            return HookResult.allow()

        # 3. Score the tool call (assess_risk → scorer → policy table)
        risk_score = await self._scorer.score(
            ctx.tool_name,
            ctx.args,
            tool_ref=ctx.tool_ref,
            user_messages=ctx.user_messages or [],
        )

        # 4. Policy table lookup (use gate's profile, not scorer's, for consistency)
        action, always_allow = lookup_policy(risk_score.score, self._security_profile)

        if action == PolicyAction.AUTO:
            return HookResult.allow()
        if action == PolicyAction.REJECT:
            return HookResult.reject(f"[score {risk_score.score} / 10] {risk_score.reason}")

        # 5. Human or Timeout-auto — route to approval
        if not self._approval_manager:
            return HookResult.reject(f"Requires approval: {risk_score.reason}")

        return await self._route_to_approval(ctx, risk_score, action, always_allow)

    async def _route_to_approval(
        self,
        ctx: PreToolHookContext,
        risk_score: Any,
        action: Any,
        always_allow: bool,
    ) -> HookResult:
        """Route a tool call to human approval (Human or Timeout-auto action)."""
        from workpilot.security.risk import PolicyAction

        assert self._approval_manager is not None

        # Score-aware timeouts (see _score_aware_timeout):
        # Timeout-auto: higher score → longer timeout (more time to intervene)
        # Human: higher score → shorter timeout (reject dangerous ops faster)
        auto_timeout: int | None = None
        reject_timeout: int | None = None
        if action == PolicyAction.TIMEOUT_AUTO:
            auto_timeout = _score_aware_timeout(
                risk_score.score, is_auto_approve=True, profile=self._security_profile
            )
        else:
            reject_timeout = _score_aware_timeout(
                risk_score.score, is_auto_approve=False, profile=self._security_profile
            )

        # Resolve channel
        resolved_channel = ctx.channel
        if resolved_channel is None and self._channel_manager:
            active = self._channel_manager.active_channel_names()
            if active:
                resolved_channel = ChannelType.of(active[0])

        request = await self._approval_manager.request_approval(
            tool_name=ctx.tool_name,
            args=ctx.args,
            agent_name=ctx.agent_name,
            channel=resolved_channel,
            channel_id=ctx.channel_id or "",
            score=risk_score.score,
            reason=risk_score.reason,
        )

        # Persist approval_request to session
        if self._session_manager and ctx.session_id:
            import json as _json

            self._session_manager.add_message(
                ctx.session_id,
                {
                    "role": "approval_request",
                    "content": _json.dumps(
                        {
                            "request_id": request.id,
                            "tool_name": ctx.tool_name,
                            "args": {k: str(v)[:200] for k, v in list(ctx.args.items())[:10]},
                            "score": risk_score.score,
                            "reason": risk_score.reason,
                            "status": "pending",
                        }
                    ),
                },
            )

        # Emit APPROVAL_REQUESTED event
        if self._bus:
            from workpilot.bus.events import EventType

            self._bus.emit(
                EventType.APPROVAL_REQUESTED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "score": risk_score.score,
                    "reason": risk_score.reason,
                },
            )

        # Send approval prompt to channel
        if request.channel == ChannelType.CLI:
            return await self._cli_prompt(
                ctx, request, risk_score, action, always_allow, auto_timeout
            )

        await self._send_approval_prompt(ctx, request, risk_score, auto_timeout, reject_timeout)

        # Wait for resolution
        resolved = await self._approval_manager.wait_for_resolution(
            request.id,
            auto_approve_timeout=auto_timeout,
            reject_timeout=reject_timeout,
        )

        # Emit resolution event
        if self._bus:
            from workpilot.bus.events import EventType

            approved = resolved.status.value == "approved"
            self._bus.emit(
                EventType.TOOL_APPROVED if approved else EventType.TOOL_DENIED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "resolver": resolved.resolver,
                },
            )

        from workpilot.security.approval import ApprovalStatus

        approved = resolved.status == ApprovalStatus.APPROVED
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver={} score={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            resolved.resolver or "timeout",
            risk_score.score,
            request.id,
        )

        if approved:
            return HookResult.allow()
        return HookResult.reject(
            f"Tool '{ctx.tool_name}' {resolved.status.value} by {resolved.resolver or 'timeout'}"
        )

    async def _cli_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        action: Any,
        always_allow: bool,
        auto_timeout: int | None,
    ) -> HookResult:
        """Inline CLI approval prompt — rich display with optional countdown."""
        assert self._approval_manager is not None

        score = risk_score.score
        score_str = f"{score} / 10" if score is not None else "? / 10"

        # Color by score range
        if score is None or score >= 9:
            colour = "\033[35m"  # magenta
        elif score >= 7:
            colour = "\033[31m"  # red
        elif score >= 5:
            colour = "\033[33m"  # yellow
        else:
            colour = "\033[32m"  # green
        reset = "\033[0m"

        args_lines = "\n".join(f"    {k} = {v!r}" for k, v in list(ctx.args.items())[:8])
        timeout_line = (
            f"  Auto-approving in {auto_timeout}s if no response.\n"
            if auto_timeout is not None
            else "  No auto-approve -- waiting for your decision.\n"
        )
        always_hint = "  [a]lways" if always_allow else ""
        banner = (
            f"\n\033[1m!  Approval Required\033[0m  [id: {request.id[:12]}]\n"
            f"  Tool:   \033[1m{ctx.tool_name}\033[0m\n"
            f"  Score:  {colour}{score_str}{reset}\n"
            f"  Reason: {risk_score.reason}\n"
            f"  Args:\n{args_lines}\n"
            f"{timeout_line}"
            f"\n  [y]es  [n]o{always_hint}  > "
        )

        def _read() -> str:
            try:
                return input(banner).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "n"

        if auto_timeout is not None:
            loop = asyncio.get_running_loop()
            try:
                answer = await asyncio.wait_for(
                    loop.run_in_executor(None, _read), timeout=auto_timeout
                )
            except TimeoutError:
                print(f"\n  [auto-approved after {auto_timeout}s timeout]")
                answer = "y"
        else:
            loop = asyncio.get_running_loop()
            answer = await loop.run_in_executor(None, _read)

        approved = answer in ("y", "yes", "always", "a")
        self._approval_manager.resolve(request.id, approved=approved, resolver="cli-user")
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver=cli-user score={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            score,
            request.id,
        )
        if approved:
            if answer in ("always", "a") and always_allow and self._allowlist:
                self._allowlist.add(
                    ctx.tool_name, added_by="cli-user", note="Added via CLI 'always' prompt"
                )
            return HookResult.allow()
        return HookResult.reject(f"Tool '{ctx.tool_name}' denied by user")

    async def _send_approval_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> None:
        """Send an approval prompt to a non-CLI channel."""
        from workpilot.security.approval_format import get_approval_formatter

        formatter = get_approval_formatter(request.channel)
        content = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )

        if self._channel_manager:
            channel = self._channel_manager.get(request.channel)
            if channel:
                try:
                    if isinstance(content, dict):
                        import json as _json

                        await channel.send(
                            ctx.channel_id,
                            _json.dumps(content),
                            keep_context=True,
                            **ctx.metadata,
                        )
                    else:
                        await channel.send(ctx.channel_id, str(content), **ctx.metadata)
                except Exception as exc:
                    logger.error("Failed to send approval prompt: {}", exc)


# ── post_tool_use handlers ───────────────────────────────────────────────────


class LeakScanner:
    """Scan tool output for credential patterns and env-var values."""

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based detection (JWT, AWS, GitHub PAT, etc.)
        findings = detect_credentials(ctx.result)
        if findings:
            types = ", ".join(sorted({t for t, _ in findings}))
            logger.warning(
                "Credential patterns detected in '{}' output: {}",
                ctx.tool_name,
                types,
            )

        # Env-var value detection (existing)
        redacted = Sanitizer.redact_env_values(ctx.result)
        if redacted != ctx.result:
            logger.warning("Env var leak detected in '{}' output", ctx.tool_name)

        return HookResult.allow()


class Redactor:
    """Replace detected secrets in tool output.

    Env-var values are replaced with ``[REDACTED]``.
    Credential patterns are replaced with ``[REDACTED:{type}]``
    (e.g. ``[REDACTED:JWT]``, ``[REDACTED:AWS Access Key]``).
    """

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based redaction first, then env-var redaction
        cleaned = redact_credentials(ctx.result)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.result:
            ctx.result = cleaned
        return HookResult.allow(data=ctx)


class Auditor:
    """Log every tool call to the audit trail."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        if self._audit is not None:
            self._audit.log_tool(
                tool=ctx.tool_name,
                actor=ctx.agent_name,
                args=ctx.args,
                result=ctx.result[:200] if ctx.result else "",
                is_error=not ctx.success,
                session_id=ctx.session_id,
                duration_ms=ctx.duration_ms,
            )
        return HookResult.allow()


# ── on_message_sent handlers ────────────────────────────────────────────────


class OutboundLeakScanner:
    """Scan outbound responses for credential leaks."""

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        cleaned = redact_credentials(ctx.content)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.content:
            logger.warning("Leak detected in outbound message to {}", ctx.channel)
            ctx.content = cleaned
        return HookResult.allow(data=ctx)


# ── Registration helper ──────────────────────────────────────────────────────


def register_builtin_handlers(
    hook_manager: HookManager,
    *,
    estop: object | None = None,
    policy_engine: PolicyEngine | None = None,
    audit_logger: AuditLogger | None = None,
    scorer: RiskScorer | None = None,
    approval_manager: ApprovalManager | None = None,
    allowlist: AllowlistManager | None = None,
    bus: EventBus | None = None,
    channel_manager: ChannelManager | None = None,
    session_manager: Any = None,
    auto_approve_timeout: int = 180,
    security_profile: str = "standard",
    block_injections: bool = False,
) -> None:
    """Register all built-in handlers onto a HookManager.

    Args:
        hook_manager: HookManager instance.
        estop: EStop instance (optional).
        policy_engine: PolicyEngine instance (optional).
        audit_logger: AuditLogger instance (optional).
        scorer: RiskScorer (v2) for the ApprovalGate (optional).
        approval_manager: ApprovalManager for human-in-the-loop (optional).
        allowlist: AllowlistManager for per-user tool allowlist (optional).
        bus: EventBus for emitting approval events (optional).
        channel_manager: ChannelManager for sending approval prompts (optional).
        auto_approve_timeout: Seconds before Timeout-auto executes.
        block_injections: If True, reject messages with injection patterns.
    """
    mgr = hook_manager

    # on_message_received
    mgr.register("on_message_received", InjectionScanner(block=block_injections), priority=10)

    # pre_tool_use
    mgr.register("pre_tool_use", EStopGate(estop), priority=1)
    mgr.register("pre_tool_use", PolicyGate(policy_engine), priority=10)
    mgr.register(
        "pre_tool_use",
        ApprovalGate(
            scorer,
            approval_manager=approval_manager,
            allowlist=allowlist,
            bus=bus,
            channel_manager=channel_manager,
            session_manager=session_manager,
            auto_approve_timeout=auto_approve_timeout,
            security_profile=security_profile,
        ),
        priority=20,
    )

    # post_tool_use
    mgr.register("post_tool_use", LeakScanner(), priority=10)
    # Redactor disabled — redacting tool output breaks LLM tool chaining
    # (LLM can't use credentials returned by one tool in a subsequent call).
    # User-facing protection is handled by OutboundLeakScanner on_message_sent.
    # See: https://github.com/gim-home/WorkPilot/issues/184
    mgr.register("post_tool_use", Auditor(audit_logger), priority=30)

    # on_message_sent
    mgr.register("on_message_sent", OutboundLeakScanner(), priority=10)
