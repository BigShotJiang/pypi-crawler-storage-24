"""
Config loader — YAML with environment variable substitution,
profile support, and config inheritance via `extends`.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml

from workpilot.config.schema import AppConfig

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
_SEARCH_NAMES = ("workpilot.yaml", "workpilot.yml", "config.yaml", "config.yml")
_SCHEMA_URL = "https://workpilot.newfuture.cc/schema/workpilot-config.schema.json"
_SCHEMA_LINE = f"# yaml-language-server: $schema={_SCHEMA_URL}\n"


def _substitute_env(value: str, env: dict[str, str]) -> str:
    """Replace ${VAR} placeholders with environment values."""

    def _replace(m: re.Match[str]) -> str:
        return env.get(m.group(1), "")

    return _ENV_PATTERN.sub(_replace, value)


def _deep_substitute(obj: Any, env: dict[str, str]) -> Any:
    if isinstance(obj, str):
        return _substitute_env(obj, env)
    if isinstance(obj, dict):
        return {k: _deep_substitute(v, env) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_substitute(v, env) for v in obj]
    return obj


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge override into base."""
    result = {**base}
    for key, value in override.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_yaml(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    return yaml.safe_load(text) or {}


def save_yaml(path: Path, data: dict[str, Any], *, header: str = "") -> None:
    """Write a config dict to a YAML file with the JSON Schema reference line.

    The ``# yaml-language-server: $schema=…`` directive is always placed as
    the very first line so that IDEs (VS Code, JetBrains) pick it up for
    autocompletion and validation.
    """
    body = yaml.dump(data, default_flow_style=False, sort_keys=False)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_SCHEMA_LINE + header + body, encoding="utf-8")


def ensure_schema_line(path: Path) -> None:
    """Ensure exactly one schema directive exists as the very first line."""
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    if not text:
        path.write_text(_SCHEMA_LINE, encoding="utf-8")
        return
    lines = text.splitlines(keepends=True)
    # Remove all existing schema directives
    lines = [
        line
        for line in lines
        if not (line.lstrip().startswith("# yaml-language-server:") and "$schema=" in line)
    ]
    # Insert canonical directive at top
    lines.insert(0, _SCHEMA_LINE)
    path.write_text("".join(lines), encoding="utf-8")


def _load_builtin_workpilot_config() -> dict[str, Any]:
    """Load the bundled default config from package data."""
    from importlib.resources import files

    resource = files("workpilot.defaults").joinpath("workpilot.yaml")
    text = resource.read_text(encoding="utf-8")
    return yaml.safe_load(text) or {}


def _home_base_config() -> Path:
    return Path.home() / ".workpilot" / "workpilot.yaml"


def _home_local_override() -> Path:
    return Path.home() / ".workpilot" / "workpilot.local.yaml"


def _resolve_config_file(config_path: Path) -> Path | None:
    """Find the config file at the given path or in directory."""
    if config_path.is_file():
        return config_path
    if config_path.is_dir():
        for name in _SEARCH_NAMES:
            candidate = config_path / name
            if candidate.is_file():
                return candidate
    return None


def _load_dotenv(directory: Path, env: dict[str, str]) -> None:
    """Read a .env file into *env* (existing keys take priority).

    Values are loaded into the substitution dict only — ``os.environ`` is
    never modified.  A future version will support encrypted .env files.
    """
    dotenv = directory / ".env"
    if not dotenv.is_file():
        return
    for line in dotenv.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("\"'")
        env.setdefault(key, value)


def _resolve_local_override(config_file: Path) -> Path | None:
    """Derive the .local.yaml sibling for a config file and return it if it exists.

    workpilot.yaml  -> workpilot.local.yaml
    config.yml      -> config.local.yml
    """
    stem = config_file.stem  # e.g. "workpilot"
    suffix = config_file.suffix  # e.g. ".yaml"
    local_name = f"{stem}.local{suffix}"
    local_path = config_file.parent / local_name
    return local_path if local_path.is_file() else None


def load_config(
    config_path: str | Path | None = None,
    profile: str | None = None,
) -> AppConfig:
    """
    Load and validate WorkPilot configuration.

    Merge order (lowest → highest priority):
    1. Bundled `workpilot.yaml`
    2. `~/.workpilot/workpilot.yaml`
    3. `~/.workpilot/workpilot.local.yaml`

    When an explicit config path/file is provided and resolves successfully,
    preserve legacy behavior for that path plus its sibling `.local` override.
    """
    path = Path(config_path) if config_path else None
    resolved = _resolve_config_file(path) if path is not None else None

    if resolved is None:
        home_base = _home_base_config()
        home_local = _home_local_override()
        raw = _load_builtin_workpilot_config()

        if home_base.is_file():
            raw = _deep_merge(raw, _load_yaml(home_base))

        if home_local.is_file():
            raw = _deep_merge(raw, _load_yaml(home_local))

        config_dir = home_base.parent if home_base.is_file() else Path.home() / ".workpilot"
    else:
        raw = _load_yaml(resolved)
        config_dir = resolved.parent

    # Process extends
    extends = raw.pop("extends", None)
    if isinstance(extends, list):
        for parent_path in extends:
            parent_file = _resolve_config_file(config_dir / parent_path)
            if parent_file:
                parent_raw = _load_yaml(parent_file)
                raw = _deep_merge(parent_raw, raw)

    # Merge local override (legacy explicit-path behavior only)
    if resolved is not None:
        local_file = _resolve_local_override(resolved)
        if local_file is not None:
            local_raw = _load_yaml(local_file)
            raw = _deep_merge(raw, local_raw)

    # Apply profile
    profiles = raw.pop("profiles", None)
    if profile and isinstance(profiles, dict) and profile in profiles:
        raw = _deep_merge(raw, profiles[profile])

    # Environment variable substitution
    # Sources (lowest → highest priority): .env file, os.environ, config env section.
    # Nothing is written to os.environ — the env dict is local only.
    # TODO: support encrypted .env files (AES / age / SOPS)
    env: dict[str, str] = {}
    _load_dotenv(config_dir, env)
    env.update(os.environ)
    # Also extract env defaults from config
    config_env = raw.get("env", {})
    if isinstance(config_env, dict):
        for key, val in config_env.items():
            if isinstance(val, str):
                env.setdefault(key, val)
            elif isinstance(val, dict) and "default" in val:
                env.setdefault(key, val["default"])
    raw = _deep_substitute(raw, env)

    # Remove env section (not part of AppConfig)
    raw.pop("env", None)

    return AppConfig.model_validate(raw)
