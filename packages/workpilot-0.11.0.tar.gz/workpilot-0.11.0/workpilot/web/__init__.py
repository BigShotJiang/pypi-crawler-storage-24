"""Web — FastAPI-based HTTP web server for WorkPilot."""

from workpilot.web.estop_middleware import EStopMiddleware
from workpilot.web.server import WebServer

__all__ = ["EStopMiddleware", "WebServer"]
