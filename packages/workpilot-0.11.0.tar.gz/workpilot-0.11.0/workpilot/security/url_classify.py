"""
Local URL classification database — domain and TLD-based risk scoring.

Domain and TLD data loaded from the ``workpilot.security.data`` package via
``importlib.resources`` (works in wheels and editable installs).

To update classifications, edit ``url_classify.json`` directly — no code changes needed.

Future: augment with Microsoft Graph / SmartScreen / Defender TI APIs.
"""

from __future__ import annotations

import json
import re
from urllib.parse import urlparse

# ── Load domain DB from JSON ─────────────────────────────────────────────────

_DOMAIN_DB: dict[str, tuple[int, str]] = {}


def _load_db() -> None:
    from importlib.resources import files as _pkg_files

    try:
        raw = (
            _pkg_files("workpilot.security.data")
            .joinpath("url_classify.json")
            .read_text(encoding="utf-8")
        )
        data = json.loads(raw)
    except Exception as exc:
        from loguru import logger

        logger.warning("Failed to load url_classify.json: {}", exc)
        return
    for category, info in data.items():
        if category.startswith("_"):
            continue
        if not isinstance(info, dict):
            continue
        score = info.get("_score", 2)
        for domain in info.get("domains", []):
            _DOMAIN_DB[domain.lower()] = (score, category)


_load_db()

# ── Sensitive URL parameter names ────────────────────────────────────────────

_SENSITIVE_URL_PARAMS = re.compile(
    r"[?&](token|api_key|apikey|key|secret|password|passwd|pwd"
    r"|access_token|auth|session|sessionid|sid|jwt|bearer)=",
    re.IGNORECASE,
)

# ── Credential patterns in free text ─────────────────────────────────────────

_CREDENTIAL_LEAK_RE = re.compile(
    r"(ghp_[A-Za-z0-9]{36}"  # GitHub PAT
    r"|sk-[A-Za-z0-9]{20,}"  # OpenAI key
    r"|AKIA[A-Z0-9]{16}"  # AWS access key
    r"|eyJ[A-Za-z0-9_-]{20,}"  # JWT
    r"|xox[bprs]-[A-Za-z0-9-]+"  # Slack token
    r"|password\s*[:=]\s*\S+"  # password=xxx
    r"|secret\s*[:=]\s*\S+)",  # secret=xxx
    re.IGNORECASE,
)

# ── Auth-related HTTP header keys ────────────────────────────────────────────

AUTH_HEADER_KEYS = frozenset(
    {
        "authorization",
        "x-api-key",
        "x-auth-token",
        "cookie",
        "x-csrf-token",
        "proxy-authorization",
    }
)


# ── Public API ───────────────────────────────────────────────────────────────


def classify_url(url: str) -> tuple[int, str]:
    """Classify URL risk → (score, reason).

    Returns (-1, reason) when the domain/TLD is high-risk but score
    is uncertain → caller should delegate to LLM (RiskPrompt).

    Priority:
    1. Embedded credentials in URL → 6 (deterministic)
    2. Sensitive query parameters → 6 (deterministic)
    3. Domain/TLD match → 1~9 deterministic, -2 (shortener) → LLM
    4. Unknown domain → LLM with scoring factors and context
    """
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()
    scheme = (parsed.scheme or "").lower()
    try:
        port = parsed.port
    except ValueError:
        port = -1  # invalid port — treated as non-standard

    # 1-2. Sensitive info in URL
    if parsed.username or parsed.password:
        return 6, f"URL contains embedded credentials: {hostname}"
    if _SENSITIVE_URL_PARAMS.search(url):
        return 6, f"URL contains sensitive query params: {hostname}"

    # 3. Scheme/port risk floor
    scheme_score = 0
    scheme_note = ""
    if port not in {80, 443, None}:
        scheme_score = 4
        scheme_note = f", non-standard port {port}"
    elif scheme == "http":
        scheme_score = 3
        scheme_note = ", unencrypted HTTP"

    # 4. Domain/TLD lookup (walks up: sub.example.com → example.com → com)
    domain_result = _lookup_domain(hostname)
    if domain_result is not None:
        score, category = domain_result
        if score == -2:
            # URL shortener — destination unknown, delegate to LLM
            # TODO: implement async URL expansion in RiskScorer
            return -1, (
                f"URL shortener ({hostname}) — destination hidden.\n"
                f"Scoring factors:\n"
                f"  5: Known MS shortener (aka.ms) with plausible context\n"
                f"  6: Third-party shortener (bit.ly, t.co) with plausible user intent\n"
                f"  7: Shortener with no context or suspicious usage pattern\n"
                f"  8: Shortener used to hide potentially malicious destination"
            )
        # All other scores (1~9) are deterministic
        final = max(score, scheme_score)
        reason = (
            f"{category}: {hostname}{scheme_note}" if scheme_note else f"{category}: {hostname}"
        )
        return final, reason

    # 5. Unknown domain — not in database, delegate to LLM with context
    scheme_hint = (
        scheme_note if scheme_note else (", HTTPS" if scheme == "https" else ", non-HTTPS")
    )
    return -1, (
        f"Unknown site: {hostname}{scheme_hint}.\n"
        f"This domain is not in the classification database.\n"
        f"Scoring factors:\n"
        f"  4: Recognizable company/project site, HTTPS, standard port\n"
        f"  5: Lesser-known site with some visible reputation\n"
        f"  6: Unknown site, or HTTP without TLS, or non-standard port\n"
        f"  7: Suspicious domain pattern, recently registered, or free hosting\n"
        f"  8: Domain resembles typosquatting, or known abuse TLD (.tk, .ml)"
    )


def has_credential_leak(text: str) -> bool:
    """Check if text contains credential-like patterns."""
    return bool(_CREDENTIAL_LEAK_RE.search(text))


def has_sensitive_url_params(url: str) -> bool:
    """Check if URL contains sensitive query parameters."""
    return bool(_SENSITIVE_URL_PARAMS.search(url))


# ── Internal helpers ─────────────────────────────────────────────────────────


def _lookup_domain(hostname: str) -> tuple[int, str] | None:
    """Walk up the domain hierarchy to find a match.

    ``api.github.com`` → ``github.com`` → ``com``.
    TLDs are just the shortest domain entries (e.g. ``com``, ``tk``, ``xxx``).
    """
    if hostname in _DOMAIN_DB:
        return _DOMAIN_DB[hostname]
    parts = hostname.split(".")
    for i in range(1, len(parts)):
        parent = ".".join(parts[i:])
        if parent in _DOMAIN_DB:
            return _DOMAIN_DB[parent]
    return None
