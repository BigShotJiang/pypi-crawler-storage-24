"""
Channel-specific approval prompt formatters.

Each formatter renders an approval request for a specific channel type:
- CLI:   rich text prompt
- Cloud: structured JSON for web chat clients
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from workpilot.config.schema import ChannelType


class ApprovalFormatter(ABC):
    """Abstract base for channel-specific approval formatters."""

    @abstractmethod
    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str | dict[str, Any]:
        """Format an approval request for display.

        Parameters
        ----------
        request:
            The ``ApprovalRequest`` object.
        classify_result:
            The ``RiskScore`` from the Risk Scorer (has ``.score`` and ``.reason``).
        auto_timeout:
            Seconds until auto-approve (Timeout-auto action). ``None`` = not auto-approve.
        reject_timeout:
            Seconds until auto-reject (Human action). ``None`` = wait indefinitely.

        Returns
        -------
        str | dict
            Formatted content: plain text for CLI, dict for structured channels.
        """


class CLIApprovalFormatter(ApprovalFormatter):
    """Rich text prompt for CLI."""

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str:
        args_summary = ", ".join(f"{k}={v!r}" for k, v in list(request.args.items())[:5])
        if auto_timeout is not None:
            timeout_info = f"\n  Auto-approving in {auto_timeout}s if no response."
        elif reject_timeout is not None:
            timeout_info = f"\n  Auto-rejecting in {reject_timeout}s if no response."
        else:
            timeout_info = "\n  Waiting for approval (no timeout)."
        return (
            f"\n[Approval Required] Tool: {request.tool_name}({args_summary})\n"
            f"  Score: {classify_result.score if classify_result.score is not None else '?'} / 10"
            f" | Reason: {classify_result.reason}"
            f"{timeout_info}\n"
            f"  Request ID: {request.id}\n"
            f"  Reply: yes/no/always  "
            f"(or /approve {request.id} | /deny {request.id} | /always {request.id})"
        )


class CloudApprovalFormatter(ApprovalFormatter):
    """Structured JSON for Cloud/Web Chat clients.

    The rendered payload is sent as a WebSocket frame and causes the
    web chat UI to display an inline approve/deny card.
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> dict[str, Any]:
        args_summary = {k: str(v)[:200] for k, v in list(request.args.items())[:10]}
        return {
            "type": "approval_request",
            "request_id": request.id,
            "tool_name": request.tool_name,
            "args": args_summary,
            "score": classify_result.score,
            "reason": classify_result.reason,
            "agent_name": request.agent_name,
            "auto_timeout": auto_timeout,
            "reject_timeout": reject_timeout,
        }


def get_approval_formatter(channel_name: ChannelType) -> ApprovalFormatter:
    """Factory — return the appropriate formatter for a channel."""
    if channel_name == ChannelType.CLI:
        return CLIApprovalFormatter()
    return CloudApprovalFormatter()
