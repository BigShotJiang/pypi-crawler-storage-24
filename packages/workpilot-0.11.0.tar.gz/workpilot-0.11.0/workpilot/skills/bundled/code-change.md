---
name: code-change
description: Structured workflow for significant code changes
metadata:
  activation:
    keywords: [rollback plan]
    patterns:
      - "(?i)\\b(migration|rollback|upgrade)\\s+(plan|strategy)\\b"
      - "(?i)\\b(major|large|big)\\s+(refactor|rewrite|change)\\b"
      - "(?i)\\bbreaking\\s+change\\b"
---
## Code Change Workflow

When making significant code changes, follow this structure:

1. Plan: tasks, impact, risks
2. Changes: file list and diffs
3. Tests: strategy and key cases
4. PR: title and description
5. Rollback: how to undo

Principles:
- Minimal, purposeful changes — do only what's requested
- Test changes before committing
- Never expose credentials in code or commits
