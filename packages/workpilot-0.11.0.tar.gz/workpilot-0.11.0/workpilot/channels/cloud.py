"""
Cloud channel — outbound WebSocket relay to WorkPilot Cloud Gateway.

Connects to wss://<cloud-gateway>/connect using an Entra ID access token.
Supports two login methods:

  browser  — opens the default browser for interactive PKCE auth code flow
             (http://localhost callback, no redirect URI limitations).
  wam      — WAM broker (native OS auth dialog, no browser); falls back to
             browser PKCE if the app registration doesn't support broker.
             Requires msal[broker] on Windows.
  device   — device code flow (visit a URL + enter a code); works in
             headless / SSH / corporate environments that block browser launch.
             Only used when explicitly configured (many tenants disable this).
  auto     — (default) same as browser. WAM not attempted unless explicitly
             configured via login_method=wam.

Inbound  (server → client): connected, buffered_start/end, message, ping, error
Outbound (client → server): response, chunk, pong
"""

from __future__ import annotations

import asyncio
import html as _html
import json
import re
import socket
import webbrowser
from pathlib import Path
from typing import Any, Literal

import msal
import websockets
import websockets.exceptions
from loguru import logger

from workpilot.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.config.schema import ChannelType
from workpilot.utils.helpers import get_auth_dir, webchat_url_from_connect
from workpilot.utils.html import html_to_markdown


class CloudChannel(BaseChannel):
    """Outbound WebSocket relay to WorkPilot Cloud Gateway."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        url: str,
        tenant_id: str,
        client_id: str,
        scope: str,
        login_method: Literal["auto", "browser", "wam", "device"] = "auto",
        login_port: int = 49215,
        allow_from: list[str] | None = None,
        auto_reconnect: bool = True,
        reconnect_max: int = 60,
        bypass_token: str | None = None,
        open_browser_on_connect: bool = False,
    ) -> None:
        super().__init__(bus, allow_from)
        self._url = url
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._scope = scope
        self._login_method = login_method
        self._login_port = login_port
        self._auto_reconnect = auto_reconnect
        self._reconnect_max = reconnect_max

        self._bypass_token = bypass_token
        self._open_browser_on_connect = open_browser_on_connect
        self._token: str | None = None
        self._running = False
        self._ws_connected = False  # True only while WebSocket handshake is live
        self._send_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=500)
        self._connect_task: asyncio.Task | None = None
        self._browser_opened = False  # open browser only on first successful connect
        self._runtime: Any = None  # set by Runtime after construction
        self._ping_count = 0  # monotonic counter for ping/pong log correlation

        # MSAL PublicClientApplication — persists token cache across reconnects.
        # Skipped in bypass mode (no MSAL calls needed).
        self._cache_path: Path | None = None
        self._broker_enabled = False
        if bypass_token:
            logger.warning("Cloud channel using bypass token — disable for production!")
            self._msal_app = None
        else:
            # Persist MSAL token cache to ~/.workpilot/auth/ so login survives process restarts.
            # auth/ is ACL-protected on Windows, chmod 0o700 on POSIX.
            self._cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.json"
            self._token_cache = msal.SerializableTokenCache()
            if self._cache_path.exists():
                try:
                    self._token_cache.deserialize(self._cache_path.read_text(encoding="utf-8"))
                    logger.debug("MSAL token cache loaded from {}", self._cache_path)
                except Exception as exc:
                    logger.warning(
                        "Corrupted MSAL token cache at {} ({}); starting fresh.",
                        self._cache_path,
                        exc,
                    )
                    self._cache_path.unlink(missing_ok=True)
            broker_kwargs: dict[str, Any] = {}
            self._broker_enabled = False
            if login_method == "wam":
                try:
                    import pymsalruntime  # noqa: F401

                    broker_kwargs["enable_broker_on_windows"] = True
                    self._broker_enabled = True
                    logger.debug("WAM broker enabled")
                except ImportError:
                    logger.warning("login_method=wam but msal[broker] not installed; using browser")
                    self._login_method = "browser"

            self._msal_app = msal.PublicClientApplication(
                client_id=client_id,
                authority=f"https://login.microsoftonline.com/{tenant_id}",
                token_cache=self._token_cache,
                **broker_kwargs,
            )

    def set_runtime(self, runtime: Any) -> None:
        """Set the Runtime reference for admin relay queries."""
        self._runtime = runtime

    @property
    def name(self) -> str:
        return ChannelType.CLOUD

    @property
    def is_connected(self) -> bool:
        """True only while the WebSocket handshake is live (not during reconnect backoff)."""
        return self._ws_connected

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def has_cached_credentials(self) -> bool:
        """Return True if a token can be acquired without user interaction.

        Used by the runtime to decide whether to auto-connect on startup.
        bypass_token always counts as cached; MSAL checks for stored accounts.
        """
        if self._bypass_token:
            return True
        return bool(self._msal_app and self._msal_app.get_accounts())

    async def start(self) -> None:
        if self._running:
            return  # already started — prevent duplicate connection tasks
        self._running = True

        # Acquire initial token (device code flow if not cached)
        self._token = await asyncio.get_running_loop().run_in_executor(
            None, self._acquire_token_sync
        )

        # Subscribe to outbound bus messages
        self._bus.on_outbound(self._handle_outbound)

        # Launch connection loop as background task
        self._connect_task = asyncio.create_task(self._connect_loop(), name="cloud-channel-loop")
        logger.info("Cloud channel started -> {}", self._url)

    async def stop(self) -> None:
        self._running = False
        if self._connect_task and not self._connect_task.done():
            self._connect_task.cancel()
        # Drain the send queue so callers aren't stuck
        while not self._send_queue.empty():
            try:
                self._send_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        logger.info("Cloud channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Enqueue a response frame (called by ChannelManager).

        Approval cards are sent as ``notification`` frames so the gateway does
        NOT delete the reply context — the context must stay alive until the
        tool result is delivered after the user approves/denies.
        """
        # Approval cards use "notification" so the gateway keeps deleteContext=false,
        # preserving the reply context until the final tool result is delivered.
        # Callers pass keep_context=True (via kwargs) to opt in.
        frame_type = "notification" if kwargs.get("keep_context") else "response"

        # Non-routable channel_id (e.g. "scheduler:xxx") → send as a "push"
        # frame.  Push frames don't target a specific conversation; the gateway
        # broadcasts them to the connected user's active clients.
        _INTERNAL_PREFIXES = ("scheduler:", "agent-", "cron:", "copilot-", "claude-")
        is_non_routable = (
            any(channel_id.startswith(p) for p in _INTERNAL_PREFIXES)
            or channel_id == self.name  # bare "cloud" from notify tool without conversation context
        )

        if is_non_routable:
            data: dict[str, Any] = {
                "type": "push",
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            title = kwargs.get("title")
            if title:
                data["title"] = title
        else:
            data = {
                "type": frame_type,
                "channel_id": channel_id,
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            thread_id = kwargs.get("thread_id")
            if thread_id:
                data["thread_id"] = thread_id

        frame = json.dumps(data, ensure_ascii=False)
        await self._send_queue.put(frame)

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:
        """Send a typing indicator via WebSocket."""
        frame = json.dumps({"type": "typing", "channel_id": channel_id}, ensure_ascii=False)
        await self._send_queue.put(frame)

    # ── Outbound bus handler ─────────────────────────────────────────────────

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Route streaming chunks from the agent → WebSocket send queue.

        OutboundMessage (non-streaming responses) are handled by ChannelManager
        which calls CloudChannel.send() — registering both handlers would send
        each response twice and cause reply_context_expired errors on the second.
        Only StreamingChunk is handled here because ChannelManager.send() has no
        streaming-chunk path.
        """
        if msg.channel != self.name:
            return

        if not isinstance(msg, StreamingChunk):
            return

        frame = json.dumps(
            {
                "type": "chunk",
                "channel_id": msg.channel_id,
                "content": msg.content,
                "chunk_type": msg.chunk_type,
                "done": msg.done,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(frame)

    # ── Connection loop ──────────────────────────────────────────────────────

    async def _connect_loop(self) -> None:
        """Main loop: connect → run → reconnect with exponential backoff."""
        backoff = 1
        while self._running:
            try:
                await self._run_connection()
                backoff = 1  # reset on clean close
            except asyncio.CancelledError:
                break
            except Exception as exc:
                if not self._running:
                    break

                # websockets follows HTTP redirects and raises InvalidURI when the
                # Location header has an https:// scheme (not wss://).  This happens
                # when the server redirects the WebSocket upgrade to an auth page
                # (e.g. /Account/AccessDenied) instead of returning 401/403.
                # Force interactive re-authentication in this case rather than
                # silently refreshing a token that the server is already rejecting.
                is_auth_redirect = isinstance(exc, websockets.exceptions.InvalidURI) and (
                    "AccessDenied" in str(exc) or "login" in str(exc).lower()
                )
                # websockets ≤13: RejectHandshake with exc.status_code
                # websockets ≥14: InvalidStatus with exc.response.status_code
                _status = getattr(exc, "status_code", None) or getattr(
                    getattr(exc, "response", None), "status_code", None
                )
                _rejection_types = (websockets.exceptions.InvalidStatus,)
                if hasattr(websockets.exceptions, "RejectHandshake"):
                    _rejection_types = (*_rejection_types, websockets.exceptions.RejectHandshake)  # type: ignore[assignment]
                is_auth_rejection = isinstance(exc, _rejection_types) and _status in (401, 403)

                if is_auth_redirect or is_auth_rejection:
                    logger.warning(
                        "Cloud gateway rejected connection (auth failure: {}). Re-authenticating…",
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)
                    # Route through _acquire_token_sync so bypass-token mode
                    # (where _msal_app is None) returns the bypass token directly
                    # instead of crashing inside _interactive_login.
                    try:
                        self._token = await asyncio.get_running_loop().run_in_executor(
                            None, self._acquire_token_sync
                        )
                    except Exception as auth_err:
                        logger.error("Re-authentication failed: {}", auth_err)
                else:
                    logger.warning(
                        "Cloud gateway connection lost: {}. Reconnecting in {}s…", exc, backoff
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)

                    # Refresh token silently before reconnecting
                    try:
                        self._token = await asyncio.get_running_loop().run_in_executor(
                            None, self._refresh_token_sync
                        )
                    except Exception as auth_err:
                        logger.error("Token refresh failed: {}", auth_err)

    async def _run_connection(self) -> None:
        """Single WebSocket connection lifecycle."""
        headers = {"Authorization": f"Bearer {self._token}"}

        async with websockets.connect(
            self._url,
            additional_headers=headers,
            ping_interval=None,  # server manages heartbeat via ping/pong frames
            open_timeout=15,
            close_timeout=5,
        ) as ws:
            self._ws_connected = True
            logger.success("Connected to Cloud Gateway")
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})

            recv_task = asyncio.create_task(self._recv_loop(ws))
            send_task = asyncio.create_task(self._send_loop(ws))

            try:
                done, pending = await asyncio.wait(
                    [recv_task, send_task],
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
                # Re-raise any exception from the completed task
                for task in done:
                    if not task.cancelled():
                        task.result()
            finally:
                self._ws_connected = False
                recv_task.cancel()
                send_task.cancel()

    async def _recv_loop(self, ws) -> None:
        """Process incoming frames from the gateway."""
        async for raw in ws:
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("Malformed frame from gateway: {!r:.100}", raw)
                continue

            await self._dispatch(frame)

    async def _send_loop(self, ws) -> None:
        """Drain send queue → write frames to WebSocket."""
        while True:
            frame = await self._send_queue.get()
            try:
                await ws.send(frame)
            except Exception:
                # Put it back so it's not lost on reconnect
                await self._send_queue.put(frame)
                raise

    # ── Frame dispatch ───────────────────────────────────────────────────────

    async def _dispatch(self, frame: dict[str, Any]) -> None:
        ftype = frame.get("type")

        if ftype == "connected":
            count = frame.get("buffered_count", 0)
            logger.info("Gateway handshake complete. Buffered messages: {}", count)
            if self._open_browser_on_connect and not self._browser_opened:
                self._browser_opened = True
                web_url = webchat_url_from_connect(self._url)
                loop = asyncio.get_running_loop()
                loop.run_in_executor(None, webbrowser.open, web_url)
                logger.info("Opening web chat: {}", web_url)

        elif ftype == "message":
            await self._on_message(frame)

        elif ftype == "ping":
            self._ping_count += 1
            await self._send_queue.put(json.dumps({"type": "pong"}, ensure_ascii=False))
            logger.debug(
                "Ping #{} -> pong  [url={} queue_depth={}]",
                self._ping_count,
                self._url,
                self._send_queue.qsize(),
            )

        elif ftype == "buffered_start":
            logger.info("Replaying {} buffered message(s)…", frame.get("count", "?"))

        elif ftype == "buffered_end":
            logger.info("Buffered message replay complete")

        elif ftype == "admin_request":
            await self._on_admin_request(frame)

        elif ftype == "approval_response":
            # Structured approval response from web chat client
            await self._on_approval_response(frame)

        elif ftype == "error":
            code = frame.get("code", "unknown")
            msg = frame.get("message", "")
            # reply_context_expired is expected when a response arrives after the
            # Teams reply window closes (e.g. long-running tool). Log at DEBUG.
            if code == "reply_context_expired":
                logger.debug("Gateway error [{}]: {}", code, msg)
            else:
                logger.warning("Gateway error [{}]: {}", code, msg)
            if code == "auth_expired":
                # Force token refresh on next reconnect
                self._token = None

        else:
            logger.debug("Unhandled frame type: {}", ftype)

    async def _on_message(self, frame: dict[str, Any]) -> None:
        """Publish an inbound message frame to the bus."""
        content = frame.get("content", "")
        content_format = frame.get("content_format", "text").lower()

        # Strip <at>…</at> @mention XML BEFORE HTML→Markdown conversion,
        # otherwise html_to_markdown strips the tags but leaves the text.
        content = re.sub(r"<at>[^<]*</at>", "", content).strip()

        # Convert HTML rich text to Markdown
        if content_format == "html":
            content = html_to_markdown(content)
            content_format = "markdown"

        channel_id = frame.get("channel_id", "")
        sender_id = frame.get("sender_id", "")
        sender_name = frame.get("sender_name", sender_id)
        thread_id = frame.get("thread_id")
        session_key = frame.get("session_key")
        metadata = {**frame.get("metadata", {})}
        metadata["content_format"] = content_format

        # Allow-list check must happen before any approval fast-path.
        if not self.is_allowed(sender_id):
            logger.warning("Message blocked from {} (not in allow_from)", sender_id)
            return

        # Metadata approval fast-path: Teams card button or slash command sends
        # approval_action in metadata — resolve directly, bypassing the blocked queue.
        approval_action = metadata.get("approval_action")
        approval_request_id = metadata.get("approval_request_id")
        if approval_action and approval_request_id:
            await self._on_approval_response(
                {
                    "action": approval_action,
                    "request_id": approval_request_id,
                    "sender_id": sender_id,
                }
            )
            logger.debug(
                "Cloud approval action={} request_id={}", approval_action, approval_request_id
            )
            return

        if not content:
            logger.debug("Cloud message with empty content from {} — ignored", sender_id)
            return

        # Approval keyword / slash-command fast-path — bypass the blocked agent queue.
        cl = content.lower()  # content already stripped via re.sub earlier
        action: str | None = None
        req_id = ""

        parts = content.split(maxsplit=1)
        # /approve <id> · /deny <id> · /always <id>  (with explicit request_id)
        if cl.startswith("/approve ") and len(parts) == 2:
            action, req_id = "approve", parts[1]
        elif cl.startswith("/deny ") and len(parts) == 2:
            action, req_id = "deny", parts[1]
        elif cl.startswith("/always ") and len(parts) == 2:
            action, req_id = "always", parts[1]
        # bare keyword (no id — runtime resolves any single pending approval)
        elif cl in {"yes", "y", "approve", "/approve"}:
            action = "approve"
        elif cl in {"no", "n", "deny", "/deny"}:
            action = "deny"
        elif cl in {"always", "a", "/always"}:
            action = "always"

        if action:
            await self._on_approval_response(
                {"action": action, "request_id": req_id, "sender_id": sender_id}
            )
            logger.debug("Cloud approval action={} request_id={}", action, req_id or "(any)")
            return

        msg = InboundMessage(
            channel=self.name,
            channel_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=content_format,
            thread_id=thread_id,
            session_key=session_key,
            timestamp=frame.get("timestamp"),
            metadata=metadata,
        )
        await self._bus.publish_inbound(msg)
        logger.debug(
            "Cloud message channel_id={} sender={} len={}", channel_id, sender_id, len(content)
        )

    async def _on_approval_response(self, frame: dict[str, Any]) -> None:
        """Resolve an approval request directly (bypasses inbound queue).

        Approval responses must NOT go through the inbound message queue
        because the agent loop is blocked in the pre_tool_use hook waiting
        for resolution — routing through the queue would deadlock.
        """
        action = frame.get("action", "")
        request_id = frame.get("request_id", "")
        if not action:
            logger.warning("Malformed approval_response frame: {}", frame)
            return
        # Empty request_id is valid — runtime resolves any single pending approval

        sender_id = frame.get("sender_id", "unknown")

        # Resolve directly via the approval manager on the bus event
        self._bus.events.emit(
            EventType.APPROVAL_RESOLVED,
            {
                "request_id": request_id,
                "action": action,
                "resolver": sender_id,
            },
        )
        logger.debug("Approval response: action={} request_id={}", action, request_id)

    async def _on_admin_request(self, frame: dict[str, Any]) -> None:
        """Handle an admin data query from the Cloud Gateway.

        Routes the request to the local WebServer's API handlers in-process
        and sends back an admin_response frame with the result.
        """
        request_id = frame.get("request_id", "")
        endpoint = frame.get("endpoint", "")
        if not request_id or not endpoint:
            logger.warning("Malformed admin_request frame: {}", frame)
            return

        status = 200
        body: Any = {"error": "not_found", "message": f"Unknown endpoint: {endpoint}"}

        try:
            result = await self._handle_admin_endpoint(endpoint, frame)
            if result is not None:
                status = result.get("status", 200)
                body = result.get("body", body)
            else:
                status = 404
        except Exception as exc:
            logger.error("Admin request error endpoint={}: {}", endpoint, exc)
            status = 500
            body = {"error": "internal_error", "message": str(exc)}

        response_frame = json.dumps(
            {
                "type": "admin_response",
                "request_id": request_id,
                "status": status,
                "body": json.dumps(body, ensure_ascii=False) if not isinstance(body, str) else body,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(response_frame)

    def _build_channels(self, rt: Any) -> list[dict[str, Any]]:
        """Build the channel list for /api/status — mirrors server.py logic."""
        from workpilot.utils.helpers import webchat_url_from_connect

        channels: list[dict[str, Any]] = []
        for name in rt.channel_manager._channels:
            if name == ChannelType.CLOUD:
                continue
            if name in (ChannelType.WEB, "gateway"):
                channels.append({"name": name, "url": "/chat", "connected": True})
            else:
                channels.append({"name": name, "url": None, "connected": True})

        cloud_cfg = rt.config.channels.cloud
        if cloud_cfg.enabled and cloud_cfg.url:
            try:
                wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
            except ValueError:
                wc_url = None
            channels.append(
                {"name": "Web Chat (Cloud)", "url": wc_url, "connected": self._ws_connected}
            )
            teams_url = cloud_cfg.teams_bot_url or None
            channels.append(
                {
                    "name": "Teams (Cloud)",
                    "url": teams_url,
                    "connected": self._ws_connected and bool(teams_url),
                }
            )
        return channels

    async def _handle_admin_endpoint(
        self, endpoint: str, frame: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Dispatch an admin request to the Runtime via shared handlers.

        Returns {"status": int, "body": dict|str} or None if not found.
        """
        rt = self._runtime
        if rt is None:
            return {"status": 503, "body": {"error": "runtime_unavailable"}}

        from workpilot.web.api_handlers import (
            handle_approval_resolve,
            handle_approvals,
            handle_audit,
            handle_config,
            handle_cost,
            handle_estop,
            handle_health,
            handle_memory,
            handle_models,
            handle_reset,
            handle_session_detail,
            handle_sessions,
            handle_skills,
            handle_status,
            handle_tools,
        )

        method = frame.get("method", "GET")

        # ── GET ───────────────────────────────────────────────────────
        if method == "GET":
            routes: dict[str, Any] = {
                "/api/status": lambda: handle_status(rt, channels=self._build_channels(rt)),
                "/api/health": lambda: handle_health(rt),
                "/api/sessions": lambda: handle_sessions(rt),
                "/api/tools": lambda: handle_tools(rt),
                "/api/skills": lambda: handle_skills(rt),
                "/api/memory": lambda: handle_memory(rt),
                "/api/audit": lambda: handle_audit(rt),
                "/api/cost": lambda: handle_cost(rt),
                "/api/models": lambda: handle_models(rt),
                "/api/approvals": lambda: handle_approvals(rt),
            }
            if endpoint in routes:
                return {"status": 200, "body": routes[endpoint]()}

            if endpoint.startswith("/api/sessions/"):
                from urllib.parse import unquote

                session_id = unquote(endpoint[len("/api/sessions/") :])
                detail = handle_session_detail(rt, session_id)
                return (
                    {"status": 200, "body": detail}
                    if detail
                    else {"status": 404, "body": {"error": "not_found"}}
                )

            if endpoint == "/api/config":
                result = handle_config(rt)
                return (
                    {"status": 200, "body": result}
                    if result
                    else {"status": 500, "body": {"error": "Failed to serialize config."}}
                )

        # ── POST ──────────────────────────────────────────────────────
        if method == "POST":
            body_str = frame.get("body")
            body_data: dict[str, Any] = {}
            if body_str:
                try:
                    body_data = json.loads(body_str)
                except (json.JSONDecodeError, TypeError):
                    pass

            if endpoint == "/api/estop":
                return {
                    "status": 200,
                    "body": handle_estop(rt, body_data.get("reason", "admin dashboard")),
                }
            if endpoint == "/api/reset":
                return {"status": 200, "body": handle_reset(rt, body_data.get("actor", "admin"))}
            if endpoint.startswith("/api/approvals/") and endpoint.endswith("/resolve"):
                req_id = endpoint.split("/")[3] if len(endpoint.split("/")) >= 5 else ""
                code, body = handle_approval_resolve(
                    rt, req_id, body_data.get("approved", False), body_data.get("resolver", "admin")
                )
                return {"status": code, "body": body}

        return None

    # ── Auth ─────────────────────────────────────────────────────────────────

    def _acquire_token_sync(self) -> str:
        """Acquire token — silent if cached, then interactive if not. Runs in executor."""
        # Dev bypass: skip MSAL entirely and use the hardcoded token.
        if self._bypass_token:
            logger.debug("Using bypass token (local dev mode)")
            return self._bypass_token

        assert self._msal_app is not None, "_msal_app must be set when bypass_token is not used"

        # 1. Try silent (cached) first — always, regardless of login_method
        accounts = self._msal_app.get_accounts()
        if accounts:
            result = self._msal_app.acquire_token_silent([self._scope], account=accounts[0])
            if result and "access_token" in result:
                logger.debug("Token acquired silently (cached)")
                self._persist_cache()
                return str(result["access_token"])

        # 2. Interactive login — method chosen by caller
        token = self._interactive_login()
        self._persist_cache()
        return token

    # Alias — reconnect path uses the same logic as initial acquisition.
    _refresh_token_sync = _acquire_token_sync

    def _interactive_login(self) -> str:
        """Dispatch to the configured login method.

        "auto" / "browser" — browser PKCE only (default, always works).
        "wam"              — WAM broker → browser PKCE fallback (opt-in).
        "device"           — device code only (opt-in, many tenants disable it).
        """
        if self._login_method == "device":
            return self._device_code_flow()
        if self._login_method == "wam":
            return self._browser_flow(try_wam=self._broker_enabled)
        # "auto" and "browser": browser PKCE only
        return self._browser_flow(try_wam=False)

    def _resolve_login_port(self) -> int:
        """Return a usable localhost port for the PKCE callback.

        Tries self._login_port first (the preferred/gateway port).
        If that port is already bound, asks the OS for any free port.
        """
        preferred = self._login_port
        for port in (preferred, 52813, 58729, 0):  # fixed high ports for AAD, then OS-assigned
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("localhost", port))
                    chosen = s.getsockname()[1]
                    if port != preferred:
                        logger.debug(
                            "Login port {} busy — using {} instead",
                            preferred,
                            chosen,
                        )
                    return int(chosen)
                except OSError:
                    continue
        # Should never reach here — port 0 always succeeds
        return preferred  # pragma: no cover

    def _browser_flow(self, *, try_wam: bool = False) -> str:
        """Interactive browser-based auth (authorization code + PKCE).

        MSAL opens the default browser and starts a local HTTP server on
        login_port (default 49215 — high port to avoid conflicts) for the
        callback. The registered redirect URI is http://localhost which
        AAD matches against any http://localhost:{PORT} loopback address.
        """
        port = self._resolve_login_port()
        print()
        print("=" * 60)
        print("  WorkPilot Cloud — Opening browser for sign-in…")
        print(f"  Listening on http://localhost:{port}")
        print("  Close the tab / press Ctrl+C to cancel.")
        print("=" * 60)
        print()

        # After the OAuth callback, redirect to the web chat.
        # MSAL's local callback server always returns HTTP 200, so a true
        # 301/302 is not possible here.  <meta http-equiv="refresh"> is the
        # closest equivalent — an instantaneous, no-JavaScript client redirect
        # that degrades gracefully in environments that block JS.
        # The URL is HTML-attribute-escaped to prevent injection.
        web_url = webchat_url_from_connect(self._url)
        # html.escape covers all five special HTML chars (< > & ' "),
        # making the URL safe for both attribute values and text content.
        safe_url = _html.escape(web_url, quote=True)
        success_template = (
            "<!DOCTYPE html><html><head><title>WorkPilot</title>"
            f'<meta http-equiv="refresh" content="0;url={safe_url}"></head>'
            f'<body>Sign-in successful — <a href="{safe_url}">opening WorkPilot</a>…'
            "</body></html>"
        )

        assert self._msal_app is not None
        wam_kwargs: dict[str, Any] = {}
        if try_wam:
            wam_kwargs["parent_window_handle"] = self._msal_app.CONSOLE_WINDOW_HANDLE

        result = self._msal_app.acquire_token_interactive(
            scopes=[self._scope],
            prompt="select_account",
            port=port,
            timeout=300,
            success_template=success_template,
            **wam_kwargs,
        )

        # WAM broker failed — unconditionally retry with plain browser.
        # Common WAM errors: broker_error (redirect URI missing), admin consent
        # required (AADSTS65001), public client blocked (AADSTS7000218), etc.
        if try_wam and "error" in result:
            err = result.get("error", "")
            err_desc = result.get("error_description", "")
            logger.info("WAM broker failed ({}); falling back to browser PKCE", err)
            logger.debug("WAM error detail: {}", err_desc[:300])
            result = self._msal_app.acquire_token_interactive(
                scopes=[self._scope],
                prompt="select_account",
                port=port,
                timeout=300,
                success_template=success_template,
            )

        if "error" in result:
            raise RuntimeError(
                f"Browser login failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._save_identity(result)
        return str(result["access_token"])

    def _device_code_flow(self) -> str:
        """Device code flow — visit a URL and enter a short code.

        Works in headless / SSH / corporate environments where browser
        pop-ups are blocked.
        """
        assert self._msal_app is not None
        flow = self._msal_app.initiate_device_flow(scopes=[self._scope])
        if "error" in flow:
            raise RuntimeError(
                f"Device code flow failed to start: {flow.get('error_description', flow['error'])}"
            )

        print()
        print("=" * 60)
        print("  WorkPilot Cloud — Sign in required")
        print("=" * 60)
        print(flow["message"])
        print("=" * 60)
        print()

        result = self._msal_app.acquire_token_by_device_flow(flow)
        if "error" in result:
            raise RuntimeError(
                f"Device code flow failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._save_identity(result)
        return str(result["access_token"])

    def _persist_cache(self) -> None:
        """Write MSAL token cache to disk if it changed.

        Uses an atomic rename and mode 0o600 on POSIX. On Windows the parent
        auth/ directory is ACL-restricted via icacls (best-effort; see ensure_private_dir).
        """
        if self._cache_path is None or not self._token_cache.has_state_changed:
            return
        try:
            tmp = self._cache_path.with_suffix(".tmp")
            tmp.write_text(self._token_cache.serialize(), encoding="utf-8")
            try:
                tmp.chmod(0o600)
            except (NotImplementedError, OSError):
                pass  # Windows/some filesystems: parent ACL governs access
            tmp.replace(self._cache_path)
            logger.debug("MSAL token cache saved to {}", self._cache_path)
        except Exception as exc:
            logger.warning("Failed to save MSAL token cache: {}", exc)

    @staticmethod
    def _log_authenticated(result: dict) -> None:
        claims = result.get("id_token_claims", {})
        name = claims.get("name") or claims.get("preferred_username", "unknown")
        oid = claims.get("oid", "unknown")
        logger.success("Authenticated as: {} (oid={})", name, oid)

    def _save_identity(self, result: dict) -> None:
        """Persist Entra ID claims to ~/.workpilot/USER.md."""
        if self._runtime is None:
            return
        from workpilot.utils.identity import save_identity

        save_identity(
            result.get("id_token_claims", {}),
            self._runtime.workspace,
            user_file=self._runtime.config.agents.default.user_file,
        )
