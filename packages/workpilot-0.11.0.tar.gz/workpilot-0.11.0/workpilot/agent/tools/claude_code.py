"""
Claude Code tools — delegate coding/review tasks to Claude via the Agent SDK.

Tools
-----
  claude_code         Submit a task (background or wait mode).
  claude_code_status  Query task status / list all tasks.

Both share a singleton ClaudeCodeService which manages concurrent tasks
using ``claude-agent-sdk`` (ClaudeSDKClient / query).

Authentication uses Claude's own auth flow (Anthropic subscription —
Max/Pro/Team/Enterprise — or ANTHROPIC_API_KEY).

SDK: https://github.com/anthropics/claude-agent-sdk-python
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import ChannelType
from workpilot.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from workpilot.config.schema import ClaudeCodeToolConfig


# ── Task state ────────────────────────────────────────────────────────────────


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class ClaudeTask:
    task_id: str
    task: str
    task_type: str
    model: str = "sonnet"
    status: TaskStatus = TaskStatus.PENDING
    result: str = ""
    error: str = ""
    session_id: str = ""
    notify_channel: ChannelType = ChannelType.CLI
    notify_channel_id: str = ""
    notify_thread_id: str | None = None
    asyncio_task: asyncio.Task | None = field(default=None, repr=False)


# ── Service ───────────────────────────────────────────────────────────────────


class ClaudeCodeService:
    """Singleton service managing Claude Agent SDK tasks.

    Uses ``claude_agent_sdk.query()`` for one-shot tasks.
    Auth uses Claude's own flow (Anthropic subscription or ANTHROPIC_API_KEY).
    """

    _TASK_TYPE_PROMPTS: dict[str, str] = {
        "code": (
            "Implement the following task. Write clean, minimal code. "
            "Only change what is necessary. Run tests when applicable."
        ),
        "review": (
            "You have Agency plugins available: code-review and pr-review-toolkit. "
            "Use the /review-pr skill (from pr-review-toolkit plugin) for PR reviews "
            "or the /code-review skill (from code-review plugin) for general code reviews. "
            "These plugins provide structured, thorough review workflows with "
            "security analysis, best-practice checks, and actionable feedback.\n\n"
            "IMPORTANT — Post INLINE comments, not a single summary comment:\n"
            "For each issue found, POST a SEPARATE thread to the PR threads API "
            "with a threadContext that pins the comment to the specific file and line range. "
            "Use this JSON body for each inline comment:\n"
            "{\n"
            '  "comments": [{"parentCommentId": 0, "content": "[WorkPilot Review] <issue description>"}],\n'
            '  "status": 1,\n'
            '  "threadContext": {\n'
            '    "filePath": "/<path-to-file>",\n'
            '    "rightFileStart": {"line": <start_line>, "offset": 1},\n'
            '    "rightFileEnd": {"line": <end_line>, "offset": 1}\n'
            "  }\n"
            "}\n\n"
            "After all inline comments, POST one final summary thread (without threadContext) "
            "containing the overall verdict and a numbered list of all issues found. "
            "Use status 4 (closed) for the summary thread."
        ),
        "test": (
            "Write tests for the following task. Use the existing test framework "
            "and conventions in the codebase."
        ),
        "refactor": (
            "Refactor the following code. Keep behaviour identical. "
            "Improve readability, reduce duplication, and simplify where possible."
        ),
        "research": (
            "Research the following topic using the codebase and available tools. "
            "Provide a thorough analysis with specific code references."
        ),
    }

    def __init__(
        self,
        workspace: Path,
        bus: MessageBus,
        config: ClaudeCodeToolConfig,
    ) -> None:
        self._workspace = workspace
        self._bus = bus
        self._config = config
        self._tasks: dict[str, ClaudeTask] = {}
        self._sdk_validated = False
        self._sdk_lock = asyncio.Lock()
        self._semaphore = asyncio.Semaphore(config.max_concurrent)

    # ── SDK validation ────────────────────────────────────────────────────────

    async def _validate_sdk(self) -> None:
        """Validate the SDK is importable (lazy, once)."""
        async with self._sdk_lock:
            if self._sdk_validated:
                return
            try:
                import claude_agent_sdk  # noqa: F401

                logger.info(
                    f"ClaudeCodeService: claude-agent-sdk available "
                    f"(v{getattr(claude_agent_sdk, '__version__', 'unknown')})"
                )
            except ImportError:
                raise RuntimeError(
                    "claude-agent-sdk not installed. Install it: pip install claude-agent-sdk"
                )
            self._sdk_validated = True

    async def stop(self) -> None:
        """Cancel all in-flight tasks and clean up."""
        for ct in self._tasks.values():
            if ct.asyncio_task and not ct.asyncio_task.done():
                ct.asyncio_task.cancel()
                ct.status = TaskStatus.FAILED
                ct.error = "Cancelled: runtime shutting down"

        pending = [
            ct.asyncio_task
            for ct in self._tasks.values()
            if ct.asyncio_task and not ct.asyncio_task.done()
        ]
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        logger.info("ClaudeCodeService: stopped")

    # ── Model resolution ──────────────────────────────────────────────────────

    def _resolve_model(self, task_type: str, model_override: str | None) -> str:
        if model_override:
            return model_override
        policy = self._config.model_policy
        return getattr(policy, task_type, self._config.default_model)

    _REVIEW_PROMPT_NO_PLUGINS: str = (
        "Review the following code or PR. Identify bugs, security issues, "
        "performance problems, and style violations. Be concise and actionable.\n\n"
        "IMPORTANT — Post INLINE comments, not a single summary comment:\n"
        "For each issue found, POST a SEPARATE thread to the PR threads API "
        "with a threadContext that pins the comment to the specific file and line range. "
        "Use this JSON body for each inline comment:\n"
        "{\n"
        '  "comments": [{"parentCommentId": 0, "content": "[WorkPilot Review] <issue description>"}],\n'
        '  "status": 1,\n'
        '  "threadContext": {\n'
        '    "filePath": "/<path-to-file>",\n'
        '    "rightFileStart": {"line": <start_line>, "offset": 1},\n'
        '    "rightFileEnd": {"line": <end_line>, "offset": 1}\n'
        "  }\n"
        "}\n\n"
        "After all inline comments, POST one final summary thread (without threadContext) "
        "containing the overall verdict and a numbered list of all issues found. "
        "Use status 4 (closed) for the summary thread."
    )

    # ── Prompt builder ────────────────────────────────────────────────────────

    def _build_prompt(self, ct: ClaudeTask, files: list[str]) -> tuple[str, str]:
        """Return (user_prompt, system_prompt_append)."""
        if ct.task_type == "review" and not self._config.use_plugins:
            system = self._REVIEW_PROMPT_NO_PLUGINS
        else:
            system = self._TASK_TYPE_PROMPTS.get(ct.task_type, self._TASK_TYPE_PROMPTS["code"])
        parts = [ct.task]
        if files:
            file_list = "\n".join(f"  - {f}" for f in files)
            parts.append(f"\nFocus on these files/paths:\n{file_list}")
        return "\n".join(parts), system

    # ── Task submission ───────────────────────────────────────────────────────

    async def submit(
        self,
        task_desc: str,
        task_type: str,
        files: list[str],
        model_override: str | None,
        mode: str,
        notify_channel: ChannelType,
        notify_channel_id: str,
        notify_thread_id: str | None,
        allowed_tools: list[str] | None = None,
        max_turns: int = 0,
        resume_session_id: str | None = None,
        dangerously_skip_permissions: bool = False,
    ) -> str:
        await self._validate_sdk()

        model = self._resolve_model(task_type, model_override)
        task_id = uuid.uuid4().hex[:12]

        ct = ClaudeTask(
            task_id=task_id,
            task=task_desc,
            task_type=task_type,
            model=model,
            session_id=resume_session_id or "",
            notify_channel=notify_channel,
            notify_channel_id=notify_channel_id,
            notify_thread_id=notify_thread_id,
        )
        self._tasks[task_id] = ct

        user_prompt, system_prompt = self._build_prompt(ct, files)

        if mode == "wait":
            await self._run_task(
                ct,
                user_prompt,
                system_prompt,
                model,
                allowed_tools=allowed_tools,
                max_turns=max_turns,
                resume_session_id=resume_session_id,
                dangerously_skip_permissions=dangerously_skip_permissions,
                notify=False,
            )
            if ct.status == TaskStatus.DONE:
                session_line = f"\nSession: {ct.session_id}" if ct.session_id else ""
                return ct.result + session_line
            elif ct.result:
                return f"Task failed ({ct.error}):\n\n{ct.result}"
            else:
                return f"Task failed: {ct.error}"

        ct.asyncio_task = asyncio.create_task(
            self._run_task(
                ct,
                user_prompt,
                system_prompt,
                model,
                allowed_tools=allowed_tools,
                max_turns=max_turns,
                resume_session_id=resume_session_id,
                dangerously_skip_permissions=dangerously_skip_permissions,
                notify=True,
            ),
            name=f"claude-code-{task_id}",
        )
        session_line = f"Resuming: {resume_session_id}\n" if resume_session_id else ""
        return (
            f"Task submitted (id={task_id})\n"
            f"Type: {task_type} | Model: {model}\n"
            f"{session_line}"
            f"You will be notified on '{notify_channel}' when it completes.\n"
            f'Check status: claude_code_status(task_id="{task_id}")'
        )

    # ── Task execution ────────────────────────────────────────────────────────

    async def _run_task(
        self,
        ct: ClaudeTask,
        user_prompt: str,
        system_prompt: str,
        model: str,
        *,
        allowed_tools: list[str] | None,
        max_turns: int,
        resume_session_id: str | None,
        dangerously_skip_permissions: bool,
        notify: bool,
    ) -> None:
        async with self._semaphore:
            ct.status = TaskStatus.RUNNING
            logger.info(f"ClaudeCode [{ct.task_id}]: starting ({ct.task_type}) model={model}")
            try:
                await self._execute_sdk(
                    ct,
                    user_prompt,
                    system_prompt,
                    model,
                    allowed_tools=allowed_tools,
                    max_turns=max_turns,
                    resume_session_id=resume_session_id,
                    dangerously_skip_permissions=dangerously_skip_permissions,
                )
            except asyncio.CancelledError:
                ct.status = TaskStatus.FAILED
                if not ct.error:
                    ct.error = "Cancelled"
                logger.warning(f"ClaudeCode [{ct.task_id}]: cancelled")
            except Exception as exc:
                ct.status = TaskStatus.FAILED
                ct.error = str(exc)
                logger.error(f"ClaudeCode [{ct.task_id}]: failed — {exc}")

        if notify:
            await self._notify(ct)

    async def _execute_sdk(
        self,
        ct: ClaudeTask,
        user_prompt: str,
        system_prompt: str,
        model: str,
        *,
        allowed_tools: list[str] | None,
        max_turns: int,
        resume_session_id: str | None,
        dangerously_skip_permissions: bool,
    ) -> None:
        """Execute a task using the Claude Agent SDK query() function."""
        from claude_agent_sdk import (
            AssistantMessage,
            ClaudeAgentOptions,
            ResultMessage,
            TextBlock,
            query,
        )

        # Build SDK options
        options_kwargs: dict[str, Any] = {
            "model": model,
            "cwd": str(self._workspace),
        }

        if system_prompt:
            options_kwargs["system_prompt"] = system_prompt

        if allowed_tools:
            options_kwargs["allowed_tools"] = allowed_tools

        if max_turns > 0:
            options_kwargs["max_turns"] = max_turns

        # CLI path override (SDK bundles its own CLI, but allow override)
        if self._config.cli_path:
            options_kwargs["cli_path"] = self._config.cli_path

        # Session management — resume a prior session if requested
        if resume_session_id:
            options_kwargs["resume"] = resume_session_id

        # Permission bypass (sandboxed environments)
        # SDK valid modes: acceptEdits, bypassPermissions, default, dontAsk, plan
        skip_perms = dangerously_skip_permissions or self._config.dangerously_skip_permissions
        if skip_perms:
            options_kwargs["permission_mode"] = "bypassPermissions"

        # Setting sources — ensures .claude/settings.local.json is read
        # (which contains enabledPlugins for Agency plugins like code-review,
        # pr-review-toolkit, security-guidance, etc.)
        if self._config.setting_sources:
            options_kwargs["setting_sources"] = self._config.setting_sources

        options = ClaudeAgentOptions(**options_kwargs)

        logger.debug(f"ClaudeCode [{ct.task_id}]: query(model={model}, session={ct.session_id})")

        # Collect response text from the async iterator
        result_parts: list[str] = []

        timeout = self._config.task_timeout if self._config.task_timeout > 0 else 3600

        try:
            async with asyncio.timeout(timeout):
                async for message in query(prompt=user_prompt, options=options):
                    # Extract text from AssistantMessage blocks
                    if isinstance(message, AssistantMessage):
                        for block in message.content:
                            if isinstance(block, TextBlock):
                                result_parts.append(block.text)
                    # ResultMessage carries the real session ID and final status
                    elif isinstance(message, ResultMessage):
                        if message.session_id:
                            ct.session_id = message.session_id
                        if message.is_error:
                            if result_parts:
                                ct.result = "\n".join(result_parts)
                            raise RuntimeError(
                                f"Claude Code reported an error "
                                f"(stop_reason={message.stop_reason}): "
                                f"{message.result or '(no detail)'}"
                            )
                        # Only use ResultMessage.result as fallback when no
                        # AssistantMessage content was collected (e.g. non-streaming run)
                        if not result_parts and message.result:
                            result_parts.append(message.result)
        except TimeoutError:
            # Preserve any partial results collected before the timeout
            if result_parts:
                ct.result = "\n".join(result_parts) + "\n\n...(timed out)"
                ct.status = TaskStatus.FAILED
                ct.error = f"Partial result — timed out after {timeout}s"
                logger.warning(
                    f"ClaudeCode [{ct.task_id}]: timed out after {timeout}s "
                    f"with partial result ({len(ct.result)} chars)"
                )
                return
            raise TimeoutError(f"Claude Code task timed out after {timeout}s")

        ct.result = "\n".join(result_parts) if result_parts else "(no response)"
        ct.status = TaskStatus.DONE
        logger.info(f"ClaudeCode [{ct.task_id}]: done ({len(ct.result)} chars)")

    # ── Notification ──────────────────────────────────────────────────────────

    async def _notify(self, ct: ClaudeTask) -> None:
        from workpilot.security.leak import redact_credentials

        max_chars = self._config.notification_max_chars
        if ct.status == TaskStatus.DONE:
            body = (
                ct.result
                if len(ct.result) <= max_chars
                else ct.result[:max_chars] + "\n\n...(truncated)"
            )
            body = redact_credentials(body)
            session_line = f"\nSession: `{ct.session_id}`" if ct.session_id else ""
            content = (
                f"**Claude Code task complete** (id=`{ct.task_id}`, type=`{ct.task_type}`)"
                f"{session_line}\n\n"
                f"{body}"
            )
        elif ct.result:
            # Failed with partial results (e.g. timeout) — include what we got
            body = (
                ct.result
                if len(ct.result) <= max_chars
                else ct.result[:max_chars] + "\n\n...(truncated)"
            )
            body = redact_credentials(body)
            content = (
                f"**Claude Code task failed** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n"
                f"Error: {ct.error}\n\n{body}"
            )
        else:
            content = (
                f"**Claude Code task failed** (id=`{ct.task_id}`, type=`{ct.task_type}`)\n"
                f"Error: {ct.error}"
            )
        try:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=ct.notify_channel,
                    channel_id=ct.notify_channel_id,
                    content=content,
                    thread_id=ct.notify_thread_id,
                    metadata={"source": "claude_code", "task_id": ct.task_id},
                )
            )
        except Exception as exc:
            logger.warning(f"ClaudeCode [{ct.task_id}]: notification failed — {exc}")

    # ── Status queries ────────────────────────────────────────────────────────

    def get_task(self, task_id: str) -> ClaudeTask | None:
        return self._tasks.get(task_id)

    def list_tasks(self) -> list[ClaudeTask]:
        return list(self._tasks.values())


# ── Tool: claude_code ─────────────────────────────────────────────────────────


class ClaudeCodeTool(Tool):
    """Delegate a coding, review, test, refactor, or research task to Claude Code via Agent SDK."""

    risk_range = (2, 9)

    def __init__(self, service: ClaudeCodeService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "claude_code"

    @property
    def description(self) -> str:
        return (
            "Delegate a coding task to Claude Code (Anthropic Agent SDK). "
            "Claude Code reads, edits, and tests autonomously. "
            "Returns a task_id; notifies on completion."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=1800, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if args.get("dangerously_skip_permissions"):
            return RiskScore(9, reason="Claude Code with permission bypass")

        # Read-only tool restriction → low risk regardless of task_type
        allowed_tools = args.get("allowed_tools") or []
        if allowed_tools and set(allowed_tools).issubset({"Read", "Grep", "Glob", "Bash"}):
            task_type = (args.get("task_type", "code") or "code").strip()
            return RiskScore(2, reason=f"Claude Code {task_type} (restricted to read-only tools)")

        from workpilot.agent.tools.copilot import _assess_delegate_risk

        return _assess_delegate_risk("Claude Code", args)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "Task description. Include file names, expected behaviour, "
                        "and acceptance criteria."
                    ),
                },
                "task_type": {
                    "type": "string",
                    "enum": ["code", "review", "test", "refactor", "research"],
                    "description": (
                        "code = fix/implement; review = audit for bugs/security; "
                        "test = write tests; refactor = restructure; "
                        "research = explore codebase and analyze."
                    ),
                },
                "files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File or directory paths to focus on.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["background", "wait"],
                    "description": (
                        "background (default) = async with notification; "
                        "wait = block until done (short tasks only)."
                    ),
                },
                "model": {
                    "type": "string",
                    "description": "Model alias: sonnet, opus, haiku. Or full model name.",
                },
                "allowed_tools": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Restrict Claude's tools, e.g. ['Read', 'Grep', 'Glob'] "
                        "for read-only. Omit to allow all."
                    ),
                },
                "max_turns": {
                    "type": "integer",
                    "description": "Max agentic turns. 0 (default) = unlimited.",
                },
                "resume_session_id": {
                    "type": "string",
                    "description": (
                        "Resume a prior session. Use the session ID from claude_code_status output."
                    ),
                },
                "dangerously_skip_permissions": {
                    "type": "boolean",
                    "description": "Bypass permission checks (CI/containers only).",
                },
            },
            "required": ["task"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        thread_id = kwargs.get("_thread_id")

        task: str = kwargs.get("task", "")
        task_type: str = kwargs.get("task_type", "code")
        files: list[str] = kwargs.get("files", [])
        mode: str = kwargs.get("mode", "background")
        model: str | None = kwargs.get("model") or None
        allowed_tools: list[str] | None = kwargs.get("allowed_tools") or None
        max_turns: int = kwargs.get("max_turns", 0)
        resume_session_id: str | None = kwargs.get("resume_session_id") or None
        dangerously_skip_permissions: bool = kwargs.get("dangerously_skip_permissions", False)

        if not task.strip():
            return "Error: task description cannot be empty."
        if task_type not in ("code", "review", "test", "refactor", "research"):
            return (
                f"Error: invalid task_type '{task_type}'. "
                "Use: code, review, test, refactor, research."
            )
        if mode not in ("background", "wait"):
            return f"Error: invalid mode '{mode}'. Use: background or wait."

        return await self._service.submit(
            task_desc=task,
            task_type=task_type,
            files=files,
            model_override=model,
            mode=mode,
            notify_channel=ChannelType.of(channel),
            notify_channel_id=channel_id,
            notify_thread_id=thread_id,
            allowed_tools=allowed_tools,
            max_turns=max_turns,
            resume_session_id=resume_session_id,
            dangerously_skip_permissions=dangerously_skip_permissions,
        )


# ── Tool: claude_code_status ──────────────────────────────────────────────────


class ClaudeCodeStatusTool(Tool):
    """Query the status and result of a background Claude Code task."""

    risk_range = (0, 0)

    def __init__(self, service: ClaudeCodeService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "claude_code_status"

    @property
    def description(self) -> str:
        return "Check Claude Code task status or list all tasks."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=5, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only Claude Code status query")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task ID from claude_code. Omit to list all tasks.",
                },
            },
        }

    async def execute(self, **kwargs: Any) -> str:
        task_id: str | None = kwargs.get("task_id")

        if not task_id:
            tasks = self._service.list_tasks()
            if not tasks:
                return "No Claude Code tasks found."
            lines = [f"{'ID':<14} {'TYPE':<10} {'STATUS':<10} {'MODEL'}"]
            lines.append("-" * 44)
            for t in tasks:
                lines.append(f"{t.task_id:<14} {t.task_type:<10} {t.status.value:<10} {t.model}")
            return "\n".join(lines)

        ct = self._service.get_task(task_id)
        if ct is None:
            return f"Error: no task with id '{task_id}'."

        lines = [
            f"Task ID:   {ct.task_id}",
            f"Type:      {ct.task_type}",
            f"Model:     {ct.model}",
            f"Status:    {ct.status.value}",
        ]
        if ct.session_id:
            lines.append(f"Session:   {ct.session_id}")
        if ct.status == TaskStatus.RUNNING:
            lines.append("Result:    (in progress...)")
        elif ct.status == TaskStatus.DONE:
            # Return full result (up to 16K) so callers can see the complete output
            max_result = 16_000
            result_text = ct.result[:max_result] + (
                "...(truncated)" if len(ct.result) > max_result else ""
            )
            lines.append(f"Result:\n{result_text}")
        elif ct.status == TaskStatus.FAILED:
            lines.append(f"Error:     {ct.error}")

        return "\n".join(lines)
