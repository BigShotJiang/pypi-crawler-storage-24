"""
config_workpilot tool — lets the agent read, discover, and modify WorkPilot configuration.

The agent can:
- show: read current config (secrets redacted) with a baseHash for optimistic concurrency
- lookup: discover the JSON Schema for a config path (type, description, constraints)
- patch: apply a partial update to workpilot.local.yaml with Pydantic validation
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.config.schema import AppConfig
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore

# ── Deny list — fields the agent must never modify ─────────────────────────

_DENY_PATHS: frozenset[str] = frozenset(
    {
        # All security settings (profile, estop, audit, approval, roles, overrides, etc.)
        "security",
        # Sandbox boundaries — deny + allow patterns, path restrictions
        "tools.shell.deny_patterns",
        "tools.shell.allow_patterns",
        "tools.filesystem.deny_paths",
        "tools.filesystem.restrict_to_workspace",
        "tools.filesystem.extra_allowed_paths",
        # MCP servers: block executable, env, auth, headers; allow url/args/description
        "tools.mcp_servers.*.command",
        "tools.mcp_servers.*.env",
        "tools.mcp_servers.*.auth",
        "tools.mcp_servers.*.headers",
        # Credentials
        "providers.openai.api_key",
        "providers.github_copilot.token",
        "channels.web.api_key",
        "channels.cloud.bypass_token",
        # Loader-only keys (processed before validation, can break startup)
        "extends",
        "profiles",
        "env",
    }
)


class ConfigWorkpilotTool(Tool):
    """Read or modify WorkPilot configuration via natural language."""

    def __init__(
        self,
        config: AppConfig,
        local_config_path: Path,
        schema: dict[str, Any],
    ) -> None:
        self._config = config
        self._local_path = local_config_path
        self._schema = schema

    @property
    def name(self) -> str:
        return "config_workpilot"

    @property
    def description(self) -> str:
        return "Read or modify current configuration settings."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["show", "lookup", "patch"],
                    "description": (
                        "show = read current config (secrets redacted) with a baseHash; "
                        "lookup = get schema info (type, allowed values, description) for a config path; "
                        "patch = update a config value (validates before writing). "
                        "Sections: providers, agents, tools, skills, security, channels, cron, logging."
                    ),
                },
                "path": {
                    "type": "string",
                    "description": (
                        "Dot-separated config path (e.g. 'logging.level', 'agents.default.model', 'tools.shell.timeout'). "
                        "Use a section name like 'logging' or 'tools' to see all children. "
                        "Omit for show to return the full config. Required for lookup and patch."
                    ),
                },
                "value": {
                    "type": "string",
                    "description": "New value for patch (use lookup to check allowed values). Pass JSON for arrays/objects.",
                },
                "base_hash": {
                    "type": "string",
                    "description": "Hash from a previous show response. Pass to patch to ensure config hasn't changed since you read it. Optional.",
                },
            },
            "required": ["action"],
        }

    risk_range = (0, 8)

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = (args.get("action", "") or "").strip()
        if action == "show":
            return RiskScore(1, reason="Read current config (secrets redacted)")
        if action == "lookup":
            return RiskScore(0, reason="Read config schema")
        if action == "patch":
            path = (args.get("path", "") or "").strip()
            if not path:
                return RiskScore(4, reason="Config patch (no path specified)")
            # Deny-listed paths (blocked by execute anyway)
            denial = _check_deny_list(path)
            if denial:
                return RiskScore(8, reason=f"Config patch to protected path: {path}")
            # Deterministic by path pattern
            leaf = path.rsplit(".", 1)[-1] if "." in path else path
            if path.startswith("logging."):
                return RiskScore(3, reason=f"Config patch: {path} (cosmetic)")
            if leaf in ("format", "level"):
                return RiskScore(3, reason=f"Config patch: {path} (cosmetic)")
            if leaf in ("description", "prompt"):
                return RiskScore(3, reason=f"Config patch: {path} (text only)")
            if leaf in ("timeout", "port", "interval"):
                return RiskScore(4, reason=f"Config patch: {path} (tuning)")
            if leaf in ("model", "max_iterations", "max_spawn_depth"):
                return RiskScore(5, reason=f"Config patch: {path} (agent behavior)")
            if leaf == "enabled":
                return RiskScore(6, reason=f"Config patch: {path} (feature toggle)")
            if leaf in ("url", "endpoint", "host"):
                return RiskScore(6, reason=f"Config patch: {path} (connectivity)")
            # Remaining → LLM
            return RiskPrompt(
                f"Config patch: {path}. Range: 4~7\n"
                f"Scoring factors:\n"
                f"  4: Agent behavior or minor structural change\n"
                f"  5: Feature toggle or tool configuration\n"
                f"  6: External connectivity or channel config\n"
                f"  7: Broad change affecting multiple subsystems"
            )
        # Unknown action → fall through to base class default RiskPrompt
        return super().assess_risk(args)

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        path = kwargs.get("path", "")
        raw_value = kwargs.get("value")
        base_hash = kwargs.get("base_hash")

        if action == "show":
            return self._show(path or None)
        if action == "lookup":
            if not path:
                return "Error: 'path' is required for lookup. Example: 'logging.level'"
            return self._lookup(path)
        if action == "patch":
            if not path:
                return "Error: 'path' is required for patch."
            if "value" not in kwargs:
                return "Error: 'value' is required for patch."
            value = self._parse_value(raw_value)
            return self._patch(path, value, base_hash)
        return f"Error: unknown action '{action}'. Use show, lookup, or patch."

    # ── show ────────────────────────────────────────────────────────────────

    def _show(self, path: str | None) -> str:
        from workpilot.security.audit import _redact_dict

        raw = self._config.model_dump(mode="json")
        redacted = _redact_dict(raw)

        if path:
            value = _get_nested(redacted, path)
            if value is _MISSING:
                return f"Config path '{path}' not found."
            result: Any = {"path": path, "value": value}
        else:
            result = redacted

        try:
            local_data = self._load_local()
        except ValueError as exc:
            return str(exc)
        bh = _compute_hash(local_data)
        return json.dumps({"config": result, "baseHash": bh}, indent=2, default=str)

    # ── lookup ──────────────────────────────────────────────────────────────

    def _lookup(self, path: str) -> str:
        node = self._resolve_schema_node(path)
        if node is None:
            return f"Config path '{path}' not found in schema."

        # Build a compact summary for the LLM
        summary: dict[str, Any] = {"path": path}
        _SUMMARY_KEYS = ("type", "description", "default", "enum", "minimum", "maximum", "pattern")
        for key in _SUMMARY_KEYS:
            if key in node:
                summary[key] = node[key]

        # For objects, list child keys
        if node.get("type") == "object" and "properties" in node:
            children: dict[str, str] = {}
            for k, v in node["properties"].items():
                resolved = v
                if "$ref" in v:
                    resolved = self._resolve_ref(v["$ref"])
                children[k] = resolved.get("description", resolved.get("type", ""))
            summary["properties"] = children

        # Show current value
        current = _get_nested(self._config.model_dump(mode="json"), path)
        if current is not _MISSING:
            from workpilot.security.audit import _redact_dict

            if isinstance(current, dict):
                current = _redact_dict(current)
            summary["current_value"] = current

        return json.dumps(summary, indent=2, default=str)

    # ── patch ───────────────────────────────────────────────────────────────

    def _patch(self, path: str, value: Any, base_hash: str | None) -> str:
        # 1. Deny list check (top-level path + all nested keys in value)
        for check_path in _iter_patch_paths(path, value):
            denial = _check_deny_list(check_path)
            if denial:
                return denial

        # 2. Load existing local override
        try:
            local_data = self._load_local()
        except ValueError as exc:
            return str(exc)

        # 3. Optimistic concurrency
        if base_hash is not None:
            current_hash = _compute_hash(local_data)
            if current_hash != base_hash:
                return (
                    "Error: config changed since last read (hash mismatch). "
                    "Call 'show' again to get the current baseHash."
                )

        # 4. Build nested dict from dot-path
        patch_dict = _build_nested(path, value)

        # 5. Deep-merge into local data
        from workpilot.config.loader import _deep_merge

        merged_local = _deep_merge(local_data, patch_dict)

        # 6. Validate by simulating full config load
        error = self._validate_merged(merged_local)
        if error:
            return error

        # 7. Write
        from workpilot.config.loader import save_yaml

        save_yaml(self._local_path, merged_local)
        return f"Updated '{path}' in {self._local_path.name}. Changes take effect on next restart."

    # ── Schema navigation ───────────────────────────────────────────────────

    def _resolve_ref(self, ref: str) -> dict[str, Any]:
        """Resolve a $ref like '#/$defs/ShellConfig'."""
        parts = ref.lstrip("#/").split("/")
        node: dict[str, Any] = self._schema
        for part in parts:
            node = node[part]
        return dict(node)

    def _resolve_schema_node(self, dot_path: str) -> dict[str, Any] | None:
        """Navigate to the schema node for a dot-separated path."""
        segments = dot_path.split(".")
        node: dict[str, Any] = self._schema

        for segment in segments:
            node = self._deref(node)
            props = node.get("properties", {})
            if segment in props:
                node = props[segment]
            elif node.get("additionalProperties") and isinstance(
                node["additionalProperties"], dict
            ):
                node = node["additionalProperties"]
            else:
                return None

        return self._deref(node)

    def _deref(self, node: dict[str, Any]) -> dict[str, Any]:
        """Resolve $ref and anyOf wrappers, preserving description."""
        if "$ref" in node:
            resolved = self._resolve_ref(node["$ref"])
            if "description" in node:
                resolved = {**resolved, "description": node["description"]}
            return resolved
        if "anyOf" in node:
            for option in node["anyOf"]:
                if "$ref" in option:
                    resolved = self._resolve_ref(option["$ref"])
                    if "description" in node:
                        resolved = {**resolved, "description": node["description"]}
                    return resolved
                if option.get("type") not in ("null",):
                    merged = {**option}
                    if "description" in node and "description" not in merged:
                        merged["description"] = node["description"]
                    return merged
        return node

    # ── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_value(raw: Any) -> Any:
        """Parse a string value into the appropriate Python type.

        The LLM sends value as a string (schema declares type=string for
        provider compatibility). Try JSON parsing first to handle numbers,
        booleans, arrays, and objects. Fall back to raw string.
        """
        if not isinstance(raw, str):
            return raw  # already parsed (e.g. from direct tool call)
        # Try JSON parse for non-string types
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            return raw  # keep as string

    def _load_local(self) -> dict[str, Any]:
        """Load local override YAML. Raises ValueError on parse errors."""
        if not self._local_path.is_file():
            return {}
        try:
            data = yaml.safe_load(self._local_path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            raise ValueError(
                f"Cannot parse {self._local_path.name}: {exc}. "
                "Please fix the YAML syntax before modifying config."
            ) from exc
        if not isinstance(data, dict):
            return {}
        return data

    def _validate_merged(self, merged_local: dict[str, Any]) -> str | None:
        """Validate by merging into the current running config. Return error or None."""
        from pydantic import ValidationError

        from workpilot.config.loader import _deep_merge

        full = _deep_merge(self._config.model_dump(mode="python"), merged_local)
        try:
            AppConfig.model_validate(full)
        except ValidationError as exc:
            return f"Validation error: {exc}"
        return None


# ── Module-level helpers (also used by tests) ───────────────────────────────

_MISSING = object()


def _get_nested(data: dict[str, Any], dot_path: str) -> Any:
    """Navigate a dict by dot-separated path. Returns _MISSING if not found."""
    cursor: Any = data
    for segment in dot_path.split("."):
        if isinstance(cursor, dict) and segment in cursor:
            cursor = cursor[segment]
        else:
            return _MISSING
    return cursor


def _build_nested(dot_path: str, value: Any) -> dict[str, Any]:
    """Build a nested dict from a dot-path: 'a.b.c' + v → {'a': {'b': {'c': v}}}."""
    segments = dot_path.split(".")
    result: dict[str, Any] = {}
    cursor = result
    for seg in segments[:-1]:
        cursor[seg] = {}
        cursor = cursor[seg]
    cursor[segments[-1]] = value
    return result


def _compute_hash(data: dict[str, Any]) -> str:
    """SHA-256 hash of JSON-serialized config for optimistic concurrency."""
    raw = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _iter_patch_paths(prefix: str, obj: Any) -> list[str]:
    """Yield the prefix and all nested dot-paths for dict values."""
    paths = [prefix]
    if isinstance(obj, dict):
        for k, v in obj.items():
            paths.extend(_iter_patch_paths(f"{prefix}.{k}", v))
    return paths


def _check_deny_list(dot_path: str) -> str | None:
    """Return an error message if the path is denied, else None.

    Supports wildcard ``*`` in deny patterns to match any single segment.
    E.g. ``tools.mcp_servers.*.auth`` blocks ``tools.mcp_servers.myserver.auth``.
    """
    path_parts = dot_path.split(".")
    for denied in _DENY_PATHS:
        deny_parts = denied.split(".")
        if _match_pattern(path_parts, deny_parts):
            return (
                f"Error: modifying '{dot_path}' is not permitted. "
                "This field is protected for security reasons."
            )
    return None


def _match_pattern(path_parts: list[str], deny_parts: list[str]) -> bool:
    """Check if path matches a deny pattern (prefix match with * wildcards)."""
    for i, dp in enumerate(deny_parts):
        if i >= len(path_parts):
            return False
        if dp != "*" and dp != path_parts[i]:
            return False
    return True
