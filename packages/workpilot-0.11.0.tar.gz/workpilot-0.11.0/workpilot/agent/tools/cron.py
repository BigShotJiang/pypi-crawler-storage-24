"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, and disable jobs.
Dynamic jobs persist to .workpilot/cron/jobs.json.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore

if TYPE_CHECKING:
    from workpilot.agent.tools.registry import ToolRegistry
    from workpilot.cron.service import SchedulerService


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs (nanobot CronTool pattern)."""

    risk_range = (0, 9)

    def __init__(self, scheduler: SchedulerService, registry: ToolRegistry | None = None) -> None:
        self._scheduler = scheduler
        self._registry = registry

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled jobs. Prefer tool mode for reminders; agent mode for complex tasks."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove", "enable", "disable", "describe"],
                    "description": (
                        "list = show all; add = create; remove = delete; "
                        "enable/disable = toggle; describe = show details."
                    ),
                },
                "job_id": {
                    "type": "string",
                    "description": (
                        "Short descriptive name for the job (e.g. 'drink-water', 'standup-reminder'). "
                        "Required for remove/enable/disable/describe. For add, provide a meaningful name."
                    ),
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "In SECONDS: 'at:+60' = 1 min; 'at:+3600' = 1 hr; "
                        "'at:2026-03-04T15:00:00' = specific time; "
                        "'at' = immediate; 3600 = repeat every hour; "
                        "'0 9 * * *' = cron. Required for add."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Agent mode: task for LLM to execute. Use for complex tasks needing reasoning. "
                        "Mutually exclusive with tool."
                    ),
                },
                "tool": {
                    "type": "string",
                    "description": (
                        "Tool mode (PREFERRED for reminders): tool name to execute directly, no LLM. "
                        "Use tool='notify' with arguments={channel:'*', content:'your message'} for reminders. "
                        "Mutually exclusive with prompt."
                    ),
                },
                "arguments": {
                    "type": "object",
                    "description": (
                        "Arguments for tool mode (required when tool is set). "
                        'Example: {"channel": "*", "content": "Time to drink water!"}'
                    ),
                },
                "notify_channels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Result delivery channels. ['*'] = all active channels.",
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = (args.get("action", "") or "").strip()
        if action in ("list", "describe"):
            return RiskScore(0, reason=f"Read-only cron operation ({action})")
        if action in ("enable", "disable", "remove"):
            return RiskScore(2, reason=f"Cron job management ({action})")
        # add action — delegate to target tool's assess_risk
        tool_name = args.get("tool")
        prompt = args.get("prompt")
        if tool_name and self._registry:
            target = self._registry.get(tool_name)
            if target:
                tool_args = args.get("arguments") or {}
                tool_risk = target.assess_risk(tool_args)
                if isinstance(tool_risk, RiskScore):
                    return RiskScore(
                        tool_risk.score,
                        reason=f"Schedule {tool_name}: {tool_risk.reason}",
                    )
                # Tool returned RiskPrompt — pass through with cron context
                return RiskPrompt(
                    f"Schedule recurring {tool_name} execution.\n"
                    f"Tool risk: {tool_risk.prompt}\n"
                    f"Scheduling adds risk — recurring unattended execution."
                )
        if tool_name:
            # No registry — can't evaluate target, use conservative estimate
            tool_args = args.get("arguments") or {}
            args_desc = ", ".join(f"{k}={v!r}" for k, v in list(tool_args.items())[:5])
            return RiskPrompt(
                f"Schedule recurring execution of tool '{tool_name}'.\n"
                f"Arguments: {{{args_desc}}}\n"
                f"Schedule: {args.get('schedule', '?')}\n"
                f"Range: 3~9\n"
                f"Scoring factors:\n"
                f"  3: Read-only or notification tool (e.g. notify, search)\n"
                f"  4: Local write tool (e.g. git commit, file edit)\n"
                f"  5: Tool with moderate side effects (e.g. build, test)\n"
                f"  6: Tool with external impact (e.g. http_request POST, git push)\n"
                f"  7: Elevated or broad-scope tool (e.g. shell with sudo)\n"
                f"  8: Destructive tool (e.g. shell rm -rf, git reset --hard)\n"
                f"  9: Catastrophic or unrestricted execution"
            )
        if prompt:
            prompt_preview = prompt[:100] + ("..." if len(prompt) > 100 else "")
            return RiskPrompt(
                f"Schedule recurring agent prompt execution.\n"
                f"Prompt: {prompt_preview}\n"
                f"Schedule: {args.get('schedule', '?')}\n"
                f"Range: 3~9\n"
                f"Scoring factors:\n"
                f"  3: Read-only analysis or status check\n"
                f"  4: Task involving local file reads\n"
                f"  5: Task involving file modifications\n"
                f"  6: Task with external side effects (API calls, notifications)\n"
                f"  7: Task with elevated or broad scope\n"
                f"  8: Task with destructive potential\n"
                f"  9: Unrestricted agent execution"
            )
        return RiskScore(2, reason="Cron management")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            jobs = self._scheduler.list_jobs()
            if not jobs:
                return "No scheduled jobs."
            lines = ["Scheduled jobs:"]
            for j in jobs:
                status = "enabled" if j["enabled"] else "DISABLED"
                next_run = j.get("next_run") or "N/A"
                mode = j.get("mode", "tool" if j.get("tool") else "agent")
                lines.append(
                    f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                    f"mode={mode} agent={j['agent']} [{status}] next={next_run}"
                )
            return "\n".join(lines)

        elif action == "add":
            schedule = kwargs.get("schedule")
            tool_name = kwargs.get("tool")
            arguments = kwargs.get("arguments")
            prompt = kwargs.get("prompt")

            if not schedule:
                return "Error: 'schedule' is required for add."
            if tool_name and prompt:
                return "Error: 'tool' and 'prompt' are mutually exclusive."
            if not tool_name and not prompt:
                return "Error: either 'tool' or 'prompt' is required for add."
            if tool_name and arguments is None:
                return "Error: 'arguments' is required when 'tool' is set."

            # Tool mode: check if target tool exists
            if tool_name and self._registry:
                target = self._registry.get(tool_name)
                if not target:
                    return f"Error: unknown tool '{tool_name}'."

            import re as _re

            job_id = kwargs.get("job_id")
            if not job_id:
                # Derive a short name from the prompt or tool (first few words, slugified)
                source = prompt or tool_name or "task"
                slug = _re.sub(r"[^a-z0-9]+", "-", source[:40].lower()).strip("-")
                job_id = slug or "task"
            # Ensure unique name by appending suffix if already exists
            existing = {j["name"] for j in self._scheduler.list_jobs()}
            if job_id in existing:
                base = job_id
                for i in range(2, 100):
                    job_id = f"{base}-{i}"
                    if job_id not in existing:
                        break
                else:
                    import uuid as _uuid

                    job_id = f"{base}-{_uuid.uuid4().hex[:6]}"
            notify_channels = kwargs.get("notify_channels") or ["*"]
            try:
                self._scheduler.add_job(
                    name=job_id,
                    schedule=schedule,
                    prompt=prompt or "",
                    tool=tool_name,
                    arguments=arguments,
                    notify_channels=notify_channels,
                    dynamic=True,
                    channel=kwargs.get("_channel"),
                    channel_id=kwargs.get("_channel_id"),
                )
            except ValueError as exc:
                return f"Error: {exc}"
            mode_info = f", tool={tool_name}" if tool_name else ""
            return f"Job '{job_id}' added (schedule={schedule}{mode_info})."

        elif action == "remove":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for remove."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.remove_job(job_id)
            return f"Job '{job_id}' removed."

        elif action == "enable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for enable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.enable(job_id)
            return f"Job '{job_id}' enabled."

        elif action == "disable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for disable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.disable(job_id)
            return f"Job '{job_id}' disabled."

        elif action == "describe":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for describe."
            jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
            job = jobs_by_name.get(job_id)
            if not job:
                return f"Error: job '{job_id}' not found."
            mode = job.get("mode", "tool" if job.get("tool") else "agent")
            tool_line = f"\nTool: {job['tool']}" if job.get("tool") else ""
            return (
                f"Job: {job['name']}\n"
                f"Schedule: {job['trigger_type']} ({job['schedule']})\n"
                f"Mode: {mode}\n"
                f"Agent: {job['agent']}\n"
                f"Status: {'enabled' if job['enabled'] else 'DISABLED'}\n"
                f"Next run: {job.get('next_run') or 'N/A'}\n"
                f"Failures: {job['failure_count']}"
                f"{tool_line}"
            )

        return f"Unknown action: {action}"
