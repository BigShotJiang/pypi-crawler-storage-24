# Heartbeat

You are running as a periodic background task (default: every 30 minutes).
Reply HEARTBEAT_OK if nothing to report. Only notify the user when action is genuinely needed.

## System
- Check for updates: skip if current local time is outside 7:30–19:30. Read {WorkPilot_Dir}/.last_update_check — skip if checked within 18 hours. Otherwise call check_update() and write the current timestamp to that file.

## Security
- Scan {WorkPilot_Dir}/MEMORY.md for accidentally stored secrets (API keys, tokens, passwords). Remove if found and notify user.

## User Profile
Only run this section if {WorkPilot_Dir}/USER.md does not exist or is older than 7 days.
- Scan workspace for languages and frameworks, update {WorkPilot_Dir}/USER.md ## Tech Stack if changed.
- Review recent conversations, infer user's role and preferences, update {WorkPilot_Dir}/USER.md ## Preferences.

## Skills
Check `{WorkPilot_Dir}/skills/.last_updated` — skip this entire section if it was written within the last 6 hours.

Scan sessions in `{WorkPilot_Dir}/sessions/` and identify repeated tasks, workflows, or patterns
that would benefit from a reusable skill.

**Creating new skills:**
- Direct create if either condition is met:
  - 2+ similar operations in the last 36 hours (scan recent sessions only), OR
  - 4+ similar operations across all available session history
- Otherwise: save draft to `{WorkPilot_Dir}/skill-draft/<name>.md`, notify user to review.
- Create `{WorkPilot_Dir}/skills/<name>.md` using SKILL.md format
  (YAML frontmatter with name, description, activation keywords; body with step-by-step instructions).
- Do not create skills for trivial or one-off tasks regardless of frequency.

**Modifying existing skills:**
- For each skill in `{WorkPilot_Dir}/skills/`, cross-check its instructions against recent session operations:
  - Are any referenced paths, commands, or steps broken or no longer valid?
  - Does the session show a simpler or more effective approach than what the skill describes?
- If inconsistencies are found and you are confident in the improvement:
  - Save the proposed update to `{WorkPilot_Dir}/skill-draft/<name>.md`.
  - Notify the user via notify(channel='*') with a clear diff summary and ask for confirmation.
  - Do NOT overwrite the live skill — wait for user approval.
- If the signal is ambiguous or only seen once, skip — do not generate a pending update.

After completing this section (regardless of whether any changes were made), write the current
timestamp to `{WorkPilot_Dir}/skills/.last_updated`.

## Notification Guidelines
- Batch all findings into a SINGLE notify() call at the end, not per-section.
- Do NOT notify if everything is up to date and nothing needs attention.
- Only notify for: updates available, security issues found, skills created/modified.
