Compress the memory to fit within the target size.

Current size: {total_chars} chars (target <5.5KB).
Section sizes: {size_summary}
The {worst} section is most over budget.

FOCUS compression on {worst} only:
- Merge similar entries in {worst}
- Shorten verbose descriptions in {worst}
- Do NOT drop facts — merge, don't delete
- Keep other sections unchanged (copy them as-is)
- Be gentle — reduce {worst} by ~30%, not drastically

Preserve the two-section structure exactly:
- ## Facts: `tag: content` (20~25 entries, no dates, always English)
- ## Recent Activity: `YYYY-MM-DD summary` (12~15 entries, newest first)
- Preserve each entry's original language (do NOT translate Chinese to English or vice versa)

Output the full result in a ```memory``` fenced block.

---

{memory_content}
