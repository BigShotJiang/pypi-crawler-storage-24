"""
Built-in agent configurations — default, explorer, security.

These are always available. Users can override any field via workpilot.yaml.
"""

from __future__ import annotations

from workpilot.config.schema import AgentConfig, AgentPermissions


def get_builtin_agents() -> dict[str, AgentConfig]:
    """Return the 3 built-in agent configs."""
    return {
        "default": _default_agent(),
        "explorer": _explorer_agent(),
        "security": _security_agent(),
    }


def _default_agent() -> AgentConfig:
    return AgentConfig(
        name="WorkPilot Assistant",
        description="General-purpose assistant. Handles direct user interaction, orchestrates sub-agents.",
        model="auto",
        max_iterations=40,
        timeout=1200,
        memory_writable=True,
        max_spawn_depth=2,
        max_concurrent_children=5,
        instructions="",
        tools=[
            "tools",
            "shell",
            "read_file",
            "write_file",
            "edit_file",
            "list_dir",
            "search_files",
            "git",
            "http_request",
            "web_search",
            "web_fetch",
            "browser",
            "spawn",
            "notify",
            "search_history",
            "config_workpilot",
            "github_copilot",
            "github_copilot_status",
            "github_copilot_models",
            "claude_code",
            "claude_code_status",
        ],
        permissions=AgentPermissions(
            allow_shell=True,
            allow_file_write=True,
            allow_file_read=True,
            allow_network=True,
            allow_browser=True,
            allow_spawn=True,
        ),
        metadata={"category": "orchestrator", "builtin": True},
    )


def _explorer_agent() -> AgentConfig:
    return AgentConfig(
        name="Explorer",
        description="Fast codebase search and file discovery. Read-only.",
        model="fast",
        max_iterations=15,
        timeout=120,
        memory_writable=False,
        instructions=(
            "You are a codebase explorer. READ-ONLY MODE.\n"
            "You are STRICTLY PROHIBITED from creating, modifying, or deleting files.\n\n"
            "Your strengths:\n"
            "- Rapidly finding files using glob and regex patterns\n"
            "- Searching code contents across the entire codebase\n"
            "- Reading and analyzing file contents\n\n"
            "Guidelines:\n"
            "- Use search_files for content search (regex) or file discovery (glob)\n"
            "- Use read_file when you know the specific file path\n"
            "- Use list_dir for directory exploration\n"
            "- Return file paths with line numbers in your final response\n"
            "- Do NOT suggest code changes — just report what you find"
        ),
        tools=["read_file", "list_dir", "search_files"],
        permissions=AgentPermissions(
            allow_shell=False,
            allow_file_write=False,
            allow_file_read=True,
            allow_network=False,
            allow_browser=False,
            allow_spawn=False,
        ),
        metadata={"category": "development", "builtin": True},
    )


def _security_agent() -> AgentConfig:
    return AgentConfig(
        name="Security Agent",
        description="Internal: evaluates tool calls for risk and policy compliance.",
        model="fast",
        max_iterations=2,
        timeout=55,
        memory_writable=False,
        instructions=(
            "You evaluate whether a proposed tool call should be allowed.\n"
            'Respond with JSON: {"decision": "allow"|"deny"|"escalate", '
            '"risk": "low"|"medium"|"high"|"critical", "reason": "..."}\n'
            "When in doubt, ESCALATE rather than ALLOW."
        ),
        tools=["read_file", "list_dir"],
        permissions=AgentPermissions(
            allow_shell=False,
            allow_file_write=False,
            allow_file_read=False,
            allow_network=False,
            allow_browser=False,
            allow_spawn=False,
        ),
        metadata={"category": "system", "builtin": True, "internal": True},
    )


def merge_agents(
    builtin: dict[str, AgentConfig],
    user: dict[str, AgentConfig],
) -> dict[str, AgentConfig]:
    """Merge user-defined agents with built-in agents.

    User configs override built-in fields. Disabled agents (enabled=False)
    are excluded from the result.
    """
    # Build a reference default instance ONCE for comparison
    _defaults = AgentConfig()
    _default_data = _defaults.model_dump()

    merged = dict(builtin)
    for name, user_config in user.items():
        if name in merged:
            # Override built-in fields with user-specified values.
            # Compare against a default instance to detect user overrides
            # (works correctly for default_factory fields like tools, metadata).
            builtin_data = merged[name].model_dump()
            user_data = user_config.model_dump()
            for k, v in user_data.items():
                if v != _default_data.get(k):
                    builtin_data[k] = v
            merged[name] = AgentConfig(**builtin_data)
        else:
            merged[name] = user_config

    # Remove disabled agents
    return {k: v for k, v in merged.items() if v.enabled}
