"""
Model context window catalog — static fallback values + runtime API fetch.

Three data sources (in priority order):
1. Runtime: GitHub Models API  (models.github.ai/catalog/models)
2. Runtime: Copilot API        (api.enterprise.githubcopilot.com/models)
3. Static:  Hardcoded below    (fallback when APIs are unreachable)

Static values last verified: 2026-03-18
- GitHub Models:  limits.max_input_tokens
- Copilot:        capabilities.limits.max_context_window_tokens
- Azure OpenAI:   learn.microsoft.com/azure/ai-services/openai/concepts/models
"""

from __future__ import annotations

import threading

from loguru import logger

# ── Static catalog ────────────────────────────────────────────────────────────
# Keys with provider prefix (github/, github_copilot/, azure/) are endpoint-
# specific.  Bare keys are used as fallback when the provider prefix doesn't
# match.  Runtime fetch merges live values on top of these.

CONTEXT_WINDOW: dict[str, int] = {
    # ── GitHub (Models + Copilot) ─────────────────────────────────────────
    # Verified 2026-03-18 against GitHub Models UI + Copilot API.
    # Context sizes from GitHub Models marketplace (K = ×1000).
    # Claude
    "github/claude-haiku-4.5": 200_000,
    "github/claude-opus-4.5": 200_000,
    "github/claude-opus-4.6": 200_000,
    "github/claude-opus-4.6-1m": 1_000_000,
    "github/claude-sonnet-4": 144_000,
    "github/claude-sonnet-4.5": 200_000,
    "github/claude-sonnet-4.6": 200_000,
    # Gemini
    "github/gemini-2.5-pro": 173_000,
    "github/gemini-3-flash-preview": 173_000,
    # GPT-5.x
    "github/gpt-5-mini": 192_000,
    "github/gpt-5.1": 192_000,
    "github/gpt-5.2": 400_000,
    "github/gpt-5.2-codex": 400_000,
    "github/gpt-5.3-codex": 400_000,
    "github/gpt-5.4": 400_000,
    "github/gpt-5.4-mini": 400_000,
    # ── Azure OpenAI ────────────────────────────────────────────────────────
    # Source: learn.microsoft.com/azure/ai-services/openai/concepts/models
    # Verified 2026-03-18. Input token limits only.
    # GPT-5.x
    "azure/gpt-5.4": 1_050_000,
    "azure/gpt-5.3-codex": 400_000,
    "azure/gpt-5.2": 400_000,
    "azure/gpt-5.2-codex": 400_000,
    "azure/gpt-5.1": 400_000,
    "azure/gpt-5": 400_000,
    "azure/gpt-5-mini": 400_000,
    # o-series
    "azure/o4-mini": 200_000,
    "azure/o3": 200_000,
    "azure/o3-mini": 200_000,
    "azure/o1": 200_000,
}

DEFAULT_CONTEXT_WINDOW = 192_000

# ── Runtime fetch ─────────────────────────────────────────────────────────────

_fetch_done = threading.Event()
_fetch_started = False
_fetch_lock = threading.Lock()


def _fetch_from_apis() -> None:
    """Fetch live context windows from GitHub Models + Copilot APIs.

    Thread-safe: only one fetch runs; concurrent callers wait via Event.
    Silently falls back to static values on any error.
    """
    global _fetch_started  # noqa: PLW0603
    with _fetch_lock:
        if _fetch_started:
            return
        _fetch_started = True

    try:
        from workpilot.config.loader import load_config
        from workpilot.providers.resolver import _secret_or_env

        cfg = load_config()
        token = _secret_or_env(cfg.providers.github_copilot.token, "GITHUB_TOKEN")
    except Exception:
        token = None
    if not token:
        _fetch_done.set()
        return

    import httpx

    # 1. GitHub Models catalog
    try:
        resp = httpx.get(
            "https://models.github.ai/catalog/models",
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {token}",
                "X-GitHub-Api-Version": "2026-03-10",
            },
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            for m in data if isinstance(data, list) else data.get("models", []):
                mid = m.get("id", "")
                val = (m.get("limits") or {}).get("max_input_tokens")
                if not mid or not val:
                    continue
                bare = mid.split("/", 1)[-1].lower() if "/" in mid else mid.lower()
                v = int(val)
                CONTEXT_WINDOW[f"github/{bare}"] = v
                CONTEXT_WINDOW[bare] = v
            logger.debug(
                "Fetched {} models from GitHub Models catalog",
                len(data) if isinstance(data, list) else len(data.get("models", [])),
            )
    except Exception:
        pass

    # 2. Copilot /models API
    try:
        from workpilot.security.github_auth import get_copilot_token

        copilot_token = get_copilot_token(token)
        resp = httpx.get(
            "https://api.enterprise.githubcopilot.com/models",
            headers={
                "Authorization": f"Bearer {copilot_token}",
                "Accept": "application/json",
                "Copilot-Integration-Id": "vscode-chat",
            },
            timeout=10,
        )
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            for m in models:
                mid = m.get("id", "")
                val = ((m.get("capabilities") or {}).get("limits") or {}).get(
                    "max_context_window_tokens"
                )
                if not mid or not val:
                    continue
                name = mid.lower()
                v = int(val)
                # github/ and github_copilot/ share the same limits
                CONTEXT_WINDOW[f"github/{name}"] = v
                CONTEXT_WINDOW[f"github_copilot/{name}"] = v
                CONTEXT_WINDOW[name] = v
            logger.debug("Fetched {} models from Copilot API", len(models))
    except Exception:
        pass
    finally:
        _fetch_done.set()


# ── Lookup ────────────────────────────────────────────────────────────────────


def get_context_window(model: str) -> int:
    """Return the context window size for *model*.

    Lookup order:
    1. Exact match with full name (e.g. ``github_copilot/gpt-5.4``)
    2. Exact match bare name (e.g. ``gpt-5.4``)
    3. Longest prefix match on bare name
    4. DEFAULT_CONTEXT_WINDOW (192K)

    Waits up to 5s for background fetch to complete on first call.
    Falls back to static values if fetch hasn't finished.
    """
    _fetch_done.wait(timeout=5)

    full = model.lower()
    # Normalize: github_copilot/ → github/ (same limits)
    if full.startswith("github_copilot/"):
        full = "github/" + full[15:]

    # 1. Exact match with full name
    if full in CONTEXT_WINDOW:
        return CONTEXT_WINDOW[full]

    # 2. Try with github/ prefix (bare name → github/bare)
    bare = full.split("/", 1)[-1] if "/" in full else full
    github_key = f"github/{bare}"
    if github_key in CONTEXT_WINDOW:
        return CONTEXT_WINDOW[github_key]

    # 3. Longest prefix match on github/ keys
    best_len, best_val = 0, DEFAULT_CONTEXT_WINDOW
    for key, window in CONTEXT_WINDOW.items():
        prefix = key.split("/", 1)[-1] if "/" in key else key
        if bare.startswith(prefix) and len(prefix) > best_len:
            best_len = len(prefix)
            best_val = window
    return best_val
