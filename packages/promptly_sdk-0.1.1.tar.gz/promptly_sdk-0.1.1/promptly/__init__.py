"""
Promptly Python SDK - LLM cost optimization proxy.

Usage:
    from promptly import Promptly

    client = Promptly(api_key="sk-promptly-...")
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}]
    )
"""

from .client import Promptly, wrap

__version__ = "0.1.1"
__all__ = ["Promptly", "wrap"]
