from typing_extensions import NotRequired, TypedDict
from alchemy.core import Endpoint
from pydantic import TypeAdapter

class Address(TypedDict):
  address: str
  """Wallet address whose transaction history should be fetched."""
  networks: list[str]
  """Networks to query for this wallet address."""

class Transaction(TypedDict):
  network: NotRequired[str]
  hash: NotRequired[str]
  timeStamp: NotRequired[str]
  blockNumber: NotRequired[int]
  blockHash: NotRequired[str]
  nonce: NotRequired[int]
  transactionIndex: NotRequired[int]
  fromAddress: NotRequired[str]
  toAddress: NotRequired[str | None]

class Request(TypedDict):
  addresses: list[Address]
  """Array of address and networks pairs. The docs say this endpoint is currently limited to 1 address pair and at most 2 networks."""
  before: NotRequired[str]
  """Cursor pointing to the previous set of results."""
  after: NotRequired[str]
  """Cursor pointing to the end of the current set of results."""
  limit: NotRequired[int]
  """Maximum number of transactions to return in this page."""
  pageKey: NotRequired[str]
  """Pagination cursor returned by a previous response."""

class Response(TypedDict):
  transactions: list[Transaction]
  before: NotRequired[str | None]
  after: str | None
  totalCount: int | None

adapter = TypeAdapter(Response)

class History(Endpoint):
  async def __call__(self, request: Request, *, validate: bool | None = None) -> Response:
    """Fetches historical transactions for wallet addresses across supported networks. Alchemy documents this endpoint as beta and recommends migrating to `alchemy_getAssetTransfers`.
    
    - `request`
    - `validate`: Whether to validate the response against the expected schema (default: client setting). (default: None)
    
    [Official docs](https://www.alchemy.com/docs/data/portfolio-apis/portfolio-api-endpoints/portfolio-api-endpoints/get-transaction-history-by-address)"""
    r = await self.request('POST', '/transactions/history/by-address', json=request)
    
    if r.status_code != 200:
      self.raise_error(r)
    return adapter.validate_json(r.text) if self.should_validate(validate) else r.json()
