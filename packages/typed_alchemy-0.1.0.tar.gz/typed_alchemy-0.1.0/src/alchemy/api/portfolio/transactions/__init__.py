from alchemy.core import Router
from .history import History

class Transactions(Router):
  history: History
