"""
ASGI instrumentation for OpenTelemetry.
"""
import logging
from typing import Any

logger = logging.getLogger(__name__)


def instrument_asgi(app: Any) -> Any:
    """
    Wrap an ASGI application with OpenTelemetry middleware for HTTP/WebSocket tracing.
    """
    try:
        from opentelemetry.instrumentation.asgi import OpenTelemetryMiddleware
        return OpenTelemetryMiddleware(app)
    except ImportError:
        logger.debug("opentelemetry-instrumentation-asgi not installed, skipping ASGI instrumentation")
        return app
