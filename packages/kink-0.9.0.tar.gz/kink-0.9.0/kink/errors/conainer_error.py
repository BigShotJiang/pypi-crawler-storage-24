class ContainerError(RuntimeError):
    pass
