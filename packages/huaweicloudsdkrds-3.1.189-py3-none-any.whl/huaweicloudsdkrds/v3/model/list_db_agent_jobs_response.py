# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDbAgentJobsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'jobs': 'list[ListDbAgentJobsResult]',
        'total_count': 'int'
    }

    attribute_map = {
        'jobs': 'jobs',
        'total_count': 'total_count'
    }

    def __init__(self, jobs=None, total_count=None):
        r"""ListDbAgentJobsResponse

        The model defined in huaweicloud sdk

        :param jobs: 作业列表。
        :type jobs: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobsResult`]
        :param total_count: 作业总数。
        :type total_count: int
        """
        
        super().__init__()

        self._jobs = None
        self._total_count = None
        self.discriminator = None

        if jobs is not None:
            self.jobs = jobs
        if total_count is not None:
            self.total_count = total_count

    @property
    def jobs(self):
        r"""Gets the jobs of this ListDbAgentJobsResponse.

        作业列表。

        :return: The jobs of this ListDbAgentJobsResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobsResult`]
        """
        return self._jobs

    @jobs.setter
    def jobs(self, jobs):
        r"""Sets the jobs of this ListDbAgentJobsResponse.

        作业列表。

        :param jobs: The jobs of this ListDbAgentJobsResponse.
        :type jobs: list[:class:`huaweicloudsdkrds.v3.ListDbAgentJobsResult`]
        """
        self._jobs = jobs

    @property
    def total_count(self):
        r"""Gets the total_count of this ListDbAgentJobsResponse.

        作业总数。

        :return: The total_count of this ListDbAgentJobsResponse.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this ListDbAgentJobsResponse.

        作业总数。

        :param total_count: The total_count of this ListDbAgentJobsResponse.
        :type total_count: int
        """
        self._total_count = total_count

    def to_dict(self):
        import warnings
        warnings.warn("ListDbAgentJobsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDbAgentJobsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
