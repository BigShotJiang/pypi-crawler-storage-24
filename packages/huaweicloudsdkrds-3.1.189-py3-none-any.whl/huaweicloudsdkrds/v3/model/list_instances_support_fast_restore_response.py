# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInstancesSupportFastRestoreResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'support_fast_restore_list': 'list[SupportFastRestoreList]'
    }

    attribute_map = {
        'support_fast_restore_list': 'support_fast_restore_list'
    }

    def __init__(self, support_fast_restore_list=None):
        r"""ListInstancesSupportFastRestoreResponse

        The model defined in huaweicloud sdk

        :param support_fast_restore_list: 实例的极速恢复支持情况。
        :type support_fast_restore_list: list[:class:`huaweicloudsdkrds.v3.SupportFastRestoreList`]
        """
        
        super().__init__()

        self._support_fast_restore_list = None
        self.discriminator = None

        if support_fast_restore_list is not None:
            self.support_fast_restore_list = support_fast_restore_list

    @property
    def support_fast_restore_list(self):
        r"""Gets the support_fast_restore_list of this ListInstancesSupportFastRestoreResponse.

        实例的极速恢复支持情况。

        :return: The support_fast_restore_list of this ListInstancesSupportFastRestoreResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.SupportFastRestoreList`]
        """
        return self._support_fast_restore_list

    @support_fast_restore_list.setter
    def support_fast_restore_list(self, support_fast_restore_list):
        r"""Sets the support_fast_restore_list of this ListInstancesSupportFastRestoreResponse.

        实例的极速恢复支持情况。

        :param support_fast_restore_list: The support_fast_restore_list of this ListInstancesSupportFastRestoreResponse.
        :type support_fast_restore_list: list[:class:`huaweicloudsdkrds.v3.SupportFastRestoreList`]
        """
        self._support_fast_restore_list = support_fast_restore_list

    def to_dict(self):
        import warnings
        warnings.warn("ListInstancesSupportFastRestoreResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInstancesSupportFastRestoreResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
