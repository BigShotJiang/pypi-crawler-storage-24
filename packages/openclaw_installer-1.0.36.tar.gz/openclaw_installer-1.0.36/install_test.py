#!/usr/bin/env python3
"""Test the complete installation flow."""

import subprocess
from pathlib import Path

print("=== Testing OpenClaw Installation ===\n")

# Test 1: Install
print("1. Running installer...")
result = subprocess.run(
    ["openclaw-installer", "install", "--config", "ollama-config.yaml"],
    capture_output=True,
    text=True,
)
if result.returncode == 0:
    print("   [OK] Installation succeeded")
else:
    print(f"   [FAIL] Installation failed: {result.stderr}")
    exit(1)

# Test 2: Check wrapper
wrapper = Path.home() / "bin" / "openclaw.cmd"
if wrapper.exists():
    print("   [OK] Wrapper created")
else:
    print("   [FAIL] Wrapper not found")
    exit(1)

# Test 3: Test OpenClaw
print("\n2. Testing OpenClaw...")
result = subprocess.run(
    [str(wrapper), "--version"],
    capture_output=True,
    text=True,
)
if result.returncode == 0:
    print(f"   [OK] Version: {result.stdout.strip()}")
else:
    print(f"   [FAIL] Command failed: {result.stderr}")
    exit(1)

print("\n=== ALL TESTS PASSED ===")
