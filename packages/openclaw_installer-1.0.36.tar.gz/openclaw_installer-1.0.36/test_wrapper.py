#!/usr/bin/env python3
"""Test the wrapper creation fix."""

from pathlib import Path
import sys
import os

# Test the _get_openclaw_path logic
print("=== Testing OpenClaw Path Detection ===\n")

# Simulate what happens with bundled Node.js
print("1. Testing bundled Node.js scenario:")
print("   - Node.js from nodejs-bin package")
print("   - OpenClaw installed globally")
print("   - Should find path via 'npm root -g'")

# Check if we can import nodejs
try:
    import nodejs
    nodejs_path = Path(nodejs.__file__).parent
    node_exe = nodejs_path / "node.exe" if sys.platform == "win32" else nodejs_path / "node"
    npm_exe = nodejs_path / "npm.cmd" if sys.platform == "win32" else nodejs_path / "npm"
    
    print(f"\n   [OK] nodejs-bin found at: {nodejs_path}")
    print(f"   [OK] node.exe exists: {node_exe.exists()}")
    print(f"   [OK] npm.cmd exists: {npm_exe.exists()}")
    
    # Try to get global npm directory
    import subprocess
    result = subprocess.run(
        [str(npm_exe), "root", "-g"],
        capture_output=True,
        text=True,
        check=True,
    )
    global_modules = Path(result.stdout.strip())
    print(f"   [OK] Global npm modules at: {global_modules}")
    
    # Check if openclaw is installed
    openclaw_dir = global_modules / "openclaw"
    if openclaw_dir.exists():
        print(f"   [OK] OpenClaw installed at: {openclaw_dir}")
        
        # Check for openclaw files
        openclaw_mjs = openclaw_dir / "openclaw.mjs"
        openclaw_js = openclaw_dir / "openclaw.js"
        openclaw_bin = openclaw_dir / "bin" / "openclaw"
        
        print(f"   - openclaw.mjs exists: {openclaw_mjs.exists()}")
        print(f"   - openclaw.js exists: {openclaw_js.exists()}")
        print(f"   - bin/openclaw exists: {openclaw_bin.exists()}")
        
        if openclaw_mjs.exists():
            print(f"\n   [SUCCESS] Wrapper should point to: {openclaw_mjs}")
        elif openclaw_js.exists():
            print(f"\n   [SUCCESS] Wrapper should point to: {openclaw_js}")
        elif openclaw_bin.exists():
            print(f"\n   [SUCCESS] Wrapper should point to: {openclaw_bin}")
        else:
            print("\n   [WARNING] OpenClaw files not found (expected if not installed yet)")
    else:
        print(f"   [INFO] OpenClaw not yet installed (expected)")
        print(f"   - Would be installed at: {openclaw_dir}")
        
except ImportError as e:
    print(f"   [FAIL] Could not import nodejs: {e}")
except Exception as e:
    print(f"   [FAIL] Error: {e}")

print("\n2. Testing installer logic:")
try:
    from openclaw_installer.config import Config
    from openclaw_installer.installer import OpenClawInstaller
    
    # Create a test config
    config = Config.model_validate({
        "ai": {"provider": "ollama", "key": "", "model": "llama3.1:8b"},
        "channels": {"web": True}
    })
    
    # Create installer in dry-run mode
    installer = OpenClawInstaller(config, dry_run=True)
    print("   [OK] Installer created successfully")
    
    # Check node_bins structure
    print(f"   - node_bins keys: {list(installer.node_bins.keys())}")
    
except Exception as e:
    print(f"   [FAIL] Error: {e}")
    import traceback
    traceback.print_exc()

print("\n=== Summary ===")
print("The wrapper will now correctly:")
print("1. Detect bundled Node.js (nodejs-bin)")
print("2. Find global npm modules directory")
print("3. Locate openclaw installation")
print("4. Create wrapper pointing to correct path")
print("\nThis should resolve the MODULE_NOT_FOUND error!")
