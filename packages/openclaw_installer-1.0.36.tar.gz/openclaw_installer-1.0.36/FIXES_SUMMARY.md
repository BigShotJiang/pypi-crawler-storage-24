# OpenClaw Installer - Zero-Interaction Fix Summary

## Issue Fixed: Node.js Download Fallback & NPM Local Installation

### Root Cause
The installer had a critical bug where the `npm install` command was missing the `cwd` parameter, causing packages to be installed to the wrong directory (project root instead of `~/.local/openclaw-installer/openclaw/`).

### Critical Bug Fixed
**File:** `openclaw_installer/installer.py`
**Line:** 386
**Issue:** Missing `cwd=str(install_dir)` in subprocess.run() for npm install
**Impact:** openclaw package installed to wrong location, wrapper couldn't find it

```python
# Before (BROKEN):
result = subprocess.run(
    cmd,
    capture_output=True,
    text=True,
    env=env,
    timeout=300,
)

# After (FIXED):
result = subprocess.run(
    cmd,
    cwd=str(install_dir),  # ← Added this line
    capture_output=True,
    text=True,
    env=env,
    timeout=300,
)
```

## Complete Fix List

### 1. Removed nodejs-bin Dependency
- **Reason:** Bundled Node.js (nodejs-bin) fails on Windows
- **Solution:** Always download official Node.js v22.16.0 from nodejs.org when system Node.js is unavailable or broken
- **Benefit:** Reliable cross-platform support

### 2. Local NPM Installation
- **Before:** `npm install -g openclaw` (global install)
- **After:** `npm install openclaw` in local directory
- **Benefit:** Avoids system npm conflicts and permission issues
- **Location:** `~/.local/openclaw-installer/openclaw/node_modules/openclaw/`

### 3. Added NODE_PATH to Wrapper
- **Purpose:** Ensures Node.js can find modules regardless of current working directory
- **Windows wrapper:** `set "NODE_PATH=%APPDATA%\openclaw-installer\node\node_modules"`
- **Linux/macOS wrapper:** `export NODE_PATH="$HOME/.local/openclaw-installer/node/node_modules"`

### 4. Updated Path Resolution
- **Method:** `_get_openclaw_path()` now checks local install directory directly
- **Path:** `~/.local/openclaw-installer/openclaw/node_modules/openclaw/openclaw.mjs`
- **Benefit:** No npm commands needed to find installation

### 5. Enhanced System Node.js Detection
- **Before:** Only checked PATH for node
- **After:** Validates npm actually works, falls back to download if broken
- **Test:** `npm --version` with proper PATH set to verify functionality

### 6. NPM Cache Clearing
- **Added:** `npm cache clean --force` before installation
- **Benefit:** Prevents corrupted package installations
- **Retry:** Automatic retry with fresh Node.js download on failure

### 7. Exponential Backoff Retry
- **Attempts:** 3 with increasing delays (3s, 6s, 9s)
- **Fallback:** Downloads Node.js v22.16.0 on first failure
- **Zero-interaction:** No user prompts, automatic recovery

## Installation Flow (Zero-Interaction)

1. **Check System Node.js**
   - Look for node v22+ in PATH
   - Test npm works correctly
   - If broken/missing → download Node.js v22.16.0

2. **Clear NPM Cache**
   - Run `npm cache clean --force`
   - Prevents corrupted installs

3. **Local NPM Install**
   - Create install directory: `~/.local/openclaw-installer/openclaw/`
   - Run `npm install openclaw@{version}` in that directory
   - Set proper environment (PATH, NODE_PATH, npm_config_cache)

4. **Configure AI Provider**
   - Set environment variables from config
   - Run `openclaw onboard --yes` (non-blocking)

5. **Create Wrapper**
   - Windows: `~/.local/bin/openclaw.cmd`
   - Linux/macOS: `~/.local/bin/openclaw`
   - Sets NODE_PATH to find modules anywhere
   - Points to: `<install_dir>/openclaw/node_modules/openclaw/openclaw.mjs`

6. **Verify Installation**
   - Check openclaw.mjs exists
   - Test `openclaw --version`
   - Exit with code 0 on success

## Test Results

### Fresh Install (No Node.js present)
```
OpenClaw Installer

Setting up Node.js...
Downloading Node.js v22.16.0... OK
Extracting Node.js... OK
OK Node.js v22.16.0 ready
Installing OpenClaw latest... OK
Configuring AI provider... OK
Creating wrapper... OK
  Add to PATH: C:\Users\netge\bin
  Or use: %USERPROFILE%\bin\openclaw.cmd dashboard

Installation Complete!
Web UI: http://localhost:18789
```

### Verification Checklist
- ✅ Node.js v22.16.0 downloaded and extracted
- ✅ openclaw.mjs installed to correct location
- ✅ Wrapper script created with NODE_PATH
- ✅ Command executes: `openclaw --version` → "OpenClaw 2026.3.13 (61d171a)"
- ✅ Zero prompts during installation
- ✅ Zero errors during installation
- ✅ Exit code: 0

## Files Modified

1. **openclaw_installer/installer.py**
   - Removed nodejs-bin import and logic
   - Updated `find_node_js()` to only check system Node.js
   - Modified `_setup_node()` to download Node.js when needed
   - Fixed `_install_openclaw()` with missing `cwd` parameter
   - Updated `_get_openclaw_path()` to check local install directory
   - Enhanced `_create_wrapper()` with NODE_PATH

2. **pyproject.toml**
   - Removed nodejs-bin from dependencies

## Conclusion

The installer now successfully achieves **zero-interaction, unattended installation** on Windows with automatic Node.js download fallback. All critical bugs have been fixed, and the installation completes without any user prompts or errors.
